

# Generated at 2022-06-20 15:54:37.742980
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    preferences = ['en_US.utf8', 'en_US', 'POSIX', 'C']

    # Test 1: locale returns empty string on locale -a
    test_module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(required=False, type='list', default=preferences)
        )
    )
    test_module.run_command = lambda x, check_rc=True: ('', '', 0)
    assert test_module.get_best_parsable_locale(preferences) == preferences[0]

    # Test 2: locale return lists of locales and en_US.utf8 is returned
    # as the locale preference

# Generated at 2022-06-20 15:54:48.378000
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Create a fake module
    class FakeModule(object):
        def __init__(self, locale_found=True, locale_output='en_US.utf8'):
            self._locale_found = locale_found
            self._locale_output = locale_output

        def get_bin_path(self, name):
            return name if self._locale_found else None

        def run_command(self, args):
            return (0, self._locale_output, '')

    # Get the best parsable locale
    module = FakeModule()
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    # Get the best parsable locale with a custom list of preferred locales
    module = FakeModule()

# Generated at 2022-06-20 15:54:58.163942
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible
    import tempfile
    import os.path
    import os.path
    import pytest

    # NOTE: We must use this /tmp/ansible_get_best_parsable_locale_bin directory
    # as some tests are watching to see if this file is created. On the other
    # hand, if it exists and gets deleted, later tests fail.
    LOCALE_TEST_BIN_DIR = u'/tmp/ansible_get_best_parsable_locale_bin'
    LOCALE_TEST_MODULE_PATH = u'/tmp/ansible_get_best_parsable_locale_modules'


# Generated at 2022-06-20 15:55:09.265305
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        from ansible.module_utils.ansible_freeipa_module import FakeModule
    except ImportError:
        from .ansible_freeipa_module import FakeModule

    # Test defaults
    module = FakeModule()
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    # Test utf8
    module = FakeModule(run_command_locale_a_out='C.utf8\nen_US.utf8\nen_US.UTF-8\n')
    locale = get_best_parsable_locale(module)
    assert locale == 'C.utf8'

    # Test no utf8
    module = FakeModule(run_command_locale_a_out='C\nen_US\n')
    locale = get_best_

# Generated at 2022-06-20 15:55:20.357526
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.system.base import get_facts
    from ansible.module_utils.facts.system.base import get_file_content

    class FakeModule(object):

        def __init__(self):
            self.params = {}
            self.facts = {'system': 'Linux', 'distribution': 'RedHat'}

        def get_bin_path(self, binary, required=False):
            return binary

        def run_command(self, cmd):
            return (0, '', '')

    def fake_get_facts(self, module, collected_facts=None, cache=False,
                       gather_subset=None, timeout=10):
        return self.facts


# Generated at 2022-06-20 15:55:31.517975
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.common.removed import removed_module
    from ansible.module_utils._text import to_bytes

    # Windows has no locale included, but it seems a reasonable test
    def mock_run(self, args, **kwargs):
        out = '''
C
POSIX
en_US.utf8
'''
        return 0, to_bytes(out), b''

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    locale = get_best_parsable_locale(removed_module, preferences=preferences)
    assert locale == 'C.utf8', "Should return C.utf8 when it is the first preference that's available"

    preferences = ['fr_FR.utf8', 'C', 'POSIX']
    locale = get

# Generated at 2022-06-20 15:55:35.274710
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class AnsibleModule(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path
        def get_bin_path(self, name):
            if name == 'locale':
                return self.bin_path
            return None

        def run_command(self, cmd):
            if 'locale' in cmd:
                print(cmd)
                if '-a' in cmd:
                    return 0, '''C
en_AU.utf8
en_CA.utf8
en_GB.utf8
en_US.utf8
POSIX
''', ''

# Generated at 2022-06-20 15:55:45.140563
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile

    # Prepare a fake "locale"
    with tempfile.NamedTemporaryFile(delete=False) as fp:
        fp.write(b'''
            #!/bin/sh
            echo "C.utf8"
            exit 0
        ''')
        fp.flush()

        m = AnsibleModule(argument_spec={})
        m.set_binary_file(fp.name)

        # Get "locale" output
        output = get_best_parsable_locale(m)

        assert output == 'C.utf8', "Expected 'C.utf8', but got %s" % output
        import os
        os.unlink(fp.name)

# Generated at 2022-06-20 15:55:55.440581
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible
    from ansible.module_utils.basic import AnsibleModule, get_module_path
    module = AnsibleModule(
        argument_spec=dict(),
    )
    my_test_module_path = get_module_path("test_get_best_parsable_locale")
    module.warn = AnsibleModule.warn
    module.fail_json = AnsibleModule.fail_json
    module.get_bin_path = AnsibleModule.get_bin_path
    module._ansible_version = ansible.__version__

    # No locales installed
    module.run_command = lambda a: (0, '', '')
    locale = get_best_parsable_locale(module)
    assert(locale == 'C')

    # C.utf8 and POSIX are installed
   

# Generated at 2022-06-20 15:56:05.086975
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    try:
        from ansible.utils.display import Display
        display = Display()
    except ImportError:
        from ansible.utils import display
        display = display

    display.debug("Trying to get best locale for parsing en_US output")

    # Try to get the best locale for parsing output in English
    try:
        pref_locale = get_best_parsable_locale(module, raise_on_locale=False)
        display.debug("Found locale %s" % pref_locale)
    except RuntimeWarning:
        display.debug("Failed to get locale, will use 'C' locale")
        pref_locale = 'C'

    pref_locale = get_best_pars

# Generated at 2022-06-20 15:56:20.833865
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # stubbing everything out, tests should not rely on module
    # so we can test this function independently
    # ansible.module_utils.basic.AnsibleModule

    class StubAnsibleModule:
        def __init__(self):
            self.fail_json = None
            self.run_command_rc = 0
            self.run_command_out = 'C.utf8\nen_US.utf8\nC\nPOSIX'
            self.locale_command = None

        def get_bin_path(self, cmd):
            if cmd != 'locale':
                return None

            return self.locale_command

        def run_command(self, cmd):
            if cmd[0] != 'locale':
                return 1, '', 'Unable to get locale information'

            return self.run_command_

# Generated at 2022-06-20 15:56:24.053671
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale = get_best_parsable_locale()
    assert locale == 'C' or locale == 'POSIX'

# Generated at 2022-06-20 15:56:32.986496
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''test_get_best_parsable_locale: Assert on other than English locales'''
    from ansible.module_utils.basic import AnsibleModule
    import os

    # test that we can execute the function get_best_parsable_locale()
    module = AnsibleModule(argument_spec={})
    locale = module.get_best_parsable_locale()

    # test that the locale returned is in English
    assert 'en' in locale

    # test when the user sets a preference bigger than the system has
    os.environ['LANGUAGE'] = 'fr:de:it:pt'

# Generated at 2022-06-20 15:56:42.489925
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict()
    )
    # If this raises an exception, we shoudl have failed
    locale = get_best_parsable_locale(module, raise_on_locale=True)
    assert locale == "C"

    # Try to get a better locale
    try:
        module.run_command = lambda x: (0, "C.utf8\nen_US.utf8\n", "")
        locale = get_best_parsable_locale(module, raise_on_locale=True)
        assert locale == "en_US.utf8"
    except RuntimeWarning:
        pass

# Generated at 2022-06-20 15:56:45.570343
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Basic unit test which checks the get_best_parsable_locale function.
    '''
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)
    assert locale

# Generated at 2022-06-20 15:56:47.898608
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())
    result = get_best_parsable_locale(module, ['C', 'C.utf8'], False)
    assert result == 'C'

# Generated at 2022-06-20 15:56:59.028805
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from io import StringIO
    import sys

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2, PY3

    def make_module(c_locale):
        return AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=False,
        )
    if PY2:
        import __builtin__ as builtins
    else:
        import builtins
    builtins.__dict__['open'] = open

    def run_command(self, cmd):
        if len(cmd) < 2:
            raise RuntimeError()

# Generated at 2022-06-20 15:57:08.013434
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import platform
    import os

    if platform.system() == 'Windows':
        os.environ['LANGUAGE'] = 'en_US'
        os.environ['LC_ALL'] = 'English_United States'
        os.environ['LC_MESSAGES'] = 'English_United States'
        os.environ['LANG'] = 'en_US'
        assert os.getenv('LC_ALL') == 'English_United States'
        assert get_best_parsable_locale(AnsibleModule()) == 'en_US'
    else:
        assert get_best_parsable_locale(AnsibleModule()) == 'C'

# Generated at 2022-06-20 15:57:18.699567
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModuleArgs

    class MyModule(AnsibleModule):

        def __init__(self, *args, **kwargs):
            super(MyModule, self).__init__(argument_spec=dict(), *args, **kwargs)

        def get_bin_path(self, arg, opt_dirs=[]):
            return arg

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    my_module = MyModule(argument_spec=AnsibleModuleArgs(),
                         supports_check_mode=True)

    module_print = str(my_module)

    assert get_best_parsable_locale(my_module) == 'C'
    assert get

# Generated at 2022-06-20 15:57:24.622521
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert to_native('C') == get_best_parsable_locale(module=None)
    assert to_native('C') == get_best_parsable_locale(module=None, preferences=None, raise_on_locale=False)
    assert to_native('C') == get_best_parsable_locale(module=None, preferences=None, raise_on_locale=True)
    assert to_native('C.iso') == get_best_parsable_locale(module=None, preferences=['C.iso'], raise_on_locale=False)

# Generated at 2022-06-20 15:57:35.718599
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):

        def __init__(self, languages=['C']):
            self.languages = languages
            self.test_results = []
            self.test_errors = []

        def get_bin_path(self, tool):
            return True

        def run_command(self, commands):
            self.test_results.append(commands)
            return 0, '\n'.join(self.languages), ''

    a = AnsibleModule(argument_spec={})

    t = TestModule()
    assert a.get_best_parsable_locale(t) == 'C'

    t = TestModule(['C', 'POSIX'])

# Generated at 2022-06-20 15:57:46.868040
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Locale is not found
    assert get_best_parsable_locale(ModuleStub([]), raise_on_locale=False) == 'C'

    # Locale is found, but not in our preferences
    assert get_best_parsable_locale(ModuleStub(['foo']), raise_on_locale=False) == 'C'

    # First preference is found
    assert get_best_parsable_locale(ModuleStub(['posix', 'foo']), raise_on_locale=False) == 'POSIX'

    # Second preference is found
    assert get_best_parsable_locale(ModuleStub(['bar', 'posix', 'foo']), raise_on_locale=False) == 'POSIX'

    # Multiple preferences are found
    assert get_best_

# Generated at 2022-06-20 15:57:48.884736
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    mod = MockAnsibleModule()
    assert 'C' == get_best_parsable_locale(mod)

# Generated at 2022-06-20 15:57:55.879720
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test for get_best_parsable_locale
    '''
    result = None
    try:
        from ansible.module_utils.basic import AnsibleModule
        module = AnsibleModule(argument_spec={})
        result = get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True)
    except RuntimeWarning:
        pass

    assert result == 'C'

# Generated at 2022-06-20 15:58:04.003722
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.facts.system
    import os
    import sys

    # I can't seem to get the stdout module to work, so we'll just stub out some
    # output from the locale command.
    class stdout:
        @staticmethod
        def read():
            return '''C
C.UTF-8
en_US.utf8
en_US
POSIX
'''

    class TempFileManager:
        def __init__(self, fd):
            self.fd = fd
        def __enter__(self):
            return self.fd
        def __exit__(self, exc_type, exc_value, traceback):
            os.remove(self.fd.name)


# Generated at 2022-06-20 15:58:10.949468
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.local import LOCALHOST

    mod_obj = AnsibleModule(argument_spec={}, supports_check_mode=True)
    mod_obj.connection = LOCALHOST
    mod_obj.params = {'ANSIBLE_LOCALHOST': LOCALHOST}

    try:
        locale = get_best_parsable_locale(mod_obj)
    except RuntimeWarning:
        locale = None
    assert locale is not None, "locale returned None and we expected one"

# Generated at 2022-06-20 15:58:16.954397
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    # This is a dict ONLY for testing input vars
    params = {}
    module = AnsibleModule(argument_spec=params)
    # We want to check the exceptions
    found = get_best_parsable_locale(module, raise_on_locale=True)
    assert found == 'C'

# Generated at 2022-06-20 15:58:27.317948
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os

    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    # set in test/../test/runner/filter/inventory
    # also need to set ANSIBLE_PYTHON_INTERPRETER in test/../test/runner/filter/inventory
    # or we'll get error: no module named ansible.module_utils.common.process
    result = get_best_parsable_locale(module=module, preferences=None, raise_on_locale=False)

    # result is expected to be 'C'
    # on OSX and Windows, expected to be 'en_US.utf8'
    # on Windows, also sometimes get 'English_United States.1252'
    # sometimes get 'English_United States

# Generated at 2022-06-20 15:58:33.695941
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.warnings = []
            self.failures = []
            self.rc = 0
            self.stdout = ''
            self.tmpdir = tempfile.mkdtemp()
            self.bin_dir = [self.tmpdir]

        def run_command(self, args, input_data=None, check_rc=True, cwd=None):
            self.args = args
            self.rc = 0
            self.stdout = ''

            return self.rc, self.stdout, None

        def get_bin_path(self, name, opt_dirs=None, required=False, check_readable=False):
            return name

    module = FakeModule()

    # Testing default preferences
   

# Generated at 2022-06-20 15:58:43.593531
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['C.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(None, ['en_US.utf8', 'C.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(None, ['ru_RU.utf8']) == 'C'
    assert get_best_parsable_locale(None, ['ru_RU.utf8'], True) == 'C'

# Generated at 2022-06-20 15:59:01.979293
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.facts import ModuleBase
    import os
    import sys
    import tempfile
    import shlex

    class FakeModule(ModuleBase):
        def __init__(self, *args, **kwargs):
            super(FakeModule, self).__init__(*args, **kwargs)
            self._cache_dir = tempfile.mkdtemp(dir='/tmp')

        def get_bin_path(self, *args, **kwargs):
            if args[0] == 'locale':
                tool_dir = os.path.dirname(os.path.realpath(sys.argv[0]))
                return os.path.join(tool_dir, args[0])
            else:
                raise RuntimeWarning("Could not find required test tool %s" % args[0])


# Generated at 2022-06-20 15:59:09.191669
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.distribution.redhat
    import ansible.module_utils.facts.system.distribution.sles
    import ansible.module_utils.facts.system.distribution.ubuntu

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    module.run_command = lambda x, check_rc=True, close_fds=True: (0, 'C\nen_US.utf8\nen_US.UTF-8\n', '')

    prefs = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_

# Generated at 2022-06-20 15:59:18.735007
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # We create a fake module to call the function
    class FakeModule(object):
        def __init__(self):
            self._locale = None
            self._locale_out = None
            self._locale_err = None
            self._locale_rc = 0

        def get_bin_path(self, name):
            if name == 'locale':
                return '/bin/locale'
            else:
                return None

        def run_command(self, args):
            assert args == ['/bin/locale', '-a']
            return (self._locale_rc, self._locale_out, self._locale_err)

    # Test 1 : Default values
    module = FakeModule()
    module._locale_out = "C\nen_US.utf8\nen_US.UTF-8"

# Generated at 2022-06-20 15:59:27.157012
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.utils.path import unfrackpath

    import ansible.module_utils.basic
    best_locale = ansible.module_utils.basic.get_best_parsable_locale(ansible.module_utils.basic.AnsibleModule(
    ))
    assert True == unfrackpath('/usr/bin/locale') in ansible.module_utils.basic.AnsibleModule.get_bin_path.__globals__[
        '_bin_paths']
    assert best_locale in ['C', 'en_US.utf8', 'C.utf8', 'POSIX']

# Generated at 2022-06-20 15:59:36.315782
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Setting up mocked module
    class MockModule:
        def __init__(self):
            self.run_command_result = 0
            self.run_command_out = ''
            self.run_command_err = ''

        def run_command(self, args):
            return self.run_command_result, self.run_command_out, self.run_command_err

        def get_bin_path(self, name):
            return 'locale'

    mock_module = MockModule()

    # First we check the default output of get_best_parsable_locale()
    default_out = get_best_parsable_locale(mock_module)
    assert 'C' == default_out, 'Default output should be "C", but was %s' % default_out

    # Now we check the best

# Generated at 2022-06-20 15:59:43.702240
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path

    # This function interacts with the OS
    # pylint: disable=protected-access
    class AnsibleModuleMock(AnsibleModule):
        def __init__(self):
            self._ansible_no_log = False
            self.run_command = self._run_command_mock
            self.get_bin_path = self._get_bin_path_mock

        @staticmethod
        def _get_bin_path_mock(name):
            found = [None, '/bin/echo', '/usr/bin/echo', '/usr/local/bin/echo']
            return found[get_bin_path(name)]

       

# Generated at 2022-06-20 15:59:53.204368
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''
    # Empty module mock
    class EmptyModule(object):
        def __init__(self, **kwargs):
            self.ansible_facts = {'ansible_os_family': 'Linux'}

        def get_bin_path(self, bin_name):
            return

    # Mocked module with data for testing
    class MockModule(object):
        def __init__(self, **kwargs):
            self.ansible_facts = {'ansible_os_family': 'Linux'}

        def run_command(self, cmd):
            return (0, 'en_US.utf8\nC\nC.utf8\nPOSIX', '')


# Generated at 2022-06-20 15:59:57.976879
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Basic Test get_best_parsable_locale function
    '''
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, raise_on_locale=True) == 'C'

# Generated at 2022-06-20 15:59:59.871320
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(
        locale=dict(type='str')
    ))

    result = get_best_parsable_locale(module, raise_on_locale=True)
    assert result == 'C'

# Generated at 2022-06-20 16:00:07.296593
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    current_module = ('c', 'C')
    default_module = ('c', 'C')
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.run_command = lambda x: (0, '\n'.join(current_module), '')

    # if we pass in an empty list of locale preferences, we should get the default locale
    assert default_module == get_best_parsable_locale(module, preferences=None)

    # if we pass in an empty list of available locales, we should get the default locale
    module.run_command = lambda x: (0, '', '')
    assert default_module == get_best_parsable_locale(module, preferences=None)

    # if we pass in

# Generated at 2022-06-20 16:00:22.386347
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-20 16:00:32.525612
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})
    inner_module = AnsibleModule({})

    # test with no locale command
    setattr(module, 'get_bin_path', lambda x: None)
    res = get_best_parsable_locale(module)
    assert res == 'C'

    # test with empty available locales
    setattr(module, 'get_bin_path', lambda x: 'locale')
    setattr(module, 'run_command', lambda x: (0, '', ''))
    res = get_best_parsable_locale(module)
    assert res == 'C'

    # test with available locales and one we want
    setattr(module, 'get_bin_path', lambda x: 'locale')
    set

# Generated at 2022-06-20 16:00:43.373638
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict()
    )

    valid_locales = ['C', 'C.UTF-8', 'C.utf8', 'POSIX', 'POSIX.utf8', 'en_US.UTF-8', 'en_US.utf8', 'en_US']
    invalid_locales = ['C.UTF-16', 'S.utf8', 'template.utf8']
    default_locale = 'C'

    for test_locale in valid_locales:
        assert test_locale == get_best_parsable_locale(module, [test_locale])

    for test_locale in invalid_locales:
        assert default_locale == get_best_parsable

# Generated at 2022-06-20 16:00:54.868423
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule, AnsibleModuleError

    class FakeModule:

        def __init__(self):
            self.params = {}
            self.exit_json = lambda x, **kwargs: x
            self.fail_json = lambda x, **kwargs: x

        def run_command(self, cmd):
            import subprocess

            if cmd[-1] != '-a':
                raise ValueError("unexpected command to run: %s" % cmd)

            cmd.append(self.params['locale_out'])
            return subprocess.call(cmd)

        def get_bin_path(self, cmd):
            if cmd not in ('locale', 'x'):
                raise ValueError("unexpected command to check: %s" % cmd)


# Generated at 2022-06-20 16:01:07.755103
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule

    # Basic test with locales
    class RunCommand:
        def __init__(self, out, err, rc):
            self.out = out
            self.err = err
            self.rc = rc

        def __call__(self, cmd, cwd=None, data=None, binary_data=False):
            return self.rc, self.out, self.err

    # Basic test with locale
    locale = "locale"
    locale_locale_a_stdout_1 = "C\nPOSIX\nUTF-8\nUTF-8\nen_US.UTF-8\n"

# Generated at 2022-06-20 16:01:17.065001
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.facts import ModuleArgsParser
    from ansible.module_utils.facts.system.locale import get_locale_facts


# Generated at 2022-06-20 16:01:23.415216
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile
    import os
    import sys
    import shutil
    import subprocess

    saved_env = None
    temp_dir = None

# Generated at 2022-06-20 16:01:34.093377
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import EnvironmentDummy

    class AnsibleModuleDummy(object):
        def __init__(self):
            self.params = {}
            self.args = {}
            self.fail_json = lambda **args: None


        def get_bin_path(self, cmd, required=False, opt_dirs=[]):
            return cmd


        def run_command(self, cmd):
            return (0, 'C\nen_US.utf8\nC.UTF-8', '')


# Generated at 2022-06-20 16:01:37.075118
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    # just test that it doesn't throw an exception
    get_best_parsable_locale(module, preferences=None, raise_on_locale=False)

# Generated at 2022-06-20 16:01:46.902173
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeModule:
        def __init__(self, results):
            self.results = results
        def get_bin_path(self, program):
            if program == 'locale':
                return 'locale'
            else:
                return None
        def run_command(self, command):
            if command == ['locale', '-a'] and self.results:
                return 0, self.results, None
            else:
                return 1, None, None

    # Test that the default is used if the program is not found
    module = FakeModule(results=None)
    assert get_best_parsable_locale(module, raise_on_locale=False) == 'C'
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

    # Test

# Generated at 2022-06-20 16:02:24.909661
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import sys
    if sys.version_info[0] == 2:
        from ansible.module_utils.basic import AnsibleModule
    else:
        from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils import basic
    from ansible.module_utils.six import PY3

    class ModuleFailJson(object):
        # for unit test only
        def __init__(self, module):
            self.module = module

        def __getattr__(self, name):
            return getattr(self.module, name)

        def fail_json(self, *args, **kwargs):
            raise Exception(str(kwargs))


# Generated at 2022-06-20 16:02:35.353117
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' test_get_best_parsable_locale

        Because we can't test this on every system we run on we
        test the expected output on systems that have the locale
        present.
    '''

    # test function with raise_on_locale False
    module = AnsibleModule(argument_spec={})

    # normal return of first match
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'C']) == 'C.utf8'

    # normal return of first match (second preference)
    assert get_best_parsable_locale(module, preferences=['C', 'C.utf8']) == 'C'

    # normal return of first match (match in the middle)

# Generated at 2022-06-20 16:02:45.709405
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Check function parsing an utf-8 locale
    module = {}
    module['run_command'] = lambda x, y=None, z=None: (0, 'C.utf8\nen_US.utf8', '')
    assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'

    # Check function parsing a non utf-8 locale
    module['run_command'] = lambda x, y=None, z=None: (0, 'C\nen_US.utf8', '')
    assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Check function parsing a non utf

# Generated at 2022-06-20 16:02:54.685845
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    # Two cases
    # 1. locale utils not available in the system
    #    then, the function return C
    # 2. locale utils is available
    #    if one of the preferred locales is available in the system
    #    then, the function will return one of preferred locales
    #    if none of the preferred locales is available
    #    then, the function will return the first locale in the system
    None_return = get_best_parsable_locale(module)
    assert None_return == 'C'
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

# Generated at 2022-06-20 16:03:04.295015
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = None
    assert get_best_parsable_locale(module) == "C"
    assert get_best_parsable_locale(module, ['C', 'POSIX']) == "C"

    module = MockModule()
    module.run_command = Mock(return_value=(0, 'en_US.utf8\nen_US.UTF-8\nen_US.UTF8\nC\nC.utf8\nPOSIX\n', ''))
    assert get_best_parsable_locale(module) == "C.utf8"
    assert get_best_parsable_locale(module, ['en_US.utf8', 'en_US.UTF-8', 'en_US.UTF8']) == "en_US.utf8"
    assert get_best_parsable

# Generated at 2022-06-20 16:03:05.488058
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-20 16:03:06.810296
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

# Generated at 2022-06-20 16:03:08.434164
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    assert get_best_parsable_locale(AnsibleModule({})) == "C"

# Generated at 2022-06-20 16:03:16.255248
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    preferences = ['en_US.utf8', 'en_GB.utf8', 'en_AU.utf8']
    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module, preferences=preferences) == 'en_US.utf8'
    assert get_best_parsable_locale(module) == 'C'

    preferences = ['en_US.utf8', 'en_GB.utf8', 'en_AU.utf8', 'C']
    assert get_best_parsable_locale(module, preferences=preferences) == 'C'

    preferences = [None]
    assert get_best_parsable_locale(module, preferences=preferences) == 'C'

# Generated at 2022-06-20 16:03:27.138858
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Mock-up module
    module = AnsibleModule({}, check_invalid_arguments=False)

    # Mock-up module.run_command
    # Return system locale
    module.run_command = lambda args, check_rc=True: (0, ['C.utf8', 'C.UTF-8',
                                                         'C.UTF8', 'C.utf-8',
                                                         'C'], '')
    # First locale should be returned
    locale = get_best_parsable_locale(module, ['C.UTF-8', 'C.utf8'])
    assert(locale == 'C.UTF-8')

    # Mock-up module.run_command
    # Return system locale

# Generated at 2022-06-20 16:04:05.159549
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    name = 'get_best_parsable_locale'
    locale_path = 'locale'
    # Test 1:
    #   inputs:
    #       preferences = ['it_IT.utf8']
    #       raise_on_locale = False
    #   returns:
    #       C
    #   expected_return:
    #       C
    #   expected_cmd:
    #       ['locale', '-a']
    module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(default=['it_IT.utf8']),
            raise_on_locale=dict(default=False, type='bool'),
        )
    )
    # Mock module.run_command

# Generated at 2022-06-20 16:04:08.615087
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale = get_best_parsable_locale()
    assert locale in ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    locale = get_best_parsable_locale(preferences=['foo', 'bar', 'baz'])
    assert locale == 'C'

# Generated at 2022-06-20 16:04:12.440354
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    best_locale = get_best_parsable_locale(module, preferences)
    assert best_locale in preferences

# Generated at 2022-06-20 16:04:23.200185
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec={})

    # Test with no exceptions
    best_locale = get_best_parsable_locale(module)
    assert best_locale == 'C'

    # Test with english
    best_locale = get_best_parsable_locale(module, preferences=['en_US.utf8'])
    assert best_locale == 'en_US.utf8'

    # Test with no locale tool
    module.run_command = lambda x: (1, '', 'failed')
    best_locale = get_best_parsable_locale(module)
    assert best_locale == 'C'

# Test with exceptions raised