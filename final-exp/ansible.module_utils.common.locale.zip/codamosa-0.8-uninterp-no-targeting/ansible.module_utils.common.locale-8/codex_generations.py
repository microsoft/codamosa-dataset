

# Generated at 2022-06-20 15:54:34.081725
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    def execute_locale_command(module, command, output='', error='', rc=0):
        return output, error, rc

    import mock
    import types

    class AnsibleModuleMock(object):
        def __init__(self, execute_cmd=execute_locale_command):
            self.execute_command = execute_cmd

        def get_bin_path(self, cmd):
            return cmd

        def run_command(self, cmd):
            res = self.execute_command(self, cmd)
            return res

    my_module = AnsibleModuleMock()

    assert get_best_parsable_locale(my_module) == 'C'

    # Test for a successful preference
    preferences = ['C', 'en_US.utf8']


# Generated at 2022-06-20 15:54:44.943862
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    my_module = AnsibleModule(
        argument_spec={
            'preferences': {'type': 'list', 'default': None},
            'raise_on_locale': {'type': 'bool', 'default': False},
        },
        required_one_of=[['preferences']],
        supports_check_mode=True
    )

    # Test different cases
    module_params = my_module.params
    locale = get_best_parsable_locale(my_module, **module_params)

    # Test default value
    assert locale == 'C'
    # Test different preferences where one is available and one should be returned

# Generated at 2022-06-20 15:54:54.334185
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    saved_path = os.environ['PATH']
    os.environ['PATH'] = '/usr/bin:/bin'


# Generated at 2022-06-20 15:55:01.583041
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 15:55:13.028459
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
        Test that returns the preferred locale or 'C'
    """
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    # No preferences for locale so this returns 'C'
    assert get_best_parsable_locale(module) == 'C'

    # return 'en_US.utf8'
    prefs = ['en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(module, prefs) == 'en_US.utf8'

    # return 'en_US.utf8'
    prefs = ['C', 'en_US.utf8']

# Generated at 2022-06-20 15:55:22.989907
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    class FakeModule(AnsibleModule):
        def __init__(self):
            self.fail_json = lambda **kwargs: {}
        def get_bin_path(self, a):
            return "locale"

    module = FakeModule()

    module.run_command = lambda a, b, c=None, d=None: (0, "C\nen_US.UTF-8\nen_DK.UTF-8", None)
    assert(get_best_parsable_locale(module) == 'C')
    assert(get_best_parsable_locale(module, ['en_US.UTF-8']) == 'en_US.UTF-8')

# Generated at 2022-06-20 15:55:24.191823
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = None
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

# Generated at 2022-06-20 15:55:31.386456
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    assert 'C' == get_best_parsable_locale(module, preferences=[])
    assert 'C' == get_best_parsable_locale(module, preferences=['abc'])
    assert 'C' == get_best_parsable_locale(module, preferences=['abc'], raise_on_locale=True)
    assert 'C' != get_best_parsable_locale(module, preferences=['C'])

# Generated at 2022-06-20 15:55:43.009293
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    assert get_best_parsable_locale(test_module) == 'C'
    test_module.run_command = run_command_sideeffect(0, '', '')
    assert get_best_parsable_locale(test_module) == 'C'
    test_module.run_command = run_command_sideeffect(0, 'C.utf8', '')
    assert get_best_parsable_locale(test_module) == 'C.utf8'

# Generated at 2022-06-20 15:55:48.798461
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_module = lambda: None
    locale_module.get_bin_path = lambda x: '/usr/bin/locale'
    locale_module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nC.utf8\nPOSIX\n', '')

    assert get_best_parsable_locale(locale_module) == 'C.utf8'
    assert get_best_parsable_locale(locale_module, preferences=['en_US.utf8', 'POSIX']) == 'en_US.utf8'
    assert get_best_parsable_locale(locale_module, preferences=['en_US', 'POSIX']) == 'POSIX'

# Generated at 2022-06-20 15:56:03.552520
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import shutil
    import tempfile
    import subprocess

    def create_mock_locale_tool(temp_dir, return_code, output):
        locale = tempfile.NamedTemporaryFile(mode='w+', dir=temp_dir, prefix='locale.', suffix='.py', delete=False)
        locale.write("#!/usr/bin/env python3\n")
        locale.write("import sys\n")
        locale.write("sys.exit(%d)\n" % return_code)
        locale.write("sys.stdout.write(\"%s\")\n" % output)
        locale.close()
        os.chmod(locale.name, 0o755)
        return locale

    # no locale tool
    temp

# Generated at 2022-06-20 15:56:11.789595
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule(argument_spec={})

    # No prefs passed
    assert get_best_parsable_locale(test_module) == 'C'

    # prefs passed and found
    assert get_best_parsable_locale(test_module, preferences=['C.utf8', 'en_US.utf8']) == 'C.utf8'

    # prefs passed and not found
    assert get_best_parsable_locale(test_module, preferences=['C.utf8', 'en_US.utf8'], raise_on_locale=True) == 'C.utf8'

# Generated at 2022-06-20 15:56:16.380431
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    preferences = ['C.UTF-8', 'en_US.UTF-8', 'POSIX']
    assert get_best_parsable_locale(AnsibleModule(), preferences) == 'C.UTF-8'

# Generated at 2022-06-20 15:56:24.188242
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.compat.tests.mock import Mock

    module = Mock()
    result = get_best_parsable_locale(module)
    assert result == 'C'

    module.get_bin_path.return_value = None
    result = get_best_parsable_locale(module)
    assert result == 'C'

    module.get_bin_path.return_value = "locale"
    module.run_command.return_value = (0, "C\nC.UTF-8\nC.utf8\nPOSIX\nen_US.utf8", "")
    result = get_best_parsable_locale(module)
    assert result == 'C.utf8'


# Generated at 2022-06-20 15:56:33.040393
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from unittest import mock
    from units.module_utils.common import AnsibleModule

    class TestAnsibleModule(AnsibleModule):
        def get_bin_path(self, arg, required=False):
            return '/bin/locale'

        def run_command(self, args):
            if '/bin/locale' in args:
                return (0, 'C.utf8\nen_US.utf8\nC\nPOSIX', '')
            else:
                return (1, 'N/A', 'Not possible to get locale')

    module = TestAnsibleModule(argument_spec={'preferences': dict})

    result = get_best_parsable_locale(module, module.params['preferences'])
    assert result == 'C.utf8'

    result = get_best

# Generated at 2022-06-20 15:56:43.529282
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import ansible.module_utils.common.process
    module = basic.AnsibleModule(argument_spec={})
    module.run_command = lambda cmd, cwd=None: (0, 'C\nen_US.utf8\nen_US\nC.utf8', '')

    # Test normal behavior
    assert module.get_best_parsable_locale() == 'C.utf8'

    # Test behavior when first preference is not found
    module.run_command = lambda cmd, cwd=None: (0, 'en_US.utf8\nen_US\nC.utf8', '')
    assert module.get_best_parsable_locale(preferences=['C', 'POSIX']) == 'C.utf8'

    # Test behavior

# Generated at 2022-06-20 15:56:50.078282
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(module, preferences=['POSIX.utf8', 'C.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(module, preferences=['POSIX', 'POSIX.utf8', 'C.utf8']) == 'POSIX'
    assert get_best_parsable_locale(module, preferences=['C.utf8']) == 'C.utf8'

# Generated at 2022-06-20 15:56:51.920894
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_found = get_best_parsable_locale(None)
    assert locale_found == 'C'

# Generated at 2022-06-20 15:56:54.199018
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    assert get_best_parsable_locale(AnsibleModule(), preferences=['C', 'C.UTF-8']) == 'C'
    assert get_best_parsable_locale(AnsibleModule(), preferences=['en_US', 'C']) == 'C'
    assert get_best_parsable_locale(AnsibleModule(), preferences=['C', 'en_US']) == 'C'

# Generated at 2022-06-20 15:57:05.455303
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common._collections_compat import Mapping

    class MockModule:
        def __init__(self, run_command_rc, run_command_out):
            self.run_command_rc = run_command_rc
            self.run_command_out = run_command_out

        def get_bin_path(self, cmd, required=False):
            return cmd

        def run_command(self, cmd):
            out = None
            if cmd[0] == 'locale' and cmd[1] == '-a':
                rc = self.run_command_rc
                out = self.run_command_out
            else:
                rc = 1
            return rc, out, ''


# Generated at 2022-06-20 15:57:15.415753
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec=dict())

    # C is always there, I hope
    assert get_best_parsable_locale(mod) == 'C'

# Generated at 2022-06-20 15:57:21.578456
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Unit test to test that method get_best_parsable_locale correctly finds a locale in a list of preferences
    """
    module = object()
    preferences = ["en_US.UTF-8", "en_US.iso885915@euro", "en_US", "C"]
    available = ["en_US.iso885915@euro", "en_US.UTF-8", "C", "en_US", "POSIX"]
    assert get_best_parsable_locale(module, preferences, available) == preferences[1]

# Generated at 2022-06-20 15:57:32.076245
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    if sys.version_info < (2, 7):
        raise Exception("Python 2.6 or lower is not supported")
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
    )
    assert get_best_parsable_locale(module) == 'C'
    module = AnsibleModule(
        argument_spec=dict(),
    )
    assert get_best_parsable_locale(module, ['C', 'POSIX']) == 'C'
    module = AnsibleModule(
        argument_spec=dict(),
    )
    assert get_best_parsable_locale(module, ['C', 'POSIX', 'C.utf8']) == 'C.utf8'

# Generated at 2022-06-20 15:57:44.028573
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    # Without module you get a SystemWarning here because its a RuntimeWarning that gets raised
    # If a warning is raised we can just go with the default 'C'
    # If we had a module we could test that a RuntimeWarning would get raised
    locale = get_best_parsable_locale(None)
    assert locale == 'C'

    # If we pass in a list of preferences and the first one is in the list but the second is not
    # then we should get the first one back
    preferences = ['POSIX', 'en_US.utf8', 'C']
    locale = get_best_parsable_locale(None, preferences)
    assert locale == 'POSIX'

    # If we pass in a list of preferences and the first one is not in the list but the second is
    #

# Generated at 2022-06-20 15:57:55.682466
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock module and return values for get_bin_path and run_command
    module = {'get_bin_path': lambda x:x, 'run_command': lambda x: (0, '', '')}
    assert get_best_parsable_locale(module, None) == 'C'
    module = {'get_bin_path': lambda x:None, 'run_command': lambda x: (0, '', '')}
    assert get_best_parsable_locale(module, None) == 'C'
    module = {'get_bin_path': lambda x:True, 'run_command': lambda x: (0, 'C.UTF-8', '')}
    assert get_best_parsable_locale(module, None) == 'C'

# Generated at 2022-06-20 15:57:57.925358
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    assert get_best_parsable_locale(AnsibleModule()) == 'C'

# Generated at 2022-06-20 15:58:08.630319
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec={})
    import os
    import tempfile
    try:
        fd, path = tempfile.mkstemp()
        os.write(fd, b'C.utf8\nen_US.utf8\nen_US.iso88591\nen_US\nfr_FR\n')
        os.close(fd)
        mod.get_bin_path = lambda _: path
        mod.run_command = lambda args: (0, args[1], '')
    except Exception:
        pass
    assert get_best_parsable_locale(mod, raise_on_locale=True) == 'en_US.utf8'

# Generated at 2022-06-20 15:58:11.135672
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    results = get_best_parsable_locale(module)
    assert results == 'C'

# Generated at 2022-06-20 15:58:23.538920
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class module(object):
        @staticmethod
        def get_bin_path(command):
            if command in ['locale']:
                return command

            return ''

        @staticmethod
        def run_command(args):
            if args[0] == 'locale':
                return (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
            elif args[0] == 'C.utf8':
                return (0, 'C.utf8', '')
            elif args[0] == 'en_US.utf8':
                return (0, 'en_US.utf8', '')
            elif args[0] == 'C':
                return (0, 'C', '')

# Generated at 2022-06-20 15:58:30.809969
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    class FakeModule(object):
        def __init__(self, module_name, arguments=None, check_invalid_arguments=None,
                     bypass_checks=False, no_log=False,
                     run_command_environ_update=None):
            self.module_name = module_name
            self.arguments = arguments or []
            self.check_invalid_arguments = check_invalid_arguments
            self.bypass_checks = bypass_checks
            self.no_log = no_log
            self.run_command_environ_update = run_command_environ_update


# Generated at 2022-06-20 15:58:46.502959
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """Test the results of get_best_parsable_locale for different mocked outputs"""

    import sys

    # Python 2 & 3 compatible
    if sys.version_info[0] < 3:
        from mock import patch
    else:
        from unittest.mock import patch

    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 15:58:54.403460
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from units.compat.mock import mock_module_helper, MagicMock
    import sys

    mock_module = MagicMock()

    mock_module.run_command.return_value = (0, 'C\nen_US.utf8', None)

    if sys.version_info[0] < 3:
        mock_module_helper(mock_module, 'run_command', return_value=(0, 'C\nen_US.utf8', None),
                           side_effect=IOError('failed to find locale'))
    else:
        mock_module_helper(mock_module, 'run_command', return_value=(0, b'C\nen_US.utf8', None),
                           side_effect=IOError('failed to find locale'))

    assert get_best_parsable_

# Generated at 2022-06-20 15:59:05.134811
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys
    import mock

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )

    # Test if binary is not found
    with mock.patch('ansible.module_utils.basic.AnsibleModule.get_bin_path') as get_bin_path_mock:
        get_bin_path_mock.return_value = None
        assert module.get_bin_path("locale") is None
        assert module.get_bin_path("locale") is None

    # Test locale not found in path
    with mock.patch('ansible.module_utils.basic.AnsibleModule.get_bin_path') as get_bin_path_mock:
        get_bin

# Generated at 2022-06-20 15:59:11.969846
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    locales = ["fr_CH.utf8", "en_US.utf8", "en_US.utf8", "C.utf8", "POSIX"]
    for pref in locales:
        module = AnsibleModule(argument_spec={})
        result = get_best_parsable_locale(module, preferences=[pref])
        assert result == pref

# Generated at 2022-06-20 15:59:21.792708
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    found = get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX', 'en_US.UTF8'])
    assert found == 'C.utf8'

    found = get_best_parsable_locale(module, preferences=['C.utf8', 'en_US', 'C', 'POSIX', 'en_US.UTF8'])
    assert found == 'C.utf8'

    found = get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8', 'C', 'POSIX', 'en_US.UTF8'])

# Generated at 2022-06-20 15:59:27.834939
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec={})
    best_locale = get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX'], True)
    if best_locale == 'C':
        assert True, "best_locale is C"
    else:
        raise AssertionError("test_get_best_parsable_locale, best_locale is not C")

# Generated at 2022-06-20 15:59:36.788251
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec=dict())


# Generated at 2022-06-20 15:59:39.810592
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    locale = get_best_parsable_locale(mod)

    assert locale is not None

# Generated at 2022-06-20 15:59:46.192051
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Ensure that the function get_best_parsable_locale returns the first
    matching preferred locale or 'C' which is the default.
    '''
    from ansible.module_utils.basic import AnsibleModule

    # define test class with mocked AnsibleModule instance
    class TestGetBestParsableLocale:
        def __init__(self, module_args, no_cli=False):
            self.params = module_args
            self.boostrap()

        def boostrap(self):
            self._ansible_module_instance = True
            self.params = {
                'remote_user': 'test',
                'private_key_file': 'test',
                'port': 22,
                'host_key_checking': None,
            }


# Generated at 2022-06-20 15:59:54.580454
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.utils.hashing import md5s
    import ansible.module_utils.basic
    import tempfile
    import os

    # Fake module instance
    module = type('obj', (object,), {'params': {
        'fetch': [
            {'url': 'https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/module_utils/basic.py',
             'dest': tempfile.mkdtemp()}
        ]
    }})
    module.run_command = ansible.module_utils.basic._execute_command
    module.get_bin_path = ansible.module_utils.basic._load_bin_path

    # Default: use only C
    locale = get_best_parsable_locale(module)
    assert locale == 'C'



# Generated at 2022-06-20 16:00:11.693829
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    preferences = ['C.utf8', 'POSIX']
    posix_locale = get_best_parsable_locale(module, preferences)
    assert posix_locale == 'C', 'Expected POSIX locale but got %s' % posix_locale

# Generated at 2022-06-20 16:00:14.511270
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule()
    assert get_best_parsable_locale(m) == 'C'

# Generated at 2022-06-20 16:00:17.392322
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    assert get_best_parsable_locale(AnsibleModule(argument_spec={})) == 'C'

# Generated at 2022-06-20 16:00:25.190589
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Stub out the module_utils.basic.AnsibleModule class so we don't have to do a
    # full import and have to mock out dependencies.
    import types
    class _AnsibleModule:
        def get_bin_path(self, arg):
            return 'bin/' + arg
        def run_command(self, arg):
            return (0, 'out', 'err')
        def check_mode(self):
            return False
    def _ansible_module_create(argument_spec=None, **kwargs):
        cls = types.new_class('AnsibleModule', (object,), {'__doc__': 'AnsibleModule class'})
        cls.base_class = _AnsibleModule
        cls.__init__ = lambda self: None
        return cls()
    module_

# Generated at 2022-06-20 16:00:33.463627
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test 'POSIX' locale
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    # Test 'en_US.utf8' locale
    if 'C.utf8' in module.run_command([module.get_bin_path('locale'), '-a'])[1].strip().splitlines():
        locale = get_best_parsable_locale(module, ['en_US.utf8', 'C.utf8'])
        assert locale == 'en_US.utf8'
    else:
        locale = get_best_parsable_locale(module, ['en_US.utf8', 'C.utf8'])
        assert locale

# Generated at 2022-06-20 16:00:43.476668
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # An empty preferences list should default to 'C'
    assert get_best_parsable_locale(m, preferences=[]) == 'C'

    # make sure we still fall back to 'C' if locale bin can't be found or fails
    m.run_command = lambda cmd: (127, '', 'Command %s not found' % cmd[0])
    assert get_best_parsable_locale(m, raise_on_locale=True) == 'C'

    m.run_command = lambda cmd: (0, 'unsupported.utf8', '')

# Generated at 2022-06-20 16:00:54.867482
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule()

    def mocked_run_command(cmd, cmd_args=None, prompt_regex=None, answer=None, data=None):
        if cmd == 'env':
            return 0, None, None
        if cmd == 'locale' and cmd_args == ['-a']:
            return 0, 'C\nen_US.utf8\nen_US\nen_US.utf8\nC.utf8', None
        return 0, None, None
    m.run_command = mocked_run_command

    assert get_best_parsable_locale(m) == 'C'
    assert get_best_parsable_locale(m, preferences=['C', 'C.utf8', 'en_US.utf8'])

# Generated at 2022-06-20 16:01:07.753362
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Mocking the AnsibleModule class
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    class AnsibleModuleFake(AnsibleModule):

        def __init__(self):
            pass

        def get_bin_path(self, cmd, required=False):
            if cmd == 'locale':
                return 'locale'

    class AnsibleRunResult(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.stdout = out
            self.stderr = err

        def __enter__(self):
            return AnsibleRunResult(self.rc, self.stdout, self.stderr)

        def __exit__(self, type, value, traceback):
            return False



# Generated at 2022-06-20 16:01:17.065825
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Raise an assertion error if the test doesn't pass
    class Module(object):
        def run_command(self, command):
            # Return the same command if proper
            if command[0] == 'locale' and command[1] == '-a':
                return 0, 'C\nC.UTF-8\nPOSIX\na_DK.UTF-8\nb_BV.UTF-8\n', ''
            else:
                raise AssertionError("get_best_parsable_locale() wasn't called correctly")

        def get_bin_path(self, command, *args, **kwargs):
            return "locale"

    module = Module()
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    locale = get_best_parsable_loc

# Generated at 2022-06-20 16:01:23.439914
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    """
    ModuleFixture is used to create an AnsibleModule instance as a fixture.
    The AnsibleModule is needed when mocking the module.run_command method.
    """

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_bin_path
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils import basic

    import mock
    import pytest

    # Verify that when 'locale' is not found, that the default locale of 'C' is returned

# Generated at 2022-06-20 16:01:42.102633
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = get_best_parsable_locale('AnsibleModule')
    assert module == 'C'

# Generated at 2022-06-20 16:01:51.737462
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    # test that it returns 'C' default posix
    found = get_best_parsable_locale(module)
    assert found == 'C'
    # test that it returns locale that is available and that is first in list of preferences
    lang_1_pref_1 = get_best_parsable_locale(module, preferences=['de_DE.utf8', 'en_US.utf8'])
    lang_1_pref_2 = get_best_parsable_locale(module, preferences=['en_US.utf8', 'de_DE.utf8'])
    assert lang_1_pref_1 == 'en_US.utf8'

# Generated at 2022-06-20 16:01:58.614460
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test case with no arguments
    ansible_module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    result = get_best_parsable_locale(ansible_module)
    assert result == "C"

    # Test case with preferences as input
    ansible_module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    result = get_best_parsable_locale(ansible_module, ['C', 'POSIX'])
    assert result == "C"

# Generated at 2022-06-20 16:02:08.915104
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['en_US.utf8', 'en_US', 'C', 'en_GB.utf8', 'en_GB', 'POSIX']
    available = ['ab_CD', 'C', 'C.utf8', 'C.UTF-8', 'de_DE', 'de_DE.utf8', 'de_DE.UTF-8', 'en_US.utf8', 'en_US', 'en_US.UTF-8', 'POSIX']

    assert get_best_parsable_locale(None, preferences=None, raise_on_locale=False) == 'C'
    assert get_best_parsable_locale(None, preferences, raise_on_locale=False) == 'en_US.utf8'

# Generated at 2022-06-20 16:02:10.387596
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-20 16:02:12.733346
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == 'C'
    assert get_best_parsable_locale(preferences=['pt_BR.utf8']) == 'C'

# Generated at 2022-06-20 16:02:23.041024
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class TestModule(object):
        """AnsibleModule object stub"""
        def __init__(self, run_command_result=None):
            self._run_command_result = run_command_result

        def get_bin_path(self, name, required=False):
            return True

        def run_command(self, args, executable=None, run_in_check_mode=False, no_log=False):
            return self._run_command_result

    # in this test we check that the function returns the first valid locale from the list
    test_module = TestModule(run_command_result=(0, 'en_US\nen_US.utf8', None))
    # a weird case where the terminal does not support utf8

# Generated at 2022-06-20 16:02:33.861152
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == 'C'
    assert get_best_parsable_locale(preferences=['FOO', 'BAR']) == 'C'
    assert get_best_parsable_locale(preferences=['C', 'POSIX']) == 'C'

    # Fake an AnsibleModule instance
    class AnsibleModule():
        def __init__(self):
            self.params = {}
        def get_bin_path(self, s):
            return s
        def run_command(self, cmd):
            return (0, 'C\nPOSIX\nC.UTF-8\nC.utf8', '')
    assert get_best_parsable_locale(AnsibleModule()) == 'C'
    assert get_best_parsable

# Generated at 2022-06-20 16:02:38.503690
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule({})

    # test case 1
    assert mod.get_best_parsable_locale() == 'C', "Result should be 'C'"
    # test case 2
    assert mod.get_best_parsable_locale(['en', 'C']) == 'C', "Result should be 'C'"
    # test case 3
    assert mod.get_best_parsable_locale(['foobar']) == 'C', "Result should be 'C'"

# Generated at 2022-06-20 16:02:45.322382
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Setup test
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    # Test
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['notthere']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C', 'notthere']) == 'C'

# Generated at 2022-06-20 16:03:10.189928
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    # test if function return C
    module.run_command = lambda cmd, shell=False, check_rc=True, close_fds=True: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # test if function return language_code.encoding
    module.run_command = lambda cmd, shell=False, check_rc=True, close_fds=True: (0, 'language_code.encoding', '')
    assert get_best_parsable_locale(module) == 'language_code.encoding'

    # test if function return language_code

# Generated at 2022-06-20 16:03:11.946901
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale == get_best_parsable_locale

# Generated at 2022-06-20 16:03:18.090192
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule:
        @staticmethod
        def get_bin_path(module_name):
            return True

        @staticmethod
        def run_command(args):
            return True

    locale = get_best_parsable_locale(AnsibleModule, preferences=None, raise_on_locale=False)
    assert locale in ['C.utf8', 'en_US.utf8', 'POSIX'], "Failed to find valid locale: %s" % locale

    preferences = ['C', 'POSIX', 'C.utf8']
    locale = get_best_parsable_locale(AnsibleModule, preferences=preferences, raise_on_locale=False)
    assert locale in ['C', 'POSIX'], "Failed to find valid locale from list of preferences: %s" % locale


# Generated at 2022-06-20 16:03:28.951167
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    out = '''C
C.UTF-8
en_US.utf8
POSIX
'''
    err = ''
    rc = 0
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    module.run_command = lambda x: (rc, StringIO(out), StringIO(err))
    module.NO_LOCALE_CTYPE = 'C'

# Generated at 2022-06-20 16:03:34.675599
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['a', 'b', 'c']) == 'a'
    assert get_best_parsable_locale(None, ['a', 'b', 'c', 'POSIX']) == 'POSIX'
    assert get_best_parsable_locale(None, ['a', 'b', 'c', 'd', 'POSIX']) == 'POSIX'

# Generated at 2022-06-20 16:03:44.663965
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test function when there is no binary 'locale' available
    def run_command_mock(cmd, check_rc=True):
        if cmd[0] == 'locale':
            return (1, '', '')
        else:
            return (0, 'out', '')

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(run_command=run_command_mock)
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    # Test function when approach to get available locales fails
    def run_command_mock(cmd, check_rc=True):
        if cmd[0] == 'locale':
            return (1, None, '')
        else:
            return (0, 'out', '')

    module

# Generated at 2022-06-20 16:03:47.787414
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(m) == 'C'

# Generated at 2022-06-20 16:03:49.337888
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test = get_best_parsable_locale('test')
    assert test == 'C'

# Generated at 2022-06-20 16:03:56.549777
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

    # We need to mock locale module
    def mock_run_command(self, cmd, check_rc=True, close_fds=True, encoding=None, errors=None, binary_data=False):
        # Return C.utf-8
        return 0, 'C.utf8\n', ''

    module = AnsibleModule(argument_spec={})
    module.run_command = mock_run_command
    best_locale = get_best_parsable_locale(module, ["C.utf8", "en_US.utf8", "C", "POSIX"])
    assert best_locale == "C.utf8"

# Generated at 2022-06-20 16:04:05.159220
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    import sys

    module = AnsibleModule(
        argument_spec={},
    )

    # Should not raise exception
    try:
        get_best_parsable_locale(module, raise_on_locale=False)
    except RuntimeError:
        ex = get_exception()
        traceback = sys.exc_info()[2]
        raise AssertionError('Should not have raised an exception.\n%r' % (ex,))

    # Should raise exception
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
    except RuntimeError:
        pass