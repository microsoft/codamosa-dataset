

# Generated at 2022-06-20 15:54:36.761267
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # expected data
    prefs = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    # expected posix locale tool output
    locale_list_output = (
        'C\n'
        'C.UTF-8\n'
        'POSIX\n'
        'en_US.utf8\n'
    )

    # expected modules output

# Generated at 2022-06-20 15:54:47.438634
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule, missing_required_lib
    import mock

    running_env = {}

    # create an AnsibleModule mock object
    module = mock.Mock(spec=AnsibleModule)

    # set needed attributes
    module.run_command.return_value = (0, 'C.utf8\nen_US.utf8\nC', '')
    module.get_bin_path.return_value = 'locale'
    module.safe_eval.return_value = {}

    # invoke the function
    result = get_best_parsable_locale(module)
    assert result == 'C.utf8'

    # test for exceptions raise
    running_env['locale_exception'] = 'yes'

# Generated at 2022-06-20 15:54:58.024324
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 15:55:06.157348
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Assert function is able to pick the available best parsable locale given in preferences list.
    # Also, it is able to pick the C when preferences are not given.
    from ansible.module_utils.basic import NO_DEFAULT, AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-20 15:55:17.501265
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import iteritems

    module = AnsibleModule(
        argument_spec={
            'fail_on_locale': dict(type='bool', default=True),
            'preferred': dict(type='list', default=None)
        }
    )

    locale = module.get_bin_path("locale")
    if not locale:
        module.fail_json(msg='could not find \'locale\' tool')


# Generated at 2022-06-20 15:55:23.644429
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    import sys

    module = AnsibleModule(argument_spec=dict())
    if sys.version_info[0] > 2:
        assert module._executable == sys.executable
    else:
        assert module._executable == sys.executable.decode("utf-8")
    #print("Best locale: %s" % get_best_parsable_locale(module))
    assert isinstance(get_best_parsable_locale(module), str), "get_best_parsable_locale return value is not a string"

# Generated at 2022-06-20 15:55:30.231539
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # When we specify a list of preferred locales to the get_best_parsable_locale method
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    # And when the method get_best_parsable_locale is called with the preferred locale list
    locale = get_best_parsable_locale(None, preferences=preferences)
    # Then the locale 'C' should be returned
    assert locale == 'C'

# Generated at 2022-06-20 15:55:42.357613
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # The purpose of this function is to get the best locale in a list that is available
    # we test with a list and a non-utf8 version of C, POSIX and en_US.utf8
    # some of these are just duplicates but it tests that we are finding the
    # best suitable locale in the list
    preferences = ['C.utf8', 'en_US.utf8', 'POSIX', 'C', 'en_US.utf8']
    try:
        import ansible.module_utils.basic
        locale_module = ansible.module_utils.basic.AnsibleModule
    except ImportError:
        import ansible.module_utils.basic_common
        locale_module = ansible.module_utils.basic_common.AnsibleModule
    test_module = locale_module(argument_spec={})
    assert test

# Generated at 2022-06-20 15:55:48.738625
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.compat.tests import mock
    from ansible.compat.tests.mock import patch

    from ansible.utils.file_functions import get_best_parsable_locale

    # mock the module
    mock_module = mock.MagicMock()

    # os.getcwd
    mock_getcwd = mock.Mock()
    mock_getcwd.return_value = '/home/ansible'
    with patch.dict('sys.modules', {'os.path': mock_getcwd}):
        mock_module.run_command.return_value = (0, 'en_US.UTF-8', '')
        assert get_best_parsable_locale(mock_module) == 'en_US.UTF-8'

        mock_module.run_command.return_

# Generated at 2022-06-20 15:55:55.337717
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    am = AnsibleModule(argument_spec={})
    if not PY3:
        am.byte_str = str
    else:
        am.byte_str = None

    out = get_best_parsable_locale(am, raise_on_locale=False)
    # On my system, there is no locale named posix, so it will default to 'C'
    assert out == 'C'

# Generated at 2022-06-20 15:56:03.870951
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

# Generated at 2022-06-20 15:56:07.152207
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule(argument_spec={}, supports_check_mode=True)

    assert get_best_parsable_locale(mod) == "C"

# Generated at 2022-06-20 15:56:08.758052
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale({}, raise_on_locale=False)

# Generated at 2022-06-20 15:56:14.280648
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' test get_best_parsable_locale '''

    # python 2.6 requires import inside function
    # pylint: disable=F0401
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    # passing in module to function as opposed to global
    # as the unit tests for this module do not use global
    # pylint: disable=E1120
    assert get_best_parsable_locale(test_module)

# Generated at 2022-06-20 15:56:23.108086
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test function get_best_parsable_locale()
    '''

    arguments = dict(
        bin_path='/bin:/usr/bin',
        get_bin_path=lambda x: x,
        check_conditional_deps=lambda x: False,
        _debug=True,
        ansible_debug=False,
        ansible_verbosity=2,
        _ansible_version_info=['0', '9', '1'],
        no_log=False,
        run_command=lambda x, check_rc=None, executable=None: (0, 'en_US.UTF-8', None),
    )

    from collections import namedtuple
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(**arguments)

    locale = get

# Generated at 2022-06-20 15:56:28.285909
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-20 15:56:36.211012
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['en_US.utf8', 'POSIX']) == 'en_US.utf8' or get_best_parsable_locale(None, ['en_US.utf8', 'POSIX']) == 'POSIX'
    assert get_best_parsable_locale(None, ['en_US.utf8', 'POSIX', 'C.utf8', 'C']) == 'C.utf8' or get_best_parsable_locale(None, ['en_US.utf8', 'POSIX', 'C.utf8', 'C']) == 'C'

# Generated at 2022-06-20 15:56:43.372699
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleFallbackNotFound
    from ansible.module_utils import common_koji

    # Create a dummy module object, because we don't want to run this test
    # when this function is used as a module_util.
    dummy_module = AnsibleModule(argument_spec={})

    # Run the get_best_parsable_locale function
    best_locale = common_koji.get_best_parsable_locale(dummy_module)

    # Assert that locale is set to C
    assert best_locale == 'C'

# Generated at 2022-06-20 15:56:49.671283
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''

    try:
        assert "UTF-8" == get_best_parsable_locale(None, ["UTF-8"])
    except RuntimeWarning:
        pass
    else:
        # This test should have thrown a RuntimeWarning, so fail
        raise AssertionError("RuntimeWarning exception not raised for locale not found.")

# Generated at 2022-06-20 15:57:01.184096
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import mock
    import atexit
    import time
    import re

    class AnsibleModule:
        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     check_invalid_arguments=True, mutually_exclusive=None, required_together=None, required_one_of=None,
                     add_file_common_args=False):
            self.argument_spec = argument_spec
            self.bypass_checks = bypass_checks
            self.no_log = no_log
            self.check_invalid_arguments = check_invalid_arguments
            self.mutually_exclusive = mutually_exclusive or []
            self.required_one_of = required_one_of or []

# Generated at 2022-06-20 15:57:16.471868
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import copy

    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    import ansible.module_utils.basic as basic_utils

    # Fake up a module class
    class FakeModule(object):
        def __init__(self, out):
            self.run_command = mock.Mock(return_value=out)


# Generated at 2022-06-20 15:57:27.061237
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """This is not actually a unit test but illustrates how get_best_parsable_locale works.

    The output from the function get_best_parsable_locale is dependent on the system locale
    settings and there is no easy way to mock it. This is just a small illustration
    on how the function works.
    """
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({}, supports_check_mode=False)

    print("## Testing get_best_parsable_locale function ##")
    print("\nTest 1 with default preferences")
    print("Result: %s\n" % get_best_parsable_locale(module))

    print("Test 2 with a preference")
    preferences = ['fi_FI.utf8']

# Generated at 2022-06-20 15:57:38.888267
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Ugly hack to get the module to work in test
    import mock
    import ansible.module_utils.common.collections

    # mocking the module
    module = mock.Mock(
        get_bin_path=mock.Mock(return_value=True),
        run_command=mock.Mock(return_value=(0, "", "")),
        params=dict()
    )

    # mocking the module.run_command to return an empty string
    module.run_command.return_value = (0, "C\nen_US.utf8\nen_US.ISO8859-1\nC.utf8", "")

    # Test 1: Test one prefered locale, but not the best one
    locale = get_best_parsable_locale(module, ['en_US.utf8'])

# Generated at 2022-06-20 15:57:44.367920
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    preferences = ['en_US.utf8', 'en_US.UTF-8', 'C.UTF-8', 'C.utf8']
    locale_name = get_best_parsable_locale(ansible.module_utils.basic.AnsibleModule(), preferences)
    assert locale_name in preferences

# Generated at 2022-06-20 15:57:56.037785
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    from ansible.module_utils.common.process import get_bin_path

    class TestModule(object):
        def __init__(self):
            self.get_bin_path = get_bin_path

        def run_command(self, args, **kwargs):
            if args[0] == 'locale':
                print("Pretending to run locale tool")
                if args[1] == '-a':
                    # fake out a few locales
                    return 0, "C.UTF-8\nen_US\nen_US.utf8", ""
            else:
                return 1, "", "Command not found"

    t = TestModule()
    m = ansible.module_utils.basic.AnsibleModule(argument_spec={}, supports_check_mode=False)

# Generated at 2022-06-20 15:58:04.087704
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_utility = '/usr/bin/locale'
    locale = [locale_utility, '-a']
    test_preferences = ['en_US.utf8', 'C.utf8', 'C', 'POSIX']


# Generated at 2022-06-20 15:58:12.835776
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=False)


# Generated at 2022-06-20 15:58:25.225493
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class TestModule():
        def get_bin_path(self, *args, **kwargs):
            return 'locale'

        def run_command(self, *args, **kwargs):
            return 0, 'C\nen_US.utf8\nC.UTF-8\n', ''

    module = TestModule()

    assert get_best_parsable_locale(module) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['en_GB.utf8', 'C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_GB.utf8', 'C'], raise_on_locale=True) == 'C'
    assert get

# Generated at 2022-06-20 15:58:25.699489
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-20 15:58:32.068511
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os, sys

    # Test get_best_parsable_locale when 'locale' tool is not there
    temp_module = AnsibleModule(argument_spec=dict(locale=dict(type='str')),
                                check_invalid_arguments=False)
    temp_module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(temp_module) == 'C'

    # Test get_best_parsable_locale when 'locale -a' raises an exception
    temp_module.run_command = lambda x: (1, None, None)
    assert get_best_parsable_locale(temp_module) == 'C'

    # Test get_best_parsable_loc

# Generated at 2022-06-20 15:58:42.993770
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    # We use a mock of the module class
    # pylint: disable=no-name-in-module,import-error
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.module_utils.basic import AnsibleModule

    # Make sure Python thinks our output has a utf8 encoding
    if sys.version_info[0] == 3:
        sys.stdout = open(sys.stdout.fileno(), mode='w', encoding='utf8', buffering=1)  # pylint: disable=no-member

    class MockModule:
        def __init__(self):
            self.params = {}
            self.params['id'] = 1
            self.params['name'] = 'foo'


# Generated at 2022-06-20 15:58:54.116344
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import platform

    test_preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    test_best = 'C'
    test_bad_locale = False

    def _run_bad_locale(cmd, *args):
        return (127, '', '')


# Generated at 2022-06-20 15:59:04.851474
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    from tempfile import NamedTemporaryFile
    from os import environ
    from os.path import exists
    from os import remove
    from shutil import copy
    import sys


# Generated at 2022-06-20 15:59:16.161404
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # define a mock module class to test function
    class AnsibleModule:
        def __init__(self):
            self.params = dict()
            self.called_internal_module = False
            self.result = dict(rc=0, changed=False, failed=False)
            self.params['name'] = 'test_module'
            self.connection = 'local'

        def exit_json(self, **kwargs):
            self.called_internal_module = True

        def run_command(self, args):
            return 0, 'C\nen_US.utf8', ''

    # Test for default usage
    module = AnsibleModule()
    assert 'en_US.utf8' == get_best_parsable_locale(module)

    # Test locale list has no locale
    module = AnsibleModule()

# Generated at 2022-06-20 15:59:17.308407
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # TODO: Properly test this function
    assert True

# Generated at 2022-06-20 15:59:23.010842
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    module = AnsibleModule(argument_spec=dict())
    get_best_parsable_locale(module, raise_on_locale=True)

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-20 15:59:33.623904
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # TODO: unit test should not use AnsibleModule
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 15:59:41.517949
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['en_US.utf8', 'POSIX', 'C.utf8', 'C']
    class AnsModule():
        def __init__(self):
            pass

        def get_bin_path(self, search_name):
            if "locale" in search_name:
                return "/usr/bin/locale"
            return None


# Generated at 2022-06-20 15:59:52.724825
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import pytest
    from collections import namedtuple
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(object):
        def __init__(self, module_name='', bin_path='', params={}):
            self.params = params
            self.call_args = []

        def get_bin_path(self, exe, required=False, opt_dirs=None):
            self.call_args.append((exe, required, opt_dirs))
            if exe == 'locale':
                return 'locale'


# Generated at 2022-06-20 16:00:03.225326
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests.mock import Mock

    module = Mock()
    module.get_bin_path = Mock(return_value='/usr/bin/locale')
    module.run_command = Mock(return_value=(0, '', ''))

    with patch.object(AnsibleModule, 'get_bin_path', module.get_bin_path):
        with patch.object(AnsibleModule, 'run_command', module.run_command):
            # Test when preferred locale is not available
            module.run_command.return_value = (0, '', '')

# Generated at 2022-06-20 16:00:20.895159
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict

    # Test mocked get_bin_path() method, no locale
    params = ImmutableDict(dict(test=1))
    fake_module = basic.AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    def fake_get_bin_path(tool):
        if tool == 'locale':
            return None
        return True
    fake_module.get_bin_path = fake_get_bin_path
    assert get_best_parsable_locale(fake_module, []) == 'C'

    # Test mocked run_command() method
    fake_module = basic.AnsibleModule(argument_spec=dict(), supports_check_mode=True)


# Generated at 2022-06-20 16:00:26.744416
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def test_exec_args(cmd, **kwargs):
        return (0, 'C\nen_US.utf8', '')

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    module.get_bin_path = lambda x: x
    module.run_command = test_exec_args
    prefs = ['C', 'en_US.utf8', 'POSIX']
    found = get_best_parsable_locale(module=module, preferences=prefs, raise_on_locale=True)
    assert found == 'en_US.utf8'

# Generated at 2022-06-20 16:00:35.639100
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # import modules to be used here
    from ansible.module_utils.basic import AnsibleModule

    # assign module instance to variable
    module = AnsibleModule(argument_spec={})

    # call function with various arguments
    locale = get_best_parsable_locale(module)
    assert locale == 'C'
    locale = get_best_parsable_locale(module, [])
    assert locale == 'C'
    locale = get_best_parsable_locale(module, ['C'])
    assert locale == 'C'
    locale = get_best_parsable_locale(module, ['POSIX'])
    assert locale == 'C'
    locale = get_best_parsable_locale(module, ['POSIX', 'C'])
    assert locale == 'C'
    locale

# Generated at 2022-06-20 16:00:36.507186
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-20 16:00:45.091083
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test locale outputs
    locale_good = """
C
en_US.utf8
C.UTF-8
POSIX
"""

    locale_bad = """
This is a bad output
locale: Cannot set LC_CTYPE to default locale: No such file or directory
locale: Cannot set LC_MESSAGES to default locale: No such file or directory
locale: Cannot set LC_COLLATE to default locale: No such file or directory
"""

    # Test import
    from ansible.module_utils.basic import AnsibleModule

    # Test for good output
    module = AnsibleModule(
        argument_spec=dict(),
    )

    module.run_command = lambda x: (0, locale_good, '')
    assert get_best_parsable_locale(module) == 'C'

    # Test preferences

# Generated at 2022-06-20 16:00:53.119534
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def run_command(args):
        if args[-1] == '-a':
            return 0, 'C\nen_US.utf8', None
        else:
            return 0, None, None

    module = AnsibleModule(
        argument_spec=dict()
    )
    module.run_command = run_command

    best_locale = get_best_parsable_locale(module)
    assert best_locale == 'en_US.utf8'

# Generated at 2022-06-20 16:00:59.603244
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

    # test without preferences
    module = MockModule()
    module.run_command = lambda cmd, **kwargs: (0, "af_ZA.iso885915\naf_ZA.utf8", "")

    assert get_best_parsable_locale(module) == "C"

    # test with preferences
    module = MockModule()
    module.run_command = lambda cmd, **kwargs: (0, "af_ZA.iso885915\naf_ZA.utf8", "")
    assert get_best_parsable_locale(module, preferences=['af_ZA.utf8']) == 'af_ZA.utf8'



# Generated at 2022-06-20 16:01:09.785728
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """ Test get_best_parsable_locale """
    import distutils.spawn as spawn
    if not spawn.find_executable("locale"):
        raise Exception("locale executable not found, can't run unit tests")
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.sys_info import get_platform_info
    from ansible.module_utils.pycompat24 import get_exception

    module = AnsibleModule(argument_spec=dict())
    module.get_bin_path = get_bin_path
    module.run_command = module.run_command
    module.run_command.__self__.get_platform_info = get_platform_info

# Generated at 2022-06-20 16:01:18.505383
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """Verify the return value of get_best_parsable_locale"""

    import ansible.module_utils.basic as basic
    import ansible.module_utils.urls as urls
    import json

    class FakeModule:
        def __init__(self, cmd, rc, out, err):
            self.params = {'timeout': 10, 'forks': 100}
            self.debug = True
            self.bin_path = {}
            self.bin_path['locale'] = 'locale'
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, cmd, required=True):
            return self.bin_path[cmd]


# Generated at 2022-06-20 16:01:23.224774
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = MockModule()
    supported_locales = ["C", "en_US.utf8", "en_US.UTF-8"]

    assert get_best_parsable_locale(module, raise_on_locale=True) == "C"
    assert get_best_parsable_locale(module, preferences=supported_locales, raise_on_locale=True) == "en_US.utf8"
    assert get_best_parsable_locale(module, preferences=["en_NL.utf8"], raise_on_locale=True) == "C"


# This is a mock AnsibleModule object that we can use to test with

# Generated at 2022-06-20 16:01:32.685800
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule()
    found = get_best_parsable_locale(module)
    assert found == 'C'

# Generated at 2022-06-20 16:01:41.531613
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    # Test that the default preference list works
    assert get_best_parsable_locale(module) == 'C'

    pref_list = ['C', 'POSIX']
    assert get_best_parsable_locale(module, pref_list) == 'C'

    module = AnsibleModule(locales_dir='/tmp')
    module.run_command = lambda x: (0, '/tmp\nen_CA.utf8\nen_US.utf8\nen_US.utf8.qwerty\nC.utf8', '')
    assert get_best_parsable_locale(module) == 'C'


# Generated at 2022-06-20 16:01:50.963952
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    This function tests for the correct locale when
    locale CLI is available
    """
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})
    # The locale -a command below is just for the test
    basic_locale = """en_US
en_US.iso88591
en_US.iso885915
en_US.utf8
C
C.ascii
C.iso88591
C.iso885915
C.utf8
POSIX
"""

# Generated at 2022-06-20 16:01:54.063505
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8', 'C', 'POSIX'])
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True)

# Generated at 2022-06-20 16:02:04.602925
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Unit test for function get_best_parsable_locale
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    def run_command(args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None):
        # we are only testing for help
        if args[0] == '-h':
            return 0, 'USAGE: env [OPTION]... [-] [NAME=VALUE]... [COMMAND [ARG]...]', ''


# Generated at 2022-06-20 16:02:13.131217
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    pref_locales_simple = ['C.UTF-8', 'C', 'POSIX']
    pref_locales_complex = ['fr_FR.UTF-8', 'fr_FR.utf8', 'fr_FR', 'fr.utf8', 'fr']

    module = AnsibleModule(
        argument_spec=dict(),
    )

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=pref_locales_simple) == 'C'


# Generated at 2022-06-20 16:02:17.127795
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Valid locale
    assert get_best_parsable_locale(None, preferences=['en_US.utf8']) == 'en_US.utf8'

    # Preferred locales are not available - use default
    assert get_best_parsable_locale(None, preferences=['zz_ZZ.utf8']) == 'C'

    # Preferred locales are not available - use default
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-20 16:02:25.453969
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()

    assert 'C' == get_best_parsable_locale(module, ['foo', 'bar', 'baz'])
    assert 'C' == get_best_parsable_locale(module, preferences=None)
    assert 'C.utf8' == get_best_parsable_locale(module, ['C.utf8', 'bar', 'baz'])
    assert 'POSIX' == get_best_parsable_locale(module, ['POSIX', 'bar', 'baz'])
    assert 'en_US.utf8' == get_best_parsable_locale(module, ['en_US.utf8', 'bar', 'baz'])
    assert 'C' == get_best_

# Generated at 2022-06-20 16:02:29.139895
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(supports_check_mode=True)
    locale = get_best_parsable_locale(module)
    assert len(locale) > 0
    assert locale == 'C'

# Generated at 2022-06-20 16:02:37.819687
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import run_command as run_command
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    class FakeModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            self._ansible_no_log = True
            self.run_command = run_command
            self.get_bin_path = get_bin_path

            super(FakeModule, self).__init__(*args, **kwargs)

    module = FakeModule(argument_spec={})

    # find POSIX

# Generated at 2022-06-20 16:02:57.655899
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    from ansible.module_utils.common.process import get_bin_path
    import ansible.module_utils.basic
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock


# Generated at 2022-06-20 16:03:02.553025
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec={})

    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    # test raise on locale exception
    try:
        locale = get_best_parsable_locale(module, raise_on_locale=True)
    except RuntimeWarning:
        pass  # expected exception
    else:
        assert False, "Expected exception"

# Generated at 2022-06-20 16:03:07.673805
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class NoGitModule(object):
        def __init__(self):
            self.paths = []

    module = NoGitModule()
    best_parsable_locale = get_best_parsable_locale(module)
    assert best_parsable_locale == 'C'
    assert module.paths == []

# Generated at 2022-06-20 16:03:13.939657
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Arrange
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    import os

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    module = AnsibleModule(argument_spec={})

    # Act
    locale = get_best_parsable_locale(module)

    # Assert
    if PY3:
        assert locale.startswith('C')
    else:
        assert locale == 'POSIX'

# Generated at 2022-06-20 16:03:24.641508
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule(argument_spec={})
    result = get_best_parsable_locale(am)
    assert result == 'C'

    preferences = ['en_US.UTF-8', 'en_US.utf8', 'C', 'POSIX']
    result = get_best_parsable_locale(am, preferences)
    assert result == 'C'

    preferences = ['no-unsupported-locale', 'C', 'POSIX']
    result = get_best_parsable_locale(am, preferences)
    assert result == 'C'

    preferences = ['no-unsupported-locale']
    result = get_best_parsable_locale(am, preferences)
    assert result == 'C'

# Generated at 2022-06-20 16:03:36.786674
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys

    # Mock modules
    class MockOS:
        def __init__(self):
            self.files = ['locale']

        def path(self, path):
            return path in self.files

    class MockModule:
        def __init__(self, paths, locales):
            self.os = MockOS()
            self.paths = paths
            self.locales = locales

        def get_bin_path(self, path):
            return self.paths[path] if path in self.paths else None

        def run_command(self, command):
            if command[1] == '-a':
                return (0, '\n'.join(self.locales), '')
            else:
                return (0, 'C.UTF-8', '')


# Generated at 2022-06-20 16:03:46.473470
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    import tempfile
    import io
    import io

    # Import module to test
    globals()['sys'] = sys
    globals()['os'] = os
    globals()['io'] = io
    globals()['tempfile'] = tempfile

    import ansible.module_utils.basic as basic
    # Import module being tested
    globals()['basic'] = basic

    # try to import othe modules but ignore the error
    try:
        import ansible.module_utils.facts.system.locale as locale
    except ImportError:
        pass

    from ansible.module_utils.common._collections_compat import OrderedDict

    # create mock module
    mod = basic.AnsibleModule(argument_spec={})

    # create a temporary file for the tests
   

# Generated at 2022-06-20 16:03:55.796810
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == "C"
    assert get_best_parsable_locale(module, preferences=None) == "C"
    assert get_best_parsable_locale(module, preferences=["C"]) == "C"
    assert get_best_parsable_locale(module, preferences=["Klingon"]) == "C"
    assert get_best_parsable_locale(module, preferences=["POSIX"]) == "C"
    assert get_best_parsable_locale(module, preferences=["Klingon", "POSIX"]) == "C"
    assert get_best_parsable_locale(module, preferences=["C", "POSIX"]) == "C"

# Generated at 2022-06-20 16:04:05.472766
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock an AnsibleModule object with a run_command method
    class AnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.result = {}

        def get_bin_path(self, name):
            if name == "locale": return True
            return False

        def run_command(self, args):
            # If a custom preference is specified, the second argument should be the first
            # item in the list
            assert(args[1] == "en_US.utf8")
            return (0, "C\nen_US.utf8", "")

    module = AnsibleModule()
    result = get_best_parsable_locale(module, ["en_US.utf8"])
    assert(result == "en_US.utf8")

# Generated at 2022-06-20 16:04:10.890439
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # test with no priories
    assert get_best_parsable_locale(AnsibleModule({}), raise_on_locale=True) == 'C'

    # test with priories
    assert get_best_parsable_locale(AnsibleModule({}), ['C', 'POSIX', 'en_US.utf8'], raise_on_locale=True) == 'C'

