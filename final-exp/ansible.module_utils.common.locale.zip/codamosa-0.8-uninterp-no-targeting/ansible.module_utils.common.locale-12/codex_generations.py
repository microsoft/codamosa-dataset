

# Generated at 2022-06-20 15:54:38.960023
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import os

    MOCK_LOCALE_PATH = 'tests/unit/mock_bin_locale'

# Generated at 2022-06-20 15:54:49.467857
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # mock the AnsibleModule class object
    module = type('AnsibleModule', (), {
        'get_bin_path': lambda self, x: '/usr/bin/locale' if x == 'locale' else None,
        'run_command': lambda self, cmd: ('', [
            '# Locale (charmap) information',
            '#',
            'C',
            'de_DE',
            'de_DE@euro',
            'de_DE.iso88591',
            'de_DE.iso885915',
            'de_DE.utf8',
            'en_US',
            'en_US.iso88591',
            'en_US.iso885915',
            'en_US.utf8',
            'POSIX'
        ], ''),
    })()

    #

# Generated at 2022-06-20 15:54:54.854249
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    found = get_best_parsable_locale(module, ["C.UTF-8", "en_US.UTF-8", "C", "POSIX"], raise_on_locale=True)
    assert found == "C"

# Generated at 2022-06-20 15:55:02.797550
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_cases = [
        None,
        [],
        ['C'],
        ['C', 'POSIX'],
        ['C.utf8', 'POSIX'],
        ['he_IL.utf8', 'POSIX', 'KOI8-R']
    ]

    for preference in test_cases:
        locale = get_best_parsable_locale(None, preference)
        if locale not in preference:
            raise AssertionError("Got unexpected locale: %s" % locale)

# Generated at 2022-06-20 15:55:14.215219
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import EnvironmentError
    from ansible.module_utils._text import to_bytes
    import pytest

    # AnsibleModule is not a mock because it does so many things and
    # behaves like an object that it is easier to just use one
    module = AnsibleModule(
        argument_spec={},
    )

    def run_command(args, **kwargs):
        if args == [b'locale', b'-a']:
            return 0, to_bytes("en_US.utf8\nC.utf8\nC.UTF-8\nen_US.UTF-8\nC\nen_US\nPOSIX\nja_JP.utf8"), to_bytes("")

# Generated at 2022-06-20 15:55:23.312616
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    fake_module = object()
    fake_module.run_command = None
    fake_module.get_bin_path = None

    fake_module.run_command = lambda cmd: (0, 'C\nen_US.utf8\nen_US.UTF-8\nen_US\n', '')
    assert get_best_parsable_locale(fake_module, ['C.utf8', 'en_US.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(fake_module, ['en_US.utf8', 'C.utf8']) == 'en_US.utf8'

    # we get the first preferred by default

# Generated at 2022-06-20 15:55:26.161201
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Get a local module object
    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module, preferences=['C'], raise_on_locale=True) == 'C'

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-20 15:55:34.187187
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class ansible_module(object):
        def get_bin_path(self, bin):
            return bin

        def run_command(self, cmd):
            return (1, None, None)

    test_module = ansible_module()

    assert get_best_parsable_locale(test_module, raise_on_locale=True) == 'C'

    class ansible_module(object):
        def get_bin_path(self, bin):
            return bin

        def run_command(self, cmd):
            return (0, "", "")

    test_module = ansible_module()

    assert get_best_parsable_locale(test_module, raise_on_locale=True) == 'C'


# Generated at 2022-06-20 15:55:38.903741
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    prefs = ['C', 'POSIX']
    result = get_best_parsable_locale(module, prefs)
    assert result == 'C'

    prefs = ['en_US.utf8', 'C', 'POSIX']
    result = get_best_parsable_locale(module, prefs)
    assert result == 'en_US.utf8'

# Generated at 2022-06-20 15:55:42.772846
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['en_US.utf8', 'C']) == 'C'

# Generated at 2022-06-20 15:55:56.496792
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.six
    import pytest

    class AnsibleModuleMock(ansible.module_utils.basic.AnsibleModule):
        def __init__(self, *args, **kwargs):
            ansible.module_utils.basic.AnsibleModule.__init__(self, *args, **kwargs)
            self.bin_path = dict()

        def get_bin_path(self, cmd, required=False):
            return self.bin_path[cmd]

        def run_command(self, cmd, check_rc=True, environ_update=None, data=None, binary_data=False):
            (out, err, rc) = ('', '', 0)

# Generated at 2022-06-20 15:56:05.947180
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def test_module_run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None):
        out_best_locale = '''a_is@<>:~$ locale -a
  C
  C.UTF-8
  en_US.utf8
  POSIX
a_is@<>:~$
'''


# Generated at 2022-06-20 15:56:14.013133
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    if sys.version_info[0] < 3:
        import __builtin__ as builtins
    else:
        import builtins
    # Importing the module in this way allows us to redirect stdout,
    # and to test that a SystemExit exception is thrown with a given exit code.
    from ansible.module_utils import basic
    from ansible.module_utils import common_koji
    from ansible.module_utils import legacy
    from ansible.module_utils import get_best_parsable_locale

    from ansible.module_utils._text import to_bytes
    from io import StringIO
    from sys import argv

    argv = [argv[0]]

    # Reset logging, since it can be configured before this module is imported

# Generated at 2022-06-20 15:56:22.211918
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec={})

    default_locale = get_best_parsable_locale(module=module)
    assert default_locale == 'C'

    # Find a locale that we know exists
    test_locale = 'en_US.utf8'
    locale = get_best_parsable_locale(module=module, preferences=[test_locale])
    assert locale == test_locale

    # Verify that we get the default locale if the desired locale is not available
    locale = get_best_parsable_locale(module=module, preferences=['es_MX'])
    assert locale == 'C'

# Generated at 2022-06-20 15:56:31.994508
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = type('ANSIBLE_MODULE', (object,), dict())
    module.get_bin_path = lambda x: '/usr/bin/' + x
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nen_US.UTF-8\nen_US\n', '')

    assert get_best_parsable_locale(module) == 'en_US.utf8'
    # On FreeBSD locale -a returns:
    # C
    # en_US.ISO8859-1
    # en_US.ISO8859-15
    # en_US.US-ASCII
    # en_US.UTF-8
    # POSIX

    # On OpenBSD locale -a returns:
    #   C
    #   en_US.ISO8859-1
    #

# Generated at 2022-06-20 15:56:43.104690
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.text import AnsibleModule
    import sys
    import shutil
    import tempfile
    from contextlib import contextmanager

    @contextmanager
    def temp_path():
        _temp_dir = tempfile.mkdtemp()
        try:
            yield _temp_dir
        finally:
            shutil.rmtree(_temp_dir)

    with temp_path() as tmp_dir:
        # no executable 'locale' in mocked execution path
        module = AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=True,
            check_invalid_arguments=False,
            bypass_checks=True,
        )
        sys.path.insert(0, tmp_dir)


# Generated at 2022-06-20 15:56:49.741772
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-20 15:57:01.227779
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})


# Generated at 2022-06-20 15:57:09.886554
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class FakeModule:
        def __init__(self, bin_path_results, run_command_results):
            self.bin_path_results = bin_path_results
            self.run_command_results = run_command_results
            self.bin_path_called = False
            self.run_command_called = False

        def get_bin_path(self, name):
            self.bin_path_called = True
            return self.bin_path_results.get(name)

        def run_command(self, command_array, **kwargs):
            self.run_command_called = True
            return self.run_command_results[command_array[0]][command_array[1]]

    # This is a 'happy path' test to ensure everything works if the locale binary is present
    # Additionally, we're testing that

# Generated at 2022-06-20 15:57:13.843331
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic

    module = AnsibleModule(argument_spec={})
    assert "C" == get_best_parsable_locale(module, raise_on_locale=True)

# Generated at 2022-06-20 15:57:31.368185
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test if the function is able to return the best available locale.
    '''
    class AnsiModule:
        def get_bin_path(self, bin):
            return '/bin/locale'

        def run_command(self, command):
            return 0, 'C\nen_US.utf8', ''

    # Test case when all preferred locales are available
    # Preferred locale - C.utf8
    module = AnsiModule()
    pref_list = ['C.utf8']
    assert get_best_parsable_locale(module, pref_list) == 'C.utf8'

    # Preferred locale - en_US.utf8
    module = AnsiModule()
    pref_list = ['en_US.utf8']

# Generated at 2022-06-20 15:57:43.463327
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # best_parsable_locale should default to 'C'
    assert get_best_parsable_locale(None) == 'C'

    # best_parsable_locale should choose preferred locale in order of
    # preference.
    try:
        assert get_best_parsable_locale(None, ['en_US.utf8', 'C']) == 'en_US.utf8'
    except RuntimeWarning:
        # There could be platforms that don't support this locale
        pass

    try:
        assert get_best_parsable_locale(None, ['C.utf8', 'C']) == 'C.utf8'
    except RuntimeWarning:
        # There could be platforms that don't support this locale
        pass


# Generated at 2022-06-20 15:57:55.009742
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    if sys.version_info >= (3, 0):
        import unittest.mock as mock
    else:
        import mock

    class RealAnsibleModule(object):
        def __init__(self, argument_spec, bypass_checks=False, no_log=False, check_invalid_arguments=True,
                     mutually_exclusive=None, required_together=None, required_one_of=None,
                     add_file_common_args=False, supports_check_mode=False):
            super(RealAnsibleModule, self).__init__()
            self.argument_spec = argument_spec
            self.params = {}
            self.exit_args = {}
            self.fail_json = mock.MagicMock(side_effect=SystemExit)
            self.warn = mock.MagicMock()
            self

# Generated at 2022-06-20 15:58:03.493071
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import sys
    import subprocess
    class TestModule(object):
        def __init__(self):
            self._bin_path = {}
        def get_bin_path(self, name, required=False):
            if name in self._bin_path:
                return self._bin_path[name]
            return None
        def set_bin_path(self, name, value):
            self._bin_path[name] = value
        def run_command(self, args):
            return subprocess.call(args, stdout=sys.stdout, stderr=sys.stderr)

    class TestGetBestParsableLocale(unittest.TestCase):
        def setUp(self):
            self.mod = TestModule()

# Generated at 2022-06-20 15:58:07.332431
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = type('', (object,), {})
    module.get_bin_path = lambda x: None
    module.run_command = lambda x: (0, '', '')
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

# Generated at 2022-06-20 15:58:14.206200
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils.common._collections_compat import Mapping, Sequence
        from ansible.module_utils.six import PY2
        from ansible.module_utils.six.moves import zip_longest
    except Exception:
        return

    m = AnsibleModule(argument_spec=dict())

    m.get_bin_path_for_testing = lambda x: x
    m.run_command_for_testing = lambda x: (0, 'C\nPOSIX', '')

    # equivalent to the default
    result = get_best_parsable_locale(m)
    assert result == 'C'

    # equivalent to the default

# Generated at 2022-06-20 15:58:26.189561
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    def mock_run_command(args, check_rc=True, command_timeout=5, data=None, binary_data=False, update_env=True):
        if args[0] == '/usr/bin/locale':
            if args[1] == '-a':
                rc = 0
                out = 'C\nC.UTF-8\nPOSIX\nen_US.utf8\n'
                err = ''
            else:
                raise AssertionError('Unexpected command %s %s' % (args[0], args[1]))
        else:
            raise AssertionError('Unexpected command %s %s' % (args[0], args[1]))
        return rc, out, err


# Generated at 2022-06-20 15:58:30.520455
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import mock
    import six

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    module.run_command = mock.MagicMock(return_value=(0, 'a_line\nanother_line\n', ''))

    assert get_best_parsable_locale(module, preferences=['a_line', 'another_line']) == 'a_line'


# Generated at 2022-06-20 15:58:40.950868
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' Unit test for function get_best_parsable_locale '''
    locale_utils = AnsibleModule()
    locale_utils.run_command = lambda command: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    locale_utils.get_bin_path = lambda name: '/usr/bin/locale'

    assert get_best_parsable_locale(locale_utils) == 'C.utf8'
    assert get_best_parsable_locale(locale_utils, preferences=['en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(locale_utils, preferences=['fr_FR.utf8']) == 'C'
    assert get_best_p

# Generated at 2022-06-20 15:58:45.232314
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    AM = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(AM, preferences=['en_US.utf8', 'en_US.utf8', 'en_US.utf8', 'en_US.utf8'], raise_on_locale=False) == 'en_US.utf8'



# Generated at 2022-06-20 15:59:03.171541
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    results = get_best_parsable_locale(AnsibleModule(),
                                       preferences=['fr.utf8', 'fr.UTF-8', 'french', 'en_US.utf8'])
    assert results == 'en_US.utf8'
    results = get_best_parsable_locale(AnsibleModule(),
                                       preferences=['french', 'fr.UTF-8', 'fr.utf8', 'en_US.utf8'])
    assert results == 'fr.utf8'
    results = get_best_parsable_locale(AnsibleModule(),
                                       preferences=['en_US.utf8'])
    assert results == 'en_US.utf8'
    results = get_best_parsable_

# Generated at 2022-06-20 15:59:12.893368
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule()
    assert get_best_parsable_locale(m) == 'C'

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    out = '''af_ZA.utf8
af_ZA.utf8
af_ZA.utf8
en_US.utf8
'''
    m = AnsibleModule(dict(preferences=preferences, out=out))
    assert get_best_parsable_locale(m) == 'en_US.utf8'

    out = '''af_ZA.utf8
C.utf8
af_ZA.utf8
en_US.utf8
'''

# Generated at 2022-06-20 15:59:16.823484
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    test_module = basic.AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(test_module, preferences=['en_US']) == 'en_US'


# Generated at 2022-06-20 15:59:24.137407
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'en_US.utf8' == get_best_parsable_locale(preferences=['en_US.utf8', 'en_US'])
    assert 'C' == get_best_parsable_locale(preferences=['en_US.utf8', 'en_US'], raise_on_locale=True)
    assert 'C.utf8' == get_best_parsable_locale(preferences=['C.utf8', 'C'])
    assert 'POSIX' == get_best_parsable_locale(preferences=['C.utf8', 'POSIX'])
    assert 'C' == get_best_parsable_locale(preferences=['C'])

# Generated at 2022-06-20 15:59:34.274861
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    insures that get_best_parsable_locale is properly selecting the locale
    amongst an array of locale choices.  In the case where there is no
    choice, we need to return the default.
    """


# Generated at 2022-06-20 15:59:42.571924
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # noinspection PyUnusedLocal
    module = None
    assert get_best_parsable_locale(module, preferences=['a.utf8',], raise_on_locale=False) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'b.utf8'], raise_on_locale=False) == 'C'
    assert get_best_parsable_locale(module, preferences=['C', 'b.utf8'], raise_on_locale=False) == 'C'
    assert get_best_parsable_locale(module, preferences=['b.utf8', 'C', 'POSIX'], raise_on_locale=False) == 'C'

# Generated at 2022-06-20 15:59:53.087968
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    d = {}
    d['ANSIBLE_PYTHON_INTERPRETER'] = '/usr/bin/python'
    module = basic.AnsibleModule(argument_spec=dict(), supports_check_mode=False, check_invalid_arguments=False, bypass_checks=True)
    available = ['en_US.UTF-8', 'C.UTF-8', 'en_US.ISO-8859-1', 'en_US.ISO8859-1',
                 'en_US.UTF-8@modifier', 'C', 'POSIX']
    for a in available:
        assert get_best_parsable_locale(module, preferences=[a]) == a

    # default is C locale.  A list of preferences should not adversely affect the
    # final outcome of the default

# Generated at 2022-06-20 16:00:03.249539
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # AnsibleModule instance with run_command() mocked
    from ansible.module_utils.common import run_command
    from ansible.module_utils.basic import AnsibleModule
    class module(AnsibleModule):
        def run_command(self, cmd, environ_update=None, check_rc=True, close_fds=True, executable=None, data=None):
            module.run_command_result = run_command(cmd, environ_update, check_rc, close_fds, executable, data)
            return module.run_command_result
    module_instance = module()

    assert get_best_parsable_locale(module_instance, ['en_US.utf8','C.utf8','POSIX']) == 'en_US.utf8'
    assert get_best_parsable_loc

# Generated at 2022-06-20 16:00:07.711980
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    for a, b in dict(
            normal=[None, 'C.utf8'],
            no_locale=[None, 'C'],
            no_pref_locale=[None, 'C.utf8'],
            override_normal=['C.utf8', 'POSIX'],
            override_no_pref_locale=['POSIX', 'POSIX'],
    ).items():
        class TestModule(AnsibleModule):
            def get_bin_path(self, executable):
                if executable == 'locale':
                    return '/usr/bin/locale'
                else:
                    raise RuntimeError("unexpected call")


# Generated at 2022-06-20 16:00:13.118924
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    This function unit tests the functionality of get_best_parsable_locale
    '''

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(preferences=dict(type='list')))

    # Test scenarios where no preferences are set
    module.params['preferences'] = None
    result = get_best_parsable_locale(module)
    assert result == 'C'

    # Test scenarios where preferences are set
    module.params['preferences'] = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    result = get_best_parsable_locale(module)
    assert result == 'C'

# Generated at 2022-06-20 16:00:26.854175
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Returns the default locale C.
    '''
    # Stubbing the method run_command
    import mock
    import ansible.module_utils.basic

    #mock class
    class MockModule:
        class AnsibleModule:
            def __init__(self, *args, **kwargs):
                self.args = args
                self.kwargs = kwargs

            def fail_json(self, **kwargs):
                pass
            def exit_json(self, **kwargs):
                pass
            def get_bin_path(self, cmd):
                return cmd

        def __init__(self, *args, **kwargs):
            self.ansible_module = self.AnsibleModule(*args, **kwargs)
            self.ansible_module.exit_json = self.exit_json

   

# Generated at 2022-06-20 16:00:35.638900
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import pytest

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def get_bin_path(self, **kwargs):
            return '/usr/bin/locale'

        def run_command(self, **kwargs):
            return 0, 'C', ''

    def run_function(function_name, **kwargs):
        return globals()[function_name](MockModule(**kwargs))

    with pytest.raises(RuntimeWarning):
        run_function('get_best_parsable_locale', raise_on_locale=True)
    assert run_function('get_best_parsable_locale') == 'C'

    # Mock output from locale command

# Generated at 2022-06-20 16:00:44.519797
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(argument_spec={})
    test_results = []

    # 'locale' command exits with 0 and the output is not empty
    test_results.append(("C.UTF-8", 0, 'C.UTF-8\nen_US.UTF-8\nen_US.utf8'))
    # 'locale' command exits with 0 and the output is empty
    test_results.append(("C", 0, ''))
    # 'locale' command exits with 0 and the output is empty with no error message
    test_results.append(("C", 0, '', ''))


# Generated at 2022-06-20 16:00:51.372807
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    # The first option should be return
    assert get_best_parsable_locale(module, ['POSIX', 'C']) == 'POSIX'
    # None of the options are present, return default
    assert get_best_parsable_locale(module, ['abc', 'xyz']) == 'C'

# Generated at 2022-06-20 16:00:53.475041
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.modules.system.locale import get_best_parsable_locale

    locale = get_best_parsable_locale(None)
    assert locale == 'C'

    locale = get_best_parsable_locale(None, preferences=['fr_FR.utf8', 'C'])
    assert locale == 'fr_FR.utf8'

# Generated at 2022-06-20 16:01:00.070140
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == 'C'
    assert get_best_parsable_locale('posix') == 'C'
    assert get_best_parsable_locale('POSIX') == 'C'
    assert get_best_parsable_locale(['chinese', 'en_US']) == 'C'
    assert get_best_parsable_locale(['chinese', 'en_US', 'C']) == 'C'
    assert get_best_parsable_locale(['chinese', 'C', 'en_US']) == 'C'
    assert get_best_parsable_locale(['C', 'chinese', 'en_US']) == 'C'

# Generated at 2022-06-20 16:01:10.003507
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic as module_utils
    module_utils.HAS_LOCALE = True
    module_utils.HAS_LOCALECONV = True

    test_Module = module_utils.AnsibleModule(
        argument_spec=dict(
        )
    )

    module_utils._HAS_LOCALE = False
    assert 'C' == get_best_parsable_locale(test_Module)

    module_utils._HAS_LOCALE = True
    module_utils._LOCALE_CMD = 'echo'
    assert 'C' == get_best_parsable_locale(test_Module)

    module_utils._LOCALE_CMD = 'echo C.UTF-8'
    assert 'C' == get_best_parsable_locale(test_Module)

# Generated at 2022-06-20 16:01:18.650278
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import pytest

    a = AnsibleModule(
        argument_spec=dict()
    )

    en_US = 'en_US.utf8'
    es = 'es_CO.utf8'

    # default
    assert get_best_parsable_locale(a) == 'C'

    # English
    assert get_best_parsable_locale(a, preferences=[en_US, es]) == en_US

    # Spanish
    assert get_best_parsable_locale(a, preferences=[es]) == es

    # English
    assert get_best_parsable_locale(a, preferences=['bogus', 'notreal', en_US]) == en_US

    # Spanish
    assert get_best_parsable

# Generated at 2022-06-20 16:01:24.562950
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_facts_from_cache
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.selinux import SELinuxFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.user import UserFactCollector
    from ansible.module_utils.facts.system.service import ServiceMgrFactCollector
    from ansible.module_utils.facts.virt_ip import VirtIPFactCollector

# Generated at 2022-06-20 16:01:34.969492
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(
        argument_spec=dict(
            module_default_arguments
        )
    )

    from ansible.module_utils.common.locales import get_best_parsable_locale
    from ansible.module_utils.facts.system.base import get_system_locale

    expected = get_system_locale(module)
    #fallback to C if no locale is found
    if not expected:
        expected = 'C'

    result = get_best_parsable_locale(module)
    assert result == expected

    expected = 'C'
    result = get_best_parsable_locale(module, ['this-locale-will-never-exist', 'C'])
    assert result == expected


# Test function to produce files that contain strings in various locales


# Generated at 2022-06-20 16:01:55.716318
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    mod = ansible.module_utils.basic.AnsibleModule(argument_spec={})

    # Checking with `en_US.utf8` locale
    mod._connection = MockConnection()
    assert "en_US.utf8" == get_best_parsable_locale(mod)

    # Checking with `C.utf8` locale
    mod._connection = MockConnection(stdout="C.utf8")
    assert "en_US.utf8" == get_best_parsable_locale(mod)

    # Checking with `C` locale
    mod._connection = MockConnection(stderr="Unable to get locale information")
    assert "C" == get_best_parsable_locale(mod)

    # Checking with `POSIX` locale
    mod._connection

# Generated at 2022-06-20 16:02:04.473720
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test module_utils.basic.get_best_parsable_locale function with no parameters
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_best_parsable_locale
    assert (get_best_parsable_locale(AnsibleModule({}), None, False) == 'C')

    # Test module_utils.basic.get_best_parsable_locale function with parameters
    assert (get_best_parsable_locale(AnsibleModule({}), ['C', 'POSIX'], False) == 'C')

# Generated at 2022-06-20 16:02:07.283460
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-20 16:02:13.230888
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    am = AnsibleModule(
        argument_spec=dict(),
    )
    try:
        locale = get_best_parsable_locale(am, preferences=["a", "b", am.fail_json])
    except Exception as e:
        if "is not a valid_locale" not in str(e):
            raise
    locale = get_best_parsable_locale(am, preferences=["a", "b", "C"], raise_on_locale=True)
    assert locale == "C"

# Generated at 2022-06-20 16:02:20.175350
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    if sys.version_info[0] < 3:
        from mock import Mock
    else:
        from unittest.mock import Mock

    # Verify 'en_US.utf8' is selected if available
    module = Mock()
    module.get_bin_path.return_value = "/usr/bin/locale"
    module.run_command.return_value = (0, "en_US.utf8\nen_US\n", None)
    assert get_best_parsable_locale(module, ["en_US.utf8", "POSIX"]) == "en_US.utf8"

    # Verify 'POSIX' is selected if en_US.utf8 is unavailable
    module = Mock()
    module.get_bin_path.return_value = "/usr/bin/locale"


# Generated at 2022-06-20 16:02:27.525553
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # empty list of locales
    module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module, preferences=['foo', 'bar']) == 'C'

    # list of locales in the system
    module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # list of locales in the system, with the preferred locale
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-20 16:02:36.845815
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock an AnsibleModule (not an actual one)
    # We're only going to use run_command
    # We already patched run_command in unit tests
    # so this will just return what we want
    class AnsibleModule:
        def __init__(self, argument_spec=None, bypass_checks=False, check_invalid_arguments=None, mutually_exclusive=None,
                     required_together=None, required_one_of=None, add_file_common_args=False, supports_check_mode=False,
                     required_if=None, required_by=None):
            pass

        def run_command(self, cmd, check_rc=True):
            if cmd[1] == '-a':
                if 'C' in cmd[0]:
                    return 0, 'C\nC.UTF-8', ''

# Generated at 2022-06-20 16:02:43.741636
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    # Dummy module for testing
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )
    assert module.get_best_parsable_locale() == 'C'
    assert module.get_best_parsable_locale(preferences=['en_US']) == 'C'
    assert module.get_best_parsable_locale(preferences=['en_US', 'C']) == 'C'

# Generated at 2022-06-20 16:02:53.344131
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    import copy

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    available = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']


    # First test, without check mode
    assert module.check_mode is False

    # If not provided, use module's defaults
    assert get_best_parsable_locale(module) == 'C'

    # If preferences are provided, return the first one matching
    assert get_best_parsable_locale(module, preferences=['POSIX']) == 'POSIX'

    # If preferences are provided, return the first one matching, even if default preference isn't there

# Generated at 2022-06-20 16:03:04.219613
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Tests that function get_best_parsable_locale works and returns
    the default value if any exception occurs.
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping
    import os


# Generated at 2022-06-20 16:03:29.005984
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.local import LocalAnsibleModule

    ansible_module = LocalAnsibleModule(name="unit_test_module")
    # Tests with no output
    assert get_best_parsable_locale(ansible_module) == 'C'

    # Tests with at least one valid output
    ansible_module.run_command = MagicMock(return_value=(0, "en_US.utf8 en_US en_US.utf8@euro en_US.iso88591 en_US.utf8@euro", ''))
    assert get_best_parsable_locale(ansible_module) == 'en_US.utf8'


# Generated at 2022-06-20 16:03:36.010187
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == 'C', "default to 'C' when tools/preferences are not met"

    assert get_best_parsable_locale(preferences=['es_ES.utf8', 'POSIX']) == 'POSIX', "return first preferred found"
    assert get_best_parsable_locale(preferences=['es_ES.utf8', 'en_US.utf8', 'POSIX']) == 'en_US.utf8', "return first preferred found"

# Generated at 2022-06-20 16:03:45.811471
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
        :returns: None
    '''
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys

    # create an instance of the module
    module = AnsibleModule(form_json=False)

    # lets pretend we are running from Linux which has always a locale setting
    # set the required os.environ variable for locale tools
    os.environ['LANG'] = 'C.utf8'
    assert get_best_parsable_locale(module) == 'C.utf8'
    assert get_best_parsable_locale(module, ['C.utf8', 'POSIX', 'C']) == 'C.utf8'

# Generated at 2022-06-20 16:03:54.395429
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Load dependencies
    from ansible.utils.display import Display
    from ansible.compat.tests import mock
    import mock_module_util
    from ansible.module_utils import basic

    # Need to set the locale to prevent tests from raising an exception
    mock_module_util.get_bin_path = mock.MagicMock()
    mock_module_util.get_bin_path.return_value = "locale"
    module = basic.AnsibleModule(argument_spec={})
    module.run_command = mock.MagicMock()
    module.run_command.return_value = (0, "en_US.utf8", None)

    # Make sure that the locale gets set properly if no locale is passed in
    locale = get_best_parsable_locale(module)

# Generated at 2022-06-20 16:03:59.884776
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import sys
    import os
    sys.path.append("/tmp/ansible_modlib.zip")
    #sys.path.append("/tmp/ansible_modlib/ansible")
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-20 16:04:09.426406
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import io
    import tempfile

    mod_path = 'ansible.module_utils.basic.get_best_parsable_locale'
    path_to_module = '.'.join(mod_path.split('.')[:-1])

    import sys
    old_path = sys.path
    sys.path.insert(0, '.')

    # Importing modules is expensive, so we do it once here then call the
    # specific functions we need to test
    basic = __import__(path_to_module, globals(), locals(), ['basic'], 0)


# Generated at 2022-06-20 16:04:23.024358
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """We should be able to run this helper function in tests."""

    mock_module = type('module', (object,), dict(get_bin_path=lambda x,y: None))
    locale = get_best_parsable_locale(mock_module)
    assert locale == 'C'

    mock_module = type('module', (object,), dict(get_bin_path=lambda x,y: None,
                                                 run_command=lambda x: (0, None, None)))
    locale = get_best_parsable_locale(mock_module)
    assert locale == 'C'

    mock_module = type('module', (object,), dict(get_bin_path=lambda x,y: 'locale',
                                                 run_command=lambda x: (0, 'C', None)))
   

# Generated at 2022-06-20 16:04:25.287800
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # TODO: write unit tests
    import pytest
    pytest.skip("Currently no tests exist for this module")