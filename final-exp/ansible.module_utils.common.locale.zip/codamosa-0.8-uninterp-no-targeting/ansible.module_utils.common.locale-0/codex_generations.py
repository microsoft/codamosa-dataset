

# Generated at 2022-06-20 15:54:33.255497
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.commands import Command

    module = AnsibleModule({}, supports_check_mode=True)
    module.run_command = Command.run_command
    # on most systems C shouldn't be available
    assert module.get_bin_path("locale")
    assert get_best_parsable_locale(module) == 'C'


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-20 15:54:41.115639
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, None) == 'C'

    from ansible.module_utils.basic import AnsibleModule
    mock_args = dict(ANSIBLE_MODULE_ARGS=dict(output='hello world'))
    mock_ansible_module = AnsibleModule(**mock_args)
    mock_ansible_module.run_command = lambda x: (0, 'C\nen_US.UTF-8', '')

    assert get_best_parsable_locale(mock_ansible_module, None) == 'C'



# Generated at 2022-06-20 15:54:47.310885
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    # We should get a preference if available
    pref = 'test'
    assert pref == get_best_parsable_locale(module, preferences=[pref])

    # We should get 'C' if we have no preferences
    assert 'C' == get_best_parsable_locale(module)

# Generated at 2022-06-20 15:54:54.241557
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule(argument_spec=dict())
    test_module.params = dict()
    # test_module.params['locale'] = dict()
    best_parsable_locale = get_best_parsable_locale(test_module)
    assert best_parsable_locale is not None

# Generated at 2022-06-20 15:55:01.537538
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    assert(get_best_parsable_locale(AnsibleModule()) == 'C')

    # stub out locale, and assert that if we can't find one
    # we return the default, even if there was a preference
    def get_bin_path_stub(path):
        return ''

    default_module = AnsibleModule()
    default_module.get_bin_path = get_bin_path_stub
    assert(get_best_parsable_locale(default_module, ['ja_JP.utf8']) == 'C')

    # stub out locale, and have it return a list of locales without
    # our preference
    def run_command_stub(command):
        return 0, 'C\nen_US.utf8\n',

# Generated at 2022-06-20 15:55:12.984385
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Function to test get_best_parsable_locale
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr, PkgMgrFactCollector
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    module = AnsibleModule(argument_spec=ImmutableDict())
    pkg_mgr = PkgMgr(module).pkg_mgr
    pkg_mgr_fact = PkgMgrFactCollector(module, pkg_mgr).collect()

# Generated at 2022-06-20 15:55:21.272115
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(name='test', args='')

    assert get_best_parsable_locale(m, preferences=['a_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(m, preferences=['a_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'
    assert get_best_parsable_locale(m) == 'C'
    assert get_best_parsable_locale(m, preferences=[]) == 'C'

# Generated at 2022-06-20 15:55:30.070860
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    m = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
        required_one_of=[
            ["foo", "bar"],
            ["thing", "stuff"],
        ],
        required_together=[
            ['state', 'password']
        ],
    )
    # load the user module
    basic._ANSIBLE_ARGS = None

    assert get_best_parsable_locale(m, preferences=None, raise_on_locale=False) == 'C'

# Generated at 2022-06-20 15:55:42.320625
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import ansible.module_utils.basic
    import ansible.module_utils.common.dict_transformations

    class FakeModule:

        def __init__(self):
            self.params = {}
            self.ansible_facts = {}

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd):
            if cmd[1] == '-a':
                return 0, 'C\nen_US.utf8\nC.utf8\n', ''
            else:
                return 0, 'C.UTF-8', ''

    fake_module = FakeModule()

    rv = ansible.module_utils.basic.get_best_parsable_locale(fake_module)
    assert rv == 'C.utf8'

    rv = ansible.module_

# Generated at 2022-06-20 15:55:45.830002
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    try:
        result = get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8', 'C'])
    except RuntimeWarning:
        result = 'C'

    assert result in ['C', 'en_US']

# Generated at 2022-06-20 15:55:57.491210
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import shutil
    import os
    import tempfile
    import mock

    # Mock the module
    # Create a tempfile for the mock module to use
    test_file = tempfile.NamedTemporaryFile(delete=False)
    # Create the mock module that will be passed
    class MockModule:
        def __init__(self, locale_file=None):
            self.params = []
            self.fail_json = mock.MagicMock()
            # Store the path to the tempfile
            self.file = locale_file
        def get_bin_path(self, name):
            # mock the binary path
            if name == 'locale':
                return to_native(self.file.name)
            return None

# Generated at 2022-06-20 15:56:02.788260
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test default preference
    assert get_best_parsable_locale(None) == 'C'

    # Test specific preference
    assert get_best_parsable_locale(None, preferences=['en_US.utf8']) == 'en_US.utf8'

    # Test locale not found
    assert get_best_parsable_locale(None, preferences=['not_exist']) == 'C'

# Generated at 2022-06-20 15:56:09.087705
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.modules.system import locale_gen
    from ansible.module_utils.common.process import get_bin_path

    locale = get_bin_path('locale')
    if locale:
        preferences = ['eng_US.utf_8', 'POSIX', 'C']
        try:
            best_parsable_locale = get_best_parsable_locale(locale_gen, preferences, True)
            assert best_parsable_locale in preferences
        except:
            pass

# Generated at 2022-06-20 15:56:20.552517
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # test for exception
    from ansible.module_utils.basic import AnsibleModule
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import environ
    from os.path import join, realpath


# Generated at 2022-06-20 15:56:26.539022
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule()
    best_locale = get_best_parsable_locale(mod)
    print (best_locale)

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-20 15:56:36.683259
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Module instance not needed in test.
    class Module:
        def get_bin_path(self, name):
            return name

        def run_command(self, cmd):
            if cmd[0] == 'locale' and cmd[1] == '-a':
                return (0, 'C\nPOSIX\nen_US.utf8\nen.utf8\nC.utf8', None)
            else:
                raise Exception('Unexpected command "%s"' % cmd)

    module = Module()

    # This shouldn't raise
    assert get_best_parsable_locale(module) == 'POSIX'

    # These should raise
    module.get_bin_path = lambda name: None

# Generated at 2022-06-20 15:56:41.155709
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # import the mock module
    from ansible.module_utils.basic import AnsibleModule
    # make a module that pretends it is on a system where no locale is available
    module = AnsibleModule({})
    # call the function to test with reasonable defaults
    locale = get_best_parsable_locale(module)
    # default POSIX locale is 'C', verify that
    assert locale == 'C'

# Generated at 2022-06-20 15:56:48.827578
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Tests AnsibleModule.get_best_parsable_locale() method.
    '''
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule(argument_spec={})
    assert test_module.get_best_parsable_locale(preferences=['C']) == 'C'
    assert test_module.get_best_parsable_locale(preferences=['C.utf8']) == 'C.utf8'

# Generated at 2022-06-20 15:56:59.995151
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) in ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(module, ['fr_FR.utf8', 'es_ES.utf8']) in ['fr_FR.utf8', 'es_ES.utf8', 'C.utf8', 'en_US.utf8', 'C', 'POSIX']

# Generated at 2022-06-20 15:57:09.081026
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 15:57:23.351746
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule()
    mod.run_command = lambda args: (0, "C\nen\nen_US\nen_US.utf8", '')
    assert get_best_parsable_locale(mod, ['en_US.utf8', 'en_US']) == 'en_US.utf8'
    assert get_best_parsable_locale(mod, ['en_US', 'xx_XX']) == 'en_US'
    assert get_best_parsable_locale(mod, ['xx_XX']) == 'C'
    mod.run_command = lambda args: (0, "C\nen\nen_US\nen_US.utf8", 'This is an exception')
    assert get_best_parsable_

# Generated at 2022-06-20 15:57:26.437170
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule()
    assert get_best_parsable_locale(module, preferences=['C', 'en_US.utf8']) == 'C'

    # The following scenario is not possible on an OS supporting locale.
    # In this case, we would be using the default locale, not 'en_US.utf8'
    module = AnsibleModule()
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'en_GB.utf8']) == 'en_US.utf8'

# Generated at 2022-06-20 15:57:33.858934
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # First test to prove that C locale is the default and we get it even if
    # the module fails completely
    tmp = FakeModule(['locale', '-a']).get_bin_path("locale")
    assert tmp is None
    tmp = get_best_parsable_locale(FakeModule(['locale', '-a']))
    assert tmp == 'C'

    # Second test to prove that locales from module can be parsed (with or without
    # empty line)
    locale_no_output = FakeModule(['locale', '-a'], rc=0, out='', err='No output from locale')
    tmp = get_best_parsable_locale(locale_no_output)
    assert tmp == 'C'

    # Third test to prove that we pass the test in case of rc=0 and

# Generated at 2022-06-20 15:57:45.299289
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # when there is no locale command on the host
    module.run_command = lambda _: (1, '', '')
    assert module.get_bin_path("locale") is None
    assert module.run_command([module.get_bin_path("locale"), '-a']) == (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # when there is locale command on the host, but no locale matches the preference list
    module.run_command = lambda _: (0, 'a b c', '')
    assert module.get_bin_path("locale")

# Generated at 2022-06-20 15:57:57.499569
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import unittest
    import tempfile

    #assert isinstance(os.environ.get('LANG'), basestring)

    locale_list = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    class ModuleFake(object):

        def __init__(self, locale_list):
            self.locale_list = locale_list

        def get_bin_path(self, name):
            return '/usr/bin/locale'

        def run_command(self, cmd):
            rc = 0
            err = ''
            if self.locale_list is None:
                rc = 1
                out = ''
                err = 'No locales found'
            elif not self.locale_list:
                rc = 1
                out = ''

# Generated at 2022-06-20 15:57:59.329876
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = object()
    assert get_best_parsable_locale(module, ['missing_locale', 'C']) == 'C'

# Generated at 2022-06-20 15:58:10.281152
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test the get_best_parsable_locale function
    '''

    # we need to mock AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    import os

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.run_command = lambda x, encoding=None: (0, os.linesep.join(["C","C.utf8","POSIX","en_US.utf8"]), "")

    assert get_best_parsable_locale(module) == "C.utf8"
    assert get_best_parsable_locale(module, preferences=["en_US.utf8", "POSIX", "C"]) == "en_US.utf8"

    # Now, we mock the locale command to return an invalid locale

# Generated at 2022-06-20 15:58:16.537043
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class AnsibleModuleTest(AnsibleModule):
        def __init__(self):
            super(AnsibleModuleTest, self).__init__()

        def run_command(self, cmd):
            cmd = ' '.join(cmd)
            if 'get_bin_path' in cmd:
                cmd_name = 'get_bin_path'
            elif 'locale -a' in cmd:
                cmd_name = 'locale -a'
            else:
                cmd_name = None

            if cmd_name == 'get_bin_path':
                return 0, '/usr/bin/locale', ''

# Generated at 2022-06-20 15:58:27.050665
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, preferences=['C.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(None, preferences=['C.utf8', 'C.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(None, preferences=['C.utf8', 'es_ES.iso88591']) == 'C.utf8'
    assert get_best_parsable_locale(None, preferences=['C.utf8', 'es_ES.iso88591'], raise_on_locale=True) == 'C.utf8'

# Generated at 2022-06-20 15:58:32.981514
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    expected_found = 'C.utf8'
    available = ['en_US.utf8', 'C', 'POSIX', 'C.utf8']

    # The func needs to be imported directly because we don't want to run
    # the unit tests with a locale we are not expecting
    from ansible.module_utils.basic import get_best_parsable_locale as gbpl

    found = gbpl(None, preferences, available)

    assert found == expected_found, \
        "Best locale found = '{}' (expected '{}')".format(found, expected_found)

# Generated at 2022-06-20 15:58:44.154232
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'test': {'required': True}})

    best_locale = get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'POSIX'], True)
    print(best_locale)
    assert best_locale == 'C.utf8'

# Generated at 2022-06-20 15:58:48.964331
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class MockModule(object):
        def get_bin_path(self, cmd):
            return cmd

        def run_command(self, cmd):
            return 0, "It's not a bug, it's a feature.", None

    mod = MockModule()
    rc = [
        get_best_parsable_locale(mod, ['fr_FR.utf8']),
        get_best_parsable_locale(mod, ['invalid-locale', 'de_DE.utf8']),
    ]
    assert 'C' in rc

# Generated at 2022-06-20 15:58:54.302174
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test with a given list of locales
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    locale = get_best_parsable_locale(preferences)
    assert preference[0] == locale

    # Test with a None parameter
    preferences = None
    locale = get_best_parsable_locale(preferences)
    assert preference[0] == locale

# Generated at 2022-06-20 15:59:05.055024
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Should return true because a list of prefered locales is provided in order
    assert get_best_parsable_locale(['en_US.utf8', 'en_US.utf8', 'en_US.utf8']) == 'en_US.utf8'

    # Should return true because a list of prefered locales is provided in order
    assert get_best_parsable_locale(['fr_FR.utf8', 'en_US.utf8', 'en_US.utf8']) == 'fr_FR.utf8'

    # Should return 'C' because a list of prefered locales is provided in order
    assert get_best_parsable_locale(['junk', 'morejunk', 'evenmorejunk']) == 'C'

    # Should return 'C' because no list of prefered

# Generated at 2022-06-20 15:59:16.195249
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    assert get_best_parsable_locale(m, preferences=None) == 'C'

    assert get_best_parsable_locale(m, preferences=['C.utf8', 'en_US.utf8', 'C']) == 'C'

    test_successful_locale_output = '''
# locale -a
C
C.UTF-8
de_DE.utf8
en_US.utf8
POSIX
'''


# Generated at 2022-06-20 15:59:26.992016
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def test_command(*args, **kwargs):
        return 1, '', 'error'

    module = AnsibleModule(command_fn=test_command)

    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'
    assert get_best_parsable_locale(module, preferences=['fr_FR'], raise_on_locale=True) == 'C'

    with pytest.raises(RuntimeWarning) as exception:
        assert get_best_parsable_locale(module, raise_on_locale=False) == 'C'
    assert exception.match('Unable to get locale information')

# Generated at 2022-06-20 15:59:31.350407
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Check for basic 'C' locale
    assert get_best_parsable_locale(None, preferences=['C']) == 'C'

    # Check for basic 'C.utf8' locale
    assert get_best_parsable_locale(None, ['C.utf8']) == 'C.utf8'

# Generated at 2022-06-20 15:59:39.475959
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class module:
        class fail_json:

            def __init__(self, msg):
                self.msg = msg

            def __call__(self, *args, **kwargs):
                raise AssertionError(self.msg)

        def run_command(self, cmd):
            if cmd[1] == '-a':
                return 0, "locale\npossible\nlist\nof\nlocalization\noptions\nC\nen_US.utf8\nPOSIX\n", ""

        def get_bin_path(self, name):
            return 'a path'

        def __init__(self, *args, **kwargs):
            pass

    module_obj = module()
    assert get_best_parsable_locale(module_obj) == "C"

    assert get_best_p

# Generated at 2022-06-20 15:59:52.579950
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible
    from ansible.module_utils.basic import AnsibleModule

    # test that defaults are C when no locale is present
    module = AnsibleModule({})
    module.get_bin_path = lambda x: None
    assert('C' == get_best_parsable_locale(module))

    # test that locals are C if the locale command fails
    def run_command_mock_fail(*args):
        return (1, '', '')
    module.run_command = run_command_mock_fail
    assert('C' == get_best_parsable_locale(module))

    # test that locales are C if the locale command returns no output
    def run_command_mock_no_output(*args):
        return (0, '', '')
    module.run_command = run

# Generated at 2022-06-20 16:00:00.430451
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class MockModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, bin_name):
            return '/usr/bin/' + bin_name

        def run_command(self, cmd):
            rc = 0
            if cmd[1] == '-a':
                out = 'C\nen_US.utf8\n'
            return rc, out, ''

    mm = MockModule()
    assert get_best_parsable_locale(mm) == 'en_US.utf8'

# Generated at 2022-06-20 16:00:23.557710
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from unittest.mock import patch, Mock, sentinel

    argv = [sentinel.mod_name, sentinel.mod_path, sentinel.mod_args, sentinel.mod_kwargs]
    module_mock = Mock(AnsibleModule, spec_set=True, **{i: sentinel.argv for i, sentinel.argv in enumerate(argv)})
    module_mock.boolean = lambda arg: arg
    module_mock.params = lambda: {}
    module_mock.check_mode = lambda: False
    module_mock.no_log = lambda: False
    module_mock.fail_json = lambda failure, **kwargs: failure

# Generated at 2022-06-20 16:00:33.451047
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class MockModule:
        def get_bin_path(self, name):
            return 'locale'
        def run_command(self, cmd):
            rc = 0
            out = ''
            err = ''
            if cmd == ['locale', '-a']:
                out = 'en_US.utf8\nC.utf8\nC'
            else:
                rc = 1
            return rc, out, err

    module = MockModule()

    # Try with the defaults
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Try with another list of preferred locales
    preferences = ['POSIX', 'C']
    assert get_best_parsable_locale(module, preferences) == 'C'

    # Try with a list of preferred locales that are not supported

# Generated at 2022-06-20 16:00:43.476991
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Import module and create bare minimum AnsibleModule object.
    from ansible.module_utils.basic import AnsibleModule
    dummy_module = AnsibleModule(argument_spec=dict())

    # Test for no available locales.
    assert get_best_parsable_locale(dummy_module, preferences=None) == 'C'

    # Test for 'C' locale available.
    dummy_module.run_command = lambda command: (0, 'C\nen_US.utf8', '')
    assert get_best_parsable_locale(dummy_module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test for 'C.utf8' locale available and preferred.

# Generated at 2022-06-20 16:00:54.868662
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' test get_best_parsable_locale '''
    # Test that exception is not thrown and we return 'C' by default
    class Tmp:
        def get_bin_path(self, bin):
            if bin == 'locale':
                return False

        def run_command(self, args):
            if args == ['locale', '-a']:
                return 1, '', 'Returned error'

    tm = Tmp()
    assert 'C' == get_best_parsable_locale(tm)

    # Test that we return 'en_US.utf8' by order of preference
    class Tmp2:
        def get_bin_path(self, bin):
            if bin == 'locale':
                return 1


# Generated at 2022-06-20 16:01:07.753177
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_best_parsable_locale as gbp

    test_mod = AnsibleModule(argument_spec={})
    test_mod.run_command = lambda cmd: ('Command stub', cmd, '')

    return_value = gbp(test_mod)
    assert return_value == 'C'

    return_value = gbp(test_mod, ['zh_CN.utf8', 'fr_FR.utf8'])
    assert return_value == 'C'

    test_mod.run_command = lambda cmd: ('', cmd, '')
    return_value = gbp(test_mod, ['C'])
    assert return_value == 'C'


# Generated at 2022-06-20 16:01:10.477349
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'POSIX'

# Generated at 2022-06-20 16:01:19.272810
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Functions used by AnsibleModule
    def run_command(args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None,
                    use_unsafe_shell=False, prompt_regex=None):
        return (0, '', '')

    def get_bin_path(self, arg, required=False, opt_dirs=[]):
        if arg == 'locale':
            return arg

    # Mock AnsibleModule
    ansible_module = AnsibleModule(
        argument_spec=dict(),  # no args
        supports_check_mode=False
    )
    ansible_module.run_command = run_command
    ansible_module.get

# Generated at 2022-06-20 16:01:24.201920
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    from ansible.module_utils.six import StringIO

    # This is the output of running locale -a on a Debian system with 8 locales
    locale_a_output = '''C
en_US.utf8
C.utf8
POSIX
fr_FR.utf8
fr_FR.utf-8
de_DE.utf8
de_DE.utf-8'''

    class TestModule:
        def __init__(self):
            self.params = {}
            self.exit_json = ansible.module_utils.basic._ANSIBLE_ARGS['exit_json']
            self.fail_json = ansible.module_utils.basic._ANSIBLE_ARGS['fail_json']


# Generated at 2022-06-20 16:01:34.815080
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    import os
    class FakeModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(FakeModule, self).__init__(*args, **kwargs)
            self.run_command_environ_update = dict()

        def get_bin_path(self, cmd, required=True):
            return "/usr/bin/locale"


# Generated at 2022-06-20 16:01:45.084912
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.basic import AnsibleModule

    for language in ['C', 'POSIX']:
        module = AnsibleModule(argument_spec=dict())
        result = get_best_parsable_locale(module)
        assert result == language

    # Add POSIX and C to available
    for language in ['POSIX', 'C']:
        module = AnsibleModule(argument_spec=dict())
        module.run_command = lambda command, check_rc=True: (0, language, None)
        result = get_best_parsable_locale(module)
        assert result == language

    # Add POSIX and C to available, POSIX is preferred

# Generated at 2022-06-20 16:02:09.815973
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Ensure the default returns the default
    assert get_best_parsable_locale(None) == 'C'

    # Ensure that a locale that exists is returned
    assert get_best_parsable_locale(None, ['C']) == 'C'

    # Ensure that a locale that exists is returned
    assert get_best_parsable_locale(None, ['C', 'POSIX']) == 'C'

    # Ensure that the first found is returned
    assert get_best_parsable_locale(None, ['POSIX', 'C']) == 'POSIX'
    assert get_best_parsable_locale(None, ['POSIX', 'C', 'en_US']) == 'POSIX'

    # Ensure that 'en_US' is returned even though its not in the list
    # because its

# Generated at 2022-06-20 16:02:19.682349
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six.moves import shlex_quote

    # Use the basic module to create a mock AnsibleModule
    ansible.module_utils.basic._ANSIBLE_ARGS = shlex_quote(str({'ANSIBLE_MODULE_ARGS': {}}))
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    old_run_command = ansible.module_utils.basic.run_command

    # All the locales should be fake, except for en_US.utf8

# Generated at 2022-06-20 16:02:27.151028
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    m = {}
    assert get_best_parsable_locale(m) == 'C'
    assert get_best_parsable_locale(m, raise_on_locale=True) == 'C'

    m['run_command'] = lambda x, check_rc=False: (0, 'C\nen_US.utf8', '')
    assert get_best_parsable_locale(m) == 'C'
    assert get_best_parsable_locale(m, raise_on_locale=True) == 'C'

    m['run_command'] = lambda x, check_rc=False: (0, 'C\nen_US.utf8', '')

# Generated at 2022-06-20 16:02:32.573258
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from units.compat.mock import Mock
    mock_module = Mock(run_command=lambda x, check_rc=True: (0, 'C\nen_US.utf8\nen_US.utf', None))
    mock_module.get_bin_path = lambda x: 'locale'
    assert get_best_parsable_locale(mock_module) == 'en_US.utf8'

    mock_module.run_command = lambda x, check_rc=True: (0, None, None)
    assert get_best_parsable_locale(mock_module) == 'C'

    mock_module.run_command = lambda x, check_rc=True: (0, None, None)
    mock_module.get_bin_path = lambda x: None
    assert get_best_p

# Generated at 2022-06-20 16:02:39.407049
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    module = unittest.mock.MagicMock()

    # locale installed and supported locale found
    locale = '/bin/locale'
    out = '''C
en_US.utf8
POSIX
de_DE.utf8'''
    rc = 0
    err = ''
    module.get_bin_path.return_value = locale
    module.run_command.return_value = (rc, out, err)
    result = get_best_parsable_locale(module)
    assert result == 'POSIX'

    # locale not installed
    module.get_bin_path.return_value = None
    result = get_best_parsable_locale(module)

# Generated at 2022-06-20 16:02:49.276026
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.system.locale import get_best_parsable_locale

    rc = 0
    out = ''
    err = ''
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda args: (rc, out, err)
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert preferences == get_best_parsable_locale(module, preferences)

    preferences = ['tf.utf8', 'C.us.utf8', 'C', 'POSIX']
    assert 'C' == get_best_parsable_locale(module, preferences)

    rc = 1
    out = 'Error'
    assert 'C' == get

# Generated at 2022-06-20 16:02:51.118607
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = MockModule()
    assert get_best_parsable_locale(module, None, False) == 'C'


# Generated at 2022-06-20 16:02:57.585337
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.utils
    import random
    # AnsibleModule isn't available directly in the module_utils.basic, so we need to import it here
    from ansible.module_utils.basic import AnsibleModule

    results = []
    class MockModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(MockModule, self).__init__(*args, **kwargs)
            self.params = {}
            self.tmpdir = "/tmp"
        def get_bin_path(self, _):
            i = random.randint(0, len(results) - 1)
            if results[i] == "Exception":
                raise RuntimeWarning("Something broke")
            elif results[i] == "fail":
                return None
           

# Generated at 2022-06-20 16:03:08.668242
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale({
        'get_bin_path': lambda x: True,
        'run_command': lambda x: (0, "", "")
    }, preferences=['C.UTF-8']) == 'C.UTF-8'

    assert get_best_parsable_locale({
        'get_bin_path': lambda x: True,
        'run_command': lambda x: (0, "", "")
    }, preferences=['POSIX.RFC3339', 'C.UTF-8']) == 'POSIX.RFC3339'


# Generated at 2022-06-20 16:03:11.226898
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # TODO: implement unit test
    assert True

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-20 16:03:48.723124
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path
    module = AnsibleModule(argument_spec={})
    module.fail_json = fail_json
    module.exit_json = exit_json
    module.get_bin_path = get_bin_path
    module.params = {'preferences': ['C.utf8', 'en_US.utf8', 'C', 'POSIX']}

    def test_run_command_1(cmd, check_rc=True, close_fds=False, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None):
        return (0, '', None)


# Generated at 2022-06-20 16:03:54.805571
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    import sys
    import os

    # Create a temp module to get tmpdir from
    tmpdir = AnsibleModule(argument_spec={}).tmpdir
    sys.path.append(os.path.join(tmpdir, 'library'))
    # Now import basic module to use get_bin_path method
    basic = __import__('ansible.module_utils.basic.basic')
    best_locale = get_best_parsable_locale(basic)
    assert best_locale == 'C'

# Generated at 2022-06-20 16:04:04.167981
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    module = AnsibleModule(
        argument_spec={
            'test_string': {'type': 'str'},
        }
    )
    module.params = ImmutableDict(test_string='some string')
    best_locale = get_best_parsable_locale(module, [], True)
    # run_command did not run, best_locale == 'C'
    assert best_locale == 'C'

    def dummy_run_command(*args, **kwargs):
        # defaults
        ret = 0
        out = b''
        err = b''

        # switch on command args
       

# Generated at 2022-06-20 16:04:10.895704
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule(
        argument_spec=dict(
            locale=dict(default='en_US.UTF-8', aliases=['lang'])
        )
    )

    l = get_best_parsable_locale(mod)

    # On Mac, we would get this one
    assert 'C' == l

    # On Linux, it should be this one
    assert 'C.utf8' == l

# Unit Test for function get_best_parsable_locale()

# Generated at 2022-06-20 16:04:22.819888
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        module = None
    else:
        module = AnsibleModule(argument_spec={})

    # Test rc 1
    locale = get_best_parsable_locale(module, raise_on_locale=True)
    assert locale == 'C'

    # Test rc 0
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda x: (0, "C\nC.utf8\nPOSIX", '')
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    # Test preferences and rc 0
    module = AnsibleModule(argument_spec={})