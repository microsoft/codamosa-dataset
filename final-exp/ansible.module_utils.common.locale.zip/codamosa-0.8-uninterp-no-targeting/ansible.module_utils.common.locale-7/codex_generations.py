

# Generated at 2022-06-20 15:54:30.532948
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, ['C', 'en_US.utf8'], raise_on_locale=True) is not None

# Generated at 2022-06-20 15:54:39.646950
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile
    import os
    from ansible.module_utils.basic import AnsibleModule

    # Should return en_US.utf8
    MOD_PATH = os.path.dirname(os.path.abspath(__file__))
    tests = [
        '''
C
C.UTF-8
en_US.utf8
POSIX
''',
        '''
C
C.UTF-8
POSIX''']


# Generated at 2022-06-20 15:54:49.943277
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_module = object()
    locale_module.fail_json = fail_json
    locale_module.get_bin_path = get_bin_path
    locale_module.run_command = run_command

    for lang in [None, []]:
        for raise_on_locale in [True, False]:
            assert get_best_parsable_locale(locale_module, lang, raise_on_locale) == 'C'


# Generated at 2022-06-20 15:54:56.021073
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # test if we get the right locale back
    assert get_best_parsable_locale(None, ['POSIX', 'C']) == 'POSIX'
    # test if we return C when preferences list is empty
    assert get_best_parsable_locale(None, []) == 'C'
    # test if we return C when preferences is None
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-20 15:55:00.674192
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.facts.system.locale as locale_data
    assert locale_data.get_best_parsable_locale({}, None, False)
    assert locale_data.get_best_parsable_locale({}, ['en_US.utf8'], False)


# Generated at 2022-06-20 15:55:03.940646
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-20 15:55:15.746887
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.six.moves import StringIO

    # Mock up all the things needed for the function get_best_parsable_locale
    class MyModule:

        def __init__(self, tmp, rc=0, out=None, err=None):
            self.tmp = tmp
            self.rc = rc
            self.out = out
            self.err = err


# Generated at 2022-06-20 15:55:23.994788
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import b
    from ansible.module_utils.common.process import get_bin_path

    module = AnsibleModule(argument_spec={})

    if get_bin_path(module, 'locale'):
        # test get_best_parsable_locale returns C by default if the default preferred locales are not
        # matched in the output of locales -a
        result = get_best_parsable_locale(module)
        assert result == 'C'

        # test get_best_parsable_locale returns the first matched preferred locale from the output of
        # locale -a
        result = get_best_parsable_locale(module, preferences=['C.utf8'])

# Generated at 2022-06-20 15:55:33.191003
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys

    # This function cannot be tested on Windows due to it's reliance on the CLI
    if sys.platform.startswith('win'):
        return

    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    tmp = tempfile.mkdtemp()

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        add_file_common_args=False,
    )

    # set language env to test case en_US/UTF8
    old_env = dict(os.environ)
    os.environ['LANGUAGE'] = os.environ['LANG'] = os.environ['LC_ALL'] = 'en_US.UTF-8'


# Generated at 2022-06-20 15:55:44.188325
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # No preference, no locale cmd
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # No preference, locale cmd available
    module.get_bin_path = lambda x: True
    assert get_best_parsable_locale(module) == 'C'

    # Preferred given, no locale cmd
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module, ['C']) == 'C'

    # Preferred given, locale cmd available, preferred not found
    module.run_command = lambda x: (0, 'en_US', '')
    assert get_

# Generated at 2022-06-20 15:55:57.841807
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Initiate a fake AnsibleModule object
    class FakeModule:
        def __init__(self):
            self.run_command_called = False

        def get_bin_path(self, tool):
            return '/usr/bin/locale'

        def run_command(self, args):
            self.run_command_called = True
            return 0, 'en_US.UTF-8\nLANG=en_US.UTF-8', ''

    fake_module = FakeModule()

    # Test that 'locale -a' command is called correctly
    assert(get_best_parsable_locale(fake_module) == 'en_US.UTF-8')
    assert(fake_module.run_command_called)

    # Reset the flag for next test
    fake_module.run_command_called = False



# Generated at 2022-06-20 15:56:07.418480
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeModule:
        def __init__(self, out, prefs):
            self._out = out
            self._prefs = prefs

        def get_bin_path(self, path):
            return 'locale'

        def run_command(self, args):
            return 0, self._out, ''

    class MyException(Exception):
        pass

    # Test that preferences are honored
    m = FakeModule('C.utf8\nen_US.utf8\nC\nPOSIX', prefs=['POSIX', 'C'])
    assert get_best_parsable_locale(m) == 'POSIX'
    m = FakeModule('C.utf8\nen_US.utf8\nC\nPOSIX', prefs=['en_US.utf8'])
    assert get_best_p

# Generated at 2022-06-20 15:56:08.276139
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-20 15:56:19.710495
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.locale import get_best_parsable_locale
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.pycompat24 import get_exception
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.basic import AnsibleModule

    locale_utility = os.path.join(os.path.realpath(__file__), '..', '..', 'utils', 'locale')


# Generated at 2022-06-20 15:56:31.674673
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import mock
    from ansible.module_utils.basic import AnsibleModule
    import locale

    # Note: I18n in unittest means *don't* run the test with locale environment variables
    # and tests that deal with locale information must to unset the variables.
    original_environment = dict(os.environ)
    for env in ('LANG', 'LANGUAGE'):
        if env in os.environ:
            del os.environ[env]

    # This is needed to make sure we are not getting locales from environment
    reload(locale)


# Generated at 2022-06-20 15:56:36.246620
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.local_ansible_utils

    fake_module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    ansible.module_utils.local_ansible_utils.get_best_parsable_locale(fake_module)

# Generated at 2022-06-20 15:56:41.513530
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.release import __version__
    preferences = ['C.utf8', 'C']
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        bypass_checks=False
    )
    found = get_best_parsable_locale(module)
    assert found in preferences, 'Unexpected locale "%s", expected one of "%s"' % (found, preferences)

# Generated at 2022-06-20 15:56:52.463794
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import tempfile
    import shutil

    LOCALE_DIR="/tmp/locale-test"
    LOCALE_FILE="/tmp/locale-test/fake_locale"

    os.makedirs(LOCALE_DIR)
    open(LOCALE_FILE, 'a').close()

    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule(argument_spec={}, supports_check_mode=False)

    fake_locale = get_best_parsable_locale(mod, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=False)
    assert fake_locale == 'POSIX'
    shutil.rmtree(LOCALE_DIR)

# Generated at 2022-06-20 15:56:59.472883
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_result = get_best_parsable_locale(None)
    if locale_result == 'C':
        assert True
    else:
        assert False

    preferences = ['fr_FR.utf8', 'C.utf8', 'en_US.utf8', 'C', 'POSIX']
    locale_result = get_best_parsable_locale(None, preferences)
    if locale_result == 'C':
        assert True
    else:
        assert False

# Generated at 2022-06-20 15:57:09.000906
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os

    class FakeModule(object):
        class FakeRunCommand(object):
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

            def __call__(self, command, input=None, data=None):
                return self.rc, self.out, self.err

        def __init__(self, with_locale=True, locale_rc=0, locale_out='', locale_err=''):
            self.params = {}
            self.version_info = sys.version_info[0]
            self.run_command = self.FakeRunCommand(locale_rc, locale_out, locale_err)
            self.get_bin_path = False

# Generated at 2022-06-20 15:57:19.274349
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    fake_module = AnsibleModule({'shell': 'sh'})
    if get_best_parsable_locale(fake_module, preferences=['C', 'C.ISO-8859-1']) == 'C':
        pass
    else:
        raise AssertionError('Unexpected locale')


# Generated at 2022-06-20 15:57:26.661315
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import common_koji
    from ansible.modules.packaging.language.pip import _best_parsable_locale

    a_module = AnsibleModule({})
    _best_parsable_locale.get_best_parsable_locale(a_module)

    common_koji.LC_ALL.pop()

# Generated at 2022-06-20 15:57:38.219865
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Python 27 compat: module_utils.basic.AnsibleModule used to not work with kwargs
    # in the constructor, so we need to use it without kwargs here
    module = AnsibleModule({})

    # we should always be able to find C since that's a POSIX requirement
    assert get_best_parsable_locale(module) == "C"

    # If a valid locale is passed in it should be returned
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C']) == "en_US.utf8"

    # if an invalid locale is being used default to 'C'
    assert get_best_parsable_loc

# Generated at 2022-06-20 15:57:46.754200
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule(argument_spec={})
    results = get_best_parsable_locale(mod)
    assert results is not None
    assert results == 'C'

    results = get_best_parsable_locale(mod, preferences=['en_US.utf8', 'C'])
    assert results is not None
    assert results == 'en_US.utf8'

    results = get_best_parsable_locale(mod, preferences=['fr_FR.utf8', 'C'])
    assert results is not None
    assert results == 'C'

# Generated at 2022-06-20 15:57:57.801629
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Test success
    preferences = ['C.utf8', 'en_US.utf8', 'POSIX', 'C']
    locale = 'C.utf8'
    assert locale == get_best_parsable_locale(mod, preferences=preferences)

    # Test success
    preferences = ['C.utf8', 'en_US.utf8', 'POSIX', 'C']
    locale = 'POSIX'
    assert locale == get_best_parsable_locale(mod, preferences=preferences)

    # Test success
    preferences = ['C.utf8', 'en_US.utf8', 'POSIX', 'C']
    locale = 'C'


# Generated at 2022-06-20 15:58:08.451815
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils._text import to_bytes
    import sys
    sys.path.insert(0, '../')
    from ansible.modules.packaging.os import locale_gen
    module = locale_gen._system_state_change_locale_gen
    module.get_bin_path = lambda x: "/bin/locale"

    orig_run_command = module.run_command
    def test_module_run_command(args, **kwargs):
        rc = 0
        out = b"POSIX\nen_US.utf8\nC.utf8\nC.utf8\nen_US.utf8"
        err = b""

        return (rc, out, err)

    module.run_command = test_module_run_command
    # Test normal
    assert module.get_best_

# Generated at 2022-06-20 15:58:15.460188
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # mock up a module instance
    class MockModule(object):
        def __init__(self, out, err, rc):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, *args):
            return "/usr/bin/locale"

        def run_command(self, command):
            return self.rc, self.out, self.err


    # run successful test
    module = MockModule('en_US.utf8\nC', '', 0)
    assert get_best_parsable_locale(module, ['en_US.utf8', 'C']) == 'en_US.utf8'

    # fail on no output from locale command
    module = MockModule('', '', 0)

# Generated at 2022-06-20 15:58:26.528222
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # test 1
    # For this test, we need to mock the ansible module
    module_path = 'ansible.module_utils.basic.AnsibleModule'
    from mock import Mock
    am = Mock()
    am.get_bin_path.return_value = '/usr/bin/locale'
    am.error.side_effect = RuntimeWarning
    am.run_command.return_value = (0,'C\nen_US.utf8\nen_US.utf\nen_US\nC.utf8\nC.utf\nC.utf\nPOSIX\n','')

    module = am
    prefs = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    raise_on_locale = False

# Generated at 2022-06-20 15:58:32.538157
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class DummyModule:

        def __init__(self, module):
            self._module = module

        def get_bin_path(self, cmd):
            if cmd == "locale":
                return "/bin/locale"
            else:
                return None

        def get_bin_path_with_default(self, cmd):
            return self.get_bin_path(cmd)

        def run_command(self, cmd):
            if cmd == ['/bin/locale', '-a']:
                return 0, "C\nen_US.utf8\nC.utf8", ''
            else:
                return -1, '', 'does not matter'

    module_mock = DummyModule(AnsibleModule)
    assert get_best_p

# Generated at 2022-06-20 15:58:42.475079
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) is not None
    assert get_best_parsable_locale(module, ['de_DE.utf8']) is 'C'
    assert get_best_parsable_locale(module, ['de_DE.utf8', 'C']) is 'C'
    assert get_best_parsable_locale(module, ['de_DE.utf8', 'C.utf8']) is 'C.utf8'
    assert get_best_parsable_locale(module, ['de_DE.utf8', 'C', 'C.utf8']) is 'C'

# Generated at 2022-06-20 15:58:55.928216
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys
    import subprocess
    out = subprocess.check_output(["locale", "-a"])
    locale_list = out.strip().splitlines()
    if ('C.utf8' in locale_list) or ('en_US.utf8' in locale_list) or ('C' in locale_list):
        C_locale = 'C'
    elif ('C.UTF-8' in locale_list) or ('en_US.UTF-8' in locale_list):
        C_locale = 'C.UTF-8'

    # if preferred locale is available, return it
    assert C_locale == get_best_parsable_locale(None, [C_locale])

    # if preferred locale is not available but 'C' is available, return 'C'
    assert C_

# Generated at 2022-06-20 15:58:59.075885
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule(argument_spec={})
    assert am.get_bin_path("locale") is not None
    assert get_best_parsable_locale(am) != ''

# Generated at 2022-06-20 15:59:08.037680
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    found = module.get_best_parsable_locale()

    assert module.get_best_parsable_locale(preferences=['C.utf8', 'C']) == 'C'
    assert module.get_best_parsable_locale(preferences=['POSIX']) == 'C'
    assert module.get_best_parsable_locale(preferences=['en_US.utf8']) == 'en_US.utf8'

    # when 'locale' tool is unavailable, then fallback to ASCII
    module.get_bin_path = lambda *args, **kwargs: ''

# Generated at 2022-06-20 15:59:17.256067
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['C.UTF-8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, ['de_DE.UTF-8', 'en_US.utf8', 'C', 'POSIX']) == 'de_DE.UTF-8'
    assert get_best_parsable_locale(None, ['de_DE.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'de_DE.utf8'
    assert get_best_parsable_locale(None, ['de_DE.UTF8', 'en_US.utf8', 'C', 'POSIX']) == 'de_DE.UTF8'
    assert get_best_p

# Generated at 2022-06-20 15:59:24.361821
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Forcing a 'locale' failure/error message
    from ansible.module_utils.basic import to_native
    from ansible.module_utils.common._collections_compat import namedtuple
    import json
    import re


# Generated at 2022-06-20 15:59:34.454371
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.parsing.convert_bool import boolean

    class TestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            module_args = {
                'always_run': 'yes',
                'run_once': 'no'
            }
            AnsibleModule.__init__(self, *args, **kwargs)

    load_result = {'changed': True, 'warnings': []}

    am = TestModule()
    am.run_command = lambda cmd, tmp_path, in_data, sudoable: (0, StringIO("C\nextra line\n"), None)
    locale = get_best_p

# Generated at 2022-06-20 15:59:39.395887
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.modules.system.setup import get_best_parsable_locale
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )
    # test for some locale
    locale = get_best_parsable_locale(module, preferences=['C'], raise_on_locale=True)

    assert locale == 'C'

# Generated at 2022-06-20 15:59:46.796648
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Import
    import platform
    import unittest
    import os
    import random

    import ansible.module_utils.basic as module_utils
    import ansible.module_utils.basic

    # Create a fake AnsibleModule that looks like what run_main
    # creates for us.
    class FakeAnsibleModule(object):
        def __init__(self, *args, **kwargs):
            self.module = module_utils.basic.AnsibleModule(
                *args,
                **kwargs)

        def get_bin_path(self, *args, **kwargs):
            return os.path.join(os.path.sep, 'usr', 'bin', args[0])


# Generated at 2022-06-20 15:59:54.865318
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeModule:
        def __init__(self, locale_output):
            self.locale_output = locale_output
            self.locale = get_best_parsable_locale(self, raise_on_locale=True)

        def get_bin_path(self, app=''):
            return '/usr/bin/%s' % app

        def run_command(self, cmd):
            return 0, self.locale_output, None

    # Testing first available locale
    module = FakeModule('C\nen_US.utf8')
    assert module.locale == 'C'

    # Testing the first preferred locale
    module = FakeModule('C\nen_US.utf8')

# Generated at 2022-06-20 16:00:04.385180
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile
    import shutil
    import atexit
    import os

    module = AnsibleModule()

    # Create mock for locale binary (locale is a Python module)
    tmp_dir = tempfile.mkdtemp()
    open(os.path.join(tmp_dir, "locale"), 'a').close()
    os.chmod(os.path.join(tmp_dir, "locale"), 0o777)
    os.environ["PATH"] = tmp_dir + ":" + os.environ["PATH"]

    assert get_best_parsable_locale(module) == 'C'

    shutil.rmtree(tmp_dir, ignore_errors=True)

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-20 16:00:21.701552
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test a list of locales having our preference
    assert get_best_parsable_locale(None,['en_US.utf8', 'en_US.utf-8', 'en_US.UTF-8', 'en_US.utf8', 'en_US.UTF8']) == 'en_US.utf8'

    # Test a list of locales not having our preference
    assert get_best_parsable_locale(None,['en_IN.utf8', 'fr_FR.utf8', 'en_US.iso88591']) == 'C'

    # Test a list of locales not having any locale
    assert get_best_parsable_locale(None, []) == 'C'

    # Test an empty list

# Generated at 2022-06-20 16:00:31.710340
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()

    # list available locales
    rc, out, err = module.run_command([module.get_bin_path("locale"), '-a'])
    assert rc == 0, "Expected rc=0 but rc=%s, stdout=%s, stderr=%s" % (rc, out, err)

    # test default behavior
    locale = get_best_parsable_locale(module)
    assert locale in out.splitlines()

    # test specific preferred list
    pref_list = ['C', 'POSIX']
    locale = get_best_parsable_locale(module, preferences=pref_list)
    assert locale in pref_list

    # test error conditions

# Generated at 2022-06-20 16:00:43.124663
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert get_best_parsable_locale(None, preferences=['en_US.utf8', 'en_US', 'POSIX']) == 'en_US.utf8'
    assert get_best_parsable_locale(None, preferences=['es_ES.utf8', 'es_ES', 'POSIX']) == 'POSIX'
    assert get_best_parsable_locale(None, preferences=['C']) == 'C'
    assert get_best_parsable_locale(None, preferences=['POSIX']) == 'POSIX'
    assert get_best_parsable_locale(None, preferences=['abcd.utf8']) == 'C'

# Generated at 2022-06-20 16:00:51.128867
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    def import_module():
        class MockModule:
            def get_bin_path(self, a):
                return 'locale'
            def run_command(self, a):
                if a == ['locale', '-a']:
                    return 0, 'locale', None
            def fail_json(self, *args, **kw):
                return
        return MockModule()

    module = import_module()
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-20 16:00:59.004786
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # create a fake ansible module to ply the trade
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: x  # assume all binaries are on PATH
    import os

    # find the test data (which always resides in a dir parallel to this source code file)
    __source__ = os.path.realpath(__file__)
    test_data_dir = os.path.dirname(__source__)
    test_data_dir = os.path.join(test_data_dir, "unit_test_data")

    # Define the test data

# Generated at 2022-06-20 16:01:04.351272
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule:
        def get_bin_path(self, path):
            return path

        def run_command(self, cmd):
            return (0, 'C\nen_US.utf8\nen_US.UTF8', '')

    assert get_best_parsable_locale(AnsibleModule()) == 'C'

# Generated at 2022-06-20 16:01:07.758813
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import os

    if os.name == 'nt':
        assert get_best_parsable_locale('Windows_NT') == 'C'
    elif os.name == 'posix':
        assert get_best_parsable_locale('posix') != 'Windows_NT'

# Generated at 2022-06-20 16:01:17.099980
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    # Test 1: good input
    test_input = '''C
C.UTF-8
en_US.utf8
POSIX
'''
    module = AnsibleModule(
        argument_spec=dict(),
    )
    module._output_buffer = StringIO(test_input)

    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test 2: no input
    module = AnsibleModule(
        argument_spec=dict(),
    )
    module._output_buffer = StringIO()

    assert get_best_parsable_locale(module) == 'C'

    # Test 3: bad input

# Generated at 2022-06-20 16:01:23.441008
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys
    import tempfile
    import textwrap
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import iteritems

    # we need to avoid the locale from the environment
    tmp_locale = os.environ.get('LC_ALL', None)
    os.environ['LC_ALL'] = 'C'

    # setup the module
    module = AnsibleModule(argument_spec=dict())

    # the test cases

# Generated at 2022-06-20 16:01:34.132794
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import unittest

    if sys.version_info[0] > 2:
        from unittest.mock import Mock, patch
    else:
        from mock import Mock, patch

    class TestAnsibleModule(object):
        def __init__(self, runner):
            self.runner = runner
            self.fail_json_called = False

        def get_bin_path(self, name):
            return self.runner

        def run_command(self, cmd, check_rc=False):
            return self.runner(*cmd)

        def fail_json(self, **kwargs):
            self.fail_json_called = True

    def test_runner(*args, **kwargs):
        return (0, 'test_result', '')


# Generated at 2022-06-20 16:01:50.745732
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.local import LocalAnsibleModule
    # First test that it returns 'C' when there is no locales available
    module = LocalAnsibleModule(**{})
    module.run_command = lambda x: (1, '', 'No such command')
    assert get_best_parsable_locale(module) == 'C', 'Expected "C"'

    # Then test that it returns the first preferred locale when there are multiple ones

# Generated at 2022-06-20 16:02:01.170902
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Testing the that 'C' is returned if there are no preferred locales
    assert get_best_parsable_locale(None, None) == 'C'

    # Testing the that 'en_US.utf8' is returned if 'C' is not in the list
    assert get_best_parsable_locale(None, ['en_US.utf8', 'C.utf8']) == 'en_US.utf8'

    # Testing the that 'C' is returned if the only preferred locale is 'C' and it is not in the list
    assert get_best_parsable_locale(None, ['C'], raise_on_locale=True) == 'C'

    # Testing the that exception is raised if the only preferred locale is 'C' and it is not in the list
    # and raise_on_locale

# Generated at 2022-06-20 16:02:10.864426
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils as utils
    import ansible.module_utils.basic as basic_utils

    module_args = dict()
    module_args['ansible_python_interpreter'] = '/usr/bin/env python'

    # Mock AnsibleModule instance
    module = basic_utils.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
        bypass_checks=False,
    )

    # Mock get_bin_path()
    def get_bin_path(name, required=True):
        if name == 'locale':
            return '/bin/locale'

    module.get_bin_path = get_bin_path

    # Mock run_command()

# Generated at 2022-06-20 16:02:18.407298
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module) == 'C'

    available = ['C', 'C.utf8', 'fr_FR']
    preferences = ['C.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(module, preferences, available) == 'C.utf8'

    preferences = ['fr_FR.utf8', 'fr_FR', 'POSIX' ]
    assert get_best_parsable_locale(module, preferences, available) == 'fr_FR'

    preferences = ['fr_FR.utf8', 'fr_FR', 'POSIX' ]
    assert get_best_parsable_locale

# Generated at 2022-06-20 16:02:30.791195
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Create dummy AnsibleModule
    class DummyModule:
        def __init__(self):
            self.params = None

        def run_command(self, command):
            if command == [locale, '-a']:
                return 0, 'en_US.utf8\nen_US\nC\nPOSIX\n', ''
            else:
                return 1, '', 'Error'

        def get_bin_path(self, command):
            return command

    m = DummyModule()
    # Call test function
    assert(get_best_parsable_locale(m) == 'en_US.utf8')
    assert(get_best_parsable_locale(m, preferences=['en_US.utf8']) == 'en_US.utf8')

# Generated at 2022-06-20 16:02:35.026210
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, None) == 'C'

# Generated at 2022-06-20 16:02:44.295467
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # no preferences
    assert get_best_parsable_locale(AnsibleModule()) == 'C'

    # multiple preferences, none exist
    preferences = ['en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(AnsibleModule(), preferences) == 'C'

    # single preference
    assert get_best_parsable_locale(AnsibleModule(), ['C']) == 'C'

    # multiple preferences, one exists
    preferences = ['en_US.utf8', 'POSIX']
    assert get_best_parsable_locale(AnsibleModule(), preferences) == 'POSIX'

# Generated at 2022-06-20 16:02:49.366161
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    test_module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())

    cur_locale = get_best_parsable_locale(test_module)
    assert isinstance(cur_locale, str)
    assert cur_locale == 'C'

# Generated at 2022-06-20 16:02:56.858648
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    def set_locale(locale):
        os.environ['LC_ALL'] = locale

    def check_locale(result):
        current_locale = module.run_command('locale')
        assert result == current_locale[1].strip()

    set_locale('pt_BR.utf8')
    if get_best_parsable_locale(module, preferences=['C'], raise_on_locale=True):
        check_locale('C')

    set_locale('pt_BR.utf8')

# Generated at 2022-06-20 16:03:03.336478
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(AnsibleModule):
        pass

    # Test no locale found in preferences
    try:
        locale = get_best_parsable_locale(TestModule(), ['en_US.utf8', 'C.utf8'], raise_on_locale=True)
    except RuntimeWarning:
        locale = 'C'
    assert locale == 'C'

    # Test no preferences given
    locale = get_best_parsable_locale(TestModule())
    assert locale == 'C'

# Generated at 2022-06-20 16:03:12.664560
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'


# Generated at 2022-06-20 16:03:17.620643
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    best_locale = get_best_parsable_locale(module)
    assert best_locale == 'C'
    best_locale = get_best_parsable_locale(module, ['C/C/C'])
    assert best_locale == 'C'



# Generated at 2022-06-20 16:03:22.130148
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    best_locale = get_best_parsable_locale(module, ['C.UTF-8'])
    assert best_locale == 'C'

# Generated at 2022-06-20 16:03:30.760666
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """ Test that we can detect the locale.
        For testing purposes a mock class is created and the
        get_bin_path and run_command methods are mocked out.
        Since the return values depend on the operation system the
        tests are skipped on the OSX operating system.
        """

    import sys
    import unittest
    import re

    from ansible.module_utils.basic import AnsibleModule

    class FakeModule:
        def __init__(self):
            self.exit_json = False
            self.fail_json = False
            self.params = {}
            self.language = None

        def exit_json(self, changed=False, **kwargs):
            """ public API: return from the module, without error """
            self.exit_json = True


# Generated at 2022-06-20 16:03:41.557126
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.utils.vars import merge_hash

    from ansible.module_utils.basic import AnsibleModule
    from ansible.compat.tests.mock import patch, Mock, MagicMock

    class FakeModule(object):
        def __init__(self, check_rc=True):
            self.params = {}
            self.check_rc = check_rc
            self.fail_json = self.run_command = Mock()
            self.fail_json.side_effect = Exception

        def get_bin_path(self, arg, req=True, opt=True):
            if arg == 'locale':
                return '/bin/locale'
            else:
                return None


# Generated at 2022-06-20 16:03:47.541201
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Check that it returns the first locale in the preferences.
    preferences = ['en_US.utf8', 'en_US.US-ASCII']
    assert get_best_parsable_locale(AnsibleModule(), preferences) == preferences[0]

    # Check that it returns 'C' if no locale has been installed.
    preferences = ['en_US.utf8', 'en_US.US-ASCII']
    assert get_best_parsable_locale(AnsibleModule(), preferences, raise_on_locale=True) == 'C'

# Generated at 2022-06-20 16:03:55.447935
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_values = ['C', 'C.utf8', 'POSIX']
    available_locales = ['C.utf8', 'POSIX', 'en_US.utf8', 'en_US.utf-8']
    assert get_best_parsable_locale(locale_values, available_locales) == 'C.utf8'
    assert get_best_parsable_locale(locale_values[:2], available_locales[:2]) == 'C.utf8'
    assert get_best_parsable_locale(locale_values[:1], available_locales[:1]) == 'C'
    assert get_best_parsable_locale(locale_values[:3], available_locales[:3]) == 'C.utf8'
    assert get_best_p

# Generated at 2022-06-20 16:04:05.129976
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    # Test 1
    # Test with right env set and with no preferred locale
    env_bkp = dict(os.environ)
    os.environ['LANG'] = 'en_US.utf8'
    assert 'en_US.utf8' == get_best_parsable_locale(module)
    os.environ = env_bkp

    # Test 2
    # Test with right env set and with preference to 'C' locale
    env_bkp = dict(os.environ)
    os.environ['LANG'] = 'en_US.utf8'
    assert 'C' == get

# Generated at 2022-06-20 16:04:16.431580
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # unit test for get_best_parsable_locale with mock stdout
    # if locale find "C" then it is not mocks that are used
    import errno
    import unittest
    import ansible.module_utils
    from ansible.module_utils import basic

    null = open('/dev/null', 'w')
    sys = __import__('sys')
    sys.stdout = null
    sys.stderr = null
    module_mock = basic.AnsibleModule(argument_spec={})
    module_mock.run_command = lambda *args, **kwargs: ('', ('C','POSIX','en_US.utf8','en_US','en_US.utf8','fr_FR.utf8'), '')
    assert module_mock.get_best_parsable_loc

# Generated at 2022-06-20 16:04:20.081062
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """ Test the get_best_parsable_locale() function """
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(mod, preferences=['en_US.utf8', 'C'])
    assert to_native(locale) == 'C' or to_native(locale) == 'en_US.utf8'
    locale = get_best_parsable_locale(mod, preferences=['de_DE.utf8', 'C'])
    assert to_native(locale) == 'C'
    locale = get_best_parsable_locale(mod)
    assert to_native(locale) == 'C' or to_native(locale) == 'POSIX'