

# Generated at 2022-06-20 15:54:35.645627
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale = get_best_parsable_locale(None)
    assert locale == 'C'
    locale = get_best_parsable_locale(None, preferences=['C.utf8', 'C', 'POSIX'])
    assert locale == 'C'
    locale = get_best_parsable_locale(None, preferences=['en_US.utf8', 'C.utf8', 'C', 'POSIX'])
    assert locale == 'en_US.utf8'
    locale = get_best_parsable_locale(None, preferences=['en_US.utf8', 'C', 'POSIX', 'C.utf8'])
    assert locale == 'en_US.utf8'

# Generated at 2022-06-20 15:54:46.649787
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Stub for an AnsibleModule instances
    class AnsibleModule:
        def get_bin_path(self, path):
            return path
        def run_command(self, command):
            return (0, 'C\nen_US.utf8', '')

    # First, without providing any preferences, tests the default
    assert get_best_parsable_locale(AnsibleModule()) == 'C'

    # Second, with a list of preferences, tests the first match
    assert get_best_parsable_locale(AnsibleModule(), ['en_US.utf8', 'en_UK.utf8']) == 'en_US.utf8'

    # Third, with a list of preferences but no match, tests the default

# Generated at 2022-06-20 15:54:54.630867
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic  import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['en_US.utf8']) == 'C'
    assert get_best_parsable_locale(module, ['junk']) == 'C'
    assert get_best_parsable_locale(module, ['junk', 'C']) == 'C'
    assert get_best_parsable_locale(module, ['C', 'junk']) == 'C'

# Generated at 2022-06-20 15:55:06.641240
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        mock out module.run_command, module.get_bin_path, and module.fail_json
        for the function get_best_parsable_locale()
    '''
    from ansible import constants as C

    import json
    from ansible.module_utils.common._collections_compat import MutableMapping

    if C.DEFAULT_MODULE_LANG is None:
        C.DEFAULT_MODULE_LANG = 'C'
    if C.DEFAULT_MODULE_LOCALE is None:
        C.DEFAULT_MODULE_LOCALE = 'C'

    # set default locale to test
    default_locale = 'en_US.utf8'

    # create class that represents an AnsibleModule instance

# Generated at 2022-06-20 15:55:17.945725
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    running_locale = os.environ.get('LC_ALL', 'C')
    if running_locale == 'C' or running_locale == 'POSIX':
        running_locale = 'C'
        unittest.skip("No need to do unnecessary work!")
        return
    rc, out, err = module.run_command(["locale", "-a"])
    if rc != 0:
        unittest.skip("Unable to get locale information, rc=%s: %s" % (rc, to_native(err)))
        return
    available = []
    if out:
        available = out.strip().splitlines()
    else:
        unittest.skip("No output from locale, rc=%s: %s" % (rc, to_native(err)))
        return
    assert running_

# Generated at 2022-06-20 15:55:25.331139
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class ModuleTest(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_rc = None

        def get_bin_path(self, name):
            return name

        def run_command(self, args, check_rc=False):
            self.run_command_called = True
            self.run_command_rc = [0, "Found", ""]
            return self.run_command_rc

    module = ModuleTest()

    prefs = None
    raise_on_locale = None

    assert get_best_parsable_locale(module, prefs, raise_on_locale) == 'C'

    prefs = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

# Generated at 2022-06-20 15:55:33.805223
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    module = AnsibleModule(
        argument_spec={},
    )

    # Test get_best_parsable_locale
    try:
        from ansible.parsing.dataloader import DataLoader
        C = get_best_parsable_locale(module)
        loader = DataLoader()
        LANGUAGE = loader.get_basedir()
        assert C == 'C'  # can't test on non-Linux systems
    except Exception:
        # LANGUAGE isn't set and module._load_params is inaccessible, so can't test on non-Linux systems
        pass

# Generated at 2022-06-20 15:55:38.448630
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
    )

    best_locale = get_best_parsable_locale(module)
    assert best_locale in ['C', 'POSIX']

# Generated at 2022-06-20 15:55:46.074496
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Test all good locales set
    best_locale = get_best_parsable_locale(module)
    assert best_locale == 'C'

    # Test locale not found
    module.run_command = lambda cmd: (1, '', 'locale: not found')
    try:
        best_locale = get_best_parsable_locale(module)
    except RuntimeWarning:
        pass
    else:
        assert False, "Exception was not raised"

    # Test locale found but no output
    module.run_command = lambda cmd: (0, '', '')

# Generated at 2022-06-20 15:55:55.774879
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    #
    # Test no 'locale' command
    #
    fake_module = AnsibleModule(argument_spec={})
    fake_module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(fake_module) == 'C'

    #
    # Test 'locale' is able to run
    #
    fake_module = AnsibleModule(argument_spec={})
    fake_module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(fake_module) == 'C'

    #
    # Test 'locale' output is set of languages
    #
    fake_module = AnsibleModule(argument_spec={})
    fake

# Generated at 2022-06-20 15:56:08.291865
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''Take the mock module and check that we get the expected output'''
    import sys
    sys.path.append('/usr/lib/python3.6/site-packages/ansible-2.9.7-py3.6.egg')
    from ansible.module_utils.basic import AnsibleModule
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    raise_on_locale = False
    module = AnsibleModule(
        argument_spec = dict(
        )
    )
    output = get_best_parsable_locale(module, preferences, raise_on_locale)
    print(output)


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-20 15:56:19.756021
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test that we return the best locale we can find in the list of preferences
    assert get_best_parsable_locale(None, ['pt_BR', 'C']) == 'C'
    assert get_best_parsable_locale(None, ['pt_BR', 'C', 'POSIX']) == 'POSIX'
    assert get_best_parsable_locale(None, ['pt_BR', 'POSIX']) == 'POSIX'
    assert get_best_parsable_locale(None, ['pt_BR', 'en_US']) == 'en_US'
    assert get_best_parsable_locale(None, ['pt_BR', 'C.utf8']) == 'C.utf8'

    # Test that we default to C if no suitable locale is found
    assert get_

# Generated at 2022-06-20 15:56:25.289877
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'



# Generated at 2022-06-20 15:56:33.530017
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    fn = get_best_parsable_locale

    # The following line raises a warning since 'locale' is not available in PATH
    assert fn(dict(get_bin_path=lambda _: None)) == 'C'
    assert fn(dict(get_bin_path=lambda _: None), raise_on_locale=True)

    # Test for valid 'locale -a' output
    assert fn(dict(get_bin_path=lambda _: '/bin/locale',
                   run_command=lambda *args, **kwargs: (0, 'C\nC.UTF-8\nen_US.UTF-8', None))) == 'C'

    # If a preferred locale is available, it should be returned

# Generated at 2022-06-20 15:56:43.885223
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec={})
    locale_list = mod.run_command([mod.get_bin_path("locale"), '-a'])[1].strip().splitlines()
    assert len(locale_list) > 0
    assert get_best_parsable_locale(mod, raise_on_locale=False) in locale_list
    assert get_best_parsable_locale(mod, raise_on_locale=False, preferences=locale_list) in locale_list
    # Test that get_best_parsable_locale can't find a locale not in the list

# Generated at 2022-06-20 15:56:50.252500
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    fake_module = AnsibleModule(argument_spec={})
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(module=fake_module) == 'C'
    fake_module.run_command = lambda x: (0, '\n'.join(['C', 'C.utf8']), None)  # returns 2 lines representing available locales
    assert get_best_parsable_locale(module=fake_module) == 'C'
    fake_module.run_command = lambda x: (0, '\n'.join(['C', 'C.utf8', 'POSIX']), None)  # returns 3 lines representing available locales

# Generated at 2022-06-20 15:57:01.679912
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Create ansible module object for unit test
    am = AnsibleModule(argument_spec=dict())
    am.get_bin_path = lambda x: x

    # This dict maps locale_out to the expected return of locale found

# Generated at 2022-06-20 15:57:10.201809
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path

    # setup test scenario
    # scenario 1: 'locale' tool not available
    # scenario 2: 'locale' tool available but no output
    # scenario 3: 'locale' tool available but no valid language
    # scenario 4: 'locale' tool available and valid language found

    module = AnsibleModule(argument_spec={})
    module.get_bin_path = get_bin_path

    # scenario 1: 'locale' tool not available
    test_fail = False
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
    except Exception:
        test_fail = True

    assert test_fail == True

    # scenario

# Generated at 2022-06-20 15:57:20.339297
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    if sys.version_info[0] >= 3:
        from unittest import mock
    else:
        import mock

    # mock class of AnsibleModule
    class MockAnsibleModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, location):
            return os.path.join(os.path.dirname(__file__), 'mock_bin', location)


# Generated at 2022-06-20 15:57:25.256913
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['foo']) == 'C'
    assert get_best_parsable_locale(module, preferences=['nonsense']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C', 'nonsense']) == 'C'



# Generated at 2022-06-20 15:57:41.908341
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test to see if the best locales are returned.
    '''
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import pytest

    # for now just a basic test to see if the locale is returned
    # and an exception is raised if it is not found.


# Generated at 2022-06-20 15:57:50.091190
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins

    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule, get_exception
    import ansible.module_utils.basic

    # Redirect stderr
    stderr = sys.stderr
    sys.stderr = StringIO()

    # Mock get_bin_path so that locale command is found
    def fake_get_bin_path(module, cmd):
        return '/usr/bin/locale'
    ansible.module_utils.common.process.get_bin_path = fake_get_bin_path

    # Mock the run_command function from AnsibleModule

# Generated at 2022-06-20 15:57:51.895061
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' == get_best_parsable_locale(None)

# Generated at 2022-06-20 15:58:01.009663
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    test = AnsibleModule(argument_spec={}, supports_check_mode=False)
    assert test.get_best_parsable_locale() == 'C'

    test = AnsibleModule(argument_spec={}, supports_check_mode=False)
    test._ansible_version = b'2.9.0.dev0\n'
    assert test.get_best_parsable_locale() == 'C'

    test = AnsibleModule(argument_spec={}, supports_check_mode=False)
    test._ansible_version = b'2.9.0.dev0\n'

# Generated at 2022-06-20 15:58:11.024151
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    m = ansible.module_utils.basic.AnsibleModule(argument_spec={})

    # Test 1: Output from locale -a includes all elements from preferences list
    locale = 'C.utf8'
    preferences = ['POSIX', 'C.utf8', 'en_US.utf8', 'C']
    module = MockModule(['locale', '-a'], rc=0, out=locale)
    assert(get_best_parsable_locale(module, preferences) == locale)

    # Test 2: Output from locale -a includes some elements from preferences list
    locale = 'en_US.utf8'
    preferences = ['POSIX', 'C.utf8', 'en_US.utf8', 'C']

# Generated at 2022-06-20 15:58:23.368541
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({'run_command': 'noop'})
    locale = get_best_parsable_locale(module)
    assert locale == 'C', 'Expected locale "C" but found "%s"' % locale

    module = AnsibleModule({'run_command': ['locale', '-a']})
    # Override mocked run_command
    module.run_command = lambda x: (0, '\n'.join(['C', 'C.UTF-8',
                                                  'en_US.UTF-8', 'POSIX']), None)
    import types

# Generated at 2022-06-20 15:58:31.181265
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import os
    import pytest

    # Create a mock module
    class MockModule:
        def __init__(self):
            self.params = None
            self.syslog_facility = None
            self.supports_check_mode = False
            self.run_command_environ_update = dict(os.environ)

        def exit_json(self, *args, **kwargs):
            pass

        def fail_json(self, *args, **kwargs):
            pass


# Generated at 2022-06-20 15:58:35.988507
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Import needed module functions
    from ansible.module_utils.basic import AnsibleModule

    module_args = {}
    module = AnsibleModule(argument_spec=module_args)
    # Test getting best parsable locale
    assert get_best_parsable_locale(module, raise_on_locale=False) == 'C'

# Generated at 2022-06-20 15:58:42.721140
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # non-existing module just to test the function
    class AnsibleModuleStub:
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, path):
            if self.bin_path == 'not found':
                raise RuntimeWarning("Could not find 'locale' tool")
        def run_command(self, command):
            self.command = command
            return (0, '', '')

    # create module and test for default locale
    module = AnsibleModuleStub('found')
    assert get_best_parsable_locale(module) == 'C'

    # test command execution
    assert module.command == [module.bin_path, '-a']

    # test response to RuntimeWarning
    module.bin_path = 'not found'

# Generated at 2022-06-20 15:58:48.578509
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(argument_spec={}, supports_check_mode=True)

    assert get_best_parsable_locale(m) == 'C'

# Generated at 2022-06-20 15:59:05.311756
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        from ansible_collections.ansible.community.plugins.module_utils.basic import AnsibleModule
    except ImportError:
        from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import namedtuple
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path_or_none

    class FakeModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(FakeModule, self).__init__(*args, **kwargs)
            self.run_command = self._run_command
            self.run_command_environ_update = {}
            self.debug = False
            self.fail_json

# Generated at 2022-06-20 15:59:16.228500
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import mock
    mock_module = mock.Mock()
    mock_module.run_command.return_value = (0, 'C.utf8\nen_US.utf8\nC\nPOSIX', '')

    try:
        assert get_best_parsable_locale(mock_module, raise_on_locale=True) == 'C.utf8'
    except RuntimeWarning:
        assert False

    mock_module = mock.Mock()
    mock_module.run_command.return_value = (0, '', '')
    try:
        assert get_best_parsable_locale(mock_module, raise_on_locale=True) == 'C'
    except RuntimeWarning:
        assert False

    mock_module = mock.Mock()
    mock_module.run_

# Generated at 2022-06-20 15:59:22.802714
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        bypass_checks=True
    )

    result = get_best_parsable_locale(module)
    assert result in ['C', 'POSIX', 'C.utf8', 'en_US.utf8']

# Generated at 2022-06-20 15:59:33.020621
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import pytest

    module = AnsibleModule(
        argument_spec=dict()
    )

    # when none of the preferences are available, should return 'C'
    # NOTE: below is the entire available/usable locale output on some system
    # NOTE: (fr_FR.utf8 is not available on all systems, so we don't test that)
    locale_list_str = b'C\nen_US.utf8\nPOSIX\n'
    rc = 0
    assert get_best_parsable_locale(module, preferences=None) == 'C'

# Generated at 2022-06-20 15:59:41.003475
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    import pytest
    from six import PY3

    if PY3:
        dict_iter_func = 'dict_values'
    else:
        dict_iter_func = 'dict_itervalues'

    # Test Case:
    # Case 1: All is well and it returns the first preferred one
    m_run_command_p = Mock(return_value=(0, 'C.UTF-8\nC\nen_US.UTF-8\nen_US\nen_US.ISO-8859-1', ''))

# Generated at 2022-06-20 15:59:52.713067
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule()

    # get_bin_path is mocked cause locale was not found, which is fine
    try:
        get_best_parsable_locale(module)
        assert False, "Should have raise an exception"
    except RuntimeWarning:
        pass

    from units.mock.procenv import ModuleTestCase, IsADirectoryError, ENOENT
    from ansible.module_utils.basic import AnsibleModule

    class TestGetBestLocale(ModuleTestCase):
        def test_missing_locale(self):
            module = self.get_module_mock()

            # Mock get_bin_path so that it returns None
            self.mock_module.get_bin_path = self.get_p
            self.mock_module.run_command = self.get_run_command_m

# Generated at 2022-06-20 16:00:03.208523
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['fr_FR.UTF8', 'en_US.utf8', 'POSIX']
    # first preference should be the best
    best = get_best_parsable_locale(preferences=preferences)
    assert best == 'fr_FR.UTF8'

    preferences = ['fr_FR.UTF8', 'en_US.utf8', 'POSIX']
    # second preference should be the best if first is not present
    best = get_best_parsable_locale(preferences=preferences)
    assert best == 'fr_FR.UTF8'

    preferences = ['fr_FR.UTF8', 'en_US.utf8', 'POSIX']
    # first preference and second preference are not present so posix should be the best

# Generated at 2022-06-20 16:00:11.217053
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['C.utf8']) == 'C.utf8'

    assert get_best_parsable_locale(None, ['non_existing.utf8']) == 'C'

    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8']) == 'C.utf8'

    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8', 'C']) == 'C.utf8'

    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'

# Generated at 2022-06-20 16:00:23.022752
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import platform
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import b

    # Build a mock module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    class MockModule(object):
        def __init__(self, module):
            self.run_command_values = []
            self.run_command_rc = None
            self.run_command_out = None
            self.run_command_err = None
            self.module = module

        def init(self, values=None, rc=0, out=b('C'), err=None):
            self.run_command_values = values
            self.run_command_rc = rc
            self.run_command_out = out

# Generated at 2022-06-20 16:00:33.232656
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # import to stub out AnsibleModule so we can run this without erroring
    from ansible.modules.system.setup import AnsibleModule

    # import to import function being tested
    from ansible.module_utils.common.localization import get_best_parsable_locale

    import sys

    # create an instance of AnsibleModule without any arguments
    am = AnsibleModule(argument_spec=dict())

    # create a return code, stdout and stderr that mock failure
    rc = 1
    out = None
    err = 'test'

    # run the function being tested with the mocked return code, stdout and stderr
    # to cause it to raise an exception

# Generated at 2022-06-20 16:00:51.561322
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-20 16:00:59.182014
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import mock

    class FakeModule:
        def __init__(self):
            self.params = {}
            self.exit_json = None
            self.fail_json = None

        def get_bin_path(self, path, required=False, opt_dirs=[]):
            return '/usr/bin/locale'

        def run_command(self, args, check_rc=True):
            if path == '/usr/bin/locale':
                return 0, "C.utf8\nen_US.utf8\nPOSIX\n", None

        def fail_json(self, *args, **kwargs):
            return False

    class FakeArgs:
        def __init__(self):
            self.connection = None
            self.check = None
            self._ansible_debug = None

    fake

# Generated at 2022-06-20 16:01:05.971243
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = None
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    raise_on_locale = False
    print(get_best_parsable_locale(module, preferences, raise_on_locale))
    print(get_best_parsable_locale(module, None, raise_on_locale))

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-20 16:01:15.525600
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(required=True, type='raw'),
        ),
        supports_check_mode=True
    )

    assert 'POSIX' == get_best_parsable_locale(module, preferences='POSIX')
    assert 'C' == get_best_parsable_locale(module, preferences='en_US.utf8')
    assert 'POSIX' == get_best_parsable_locale(module, preferences=['POSIX', 'en_US.utf8'])
    assert 'C' == get_best_parsable_locale(module, preferences=['en_US.utf8', 'POSIX'])
    assert 'C' == get_best_parsable

# Generated at 2022-06-20 16:01:22.155787
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('C') == 'C'
    assert get_best_parsable_locale('C.utf8') == 'C.utf8'
    assert get_best_parsable_locale(['C']) == 'C'
    assert get_best_parsable_locale(['C.utf8', 'asdf']) == 'C.utf8'
    assert get_best_parsable_locale(['asdf', 'C.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(['asdf', 'qwer']) == 'C'
    assert get_best_parsable_locale(['asdf', 'qwer', 'C']) == 'C'

# Generated at 2022-06-20 16:01:23.781753
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['C.utf8']) == 'C.utf8'

# Generated at 2022-06-20 16:01:34.417963
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils
    module = ansible.module_utils.basic.AnsibleModule(
    )
    classModule = dict()
    classModule['run_command'] = lambda self, command: (0, "C POSIX en_US.UTF-8", '')
    classModule['get_bin_path'] = lambda self, command: '/usr/bin/locale'
    module.__class__ = type(ansible.module_utils.basic.AnsibleModule)(ansible.module_utils.basic.AnsibleModule.__name__, ansible.module_utils.basic.AnsibleModule.__bases__, classModule)  # pylint: disable=no-member

    returnedLocale = get_best_parsable_locale(module)
    assert(returnedLocale == 'C')

# Generated at 2022-06-20 16:01:35.597273
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale({}) == 'C'

# Generated at 2022-06-20 16:01:46.518928
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    test_locales = ['en_US.utf8', 'C']
    assert module.get_best_parsable_locale(test_locales) == 'en_US.utf8'

    test_locales = ['blah_US.utf8', 'C']
    assert module.get_best_parsable_locale(test_locales) == 'C'

    test_locales = ['blah_US.utf8', 'C', 'blah2_US.utf8']
    assert module.get_best_parsable_locale(test_locales) == 'C'

# Generated at 2022-06-20 16:01:54.092006
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self, locale_bin, locale_list_output, locale_list_rc=0, locale_list_err=None):
            self.bin_path_dirs = (locale_bin,)
            self.argv = None
            self.locale_list_output = locale_list_output
            self.locale_list_rc = locale_list_rc
            self.locale_list_err = locale_list_err
            self.exit_args = None
            self.fail_json_args = None
            self.warnings = []


# Generated at 2022-06-20 16:02:11.633013
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import common_koji

    module = common_koji.AnsibleModule(
        argument_spec=dict()
    )
    assert get_best_parsable_locale(module).startswith('en')

# Generated at 2022-06-20 16:02:21.419178
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = MockAnsibleModule()
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    # Test case 1: find C.utf8 in available locales
    rc = 0
    out = 'C.utf8\nen_US.utf8\nC\nPOSIX\nfoo\nbar'
    module.run_command.return_value = (rc, out, '')
    result = get_best_parsable_locale(module, preferences, raise_on_locale=True)
    assert result == 'C.utf8'

    # Test case 2: find en_US.utf8 in available locales
    rc = 0
    out = 'en_US.utf8\nC\nPOSIX\nfoo\nbar'

# Generated at 2022-06-20 16:02:29.973704
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = {},
        supports_check_mode = False
    )

    assert get_best_parsable_locale(module) == 'C'

    module.run_command = lambda *args, **kwargs: (0, 'a_good_locale\nC', '')
    assert get_best_parsable_locale(module) == 'a_good_locale'

    module.run_command = lambda *args, **kwargs: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-20 16:02:43.700401
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    mock_module = AnsibleModule(
        argument_spec={'preferences': dict(type='list', default=None),
                       'raise_on_locale': dict(type='bool', default=False)}
    )

    # Test with no exceptions
    mock_module.get_bin_path = lambda x: 'locale'
    mock_module.run_command = lambda x: (0, 'POSIX\nen_US.utf8\nC.utf8\nC\n', '')
    assert get_best_parsable_locale(mock_module) == 'POSIX'

    # Test with empty locale output
    mock_module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale

# Generated at 2022-06-20 16:02:53.270806
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class AnsibleModuleMock:
        @staticmethod
        def get_bin_path(binary):
            # we define only these two, the rest is not important for our case
            if binary == 'locale':
                return 'locale'
            elif binary == 'ansible_test':
                # that's us
                return 'ansible_test'

    class TestPurePosix(unittest.TestCase):
        ''' Test cases for this method when locale is not available '''

        def setUp(self):
            # setup mock for get_bin_path
            AnsibleModuleMock.get_bin_path = self.get_bin_path

# Generated at 2022-06-20 16:03:04.176930
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # mocker fixture needs to be imported like this here
    # otherwise the test fails with: ValueError: Namespace 'mocker' already imported from
    # https://github.com/pytest-dev/pytest-mock/issues/29#issuecomment-374843674
    try:
        from mocker import Mocker
    except ImportError:
        try:
            from unittest.mock import Mock as Mocker
        except ImportError:
            from mock import Mock as Mocker

    mocker = Mocker()

    mock_module = mocker.patch('ansible.module_utils.basic.AnsibleModule')
    mock_module.get_bin_path = mocker.Mock(return_value='/bin/locale')

# Generated at 2022-06-20 16:03:13.044848
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    import os

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.run_command = lambda cmd, environ_update=None, check_rc=True: (0, '', '')
    module.get_bin_path = get_bin_path

    module.run_command = lambda cmd, environ_update=None, check_rc=True: (0, 'C.utf8\nen_US.utf8', '')
    locale = get_best_parsable_locale(module)
    assert locale == 'C.utf8'


# Generated at 2022-06-20 16:03:23.346275
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Check that we don't raise an exception when raise_on_locale is False
    locale = get_best_parsable_locale(module, ['en_US.utf8'], False)
    assert locale == 'C'

    # Check that we raise an exception when raise_on_locale is True
    try:
        locale = get_best_parsable_locale(module, ['en_US.utf8'], True)
    except RuntimeError:
        pass
    else:
        pytest.fail("get_best_parsable_locale does not raise the expected exception when locale is not found and raise_on_locale is True")

# Generated at 2022-06-20 16:03:32.082481
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8', 'C']) == 'C'
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-20 16:03:41.129263
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class FakeModule(object):
        def __init__(self):
            return

        def get_bin_path(self, *args, **kwargs):
            return None

        def run_command(self, *args, **kwargs):
            out = '''C
C.UTF-8
C.utf8
de_DE.utf8
POSIX
en_US.utf8
'''
            return 0, out, None

    assert get_best_parsable_locale(FakeModule(), ['C.utf8', 'de_DE.utf8', 'POSIX'], raise_on_locale=True) == 'C.utf8'

# Generated at 2022-06-20 16:04:05.131029
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic as basic
    from ansible.module_utils.common._collections_compat import Mapping


# Generated at 2022-06-20 16:04:16.376702
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import sys
    import os
    import tempfile
    import shutil
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean

    def run_module(args, fail_json=False, **kwargs):
        # args is an array of strings.  We want to convert it to an array of bytes
        # since that's the format we will use within the module.
        args = [to_bytes(a, encoding='utf-8') for a in args]
        # kwargs are passed through to the module.
        # This function is called from get_bin_path.
        # Since we don't have access to the module object, we pass this function as a kwarg,
        # so that our module can

# Generated at 2022-06-20 16:04:17.950700
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={}
    )

    locale = get_best_parsable_locale(module)
    assert locale == 'C'

# Generated at 2022-06-20 16:04:23.083891
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec=dict())

    preferences = ['ANSI_X3.4-1968', 'C', 'POSIX', 'en_US.utf8', 'C.utf8']
    best_locale = get_best_parsable_locale(module)
    assert best_locale in preferences, "Result: %s, Expected: %s" % (best_locale, preferences)

