

# Generated at 2022-06-20 15:54:33.921502
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class MockModule(object):
        @staticmethod
        def get_bin_path(binary):
            return '/usr/bin/locale'

        @staticmethod
        def run_command(command):
            return (0, '', '')

    assert get_best_parsable_locale(MockModule()) == 'C'

    # test a custom preference
    assert get_best_parsable_locale(MockModule(), ['C']) == 'C'

    # Let's test for a match
    class MockModuleMatch(object):
        @staticmethod
        def get_bin_path(binary):
            return '/usr/bin/locale'

        @staticmethod
        def run_command(command):
            return (0, 'C\nen_US.utf8\nPOSIX\n', '')


# Generated at 2022-06-20 15:54:44.944483
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    def run_command(*args, **kwargs):
        return 0, ''' C
                      C.UTF-8
                      en_US.utf8
                      POSIX''', ''

    class FakeModule:
        def get_bin_path(self, *args, **kwargs):
            return 'locale'

        def run_command(self, *args, **kwargs):
            return run_command(*args, **kwargs)

    module = FakeModule()

    # Test default preferences
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test that the first available preferred locale is returned
    assert get_best_parsable_locale(module, ['POSIX']) == 'POSIX'

# Generated at 2022-06-20 15:54:48.511771
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    m_module = MockAnsibleModule()
    try:
        assert m_module.get_bin_path('locale') is not None
    except RuntimeWarning:
        pass
    assert get_best_parsable_locale(m_module) == 'C'



# Generated at 2022-06-20 15:54:58.232186
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import json
    import unittest
    from ansible.module_utils import basic
    import ansible.module_utils.shell as shell

    # If the system does not have /usr/bin/locale, we will raise an exception
    # and fail the test.
    if not shell.which('locale'):
        raise unittest.SkipTest("Skipping test since no locale available on the system")

    class TestModule(object):

        def __init__(self):
            self.fail_json = fail_json

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd):
            return shell.run_command(cmd)


# Generated at 2022-06-20 15:55:09.347102
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path
    module = get_bin_path

    preferences = None
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module, preferences) == 'C'

    preferences = None
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (0, 'en_US.utf8\nC\nPOSIX\n', '')
    assert get_best_parsable_locale(module, preferences) == 'en_US.utf8'

    preferences = None
    module.get_bin_path

# Generated at 2022-06-20 15:55:16.913592
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    locale_found = get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=False)
    assert locale_found == 'C', "get_best_parsable_locale returned %s, but 'C' expected" % locale_found

# Generated at 2022-06-20 15:55:24.712851
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import mock
    from ansible.module_utils._text import to_text

    class TestModule(object):
        pass

    class ModuleTest(unittest.TestCase):
        @mock.patch.object(TestModule, 'get_bin_path')
        @mock.patch.object(TestModule, 'run_command')
        def test_get_best_parsable_locale_success(self, mock_run_command, mock_get_bin_path):
            mock_get_bin_path.return_value = 'locale'

# Generated at 2022-06-20 15:55:33.572440
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # preferably "C.utf8"
    module.run_command = lambda cmd, check_rc=True: (0, 'C.utf8\nen_US.utf8\n', '')
    assert get_best_parsable_locale(module) == "C.utf8"

    # alternatively "en_US.utf8"

# Generated at 2022-06-20 15:55:41.552472
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_available = [
        'C',
        'C.utf8',
        'en_US.utf8',
        'POSIX'
    ]
    locale_not_available = [
        'de_DE.utf8',
        'es_ES.utf8'
    ]

    assert get_best_parsable_locale(locale_available) == 'C.utf8'
    assert get_best_parsable_locale(locale_not_available) == 'C'

# Generated at 2022-06-20 15:55:43.753888
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
    )

    assert "C" == get_best_parsable_locale(module)

# Generated at 2022-06-20 15:55:56.918359
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class MockModule(object):
        def __init__(self, locale_bin):
            self.locale_bin = locale_bin

        def get_bin_path(self, name, required=False, opt_dirs=None):
            ret_val = None
            if name == "locale":
                ret_val = self.locale_bin
            return ret_val

        def run_command(self, args, check_rc=True, close_fds=True):
            rc = 0
            if args[0] != self.locale_bin:
                rc = 1
            return rc, None, None

    locale_bin = "/usr/bin/locale"

    module = MockModule(locale_bin)

    preferences = None
    raise_on_locale = False
    ret = get_best_parsable

# Generated at 2022-06-20 15:56:05.688379
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preference = ['de_DE.utf8', 'C.utf8', 'C', 'POSIX']
    locales = ['C', 'C.UTF-8', 'de_DE.utf8', 'POSIX']
    expected = 'de_DE.utf8'
    best = get_best_parsable_locale(None, preference, False)
    assert best == expected
    best = get_best_parsable_locale(None, preference, False)
    assert best == expected
    preference = ['de_DE.utf8', 'C.utf8', 'C', 'POSIX']
    locales = ['C', 'C.UTF-8', 'POSIX']
    expected = 'C'
    best = get_best_parsable_locale(None, preference, False)
    assert best == expected

# Generated at 2022-06-20 15:56:17.148822
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # No locale present on the system.
    file_mock = {
        'run_command.return_value': (1, None, None)
    }
    assert get_best_parsable_locale(file_mock) == 'C'

    # Locale tool exists, but no locales are return.
    file_mock = {
        'run_command.return_value': (0, None, None)
    }

    assert get_best_parsable_locale(file_mock) == 'C'

    # Locale tool exists, but no locales are return.
    file_mock = {
        'run_command.return_value': (0, 'a_US.utf8', None)
    }


# Generated at 2022-06-20 15:56:24.572158
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible import constants as C

    from ansible.module_utils.basic import AnsibleModule, get_exception

    m = AnsibleModule(argument_spec={})

    # test the default preference list
    try:
        assert m.get_best_parsable_locale() == 'C'
    except Exception:
        raise

    # test a user defined preference list
    try:
        assert m.get_best_parsable_locale(preferences=['C', 'POSIX', 'C.utf8', 'en_US.utf8']) == 'C'
    except Exception:
        raise

    # test the -a flag to locale is not found

# Generated at 2022-06-20 15:56:34.577068
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import collections

    class FakeModule(object):
        """ Fake module for AnsibleModule """

        def __init__(self):
            self.params = collections.defaultdict(dict)
            self.NO_LOCALES_FOUND = "No Locales Found"

        def run_command(self, cmd, check_rc=None):
            """ Fake run_command method

            :param cmd: arguments to be passed to a command
            :param check_rc: not used in this fake
            :returns: a tuple of (rc, stdout, stderr)
            """

            # sample command: ['/usr/bin/locale', '-a']
            # sample out: ['C', 'C.utf8', 'en_US.utf8', 'POSIX']

# Generated at 2022-06-20 15:56:43.222799
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeModule(object):
        def get_bin_path(self, tool):
            return tool

        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None,
                        data=None, binary_data=False, path_prefix=None, cwd=None,
                        use_unsafe_shell=False, prompt_regex=None):
            results = {
                "locale -a": (0,
                              "\n"
                              "C\n"
                              "C.UTF-8\n"
                              "en_US.utf8\n"
                              "POSIX",
                              ""),
                "locale -a": (1, '', 'Command failed'),
                "locale -a": (0, '', '')
            }
            return results

# Generated at 2022-06-20 15:56:45.110812
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    assert get_best_parsable_locale(AnsibleModule({})) == 'C'

# Generated at 2022-06-20 15:56:57.342612
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = ModuleMock('ansible.module_utils.basic.environment')
    module.params = dict(locale='C.UTF-8')
    # returning the default posix, its ascii but always there
    assert get_best_parsable_locale(module) == 'C'

    # return the preferred locale
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(module, preferences) == 'C.utf8'

    module.run_command.return_value = (1, '', '')
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
    except RuntimeWarning:
        pass

# Generated at 2022-06-20 15:57:07.638130
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.collections import ImmutableDict

    from ansible.module_utils.basic import AnsibleModule

    def test_wrapper(mock_get_bin_path, mock_run_command):
        test_args = {"preferences": ["FOO"],
                     "raise_on_locale": True}

        test_result = {"rc": 0,
                       "out": "C.utf8\nen_US.utf8\nC\nPOSIX",
                       "err": ""}

        def mock_run_command_func(args):
            if args == ['locale', '-a']:
                return test_result.get("rc"), test_result.get("out"), test_result.get("err")
            return 1, "", ""


# Generated at 2022-06-20 15:57:18.576101
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Change directory to test directory so that get_bin_path works
    import os
    test_dir = os.path.dirname(__file__)
    os.chdir(test_dir)

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    # Verify 'C' returned when local not found
    assert module.get_best_parsable_locale() == 'C'

    # Set locale to a particular locale
    os.environ['LC_ALL'] = 'en_US.utf8'
    assert module.get_best_parsable_locale() == 'en_US.utf8'


if __name__ == '__main__':
    import pytest
    pytest.main(['-xrs', __file__])

# Generated at 2022-06-20 15:57:31.225160
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.utils.sunos import get_best_parsable_locale
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    # Get the first preferred locale
    best = get_best_parsable_locale(module)
    assert best == 'C'

    # Get the first preferred locale, second in the list.
    best = get_best_parsable_locale(module, ['foo', 'C'])
    assert best == 'C'

# Generated at 2022-06-20 15:57:43.190327
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Note:
    # get_bin_path() not mocked as it can only return a string or None
    # run_command() not mocked out as it can only return a tuple of strings and int
    # get_bin_path() and run_command() are tested as they are called in
    # unit tests for module_utils.basic.AnsibleModule

    class FakeModule():
        def get_bin_path(self, binary):
            return binary

        def run_command(self, cmd):
            # Command with no output
            if cmd == ['locale', '-a'] and cmp(preferences, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 0:
                return 0, '', ''
            # Command with available locales

# Generated at 2022-06-20 15:57:49.466405
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module_input = dict(
        locale_cmd='/usr/bin/locale',
        locale_paths=['/usr/share/locale/', '/usr/lib/locale']
    )
    module_args = dict(
        ANSIBLE_MODULE_ARGS=module_input
    )

    am = AnsibleModule(
        argument_spec=module_input,
        supports_check_mode=False
    )

    assert get_best_parsable_locale(am, raise_on_locale=True) == 'C.utf8'

# Generated at 2022-06-20 15:57:59.617735
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == "C"

    # test a few in English
    assert get_best_parsable_locale(None, ['en_AU.utf8', 'en_US.utf8']) == "en_US.utf8"
    assert get_best_parsable_locale(None, ['en_GB.utf8', 'en_US.utf8']) == "en_US.utf8"
    assert get_best_parsable_locale(None, ['en_GB.utf8', 'en_CA.utf8']) == "en_CA.utf8"
    assert get_best_parsable_locale(None, ['en_CA.utf8', 'en_GB.utf8']) == "en_CA.utf8"

    # test

# Generated at 2022-06-20 15:58:02.124772
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert get_best_parsable_locale() == 'C'

# Generated at 2022-06-20 15:58:11.606740
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule({}, {}, skip_conditional=True)

    assert "C" == get_best_parsable_locale(mod)

    assert "C" == get_best_parsable_locale(mod, preferences=["ja_JP.utf8"])

    assert "C" == get_best_parsable_locale(mod, preferences=["ja_JP.utf8"], raise_on_locale=True)

    assert "C.utf8" == get_best_parsable_locale(mod, preferences=["C.utf8"])

    assert "POSIX" == get_best_parsable_locale(mod, preferences=["POSIX"])

    assert "C" == get_best_parsable_locale

# Generated at 2022-06-20 15:58:24.206258
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-20 15:58:31.214253
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module_mock = ansible.module_utils.basic.AnsibleModule(argument_spec={})

    # default test (POSIX)
    assert 'C' == get_best_parsable_locale(module_mock)

    # empty preferences test (POSIX)
    assert 'C' == get_best_parsable_locale(module_mock, [])

    # default test (English)
    assert 'en_US.utf8' == get_best_parsable_locale(module_mock, ['en_US.utf8'])

    # default test (POSIX)
    assert 'C' == get_best_parsable_locale(module_mock, ['fr_FR.utf8', 'en_US.utf8'])

   

# Generated at 2022-06-20 15:58:41.408987
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic as basic
    module = basic.AnsibleModule(argument_spec={})

    # Default values return C
    assert 'C' == get_best_parsable_locale(module)

    # Returns preference that exists
    prefs = ['C', 'en_US.utf8', 'POSIX']
    assert 'en_US.utf8' == get_best_parsable_locale(module, preferences=prefs)

    # Return first preference that exists
    prefs = ['POSIX', 'de_DE.utf8', 'C']
    assert 'POSIX' == get_best_parsable_locale(module, preferences=prefs)

    # Returns the first preference that exists
    prefs = ['zh_CN.utf8', 'de_DE.utf8', 'C']

# Generated at 2022-06-20 15:58:48.784069
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import mock

    class TestGetBestParsableLocale(unittest.TestCase):
        def setUp(self):
            self.mock_module = mock.Mock()
            self.mock_module.run_command = mock.Mock()


# Generated at 2022-06-20 15:59:05.700897
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule()
    module.no_log_values.update(dict(PYTHONUNBUFFERED='1'))

    # No locale, default locale - test that it returns "C"
    module.run_command = lambda cmd: (0, '', '')

    assert get_best_parsable_locale(module) == 'C'

    # We have a locale, default locale - test that it returns "C"
    module.run_command = lambda cmd: (0, 'C', '')

    assert get_best_parsable_locale(module) == 'C'

    # We don't have a locale,

# Generated at 2022-06-20 15:59:09.566532
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-20 15:59:21.541832
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # locale is not installed, raise warning
    locale = None
    available = []
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    try:
        get_best_parsable_locale(locale, preferences)
    except RuntimeWarning:
        pass
    else:
        assert False, "Expected RuntimeWarning"

    # no output from locale, raise warning
    out = ""
    err = ""
    try:
        get_best_parsable_locale(locale, preferences, out, err)
    except RuntimeWarning:
        pass
    else:
        assert False, "Expected RuntimeWarning"

    # unable to get locale information, raise warning
    out = None
    err = "Some error"

# Generated at 2022-06-20 15:59:31.516729
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # write mock output
    f = open('locale.out', 'w')
    f.write('C\n'
            'fr_FR\n'
            'fr_FR.utf8\n'
            'POSIX\n')
    f.close()

    assert get_best_parsable_locale('test', ['POSIX']) == 'POSIX'

    assert get_best_parsable_locale('test', ['fr_FR.utf8']) == 'fr_FR.utf8'

    assert get_best_parsable_locale('test', ['fr_FR.utf8', 'POSIX']) == 'fr_FR.utf8'

    assert get_best_parsable_locale('test', ['POSIX', 'fr_FR.utf8']) == 'POSIX'


# Generated at 2022-06-20 15:59:35.250756
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})

    preferences = ['C.utf8', 'en_US.utf8', 'POSIX']
    assert get_best_parsable_locale(module, preferences=preferences) in preferences

# Generated at 2022-06-20 15:59:41.817595
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})

    # Assert 'C'
    assert get_best_parsable_locale(module) == 'C'

    preferences = ['POSIX', 'C']
    # Assert 'POSIX'
    assert get_best_parsable_locale(module, preferences) == 'POSIX'

    # Assert 'C'
    assert get_best_parsable_locale(module, ['POSIXX', 'C']) == 'C'

# Generated at 2022-06-20 15:59:52.757847
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Test that get_best_parsable_locale returns the first match in the preferred locales
    """

    # Create an ansible module instance to test.
    # We're using the module_utils/shell.py module because it has the required
    # module.run_command function.
    class AnsibleModule(object):
        def __init__(self):
            self.params = dict()

        def get_bin_path(self, cmd):
            return cmd

        @staticmethod
        def run_command(args):
            return (0, '\n'.join(args[2:]), "")

    module = AnsibleModule()

    # Test with a list of preferred locales

# Generated at 2022-06-20 15:59:58.295414
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(m) == 'C'

    assert get_best_parsable_locale(m, ['en_US'], raise_on_locale=True) == 'C'

# Generated at 2022-06-20 16:00:06.379757
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import six

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            # If this is python 3 and we are on a mac, then mac will return
            # /System/Library/Frameworks/Python.framework/Versions/3.5/bin/pip3
            # instead of /usr/bin/pip3
            # for this reason, we have to check this
            if sys.version_info[0] == 3 and six.PY3:
                if name == 'pip3':
                    return '/usr/bin/pip3'

            return name


# Generated at 2022-06-20 16:00:15.308311
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    import ansible.utils.display as display
    import ansible.module_utils.basic as basic
    import tempfile

    display.VERBOSITY = 4
    display.COLORIZE = False


# Generated at 2022-06-20 16:00:39.129798
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import to_bytes
    import json

    class TestAnsibleModule(AnsibleModule):
        def __init__(self):
            self.params = {}
            self.result = {}
            self.msg = ''

        def fail_json(self, **kwargs):
            self.result.update(kwargs)

        def run_command(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False):
            self.result.update(dict(rc=0, out='C\nen_US.utf8\nUTF-8', err=''))

    test_module = TestAnsibleModule()
    assert test_module.get

# Generated at 2022-06-20 16:00:48.758973
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Unit test mocking imports
    from ansible.module_utils import basic
    import os

    # Function's get_best_parsable_locale() parameters
    include_preferences = ['C', 'POSIX', 'en_US.utf8']
    exclude_preferences = ['C.utf8']

    # Function calls
    param_include_preferences = get_best_parsable_locale(basic.AnsibleModule(argument_spec={}), include_preferences)
    param_exclude_preferences = get_best_parsable_locale(basic.AnsibleModule(argument_spec={}), exclude_preferences)
    no_param_preferences = get_best_parsable_locale(basic.AnsibleModule(argument_spec={}))
    param_

# Generated at 2022-06-20 16:00:56.852326
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    from ansible.module_utils.basic import ModuleTestCase
    from ansible.module_utils._text import to_bytes

    class TestCase(ModuleTestCase):

        def test_get_best_parsable_locale(self):
            module = AnsibleModule(
                argument_spec=dict()
            )
            locale = basic.get_best_parsable_locale(module)
            self.assertIn(to_bytes(locale), [b'C', b'POSIX', b'en_US.utf8', b'C.utf8'])

# Generated at 2022-06-20 16:01:07.876701
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    module.run_command = run_command_mock
    assert get_best_parsable_locale(module) == 'C'

    module.run_command = run_command_mock2
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    module.run_command = run_command_mock2
    assert get_best_parsable_locale(module, ['POSIX', 'de_DE.utf8', 'nl_NL.utf8', 'C.utf8']) == 'POSIX'

    module.run_command = run_command_mock2

# Generated at 2022-06-20 16:01:17.169451
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.compat.tests.mock import MagicMock

    # Module results
    rc = 0

# Generated at 2022-06-20 16:01:23.512096
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Unitest for get_best_parsable_locale
    '''

    from ansible.module_utils.common._collections_compat import Mapping

    class FakeAnsibleModule():
        '''
        Fake ansible module used to test get_best_parsable_locale
        '''
        def __init__(self, config=None):
            self.params = config
            self.fail_json = None

        def get_bin_path(self, command):
            if command is 'locale':
                return command

        def run_command(self, command):
            if command[1] == '-a':
                return 0, 'en_US', ''
            if command[1] == '-k':
                return 0, 'foo', ''

# Generated at 2022-06-20 16:01:34.212880
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.removed import removed_module
    with removed_module():
        from ansible.module_utils.basic import AnsibleModule
        module = AnsibleModule(
            argument_spec=dict(
                preferences=dict(type='list', required=False)
            )
        )
        assert get_best_parsable_locale(module) == 'C'

        module.params['preferences'] = ['C']
        assert get_best_parsable_locale(module) == 'C'

        module.params['preferences'] = ['POSIX']
        assert get_best_parsable_locale(module) == 'C'

        module.params['preferences'] = ['en_US.UTF-8']

# Generated at 2022-06-20 16:01:41.293160
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'test_locale': dict(type='str', required=True)})

    try:
        locale = get_best_parsable_locale(module)
        if locale != 'C':
            module.fail_json(msg='locale set to {0} expected to be C'.format(locale))
    except RuntimeWarning:
        module.fail_json(msg='Cannot find or run locale')

    try:
        locale = get_best_parsable_locale(module, ['C.utf8', 'C'])
        if locale != 'C':
            module.fail_json(msg='locale set to {0} expected to be C'.format(locale))
    except RuntimeWarning:
        module.fail

# Generated at 2022-06-20 16:01:50.517452
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # List of tuples (preferences, found)
    tests = [
        (None, 'C'),
        (['utf8', 'UTF-8'], 'C'),
        (['utf8', 'UTF-8', 'C.utf8'], 'C.utf8'),
        (['utf8', 'UTF-8', 'C.UTF-8'], 'C'),
        (['en_US.utf8', 'en_US.UTF-8'], 'en_US.utf8'),
        (['en_US.utf8', 'en_US.UTF-8', 'en_US'], 'en_US'),
    ]

    for test in tests:
        yield get_best_parsable_locale, None, test[0], test[1]

# Generated at 2022-06-20 16:01:56.543627
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Run tests against ansible_run_module and return the exit status
    and output for the same
    :return: exit_status and output
    :rtype: (bool, str)
    """
    from ansible.module_utils.common.text.converters import to_bytes

    ARGUMENT_SPEC = dict(
        locale=dict(type='list', default=None, elements='str'),
        raise_on_locale=dict(required=False, type='bool', default=False),
    )


# Generated at 2022-06-20 16:02:35.687472
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock ansible module
    mock_module = MockAnsibleModule()
    mock_run_command = MockRunCommand()

    # Test if no error.
    mock_run_command.rc = 0
    mock_run_command.stdout = 'C.UTF-8\nen_US.utf8\nen_US.utf-8\nen_US\nen_US.utf8\nen_US.UTF-8'
    mock_module.run_command.return_value = (mock_run_command.rc, mock_run_command.stdout, mock_run_command.stderr)
    assert get_best_parsable_locale(mock_module) == 'en_US.utf8', 'Failed to get the best locale'

    # Test if return default locale.
    mock_run_command.rc

# Generated at 2022-06-20 16:02:45.950903
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import cStringIO as StringIO

    module = AnsibleModule(
        argument_spec={},
        stdin_add_newline=False,
        common_warn_filters=[
            'always', 'never', 'module_stderr', 'module_stdout', 'rc', 'stderr', 'stdout'
        ],
    )
    # default locale
    assert get_best_parsable_locale(module) == 'C'
    # check that it raises when requested
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
    except RuntimeWarning:
        pass

# Generated at 2022-06-20 16:02:54.899228
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec={})

    # Test best Locale matching (default preference)
    # Mock the module.run_command function to return mocked data
    def mock_run_command(command, environ_update=None, data=None, binary_data=False):
        # Return something compatible with module.run_command
        rc = 0
        out = ('C\n'
               'C.utf8\n'
               'POSIX\n' )
        err = ''
        return rc, out, err

    module.run_command = mock_run_command
    assert 'C.utf8' == get_best_parsable_locale(module)

    # Test best Locale matching (POSIX preference)
    # Mock the module.run_command function to return mocked data

# Generated at 2022-06-20 16:03:06.028667
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale
    module = AnsibleModule(argument_spec={})
    module.warn = lambda msg: True


# Generated at 2022-06-20 16:03:13.068349
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['C']) == 'C'
    assert get_best_parsable_locale(None, ['C.utf8']) == 'C'
    assert get_best_parsable_locale(None, ['POSIX']) == 'C'
    assert get_best_parsable_locale(None, ['fr_FR.utf8']) == 'C'
    assert get_best_parsable_locale(None, ['en_US.utf8']) == 'C'
    assert get_best_parsable_locale(None, ['fr_FR.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-20 16:03:23.648381
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={}
    )

    # test empty preferences
    assert get_best_parsable_locale(module, preferences=None) == 'C'

    # test preferences not available
    assert get_best_parsable_locale(module, preferences=['xx_YY.utf8', 'xx_YY']) == 'C'

    # test available preferences
    module.run_command = lambda command: (0, 'C\nen_US.utf8\nen_US\nxx_YY\nen_US.utf8')
    assert get_best_parsable_locale(module, preferences=['xx_YY.utf8', 'xx_YY']) == 'en_US.utf8'

# Generated at 2022-06-20 16:03:36.710623
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # test 1: "locale" command is not present
    m = MockAnsibleModule('none')
    m.get_bin_path = Mock(return_value=None)
    assert get_best_parsable_locale(m) == 'C'
    assert 'Could not find' in m.warnings

    # test 2: "locale" command is present but no output
    m = MockAnsibleModule('none')
    m.get_bin_path = Mock(return_value='/usr/bin/locale')
    m.run_command = Mock(return_value=(0, None, 'Error'))
    assert get_best_parsable_locale(m) == 'C'
    assert 'No output' in m.warnings

    # test 3: "locale" command is present but returns an error

# Generated at 2022-06-20 16:03:42.829060
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule(argument_spec={})

    # test if it returns a string or raises an exception
    assert isinstance(get_best_parsable_locale(test_module, ['blah']), str)
    assert isinstance(get_best_parsable_locale(test_module, raise_on_locale=True), str)

# Generated at 2022-06-20 16:03:54.771447
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ## This test actually does a lot more than just test get_best_parsable_locale,
    ## (it actually tests locale -a and getting bin path) but I don't want
    ## to make a new class just for this one function...
    ## If you want to test this function, search for "## test"
    from ansible import _ansible_posix as posix
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict()
    )

    ##################################################################
    # We try to get the actual value of the ansible_locale_lang
    # fact and then return a locale that matches it. If this fails
    # then we fall back to a default locale.
    ##################################################################

# Generated at 2022-06-20 16:04:04.151343
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.compat import IS_PY3

    # Create a test module
    module = AnsibleModule(argument_spec=dict())

    if IS_PY3:
        preferences = ['C.UTF-8', 'en_US.utf8', 'C', 'POSIX']
        defaults = ['C.UTF-8', 'en_US.UTF-8']
    else:
        preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
        defaults = ['en_US.utf8']

    # Default test case (expecting one of the defaults)