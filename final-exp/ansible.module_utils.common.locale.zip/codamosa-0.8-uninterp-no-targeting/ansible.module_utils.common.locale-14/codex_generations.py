

# Generated at 2022-06-20 15:54:38.938530
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class MockModule(object):
        bin_path_cache = {}

        def _check_list(self, cmd, value):
            '''
                Ensures that the cmd attribute contains the value
            '''
            if not isinstance(cmd, list):
                return False

            if not value:
                return False

            if value not in cmd:
                return False

            return True

        def get_bin_path(self, name, required=False):
            '''
                Ensures that get_bin_path has the correct name and required parameter
                Returns /usr/bin/locale
            '''
            parameters = self.bin_path_cache.get(name, None)

            if not parameters:
                return None

            if not self._check_list(parameters, required):
                return None


# Generated at 2022-06-20 15:54:49.432156
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test inputs
    test_preferences = ['POSIX','C', 'C.utf8', 'en_US.utf8']
    test_preferences_empty = []
    test_preferences_none = None

    # Test expected outputs
    test_expected = 'C'
    test_expected_empty = 'POSIX'
    test_expected_none = 'POSIX'
    test_expected_locale_error = 'POSIX'

    # Test actual outputs are equal to expected outputs for various preferences
    assert get_best_parsable_locale(test_preferences) == test_expected
    assert get_best_parsable_locale(test_preferences_empty) == test_expected_empty
    assert get_best_parsable_locale(test_preferences_none) == test_

# Generated at 2022-06-20 15:54:55.465660
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = None # Can't create a mock module here
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    raise_on_locale = False

    locale_info = get_best_parsable_locale(module, preferences, raise_on_locale)
    print (locale_info)

test_get_best_parsable_locale()

# Generated at 2022-06-20 15:55:07.833880
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule  # only for testing

    module = AnsibleModule(argument_spec={})
    locale_available = ['C', 'C.utf8', 'en_US.utf8', 'POSIX']

    # test preferences - should return 'en_US.utf8'
    prefs = ['en_US.utf8', 'C.utf8']
    best_locale = get_best_parsable_locale(module, preferences=prefs, raise_on_locale=False)
    assert best_locale in locale_available
    assert best_locale == 'en_US.utf8'

    # test no preferences - should return 'C'
    best_locale = get_best_parsable_locale(module, raise_on_locale=False)

# Generated at 2022-06-20 15:55:12.500199
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) is not None
    assert get_best_parsable_locale(None, None) is not None
    assert get_best_parsable_locale(None, [], True) is not None



# Generated at 2022-06-20 15:55:15.815471
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import sys
    import re
    import tempfile
    import io
    import os

    class TestGetBestParsableLocale(unittest.TestCase):

        def setUp(self):
            # working directory has to be present otherwise module exits early
            if not os.path.isdir('/tmp/ansible_test'):
                os.mkdir('/tmp/ansible_test')
            os.chdir('/tmp/ansible_test')

            class Args:
                prefer_unparsable_locale = True

            class AnsibleModule:
                def __init__(self, argument_spec, module_kwargs=None):
                    self.argument_spec = argument_spec
                    self.params = Args


# Generated at 2022-06-20 15:55:17.183717
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-20 15:55:24.881271
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import tempfile
    import shutil
    import sys

    def setup_locale_test(testdir, locales):
        '''Returns the tmpdir
        '''
        if os.path.isdir(testdir):
            shutil.rmtree(testdir)

        os.mkdir(testdir)
        os.mkdir(os.path.join(testdir, 'etc'))
        os.mkdir(os.path.join(testdir, 'usr', 'lib', 'locale'))
        with open(os.path.join(testdir, 'usr', 'lib', 'locale', 'locale-archive'), 'w') as f:
            for l in locales:
                os.mkdir(os.path.join(testdir, 'usr', 'lib', 'locale', l))

# Generated at 2022-06-20 15:55:31.616978
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert get_best_parsable_locale(None, None) == 'C'

    assert get_best_parsable_locale(None, ['A.utf8']) == 'C'

    assert get_best_parsable_locale(None, ['A.utf8', 'C.utf8']) == 'C.utf8'

    tries = ['B.utf8', 'C.utf8', 'POSIX']
    assert get_best_parsable_locale(None, tries) == 'C.utf8'

# Generated at 2022-06-20 15:55:43.110926
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import platform
    import unittest

    try:
        # python2
        from mock import Mock, patch
    except ImportError:
        # python3
        from unittest.mock import Mock, patch

    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {'module_name': 'stat', 'module_arguments': 'path=/etc/hosts'}
            self.fail_json = Mock(return_value=False)

        def get_bin_path(self, name, required=False):
            return name

        def run_command(self, cmd, check_rc=True):
            if not isinstance(cmd, list):
                raise TypeError(cmd)


# Generated at 2022-06-20 15:55:52.200388
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import sys
    ansible_mod = basic.AnsibleModule(
        argument_spec=dict(),
    )
    try:
        locale = get_best_parsable_locale(ansible_mod, None, True)
    except:
        assert False, 'Test succeed'
    assert True

# Generated at 2022-06-20 15:56:02.875638
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    class TestModule(object):
        def __init__(self, out):
            self.out = out

        @classmethod
        def fail_json(self, **kwargs):
            pass

        def get_bin_path(self, tool, **kwargs):
            return '/bin/%s' % tool

        def run_command(self, command, **kwargs):
            if command[1] == '-a':
                return 0, self.out, ''
            else:
                return 0, 'C', ''

    # Test no output from locale command
    module = TestModule(to_bytes(''))

# Generated at 2022-06-20 15:56:12.190636
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import sys
    import os
    import shutil
    import tempfile
    import subprocess
    import ansible.module_utils.basic as basic

    class TestUtilsLocale(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.module = basic.AnsibleModule(argument_spec=dict(), check_invalid_arguments=False)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        @staticmethod
        def _mk_fake_locale(locale, code):
            os.mkdir(os.path.join(locale, 'LC_MESSAGES'))

# Generated at 2022-06-20 15:56:22.280746
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def _fake_run_command(args):
        # Fake command that returns the first two args as the output.
        return (0, ' '.join(args[1:]), None)

    # If a suitable locale is found, the first preferred value which is found will be returned.
    module = AnsibleModule(run_command=_fake_run_command)
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule(run_command=_fake_run_command)
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'C', 'POSIX']) == 'C'

    module = AnsibleModule(run_command=_fake_run_command)
    assert get_best_

# Generated at 2022-06-20 15:56:23.491506
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    #  test code here
    pass



# Generated at 2022-06-20 15:56:32.723696
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import ansible.module_utils.basic as basic
    import ansible.module_utils.common.ansible_module_common as amc
    import locale

    module = amc.AnsibleModuleCommon(
        argument_spec=dict(),
    )

    # noop 'locale' command to see if it matches expected behavior
    module.run_command = lambda x: ('C.utf8', '', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # check against system locale
    module.run_command = lambda x: (locale.setlocale(locale.LC_ALL), '', '')
    assert get_best_parsable_locale(module) == locale.getlocale()[0]

    # check default 'posix' if locale command fails


# Generated at 2022-06-20 15:56:35.367313
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule()
    mod.config={'debug':True}
    assert "C" == get_best_parsable_locale(mod)

# Generated at 2022-06-20 15:56:43.795148
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping

    locale_tool_path = None
    locale_output = 'C'
    locale_error = None
    locale_output_win = '1046'
    locale_error_win = None
    locale_win_broken = 'en_US.utf8'
    locale_output_mac = '1033'
    locale_error_mac = '1034'
    locale_mac_broken = 'en_US.UTF-8'
    locale_win_broken = 'en_US.utf8'
    pref = None

# Generated at 2022-06-20 15:56:55.368469
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
    )

    class FakeRunCommand(object):
        def __init__(self, results):
            self.results = results
            self.counter = 0

        def __call__(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.counter += 1
            out = self.results[self.counter]
            if self.counter == len(self.results):
                self.counter = 0
            return 0, out, ''

    # without locale installed (locale bin not found)
    module.run_command = FakeRunCommand(results=[])

# Generated at 2022-06-20 15:57:06.196131
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from six import StringIO
    from ansible.module_utils.six import PY3

    MOCK_LOCALE_GOOD = """
C
POSIX
en_US.utf8
C.utf8
"""
    MOCK_LOCALE_BAD = """
C
POSIX
fr_FR.utf8
C.utf8
"""
    MOCK_LOCALE_EMPTY = """
"""

    class MockModule(object):
        def __init__(self):
            self.params = ""
            self.result = dict(changed=False, msg='')

        def fail_json(self, msg):
            self.result['msg'] = msg


# Generated at 2022-06-20 15:57:14.328320
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.collections import ImmutableDict

    test_module = type('TestModule', (), dict(run_command=run_command))

    # Two different tests for different scenarios, could do better with parametrized test
    test_module.check_mode = False
    test_module.get_bin_path = lambda x: '/usr/bin/locale'
    assert get_best_parsable_locale(test_module) == 'C'

    test_module.check_mode = True
    test_module.get_bin_path = lambda x: '/usr/bin/locale'
    assert get_best_parsable_locale(test_module) == 'C'

    test_module.check_mode = False
    test_module.get_bin_path = lambda x: None


# Generated at 2022-06-20 15:57:23.351658
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        A basic unit test for the get_best_parsable_locale function.
        This test runs the function with just about every possible combination
        to ensure success.
    '''

    import unittest
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule

    class MockAnsibleModule(object):
        """Mock class to mimic an ``AnsibleModule``."""


# Generated at 2022-06-20 15:57:29.255254
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    def mock_run_command(module, args, check_rc=True, close_fds=True, executable=None, use_unsafe_shell=False, data=None, binary_data=True, path_prefix=None, cwd=None, encoding=None):
        unicode_err = u"Error '\u8bdd\u53e5'.\n"
        unicode_out = u"English locale is '\u82f1\u8bed'."
        return 0, unicode_out, unicode_err

    test_module = AnsibleModule(
        argument_spec={},
    )
    test_module.run_command = mock_run_command


# Generated at 2022-06-20 15:57:33.500820
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Unit test for function get_best_parsable_locale  
    module = AnsibleModule(argument_spec=dict())
    # assert_equals(get_best_parsable_locale(module, ['en', 'C']), 'C')

# Generated at 2022-06-20 15:57:37.574057
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    # import fake module class
    module = AnsibleModule(argument_spec={})

    locale = get_best_parsable_locale(module)
    assert(locale == 'C')

# Generated at 2022-06-20 15:57:47.688645
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Elsewhere we check if the function is used in a non-Python 3 environment.
    # Here we just assume we are running the tests with Python 3.
    from unittest import mock

    from ansible.module_utils.basic import AnsibleModule

    # First part of the test, we do have a locale binary.
    with mock.patch.object(AnsibleModule, 'get_bin_path', return_value='/usr/bin/locale'):
        # First we check if the function returns the wanted 'C' locale.
        with mock.patch.object(AnsibleModule, 'run_command', return_value=(0, 'C\nen_US.utf8\nen_US\n', '')):
            assert get_best_parsable_locale(AnsibleModule(argument_spec={})) == 'C'


# Generated at 2022-06-20 15:57:58.341862
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    unit tests for get_best_parsable_locale
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch

    fake_module = AnsibleModule(
        argument_spec=dict(),
    )

    # case 1: no module.get_bin_path
    with patch('ansible_collections.ansible.netcommon.plugins.modules.network.nxos.get_best_parsable_locale.AnsibleModule.get_bin_path', return_value=None):
        result = get_best_parsable_locale(fake_module)
        assert result == 'C'

    # case 2: locale binary found, but no output from locale -a
   

# Generated at 2022-06-20 15:58:09.157297
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class MockModule(object):

        def __init__(self):
            self.run_command = []
            self.fail_json = []
            self.params = []

        def get_bin_path(self, name):
            return name

    from ansible.compat.tests import unittest

    class TestGetBestParsableLocale(unittest.TestCase):

        def setUp(self):
            self.mock_module = MockModule()

        def test_default(self):
            self.mock_module.run_command = [(0, 'C\nen_US.utf8\nC.utf8\nen_GB\nen_US', ''), (0, '', '')]
            locale = get_best_parsable_locale(self.mock_module)

# Generated at 2022-06-20 15:58:15.811661
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test that a default is returned when no locales are available
    def mock_run_command_empty(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False):
        return (0, None, None)
    module = type('AnsibleModule', (object,), dict(run_command=mock_run_command_empty))
    result = get_best_parsable_locale(module)
    assert result == 'C', 'Incorrect default locale returned by get_best_parsable_locale'

    # Test that C is returned when C is the only available locale
    def mock_run_command_c(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False):
        return

# Generated at 2022-06-20 15:58:20.208456
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    mod = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    assert get_best_parsable_locale(mod)

# Generated at 2022-06-20 15:58:36.373366
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test to make sure we get the best locale possible
    '''

    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(test_module)

    assert (locale in ['C', 'POSIX'])

# Generated at 2022-06-20 15:58:45.337941
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-20 15:58:47.699748
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    best_locale = get_best_parsable_locale(None,preferences)
    assert best_locale == 'C'

# Generated at 2022-06-20 15:58:55.141210
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module_mock = AnsibleModule(argument_spec={})
    module_mock.get_bin_path = lambda x: "/bin/%s" % x

    # we're not stubbing popen/communicate as we do not want to deal with
    # every possible exception that may be raised.

    # found = 'C' is returned by default, if an exception is raised
    assert get_best_parsable_locale(module_mock) == 'C'

    # found = first matched preferred locale, if no exception is raised
    assert get_best_parsable_locale(module_mock, preferences=['POSIX', 'C']) == 'POSIX'

    # found = default, if raise_on_locale is False and an exception is raised
   

# Generated at 2022-06-20 15:59:05.311551
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    results = {'rc': 0, 'out': 'C\nen_US.utf8\nde_DE.utf8\n'}
    test_module = AnsibleModule(
        argument_spec=dict(preferences=dict(type='list', required=False),
                           raise_on_locale=dict(type='bool', required=False)),
        supports_check_mode=False
    )
    test_module.run_command = lambda args, **kwargs: results
    test_module.get_bin_path = lambda x, **kwargs: x

    locale = get_best_parsable_locale(test_module)
    assert(locale == 'C')


# Generated at 2022-06-20 15:59:16.229545
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert(get_best_parsable_locale(None, ['en_US.utf8', 'en_US.utf8']) == 'en_US.utf8')
    assert(get_best_parsable_locale(None, ['en_US.utf8', 'C']) == 'en_US.utf8')
    assert(get_best_parsable_locale(None, ['C.utf8', 'C']) == 'C.utf8')
    assert(get_best_parsable_locale(None, ['C.utf8', 'POSIX']) == 'C.utf8')
    assert(get_best_parsable_locale(None, ['en_US.utf8', 'POSIX']) == 'en_US.utf8')

# Generated at 2022-06-20 15:59:27.038560
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Unit test for function get_best_parsable_locale
    '''
    # pass
    assert get_best_parsable_locale(raise_on_locale=False) == 'C'
    assert get_best_parsable_locale({'get_bin_path': lambda x: x}, preferences=['C.utf8'], raise_on_locale=False) == 'C.utf8'
    assert get_best_parsable_locale({'get_bin_path': lambda x: x, 'run_command': lambda x: (0, 'C.utf8\nC\nen_US.utf8', '')}, preferences=['C.utf8', 'C', 'en_US.utf8'], raise_on_locale=False) == 'C.utf8'

   

# Generated at 2022-06-20 15:59:31.375607
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert get_best_parsable_locale(None,preferences=['C.utf8'],raise_on_locale=False) == 'C.utf8'

    assert get_best_parsable_locale(None,raise_on_locale=False) == 'C'

# Generated at 2022-06-20 15:59:39.476155
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test with no locale available
    module = AnsibleModule(argument_spec={})
    try:
        locale = get_best_parsable_locale(module)
        assert locale == 'C'
    except RuntimeWarning:
        assert False

    # Test with available locale
    def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        class Result:
            def __init__(self, args, available):
                self.args = args
                self.rc = 0
                self.stdout = '\n'.join(available)
                self.stderr = ''

        available = ['C', 'en_US.utf8']
        return Result(args, available)

    module = AnsibleModule(argument_spec={})
   

# Generated at 2022-06-20 15:59:46.817391
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule, env_fallback
    from ansible.module_utils.common._text import to_bytes

    # setting up parameters needed for AnsibleModule
    module_args = {}

    # demo AnsibleModule that can be used as a library
    # since we don't have access to actual ansible runner, we need to mock the environment variable
    env = {"LC_ALL": "C.utf8"}
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True, bypass_checks=True, check_invalid_arguments=False)
    module.run_command = lambda *args, **kwargs: (0, to_bytes(env["LC_ALL"]), '')

    # test for preferred locale 'C.utf8'
    result = get_best_p

# Generated at 2022-06-20 16:00:16.711495
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert('C' == get_best_parsable_locale(None))

# Generated at 2022-06-20 16:00:25.799278
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest

    class AnsibleModule:
        def __init__(self):
            self.params = None
            self.result = None
            self.fail_json = None
            self.exit_json = None
            self.run_command = None

        def get_bin_path(self, tool):
            if tool == 'locale':
                return '/usr/bin/locale'
            else:
                return None

    class TestLocale(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.module = AnsibleModule()

# Generated at 2022-06-20 16:00:35.096182
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class Args:
        pass

    module = AnsibleModule(
        argument_spec=dict()
    )
    module.params =  Args()
    assert get_best_parsable_locale(module)

    module.params.preference = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(module)

    module.params.preference = ['C', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(module)

    module.params.preference = ['en_US.utf8', 'C.utf8', 'POSIX']

# Generated at 2022-06-20 16:00:40.097767
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Test 1: No module argument provided
    assert get_best_parsable_locale() == 'C'

    # Test 2: Empty locale -a output
    module = AnsibleModule(
        argument_spec={'echo': {'required': False}}
    )
    assert get_best_parsable_locale(module) == 'C'

    # Test 3: Preferred locale is not in output from locale -a
    module = AnsibleModule(
        argument_spec={'echo': {'required': False}}
    )
    assert get_best_parsable_locale(module, preferences=['fr_FR.utf8']) == 'C'

    # Test 4: Preferred locale is in output from locale -a

# Generated at 2022-06-20 16:00:46.712769
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # get_best_parsable_locale()
    assert get_best_parsable_locale(None) == 'C'
    # get_best_parsable_locale(preferences)
    assert get_best_parsable_locale(None, preferences=['C']) == 'C'

# Generated at 2022-06-20 16:00:57.017265
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class TestModule:
        def get_bin_path(m, bin):
            return bin

        def run_command(m, cmd):
            out = ".\n..\nC\nen_US.utf8\nC.utf8\nPOSIX\n.\n..\n"
            if cmd[1] == "-a":
                return 0, out, ""
            elif cmd[1] == "-c":
                return 0, cmd[1], ""
            else:
                return 1, "", "Unable to set locale"

    preferences = ['C.utf8', 'POSIX', 'C', 'en_US.utf8']
    module = TestModule()
    best_locale = get_best_parsable_locale(module, preferences)
    assert best_locale == 'C.utf8'

   

# Generated at 2022-06-20 16:01:03.886238
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    # No locale provided but should not raise exception and
    # default to the POSIX locale
    assert get_best_parsable_locale(module, raise_on_locale=False) == 'C'
    assert get_best_parsable_locale(module, preferences=None, raise_on_locale=False) == 'C'

# Generated at 2022-06-20 16:01:13.772873
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''Test function get_best_parsable_locale'''

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    mod = AnsibleModule(argument_spec={'lang': dict(type='str')})

    # define the inputs and expected outputs

# Generated at 2022-06-20 16:01:20.747208
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(argument_spec={})
    module._debug = False
    module._ansible_debug = False
    module.run_command = lambda x: (0, '\n'.join(['C.UTF-8', 'en_US.UTF-8', 'POSIX']), None)

    # Test that language of the running user is returned
    assert get_best_parsable_locale(module) == 'C.UTF-8'

    # Test that language is returned even when preference list is specified
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C']) == 'POSIX'

    # Test that if no language matches, POSIX is returned

# Generated at 2022-06-20 16:01:26.429845
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

# Generated at 2022-06-20 16:02:06.944964
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    module.run_command = lambda cmd: (
        1,
        '',
        'failed to run locale'
    )
    assert module.get_bin_path('locale')
    # raise_on_locale is False, get_best_parsable_locale should return 'C' if it raises an exception
    assert get_best_parsable_locale(module) == 'C'

    # test preferences
    module.run_command = lambda cmd: (
        0,
        'C.utf8\nen_US.utf8\nC\nPOSIX\n',
        ''
    )
    preferences = ['C']

# Generated at 2022-06-20 16:02:14.864514
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest

    class TestGetBestParsableLocale(unittest.TestCase):
        def test_result(self):
            class MockModule(object):
                def __init__(self):
                    self.rc = 0
                    self.out = """
C
en_US.utf8
posix
C.utf8
"""
                    self.err = ""

                def run_command(self, args):
                    return (self.rc, self.out, self.err)

                def get_bin_path(self, executable):
                    return True

            preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
            test_obj = MockModule()
            actual = get_best_parsable_locale(test_obj, preferences)

# Generated at 2022-06-20 16:02:24.036494
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeModule:
        def __init__(self, locale=None):
            self.locale = locale
            self.out = b''
            self.err = b''

        def run_command(self, cmd):
            self.out, self.err = self.locale()
            return (0, self.out, self.err)

        def get_bin_path(self, path):
            return self.locale

    # test if no locale available
    m = FakeModule(lambda: (b'', b''))
    assert get_best_parsable_locale(m) == 'C', "Should be default locale"

    # test if locale available
    m = FakeModule(lambda: (b'en_US.utf8', b''))

# Generated at 2022-06-20 16:02:34.502248
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import os

    # This unit test is written in simplest form possible to test the function get_best_parsable_locale.
    # This is because AnsibleModule is quite complicated to setup with expected values and stubs and
    # it is easier to write this test in simpler form to test  only the get_best_parsable_locale function
    #
    # When writing unit tests, the get_best_parsable_locale is tested in 2 ways,
    #   1) When 'locale' command is not available, it prints a warning message and returns 'C' as default
    #   2) When 'locale' command is available, it checks for available locale list
    #           (simulated with input_locale_list which can be modified to add/remove locale)
    #           and checks for

# Generated at 2022-06-20 16:02:39.930449
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(object):
        def __init__(self):
            self.fail_json = None

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd):
            if cmd[0] == 'locale' and cmd[1] == '-a':
                if 'C.utf8' in cmd[2]:
                    return (0, 'C.utf8', '')
                elif 'en_US.utf8' in cmd[2]:
                    return (0, 'en_US.utf8', '')
            return (0, '', '')

    module = AnsibleModule()

    module.run_command = FakeModule().run_command
    module.get_bin_path = FakeModule().get_bin

# Generated at 2022-06-20 16:02:49.768364
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import subprocess
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 16:02:57.111910
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible import context
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec={}
    )

    # test preferences are applied correctly
    test_module.run_command = lambda command: (0, '\n'.join(context.CLIARGS['export_preferred_locales']), '')
    assert get_best_parsable_locale(test_module, preferences=context.CLIARGS['export_preferred_locales']) == 'C.utf8'

    # test that preference of 'C.UTF-8' does not match 'C.utf8'
    test_module.run_command = lambda command: (0, '\n'.join(['C.utf8']), '')
    assert get_best_parsable_locale

# Generated at 2022-06-20 16:03:07.259407
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import ansible.module_utils.common.collections as collections
    from ansible.module_utils import basic

    fake_module = collections.namedtuple('fake_module', ('run_command'))

    def run_command(self, cmd, data=None):

        if cmd == ['locale', '-a']:
            out = '''C
C.UTF-8
en_US.utf8
POSIX
'''
            return 0, out, ''
        else:
            raise Exception('Unexpected command: %s' % cmd)

    fake_module.run_command = run_command
    basic.AnsibleModule = fake_module

    assert get_best_parsable_locale(fake_module) == 'en_US.utf8'

# Generated at 2022-06-20 16:03:15.648628
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    :return: True or False if unit test was successful or not
    '''
    import sys
    import random
    import unittest

    class ModuleUtilsI18nTest(unittest.TestCase):
        """
        Unit test for Ansible module_utils.i18n.get_best_parsable_locale function
        """
        class FakeModule(object):
            def __init__(self):
                self.params = {}
                self.fail_json = exit_json = self.exit_json = lambda **kwargs: sys.exit(0)

            def get_bin_path(self, cmd):
                return '/tmp/bin/%s' % cmd


# Generated at 2022-06-20 16:03:18.380916
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    found = get_best_parsable_locale(module)
    assert found == 'C'

# Generated at 2022-06-20 16:03:51.829182
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_module = {}

    try:
        result = get_best_parsable_locale(test_module, ['C'], True)
    except Exception:
        print("Could not find locale executable.")
        return

    assert result == 'C'


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-20 16:04:04.128131
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile

    def create_stub_locale():
        fd, location = tempfile.mkstemp()

# Generated at 2022-06-20 16:04:09.725304
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''
    import ansible.module_utils.basic as basic

    class AnsibleModule:
        '''
            This class handles the get_bin_path call
        '''
        def __init__(self, run_command):
            self.run_command = run_command

        def get_bin_path(self, tool):
            if tool == "locale":
                return "/usr/bin/locale"
            return None


# Generated at 2022-06-20 16:04:23.024317
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Used to test the return values as well as to establish expected values for testing.
    """

    assert get_best_parsable_locale(None) == 'C'

    assert get_best_parsable_locale(None, ['C.UTF-8', 'POSIX', 'en_US.utf8']) == 'C.UTF-8'

    assert get_best_parsable_locale(None, ['POSIX', 'en_US.utf8', 'C']) == 'C'

    assert get_best_parsable_locale(None, ['POSIX', 'en_US.utf8', 'C', 'fr_FR.UTF-8', 'ja_JP.UTF-8']) == 'C'


# Generated at 2022-06-20 16:04:25.819873
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Use the locale provided by the OS
    locale = get_best_parsable_locale(None)
    assert(locale)
    assert(type(locale) == str)