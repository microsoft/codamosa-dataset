

# Generated at 2022-06-16 22:38:04.053122
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:15.751629
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Test with no locale
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\n', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale and preferences
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: '/usr/bin/locale'

# Generated at 2022-06-16 22:38:19.115422
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:22.140144
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:32.714720
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and preferences
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')

# Generated at 2022-06-16 22:38:44.562189
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and preferences
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C']) == 'POSIX'



# Generated at 2022-06-16 22:38:56.076824
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(type='list', default=None),
            raise_on_locale=dict(type='bool', default=False),
        ),
    )

    # Test with no preferences
    assert get_best_parsable_locale(module) == 'C'

    # Test with preferences
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test with raise_on_locale
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

# Generated at 2022-06-16 22:38:58.951089
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:39:10.503475
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale tool
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale tool
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with no locale tool
    module.get_bin_path = lambda x: 'locale'

# Generated at 2022-06-16 22:39:13.918548
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:39:30.555194
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # test that we get the default locale if we don't have any preferences
    assert get_best_parsable_locale(module) == 'C'

    # test that we get the first preference if we have one
    assert get_best_parsable_locale(module, preferences=['C.utf8']) == 'C.utf8'

    # test that we get the first preference if we have multiple
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8']) == 'C.utf8'

    # test that we get the first preference if we have multiple
    assert get_best

# Generated at 2022-06-16 22:39:42.488075
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    # Test that we get the first preferred locale
    os.environ['LC_ALL'] = 'C.UTF-8'
    locale = get_best_parsable_locale(module, preferences=['C.UTF-8', 'en_US.UTF-8'])
    assert locale == 'C.UTF-8'

    # Test that we get the second preferred locale
    os.environ['LC_ALL'] = 'en_US.UTF-8'

# Generated at 2022-06-16 22:39:45.469162
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:39:53.662644
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C', 'POSIX']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'POSIX', 'C'])

# Generated at 2022-06-16 22:40:05.046735
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    module = AnsibleModule(argument_spec={})

    # Test 1: Test with no locale
    os.environ['LC_ALL'] = ''
    assert get_best_parsable_locale(module) == 'C'

    # Test 2: Test with locale
    os.environ['LC_ALL'] = 'en_US.utf8'
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    # Test 3: Test with locale and preferences
    os.environ['LC_ALL'] = 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'])

# Generated at 2022-06-16 22:40:13.659209
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test case 1: locale is not available
    module.run_command = lambda x, **kwargs: (1, '', 'locale: command not found')
    assert get_best_parsable_locale(module) == 'C'

    # Test case 2: locale is available but no output
    module.run_command = lambda x, **kwargs: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test case 3: locale is available but no output
    module.run_command = lambda x, **kwargs: (0, '', '')

# Generated at 2022-06-16 22:40:17.182064
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:20.333517
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:30.758887
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO

    # Create a fake module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    # Create a fake locale command
    class FakeLocale(object):
        def __init__(self, module):
            self.module = module
            self.locale_list = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']


# Generated at 2022-06-16 22:40:39.291984
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    # Create a fake module
    module = AnsibleModule(argument_spec={})

    # Create a fake locale
    fake_locale = os.path.join(os.path.dirname(__file__), 'fake_locale')

    # Test with a fake locale
    module.get_bin_path = lambda x: fake_locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with a fake locale and a fake preference
    module.get_bin_path = lambda x: fake_locale
    assert get_best_parsable_locale(module, preferences=['fake_preference']) == 'C'

    # Test with a fake locale and a fake preference and raise_on_locale
   

# Generated at 2022-06-16 22:41:02.320186
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import tempfile
    import shutil
    import sys
    import unittest

    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, **kwargs):
            raise Exception(kwargs)

        def get_bin_path(self, name):
            return os.path.join(self.params['bin_path'], name)

        def run_command(self, cmd):
            return self.params['run_command'](cmd)

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-16 22:41:06.432097
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:17.502527
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
    )
    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'
    # Test with locale
    module.run_command = lambda x: (0, 'C\nen_US.utf8\n', '')
    assert get_best_parsable_locale(module) == 'C'
    # Test with locale and preferences
    module.run_command = lambda x: (0, 'C\nen_US.utf8\n', '')
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C']) == 'en_US.utf8'
    # Test

# Generated at 2022-06-16 22:41:25.151727
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    if PY3:
        assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'
    else:
        assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test with locale not found

# Generated at 2022-06-16 22:41:36.864694
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    class TestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.run_command_called = False
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''
            self.run_command_command = ''
            self.get_bin_path_called = False
            self.get_bin_path_path = ''
            self.get_bin_path_rc = 0
            self.get_bin_path_path = ''
            self.get_bin_path_path = ''
            self.get_

# Generated at 2022-06-16 22:41:48.875611
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:42:01.149679
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: None

        def run_command(self, cmd):
            if cmd[0] == 'locale':
                return 0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', ''
            else:
                return 1, '', ''

        def get_bin_path(self, cmd):
            return get_bin_path(cmd)

    module = FakeModule()

    assert get_best_parsable_locale(module) == 'C.utf8'
    assert get_best_parsable_

# Generated at 2022-06-16 22:42:05.532108
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:15.998602
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

# Generated at 2022-06-16 22:42:25.627865
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:42:49.391705
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and preferences
    module.get_bin_path = lambda x: '/usr/bin/locale'

# Generated at 2022-06-16 22:43:02.627595
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    # Create a fake module
    module = AnsibleModule(argument_spec={})

    # Test the function with a locale that exists
    assert get_best_parsable_locale(module, preferences=['C']) == 'C'

    # Test the function with a locale that does not exist
    assert get_best_parsable_locale(module, preferences=['foo']) == 'C'

    # Test the function with a locale that exists but is not in the list of preferences
    assert get_best_parsable_locale(module, preferences=['foo']) == 'C'

    # Test the function with a locale that exists but is not in the list of preferences

# Generated at 2022-06-16 22:43:10.738521
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test for default preferences
    assert get_best_parsable_locale(module) == 'C'

    # Test for custom preferences
    assert get_best_parsable_locale(module, preferences=['C', 'POSIX']) == 'C'

    # Test for custom preferences with locale that is not available
    assert get_best_parsable_locale(module, preferences=['C', 'POSIX', 'en_US.utf8']) == 'C'

    # Test for custom preferences with locale that is available
    assert get_best_parsable_locale(module, preferences=['C', 'POSIX', 'en_US.utf8']) == 'C'

    # Test for custom preferences

# Generated at 2022-06-16 22:43:18.043709
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # test with locale
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\n', '')
    assert get_best_parsable_locale(module) == 'C'

    # test with locale and preferences
    module.run_command = lambda x: (0, 'C\nen_US.utf8\n', '')

# Generated at 2022-06-16 22:43:30.582600
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test that we get the default locale when we don't have any preferences
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the default locale when we don't have any preferences
    # and we raise on locale
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

    # Test that we get the first preference when we have preferences
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'

    # Test that we get the first preference when we have preferences
    # and we raise

# Generated at 2022-06-16 22:43:37.823171
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale
    import os

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    os.environ['LC_ALL'] = ''
    os.environ['LANG'] = ''
    os.environ['LANGUAGE'] = ''
    assert get_best_parsable_locale(module) == 'C'

    # Test with a locale that is not available
    os.environ['LC_ALL'] = 'en_US.UTF-8'
    os.environ['LANG'] = 'en_US.UTF-8'
    os.environ['LANGUAGE'] = 'en_US.UTF-8'

# Generated at 2022-06-16 22:43:51.315047
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test for default locale
    assert get_best_parsable_locale(module) == 'C'

    # Test for locale with utf8
    assert get_best_parsable_locale(module, preferences=['C.utf8']) == 'C.utf8'

    # Test for locale with utf8
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'C']) == 'C.utf8'

    # Test for locale with utf8

# Generated at 2022-06-16 22:43:56.152969
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)

    if PY2:
        assert locale == 'C'
    else:
        assert locale == 'C.utf8'

# Generated at 2022-06-16 22:43:59.121908
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:44:01.683266
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:44:33.489892
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:44:43.166493
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Test with no locale
    os.environ['LC_ALL'] = ''
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    os.environ['LC_ALL'] = 'en_US.utf8'
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    # Test with locale and preferences
    os.environ['LC_ALL'] = 'en_US.utf8'

# Generated at 2022-06-16 22:44:51.462922
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX']) == 'C.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'POSIX']) == 'en_US.utf8'

# Generated at 2022-06-16 22:44:55.411457
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:44:59.138020
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:01.892499
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:05.540758
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:09.316919
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test with no locale
    assert get_best_parsable_locale(None) == 'C'

    # Test with locale
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:45:21.226584
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test that we get 'C' locale when locale command is not found
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get 'C' locale when locale command is found but no output
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get 'C' locale when locale command is found but no output
    module.run_command = lambda x: (0, '', '')
    assert get_best_p

# Generated at 2022-06-16 22:45:24.647518
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:46:23.142414
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:46:35.712225
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Test 1: locale not found
    module = AnsibleModule(
        argument_spec=dict(),
    )
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test 2: locale found, but no output
    module = AnsibleModule(
        argument_spec=dict(),
    )
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test 3: locale found, but no output
    module = AnsibleModule(
        argument_spec=dict(),
    )

# Generated at 2022-06-16 22:46:43.497182
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    os.environ['LC_ALL'] = ''
    os.environ['LANG'] = ''
    os.environ['LANGUAGE'] = ''
    assert get_best_parsable_locale(module) == 'C'

    # Test with a locale
    os.environ['LC_ALL'] = 'en_US.utf8'
    os.environ['LANG'] = 'en_US.utf8'
    os.environ['LANGUAGE'] = 'en_US.utf8'
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    # Test with a locale that is not

# Generated at 2022-06-16 22:46:47.177702
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:46:55.555596
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    module = AnsibleModule(argument_spec={})

    # Test with no locale tool
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale tool, but no output
    module.get_bin_path = lambda x: x
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale tool, but no output
    module.get_bin_path = lambda x: x

# Generated at 2022-06-16 22:47:05.010007
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test that the function returns the first preference that is available
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'

    # Test that the function returns the first preference that is available
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8', 'C', 'POSIX']) == 'en_US.utf8'

    # Test that the function returns the first preference that is available

# Generated at 2022-06-16 22:47:11.893611
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    # Create a fake module
    module = AnsibleModule(argument_spec={})

    # Create a fake locale command
    os.environ['PATH'] = os.pathsep.join(['/bin', os.environ['PATH']])
    with open('/bin/locale', 'w') as f:
        f.write('''#!/bin/sh
echo "C.utf8"
echo "en_US.utf8"
echo "C"
echo "POSIX"
''')
    os.chmod('/bin/locale', 0o755)

    # Test with no preferences
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with preferences
    assert get_best_

# Generated at 2022-06-16 22:47:14.921461
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:47:17.695910
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:47:29.355183
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    if PY3:
        assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'
    else:
        assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test with locale and raise_on_locale
    assert get_best_pars