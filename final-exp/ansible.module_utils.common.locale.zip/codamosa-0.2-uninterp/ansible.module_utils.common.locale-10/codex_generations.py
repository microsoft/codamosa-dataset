

# Generated at 2022-06-16 22:38:09.115116
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C', 'C.utf8']) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C', 'C.utf8', 'en_US.utf8']) == 'C'
    assert get_best_parsable_loc

# Generated at 2022-06-16 22:38:21.128292
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    # Test with a list of preferences
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    locale = get_best_parsable_locale(module, preferences)
    assert locale == 'C'

    # Test with a list of preferences and a locale that exists
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    if PY3:
        preferences.append('en_US.UTF-8')

# Generated at 2022-06-16 22:38:31.994148
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    import os

    if PY3:
        from unittest.mock import patch
    else:
        from mock import patch

    def mock_run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='surrogate_then_replace', text=None, data_struct=None, binary_data_size=None):
        if args[0] == 'locale':
            if args[1] == '-a':
                return

# Generated at 2022-06-16 22:38:34.859182
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:40.746650
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C', 'en_US.utf8']) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C', 'en_US.utf8', 'C.utf8']) == 'C'
    assert get_best_parsable

# Generated at 2022-06-16 22:38:43.664573
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:55.595539
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys

    module = AnsibleModule(argument_spec={})

    # Test case 1:
    # Test case where locale is not found
    # Expected result:
    #   C
    #   No exception raised
    try:
        result = get_best_parsable_locale(module)
        assert result == 'C'
    except RuntimeWarning:
        assert False

    # Test case 2:
    # Test case where locale is found
    # Expected result:
    #   C.UTF-8
    #   No exception raised

# Generated at 2022-06-16 22:38:58.094854
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:39:05.426539
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'

    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C.utf8']) == 'POSIX'


# Generated at 2022-06-16 22:39:16.806439
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'POSIX']) == 'C.utf8'
    assert get_best_parsable_locale(module, ['en_US.utf8', 'POSIX']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, ['POSIX']) == 'POSIX'

# Generated at 2022-06-16 22:39:24.536464
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:39:34.464475
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.common.process
    import ansible.module_utils.common.system
    import ansible.module_utils.common.text
    import ansible.module_utils.six
    import ansible.module_utils.six.moves
    import ansible.module_utils.six.moves.urllib
    import ansible.module_utils.six.moves.urllib.error
    import ansible.module_utils.six.moves.urllib.parse
    import ansible.module_utils.six.moves.urllib.request
    import ansible.module_utils.urls
    import ansible.module_utils.urls.__init__
    import ansible.module_utils.urls.basic
    import ansible

# Generated at 2022-06-16 22:39:38.148516
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:39:41.436964
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:39:46.931551
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    module = AnsibleModule(argument_spec={})
    if PY2:
        assert get_best_parsable_locale(module) == 'C'
    else:
        assert get_best_parsable_locale(module) == 'C.utf8'

# Generated at 2022-06-16 22:39:49.605559
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:39:56.588503
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale and raise_on_locale
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'

    # Test with locale and raise_on_locale

# Generated at 2022-06-16 22:40:00.558320
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:10.449228
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test that we get the default locale when no locale is available
    module.run_command = lambda args: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the default locale when no locale is available
    module.run_command = lambda args: (0, '', '')
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test that we get the default locale when no locale is available
    module.run_command = lambda args: (0, '', '')
    assert get_best_pars

# Generated at 2022-06-16 22:40:14.725262
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:31.712377
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:39.761781
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test that we get C locale when locale command is not present
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get C locale when locale command is present but returns an error
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get C locale when locale command is present but returns no output
    module.get_bin_path = lambda x: 'locale'

# Generated at 2022-06-16 22:40:43.432274
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:47.417663
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:57.752653
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.get_bin_path = lambda x: '/usr/bin/locale'

# Generated at 2022-06-16 22:41:04.923929
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale command
    module.run_command = lambda x: (1, '', 'locale command not found')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no output from locale command
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale command output
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_loc

# Generated at 2022-06-16 22:41:08.085482
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:11.439221
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:21.418622
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'

    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'POSIX']) == 'en_US.utf8'


# Generated at 2022-06-16 22:41:33.596317
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile

    # Create a temporary file to hold the output of the locale command
    fd, locale_output_file = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file to hold the output of the locale command
    fd, locale_output_file = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file to hold the output of the locale command
    fd, locale_output_file = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file to hold the output of the locale command
    fd, locale_output_file = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file to hold the output of

# Generated at 2022-06-16 22:41:58.904895
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'

    # Test with locale that does not exist
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX', 'en_US.utf9']) == 'C.utf8'

# Generated at 2022-06-16 22:42:01.643364
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:06.106796
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:17.516553
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:42:19.842549
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:28.337575
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    if PY3:
        assert get_best_parsable_locale(module) == 'C.utf8'
    else:
        assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:31.243976
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:34.636625
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:37.988099
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert module.get_best_parsable_locale() == 'C'

# Generated at 2022-06-16 22:42:48.408571
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys

    # Create a fake module
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.params['_ansible_verbosity'] = 0
            self.params['_ansible_no_log'] = False
            self.params['_ansible_debug'] = False
            self.params['_ansible_diff'] = False
            self.params['_ansible_check_mode'] = False
            self.params['_ansible_remote_tmp'] = None
            self.params['_ansible_keep_remote_files'] = False
            self.params['_ansible_socket'] = None
            self.params['_ansible_selinux_special_fs'] = None
            self

# Generated at 2022-06-16 22:43:08.849071
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

# Generated at 2022-06-16 22:43:12.145349
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:43:18.708309
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.common.process
    import ansible.module_utils.common.shell

    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {}
            self.fail_json = kwargs.get('fail_json', None)
            self.run_command = kwargs.get('run_command', None)
            self.get_bin_path = kwargs.get('get_bin_path', None)

    class FakeAnsibleModule(ansible.module_utils.basic.AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.params = {}
            self.fail_json = kwargs.get('fail_json', None)
           

# Generated at 2022-06-16 22:43:30.964765
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    # Create a fake module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    # Create a fake locale command
    class FakeLocale(object):
        def __init__(self):
            self.stdout = StringIO()
            self.stderr = StringIO()

        def write(self, s):
            self.stdout.write(s)

        def flush(self):
            self.stdout.flush()

        def close(self):
            self.stdout.close()

    # Create a fake module.run_command

# Generated at 2022-06-16 22:43:40.224307
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test with no locale installed
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale installed and raise_on_locale=True
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
    except RuntimeWarning:
        pass
    else:
        assert False, "Expected RuntimeWarning"

    # Test with locale installed
    module.run_command = lambda x: (0, 'C\nen_US.utf8\n', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale installed and raise_on_locale=True

# Generated at 2022-06-16 22:43:52.020960
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test that we get the default locale when no locale is available
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the default locale when no locale is available
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the default locale when no locale is available
    module.run_command = lambda x: (0, '', 'error')
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the default locale when no

# Generated at 2022-06-16 22:44:01.111025
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = None
            self.run_command = None

        def get_bin_path(self, name):
            return name

    # Mock run_command

# Generated at 2022-06-16 22:44:04.595192
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:44:15.677917
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    if PY3:
        assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'
    else:
        assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test with locale that does not exist
    assert get_best_parsable_loc

# Generated at 2022-06-16 22:44:26.271252
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile

    # Create a temporary file for the locale output
    (fd, locale_file) = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file for the locale output
    (fd, locale_file) = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file for the locale output
    (fd, locale_file) = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file for the locale output
    (fd, locale_file) = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file for the locale output
    (fd, locale_file) = tempfile.mkstemp()

# Generated at 2022-06-16 22:44:49.592262
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable

# Generated at 2022-06-16 22:44:59.786083
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test 1: locale not found
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test 2: locale found
    module.run_command = lambda x: (0, 'C.utf8\nen_US.utf8\nC\nPOSIX', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test 3: locale found, but not in the list of preferred locales
    module.run_command = lambda x: (0, 'de_DE.utf8\nC\nPOSIX', '')
    assert get_best_pars

# Generated at 2022-06-16 22:45:03.460237
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:11.992411
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = None
            self.fail_json = None
            self.run_command = None
            self.get_bin_path = None

        def run_command(self, cmd):
            if cmd[1] == '-a':
                return 0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', ''
            else:
                return 0, '', ''

        def get_bin_path(self, cmd):
            return cmd

    module = FakeModule()


# Generated at 2022-06-16 22:45:24.010924
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    module = AnsibleModule(argument_spec={})

    # Test that we get the default locale when locale is not found
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the default locale when locale is not found
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

    # Test that we get the default locale when locale is not found
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C']) == 'C'

    # Test that we get the default locale when locale is not found
    assert get

# Generated at 2022-06-16 22:45:25.364524
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:28.261245
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:30.080545
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:40.187060
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test with no locale tool
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test with no output from locale tool
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale tool
    module.get_bin_path = lambda x: '/usr/bin/locale'

# Generated at 2022-06-16 22:45:51.561576
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO

    # Mock the module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Mock the locale command
    module.run_command = lambda args: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')

    # Test the function
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test the function with a custom preference
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C']) == 'POSIX'

    # Test

# Generated at 2022-06-16 22:46:21.075498
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:46:33.647574
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    class TestModule(object):
        def __init__(self, params):
            self.params = params
            self.fail_json = self.exit_json = self.run_command = self.get_bin_path = None

        def fail_json(self, **kwargs):
            raise Exception(kwargs)

        def exit_json(self, **kwargs):
            return kwargs

        def run_command(self, cmd, check_rc=True):
            if cmd[0] == 'locale':
                if cmd[1] == '-a':
                    return 0, 'C\nC.UTF-8\nPOSIX\n', ''

# Generated at 2022-06-16 22:46:42.252041
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (0, 'C.utf8\nen_US.utf8\nC\nPOSIX', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with no locale

# Generated at 2022-06-16 22:46:52.731997
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'

    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'POSIX']) == 'en_US.utf8'


# Generated at 2022-06-16 22:46:55.335712
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:47:04.785367
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    # Test 1: Test that the function returns the first matched preferred locale
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nPOSIX', '')
    assert get_best_parsable_locale(module, preferences) == 'C.utf8'

    # Test 2: Test that the function returns the default locale if no preferred locale is matched
    preferences = ['C.utf8', 'en_US.utf8', 'POSIX']
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-16 22:47:11.769709
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'

    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'POSIX']) == 'en_US.utf8'


# Generated at 2022-06-16 22:47:14.781911
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:47:25.690601
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    if PY3:
        assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'
    else:
        assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test with locale and raise_on_locale

# Generated at 2022-06-16 22:47:29.191262
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'