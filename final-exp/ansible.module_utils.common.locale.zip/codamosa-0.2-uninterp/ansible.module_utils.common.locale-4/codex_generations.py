

# Generated at 2022-06-16 22:38:06.335305
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:13.574103
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    if PY3:
        return

    module = AnsibleModule(argument_spec={})

    # Test with no locale tool
    module.run_command = lambda x: (1, '', 'No such file or directory')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale tool
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale tool
    module.run_command = lambda x: (0, 'C.utf8\nen_US.utf8\nC\nPOSIX', '')
    assert get_best

# Generated at 2022-06-16 22:38:23.446503
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

# Generated at 2022-06-16 22:38:27.483615
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:35.056451
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale installed
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale installed
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale installed and custom preferences
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable

# Generated at 2022-06-16 22:38:41.107383
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys

    # Create a fake module
    module = AnsibleModule(argument_spec={})

    # Create a fake locale binary
    def fake_locale(args, **kwargs):
        if args[0] == '-a':
            return 0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', ''
        else:
            return 0, '', ''

    # Create a fake module.get_bin_path
    def fake_get_bin_path(name, **kwargs):
        if name == 'locale':
            return os.path.join(os.path.dirname(__file__), 'fake_locale')
        else:
            return None

    # Create a fake module.run_

# Generated at 2022-06-16 22:38:43.778090
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:55.701239
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Test with no locale
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\n', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale and preferences
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: '/usr/bin/locale'

# Generated at 2022-06-16 22:39:06.214803
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Test with no locale
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale and raise_on_locale
    module = AnsibleModule(argument_spec={})
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
    except RuntimeWarning:
        pass
    else:
        assert False

    # Test with locale and no preferences
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: '/usr/bin/locale'

# Generated at 2022-06-16 22:39:17.874320
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and preferences
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')

# Generated at 2022-06-16 22:39:27.456536
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:39:38.466883
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    import os

    # Create a fake module
    module = AnsibleModule(argument_spec={})

    # Create a fake locale
    fake_locale = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'fake_locale')

    # Test that we get the default locale when locale is not found
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the default locale when locale is not found
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

    # Test that we get the default locale when locale is not found

# Generated at 2022-06-16 22:39:48.890589
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
    import ansible.module_utils.basic
   

# Generated at 2022-06-16 22:40:00.945114
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    import os
    import sys

    # Create a fake module
    module = AnsibleModule(argument_spec={})

    # Create a fake locale
    fake_locale = os.path.join(os.path.dirname(__file__), 'fake_locale')

    # Create a fake locale output
    fake_locale_output = 'C\nC.utf8\nen_US.utf8\nPOSIX\n'

    # Set the fake locale as the module's bin path
    module.get_bin_path = lambda x: fake_locale

    # Set the fake locale output as the module's run_command output

# Generated at 2022-06-16 22:40:10.762131
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Test with no locale
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and preferences
    module = AnsibleModule(argument_spec={})
    module.get_bin_

# Generated at 2022-06-16 22:40:22.378275
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    if PY3:
        module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    else:
        module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n'.decode('utf-8'), '')

    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and

# Generated at 2022-06-16 22:40:25.613418
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:32.695428
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale tool
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test with no output
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no preferred locale
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C'

   

# Generated at 2022-06-16 22:40:40.329679
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile

    # Create a temporary file to store the locale output
    (fd, fname) = tempfile.mkstemp()
    os.close(fd)

    # Write the locale output to the temporary file
    with open(fname, 'w') as f:
        f.write("C\nC.UTF-8\nPOSIX\n")

    # Create a temporary module to test the function
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda args: (0, open(fname).read(), '')

    # Test the function
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:44.246274
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:00.838192
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Test 1: locale command is not found
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test 2: locale command is found but no output
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test 3: locale command is found but no output
    module = AnsibleModule(argument_spec={})


# Generated at 2022-06-16 22:41:05.637894
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

# Generated at 2022-06-16 22:41:16.719566
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and preferences
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')

# Generated at 2022-06-16 22:41:24.743658
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test that the default locale is returned
    assert get_best_parsable_locale(module) == 'C'

    # Test that the first preferred locale is returned
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'

    # Test that the last preferred locale is returned
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C']) == 'C'

    # Test that the default locale is returned when the locale command fails
    assert get_best_parsable_locale

# Generated at 2022-06-16 22:41:28.913756
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

# Generated at 2022-06-16 22:41:32.634907
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:35.616431
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:41:37.954344
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:41.405103
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:52.750901
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (0, 'C', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (0, 'C\nen_US.utf8', '')

# Generated at 2022-06-16 22:42:10.014203
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:13.459083
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:22.754262
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    # Test that the function returns the first preferred locale that is available
    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8', 'C', 'POSIX'])
    assert locale == 'en_US.utf8'

    # Test that the function returns the first preferred locale that is available
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-16 22:42:27.445461
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:38.684782
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['foo']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'foo']) == 'C.utf8'
    assert get_best_parsable_locale(module, preferences=['foo', 'C.utf8']) == 'C.utf8'

# Generated at 2022-06-16 22:42:41.933173
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:50.716665
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    if PY3:
        assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'
    else:
        assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test with no locale and raise_on_locale

# Generated at 2022-06-16 22:43:03.122945
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and preferences
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_

# Generated at 2022-06-16 22:43:12.186381
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

# Generated at 2022-06-16 22:43:14.665533
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:43:31.623964
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:43:33.983376
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:43:37.220345
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:43:46.653573
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no preferences
    assert get_best_parsable_locale(module) == 'C'

    # Test with preferences
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:43:56.831474
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.facts.system.locale

    # test case 1: no locale binary
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    module.get_bin_path = lambda x: None
    assert ansible.module_utils.facts.system.locale.get_best_parsable_locale(module) == 'C'

    # test case 2: no locale output
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    module.get_bin_path = lambda x: 'locale'

# Generated at 2022-06-16 22:44:04.229509
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8', 'POSIX', 'C']) == 'C'

# Generated at 2022-06-16 22:44:15.439183
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX']) == 'C.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'POSIX']) == 'en_US.utf8'

# Generated at 2022-06-16 22:44:26.036167
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale and raise_on_locale
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
    except RuntimeWarning:
        pass
    else:
        assert False, "Expected RuntimeWarning"

    # Test with no locale and preferences
    assert get_best_parsable_locale(module, preferences=['C']) == 'C'

    # Test with no locale and preferences and raise_on_locale

# Generated at 2022-06-16 22:44:31.707431
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:44:34.949420
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:44:53.572255
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:00.791090
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Create a fake module
    module = AnsibleModule(argument_spec={})

    # Test for locale CLI issues
    if PY3:
        assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'
    else:
        assert get_best_parsable_locale(module, raise_on_locale=True) == 'C.utf8'

    # Test for locale CLI issues
    assert get_best_parsable_locale(module, raise_on_locale=False) == 'C'

    # Test for locale CLI issues

# Generated at 2022-06-16 22:45:04.535894
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:12.743501
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test 1: locale not found
    module.run_command = lambda x: (1, '', 'locale not found')
    assert get_best_parsable_locale(module) == 'C'

    # Test 2: no output from locale
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test 3: locale found, but no locale in list
    module.run_command = lambda x: (0, 'C.utf8\nen_US.utf8\nC\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C'



# Generated at 2022-06-16 22:45:16.681956
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:22.673926
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    module = AnsibleModule(argument_spec={})

    if PY2:
        assert get_best_parsable_locale(module) == 'C'
    else:
        assert get_best_parsable_locale(module) == 'C.utf8'

# Generated at 2022-06-16 22:45:32.803812
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test that the default locale is returned
    assert get_best_parsable_locale(module) == 'C'

    # Test that a locale in the list is returned
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test that the first locale in the list is returned
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8', 'C', 'POSIX']) == 'en_US.utf8'

    # Test that the first locale in the list is returned
    assert get_best_parsable_

# Generated at 2022-06-16 22:45:35.354452
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:48.642005
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.common.process
    import ansible.module_utils.common.shell
    import ansible.module_utils.local_ansible_utils
    import ansible.module_utils.local_tmp
    import ansible.module_utils.six.moves.builtins
    import ansible.module_utils.six.moves.urllib.parse
    import ansible.module_utils.urls
    import ansible.module_utils.urls.__init__
    import ansible.module_utils.urls.url_argument_spec
    import ansible.module_utils.urls.url_utils
    import ansible.module_utils.urls.urls
    import ansible.module_utils.urls.urllib2

# Generated at 2022-06-16 22:45:59.500700
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import locale

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a locale directory
    os.mkdir(os.path.join(tmpdir, 'locale'))

    # Create a locale file
    with open(os.path.join(tmpdir, 'locale', 'en_US.utf8'), 'w') as f:
        f.write('LC_MESSAGES="en_US.utf8"')

    # Create a locale file
    with open(os.path.join(tmpdir, 'locale', 'C.utf8'), 'w') as f:
        f.write('LC_MESSAGES="C.utf8"')

    # Create a locale file

# Generated at 2022-06-16 22:46:21.842909
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.run_command = lambda x: (0, 'C\nen_US.utf8\n', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.run_command = lambda x: (0, 'C\nen_US.utf8\n', '')
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.utf8'

    #

# Generated at 2022-06-16 22:46:25.262340
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:46:37.064978
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.run_command = lambda x: (0, 'C\nen_US.utf8', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.run_command = lambda x: (0, 'C\nen_US.utf8', '')
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.utf8'

    # Test with locale


# Generated at 2022-06-16 22:46:43.607999
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test with no preferences
    assert get_best_parsable_locale(module) == 'C'

    # Test with preferences
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test with preferences and raise_on_locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

# Generated at 2022-06-16 22:46:45.244957
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:46:48.218031
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:46:57.208703
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test that we get the default locale
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the default locale when we don't have locale
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the default locale when we don't have locale
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the default locale when we don't have locale

# Generated at 2022-06-16 22:47:06.366285
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test 1: Test that the default locale is returned when no locale is available
    assert get_best_parsable_locale(module) == 'C'

    # Test 2: Test that the default locale is returned when an empty list is passed
    assert get_best_parsable_locale(module, []) == 'C'

    # Test 3: Test that the first available locale is returned when a list of locales is passed
    assert get_best_parsable_locale(module, ['en_US.utf8', 'C.utf8', 'C']) == 'en_US.utf8'

    # Test 4: Test that the default locale is returned when the list of locales is not available
    assert get_best

# Generated at 2022-06-16 22:47:15.119281
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale tool
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale tool
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale tool
    module.run_command = lambda x: (0, 'C', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale tool
    module.run_command = lambda x: (0, 'C.utf8', '')

# Generated at 2022-06-16 22:47:17.908075
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:47:48.221163
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:47:50.275124
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:47:52.897720
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:47:55.388726
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

# Generated at 2022-06-16 22:47:58.378070
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'