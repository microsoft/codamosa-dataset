

# Generated at 2022-06-16 22:38:01.708836
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:04.088068
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:15.751586
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    # Test with a locale that exists
    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module, preferences=['C', 'en_US.utf8'])
    assert locale == 'C'

    # Test with a locale that does not exist
    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module, preferences=['en_US.utf8', 'en_US.utf8'])
    assert locale == 'C'

    # Test with a locale that exists
    module = Ans

# Generated at 2022-06-16 22:38:19.067617
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:30.384798
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the first preferred locale in the list
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(module, preferences) == 'C.utf8'

    # Test that we get the first preferred locale in the list
    preferences = ['en_US.utf8', 'C.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(module, preferences) == 'en_US.utf8'

    # Test that we get

# Generated at 2022-06-16 22:38:36.576689
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    # Test with locale

# Generated at 2022-06-16 22:38:42.643669
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    # test with no locale
    assert get_best_parsable_locale(module) == 'C'
    # test with locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:38:54.577044
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'POSIX', 'en_US.utf8', 'C']) == 'C'

# Generated at 2022-06-16 22:39:04.235246
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'POSIX', 'en_US.utf8', 'C']) == 'C'

# Generated at 2022-06-16 22:39:15.890792
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and preferences
    preferences = ['en_US.utf8', 'POSIX']
    assert get_best_parsable_locale(module, preferences) == 'en_US.utf8'

    # Test with locale

# Generated at 2022-06-16 22:39:31.129504
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test that the default locale is C
    assert get_best_parsable_locale(module) == 'C'

    # Test that the default locale is C if the locale command is not found
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test that the default locale is C if the locale command fails
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test that the default locale is C if the locale command returns no output

# Generated at 2022-06-16 22:39:43.159798
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test that we get 'C' when there is no locale binary
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get 'C' when there is no locale output
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get 'C' when there is no locale output
    module.get_bin_path = lambda x: 'locale'
    module

# Generated at 2022-06-16 22:39:46.054707
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:39:47.868800
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:39:59.478846
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    # Test case 1: locale not found
    module = AnsibleModule(
        argument_spec=dict(),
    )
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test case 2: locale found, but no output
    module = AnsibleModule(
        argument_spec=dict(),
    )
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test case 3: locale found, but no output
    module

# Generated at 2022-06-16 22:40:09.589251
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale installed
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale installed
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale installed
    module.run_command = lambda x: (0, 'C\nen_US.utf8', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale installed

# Generated at 2022-06-16 22:40:11.981006
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:15.112828
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:18.549977
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test case 1:
    # Test case with no preferences
    # Expected result:
    # The first matched preferred locale or 'C' which is the default
    assert get_best_parsable_locale(None) == 'C'

    # Test case 2:
    # Test case with preferences
    # Expected result:
    # The first matched preferred locale or 'C' which is the default
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:40:22.202126
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)
    if PY3:
        assert locale == 'C.UTF-8'
    else:
        assert locale == 'C'

# Generated at 2022-06-16 22:40:40.538372
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and preferences
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX', '')

# Generated at 2022-06-16 22:40:51.336246
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test for default preferences
    assert get_best_parsable_locale(module) == 'C'

    # Test for custom preferences
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test for custom preferences with a match
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX', 'C.UTF-8']) == 'C.UTF-8'

# Generated at 2022-06-16 22:40:56.810965
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    if PY3:
        assert get_best_parsable_locale(module) == 'C.utf8'
    else:
        assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:04.477691
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8', 'POSIX']) == 'C.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'POSIX']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['POSIX']) == 'C'

# Generated at 2022-06-16 22:41:07.748706
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:11.146903
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:21.229492
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    module = AnsibleModule(argument_spec={})

    # test that we get 'C' locale when locale command is not available
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # test that we get 'C' locale when locale command is available but there are no locales
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # test that we get 'C' locale when locale command is available but there are no locales

# Generated at 2022-06-16 22:41:24.341186
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:31.946260
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    # Test with no preferred locale
    assert get_best_parsable_locale(module) == 'C'
    # Test with preferred locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:41:35.036964
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:15.112067
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nen_US.utf8\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and preferences
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nen_US.utf8\n', '')


# Generated at 2022-06-16 22:42:17.870398
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:30.339534
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Mock module
    module = AnsibleModule(argument_spec={})

    # Mock locale
    module.run_command = lambda x: (0, 'C\nC.utf8\nen_US.utf8\nPOSIX\n', '')

    # Test default
    assert get_best_parsable_locale(module) == 'C'

    # Test with preferences
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'POSIX']) == 'en_US.utf8'

    # Test with preferences and raise_on_locale

# Generated at 2022-06-16 22:42:41.387733
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    if PY3:
        module.run_command = lambda x: (0, 'C\nC.UTF-8\nC.utf8\nen_US.utf8\nPOSIX\n', '')
    else:
        module.run_command = lambda x: (0, 'C\nC.UTF-8\nC.utf8\nen_US.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C'

    #

# Generated at 2022-06-16 22:42:50.540753
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale, but raise_on_locale
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
    except RuntimeWarning:
        pass
    else:
        assert False, "Expected RuntimeWarning"

    # Test with locale
    if PY3:
        assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'

# Generated at 2022-06-16 22:43:03.079587
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale tool
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale tool
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale tool
    module.run_command = lambda x: (0, 'C', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale tool

# Generated at 2022-06-16 22:43:06.017692
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:43:15.512951
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    module = AnsibleModule(argument_spec={})

    # Test that it returns the default locale when locale is not available
    assert get_best_parsable_locale(module) == 'C'

    # Test that it returns the default locale when locale is not available
    # and raise_on_locale is set to True
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

    # Test that it returns the default locale when locale is available
    # but no preferred locale is found

# Generated at 2022-06-16 22:43:28.249593
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: None
            self.run_command = lambda cmd: (0, 'C\nen_US.utf8\nPOSIX', '')
            self.get_bin_path = lambda cmd: '/usr/bin/locale'

    module = FakeModule()

    assert get_best_parsable_locale(module) == 'en_US.utf8'

    module.run_command = lambda cmd: (0, 'C\nen_US.utf8\nPOSIX\nC.utf8', '')
    assert get_best_parsable_locale

# Generated at 2022-06-16 22:43:31.065749
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:44:31.707518
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:44:34.949803
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:44:37.821083
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:44:47.415254
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Test with no locale
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test with locale
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test

# Generated at 2022-06-16 22:44:49.903714
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:44:59.993655
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['C']) == 'C'

    # Test with locale that does not exist
    assert get_best_parsable_locale(module, preferences=['C', 'en_US.utf8']) == 'C'

    # Test with locale that does exist
    assert get_best_parsable_locale(module, preferences=['C', 'en_US.utf8', 'POSIX']) == 'POSIX'

    # Test with locale

# Generated at 2022-06-16 22:45:10.108623
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile

    # Create a temporary file to hold the output of locale -a
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Write the output of locale -a to the temporary file
    with open(path, 'w') as f:
        f.write('C\n')
        f.write('C.utf8\n')
        f.write('en_US.utf8\n')
        f.write('POSIX\n')

    # Create a mock module
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda x: (0, open(path).read(), '')

    # Test the function

# Generated at 2022-06-16 22:45:22.350464
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test with locale and raise_on_locale
    if PY3:
        assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

# Generated at 2022-06-16 22:45:32.540873
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale available
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale available
    module.run_command = lambda x: (0, 'C.UTF-8\nC.utf8\nC\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale available but not in preferred list

# Generated at 2022-06-16 22:45:44.851826
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test that we get the default locale
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the default locale when we pass in a list of locales
    # that are not available
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test that we get the first locale in the list that is available
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

# Generated at 2022-06-16 22:47:40.916688
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:47:51.081794
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    # Create a fake module
    module = AnsibleModule(argument_spec={})

    # Create a fake locale command
    fake_locale = os.path.join(os.path.dirname(__file__), 'fake_locale')

    # Set the fake locale command
    module.get_bin_path = lambda x: fake_locale

    # Test with no preferences
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with preferences
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'

# Generated at 2022-06-16 22:47:53.703938
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'