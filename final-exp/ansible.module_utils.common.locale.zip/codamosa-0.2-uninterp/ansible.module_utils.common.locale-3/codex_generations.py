

# Generated at 2022-06-16 22:38:06.377992
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:10.478296
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    module = AnsibleModule(argument_spec={})

    if PY2:
        assert module.get_best_parsable_locale() == 'C'
    else:
        assert module.get_best_parsable_locale() == 'C.utf8'

# Generated at 2022-06-16 22:38:21.863385
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test case 1: no locale tool
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test case 2: locale tool, no output
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test case 3: locale tool, no output
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (1, '', '')

# Generated at 2022-06-16 22:38:32.542869
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # test with no locale
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # test with no locale
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # test with no locale
    module.run_command = lambda x: (0, 'C', '')
    assert get_best_parsable_locale(module) == 'C'

    # test with no locale
    module.run_command = lambda x: (0, 'C\nen_US.utf8', '')

# Generated at 2022-06-16 22:38:36.791635
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:47.955538
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    module = AnsibleModule(argument_spec={})

    # Test 1: locale command is not available
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test 2: locale command is available but no output
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test 3: locale command is available but no output
    module.run_command = lambda x: (0, 'C', '')

# Generated at 2022-06-16 22:38:51.623763
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:39:01.469858
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    class FakeModule(object):
        def __init__(self, out, err, rc):
            self.out = out
            self.err = err
            self.rc = rc

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd):
            return self.rc, self.out, self.err

    # Test with no locale
    module = FakeModule('', '', 0)
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale and raise_on_locale=True
    module = FakeModule('', '', 0)

# Generated at 2022-06-16 22:39:05.175530
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

# Generated at 2022-06-16 22:39:16.604968
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8', 'POSIX', 'C']) == 'C'

# Generated at 2022-06-16 22:39:31.781507
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale

# Generated at 2022-06-16 22:39:35.466679
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:39:46.761044
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path

    module = AnsibleModule(argument_spec={})
    locale = get_bin_path(module, "locale")

    if locale:
        # test with no preferences
        assert get_best_parsable_locale(module) == 'C'

        # test with preferences
        assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

        # test with preferences and raise_on_locale

# Generated at 2022-06-16 22:39:48.084957
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:39:59.851922
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import ansible.module_utils.basic
    import ansible.module_utils.common.process

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary environment
    old_env = os.environ.copy()
    os.environ.update({
        'PATH': tmpdir + ':' + os.environ['PATH'],
        'LC_ALL': 'C',
        'LANG': 'C',
    })

    # Create a temporary module
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
    )

    # Create a locale command
    locale_path = os.path.join(tmpdir, 'locale')
   

# Generated at 2022-06-16 22:40:02.832733
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:11.905088
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX']) == 'C.utf8'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX'], raise_on_locale=True) == 'C.utf8'

# Generated at 2022-06-16 22:40:15.061511
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:21.507035
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:40:29.791051
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX']) == 'C.utf8'

    # Test with locale

# Generated at 2022-06-16 22:40:49.601393
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    module.run_command = lambda x: (0, 'C\nen_US.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    module.run_command = lambda x: (0, 'C\nen_US.utf8\nPOSIX\n', '')
    assert get_best_

# Generated at 2022-06-16 22:40:55.486088
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with default preferences
    assert get_best_parsable_locale(module) == 'C'

    # Test with custom preferences
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:40:58.503614
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:05.309865
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'

    # Test with a locale that is not available
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'en_US.utf-8']) == 'C'

    # Test with a locale that is available
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'

    # Test with a locale that is available

# Generated at 2022-06-16 22:41:13.600406
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

# Generated at 2022-06-16 22:41:23.044076
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale tool
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test with no output from locale
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no preferred locale
    module.run_command = lambda x: (0, 'C\nPOSIX\n', '')

# Generated at 2022-06-16 22:41:26.211422
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:30.461429
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:39.395807
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale installed
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale installed
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale installed but not in the list of preferred locales
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')

# Generated at 2022-06-16 22:41:50.790279
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test that the function returns the first preferred locale
    # that is available
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8']) == 'en_US.utf8'

    # Test that the function returns the first preferred locale
    # that is available
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8']) == 'C.utf8'

    # Test that the function returns the first preferred locale
    # that is available

# Generated at 2022-06-16 22:42:10.451468
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:42:20.564914
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and preferences
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'POSIX']) == 'en_US.utf8'

    # Test with locale and preferences and raise_on_locale

# Generated at 2022-06-16 22:42:34.334110
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.process import get_bin_path_input

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: None

        def get_bin_path(self, name, required=False):
            return get_bin_path(name, required)


# Generated at 2022-06-16 22:42:45.696372
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test 1: Test that the default preference list is used
    #         when no preference list is passed in
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    # Test 2: Test that the default preference list is used
    #         when an empty preference list is passed in
    locale = get_best_parsable_locale(module, [])
    assert locale == 'C'

    # Test 3: Test that the default preference list is used
    #         when a preference list with only invalid locales
    #         is passed in

# Generated at 2022-06-16 22:42:52.906134
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['C', 'POSIX']) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C']) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C', 'en_US.utf8']) == 'C'

    # Test with locale

# Generated at 2022-06-16 22:42:57.161163
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:43:02.442450
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:43:05.044999
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:43:12.469797
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and preferences
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')

# Generated at 2022-06-16 22:43:14.934494
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:43:35.674060
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['C', 'en_US.utf8']) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C']) == 'en_US.utf8'

# Generated at 2022-06-16 22:43:43.625944
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX']) == 'C.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'POSIX']) == 'en_US.utf8'

# Generated at 2022-06-16 22:43:54.338875
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    module = AnsibleModule(argument_spec={})

    # Test for locale not found
    try:
        get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True)
    except RuntimeWarning:
        pass
    else:
        assert False, "Expected RuntimeWarning exception"

    # Test for locale found
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=False) == 'C'

# Generated at 2022-06-16 22:44:02.656147
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nen_US.UTF-8\nen_US\n', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale and preferences
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nen_US.UTF-8\nen_US\n', '')

# Generated at 2022-06-16 22:44:06.048026
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:44:16.678242
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    if PY3:
        assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'
    else:
        assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test with locale and raise_on_locale

# Generated at 2022-06-16 22:44:27.113667
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (0, 'C', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (0, 'C.utf8', '')
    assert get_best_

# Generated at 2022-06-16 22:44:38.950672
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Test with locale not found
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale found
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale found, but no output
    module = Ansible

# Generated at 2022-06-16 22:44:42.003531
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:44:48.637814
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: sys.exit(1)
            self.run_command = lambda cmd: (0, 'C\nen_US.utf8\nC.utf8', '')
            self.get_bin_path = lambda cmd: '/usr/bin/locale'

    module = FakeModule()
    assert get_best_parsable_locale(module) == 'C.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.utf8'

# Generated at 2022-06-16 22:45:27.739616
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'

    module.run_command = lambda x: (0, 'C\nen_US.utf8\n', '')
    assert get_best_parsable_locale(module) == 'C'

    module.run_command = lambda x: (0, 'en_US.utf8\nC\n', '')
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    module.run_command = lambda x: (0, 'C\nen_US.utf8\n', '')

# Generated at 2022-06-16 22:45:29.536211
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert module.get_best_parsable_locale() == 'C'

# Generated at 2022-06-16 22:45:31.156522
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:33.829137
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:46.695235
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['C', 'en_US.utf8']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C', 'en_US.utf8', 'POSIX']) == 'C'
    assert get_

# Generated at 2022-06-16 22:45:58.283845
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and no preferences
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX', '')

# Generated at 2022-06-16 22:46:00.975761
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:46:12.454110
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C']) == 'en_US.utf8'

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C'], raise_on_locale=True) == 'en_US.utf8'

# Generated at 2022-06-16 22:46:15.332735
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:46:23.433467
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test that we get the default locale 'C' when locale is not found
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the default locale 'C' when locale is not found
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

    # Test that we get the default locale 'C' when locale is not found
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'C'

    # Test that we get the default locale 'C' when locale is not found
    assert get_

# Generated at 2022-06-16 22:47:32.532563
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    if PY3:
        from unittest.mock import patch
    else:
        from mock import patch

    with patch('ansible.module_utils.basic.AnsibleModule.get_bin_path') as mock_get_bin_path:
        mock_get_bin_path.return_value = 'locale'
        with patch('ansible.module_utils.basic.AnsibleModule.run_command') as mock_run_command:
            mock_run_command.return_value = (0, 'C\nen_US.utf8\nen_US.UTF-8\nen_US\nPOSIX\n', '')
            module = AnsibleModule(argument_spec={})
           

# Generated at 2022-06-16 22:47:44.622348
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Test with no locale
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test with locale
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test

# Generated at 2022-06-16 22:47:47.673440
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:47:51.779700
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    if sys.version_info[0] == 2:
        from ansible.module_utils.basic import AnsibleModule
    else:
        from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:47:58.942480
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.common.process
    import ansible.module_utils.common.system
    import ansible.module_utils.six

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = ansible.module_utils.basic.fail_json
            self.exit_json = ansible.module_utils.basic.exit_json
            self.run_command = ansible.module_utils.common.process.run_command
            self.get_bin_path = ansible.module_utils.common.system.get_bin_path

    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = ansible.module_