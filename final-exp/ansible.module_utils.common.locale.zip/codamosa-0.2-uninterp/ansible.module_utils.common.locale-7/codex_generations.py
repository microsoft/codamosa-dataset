

# Generated at 2022-06-16 22:38:12.249506
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile

    # Create a fake locale command that returns a list of locales
    # and a fake locale -a command that returns a list of available
    # locales.
    locale_cmd = tempfile.NamedTemporaryFile(delete=False)
    locale_cmd.write(b'#!/bin/sh\n')
    locale_cmd.write(b'echo "C.UTF-8\nen_US.UTF-8\nC\nPOSIX"\n')
    locale_cmd.close()
    os.chmod(locale_cmd.name, 0o755)

    locale_a_cmd = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-16 22:38:15.752793
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:21.078808
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:38:31.956540
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8']) == 'C'


# Generated at 2022-06-16 22:38:41.256472
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

# Generated at 2022-06-16 22:38:43.806977
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:47.108851
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:58.695082
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.common.process
    import ansible.module_utils.common.systemd
    import ansible.module_utils.common.text
    import ansible.module_utils.common.win_dsc
    import ansible.module_utils.common.win_firewall
    import ansible.module_utils.common.win_registry
    import ansible.module_utils.common.win_system
    import ansible.module_utils.common.win_updates
    import ansible.module_utils.common.win_xml
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.windows
    import ansible.module_utils.facts.zfs
   

# Generated at 2022-06-16 22:39:10.148470
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    import os
    import sys

    # Create a fake module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a fake locale command
    locale_path = os.path.join(os.path.dirname(__file__), 'locale')
    if PY3:
        locale_path = locale_path.encode(sys.getfilesystemencoding())
    module.run_command = lambda cmd: (0, open(locale_path).read(), '')

    # Test with no preferences
    assert get_best_parsable_locale(module) == 'C'

    # Test with preferences
    assert get_best

# Generated at 2022-06-16 22:39:20.616994
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    module = AnsibleModule(argument_spec={})

    # Test with no locale tool
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no output from locale tool
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale tool
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale

# Generated at 2022-06-16 22:39:34.718953
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no preferences
    assert get_best_parsable_locale(module) == 'C'

    # Test with preferences
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test with preferences and raise_on_locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

    # Test with preferences and raise_on_locale


# Generated at 2022-06-16 22:39:46.146037
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'POSIX']) == 'C'
    assert get_best

# Generated at 2022-06-16 22:39:47.979623
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:39:50.357833
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:02.741934
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    module = AnsibleModule(argument_spec={})
    module.run_command = lambda args, check_rc=True: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')

    assert get_best_parsable_locale(module) == 'C.utf8'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'POSIX']) == 'C.utf8'
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C.utf8']) == 'POSIX'

# Generated at 2022-06-16 22:40:12.165421
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nen_US.UTF-8\nen_US\n', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale and preferences
    module.get_bin_path = lambda x: '/usr/bin/locale'

# Generated at 2022-06-16 22:40:22.870551
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale tool
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale tool, but no output
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale tool, but no output
    module.get_bin_path = lambda x: 'locale'

# Generated at 2022-06-16 22:40:29.732576
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module, preferences=None, raise_on_locale=False) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=False) == 'C'

# Generated at 2022-06-16 22:40:35.096419
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    if PY3:
        assert module.get_best_parsable_locale() == 'C.utf8'
    else:
        assert module.get_best_parsable_locale() == 'C'

# Generated at 2022-06-16 22:40:41.442473
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test that we get a locale back
    assert get_best_parsable_locale(module)

    # Test that we get a locale back when we specify a preference
    assert get_best_parsable_locale(module, preferences=['C.utf8'])

    # Test that we get a locale back when we specify a preference
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8'])

    # Test that we get a locale back when we specify a preference

# Generated at 2022-06-16 22:41:03.453857
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test 1: Test with no locale tool
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test 2: Test with no locale tool
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test 3: Test with no locale tool
    module.get_bin_path = lambda x: 'locale'

# Generated at 2022-06-16 22:41:07.271846
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:18.232949
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    import sys

    module = AnsibleModule(argument_spec={})

    # Test case 1: locale is not found
    # This test case is not applicable for Python 3.x
    if not PY3:
        if sys.version_info[0] == 2:
            reload(sys)
            sys.setdefaultencoding('utf-8')
        module.run_command = lambda x, check_rc=True: (1, '', 'locale: command not found')
        assert get_best_parsable_locale(module) == 'C'

    # Test case 2: locale is found but no output
    module.run_command = lambda x, check_rc=True: (0, '', '')

# Generated at 2022-06-16 22:41:19.480681
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:26.115472
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    # Test that we get the first preferred locale
    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8'])
    assert locale == 'en_US.utf8'

    # Test that we get the first preferred locale
    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8'])

# Generated at 2022-06-16 22:41:30.284573
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:39.307834
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test the get_best_parsable_locale function
    '''
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test the default case
    assert get_best_parsable_locale(module) == 'C'

    # Test the case where the locale tool is not found
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test the case where the locale tool is found but returns an error
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (1, '', 'error')
    assert get_best_parsable_locale(module) == 'C'

    #

# Generated at 2022-06-16 22:41:50.690609
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with locale not found
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale found
    module.run_command = lambda x: (0, 'C.utf8\nen_US.utf8\nC\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale found and preferences given
    module.run_command = lambda x: (0, 'C.utf8\nen_US.utf8\nC\nPOSIX\n', '')
    assert get_best_parsable

# Generated at 2022-06-16 22:42:02.431839
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.common.process
    import ansible.module_utils.common.system
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.pkg_mgr
    import ansible.module_utils.facts.service_mgr
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.zfs
    import ansible.module_utils.facts.zpool

# Generated at 2022-06-16 22:42:06.970021
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:38.992541
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test 1: Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test 2: Test with locale
    if PY3:
        assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'
    else:
        assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:42:49.024507
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'POSIX', 'en_US.utf8', 'C']) == 'C'

# Generated at 2022-06-16 22:42:55.606647
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test with no preferences
    assert get_best_parsable_locale(None) == 'C'

    # Test with preferences
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:42:58.852062
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    assert get_best_parsable_locale(AnsibleModule(argument_spec={})) == 'C'

# Generated at 2022-06-16 22:43:08.037272
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test the default case
    assert get_best_parsable_locale(module) == 'C'

    # Test the case where we have a locale available
    if PY3:
        module.run_command = lambda x: (0, 'C.utf8\nen_US.utf8\nC\nPOSIX\n', '')
    else:
        module.run_command = lambda x: (0, 'C.utf8\nen_US.utf8\nC\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test the case where we

# Generated at 2022-06-16 22:43:16.848374
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and preferences
    module.get_bin_path = lambda x: '/usr/bin/locale'

# Generated at 2022-06-16 22:43:29.694283
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile

    # Create a temporary file to be used as a fake locale command
    (fd, locale_file) = tempfile.mkstemp()
    os.close(fd)
    os.chmod(locale_file, 0o755)

    # Create a fake locale command that returns the locales in the order we want
    with open(locale_file, 'w') as f:
        f.write("#!/bin/sh\n")
        f.write("echo C.utf8\n")
        f.write("echo en_US.utf8\n")
        f.write("echo C\n")
        f.write("echo POSIX\n")

    # Create a fake module

# Generated at 2022-06-16 22:43:37.352987
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

# Generated at 2022-06-16 22:43:51.265073
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale tool
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale tool, no output
    module.get_bin_path = lambda x: '/bin/locale'
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale tool, no output
    module.get_bin_path = lambda x: '/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8', '')
    assert get_best_p

# Generated at 2022-06-16 22:43:54.294262
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:44:52.887929
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:44:55.734792
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:01.070344
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)
    if PY3:
        assert locale == 'C.UTF-8'
    else:
        assert locale == 'C'

# Generated at 2022-06-16 22:45:09.233626
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

# Generated at 2022-06-16 22:45:21.136691
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2
    import sys
    import os

    # Create a fake module
    module = AnsibleModule(argument_spec={})

    # Create a fake locale command
    fake_locale_path = os.path.join(os.path.dirname(__file__), 'fake_locale')
    if PY2:
        fake_locale_path = fake_locale_path.encode(sys.getfilesystemencoding())
    module.get_bin_path = lambda x: fake_locale_path

    # Test with no preferences
    assert get_best_parsable_locale(module) == 'C'

    # Test with a preference that is not available
    assert get_best_parsable_

# Generated at 2022-06-16 22:45:24.598538
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:33.568647
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C.utf8'

# Generated at 2022-06-16 22:45:36.328723
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:49.301238
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test for default preferences
    assert get_best_parsable_locale(module) == 'C'

    # Test for empty preferences
    assert get_best_parsable_locale(module, preferences=[]) == 'C'

    # Test for non-existent locale
    assert get_best_parsable_locale(module, preferences=['foo']) == 'C'

    # Test for non-existent locale with raise_on_locale
    if PY3:
        with pytest.raises(RuntimeWarning):
            get_best_parsable_locale(module, preferences=['foo'], raise_on_locale=True)

# Generated at 2022-06-16 22:46:00.292450
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.common.process
    import ansible.module_utils.common.system
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.distribution
    import ansible.module_utils.facts.other
    import ansible.module_utils.facts.processor
    import ansible.module_utils.facts.pkg_mgr
    import ansible.module_utils.facts.service_mgr
    import ansible.module_utils.facts

# Generated at 2022-06-16 22:46:57.700321
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:47:06.905502
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Test with no locale
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['C', 'POSIX']) == 'C'

    # Test with locale and no preferences
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=None) == 'C'

    # Test with locale and preferences
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-16 22:47:13.081083
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test with no locale command
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale command but no output
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale command but no output
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-16 22:47:24.047574
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale tool
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale tool, but no output
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale tool, but no output
    module.get_bin_path = lambda x: '/usr/bin/locale'

# Generated at 2022-06-16 22:47:33.401677
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test with no locale tool
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with empty locale tool output
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale tool output
    module.run_command = lambda x: (0, 'C.utf8\nen_US.utf8\nC\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale tool output and custom

# Generated at 2022-06-16 22:47:36.524348
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:47:40.762540
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:47:43.976681
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:47:47.108145
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:47:52.334272
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C'], raise_on_locale=True) == 'en_US.utf8'