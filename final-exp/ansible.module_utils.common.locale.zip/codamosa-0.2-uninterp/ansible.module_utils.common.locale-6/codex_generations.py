

# Generated at 2022-06-16 22:38:05.472848
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:07.776142
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:19.919695
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test the default case
    assert get_best_parsable_locale(module) == 'C'

    # Test the case where we have a locale available
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test the case where we have a locale available
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX']) == 'C.utf8'

    # Test the case where we have a locale available
    assert get_best

# Generated at 2022-06-16 22:38:31.053966
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path

    module = AnsibleModule(argument_spec={})
    module.get_bin_path = get_bin_path

    # Test with no locale
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (0, 'C.UTF-8', '')

# Generated at 2022-06-16 22:38:33.626541
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:38.053116
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:41.349003
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:47.676380
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Create a fake module
    module = AnsibleModule(argument_spec={})

    # Test with no locale
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    if PY3:
        module.run_command = lambda x: (0, 'C.UTF-8\nen_US.UTF-8\n', '')
    else:
        module.run_command = lambda x: (0, 'C.UTF-8\nen_US.UTF-8\n', '')

# Generated at 2022-06-16 22:38:58.951852
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    import shutil
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a locale file
    locale_file = os.path.join(tmpdir, 'locale')
    with open(locale_file, 'w') as f:
        f.write('#!/bin/sh\n')
        f.write('echo "C.UTF-8"\n')
        f.write('echo "en_US.UTF-8"\n')
        f.write('echo "C"\n')
        f.write('echo "POSIX"\n')

    # Make the locale file executable
    os.chmod(locale_file, 0o755)

    # Add the

# Generated at 2022-06-16 22:39:10.503533
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test that we get the default locale if we don't have a locale binary
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the default locale if we can't get locale information
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the default locale if we can't get locale information

# Generated at 2022-06-16 22:39:22.950379
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    module = AnsibleModule(argument_spec={})

    # Test that the default locale is 'C'
    assert get_best_parsable_locale(module) == 'C'

    # Test that a locale that is not available is not returned
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'en_US.utf8']) == 'C'

    # Test that a locale that is available is returned
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C']) == 'C'

    # Test that the first available locale is returned

# Generated at 2022-06-16 22:39:29.710871
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:39:36.821697
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and preferences
    module.get_bin_path = lambda x: '/usr/bin/locale'

# Generated at 2022-06-16 22:39:47.814974
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C.utf8', 'en_US.utf8', 'C']) == 'C'

# Generated at 2022-06-16 22:39:55.409455
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    module = AnsibleModule(argument_spec={})

    # Test 1: Test with no locale tool
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test 2: Test with no locale tool
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test 3: Test with no locale tool
    module.run_command = lambda x: (0, 'C.utf8\nen_US.utf8\nC\nPOSIX\n', '')

# Generated at 2022-06-16 22:40:02.199149
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:40:05.144505
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:13.740733
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test with no locale available
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale available, but raise_on_locale=True
    module.run_command = lambda x: (1, '', '')
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
    except RuntimeWarning:
        pass
    else:
        assert False, "Expected RuntimeWarning"

    # Test with locale available, but no preferences

# Generated at 2022-06-16 22:40:17.248296
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:20.382223
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:40.753359
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.common.process
    import ansible.module_utils.common.collections
    import ansible.module_utils.common.text
    import ansible.module_utils.common.json_utils
    import ansible.module_utils.common.file
    import ansible.module_utils.common.netcommon
    import ansible.module_utils.common.crypto
    import ansible.module_utils.common.removed
    import ansible.module_utils.common.validation
    import ansible.module_utils.common.warnings
    import ansible.module_utils.common.sys_info
    import ansible.module_utils.common.compat
    import ansible.module_utils.common.clean
    import ansible.module_utils

# Generated at 2022-06-16 22:40:44.778666
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:48.595656
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:51.576143
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:01.183329
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (0, 'C.UTF-8', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (0, 'C.UTF-8', '')
   

# Generated at 2022-06-16 22:41:05.878685
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:16.955539
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test that we get the default locale
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    # Test that we get the first preferred locale
    locale = get_best_parsable_locale(module, preferences=['en_US.utf8', 'C'])
    assert locale == 'en_US.utf8'

    # Test that we get the second preferred locale
    locale = get_best_parsable_locale(module, preferences=['en_US.utf8', 'C', 'POSIX'])
    assert locale == 'C'

    # Test that we get the default locale when locale is

# Generated at 2022-06-16 22:41:23.225986
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['C.UTF-8']) == 'C.UTF-8'

    # Test with locale not found
    assert get_best_parsable_locale(module, preferences=['C.UTF-8', 'en_US.UTF-8']) == 'C.UTF-8'

    # Test with locale not found and raise_on_locale

# Generated at 2022-06-16 22:41:26.406985
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:30.702733
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:48.373903
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:51.236558
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:02.763965
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and preferences
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')

# Generated at 2022-06-16 22:42:07.252749
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:10.664124
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:14.120984
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:23.600177
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test that we get a locale back
    assert get_best_parsable_locale(module)

    # Test that we get a locale back with a preference
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'])

    # Test that we get a locale back with a preference
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'])

    # Test that we get a locale back with a preference
    assert get_best_parsable_loc

# Generated at 2022-06-16 22:42:35.769370
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test that we get the default locale if no preferences are given
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the first preference if it is available
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8']) == 'C.utf8'

    # Test that we get the second preference if the first is not available
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8']) == 'C.utf8'

    # Test that we get the default locale if none of the preferences are available
    assert get_best_parsable

# Generated at 2022-06-16 22:42:46.987408
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test that we get the default locale
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the default locale when we have no locale tool
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the default locale when we have no locale tool
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the default locale when we have no locale tool
    module

# Generated at 2022-06-16 22:42:50.505865
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:43:22.741194
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:43:26.626703
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:43:35.214286
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    os.environ['LC_ALL'] = ''
    os.environ['LANG'] = ''
    os.environ['LANGUAGE'] = ''
    assert get_best_parsable_locale(module) == 'C'

    # Test with bad locale
    os.environ['LC_ALL'] = 'bad_locale'
    os.environ['LANG'] = 'bad_locale'
    os.environ['LANGUAGE'] = 'bad_locale'
    assert get_best_parsable_locale(module) == 'C'

    # Test with good locale

# Generated at 2022-06-16 22:43:43.082503
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test that we get the default locale
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the first preferred locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'

    # Test that we get the second preferred locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX']) == 'en_US.utf8'

    # Test that we get the third preferred locale

# Generated at 2022-06-16 22:43:53.977386
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test for locale command not found
    assert get_best_parsable_locale(module) == 'C'

    # Test for locale command found
    module.run_command = lambda x: (0, 'C\nC.UTF-8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test for locale command found
    module.run_command = lambda x: (0, 'C\nC.UTF-8\nPOSIX\n', '')

# Generated at 2022-06-16 22:43:55.852825
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert module.get_best_parsable_locale() == 'C'

# Generated at 2022-06-16 22:43:58.969649
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:44:10.360634
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no arguments
    assert get_best_parsable_locale(module) == 'C'

    # Test with a list of preferences
    assert get_best_parsable_locale(module, preferences=['C', 'POSIX']) == 'C'

    # Test with a list of preferences that does not exist
    assert get_best_parsable_locale(module, preferences=['foo', 'bar']) == 'C'

    # Test with a list of preferences that does not exist and raise_on_locale=True

# Generated at 2022-06-16 22:44:19.200487
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale installed
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale installed
    module.run_command = lambda x: (0, 'C.utf8\nen_US.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale installed and no preferences
    module.run_command = lambda x: (0, 'C.utf8\nen_US.utf8\nPOSIX\n', '')

# Generated at 2022-06-16 22:44:30.072879
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    if PY3:
        assert get_best_parsable_locale(module, preferences=['C.UTF-8', 'C.utf8', 'C']) == 'C.UTF-8'
    else:
        assert get_best_parsable_locale(module, preferences=['C.UTF-8', 'C.utf8', 'C']) == 'C.utf8'

    # Test with no locale and raise_on_locale

# Generated at 2022-06-16 22:45:27.928829
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:30.780623
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:38.051615
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Test with no locale tool
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale tool but raise_on_locale=True
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: None
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
        assert False
    except RuntimeWarning:
        assert True

    # Test with locale tool but no output
    module = AnsibleModule(argument_spec={})
    module.get_

# Generated at 2022-06-16 22:45:50.405615
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys

    # Create a fake module
    module = AnsibleModule(argument_spec={})

    # Create a fake locale command
    def fake_run_command(args, **kwargs):
        if args[0] == 'locale':
            if args[1] == '-a':
                return (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')

# Generated at 2022-06-16 22:46:00.814806
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Create a fake module
    module = AnsibleModule(argument_spec={})

    # Create a fake locale command

# Generated at 2022-06-16 22:46:13.822606
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    module = AnsibleModule(argument_spec={})

    # Test with no locale command
    module.run_command = lambda x: (1, '', 'locale command not found')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no output from locale command
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale command
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nen_US.UTF-8\nen_US\n', '')

# Generated at 2022-06-16 22:46:22.295300
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: None
            self.run_command = lambda cmd: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
            self.get_bin_path = lambda cmd: get_bin_path(cmd)

    module = FakeModule()

    assert get_best_parsable_locale(module) == 'C.utf8'

# Generated at 2022-06-16 22:46:34.847977
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Test for locale not found
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test for locale found
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test for locale found with custom preferences
    module = AnsibleModule

# Generated at 2022-06-16 22:46:42.920218
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale command
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test with no output from locale command
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale in output from locale command
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale in output from locale command

# Generated at 2022-06-16 22:46:53.384815
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (0, '', 'error')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (1, '', 'error')
    assert get_best_parsable