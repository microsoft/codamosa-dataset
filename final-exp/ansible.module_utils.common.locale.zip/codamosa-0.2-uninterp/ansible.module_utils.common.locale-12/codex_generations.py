

# Generated at 2022-06-16 22:38:11.278865
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test that we get the default locale
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the first preferred locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'

    # Test that we get the last preferred locale
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C']) == 'C'

    # Test that we get the default locale when locale command is not found

# Generated at 2022-06-16 22:38:19.115088
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:38:23.626819
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys

    # Create a fake module
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda cmd: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')

    # Test that we get the first preferred locale
    assert get_best_parsable_locale(module, ['en_US.utf8', 'C.utf8']) == 'en_US.utf8'

    # Test that we get the first preferred locale
    assert get_best_parsable_locale(module, ['en_US.utf8', 'C.utf8']) == 'en_US.utf8'

    # Test that we get the first preferred locale
    assert get_best

# Generated at 2022-06-16 22:38:27.682974
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:32.435433
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    if PY3:
        assert get_best_parsable_locale(module) == 'C.utf8'
    else:
        assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:36.681794
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:47.559401
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule, get_exception
    from ansible.module_utils.six import PY3

    # Create a fake module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Test get_best_parsable_locale with no preferences
    assert get_best_parsable_locale(module) == 'C'

    # Test get_best_parsable_locale with preferences
    assert get_best_parsable_locale(module, preferences=['C', 'POSIX']) == 'C'

    # Test get_best_parsable_locale with preferences and raise_on_locale
    assert get_best_pars

# Generated at 2022-06-16 22:38:58.605530
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
    )

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C'], raise_on_locale=True) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C'], raise_on_locale=False) == 'en_US.utf8'

# Generated at 2022-06-16 22:39:09.996746
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test with no locale installed
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale installed
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale installed but not in the list
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')

# Generated at 2022-06-16 22:39:13.869217
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict()
    )
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:39:31.866117
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.check_mode = False
            self.no_log = False
            self.debug = False
            self.verbosity = 0
            self.fail_json = False
            self.exit_json = False
            self.run_command_environ_update = {}
            self.run_command_suppress_warnings = False
            self.run_command_check_rc = False
            self.run_command_encoding = None
            self.run_command_errors = 'surrogate_then_replace'
            self.run

# Generated at 2022-06-16 22:39:43.580614
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    # Test for locale CLI issues
    module = AnsibleModule(argument_spec={})
    if PY3:
        from unittest.mock import patch
    else:
        from mock import patch

    with patch.object(module, 'run_command') as mock_run_command:
        mock_run_command.return_value = (1, '', '')
        locale = get_best_parsable_locale(module, raise_on_locale=True)
        assert locale == 'C'

# Generated at 2022-06-16 22:39:52.404778
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C', 'POSIX']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'POSIX', 'C'])

# Generated at 2022-06-16 22:39:55.831549
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:06.966501
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test that we get 'C' locale when locale command is not available
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get 'C' locale when locale command is available but
    # there is no output
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get 'C' locale when locale command is available but
    # there is no output

# Generated at 2022-06-16 22:40:14.685481
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX']) == 'C'

# Generated at 2022-06-16 22:40:22.946320
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'

    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

# Generated at 2022-06-16 22:40:33.532571
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX']) == 'C'
    assert get_best_

# Generated at 2022-06-16 22:40:36.490300
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:49.183082
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    import os

    # Create a fake module
    module = AnsibleModule(argument_spec={})

    # Create a fake locale command
    locale_cmd = os.path.join(os.path.dirname(__file__), 'locale')
    os.chmod(locale_cmd, 0o755)
    module.run_command = lambda args: (0, open(locale_cmd).read(), '')

    # Test with no preferences
    assert get_best_parsable_locale(module) == 'C'

    # Test with preferences

# Generated at 2022-06-16 22:41:04.164437
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale installed
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale installed
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale installed
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX', '')

# Generated at 2022-06-16 22:41:15.640636
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and preferences
    module.get_bin_path = lambda x: '/usr/bin/locale'

# Generated at 2022-06-16 22:41:24.166956
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and preferences
    preferences = ['en_US.utf8', 'POSIX']
    assert get_best_parsable_locale(module, preferences) == 'en_US.utf8'

    # Test with locale

# Generated at 2022-06-16 22:41:36.090138
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and preferences
    module.get_bin_path = lambda x: '/usr/bin/locale'

# Generated at 2022-06-16 22:41:47.371491
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale command
    module.run_command = lambda x: (1, '', 'locale: command not found')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no output from locale command
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no output from locale command
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no output from locale command

# Generated at 2022-06-16 22:41:48.670281
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:00.947285
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and custom preferences
    module.get_bin_path = lambda x: '/usr/bin/locale'

# Generated at 2022-06-16 22:42:13.880429
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX']) == 'C.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'POSIX']) == 'en_US.utf8'

# Generated at 2022-06-16 22:42:16.933169
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:23.077363
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})
    if PY3:
        assert module.get_best_parsable_locale() == 'C'
    else:
        assert module.get_best_parsable_locale() == 'C.utf8'

# Generated at 2022-06-16 22:42:47.791280
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'

    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.utf8'


# Generated at 2022-06-16 22:42:51.904694
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:56.184257
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:43:06.279234
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX']) == 'C.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'POSIX']) == 'en_US.utf8'

# Generated at 2022-06-16 22:43:15.722472
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO

    class FakeModule(object):
        def __init__(self, locale_path):
            self.locale_path = locale_path
            self.params = {}
            self.fail_json = lambda **kwargs: None
            self.run_command = lambda args, **kwargs: (0, self.locale_path, '')

    # Test with no locale
    module = FakeModule('')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module = FakeModule('C.UTF-8')

# Generated at 2022-06-16 22:43:28.438904
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and no preferences
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable

# Generated at 2022-06-16 22:43:31.345915
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:43:38.322800
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale available
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale available, but raise_on_locale is True
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
        assert False
    except RuntimeWarning:
        assert True

    # Test with locale available, but no preferences
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nen_US.utf8\n', '')
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:43:51.420437
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Create a mock module
    module = AnsibleModule(argument_spec={})

    # Test that the function returns the default locale 'C' when the locale command is not found
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test that the function returns the default locale 'C' when the locale command returns an error
    module.run_command = lambda x: (1, '', 'Error')
    assert get_best_parsable_locale(module) == 'C'

    # Test that the function returns the default locale 'C' when the locale command returns no output

# Generated at 2022-06-16 22:44:00.689385
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8', 'POSIX', 'C']) == 'en_US.utf8'

# Generated at 2022-06-16 22:44:38.771387
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale command
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale command and raise_on_locale=True
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
    except RuntimeWarning:
        pass
    else:
        assert False, "Expected RuntimeWarning exception"

    # Test with locale command and no locale available
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale command and no locale

# Generated at 2022-06-16 22:44:48.336028
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.common.process
    import ansible.module_utils.common.system
    import ansible.module_utils.common.text
    import ansible.module_utils.common.json
    import ansible.module_utils.common.file
    import ansible.module_utils.common.crypto
    import ansible.module_utils.common.network
    import ansible.module_utils.common.collections
    import ansible.module_utils.common.logging
    import ansible.module_utils.common.sys_info
    import ansible.module_utils.common.validation
    import ansible.module_utils.common.warnings
    import ansible.module_utils.common.clean
    import ansible.module_utils.common.comp

# Generated at 2022-06-16 22:44:58.728115
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['C']) == 'C'
    assert get_best_parsable_locale(module, ['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, ['POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(module, ['POSIX', 'C', 'en_US.utf8']) == 'C'

# Generated at 2022-06-16 22:45:01.333554
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:11.184896
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8', 'POSIX', 'C']) == 'C'

# Generated at 2022-06-16 22:45:15.057025
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:25.573196
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test with no preferences
    assert get_best_parsable_locale(module) == 'C'

    # Test with preferences
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test with preferences and raise_on_locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

# Generated at 2022-06-16 22:45:28.469652
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:36.674915
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test that we get the default locale
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the first preferred locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'

    # Test that we get the second preferred locale
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8', 'C', 'POSIX']) == 'en_US.utf8'

    # Test that we get the third preferred locale
    assert get_best_parsable_locale

# Generated at 2022-06-16 22:45:40.988959
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:46:44.008255
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale available
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale available and raise_on_locale set to True
    module.run_command = lambda x: (1, '', '')
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
    except RuntimeWarning:
        pass
    else:
        assert False, 'Expected RuntimeWarning'

    # Test with locale available

# Generated at 2022-06-16 22:46:45.623331
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:46:48.263850
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:46:52.860517
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)

    if PY3:
        assert locale == 'C.UTF-8'
    else:
        assert locale == 'C'

# Generated at 2022-06-16 22:46:57.438416
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'
    # Test with locale
    assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:47:05.721355
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

# Generated at 2022-06-16 22:47:14.572139
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    class TestModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, name):
            return os.path.join(os.path.dirname(__file__), 'bin', name)

        def run_command(self, args):
            return 0, '', ''

    module = TestModule({})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.utf8'

# Generated at 2022-06-16 22:47:25.491843
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (1, '', 'error')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (0, '', 'error')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale
    module.run_command = lambda x: (0, 'C', '')
    assert get_best_pars

# Generated at 2022-06-16 22:47:34.114858
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'POSIX', 'en_US.utf8', 'C']) == 'C'

# Generated at 2022-06-16 22:47:46.197855
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.common.process
    import ansible.module_utils.common.system
    import ansible.module_utils.common.text
    import ansible.module_utils.common.collections
    import ansible.module_utils.common.json_utils
    import ansible.module_utils.common.crypto
    import ansible.module_utils.common.file
    import ansible.module_utils.common.netcommon
    import ansible.module_utils.common.removed
    import ansible.module_utils.common.validation
    import ansible.module_utils.common.warnings
    import ansible.module_utils.common.sys_info
    import ansible.module_utils.common.win_dsc
    import ansible.module