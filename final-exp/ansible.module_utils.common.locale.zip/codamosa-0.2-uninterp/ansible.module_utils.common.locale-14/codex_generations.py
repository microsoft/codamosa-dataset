

# Generated at 2022-06-16 22:38:06.270870
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:08.599450
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:14.630410
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test default preferences
    assert get_best_parsable_locale(module) == 'C'

    # Test custom preferences
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test custom preferences with a match
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX', 'en_US.utf8']) == 'en_US.utf8'

# Generated at 2022-06-16 22:38:18.328573
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:24.317469
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:38:28.166423
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:35.435496
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'POSIX', 'en_US.utf8', 'C']) == 'C'

# Generated at 2022-06-16 22:38:39.414700
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:38:50.775177
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    class FakeModule(object):
        def __init__(self, locale_path):
            self.locale_path = locale_path

        def get_bin_path(self, name, required=False, opt_dirs=None):
            if name == 'locale':
                return self.locale_path


# Generated at 2022-06-16 22:38:55.960891
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.run_command = lambda args: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and preferences
    module.run_command = lambda args: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C']) == 'POSIX'



# Generated at 2022-06-16 22:39:03.467808
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:39:06.986410
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:39:18.605133
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test that we get the default locale if locale is not installed
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the default locale if locale is installed but doesn't return any output
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the default locale if locale is installed but returns an error
    module.run_command = lambda x: (1, '', 'error')
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get

# Generated at 2022-06-16 22:39:29.862435
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Create a mock module
    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    if PY3:
        module.run_command = lambda x: (0, 'C\nC.UTF-8\nC.utf8\nPOSIX\nen_US.utf8\n', '')
    else:
        module.run_command = lambda x: (0, 'C\nC.UTF-8\nC.utf8\nPOSIX\nen_US.utf8\n'.decode('utf-8'), '')
    assert get_best_pars

# Generated at 2022-06-16 22:39:36.894020
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Test with no locale binary
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale binary and raise_on_locale=True
    module = AnsibleModule(argument_spec={})
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
    except RuntimeWarning:
        pass
    else:
        assert False, "Expected RuntimeWarning to be raised"

    # Test with no locale binary and raise_on_locale=False
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, raise_on_locale=False) == 'C'

# Generated at 2022-06-16 22:39:40.459712
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:39:50.369123
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    import sys

    class FakeModule(object):
        def __init__(self):
            self.params = {}

# Generated at 2022-06-16 22:39:54.345378
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:05.624428
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test that we get the default locale if no preferences are passed
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the first preference if it is available
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'

    # Test that we get the first preference if it is available
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8', 'C', 'POSIX']) == 'en_US.utf8'

    # Test that we get the first preference if it is

# Generated at 2022-06-16 22:40:13.336493
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Test with no locale tool
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale tool and no preferences
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=None) == 'C'

    # Test with locale tool and preferences
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:40:29.948305
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:40:35.607220
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test with no preferences
    assert get_best_parsable_locale(module) == 'C'

    # Test with preferences
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(module, preferences) == 'C'

# Generated at 2022-06-16 22:40:48.799374
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test that we get the default locale if we don't have any preferences
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get the first preference if it exists
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'

    # Test that we get the first preference if it exists

# Generated at 2022-06-16 22:40:58.958176
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test with no locale tool
    module = MockAnsibleModule()
    module.get_bin_path.return_value = None
    assert get_best_parsable_locale(module) == 'C'

    # Test with no output from locale
    module = MockAnsibleModule()
    module.run_command.return_value = (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no output from locale
    module = MockAnsibleModule()
    module.run_command.return_value = (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test with no output from locale
    module = MockAnsibleModule()

# Generated at 2022-06-16 22:41:10.669925
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    # Test 1:
    # Test that we get the best locale for parsing output in English
    # when the locale command is available
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nen_US.utf8\nC\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test 2:
    # Test that we get the best locale for parsing output in English
    # when the locale command is not available
    module = AnsibleModule(argument_spec={})
   

# Generated at 2022-06-16 22:41:20.834588
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale and raise_on_locale=True
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
    except RuntimeWarning:
        pass
    else:
        assert False, "RuntimeWarning not raised"

    # Test with no locale and preferences
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test with no locale and preferences

# Generated at 2022-06-16 22:41:23.911000
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:41:35.838796
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    # Test with a locale that is not available
    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8', 'C', 'POSIX'])
    assert locale == 'C'

    # Test with a locale that is available
    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module, preferences=['C.utf8', 'C', 'POSIX'])

# Generated at 2022-06-16 22:41:47.281078
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C.utf8', 'C']) == 'C'
    assert get_best_parsable_loc

# Generated at 2022-06-16 22:42:00.125353
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.get_bin_path = lambda x: '/usr/bin/locale'

# Generated at 2022-06-16 22:42:29.722211
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:42:40.736423
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no preferences
    assert get_best_parsable_locale(module) == 'C'

    # Test with preferences
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # Test with preferences and raise_on_locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

    # Test with preferences and raise_on_locale


# Generated at 2022-06-16 22:42:50.170443
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.common.process
    import ansible.module_utils.common.shell
    import ansible.module_utils.common.text
    import ansible.module_utils.common.json
    import ansible.module_utils.common.arguments
    import ansible.module_utils.common.collections
    import ansible.module_utils.common.netcommon
    import ansible.module_utils.common.network
    import ansible.module_utils.common.crypto
    import ansible.module_utils.common.file
    import ansible.module_utils.common.system
    import ansible.module_utils.common.validation
    import ansible.module_utils.common.warnings
    import ansible.module_utils.common.os


# Generated at 2022-06-16 22:43:00.758162
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

# Generated at 2022-06-16 22:43:03.510277
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:43:13.595545
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    if PY3:
        module.run_command = lambda x: (0, 'C.UTF-8\nen_US.UTF-8\nen_US.UTF-8\n', '')
    else:
        module.run_command = lambda x: (0, 'C.UTF-8\nen_US.UTF-8\nen_US.UTF-8\n'.decode('utf-8'), '')
    assert get_best_parsable_locale(module) == 'C.UTF-8'

# Generated at 2022-06-16 22:43:19.333510
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    class FakeModule(object):
        def __init__(self, locale_bin_path, locale_bin_rc, locale_bin_out, locale_bin_err):
            self.locale_bin_path = locale_bin_path
            self.locale_bin_rc = locale_bin_rc
            self.locale_bin_out = locale_bin_out
            self.locale_bin_err = locale_bin_err

        def get_bin_path(self, tool, required=False):
            return self.locale_bin_path


# Generated at 2022-06-16 22:43:29.002402
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'

# Generated at 2022-06-16 22:43:31.635876
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:43:34.705922
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:44:40.372496
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Test with no locale
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    # Test with locale and preferences
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: '/usr/bin/locale'
   

# Generated at 2022-06-16 22:44:49.748294
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Test for locale not found
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test for locale not found, but raise_on_locale=True
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    module.get_bin_path = lambda x: None
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
        assert False
    except RuntimeWarning:
        assert True

# Generated at 2022-06-16 22:44:59.877201
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    # Test that we get C locale if locale command is not available
    module.run_command = lambda x: (1, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get C locale if locale command is available but no output
    module.run_command = lambda x: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # Test that we get C locale if locale command is available but no output
    module.run_command = lambda x: (0, '', '')

# Generated at 2022-06-16 22:45:06.251464
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:45:13.686979
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\n', '')
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    # Test with locale and preferences
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\n', '')
    assert get_best_p

# Generated at 2022-06-16 22:45:25.523132
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8', 'C']) == 'en_US.utf8'

# Generated at 2022-06-16 22:45:27.147898
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:45:35.902038
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Test with no locale binary
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale binary, but raise_on_locale=True
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
    except RuntimeWarning:
        pass
    else:
        assert False, "Expected RuntimeWarning"

    # Test with no locale binary, but preferences=['foo']
    assert get_best_parsable_locale(module, preferences=['foo']) == 'C'

    # Test with no locale binary, but preferences=['foo'], and raise_

# Generated at 2022-06-16 22:45:49.209358
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Create a fake module
    module = AnsibleModule(argument_spec={})

    # Test the function with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test the function with a locale
    if PY3:
        assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX', 'en_US.utf8']) == 'en_US.utf8'

# Generated at 2022-06-16 22:45:51.913113
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-16 22:47:53.174726
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-16 22:48:03.601898
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    # Test with no locale command
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module) == 'C'

    # Test with no locale command and raise_on_locale=True
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: None
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
    except RuntimeWarning:
        pass
    else:
        assert False, "Expected RuntimeWarning"

    # Test with no output from locale command