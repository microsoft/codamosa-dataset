

# Generated at 2022-06-24 20:35:41.100450
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(bool_0) == True

# Generated at 2022-06-24 20:35:47.517291
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = False
    var_0 = get_best_parsable_locale(bool_0)
    var_1 = get_best_parsable_locale(bool_0, [''])
    var_2 = get_best_parsable_locale(bool_0, [''], True)

# Generated at 2022-06-24 20:35:49.260684
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    for test_case in [test_case_0]:
        test_case()

# Generated at 2022-06-24 20:35:54.062315
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert (test_case_0() == True)
        print('Passed.')
    except Exception as e:
        print('Failed.')
        print(e)

# Unit test
test_get_best_parsable_locale()

# Generated at 2022-06-24 20:35:56.332100
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()


if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:36:06.413022
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_0 = '''
    def get_best_parsable_locale(module, preferences=None, raise_on_locale=False):
        '''

# Generated at 2022-06-24 20:36:09.362950
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(module=None, preferences=None, raise_on_locale=True) == 'C'

# Generated at 2022-06-24 20:36:11.080952
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Basic case test
    assert get_best_parsable_locale(bool_0) == var_0

# Generated at 2022-06-24 20:36:13.109602
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' == get_best_parsable_locale('C')

# Generated at 2022-06-24 20:36:14.350177
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test the function is working as expected.
    var_1 = test_case_0()
    assert(var_1 == 'C')

# Generated at 2022-06-24 20:36:29.562570
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # may fail on machines where the locale commands are missing
    if not LOCALE_CMD:
        return True
    # not on Mac
    if platform.system() == 'Darwin':
        return True

    # test that if module is None, code should fail when we try to use it
    # we try to fail in a way that doesn't kill the entire test
    module = None
    try:
        get_best_parsable_locale(module, preferences=['C.utf8'])
        assert False, 'expected to fail with None module, but did not'
    except TypeError:
        assert True

    # test that it returns C.utf8 for preference
    # but only if that locale is actually available on the system
    LANG = None

# Generated at 2022-06-24 20:36:31.205785
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '\n    def get_best_parsable_locale(module, preferences=None, raise_on_locale=False):\n        '
    assert get_best_parsable_locale() == str_0

# Generated at 2022-06-24 20:36:33.949487
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale) == True


# Generated at 2022-06-24 20:36:37.817256
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

test_case_1 = 'C'
test_case_2 = 'C.utf8'
test_case_3 = 'POSIX'
test_case_4 = 'en_US.utf8'
test_case_5 = 'C'

# Print results from unit test
print(test_get_best_parsable_locale())

# Generated at 2022-06-24 20:36:43.548108
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Methodology:
    #
    # 1. Pick a simple test case.
    # 2. Write a test function and assert the expected output.
    # 3. Make the test pass.
    # 4. Refactor your code.
    # 5. Repeat.

    call_1 = get_best_parsable_locale(test_case_0)
    assert call_1 == 'C', "Result does not match expected"

    call_2 = get_best_parsable_locale(test_case_1)
    assert call_2 == 'C', "Result does not match expected"

    call_3 = get_best_parsable_locale(test_case_2)
    assert call_3 == 'C', "Result does not match expected"


# Generated at 2022-06-24 20:36:46.352209
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert str(get_best_parsable_locale())

# Generated at 2022-06-24 20:36:49.198284
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:36:50.672092
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 20:36:59.806703
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert str_0 in get_best_parsable_locale
# AssertionError: str_0 not in get_best_parsable_locale

# 
#     '''\n        Attempts to return the best possible locale for parsing output in English\n        useful for scraping output with i18n tools. When this raises an exception\n        and the caller wants to continue, it should use the \'C\' locale.\n\n        :param module: an AnsibleModule instance\n        :param preferences: A list of preferred locales, in order of preference\n        :param raise_on_locale: boolean that determines if we raise exception or not\n                                due to locale CLI issues\n        :returns: The first matched preferred locale or \'C\' which is the default\n    '''\n\n    found = \'C\'  #

# Generated at 2022-06-24 20:37:02.361166
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == '\n    def get_best_parsable_locale(module, preferences=None, raise_on_locale=False):\n        '

# Generated at 2022-06-24 20:37:08.216998
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale is None

# Generated at 2022-06-24 20:37:09.103371
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:37:18.751835
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # testing for raise on locale
    assert get_best_parsable_locale(test_case_0, raise_on_locale=True) == 'POSIX'
    assert get_best_parsable_locale(test_case_0, ['de_DE.utf8'], True) == 'POSIX'
    # testing for no raise
    assert get_best_parsable_locale(test_case_0) == 'POSIX'
    assert get_best_parsable_locale(test_case_0, ['de_DE.utf8']) == 'POSIX'
    assert get_best_parsable_locale(test_case_0, raise_on_locale=False) == 'POSIX'

# Generated at 2022-06-24 20:37:19.948586
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True # TODO: implement your test here


# Generated at 2022-06-24 20:37:25.189925
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_1 = None
    var_2 = False
    var_3 = get_best_parsable_locale(var_1, var_2)
    print(var_3)
    print("timezone: \"{}\"".format(var_3))

if __name__ == '__main__':
    import sys
    # sys.exit(test_case_0())
    print(test_get_best_parsable_locale())

# Generated at 2022-06-24 20:37:25.767418
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True



# Generated at 2022-06-24 20:37:27.055942
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Try to retrieve a preferred locale.
    assert test_case_0() == 'C'

# Generated at 2022-06-24 20:37:28.825593
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0()

# Generated at 2022-06-24 20:37:31.677284
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Verifying with known value
    assert get_best_parsable_locale(bool_0, preferences=['C.utf8', 'en_US.utf8'], raise_on_locale=True) == 'C.utf8'

# Generated at 2022-06-24 20:37:40.019666
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    parameters_0 = [
        (
            True,
        ),
        (
            True,
            [
                'C.utf8',
                'en_US.utf8',
                'C',
                'POSIX',
            ],
            True,
        ),
    ]
    return_value_0 = 'C.utf8'
    return_value_1 = 'POSIX'
    return_values = [
        return_value_0,
        return_value_1,
    ]
    def mock_get_bin_path(arg):
        return return_value_0

# Generated at 2022-06-24 20:37:55.107019
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None)


if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:37:57.227582
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = False
    array_0 = []
    var_0 = get_best_parsable_locale(bool_0, array_0)
    if var_0 == 'C':
        assert True
    else:
        assert False


# Generated at 2022-06-24 20:38:01.093474
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = False
    result = get_best_parsable_locale(bool_0)
    assert isinstance(result, str)

# Generated at 2022-06-24 20:38:06.935771
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(
        argument_spec = dict(
            preferences = dict(type='list'),
            raise_on_locale = dict(type='bool'),
        ),
        supports_check_mode=True,
    )
    result = get_best_parsable_locale(module, module.params['preferences'], module.params['raise_on_locale'])

    module.exit_json(result=result)


# Generated at 2022-06-24 20:38:17.113587
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    osn_platform_0 = 'win32'
    osn_platform_1 = 'linux'
    osn_platform_2 = 'darwin'
    osn_platform_3 = 'aix'
    osn_platform_4 = 'freebsd'
    osn_platform_5 = 'openbsd'
    osn_platform_6 = 'netbsd'

# Generated at 2022-06-24 20:38:17.698575
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True

# Generated at 2022-06-24 20:38:19.207764
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)



# Generated at 2022-06-24 20:38:21.689190
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ansible_module_instance = AnsibleModule(ansible_options={'no_log': True})

    assert test_case_0(ansible_module_instance) == 'C'


# Generated at 2022-06-24 20:38:28.215181
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test the path where module.run_command raises exception
    try:
        get_best_parsable_locale(True, ['en_US.utf8'], True)
    except RuntimeWarning as ex:
        assert "Could not find 'locale' tool" in to_native(ex)

    # Test the path where module.run_command returns rc = 0
    preferences = ['en_US.utf8', 'C']
    found = get_best_parsable_locale(True, preferences)
    assert found == 'C'

    # Test the path where module.run_command returns rc != 0
    found = get_best_parsable_locale(True, preferences, True)
    assert found == 'C'

    # Test the path where module.run_command returns rc = 0 but no output
    found = get_

# Generated at 2022-06-24 20:38:31.729108
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:38:47.723179
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == test_case_0()


if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:38:53.207975
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import tempfile
    import shutil
    from ansible.module_utils.basic import AnsibleModule

    module_path = 'ansible.module_utils.basic'
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    # create a tmp module path to mimic what ansible does
    tmp_path = tempfile.mkdtemp()

    # IMPORTANT: as of 2.4, when using the module_utils loader, the modules
    # are loaded from the local ansible checkout instead of the global path
    # where the system ansible is installed. To make sure the tests always
    # run with the installed version of the module, we temporarily move the
    # module_utils directory somewhere else, so that Ansible uses the one
    # installed on the system.
    import os
   

# Generated at 2022-06-24 20:38:54.509392
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    with pytest.raises(RuntimeWarning):
        assert isinstance(test_case_0(), bool)

# Generated at 2022-06-24 20:38:57.046612
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print("Running unit tests for get_best_parsable_locale")
    test_case_0()

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:38:58.398449
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_1 = test_case_0()
    return var_1


# Add test cases here

# Generated at 2022-06-24 20:39:00.248551
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # AssertionError: 'C' != 'en_US.UTF-8'
    assert get_best_parsable_locale() == 'en_US.UTF-8'


# Generated at 2022-06-24 20:39:02.830101
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert var_0 == 'C'
    except AssertionError:
        var_0 = get_best_parsable_locale(bool_0)
        assert var_0 == 'C'

# Generated at 2022-06-24 20:39:04.195132
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert "C" == get_best_parsable_locale()

# Generated at 2022-06-24 20:39:13.897140
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # try to get the current locale, but if it fails, it defaults to 'C'
    var_0 = get_best_parsable_locale()

    # try to get the current locale, but if it fails, it defaults to 'C'
    # but we force an exception to be raised if there are locale issues
    var_1 = get_best_parsable_locale(bool_0, bool_0)

    # try to get the current locale, but if it fails, it defaults to 'C'
    # but we force an exception to be raised if there are locale issues
    # and we use our own list of preferred locales
    var_2 = get_best_parsable_locale(bool_0, bool_0, bool_0)

# Generated at 2022-06-24 20:39:16.993727
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Run assertion test 0
    try:
        test_case_0()
    except Exception:
        assert False



# Generated at 2022-06-24 20:39:46.464174
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() is None


# Generated at 2022-06-24 20:39:47.429275
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert False



# Generated at 2022-06-24 20:39:49.115550
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True # TODO: implement your test here

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-24 20:39:59.046561
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Place your unit test code inside the function
    # It will be called with a variable number of arguments,
    # as specified in the unittest module.
    # Use the keyword argument 'msg=' to report errors or failures.
    # Use the keyword argument 'verbosity=n' to control output.

    # Unit tests are composed of three parts:
    #   - a setup
    #   - a test call
    #   - an assertion of the result

    # We use __main__ to gain access to AnsibleModule
    import __main__
    module = __main__.AnsibleModule({})

    # Set a variable for the module parameter preferences
    preferences = None

    # Get the result of get_best_parsable_locale using the AnsibleModule fixture
    result = get_best_parsable_locale(module, preferences)



# Generated at 2022-06-24 20:39:59.639937
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-24 20:40:04.469483
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(False) == "C"
    assert get_best_parsable_locale(False) == "C"
    assert get_best_parsable_locale(False) == "C"
    assert get_best_parsable_locale(False) == "C"
    assert get_best_parsable_locale(False) == "C"


# Generated at 2022-06-24 20:40:09.131300
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' == get_best_parsable_locale('asd')
    assert 'C' == get_best_parsable_locale('asd')
    assert 'POSIX' == get_best_parsable_locale('asd', ['POSIX'])
    assert 'C' == get_best_parsable_locale('asd', ['POSIX'], True)



# Generated at 2022-06-24 20:40:09.621155
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-24 20:40:10.761789
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert_equal(test_case_0(), "C")


# Generated at 2022-06-24 20:40:12.769834
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(arg_0) == expected_dict_0

# Generated at 2022-06-24 20:40:46.649121
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert to_native('C') == get_best_parsable_locale(test_case_0)  # case 0
    assert to_native('C.utf8') == get_best_parsable_locale(test_case_0, preferences=[to_native('C.utf8'), 'C', 'POSIX'])  # case 1
    assert to_native('POSIX') == get_best_parsable_locale(test_case_0, preferences=['C.utf8', 'C', to_native('POSIX')])  # case 2

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-24 20:40:51.595293
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test cases of function get_best_parsable_locale
    assert get_best_parsable_locale(False) == 'C'

    assert get_best_parsable_locale(True) == 'C'

    assert get_best_parsable_locale(None) == 'C'



# Generated at 2022-06-24 20:40:52.896138
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) is None

# Generated at 2022-06-24 20:40:55.636184
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale.__doc__ != None

if __name__ == '__main__':
    test_case_0()
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:41:00.949506
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # This will test the case where the options are false and the defaults are used
    test_case_0()


### End of Python code

# This is the code to be executed by the host Python interpreter
# to test the code above
if __name__ == "__main__":

    # These codes should be executed when invoked directly as:
    # python -m ansible_collections.community.general.plugins.module_utils.test.test_get_best_parsable_locale

    import unittest
    unittest.main()

# Generated at 2022-06-24 20:41:01.831258
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # test_case_0 is not working
    pass

# Generated at 2022-06-24 20:41:06.387601
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(bool_0)
    assert get_best_parsable_locale(bool_0, ['C.utf8', 'en_US.utf8'])
    assert get_best_parsable_locale(bool_0, ['C.utf8', 'en_US.utf8'], True)

# Generated at 2022-06-24 20:41:10.195178
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    parameters = {
        "module": {},
        "preferences": {},
        "raise_on_locale": {},
    }
    with pytest.raises(ValueError):
        get_best_parsable_locale(**parameters)


# Generated at 2022-06-24 20:41:11.492976
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)

# Generated at 2022-06-24 20:41:13.372880
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_1 = get_best_parsable_locale(bool_1, 'C', 'C')
    assert var_1 == 'C'

# Generated at 2022-06-24 20:41:47.122542
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True  # removed assert for type


# Generated at 2022-06-24 20:41:48.451159
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True # TODO: implement your test here



# Generated at 2022-06-24 20:41:58.751243
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Mock out
    class Bunch(dict):
        """Construct an object from a dictionary."""
        def __init__(self, *args, **kwds):
            super(Bunch, self).__init__(*args, **kwds)
            self.__dict__ = self

    class Bunch2(dict):
        """Construct an object from a dictionary."""
        def __init__(self, *args, **kwds):
            super(Bunch2, self).__init__(*args, **kwds)
            self.__dict__ = self

    class ModuleMock(object):
        def __init__(self, *args, **kwargs):
            super(ModuleMock, self).__init__(*args, **kwargs)
            self.params = Bunch(**kwargs)

# Generated at 2022-06-24 20:42:07.678112
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile
    import shutil
    import os
    import sys

    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
    else:
        import unittest

    from ansible.module_utils import basic

    class TestFeelings(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()

            self.bins = {}

            self.bins['cat'] = os.path.join(self.tmpdir, 'cat')

# Generated at 2022-06-24 20:42:08.846701
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True


# Generated at 2022-06-24 20:42:12.420905
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var = test_case_0.__annotations__['bool_0']
    var_1 = test_case_0.__annotations__['var_0']
    assert var == var_1

if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:42:13.639783
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)


# Generated at 2022-06-24 20:42:15.164411
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = False
    test_case_0()
    test_case_0()


if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:42:17.400521
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()
    print("all test cases passed!")


if __name__ == '__main__':
     test_get_best_parsable_locale()

# Generated at 2022-06-24 20:42:24.049078
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    parameters = [ get_best_parsable_locale() ]
    for parameter in parameters:
        try:
            test_case_0()
        except (TypeError, ValueError) as exception:
            return exception

if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:42:59.167144
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import subprocess

    assert subprocess.call(["python", "-m", "ansible.module_utils.basic.get_best_parsable_locale"]) == 0
# end of testing utils.get_best_parsable_locale

# Generated at 2022-06-24 20:43:00.634302
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert (get_best_parsable_locale(test_case_0) == "C")

# Generated at 2022-06-24 20:43:01.715728
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == False # TODO: implement your test here


# Generated at 2022-06-24 20:43:05.782027
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(bool_0) == 'C'

# Generated at 2022-06-24 20:43:06.623603
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True



# Generated at 2022-06-24 20:43:09.584311
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_cases = [
        (False, ),
    ]
    for params in test_cases:
        if isinstance(params, tuple):
            test_case_0(*params)
        else:
            test_case_0(params)

# Generated at 2022-06-24 20:43:10.104670
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:43:12.460411
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    func = get_best_parsable_locale
    module = AnsibleModule(argument_spec={})
    result = func(module, preferences=['de_DE.utf8', 'C.utf8'], raise_on_locale=False)
    assert result == "de_DE.utf8"
    assert result != "C.utf8"


# Generated at 2022-06-24 20:43:14.871016
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-24 20:43:19.552615
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(bool_0) == var_0



# Generated at 2022-06-24 20:43:55.246984
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert get_best_parsable_locale(bool_0) == var_0

# Generated at 2022-06-24 20:43:56.845097
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(var_0) == "C"


# Generated at 2022-06-24 20:43:59.758650
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except RuntimeWarning as err:
        print(err)
    except Exception as err:
        print(err)


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:44:04.866364
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_values = [
        # [input, expected],
        [False, None],
        [True, None],
        [None, None],
        [{}, None]
    ]

    for index, test_value in enumerate(test_values):
        ret_val = get_best_parsable_locale(*test_value[0])

        if ret_val != test_value[1]:
            raise AssertionError("Failed asserting that " + str(ret_val) + " == " + str(test_value[1]) + " at test case " + str(index) + ".")


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:44:07.838365
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = False
    var_0 = get_best_parsable_locale(bool_0)
    assert var_0 == "C"

# Generated at 2022-06-24 20:44:09.507500
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_cases = [
        0,
    ]
    for test_case in test_cases:
        if test_case == 0:
            test_case_0()

# Generated at 2022-06-24 20:44:14.028989
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = "min"
    var_1 = None
    var_2 = False
    var_3 = get_best_parsable_locale(var_0, var_1, var_2)
    print(var_3)
    # var_3 = 'C'


if __name__ == "__main__":
    test_case_0()
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:44:18.123121
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'


# Generated at 2022-06-24 20:44:27.916802
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

# -*- -*- -*- End included fragment: ../../test/test_get_best_parsable_locale.py -*- -*- -*-

# -*- -*- -*- Begin included fragment: ../../test/test_get_best_available_locale.py -*- -*- -*-
# pylint: disable=too-many-lines

# Generated at 2022-06-24 20:44:30.418921
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' == get_best_parsable_locale('C')

# Generated at 2022-06-24 20:45:11.167868
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Tests with assert statements
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False


if __name__ == '__main__':
    import pytest
    pytest.main(['-x', __file__])

# Generated at 2022-06-24 20:45:12.599677
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert False # TODO: implement your test here


# Generated at 2022-06-24 20:45:16.085653
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass


# Generated at 2022-06-24 20:45:18.440733
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    rc, out, err = get_best_parsable_locale('err')
    assert out == 'C'
    assert not rc
    assert err == ''
    assert err == ''


# Generated at 2022-06-24 20:45:29.723517
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # mock module for function
    module = MagicMock()

    # If a comparision fails, execute this block:
    try:
        get_best_parsable_locale(module)
    # Try block failed, execute block below
    except:
        # Try to get a failure message from the exception
        err = get_exception()
        # Compare exception text with assert message
        assert(err == "AnsibleModule object is required")

    # If a comparision fails, execute this block:
    try:
        get_best_parsable_locale(module)
    # Try block failed, execute block below
    except:
        # Try to get a failure message from the exception
        err = get_exception()
        # Compare exception text with assert message

# Generated at 2022-06-24 20:45:33.787228
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test case 0
    test_case_0()

# Test that get_best_parsable_locale doesn't crash Ansible