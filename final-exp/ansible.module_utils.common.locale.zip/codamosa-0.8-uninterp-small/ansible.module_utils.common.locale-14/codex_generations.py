

# Generated at 2022-06-24 20:35:42.711846
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    int_0 = 0
    int_1 = 1
    str_0 = get_best_parsable_locale(int_0)
    str_1 = get_best_parsable_locale(int_1)
    assert str_0 == 'C'
    assert str_1 == 'C'

# Generated at 2022-06-24 20:35:43.466042
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == 'C'

# Generated at 2022-06-24 20:35:45.730902
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_0 = 169.695
    var_0 = get_best_parsable_locale(float_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:35:48.469012
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(170) == 'C.utf8'
    assert get_best_parsable_locale(169) == 'en_US.utf8'
    assert get_best_parsable_locale(169) == 'C'

# Generated at 2022-06-24 20:35:50.445869
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test case 0
    test_case_0()
    pass



# Generated at 2022-06-24 20:35:51.588114
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() is None

# Generated at 2022-06-24 20:35:53.293971
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Run method with arguments
    assert (test_case_0() == 169.695)

# Generated at 2022-06-24 20:35:56.777483
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = ansible_module_get_best_parsable_locale()
    float_0 = 169.695
    var_0 = get_best_parsable_locale(float_0)
    assert var_0 == "C"


# Generated at 2022-06-24 20:36:03.229275
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_1 = 169.695
    var_1 = get_best_parsable_locale(float_1)
    assert var_1 == 'C'

if __name__ == "__main__":
    test_get_best_parsable_locale()
    exit(1)

# Generated at 2022-06-24 20:36:06.195825
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_0 = 169.695
    var_0 = get_best_parsable_locale(float_0)
    try:
        assert var_0 == "C"
    except AssertionError:
        # print (get_best_parsable_locale(float_0, ) )
        print("False")
        raise


if __name__ == '__main__':

    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:36:21.502544
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

# TESTS



# Generated at 2022-06-24 20:36:24.348600
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True
    # get_best_parsable_locale(module, preferences=None, raise_on_locale=False)
    assert True



# Generated at 2022-06-24 20:36:27.575767
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert('C' == get_best_parsable_locale(169.695))
    except Exception as e:
        print(e)
        raise e
    test_case_0()


# Test function for function get_best_parsable_locale

# Generated at 2022-06-24 20:36:36.050168
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(169.695) == 'C'
    assert get_best_parsable_locale({'preferences': ['C.utf8', 'en_US.utf8', 'C', 'POSIX'], 'module': ['locale']}) == 'C'
    assert get_best_parsable_locale({'preferences': ['C.utf8', 'en_US.utf8', 'C', 'POSIX'], 'module': ['locale'], 'raise_on_locale': True}) == 'C'
    assert get_best_parsable_locale() == 'C'

# Generated at 2022-06-24 20:36:38.388417
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)
    assert get_best_parsable_locale(float_0) == 'C'
    assert get_best_parsable_locale(float_0) == 'C'

# Generated at 2022-06-24 20:36:39.004467
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() is None

# Generated at 2022-06-24 20:36:40.701234
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import pytest
    import doctest

    with pytest.raises(Exception) as excinfo:
        test_case_0()
    assert excinfo.type.__name__ == 'RuntimeWarning'

# Generated at 2022-06-24 20:36:43.935251
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0()



# Generated at 2022-06-24 20:36:53.353607
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class module_mock:
        def __init__(self):
            self.get_bin_path_result = "locale"

        def get_bin_path(self, arg):
            return self.get_bin_path_result

        def run_command(self, cmd, args, check=None, binary_data=None, data=None,
                executable=None, path_prefix=None, cwd=None, raiseonerr=True,
                use_unsafe_shell=False, environ_update=None, umask=None,
                encoding=None, errors=None, text=None, log_errors=True):
            if cmd == [self.get_bin_path_result, '-a']:
                return 0, "POSIX", None
            else:
                return 1, None, None


# Generated at 2022-06-24 20:36:54.140615
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == 169.695

# Generated at 2022-06-24 20:37:16.704697
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print("Test: get_best_parsable_locale")
    print("Checking: ")
    print(get_best_parsable_locale(0, [0, 2, 3]))
    print(get_best_parsable_locale(None, [1, 2, 3]))
    print(get_best_parsable_locale(None, None))
    print(get_best_parsable_locale())
    print(get_best_parsable_locale(1))
    print(get_best_parsable_locale(1, 1))
    print(get_best_parsable_locale(1, 1, 1))


# Generated at 2022-06-24 20:37:18.302754
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(get_best_parsable_locale(17.003) == 'C')

# Generated at 2022-06-24 20:37:22.827996
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = 'C'
    var_1 = None
    var_2 = 'C'
    var_3 = False
    result = get_best_parsable_locale(var_0, var_1, var_2, var_3)


# Generated at 2022-06-24 20:37:24.371201
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_0 = 169.695
    assert get_best_parsable_locale(float_0) == 1

# Generated at 2022-06-24 20:37:26.551345
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_0 = 169.695

    # Test case 0
    assert get_best_parsable_locale(float_0)
    pass

# Generated at 2022-06-24 20:37:28.227875
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test case #0
    test_case_0()



# Generated at 2022-06-24 20:37:37.661143
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    args = []
    if __name__ == '__main__':
        args = test_get_best_parsable_locale_args()
    config = {
        "module_name": "test_get_best_parsable_locale",
        "module_path": "",
        "module_args": "",
        "wants_check_mode": False,
        "check_mode": False,
    }
    if not args:
        from ansible.module_utils.basic import AnsibleModule
        module = AnsibleModule(**config)

        module.exit_json(**test_case_0())
    else:
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils.pycompat24 import get_exception
        from ansible.utils.debug import debug

# Generated at 2022-06-24 20:37:42.650087
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    float_0 = 169.695
    var_0 = get_best_parsable_locale(float_0)
    assert var_0 == 'C'



# Test case for function get_best_parsable_locale

# Generated at 2022-06-24 20:37:45.813808
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test with simple values
    float_0 = 169.695
    var_0 = get_best_parsable_locale(float_0)


if __name__ == "__main__":
    test_get_best_parsable_locale()
    print("SUCCESS")

# Generated at 2022-06-24 20:37:49.958779
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert callable(get_best_parsable_locale) is True

# main()
if __name__ == '__main__':
    # Unit test for function get_best_parsable_locale
    test_get_best_parsable_locale()
    # Unit test for function test_case_0
    test_case_0()

# Generated at 2022-06-24 20:38:19.515678
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # FIXME: Could not test function: locale
    #assert test_case_0() == (0,)
    pass

# Generated at 2022-06-24 20:38:21.570747
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert float(test_case_0()) == 169.695

if __name__ == '__main__':
    print(test_get_best_parsable_locale())

# Generated at 2022-06-24 20:38:23.611084
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == ("success")

# Test runtime
if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:38:25.148051
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_0 = 169.695
    assert_equals(get_best_parsable_locale(169.695), float_0)

# Generated at 2022-06-24 20:38:26.973948
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:38:30.678137
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale), "get_best_parsable_locale is not a function"
    result = get_best_parsable_locale(test_case_0)
    assert result == test_case_0

# Generated at 2022-06-24 20:38:33.078883
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(get_best_parsable_locale('C') == 'C')


# Generated at 2022-06-24 20:38:34.155494
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:38:35.034531
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == 169

# Generated at 2022-06-24 20:38:36.256597
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        testcase_0()
    except Exception:
        print("Exception")

# Generated at 2022-06-24 20:39:04.157767
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0()

# Generated at 2022-06-24 20:39:14.239522
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-24 20:39:17.023627
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(test_case_0) == 'C'

# Generated at 2022-06-24 20:39:19.289274
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == 0.0

# Generated at 2022-06-24 20:39:21.887846
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test case 0
    test_case_0()

# Generated at 2022-06-24 20:39:22.841962
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert var_0 == 169.695

# Generated at 2022-06-24 20:39:25.411241
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(get_best_parsable_locale() == 'C')

# Generated at 2022-06-24 20:39:26.491775
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test cases
    test_case_0()

# Generated at 2022-06-24 20:39:33.074449
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Testing function get_best_parsable_locale
    float_0 = 169.695
    var_0 = get_best_parsable_locale(float_0)
    assert var_0 == 'C', "Error in get_best_parsable_locale(), expected %s, got %s" % ('C', var_0)
    print('test_get_best_parsable_locale passed')

#tests run
test_get_best_parsable_locale()

# Generated at 2022-06-24 20:39:37.446679
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict()
    )

    assert get_best_parsable_locale(module) == 'C', 'assertion should have been True, but was not'


# Generated at 2022-06-24 20:40:06.959469
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_0 = 169.695
    var_0 = get_best_parsable_locale(float_0)
    assert var_0 == 'C'


# Generated at 2022-06-24 20:40:08.737983
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Call function get_best_parsable_locale with arguments: True, None and True
    test_case_0()


# Generated at 2022-06-24 20:40:10.136615
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except Exception as e:
        print(e)


# Generated at 2022-06-24 20:40:12.817453
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'

# Generated at 2022-06-24 20:40:17.613994
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    raise Exception("Not implemented")

# Generated at 2022-06-24 20:40:18.391740
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == "C"

# Generated at 2022-06-24 20:40:18.989731
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass # Nothing to test



# Generated at 2022-06-24 20:40:27.450744
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert ('%f' % get_best_parsable_locale(169.695, ['C.utf8']) == '169.695000')
    assert ('%f' % get_best_parsable_locale(169.695, ['en_US.utf8']) == '169.695000')
    assert ('%f' % get_best_parsable_locale(169.695, ['C']) == '169.695000')
    assert ('%f' % get_best_parsable_locale(169.695, ['POSIX']) == '169.695000')
    assert get_best_parsable_locale(169.695, ['test']) == 'C'

# Generated at 2022-06-24 20:40:32.860000
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    int_0 = 169
    var_0 = get_best_parsable_locale(int_0)
    assert var_0 == 'C'


# Generated at 2022-06-24 20:40:38.026765
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert True
    # Test raises TypeError
    with pytest.raises(TypeError):
        test_case_0()


# main() calls the above functions with interesting inputs,
# using the standard Python sys.argv[] list of arguments
if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:41:10.594220
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(169.695) == 'C'
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-24 20:41:12.219137
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(169.695) == "C.utf8"

# Generated at 2022-06-24 20:41:14.444657
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_0 = 169.695

    # Testing if the function returns the correct output
    assert get_best_parsable_locale(float_0) == 169.695

# Generated at 2022-06-24 20:41:15.197939
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == 'C'

# Generated at 2022-06-24 20:41:17.452909
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    namespace = {}

# Generated at 2022-06-24 20:41:19.048959
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    result_0 = test_case_0()

    # Assertion
    assert result_0 == True

# Generated at 2022-06-24 20:41:24.902833
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(get_best_parsable_locale(169.695) == 169.695)

# Generated at 2022-06-24 20:41:29.217617
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_0 = 169.695
    var_0 = get_best_parsable_locale(float_0)
    result = get_best_parsable_locale(float_0)
    assert result == 0.0

# Generated at 2022-06-24 20:41:34.726226
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print("#")
    # Call function get_best_parsable_locale with appropriate arguments
    get_best_parsable_locale(float_0)


if __name__ == '__main__':
    import sys,os
    test_file = os.path.basename(__file__)
    print("Running unit tests for "+ test_file)
    # run unit tests
    test_get_best_parsable_locale()
    sys.exit(0)

# Generated at 2022-06-24 20:41:39.642600
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(169.695) == 'C'

# Generated at 2022-06-24 20:42:09.914353
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)
    assert to_native(get_best_parsable_locale(test_case_0)) == to_native('C')

# Generated at 2022-06-24 20:42:13.474533
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert os.environ['HOME']
    except KeyError as err:
        print('Env. variable not set: ' + str(err))
    test_case_0()

if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:42:16.138101
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except SystemExit as e:
        raise


# Test unit for import get_best_parsable_locale

# Generated at 2022-06-24 20:42:21.346568
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)
    test_case_0()

# Generated at 2022-06-24 20:42:26.934512
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(float_0) == 169.695
    assert get_best_parsable_locale(preferences_0) == 'C.utf8'
    assert get_best_parsable_locale(float_0) == 169.695
    assert get_best_parsable_locale(preferences_1) == 'POSIX'
    assert get_best_parsable_locale(preferences_2) == 'C'
    assert get_best_parsable_locale(preferences_3) == 'en_US.utf8'
    assert get_best_parsable_locale(preferences_4) == 'POSIX'


# Generated at 2022-06-24 20:42:30.133544
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = 169.695
    var_1 = get_best_parsable_locale(var_0)
    assert var_1 == 'C'

# Generated at 2022-06-24 20:42:31.638389
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0()
# END_OF_TEST

# Generated at 2022-06-24 20:42:33.608408
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert "C" == get_best_parsable_locale(None)

if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-24 20:42:38.849264
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_cases = [
        # TODO: add test cases
    ]
    for test_case in test_cases:
        print("Running test case: " + test_case.__name__)
        test_case()

# Generated at 2022-06-24 20:42:48.706029
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print("In test_get_best_parsable_locale")
    # AssertionError: 169.695 is not an AnsibleModule (type was <class 'float'>)
    # test_case_0()
    test_float = 169.695
    print(test_float)

test_get_best_parsable_locale()


# Generated at 2022-06-24 20:43:52.793863
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_0 = 126.939
    var_0 = get_best_parsable_locale(float_0)
    print(var_0)


if __name__ == '__main__':
    # test_case_0()
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:43:54.056851
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)


# Testing with floating point

# Generated at 2022-06-24 20:43:55.755240
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(module=None) == None, 'get_best_parsable_locale returned None instead of %s' % "None"

# Generated at 2022-06-24 20:43:57.370906
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(float_0) == var_0

# Generated at 2022-06-24 20:44:02.573945
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except Exception as err:
        print(err)
        assert False, "Failed Test Cases: 0"

# Test - Execute test cases for function get_best_parsable_locale

# Generated at 2022-06-24 20:44:03.702799
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert open(float_0)
    except AssertionError:
        assert False



# Generated at 2022-06-24 20:44:11.647404
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preference = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    # Set up mock
    module = MockModule()
    module.run_command.return_value = (0, 'output', 'error')
    module.get_bin_path.return_value = 'locale'
    # Run function
    get_best_parsable_locale(module, 'C.utf8', True)
    # Check if the function ran successfully
    assert_that(get_best_parsable_locale, equal_to('C.utf8'))


# Generated at 2022-06-24 20:44:18.250693
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # If preferences is not provided, function should return default posix locale
    assert get_best_parsable_locale(float_0) == "C"

    # If preferences is not provided, function should return default posix locale
    assert get_best_parsable_locale(float_0) == "C"

    # If preferences is not provided, function should return default posix locale
    assert get_best_parsable_locale(float_0) == "C"

    # If preferences is not provided, function should return default posix locale
    assert get_best_parsable_locale(float_0) == "C"

    # If preferences is not provided, function should return default posix locale
    assert get_best_parsable_locale(float_0) == "C"

    # If preferences is not provided, function

# Generated at 2022-06-24 20:44:23.465415
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert('C' == get_best_parsable_locale(None))

if __name__ == '__main__':
    test_case_0()
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:44:25.555295
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_1 = None
    var_2 = [u'C.utf8', u'en_US.utf8', u'C', u'POSIX']
    float_0 = 169.695
    var_0 = get_best_parsable_locale(float_0, var_2)



# Generated at 2022-06-24 20:45:37.093800
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    label = 'How many programmers does it take to change a light bulb?'