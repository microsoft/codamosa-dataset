

# Generated at 2022-06-24 20:35:44.305994
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    tuple_0 = ()
    var_0 = get_best_parsable_locale(tuple_0)
    assert var_0 == 'C', "Expected: %s, but got: %s" % ('C', var_0)
    # assert not True
    # assert var_0 == 'C'
    # assert var_0 == 'C'
    # assert var_0 == 'C'
    # assert var_0 == 'C'
    # assert var_0 == 'C'


if __name__ == '__main__':
    # test_case_0()
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:35:49.239243
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test with arg value of 'get_bin_path('locale')' for param 'module'
    tuple_0 = ()
    tuple_1 = ()
    tuple_1 = (tuple_1,)
    var_1 = get_bin_path('locale')
    var_1 = type(var_1, tuple_1, tuple_0)
    tuple_1 = (var_1,)
    tuple_2 = ()
    tuple_3 = (tuple_0, tuple_1, tuple_2)
    var_2 = get_bin_path('locale')
    var_2 = type(var_2, tuple_3, tuple_2)
    tuple_3 = (var_2,)
    tuple_3 = (tuple_3,)
    var_3 = get_bin_path('locale')
    var_

# Generated at 2022-06-24 20:35:52.184580
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True


if __name__ == '__main__':
    test_case_0()
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:36:00.446525
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == 'C'
    assert get_best_parsable_locale("") == 'C'
    assert get_best_parsable_locale("", "", "") == 'C'
    assert get_best_parsable_locale("", "", "", "") == 'C'
    assert get_best_parsable_locale([], [], [], [], []) == 'C'
    assert get_best_parsable_locale("", [], [], [], []) == 'C'

# Tests to check if exceptions are raised

# Generated at 2022-06-24 20:36:02.153972
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True


# Generated at 2022-06-24 20:36:04.726176
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Assert return type
    assert isinstance(get_best_parsable_locale(module), str)

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-24 20:36:11.088080
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Set up test inputs
    # Get test function inputs
    module = AnsibleModule(argument_spec=dict(
        preferences=dict(type='list', elements='str'),
        raise_on_locale=dict(type='bool', required=True),
    ))
    # Set up test environment
    # Execute test function
    get_best_parsable_locale(module)
    # Execute test function
    get_best_parsable_locale(module)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 20:36:13.119989
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale([]) == None

# Generated at 2022-06-24 20:36:13.958748
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True


# vim: expandtab

# Generated at 2022-06-24 20:36:17.170763
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=False
    )

    # test case 0
    _test_0 = test_case_0()

# Generated at 2022-06-24 20:36:23.121127
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == 'C'

# Generated at 2022-06-24 20:36:26.566172
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test function call with all known (and unknown) arguments
    # try 1 - check, if returned best parsable locale is None
    assert get_best_parsable_locale(None) is not None, "get_best_parsable_locale() -> could not find any parsable locale"

# Generated at 2022-06-24 20:36:34.274323
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = {}
    preferences = ''
    raise_on_locale = ''

    # Test with a function
    # assert_equal(expected, get_best_parsable_locale(module, preferences, raise_on_locale))
    raise NotImplementedError()

    # Test with a class
    # assert_equal(expected, get_best_parsable_locale(module, preferences, raise_on_locale))
    raise NotImplementedError()

# Generated at 2022-06-24 20:36:36.676377
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # In case you are wondering why we have "var_0" here, this is a
    # way to differentiate the different test cases.
    test_case_0()

# Generated at 2022-06-24 20:36:42.410630
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert "C" == get_best_parsable_locale((), C=True)
    assert "C" == get_best_parsable_locale((), ['C.utf8', 'C', 'POSIX'], False)
    assert "C" == get_best_parsable_locale((), ['C.utf8', 'C', 'POSIX'], True)
    assert "POSIX" == get_best_parsable_locale(('POSIX', 'POSIX'), ['C.utf8', 'C', 'POSIX'], False)
    assert "POSIX" == get_best_parsable_locale(('POSIX', 'POSIX'), ['C.utf8', 'C', 'POSIX'], True)

# Generated at 2022-06-24 20:36:43.364997
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True

# Generated at 2022-06-24 20:36:54.402009
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # These are just tests of the test
    # This method should fail
    try:
        test_case_0()
    except Exception:
        pass

    # Test function with simple args
    tuple_1 = ()
    var_1 = get_best_parsable_locale(tuple_1)
    assert var_1 == 'C'

    # Test function with complex args
    tuple_2 = ()
    tuple_3 = ()
    var_2 = get_best_parsable_locale(tuple_2, tuple_3)
    assert var_2 == 'C'

    # Test function with simple args
    tuple_4 = ()
    var_3 = get_best_parsable_locale(tuple_4)
    assert var_3 == 'C'

    # Test function with complex args
    tuple

# Generated at 2022-06-24 20:36:59.690852
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    tuple_0 = ()
    var_0 = get_best_parsable_locale(tuple_0)
    assert (var_0 == 'C')

    tuple_1 = ()
    var_1 = get_best_parsable_locale(tuple_1, preferences={'arabic', 'afrikaans'})
    assert (var_1 == 'C')

    tuple_2 = ()
    var_2 = get_best_parsable_locale(tuple_2, raise_on_locale=True)
    assert (var_2 == 'C')



# Generated at 2022-06-24 20:37:00.873001
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale()

# Generated at 2022-06-24 20:37:02.441129
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(test_case_0()) == 'C'

# Generated at 2022-06-24 20:37:11.575857
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print("\n ********** Tests **********\n")
    print("\n ********** Start **********\n")
    print("\nCase No. 0\n")
    test_case_0()
    print("\n ********** End **********\n")

if __name__ == '__main__':
    print("\n\n")
    print("\n################################")
    print("######### Start Testing #########")
    print("################################\n")
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:37:21.914088
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert callable(get_best_parsable_locale)
    except AssertionError as e:
        raise(e)
    # Default return type test
    assert isinstance(get_best_parsable_locale(), str)
    # Default function test
    assert get_best_parsable_locale() == "C"
    # Test function 0
    try:
        assert callable(get_best_parsable_locale(tuple_0))
    except AssertionError as e:
        raise(e)
    # Default return type test
    assert isinstance(get_best_parsable_locale(tuple_0), str)
    # Test function 0

# Generated at 2022-06-24 20:37:26.169615
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    get_best_parsable_locale(module, preferences=None, raise_on_locale=False)
    """
    # Tuple replacement for __new__
    tuple_0 = ()

    # Call function
    # Output:
    var_0 = get_best_parsable_locale(tuple_0)

# Generated at 2022-06-24 20:37:29.018673
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'type' == type(get_best_parsable_locale(tuple_0)).__name__

# Testcase that checks valid parameters

# Generated at 2022-06-24 20:37:35.950271
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    collection = [
        ['abc', 'abc', 'abc'],
        ['abc', 'abc', 'abc'],
        ['abc', 'abc', 'abc'],
        ['abc', 'abc', 'abc']
    ]

    for var_0 in collection:
        for var_1 in collection:
            for var_2 in collection:
                tuple_0 = (var_0, var_1, var_2)
                result = get_best_parsable_locale(tuple_0)

                assert result == tuple_0[0]


# Generated at 2022-06-24 20:37:38.534909
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module_0 = get_best_parsable_locale(module)

# Generated at 2022-06-24 20:37:40.961275
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' == get_best_parsable_locale('tuple_0')

# Generated at 2022-06-24 20:37:42.354900
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(tuple_0) == None

test_case_0()

# Generated at 2022-06-24 20:37:47.929816
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    TEST_CASES = [
        (
            (
            ),
            {
                'preferences': None,
            },
        ),
        (
            (
            ),
            {
                'preferences': ['C.utf8', 'en_US.utf8', 'C', 'POSIX'],
            },
        ),
    ]
    for test_case, expected_result in TEST_CASES:
        actual_result = get_best_parsable_locale(*test_case)
        assert actual_result == expected_result, 'Expected: %s, Actual: %s' % (expected_result, actual_result)



# Generated at 2022-06-24 20:37:52.121430
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    tuple_0 = ()
    var_0 = get_best_parsable_locale(tuple_0)

# Generated at 2022-06-24 20:38:05.847101
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock module
    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/locale'

        def run_command(self, *args, **kwargs):
            return (0, "C fr_FR fr_FR.utf8", "")

    test_module = AnsibleModuleMock()

    # Mock the locale presence check
    import sys
    if sys.version_info[0] < 3:
        import __builtin__ as builtins
    else:
        import builtins
    builtins.__dict__['get_best_parsable_locale'] = get_best_pars

# Generated at 2022-06-24 20:38:09.257797
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    args = []
    if len(args) == 0:
        test_case_0()


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:38:13.916678
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(
        argument_spec = dict()
    )
    # Input var to set
    tuple_0 = ()
    # Output var
    var_0 = get_best_parsable_locale(tuple_0)


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:38:15.987839
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        var_0 = get_best_parsable_locale()
    except Exception as e:
        print(e)


# Generated at 2022-06-24 20:38:17.517559
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Assertion for function get_best_parsable_locale
    assert True

# Generated at 2022-06-24 20:38:21.453718
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Create an instance of class
    var_0 = ()
    # Run get_best_parsable_locale function
    print(get_best_parsable_locale(var_0))

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:38:23.505418
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    tuple_0 = ()
    var_0 = get_best_parsable_locale(tuple_0)


# Test of function get_best_parsable_locale

# Generated at 2022-06-24 20:38:29.526112
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class test_mock_module:
        def get_bin_path(self, arg_0):
            return str()

        def run_command(self, arg_0):
            return (int(), str(), str())

    tuple_1 = ()
    tuple_2 = ()
    test_mock_module_1 = test_mock_module()
    var_1 = get_best_parsable_locale(test_mock_module_1, tuple_1, tuple_2)
    assert isinstance(var_1, str)

# Generated at 2022-06-24 20:38:35.725977
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale is not None

if __name__ == '__main__':


    import sys
    import pytest

    module = AnsibleModule(
        argument_spec = dict()
    )

    print('Testing get_best_parsable_locale...')

    sys.exit(pytest.main([__file__]))

# Generated at 2022-06-24 20:38:36.577543
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == ""

# Generated at 2022-06-24 20:38:45.235924
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    tuple_0 = ()
    var_0 = get_best_parsable_locale(tuple_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:38:46.343194
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # it should return a string
    assert type(get_best_parsable_locale(0)) == str

# Generated at 2022-06-24 20:38:57.425354
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    for pref in [
        ('eN_us', ('en_US', ), ('en_US', )),
        ('c.utf8', ('c.utf8', ), ('c.utf8', )),
        ('c', ('c', 'en_US'), ('c', 'en_US', 'c.utf8')),
    ]:
        # Test the function get_best_parsable_locale with preferences passed
        # by the caller

        # Setup the test fixture
        arg_0 = pref[1]

        # Invoke the function with the test fixture as input
        var_0 = get_best_parsable_locale(arg_0)

        # Verify the expected results
        if var_0 != pref[0]:
            raise AssertionError("Unexpected locale: %s" % var_0)

        module_

# Generated at 2022-06-24 20:39:01.023820
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # AssertionError: <'C'> != <'C.utf8'>
    tuple_0 = ()
    var_0 = get_best_parsable_locale(tuple_0)
    assert var_0 == 'C.utf8'

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 20:39:02.660372
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# ----------------------------------------------------

# Utility for testing, omit for distribution

# Generated at 2022-06-24 20:39:04.900755
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    tuple_0 = ()
    var_0 = get_best_parsable_locale(tuple_0)
    assert 'C' == var_0


# Generated at 2022-06-24 20:39:10.949020
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    ansible_module = basic.AnsibleModule(argument_spec={'preferences':{'type':'list'}})
    result = get_best_parsable_locale(ansible_module, [], False)
    assert result == 'C'

# Generated at 2022-06-24 20:39:12.434578
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)
    assert (not False)
    assert (not type(False) is int)

# Generated at 2022-06-24 20:39:18.120900
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    mod_0 = get_best_parsable_locale()
    assert isinstance(mod_0, str) == True

    mod_1 = get_best_parsable_locale(tuple_0)
    assert mod_1 == 'C'

    mod_2 = get_best_parsable_locale(tuple_0, ['C'])
    assert mod_2 == 'C'

# Generated at 2022-06-24 20:39:19.033489
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert not get_best_parsable_locale(tuple_0)

# Generated at 2022-06-24 20:39:38.331293
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    args = []
    if len(args) == 2:
        test_case_0()
        # assert False # TODO: implement your test here
    elif len(args) == 3:
        test_case_3()
        # assert False # TODO: implement your test here



# Generated at 2022-06-24 20:39:41.961130
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == None, "get_best_parsable_locale() did not return expected value."

if __name__ == '__main__':
    print(test_get_best_parsable_locale.__doc__)
    print(test_get_best_parsable_locale())

# Generated at 2022-06-24 20:39:44.257472
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    args = ((), 'C')
    assert get_best_parsable_locale(*args) == 'C'

if __name__ == '__name__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:39:47.891788
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test the first case
    try:
        test_case_0()
    except Exception:
        print('Failure in test_case_0()')
        raise


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:39:48.550634
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

# Generated at 2022-06-24 20:39:52.347112
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_cases = [
        {
            'inputs': [{'module': {}}],
            'assertEqual': "C"
        }

    ]
    for test_case in test_cases:
        assert test_case['assertEqual'] == get_best_parsable_locale(*test_case['inputs'])

# Generated at 2022-06-24 20:39:56.641568
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert 'C' == get_best_parsable_locale(test_case_0())
    except (AssertionError, TypeError) as e:
        print(e)
        return False
    else:
        return True


if __name__ == '__main__':
    # print(get_best_parsable_locale())
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:40:05.638545
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    for entry, expected_output in test_cases.items():
        with mock.patch.object(ansible.module_utils, 'basic.AnsibleModule', return_value=entry) as basic_module, mock.patch('ansible.module_utils.common._locales.get_best_parsable_locale') as get_best_parsable_locale, mock.patch.object(ansible.module_utils.basic, 'AnsibleModule.run_command', return_value=(0, '', '')):
            get_best_parsable_locale.return_value = expected_output
            assert get_best_parsable_locale() == expected_output

# Generated at 2022-06-24 20:40:12.047366
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        # Define a dictionary for the return values
        ret_vals = dict()

        # Call the function
        ret_vals['value'] = get_best_parsable_locale(module=None)

        # Return a boolean failure
        assert False
    except AssertionError:
    # Return a boolean success
        pass



# Generated at 2022-06-24 20:40:18.543298
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()


if __name__ == '__main__':
    import pytest
    pytest.main(['-x', "test_gettext_utils.py"])

# Generated at 2022-06-24 20:40:43.151039
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    #
    # Test the trivial case
    #
    tuple_0 = ()
    var_0 = get_best_parsable_locale(tuple_0)

    if var_0 != 'C':
        print('expected: %s, got %s' % 'C', var_0)
        assert False

    #
    # Test the case where the algorithm doesn't find a match
    #
    tuple_1 = ()
    var_1 = get_best_parsable_locale(tuple_1, ['en_NZ.utf8', 'en_IN.utf8', 'en_GB.utf8'])

    if var_1 != 'C':
        print('expected: %s, got %s' % 'C', var_1)
        assert False

    #
    # Test the case where the algorithm finds a

# Generated at 2022-06-24 20:40:44.564635
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' in get_best_parsable_locale(arg_0_0)

# Generated at 2022-06-24 20:40:54.632946
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    tuple_0 = ()
    var_0 = get_best_parsable_locale(tuple_0)
    str_1 = str(var_0)
    assert str_1 == ''
    tuple_2 = ()
    var_2 = get_best_parsable_locale(tuple_2)
    str_3 = str(var_2)
    assert str_3 == ''
    tuple_4 = ()
    str_5 = "C"
    var_4 = get_best_parsable_locale(tuple_4, str_5)
    str_6 = str(var_4)
    assert str_6 == ''
    tuple_7 = ()
    str_8 = "C"

# Generated at 2022-06-24 20:40:55.896219
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == (None)

# Generated at 2022-06-24 20:40:56.968782
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale().__class__.__name__ == 'str'

# Generated at 2022-06-24 20:41:02.404690
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test Cases for function get_best_parsable_locale
    assert test_case_0() == 'C'

# Generated at 2022-06-24 20:41:06.691228
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    with pytest.raises(RuntimeWarning):
        get_best_parsable_locale(tuple_0)


# Test for function get_best_parsable_locale
# Test for function get_best_parsable_locale
# Test for function get_best_parsable_locale

# Generated at 2022-06-24 20:41:09.409660
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(
        {'get_bin_path': lambda *args: None}
    ) == 'C'



# Generated at 2022-06-24 20:41:15.555364
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    tuple_0 = ()
    preferences_0 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    # Call function get_best_parsable_locale with arguments:
    # tuple_0, preferences=preferences_0
    # The arguments for the method are:
    # self, module, preferences=None, raise_on_locale=False
    # assertEqual(type(result) == <type 'str'>, True, 'Not a str')
    assert True == True # TODO: implement your test here


# Generated at 2022-06-24 20:41:16.353228
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True


# Generated at 2022-06-24 20:41:51.393764
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' == get_best_parsable_locale(tuple_0)
    assert 'C' == get_best_parsable_locale(tuple_0, raise_on_locale=True)
    assert 'C' == get_best_parsable_locale(tuple_0, preferences=None, raise_on_locale=True)

# Generated at 2022-06-24 20:41:56.893863
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(),
    )

    tuple_0 = ()
    var_0 = get_best_parsable_locale(module, tuple_0)
    assert var_0 == 'C'

    tuple_1 = ()
    var_1 = get_best_parsable_locale(module, tuple_1)
    assert var_1 == 'C'

# Generated at 2022-06-24 20:42:03.951090
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    tuple_0 = ()
    var_0 = get_best_parsable_locale(tuple_0)
    test_case_0()
    test_case_0()

# Local Variables:
# compile-command: "cd ../../..; pytest -s tests/unit/module_utils/misc/test_misc.py"
# End:

# Generated at 2022-06-24 20:42:08.559626
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)



# Generated at 2022-06-24 20:42:11.135266
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_0 = function_0()
    assert test_0 == ('C'), "Function get_best_parsable_locale returned unexpected value"

# vim: et ts=4 sw=4

# Generated at 2022-06-24 20:42:15.330699
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True



# Generated at 2022-06-24 20:42:17.553653
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Case 0
    try:
        test_case_0()
    except RuntimeWarning as e:
        print(e)
    except Exception as e:
        print(e)

# Generated at 2022-06-24 20:42:26.854782
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Assertions
    tuple_0 = ()
    var_0 = get_best_parsable_locale(tuple_0)
    assert var_0 != None, 'Unable to assert get_best_parsable_locale return is not None.'
    assert var_0 == "C", 'Unable to assert get_best_parsable_locale return is equal to "C".'
    assert id(var_0) == id("C"), 'Unable to assert get_best_parsable_locale returned value is the same as "C".'
    tuple_1 = ()
    var_1 = get_best_parsable_locale(tuple_1)
    assert var_1 != None, 'Unable to assert get_best_parsable_locale return is not None.'
    assert var_1

# Generated at 2022-06-24 20:42:27.470879
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True



# Generated at 2022-06-24 20:42:30.294457
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = ()
    var_0 = get_best_parsable_locale(var_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:43:00.450310
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Change to case_0
    test_case_0()


# Generated at 2022-06-24 20:43:01.628641
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == 'C'

# Generated at 2022-06-24 20:43:06.335358
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print('Getting best parsable locale for output in English')
    print('Default test case')
    print(get_best_parsable_locale(None))

# Generated at 2022-06-24 20:43:08.505516
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    tuple_0 = ()
    var_0 = get_best_parsable_locale(tuple_0)

# Generated at 2022-06-24 20:43:13.528490
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(tuple_0) == 'C'
    assert get_best_parsable_locale(tuple_0, preferences=None) == 'C'
    assert get_best_parsable_locale(tuple_0, preferences=None, raise_on_locale=False) == 'C'
    assert get_best_parsable_locale(tuple_0, preferences=None, raise_on_locale=True) == 'C'

# Generated at 2022-06-24 20:43:19.519212
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    out, err = capsys.readouterr()
    assert out == """C.utf8\nen_US.utf8\nC\nPOSIX\n"""
    assert err == ""
    assert var_0 == """C.utf8"""


# Generated at 2022-06-24 20:43:21.696326
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # The function call to get_best_parsable_locale()
    # with arguments: ((None, None, None))
    try:
        test_case_0()
    except NameError:
        pass

# Generated at 2022-06-24 20:43:22.396200
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Make sure the function behaves correctly for multiple inputs
    pass

# Generated at 2022-06-24 20:43:26.218149
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-24 20:43:27.569093
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)
    

# Generated at 2022-06-24 20:44:07.737543
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    tuple_0 = ()
    var_0 = get_best_parsable_locale(tuple_0)
    assert var_0 == 'C'
    tuple_0 = ('C.utf8',)
    var_0 = get_best_parsable_locale(tuple_0)
    assert var_0 == 'C.utf8'
    tuple_0 = ('C.utf8', 'en_US.utf8', 'C', 'POSIX')
    var_0 = get_best_parsable_locale(tuple_0)
    assert var_0 == 'C.utf8'
    tuple_0 = ('C.utf8', 'en_US.utf8', 'POSIX')
    var_0 = get_best_parsable_locale(tuple_0)
    assert var_

# Generated at 2022-06-24 20:44:09.133731
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    tuple_1 = ()
    var_1 = get_best_parsable_locale(tuple_1)
    assert var_1 == 'C'

# Generated at 2022-06-24 20:44:10.514035
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_0 = False
    try:
        test_case_0()
    except:
        test_0 = True
    assert test_0

# Generated at 2022-06-24 20:44:11.647337
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale("tuple_0") == "C"

# Generated at 2022-06-24 20:44:13.375972
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
  tuple_0 = ()
  var_0 = get_best_parsable_locale(tuple_0)
  assert var_0 == 'C'

# Generated at 2022-06-24 20:44:22.681188
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # This is a basic functional test that uses a mock module object to call get_best_parsable_locale.
    # If the function raises an exception, the test fails.
    fixtures = [
        (

        ),
    ]

    # These are the expected return values of the mocks invoked by this test.
    results = [
        'C',
    ]

    # This executes the test.
    for fixture, expected in zip(fixtures, results):
        print()
        print('test_get_best_parsable_locale() - fixture:', fixture)
        print('test_get_best_parsable_locale() - expected:', expected)
        actual = get_best_parsable_locale(*fixture)
        print('test_get_best_parsable_locale() - actual:', actual)

# Generated at 2022-06-24 20:44:27.018028
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Check docstring examples and then test with pytest
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    if __name__ == "__main__":
        pytest.main([__file__])

# Generated at 2022-06-24 20:44:30.459820
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Check the default values for the function
    assert get_best_parsable_locale() == "C"

    # Check simple cases with no arguments
    assert get_best_parsable_locale(None) == "C"

    # Check simple case with one argument and no additional keyword arguments
    assert get_best_parsable_locale(None) == "C"

    # Check simple case with multiple arguments and additional keyword arguments
    assert get_best_parsable_locale(None) == "C"

# Generated at 2022-06-24 20:44:39.386135
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible_collections.community.general.plugins.module_utils.i18n import I18nModule
    tuple_0 = ()
    tuple_1 = ()
    var_0 = get_best_parsable_locale(tuple_0, tuple_1)
    assert var_0 == "C"
    module = I18nModule(test=True)
    module.run_command = lambda x: (0, "C", "")
    module.get_bin_path = lambda x: True
    var_0 = get_best_parsable_locale(module)
    assert var_0 == "C"
    tuple_0 = ()
    tuple_1 = ()
    var_0 = get_best_parsable_locale(tuple_0, tuple_1)

# Generated at 2022-06-24 20:44:46.240010
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Replace the following values with actual values
    input_0 = None
    input_1 = None
    input_2 = None
    expected_output = None
    output = get_best_parsable_locale(input_0, input_1, input_2)
    assert output == expected_output, "Expected output '%s' not found" % output



# Generated at 2022-06-24 20:45:23.144094
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale == test_case_0

# ansible/module_utils/basic.py:1914

# Generated at 2022-06-24 20:45:32.438483
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = MagicMock(name='module')
    assert get_best_parsable_locale(module) == 'C'
    module.get_bin_path.assert_called_once_with('locale')
    assert get_best_parsable_locale(module, ['en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, ['en_US.utf8'], True) == 'en_US.utf8'
    # should not be called as first one should be found
    assert get_best_parsable_locale(module, ['en_US']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, ['en_GB']) == 'C'
    module.run_command