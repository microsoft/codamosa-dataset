

# Generated at 2022-06-24 20:35:43.637608
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Condition 1: args['boolean'] is False
    bool_0 = True  # set condition for bool_0
    var_0 = get_best_parsable_locale(bool_0)
    assert var_0 is not None, "unit test failed"
    # Condition 2: args['boolean'] is True
    bool_0 = False  # set condition for bool_0
    var_0 = get_best_parsable_locale(bool_0)
    assert var_0 is not None, "unit test failed"

# Generated at 2022-06-24 20:35:44.101887
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True

# Generated at 2022-06-24 20:35:45.260376
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert not test_case_0
    assert callable(get_best_parsable_locale)

# Generated at 2022-06-24 20:35:46.440659
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert "C" == get_best_parsable_locale(False)

# Generated at 2022-06-24 20:35:50.100243
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # If called with explicit arguments
    assert test_case_0()

    # If called with no arguments
    assert test_case_0()



# Generated at 2022-06-24 20:35:55.691377
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = False
    var_0 = get_best_parsable_locale(bool_0)
    var_1 = get_best_parsable_locale(bool_0, raise_on_locale=True)
    var_2 = get_best_parsable_locale(bool_0, preferences=['C', 'C.utf8'])

# Generated at 2022-06-24 20:35:56.733010
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert False == False # implemented

# Generated at 2022-06-24 20:36:00.710660
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert test_case_0() == None
    except:
        raise AssertionError("Assertion Failed in test_case_0()")

# Generated at 2022-06-24 20:36:02.319580
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert isinstance(test_case_0(), str)

# Generated at 2022-06-24 20:36:06.108704
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = ['ASDF', 'C', 'POSIX']
    var_1 = get_best_parsable_locale('ASDF', var_0)
    print('Locale: ' + var_1)


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:36:15.139972
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Testing for best and worst locale conditions
    assert get_best_parsable_locale(['C', 'POSIX', 'en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(['asdfgh_BV.asdf', 'asdfgh_ij.asdf']) == 'C'

    test_case_0()

# Generated at 2022-06-24 20:36:18.921529
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True is not False, "False is not true"


# end of test_get_best_parsable_locale

# Generated at 2022-06-24 20:36:21.502031
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True


# Generated at 2022-06-24 20:36:22.705668
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert isinstance(bool_0, bool)
    assert isinstance(var_0, str)

# Generated at 2022-06-24 20:36:23.756183
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(test_case_0) == 'C'

# Generated at 2022-06-24 20:36:24.761037
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # From test/units/modules/utils/test_module_utils_basic.py
    test_case_0()

# Generated at 2022-06-24 20:36:31.597784
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = False
    var_0 = get_best_parsable_locale(bool_0)
    bool_0 = True
    var_0 = get_best_parsable_locale(bool_0)
    bool_0 = False
    var_0 = get_best_parsable_locale(bool_0, True)
    bool_0 = True
    var_0 = get_best_parsable_locale(bool_0, True)
    bool_0 = False
    var_0 = get_best_parsable_locale(bool_0, False)
    bool_0 = True
    var_0 = get_best_parsable_locale(bool_0, False)
    bool_0 = False

# Generated at 2022-06-24 20:36:36.532713
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = False
    var_0 = get_best_parsable_locale(bool_0)
    assert bool_0 is False, "bool_0 is False"
    assert var_0 == "C", "var_0 == 'C'"

# Generated at 2022-06-24 20:36:42.671856
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    my_object = ansible.module_utils._text.to_native
    my_preferences = [ansible.module_utils._text.to_native]
    my_raise_on_locale = False
    assert my_object is not None, "Expected defined argument 'my_object', not None"
    assert my_preferences is not None, "Expected defined argument 'my_preferences', not None"
    assert my_raise_on_locale is not None, "Expected defined argument 'my_raise_on_locale', not None"

# Generated at 2022-06-24 20:36:45.547985
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True # created using ansible-test
    # This function is complex, the following test checks that the function returns a value
    assert test_case_0() == None

# Generated at 2022-06-24 20:36:58.094550
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_1 = False
    var_1 = get_best_parsable_locale(bool_1)
    bool_2 = False
    string_1 = 'C'
    array_0 = [string_1]
    var_2 = get_best_parsable_locale(bool_2, array_0)
    bool_3 = False
    var_3 = get_best_parsable_locale(bool_3, raise_on_locale=False)


# This is a test case for get_best_parsable_locale consists of a few different test scenarios.
test_case_0()

# Generated at 2022-06-24 20:36:59.623303
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)


# Generated at 2022-06-24 20:37:03.885951
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    testcase_0 = [
        # Testcase #0
        {
            'bool_0': False,
            'var_0': get_best_parsable_locale(bool_0),
        },
    ]

    # FIXME: Add testcases

    # Cleanup
    testcase_0[0]['var_0']

# Generated at 2022-06-24 20:37:04.840312
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(test_case_0) == "C"

# Generated at 2022-06-24 20:37:05.628387
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == False

# Generated at 2022-06-24 20:37:06.127301
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True

# Generated at 2022-06-24 20:37:07.264952
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    last_result = test_case_0()
    print(last_result)

# Generated at 2022-06-24 20:37:11.749579
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module_mock = MagicMock()

    assert(str(get_best_parsable_locale(module_mock)) is not None)
    assert(str(get_best_parsable_locale(module_mock)) is not None)
    assert(get_best_parsable_locale(module_mock).__class__.__name__ is str)

# Generated at 2022-06-24 20:37:12.661630
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test case 0
    test_case_0()

# Generated at 2022-06-24 20:37:13.192806
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

# Generated at 2022-06-24 20:37:31.233883
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Setupboolean
    bool_0 = False

    # Setupvar
    var_0 = get_best_parsable_locale(bool_0)

    # Assertions
    assert var_0 == 'C'
    assert var_0 == 'C'

# Generated at 2022-06-24 20:37:32.751210
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)

# Generated at 2022-06-24 20:37:40.373305
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(False, None, False) == 'C'

    assert get_best_parsable_locale(False, ['C.utf8'], False) == 'C.utf8'

    assert get_best_parsable_locale(False, ['en_US.utf8', 'C.utf8'], False) == 'en_US.utf8'

    assert get_best_parsable_locale(False, ['en_US.utf8', 'C.utf8', 'C'], False) == 'en_US.utf8'

    assert get_best_parsable_locale(False, ['en_US.utf8', 'C.utf8', 'C', 'POSIX'], False) == 'en_US.utf8'

    assert get_best_p

# Generated at 2022-06-24 20:37:42.310356
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale) == True
    assert isinstance(get_best_parsable_locale(True), str) == True
    assert get_best_parsable_locale(True) == 'C'

# Generated at 2022-06-24 20:37:43.440059
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)

# Generated at 2022-06-24 20:37:47.372746
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True
    #assert var_0 == 'C'

# Generated at 2022-06-24 20:37:49.712235
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Input parameters
    bool_0 = False

    # Act
    var_0 = get_best_parsable_locale(bool_0)

    # Assert
    assert var_0 == 'C'

# Generated at 2022-06-24 20:37:52.736035
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True

# Unit test to verify if we raise an exception or fail_json when we don't find
# locale binary

# Generated at 2022-06-24 20:37:57.819623
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(True) == 'C'
    assert get_best_parsable_locale(True) == 'C'
    assert get_best_parsable_locale(True) == 'C'

# Generated at 2022-06-24 20:37:58.634422
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:38:30.677137
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    cur_func = test_get_best_parsable_locale.__name__ + '()'
    print('\n## Begin %s' % cur_func)
    print('\n## End %s' % cur_func)


# Generated at 2022-06-24 20:38:32.005540
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == 'C'

# Generated at 2022-06-24 20:38:34.706614
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test case for function get_best_parsable_locale
    bool_0 = False
    var_0 = get_best_parsable_locale(bool_0)

# Generated at 2022-06-24 20:38:35.599132
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0()



# Generated at 2022-06-24 20:38:37.969129
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # should fail
    try:
        test_case_0()
        failed=True
    except RuntimeWarning:
        failed=False
        pass
    assert not failed




# Generated at 2022-06-24 20:38:40.827029
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    with pytest.raises(RuntimeWarning) as excinfo:
        assert get_best_parsable_locale(bool_0)
    the_exception = excinfo.value

# Generated at 2022-06-24 20:38:45.667431
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Set up the arguments that the function will be called with.

    # Perform the call, and check the result.
    test_case_0()


# Generated at 2022-06-24 20:38:47.919125
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = True
    var_1 = [""]
    var_2 = False
    func_0 = get_best_parsable_locale(var_0,var_1,var_2)
    assert func_0 == "C"


# Generated at 2022-06-24 20:38:55.789702
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == True
    assert get_best_parsable_locale() == True
    assert get_best_parsable_locale() == True
    assert get_best_parsable_locale() == True
    assert get_best_parsable_locale() == True
    assert get_best_parsable_locale() == True
    assert get_best_parsable_locale() == True
    assert get_best_parsable_locale() == True
    assert get_best_parsable_locale() == True
    assert get_best_parsable_locale() == True
    assert get_best_parsable_locale() == True
    assert get_best_parsable_locale() == True
    assert get_best_p

# Generated at 2022-06-24 20:39:04.102958
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    var_1 = get_best_parsable_locale(preferences)
    try:
        var_2 = get_best_parsable_locale(True)
        print(var_2)
    except RuntimeWarning as e:
        print(e)
    try:
        var_3 = get_best_parsable_locale(False)
        print(var_3)
    except RuntimeWarning as e:
        print(e)
    var_4 = get_best_parsable_locale(preferences, raise_on_locale=True)

# Generated at 2022-06-24 20:40:10.109799
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    int_0 = 1
    str_0 = 'C'
    int_1 = 1
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
   

# Generated at 2022-06-24 20:40:13.470943
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Assert get_best_parsable_locale raises "TypeError"
    # on invalid input
    try:
        test_case_0()
        assert(False)
    except RuntimeWarning:
        assert(True)

# Generated at 2022-06-24 20:40:16.771994
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)
    test_case_0()

# Generated at 2022-06-24 20:40:17.634911
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == False

# Generated at 2022-06-24 20:40:18.978561
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(bool_0) == var_0

# Generated at 2022-06-24 20:40:22.919056
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Verify setting the default locale to en_US.
    assert get_best_parsable_locale(bool()).casefold() == 'C'.casefold()


if __name__ == '__main__':
    # Unit test for function get_best_parsable_locale
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:40:25.850379
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Call the function
    # assert get_best_parsable_locale() ==
    test_case_0()


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:40:29.560414
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(True) == 0

if __name__ == '__main__':
    print('Running Unit Tests')


# vim: ai et ts=4 sw=4 sts=4 ft=python

# Generated at 2022-06-24 20:40:30.457362
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True



# Generated at 2022-06-24 20:40:34.182021
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    function_name = "get_best_parsable_locale"
    preferences = None
    raise_on_locale = False
    module = AnsibleModule(argument_spec={})
    assert (get_best_parsable_locale(module, preferences, raise_on_locale) == 'C')

# Generated at 2022-06-24 20:41:34.784960
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert(get_best_parsable_locale(test_case_0) == 'C')
    except AssertionError:
        print("Failed Assertion: ", get_best_parsable_locale(test_case_0))
    assert(True)

if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:41:41.086880
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('arg_0') == 'C'
    assert get_best_parsable_locale('arg_1') == 'C'
    assert get_best_parsable_locale('arg_2') == 'C'

# Generated at 2022-06-24 20:41:42.652590
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # check whether the function can be called without error
    assert callable(get_best_parsable_locale)

# Generated at 2022-06-24 20:41:46.985316
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert not False
    
    


# Generated at 2022-06-24 20:41:55.115716
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # No exception raised
    assert get_best_parsable_locale(test_case_0(), None, True) == "C"
    # No exception raised
    assert get_best_parsable_locale(test_case_0(), ["C"], True) == "C"
    # No exception raised
    assert get_best_parsable_locale(test_case_0(), ["C.utf8", "en_US.utf8", "C", "POSIX"], True) == "C"

# Generated at 2022-06-24 20:41:57.914566
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale != "", "AnsibleException"
    assert get_best_parsable_locale != "", "AnsibleException"
    assert get_best_parsable_locale != "", "AnsibleException"

# Generated at 2022-06-24 20:42:04.907369
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = None
    var_1 = []
    var_2 = False
    var_0 = get_best_parsable_locale(var_1, var_2)
    assert var_0 == 'C'
    # assert var_0 == 'POSIX'
    # assert var_0 == 'en_US.utf8'
    # assert var_0 == 'C.utf8'

# Generated at 2022-06-24 20:42:12.272669
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = get_best_parsable_locale('bool_0')
    assert var_0 == 'C'
    var_1 = get_best_parsable_locale(bool_0 = 'bool_0', preferences = 'preferences_1', raise_on_locale = 'raise_on_locale_2')
    assert var_1 == 'C'

# Generated at 2022-06-24 20:42:14.137909
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert exec_function('tests.unit.common.shell.test_get_best_parsable_locale', 'test_case_0') == None

# Generated at 2022-06-24 20:42:20.679210
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import io
    import sys

    # Capture arguments
    # This is needed because the called function alters the arguments
    saved_stdout = sys.stdout
    saved_stderr = sys.stderr
    try:
        out_buff = io.StringIO()
        err_buff = io.StringIO()
        sys.stdout = out_buff
        sys.stderr = err_buff

        test_case_0()
    finally:
        sys.stdout = saved_stdout
        sys.stderr = saved_stderr


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:43:19.684439
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == False, "test not implemented"

# Generated at 2022-06-24 20:43:21.583010
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # TODO: unit test for function get_best_parsable_locale
    pass


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:43:24.231567
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # assert(get_best_parsable_locale(bool_0) == var_0);

    # How do I test this?
    failed = False
    try:
        get_best_parsable_locale(None)
    except RuntimeWarning:
        failed = True
    assert(failed)

# Generated at 2022-06-24 20:43:33.141917
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = 'C'
    assert get_best_parsable_locale(var_0, None) == var_0
    var_0 = 'C'
    var_1 = ['C', 'a']
    assert get_best_parsable_locale(var_0, var_1) == var_0
    var_0 = 'C'
    var_1 = []
    assert get_best_parsable_locale(var_0, var_1) == var_0


if __name__ == '__main__':
    test_case_0()
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:43:35.347305
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert isinstance(test_case_0(), str)

if __name__ == '__main__':
    import pytest
    pytest.main(['-x', __file__])

# Generated at 2022-06-24 20:43:37.993198
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = False
    var_1 = None
    var_2 = False
    var_3 = get_best_parsable_locale(var_0, var_1, var_2)
    print(var_3)

# Generated at 2022-06-24 20:43:43.252678
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ["non-existent"]) == 'C'
    assert get_best_parsable_locale(None, ["non-existent"], raise_on_locale=True) == 'C'
    assert get_best_parsable_locale(None, ["non-existent"], raise_on_locale=True) == 'C'

# Generated at 2022-06-24 20:43:44.181665
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

# Generated at 2022-06-24 20:43:47.779355
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_1 = False
    list_1 = [u'C.utf8', u'en_US.utf8', u'C', u'POSIX']
    var_1 = get_best_parsable_locale(bool_1, list_1)
    assert var_1 == u'C'

# Generated at 2022-06-24 20:43:50.317988
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = False
    preferences_0 = [10, 'test', -3]
    var_1 = get_best_parsable_locale(bool_0, preferences_0)
    if var_1 is not None:
        raise Exception('Failed')
    # no exception


# Generated at 2022-06-24 20:44:58.563001
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Assert False
    assert False == test_case_0()

# Test case with arguments

# Generated at 2022-06-24 20:45:01.665388
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print("Test 1 - No arguments")
    test_case_0()


# This function is used for testing

# Generated at 2022-06-24 20:45:09.975477
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_1 = False
    # Test from the default case
    assert(not get_best_parsable_locale(bool_1))

if __name__ == '__main__':
    print("=======================")
    print("START test_get_best_parsable_locale.py")
    print("=======================")
    print("=======================")
    print("test_case_0()")
    print("=======================")
    test_case_0()
    print("=======================")
    print("test_get_best_parsable_locale()")
    print("=======================")
    test_get_best_parsable_locale()
    print("=======================")
    print("END test_get_best_parsable_locale.py")

# Generated at 2022-06-24 20:45:11.644462
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('var_0') == 'C.utf8'

# Generated at 2022-06-24 20:45:20.529557
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # mock locale command
    # locale -a | head -1
    assert get_best_parsable_locale(["locale", "-a"],
                                    ["C.utf8", "en_US.utf8", "C", "POSIX"], False) == "C"
    # mock locale command
    # locale -a | head -1
    assert get_best_parsable_locale(["locale", "-a"], None, False) == "C"
    # mock locale command
    # locale -a | head -1
    assert get_best_parsable_locale(["locale", "-a"],
                                    ["fr_FR.utf8", "en_US.utf8", "C", "POSIX"], False) == "fr_FR.utf8"
    # mock locale command
    # locale -a | head

# Generated at 2022-06-24 20:45:24.919088
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale), "Function does not exist: get_best_parsable_locale"
    assert isinstance(get_best_parsable_locale(test_case_0), str), "Return type does not match"

# Generated at 2022-06-24 20:45:29.337976
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # testing input pairs info ...

    test_pairs = [
        (
            True,  # param_0
        ),
        (
            False,  # param_0
        ),
    ]

    # testing function ...
    for test_pair in test_pairs:
        get_best_parsable_locale(*test_pair)