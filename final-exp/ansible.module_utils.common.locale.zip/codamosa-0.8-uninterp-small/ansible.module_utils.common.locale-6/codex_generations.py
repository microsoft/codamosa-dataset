

# Generated at 2022-06-24 20:35:40.223613
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        get_best_parsable_locale(list)
    except TypeError:
        assert True
    else:
        assert False

# test for function get_best_parsable_locale
# assuming that None is the best locale

# Generated at 2022-06-24 20:35:42.195915
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = [None, None, None]
    var_0 = get_best_parsable_locale(list_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:35:46.556915
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == "C"
    assert get_best_parsable_locale() == "C"
    assert get_best_parsable_locale() == "C"
    assert get_best_parsable_locale() == "C"
    assert get_best_parsable_locale() == "C"
    assert get_best_parsable_locale() == "C"


# Testing for function is_platform_sunos

# Generated at 2022-06-24 20:35:50.654275
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = None
    var_0 = get_best_parsable_locale(list_0)
    assert var_0 == 'C'


# Generated at 2022-06-24 20:35:52.237372
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)

# Generated at 2022-06-24 20:35:54.638714
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_get_best_parsable_locale.__name__ == 'test_get_best_parsable_locale'

# Generated at 2022-06-24 20:35:55.245298
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 1 == 1

# Generated at 2022-06-24 20:35:57.105819
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except Exception:
        assert False


# Generated at 2022-06-24 20:36:00.066254
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True


# Generated at 2022-06-24 20:36:01.771660
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == None

# Generated at 2022-06-24 20:36:06.074309
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    pass


# Generated at 2022-06-24 20:36:07.580965
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(list_0) == None

# Generated at 2022-06-24 20:36:09.152428
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert False # TODO: implement your test here


# Generated at 2022-06-24 20:36:10.691413
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print(get_best_parsable_locale(list_0))




# Generated at 2022-06-24 20:36:11.890653
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Placeholder for unit testing
# Not yet implemented

# Generated at 2022-06-24 20:36:13.558747
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True


# Generated at 2022-06-24 20:36:22.191216
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = None
    list_1 = None
    list_2 = None
    list_3 = None
    list_4 = None
    list_5 = None
    list_6 = None

    # Disabled, needs runtime data
    # var_0 = get_best_parsable_locale(list_0)
    # assert var_0 == ''

    # Disabled, needs runtime data
    # var_1 = get_best_parsable_locale(list_1)
    # assert var_1 == ''

    # Disabled, needs runtime data
    # var_2 = get_best_parsable_locale(list_2)
    # assert var_2 == ''

    # Disabled, needs runtime data
    # var_3 = get_best_parsable_locale(list_3)
    # assert

# Generated at 2022-06-24 20:36:23.756840
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(list) == None



# Generated at 2022-06-24 20:36:25.088876
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except:
        assert False

# Generated at 2022-06-24 20:36:26.327860
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(0)


# Generated at 2022-06-24 20:36:33.356771
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == None

# Generated at 2022-06-24 20:36:35.899936
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Testing for checking null value for input parameters
    # value for list_0 = null value
    try:
        test_case_0()
    except Exception as e:
        print("Exception in Unit testing", e)

# Generated at 2022-06-24 20:36:36.672972
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Testing argument type
    test_case_0()

# Generated at 2022-06-24 20:36:38.887566
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert "C" == get_best_parsable_locale(list_0)

# Generated at 2022-06-24 20:36:42.326108
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert ('C' == get_best_parsable_locale('C'))
        assert ('C' == get_best_parsable_locale('C', ''))
    except:
        print('test_get_best_parsable_locale assert failed')


if __name__ == '__main__':
    test_case_0()
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:36:45.440323
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = None
    assert get_best_parsable_locale(list_0) == 'C'

# Generated at 2022-06-24 20:36:51.776436
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-24 20:36:57.824457
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = None
    assert get_best_parsable_locale(list_0) == 'C'
    list_1 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX', 'en_US.utf8']
    assert get_best_parsable_locale(list_1) == 'C.utf8'
    list_2 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX', 'en_US.utf8']

# Generated at 2022-06-24 20:36:58.252161
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert False

# Generated at 2022-06-24 20:37:00.899040
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    list_1 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    var_0 = get_best_parsable_locale(list_0, list_1)
    assert len(var_0) == 2
    assert var_0 == 'C'

# Generated at 2022-06-24 20:37:15.546628
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = None
    var_0 = get_best_parsable_locale(list_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:37:21.566122
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = None
    var_0 = get_best_parsable_locale(list_0)
    list_1 = None
    list_2 = ['C']
    var_1 = get_best_parsable_locale(list_1, list_2)

# Generated at 2022-06-24 20:37:23.129228
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    res_0 = 'C'
    assert get_best_parsable_locale(None) == res_0

# Generated at 2022-06-24 20:37:23.987491
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True


# Generated at 2022-06-24 20:37:26.642561
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print("in main function for testing")
    test_case_0()

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:37:31.617222
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = None
    var_1 = None
    var_2 = False
    var_3 = get_best_parsable_locale(var_0, var_1, var_2)
    assert object(var_3) == "<class 'str'>"
    assert var_3 == 'C'

# Generated at 2022-06-24 20:37:34.463533
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # print(get_best_parsable_locale())
    test_case_0()

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:37:35.294642
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:37:43.111884
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = None
    var_0 = get_best_parsable_locale(list_0)

    list_1 = None
    var_1 = get_best_parsable_locale(list_1)

    list_2 = None
    var_2 = get_best_parsable_locale(list_2)

    assert var_0 == 'C'
    assert var_1 == 'C'
    assert var_2 == 'C'


# Generated at 2022-06-24 20:37:52.252382
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_of_preferences_0 = None
    found_0 = get_best_parsable_locale(list_of_preferences_0)
    assert found_0 == 'C'

    list_of_preferences_1 = None
    found_1 = get_best_parsable_locale(list_of_preferences_1)
    assert found_1 == 'C'

    list_of_preferences_2 = None
    found_2 = get_best_parsable_locale(list_of_preferences_2)
    assert found_2 == 'C'

    list_of_preferences_3 = None
    found_3 = get_best_parsable_locale(list_of_preferences_3)
    assert found_3 == 'C'

# Generated at 2022-06-24 20:38:07.901890
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == False # TODO: implement your test here


# Generated at 2022-06-24 20:38:09.303951
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(list_0) == None

# Generated at 2022-06-24 20:38:11.229723
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    out = get_best_parsable_locale(list_0)
    assert out == var_0

# Generated at 2022-06-24 20:38:15.610459
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['en_US', 'C', 'C.utf8']) == 'C'
    assert get_best_parsable_locale(None, ['C']) == 'C'



# Generated at 2022-06-24 20:38:24.494870
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert 'C' == get_best_parsable_locale(None)
        assert 'C' == get_best_parsable_locale(None, None)
        assert 'C' == get_best_parsable_locale(None, ['C.UTF-8', 'C.utf8', 'C'], False)
        assert 'C' == get_best_parsable_locale(None, ['C.UTF-8', 'C.utf8', 'C'], True)
        assert 'POSIX' == get_best_parsable_locale(None, ['POSIX', 'C'], False)
        assert 'POSIX' == get_best_parsable_locale(None, ['POSIX', 'C'], True)
    except Exception as e:
        print(e)


# Generated at 2022-06-24 20:38:26.634793
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale is not None

# Generated at 2022-06-24 20:38:33.036960
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    arg0 = None
    arg1 = None
    arg2 = False
    expected = None
    with pytest.raises(Exception):
        # Call the function
        actual = get_best_parsable_locale(arg0, arg1, arg2)
        assert expected == actual, 'Expected calling get_best_parsable_locale' + ' with ' + str(arg0) + str(arg1) + str(arg2) + ' to return ' + str(expected) + ' but returned ' + str(actual)

# Generated at 2022-06-24 20:38:34.326325
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-24 20:38:38.444110
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert False


# Arrange
ansible_module_instance = None
preferences = 'some string'
raise_on_locale = False

# Act
result_0 = get_best_parsable_locale(ansible_module_instance, preferences, raise_on_locale)

# Assert
print(result_0)

# Generated at 2022-06-24 20:38:47.797008
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # If a list is provided as the 2nd argument and none of the values of the
    # list is matched with the list of available locales then a value C is
    # returned
    list_0 = ['de_DE.utf8', 'en_US.utf8', 'C', 'POSIX']
    result = get_best_parsable_locale(list_0)
    assert 'C' == result, "Actual result: %s" % result

    # If a list is provided as the 2nd argument then the 1st match from the
    # list is returned if the list of available locales is empty the value C
    # is returned
    list_0 = ['en_US.utf8', 'de_DE.utf8', 'C', 'POSIX']
    result = get_best_parsable_locale(list_0)

# Generated at 2022-06-24 20:39:03.794133
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-24 20:39:10.235754
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Tests for get_best_parsable_locale

    # Test #0
    try:
        test_case_0()
    except RuntimeError as e:
        msg = e.args[0]
    assert msg == 'get_best_parsable_locale takes a module'

# Generated at 2022-06-24 20:39:16.580084
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(list_0) == 'C'
    assert get_best_parsable_locale(list_0, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True) == 'C'



# Generated at 2022-06-24 20:39:26.754954
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Testing with a list as the first argument
    list_0 = "ansible"
    var_0 = get_best_parsable_locale(list_0)

    # Testing with a string as the first argument
    list_0 = "ansible"
    var_0 = get_best_parsable_locale(list_0)

    # Testing with a tuple as the first argument
    list_0 = "ansible"
    var_0 = get_best_parsable_locale(list_0)

    # Testing with a True as the first argument
    list_0 = "ansible"
    var_0 = get_best_parsable_locale(list_0)

    # Testing with a False as the first argument
    list_0 = "ansible"
    var_0 = get_best_p

# Generated at 2022-06-24 20:39:27.854199
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() is None

# Generated at 2022-06-24 20:39:29.232197
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('list_0') == None

# Generated at 2022-06-24 20:39:32.649663
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # No exception expected
    try:
        test_case_0()
    except Exception as exc:
        assert False, f'An exception of type {exc.__class__.__name__} was raised, incorrectly.'



# Generated at 2022-06-24 20:39:33.652160
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert False == False


# Generated at 2022-06-24 20:39:42.838326
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert set(get_best_parsable_locale(list_0, List1_0)) == set(List2)
    assert set(get_best_parsable_locale(list_1, List1_1)) == set(List3)
    assert set(get_best_parsable_locale(list_2, List1_2)) == set(List4)
    assert get_best_parsable_locale(str_0) == 'C'
    assert get_best_parsable_locale(str_1) == 'C'
    assert get_best_parsable_locale(str_2) == 'C'
    assert set(get_best_parsable_locale(set_0)) == set(List0)

# Generated at 2022-06-24 20:39:50.745679
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    asserted_ansible_module = AnsibleModule(
        argument_spec = dict(
            preferences = dict(type='list',),
            raise_on_locale = dict(type='bool',),
        ),
        supports_check_mode=True
    )
    var_0 = asserted_ansible_module.params['preferences']
    var_1 = asserted_ansible_module.params['raise_on_locale']
    assert var_0 is not None
    assert var_1 is not None

    assert get_best_parsable_locale(var_0, var_1) is None

# Generated at 2022-06-24 20:40:06.425627
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True


# unit test for function get_best_parsable_locale()

# Generated at 2022-06-24 20:40:09.771461
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print(test_case_0())

if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:40:16.564203
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Mock
    class MockAnsibleModule:
        def __init__(self):
            self.params = {"preferences": {"this": "that"}, "raise_on_locale": True}

        def run_command(self, arg):
            return 0, "C.UTF-8", ""

        def fail_json(self, *args, **kwargs):
            raise Exception()

        def get_bin_path(self, arg):
            return arg

    # Assertions

    # Mock
    module = MockAnsibleModule()
    assert get_best_parsable_locale(module) == "C.UTF-8"

    # Mock
    module = MockAnsibleModule()
    assert get_best_parsable_locale(module) == "C.UTF-8"

    # Mock
    module

# Generated at 2022-06-24 20:40:17.418493
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(list_0) == var_0

# Generated at 2022-06-24 20:40:19.413895
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_1 = None
    var_1 = get_best_parsable_locale(list_1)
    print(var_1)

# Generated at 2022-06-24 20:40:20.651850
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:40:22.672494
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = None
    var_0 = get_best_parsable_locale(list_0)
    assert var_0 == 'C'


# Generated at 2022-06-24 20:40:23.765329
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True # TODO: implement your test here


# Generated at 2022-06-24 20:40:24.908488
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(list_0) == var_0

# Generated at 2022-06-24 20:40:33.402362
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)
    test_case_0()


# Tests for parsing locale tool output.
# These tests should work on all platforms, but only
# output from GNU coreutils is validated.
#
# Sample output from GNU coreutils (as of v8.24):
#
# $ locale -a
# C
# C.UTF-8
# en_US
# en_US.iso88591
# en_US.utf8
# POSIX
#
# $ LC_ALL=C.UTF-8 locale -a
# C
# C.UTF-8
# en_US
# en_US.iso88591
# en_US.utf8
# POSIX
#
# $ LC_ALL=C locale -a
# C
# POSIX


# Generated at 2022-06-24 20:40:50.800547
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(list_0) == var_0

if __name__ == '__main__':

    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:40:54.411377
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert 'C' == get_best_parsable_locale(None)
    except (AssertionError, TypeError, NameError):
        raise AssertionError('test_get_best_parsable_locale() failed')



# Generated at 2022-06-24 20:41:02.374509
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    module = basic.AnsibleModule()
    # Output from local -a

# Generated at 2022-06-24 20:41:05.615816
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    print(get_best_parsable_locale(preferences))
    # expected output: C

# Generated at 2022-06-24 20:41:14.856161
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = None
    var_0 = get_best_parsable_locale(list_0)
    list_1 = ['en_US.utf8']
    list_2 = ['en_US.utf8', 'en_US.UTF-8', 'en_US.utf-8']
    list_3 = ['en_US.utf8', 'en_US.UTF-8', 'en_US.utf-8', 'hi_IN.utf8', 'hi_IN.UTF-8', 'hi_IN.utf-8']
    list_4 = ['hi_IN.utf8', 'hi_IN.UTF-8', 'hi_IN.utf-8', 'es_MX.utf8', 'es_MX.UTF-8', 'es_MX.utf-8']

# Generated at 2022-06-24 20:41:20.552669
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-24 20:41:29.537295
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' == get_best_parsable_locale(None)
    assert 'C' == get_best_parsable_locale(None, ['en'])
    assert 'C' == get_best_parsable_locale(None, ['en', 'en_US'])
    # This is an issue fixed with Python 3.4.3
    #  -fno-semantic-interposition is a workaround to fix this
    # https://bugs.python.org/issue22257
    # assert 'C' == get_best_parsable_locale(None, ['en', 'en_US', 'C'])
    # assert 'C' == get_best_parsable_locale(None, ['en', 'en_US', 'en_US.en'])
    # assert 'C' == get

# Generated at 2022-06-24 20:41:30.467732
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert False == False


# Generated at 2022-06-24 20:41:32.738688
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    result = get_best_parsable_locale(42, 42, 42)
    assert result == 42



# Generated at 2022-06-24 20:41:37.345424
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = None
    var_0 = get_best_parsable_locale(list_0)
    assert var_0 is not None, 'Unable to get value of get_best_parsable_locale'
    assert var_0 == 'C', 'Get value of get_best_parsable_locale is not equal to C'

# Generated at 2022-06-24 20:41:53.004990
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    #assert get_best_parsable_locale() == 'C'
    print('Test get_best_parsable_locale:')
    print(get_best_parsable_locale())

# Generated at 2022-06-24 20:41:59.915029
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    arg0 = 'foo'
    arg1 = 'bar'
    arg2 = 'foo'
    arg3 = 'bar'
    arg4 = 'foo'
    arg5 = 'bar'
    arg6 = 'foo'
    arg7 = 'bar'

    # Call the function
    get_best_parsable_locale(arg0, arg1, arg2)

    try:
        get_best_parsable_locale(arg3, arg4, arg5)
    except RuntimeWarning:
        pass
    else:
        # Exception raised
        assert False

    try:
        get_best_parsable_locale(arg6, arg7, raise_on_locale=True)
    except RuntimeWarning:
        pass
    else:
        # Exception raised
        assert False



# Generated at 2022-06-24 20:42:06.590305
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert not_callable(get_best_parsable_locale)

    # test with no argument and
    # default values
    get_best_parsable_locale()

    # test with mandatory argument
    get_best_parsable_locale(list_0=True)

    # test with one of the
    # optional parameters

    # test with all of the
    # optional parameters
    get_best_parsable_locale(list_0=True, preferences='list_1', raise_on_locale=True)


# Generated at 2022-06-24 20:42:13.557259
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert 'C' == get_best_parsable_locale(None)

    assert 'C' == get_best_parsable_locale(None, ['not-a-locale'])
    assert 'C' == get_best_parsable_locale(None, ['not-a-locale'], True)

    assert 'en_US.utf8' == get_best_parsable_locale(None, ['en_US.utf8'])
    assert 'en_US.utf8' == get_best_parsable_locale(None, ['en_US.utf8'], True)



# Generated at 2022-06-24 20:42:14.417844
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True


# Generated at 2022-06-24 20:42:18.489612
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Tests for function get_best_parsable_locale
    preferences = ["en_US.UTF-8", "C", "POSIX", "en_US.utf8", "C.UTF-8", "en_US", "C.utf8"]
    test = get_best_parsable_locale(preferences)
    print(test)



# Generated at 2022-06-24 20:42:23.746027
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert(get_best_parsable_locale(list_0) == "C")
    except AssertionError as e:
        raise(e)
    except Exception as e:
        raise(e)

# Unit test execution
#test_get_best_parsable_locale()

# Generated at 2022-06-24 20:42:25.203721
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(list_0)

# Generated at 2022-06-24 20:42:27.854055
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    var_1 = get_best_parsable_locale(preferences)

# Generated at 2022-06-24 20:42:30.620059
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(list_0) == get_best_parsable_locale(list_0)

# Generated at 2022-06-24 20:42:54.900933
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(module, preferences=preferences) == 'C.utf8'
    assert get_best_parsable_locale(module, preferences=preferences) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=preferences) == 'C'
    assert get_best_parsable_locale(module, preferences=preferences) == 'POSIX'

# Generated at 2022-06-24 20:42:59.297159
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        import ansible.module_utils.basic
    except ImportError:
        print("Module ansible.module_utils.basic not found.")
        import sys
        sys.exit()

    module = ansible.module_utils.basic.AnsibleModule(argument_spec={}, supports_check_mode=True)

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:43:00.699528
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)



# Generated at 2022-06-24 20:43:10.854496
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_1 = module.get_bin_path('locale')
    var_2 = module.run_command('[locale, -a]')
    var_2.rc
    var_2.err
    var_2.out
    var_3 = (var_2.rc == 0)
    var_4 = str(var_2.rc)
    var_5 = to_native(var_2.err)
    var_6 = var_2.out
    var_7 = (var_6 == '')
    var_8 = to_native(var_2.err)
    var_9 = str(var_2.rc)
    var_10 = to_native(var_2.err)
    var_11 = str(var_2.rc)

# Generated at 2022-06-24 20:43:17.206153
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_1 = ["C.utf8", "en_US.utf8", "C", "POSIX"]
    var_1 = get_best_parsable_locale(list_1)
    assert var_1 == "C.utf8" or var_1 == "en_US.utf8" or var_1 == "C" or var_1 == "POSIX"
    list_2 = ["C.utf8", "en_US.utf8", "C", "POSIX"]
    var_2 = get_best_parsable_locale(list_2)
    assert var_2 == "C.utf8" or var_2 == "en_US.utf8" or var_2 == "C" or var_2 == "POSIX"
    # Test for a negative test case

# Generated at 2022-06-24 20:43:21.401424
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert True == True
    except AssertionError as e:
        raise(e)
    except Exception as e:
        raise(e)



# Generated at 2022-06-24 20:43:22.136095
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == None

# Generated at 2022-06-24 20:43:24.667732
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = None
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    raise_on_locale = True
    var_0 = get_best_parsable_locale(list_0,preferences,raise_on_locale)

# Generated at 2022-06-24 20:43:31.055093
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock MODULE
    class MockMODULE:
        def get_bin_path(self, argv_0=None):
            return 'posix'

        def run_command(self, argv_0=None):
            pass
    module = MockMODULE()

    with pytest.raises(TypeError):
        # Call get_best_parsable_locale()
        get_best_parsable_locale(module)

# Generated at 2022-06-24 20:43:35.546007
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = None
    var_0 = get_best_parsable_locale(list_0)


if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:43:55.751106
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test for function get_best_parsable_locale
    assert True

# Generated at 2022-06-24 20:43:56.725209
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == 'C'

# Generated at 2022-06-24 20:43:57.572502
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert test_case_0() == True

# Generated at 2022-06-24 20:44:03.215989
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = None
    var_0 = get_best_parsable_locale(list_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:44:05.869791
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        globals().pop('test_0')
    except KeyError:
        pass
    globals().update(locals())
    test_0()


# make an alias so code intel won't complain
test_get_best_parseable_locale = test_get_best_parsable_locale



# Generated at 2022-06-24 20:44:07.918685
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except Exception as e:
        print('FAILED: ' + str(e))

# Generated at 2022-06-24 20:44:09.044317
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(list_0) == None

# Generated at 2022-06-24 20:44:13.009951
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except Exception as e:
        print(str(e))
        assert False
    try:
        test_case_0()
    except Exception as e:
        print(str(e))
        assert False


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:44:17.433316
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
  assert globals()['test_case_0']() == None

# Generated at 2022-06-24 20:44:22.779129
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_1 = ["C.utf8", "en_US.utf8", "C", "POSIX"]
    var_1 = get_best_parsable_locale(list_1)

# Generated at 2022-06-24 20:45:04.805784
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert get_best_parsable_locale(list_0) == get_best_parsable_locale(list_0)
    except AssertionError:
        var_0 = get_best_parsable_locale(list_0)
        raise AssertionError(var_0)


# Generated at 2022-06-24 20:45:07.980687
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # AssertionError: ('locale command failed with rc=1', <MagicMock name='run_command()' id='140244763056752'>)
    # assert get_best_parsable_locale(module) == 'C'
    pass



# Generated at 2022-06-24 20:45:18.267997
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = None
    var_0 = get_best_parsable_locale(list_0)
    assert var_0 == 'C', "Expected %s, got %s" % ('C', var_0)

    list_1 = None
    var_1 = get_best_parsable_locale(list_1)
    assert var_1 == 'C', "Expected %s, got %s" % ('C', var_1)

    list_2 = None
    var_2 = get_best_parsable_locale(list_2)
    assert var_2 == 'C', "Expected %s, got %s" % ('C', var_2)

    list_3 = None
    var_3 = get_best_parsable_locale(list_3)
    assert var

# Generated at 2022-06-24 20:45:21.720554
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # AssertionError: found: 'C', expected: None
    assert get_best_parsable_locale(test_case_0()) == None


# Generated at 2022-06-24 20:45:24.216627
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print(get_best_parsable_locale())
    test_case_0()

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-24 20:45:31.559267
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = None
    var_0 = get_best_parsable_locale(list_0)
    list_1 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    var_1 = get_best_parsable_locale(list_0, list_1)
    list_2 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    var_2 = get_best_parsable_locale(list_0, list_1, True)


# unit test cases for function get_best_parsable_locale