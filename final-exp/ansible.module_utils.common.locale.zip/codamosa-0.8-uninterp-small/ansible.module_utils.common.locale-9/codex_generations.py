

# Generated at 2022-06-24 20:35:44.492101
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'
    var_0 = get_best_parsable_locale(str_0, str_0, str_0)
    pass

# Generated at 2022-06-24 20:35:51.001062
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Testing with a mock object
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import boolean_or_none

# Generated at 2022-06-24 20:35:53.607319
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:35:54.220025
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert var_0

# Generated at 2022-06-24 20:35:55.246364
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:35:56.682785
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == 'C.utf8'

# Generated at 2022-06-24 20:36:03.666068
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule({}, {}, supports_check_mode=True)
    ansible.module_utils.basic._ANSIBLE_ARGS = to_text(json.dumps({'ANSIBLE_MODULE_ARGS': {}}))

    assert type(module) == types.ModuleType
    assert type(module.params) == dict
    test_case_0()



# Generated at 2022-06-24 20:36:11.592519
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'
    var_0 = get_best_parsable_locale(str_0, str_0, str_0)

# Generated at 2022-06-24 20:36:21.258991
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'
    var_0 = get_best_parsable_locale(str_0, str_0, str_0)
    assert var_0 == 'C'

    var_0 = get_best_parsable_locale(str_0, str_0, str_0)
    assert var_

# Generated at 2022-06-24 20:36:30.049725
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Case 0:
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'
    var_0 = get_best_parsable_locale(str_0, str_0, str_0)

    # Case 1:

# Generated at 2022-06-24 20:36:39.543192
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    arg_0 = ['path', 'path', 'path']
    arg_1 = ['state', 'state', 'state']
    arg_2 = ['absent', 'directory', 'file']
    #result = get_best_parsable_locale(arg_0, arg_1, arg_2)
    result = get_best_parsable_locale()
    assert result == 'C'

# Generated at 2022-06-24 20:36:39.972846
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass


# Generated at 2022-06-24 20:36:49.122965
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '\nUnable to get locale information, rc=1: locale: cannot set LC_CTYPE to default locale: No such file or directory\nlocale: cannot set LC_MESSAGES to default locale: No such file or directory\nlocale: cannot set LC_ALL to default locale: No such file or directory\n\n'
    var_0 = get_best_parsable_locale(str_0, str_0, str_0)



# Generated at 2022-06-24 20:36:56.229148
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'
    var_0 = get_best_parsable_locale(str_0, str_0, str_0)
    assert var_0 == 'C'


# Generated at 2022-06-24 20:37:05.070306
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'
    var_0 = get_best_parsable_locale(str_0, str_0, str_0)

# Generated at 2022-06-24 20:37:05.898468
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert var_0 == 'C'

# Generated at 2022-06-24 20:37:06.702937
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == 'C'

# Generated at 2022-06-24 20:37:08.307412
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except RuntimeWarning:
        pass
    else:
        assert False

# Generated at 2022-06-24 20:37:18.627485
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'

# Generated at 2022-06-24 20:37:21.448777
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = get_best_parsable_locale('', None, False, False)



# Generated at 2022-06-24 20:37:30.211868
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)


# Generated at 2022-06-24 20:37:30.946686
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True



# Generated at 2022-06-24 20:37:39.019115
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Find the value for the instances when
    # result is not a failure

    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'
    var_0 = get_best_parsable_locale(str_0, str_0, str_0)

    # Find the value for the instances when
    # result is a failure


# Generated at 2022-06-24 20:37:42.141421
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert var_0 == str_0

# Generated at 2022-06-24 20:37:48.480465
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test function input parameter types
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'

# Generated at 2022-06-24 20:37:51.837378
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert False
    except AssertionError:
        pass

# Generated at 2022-06-24 20:37:57.673167
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    with pytest.raises(Exception):
        test_case_0()

#
# Example
#
# def compute(x, y):
#     return x + y
#
# class TestClass:
#     def test_one(self):
#         assert compute(1, 2) == 3
#
#     def test_two(self):
#         assert compute(2, 3) == 5

if __name__ == '__main__':
    test_get_best_parsable_locale()
    pytest.main()

# Generated at 2022-06-24 20:37:59.408403
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # test with valid value
    get_best_parsable_locale(test_case_0,test_case_0,test_case_0)

# Generated at 2022-06-24 20:38:03.897506
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale
    assert get_best_parsable_locale
    assert get_best_parsable_locale


# Generated at 2022-06-24 20:38:14.282372
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'

    # Tests with:
    # preference == '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath

# Generated at 2022-06-24 20:38:25.175849
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = get_best_parsable_locale(( to_native(err)))
    assert var_0 =='C'

    #unable to get locale information, rc=%s: %s' % (rc, to_native(err)))
    var_1 = get_best_parsable_locale(str_0, str_0, str_0)
    assert var_1 == 'C'

# Generated at 2022-06-24 20:38:34.354108
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'
    var_0 = get_best_parsable_locale(str_0, str_0, str_0)

    assert var_0 == 'C'


# Generated at 2022-06-24 20:38:43.955701
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # 'available': [u'en_US.utf8', u'C', u'POSIX']
    str_0 = '\nhistory_id: |\n            dest:\n                description: Destination file/path, equal to the value passed to I(path).\n                returned: state=touch, state=hard, state=link\n                type: str\n                sample: /path/to/file.txt\n            path:\n                description: Destination file/path, equal to the value passed to I(path).\n                returned: state=absent, state=directory, state=file\n                type: str\n                sample: /path/to/file.txt\n            \n'
    var_0 = get_best_parsable_locale(str_0, str_0, str_0)

# Generated at 2022-06-24 20:38:50.160810
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'
    var_0 = get_best_parsable_locale(str_0, str_0, str_0)

# Generated at 2022-06-24 20:38:57.692186
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'
    var_0 = get_best_parsable_locale(str_0, str_0, str_0)
    return var_0

# Generated at 2022-06-24 20:39:04.486809
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # default locale is C
    locale = get_best_parsable_locale(None, None, False)
    assert locale == 'C'
    assert locale != 'CHINAMEN'
    # test for an empty string for get_best_parsable_locale function
    locale = get_best_parsable_locale("", "", False)
    assert locale == 'C'



# Generated at 2022-06-24 20:39:08.212539
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:39:10.779606
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(str_0, str_0, str_0) == str_0

# Testing for function get_best_parsable_locale

# Generated at 2022-06-24 20:39:20.876030
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Raises ValueError if the given value is not present in the object's list of choices.
    # setup test values
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'

# Generated at 2022-06-24 20:39:27.614275
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'
    result = get_best_parsable_locale(var, var, var)
    assert result == 'C'

# Generated at 2022-06-24 20:39:52.107844
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert test_case_0() == 'C', "Expected: 'C', Got '%s'" % get_best_parsable_locale("Compare")
    except AssertionError as e:
        print("AssertionError: ", e.args)
        # AssertionError: ('Expected:','C','Got','C')

# Pylint UseCase:
# pylint: disable=too-many-locals
# pylint: disable=too-many-statements
# pylint: disable=unused-argument
# pylint: disable=unused-variable
# pylint: disable=redefined-outer-name
# pylint: disable=unused-wildcard-import
# pylint: disable=too-many-branches
# pylint: disable=too-

# Generated at 2022-06-24 20:39:57.113911
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = get_best_parsable_locale('test', 'test', False)

    assert var_0 == 'C', "Expected %s, got %s" % ('C', var_0)
#
# if __name__ == "__main__":
#     test_get_best_parsable_locale()
#     test_case_0()

# Generated at 2022-06-24 20:39:59.483889
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert test_case_0() == 1
    except AssertionError as e:
        print(e)
        raise e



# Generated at 2022-06-24 20:40:03.419444
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test case 0
    str_0 = "C.utf8"
    str_1 = "C"
    str_2 = "POSIX"
    var_0 = get_best_parsable_locale(str_0, str_1, str_2)
    print(var_0)  # Print the returned value


# Generated at 2022-06-24 20:40:11.672868
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'
    var_0 = get_best_parsable_locale(str_0, str_0, str_0)

# Generated at 2022-06-24 20:40:13.201546
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(test_case_0())


if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:40:23.806421
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    SKIP_TEST = False
    if SKIP_TEST:
        print("Tests skipped, set the environment variable RUN_TESTS to run these tests.")
        return None

    ansible_facts = dict()
    status = dict()

    # Do the test(s)
    if not test_case_0():
        status['TEST_0'] = {'status': 'FAILED', 'output': 'Test 0 failed'}    
    else:
        status['TEST_0'] = {'status': 'PASSED', 'output': 'Test 0 passed'}

    if not status:
        return None

    for test in status:
        msg = ''
        for line in status[test]['output'].split('\n'):
            msg += '   {0}\n'.format(line)

# Generated at 2022-06-24 20:40:32.668676
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'
    bool_0 = bool_1 = bool_2 = bool_3 = bool_4 = bool_5 = bool_6 = bool_7 = bool_8 = bool_9 = bool_10 = bool_11 = bool_12 = bool_13 = bool_14 = bool_15 = bool_16 = bool_17

# Generated at 2022-06-24 20:40:38.193565
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # String compare test case 0
    assert 'C' == get_best_parsable_locale('C', 'C', 'C')

    # String compare test case 1
    assert 'en_US.utf8' == get_best_parsable_locale('C.utf8', 'en_US.utf8', 'POSIX')
    pass


# Generated at 2022-06-24 20:40:46.289579
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(str_0, str_0, str_0) == var_0
    assert get_best_parsable_locale(str_0, str_0, str_0) == var_0
    assert get_best_parsable_locale(str_0, str_0, str_0) == var_0
    assert get_best_parsable_locale(str_0, str_0, str_0) == var_0
    assert get_best_parsable_locale(str_0, str_0, str_0) == var_0
    assert get_best_parsable_locale(str_0, str_0, str_0) == var_0

# Generated at 2022-06-24 20:41:15.386196
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()


# Generated at 2022-06-24 20:41:16.440752
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' == get_best_parsable_locale(str_0, str_0, str_0)

# Generated at 2022-06-24 20:41:17.451861
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:41:27.815514
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'

# Generated at 2022-06-24 20:41:37.257057
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('C.UTF-8', 'C.UTF-8', 'C.UTF-8') == 'C.UTF-8'
    assert get_best_parsable_locale('C', 'C', 'C') == 'C'
    assert get_best_parsable_locale('POSIX', 'POSIX', 'POSIX') == 'POSIX'
    assert get_best_parsable_locale('en_US.utf8', 'en_US.utf8', 'en_US.utf8') == 'en_US.utf8'
    assert get_best_parsable_locale('C.utf8', 'C.utf8', 'C.utf8') == 'C.utf8'

# Generated at 2022-06-24 20:41:39.107976
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(module, preferences=None, raise_on_locale=False)


# Generated at 2022-06-24 20:41:42.902747
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # tester for function get_best_parsable_locale
    preferred_locales = ['C', 'POSIX']
    raise_on_locale_false = False
    var_0 = get_best_parsable_locale(test_case_0, preferred_locales, raise_on_locale_false)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:41:49.389620
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'

# Generated at 2022-06-24 20:41:54.200061
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == "C"

# Generated at 2022-06-24 20:41:59.847609
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'
    var_0 = get_best_parsable_locale(str_0, str_0, str_0)
    assert 'C' == var_0

# Generated at 2022-06-24 20:42:36.878884
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'
    var_0 = get_best_parsable_locale(str_0, str_0, str_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:42:46.965576
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-24 20:42:53.503493
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == get_best_parsable_locale(None)
    assert True == get_best_parsable_locale(None, None)
    assert True == get_best_parsable_locale(None, None, None)

# Generated at 2022-06-24 20:43:01.285890
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert not get_best_parsable_locale("C.utf8") == "C.utf8"
    assert not get_best_parsable_locale("C.utf8" == None)
    assert not get_best_parsable_locale("POSIX" == None)
    assert not get_best_parsable_locale("C" == None)
    assert not get_best_parsable_locale("c" == None)
    assert not get_best_parsable_locale("en_US.utf8" == None)
    assert not get_best_parsable_locale("en_US.UCS-2" == None)
    assert not get_best_parsable_locale("en_US.iso88591" == None)
    assert not get_best_parsable

# Generated at 2022-06-24 20:43:06.667492
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # test case 0
    test_case_0()


if __name__ == "__main__":

    # run all the test cases
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:43:14.397010
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Output from module is a string
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'
    var_0 = get_best_parsable_locale(str_0, str_0, str_0)
    assert var_0 == 'C'

    # Output from module is a string

# Generated at 2022-06-24 20:43:20.719532
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
  try:
    test_case_0()
  except Exception as e:
    print("Exception in test case 0: " + str(e))
    assert False


if __name__ == "__main__":
  test_get_best_parsable_locale()

# Generated at 2022-06-24 20:43:26.332380
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-24 20:43:29.161460
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert test_case_0() == 'C'

if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:43:34.922575
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(str_0, str_0, str_0) == 'C'

# Generated at 2022-06-24 20:44:43.715694
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert (get_best_parsable_locale('/usr/sbin/locale', [], True)) == 'C.utf8'

# Generated at 2022-06-24 20:44:44.853525
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() != None

# Module unit test for get_best_parsable_locale

# Generated at 2022-06-24 20:44:47.505381
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = str(True) # given value: False
    val_0 = get_best_parsable_locale(str_0)
    assert val_0 == 'default_expected_value'

# Generated at 2022-06-24 20:44:49.150411
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert (get_best_parsable_locale(module='module', preferences='preferences', raise_on_locale='True') == None),'Return type does not match'


# Generated at 2022-06-24 20:44:54.009470
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping

    class FakeModule(Mapping):
        def get_bin_path(self, name, required=True, opt_dirs=None):
            return '/bin/{}'.format(name)


# Generated at 2022-06-24 20:45:03.600111
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'
    var_0 = get_best_parsable_locale(str_0, str_0, str_0)
    assert var_0 == "C", "Expected variable %s to be %s but instead got %s" % ("var_0", "C", var_0)

# Generated at 2022-06-24 20:45:11.093812
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '\ndest:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=touch, state=hard, state=link\n    type: str\n    sample: /path/to/file.txt\npath:\n    description: Destination file/path, equal to the value passed to I(path).\n    returned: state=absent, state=directory, state=file\n    type: str\n    sample: /path/to/file.txt\n'
    str_1 = ""
    str_2 = ""
    var_0 = get_best_parsable_locale(str_0, str_1, str_2)
    var_1 = get_best_parsable_locale(str_0, var_0, str_2)


# Generated at 2022-06-24 20:45:12.151092
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert var_0 == str_0

# Generated at 2022-06-24 20:45:15.123054
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)


# Testing whether the object returned is a string

# Generated at 2022-06-24 20:45:19.184774
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Nothing
    assert get_best_parsable_locale(None, None) == "C"
    # Something
    assert get_best_parsable_locale("something", preferences=["something", "nope"]) == "something"
    # Something that does not exist
    assert get_best_parsable_locale("something", preferences=["nope", "nothing"]) == "C"
    return True