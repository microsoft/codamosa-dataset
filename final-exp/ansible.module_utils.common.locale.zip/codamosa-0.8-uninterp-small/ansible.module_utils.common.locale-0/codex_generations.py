

# Generated at 2022-06-24 20:35:43.702582
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test the locale is parsable and in preferences
    str_0 = '!s>\\6'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 == 'C.utf8'

    # Test the locale is not parsable and in preferences
    str_1 = '!s?\\6'
    var_1 = get_best_parsable_locale(str_1)
    assert var_1 == 'C'

    # Test the locale is parsable and not in preferences
    str_2 = '!s>\\8'
    var_2 = get_best_parsable_locale(str_2)
    assert var_2 == 'C'

    # Test the locale is not parsable and not in preferences
    str_3 = '!s?\\8'

# Generated at 2022-06-24 20:35:46.285347
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert (get_best_parsable_locale(None) == 'C')

    assert (get_best_parsable_locale('en_US.utf8') == 'en_US.utf8')


test_case_0()
test_get_best_parsable_locale()

# Generated at 2022-06-24 20:35:48.144741
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    arg0 = ''
    arg1 = []
    arg2 = False
    var0 = get_best_parsable_locale(arg0, arg1, arg2)
    assert False


# Generated at 2022-06-24 20:35:53.033979
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert (test_case_0() == '!s>\\6')
        print('Success: test_get_best_parsable_locale')
    except AssertionError:
        print('Failure: test_get_best_parsable_locale')



# Generated at 2022-06-24 20:35:57.346769
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except Exception as e:
        print('FAILED to get_best_parsable_locale:')
        print(e)

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:36:03.009779
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    args0 = "tk_tst.py"
    args1 = '!s>\\6'
    res0 = None
    try:
        test_case_0()
        res0 = 'C'
    except Exception as e:
        res0 = 'ERROR'
    assert res0 == 'C', "The function get_best_parsable_locale returned inconsistent results."

# Generated at 2022-06-24 20:36:13.442346
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('!s>\\6', None) == 'C'
    assert get_best_parsable_locale('\\,(w}\\>!_\\!', None) == 'C'
    assert get_best_parsable_locale('\\,(w}\\>!_\\!', []) == 'C'
    assert get_best_parsable_locale('!s>\\6', []) == 'C'
    assert get_best_parsable_locale('!s>\\6', ['C']) == 'C'
    assert get_best_parsable_locale('!s>\\6', ['C', 'en_US.utf8']) == 'C'

# Generated at 2022-06-24 20:36:14.650559
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(1) == 'C'

# Generated at 2022-06-24 20:36:18.233868
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert False


# Generated at 2022-06-24 20:36:19.904565
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(str_0) == var_0

# Generated at 2022-06-24 20:36:28.978548
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('!s>\\6') == 'C'



# Generated at 2022-06-24 20:36:32.642281
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Unicode input with an encoded string
    str_0 = '!s>\\6'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:36:38.415515
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert str(get_best_parsable_locale("0")) == "C"
    assert str(get_best_parsable_locale("1")) == "C"
    assert str(get_best_parsable_locale("2")) == "C"
    assert str(get_best_parsable_locale("3")) == "C"
    assert str(get_best_parsable_locale("4")) == "C"

if __name__ == "__main__":
    test_get_best_parsable_locale()
# end of test cases

# Generated at 2022-06-24 20:36:43.709644
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '!s>\\6'
    assert get_best_parsable_locale(str_0) == '!s>\\6'
    str_1 = 'f\\B'
    assert get_best_parsable_locale(str_1) == 'f\\B'
    str_2 = '+>w'
    assert get_best_parsable_locale(str_2) == '+>w'
    str_3 = 'Q['
    assert get_best_parsable_locale(str_3) == 'Q['
    str_4 = 'g\\4;'
    assert get_best_parsable_locale(str_4) == 'g\\4;'
    str_5 = 'x'

# Generated at 2022-06-24 20:36:45.238392
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True


# Generated at 2022-06-24 20:36:48.761417
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == 'C', 'The function get_best_parsable_locale failed for case 0'

# Generated at 2022-06-24 20:36:51.654598
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True
    # assert get_best_parsable_locale(preferences, raise_on_locale) == 'C'
    # assert get_best_parsable_locale() == True
    # assert get_best_parsable_locale() == True

# Generated at 2022-06-24 20:36:53.782871
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Takes arguments string, list
    # Raises Exception if arguments are invalid
    str_0 = '!s>\\6'
    var_0 = get_best_parsable_locale(str_0)


# Generated at 2022-06-24 20:36:57.049661
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        str_0 = '*bhH'
        var_0 = get_best_parsable_locale(str_0)
        assert var_0 == 'C'
    except AssertionError:
        var_0 = get_best_parsable_locale(str_0)
        raise Exception(var_0)

# Unit tests for function get_best_parsable_locale

# Generated at 2022-06-24 20:36:59.497837
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(2) == 'C'



# Generated at 2022-06-24 20:37:16.704719
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    #Run the function multiple times (once per potential locale) to ensure that it always returns the correct value
    #Case 1 - System locale is "C.utf8"
    preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    available=['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(preferences,available) == 'C.utf8'
    #Case 2 - System locale is "en_US.utf8"
    preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    available=['en_US.utf8', 'C.utf8', 'C', 'POSIX']

# Generated at 2022-06-24 20:37:25.812711
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # From test case 0
    str_0 = '!s>\\6'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 == 'C'

    str_0 = '!s>\\6'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 == 'C'

    str_0 = '!s>\\6'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 == 'C'

    str_0 = '!s>\\6'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 == 'C'

    test_case_0()

# Generated at 2022-06-24 20:37:28.183434
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert_raises(RuntimeWarning, test_case_0)


# Generated at 2022-06-24 20:37:32.711501
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('!s>\\6', []) == 'C'
    assert get_best_parsable_locale('!s>\\6', ['en_US.utf8']) == 'en_US.utf8'


# Generated at 2022-06-24 20:37:34.901834
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(str()) is None
    assert get_best_parsable_locale('s') == 's'



# Generated at 2022-06-24 20:37:41.884677
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']  # pylint: disable=unsubscriptable-object

    # 1
    # Test with a simple command line output, with an unknown best parsable locale in the `preferences` list.
    # Expected result: the default locale 'C' will be returned by the `get_best_parsable_locale` function.

# Generated at 2022-06-24 20:37:42.628603
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True # FIXME: implement your test here


# Generated at 2022-06-24 20:37:44.862398
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert get_best_parsable_locale(str_0) == var_0

    except:
        raise Exception("Test case 0 failed.")


# Generated at 2022-06-24 20:37:48.965718
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert 'C' == get_best_parsable_locale(str)
    except (AssertionError, TypeError) as e:
        print(e)
        assert False


# Generated at 2022-06-24 20:37:58.672796
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    var_1 = get_best_parsable_locale('Aa')
    assert var_1 == 'C'

    var_2 = get_best_parsable_locale('Aa', [])
    assert var_2 == 'C'

    var_3 = get_best_parsable_locale('Aa', [], True)
    assert var_3 == 'C'

    var_4 = get_best_parsable_locale('Aa', ['Bb'])
    assert var_4 == 'C'

    var_5 = get_best_parsable_locale('Aa', ['Bb'], True)
    assert var_5 == 'C'

    var_6 = get_best_parsable_locale('Aa', ['Bb'], False)
    assert var_

# Generated at 2022-06-24 20:38:08.445215
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale) == True

# Test for function get_best_parsable_locale():

# Generated at 2022-06-24 20:38:11.885556
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_1 = '6722_g6dz'
    var_1 = get_best_parsable_locale(str_1)
    assert var_1 == 'C'

# Utility function for removing test output files

# Generated at 2022-06-24 20:38:14.093277
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print("Output #0: " + str(test_case_0()))

test_get_best_parsable_locale()

# Generated at 2022-06-24 20:38:16.472108
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        get_best_parsable_locale(None)
    except NotImplementedError:
        pass
    else:
        raise Exception("Unexpected behavior")



# Generated at 2022-06-24 20:38:19.909209
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(str_0) == var_0


if __name__ == '__main__':
    test_case_0()
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:38:27.771698
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    a0 = '<1\\A$\x14'
    a1 = '\x10B\x0c'
    b0 = True
    f0 = get_best_parsable_locale(a0, a1, b0)
    assert(f0 == 'C')
    a0 = '\x00Af\x0c'
    a1 = '\x04\x0e\x0c'
    b0 = True
    f0 = get_best_parsable_locale(a0, a1, b0)
    assert(f0 == 'en_US.utf8')
    a0 = '\r\tR\x16'
    a1 = '\x04\x0e\x10'
    b0 = True
    f0 = get_best_parsable

# Generated at 2022-06-24 20:38:30.382558
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '*m8'
    var_0 = get_best_parsable_locale(str_0)

    assert var_0 == 'POSIX'

# Generated at 2022-06-24 20:38:34.121532
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert '!s>\\6' == get_best_parsable_locale('!s>\\6')
    assert ['foo'] == get_best_parsable_locale('!s>\\6', 'foo')

# Generated at 2022-06-24 20:38:36.013668
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:38:45.302430
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == 'C'
    assert get_best_parsable_locale('C') == 'C'
    assert get_best_parsable_locale('C', 'C') == 'C'
    assert get_best_parsable_locale('C', 'C', 'C') == 'C'
    assert get_best_parsable_locale('A', 'C', 'C') == 'A'
    assert get_best_parsable_locale('C', 'A', 'C') == 'A'
    assert get_best_parsable_locale('C', 'C', 'A') == 'A'
    assert get_best_parsable_locale('B', 'A', 'C') == 'B'
    assert get_best_pars

# Generated at 2022-06-24 20:38:57.810264
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '1'
    str_1 = '2'
    str_2 = '3'
    str_3 = '4'

    var_0 = get_best_parsable_locale(str_0, str_1, str_2, str_3)


if __name__ == '__main__':
    for func in ['test_case_0', 'test_get_best_parsable_locale']:
        func_call = '{}()'.format(func)
        print('')
        print('Running {}...'.format(func_call))
        eval(func_call)

# Generated at 2022-06-24 20:39:01.564410
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert test_case_0() == 'C.utf8'
    except AssertionError as e:
        print('test_case_0 failed: %s' % str(e))
        raise AssertionError

# Utility function to validate the tests
# Expects a tuple with an integer and a string
# Returns True if the test passes, False if it fails

# Generated at 2022-06-24 20:39:02.625541
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' == get_best_parsable_locale(None)

# Generated at 2022-06-24 20:39:10.591524
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('!s>\\6') == 'C'
    assert get_best_parsable_locale('!s>\\6', preferences=None) == 'C'
    assert get_best_parsable_locale('!s>\\6', preferences=None, raise_on_locale=False) == 'C'
    assert get_best_parsable_locale('!s>\\6', preferences=None, raise_on_locale=True) == 'C'
    assert get_best_parsable_locale('!s>\\6', preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:39:20.853067
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' == get_best_parsable_locale(), \
      'Expected "C", but got "{0}"'.format(get_best_parsable_locale())
    assert 'C' == get_best_parsable_locale(None), \
      'Expected "C", but got "{0}"'.format(get_best_parsable_locale(None))
    assert 'C.utf8' == get_best_parsable_locale('C.utf8'), \
      'Expected "C.utf8", but got "{0}"'.format(get_best_parsable_locale('C.utf8'))

# Generated at 2022-06-24 20:39:21.839741
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()


# Generated at 2022-06-24 20:39:26.035549
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    function_name = 'get_best_parsable_locale'
    locals = locals()
    # getting the function from the locals dictionary is important,
    # otherwise you will try to call the test_get_best_parsable_locale function
    function = locals.get(function_name)
    # calling the function
    function()
    assert True


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:39:35.346390
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test against a string
    str_0 = '!s>\\6'
    var_0 = get_best_parsable_locale(str_0)

    # Test against a list
    list_0 = [1, 2, 3]
    var_1 = get_best_parsable_locale(list_0)

    # Test against a dictionary
    dict_0 = {'name': 'Adam', 'age': 21}
    var_2 = get_best_parsable_locale(dict_0)

    # Test against a boolean
    bool_0 = False
    var_3 = get_best_parsable_locale(bool_0)


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:39:44.044899
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # from mock import Mock
    str_0 = '!s>\\6'
    # mock.patch('errno').start()
    # mock.patch('sys.stdout').start()
    # mock.patch('sys.stdin').start()
    # mock.patch('sys.stderr').start()
    # mock.patch('sys.getprofile').start()
    # mock.patch('localtime').start()
    # mock.patch('gmtime').start()
    # mock.patch('time.sleep').start()
    # mock.patch('signal.pause').start()
    # mock.patch('os.getenv').start()
    # mock.patch('os.getlogin').start()
    # mock.patch('sys.exit').start()
    # mock.patch('traceback.print_tb').start()
   

# Generated at 2022-06-24 20:39:44.992980
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass



# Generated at 2022-06-24 20:39:59.201495
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '!s>\\6'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 is not None
    assert var_0 == 'C'
    str_0 = '7Zu,:`'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 is not None
    assert var_0 == 'C'
    str_0 = '  !Y!'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 is not None
    assert var_0 == 'C'
    str_0 = '^j'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 is not None
   

# Generated at 2022-06-24 20:40:00.855018
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(str_0) == var_0

# Generated at 2022-06-24 20:40:04.774948
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('s') == 'C'

# Generated at 2022-06-24 20:40:09.732023
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Setup testcase
    str_0 = '!s>\\6'
    var_0 = get_best_parsable_locale(str_0)

    # Check conditions
    assert var_0 == '!s>\\6'

# Testcase 1
# Testcase description: Testcase for function get_best_parsable_locale
# Expected result:      We expect to get the best locale back


# Generated at 2022-06-24 20:40:17.500950
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '#'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 == 'C'
    str_0 = '|'
    var_1 = get_best_parsable_locale(str_0)
    assert var_1 == 'C'
    str_0 = 'd6'
    var_2 = get_best_parsable_locale(str_0)
    assert var_2 == 'C'
    str_0 = 'O'
    var_3 = get_best_parsable_locale(str_0)
    assert var_3 == 'C'
    str_0 = 'z'
    var_4 = get_best_parsable_locale(str_0)

# Generated at 2022-06-24 20:40:19.191582
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, None) == 'C'

# Generated at 2022-06-24 20:40:21.057549
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert get_best_parsable_locale('f$lTh`@') == 'C'


# Generated at 2022-06-24 20:40:22.449618
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(str_0) == var_0

# Generated at 2022-06-24 20:40:31.593183
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Check the default locale, en_US.utf8
    try:
        preferences = ['en_US.utf8']
        str_0 = '!s>\\6'
        var_0 = get_best_parsable_locale(str_0, preferences)
    except RuntimeError:
        assert False, "Unable to set a valid locale"

    # Check an invalid locale, invalid_locale
    try:
        preferences = ['invalid_locale']
        str_0 = '!s>\\6'
        var_0 = get_best_parsable_locale(str_0, preferences)
        assert False, "Invalid locale accepted"
    except RuntimeError:
        pass
    # Check that the function fails to set a locale

# Generated at 2022-06-24 20:40:41.767420
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(get_best_parsable_locale('l8@Ad'))
    assert(get_best_parsable_locale('c#*U'))
    assert(get_best_parsable_locale('(ye@'))
    assert(get_best_parsable_locale('!s>\\6'))
    assert(get_best_parsable_locale('Oz[/'))
    assert(get_best_parsable_locale('!s?:}'))
    assert(get_best_parsable_locale('R}sD'))
    assert(get_best_parsable_locale('!s>\\6'))

# Generated at 2022-06-24 20:40:53.490382
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_7 = to_native('!s>\\6')
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    var_8 = get_best_parsable_locale(var_7, preferences)
    assert var_8 == 'C', "AssertionError: var_8 == 'C'"

# Generated at 2022-06-24 20:40:55.720526
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(False) is not None


# Generated at 2022-06-24 20:40:57.428724
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(get_best_parsable_locale('!s>\\6')) == 'C'

# Generated at 2022-06-24 20:41:03.034843
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = 'm=s%i'
    str_1 = '&w'
    str_2 = 'i'
    var_0 = get_best_parsable_locale(str_0, str_1, str_2)
    assert var_0 == 'C'


# Generated at 2022-06-24 20:41:04.143917
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0()

# Generated at 2022-06-24 20:41:13.603616
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    warnings.filterwarnings("ignore", ".*", DeprecationWarning)
    warnings.filterwarnings("ignore", ".*", RuntimeWarning)

    # No exception should be raised if no str parameter
    try:
        str_0 = 'e_s'
        var_0 = get_best_parsable_locale(str_0)
    except RuntimeWarning as e:
        print("RuntimeWarning raised as expected: ", e)
    else:
        print("RuntimeWarning not raised as expected!")

    # No exception should be raised if no str parameter and no preferences list
    try:
        str_1 = 'J5'
        var_0 = get_best_parsable_locale(str_1, [])
    except RuntimeWarning as e:
        print("RuntimeWarning raised as expected: ", e)
    else:
        print

# Generated at 2022-06-24 20:41:14.786943
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    #assert get_best_parsable_locale() ==
    pass



# Generated at 2022-06-24 20:41:20.100501
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('x', 'C.utf8', 'POSIX') == 'C'
    assert get_best_parsable_locale('C', 'C.utf8', 'POSIX') == 'C'
    assert get_best_parsable_locale('C.utf8', 'C.utf8', 'POSIX') == 'C.utf8'
    assert get_best_parsable_locale('POSIX', 'C.utf8', 'POSIX') == 'POSIX'
    assert get_best_parsable_locale('C.utf8', 'POSIX') == 'POSIX'
    assert get_best_parsable_locale('POSIX', 'C.utf8') == 'C.utf8'

# Generated at 2022-06-24 20:41:20.611352
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True



# Generated at 2022-06-24 20:41:29.610223
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert func_0(None) == 'C'
    assert func_0(None) == 'C'
    assert func_0(None) == 'C'
    assert func_0(None) == 'C'
    assert func_0(None) == 'C'
    assert func_0(None) == 'C'
    assert func_0(None) == 'C'
    assert func_0(None) == 'C'
    assert func_0(None) == 'C'
    assert func_0(None) == 'C'
    assert func_0(None) == 'C'
    assert func_0(None) == 'C'
    assert func_0(None) == 'C'
    assert func_0(None) == 'C'
    assert func_0(None) == 'C'
    assert func_

# Generated at 2022-06-24 20:41:39.537513
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
  pass


# Generated at 2022-06-24 20:41:41.459969
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = get_best_parsable_locale('!s>\\6')
    assert var_0 == 'C'

# Generated at 2022-06-24 20:41:49.961566
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str1_0 = '!s>\\6'
    str2_0 = '!s'
    str1_1 = '!s'
    re1_1 = '\\d+'
    str2_1 = '!s'
    result_0 = get_best_parsable_locale(str1_0, str2_0)
    result_1 = get_best_parsable_locale(str1_1, str2_1)
    assert result_0 == '!s>\\6'
    assert result_1 == '!s'



# Generated at 2022-06-24 20:41:53.814017
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('!s>\\6', None, False) == 'C'

# Generated at 2022-06-24 20:41:55.373567
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(str_0) == var_0


# Generated at 2022-06-24 20:42:00.232034
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(str_0) == var_0

# Generated at 2022-06-24 20:42:00.763387
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == 'C'

# Generated at 2022-06-24 20:42:10.701831
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert get_best_parsable_locale([0]) == 'C'
    except (TypeError, AssertionError) as e:
        print(e)

    try:
        assert get_best_parsable_locale([[]]) == 'C'
    except (TypeError, AssertionError) as e:
        print(e)

    try:
        assert get_best_parsable_locale([True]) == 'C'
    except (TypeError, AssertionError) as e:
        print(e)

    try:
        assert get_best_parsable_locale([False]) == 'C'
    except (TypeError, AssertionError) as e:
        print(e)


# Testing of function get_best_parsable_locale

# Generated at 2022-06-24 20:42:18.168784
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '#<'
    str_1 = '\\fy\\n'
    var_0 = get_best_parsable_locale(str_0)
    var_1 = get_best_parsable_locale(str_1)
    assert var_0 == 'C'
    assert var_1 == 'C'


# Unit test function name: test_get_best_parsable_locale
# Test 1
loc = get_best_parsable_locale(module=None, preferences=None, raise_on_locale=False)
print(loc)
assert loc == 'C'

# Generated at 2022-06-24 20:42:27.818484
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Assign
    str_0 = '!s>\\6'
    pref_0 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    pref_1 = ['JB1v4UKF2', '%c', '9', '$']
    pref_2 = ['5#', '1', '%7^u', 'YFn7VyC']

    # Act
    var_0 = get_best_parsable_locale(str_0)
    var_1 = get_best_parsable_locale(str_0, pref_0)
    var_2 = get_best_parsable_locale(str_0, pref_1)
    var_3 = get_best_parsable_locale(str_0, pref_2)

   

# Generated at 2022-06-24 20:42:37.322207
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() is None, 'Missing required argument: module'

    test_case_0()

# Generated at 2022-06-24 20:42:38.428234
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test for input argument of type string
    test_case_0()

# Generated at 2022-06-24 20:42:42.728746
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '!s>\\6'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 == 'C'


# Generated at 2022-06-24 20:42:49.952434
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    str_1 = 'z'
    var_1 = get_best_parsable_locale(str_1)
    assert var_1 == 'z'

    str_1 = '~'
    var_1 = get_best_parsable_locale(str_1)
    assert var_1 == '~'

    str_1 = 'q9'
    var_1 = get_best_parsable_locale(str_1)
    assert var_1 == 'q9'

    str_1 = 'd'
    var_1 = get_best_parsable_locale(str_1)
    assert var_1 == 'd'

    str_1 = '_'
    var_1 = get_best_parsable_locale(str_1)

# Generated at 2022-06-24 20:42:55.843663
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, b"C.utf8", b"")
    mock_module.get_bin_path.return_value = "/usr/bin/locale"

    with patch.dict(get_best_parsable_locale.__globals__, {'module': mock_module}):
        assert get_best_parsable_locale() == "C.utf8"

# Generated at 2022-06-24 20:43:01.352233
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert callable(get_best_parsable_locale)
    except NameError:
        # Mock the module object
        class Module(object):
            def __init__(self, *args, **kwargs):
                self.run_command = None
                self.get_bin_path = None

        module = Module()
        module.run_command = MagicMock(return_value=(0, None, None))
        module.get_bin_path = MagicMock(return_value='echo')
        
        assert callable(get_best_parsable_locale)


# Generated at 2022-06-24 20:43:09.502610
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test when nothing is passed
    str_0 = '!s>\\6'
    var_0 = get_best_parsable_locale(str_0)
    assert not 'C' == var_0

    # Test when pref is passed
    str_1 = '!s>\\6'
    var_1 = get_best_parsable_locale(str_1, 'C', True)
    assert not 'C' == var_1


if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:43:10.570482
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(str) == str

# Generated at 2022-06-24 20:43:14.848858
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # arg_0 = [0x1f] * 20

    # Test with bare strings
    assert get_best_parsable_locale('0x1f') == 'C'
    assert get_best_parsable_locale(None) == 'C'

    # Test with actual modules
    assert get_best_parsable_locale('0x1f') == 'C'
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-24 20:43:22.057715
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = ':1:0'
    str_1 = '&*Z2'
    assert get_best_parsable_locale(str_0, str_1) == 'C'
    assert get_best_parsable_locale(str_1, str_0) == 'C'
    assert get_best_parsable_locale(str_0) == 'C'

# Generated at 2022-06-24 20:43:38.482213
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass


# Generated at 2022-06-24 20:43:47.585220
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test with an importlib.reload call on a module object
    # Get a temporary python interpreter
    from ansible.module_utils import basic
    import locale

    orig_locale = locale.getdefaultlocale()
    try:
        test_case_0()
        test_case_1()
        test_case_2()
        test_case_3()
        test_case_4()
        test_case_5()
    finally:
        locale.setlocale(locale.LC_ALL, orig_locale)

    # Test with an importlib.reload call on a module object
    # Get a temporary python interpreter
    from ansible.module_utils import basic
    import locale

    orig_locale = locale.getdefaultlocale()

# Generated at 2022-06-24 20:43:54.817089
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '<rGpr&x/9X=k;`'
    str_1 = '5Py#'
    str_2 = '$S'
    str_3 = 'g!;Dz'
    str_4 = '/p'
    str_5 = 'Rs'
    str_6 = 't^'
    str_7 = 'P'
    str_8 = 'G'
    int_0 = 0
    int_1 = 1
    tuple_0 = (str_2, str_2, str_2, str_2, str_2, str_2)
    tuple_1 = (str_1, str_0, str_6, str_6, str_6, str_6)

# Generated at 2022-06-24 20:44:02.624128
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert callable(get_best_parsable_locale)
    except NameError:
        # This means that a function/class/method is not defined properly, so we
        # collect the name of the code and the line number on which it occurred.
        import sys
        info = sys.exc_info()
        name = info[2].tb_frame.f_code.co_name
        lineno = info[2].tb_lineno
        # We then add this to the exception message and continue with the execution,
        # so that the end-user can see how the error occurred.
        raise AssertionError("'" + name + "' function/method not defined: " + str(lineno))

# Generated at 2022-06-24 20:44:04.922901
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(str_0) == var_0
    assert get_best_parsable_locale(str_0) == var_0
    assert get_best_parsable_locale(str_0) == var_0

# Generated at 2022-06-24 20:44:06.870043
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True


# Generated at 2022-06-24 20:44:09.445743
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert test_case_0() == 'C'
    except AssertionError:
        raise AssertionError("get_best_parsable_locale: Did not get the expected result")


# Generated at 2022-06-24 20:44:16.762059
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = 'Gz5'
    str_1 = 'n[>H'

# Generated at 2022-06-24 20:44:18.346604
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(module, preferences=None, raise_on_locale=False) == 'C'


# Generated at 2022-06-24 20:44:24.561401
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert test_case_0() == 'C'
    except AssertionError as e:
        raise(AssertionError(str(e) + '\n\nFailed Unit Test: test_case_0()'))

if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:44:46.277115
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = 'get_best_parsable_locale'

    # Mock
    test_0 = [module, None, True]
    test_case_0(test_0)

    # Mock
    test_1 = [module, None, True]
    test_case_0(test_1)




# Generated at 2022-06-24 20:44:49.842363
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except Exception as err:
        assert False, err

# Generated at 2022-06-24 20:45:00.829819
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Testing with normal inputs
    preferences = ['C.UTF-8', 'C.utf8', 'C']
    raise_on_locale = True
    assert get_best_parsable_locale(preferences, raise_on_locale) == "C.UTF-8"
    assert preferences == ['C.UTF-8', 'C.utf8', 'C']
    assert raise_on_locale == True

    # Testing with int inputs
    preferences = 4
    raise_on_locale = 3
    assert get_best_parsable_locale(preferences, raise_on_locale) == 'C'
    assert preferences == 4
    assert raise_on_locale == 3

    # Testing with float inputs
    preferences = 3.12
    raise_on_locale = 4.21
    assert get

# Generated at 2022-06-24 20:45:02.446233
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(str_0) == var_0

# Generated at 2022-06-24 20:45:10.375742
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = importlib.import_module('time')

    args = []
    # TypeError should be raised here
    with pytest.raises(TypeError):
        get_best_parsable_locale(args)

    # args = [get_best_parsable_locale, str]
    # # TypeError should be raised here
    # with pytest.raises(TypeError):
    #     get_best_parsable_locale(*args)

    args = [module, None]
    # ValueError should be raised here
    with pytest.raises(ValueError):
        get_best_parsable_locale(*args)

    args = [module, 'C']
    # TypeError should be raised here
    with pytest.raises(TypeError):
        get_best_parsable_loc

# Generated at 2022-06-24 20:45:15.512273
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '!s>\\6'
    var_0 = get_best_parsable_locale(str_0)
    with open('/tmp/debug.log','a') as out:
        out.write(to_native(var_0))
    assert True == True


# Generated at 2022-06-24 20:45:18.728912
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except (RuntimeError, TypeError, NameError) as error:
        print("Error in test case - {0}".format(error))
    except AttributeError as error:
        print("Imported object - {0}".format(error))



# Generated at 2022-06-24 20:45:21.465737
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(str_0) == var_0

# Generated at 2022-06-24 20:45:26.397404
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '!s>\\6'
    var_0 = get_best_parsable_locale(str_0)
    print('get_best_parsable_locale(str_0) = ' + var_0)
    # Should be "C"
    assert var_0 == 'C'

# Generated at 2022-06-24 20:45:34.223474
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = "C.utf8"
    assert get_best_parsable_locale(var_0) == 'C.utf8'

    var_0 = "POSIX"
    assert get_best_parsable_locale(var_0) == 'POSIX'

    var_0 = "C"
    assert get_best_parsable_locale(var_0) == 'C'

    var_0 = "C"
    assert get_best_parsable_locale(var_0) == 'C'

    var_0 = "POSIX"
    assert get_best_parsable_locale(var_0) == 'POSIX'

    var_0 = "en_US.utf8"