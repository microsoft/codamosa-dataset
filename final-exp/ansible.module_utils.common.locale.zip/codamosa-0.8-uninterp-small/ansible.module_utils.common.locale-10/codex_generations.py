

# Generated at 2022-06-24 20:35:39.880924
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        PREFIX = 'ansible.module_utils.basic.get_best_parsable_locale'
        from ansible.module_utils.basic import AnsibleModule
        module = AnsibleModule(argument_spec=dict())
        assert test_case_0(module) == 'C'
    except (NameError, UnboundLocalError):
        module.fail_json(msg='Error accessing ansible module class')


# Generated at 2022-06-24 20:35:40.960899
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(1, 1) == 'C'

# Generated at 2022-06-24 20:35:42.306805
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # No code available to test the function get_best_parsable_locale
    assert True

# Generated at 2022-06-24 20:35:43.064169
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True # TODO: implement your test here


# Generated at 2022-06-24 20:35:43.799229
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True


# Generated at 2022-06-24 20:35:47.539233
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert test_case_0() == ''
    except AssertionError as e:
        raise(AssertionError(str(e) + '\nactual: ' + str(test_case_0())))

    # test comparison to test_case_0
    try:
        assert test_case_0() != None
    except AssertionError as e:
        raise(AssertionError(str(e) + '\nactual: ' + str(test_case_0())))


# Generated at 2022-06-24 20:35:53.088782
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = None
    preferences = {}
    raise_on_locale = True
    try:
        get_best_parsable_locale(module, preferences, raise_on_locale)
    except RuntimeError:
        pass
    else:
        assert False, "Expected exception"


# Generated at 2022-06-24 20:35:54.112535
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True


# Generated at 2022-06-24 20:35:58.014682
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    result = get_best_parsable_locale(module)
    assert result is not None, "get_best_parsable_locale is returning None"

# Generated at 2022-06-24 20:36:00.077359
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(bytes_0=None, dict_0={})


# Generated at 2022-06-24 20:36:09.426784
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    expected = 'C'
    var_0 = get_best_parsable_locale(1,1)
    assert var_0 == expected


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, '-sv'])

# Generated at 2022-06-24 20:36:13.235576
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
  try:
    assert 1, 'Not implemented'
  except AssertionError as e:
    print('Test Failed: ', e )

if __name__ == '__main__':
  test_get_best_parsable_locale()

# Generated at 2022-06-24 20:36:20.590455
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(1, 1) == 'C'
    assert get_best_parsable_locale(1, 2) == 'C'
    assert get_best_parsable_locale(1, 3) == 'C'
    assert get_best_parsable_locale(1, 4) == 'C'
    assert get_best_parsable_locale(1, 5) == 'C'
    assert get_best_parsable_locale(1, 6) == 'C'
    assert get_best_parsable_locale(1, 7) == 'C'

# Generated at 2022-06-24 20:36:24.050745
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    int_0 = 1
    int_1 = 1
    var_0 = get_best_parsable_locale(int_0, int_1)
    assert var_0 == 'POSIX'

# Generated at 2022-06-24 20:36:26.044683
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print("Test get_best_parsable_locale")
    assert get_best_parsable_locale(test_case_0()) != None

# Generated at 2022-06-24 20:36:29.225198
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Uncomment the following lines to test:
    #test_case_0()
    pass



# Generated at 2022-06-24 20:36:31.037899
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == 'C'

# Generated at 2022-06-24 20:36:34.932029
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0()


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:36:37.405222
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test a basic scenario
    test_case_0()


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:36:38.836427
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 0

#   test_case_0()
# #

# Generated at 2022-06-24 20:36:52.103090
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys
    import tempfile
    import shlex
    import shutil
    import subprocess

    curr_dir = os.getcwd()
    test_dir = tempfile.mkdtemp(dir=curr_dir)
    test_file = os.path.join(test_dir, 'test.py')
    temp_locale_lib = os.path.join(test_dir, 'locale.py')
    shutil.copyfile('./locale_info/locale.py', temp_locale_lib)


# Generated at 2022-06-24 20:36:52.767128
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == 'C'

# Generated at 2022-06-24 20:36:54.456083
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() is None

# Generated at 2022-06-24 20:36:55.545376
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    raise NotImplementedError


# Generated at 2022-06-24 20:37:06.498248
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    func_name = 'get_best_parsable_locale'
    func_parameters = [(0, 0, 0), (0, 0, 0), (0, 0, 0), (0, 0, 0)]
    assert_result_within_range = [(0, 0), (0, 0), (0, 0)]
    # Use the following values for function parameters when calling the function
    data_all = [
        [(2, 3), (4, 5), (6, 7), (8, 9)],
        [(2, 3), (4, 5), (6, 7), (8, 9)],
        [(2, 3), (4, 5), (6, 7), (8, 9)],
        [(2, 3), (4, 5), (6, 7), (8, 9)],
    ]
    expected_result_

# Generated at 2022-06-24 20:37:12.834951
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module_mock = MagicMock()
    module_mock.get_bin_path.return_value = "locale_bin_path"
    module_mock.run_command.return_value = (0, ["C"], None)

    assert("C" == get_best_parsable_locale(module_mock))
    assert(module_mock.get_bin_path.call_count == 1)
    assert(module_mock.get_bin_path.call_args == call("locale"))
    assert(module_mock.run_command.call_count == 1)
    assert(module_mock.run_command.call_args == call(["locale_bin_path", '-a']))



# Generated at 2022-06-24 20:37:15.499461
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(1, 1) == 'C.utf8'


# Generated at 2022-06-24 20:37:17.752375
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Initial test for get_best_parsable_locale
    :return:
    """
    test_case_0()

# Generated at 2022-06-24 20:37:24.117507
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Get parameters from config_settings.yml
    config_file = 'config_settings.yml'
    with open(config_file, 'r') as ymlfile:
        cfg = yaml.load(ymlfile)
    for section in cfg:
        if (section == 'get_best_parsable_locale_tests'):
            for test in cfg[section]:
                get_best_parsable_locale(*int_test)

test_case_0()

# Generated at 2022-06-24 20:37:28.732923
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    int_0 = -85502
    int_1 = 173601
    int_2 = -4650
    var_0 = get_best_parsable_locale(int_0, int_1)
    assert var_0 == 'C'
    var_1 = get_best_parsable_locale(int_2, int_1)
    assert var_1 == 'C'

# Generated at 2022-06-24 20:37:36.798871
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    int_0 = 1
    test_case_0()


if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:37:38.460434
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == 1, "Test case 0 failed."


if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:37:41.481537
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    int_0 = 1
    var_1 = get_best_parsable_locale(int_0, int_0)



# Generated at 2022-06-24 20:37:44.245925
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Check that the function returns the correct value
    var_0 = get_best_parsable_locale(int_0, var_0)
    test_case_0()
    assert var_0 == 1

# Generated at 2022-06-24 20:37:51.332188
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(
        argument_spec = dict(
            preferences = dict(type='dict', default=None),
            raise_on_locale = dict(type='dict', default=False),
        ),
        supports_check_mode=True
    )
    int_0 = 1
    int_1 = 1
    int_2 = 1
    str_0 = 'some string'
    str_1 = 'some string'
    str_2 = 'some string'
    int_3 = 1
    int_4 = 1
    str_3 = 'some string'
    str_4 = 'some string'
    str_5 = 'some string'
    str_6 = 'some string'
    int_5 = 1
    int_6 = 1
    int_7 = 1
    int_8 = 1
    int

# Generated at 2022-06-24 20:37:53.722226
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    int_0 = 1
    var_0 = get_best_parsable_locale(int_0, int_0)
    print(var_0)

# Main entry-point call.
if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:37:55.943913
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_ca

# Generated at 2022-06-24 20:37:56.664240
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True


# Generated at 2022-06-24 20:37:57.739804
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(1, True) is None

# Generated at 2022-06-24 20:38:05.669017
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import env_fallback
    module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(type='list', elements='str', default=None),
        ),
        supports_check_mode=True,
    )
    preferences = module.params['preferences']

    result = dict(
        preferences=preferences,
    )

    result['locale'] = get_best_parsable_locale(module, preferences=preferences)
    module.exit_json(**result)


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:38:22.345481
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    int_0 = 1
    double_0 = 1.0
    # test_case_0
    assert (get_best_parsable_locale(int_0, var_0) == 'C')
    # test_case_1
    assert (get_best_parsable_locale(int_0, var_0) == 'C')
    # test_case_2
    assert (get_best_parsable_locale(int_0, var_0) == 'C')
    # test_case_3
    assert (get_best_parsable_locale(int_0, var_0) == 'C')


# Generated at 2022-06-24 20:38:24.075212
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Verify that the function returns a value
    assert get_best_parsable_locale(None, None)



# Generated at 2022-06-24 20:38:34.237739
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test for possible values for var_0
    int_0 = 1
    var_0 = get_best_parsable_locale(int_0, int_0)

    # Test for possible values for var_1
    int_1 = 1
    var_1 = get_best_parsable_locale(int_1, int_1, int_1)

    # Test for possible values for var_2
    int_2 = 1
    var_2 = get_best_parsable_locale(int_2, int_2, int_2, int_2)

    # Test for possible values for var_3
    int_3 = 1
    var_3 = get_best_parsable_locale(int_3, int_3, int_3, int_3, int_3)

    # Test

# Generated at 2022-06-24 20:38:38.352655
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Raise error if function returns None
    try:
        assert get_best_parsable_locale(int_0, int_0) is not None
    except AssertionError:
        raise AssertionError(
            'get_best_parsable_locale function returned None, should return the best possible locale for parsing output in English'
        )

# Generated at 2022-06-24 20:38:41.192489
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
        assert True
    except AssertionError:
        assert False
    except RuntimeWarning as e:
        print("RuntimeWarning detected: ", e)

    return

# Generated at 2022-06-24 20:38:48.110925
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(10, True) == 'C'
    assert get_best_parsable_locale(1, False) == 'C'
    assert get_best_parsable_locale(0, False) == 'C'
    assert get_best_parsable_locale(None, None) == 'C'

# Generated at 2022-06-24 20:38:55.919900
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import ansible.module_utils.basic
    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    class ModuleMock(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def fail_json(*args, **kwargs):
            raise AnsibleFailJson(kwargs)

        def exit_json(*args, **kwargs):
            raise AnsibleExitJson(kwargs)

        def get_bin_path(self, name, *args, **kwargs):
            return name

        def run_command(self, name, *args, **kwargs):
            if name != '/usr/bin/locale':
                raise RuntimeWarning("Unknown command")

# Generated at 2022-06-24 20:38:56.631154
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True

# Generated at 2022-06-24 20:38:57.407789
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() is None

# Generated at 2022-06-24 20:38:57.889326
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

# Generated at 2022-06-24 20:39:07.486435
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert func_get_best_parsable_locale('module', 'preferences', 'raise_on_locale') == 'expected_result'


# Generated at 2022-06-24 20:39:07.952741
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True

# Generated at 2022-06-24 20:39:14.599457
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Unit test for get_best_parsable_locale
    test_case_0()

# End of unit tests

if __name__ == "__main__":
    # Test with python -m ansible.utils.module_docs_fragments.get_best_parsable_locale,
    # or python -m -v ansible.utils.module_docs_fragments.get_best_parsable_locale
    # or python -m -v /path/to/ansible/ansible/utils/module_docs_fragments/get_best_parsable_locale.py
    # with -v or -vv and you get verbose messages, mostly useful with -m
    import doctest
    #doctest.testmod()
    doctest.testmod(verbose=True)

# Generated at 2022-06-24 20:39:17.053679
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(1, 1) is None


# Generated at 2022-06-24 20:39:22.496022
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    int_0 = "int_0"
    test_case_0()

if __name__ == '__main__':
    # test_get_best_parsable_locale()
    pass

# Generated at 2022-06-24 20:39:25.740084
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert var_0 == 1
        assert True
    except AssertionError as ae:
        raise ae

# Generated at 2022-06-24 20:39:26.542870
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:39:28.705295
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    error = True
    try:
        test_case_0()
        error = False
    except:
        error = True
    assert error == False

# Generated at 2022-06-24 20:39:39.127472
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert get_best_parsable_locale(None) == 'C'
    except Exception:
        assert False, 'An unexpected exception occurred, please investigate'


if __name__ == '__main__':
    # Unit test code
    test_get_best_parsable_locale()

    #
    # # Load test code
    #
    # import __main__
    #
    # if 'main' in __main__.__dict__:
    #     sys.modules['__main__'].__dict__['main']()
    #
    #
    # # Profiling code
    #
    # import cProfile
    # import pstats
    # import StringIO
    #
    # pr = cProfile.Profile()
    # pr.enable()
    #
    # main()
    #

# Generated at 2022-06-24 20:39:46.597665
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Input parameters
    # Module object
    class Module:
        def __init__(self):
            self.run_command = run_command

        def get_bin_path(self, _):
            return 'locale'

    # Preferences list
    preferences = ['en_US.utf8']

    # Expected output
    expected = 'en_US.utf8'

    # Construct module object
    module = Module()

    # Run test
    actual = get_best_parsable_locale(module, preferences)
    assert actual == expected



# Generated at 2022-06-24 20:39:56.720726
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True

# vim: ft=python

# Generated at 2022-06-24 20:39:59.420718
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == False

# Generated at 2022-06-24 20:40:00.532774
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(int_0, int_0) == None

# Generated at 2022-06-24 20:40:02.298098
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    int_0 = 1
    int_0 = 1
    var_0 = get_best_parsable_locale(int_0, int_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:40:07.597797
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    int_0 = 1
    int_1 = 1
    var_0 = get_best_parsable_locale(int_0, int_1)
    print(var_0)
    assert var_0 == 1


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:40:15.117972
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(1,1) == 'POSIX'
    assert get_best_parsable_locale(1,'C') == 'POSIX'
    assert get_best_parsable_locale(1,'POSIX') == 'POSIX'
    assert get_best_parsable_locale(1,'C.utf8') == 'POSIX'
    assert get_best_parsable_locale(1,['POSIX', 'C.utf8']) == 'POSIX'
    assert get_best_parsable_locale(1,['POSIX', 'C']) == 'POSIX'
    assert get_best_parsable_locale(1,['C.utf8', 'POSIX']) == 'POSIX'
    assert get_best_parsable_

# Generated at 2022-06-24 20:40:17.600302
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    int_0 = 1
    var_0 = get_best_parsable_locale(int_0, int_0)
    assert var_0 != ''


# Generated at 2022-06-24 20:40:18.940834
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(callable(get_best_parsable_locale))


# Generated at 2022-06-24 20:40:21.457633
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)

    # Call get_best_parsable_locale
    # assert <Conditional Expression>



# Generated at 2022-06-24 20:40:22.239096
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:40:32.228071
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0()

# Generated at 2022-06-24 20:40:32.734458
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

# Generated at 2022-06-24 20:40:35.785010
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print("in test_get_best_parsable_locale")

    assert get_best_parsable_locale(module, [], True) == 'C'

# Generated at 2022-06-24 20:40:40.862879
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except Exception:
        import traceback
        traceback.print_exc()
        assert False


if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:40:44.498551
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import nose
    import sys
    import os
    from nose.tools import raises

    from ansible.module_utils import basic

    arg_0 = 'test'

    # print(var_0)
    print('Created test_case_0')
    test_case_0()


# (2,-1)

# Generated at 2022-06-24 20:40:45.237211
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0()

# Generated at 2022-06-24 20:40:46.983366
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == None, "Test case 0 failed"

# Generated at 2022-06-24 20:40:52.040501
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Arguments
    int_0 = 1
    int_1 = 1
    # Return type
    var_0 = get_best_parsable_locale(int_0)
    var_1 = get_best_parsable_locale(int_0, int_1)

    assert type(var_0) == str
    assert type(var_1) == str

# Generated at 2022-06-24 20:40:54.115030
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    results = []
    for i in range(4):
        results.append(test_case_0())
    return results



# Generated at 2022-06-24 20:41:00.856389
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Asserting whether the function get_best_parsable_locale() throws or not
    # for the below given testcases.
    try:
        test_case_0()
        # If all the above testcases are true then the given assertion is true and hence the program
        # terminates.
        assert True
    # If the above testcases fail then the complete program is considered to be failed
    # which is represented by the given assertion.
    except AssertionError:
        assert False

if __name__ == '__main__':
    # Calling the function get_best_parsable_locale()
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:41:13.454569
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(1, 1) == "C"
    assert get_best_parsable_locale(2, 2) == "C"
    assert get_best_parsable_locale(3, 3) == "C"


# End test scaffolding

if __name__ == '__main__':
    import pytest
    pytest.main(['-xrsv'])

# Generated at 2022-06-24 20:41:15.197594
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == True, "test case 0 failed"
test_get_best_parsable_locale()

# Generated at 2022-06-24 20:41:18.560276
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        # First argument is a AnsibleModule
        # Second argument is a list of preferences.
        # Boolean value determines if exception due to locale CLI should be raised.
        get_best_parsable_locale(test_case_0(), None, True)
    except RuntimeWarning:
        print("RuntimeWarning")

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:41:20.247181
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(test_case_0() == None)

# Generated at 2022-06-24 20:41:25.290752
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    int_0 = 1
    var_0 = get_best_parsable_locale(int_0, int_0)
    assert var_0 == 1




# Generated at 2022-06-24 20:41:27.200512
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(1, 1) is 1

# Generated at 2022-06-24 20:41:32.272082
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == False, "TODO: Implement"


# Unit tests for csv

# Generated at 2022-06-24 20:41:34.283693
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-24 20:41:38.562922
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert False

# Generated at 2022-06-24 20:41:43.915184
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    disp_0 = 1
    int_0 = 1
    var_0 = get_best_parsable_locale(int_0, int_0)
    assert var_0.__class__.__name__ == 'str',\
        'Expected str, got {}'.format(var_0.__class__.__name__)
    assert var_0 == 'C',\
        'Expected C, got {}'.format(var_0)
    disp_1 = 1
    int_1 = 1
    var_1 = get_best_parsable_locale(int_1, int_1, disp_1)
    assert var_1.__class__.__name__ == 'str',\
        'Expected str, got {}'.format(var_1.__class__.__name__)
    assert var_

# Generated at 2022-06-24 20:42:00.279355
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:42:07.197167
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # mocks

    class ModuleMock(object):
        def __init__(self):
            self.params =  {}
            self.fail_json =  MagicMock()
            self.run_command =  MagicMock(return_value=('', '', '', '', ''))

        def get_bin_path(self, arg_0):
            return None

    module =  ModuleMock()
    preferences =  1

    assert get_best_parsable_locale(module, preferences, False) == 'C'

# Generated at 2022-06-24 20:42:08.107435
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass


# Generated at 2022-06-24 20:42:09.368209
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)

# Generated at 2022-06-24 20:42:11.589411
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    int_0 = 1
    var_0 = get_best_parsable_locale(int_0, int_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:42:16.985114
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Make sure 'tools/locale' is not found in this environment
    import mock
    with mock.patch('ansible.module_utils.basic._ansible_module.AnsibleModule.get_bin_path', return_value=None):
        with mock.patch('ansible.module_utils.basic._ansible_module.AnsibleModule.run_command', return_value=(0, None, None)):
            assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-24 20:42:23.518587
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    int_0 = 1
    int_1 = 2
    test_case_0()
    var_0 = get_best_parsable_locale(int_0, int_1)

if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:42:25.203253
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(1,1) == "C"



# Generated at 2022-06-24 20:42:26.135968
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # sanity check
    assert True


# Generated at 2022-06-24 20:42:33.734830
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Clear the existing variables in the test environment
    #
    # If the test environment contains variables that have the same name
    # as the variables that are defined in the test, the test may be
    # affected by the value of these pre-existing variables. In order to
    # avoid this, all pre-existing variables are first cleared.
    for key in list(locals().keys()):
        if key.startswith('var_'):
            del locals()[key]

    # Execute the test case
    test_case_0()


# Generated at 2022-06-24 20:42:52.562356
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(1, 1) == 'C'

# Generated at 2022-06-24 20:42:56.883567
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock input data for testing
    int_0 = 1
    int_1 = 1
    var_0 = ['INT_KEY_0']
    var_1 = ['INT_KEY_1']

    # Run the function being tested
    var_0 = get_best_parsable_locale(int_0, var_0, int_1)

    # Check the results
    assert var_0 == 'C'



# Generated at 2022-06-24 20:42:57.658788
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:42:59.800608
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(1, 1) == 'C'


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:43:03.383415
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Set up mock
    preferences = [1, 'C', 'C.UTF-8', 'C.utf8', 'POSIX', 'en_US.UTF-8', 'en_US.utf8', 'en_US']

    try:
        get_best_parsable_locale(preferences, preferences)
    except RuntimeWarning:
        pass



# Generated at 2022-06-24 20:43:04.095244
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(get_best_parsable_locale())

# Generated at 2022-06-24 20:43:09.444493
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert preferred == 'en_US.UTF-8'
    assert available == [ 'en_US.utf8', 'en_US.UTF-8', 'en_US.utf8' ]
    assert preferred == 'en_US.utf8'
    assert available == [ 'en_US.utf8', 'en_US.UTF-8', 'en_US.utf8' ]
    assert preferred == 'en_US.UTF-8'
    assert available == [ 'en_US.utf8', 'en_US.UTF-8', 'en_US.utf8' ]
    assert preferred == 'en_US.utf8'
    assert available == [ 'en_US.utf8', 'en_US.UTF-8', 'en_US.utf8' ]

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-24 20:43:16.246145
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_1 = 1
    # Default: True
    my_list = ['LC_ALL', 'LC_COLLATE', 'LC_CTYPE', 'LC_MESSAGES', 'LC_MONETARY', 'LC_NUMERIC', 'LC_TIME']
    for x in my_list:
        # Checkpoint: True
        xxx = os.environ.get(x)
        if xxx:
            print("%s is set to: %s" % (x, xxx))
        else:
            print("%s is set to: %s" % (x, "NONE"))
    print("\n")
    # Checkpoint: True
    print("Setting %s to: %s" % ('LC_ALL', 'en_US.UTF-8'))

# Generated at 2022-06-24 20:43:21.864227
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)
    assert isinstance(get_best_parsable_locale(1, 1), str)

# Unit testing for function get_best_parsable_locale

# Generated at 2022-06-24 20:43:23.086693
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Check if the expected result was returned
    assert test_case_0() == 'C'



# Generated at 2022-06-24 20:43:44.644939
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    int_0 = 1
    var_0 = get_best_parsable_locale(int_0, int_0)
    assert var_0 == 1

# Generated at 2022-06-24 20:43:45.549903
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == None

# Generated at 2022-06-24 20:43:47.105509
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(int_0, int_0) == var_0

# Generated at 2022-06-24 20:43:48.255894
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)


# Generated at 2022-06-24 20:43:50.336850
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(test_case_0) is not None
    print('Test passed')

test_get_best_parsable_locale()

# Generated at 2022-06-24 20:43:52.287636
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    arg0 = 1
    arg1 = True
    arg2 = False
    result = get_best_parsable_locale(arg0, arg1, arg2)



# Generated at 2022-06-24 20:43:53.393786
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True # TODO: implement your test here


# Generated at 2022-06-24 20:43:54.423363
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Call function with arguments
    test_case_0()



# Generated at 2022-06-24 20:43:55.868838
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(1, 1) == 'C'



# Generated at 2022-06-24 20:43:57.491327
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    value = get_best_parsable_locale(None, None)
    assert(value == 'C')

# Generated at 2022-06-24 20:44:17.474197
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(1, 1) == 'C'

# Generated at 2022-06-24 20:44:27.601288
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    int_0 = 2
    int_1 = 3
    int_2 = 2
    int_3 = 0
    str_0 = "foo"
    str_1 = "a"
    str_2 = "bar"
    str_3 = "baz"
    str_4 = "f"
    str_5 = "abc"
    str_6 = "c"
    str_7 = "ab"
    str_8 = "def"
    str_9 = "ghi"
    str_10 = "foobar"
    str_11 = "barbaz"
    str_12 = "fooqux"
    str_13 = "bazqux"
    str_14 = "qux"
    str_15 = "  -  "

    # Test case 0
    # test_case_0()

# Generated at 2022-06-24 20:44:30.183832
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 1 == 1


# Generated at 2022-06-24 20:44:38.096706
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(
        argument_spec = dict(
            preferences = dict(required=True, type='str'),
            raise_on_locale = dict(required=True, type='str'),
        ),
        supports_check_mode=True
    )
    preferences = module.params['preferences']
    raise_on_locale = module.params['raise_on_locale']

    # Get best parsable locale
    try:
        get_best_parsable_locale(module, preferences, raise_on_locale)
    except RuntimeError as e:
        module.fail_json(msg=str(e))

# Generated at 2022-06-24 20:44:39.457315
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert  get_best_parsable_locale(int_0, int_0) == var_0

# Generated at 2022-06-24 20:44:49.370927
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # In this test we have 3 variables declared and passed to the
    # get_best_parsable_locale function. The number of arguments is not equal
    # so this should raise an exception
    try:
        test_case_0()
    except TypeError:
        # This is the expected behaviour
        pass

    # In this test we have 2 variables declared. Both are integers and both are
    # passed to the get_best_parsable_locale function. This should raise an
    # exception
    try:
        test_case_1()
    except TypeError:
        # This is the expected behaviour
        pass

    # In this test we have 2 variables declared. Both are integers and one is
    # passed to the get_best_parsable_locale function. This should raise an
    # exception

# Generated at 2022-06-24 20:44:51.572650
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    raise_on_locale = False
    assert get_best_parsable_locale(preferences, raise_on_locale) == "C"


# Generated at 2022-06-24 20:45:01.394269
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert False, "Expected to fail, but the function ran successfully."

##
## unit test for positional arguments
##
# def test_case_1():
#     int_0 = 1
#     var_0 = get_best_parsable_locale(int_0)
#
# # Unit test for function get_best_parsable_locale
# def test_get_best_parsable_locale():
#     assert False, "Expected to fail, but the function ran successfully."

##
## unit test for keyword arguments
##
# def test_case_1():
#     int_0 = 1
#     var_0 = get_best_parsable_locale(preferences=int_0)
#
# # Unit test for function get_best_parsable_locale
# def test_

# Generated at 2022-06-24 20:45:02.897996
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == None # <-- TODO: change

# Generated at 2022-06-24 20:45:04.148161
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(1,1) == 'C'