

# Generated at 2022-06-24 20:35:35.080035
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True


# Generated at 2022-06-24 20:35:43.532633
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Unit test for function get_best_parsable_locale
    # Attempts to return the best possible locale for parsing output in English
    # useful for scraping output with i18n tools. When this raises an exception
    # and the caller wants to continue, it should use the 'C' locale.
    # :param module: an AnsibleModule instance
    # :param preferences: A list of preferred locales, in order of preference
    # :param raise_on_locale: boolean that determines if we raise exception or not
    #                         due to locale CLI issues
    # :returns: The first matched preferred locale or 'C' which is the default
    # Result:
    assert get_best_parsable_locale(test_case_0.str_0,) == test_case_0.var_0



# Generated at 2022-06-24 20:35:44.246473
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 1 == 1



# Generated at 2022-06-24 20:35:45.956302
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-24 20:35:50.705259
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test with each item in the list pos_tests, assert that it raises the errors described in neg_tests
    preferences = ']%vz'
    raise_on_locale = 'ju^i$8'

    # Call function, check if it raised an exception, check the exception's arguments
    try:
        get_best_parsable_locale(preferences, raise_on_locale)
    except Exception as e:
        assert type(e) == RuntimeWarning
        assert e.args[0] == 'Could not find \'locale\' tool'
    else:
        assert False, 'Expected exception not thrown'


# Generated at 2022-06-24 20:35:58.191823
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(']%vz') == "C", "Your function did not return the correct value."
    assert get_best_parsable_locale(None) == "C", "Your function did not return the correct value."
    assert get_best_parsable_locale(None) == "C", "Your function did not return the correct value."
    assert get_best_parsable_locale(None, []) == "C", "Your function did not return the correct value."

# Generated at 2022-06-24 20:36:07.969242
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = ']%vz'

    # Start a subprocess that will simulate an AnsibleModule
    p = mock.start_module(var_0)
    # Use the mocked function to simulate an AnsibleModule's 'run_command' function
    mock.run_command(p)
    # Call the function under test
    result = get_best_parsable_locale(var_0)
    # Ensure that we got back an exit code of 0
    assert mock.rc(p) == 0
    # Ensure that the stdout is empty
    assert not mock.stdout(p)
    # Ensure that the stderr is empty
    assert not mock.stderr(p)
    # Ensure that the function returned the expected result
    assert result == 'C'

# Generated at 2022-06-24 20:36:15.619976
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_1 = ']%vz'
    var_1 = get_best_parsable_locale(str_1)
    assert(var_1 == 'C')
    str_2 = '\x9d\xfa\xed\xfd\x84\xdd\x8d\x13\x04\xa6\xe9\x8c\x77\xa6\xd6\xa8\x00\x81'
    var_2 = get_best_parsable_locale(str_2)
    assert(var_2 == 'C')
    str_3 = '\xdc\xc9\x93Z?\x1d\x8b\x07\x0a'
    var_3 = get_best_parsable_locale(str_3)

# Generated at 2022-06-24 20:36:19.888029
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = ']%vz'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:36:21.412514
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Call function get_best_parsable_locale
    str_0 = ']%vz'
    str_1 = get_best_parsable_locale()



# Generated at 2022-06-24 20:36:28.136046
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(']%vz', None, False) == 'C'

# Generated at 2022-06-24 20:36:37.817414
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)
    str_0 = ']%vz'
    var_0 = get_best_parsable_locale(str_0)
    str_1 = 'S*h9P!-L#z'
    var_1 = get_best_parsable_locale(str_0, str_1)
    str_2 = 'c$F'
    var_2 = get_best_parsable_locale(str_0, str_1, str_2)
    str_3 = 'W!zyw0;0'
    var_3 = get_best_parsable_locale(str_0, str_1, str_2, str_3)
    str_4 = 'W!zyw0;0'
    var_

# Generated at 2022-06-24 20:36:39.785177
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = MockModule()
    assert get_best_parsable_locale(module, None, False) == 'C'

# Generated at 2022-06-24 20:36:42.043109
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        str_0 = ']%vz'
        var_0 = get_best_parsable_locale(str_0)
    except Exception as var_1:
        print(var_1)
        assert False


if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:36:45.392907
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(']%vz') != None


# Generated at 2022-06-24 20:36:50.080363
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(']%vz') == 'C'

if __name__ == '__main__':
    test_get_best_parsable_locale()
    test_case_0()

# Generated at 2022-06-24 20:36:57.823535
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(str_0) == str_0
    assert get_best_parsable_locale(str_0, preferences=list_0) == str_0
    assert get_best_parsable_locale(str_0, raise_on_locale=bool_0) == str_0
    assert get_best_parsable_locale(str_0, preferences=list_0, raise_on_locale=bool_0) == str_0

# Generated at 2022-06-24 20:36:59.367842
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # AssertionError: get_best_parsable_locale() takes at least 1 argument (0 given)
    try:
        test_case_0()
    except TypeError:
        pass

# Generated at 2022-06-24 20:37:00.637806
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-24 20:37:03.537723
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    func_name = "test_get_best_parsable_locale"
    assert test_case_0() == None, func_name + " - Case 0"

test_get_best_parsable_locale()

# Generated at 2022-06-24 20:37:21.605628
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()
    assert True

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:37:23.424889
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = get_best_parsable_locale('bt')
    assert var_0 == 'C'



# Generated at 2022-06-24 20:37:26.361856
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = get_best_parsable_locale()
    assert var_0 == 'C'

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:37:30.708410
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)
    str_0 = ']%vz'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:37:36.719964
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert '%ze&' == get_best_parsable_locale('~;|')
    except (TypeError, AssertionError) as e:
        raise AssertionError(e)

    try:
        assert '*d,7' == get_best_parsable_locale('~;|')
    except (TypeError, AssertionError) as e:
        raise AssertionError(e)

    try:
        assert '8K9' == get_best_parsable_locale('~;|')
    except (TypeError, AssertionError) as e:
        raise AssertionError(e)


# Generated at 2022-06-24 20:37:42.987475
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = ']%vz'
    str_1 = 'GA'
    str_2 = 'J@!['
    str_3 = '_a6L'
    str_4 = 'OjYG'
    str_5 = 'y8>s'
    str_6 = 'A\x9a'
    str_7 = 'C\x9f'
    str_8 = 'K\xa7'
    str_9 = '^\xbd'
    str_10 = 'h\x8e'
    str_11 = 'l\x9f'
    str_12 = '`\x80'
    str_13 = 'l\xb3'
    str_14 = 'V\xa0'
    str_15 = ']'
    str_16 = '\x98'


# Generated at 2022-06-24 20:37:46.826636
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == None

# Generated at 2022-06-24 20:37:48.553978
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(test_case_0()) == 'C'

# Generated at 2022-06-24 20:37:58.647519
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # AssertionError: ']%vz' != 'C'
    assert(get_best_parsable_locale(']%vz') == 'C')
    # AssertionError: 'kNr' != 'C'
    assert(get_best_parsable_locale('kNr') == 'C')
    # AssertionError: ']%vz' != 'C'
    assert(get_best_parsable_locale(']%vz') == 'C')
    # AssertionError: '%&' != 'C'
    assert(get_best_parsable_locale('%&') == 'C')
    # AssertionError: '#y`R' != 'C'

# Generated at 2022-06-24 20:38:00.972782
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(str_0) == expected_0


# Generated at 2022-06-24 20:38:17.471810
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        get_best_parsable_locale('')
    except Exception:
        assert True
    else:
        assert False


# Generated at 2022-06-24 20:38:18.988268
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(str_0) == var_0

# Generated at 2022-06-24 20:38:26.974037
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = ']%vz'
    assert get_best_parsable_locale(var_0) is None
    var_0 = ']%v{'
    assert get_best_parsable_locale(var_0) is None
    var_0 = ']%v{'
    var_1 = ']%v{'
    assert get_best_parsable_locale(var_0, var_1) is None
    var_0 = ']%v{'
    var_1 = ']%v{'
    var_2 = ']%v{'
    assert get_best_parsable_locale(var_0, var_1, var_2) is None
    var_0 = ']%v{'
    var_1 = ']%v{'

# Generated at 2022-06-24 20:38:35.914224
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = 'Hello World!'
    str_1 = 'Supercalifragilisticexpialidocious'
    str_2 = 'antidisestablishmentarianism'
    str_3 = 'floccinaucinihilipilification'
    str_4 = 'Honorificabilitudinitatibus'
    str_5 = 'pneumonoultramicroscopicsilicovolcanoconiosis'
    str_6 = 'dichlorodiphenyltrichloroethane'
    str_7 = 'pseudopseudohypoparathyroidism'
    str_8 = 'supercalifragilisticexpialidocious'
    # Test if get_best_parsable_locale returns the correct output
    assert str_0 == str_0
    assert str_1 == str_1
   

# Generated at 2022-06-24 20:38:43.842001
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert 1 == 1
    except AssertionError as e:
        print('Test Failed', e)

# Unit tests to check your solution, after each call to solution.
# It is ok if your program crashes, as long as you pass the tests.
if __name__ == "__main__":

    try:
        test_get_best_parsable_locale()
        test_case_0()
        test_get_best_parsable_locale()
    except AssertionError as e:
        print('FAILED:', e)

    else:
        print('PASSED ALL TESTS')

# Generated at 2022-06-24 20:38:51.334091
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)
    try:
        get_best_parsable_locale()
        assert False
    except TypeError as err:
        assert "module" in str(err)
        assert "preferences" in str(err)
        assert "raise_on_locale" in str(err)
    assert get_best_parsable_locale(
        'teststr_0', preferences=None, raise_on_locale=None)
    assert get_best_parsable_locale(
        'teststr_0', preferences=None, raise_on_locale=None)
    assert get_best_parsable_locale(
        'teststr_0', preferences=None, raise_on_locale=None)
    assert get_best_pars

# Generated at 2022-06-24 20:38:59.744933
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Assign Values
    str_0 = ']%vz'
    var_0 = get_best_parsable_locale(str_0)

    # Verify Assignments
    assert var_0 == 'C'

    # Assign Values
    str_0 = 'VhR)2n'
    var_0 = get_best_parsable_locale(str_0)

    # Verify Assignments
    assert var_0 == 'C.utf8'

    # Assign Values
    str_0 = 'nbFc:|'
    var_0 = get_best_parsable_locale(str_0)

    # Verify Assignments
    assert var_0 == 'en_US.utf8'

    # Assign Values

# Generated at 2022-06-24 20:39:07.011390
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = ']%vz'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 is not None, "Unable to parse return value from get_best_parsable_locale"
    assert isinstance(var_0, str), "Return value from get_best_parsable_locale should be type string"
    assert var_0 in [ 'C', 'POSIX' ], "Return value from get_best_parsable_locale should be one of the following: ['C', 'POSIX']"

# Generated at 2022-06-24 20:39:09.278433
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(['a', 'b', 'c', 'd']) == 'a'

# Generated at 2022-06-24 20:39:12.828274
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True


# Generated at 2022-06-24 20:39:30.418356
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = ']%vz'
    var_0 = get_best_parsable_locale(str_0)
    expected_var_0 = 'C'
    assert var_0 == expected_var_0



# Generated at 2022-06-24 20:39:40.165324
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('&I') != ']%vz'
    assert get_best_parsable_locale(']%vz') != '&I'
    assert get_best_parsable_locale('!p') != '!p'
    assert get_best_parsable_locale('!p') != ')2F!'
    assert get_best_parsable_locale('!j') != '!j'
    assert get_best_parsable_locale('!j') != '*w'
    assert get_best_parsable_locale('*w') != '!j'
    assert get_best_parsable_locale('*w') != '>)'

# Generated at 2022-06-24 20:39:50.868093
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(get_best_parsable_locale(str) is None)
    assert(get_best_parsable_locale(str, [str], True) is None)
    assert(get_best_parsable_locale(str, [str], False) is None)
    assert(get_best_parsable_locale(str, [str, str], True) is None)
    assert(get_best_parsable_locale(str, [str, str], False) is None)
    assert(get_best_parsable_locale(str, [str, str, str], True) is None)
    assert(get_best_parsable_locale(str, [str, str, str], False) is None)

# Generated at 2022-06-24 20:39:57.188560
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(']%vz') == 'C'
    assert get_best_parsable_locale(']%vz', ['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(']%vz', ['en_GB.utf-8', 'C', 'POSIX']) == 'en_GB.utf-8'

# Generated at 2022-06-24 20:39:58.398703
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    with pytest.raises(TypeError):
        get_best_parsable_locale()



# Generated at 2022-06-24 20:40:04.137444
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = ']%vz'
    assert get_best_parsable_locale(str_0) == 'C', 'Failed to assert that get_best_parsable_locale is equal to "C"'
    str_1 = ']%vz'
    assert get_best_parsable_locale(str_1, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C', 'Failed to assert that get_best_parsable_locale is equal to "C"'
    str_2 = ']%vz'

# Generated at 2022-06-24 20:40:06.228317
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()


# Test case 2:
# Calling function get_best_parsable_locale() with '[]' as argument


# Generated at 2022-06-24 20:40:09.191541
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() is True


# Generated at 2022-06-24 20:40:11.746413
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert test_case_0()
    except (AssertionError, AttributeError) as e:
        print('Failed test_case_0: %s' % str(e))



# Generated at 2022-06-24 20:40:14.387006
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = ']%vz'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 == 'C', 'Failed to assert get_best_parsable_locale()'

test_get_best_parsable_locale()

# Generated at 2022-06-24 20:40:30.957053
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print("Running test for function: get_best_parsable_locale")
    # populate the test case inputs
    test_case_0()

# vim:ft=python cc=120:

# Generated at 2022-06-24 20:40:40.864001
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(']%vz') == 'C'
    assert get_best_parsable_locale(']%vz', preferences=None) == 'C'
    assert get_best_parsable_locale(']%vz', preferences='C.utf8', raise_on_locale=False) == 'C'
    assert get_best_parsable_locale(']%vz', preferences='en_US.utf8', raise_on_locale=False) == 'en_US.utf8'
    assert get_best_parsable_locale(']%vz', preferences='C', raise_on_locale=False) == 'C'

# Generated at 2022-06-24 20:40:44.221543
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Module import
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
        ),
        supports_check_mode=True
    )

    # Test execution
    test_case_0()

# Generated at 2022-06-24 20:40:52.309395
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # All of the test cases below invoke the function get_best_parsable_locale to compute the value for var_0
    # Input parameters:
    #   str_0: ']%vz'
    # Expected Result:
    #   var_0: 'C'

    str_0 = ']%vz'
    var_0 = get_best_parsable_locale(str_0)
    test_case_0()


if __name__ == '__main__':
    print('Testing module with Python version: %s' % str(sys.version))
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:40:55.063678
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    arg0 = []
    arg1 = True
    expected_return = None
    actual_return = get_best_parsable_locale(arg0, arg1)
    assert actual_return == expected_return

# Generated at 2022-06-24 20:40:57.802727
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = ']%vz'
    var_0 = get_best_parsable_locale(str_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:41:03.991574
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = '1Xa'
    list_0 = [',', 'oZ', '=', 'i', 'x']
    str_1 = get_best_parsable_locale(str_0, list_0, False)
    assert str_1 is not None



# Generated at 2022-06-24 20:41:06.613080
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(str) == 'C'

# Generated at 2022-06-24 20:41:07.193146
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True



# Generated at 2022-06-24 20:41:08.762493
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(0)


# Generated at 2022-06-24 20:41:25.510503
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert '1' == get_best_parsable_locale.__doc__.strip()
    assert 'C' == get_best_parsable_locale(']%vz')

# Generated at 2022-06-24 20:41:27.833504
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass  # TODO: Add unit test implementation for function get_best_parsable_locale

# Generated at 2022-06-24 20:41:30.296691
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:41:32.550338
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(['y', 'z', 'v']) is None, "An exception might have occurred"
#
#
#
#

# Generated at 2022-06-24 20:41:41.444710
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(str) == str
    assert get_best_parsable_locale(str_0) == found_0
    assert get_best_parsable_locale(str_1) == found_1
    assert get_best_parsable_locale(str_2) == found_2
    assert get_best_parsable_locale(str_3) == found_3
    assert get_best_parsable_locale(str_4) == found_4
    assert get_best_parsable_locale(str_5) == found_5
    assert get_best_parsable_locale(str_6) == found_6
    assert get_best_parsable_locale(str_7) == found_7
    assert get_best

# Generated at 2022-06-24 20:41:46.899540
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == ('C')

# Generated at 2022-06-24 20:41:51.584833
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Must raise exception to indicate test failed
    assert (get_best_parsable_locale(str_0) == var_0)


# Unit test execution
test_get_best_parsable_locale()

# Generated at 2022-06-24 20:41:53.833782
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = ']%vz'
    var_0 = get_best_parsable_locale(str_0)


# Generated at 2022-06-24 20:41:55.374451
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except Exception:
        print('Exception:')

# Generated at 2022-06-24 20:42:01.946937
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # User inputs
    str_0 = ']%vz'
    var_0 = get_best_parsable_locale(str_0)
    # Test outputs
    assert var_0 == 'C'


# Generated at 2022-06-24 20:42:20.716558
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(']%vz') == 'C'

# Generated at 2022-06-24 20:42:27.548798
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = ']%vz'
    var_0 = get_best_parsable_locale(str_0)
    str_0 = '\\gO'
    str_1 = '\\"B'
    str_2 = '+q'
    str_3 = 'S'
    str_4 = 'Hm'
    var_1 = get_best_parsable_locale(str_0, [str_1, str_2, str_3, str_4])
    str_0 = 'e^1'
    str_1 = '\\b,c'
    str_2 = 'wLZ'
    str_3 = 'l'
    str_4 = 'xD{'

# Generated at 2022-06-24 20:42:37.101783
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Replace assert with whatever you do to raise an exception when the expected result doesn't match
    assert get_best_parsable_locale(str_0) == var_0

if __name__ == '__main__':
    #
    # Unit Test
    #

    test_0 = get_best_parsable_locale(str_0)

    #
    # Compare expected and returned value
    #
    var_0 = 'C.UTF-8'
    if var_0 != test_0:
        print('Returned Value:', test_0)
        print('Expected Value:', var_0)
        raise SystemExit(1)

    print('Best locale found:', test_0)
    raise SystemExit(0)

# Generated at 2022-06-24 20:42:37.906736
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True


# Generated at 2022-06-24 20:42:47.901777
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = True
    str_0 = '8!'
    str_1 = '_v*'
    list_0 = ['XD', '`h', '@g', 'd', 'Z[=t', 'j)', 'l', '^', 'hXK']
    tuple_0 = (8, 1, '4', '7.4', '<', 0.8)
    intermediateValue_0 = (0.0, -8, list_0, list_0, tuple_0, -6, 0, 3)
    str_2 = '`^'
    str_3 = 'pH'
    tuple_1 = (list_0, 'y9', 'y9', 'y9', intermediateValue_0, 'y9', 'y9', '!', 'y9', 'y9')
    tuple_

# Generated at 2022-06-24 20:42:50.440741
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = None
    var_1 = None
    var_2 = False
    var_3 = None
    var_3 = get_best_parsable_locale(var_0, var_1, var_2)
    str_0 = 'C'
    str_1 = var_3
    #assert str_0 == str_1


# Generated at 2022-06-24 20:42:52.466705
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(']%vz') is None
    assert get_best_parsable_locale('F[Yt') is None
    assert g

# Generated at 2022-06-24 20:42:56.757258
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = ']%vz'
    preferences_0 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    var_0 = get_best_parsable_locale(str_0, preferences_0)


# Standard boilerplate to call the main() function.
if __name__ == '__main__':
    test_case_0()
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:43:04.224107
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_a = ']%vz'
    var_a = get_best_parsable_locale(str_a)
    str_b = 'X'
    var_b = get_best_parsable_locale(str_b)
    str_c = '7Vu'
    var_c = get_best_parsable_locale(str_c)
    str_d = 'T'
    var_d = get_best_parsable_locale(str_d)
    str_e = '6'
    var_e = get_best_parsable_locale(str_e)
    str_f = 'Hx'
    var_f = get_best_parsable_locale(str_f)
    str_g = ':'

# Generated at 2022-06-24 20:43:04.967242
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(str_0  ) == var_0

# Generated at 2022-06-24 20:43:39.705302
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print("[*] Starting unit test for function get_best_parsable_locale")

    try:
        test_case_0()
    except Exception as err:
        print("[!] An error occurred while testing the function get_best_parsable_locale()")
        print("[!] The error was: " + str(err))
        return False

    print("[*] Finished unit test for function get_best_parsable_locale")

    return True

# Generated at 2022-06-24 20:43:41.988526
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert 'C' == get_best_parsable_locale(str_0)
    except:
        var_1 = False
    else:
        var_1 = True

    assert var_1

# Generated at 2022-06-24 20:43:51.004432
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = ']%vz'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 == 'C'

    str_0 = 'Tk}mj'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 == 'C'

    str_0 = 'g:$E'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 == 'C'

    str_0 = '5Nv;='
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 == 'C'

    str_0 = 'a8,3~'
    var_0 = get_best_parsable_

# Generated at 2022-06-24 20:43:57.087054
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        preferences = ['C.utf8', 'en_US.utf8', 'POSIX']
        raise_on_locale = True
        str_0 = ']%vz'
        var_0 = get_best_parsable_locale(str_0, preferences, raise_on_locale)
        assert 'C' == var_0
    except Exception as e:
        assert False, "Unable to execute function get_best_parsable_locale: " + type(e).__name__ + " - " + str(e)

# Create out test class

# Generated at 2022-06-24 20:44:02.308294
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True


# Generated at 2022-06-24 20:44:07.820146
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_1 = '}'
    var_0 = get_best_parsable_locale(str_1)
    assert var_0 == 'C'

    str_2 = '0>|r'
    var_1 = get_best_parsable_locale(str_2)
    assert var_1 == 'C'

    str_var_0 = 'eb:^'
    int_var_0 = 1
    var_2 = get_best_parsable_locale(str_var_0, int_var_0)
    assert var_2 == 'C'

    str_var_1 = 'n>_'
    int_var_1 = 1
    var_3 = get_best_parsable_locale(str_var_1, int_var_1)
    assert var_

# Generated at 2022-06-24 20:44:11.799972
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    a = get_best_parsable_locale("[9zGv")
    print(a)

    # if __name__ == "__main__":
    #     print("testing get_best_parsable_locale starting")
    #     test_case_0()
    #     print("testing get_best_parsable_locale done")

# Generated at 2022-06-24 20:44:13.496372
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = 'bV"UJ'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 is None



# Generated at 2022-06-24 20:44:20.811977
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Input parameters
    str_0 = [
        'Unable to get locale information, rc=',
        '_US.utf8'
    ]
    str_1 = 'C.utf8'

    # Expected results
    var_0 = get_best_parsable_locale(str_0, str_1)
    assert var_0[0] == 'en'
    assert var_0[1] == 'utf8'
    assert var_0 == 'en_US.utf8'



# Generated at 2022-06-24 20:44:22.596436
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_0 = ']%vz'
    var_0 = get_best_parsable_locale(str_0)
    return var_0 == 'C'
###############################################################################



# Generated at 2022-06-24 20:45:09.139033
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    str_1 = 'O#'
    str_2 = 'ngo!>U'
    str_3 = '*C&&^'

    try:
        assert str_1 == get_best_parsable_locale(str_1,str_2,str_3)
    except AssertionError as e:
        raise(e)
    try:
        assert str_1 != get_best_parsable_locale(str_2,str_2,str_3)
    except AssertionError as e:
        raise(e)
    try:
        assert str_1 != get_best_parsable_locale(str_3,str_2,str_3)
    except AssertionError as e:
        raise(e)

# Generated at 2022-06-24 20:45:11.919522
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert get_best_parsable_locale(None) == 'C'
    except (AssertionError, RuntimeWarning) as e:
        print(e)
        raise(e)



# Generated at 2022-06-24 20:45:16.511474
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # This test case could fail because the list of available
    # locales can change, but is unlikely to do so
    str_0 = ']%vz'
    var_0 = get_best_parsable_locale(str_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:45:21.720370
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert get_best_parsable_locale(None) is None
    except (TypeError, AttributeError) as e:
        print(e)
        assert False


# Unit tests included at the bottom of this file

# Generated at 2022-06-24 20:45:27.033439
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
        test_case_1()
        test_case_2()

    # Catch exceptions
    except Exception as e:
        print(e)

    # Check if the results are equal
    assert var_0 == var_0


# Excute the unit tests
test_get_best_parsable_locale()