

# Generated at 2022-06-24 20:35:36.567565
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)
    assert get_best_parsable_locale(float_0) == var_0

# Generated at 2022-06-24 20:35:39.777507
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(float) == 'C'
    assert get_best_parsable_locale(float, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-24 20:35:41.519221
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(module, preferences, raise_on_locale) == "C"


# Generated at 2022-06-24 20:35:45.451615
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:35:47.610941
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    expected = ''
    assert expected == get_best_parsable_locale()


if __name__ == '__main__':
    import pytest
    pytest.main(['test_get_best_parsable_locale.py'])

# Generated at 2022-06-24 20:35:55.947258
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    description = ''
    float_0 = None
    preferences = [u'C.utf8', u'en_US.utf8', u'C', u'POSIX']
    raise_on_locale = False

    var_0 = get_best_parsable_locale(float_0, preferences, raise_on_locale)

    if var_0 != 'C':
        raise RuntimeError('get_best_parsable_locale returned %s, but expected %s' % (repr(var_0), repr('C')))

# Generated at 2022-06-24 20:35:58.167472
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert abs(test_case_0())
    raise SystemExit

# Unit test to prove we catch the case when no best parsable locale is provided

# Generated at 2022-06-24 20:36:02.861566
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Case 0:
    #    float_0 = None
    #    var_0 = get_best_parsable_locale(float_0)
    # Expected:
    #    var_0 = "C"
    test_case_0()

# Generated at 2022-06-24 20:36:07.386299
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' == get_best_parsable_locale(None)

# Generated at 2022-06-24 20:36:09.691759
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_0 = None
    assert isinstance(get_best_parsable_locale(float_0), str)

# Generated at 2022-06-24 20:36:14.483049
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:36:18.716087
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert set_default_locale(None, False) == 'C'

# Generated at 2022-06-24 20:36:21.930402
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert isinstance(test_case_0(), tuple)



# Generated at 2022-06-24 20:36:25.432398
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(module=None) is not None

if __name__ == "__main__":
    test_case_0()
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:36:27.273844
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_0 = None
    var_0 = get_best_parsable_locale(float_0)



# Generated at 2022-06-24 20:36:29.368571
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(float_0) == var_0


# Generated at 2022-06-24 20:36:31.847542
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(test_case_0) != 0


# Generated at 2022-06-24 20:36:33.360726
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(1) != "C"

# Generated at 2022-06-24 20:36:37.509555
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert test_case_0()
    except AssertionError as e:
        print("test case 0 failed with: " + str(e))
        assert False
    else:
        assert True


test_get_best_parsable_locale()

# Generated at 2022-06-24 20:36:39.865617
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert(get_best_parsable_locale(test_case_0) is not None)
    except:
        assert(get_best_parsable_locale(test_case_0) is not None)

# Generated at 2022-06-24 20:36:48.724930
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Strings of floats
    func = get_best_parsable_locale
    assert func(float_0) == var_0


# Generated at 2022-06-24 20:36:49.632358
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == None

# Generated at 2022-06-24 20:36:54.454123
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert test_case_0() == None



# Generated at 2022-06-24 20:36:55.826309
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-24 20:37:00.439943
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = None

    test_case_0()


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:37:03.028023
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # float_0 = None
    # var_0 = get_best_parsable_locale(float_0)
    if __name__ == "__main__":
        test_case_0()

# Generated at 2022-06-24 20:37:05.446403
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var = get_best_parsable_locale(None, None, True)
    assert var == None
    var = get_best_parsable_locale(None, None, True)
    assert var == None

# Generated at 2022-06-24 20:37:06.193141
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert isinstance(get_best_parsable_locale(float), float)



# Generated at 2022-06-24 20:37:15.982285
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import PY3

    if not PY3:
        import __builtin__ as builtins
    else:
        import builtins

    with tempfile.TemporaryDirectory() as tempdir:
        with open(os.path.join(tempdir, 'stdout'), 'w+b') as stdout:
            with open(os.path.join(tempdir, 'stderr'), 'w+b') as stderr:
                stdout.write(b"C\naz_AZ.UTF-8\nC.UTF-8\n")
                stdout.seek(0)

# Generated at 2022-06-24 20:37:16.540067
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

# Generated at 2022-06-24 20:37:24.640915
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() is None, "If there's a failure, it will be printed out"

# Generated at 2022-06-24 20:37:30.690938
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_1 = None
    result_0 = get_best_parsable_locale(var_1)
    assert result_0 == 'C'
    var_2 = None
    var_3 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    result_1 = get_best_parsable_locale(var_2, var_3)
    assert result_1 == 'C'


if __name__ == "__main__":
    test_case_0()
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:37:34.981183
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert not get_best_parsable_locale(float_0, ['C', 'POSIX', 'C.utf8', 'en_US.utf8'], True)
    except RuntimeWarning:
        assert False
    except Exception:
        assert True


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:37:37.522008
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass


# Generated at 2022-06-24 20:37:41.041657
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert test_case_0() == 'C'
    except AssertionError:
        print('test_case_0 failed')

# Generated at 2022-06-24 20:37:43.650447
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_0 = 17.787689071936267
    assert float_0 == float_0
    var_0 = get_best_parsable_locale(float_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:37:45.252554
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(get_best_parsable_locale(test_case_0) == 'C')
test_get_best_parsable_locale()

# Generated at 2022-06-24 20:37:46.496072
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)


# Generated at 2022-06-24 20:37:52.479048
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test with default argument
    float_0 = None
    var_0 = get_best_parsable_locale(float_0)
    #print('var_0', var_0)

    # Test with a first argument
    float_1 = 1
    preferences_1 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    var_1 = get_best_parsable_locale(float_1, preferences_1)
    #print('var_1', var_1)

    # Test with a second argument
    float_2 = 2
    preferences_2 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    raise_on_locale_2 = True

# Generated at 2022-06-24 20:37:54.831928
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_0 = None
    # var_0 = get_best_parsable_locale(float_0)
    # assert var_0 == 'C'
    pass

# Generated at 2022-06-24 20:38:12.444731
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, []) == 'C', "get_best_parsable_locale(None, [])"
    assert get_best_parsable_locale(None, ['POSIX']) == 'C', "get_best_parsable_locale(None, ['POSIX'])"
    assert get_best_parsable_locale(None, ['POSIX', 'C']) == 'C', "get_best_parsable_locale(None, ['POSIX', 'C'])"

# Generated at 2022-06-24 20:38:13.518038
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True


# Generated at 2022-06-24 20:38:16.304789
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_0 = None
    var_0 = get_best_parsable_locale(float_0)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 20:38:23.953834
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(
        argument_spec = dict(
            module = dict(),
            preferences = dict(),
            raise_on_locale = dict()
        )
    )
    # float_0 = None
    # float_1 = None
    # float_2 = None
    # float_3 = None

    # var_0 = get_best_parsable_locale(float_0, float_1, float_2, float_3)
    get_best_parsable_locale(AnsibleModule, ['C.utf8', 'en_US.utf8', 'C', 'POSIX'], False)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:38:25.486993
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_0 = None
    var_0 = get_best_parsable_locale(float_0)



# Generated at 2022-06-24 20:38:27.966762
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert "test_case_0"
    except AssertionError:
        raise AssertionError()

# Generated at 2022-06-24 20:38:30.089182
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_0 = None
    var_0 = get_best_parsable_locale(float_0, None, False)
    print(var_0)


test_case_0()
test_get_best_parsable_locale()

# Generated at 2022-06-24 20:38:34.737734
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    x = 0

    # Input params type test
    if not isinstance(x, int):
        raise TypeError('Expected "int" type for input param "x"')


# Ensures that on all versions of Python, the code can be compiled to valid syntax
if __name__ == '__main__':
    test_get_best_parsable_locale()
    test_case_0()

# Generated at 2022-06-24 20:38:44.302153
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-24 20:38:46.028029
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()



# Generated at 2022-06-24 20:38:54.862331
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_1 = None
    var_1 = get_best_parsable_locale(float_1)

# Generated at 2022-06-24 20:38:56.424087
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == 'C'

test_case_0()

# Generated at 2022-06-24 20:39:02.605509
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    float_0 = None
    assert \
        get_best_parsable_locale(float_0) == "C"

    float_1 = None
    list_0 = ["en_US.utf8", "C.utf8", "en_US.UTF-8", "C", "POSIX"]
    assert \
        get_best_parsable_locale(float_1, list_0) == "C"

# Description:
# Test to verify that assert statements are used in ansible.module_utils.get_best_parsable_locale

# Generated at 2022-06-24 20:39:03.888116
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True


# Generated at 2022-06-24 20:39:10.310856
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
  with setlocale(LC_ALL, 'C'):
    # check that it raises if no locale is installed
    assert get_best_parsable_locale({}) == 'C'
    assert get_best_parsable_locale({}, raise_on_locale=True)

# Generated at 2022-06-24 20:39:20.853247
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
   
    # Passed variables
    module = AnsibleModule(
        argument_spec=dict(
            prefs=dict(required=False, type='list')
        )
    )
    preferences = module.params['prefs']

    # Test to see if locale tool exists
    locale = module.get_bin_path("locale")
    if not locale:
        module.fail_json(msg="Unable to find 'locale' tool")

    # Test to see if locale tool outputs anything
    rc, out, err = module.run_command([locale, '-a'])
    if rc != 0:
        module.fail_json(msg="Unable to get locale information, rc=%s: %s" % (rc, to_native(err)))

# Generated at 2022-06-24 20:39:21.744670
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_0 = None
    var_0 = get_best_parsable_locale(float_0)

# Generated at 2022-06-24 20:39:27.246518
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        preferences = [
            'en_US.utf8',
            'fr_FR.utf8',
            'de_DE.utf8',
            'C.utf8',
            'C',
            'POSIX',
        ]
        test_case_0()
    except RuntimeError as e:
        print("Runtime Error: %s" % str(e))
    except Exception as e:
        print("Exception in user code: %s" % str(e))
    else:
        print("Coding completed")

# Main program for unit testing
if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:39:35.625798
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # These require the Python "mock" module.
    # You can install it with: pip install mock
    # Add a mock scenario to this test that checks
    # that if a valid locale is returned, it is 'en_US.utf8'
    float_1 = None
    var_1 = get_best_parsable_locale(float_1)
    assert var_1 == 'en_US.utf8'
    # Add a mock scenario to this test that checks
    # that if a valid locale is not returned, it is False
    float_2 = None
    var_2 = get_best_parsable_locale(float_2)
    assert var_2 is False

# Generated at 2022-06-24 20:39:38.031554
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert not get_best_parsable_locale('test_string')


# Generated at 2022-06-24 20:39:46.055840
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 1 == 1

# Generated at 2022-06-24 20:39:55.076108
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    mock = Mock(
        return_value=MagicMock(
            get_bin_path=MagicMock(
                return_value=MagicMock(
                    run_command=MagicMock(
                        return_value=MagicMock(
                            returncode=0,
                            stdout='test_0',
                            stderr=None
                        )
                    )
                )
            )
        )
    )

# Generated at 2022-06-24 20:40:01.866291
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Setup
    preferences = ["C.utf8", "en_US.utf8", "C", "POSIX"]
    raise_on_locale = False

    # Testing if the call to get_best_parsable_locale() raises
    # a RuntimeError exception
    with pytest.raises(RuntimeWarning):
        get_best_parsable_locale(preferences, raise_on_locale)

# Generated at 2022-06-24 20:40:02.711927
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == None

# Generated at 2022-06-24 20:40:04.149467
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()


# Test  get_best_parsable_locale function

# Generated at 2022-06-24 20:40:05.003306
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True


# Generated at 2022-06-24 20:40:06.798262
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    if (True): # TODO: if True
        assert True # TODO: assert True


# Generated at 2022-06-24 20:40:13.547687
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # call function function_0 with arguments
    assert 1 #expected output is 1
    
## Unit test for function get_best_parsable_locale
## @returns: 0 on success
#def test_get_best_parsable_locale_2():
#    run_main(test_case_0)
#    return 0

if __name__ == "__main__":
    import sys
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:40:14.220172
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:40:23.619160
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Ignore traceback output from nose
    import sys
    from io import StringIO
    tar = StringIO()
    sav = sys.stderr
    sys.stderr = tar

    # Check for exceptions if present
    try:

        test_case_0()
    except Exception as e:
        assert False, str(e)

    sys.stderr = sav

    # Check for print statements if present
    import re
    tar = StringIO()
    sav = sys.stdout
    sys.stdout = tar

    # Check for print statements if present
    test_case_0()
    s = tar.getvalue()
    tar.close()
    sys.stdout = sav

    assert s == "", "Unit test for function get_best_parsable_locale failed"

# Generated at 2022-06-24 20:40:33.556744
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Run test
    test_case_0()


if __name__ == '__main__':
    # Run the test
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:40:43.431506
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = ansible_collections.ansible.posix.plugins.modules.get_best_parsable_locale

    assert module.get_best_parsable_locale(module, preferences=None)

    assert module.get_best_parsable_locale(module, preferences=None, raise_on_locale=False)

    assert module.get_best_parsable_locale(module, preferences=None, raise_on_locale=True)

    assert module.get_best_parsable_locale(module, preferences=[None], raise_on_locale=False)

    assert module.get_best_parsable_locale(module, preferences=[None], raise_on_locale=True)


# Generated at 2022-06-24 20:40:51.301870
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(test_case_0) == 'C'

# Generated at 2022-06-24 20:40:53.764287
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Module is imported as float
    var_1 = get_best_parsable_locale(float)

    assert var_1 == 'C'


# Generated at 2022-06-24 20:40:54.674921
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:40:56.868879
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Step 1
    assert True

    # Step 2
    assert True

    # Step 3
    assert True

    # Step 4
    assert True


# Generated at 2022-06-24 20:41:02.387611
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_0 = None
    var_0 = get_best_parsable_locale(float_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:41:04.095388
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' == get_best_parsable_locale(None)

# Generated at 2022-06-24 20:41:07.846067
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except AssertionError as e:
        print('AssertionError')
        print(e)


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:41:10.030272
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_0 = None
    var_0 = get_best_parsable_locale(float_0)



# Generated at 2022-06-24 20:41:19.102866
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(1, 2) == 'C'

# Generated at 2022-06-24 20:41:25.495059
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert(get_best_parsable_locale() == None)
    except:
        assert(False)

# Generated at 2022-06-24 20:41:26.661728
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True
    assert True



# Generated at 2022-06-24 20:41:32.586527
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # this is a stub
    float_0 = None
    assert get_best_parsable_locale(float_0) == 'C'


# Generated at 2022-06-24 20:41:34.972263
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec={})
    float_0 = None
    var_0 = get_best_parsable_locale(module, float_0)

# Generated at 2022-06-24 20:41:36.207916
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 1 is 0, "Test fails"


# Generated at 2022-06-24 20:41:37.132537
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:41:37.834295
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale()

# Generated at 2022-06-24 20:41:39.193569
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    
    # Test case for function get_best_parsable_locale
    assert test_case_0() == 'C'

# Generated at 2022-06-24 20:41:44.706696
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(test_case_0) == 'C' 

#---------------------------------------------------------------------
# ansible.module_utils.basic.py
#---------------------------------------------------------------------
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type



# Generated at 2022-06-24 20:42:06.895065
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import ansible.repository
    import ansible.module_utils.common.process
    import ansible.modules.system

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

 
    class TestAnsibleModuleGetBestParsableLocale(unittest.TestCase):
        def test_get_best_parsable_locale(self):
            res = get_best_parsable_locale(None)
            self.assertEqual(res, 'C')
 
    unittest.main()

# Generated at 2022-06-24 20:42:09.162211
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale), "The function 'get_best_parsable_locale' should be a function"



# Generated at 2022-06-24 20:42:10.742185
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('float_0', 'preferences') == 'C'



# Generated at 2022-06-24 20:42:13.973870
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = None
    var_1 = None
    var_0 = get_best_parsable_locale(var_0)

    assert var_0 == 'C', "Expected 'C', got '{}'.".format(var_0)


# Generated at 2022-06-24 20:42:15.488306
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert isinstance(get_best_parsable_locale(), str)



# Generated at 2022-06-24 20:42:16.925749
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-24 20:42:19.503258
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # variable for return value
    var_0 = None

    # variable for float paramater
    float_0 = None

    # Calling the function
    var_0 = get_best_parsable_locale(float_0)

# Generated at 2022-06-24 20:42:21.316767
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)
    # Test No.0
    try:
        test_case_0()
    except Exception:
        pass

# Generated at 2022-06-24 20:42:23.047235
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:42:23.817409
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() is None

# Generated at 2022-06-24 20:42:58.051395
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert  get_best_parsable_locale() == None

# Generated at 2022-06-24 20:42:59.840488
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_1 = get_best_parsable_locale(module, preferences=None, raise_on_locale=False)
    assert True


# Generated at 2022-06-24 20:43:00.947028
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale == "C.utf8"

# Generated at 2022-06-24 20:43:02.282525
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale( None, None, True) == 'C'

# Generated at 2022-06-24 20:43:05.997926
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    param_0 = None
    param_1 = None
    param_2 = None
    get_best_parsable_locale(param_0, param_1, param_2)

# Generated at 2022-06-24 20:43:08.997189
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Positional argument types:
    float_0 = get_best_parsable_locale(float_0)
    # Keyword argument types:
    float_0 = get_best_parsable_locale(float_0)

# Generated at 2022-06-24 20:43:10.899544
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert "C" == get_best_parsable_locale()
    assert "en_US.utf8" == get_best_parsable_locale()

# Generated at 2022-06-24 20:43:12.821364
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path
    float_0 = None
    get_bin_path(float_0)
    get_best_parsable_locale(float_0)


# Generated at 2022-06-24 20:43:13.317163
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

# Generated at 2022-06-24 20:43:14.665228
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Tests for None

    # Returns an instance of the Exception class
    assert test_case_0 ()



# Generated at 2022-06-24 20:43:53.909069
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        float_0 = None
        var_0 = get_best_parsable_locale(float_0)
        assert var_0 == "C"
    except RuntimeWarning:
        pass
    else:
        raise Exception("Test failed")



# Generated at 2022-06-24 20:43:55.223350
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    with pytest.raises(AttributeError):
        test_case_0()

# Generated at 2022-06-24 20:44:02.940943
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = get_best_parsable_locale(ansible_module, preferences=None, raise_on_locale=False)
    if var_0 == 'C':
        ansible_module.fail_json(msg="Error: get_best_parsable_locale")
    else:
        ansible_module.exit_json(changed=False)

if __name__ == '__main__':
    from ansible.module_utils.basic import *

    if not HAS_LANGTABLE:
        module.fail_json(msg='langtable is required for this module')


# Generated at 2022-06-24 20:44:03.885081
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(test_case_0()) == None

# Generated at 2022-06-24 20:44:10.586118
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test for get_best_parsable_locale
    # Attempts to return the best possible locale for parsing output in English
    # useful for scraping output with i18n tools. When this raises an exception
    # and the caller wants to continue, it should use the 'C' locale.
    # Return type: string
    float_0 = None
    var_0 = get_best_parsable_locale(float_0)
    assert isinstance(var_0, str)

# Generated at 2022-06-24 20:44:12.132427
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Off by default, since it is only used by helper plugins
    # test_case_0()
    assert False


# Generated at 2022-06-24 20:44:18.197813
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)
    assert get_best_parsable_locale('module', 'preferences', 'raise_on_locale') == 'C'

# Generated at 2022-06-24 20:44:22.229354
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(test_case_0) is None


# Generated at 2022-06-24 20:44:23.687995
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Run 'get_best_parsable_locale' with correct parameters
    get_best_parsable_locale(float_0)



# Generated at 2022-06-24 20:44:29.006894
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Python 2.7 and 3.3 do not have the same interface for assertRaises
    # contextlib.contextmanager does not exist in 2.7
    if sys.version_info[:2] == (2, 7):
        from contextlib import nested
        from StringIO import StringIO
        from StringIO import StringIO


# Generated at 2022-06-24 20:45:12.425678
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    float_0 = None
    var_0 = get_best_parsable_locale(float_0)

if __name__ == '__main__':
    try:
        test_case_0()
    except:
        pass
    try:
        test_get_best_parsable_locale()
    except:
        pass

# Generated at 2022-06-24 20:45:16.020565
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Unit test for function get_best_parsable_locale
    float_0 = None
    var_0 = get_best_parsable_locale(float_0)

# Generated at 2022-06-24 20:45:16.515069
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

# Generated at 2022-06-24 20:45:18.855062
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Place your code here
    assert True
    
    

# Generated at 2022-06-24 20:45:21.222665
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(float_0) == var_0

# Generated at 2022-06-24 20:45:26.163128
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert isinstance(get_best_parsable_locale(preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']), str)
    assert isinstance(get_best_parsable_locale(raise_on_locale=True), str)



# Generated at 2022-06-24 20:45:34.062852
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert find_most_specific_match((1, 2, 3), (4, 5, 6)) == (4, 5, 6)
    assert find_most_specific_match((1, 2, 3), (1, 2, 3)) == (1, 2, 3)
    assert find_most_specific_match((1, 2, 3), (1, 2, 3, 4)) == (1, 2, 3, 4)
    assert find_most_specific_match((1, 2, 3, 4), (1, 2, 3, 4)) == (1, 2, 3, 4)
    assert find_most_specific_match((1, 2, 3, 4), (1, 2, 3)) == (1, 2, 3)