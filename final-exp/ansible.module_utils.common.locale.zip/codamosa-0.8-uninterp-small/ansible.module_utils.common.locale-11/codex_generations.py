

# Generated at 2022-06-24 20:35:37.661657
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(get_best_parsable_locale(dict_0) == ('C'))


# Generated at 2022-06-24 20:35:45.741928
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Setup
    arg_0 = ''
    arg_1 = None
    arg_2 = ''

    try:
        var_0 = get_best_parsable_locale(arg_0, arg_1, arg_2)
        return var_0
    except:
        info = get_exception()
        if info['alias']:
            raise AssertionError("{0} {1} {2}".format(info['name'], info['desc'], info['alias'])) from None
        else:
            raise AssertionError("{0} {1}".format(info['name'], info['desc'])) from None


# Generated at 2022-06-24 20:35:47.353967
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = {}
    var_0 = get_best_parsable_locale(var_0)
    var_1 = get_best_parsable_locale(var_0)

# Generated at 2022-06-24 20:35:51.375413
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = {}
    var_0['module'] = test_case_0()
    var_1 = get_best_parsable_locale(var_0)
    print(var_1)

# Generated at 2022-06-24 20:35:55.540921
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale({"get_bin_path": lambda x: "/usr/bin/locale"}, preferences=["C", "POSIX", "C.utf8", "en_US.utf8"]) == "C"

# Generated at 2022-06-24 20:35:56.581610
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()
    assert True



# Generated at 2022-06-24 20:35:58.341421
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    dict_0 = {}
    var_0 = get_best_parsable_locale(dict_0)

# Generated at 2022-06-24 20:36:02.237099
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except RuntimeWarning as tmp_0:
        # Unable to get locale information, rc=1: locale: command not found
        assert True
    else:
        assert False

# Generated at 2022-06-24 20:36:04.149874
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale({}) == 'C'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:36:07.531747
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert get_best_parsable_locale(dict_0) == "C"
    except AssertionError:
        raise AssertionError(get_best_parsable_locale.__name__ + " unit test failed")


# Generated at 2022-06-24 20:36:21.325858
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert not get_best_parsable_locale(dict_0, raise_on_locale=True), "Should be False"
    assert not get_best_parsable_locale(dict_0), "Should be False"
    try:
        assert get_best_parsable_locale(dict_0, raise_on_locale=True), "Should be True"
    except RuntimeWarning:
        pass
    try:
        assert get_best_parsable_locale(dict_0), "Should be True"
    except RuntimeWarning:
        pass

# Generated at 2022-06-24 20:36:25.344772
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(dict_0) == None
    try:
        assert get_best_parsable_locale(dict_0) == None
    except ValueError:
        pass
    finally:
        assert 1 == 1


# Generated at 2022-06-24 20:36:27.494735
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    dict_0 = {}

    # None, but only because we don't implement this function in Ansible.
    var_0 = get_best_parsable_locale(dict_0)

# Generated at 2022-06-24 20:36:37.441261
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    dict_0 = {"get_bin_path.return_value": "bin_path", "run_command.return_value": (0, "out", "err")}
    var_0 = get_best_parsable_locale(dict_0)
    assert var_0 == "C"

    dict_0 = {"get_bin_path.return_value": None, "run_command.return_value": (0, "out", "err")}
    var_0 = get_best_parsable_locale(dict_0)
    assert var_0 == "C"

    dict_0 = {"get_bin_path.return_value": "bin_path", "run_command.return_value": (1, "out", "err")}

# Generated at 2022-06-24 20:36:39.422141
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    dict_0 = {}
    var_0 = get_best_parsable_locale(dict_0)
    assert var_0 == "C"


# Generated at 2022-06-24 20:36:40.806235
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """Check if the function gets the right output"""
    assert test_case_0() == 'C'

# Generated at 2022-06-24 20:36:52.785010
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = {}
    assert get_best_parsable_locale(var_0) == 'C'

    var_1 = {}
    var_1['module'] = {}
    var_1['module'].get_bin_path = lambda x: get_bin_path(x)
    var_1['module'].run_command = lambda x: run_command(x)
    assert get_best_parsable_locale(var_1) == 'en_US.utf8'

    var_1 = {}
    var_1['module'] = {}
    var_1['module'].get_bin_path = lambda x: get_bin_path(x)
    var_1['module'].run_command = lambda x: run_command(x, fail=True)
    assert get_best_parsable

# Generated at 2022-06-24 20:36:58.820695
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    idx_0 = 0

# Generated at 2022-06-24 20:36:59.351895
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-24 20:37:01.339502
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print("Testing get_best_parsable_locale")
    test_case_0()

# Unit test entry point

# Generated at 2022-06-24 20:37:09.896232
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    dict_0 = {}
    var_0 = get_best_parsable_locale(dict_0)


# Generated at 2022-06-24 20:37:15.406817
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec={
            'preferences': dict(type='list'),
        }
    )
    assert get_best_parsable_locale(module) == 'C'


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:37:24.700483
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    dict_0 =  {
        "stdout": "en_GB.utf8 en_US.utf8 zh_CN zh_TW zh_CN.utf8 zh_TW.utf8 C C.utf8 POSIX"
    }
    var_0 = get_best_parsable_locale(dict_0, ['zh_CN', 'en_US.utf8'])
    assert var_0 == 'zh_CN'
    dict_1 = {}
    var_1 = get_best_parsable_locale(dict_1)
    assert var_1 == 'C'

# Generated at 2022-06-24 20:37:26.503439
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' == get_best_parsable_locale(dict_0, True, True)

# Generated at 2022-06-24 20:37:28.232939
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' == get_best_parsable_locale()

# Generated at 2022-06-24 20:37:35.542614
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Mock module
    from ansible.module_utils.basic import AnsibleModule
    mock_module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(type='list', default=None),
            raise_on_locale=dict(type='bool', default=False)
        ),
        supports_check_mode=True
    )
    mock_module.params = dict(
        preferences=None,
        raise_on_locale=False
    )

    # Mock locale
    import os
    os.environ['AN_ENV_VAR'] = 'en_US.utf8'
    mock_locale = MagicMock()

# Generated at 2022-06-24 20:37:42.503948
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
  try:
    test_case_0()
  except:
    import traceback, sys
    exc_type, exc_value, exc_traceback = sys.exc_info()
    traceback.print_exception(exc_type, exc_value, exc_traceback,
                              limit=2, file=sys.stdout)
    print("Failed")
  else:
    print("Success")

# Generated at 2022-06-24 20:37:46.881138
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print('Testing get_best_parsable_locale Function')

    dict_0 = {}
    choices_0 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    var_0 = get_best_parsable_locale(dict_0, choices_0)

    assert var_0 == 'C'
    print('OK, get_best_parsable_locale Function')


# Generated at 2022-06-24 20:37:47.795061
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(dict_0) == 'C'



# Generated at 2022-06-24 20:37:51.348956
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True



# Generated at 2022-06-24 20:38:07.855538
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Try this one for fun
    module = {}
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-24 20:38:09.261755
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(dict_0) == None

# Generated at 2022-06-24 20:38:09.853070
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True

# Generated at 2022-06-24 20:38:13.776773
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # 'C' is the default and found at the end of the list
    expected = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    for i in range(3):
        assert test_case_0() == expected


# Generated at 2022-06-24 20:38:16.801959
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(module=dict_0) == var_0, 'Expected call to get_best_parsable_locale did not return expected value'

# Generated at 2022-06-24 20:38:25.147042
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    dict_0 = {}
    preferences_0 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    var_0 = get_best_parsable_locale(dict_0, preferences_0, True)
    assert var_0 == "", "Expected '', got {}".format(var_0)
    var_0 = get_best_parsable_locale(dict_0, True)
    assert var_0 == "", "Expected '', got {}".format(var_0)
    var_0 = get_best_parsable_locale(dict_0)
    assert var_0 == "", "Expected '', got {}".format(var_0)

# def main():
#     test_get_best_parsable_locale()
#
#

# Generated at 2022-06-24 20:38:35.201120
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Assign and assert.
    expected = 'C.utf8'
    result = get_best_parsable_locale({'rc': 0, 'out': 'C.utf8\nC.utf8', 'err': ''}, ["C.utf8", "C"], False)
    assert result == expected
    result = get_best_parsable_locale({'rc': 0, 'out': 'POSIX\nC.utf8\nC', 'err': ''}, ["POSIX", "C"], False)
    assert result == expected
    result = get_best_parsable_locale({'rc': 0, 'out': 'POSIX\nC.utf8', 'err': ''}, ["POSIX", "C"], False)
    assert result == expected

# Generated at 2022-06-24 20:38:35.768675
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True

# Generated at 2022-06-24 20:38:36.964616
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Make sure we are getting the value we expect
    assert True == True

# Generated at 2022-06-24 20:38:38.791124
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(dict_0) == 'C'


# Generated at 2022-06-24 20:38:54.847470
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == 'C'

# Generated at 2022-06-24 20:38:55.709093
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(test_case_0())

# Generated at 2022-06-24 20:39:01.124174
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Creating dict to pass parameters
    dict_0 = {}

    # Passing parameters to test
    var_0 = get_best_parsable_locale(dict_0)

    # Dumping output
    print("Locale: " + var_0)

if __name__ == '__main__':
    # Unit test execution
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:39:03.829803
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(dict_0, var_0) == var_0

if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:39:08.114793
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == None


# Generated at 2022-06-24 20:39:11.012809
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = {"foo": "bar"}
    var_0 = {"foo": "bar"}
    var_0 = {"foo": "bar"}
    var_0 = {"foo": "bar"}
    var_0 = {"foo": "bar"}
    assert var_0 == "C"

# Generated at 2022-06-24 20:39:12.716180
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    retval = get_best_parsable_locale('module', 'preferences', 'raise_on_locale')
    assert retval is None


# Generated at 2022-06-24 20:39:21.162466
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    D = {}
    D['called_with_args'] = False
    D['called_with_kwargs'] = False
    D['get_bin_path_calls'] = 0
    D['run_command_calls'] = 0
    def get_bin_path(x, required=False):
        D['called_with_args'] = (x == 'locale')
        D['called_with_kwargs'] = (required == False)
        D['get_bin_path_calls'] += 1
        return 'locale'
    def run_command(x):
        D['called_with_args'] = (x == ['locale', '-a'])
        D['run_command_calls'] += 1
        return (0, 'C', None)

    D['get_bin_path'] = get_bin

# Generated at 2022-06-24 20:39:28.361366
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    mock_module = type('', (), {})()
    mock_module.get_bin_path = type('', (), {})()

    mock_module.get_bin_path.return_value = 'fake_bin_path'

    mock_run_command = type('', (), {})()
    mock_module.run_command = type('', (), {})()
    mock_module.run_command.return_value = (0, 'foo bar', '')

    result = get_best_parsable_locale(mock_module)

    assert(result) == 'foo bar'
    mock_module.run_command.assert_called_with(['fake_bin_path', '-a'])

# Generated at 2022-06-24 20:39:30.064129
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # test_case_0
    assert test_case_0() == None

# Generated at 2022-06-24 20:39:59.813637
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale == 'C'

# Generated at 2022-06-24 20:40:04.958520
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec=dict(
        preferences=dict(type='list', elements='str'),
        raise_on_locale=dict(type='bool', default=False)),
        supports_check_mode=True)
    result = get_best_parsable_locale(module)
    module.exit_json(msg=to_native(result))



from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-24 20:40:06.755478
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == None, "get_best_parsable_locale() did not return expected value "

# Generated at 2022-06-24 20:40:16.393049
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Method to test params
    def test_get_best_parsable_locale_params(dict_0):
        var_0 = get_best_parsable_locale(dict_0)
        return var_0

    # Patch to mock the ansible params
    with mock.patch('ansible.utils.get_best_parsable_locale.get_bin_path') as patched_get_bin_path:
        with mock.patch('ansible.utils.get_best_parsable_locale.run_command') as patched_run_command:
            patched_get_bin_path.return_value = None

            patched_run_command.return_value = (0, "", "")
            test_get_best_parsable_locale_params(dict_0)

            patched_run_command

# Generated at 2022-06-24 20:40:17.762222
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert "C" == get_best_parsable_locale({})

# Generated at 2022-06-24 20:40:19.093726
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == 'C'


# Generated at 2022-06-24 20:40:20.651361
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale({}) is None

# Generated at 2022-06-24 20:40:21.496516
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()



# Generated at 2022-06-24 20:40:22.278466
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:40:24.988273
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    dict_0 = {}
    var_0 = get_best_parsable_locale(dict_0)
    assert str(var_0) == "C"
    list_0 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    var_1 = get_best_parsable_locale(dict_0, list_0)
    assert str(var_1) == "C"



# Generated at 2022-06-24 20:40:57.925602
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # set up test case inputs
    dict_0 = {}
    preferences_0 = {}
    raise_on_locale_0 = True

    output = get_best_parsable_locale(dict_0, preferences_0, raise_on_locale_0)

    # validate actual output against expected output
    expected_out = "C"


test_get_best_parsable_locale()



# Generated at 2022-06-24 20:41:02.738717
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module_0 = {}
    # No error should be thrown with default arguments
    get_best_parsable_locale(module_0)

# Generated at 2022-06-24 20:41:12.558010
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import ansible_collections.ansible.community.tests.unit.compat.mock as mock

    pref = 'C.utf8'

    # expected value and function return value
    exp_rc = 0
    rc = 0

    # Expected values for data structures
    exp_out = "C.utf8\n"
    exp_err = ""

    mock_module = mock.Mock()
    mock_module.get_bin_path = mock.Mock(return_value=True)
    mock_module.run_command = mock.Mock(return_value=(exp_rc, exp_out, exp_err))

# Generated at 2022-06-24 20:41:18.775987
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    dict_1 = {}
    var_1 = get_best_parsable_locale(dict_1, ['de_DE.utf8'])
    assert var_1 == 'C'
    dict_2 = {}
    var_2 = get_best_parsable_locale(dict_2)
    assert var_2 == 'C'

# Generated at 2022-06-24 20:41:23.009385
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # pylint: disable=no-member
    assert type(get_best_parsable_locale) is not bool

    # pylint: disable=no-member
    assert type(get_best_parsable_locale()) is str


# Generated at 2022-06-24 20:41:26.243573
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, 'C') == 'C'
    assert get_best_parsable_locale(None, '', 'C') == 'C'
    assert get_best_parsable_locale(None, []) == 'C'

# Generated at 2022-06-24 20:41:36.375514
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('C.utf8', {'C'}) == 'C'
    assert get_best_parsable_locale('C', ({'C', 'POSIX'})) == 'C'
    assert get_best_parsable_locale('C', ({'POSIX', 'C'})) == 'POSIX'
    assert get_best_parsable_locale('C', ({'POSIX', 'POSIX', 'C'})) == 'POSIX'
    assert get_best_parsable_locale('C', ({'POSIX', 'POSIX', 'POSIX', 'C'})) == 'POSIX'

# Generated at 2022-06-24 20:41:43.761779
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Replace the following values with your testcase inputs
    dict_0 = {}
    var_0 = to_native(get_best_parsable_locale(dict_0))
    assert (var_0 == 'C')
    var_1 = to_native(get_best_parsable_locale(dict_0, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']))
    assert (var_1 == 'C')
    var_2 = to_native(get_best_parsable_locale(dict_0, ['C.utf8', 'en_US.utf8', 'POSIX'], True))
    assert (var_2 == 'C.utf8')

# Generated at 2022-06-24 20:41:45.066843
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    dict_0 = {}
    var_0 = get_best_parsable_locale(dict_0)

# Generated at 2022-06-24 20:41:52.413922
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule({
        'C.utf8':'C.utf8',
        'en_US.utf8':'en_US.utf8',
        'C':'C',
        'POSIX':'POSIX',
        'available':'available'
    })
    var_0 = get_best_parsable_locale(module)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:42:54.866915
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' == get_best_parsable_locale(dict(get_bin_path=lambda *args: '/path/to/locale'), ['ru_RU.utf8'], True)
    assert 'C' == get_best_parsable_locale(dict(get_bin_path=lambda *args: '/path/to/locale'), ['ru_RU.utf8'], False)
    assert 'C' == get_best_parsable_locale(dict(get_bin_path=lambda *args: '/path/to/locale',
                                                run_command=lambda *args: (0, 'de_DE.utf8', '')), ['ru_RU.utf8'], False)

# Generated at 2022-06-24 20:43:05.136093
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    dict_0 = {}
    dict_0['get_bin_path.return_value'] = "bin_path"
    dict_0['run_command.return_value'] = (0, '', '')
    dict_0['run_command.side_effect'] = [
        (0, '', ''),
        (0, '', ''),
        (0, '', ''),
        (0, '', ''),
        (0, '', ''),
        (0, '', ''),
        (0, '', ''),
        (0, '', ''),
        (0, '', ''),
        (0, '', ''),
    ]
    # Should fail due to bad preferences

# Generated at 2022-06-24 20:43:07.273978
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert 'C' == get_best_parsable_locale(dict_0)
    except AssertionError as e:
        raise (AssertionError(to_native(e)))
    assert 'C' == get_best_parsable_locale(dict_0)


# Generated at 2022-06-24 20:43:08.983491
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(
        argument_spec = dict(),
    )
    assert get_best_parsable_locale(module) == 'C'
#

# Generated at 2022-06-24 20:43:10.022311
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass


# Test AnsibleModule patch

import unittest



# Generated at 2022-06-24 20:43:13.517595
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print("==================== BEGIN test_get_best_parsable_locale =====================")
    test_case_0()
    print("==================== END test_get_best_parsable_locale =====================")
    print("\n")


# Generated at 2022-06-24 20:43:14.542124
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    dict_0 = {}
    var_0 = get_best_parsable_locale(dict_0)

# Generated at 2022-06-24 20:43:20.857168
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print("\n\n-----TESTING get_best_parsable_locale-----")
    test_case_0()
    print("-----END TESTING get_best_parsable_locale-----\n\n")




# Generated at 2022-06-24 20:43:22.121801
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    dict_0 = {}
    var_0 = get_best_parsable_locale(dict_0)

# Generated at 2022-06-24 20:43:27.243570
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale({}) == 'C'

# Generated at 2022-06-24 20:44:31.423692
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    with pytest.raises(RuntimeWarning):
        test_case_0()

# Generated at 2022-06-24 20:44:40.075039
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Unit: function get_best_parsable_locale, line 11
    var_1 = get_best_parsable_locale({})
    dict_1 = {}
    dict_1['stdout'] = 'C\nen_US'
    dict_1['stdout_lines'] = ['C', 'en_US']
    dict_1['stdout_lines_'] = ['C', 'en_US']
    dict_1['stderr'] = ''
    dict_1['rc'] = 0
    dict_1['parsed'] = True
    dict_1['changed'] = False
    dict_1['warnings'] = []
    dict_1['msg'] = ''
    dict_1['cmd'] = None
    dict_1['invocation'] = None
    dict_1['stdin'] = ''


# Generated at 2022-06-24 20:44:43.201156
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale({}) == 'C'



# Generated at 2022-06-24 20:44:44.587517
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True
    assert True
    assert True

# Generated at 2022-06-24 20:44:48.151488
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''Test function get_best_parsable_locale'''
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )
    # Test the parameters
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-24 20:44:48.992372
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert func_0(test_0_0) == test_0_1

# Generated at 2022-06-24 20:44:58.282677
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    dict_0 = {}
    dict_0['ansible_locale_messages'] = 'en_US'
    dict_1 = {}
    dict_1['ansible_locale'] = 'en_US.UTF-8'
    dict_1['modified_wait_args'] = 'set_fact'
    dict_1['_ansible_item_label'] = '2'
    dict_1['ansible_facts'] = {'modified_wait_args': 'set_fact'}
    dict_1['ansible_facts']['modified_wait_args'] = 'set_fact'
    var_0 = get_best_parsable_locale(dict_0)
    var_1 = get_best_parsable_locale(dict_1, ['en_US.UTF-8'])
    var_

# Generated at 2022-06-24 20:45:01.306902
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_1 = get_best_parsable_locale(dict_1)
    print(var_1)

# Generated at 2022-06-24 20:45:03.199776
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    dict_0 = {}
    var_0 = get_best_parsable_locale(dict_0)

# Generated at 2022-06-24 20:45:05.950642
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    dict_0 = {}
    dict_0['get_bin_path'] = get_bin_path_0
    var_0 = get_best_parsable_locale(dict_0, None)
    assert var_0 == 'C'
