

# Generated at 2022-06-24 20:35:42.458644
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test case for function get_best_parsable_locale with 0 arguments
    test_case_0()

if __name__ == "__main__":
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec=dict())

    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:35:48.228297
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_module = ansible_module_get_best_parsable_locale.AnsibleModule(
        argument_spec = dict()
    )
    var_preferences = ansible_module_get_best_parsable_locale.AnsibleModule(
        argument_spec = dict()
    )
    var_raise_on_locale = ansible_module_get_best_parsable_locale.AnsibleModule(
        argument_spec = dict()
    )

    # Test with a value for 'module'
    module = dict(
        argument_spec = dict()
    )
    result = get_best_parsable_locale(module, )
    assert isinstance(result, str)

    # Test with a value for 'preferences'

# Generated at 2022-06-24 20:35:49.366662
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(test_case_0())

# Generated at 2022-06-24 20:36:00.752520
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os

    # file_name is the file that contains a list of available files
    file_name = 'locale_files.txt'
    with open(file_name, 'r') as f:
        locale_files = f.readlines()
    locale_files = [x.strip() for x in locale_files]

    # delete the file if already exists
    if os.path.exists('locale_file.txt'):
            os.remove('locale_file.txt')

    # open a file to write
    f = open('locale_file.txt', 'a')

    # write header
    header = "%-20s %-20s %-20s\n" % ('preferences', 'found', 'expected')
    f.write(header)

    # test case 1

# Generated at 2022-06-24 20:36:01.953278
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # assert get_best_parsable_locale(preferences, raise_on_locale) == expected
    print("NOT IMPLEMENTED")

# Generated at 2022-06-24 20:36:05.813178
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # from ansible module_utils.basic import AnsibleModule
    # module = AnsibleModule(
    #     argument_spec = dict()
    # )

    module = {}
    list_0 = []
    var_0 = get_best_parsable_locale(module, list_0)

    assert var_0 == 'C'

# Generated at 2022-06-24 20:36:07.250281
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = []
    var_0 = get_best_parsable_locale(var_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:36:17.456240
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-24 20:36:20.179159
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == 'C'

test_case_1 = lambda: get_best_parsable_locale(0)


# Generated at 2022-06-24 20:36:21.712298
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True



# Generated at 2022-06-24 20:36:28.456239
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except Exception as err:
        print("Caught exception: %s" % err)

if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:36:31.038648
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except Exception as e:
        print(e)

# Generated at 2022-06-24 20:36:37.616994
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = [("'C.utf8'", "preferences"), ("'en_US.utf8'",), ("'C'", "preferences"),
              ("'POSIX'", "preferences")]
    func_call_0 = get_best_parsable_locale(list_0)
    assert func_call_0 == "'C'"

# Generated at 2022-06-24 20:36:40.359179
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert 'RESULT' == 'RESULT'
    except AssertionError as e:
        raise(e)
    except Exception as e:
        print("An exception occurred")

# Test Case for function get_best_parsable_locale

# Generated at 2022-06-24 20:36:44.256365
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(list_0) == 'C'

# Generated at 2022-06-24 20:36:46.984605
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(callable(get_best_parsable_locale))

# This test is for printing the name of the test in case of failure

# Generated at 2022-06-24 20:36:49.633966
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert get_best_parsable_locale([]) == "C"

    assert get_best_parsable_locale(["C"]) == "C"



# Generated at 2022-06-24 20:36:53.655358
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == False # TODO: implement your test here


# Generated at 2022-06-24 20:36:56.024828
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    cmd = 'locale -a'
    out = subprocess.check_output(cmd, shell=True).decode('utf-8')
    list_0 = []
    var_0 = get_best_parsable_locale(list_0)
    assert var_0 in out

# Generated at 2022-06-24 20:36:59.425603
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)

# Generated at 2022-06-24 20:37:05.821235
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True
# Main function call
get_best_parsable_locale()

# Generated at 2022-06-24 20:37:06.991102
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == { }

# Generated at 2022-06-24 20:37:08.625104
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert True
    except:
        raise Exception('AssertionError')


# Generated at 2022-06-24 20:37:12.066530
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = []
    var_0 = get_best_parsable_locale(list_0)
    assert(var_0 == 'C')

# test:
test_get_best_parsable_locale()
print("Good!")

# Generated at 2022-06-24 20:37:13.595748
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale("list_0") == "C"



# Generated at 2022-06-24 20:37:16.997146
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = []
    var_0 = get_best_parsable_locale(list_0)
    assert u'C' == var_0


# Generated at 2022-06-24 20:37:26.551262
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    parsed_and_recieved_0 = 'C'
    parsed_and_recieved_1 = 'C.utf8'
    parsed_and_recieved_2 = 'POSIX'
    parsed_and_recieved_3 = 'en_US.utf8'

    list_0 = []
    var_0 = get_best_parsable_locale(list_0)

    assert var_0 == parsed_and_recieved_0, 'Expected "%s", but got "%s"' % (parsed_and_recieved_0, var_0)

    list_1 = []
    var_1 = get_best_parsable_locale(list_1, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'])

    assert var_1 == parsed_and_

# Generated at 2022-06-24 20:37:33.563808
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'en_GB.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['en_GB.utf8', 'en_US.utf8']) == 'en_GB.utf8'

# Generated at 2022-06-24 20:37:34.186840
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert False



# Generated at 2022-06-24 20:37:40.183120
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_cases = [
        (
            (0, ),
            {
                'preferences': None,
                'raise_on_locale': False,
            },
        ),
    ]
    for inputs, expected in test_cases:
        if isinstance(inputs, tuple):
            res = get_best_parsable_locale(*inputs)
        else:
            res = get_best_parsable_locale(inputs)
        assert res == expected


if __name__ == "__main__":
    test_case_0()
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:37:57.937537
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert test_case_0() == None
    except AssertionError:
        raise AssertionError("Testcase 0 failed")

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:38:00.909332
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Setup
    preferences = 'C'

    # Exercise
    # Result
    test_case_0()



# Generated at 2022-06-24 20:38:02.809598
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = []
    var_0 = get_best_parsable_locale(list_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:38:03.843479
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-24 20:38:07.721785
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Variables
    module_0 = 1

    # Assignments
    list_0 = []
    var_0 = get_best_parsable_locale(list_0)

    # noop

    # Destroy class instances
    # noop

    # Output
    # assert_equals(get_best_parsable_locale(module_0), var_0)


# vim: set filetype=python set expandtab ts=4 sw=4 : See help 'modeline'

# Generated at 2022-06-24 20:38:09.063856
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() is not None



# Generated at 2022-06-24 20:38:10.395687
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True # TODO: implement your test here


# Generated at 2022-06-24 20:38:11.974382
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(list_0) == var_0

# Generated at 2022-06-24 20:38:13.856451
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    # Please add your test cases here (and delete this line)
    AnsibleModule.exit_json(changed=False, msg=str(test_case_0()))



# Generated at 2022-06-24 20:38:18.832972
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    var_0 = get_best_parsable_locale(module, preferences)
    assert var_0 == 'C.utf8'

# Generated at 2022-06-24 20:38:52.259663
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        get_best_parsable_locale()
    except (TypeError, ArgumentParserError) as e:
        assert True
    except Exception:
        assert False


# Generated at 2022-06-24 20:38:53.822579
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except:
        # AssertionError: "No output from locale, rc=1: "
        assert 0

# Generated at 2022-06-24 20:38:58.824216
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = []
    var_0 = get_best_parsable_locale(list_0)

    list_1 = []
    list_2 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    var_1 = get_best_parsable_locale(list_1, list_2)

    list_3 = []
    var_2 = get_best_parsable_locale(list_3, raise_on_locale=True)


#test_get_best_parsable_locale()

# Generated at 2022-06-24 20:39:04.024966
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = ['C.utf8', 'en_US.utf8', 'C']
    var_0 = get_best_parsable_locale(list_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:39:11.808598
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Warm up the CACHE by calling the function twice.
    var_0 = get_best_parsable_locale(list_0)
    var_0 = get_best_parsable_locale(list_0)

    test_case_0()


if __name__ == '__main__':
    print('running')
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:39:12.752854
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

# Generated at 2022-06-24 20:39:13.563157
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == None


# Generated at 2022-06-24 20:39:18.043969
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except Exception as exception:
        raise AssertionError(str(exception))

test_get_best_parsable_locale()

# Generated at 2022-06-24 20:39:19.652213
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True


# Generated at 2022-06-24 20:39:27.596726
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = []
    var_0 = get_best_parsable_locale(list_0)
    list_1 = []
    var_1 = get_best_parsable_locale(list_1)
    list_2 = []
    var_2 = get_best_parsable_locale(list_2)
    list_3 = []
    var_3 = get_best_parsable_locale(list_3)
    list_4 = []
    var_4 = get_best_parsable_locale(list_4)
    list_5 = []
    var_5 = get_best_parsable_locale(list_5)
    list_6 = []
    var_6 = get_best_parsable_locale(list_6)
    list_

# Generated at 2022-06-24 20:40:02.198532
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        gbl = globals()
        for name in gbl:
            if name.startswith('test_'):
                gbl[name]()
    except RuntimeWarning:
        print('Runtime warning generated in', name)
    else:
        print('Function', name, 'completed successfully')


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:40:05.853334
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_1 = []
    assert(get_best_parsable_locale(list_1) == 'C')



# Generated at 2022-06-24 20:40:15.842467
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(get_best_parsable_locale(module=None) == 'C') # ansible.module_utils.basic.AnsibleModule
    assert(get_best_parsable_locale(module=None, preferences=None) == 'C') # ansible.module_utils.basic.AnsibleModule
    assert(get_best_parsable_locale(module=None, preferences=None, raise_on_locale=False) == 'C') # ansible.module_utils.basic.AnsibleModule
    assert(get_best_parsable_locale(module=None, preferences=None, raise_on_locale=True) == 'C') # ansible.module_utils.basic.AnsibleModule

# Generated at 2022-06-24 20:40:18.212108
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_1 = [1, 0]
    var_0 = get_best_parsable_locale(var_1)

    assert var_0 == 0



# Generated at 2022-06-24 20:40:19.573041
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(list_0) == var_0

# Generated at 2022-06-24 20:40:22.341116
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
       get_best_parsable_locale()
    except (TypeError, ArgumentError) as e:
        assert True
    else:
        assert False

test_case_0()

# Generated at 2022-06-24 20:40:23.397190
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('') == ''

# Generated at 2022-06-24 20:40:27.859136
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from unittest.mock import MagicMock, Mock
    m = MagicMock()
    m.run_command.return_value = "", "", ""
    m.get_bin_path.return_value = ""
    assert get_best_parsable_locale(m) == "C"

# Generated at 2022-06-24 20:40:32.508882
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == None


test_get_best_parsable_locale()

# Generated at 2022-06-24 20:40:34.182933
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale is not None


# Generated at 2022-06-24 20:41:05.003752
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(list_0, preferences=list_1, raise_on_locale=bool_2) == str_3

# Generated at 2022-06-24 20:41:05.569561
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-24 20:41:10.380421
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_arg = [1, 2, 3]
    assert get_best_parsable_locale(list_arg) == 3


# Generated at 2022-06-24 20:41:14.685478
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Variables
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    # Uncomment these if needed
    # list_0 = []
    # var_0 = get_best_parsable_locale(list_0)
    # var_0 = get_best_parsable_locale(list_0, preferences)
    # var_0 = get_best_parsable_locale(list_0, preferences, True)

# Generated at 2022-06-24 20:41:15.166641
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-24 20:41:20.771236
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    
    # pass
    
    module = Mock(name='AnsibleModule')
    module.run_command.return_value = (0, 'Test Output: locale -a','Test Error string')
    list_0 = []
    var_0 = get_best_parsable_locale(module)
    assert var_0 == "C"

    # pass
    
    module = Mock(name='AnsibleModule')
    module.run_command.return_value = (0, 'Test Output: locale -a','Test Error string')
    list_0 = []
    list_1 = ['C']
    var_0 = get_best_parsable_locale(module, list_1)
    assert var_0 == "C"

    # pass
    
    module = Mock(name='AnsibleModule')
   

# Generated at 2022-06-24 20:41:25.683362
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        # Testing with no input parameters, these are the defaults
        _pref = None
        _r = False
        assert get_best_parsable_locale(test_case_0, _pref, _r) == 'C'
    except RuntimeWarning:
        pass

# Generated at 2022-06-24 20:41:27.244776
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == False


# Generated at 2022-06-24 20:41:31.204164
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert False


# Generated at 2022-06-24 20:41:32.210553
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True # TODO: implement your test here


# Generated at 2022-06-24 20:42:02.744601
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True # TODO: implement your test here


# Generated at 2022-06-24 20:42:08.608663
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C.utf8' == get_best_parsable_locale('C.utf8', True)
    assert 'en_US.utf8' == get_best_parsable_locale('en_US.utf8', True)
    assert 'C' == get_best_parsable_locale('C', True)
    assert 'POSIX' == get_best_parsable_locale('POSIX', True)

# Generated at 2022-06-24 20:42:14.052915
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert preferences[0] == 'C.utf8'
    assert preferences[1] == 'en_US.utf8'
    assert preferences[2] == 'C'
    assert preferences[3] == 'POSIX'

    assert get_best_parsable_locale(preferences) == 'C.utf8'


if __name__ == '__main__':
    test_get_best_parsable_locale()
    test_case_0()

# Generated at 2022-06-24 20:42:16.810697
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print("Start test_get_best_parsable_locale")
    try:
        test_case_0()
    except Exception as e:
        print(e)
    print("End test_get_best_parsable_locale")

# Generated at 2022-06-24 20:42:17.480933
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

# Generated at 2022-06-24 20:42:22.265910
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True


# Generated at 2022-06-24 20:42:23.533729
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
  try:
    assert True
  except AssertionError:
    pass


# Generated at 2022-06-24 20:42:25.203871
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = get_best_parsable_locale(None)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:42:33.186857
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        preferences = ["abc", "xyz"]
        var_1 = get_best_parsable_locale(preferences);
        # print("var_1: " + str(var_1));
    except Exception as e:
        print(e);

    try:
        preferences = None;
        var_2 = get_best_parsable_locale(preferences);
        # print("var_2: " + str(var_2));
    except Exception as e:
        print(e);


# Main function for testing

# Generated at 2022-06-24 20:42:34.393327
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Case 0
    test_case_0()



# Generated at 2022-06-24 20:43:07.008728
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = [
        1,
        0,
        "abc"
    ]
    var_0 = get_best_parsable_locale(list_0)
    assert var_0 == 'C'

    list_0 = [
        1,
        0,
        "abc"
    ]
    var_0 = get_best_parsable_locale(list_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:43:08.577766
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except:
        print('Unhandled exception.')
        raise

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:43:12.919036
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
  pass


# These are the automation methods in AnsibleModuleUtils

# Generated at 2022-06-24 20:43:14.128254
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = []
    var_0 = get_best_parsable_locale(list_0)
    

# Generated at 2022-06-24 20:43:20.685285
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    list_0 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    var_0 = get_best_parsable_locale(list_0, list_0)

    # test function output against expected output
    assert var_0 == 'C.utf8'



# Generated at 2022-06-24 20:43:21.696165
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

# vim: et ts=4 sw=4 cc=80

# Generated at 2022-06-24 20:43:26.190932
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = ['POSIX', 'en_US.UTF-8', 'zhs', 'pt_BR.UTF-8']
    var_0 = get_best_parsable_locale(list_0)
    assert var_0 == 'POSIX'
    # assert type(var_0) == 
    # assert type(var_0) == 
    list_0 = ['POSIX', 'C', 'en_US.UTF-8', 'zhs', 'pt_BR.UTF-8']
    var_0 = get_best_parsable_locale(list_0)
    assert var_0 == 'C'
    # assert type(var_0) == 
    # assert type(var_0) == 

# Generated at 2022-06-24 20:43:27.526759
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)

# Generated at 2022-06-24 20:43:36.694214
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert("C" == get_best_parsable_locale([""]))
        assert("en_US.utf8" == get_best_parsable_locale([""]))
        assert("C" == get_best_parsable_locale([""]))
        assert("C" == get_best_parsable_locale([""]))
        assert("C" == get_best_parsable_locale([""]))
        print("Unit test for function get_best_parsable_locale() ran to completion.")
    except AssertionError as e:
        print("AssertionError raised within unit test for get_best_parsable_locale()!")
        print(e)



# Generated at 2022-06-24 20:43:39.249150
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(["C"], ["C", "POSIX"]) == "C"


# Generated at 2022-06-24 20:44:13.043803
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)
    test_case_0()

# Generated at 2022-06-24 20:44:18.435553
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except Exception as err:
        print("Test failed:", err)
        raise err
    else:
        print("Test succeeded")

test_get_best_parsable_locale()

# Generated at 2022-06-24 20:44:21.814862
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(list_0) == var_0

# Generated at 2022-06-24 20:44:23.978373
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = []
    var_0 = get_best_parsable_locale(list_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:44:29.653851
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

# TEST CASE 1
test_case_1_module_0 = dict(
    run_command=dict(
        return_value=(0,
                      b'ascii\nen_US.utf8\nen_US.utf8\nen_US.utf8\nen_US.utf8\nen_US.utf8\nen_US.utf8\nen_US.utf8\nen_US.utf8\nen_US.utf8\nen_US.utf8\nen_US.utf8\nen_US.utf8\nen_US.utf8\nen_US.utf8\nen_US.utf8\nen_US.utf8',
                      b'')))


# Generated at 2022-06-24 20:44:39.304260
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Mock AnsibleModule inputs and results
    ansible_module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(type='list', required=False),
            raise_on_locale=dict(type='bool', required=False, default=True)
        ),
        supports_check_mode=True
    )

    # Mock locale binary path and command outputs
    locale_bin = os.path.join(os.path.dirname(__file__), '../../bin/locale')
    locale_available_output = '''
C
C.UTF8
en_US.utf8
POSIX
'''
    ansible_module.run_command = Mock(return_value=(0, locale_available_output, ''))

# Generated at 2022-06-24 20:44:43.952277
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_var_0 = None
    var_0 = get_best_parsable_locale(list_var_0)
    assert type(var_0) is str


# Generated at 2022-06-24 20:44:49.476169
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = []
    var_0 = get_best_parsable_locale(list_0, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'])
    assert var_0 == 'C'
    list_1 = []
    var_1 = get_best_parsable_locale(list_1, preferences=['C.utf8', 'en_US.utf8', 'POSIX'])
    assert var_1 == 'C'
    list_2 = []
    var_2 = get_best_parsable_locale(list_2, preferences=['C.utf8', 'en_US.utf8', 'POSIX', 'C'])
    assert var_2 == 'C'
    list_3 = []
    var_3 = get_best_

# Generated at 2022-06-24 20:44:53.012995
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-24 20:44:55.150310
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()



# Generated at 2022-06-24 20:45:34.291662
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    list_0 = []
    var_0 = get_best_parsable_locale(list_0)
    assert var_0 == 'C'  # This test requires no assertions
