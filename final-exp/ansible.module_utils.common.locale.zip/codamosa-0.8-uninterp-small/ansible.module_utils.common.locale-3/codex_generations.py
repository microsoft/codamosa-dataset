

# Generated at 2022-06-24 20:35:43.296838
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    mod_0 = Mock(return_value=(0, to_native('out'), None))
    mod_1 = Mock(return_value=(0, to_native('out'), None))
    mod_2 = Mock(return_value=(0, to_native('out'), None))
    mod_3 = Mock(return_value=(0, to_native('out'), None))
    mod_4 = Mock(return_value=(0, to_native('out'), None))
    mod_5 = Mock(return_value=(0, to_native('out'), None))
    mod_6 = Mock(return_value=(0, to_native('out'), None))
    mod_7 = Mock(return_value=(0, to_native('out'), None))


# Generated at 2022-06-24 20:35:46.322978
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-24 20:35:46.784459
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True


# Generated at 2022-06-24 20:35:48.909953
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == False # TODO: implement your test here


# Generated at 2022-06-24 20:35:50.919812
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == None

# Generated at 2022-06-24 20:35:53.550209
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)
    assert type(get_best_parsable_locale(None)) == str or None

# Generated at 2022-06-24 20:36:04.274505
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['C']) == 'C'
    assert get_best_parsable_locale(None, ['C.utf8', 'C']) == 'C'
    assert get_best_parsable_locale(None, ['C.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, ['C.utf8', 'POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(None, ['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, ['POSIX', 'C']) == 'POSIX'


# Generated at 2022-06-24 20:36:09.013064
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(get_best_parsable_locale(bool_0, [u"C.utf8", u"en_US.utf8", u"C", u"POSIX"])) == u"C"



# Generated at 2022-06-24 20:36:11.972989
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module_0 = {"some": "dict"}
    assert (get_best_parsable_locale(module_0) == "C")


if __name__ == '__main__':
    test_case_0()
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:36:16.963280
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    Test_AnsibleModule = AnsibleModule
    bool_0 = None
    var_0 = get_best_parsable_locale(bool_0)
    __tracebackhide__ = True
    assert('en_US.utf8' == var_0)

    var_0 = get_best_parsable_locale(__tracebackhide__)

# Generated at 2022-06-24 20:36:23.219180
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Run this test case
    test_case_0()



# Generated at 2022-06-24 20:36:24.478286
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(get_best_parsable_locale({'get_bin_path': test_case_0}) == 'C')

# Generated at 2022-06-24 20:36:26.445297
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale("test_case_0") == "test_get_best_parsable_locale"

# Generated at 2022-06-24 20:36:35.287338
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = None
    var_0 = get_best_parsable_locale(bool_0, [])
    assert var_0 == 'C', var_0

    bool_1 = None
    var_1 = get_best_parsable_locale(bool_1, [])
    assert var_1 == 'C', var_1

if __name__ == "__main__":
    print("Test all cases")
    test_case_0()
    print("Function unit test")
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:36:38.273317
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(AnsibleModule, ['C']) == 'C' or 'POSIX' or 'C' or 'C.utf8' or 'POSIX.utf8' or 'en_US.utf8'




# Generated at 2022-06-24 20:36:39.546438
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = None
    assert get_best_parsable_locale(bool_0) == 'C'

# Function for evaluating a module

# Generated at 2022-06-24 20:36:40.865368
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_5 = get_best_parsable_locale(var_0)

# Generated at 2022-06-24 20:36:44.299987
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == False # TODO: implement your test here


# Generated at 2022-06-24 20:36:52.911677
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Source:
    # https://unix.stackexchange.com/questions/67045/whats-the-difference-between-c-and-posix-locales

    # The POSIX locale is roughly equivalent to C locale, but it also
    # enables all character classes and collation elements of POSIX
    # regular expression syntax.  So, \w matches all letters, digits
    # and underscores, and [[:digit:]] matches all digits. 

    # The C locale is the most basic locale.  It should work on all
    # systems, although it provides no sorting or collation rules and
    # ASCII character set is used.

    pass

# Generated at 2022-06-24 20:36:57.359069
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, preferences=None, raise_on_locale=False) == 'C'

# Generated at 2022-06-24 20:37:04.097308
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(bool_0) == 'C', "Unable to get locale information, rc=%s: %s"



# Generated at 2022-06-24 20:37:05.221458
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)



# Generated at 2022-06-24 20:37:06.014799
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True


# Generated at 2022-06-24 20:37:12.885986
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = get_best_parsable_locale(['C','POSIX','en_US.utf8','C.utf-8','C.utf8','en_US'])
    assert(var_0 == 'en_US.utf8')
    var_1 = get_best_parsable_locale(['en_GB.utf8', 'en_US.utf8', 'en_US.UTF-8', 'en_US'])
    assert(var_1 == 'en_GB.utf8')
    var_2 = get_best_parsable_locale(['en_US.utf8', 'en_US.UTF-8', 'en_US', 'C.UTF-8', 'C'])
    assert(var_2 == 'en_US.utf8')
    var_3 = get_

# Generated at 2022-06-24 20:37:14.761838
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True
    assert -1 != 0
    assert 1 == 1

# Generated at 2022-06-24 20:37:17.375913
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert test_case_0() == None
    except AssertionError as e:
        print('Test Case Failed:')
        print(e)


# Test Evaluations
print('Executing Test Cases:')
test_get_best_parsable_locale()

# Generated at 2022-06-24 20:37:21.604588
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test for normal case
    test_case_0()

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


# Generated at 2022-06-24 20:37:25.047188
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Source:
    # https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/facts.py#L1469-L1470
    assert get_best_parsable_locale('module', ['a', 'b']) == 'C'

# Generated at 2022-06-24 20:37:26.811261
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == isinstance(get_best_parsable_locale(test_case_0()), unicode)

# Generated at 2022-06-24 20:37:31.281760
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Try to get the best locale on the system
    assert get_best_parsable_locale(None, ['C']) == 'C'
    assert get_best_parsable_locale(None, ['C.UTF-8']) == 'C.UTF-8'



# Generated at 2022-06-24 20:37:41.332840
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Method 1
    assert get_best_parsable_locale(bool_0) == var_0



# Generated at 2022-06-24 20:37:41.836561
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-24 20:37:42.965379
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(test_case_0()) == None

# Generated at 2022-06-24 20:37:48.765443
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Simple test for function get_best_parsable_locale
    try:
        test_case_0()
        assert True
    except:
        assert False

main()

# Generated at 2022-06-24 20:37:51.883963
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True
    # assert False  # TODO: implement your test here


# Generated at 2022-06-24 20:37:53.427044
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == "C"


# Generated at 2022-06-24 20:38:02.665460
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_1 = None
    var_1 = get_best_parsable_locale(bool_1)
    bool_2 = None
    var_2 = get_best_parsable_locale(bool_2)
    bool_3 = None
    var_3 = get_best_parsable_locale(bool_3)
    bool_4 = None
    var_4 = get_best_parsable_locale(bool_4)
    bool_5 = None
    var_5 = get_best_parsable_locale(bool_5)
    bool_6 = None
    var_6 = get_best_parsable_locale(bool_6)

# Generated at 2022-06-24 20:38:11.090014
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
  mock_module = MagicMock(spec=AnsibleModule)
  mock_get_bin_path = MagicMock(return_value=MagicMock(returncode=1))
  mock_module.get_bin_path = mock_get_bin_path
  mock_module.run_command = MagicMock(return_value=(0, '', ''))
  mock_module.params = {'preferences':[]}
  with patch.object(os.path, 'exists', Mock(return_value=True)):
    result = get_best_parsable_locale(mock_module)
  assert result == 'C'


# Generated at 2022-06-24 20:38:13.680926
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except Exception:
        import traceback
        
        print(traceback.format_exc())
        assert False


# Generated at 2022-06-24 20:38:23.065150
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Return true if passed in arguments match the expected values
    bool_0 = None
    var_1 = get_best_parsable_locale(bool_0)
    assert var_1 == None

    bool_1 = None
    var_1 = get_best_parsable_locale(bool_0)
    assert var_1 == None

    bool_2 = None
    var_1 = get_best_parsable_locale(bool_0)
    assert var_1 == None

    bool_3 = None
    var_1 = get_best_parsable_locale(bool_0)
    assert var_1 == None

    bool_4 = None
    var_1 = get_best_parsable_locale(bool_0)
    assert var_1 == None

    bool_5 = None

# Generated at 2022-06-24 20:38:38.738755
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-24 20:38:47.979736
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # assert 0 # TODO: implement your test here
    # assert get_best_parsable_locale() == 'C' # TODO: implement your test here
    assert get_best_parsable_locale('') == 'C'  # TODO: implement your test here
    assert get_best_parsable_locale(['']) == 'C'  # TODO: implement your test here
    assert get_best_parsable_locale(('')) == 'C'  # TODO: implement your test here
    assert get_best_parsable_locale({''}) == 'C'  # TODO: implement your test here
    assert get_best_parsable_locale({'': ''}) == 'C'  # TODO: implement your test here


# Generated at 2022-06-24 20:38:54.898255
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Assign values for variables
    preferences = []
    raise_on_locale = None

    # Print statements to print return and expected values
    print("Returns : ")
    print("expected =  None")
    print("Return = ", get_best_parsable_locale(preferences, raise_on_locale))


# import module snippets
from ansible.module_utils.basic import AnsibleModule

if __name__ == '__main__':
    # local_var = locals()
    # test_var = local_var.get('test_case_0')
    # test_var()
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:38:56.936836
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True

# generated from default datasets available in ansible 2.3
# need to check 2.4 datasets for correctness


# Generated at 2022-06-24 20:38:59.350640
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import ansible.module_utils.basic
    mod = ansible.module_utils.basic.AnsibleModule(
        argument_spec={}, supports_check_mode=True,
    )

    test_case_0()

    test_case_1()

# Generated at 2022-06-24 20:39:05.218754
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    cmd = Command()
    
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    for i in range(100):
        if test_case_0() == "pass":
            print("Test Case 0: Passed")
        else:
            print("Test Case 0: Failed")

# Generated at 2022-06-24 20:39:07.522498
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True


# Unit test execution
if __name__ == '__main__':
    import pytest
    pytest.main(['-x', "test_main_os_selector.py"])

# Generated at 2022-06-24 20:39:08.908716
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # assert(get_best_parsable_locale(bool_0))
    pass


# Generated at 2022-06-24 20:39:13.097295
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(bool_0) == 'C'

# Generated at 2022-06-24 20:39:15.787193
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    b_0 = None
    a_0 = get_best_parsable_locale(b_0)
    assert a_0 == 'C'

# Generated at 2022-06-24 20:39:30.693755
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

# Generated at 2022-06-24 20:39:35.053517
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_1 = None
    var_2 = []
    var_3 = False
    result_0 = get_best_parsable_locale(var_1, var_2, var_3)
    print(result_0)
    assert result_0 == 'C', "Error in function get_best_parsable_locale"



# Generated at 2022-06-24 20:39:38.288656
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = None
    var_0 = get_best_parsable_locale(bool_0)

    assert var_0 == 'C'


# Generated at 2022-06-24 20:39:42.446297
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Generating random arguments
    arg_0 = None
    arg_1 = None
    arg_2 = None
    # Calling function with required arguments as keyword arguments
    get_best_parsable_locale(arg_0)
    # Calling function with required arguments as keyword arguments
    get_best_parsable_locale(arg_0, arg_1)
    # Calling function with required arguments as keyword arguments
    get_best_parsable_locale(arg_0, arg_2)
    # Calling function with required arguments as positional arguments
    get_best_parsable_locale(arg_0)
    # Calling function with required arguments as positional arguments
    get_best_parsable_locale(arg_0, arg_1)
    # Calling function with required arguments as positional arguments
    get_best_parsable

# Generated at 2022-06-24 20:39:51.499887
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = None
    bool_1 = None
    bool_2 = None
    list_0 = None
    var_1 = get_best_parsable_locale(bool_0, bool_1, bool_2, list_0)
    # assert var_1 == 'C'


# Test all cases
test_get_best_parsable_locale()


if __name__ == '__main__':
    print('Test cases: %s' % len(test_cases))
    for i, (test_case, expected) in enumerate(test_cases):
        print('Running test: %s/%s' % (i + 1, len(test_cases)))
        test_case()

# Generated at 2022-06-24 20:39:54.572839
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # This is an auto-generated test.
    bool_0 = None
    var_0 = get_best_parsable_locale(bool_0)


if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:40:01.156182
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = None
    data = {"preferences": None, "raise_on_locale": False}
    var_0 = get_best_parsable_locale(bool_0, **data)
    assert var_0 == "C"

test_get_best_parsable_locale()
test_case_0()

# Generated at 2022-06-24 20:40:04.820075
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(test_case_0)


# Generated at 2022-06-24 20:40:05.936564
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True


# Generated at 2022-06-24 20:40:12.817212
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = None
    bool_1 = None
    list_1 = ['string', 'string', 'string', 'string']
    bool_2 = False
    var_0 = get_best_parsable_locale(bool_0, list_1, bool_2)
    print(var_0)
    bool_0 = None
    bool_1 = None

# Generated at 2022-06-24 20:40:33.148989
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(
        argument_spec = dict(

        ),
        supports_check_mode=True
    )
    result = get_best_parsable_locale(module)
    module.exit_json(**result)


# Generated at 2022-06-24 20:40:34.996359
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # No exception thrown for this test case
    test_case_0()



# Generated at 2022-06-24 20:40:39.627929
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == None

# Generated at 2022-06-24 20:40:42.743101
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    a = open('/usr/sbin/locale', 'r')
    a.read().strip().splitlines()
    a.close()
    if __name__ == '__main__':
	    test_case_0()

# Generated at 2022-06-24 20:40:47.973348
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert isinstance(get_best_parsable_locale(test_case_0), str) == True

# Generated at 2022-06-24 20:40:49.127973
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == test_case_0()

# Generated at 2022-06-24 20:40:55.166367
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # arrange

    # act
    # pass

    # assert
    assert True == True



# Generated at 2022-06-24 20:40:56.544879
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(bool_0) == var_0

# Generated at 2022-06-24 20:41:04.862028
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = None
    var_0 = get_best_parsable_locale(bool_0)
    var_1 = get_best_parsable_locale(bool_0, ['foo'])
    var_2 = get_best_parsable_locale(bool_0, ['C'])
    var_3 = get_best_parsable_locale(bool_0, ['C', 'POSIX'])
    var_4 = get_best_parsable_locale(bool_0, ['C', 'POSIX', 'en_US.utf8'])
    var_5 = get_best_parsable_locale(bool_0, ['en_US', 'en_US.utf8'])



if __name__ == '__main__':
    import sys

    test_

# Generated at 2022-06-24 20:41:10.154681
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except (RuntimeError, TypeError, NameError) as e:
        print('Exception:', e, 'occured on line', e.__traceback__.tb_lineno)
    else:
        print('No exception occured')



if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:41:26.176734
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # assert_equals(solution, expected [, msg])
    assert true # TODO: implement your test here



# Generated at 2022-06-24 20:41:27.795409
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == None



# Generated at 2022-06-24 20:41:29.577068
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, None) == 'C'

# Generated at 2022-06-24 20:41:32.729621
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # these change by system and are not easily mocked
    assert var_0 == 'C'
    assert var_0 == 'C.utf8'
    assert var_0 == 'en_US.utf8'
    assert var_0 == 'POSIX'

# Generated at 2022-06-24 20:41:33.671221
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' == get_best_parsable_locale(bool_0)


# Generated at 2022-06-24 20:41:38.078415
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, preferences=["en_US.utf8", "en_US"]) == 'en_US.utf8'
    assert get_best_parsable_locale(None, preferences=["en_US"]) == 'en_US'

# Generated at 2022-06-24 20:41:40.824317
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_1 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert var_1 == 'C.utf8'
    assert var_1 == 'en_US.utf8'
    assert var_1 == 'C'
    assert var_1 == 'POSIX'
    assert var_1 == 'C'

# Generated at 2022-06-24 20:41:42.027095
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = None
    var_0 = get_best_parsable_locale(bool_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:41:48.494498
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print("TESTING get_best_parsable_locale")

    test_case_0()
    print("TEST COMPLETED get_best_parsable_locale")

if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:41:53.873794
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = None
    var_0 = get_best_parsable_locale(bool_0)

    var_1 = get_best_parsable_locale(bool_0, raise_on_locale=True)


# Generated at 2022-06-24 20:42:09.620133
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Should be True or False
    print(get_best_parsable_locale(1))


# Generated at 2022-06-24 20:42:11.906237
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert 'C' == get_best_parsable_locale()
    except:
        raise AssertionError("expected 'C' but got something else")

# Generated at 2022-06-24 20:42:12.783979
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True # TODO: may fail

# Generated at 2022-06-24 20:42:15.020564
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # testcase 
    test_case_0()



if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:42:15.726446
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True



# Generated at 2022-06-24 20:42:18.786078
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = None # var type: <type 'NoneType'>
    var_0 = get_best_parsable_locale(bool_0)


if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:42:19.769112
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)


# Generated at 2022-06-24 20:42:22.877398
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert 'C' == get_best_parsable_locale(None, preferences=None)

    assert 'C' == get_best_parsable_locale(None, preferences=['fr'])

    assert 'C.utf8' == get_best_parsable_locale(None, preferences=['fr', 'C.utf8'])

# Generated at 2022-06-24 20:42:26.297264
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert (get_best_parsable_locale(bool_0, var_0)) == "C"

if __name__ == '__main__':
    test_case_0()
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:42:29.489094
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = None
    var_0 = get_best_parsable_locale(bool_0)
    # assert var_0 == "expected output"

# Generated at 2022-06-24 20:42:46.487028
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_5 = None
    var_0 = get_best_parsable_locale(bool_5)
    #assert var_0 == <some_value>

if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:42:56.622727
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # unit test for function get_best_parsable_locale
    assert 'foo' in globals()
    assert 'bar' in globals()
    assert 'baz' in globals()
    assert 'boz' in globals()
    assert 'qux' in globals()
    assert 'quux' in globals()
    assert 'corge' in globals()
    assert 'garply' in globals()
    assert 'waldo' in globals()
    assert 'fred' in globals()
    assert 'plugh' in globals()
    assert 'xyzzy' in globals()
    assert 'thud' in globals()

    # foo
    assert foo.__doc__ is not None
    assert foo.__name__ == 'foo'

    # bar
    assert bar.__doc__ is not None


# Generated at 2022-06-24 20:42:58.062271
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    a = None
    b = None
    assert get_best_parsable_locale(a) is b

# Generated at 2022-06-24 20:42:58.562230
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

# Generated at 2022-06-24 20:43:00.685927
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = None
    var_0 = get_best_parsable_locale(bool_0)
    assert var_0 is False
    assert 'C' == var_0

# Generated at 2022-06-24 20:43:01.844834
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    with pytest.raises(RuntimeWarning):
        test_case_0()



# Generated at 2022-06-24 20:43:09.564898
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-24 20:43:11.810351
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print("Test: test_get_best_parsable_locale")
    test_case_0()

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:43:15.158024
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # AssertionError: rc=1 : 'locale: Cannot set LC_CTYPE to default locale: No such file or directory'
    #   assert get_best_parsable_locale(None) == 'C'
    pass


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:43:22.088479
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert(get_best_parsable_locale(None))

    assert(get_best_parsable_locale(None)) == 'C'

    assert(get_best_parsable_locale(None, ['POSIX'])) == 'POSIX'

    assert(get_best_parsable_locale(None, ['POSIX', 'POSIX'])) == 'POSIX'

# Generated at 2022-06-24 20:43:40.753802
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = None
    bool_1 = None
    var_0 = get_best_parsable_locale(bool_0,bool_1)



# Generated at 2022-06-24 20:43:41.877954
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == False # TODO: implement your test here


# Generated at 2022-06-24 20:43:45.846058
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert 'posix' in get_best_parsable_locale(var_0)
    except:
        raise AssertionError('best_parsable_locale does not work')

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:43:47.698104
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # AssertionError: Failed to find 'locale' tool.
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-24 20:43:50.968504
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(
        argument_spec = dict(

        ),
        supports_check_mode=False
    )
    bool_0 = None
    # see if we can get a best case local
    var_0 = get_best_parsable_locale(module, bool_0)
    assert var_0

# Generated at 2022-06-24 20:43:55.016483
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(test_case_0)

test_dataset_0 = [
    'test_dataset_0_arg_0',
    'test_dataset_0_arg_1',
    'test_dataset_0_arg_2',
    'test_dataset_0_arg_3'
]



# Generated at 2022-06-24 20:43:58.772750
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bool_0 = None
    var_0 = get_best_parsable_locale(bool_0)
    # get_best_parsable_locale() should return a value of type string or raise an exception.


if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:44:03.491016
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert type(get_best_parsable_locale('module')) == str
    except AssertionError as ae:
        raise AssertionError(ae)



# Generated at 2022-06-24 20:44:07.684463
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(
        argument_spec=dict(
            raise_on_locale=dict(type='bool', required=False),
        )
    )
    test_case_0()



# Generated at 2022-06-24 20:44:15.354293
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Prefer 'en_US.utf8' over 'C.utf8'
    assert get_best_parsable_locale(None, ['en_US.utf8']) == 'en_US.utf8'

    # Prefer 'en_US.utf8' over 'C.utf8' if both are available
    assert get_best_parsable_locale(None, ['en_US.utf8', 'C.utf8']) == 'en_US.utf8'

    # Prefer 'en_US.utf8' over 'C.utf8' if both are available
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8']) == 'en_US.utf8'

    # Prefer 'C.utf8' if 'en_US.utf

# Generated at 2022-06-24 20:44:36.175943
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = None
    preferences = None
    raise_on_locale = False

    # Call get_best_parsable_locale
    get_best_parsable_locale(module, preferences, raise_on_locale)

# Unit test stubs

# Generated at 2022-06-24 20:44:39.389102
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test 1: Run the code with an empty AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

    local_vars = locals()
    module = AnsibleModule(argument_spec=dict())
    # get the params
    params = module.params
    # run the code
    test_case_0()



# Generated at 2022-06-24 20:44:43.680865
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = get_best_parsable_locale('C')
    assert var_0 == 'C'


# Generated at 2022-06-24 20:44:45.021043
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None)

# test case for get_best_parsable_locale
test_case_0()

# Generated at 2022-06-24 20:44:45.888478
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = test_case_0()
    assert var_0 == None

# Generated at 2022-06-24 20:44:51.087930
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == None

# Generated at 2022-06-24 20:44:53.271222
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)



# Generated at 2022-06-24 20:45:03.561751
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # get_best_parsable_locale needs an object with an attribute 'run_command'
    class obj_0 ():
        def __init__(self, value_0):
            self.run_command = value_0
        @property
        def run_command(self):
            return self.__run_command
        @run_command.setter
        def run_command(self, value_0):
            self.__run_command = value_0
        def __getattr__(self, name):
            return name
    class obj_1 ():
        def __init__(self, value_0):
            self.run_command = value_0
        @property
        def run_command(self):
            return self.__run_command

# Generated at 2022-06-24 20:45:05.075583
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(bool_0) == var_0


# Generated at 2022-06-24 20:45:08.065110
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except RuntimeWarning:
        pass

# Calling the main function
if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:45:23.909242
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert preference

# Generated at 2022-06-24 20:45:28.695288
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test case for get_best_parsable_locale
    assert ('C' == get_best_parsable_locale(None, None, True))

    # Test case for get_best_parsable_locale
    assert ('C' == get_best_parsable_locale(None, None, True))