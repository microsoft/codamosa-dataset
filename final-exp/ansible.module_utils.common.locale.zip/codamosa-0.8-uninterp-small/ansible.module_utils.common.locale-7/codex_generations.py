

# Generated at 2022-06-24 20:35:39.489652
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    complex_0 = None
    var_0 = get_best_parsable_locale(complex_0)
    assert var_0 == 'C'

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    var_0 = get_best_parsable_locale(complex_0, preferences)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:35:41.468244
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert test_case_0() == None
    except AssertionError as e:
        print(e.message)
        assert False



# Generated at 2022-06-24 20:35:50.833274
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    class AnsibleModule(object):
        def get_bin_path(self, module):
            return None

        def run_command(self, module):
            return 0, "", ""

    module = AnsibleModule()
    assert get_best_parsable_locale(module) == 'C'

    def get_bin_path(self, module):
        return 'locale'

    def run_command(self, module):
        return 0, "supported_locale", ""

    module.get_bin_path = get_bin_path.__get__(module)
    module.run_command = run_command.__get__(module)
    assert get_best_parsable_locale(module) == 'supported_locale'



# Generated at 2022-06-24 20:35:51.966474
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_0()


# Generated at 2022-06-24 20:35:58.107160
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # the following variables are defined in the module, so we must declare them here
    # to shadow them.
    found = 'C'
    available = ['C.UTF-8', 'C.utf8', 'C', 'POSIX']
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    for pref in preferences:
        if pref in available:
            found = pref
            break
    return found

# Generated at 2022-06-24 20:36:00.170507
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == None # FIXME: may be wrong!

# Generated at 2022-06-24 20:36:04.603879
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    mock_module = type('', (), {})()
    mock_module.run_command = lambda args, **kw: (0, '', '')
    mock_module.get_bin_path = lambda name, **kw: ''
    assert get_best_parsable_locale(mock_module) == 'C'

# Generated at 2022-06-24 20:36:11.668820
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        setattr(__builtins__, '_', lambda x: x)
    except Exception:
        pass

    try:
        import ansible.module_utils.basic
        import ansible.module_utils.six.moves.builtins
    except ImportError:
        pass

    import ansible.module_utils.basic
    import ansible.module_utils.six.moves.builtins

    _ = ansible.module_utils.six.moves.builtins._
    AnsibleModule = ansible.module_utils.basic.AnsibleModule  # pylint: disable=C0103


# Generated at 2022-06-24 20:36:13.641530
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # get_best_parsable_locale()
    pass

# Generated at 2022-06-24 20:36:15.404490
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    complex_0 = None
    var_0 = get_best_parsable_locale(complex_0)
    assert var_0 == "C"

# Generated at 2022-06-24 20:36:22.085213
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print('Testing: test_get_best_parsable_locale')
    try:
        assert 1
        test_case_0()
    except AssertionError:
        print('Expected')
        print('Received')
        print('test_get_best_parsable_locale() ran to completion')

# Generated at 2022-06-24 20:36:32.125099
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Create 3 fake classes
    class FakeModule:
        def get_bin_path(self, arg_0):
            return FakeModule
        def run_command(self, arg_0):
            return FakeModule

    class FakeModule1:
        def get_bin_path(self, arg_0):
            return None
        def run_command(self, arg_0):
            return FakeModule1

    class FakeModule2:
        def get_bin_path(self, arg_0):
            return FakeModule2
        def run_command(self, arg_0):
            return (0, '', '')

    class FakeModule3:
        def get_bin_path(self, arg_0):
            return FakeModule3
        def run_command(self, arg_0):
            return (1, '', 'Error')



# Generated at 2022-06-24 20:36:36.321874
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    mock_params = [
        {
            'preferences': None
        }
    ]
    for params in mock_params:

        assert get_best_parsable_locale(**params) == 'C'

# Generated at 2022-06-24 20:36:38.468367
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    some_input = None
    some_output = 'C'  # default posix, its ascii but always there

    assert get_best_parsable_locale(some_input) == some_output

# Generated at 2022-06-24 20:36:41.231049
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ansible_0 = None
    assert isinstance(get_best_parsable_locale(ansible_0), str) == True

# Test to assert that 'get_best_parsable_locale' function throws a 'RuntimeWarning' exception when the specified
# value is not present in the 'available' list

# Generated at 2022-06-24 20:36:46.081231
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    result = get_best_parsable_locale({'bin_path': '', 'run_command': ''}, raise_on_locale=True)
    assert result == 'C'

# Generated at 2022-06-24 20:36:48.528357
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0()

# end class Testcase

# Generated at 2022-06-24 20:36:51.458514
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test case 0:
    complex_0 = None
    var_0 = get_best_parsable_locale(complex_0)
    assert var_0 == 'C'


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 20:36:53.839682
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Check if function raises expected exceptions
    with pytest.raises(RuntimeWarning):
        get_best_parsable_locale(complex_0)
    # No exception when no exception is expected
    assert get_best_parsable_locale(complex_0, True)

# Generated at 2022-06-24 20:36:54.598345
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
  assert True


# Generated at 2022-06-24 20:37:05.666970
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert "C.utf8" == get_best_parsable_locale(None)

# Generated at 2022-06-24 20:37:06.793773
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # AssertionError: None != 'expected'
    assert get_best_parsable_locale(None) != "expected"


# Generated at 2022-06-24 20:37:12.832870
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(type='list', required=False)
        )
    )

    rc = None
    out = None
    err = None
    result = dict(
        changed=False,
        rc=rc,
        stdout=out,
        stderr=err,
        locale='C',
    )

    if module.params['preferences']:
        result['locale'] = get_best_parsable_locale(module, module.params['preferences'], raise_on_locale=False)

    module.exit_json(**result)


from ansible.module_utils.basic import *
main()

# Generated at 2022-06-24 20:37:18.913697
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Call the method with a bytes or str object instead of a module
    with pytest.raises(AssertionError):
        get_best_parsable_locale('I am a string')

    # Call the method with a bytes or str object instead of a module
    with pytest.raises(AssertionError):
        get_best_parsable_locale(b'I am a string')

# Generated at 2022-06-24 20:37:21.660685
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Make sure the function returns a string
    returned_0 = get_best_parsable_locale("complex_0")
    assert returned_0 is not None
    assert isinstance(returned_0, str)

# Generated at 2022-06-24 20:37:24.486005
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C', "Function get_best_parsable_locale returned an incorrect value"
    print('Correctly ran get_best_parsable_locale')


# Generated at 2022-06-24 20:37:27.018365
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # FIXME: change this test to lint.
    assert test_case_0() == True

# pylint: disable=redefined-outer-name

# Generated at 2022-06-24 20:37:28.083141
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True is not False



# Generated at 2022-06-24 20:37:31.985841
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    complex_0 = None
    var_0 = get_best_parsable_locale(complex_0)
    if type(var_0) is str:
        assert True
    else:
        assert False


# Generated at 2022-06-24 20:37:34.143662
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    source, target = gen_testdata(test_case_0, test_case_0)
    test_fixture(source, target)


# Generated at 2022-06-24 20:38:03.710004
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Check if the function returns the right results
    assert test_case_0() == None

# Generated at 2022-06-24 20:38:07.615253
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert(get_best_parsable_locale([]) == 'C')
    except AssertionError:
        print("Testcase 0 failed.")
        raise

if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:38:11.798297
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Mock AnsibleModule class
    class MockAnsibleModule:
        def get_bin_path(self, complex_1):
            return "/usr/bin/locale"

        def run_command(self, complex_2):
            return 123
    
    test_case_0()


# Generated at 2022-06-24 20:38:15.467783
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert False == False
    var_0 = get_best_parsable_locale(complex_0)
    var_1 = get_best_parsable_locale(complex_1)
    var_2 = get_best_parsable_locale(complex_2)

# Generated at 2022-06-24 20:38:24.397538
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Setup test
    complex_1 = None

    # Test the get_best_parsable_locale method for a basic structure.
    var_1 = get_best_parsable_locale(complex_1)

    # Assert correct type
    assert type(var_1) == str, "var_1 is not a string."

    # Assert correct value
    assert var_1 == "C", "var_1 is not 'C'."

    # Setup test
    preferences = None

    # Test the get_best_parsable_locale method for a basic structure.
    var_2 = get_best_parsable_locale(complex_1, preferences)

    # Assert correct type
    assert type(var_2) == str, "var_2 is not a string."

    # Assert correct value

# Generated at 2022-06-24 20:38:27.673587
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() is None, "Info: If a function has only 1 return, there should be no more code outside the function than what is required to run the function."

# Generated at 2022-06-24 20:38:36.397123
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # define arguments and prepare the test cases
    complex_0 = None
    preferences = None
    raise_on_locale = False

    # prepare the test fixtures
    fixture_01 = [
        'C.utf8',
        'en_US.utf8',
        'C',
        'POSIX'
    ]

    fixture_02 = [
        'C.utf8',
        'en_US.utf8',
        'C',
        'POSIX'
    ]

    # execute the test

    # assert the results
    assert get_best_parsable_locale(complex_0) == 'C'
    assert get_best_parsable_locale(complex_0, preferences) == 'C'

# Generated at 2022-06-24 20:38:45.621905
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # The following definition should pass
    complex_0 = None
    var_0 = get_best_parsable_locale(complex_0)

    assert var_0 == 'C'

# Need to implement this, does not work on windows
# def test_get_best_parsable_locale_with_preferences():
#     # The following definition should pass
#     complex_0 = None
#     preferences_0 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
#     var_0 = get_best_parsable_locale(complex_0, preferences_0)

#     assert var_0 == 'C.utf8'

# # Need to implement this, does not work on windows
# def test_get_best_parsable_locale_with_pre

# Generated at 2022-06-24 20:38:50.923842
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    examples = {
        'default': 'C',
    }
    for name, example in examples.items():
        module = AnsibleModule(
            argument_spec=dict(
                preferences=dict(type='list'),
            ),
        )
        module.params = {'preferences': example}
        result = get_best_parsable_locale(module)
        assert result == example



# Generated at 2022-06-24 20:38:58.349463
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-24 20:39:28.849431
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert_equals(get_best_parsable_locale(complex_0), var_0)



# Generated at 2022-06-24 20:39:31.091056
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(test_case_0()) == 'C'

# Generated at 2022-06-24 20:39:40.710880
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    mock_module = MagicMock()
    mock_rc = (0, "stdout", "stderr")
    mock_module.run_command = MagicMock(return_value=mock_rc)
    preferences = ["en_US.UTF-8", "en_US.utf8", "UTF-8", "en_US.UTF-8", "en_US.utf8", "UTF-8", "C", "English", "POSIX"]
    assert(get_best_parsable_locale(mock_module, "en_US.UTF-8") == "en_US.UTF-8")
    assert(get_best_parsable_locale(mock_module, preferences) == "en_US.UTF-8")

# Generated at 2022-06-24 20:39:43.480392
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    complex_0 = None
    var_0 = get_best_parsable_locale(complex_0)

# Generated at 2022-06-24 20:39:45.201019
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert type(get_best_parsable_locale(
        complex_0)) is type(str())



# Generated at 2022-06-24 20:39:47.386902
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() # TODO: Fix this, it's returning None now.
    #assert 1 == 0 # TODO: Fix this.

# Generated at 2022-06-24 20:39:56.017850
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    print(locals())
    func_0 = get_best_parsable_locale
    complex_0 = None
    long_1 = 909090
    complex_0 = None
    long_2 = 909090
    complex_0

# Generated at 2022-06-24 20:40:02.358141
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock argument values

    # Parse arguments into args and kwargs
    args = []
    kwargs = {}

    # Mock the actual call within the function and collect the results
    get_best_parsable_locale(*args, **kwargs)

    # Establish that the results of the function are as expected
    assert True == True # todo: implement your test here



# Generated at 2022-06-24 20:40:08.477937
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # generating test cases.
    test_case_0()


# Ansible dynamic inventory script for OpenStack (virtual machines only)
# ==============================================

from __future__ import (absolute_import, division, print_function)
from ansible.module_utils.openstack import openstack_cloud_from_module

from ansible.module_utils.openstack import openstack_full_argument_spec, openstack_module_kwargs
from ansible.module_utils.six import iteritems



# Generated at 2022-06-24 20:40:15.721714
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import os

    class AnsibleModuleMock():
        def __init__(self, *args, **kwargs):
            self.params = kwargs.get('params', {})
        def get_bin_path(self, *args, **kwargs):
            return '/bin/{}'.format(args[0])
        def run_command(self, *args, **kwargs):
            return [0, '/opt/ansible/lib/python3.5/site-packages/ansible/module_utils/basic.py', '']

    module = AnsibleModule(argument_spec={}, params={"complex": "Foo", "a": "Foo", "b": "Foo"})

# Generated at 2022-06-24 20:40:45.568991
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True



# Generated at 2022-06-24 20:40:47.961830
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 2 == 1 + 1

# Generated at 2022-06-24 20:40:51.812533
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Return the first matched preferred locale or 'C' which is the default
    result = get_best_parsable_locale(test_case_0)

    assert result == 'C', \
        'Expected %s but got %s' % ('C', result)

# Generated at 2022-06-24 20:40:53.066708
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)



# Generated at 2022-06-24 20:40:58.535113
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    arg0 = dict(get_bin_path=lambda self, x: None, run_command=lambda self, x: (0, '', ''))
    arg0['get_bin_path'].__self__ = arg0
    arg1 = None
    arg2 = False
    ret_stub = []
    ret = get_best_parsable_locale(arg0, arg1, arg2)
    assert ret == 'C'
    assert ret == ret_stub

# Generated at 2022-06-24 20:41:01.978376
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:41:05.829494
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    complex_0 = None
    var_0 = get_best_parsable_locale(complex_0)
    try:
        assert var_0
    except AssertionError as ae:
        print(ae)


# Connect to Ansible test infrastructure

# Generated at 2022-06-24 20:41:15.024700
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Dummy module
    class DummyModule:
        def get_bin_path(self, arg):
            # Function returns an exit code of 0 and an empty string for error.
            # get_bin_path must return true for the following cases:
            #   arg = "locale"
            arg_to_return = {'locale': 0}

            try:
                return arg_to_return[arg]
            except KeyError:
                return 1


# Generated at 2022-06-24 20:41:18.807623
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Read parameters
    complex_0 = []
    complex_0.append(None)
    complex_0.append(None)
    complex_0.append(None)
    preferences_0 = []
    preferences_0.append('C.utf8')
    preferences_0.append('en_US.utf8')
    preferences_0.append('C')
    preferences_0.append('POSIX')
    raise_on_locale_0 = False

    # Run function call
    var_0 = get_best_parsable_locale(complex_0, preferences_0, raise_on_locale_0)

    var_1 = get_best_parsable_locale(complex_0, preferences_0, raise_on_locale_0)

    # Check results

# Generated at 2022-06-24 20:41:25.108476
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    complex_0 = None
    var_0 = get_best_parsable_locale(complex_0)
    assert var_0 == 'C'

    complex_1 = None
    var_1 = get_best_parsable_locale(complex_1, ['foo'])
    assert var_1 == 'C'


if __name__ == '__main__':
    test_case_0()
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:41:57.621936
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('module') == 'C'
    assert get_best_parsable_locale(module='module') == 'C'
    assert get_best_parsable_locale(preferences='preferences') == 'C'
    assert get_best_parsable_locale(module='module', preferences='preferences') == 'C'

# Generated at 2022-06-24 20:42:04.838357
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # class Args: pass
    # complex_0 = Args()     # class for None
    # complex_0.path = "/bin"
    # complex_0.run_command = pass_method_param
    # complex_0.get_bin_path = pass_method_param

    # var_0 = get_best_parsable_locale(complex_0)
    assert 0


# Generated at 2022-06-24 20:42:06.663455
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(get_best_parsable_locale(complex_0) == var_0)

# Generated at 2022-06-24 20:42:07.528312
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test with default arguments
    test_case_0()

# Generated at 2022-06-24 20:42:08.398738
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_0()



# Generated at 2022-06-24 20:42:12.027230
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Populating the necessary data elements
    complex_0 = None
    preferences_0 = []
    raise_on_locale_0 = True
    # Invoking the function
    var_0 = get_best_parsable_locale(complex_0, preferences_0, raise_on_locale_0)

# Generated at 2022-06-24 20:42:15.264764
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-24 20:42:18.062179
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec = dict()
    )

    assert get_best_parsable_locale(module) == "C"


# Generated at 2022-06-24 20:42:23.160785
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test simple test case
    complex_0 = None
    var_0 = get_best_parsable_locale(complex_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:42:29.298628
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # mock AnsibleModule
    class AnsibleModule(object):
        def __init__(self, **kwargs):
            self.ansible_module = {}
            self.ansible_module['get_bin_path'] = self.get_bin_path
            self.ansible_module['run_command'] = self.run_command
            pass

        def get_bin_path(self, name, required=True):
            return "locale"


# Generated at 2022-06-24 20:43:05.514035
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert True == True
    except AssertionError as e:
        print(e)
        print_failure()
        return

    print_success()

# Execute unit tests
if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:43:09.253883
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        # Testing for function get_best_parsable_locale
        test_case_0()
    except (IOError, TypeError, NameError) as e:
        print('Exception raised %s' % e)
    else:
        print('Test cases passed ')

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:43:12.354554
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )
    var_0 = get_best_parsable_locale(module)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:43:13.878450
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert var_0 == 'C'
    except AssertionError:
        raise AssertionError(str(var_0) + " != " + 'C')

# Generated at 2022-06-24 20:43:14.819934
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == None


# Generated at 2022-06-24 20:43:18.473401
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

# Generated at 2022-06-24 20:43:19.675886
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert isinstance(get_best_parsable_locale(module_0, preferences=None, raise_on_locale=False), str)

# Generated at 2022-06-24 20:43:24.715428
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(test_case_0())


# Unit Test Example
# unit_test = get_best_parsable_locale(complex_0)

# unit_test = get_best_parsable_locale(complex_1)

# unit_test = get_best_parsable_locale(complex_2)

# unit_test = get_best_parsable_locale(complex_3)

# unit_test = get_best_parsable_locale(complex_4)

# unit_test = get_best_parsable_locale(complex_5)

# unit_test = get_best_parsable_locale(complex_6)

# unit_test = get_best_parsable_locale(complex_7)

# unit_test = get_

# Generated at 2022-06-24 20:43:25.599750
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:43:27.610136
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    complex_1 = None
    var_1 = get_best_parsable_locale(complex_1)

    assert var_1 == "C"

# Generated at 2022-06-24 20:44:03.647281
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    results = get_best_parsable_locale(test_case_0())
    assert results[0] is None
    assert results[1] is None
    assert results[2] is None
    assert results[3] is None
    assert results == (None, None, None, None)

# Generated at 2022-06-24 20:44:06.573290
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == "C"

# Generated at 2022-06-24 20:44:14.455122
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    complex_1 = None
    preferences_1 = None
    raise_on_locale_1 = False
    var_1 = get_best_parsable_locale(complex_1, preferences_1, raise_on_locale_1)

    assert var_1 == 'C', 'Expected C, got {0}'.format(var_1)
    complex_2 = None
    preferences_2 = None
    raise_on_locale_2 = True
    var_2 = get_best_parsable_locale(complex_2, preferences_2, raise_on_locale_2)

    assert var_2 == 'C', 'Expected C, got {0}'.format(var_2)

if __name__ == "__main__":
    test_case_0()
    test_get_best_

# Generated at 2022-06-24 20:44:17.942884
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True

#
# main test run
#

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:44:19.118416
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Complex tests may be added later.
    pass


# Generated at 2022-06-24 20:44:26.963676
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    mock_module = MagicMock()
    mock_run_command = MagicMock(return_value=(0, '', ''))
    mock_module.run_command = mock_run_command
    mock_get_bin_path = MagicMock(return_value=get_best_parsable_locale.__code__.co_filename)
    mock_module.get_bin_path = mock_get_bin_path

    assert get_best_parsable_locale(mock_module) == 'C.utf8'

    pass



# Generated at 2022-06-24 20:44:30.153708
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:44:37.835776
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    x = AnsibleModule(complex_args=None)
    x.run_command = mock_run_command

    assert get_best_parsable_locale(x) == 'C'
    assert get_best_parsable_locale(x, ['en_US.utf8']) == 'C'
    assert get_best_parsable_locale(x, ['C.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(x, ['POSIX']) == 'POSIX'


# Generated at 2022-06-24 20:44:38.320301
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-24 20:44:44.667152
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(complex_0, [preferences_0, raise_on_locale_0]) == var_0
    assert get_best_parsable_locale(complex_1, preferences_1) == var_1

# Generated at 2022-06-24 20:45:21.976880
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    x =  get_best_parsable_locale(module, preferences=None, raise_on_locale=False)

# Generated at 2022-06-24 20:45:24.012638
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, None, None) == 'C'

# Generated at 2022-06-24 20:45:29.138134
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # This will allow us to use the same input, and expected
    # result for every test. We only need to update 'expected'
    # for each test.

    complex_0 = None
    expected = 'C'

    # Test #0:
    var_0 = get_best_parsable_locale(complex_0)
    assert var_0 == expected