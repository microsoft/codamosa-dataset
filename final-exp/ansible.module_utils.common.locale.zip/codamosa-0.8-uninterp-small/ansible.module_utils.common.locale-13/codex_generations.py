

# Generated at 2022-06-24 20:35:36.768956
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert False # TODO: implement your test here


# Generated at 2022-06-24 20:35:39.421751
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass


# Generated at 2022-06-24 20:35:49.573172
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(get_best_parsable_locale(b'\xdd[', [b'\xf0\x9f\x8d\x8c', b'\xe2\x9a\x99', b'\xdd[']) == b'\xf0\x9f\x8d\x8c')
    assert(get_best_parsable_locale(b'\xdd[', [b'\xe2\x9a\x99', b'\xdd[', b'\xf0\x9f\x8d\x8c']) == b'\xe2\x9a\x99')

# Generated at 2022-06-24 20:35:53.806107
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass # TODO: implement your test here if get_best_parsable_locale is non-trivial


if __name__ == "__main__":
    test_case_0()
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:35:56.061422
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) is None
    assert get_best_parsable_locale(1) is None



# Generated at 2022-06-24 20:35:59.295668
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    args = []
    if __name__ == '__main__':
        test_case_0()


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:36:09.791731
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert_equals(get_best_parsable_locale(preferences=[], raise_on_locale=False), 'C')
    assert_equals(get_best_parsable_locale(locale=None, raise_on_locale=True), True)
    assert_equals(get_best_parsable_locale(locale=None, preferences=[], raise_on_locale=True), False)
    assert_equals(get_best_parsable_locale(preferences=[], raise_on_locale=True), True)
    assert_equals(get_best_parsable_locale(locale=None, preferences=[], raise_on_locale=False), 'C')

# Generated at 2022-06-24 20:36:11.080218
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)

# Generated at 2022-06-24 20:36:13.109624
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale == 'C'

# Generated at 2022-06-24 20:36:21.832820
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec = dict()
    )

    # Test if exception is raised
    try:
        get_best_parsable_locale(module)
    except:
        pass
    else:
        raise AssertionError('Failure getting best parsable locale')

    # Test if exception is raised
    try:
        get_best_parsable_locale(module, preferences=None)
    except:
        pass
    else:
        raise AssertionError('Failure getting best parsable locale')

    # Test if exception is raised
    try:
        get_best_parsable_locale(module, preferences=None, raise_on_locale=False)
    except:
        pass
    else:
        raise Assertion

# Generated at 2022-06-24 20:36:37.112672
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Testing for function get_best_parsable_locale
    assert func_0(bytes_0_0) == str_0
    assert func_0(bytes_0_1) == str_1
    assert func_0(bytes_0_2) == str_2
    assert func_0(bytes_0_3) == str_3
    assert func_0(bytes_0_4) == str_4
    assert func_0(bytes_0_5) == str_5
    assert func_0(bytes_0_6) == str_6
    assert func_0(bytes_0_7) == str_7
    # TODO: Add more tests, this only tests the first 8 bytes


test_get_best_parsable_locale()

# Generated at 2022-06-24 20:36:39.520403
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale is not None


# Generated at 2022-06-24 20:36:40.359752
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert False, "Test not implemented"

# Generated at 2022-06-24 20:36:46.376773
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        module = ansible_module_prepared
    except NameError:
        module = None

    assert len(get_best_parsable_locale(module)) > 0


# Generated at 2022-06-24 20:36:49.588989
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print('test_get_best_parsable_locale....')


if __name__ == "__main__":
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:36:57.792921
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bytes_0 = b'\xdd['
    assert get_best_parsable_locale(bytes_0) == 'C', "get_best_parsable_locale() should not return False"
    assert get_best_parsable_locale(bytes_0) == 'C', "get_best_parsable_locale() should not return False"

if __name__ == '__main__':
    test_get_best_parsable_locale()
    test_case_0()

# Generated at 2022-06-24 20:37:00.637688
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(module, preferences=preferences, raise_on_locale=raise_on_locale) == 'C'

# Generated at 2022-06-24 20:37:08.774756
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import io
    import ansible_collections.ansible.community.plugins.module_utils.shell as shell

    fout = io.StringIO()
    # Use if available
    # fout, ferr = os.pipe()
    # Modify fd's so that they are not inherited by the child process
    # sys.stdin = os.fdopen(os.dup(sys.stdin.fileno()), 'r', closefd=True)
    # sys.stdout = os.fdopen(os.dup(sys.stdout.fileno()), 'w', closefd=True)
    # sys.stderr = os.fdopen(os.dup(sys.stderr.fileno()), 'w', closefd=True)
    stdout_fileno = sys.stdout.fileno

# Generated at 2022-06-24 20:37:11.401162
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(bytes_0) == var_0
    assert get_best_parsable_locale(bytes_0) != var_0


# testing out some features
if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 20:37:14.667824
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == get_best_parsable_locale(b'\xdd[', [b'C.utf8', b'test'], True)



# Generated at 2022-06-24 20:37:27.883444
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except:
        assert False

# Unit tests for function get_best_parsable_locale
# unit_tests = [
#     test_get_best_parsable_locale,
# ]

# for unit_test in unit_tests:
#     unit_test()

test_get_best_parsable_locale()
print('Unit test completed successfully')

# Generated at 2022-06-24 20:37:37.453156
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('\xdd[') == 'C'
    assert get_best_parsable_locale('\xdd[', []) == 'C'
    assert get_best_parsable_locale('\xdd[', None, False) == 'C'
    assert get_best_parsable_locale('\xdd[', None, True) == 'C'
    assert get_best_parsable_locale('\xdd[', ['C.utf8'], True) == 'C.utf8'
    assert get_best_parsable_locale('\xdd[', ['en_US.utf8'], False) == 'en_US.utf8'

# Generated at 2022-06-24 20:37:44.296459
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_1 = get_best_parsable_locale()
    assert var_1 == 'C'
    var_2 = get_best_parsable_locale(preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'])
    assert var_2 == 'C'
    var_3 = get_best_parsable_locale(preferences=['en_US.utf8', 'en_US.utf8', 'C', 'POSIX'])
    assert var_3 == 'en_US.utf8'



# Generated at 2022-06-24 20:37:52.309944
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(
        argument_spec = dict(
            module = dict(type='str', required=True),
            preferences = dict(type='int', required=False),
            raise_on_locale = dict(type='bool', required=False),
        ),
        supports_check_mode=True,
    )

    # Test with correct data types
    get_best_parsable_locale(module.params['module'],
                             module.params['preferences'],
                             module.params['raise_on_locale'])

    # Test with wrong types passed
    module.params['module'] = 0x0b
    module.params['preferences'] =  - 0x04
    module.params['raise_on_locale'] = "0x0c"
    get_best_parsable

# Generated at 2022-06-24 20:37:53.850609
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == b'\xdd['

# Generated at 2022-06-24 20:38:03.610351
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_1 = {
        'preferences': ['C', 'POSIX'],
        'raise_on_locale': False,
    }
    var_2 = get_best_parsable_locale(var_1)
    assert var_2 == 'C'
    var_3 = {
        'preferences': ['POSIX', 'C'],
        'raise_on_locale': False,
    }
    var_4 = get_best_parsable_locale(var_3)
    assert var_4 == 'POSIX'
    var_5 = {
        'preferences': ['C'],
        'raise_on_locale': False,
    }
    var_6 = get_best_parsable_locale(var_5)

# Generated at 2022-06-24 20:38:05.016847
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' == get_best_parsable_locale(None, None, None)

# Generated at 2022-06-24 20:38:15.563358
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-24 20:38:16.471880
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True


# Generated at 2022-06-24 20:38:18.447492
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(b'\xdd[') == 'C'

# Generated at 2022-06-24 20:38:26.992263
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bytes_0 = b'\xdd['

    # Call get_best_parsable_locale
    var_0 = get_best_parsable_locale(bytes_0)

# Generated at 2022-06-24 20:38:28.400055
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bytes_0 = b''
    var_0 = get_best_parsable_locale(bytes_0)
    assert var_0 == 'C'


# Generated at 2022-06-24 20:38:34.245177
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except Exception as e:
        assert False, "unable to execute test_case_0: %s" % (e.__class__.__name__)
    else:
        assert True

# Generated at 2022-06-24 20:38:39.183089
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module_0 = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Call to get_best_parsable_locale(bytes)
    test_case_0(module_0)


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:38:46.273690
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bytes_0 = b'\xb5\x0c:\x15]\x9c\xae\x8c\x14(\x1c\x05i\xd8'
    # Call the function
    get_best_parsable_locale(bytes_0)


test_case_0()

# Generated at 2022-06-24 20:38:55.680488
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Unit test for function get_best_parsable_locale

    # Make sure you call function with the right parameters
    preferences = ['test']
    get_best_parsable_locale(preferences)

    # Make sure exceptions are not thrown incorrectly
    try:
        preferences = ['test']
        get_best_parsable_locale(preferences, raise_on_locale=True)
    except RuntimeWarning:
        pass

    # Make sure function returns when called correctly
    preferences = ['test']
    get_best_parsable_locale(preferences, raise_on_locale=False)

# Generated at 2022-06-24 20:38:59.181198
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, None, None) == 'C'

# Generated at 2022-06-24 20:39:04.333459
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test the following:
    # - If the returned value is not 'C' (Line #1)
    assert get_best_parsable_locale(None) == 'C'
    test_case_0()

# Generated at 2022-06-24 20:39:11.621120
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import json
    import ansible.module_utils.basic

    class TestClass0(object):
        def get_bin_path(self, arg_0):
            return arg_0

        def run_command(self, arg_0):
            return arg_0

    assert get_best_parsable_locale(TestClass0()) is not None 


# Generated at 2022-06-24 20:39:20.920276
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.facts import Facts
    input_arguments = dict(
        ansible_facts = Facts(dict()),
        module = dict(),
        preferences = None,
        raise_on_locale = False
    )
    output_arguments = dict()

    # Construct the arguments from the input arguments
    arguments = dict()
    for k, v in input_arguments.items():
        arguments[k] = v

    # Call the target function
    retval = get_best_parsable_locale(**arguments)

    # Construct the output_arguments from the return value
    d = dict()

    # Construct the return value
    rv = dict(
        arguments=arguments,
        output_arguments=output_arguments,
        return_value=retval,
    )


# Generated at 2022-06-24 20:39:42.963233
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        assert get_best_parsable_locale(b'\xdd[') == 'C'
        assert get_best_parsable_locale(b'\xdd[', raise_on_locale=True) == 'C'
        assert get_best_parsable_locale(b'', preferences=['C']) == 'C'

        # both are the same locale
        assert get_best_parsable_locale(b'\nC\nC.utf8\nPOSIX', preferences=['C.utf8', 'POSIX']) in ('C', 'C.utf8')
    except ImportError:
        pass
    except RuntimeWarning:
        pass

# Generated at 2022-06-24 20:39:52.797281
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import logging
    import platform

    # Test with Python 2
    if platform.python_version_tuple()[0] == "2":

        test_case_0()
        test_case_1()
        test_case_2()
        test_case_3()
        test_case_4()
        test_case_5()
        test_case_6()
        test_case_7()
        test_case_8()
        test_case_9()
        test_case_10()
        test_case_11()
        test_case_12()
        test_case_13()
        test_case_14()
        test_case_15()
        test_case_16()
        test_case_17()
        test_case_18()
        test_case_19()
        test_case_

# Generated at 2022-06-24 20:39:58.017954
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = get_best_parsable_locale()
    assert var_0 is None
    var_1 = get_best_parsable_locale(preferences = [])
    assert var_1 is None
    var_2 = get_best_parsable_locale(preferences = [], raise_on_locale = False)
    assert var_2 is None
    var_3 = get_best_parsable_locale(preferences = [], raise_on_locale = True)
    assert var_3 is None


# Generated at 2022-06-24 20:40:03.956740
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    cmd = ('tmp=$(mktemp); '
           'cat > $tmp <<EOF;'
           '#!/usr/bin/python\n'
           'from ansible.module_utils.basic import *\n'
           'from ansible.module_utils.translation import *\n'
           'from ansible.module_utils.facts import *\n'
           'if __name__ == \'__main__\':\n'
           '   module = AnsibleModule(argument_spec=dict(\n'
           '      ))\n'
           '   print get_best_parsable_locale(module)\n'
           'EOF\n'
           'chmod +x $tmp;$tmp')
    rc, out, err = module.run_command(cmd)
    assert rc == 0
    assert "C"

# Generated at 2022-06-24 20:40:09.247202
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    # Test case 0:
    # Create AnsibleModule instance
    ansible_module = AnsibleModule(argument_spec={})

    # Execute function get_best_parsable_locale
    get_best_parsable_locale(ansible_module)

    # Attempt to get variable from module
    var_0 = ansible_module.params.get('locale')

    assert var_0 == 'C'

# Generated at 2022-06-24 20:40:10.668172
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # assert_equal(get_best_parsable_locale(), expected)    
    assert True

# Generated at 2022-06-24 20:40:13.315594
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_1 = str
    var_2 = get_best_parsable_locale(var_1)
    assert isinstance(var_2, str)


# Generated at 2022-06-24 20:40:17.668403
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:40:18.464432
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:40:28.162389
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 0 == get_best_parsable_locale('"\x1a', '\x1c')
    assert 0 == get_best_parsable_locale(b'\x1eU\xcb', '\x82')
    assert 0 == get_best_parsable_locale('\x00\x8d', '\x12')
    assert 0 == get_best_parsable_locale('\x0c\xfe', b'\x14')
    assert 0 == get_best_parsable_locale(b'\x1e', b'\xce')
    assert 0 == get_best_parsable_locale('\x9a', '\x2a')

# Generated at 2022-06-24 20:40:43.755163
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bytes_0 = b'\xdd['
    var_0 = get_best_parsable_locale(bytes_0)

# Generated at 2022-06-24 20:40:47.340933
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == None
    assert "test" == "test"

# Generated at 2022-06-24 20:40:54.160486
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert get_best_parsable_locale('\xdd[', preferences=['\xdd[', 'z\x15']) == '\xdd['

    assert get_best_parsable_locale(preferences=['z\x15', \
                                                 '\xdd[']) == 'z\x15'

    assert get_best_parsable_locale(preferences=['z\x15', 'z\x15', \
                                                 '\xdd[']) == 'z\x15'



# Generated at 2022-06-24 20:41:02.764735
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Output from module to be tested
    bytes_0 = b'\xdd['

    # Calling function to be tested
    assert get_best_parsable_locale(bytes_0)
    # Output from module to be tested
    bytes_0 = b'\xdd['
    preferences_0 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    # Calling function to be tested
    assert get_best_parsable_locale(bytes_0, preferences_0)
    # Output from module to be tested
    bytes_0 = b'\xdd['
    preferences_0 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    raise_on_locale_0 = True

    # Calling function to be tested
    assert get_best_

# Generated at 2022-06-24 20:41:06.913492
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Python3.5 and later use __bytes__
    # Python2.7 and later use bytes
    bytes_0 = b'\xdd['
    var_0 = get_best_parsable_locale(bytes_0)
    assert var_0 == 'C'


# Generated at 2022-06-24 20:41:08.905405
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() == b'3\x99\x16\x0b'

# Generated at 2022-06-24 20:41:11.238899
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    os.environ['ANSIBLE_MOD_UTILS_LOCALE'] = os.path.dirname(__file__) + '/locale_test_case.py'
    from ansible.module_utils import locale
    assert locale.get_best_parsable_locale() == 'C'

# Generated at 2022-06-24 20:41:12.849615
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(bytes_0, None, False) == 'C'



# Generated at 2022-06-24 20:41:17.553112
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = FakeModule()
    assert get_best_parsable_locale(module) == 'C'


# Generated at 2022-06-24 20:41:18.760929
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = get_best_parsable_locale(None, None, None)

# Generated at 2022-06-24 20:41:40.680993
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import mock

    module = mock.Mock()
    preferences = mock.Mock()
    raise_on_locale = mock.Mock()

    module.get_bin_path.return_value = 'C.utf8'
    module.run_command.return_value = (0, '', '')

    assert get_best_parsable_locale(module, preferences, raise_on_locale) == 'C'

    module.run_command.return_value = (1, '', '')
    assert get_best_parsable_locale(module, preferences, raise_on_locale) == 'C'



# Generated at 2022-06-24 20:41:41.449346
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()



# Generated at 2022-06-24 20:41:48.034667
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Initialize values for testing
    sample_bytes = b'\xdd['

    # Call the function
    var_0 = get_best_parsable_locale(sample_bytes)

    # Test the results against the expected
    assert var_0 == 'C'

# Generated at 2022-06-24 20:41:58.425703
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(b'\xdd[') == 'C'
    assert get_best_parsable_locale(b'\xdd[', raise_on_locale=True) == 'C'
    assert get_best_parsable_locale(b'\xdd[', preferences=None) == 'C'
    assert get_best_parsable_locale(b'\xdd[', preferences=None, raise_on_locale=True) == 'C'
    assert get_best_parsable_locale(b'\xdd[', preferences=[b'\xdd[']) == 'C'

# Generated at 2022-06-24 20:41:58.977829
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True == True


# Generated at 2022-06-24 20:42:05.194819
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bytes_0 = b'\xdd['
    var_0 = get_best_parsable_locale(bytes_0)
    assert var_0 == 'C'
    preferences_0 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    var_1 = get_best_parsable_locale(bytes_0, preferences_0)
    assert var_1 == 'C'

# Generated at 2022-06-24 20:42:13.933657
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Init vars
    bytes_0 = None
    preferences_0 = None
    raise_on_locale_0 = None
    result_0 = None
    result_1 = None
    result_2 = None
    result_3 = None
    result_4 = None
    result_5 = None
    result_6 = None
    result_7 = None
    result_8 = None
    result_9 = None

    # Function call
    bytes_0 = b'\xdd['
    preferences_0 = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    raise_on_locale_0 = False
    result_0 = get_best_parsable_locale(bytes_0, preferences_0, raise_on_locale_0)

    # Function call
    bytes

# Generated at 2022-06-24 20:42:15.144089
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == "C"

# Generated at 2022-06-24 20:42:17.323829
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:42:23.214455
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        test_case_0()
    except AttributeError:
        pass


#
# Test get_best_parsable_locale()
#

# Generated at 2022-06-24 20:42:42.615176
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # assert hasattr(get_best_parsable_locale, '__call__')
    assert get_best_parsable_locale is not None



# Generated at 2022-06-24 20:42:45.912506
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    args = []
    if __name__ == '__main__':
        args = testutils.parse_args(args)

    # Setup
    # Run the function
    try:
        get_best_parsable_locale()
    except:
        pass

    # Tested function
    assert True

# Generated at 2022-06-24 20:42:52.178818
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('relay-tcp-server') == 'C'
    assert get_best_parsable_locale('errand-filesystem') == 'C'
    assert get_best_parsable_locale('bin-routing') == 'C'
    assert get_best_parsable_locale('architect-helm') == 'C'
    assert get_best_parsable_locale('bios-replication') == 'C'
    assert get_best_parsable_locale('bios-disks') == 'C'
    assert get_best_parsable_locale('market-ops-nfs') == 'C'
    assert get_best_parsable_locale('purposeful-ops-nfs') == 'C'
    assert get_

# Generated at 2022-06-24 20:42:53.575163
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bytes_0 = b'\xdd['
    var_0 = get_best_parsable_locale(bytes_0)
    assert var_0 == 'C'

# Generated at 2022-06-24 20:43:01.359486
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bytes_2 = b'\xdd['
    var_2 = get_best_parsable_locale(bytes_2)
    assert var_2 == b'\xdd[', "Expected {}, Got {}".format(b'\xdd[', var_2)

    bytes_3 = b'\x0e\xdd['
    var_3 = get_best_parsable_locale(bytes_3)
    assert var_3 == b'\x0e\xdd[', "Expected {}, Got {}".format(b'\x0e\xdd[', var_3)

    bytes_4 = b'\x0e\xdd[\xdd['
    var_4 = get_best_parsable_locale(bytes_4)

# Generated at 2022-06-24 20:43:06.110042
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale([1, 2, 3]) == 3
    assert get_best_parsable_locale(()) is None

# Generated at 2022-06-24 20:43:13.894523
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('\xe4') == 'C'
    assert get_best_parsable_locale('\xb3') != 'C'
    assert get_best_parsable_locale('\x14') == 'C'
    assert get_best_parsable_locale('') == 'C'
    assert get_best_parsable_locale('\x1c') == 'C'
    assert get_best_parsable_locale('\xfb') == 'C'
    assert get_best_parsable_locale('\xf3') == 'C'
    assert get_best_parsable_locale('\xe4') != 'C'
    assert get_best_parsable_locale('\x83') == 'C'

# Generated at 2022-06-24 20:43:18.026184
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale is not None

test_case_0()

# Generated at 2022-06-24 20:43:19.923021
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert True

# Generated at 2022-06-24 20:43:25.954061
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import subprocess
    import sys

    class AnsibleModule(object):
        def __init__(self, **kwargs):
            self.bin_path = kwargs.pop("bin_path", {})
            self.check_mode = kwargs.pop("check_mode", False)
            self.debug = kwargs.pop("debug", True)
            self.params = kwargs.pop("params", {})
            self.run_command = kwargs.pop("run_command", self.run_command)
            self.version = kwargs.pop("version", (1, 9))

        def fail_json(self, *args, **kwargs):
            ''' fail with an error message '''
            raise Exception(args)


# Generated at 2022-06-24 20:43:45.464085
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
  try:
    test_case_0()
  except:
    assert False
  else:
    assert True

# Generated at 2022-06-24 20:43:49.848945
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert b'\xdd[' == get_best_parsable_locale(b'\xdd[')
    assert b'\xdd[' == get_best_parsable_locale(b'\xdd[', b'\xdd[')
    assert b'\xdd[' == get_best_parsable_locale(b'\xdd[', b'\xdd[', True)

# Generated at 2022-06-24 20:43:50.586391
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:43:51.662038
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert callable(get_best_parsable_locale)

# Generated at 2022-06-24 20:43:53.614596
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bytes_0 = b'\xdd['
    var_0 = get_best_parsable_locale(bytes_0)
    assert var_0 == 'C'



# Generated at 2022-06-24 20:43:58.781464
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_1 = get_best_parsable_locale()
    assert var_1 == 'C'

    var_2 = get_best_parsable_locale(var_1)
    assert var_2 == 'C'

    var_3 = get_best_parsable_locale(var_1, var_2)
    assert var_3 == 'C'

    var_4 = get_best_parsable_locale(var_1, var_2, True)
    assert var_4 == 'C'

    var_5 = get_best_parsable_locale(var_1, var_2, False)
    assert var_5 == 'C'

# Generated at 2022-06-24 20:44:02.431677
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_case_0()

# Generated at 2022-06-24 20:44:04.752742
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    my_preferences = ['en_US.utf8', 'C.utf8', 'en_US', 'C', 'POSIX']
    assert get_best_parsable_locale(my_preferences=my_preferences) == 'C.utf8'

# Generated at 2022-06-24 20:44:10.319941
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(b"\xdd[") == 'C'

# Generated at 2022-06-24 20:44:11.243833
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_1 = test_case_0()
    return var_1

# Generated at 2022-06-24 20:44:31.243905
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Evaluate whether get_best_parsable_locale() returns the correct
    value by comparing to a known-good value.
    '''
    assert get_best_parsable_locale(test_case_0()) == 'C'

# Generated at 2022-06-24 20:44:31.974861
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert False



# Generated at 2022-06-24 20:44:41.564661
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # bytes_0 is a bytearray
    bytes_0 = b'\xdd['
    var_0 = get_best_parsable_locale(bytes_0)
    assert var_0 == 'C'

    # bytes_1 is a bytearray
    bytes_1 = b'\xa9\x0fS\xcd\xcb\xde\x89\x17\x0c\xef=\xf9'
    var_1 = get_best_parsable_locale(bytes_1)
    assert var_1 == 'C'

    # bytes_2 is a bytearray

# Generated at 2022-06-24 20:44:42.919811
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    var_0 = get_best_parsable_locale()
    print(var_0)
    assert var_0 == "C"

# Generated at 2022-06-24 20:44:48.504357
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bytes_0 = b'\xdd['
    var_0 = get_best_parsable_locale(bytes_0)
    bytes_1 = b'\xdd['
    var_1 = get_best_parsable_locale(bytes_1)
    bytes_2 = b'\xdd['
    var_2 = get_best_parsable_locale(bytes_2)
    bytes_3 = b'\xdd['
    var_3 = get_best_parsable_locale(bytes_3)
    bytes_4 = b'\xdd['
    var_4 = get_best_parsable_locale(bytes_4)
    bytes_5 = b'\xdd['
    var_5 = get_best_parsable_locale(bytes_5)
   

# Generated at 2022-06-24 20:44:49.482454
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert test_case_0() is None

# Generated at 2022-06-24 20:44:55.070446
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    fld_0 = 58
    fld_1 = bytearray(60)
    fld_1[18] = 69

    # test function call
    try:
        get_best_parsable_locale(fld_0, fld_1)
    except TypeError as e:
        print('[*] get_best_parsable_locale: TypeError is thrown, as expected.')
    except Exception as e:
        print('[!] get_best_parsable_locale: Unexpected exception thrown: ' + str(e))
    else:
        print('[!] get_best_parsable_locale: Expected exception not thrown.')


if __name__ == '__main__':
    # test_case_0()
    test_get_best_parsable_locale()

# Generated at 2022-06-24 20:44:59.583818
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Testing string-type inputs
    assert get_best_parsable_locale(b'\xdd[', 'utf-8') == b'\xdd['

    # Testing int-type inputs
    assert get_best_parsable_locale(b'\xdd[', 42) == b'\xdd['


# Generated at 2022-06-24 20:45:05.065630
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # unit tests for ansible.module_utils.basic.get_best_parsable_locale
    assert get_best_parsable_locale(module="foo") == 'C'
    # test using bytes object
    assert get_best_parsable_locale(module=b'\xdd[') == 'C'

# Generated at 2022-06-24 20:45:14.860373
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert_equals(b'\xdd[', get_best_parsable_locale(b'\xdd['))
    assert_equals(b'\xdd[', get_best_parsable_locale(b'\xdd[', [b'C']))
    assert_equals(b'\xdd[', get_best_parsable_locale(b'\xdd[', [b'C', b'POSIX', b'C.utf8', b'en_US.utf8']))
    assert_equals(b'\xdd[', get_best_parsable_locale(b'\xdd[', [b'C', b'POSIX']))