

# Generated at 2022-06-11 01:08:44.872315
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """Unit test function get_best_parsable_locale
    """
    # These are the options we have
    # ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    # Try each one of them
    # Each should return
    # 'C.utf8'
    # 'en_US.utf8'
    # 'C'
    # 'POSIX'
    # 'C'
    from ansible.module_utils.basic import AnsibleModule
    preferences = ['en_US.utf8', 'C.utf8', 'C', 'POSIX']
    for test_locale in preferences:
        class TestModule(AnsibleModule):
            pass
        module = TestModule(
            argument_spec=dict())
        module.get_bin_path = lambda x: test_loc

# Generated at 2022-06-11 01:08:54.815845
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_module = type(str('AnsibleModule'), (object,), dict(get_bin_path=lambda self, path: path, run_command=lambda self, cmd, environ_update=None, check_rc=True, close_fds=True, executable=None: (0, 'C.UTF-8', None)))()
    assert get_best_parsable_locale(test_module) == 'C.UTF-8'

test_module = type(str('AnsibleModule'), (object,), dict(get_bin_path=lambda self, path: path, run_command=lambda self, cmd, environ_update=None, check_rc=True, close_fds=True, executable=None: (0, 'C.UTF-8', None)))()

# Generated at 2022-06-11 01:08:56.907542
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' == get_best_parsable_locale(None, ['nosuchlocale'])

# Generated at 2022-06-11 01:09:04.991230
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock module
    class MockModule:
        def __init__(self, run_command_return_code, run_command_stdout, run_command_stderr):
            self._run_command_return_code = run_command_return_code
            self._run_command_stdout = run_command_stdout
            self._run_command_stderr = run_command_stderr

        def get_bin_path(self, binary):
            return binary

        def run_command(self, command):
            if self._run_command_return_code == 0:
                return (self._run_command_return_code, self._run_command_stdout, self._run_command_stderr)
            else:
                raise Exception("Unable to find locale")

    # rc = 0 and out = null


# Generated at 2022-06-11 01:09:11.613257
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Example output of locale -a
    locale_a_out = '''
    C
    C.UTF-8
    en_AU.utf8
    en_CA.utf8
    en_GB.utf8
    en_US.utf8
    POSIX
    '''
    locale_a_out = locale_a_out.strip().splitlines()
    # Example output of locale -a, in case the system doesn't have any locale installed
    locale_a_out_empty = '''
    '''
    locale_a_out_empty = locale_a_out_empty.strip().splitlines()

    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    from ansible.module_utils.six import PY3

    locale_a_path = None


# Generated at 2022-06-11 01:09:17.749680
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # TODO: There's no easy way to test this.
    #       For example, one test case would be to set en_US.UTF-8 as the system-wide
    #       default locale and try to parse the output of env or ls.
    #       Late we have found out that this function is called from module_utils/basic.py
    #       That file has not been tested in a long time
    pass

# Generated at 2022-06-11 01:09:28.432878
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' test get_best_parsable_locale '''

    # Mock AnsibleModule - many of these pathos tests require it but
    # it is not always available
    try:
        from ansible.module_utils.common.ansible_module import AnsibleModule
    except ImportError:
        class AnsibleModule(object):
            ''' Mock AnsibleModule class '''
            def __init__(self):
                self.params = dict()

            def exit_json(self, **kwargs):
                ''' Mock exit_json '''

            def fail_json(self, msg=None, **kwargs):
                ''' Mock fail_json '''
                if msg:
                    raise Exception(msg)

    class MockArgs(object):
        ''' Mock argparse namescpace'''

# Generated at 2022-06-11 01:09:39.441455
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import unittest

    from ansible.module_utils.basic import AnsibleModule

    class AnsibleModuleMock(AnsibleModule):
        def __init__(self):
            self.params = dict()
            self.exit = sys.exit
            self.fail_json = sys.exit
            self.fail = sys.exit
            self.run_command = self.mock_run_command

        def mock_run_command(self, command):
            if command[0] == "locale":
                return 0, '\n'.join(LOCALE_OUTPUT), ''
            else:
                return 2, '','not found'


# Generated at 2022-06-11 01:09:46.356881
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # patch AnsibleModule instance to check that the string returned by the function is valid
    class MockAnsibleModule:
        def get_bin_path(self, command):
            return "/bin/true"
        def run_command(self, command):
            if command[1] == "-a":
                return (0, "C\nen_US.utf8\nC.utf8\nPOSIX\n", "")
            else:
                return (0, "", "")

    best_locale = get_best_parsable_locale(MockAnsibleModule())
    assert best_locale in ["C", "C.utf8", "POSIX", "en_US.utf8"]


# Generated at 2022-06-11 01:09:53.155919
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.system.locale import LOCALE_CHECK_RE

    assert get_best_parsable_locale(AnsibleModule(argument_spec={})) == 'C'

    a, b, c = list(LOCALE_CHECK_RE.findall('a_b.c'))
    assert a == 'a'
    assert b == 'b'
    assert c == 'c'

# Generated at 2022-06-11 01:10:00.909631
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(), supports_check_mode=False)
    locale = get_best_parsable_locale(module)
    assert locale == "C"

# Generated at 2022-06-11 01:10:06.134456
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()
    locale = get_best_parsable_locale(module)

    assert locale in ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    locale = get_best_parsable_locale(module, ['en_US.utf8', 'en_US.iso885915'])

    assert locale in ['en_US.utf8', 'en_US.iso885915']

# Generated at 2022-06-11 01:10:17.144358
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test for get_best_parsable_locale
    '''

    from ansible.module_utils.basic import AnsibleModule

    preferences = ['en_US.utf8', 'C', 'POSIX']
    test_module = AnsibleModule(argument_spec=dict())
    test_module.run_command = lambda cmd: (0, 'en_US.utf8\nC\nPOSIX', None)
    assert get_best_parsable_locale(test_module, preferences=preferences) == 'en_US.utf8'
    test_module.run_command = lambda cmd: (0, 'C.utf8\nPOSIX', None)
    assert get_best_parsable_locale(test_module, preferences=preferences) == 'C.utf8'
    test

# Generated at 2022-06-11 01:10:18.548354
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == "C"

# Generated at 2022-06-11 01:10:26.898786
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import _text

    module = AnsibleModule(supports_check_mode=True)

    preferences = 'C.UTF-8 en_US.UTF-8 zh_CN.UTF-8 zh_TW.UTF-8 de_DE.UTF-8 C'
    preferences = _text.split_args(preferences)

    module.run_command = lambda command, **kwargs: (0, '\n'.join(preferences), '')
    locale = get_best_parsable_locale(module, raise_on_locale=True)
    assert locale == 'C'

    module.run_command = lambda command, **kwargs: (0, '\n'.join([locale, ]), '')

# Generated at 2022-06-11 01:10:33.535824
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule(argument_spec={})
    cur_locale = module.get_bin_path("locale")
    assert get_best_parsable_locale(module) == cur_locale

# Generated at 2022-06-11 01:10:41.609456
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import unittest

    class ModuleStub(object):
        def __init__(self, tool_found, run_command_results, run_command_error_results):
            self.run_command_results = run_command_results
            self.run_command_error_results = run_command_error_results
            self.run_command_count = 0
            self.get_bin_path_results = tool_found

        def get_bin_path(self, tool):
            return self.get_bin_path_results

        def run_command(self, command):

            if self.run_command_results is None or self.run_command_error_results is None or len(self.run_command_results) == len(self.run_command_error_results):
                raise RuntimeError("Invalid run command results")


# Generated at 2022-06-11 01:10:51.377225
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import mock
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.basic import AnsibleModule

    def get_bin_path(x):
        return '/usr/bin/%s' % (x)

    def run_command(args):
        assert args[0] == '/usr/bin/locale'
        assert args[1] == '-a'
        return 0, 'C\nen_US.utf8\nPOSIX\nC.UTF-8', ''

    # mock out some functions to do what we want.
    patcher = mock.patch.object(
        AnsibleModule,
        'get_bin_path',
        get_bin_path
    )

    mock_get_bin

# Generated at 2022-06-11 01:10:57.613369
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={}
    )

    assert get_best_parsable_locale(module) == 'C'

    # If a specific locale is not available we should get None
    assert get_best_parsable_locale(module, preferences=['AF', 'C']) == 'C'

# Generated at 2022-06-11 01:11:08.508902
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class AnsibleModule:
        ''' dummy class to represent an AnsibleModule '''

        class params:
            ''' dummy class representing module parameters '''
            pass

        class fail_json:
            ''' dummy class representing fail_json '''
            pass

        @staticmethod
        def get_bin_path(arg):
            ''' dummy method for getting bin path '''
            if arg == "locale":
                return "/usr/bin/locale"
            return None

        @staticmethod
        def run_command(arg):
            ''' dummy method for running commands '''
            raise Exception("Should not call run_command")

    class AnsibleModuleNoLocale:
        ''' dummy class to represent an AnsibleModule without locale '''

        class params:
            ''' dummy class representing module parameters '''
            pass


# Generated at 2022-06-11 01:11:31.441267
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    mock = classmethod(lambda cls, **kwargs: Mock(return_value=Mock(
        run_command=lambda cmd, **kwargs: [0, '', ''])))

    from unittest.mock import patch

    class MockModule(object):
        def __init__(self):
            pass

    with patch.multiple(MockModule, get_bin_path=mock, run_command=mock):
        # Normal case
        m = MockModule()
        best_locale = get_best_parsable_locale(m)
        assert best_locale == 'C'

        # Preferred Locale case
        m = MockModule()

# Generated at 2022-06-11 01:11:37.756732
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    class fake_module(object):
        @staticmethod
        def run_command(*args, **kwargs):
            import subprocess
            return subprocess.call(list(args), **kwargs)

    assert get_best_parsable_locale(fake_module()) == 'C'

    del AnsibleModule
    del fake_module

# Generated at 2022-06-11 01:11:46.941331
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    file_path = os.path.realpath(__file__)
    test_path = os.path.dirname(file_path) + os.sep + '..' + os.sep + '..' + os.sep + 'lib'
    sys.path.append(test_path)

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = object()

    # TODO: mock this test and the module requirements,
    # the test requires the AnsibleModule object
    # which requires a lot of external requirements and has no mock
    # equivalent that we can use.
    # AnsibleModule = collections.namedtuple('AnsibleModule', ['get_bin_path'])

    found = get_best

# Generated at 2022-06-11 01:11:58.634299
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Mock of AnsibleModule
    class MockModule(object):
        class MockRunCommand(object):
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err
            def __call__(self, args, **kwargs):
                return self.rc, self.out, self.err

        def __init__(self, rc, out, err, default_locale='C'):
            self.run_command = self.MockRunCommand(rc, out, err)
            self.default_locale = default_locale

        def get_bin_path(self, binary):
            if binary == 'locale':
                return binary
            else:
                return None

    # Test case for 'en_US.utf8' or 'fr_FR

# Generated at 2022-06-11 01:12:10.166360
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Importing library modules that are needed in this context
    from ansible import context
    from ansible.cli import CLI
    from ansible.utils.display import Display

    # Initialize required Ansible module classes
    display = Display()
    display.verbosity = 4
    context._init_global_context(cli=CLI(args=[]))

    # Unit tests for function get_best_parsable_locale
    print("Test Valid Inputs")

    print("\nTest Invalid Inputs:")
    print("\tNo Inputs has default 'C' returned")
    print("\tBad Inputs has default 'C' returned")

    print("\nTest Expected Outputs:")
    print("\t'C' is returned since this is POSIX standard and always there")

# Generated at 2022-06-11 01:12:16.008165
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) in ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) in ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'POSIX']) in ['C.utf8', 'en_US.utf8', 'POSIX']

# Generated at 2022-06-11 01:12:25.925292
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''
    import ansible.module_utils.six as six
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.network.common.utils import get_module

    # Build the mock module
    module = get_module(argument_spec={})

    # Run generic tests
    failed = False
    try:
        get_best_parsable_locale(module, preferences=None, raise_on_locale=False)
    except:
        failed = True
    assert failed == False

    # Run tests that are expected to fail
    failed = True

# Generated at 2022-06-11 01:12:37.865432
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import shutil
    import tempfile
    import sys

    # Create a temp directory and freeze the current path
    tmpdir = tempfile.mkdtemp()
    old_path = os.getcwd()
    os.chdir(tmpdir)

    # Create a fake locale
    os.mkdir(os.path.join(tmpdir, 'usr', 'bin'))
    shutil.copyfile('/usr/bin/locale', os.path.join(tmpdir, 'usr', 'bin', 'locale'))

    sys.path.append(tmpdir)


# Generated at 2022-06-11 01:12:49.429094
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import env_fallback


# Generated at 2022-06-11 01:12:58.767881
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # unit tests must be py3 compatible
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils.six import unittest
    from ansible.module_utils.six.moves import StringIO

    class TestGetBestParsableLocale(unittest.TestCase):

        def setUp(self):
            class AnsibleModule:
                def __init__(self, **kwargs):
                    self.params = kwargs
                    self.fail_json = self.exit_json = self.debug = lambda *args, **kwargs: None
                    self._ansible_version = __version__
                    self._ansible_no_log = False
                    self._ansible_debug = False
                    self.argument_spec = dict()

# Generated at 2022-06-11 01:13:18.090610
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # arrange
    module = MockAnsibleModule()
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    raise_on_locale = False

    # act
    result = get_best_parsable_locale(module, preferences, raise_on_locale)

    # assert
    assert result == 'C'


# Generated at 2022-06-11 01:13:26.008052
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test the get_best_parsable_locale function
    :return:
    '''
    from ansible.module_utils.facts import ModuleFactCollector
    from ansible.module_utils import basic
    module_path = 'tests/unit/module_utils/facts/test_facts_locale.py'
    mod_collector = ModuleFactCollector(basic.AnsibleModule(argument_spec=dict(), supports_check_mode=True))
    locale_info = mod_collector._get_ansible_local_facts(module_path)
    locale_info['ansible_facts']['ansible_locale'] = get_best_parsable_locale(mod_collector.module)
    assert locale_info['ansible_facts']['ansible_locale'] == 'C'

# Generated at 2022-06-11 01:13:36.831381
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' Test get_best_parsable_locale function '''

    assert get_best_parsable_locale('module') == 'C'

    assert get_best_parsable_locale('module', preferences=['A']) == 'C'
    assert get_best_parsable_locale('module', preferences=['A', 'C']) == 'C'

    assert get_best_parsable_locale('module', preferences=['C.UTF-8', 'C.utf8']) == 'C'
    assert get_best_parsable_locale('module', preferences=['C', 'C.UTF-8', 'C.utf8']) == 'C'

    # This is not a real module but just a string for our testing

# Generated at 2022-06-11 01:13:47.096858
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # pretend locale command outputs C.utf8, en_US.utf8, C, POSIX
    # this test mimics module_utils/basic.py --list and returning a list
    # without newlines
    def run_command_fake(args, check_rc=False):
        status = 0
        stdout = u"C.utf8\nen_US.utf8\nC\nPOSIX"
        stderr = None
        return status, stdout, stderr

    module.run_command = run_command_fake

    # test base case, return en_US.utf8
    preferences = ['en_US.utf8', 'C']

# Generated at 2022-06-11 01:13:56.733926
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.collections import ImmutableDict
    args = {
        'ansible_module_args': {
            'bin_path': '/usr/bin',
            'run_command_args': None,
            'run_command_check_rc': None,
            'supports_check_mode': False,
        },
        'ansible_module_name': '',
        'ansible_version': '1.2.3',
        'ansible_facts': None,
    }
    module = ImmutableDict(args)
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

# Generated at 2022-06-11 01:14:07.881838
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Tests that get_best_parsable_locale returns a valid locale
    """

    import tempfile
    import subprocess

    # Generate a temporary locale file
    fd, path = tempfile.mkstemp()
    os.write(fd, """
    C.UTF-8
    en_US.UTF-8
    """.encode())

    # Call locale -a with the temporary locale file
    cmd = ['locale', '-a', '--debug', '--locale-path=' + path]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = proc.communicate()

    # Create a temporary module to test get_best_parsable_locale

# Generated at 2022-06-11 01:14:16.238376
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        import ansible.module_utils.basic
        import ansible.module_utils.basic
        from ansible.module_utils.six import PY3
        if PY3:
            from unittest.mock import Mock
        else:
            from mock import Mock

        module = Mock(spec=ansible.module_utils.basic.AnsibleModule)
        module.run_command.return_value = (0, '\n'.join(['C', 'en_US.utf8', 'C.utf8']), None)

        # Ensure that we get a parsable locale
        assert get_best_parsable_locale(module) == 'C.utf8'
    except ImportError:
        pass

# Generated at 2022-06-11 01:14:27.502635
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def f1():
        # Test when command 'locale' is not found
        mod = AnsibleModule(argument_spec=dict())
        mod.params = {'preferences': ['C.utf8', 'en_US.utf8', 'POSIX']}
        mod.get_bin_path = lambda x: None
        assert get_best_parsable_locale(mod) == 'C'

    def f2():
        # Test when command 'locale' does not find any locale
        mod = AnsibleModule(argument_spec=dict())
        mod.get_bin_path = lambda x: "/bin/locale"
        mod.run_command = lambda x: (0, '', '')

# Generated at 2022-06-11 01:14:35.347399
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.shell
    import os

    test_module = ansible.module_utils.basic.AnsibleModule(argument_spec={})

    # We copy the C locale in the current directory with different extensions in order to fake
    # a locale command with different locale available on the system
    file_list = ['C.utf8', 'en_US.utf8', 'POSIX']
    for file in file_list:
        with open(file, 'w') as f:
            f.write('\n')

    os.environ['PATH'] = '%s:%s' % (os.getcwd(), os.environ['PATH'])
    # We use the Shell module to execute the command instead of ansible.module_utils.basic.AnsibleModule
   

# Generated at 2022-06-11 01:14:37.227777
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == 'C', "Test for valid locale failed"

# Generated at 2022-06-11 01:14:54.014106
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Unit test for function get_best_parsable_locale
    '''
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-11 01:15:02.597051
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())

    # We know that 'C' is always available, but mock it being not available, and check
    # that we still get 'C' as the locale.
    assert 'C' == get_best_parsable_locale(module, preferences=['en_US', 'C'])

    # We know our test system has a UTF-8 native locale, and test that we get that
    # locale
    assert 'en_US.utf8' == get_best_parsable_locale(module, preferences=['en_US', 'C'])

    # Test that we 'C' locale is returned if locale executable cannot be found.

# Generated at 2022-06-11 01:15:04.633950
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # TODO: How to test this without actually running the command
    # that is being tested?
    pass

# Generated at 2022-06-11 01:15:15.854256
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' Unit test for function get_best_parsable_locale '''

    class AnsibleModule:

        @staticmethod
        def run_command(*args, **kwargs):
            ''' Mock AnsibleModule run command '''
            return(0, ['C', 'C.utf8', 'POSIX', 'en_US.utf8'], "")

        @staticmethod
        def get_bin_path(bin, required=False):
            ''' Mock AnsibleModule get_bin_path '''
            return True

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(AnsibleModule, preferences) == 'C.utf8'

    preferences = ['en_US.utf8', 'C', 'POSIX']
   

# Generated at 2022-06-11 01:15:26.902195
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Test function get_best_parsable_locale

    1. Test with all locales available
    2. Test with locales not available in system
    3. Test with invalid locales available in system
    4. Test with invalid locales unavailable in system
    """
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    import shutil

    # Ensure that remove directory and files will be called
    # when test fails
    remove_dirs = []
    remove_files = []

    def remove_temp_dirs_and_files():
        for d in remove_dirs:
            shutil.rmtree(d)
        for f in remove_files:
            os.remove(f)

    # 1. Test with all locales available

# Generated at 2022-06-11 01:15:33.467054
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_cmd_output = """C
C.utf8
de_DE.utf8
en_US
en_US.utf8
POSIX
POSIX.utf8
"""
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(mod) == 'en_US.utf8'

    mod = AnsibleModule(argument_spec=dict())
    mod.run_command = lambda x: (0, locale_cmd_output, '')
    assert get_best_parsable_locale(mod) == 'POSIX.utf8'

    mod = AnsibleModule(argument_spec=dict())
    mod.run_command = lambda x: (1, None, '')
    assert get_best_parsable

# Generated at 2022-06-11 01:15:43.006701
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class MockModule(AnsibleModule):
        def get_bin_path(self, arg):
            if arg == 'locale':
                return 'locale'
            return None

        def run_command(self, arg):
            # Return a list of locales
            if arg[0] == 'locale' and arg[1] == '-a':
                return [0, 'ar_EG\nar_IL\nar_JO\nar_SY\nde_DE\nen_CA\nen_GB\nen_US\nen_ZA\nC.utf8\nC\nPOSIX', None]

            # Return a list of locales

# Generated at 2022-06-11 01:15:53.440299
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    _mod = AnsibleModule({})
    _mod.run_command = run_command

    # Testing that the correct locale is returned when first preference is returned
    assert get_best_parsable_locale(_mod) == 'en_US.utf8'

    # Testing that the default locale is returned when all preferences are not available
    assert get_best_parsable_locale(_mod, ['eo', 'C.utf8']) == 'C'

    # Testing that this function with raise an error when requested

# Generated at 2022-06-11 01:16:01.719603
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Initialize Ansible module
    from ansible.module_utils.basic import AnsibleModule
    amodule = AnsibleModule({})

    # Test when no preferences are provided
    result = get_best_parsable_locale(amodule)
    assert result == 'C'

    # Test when preferences are provided and one is available
    result = get_best_parsable_locale(amodule, preferences=['POSIX'])
    assert result == 'POSIX'

    # Test when no preferences are available
    result = get_best_parsable_locale(amodule, preferences=['klingon', 'posix'])
    assert result == 'C'

# Generated at 2022-06-11 01:16:10.746335
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def mock_run_command(*args, **kwargs):
        if args[0] == ['locale', '-a']:
            return (0, 'C\nC.utf8\nen_US.utf8\nen_US.UTF-8\nen_US\nen_US.utf8\nen_US.UTF-8\nPOSIX\n', '')
        else:
            raise ValueError('Unexpected args: %s' % args)

    def mock_get_bin_path(*args, **kwargs):
        return '/usr/bin/locale'

    test_module = AnsibleModule(argument_spec={})
    test_module.run_command = mock_run_command
    test_module.get_bin_path = mock_get_bin_

# Generated at 2022-06-11 01:16:35.321568
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    import sys

    module = AnsibleModule(argument_spec={})

    # For this test, we need a locale that we can count on being
    # available on the system.  I have chosen en_US.utf8.
    # If this locale does not exist, then the test will fail
    # with an error.  This is not a False test result.

    # Generate a random locale file with en_US.utf8 set in the
    # LC_ALL variable. This creates a temporary locale file
    # at /tmp/testlocale
    with tempfile.NamedTemporaryFile(delete=False) as f:
        print('LC_ALL="en_US.utf8"', file=f)
        testlocale = f.name



# Generated at 2022-06-11 01:16:40.023320
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Unit test for function get_best_parsable_locale
    :return:
    '''
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    best_parsable_locale = get_best_parsable_locale(module)
    assert best_parsable_locale == 'C'


# Generated at 2022-06-11 01:16:49.173226
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    module.run_command = lambda args: (0, 'C\nC.utf8\nen_US.utf8\nPOSIX\n', '')
    locale = get_best_parsable_locale(module)
    assert locale == 'C.utf8'

    module = AnsibleModule(argument_spec={})
    module.run_command = lambda args: (0, '', '')
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 01:16:58.501270
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import sys

    test_module = basic.AnsibleModule(
        argument_spec=dict(),
    )

    test_module.run_command = mock_run_command
    sys.modules['ansible.module_utils.basic'] = basic

    assert 'en_US.utf8' == get_best_parsable_locale(test_module, preferences=['en_US.utf8',])
    assert 'en_US.utf8' == get_best_parsable_locale(test_module, preferences=['en_US.utf8','bogus_locale'])
    assert 'C' == get_best_parsable_locale(test_module, preferences=['bogus_locale',])
    assert 'C' == get_best_pars

# Generated at 2022-06-11 01:17:07.659687
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule:
        def __init__(self):
            self.run_command_return_value_from_locale_a = -1, "err", "err"
            self.run_command_return_value_from_locale = -1, "err", "err"
            self.fail_json_called = False
            self.fail_json_reason = None
            self.warn_called = False
            self.warn_reason = None

        def get_bin_path(self, locale):
            if self.run_command_return_value_from_locale_a == -1:
                return None
            else:
                return "/usr/bin/locale"

        def fail_json(self, reason):
            self.fail_json_called = True
            self.fail_json_reason = reason

       

# Generated at 2022-06-11 01:17:10.255730
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test the fallback to 'C'
    import ansible.module_utils.alive_wrapper as alive_wrapper
    module = alive_wrapper

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:17:20.585594
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # locale -a output for the locales available in the test system
    locale_output = """C
en_US.utf8
en_US.UTF-8
en_US.US-ASCII
POSIX"""

    # tests for function get_best_parsable_locale
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import get_module_name

    module = AnsibleModule(
        argument_spec=dict()
    )

    # test get_module_name()
    assert get_module_name(module) == 'test'

    # test get_best_parsable_locale()
    # locale command success case
    module.run_command = lambda args: (0, locale_output, None)

# Generated at 2022-06-11 01:17:30.094897
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import pytest
    from ansible.module_utils.facts.system.locale import get_best_parsable_locale

    # Mocking the locale.exe file, to avoid using the actual path of the file
    def mock_get_bin_path(self, arg):
        return "C:\\Python27\\Scripts\\locale.exe"
    AnsibleModule.get_bin_path = mock_get_bin_path

    # Mocking the actual response of the locale command
    def mock_run_command(self, arg):
        if arg[1] == '-a':
            return 0, "C\nen_US.utf8\nPOSIX\n", ''

# Generated at 2022-06-11 01:17:33.709821
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.redhat_subscription.redhat_subscription import RedHatSubscriptionModule

    module = RedHatSubscriptionModule()
    assert module is not None

    pref = ['C.utf8', 'POSIX']
    found = get_best_parsable_locale(module, pref)
    assert found in pref

# Generated at 2022-06-11 01:17:40.137018
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, ['POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(None, ['C.utf8', 'POSIX']) == 'C.utf8'
    assert get_best_parsable_locale(None, ['C.utf8', 'POSIX', 'C']) == 'C.utf8'

# Generated at 2022-06-11 01:18:01.704415
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    # Build fake ansible module
    fake_ans_mod = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    # Test with a few different preferred locales
    preferences = ['fr_FR.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(fake_ans_mod, preferences=preferences) == 'C'
    preferences.pop(0)
    assert get_best_parsable_locale(fake_ans_mod, preferences=preferences) == 'C'
    preferences.pop(0)
    assert get_best_parsable_locale(fake_ans_mod, preferences=preferences) == 'POSIX'

    # Test with wrong locale
   

# Generated at 2022-06-11 01:18:12.913208
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile
    import textwrap
    import sys

    # Create our test locale file
    test_dir = tempfile.TemporaryDirectory()
    test_file = "/usr/lib/locale/locale-archive"


# Generated at 2022-06-11 01:18:22.813815
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.common.process import get_bin_path

    mod_path = get_bin_path('perl')
    mod_name = 'unittest_module'
    mod_args = {'version': '1.0.0'}
    tmp_path = None

# Generated at 2022-06-11 01:18:28.812420
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test to make sure the best locale is being found as expected.
    '''
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec={})
    assert module.get_bin_path("locale") != None

    locale = get_best_parsable_locale(module, preferences=None)
    assert locale == 'C'

    locale = get_best_parsable_locale(module, preferences=['C.GBK'])
    assert locale == 'C'


# Generated at 2022-06-11 01:18:36.852303
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys

    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    import ansible.module_utils.basic

    class FakeModule(ansible.module_utils.basic.AnsibleModule):
        def __init__(self, result=None, **kwargs):
            self.result = result
            self.called_commands = []
            super(FakeModule, self).__init__(**kwargs)

        def get_bin_path(self, name):
            return name

        def run_command(self, command):
            self.called_commands.append(command)
            if self.result:
                return self.result
