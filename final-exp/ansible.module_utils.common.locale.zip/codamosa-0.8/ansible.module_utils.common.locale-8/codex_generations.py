

# Generated at 2022-06-11 01:08:50.671912
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    # Test that the POSIX locale is returned (even though it's not preferred)
    # when no locales are available
    am = AnsibleModule(argument_spec=dict())
    am.run_command = lambda x: (1, None, None)
    assert get_best_parsable_locale(am, preferences=['en_US.utf8', 'fr_FR.utf8']) == 'C'

    # Test that the last preferred locale is returned when all the preferred
    # locales are available
    am.run_command = lambda x: (0, 'en_US.utf8\nfr_FR.utf8\n', None)

# Generated at 2022-06-11 01:09:00.787486
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import platform

    arch = None
    # get architecture
    if platform.system() == "SunOS":
        arch = "sparc"
    elif platform.system() == "Linux":
        try:
            arch = platform.architecture()[1]
        except IndexError:
            arch = None

    # unit tests with expected output

# Generated at 2022-06-11 01:09:08.665809
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    # If locale isn't found, we should get a RuntimeWarning
    # and the default 'C' should be returned.
    mock_module = AnsibleModule(argument_spec={})
    mock_module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(mock_module) == 'C'

    # If locale returns anything other than 0, we should get
    # a RuntimeWarning and the default 'C' should be returned.
    mock_module = AnsibleModule(argument_spec={})
    mock_module.run_command = lambda x: (1, b'', b'')
   

# Generated at 2022-06-11 01:09:11.537289
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert "C" == get_best_parsable_locale(None)
    assert "C" == get_best_parsable_locale(None, ['en_US'])



# Generated at 2022-06-11 01:09:21.521621
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    from mock import call, patch

    module = basic.AnsibleModule({}, {})

    # The function should return the first available local from preferences
    module.run_command = lambda x: (0, 'C.UTF-8\nen_US.UTF-8', '')
    assert 'en_US.UTF-8' == get_best_parsable_locale(module)

    # In case of a failure, the function should return 'C'
    module.run_command = lambda x: (1, '', '')
    assert 'C' == get_best_parsable_locale(module)

    # If 'locale' is not found on the system the function should return 'C'

# Generated at 2022-06-11 01:09:31.294813
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale
    import tempfile

    module = AnsibleModule(argument_spec={'test': {'type': 'bool',
                                                   'required': True}})

    # This function has 2 side effects
    # 1) it will add a note to the module object
    # 2) it can raise RuntimeWarning or RuntimeError if things go horribly wrong

    with tempfile.NamedTemporaryFile() as locale_cmd:
        locale_cmd.write(
            '#!/bin/sh\n'
            'echo "C.UTF-8"\n'
        )
        locale_cmd.flush()

        module.get_bin_path = lambda x, opt_dirs=[] : locale

# Generated at 2022-06-11 01:09:41.961280
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class FakeModule(object):
        def __init__(self, run_rc, run_out, run_err, bin_path):
            self.run_rc = run_rc
            self.run_out = run_out
            self.run_err = run_err
            self.bin_path = bin_path

        def get_bin_path(self, tool):
            return self.bin_path

        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            return (self.run_rc, self.run_out, self.run_err)

    # Test 1: 'locale' doesn't exist (no exception)
    test_module = FakeModule(None, [], [], None)
    locale = get_best_

# Generated at 2022-06-11 01:09:51.956262
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test the get_best_parsable_locale function
    '''
    import os
    import sys
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    # small hack to get a temp dir to write a temp file to
    tmp = tempfile.gettempdir()

    # set up a locale testing file, this should get overridden with C locale
    locale_test_file = os.path.join(tmp, 'ansible_locale_test')
    with open(locale_test_file, 'w') as f:
        f.write("This is a test file")

    # set up a test module

# Generated at 2022-06-11 01:10:01.361392
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    mocked_module = AnsibleModule(
        argument_spec=dict()
    )

    mocked_module.run_command = lambda args: (0, 'C', '')
    assert get_best_parsable_locale(mocked_module) == 'C'

    mocked_module.run_command = lambda args: (0, 'C\nen_US', '')
    assert get_best_parsable_locale(mocked_module) == 'C'

    mocked_module.run_command = lambda args: (0, 'C\nen_US', '')
    assert get_best_parsable_locale(mocked_module, preferences=['en_US']) == 'en_US'


# Generated at 2022-06-11 01:10:08.600355
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModuleMock():
        def get_bin_path(self, path):
            return path
        def run_command(self, command):
            # simulate behaviour of the run_command function
            # return correct output for C.utf8 and C.utf8
            if command[1] == '-a':
                if command[2] == 'C.utf8':
                    return 0, 'C.utf8', ''
                elif command[2] == 'C':
                    return 0, 'C', ''
                elif command[2] == 'POSIX':
                    return 0, 'POSIX', ''
                elif command[2] == 'en_US.utf8':
                    return 0, 'en_US.utf8', ''
                else:
                    return 0, '', ''

    am = AnsibleModuleMock()


# Generated at 2022-06-11 01:10:28.392311
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Tests for getting best parsable locale
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C']) == 'en_US.utf8'

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['C']) == 'C'

    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 01:10:29.289853
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-11 01:10:39.467775
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os

    import ansible.module_utils.basic as module_utils
    from ansible.module_utils.locale import get_best_parsable_locale
    from ansible.utils.color import stringc
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.compat.tests.mock import patch, MagicMock

    # This is a re-implementation of locale.get_best_parsable_locale with a couple minor tweaks
    # to make testing simpler.  Specifically, we don't do the import_module
    # so we can use MagicMock to create a mock module.

# Generated at 2022-06-11 01:10:46.757716
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    try:
        del sys.modules['ansible.module_utils.basic']
    except KeyError:
        pass
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())
    prefs = ['C', 'en_US.utf8', 'en_US.US-ASCII', ]
    best_locale = get_best_parsable_locale(module, preferences=prefs)
    assert best_locale == 'C'

# Generated at 2022-06-11 01:10:51.694177
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        from ansible.module_utils.basic import AnsibleModule

        # make an AnsibleModule w/o argument spec
        am = AnsibleModule(argument_spec=dict())
        locale = get_best_parsable_locale(am)
        assert locale
        assert type(locale) == str
    except ImportError as e:
        print("ImportError: {0}".format(e.args[0]))

# Generated at 2022-06-11 01:11:03.213877
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # import modules needed to test
    import sys
    import os
    import tempfile
    import importlib.machinery
    import io
    import ansible.modules
    import ansible.module_utils.basic

    # import the function to test
    from ansible.module_utils.common.locales import get_best_parsable_locale

    # get path to ansible modules and then load it
    ansible_module_path = os.path.dirname(ansible.modules.__file__)
    samples_module_path = os.path.join(ansible_module_path, 'samples')
    loader = importlib.machinery.SourceFileLoader('ansible.modules.samples', samples_module_path)
    samples = loader.load_module()

    # An AnsibleModule
    module = samples.An

# Generated at 2022-06-11 01:11:10.796598
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})
    preferences = ['C.ascii', 'C']
    locale = get_best_parsable_locale(module, preferences)
    assert locale == 'C'

    preferences.append('not-a-locale')
    locale = get_best_parsable_locale(module, preferences)
    assert locale == 'C'

    preferences.append('C.utf-8')
    locale = get_best_parsable_locale(module, preferences)
    assert locale == 'C.utf-8'

# Generated at 2022-06-11 01:11:12.693617
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale = get_best_parsable_locale(None)
    assert locale == 'C'

# Generated at 2022-06-11 01:11:22.183041
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import platform
    try:
        from unittest.mock import Mock, patch
    except ImportError:
        from mock import Mock, patch
    try:
        from collections.abc import Mapping
    except ImportError:
        # Python 2/3 compatibility
        Mapping = Mapping

    class AnsibleModule:

        def __init__(self, **kwargs):
            self.params = kwargs.get("params")
            if not isinstance(self.params, Mapping):
                raise Exception("params is not a Mapping")
            self.fail_json = Mock(side_effect=self.fail_json_side_effect)
            self.run_command = Mock(side_effect=self.run_command_side_effect)


# Generated at 2022-06-11 01:11:31.990193
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import pytest
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text
    from ansible.compat.tests.mock import patch, MagicMock

    from ansible.module_utils.common.locale import get_best_parsable_locale

    module = basic.AnsibleModule(
        argument_spec=dict()
    )

    # Mock 'get_bin_path' function to return a valid path

# Generated at 2022-06-11 01:11:57.137319
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import unittest
    import ansible.module_utils.basic
    import ansible.module_utils.facts.system

    class MockModule(object):
        def __init__(self, retval):
            self.retval = retval

        def get_bin_path(self, *args, **kwargs):
            return 'locale'

        def run_command(self, *args, **kwargs):
            return self.retval

    class AnsibleExitJson(Exception):
        def __init__(self, **kwargs):
            self.kwargs = kwargs
            super(AnsibleExitJson, self).__init__(kwargs)

    class AnsibleFailJson(Exception):
        def __init__(self, **kwargs):
            self.kwargs = kwargs


# Generated at 2022-06-11 01:12:03.858327
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest

    class TestAnsibleModuleMock(object):
        def __init__(self, module_name):
            self._name = module_name

        def get_bin_path(self, *args, **kwargs):
            return self._name

        def run_command(self, *args, **kwargs):
            return 0, 'en_US.utf8'
    # end of TestAnsibleModuleMock class

    class TestAnsibleModuleMock_Fail(object):
        def __init__(self, module_name):
            self._name = module_name

        def get_bin_path(self, *args, **kwargs):
            return self._name

        def run_command(self, *args, **kwargs):
            return 0, 'en_US.utf8'
    #

# Generated at 2022-06-11 01:12:15.154517
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeModule:
        def __init__(self):
            self._bin_path = {}  # key is binary name, value is in path or not

        def get_bin_path(self, binary, required=True):
            in_path = self._bin_path.get(binary, True)
            if not in_path:
                if required:
                    raise RuntimeError("Could not find '%s' tool" % binary)

        def run_command(self, cmd, check_rc=False, quiet=False):
            pass

    m = FakeModule()

    # no locale module
    m._bin_path['locale'] = False
    assert get_best_parsable_locale(m) == 'C'

    # all good
    m._bin_path['locale'] = True
    assert get_best_pars

# Generated at 2022-06-11 01:12:15.762223
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-11 01:12:25.801278
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-11 01:12:37.739490
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Basic missing locale information
    test_module = FakeModule(run_command_results=[(1, '', '')])
    assert get_best_parsable_locale(test_module) == 'C'

    # Basic with no preferred information
    test_module = FakeModule(run_command_results=[(0, '1\n2\n', '')])
    assert get_best_parsable_locale(test_module) == 'C'

    # Basic with english locale available
    test_module = FakeModule(run_command_results=[(0, 'en_US.utf8\n1\n2\n', '')])
    assert get_best_parsable_locale(test_module) == 'en_US.utf8'

    # Fastest preferred locale is available
    test_module = FakeModule

# Generated at 2022-06-11 01:12:49.221047
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Since we have no provider, our locale should be 'C'
    assert module.get_best_parsable_locale(module) == 'C'

    # Since we have no provider, our locale should be 'C'
    assert module.get_best_parsable_locale(module, ['C.UTF-8', 'C']) == 'C'

    module._supports_check_mode = True
    module.supports_check_mode = lambda: True

    locale_mock = {'rc': 0, 'stdout': 'C\nC.UTF-8\n', 'stderr': ''}
    module.run_command = lambda cmd, tmp, executable: locale_mock

    # Since

# Generated at 2022-06-11 01:12:58.633467
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # EMPTY: should return 'C' as default
    module = AnsibleModule(
        argument_spec={}
    )
    assert get_best_parsable_locale(module) == 'C'

    # BEST_ON_LIST: make sure the first known good on the list works
    module = AnsibleModule(
        argument_spec={}
    )
    assert get_best_parsable_locale(module, preferences=['C', 'en_US.utf8']) == 'C'

    # BEST_ON_LIST_FAIL: with porter locale specified should not return None
    module = AnsibleModule(
        argument_spec={}
    )

# Generated at 2022-06-11 01:13:09.831897
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Run unit test for get_best_parsable_locale function
    '''
    # import necessary packages
    from ansible.module_utils.basic import AnsibleModule

    class myModule():
        def __init__(self):
            self.bin_path = None

        def get_bin_path(self, executable):
            return self.bin_path

        def run_command(self, command):
            if not self.bin_path:
                return (1, None, None)
            elif command[0] == 'locale':
                if self.bin_path == 'locale':
                    return (0, 'C\nC.UTF-8\nPOSIX', None)
                elif self.bin_path == 'locale_error':
                    return (1, None, 'error')

# Generated at 2022-06-11 01:13:20.277330
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    # This function runs a command and it is not guaranteed to work in a unit test.
    # We bypass this command by mocking get_bin_path and returning a simple string.
    module.get_bin_path = lambda x: "test"
    module.run_command = lambda x: (0, ('de_DE.utf8', 'C.utf8', 'C', 'POSIX', 'en_US.utf8'), '')
    assert module._get_best_parsable_locale(preferences=['de_DE.utf8', 'C.utf8', 'C', 'POSIX', 'en_US.utf8']) == 'de_DE.utf8'

# Generated at 2022-06-11 01:13:44.817555
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # 1st Test: Given that no CLI tool is available and no preferred locales are specified, then the function should return 'C'
    class AnsibleModuleStub:
        def __init__(self):
            self.bin_path = None

        def get_bin_path(self, bin):
            return self.bin_path

        def run_command(self, args):
            return 1, "", "Unable to get locale information, rc=1: No output from locale, rc=1"

    am = AnsibleModuleStub()
    assert get_best_parsable_locale(am, None, True) == 'C'

    # 2nd Test: Given that no CLI tool is available and no preferred locales are specified, then the function should return 'C'

# Generated at 2022-06-11 01:13:51.182310
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['ja_JP.utf8']) == 'C'
    assert get_best_parsable_locale(None, ['C']) == 'C'
    assert get_best_parsable_locale(None, ['ja_JP.utf8', 'C']) == 'C'
    assert get_best_parsable_locale(None, ['ja_JP.utf8', 'C.UTF-8']) == 'C.UTF-8'

    # TODO: Mock a module object and test the other code path

# Generated at 2022-06-11 01:14:02.291945
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import pytest

    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.common.sys_info import get_bin_path

    class FakeModule(object):
        @classmethod
        def get_bin_path(cls, arg):
            return get_bin_path(arg)

        @staticmethod
        def run_command(cmd):
            return 0, '', ''

    mod = FakeModule()

    first_locale = get_best_parsable_locale(mod, preferences=['en_US.utf8', 'en_US.utf', 'en_US.utf7'])
    assert first_locale == 'en_US.utf8'


# Generated at 2022-06-11 01:14:08.927954
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Test for no preferences specified
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    # Test for preferences specified
    module = AnsibleModule(argument_spec={})
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(module, preferences) in preferences



# Generated at 2022-06-11 01:14:18.874257
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

    assert get_best_parsable_locale(None, ['en_US.utf8'], False) == 'en_US.utf8'
    assert get_best_parsable_locale(None, ['en_US.utf8'], True) == 'en_US.utf8'

    assert get_best_parsable_locale(None, ['en_GB.utf8', 'en_US.utf8'], False) == 'en_GB.utf8'
    assert get_best_parsable_locale(None, ['en_GB.utf8', 'en_US.utf8'], True) == 'en_GB.utf8'


# Generated at 2022-06-11 01:14:27.125036
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    preferences = ['fr_FR.utf8', 'C.utf8', 'posix', 'C']
    module = AnsibleModule(argument_spec={})
    assert module.get_bin_path("locale") is not None
    found = get_best_parsable_locale(module, preferences)
    # one of the locale available in test/integration/targets/default/output/locale_a
    assert found in ['fr_FR.utf8', 'C.utf8', 'posix', 'C',]

# Generated at 2022-06-11 01:14:35.156626
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # We have 2 tests, one where we pass a specific preference,
    # the other where we let the function choose the preference
    # for us (default)
    for test_preference in [None, 'POSIX']:
        module = AnsibleModule({})

        # We give it a single locale, and that locale is our preference
        locale = get_best_parsable_locale(module, test_preference)
        assert locale == test_preference

        # We give it a single locale, but that locale is NOT our preference
        for test_value in ['POSIX', 'C']:
            if test_value != test_preference:
                break

        locale = get_best_parsable_locale(module, test_preference)
        assert locale == test_

# Generated at 2022-06-11 01:14:41.418943
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
    )

    result_matched = get_best_parsable_locale(module)
    result_not_matched = get_best_parsable_locale(module, ["en_US.utf8", "en_US.us"])
    expected = "en_US.utf8"

    assert result_matched == expected
    assert result_not_matched == "C"

# Generated at 2022-06-11 01:14:42.819180
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-11 01:14:53.236466
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock a module class
    class MockModuleClass:
        def __init__(self):
            self.params = {}

        def fail_json(self, **kwargs):
            raise Exception('Fail')

        def get_bin_path(self, bin):
            if bin == "locale":
                return bin

        def run_command(self, cmd):
            return 0, 'C\nen_US.utf8\nPOSIX\n', None

    class MockBadModuleClass:
        def __init__(self):
            self.params = {}
            self.warnings = []

        def fail_json(self, **kwargs):
            raise Exception('Fail')

        def warn(self, msg):
            self.warnings.append(msg)


# Generated at 2022-06-11 01:15:17.793023
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import subprocess
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.locale_gen import get_best_parsable_locale

    test_module = AnsibleModule(argument_spec=dict(), supports_check_mode=False)

    assert get_best_parsable_locale(test_module, ['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(test_module, ['POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(test_module, ['POSIX', 'C', 'C.utf8']) == 'C'

# Generated at 2022-06-11 01:15:29.236619
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """ Test for what is considered a match of a preferred locale
        when run_command('locale -a') returns both the bare string
        'en_US' and 'en_US.utf8'
    """
    from ansible.module_utils.basic import AnsibleModule
    import sys

    if sys.version_info < (2, 7):
        print("To run tests on python < 2.7 pip install unittest2")
        exit(0)

    import unittest2 as unittest


# Generated at 2022-06-11 01:15:39.208071
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test 1
    # Type: Positive Test
    # Expected Output: 'C'
    assert get_best_parsable_locale({"run_command": run_command}) == 'C'

    # Test 2
    # Type: Positive Test
    # Expected Output: 'C.utf8'
    run_command.results = [0, 'C\nC.utf8\nen_US.utf-8', '']
    assert get_best_parsable_locale({"run_command": run_command}) == 'C.utf8'

    # Test 3
    # Type: Positive Test
    # Expected Output: 'en_US.utf8'
    run_command.results = [0, 'C\nC.utf8\nen_US.utf-8', '']
    assert get_best_pars

# Generated at 2022-06-11 01:15:47.410939
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        # No need to return failure if ansible module_utils is not available for import
        return

    module = AnsibleModule({})
    preference_locales = ['is_IS.utf8', 'de_DE.utf8', 'C.utf8', 'en_IN.utf8', 'C', 'POSIX']
    actual_locale = get_best_parsable_locale(module, preference_locales, raise_on_locale=True)
    assert actual_locale == 'de_DE.utf8', "Actual locale {0} doesn't match with expected locale {1}".format(actual_locale, 'de_DE.utf8')



# Generated at 2022-06-11 01:15:54.702861
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Locale on test machine is 'en_US.UTF-8'
    assert module.get_best_parsable_locale([]) == 'C'
    assert module.get_best_parsable_locale(['en_US.UTF-8']) == 'C'
    assert module.get_best_parsable_locale(['en_US.UTF-8', 'POSIX']) == 'POSIX'

# Generated at 2022-06-11 01:16:04.138911
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Testing of the get_best_parsable_locale function.
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock
    module = AnsibleModule()

    # when locale is not found, default locale should be returned
    module.get_bin_path = MagicMock(return_value=None)
    assert get_best_parsable_locale(module) == 'C'

    module.get_bin_path = MagicMock(return_value='/usr/bin/locale')

    # when user supplies a locale, that should be returned
    preferences = ['en_US.utf8']

# Generated at 2022-06-11 01:16:13.999701
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test for function get_best_parsable_locale
    '''

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale


# Generated at 2022-06-11 01:16:23.624279
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Import module
    module = AnsibleModule()

    # Unit test get_best_parsable_locale with empty options
    best_locale = get_best_parsable_locale(module)
    assert best_locale == 'C'

    # Unit test get_best_parsable_locale with preferences
    best_locale = get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'])
    assert best_locale == 'C'

    # Unit test get_best_parsable_locale with raise_on_locale

# Generated at 2022-06-11 01:16:34.188212
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    ansible.module_utils.basic._ANSIBLE_ARGS = None

    # setup
    import sys
    import os
    import errno
    import tempfile
    import shutil
    import subprocess

    global_locale_name = None
    global_locale_rc = None
    global_locale_executable = None

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )


    # This is a hack for testability; if the locale utility is provided as a python
    # function, use it to verify out unit tests instead of calling the system's
    # locale utility. This function should take a string list of arguments and an
    # optional function that will be called to return the stdin

# Generated at 2022-06-11 01:16:43.495736
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class Module:
        def __init__(self, available, preferences):
            self.fail_json = False
            self.available = available
            self.preferences = preferences

        def get_bin_path(self, name):
            if name == "locale":
                return "/usr/bin/locale"
            else:
                return None

        def run_command(self, args):
            if args == ["/usr/bin/locale", "-a"]:
                return (0, "\n".join(self.available), "")
            else:
                return (1, "", "Error")

    # if we set preference to None, it should use the defaults

# Generated at 2022-06-11 01:17:07.130830
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    assert module.get_best_parsable_locale() == 'C'

    assert module.get_best_parsable_locale(preferences=['C']) == 'C'
    assert module.get_best_parsable_locale(preferences=['C.utf8']) == 'C'
    assert module.get_best_parsable_locale(preferences=['POSIX']) == 'C'
    assert module.get_best_parsable_locale(preferences=['en_US.utf8']) == 'C'
    assert module.get_best_parsable_locale(preferences=['en_US']) == 'C'

# Generated at 2022-06-11 01:17:15.014375
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    # Object initialization
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    # Test for 'C' locale
    module.run_command = lambda command: (0, 'C', '')
    result = get_best_parsable_locale(module, preferences, raise_on_locale=False)
    assert result == 'C'

    # Test for 'C.utf8' locale
    module.run_command = lambda command: (0, 'C.utf8', '')

# Generated at 2022-06-11 01:17:25.757281
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import tempfile

    tmpdir = tempfile.mkdtemp()
    locale_out_file = os.path.join(tmpdir, 'locale_out')
    locale_err_file = os.path.join(tmpdir, 'locale_err')

    # We test the function in 2 scenarios:
    # - the locale command is not found
    # - the locale command returns empty output (no available locales)
    # - the locale command returns output
    # We have 3 types of output:
    # - No preferred locale is available
    # - 1 preferred locale is available
    # - More than 1 preferred locale is available

    # locale command does not exist
    locale_out = """
You need to install a locale for the test to pass
"""
    locale_err = ''


# Generated at 2022-06-11 01:17:34.025166
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Unit test function that validates the best available locale is returned as expected.
    '''

    import sys

    if sys.version_info[0] == 3:
        # Under Python 3.X the installed mock lib is 2.0.0
        from unittest import mock
    else:
        import mock

    from ansible.module_utils.basic import AnsibleModule
    fake_module = AnsibleModule({})

    with mock.patch("ansible.module_utils.basic.AnsibleModule") as mock_module:
        mock_module.get_bin_path.return_value = "/usr/bin/locale"
        mock_module.run_command.return_value = (0, '', '')

        # Empty list is returned

# Generated at 2022-06-11 01:17:36.470346
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    assert(get_best_parsable_locale(AnsibleModule({})) == 'C')

# Generated at 2022-06-11 01:17:47.385384
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        import ansible.module_utils.basic as test_mod
    except ImportError:
        # We don't care about the real module's imports
        class MockModule(object):
            def __init__(self, **kwargs):
                self.params = kwargs

            def fail_json(self, **kwargs):
                raise ValueError(kwargs)
        test_mod = MockModule()

    assert get_best_parsable_locale(test_mod, raise_on_locale=True) == 'C'

    from ansible.module_utils import basic
    orig_get_bin_path = basic.get_bin_path

# Generated at 2022-06-11 01:17:56.895717
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.system.distribution import DistributionFactModule

    module = DistributionFactModule()
    prefs = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    try:
        get_best_parsable_locale(module,prefs)
    except Exception as e:
        assert "Could not find 'locale' tool" in str(e)
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8', None)
    assert get_best_parsable_locale(module,prefs) == 'C'

# Generated at 2022-06-11 01:18:08.046070
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    # Test preferences
    preferences = ['en_US.utf8', 'C.utf8']
    # Test locale -a
    locale_a = ['C.utf8', 'de_DE.utf8', 'C']
    # Test locale
    locale = 'C.UTF-8'

    # Test with preferences and locale -a
    best_locale = get_best_parsable_locale(ansible.module_utils.basic, preferences, locale_a)
    assert best_locale == 'en_US.utf8'

    # Test with preferences only
    best_locale = get_best_parsable_locale(ansible.module_utils.basic, preferences)
    assert best_locale == 'en_US.utf8'

    # Test with locale only
   

# Generated at 2022-06-11 01:18:19.217447
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import ansible.module_utils.basic

    if sys.version_info[0] > 2:
        import builtins
    else:
        import __builtin__ as builtins

    class FakeAnsibleModule(object):

        def __init__(self, *args, **kwargs):
            self.result = {}

        def get_bin_path(self, bin_name, opt_dirs=[]):
            if bin_name == 'locale':
                return '/usr/bin/locale'
            else:
                return None

        def fail_json(self, **kwargs):
            return kwargs


# Generated at 2022-06-11 01:18:27.630537
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # mock the list of available locales for testing
    available_locales = ['en_US.utf8', 'en_US.utf8', 'de_DE.utf8']

    # mock AnsibleModule as required by the function
    class AnsibleModule(object):
        class RunCommandResult(object):
            def __init__(self, rc, stdout, stderr):
                self.rc = rc
                self.stdout = stdout
                self.stderr = stderr

        def get_bin_path(self, path):
            return 'locale'

        def run_command(self, args):
            if args[0] == 'locale' and args[1] == '-a':
                return RunCommandResult(0, '\n'.join(available_locales), None)