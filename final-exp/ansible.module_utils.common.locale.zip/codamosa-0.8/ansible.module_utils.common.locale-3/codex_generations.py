

# Generated at 2022-06-11 01:08:46.167442
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock an AnsibleModule for testing
    module = AnsibleModule(argument_spec={})
    test_available = ['C.utf8', 'en_US.utf8', 'POSIX']

    # Test case 1: No preferences sent
    assert module.get_best_parsable_locale() == 'C.utf8'

    # Test case 2: Preferences sent, none match
    assert module.get_best_parsable_locale(preferences=['test']) == 'C'

# Generated at 2022-06-11 01:08:51.930808
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def run_locale_command(command):
        return 0, 'C\nen_US.utf8\nPOSIX\n', ''

    module = AnsibleModule()
    module.run_command = run_locale_command
    module.get_bin_path = lambda x: 'locale'
    best_locale = get_best_parsable_locale(module)

    assert best_locale == 'C.utf8'


# Generated at 2022-06-11 01:08:58.344455
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils import common_environment
    import ansible.constants as C

    # Define the test play
    play_context = PlayContext()
    play_context.network_os = 'default'
    connection = 'local'
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.remote_addr = '127.0.0.1'
    play_context.remote_user = 'bob'
    play_context.port = 22
    play_context.verbosity = 0
    play_context.check_mode = False
    play_context.no_log

# Generated at 2022-06-11 01:09:06.315178
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import os

    am = basic.AnsibleModule(argument_spec=dict())
    # set up for failure
    os.environ = {'LC_ALL': 'anything'}
    os.environ['LANGUAGE'] = 'en_US.utf8'
    os.environ['LANG'] = 'C.UTF-8'
    locale = am.get_bin_path('locale')
    assert locale

    # test the first two special cases in the function
    rc, out, err = am.run_command([locale, '-a'])
    # we expect 'locale' -a to return an error
    assert rc != 0
    assert err.strip()
    assert out.strip()

# Generated at 2022-06-11 01:09:17.174044
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test get_best_parsable_locale function.
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.compat.tests import unittest as compat_unittest

    class get_best_locale_test(compat_unittest.TestCase):
        '''
            Test the get_best_locale_test class.
        '''

        def setUp(self):
            '''
                Set up test.
            '''
            pass

        def tearDown(self):
            '''
                Tear down test.
            '''
            pass


# Generated at 2022-06-11 01:09:24.183883
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # import library here so we don't need to install it for unit tests
    from ansible.module_utils.basic import AnsibleModule

    # make sure we get C locale because it is always available
    module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module) == 'C'

    # make sure locale en_US.utf8 wins over C
    module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C']) == 'en_US.utf8'

    # make sure we get zh_CN.utf8 when prefer it over en_US.utf8
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-11 01:09:32.375616
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import shlex
    from ansible.module_utils.basic import AnsibleModule

    # Init module
    module = AnsibleModule(
        argument_spec=dict(
            _ansible_test_locale_binary=dict(type='path', default='/usr/bin/locale'),
            _ansible_test_locale_cmd=dict(type='raw', default='_ansible_test_locale_binary -a'),
            _ansible_test_locale_prefs=dict(type='list', default=['C.utf8', 'en_US.utf8', 'C', 'POSIX']),
            _ansible_test_locale_raise_on_locale=dict(type='bool', default=True),
        ),
    )

    # Run function get_best_parsable_loc

# Generated at 2022-06-11 01:09:42.773161
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeAnsibleModule:
        # pylint: disable=no-self-use
        def get_bin_path(self, name):
            if name == 'locale':
                return "/usr/bin/locale"
    fake_module = FakeAnsibleModule()

    def my_run_command(cmd, executable=None):
        if cmd[1] == '-a':
            return (0, """C
C.utf8
de_DE.utf8
fr_FR.utf8
""", '')
        else:
            return (0, '', '')
    fake_module.run_command = my_run_command

    assert get_best_parsable_locale(fake_module, preferences=['fr_FR']) \
        == 'fr_FR.utf8'
    assert get_best

# Generated at 2022-06-11 01:09:53.022824
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module_parsable_1 = {
        "language": "",
        "PATH": "",
        "PWD": "",
        "HOME": "",
        "LANG": "en_US.UTF-8",
        "LC_CTYPE": "en_US.UTF-8",
        "SHELL": "/bin/sh",
        "TERM": "xterm-256color",
        "SHLVL": "",
        "OLDPWD": "",
        "_": "/bin/sh"
    }

    preferences_1 = ['en_US.UTF-8', 'C.UTF-8', 'en_GB.UTF-8', 'C']
    preferences_2 = ['en_US.UTF-8', 'C.UTF-8', 'en_GB.UTF-8']

# Generated at 2022-06-11 01:09:58.759409
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Create a dummy module for testing
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec={})

    # Create the list of preferences
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    # Check the output
    assert 'C' == get_best_parsable_locale(module, preferences=preferences, raise_on_locale=False)

# Generated at 2022-06-11 01:10:08.895438
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    module = AnsibleModule(argument_spec={},
                       supports_check_mode=False)

    # First test if handling of error cases is good
    # Test 1
    try:
        get_best_parsable_locale(module, preferences=['de_DE.utf8'], raise_on_locale=True)
        assert False, "Expected an exception"
    except:
        assert True

    # Test 2
    try:
        get_best_parsable_locale(module, preferences=['de_DE.utf8'], raise_on_locale=False)
        assert True
    except:
        assert False, "Did not expect an exception"

    # check values of best locale based on what the running OS has
    # Test

# Generated at 2022-06-11 01:10:20.354447
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    def mock_run_command(self, commands, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        # command is a list where the executable is the first element, so we just ignore this
        if to_native(commands[1]) == 'locale':
            return 0, self._available_locales, ''
        else:
            return 0, '', ''

    def mock_get_bin_path(self, executable):
        if executable == 'locale':
            return executable
        else:
            return ''

    class FakeModule(object):
        _available_locales = 'de_DE.utf8\nen_US.iso88591\nen_US.utf8\nen_US.utf8.1\n'

        def __init__(self):
            self

# Generated at 2022-06-11 01:10:21.732548
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-11 01:10:28.349590
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile
    import subprocess
    import platform
    import os
    import sys

    # Mock up some of the module utility functions
    class FakeModule:
        def __init__(self):
            self.run_command_called = 0
            self.run_command_check_rc = 0
            self.run_command_stdout = ''
            self.run_command_stderr = ''
            self.debug_called = 0
            self.debug_args = ()
            self.fail_json_called = 0
            self.fail_json_args = ()
            self.fail_json_msg = None
            self.warn_called = 0
            self.warn_args = ()
            self.warn_msg = None
            self.exit_args = ()
            self.changed = False
            self.params = {}
           

# Generated at 2022-06-11 01:10:39.026028
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.utils.boolean import boolean
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(type='list'),
            raise_on_locale=dict(type='bool', default=boolean(False))
        )
    )

    # basic test no preferences
    test_result = get_best_parsable_locale(test_module)
    assert test_result == 'C', "Expected 'C' got %s" % test_result

    # test preferences
    test_module.params = dict(
        preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'],
        raise_on_locale=boolean(True)
    )
    test_result = get

# Generated at 2022-06-11 01:10:45.406752
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    if get_best_parsable_locale(AnsibleModule({}), preferences=['en_US.utf8', 'en_US.utf-8'], raise_on_locale=False) == 'en_US.utf8':
        test_result = True
    else:
        test_result = False

    assert test_result

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-11 01:10:53.577289
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from mock import Mock
    from ansible.module_utils.basic import AnsibleModule

    rc = 0
    out = """
C
C.utf8
en_US.utf8
POSIX
"""
    err = ''
    module = AnsibleModule(argument_spec=dict())
    module.run_command = Mock(return_value=(rc, out, err))
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    out = out + 'en_GB.utf8'
    module.run_command = Mock(return_value=(rc, out, err))
    locale = get_best_parsable_locale(module)
    assert locale == 'en_GB.utf8'


# Generated at 2022-06-11 01:11:04.606972
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 01:11:13.339953
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile

    test_module = AnsibleModule(argument_spec=dict())

    # Test non-existent locale command
    with tempfile.TemporaryDirectory() as temp_dir:
        test_module.PATH = temp_dir

        assert test_module.get_bin_path('locale') == None

        # this will raise exception and it will be caught
        assert get_best_parsable_locale(test_module) == 'C'

    # Test empty locale command output
    with tempfile.TemporaryDirectory() as temp_dir:
        test_module.PATH = temp_dir

        test_locale = temp_dir + '/locale'
        open(test_locale, 'w').close()

# Generated at 2022-06-11 01:11:22.867162
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    choices = ['C', 'POSIX']

    module = AnsibleModule(argument_spec={})
    # None -- default behavior of no user choice
    assert get_best_parsable_locale(module, None) in choices
    # Default choices
    assert get_best_parsable_locale(module, ['C', 'POSIX']) in choices
    # User choice
    assert get_best_parsable_locale(module, ['C', 'POSIX', 'foo_bar']) == 'C'
    # no choices
    assert get_best_parsable_locale(module, []) == 'C'

    from ansible.module_utils.common._collections_compat import MutableMapping
    # None -- default behavior of no user choice


# Generated at 2022-06-11 01:11:34.420499
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.six import PY3
    import mock
    module = mock.MagicMock()
    module.get_bin_path.return_value = None
    if PY3:
        module.run_command.return_value = (1, '', '')
    else:
        module.run_command.return_value = (1, '', '', '')

    locale = get_best_parsable_locale(module, raise_on_locale=True)
    assert locale == 'C'


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-11 01:11:42.017683
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import unittest
    import unittest.mock

    # make sure sys.stdout displays ANSI escape codes
    sys.stdout = open(1, 'w')

    class MockLocale(object):
        def __init__(self, rc=0, out=None, err=None):
            self.rc = rc
            self.out = out
            self.err = err

        def __call__(self, module):
            return self.rc, self.out, self.err

    class TestLocale(unittest.TestCase):
        def setUp(self):
            self.o_import = __import__
            self.mock_module = unittest.mock.MagicMock()

            # mock out get_bin_path which may not be available in pytest
            utils = self

# Generated at 2022-06-11 01:11:49.198017
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible_collections.misc.tests.unit.compat.mock import patch, MagicMock

    module = AnsibleModule(argument_spec=dict())
    mocked_run_command = MagicMock()

    with patch('ansible.module_utils.basic.AnsibleModule.run_command', mocked_run_command):
        mocked_run_command.return_value = (0, "", "")
        best_locale = get_best_parsable_locale(module, raise_on_locale=True)
        assert best_locale == 'C'

        mocked_run_command.return_value = (0, "", "error")

# Generated at 2022-06-11 01:11:54.457474
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    assert 'C' == get_best_parsable_locale(AnsibleModule(), preferences=None)
    assert 'en_US.utf8' == get_best_parsable_locale(AnsibleModule(), preferences=['en_US.utf8', 'C.utf8'])

# Generated at 2022-06-11 01:12:02.836097
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    def _get_locale_data(locale, preferences):
        try:
            mod = FakeModule()
            mod.run_command = run_command.run_command
            found = get_best_parsable_locale(mod, preferences=preferences, raise_on_locale=True)
            res = (True, found)
        except RunTimeError:
            res = (False, None)
        return res

    def _check_locale_data(test, expected, actual):
        assert test == expected[0]
        if test:
            assert actual == expected[1]


# Generated at 2022-06-11 01:12:14.895389
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        return (0, '', '')

    run_command._original_function = AnsibleModule.run_command

    # Patch run_command and get_bin_path to test get_best_parsable_locale
    AnsibleModule.run_command = run_command
    fake_bin_path = None
    AnsibleModule.get_bin_path = lambda self, arg: fake_bin_path
    m = AnsibleModule(argument_spec={})

    # Valid locale output
    fake_bin_path = '/usr/bin/locale'

# Generated at 2022-06-11 01:12:25.166311
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Initialize the module class
    from ansible.modules.system.setup import get_best_parsable_locale
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(AnsibleModule):
        def __init__(self):
            super(FakeModule, self).__init__()

        def get_bin_path(self, program):
            if program == 'locale':
                return program
            return None

        def run_command(self, cmd):
            if cmd[0] == 'locale' and cmd[1] == '-a':
                return (0, '\n'.join(['C', 'c.utf8', 'en_US.utf8']), '')
            return (0, '', '')

    module = FakeModule()

    # Test with no preferences, should return

# Generated at 2022-06-11 01:12:33.388002
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = None
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['en_US.utf8', 'C']) == 'C'
    assert get_best_parsable_locale(module, ['en_US.utf8', 'en_US.ISO-8859-1']) == 'C'
    assert get_best_parsable_locale(module, ['en_US.utf8', 'fr_FR.utf8']) == 'C'

# Generated at 2022-06-11 01:12:41.963058
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, preferences=['en_US']) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US', 'C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US', 'POSIX', 'C']) == 'C'

# Generated at 2022-06-11 01:12:52.209788
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    test_locale = get_best_parsable_locale(test_module)
    assert test_locale == 'C'
    test_locale = get_best_parsable_locale(test_module, preferences=['fr'])
    assert test_locale == 'C'
    # test_locale = get_best_parsable_locale(test_module, preferences=['fr'], raise_on_locale=True)
    # assert test_locale == 'fr'

# Generated at 2022-06-11 01:13:17.472783
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, raise_on_locale=True) == 'C'

    assert get_best_parsable_locale(None, preferences=['A', 'B']) == 'C'
    assert get_best_parsable_locale(None, preferences=['A', 'B'], raise_on_locale=True) == 'C'

    class module(object):
        def get_bin_path(*args, **kwargs):
            return '/usr/bin/locale'

        def run_command(*args, **kwargs):
            return (0, 'C.utf8\nen_US.utf8', '')


# Generated at 2022-06-11 01:13:25.671659
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test get_best_parsable_locale with no locale
    assert get_best_parsable_locale(None) == 'C'

    # Test get_best_parsable_locale with valid locales
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(None, preferences) in preferences

    # Test get_best_parsable_locale with invalid locale
    preferences = ['invalid_locale']
    assert get_best_parsable_locale(None, preferences) == 'C'

    # Test get_best_parsable_locale with a RuntimeError
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_

# Generated at 2022-06-11 01:13:36.619024
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class TestModule:
        def __init__(self):
            self.params = dict()
            self.exit_args = dict()

        def fail_json(self, *args, **kwargs):
            self.exit_args = kwargs
            # Simulate AnsibleModule.exit_json
            raise Exception(self.exit_args['msg'])

        def run_command(self, args):
            if 'locale' in args and '-a' in args:
                if 'test_locale_none' in args:
                    return 0, 'C\nPOSIX', ''
                elif 'test_locale_en_us' in args:
                    return 0, 'C\nen_US.utf8\nPOSIX', ''

# Generated at 2022-06-11 01:13:37.262705
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-11 01:13:43.706155
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import platform

    if platform.system() == 'Darwin':
        # darwin will just return C always
        assert get_best_parsable_locale(AnsibleModule) == 'C'
    else:
        # other platforms might return the first locale, or C
        # but it won't error
        assert get_best_parsable_locale(AnsibleModule) != ''

# Generated at 2022-06-11 01:13:51.327810
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = FakeModule()
    assert get_best_parsable_locale(module, ['C', 'en_US.utf8']) == 'C'
    assert get_best_parsable_locale(module, ['xx_XX.utf8', 'en_US.utf8']) == 'C'
    assert get_best_parsable_locale(module, ['en_US.utf8', 'xx_XX.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, ['en_US.utf8', 'C']) == 'en_US.utf8'

    module = FakeModule(returncode=2)
    assert get_best_parsable_locale(module) == 'C'
    module = FakeModule(output="")

# Generated at 2022-06-11 01:14:02.479067
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test the function get_best_parsable_locale.
    '''

    from ansible.module_utils import basic
    orig_run_command = basic.AnsibleModule.run_command
    basic.AnsibleModule.run_command = lambda self, argv: (0, "C\nen_US.utf8\n", "")

    assert get_best_parsable_locale(None) == "en_US.utf8"
    assert get_best_parsable_locale(None, preferences = ["en-US"]) == "en_US.utf8"
    assert get_best_parsable_locale(None, preferences = ["en-US", "POSIX"]) == "C"

# Generated at 2022-06-11 01:14:11.822067
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand([0, 'C', ''])
    assert get_best_parsable_locale(module) == 'C'

    module.run_command = FakeRunCommand([0, 'C.utf8', ''])
    assert get_best_parsable_locale(module) == 'C.utf8'

    module.run_command = FakeRunCommand([0, 'en_US.utf8', ''])
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    module.run_command = FakeRunCommand([0, 'C\nen_US.utf8', ''])
    assert get_best_parsable_locale(module) == 'C'

    module.run_command = FakeRunCommand

# Generated at 2022-06-11 01:14:23.455338
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule

    rc, stdout, stderr = 0, StringIO(), StringIO()

    module = AnsibleModule(argument_spec=dict())

    # test with no locale
    module.run_command = lambda *args, **kwargs: (rc, stdout.getvalue(), stderr.getvalue())

    best_locale = get_best_parsable_locale(module)
    assert best_locale == 'C'

    # test with getting normal en_US.utf8
    stdout.truncate(0)
    stdout.write("en_US.utf8")

# Generated at 2022-06-11 01:14:33.033290
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2, PY3
    from ansible.module_utils import six
    import base64
    import sys

    # Unit test for function `get_best_parsable_locale`

    # Returns the best possible locale for parsing output in English
    # useful for scraping output with i18n tools. When this raises an exception
    # and the caller wants to continue, it should use the 'C' locale.

    # Return the best preferred locale or 'C' is default locale
    # With POSIX locale, it is ignored and returns 'C'

# Generated at 2022-06-11 01:14:55.798248
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    import platform

    system = platform.system()

    if system == 'Linux':
        out = "C\nen_US.utf8\nen_US.utf8\nen_US.utf8\n"
        prefs = ['C.utf8', 'en_US.utf8']
        m = AnsibleModule(argument_spec={})
        result = get_best_parsable_locale(m, preferences=prefs, raise_on_locale=True)
        assert result == prefs[1]

# Generated at 2022-06-11 01:15:01.299037
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = None

    # Test for normal functionality for a POSIX system
    assert get_best_parsable_locale(module) == 'C'

    # Test for normal functionality for an English system
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.utf8'

    # Test for normal functionality for a German system
    assert get_best_parsable_locale(module, preferences=['de_DE.utf8']) == 'C'

# Generated at 2022-06-11 01:15:07.116525
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_module = None
    test_preferences = ['fr_FR.utf8', 'fr_FR']

    # Test locale preferences
    test_found_locale = get_best_parsable_locale(test_module, preferences=test_preferences)
    assert test_found_locale == "fr_FR.utf8"

    # Test default locale
    test_found_locale = get_best_parsable_locale(test_module)
    assert test_found_locale == "C"

# Generated at 2022-06-11 01:15:09.354041
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_locale = get_best_parsable_locale(None)
    assert test_locale == 'C'

# Generated at 2022-06-11 01:15:16.100097
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, preferences=['foo', 'baz', 'bar']) == 'C'
    assert get_best_parsable_locale(None, preferences=[]) == 'C'
    assert get_best_parsable_locale(None, preferences=None) == 'C'
    assert get_best_parsable_locale(None, preferences=['foo', 'C', 'bar']) == 'C'

# Generated at 2022-06-11 01:15:27.245091
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.text.utils import get_best_parsable_locale
    import platform

    # First, test when locale is not found
    assert get_best_parsable_locale(None) == 'C'

    # Test when we can't find any preferred locales
    assert get_best_parsable_locale(None, ['non_existent_locale']) == 'C'

    # Now, test when locale is found
    class NullModule:
        def __init__(self):
            pass
        def get_bin_path(self, name):
            if name == 'locale':
                return name
            return None

        def run_command(self, cmd, check_rc=True):
            expected_cmd = 'locale -a'

            assert cmd == expected_cmd.split

# Generated at 2022-06-11 01:15:30.895585
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict()
    )
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    found = get_best_parsable_locale(module, preferences)
    assert found in preferences

# Generated at 2022-06-11 01:15:40.907910
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module, ['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module, ['en_US.utf8', 'POSIX']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, ['en_US.utf8', 'C']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, ['POSIX', 'C.utf8']) == 'C'
    assert get_best_parsable_locale(module, ['POSIX', 'C', 'C.utf8']) == 'C'

# Generated at 2022-06-11 01:15:50.731145
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.local import LocalAnsibleModule
    import platform
    test_bin_paths = ['/usr/bin']

    # test_platform(platform, [preferences], found, best_locale)

# Generated at 2022-06-11 01:16:00.788122
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    def mock_run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        if 'locale' not in args:
            return 1, 'Could not detect locale tool'
        return 0, 'C\nen_US.utf8\nC.utf8\nPOSIX'

    from ansible.module_utils.basic import AnsibleModule

    AnsibleModule.run_command = mock_run_command

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    assert get_best_parsable_locale(
        module,
        preferences=['C.utf8', 'C', 'POSIX', 'en_US.utf8']
    ) == 'C.utf8'



# Generated at 2022-06-11 01:16:24.658818
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # we only test the functionality here, not all of the code
    # the code is tested by test_units/test_local_facts
    # this tests the function on itself

    import locale
    import sys

    # note, get_best_parsable_locale calls a function in this module
    # so using a separate module file would break the tests here

    # prefer the current local
    rv = get_best_parsable_locale(None, [locale.getlocale()[0]])

    # expect the current local returned
    if rv != locale.getlocale()[0]:
        raise AssertionError("Unexpected best local: %s, expected: %s" % (rv, locale.getlocale()[0]))

    # prefer a locale that does not exist, expect C
    rv = get_

# Generated at 2022-06-11 01:16:32.528019
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    preferences = ['en_US.utf8', 'en_US', 'C.utf8', 'C']
    prefs = ['C.utf8', 'C']
    test_mod = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(test_mod, preferences) == 'en_US.utf8'
    assert get_best_parsable_locale(test_mod, None) == 'C'
    assert get_best_parsable_locale(test_mod, prefs) == 'C.utf8'

# Generated at 2022-06-11 01:16:41.634215
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test to ensure has_best_parsable_locale works for all platforms
    d, _load_module_terms = _get_module_terms()
    assert d.has_best_parsable_locale()

    # Test to ensure locale without .utf8 works
    d, _load_module_terms = _get_module_terms(
        cmd_out=b"""
            C
            en_US
            POSIX
        """)
    assert d.has_best_parsable_locale()

    # Test to ensure emulator is working
    d, _load_module_terms = _get_module_terms()
    assert d.get_best_parsable_locale() == 'C'

    # Test to ensure emulator is working for non-posix system
    d, _load_module_terms = _get_

# Generated at 2022-06-11 01:16:50.339215
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    # Test with no locale
    assert get_best_parsable_locale(module) == 'C'

    # Test with locale
    module = AnsibleModule(argument_spec=dict())
    module.run_command = lambda x: (0, 'C\nC.UTF-8\nC.utf8\nen_US.utf8', '')
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['C.utf8']) == 'C.utf8'

    # Test with locale but incorrect preferences
   

# Generated at 2022-06-11 01:16:59.695447
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_output = """C
en_US.utf8
POSIX
"""
    preferences = ['C.utf8', 'en_US.utf8', 'C']
    assert 'en_US.utf8' == get_best_parsable_locale(None, preferences, test_output=test_output)
    preferences = ['en_DE', 'en_US.utf8', 'C']
    assert 'C' == get_best_parsable_locale(None, preferences, test_output=test_output)
    preferences = ['POSIX', 'en_US.utf8', 'C']
    assert 'POSIX' == get_best_parsable_locale(None, preferences, test_output=test_output)


if __name__ == '__main__':
    # Test via pytest
    import pytest

# Generated at 2022-06-11 01:17:08.688503
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Check that get_best_parsable_locale returns the expected locale

    :returns: True on success
    '''
    from ansible.module_utils.basic import AnsibleModule

    # expected output is, in order: the first found preferred locale or 'C'

# Generated at 2022-06-11 01:17:18.040741
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(location):
            return "/usr/bin/%s" % location

        def run_command(parameters):
            if not parameters[0].endswith("locale"):
                raise Exception("Should not be here")
            rc = 0
            if parameters[1] == "-a":
                out = "C\nen_US.utf8\nPOSIX\n"
            else:
                out = None
            err = ""

            return (rc, out, err)

    mod = AnsibleModule()

    assert get_best_parsable_locale(mod) == "en_US.utf8", "Wrong"

# Generated at 2022-06-11 01:17:25.884170
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['foo_BAR.UTF-8', 'blah_BLAH.utf-8']) == 'C'
    assert get_best_parsable_locale(None, ['C.UTF-8', 'bar_BAR.utf-8']) == 'C.UTF-8'
    assert get_best_parsable_locale(None, ['foo_foo.utf8', 'C.UTF-8']) == 'C.UTF-8'

# Generated at 2022-06-11 01:17:28.373103
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-11 01:17:34.263167
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    ansible_module = AnsibleModule(
        argument_spec=dict(),
    )

    locale_list = ['en_US.utf8', 'en_US.UTF-8', 'C.utf8', 'C.UTF-8', 'POSIX']
    result = get_best_parsable_locale(ansible_module, None)
    assert result == 'POSIX' or result == 'C' or result == 'C.UTF-8'


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-11 01:18:14.426663
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 01:18:23.825298
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    fake_module = AnsibleModule({})
    fake_module.fail_json = lambda **kwargs: None
    fake_module.run_command = lambda **kwargs: (0, 'fr_FR.utf8\nfr_FR@euro\nfr_FR\nen_US.utf8\nen_US.utf-8\nen_US\nC.utf8\nC.UTF-8\nC\nPOSIX', '')

    # Case 1: we do not provide a list of prefered locales, we expect 'C'
    assert get_best_parsable_locale(fake_module, None) == 'C'
    # Case 2: we do not provide a list of prefered locales, but locale is not installed, we expect 'C'
    fake

# Generated at 2022-06-11 01:18:27.712628
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' Function to test get_best_parsable_locale '''

    import ansible.module_utils.basic

    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    result = get_best_parsable_locale(module)
    assert result == 'C'

# Generated at 2022-06-11 01:18:35.759888
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Returns test cases for get_best_parsable_locale
    '''
    from ansible.module_utils.basic import AnsibleModule
