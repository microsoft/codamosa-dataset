

# Generated at 2022-06-11 01:08:49.690204
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-11 01:08:56.728222
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    basic unit test
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import env_fallback
    from ansible.module_utils.six import PY3
    import os

    # NOTE: everything is in UTF-8 here, not ascii, easier to read and test
    if PY3:
        chcp_o = 'Active code page: 65001'
        locale_o = 'C.UTF-8'
    else:
        chcp_o = 'Producci\xf3n de c\xf3digo activa: 65001'
        locale_o = 'es_ES.UTF-8'

    chcp_out = chcp_o.encode('utf-8')
    locale_out = locale_o.encode

# Generated at 2022-06-11 01:09:04.885545
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' Make sure we get the locale we expect based on what exists on the system '''
    from ansible.modules.system import locale_gen
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule('', '')
    # pretend locale is not there
    module.run_command = lambda x: (256, '', '')
    assert locale_gen.get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX'], False) == 'C'
    # locale is there but POSIX locale is not

# Generated at 2022-06-11 01:09:11.613611
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    changing_locale = True
    try:
        locale.setlocale(locale.LC_ALL, 'C')
    except locale.Error:
        changing_locale = False

    if changing_locale:
        # Test if we have the standard C locale
        # We are using the locales from a Fedora machine
        from ansible.module_utils.basic import AnsibleModule
        assert get_best_parsable_locale(AnsibleModule()) == "C"
        assert get_best_parsable_locale(AnsibleModule(), preferences=['POSIX', 'C']) == "C"
        assert get_best_parsable_locale(AnsibleModule(), preferences=['POSIX', 'C.UTF-8']) == "C.UTF-8"
        assert get_best_parsable_

# Generated at 2022-06-11 01:09:21.585985
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Import required modules
    import sys
    import os
    import sys
    import unittest
    import shutil
    import tempfile

    fake_module = None

    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        # Exit early for this unit test, not all modules are available.
        print("Could not import required modules for testing")
        sys.exit(0)
    try:
        from ansible.module_utils.common.systemd import is_systemd
        from ansible.module_utils.common.systemd import SystemdErrorHandler
    except ImportError:
        # Exit early for this unit test, not all modules are available.
        print("Could not import required modules for testing")
        sys.exit(0)


# Generated at 2022-06-11 01:09:24.739604
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    assert get_best_parsable_locale(AnsibleModule()) == 'C'

# Generated at 2022-06-11 01:09:32.622041
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''
    import ansible.module_utils
    an_module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        bypass_checks=True
    )

    def test_locale(preferred_locales, expected_locale):
        '''
        Internal function to test return of get_best_parsable_locale

        :param preferred_locales: List of preferred locales to be passed to get_best_parsable_locale
        :param expected_locale: expected locale to be returned from get_best_parsable_locale
        '''
        an_module.get_bin_path = lambda x: '/usr/bin/locale' if x == 'locale' else None

# Generated at 2022-06-11 01:09:42.956245
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-11 01:09:53.103810
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    sample_output = '''C 
POSIX 
en_US.utf8'''
    module = Mock()
    module.get_bin_path.return_value = "/usr/bin/locale"
    
    # Test case 1: error case where command returns error (non-zero) status
    module.run_command.return_value = 1, '', 'Error'
    result = get_best_parsable_locale(module, preferences=None)
    assert result == 'C'
    module.run_command.assert_called_with(['/usr/bin/locale', '-a'])
    
    # Test case 2: error case where command does not return any output
    module.run_command.return_value = 0, '', 'Success'

# Generated at 2022-06-11 01:10:01.918638
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    test_module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())
    assert test_module.get_bin_path("locale") is not None
    assert get_best_parsable_locale(test_module) == 'C'
    assert get_best_parsable_locale(test_module, ['C']) == 'C'
    assert get_best_parsable_locale(test_module, ['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(test_module, ['POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(test_module, ['en_US', 'POSIX']) == 'C'
    assert get

# Generated at 2022-06-11 01:10:08.770300
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''Test if the function returns the expected locale.'''
    assert get_best_parsable_locale(None) == 'C', 'Unexpected locale value received'

# Generated at 2022-06-11 01:10:20.214037
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test for exception when locale is not found and no raise_on_locale
    module = None
    preferences = None
    raise_on_locale = False
    found = get_best_parsable_locale(module, preferences, raise_on_locale)
    assert found == 'C'

    # Test for exception when locale is not found and raise_on_locale
    module = None
    preferences = None
    raise_on_locale = True
    found = get_best_parsable_locale(module, preferences, raise_on_locale)
    # This exception needs to be handled
    assert found == 'C'

    # Test for exception when locale is not found and no raise_on_locale
    module = None
    preferences = ['en_US.utf8', 'es_ES.utf8']
   

# Generated at 2022-06-11 01:10:26.477032
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def run_locale_a(module, *args, **kwargs):
        return 0, 'C\nen_US.utf8\n', ''

    module = AnsibleModule(argument_spec=dict())
    module.run_command = run_locale_a

    best = get_best_parsable_locale(module, preferences=['en_US.utf8'])
    assert best == 'en_US.utf8'

    module.run_command = None
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:10:34.072349
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    module = AnsibleModule(argument_spec={})
    try:
        locale = get_best_parsable_locale(module)
        assert locale == 'C'
    except RuntimeWarning as e:
        assert False, "Expected locale to be found, 'locale' tool not available, rc=%s: %s" % (rc, to_native(err))

# Generated at 2022-06-11 01:10:41.860349
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    # test empty available list
    available = []
    found = get_best_parsable_locale(module, preferences=['C.utf8'], available=available)
    assert found is 'C'

    # test empty preference list
    available = ['C.utf8']
    found = get_best_parsable_locale(module, preferences=[], available=available)
    assert found is 'C'

    # test no matches
    available = ['en_US.utf8']
    found = get_best_parsable_locale(module, preferences=['C.utf8'], available=available)
    assert found is 'C'

    # test matches

# Generated at 2022-06-11 01:10:49.730547
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.modules.system.locale import get_best_parsable_locale

    class MockModule(object):

        def get_bin_path(self, program):
            return "/usr/bin/locale"

        def run_command(self, cmd):
            return 0, "C.utf8 \n en_US.utf8 \n C \n POSIX", ""

    mock_module = MockModule()
    assert get_best_parsable_locale(mock_module, preferences=None, raise_on_locale=True) == "C.utf8"

# Generated at 2022-06-11 01:11:00.912501
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # pylint: disable=import-error
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import Mock, patch

    class TestGetBestParsableLocale(unittest.TestCase):
        def setUp(self):
            self.module = Mock()

        def tearDown(self):
            pass

        def test_default_locale_found(self):
            with patch("ansible.module_utils.basic.get_best_parsable_locale.to_native", return_value="mock"):
                self.module.get_bin_path.return_value = "/bin/locale"
                self.module.run_command.return_value = (0, "en_US", "")

# Generated at 2022-06-11 01:11:11.038911
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    # Locale is not available, will return 'C'
    module = AnsibleModule(argument_spec={}, binary_fn={'get_bin_path': lambda x: None})
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    # Locale is available and returns, ordered by preference
    # all locales present, preferred locale first
    module = AnsibleModule(argument_spec={}, binary_fn={'get_bin_path': lambda x: '/usr/bin/locale'})
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nen_US.utf8\nen_US.utf8\n', '')

# Generated at 2022-06-11 01:11:20.790632
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class MockModule(object):
        def __init__(self):
            self.failed = False

        def fail_json(self, **kwargs):
            self.failed = True

        def raise_warning(self, **kwargs):
            self.warning = True

        def get_bin_path(self, *args, **kwargs):
            return 'locale'

        def run_command(self, *args, **kwargs):
            self.args = args
            rc = 0
            out = None
            if args == ('locale', '-a'):
                out = 'C.UTF-8\nen_US.UTF-8\n'
            elif args == ('locale', '-a', '-v'):
                out = 'C.UTF-8\nen_US.UTF-8\n'
            el

# Generated at 2022-06-11 01:11:28.699351
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # Check if best locale is found in preferences
    preferences = ['C.UTF-8', 'C.utf8', 'C', 'POSIX']

    best_locale = get_best_parsable_locale(module, preferences)

    assert best_locale in preferences

    # Check if locale is set to C if exception is raised
    best_locale = get_best_parsable_locale(module, preferences, raise_on_locale=True)

    assert best_locale == 'C'

# Generated at 2022-06-11 01:11:42.431561
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic

    basic._ANSIBLE_ARGS = None
    # the cmd is required for get_bin_path, which we're not testing here, so create a dummy object
    am = AnsibleModule(command_definitions={'shell': {}, 'raw': {}})
    am.params['_ansible_check_mode'] = False
    am.params['_ansible_debug'] = False
    am.params['_ansible_diff'] = False
    am.params['_ansible_verbosity'] = 0
    module = am.load_platform_subclass('posix', 'shell')

    try:
        locale = get_best_parsable_locale(module)
    except Exception:
        locale = 'C'

   

# Generated at 2022-06-11 01:11:45.012406
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

# Generated at 2022-06-11 01:11:56.078848
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    from io import StringIO

    # Return POSIX if locale command does not exist
    locale_output_notfound = StringIO(u"sh: 1: locale: not found\n")
    m = basic.AnsibleModule(
        argument_spec={},
    )
    m._load_params()
    m.run_command = lambda args, check_rc=True: (0, locale_output_notfound.getvalue(), None)
    result = get_best_parsable_locale(m)
    assert result == 'C'

    # Return POSIX if locale command has issues
    locale_output_error = StringIO(u"locale: Cannot set LC_MESSAGES to default locale: No such file or directory")

# Generated at 2022-06-11 01:11:57.672321
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    assert get_best_parsable_locale(AnsibleModule(
    )) == 'C'
    assert get_best_parsable_locale(AnsibleModule(
    ), raise_on_locale=True) == 'C'

# Generated at 2022-06-11 01:12:04.101339
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # mock module
    class MockModule:
        @staticmethod
        def get_bin_path(name, required=False):
            if name == "locale":
                return "/usr/bin/locale"
            return None

        @staticmethod
        def run_command(cmd, environ_update=None, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            out = ['C', 'C.utf8', 'en_US.utf8', 'POSIX']
            if cmd[0] == "/usr/bin/locale" and cmd[1] == "-a":
                return 0, '\n'.join(out) + "\n", None
            else:
                return -1, None, None

    module = MockModule()
    # Test that default behavior works


# Generated at 2022-06-11 01:12:15.388424
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Tests with a list of locales to choose from.
    def t(preferences, locale):
        '''
            :param preferences: A list of preferred locales, in order of preference
            :param locale: The first matched preferred locale or 'C' which is the default
        '''
        class MockLocaleModule(object):
            def __init__(self):
                self.rc = 0
                self.out = None

            def get_bin_path(self, executable):
                return '/bin/' + executable

            def run_command(self, cmd):
                if cmd == ['/bin/locale', '-a']:
                    if self.rc != 0:
                        raise RuntimeWarning("Unable to get locale information, rc=%s: %s" % (self.rc, to_native(self.out)))

# Generated at 2022-06-11 01:12:18.193153
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:12:27.015590
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    import subprocess
    import tempfile

    class MockModule():
        def __init__(self):
            self.params = {}
            self.fail_json = False
            self.check_mode = False
            self.verbosity = 0
            self.no_log = []
            self.immediate_check_failed = False
            self.log = []
            self.warnings = []
            self.deprecations = []
            self.exit_args = {}
            self.fail_json_bytes_warnings = False
            self.invalid_arguments_exit_permission = True


# Generated at 2022-06-11 01:12:31.977466
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    # Create a temporary module
    am = AnsibleModule(argument_spec=dict())
    # Test the function
    locale = get_best_parsable_locale(am)
    assert locale == 'C'

# Generated at 2022-06-11 01:12:41.398250
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec={})

    def mock_get_bin_path(binary):
        return binary if binary == "locale" else None

    module.get_bin_path = mock_get_bin_path

    def mock_run_command(cmd):
        if cmd[0] == 'locale' and cmd[1] == '-a':
            return 0, 'C C.UTF-8 en_US.utf8 POSIX', None

        return 1, None, None

    module.run_command = mock_run_command

    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    locale = get_best_parsable_locale(module, ['C.UTF-8'])
    assert locale == 'C.UTF-8'

    locale = get_

# Generated at 2022-06-11 01:12:55.205905
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # Valid set of options
    assert get_best_parsable_locale(module, ['C.utf8', 'it_IT.utf8', 'C', 'POSIX']) == 'C.utf8'

    # None available
    assert get_best_parsable_locale(module, ['en_US.utf8', 'it_IT.iso885915']) == 'C'

# Generated at 2022-06-11 01:13:00.544906
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = "AnsibleModule(argument_spec={})"
    tested_get_best_parsable_locale = get_best_parsable_locale(module)

    assert tested_get_best_parsable_locale == 'C'

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    tested_get_best_parsable_locale = get_best_parsable_locale(module, preferences)

    assert tested_get_best_parsable_locale == 'C'

# Generated at 2022-06-11 01:13:11.318199
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    AnsibleModule: _AnsibleModule
        module = _AnsibleModule()
        module.get_bin_path = lambda: '/usr/bin/env'
        module.run_command = lambda *args, **kwargs: (0, 'C\nen_US.utf8', None)
    '''
    module = _AnsibleModule()
    module.get_bin_path = lambda: '/usr/bin/env'
    module.run_command = lambda *args, **kwargs: (0, 'C\nen_US.utf8', None)
    test_locale = 'en_US.utf8'
    assert test_locale == get_best_parsable_locale(module)


# Generated at 2022-06-11 01:13:21.894116
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.text import get_exception_only
    from ansible.module_utils.common.text import get_best_parsable_locale
    from ansible.module_utils.basic import AnsibleModule

    module_args = {}
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=False)

    # make sure we get a value if we don't pass any preferences
    assert(get_best_parsable_locale(module))

    # make sure we get a value if we don't pass any preferences and a tool is missing
    try:
        assert(get_best_parsable_locale(module, raise_on_locale=True))
    except RuntimeError as e:
        assert("locale" in get_exception_only(e))


# Generated at 2022-06-11 01:13:33.022586
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Fixture replacement
    class Module(object):

        class RunCommandResult(object):
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

        def run_command(self, args):
            if args[0] != 'locale':
                raise AssertionError('unexpected call to run_command, expected call with args[0] == "locale", got args = %s' % repr(args))
            if args[1] == '-a':
                return self.RunCommandResult(0, 'a_locale\nanother_locale\n', '')
            else:
                return self.RunCommandResult(0, '', '')


# Generated at 2022-06-11 01:13:44.165305
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    import tempfile
    import subprocess

    # mock the locale module
    class AnsibleModule:

        class RunCommandError(Exception):
            pass

        class TryRunCommandError(Exception):
            pass

        class RunCommand:

            def __init__(self, module, cmd, *args, **kwargs):
                self.rc = 0
                self.cmd = cmd
                self.args = args
                self.kwargs = kwargs

            def __call__(self):
                if self.args:
                    p = subprocess.Popen(self.args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

# Generated at 2022-06-11 01:13:46.075290
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['C', 'en_US.utf8'], False) == 'C'

# Generated at 2022-06-11 01:13:52.693698
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec=dict()
    )

    try:
        test_preferences = ['C.utf8', 'C', 'POSIX']
        test_found = get_best_parsable_locale(test_module, test_preferences)
    except:
        assert False, "get_best_parsable_locale failed!"

    assert test_found == "C"

    try:
        test_preferences = ['Nonexistent.utf8', 'C', 'POSIX']
        test_found = get_best_parsable_locale(test_module, test_preferences)
    except:
        assert False, "get_best_parsable_locale failed!"

    assert test

# Generated at 2022-06-11 01:14:01.242423
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    If any of the non-default options does not return the intended result,
    test_get_best_parsable_locale() will raise an AssertionError
    '''
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # set the locale preferences
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    # we expect to get en_US.utf8
    assert get_best_parsable_locale(module, preferences) == preferences[1]

# Generated at 2022-06-11 01:14:05.428517
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    attempts to probe for a locale successfully
    '''
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    locale=get_best_parsable_locale(module)
    assert locale is not None

# Generated at 2022-06-11 01:14:16.402078
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec={})

    locale = get_best_parsable_locale(module)
    assert locale == "C", "Function get_best_parsable_locale returned {}".format(locale)

# Generated at 2022-06-11 01:14:27.696116
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Run unit tests for function get_best_parsable_locale

    :return: Boolean
    '''
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys

    temp_dir = os.path.dirname(__file__)
    if not temp_dir:  # if run directly, not via pytest
        temp_dir = '.'

    test_file = os.path.join(temp_dir, 'test-i18n.sh')
    module = AnsibleModule(argument_spec={
        'test': {'default': True, 'type': 'bool', 'choices': [True]}
    })


# Generated at 2022-06-11 01:14:35.478657
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test case 1: default preferences
    preferences = ['C.utf8', 'en_US.utf8', 'C','POSIX']
    assert get_best_parsable_locale(None, preferences) == 'C'

    # Test case 2: invalid locale, but no exception
    assert get_best_parsable_locale(None, None, raise_on_locale=False) == 'C'

    # Test case 3: invalid locale and raise exception
    try:
        get_best_parsable_locale(None, None, raise_on_locale=True)
    except RuntimeError:
        assert True

    # Test case 4: valid locale
    preferences = ['en_US.utf8']
    assert get_best_parsable_locale(None, preferences) == 'en_US.utf8'

# Generated at 2022-06-11 01:14:42.956455
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda cmd, data=None: (0, cmd[1], None)

    assert get_best_parsable_locale(module, preferences=['unsupported_locale_1', 'unsupported_locale_2']) == 'unsupported_locale_1'

    # the following test should raise an exception
    import pytest

    with pytest.raises(RuntimeWarning):
        get_best_parsable_locale(module, raise_on_locale=True)

# Generated at 2022-06-11 01:14:53.331106
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys
    import tempfile
    import shutil
    import locale
    import unittest
    import ansible.module_utils.basic

    class FakeModule(object):
        def __init__(self):
            self.run_command = run_command
            self.get_bin_path = get_bin_path

    class FakePopen(object):
        def __init__(self, *args, **kwargs):
            self.returncode = 0
            self.stdout = ''
            self.stderr = ''

    def get_bin_path(_module, _binary):
        if _binary == 'locale':
            return 'locale'

        return None


# Generated at 2022-06-11 01:14:54.662091
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-11 01:15:03.108507
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import sys
    import unittest
    from ansible.module_utils.basic import AnsibleModule

    class MyException(Exception):
        pass

    class AnsibleModuleTest(unittest.TestCase):

        def setUp(self):
            self.module = AnsibleModule(argument_spec={})

        def tearDown(self):
            self.module = None

        def test_get_best_parsable_locale_pref(self):
            locale = get_best_parsable_locale(self.module, preferences=['foo', 'bar'])
            self.assertEqual('C', locale)

        def test_get_best_parsable_locale_none(self):
            locale = get_best_parsable_locale(self.module)

# Generated at 2022-06-11 01:15:14.788262
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import ansible.module_utils.basic
    test_module = ansible.module_utils.basic.AnsibleModule(argument_spec={}, supports_check_mode=True, bypass_checks=True)

    # Test locale tool provide output
    locale_get_bin_path = lambda self, command: command
    locale_command = lambda self, args, check_rc=True, environ_update=None, data=None, binary_data=False: (0, 'en_US.utf8\nC.utf8\nC\nPOSIX', None)
    test_module.get_bin_path = lambda self, command: locale_get_bin_path(self, command)

# Generated at 2022-06-11 01:15:18.709679
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule({})
    assert get_best_parsable_locale(mod.params['ansible_module']) in mod.params['ansible_module'].run_command([mod.params['ansible_module'].get_bin_path("locale"), '-a'])[1].strip().splitlines()

# Generated at 2022-06-11 01:15:29.713951
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(module=None) == 'C'
    assert get_best_parsable_locale(module=None, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(module=None, preferences=['C.utf8', 'en_US.utf8', 'POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(module=None, preferences=['C', 'POSIX', 'C.utf8', 'en_US.utf8']) == 'C'

# Generated at 2022-06-11 01:15:44.993268
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    import sys

    test_name = 'ansible_module_test_get_best_parsable_locale_'

    def run_command_mock(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='strict'):
        '''
            mocks the output of the commands run via run_command()
        '''

# Generated at 2022-06-11 01:15:54.996626
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # test module
    module = AnsibleModule(argument_spec={})

    # test locales
    preferences = ['en_US.utf8', 'en_US.UTF-8', 'C.UTF-8']
    assert get_best_parsable_locale(module, preferences) == 'en_US.utf8'

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(module, preferences) == 'C.utf8'

    preferences = ['fr_FR.utf8', 'fr_FR.UTF-8', 'C.UTF-8']
    assert get_best_parsable_locale(module, preferences) == 'C'

# Generated at 2022-06-11 01:15:58.594492
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    test_module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
    )
    assert get_best_parsable_locale(test_module) == 'C'

# Generated at 2022-06-11 01:16:04.002036
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # To keep with the language of mock, module_utils:basic.get_bin_path returns None
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.get_bin_path = lambda x: None
    module.run_command = lambda x: (0, '', '')

    assert 'C' == get_best_parsable_locale(module)

# Generated at 2022-06-11 01:16:13.878937
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    assert get_best_parsable_locale(m, raise_on_locale=False) == 'C'
    assert get_best_parsable_locale(m, ['de_DE.utf8'], raise_on_locale=False) == 'C'
    assert get_best_parsable_locale(m, ['C.utf8'], raise_on_locale=False) == 'C'

    with pytest.raises(RuntimeError) as excinfo:
        get_best_parsable_locale(m, raise_on_locale=True)


# Generated at 2022-06-11 01:16:23.472596
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Tests get_best_parsable_locale

        :returns: bool indicating success
    '''

    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        # unit test doesn't have Ansible
        return False


# Generated at 2022-06-11 01:16:25.141447
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-11 01:16:33.349135
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class MockModule(object):
        def get_bin_path(self, path):
            return '/usr/bin/locale'
        def run_command(self, cmd):
            return 0, "POSIX\nC\nC.utf8\nC.UTF8\nC.UTF-8\nen_US.utf8\n", ''

    m_mod = MockModule()
    assert get_best_parsable_locale(m_mod) == "C.utf8"
    assert get_best_parsable_locale(m_mod, preferences=['C.UTF-8', 'POSIX']) == "C.UTF-8"

# Generated at 2022-06-11 01:16:42.769613
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import tempfile
    import shutil
    from ansible.module_utils.basic import AnsibleModule

    class MyModule(AnsibleModule):
        def run_command(self, args, check_rc=False):
            if args == ['locale', '-a']:
                if args[1] == '-a' and 'LANG' not in os.environ:
                    return os.EX_CONFIG, 'C\nPOSIX', ''
                if args[1] == '-a' and 'LANG' in os.environ:
                    return os.EX_OK, 'C\nPOSIX\nC.UTF-8\nen_US.UTF-8\nfr_FR.UTF-8', ''
            return os.EX_OK, '', ''


# Generated at 2022-06-11 01:16:49.374591
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # We use a legacy Python version in CI to test our modules.
    # There is no module.get_bin_path reference which python version 2.6 understands.
    # This is due the fact that the method is based on subprocess.
    try:
        from ansible.module_utils.basic import AnsibleModule
        module = AnsibleModule(argument_spec={}, supports_check_mode=False)
        result = get_best_parsable_locale(module, ['C.utf8', 'C', 'POSIX'])
    except ImportError:
        result = 'C'

    assert result == 'C'

# Generated at 2022-06-11 01:17:06.264257
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    class UnitTestAnsibleModule(ansible.module_utils.basic.AnsibleModule):
        def __init__(self):
            # Simulate a passed in parameter with a module_utils/basic.py name
            self.params = { 'ANSIBLE_MODULE_UTILS': 'basic' }
            self.tmpdir = None
            self.nonpersistent_file_size = None

    mm = UnitTestAnsibleModule()
    found = get_best_parsable_locale(mm)
    assert found == 'C'

    # Start a fake locale executable
    import subprocess
    from tempfile import NamedTemporaryFile
    from tempfile import mkdtemp
    from shutil import copytree

    # Create a fake locale in a temp directory
    test_file = NamedTem

# Generated at 2022-06-11 01:17:13.110527
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    os.environ['LANG'] = 'C'
    os.environ['LC_ALL'] = 'C'
    import ansible
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec=dict(),
    )
    locale = get_best_parsable_locale(test_module)
    assert locale == "C"

    os.environ['LANG'] = 'de'
    os.environ['LC_ALL'] = 'de'
    test_module = AnsibleModule(
        argument_spec=dict(),
    )
    locale = get_best_parsable_locale(test_module)
    assert locale == "de"

    os.environ['LANG'] = 'de'

# Generated at 2022-06-11 01:17:23.697693
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys

    from os import path
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    locale = path.join(path.dirname(os.path.realpath(__file__)), 'locale_test_bin')
    if sys.version_info[0] >= 3:
        # Python 3
        module.get_bin_path = lambda *args: locale
    else:
        # Python 2
        module.get_bin_path = lambda *args, **kwargs: locale
    module.run_command = lambda *args: (0, 'aaa\r\nbbb', None)
    assert get_best_parsable_locale(module) == 'C'


# Generated at 2022-06-11 01:17:29.769441
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''
    # test with a readable locale
    preferences = ['en_US.utf8']
    found = get_best_parsable_locale(None, preferences)
    assert found == 'en_US.utf8'

    # test with a non-readable locale
    preferences = ['fr_CA.utf8']
    found = get_best_parsable_locale(None, preferences)
    assert found == 'C'

# Generated at 2022-06-11 01:17:36.244250
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    import unittest
    import tempfile

    TEST_MODULE_NAME = 'module_test_ansible_module_utils_locale'

    try:
        from ansible.module_utils import basic
    except ImportError:
        print('Could not import "basic" from module_utils, cannot continue')
        sys.exit(1)

    try:
        from ansible.module_utils import _text
    except ImportError:
        print('Could not import "_text" from module_utils, cannot continue')
        sys.exit(1)

    try:
        from ansible.module_utils import locale
    except ImportError:
        print('Could not import "locale" from module_utils, cannot continue')
        sys.exit(1)


# Generated at 2022-06-11 01:17:47.182373
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.sys_info import get_platform_subclass
    from ansible.module_utils.six import PY3

    class FakeModule(AnsibleModule):
        def __init__(self):
            super(FakeModule, self).__init__()

            self.exit_args = None

            self.fail_json_called = False
            self.exit_json_called = False

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

            self.fail_json_called = True

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kw

# Generated at 2022-06-11 01:17:54.454072
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    # for testing purposes we only want the locale command itself
    # we don't want the module_utils.basic checks

    # set up a mock module
    module = AnsibleModule(
        argument_spec=dict()
    )

    module.run_command = my_run_command

    module.get_bin_path = my_get_bin_path

    # run the test
    result = get_best_parsable_locale(module)
    assert result == "POSIX"


# mock functions

# Generated at 2022-06-11 01:18:01.592505
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # mock the AnsibleModule class
    class AnsibleModule(object):
        def __init__(self, *args, **kwargs):
            pass

        def get_bin_path(self, binary):
            return '/usr/bin/locale'

        def run_command(self, cmd):
            if cmd[1] == '-a':
                return 0, 'C\nC.utf8\nen_US.utf8\nPOSIX', ''
            elif cmd[1] == '-c':
                return 0, 'C\n', ''

    module = AnsibleModule()

    found = get_best_parsable_locale(module)
    assert found == 'C'

    found = get_best_parsable_locale(module, preferences=['lol'])
    assert found == 'C'

   

# Generated at 2022-06-11 01:18:12.791156
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    class FakeModule(AnsibleModule):
        def run_command(self, cmd):
            return 0, '', ''

    test_module = FakeModule(
        argument_spec={},
    )

    possible_locales = ['C', 'C.utf8', 'en_US.utf8', 'en_US.utf8.praat', 'en_US.utf8.pspp']
    locale = get_best_parsable_locale(test_module)
    assert locale == 'C'

    locale = get_best_parsable_locale(test_module, ['C'])
    assert locale == 'C'

    locale = get_best_parsable_locale(test_module, possible_locales)

# Generated at 2022-06-11 01:18:22.705872
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        import ansible.module_utils
        import ansible.module_utils.basic
    except ImportError:
        print("Could not import 'ansible.module_utils', skipping test")
        return

    # Import needed to get module mock
    # pylint: disable=unused-import
    from ansible.modules.packaging.os.pkgng import best_parsable_locale

    # noinspection PyTypeChecker
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})

    # Locale CLI issues test
    result = get_best_parsable_locale(module)
    assert result == 'C'

    # Test preferences None
    result = get_best_parsable_locale(module, preferences=None)
    assert result == 'C' or result