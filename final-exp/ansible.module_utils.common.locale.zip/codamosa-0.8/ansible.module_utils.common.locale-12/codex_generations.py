

# Generated at 2022-06-11 01:08:46.104446
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    # Warning case with 'C' locale
    assert get_best_parsable_locale(module, ['ko-KR'], raise_on_locale=True) is 'C'

    # Available case with English locale
    assert get_best_parsable_locale(module, ['ko-KR']) is 'C'

# Generated at 2022-06-11 01:08:56.071287
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 01:09:03.200810
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    from ansible.utils.path import unfrackpath

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # get the locale on the system
    locale = basic.get_best_parsable_locale(module)

    # since we don't know what locale is on the system when running tests
    # we need to unfrackpath it if its not C
    if locale != 'C':
        locale = unfrackpath(locale)

    # test that a preference returns that preference
    pref = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

# Generated at 2022-06-11 01:09:10.507113
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import mock
    import subprocess

    # Scenario 1: locale command not available
    module = mock.Mock()
    module.get_bin_path.return_value = None
    assert get_best_parsable_locale(module) == 'C'

    # Scenario 2: locale command available, but no output
    module = mock.Mock()
    module.get_bin_path.return_value = 'locale'
    module.run_command.return_value = (0, None, None)
    assert get_best_parsable_locale(module) == 'C'

    # Scenario 3: locale command available, but errors
    module = mock.Mock()
    module.get_bin_path.return_value = 'locale'

# Generated at 2022-06-11 01:09:20.964763
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.arguments import ArgumentSpec
    from ansible.module_utils.six import PY3

    main_spec = dict(
        answer = dict(type='int', required=True),
    )
    module = AnsibleModule(
        argument_spec=main_spec,
        supports_check_mode=True
    )

    assert get_best_parsable_locale(module) == 'C'

    if PY3:
        assert get_best_parsable_locale(module, raise_on_locale=True) == "en_US.utf8"
    else:
        assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

    assert get

# Generated at 2022-06-11 01:09:30.879817
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_module_namespace = dict(
        get_bin_path=lambda x: '/bin/locale',
        run_command=lambda x: (0, 'C\nen_US\nPOSIX\nC.UTF-8\nen_US.UTF-8', ''),
        fail_json=lambda x: None,
    )

    assert get_best_parsable_locale(test_module_namespace) == 'C'
    assert get_best_parsable_locale(test_module_namespace, preferences=['en_US', 'SOME_MISSING', 'POSIX']) == 'en_US'
    assert get_best_parsable_locale(test_module_namespace, preferences=['POSIX', 'C.UTF-8']) == 'POSIX'
    assert get_best

# Generated at 2022-06-11 01:09:41.566038
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    dummy_module = AnsibleModule(argument_spec={})

    # if we don't have the `locale` binary, pretend it always returns C
    def mock_run_command(args):
        if args[0] == '/bin/locale':
            return 0, 'C\nen_US.utf8', ''
        return dummy_module.run_command(args)

    dummy_module.run_command = mock_run_command
    assert 'C' == get_best_parsable_locale(dummy_module)
    assert 'C.utf8' == get_best_parsable_locale(dummy_module, preferences=['C.utf8'])

# Generated at 2022-06-11 01:09:51.494559
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module=module) == 'C'

    module = AnsibleModule(argument_spec={})
    orig_get_bin_path = module.get_bin_path

    def get_bin_path(path):
        if path == 'locale':
            return path
        else:
            return orig_get_bin_path(path)

    module.get_bin_path = get_bin_path
    orig_run_command = module.run_command


# Generated at 2022-06-11 01:10:01.025431
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Import modules
    import unittest.mock as mock
    import os
    import distutils.spawn
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.basic import AnsibleModule

    # Initialize module
    class Options(object):
        def __init__(self, no_log):
            self.no_log = no_log

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )
    # module.params = {
    #     'LOCALE': 'C.utf8'
    # }
    # module.params = {}
    module._ansible_options = Options(no_log=False)

    # Define function under test

# Generated at 2022-06-11 01:10:08.367057
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.tmpdir = None
            self.tmpdir_update = None
            self.debug = False
            self.logger = None
            self.fail_json = self.exit_json = None

        def run_command(self, cmd, tmp_path=None, allow_errs=False, environ_update=None, check_rc=True, close_fds=True):
            if 'locale' in cmd[0]:
                out = 'en_US.utf8\nanother_locale\n'
                if 'an_country' not in out:
                    out += 'an_country'
               

# Generated at 2022-06-11 01:10:16.798829
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    assert ansible.module_utils.basic.get_best_parsable_locale.__name__ == 'get_best_parsable_locale'

# Generated at 2022-06-11 01:10:25.890396
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # test empty list
    # test empty list
    avail = []
    pref = []
    assert get_best_parsable_locale(module, pref, avail) == 'C'

    # test with a hit
    avail = ['C', 'en_US.iso88591']
    pref = ['en_US.iso88591']
    assert get_best_parsable_locale(module, pref, avail) == 'en_US.iso88591'

    # not a list
    try:
        get_best_parsable_locale(module, {'one': 'two'})
        assert False
    except RuntimeWarning:
        pass

    # only need one preferred, so test that
    #

# Generated at 2022-06-11 01:10:26.844507
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass


# Generated at 2022-06-11 01:10:38.241282
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule(object):
        def __init__(self):
            pass

        def get_bin_path(self, path):
            return path

        def run_command(self, command):
            rc = 0
            out = 'C'
            err = ''
            return rc, out, err

    module = AnsibleModule()

    # Test with preferences.
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    locale = get_best_parsable_locale(module, preferences, True)
    assert locale == 'C'

    class AnsibleModule(object):
        def __init__(self):
            pass

        def get_bin_path(self, path):
            return path

        def run_command(self, command):
            rc = 0
            out

# Generated at 2022-06-11 01:10:43.376961
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Tests tested under Travis are run with LC_ALL=C which means that get_best_parsable_locale()
    # should return the default value 'C'
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:10:52.592217
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.modules.system.setup import gather_facts
    from ansible.constants import DEFAULT_LOCALE

    def _run_module(mock_module, mock_locale):
        ''' Patch locale and run the module. '''

        # Patch the bin_path to return the mock_locale
        mock_module.bin_path = lambda *args, **kwargs: mock_locale

        # Execute the module
        gather_facts.main()

        if mock_locale is None:
            assert mock_module.exit_json.called
            assert all(x[0][0] == 'failed' for x in mock_module.fail_json.call_args_list)
            assert all('locale' in x[0][1] for x in mock_module.fail_json.call_args_list)
           

# Generated at 2022-06-11 01:11:04.266652
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    test_locale = get_best_parsable_locale(module, ['en_US.utf8'], raise_on_locale=False)
    assert test_locale == 'en_US.utf8'
    test_locale = get_best_parsable_locale(module, ['en_US.utf8', 'C'], raise_on_locale=False)
    assert test_locale == 'en_US.utf8'
    test_locale = get_best_parsable_locale(module, ['C', 'POSIX'], raise_on_locale=False)
    assert test_locale == 'C'
    test_locale = get_best_pars

# Generated at 2022-06-11 01:11:04.837236
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-11 01:11:13.459382
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Using a class to mock the Ansible module in testing the get_best_parsable_locale() function.
    '''
    class AnsibleModule:
        def get_bin_path(self, command):
            if command == "locale":
                return command
            else:
                return None

        def run_command(self, command):
            # Mock the output of the OS command "locale -a" for testing
            if command == ['locale', '-a']:
                # Mock the output for different locales
                out = '''C
                    en_US.utf8
                    POSIX
                    C.UTF-8
                '''
                return 0, out, None
            else:
                return 0, None, "locale command not mocked"

    test_ansible_module = AnsibleModule()
   

# Generated at 2022-06-11 01:11:22.988614
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = FakeModule()

    # Default preference list
    assert get_best_parsable_locale(module) == 'C'

    # Raise on locale
    try:
        assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'
    except RuntimeWarning:
        pass

    # Test when locale is present but locale -a fails
    module.run_command_rc = 1
    assert get_best_parsable_locale(module) == 'C'

    # Test when locale is present but locale -a returns no output
    module.run_command_rc = 0
    module.run_command_out = ''
    assert get_best_parsable_locale(module) == 'C'

    # Test when locale is present and locale -a succeeds
    module.run

# Generated at 2022-06-11 01:11:38.513021
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Create dummy module object
    module = AnsibleModule(argument_spec={})
    # Set module.run_command return values
    module.run_command = lambda cmd: (0, 'C.utf8\nen_US.utf8', '')
    # Should not raise any exception
    assert get_best_parsable_locale(module) == 'C.utf8'
    # Set module.run_command return values
    module.run_command = lambda cmd: (0, 'en_US.utf8', '')
    # Should not raise any exception
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    # Test with not available locales
    # Set module.run_command return values
    module.run_

# Generated at 2022-06-11 01:11:42.949771
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    found = get_best_parsable_locale(module, preferences)
    assert found == 'C'

# Generated at 2022-06-11 01:11:53.644578
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.modules.system.setup import get_best_parsable_locale
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(
        argument_spec=dict(),
    )

    m.get_bin_path = lambda x: None
    m.run_command = lambda x: (0, 'locale_A_A.utf8\nlocale_B_B.ascii\nlocale_C.utf8', '')

    best = get_best_parsable_locale(m)
    assert best == 'C.utf8'

    m.run_command = lambda x: (0, 'locale_A_A.utf8\nlocale_B_B.ascii\nlocale_C.utf8', '')
    best = get_

# Generated at 2022-06-11 01:12:02.464064
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path
    import pytest

    mod = pytest.importorskip("ansible.module_utils.basic")

    assert mod.get_best_parsable_locale(mod) == 'C'

    locale = get_bin_path('locale')
    if locale:
        rc, out, err = mod.run_command([locale, '-a'])
        assert rc == 0
        assert out.strip().splitlines()
        assert not err
        assert mod.get_best_parsable_locale(mod, preferences=['C']) == 'C'
    else:
        # this is likely to happen in a container
        # assert mod.get_best_parsable_locale(mod) == 'C'
        pass

# Generated at 2022-06-11 01:12:04.215356
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Put some test cases here
    pass

# Generated at 2022-06-11 01:12:15.482078
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for get_best_parsable_locale
    '''
    module_name = 'ansible.module_utils.basic.get_best_parsable_locale'
    def test_preferences(preferences, expected_locale_return, locale_a_output):
        '''
            Test get_best_parsable_locale function
        '''
        from ansible.module_utils.common.collections import ImmutableDict
        from ansible.module_utils.basic import AnsibleModule
        mod = AnsibleModule(argument_spec=dict())
        mod.run_command = lambda cmd: (0, locale_a_output, '')
        locale = get_best_parsable_locale(mod, preferences)

# Generated at 2022-06-11 01:12:18.244838
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:12:27.063778
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    test_cases = [
        {"input": "C.utf8\nen_US.utf8\nC\nPOSIX",
         "available": "en_US.utf8"},
        {"input": "C.utf8\nC\nPOSIX",
         "available": "C"},
        {"input": "C.utf8\nen_US.utf8\nPOSIX",
         "available": "POSIX"},
        {"input": "",
         "available": "C"},
        # TODO: Add a test case where it fails due to non-english chars
    ]

    for test_case in test_cases:
        module = AnsibleModule(argument_spec={})
        module.run_command = lambda cmd: (0, test_case["input"], None)

# Generated at 2022-06-11 01:12:38.679578
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_module = AnsibleModule(argument_spec={})
    # Mock ansible module function get_bin_path
    test_module.get_bin_path = MagicMock(return_value = "locale")
    # Mock ansible module function run_command
    test_module.run_command = MagicMock(return_value = (0, 'C\nC.UTF-8\nC.utf8\nen_US.utf8\nPOSIX', None))
    # Call the get_best_parsable_locale function
    assert get_best_parsable_locale(test_module) == 'C.utf8'

    # Mock ansible module function run_command to return error code
    test_module.run_command = MagicMock(return_value = (126, None, None))
    # Call the get

# Generated at 2022-06-11 01:12:50.901520
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import copy
    import tempfile
    from ansible.module_utils.basic import Environment

    av_envs = dict()
    av_envs['en_US.UTF-8'] = 'en_US.utf8'
    av_envs['C'] = 'C'
    av_envs['POSIX'] = 'POSIX'

    with tempfile.TemporaryDirectory() as td:
        with open(os.path.join(td, 'locale'), 'w') as f:
            f.write("#!/bin/sh\nif [ $1 = -a ] ; then cat %s ; fi" % os.path.join(td, 'envs'))
        os.chmod(os.path.join(td, 'locale'), 0o755)


# Generated at 2022-06-11 01:13:07.803032
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # TODO: Add proper unit test
    # This function is not worth to unit test, since it works with system
    # locale, which is very hard to unit test.
    assert True

# Generated at 2022-06-11 01:13:10.276376
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    assert get_best_parsable_locale(AnsibleModule()) == 'C'

# Generated at 2022-06-11 01:13:20.993135
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = MockRunCommand()
            self.get_bin_path = MockGetBinPath()

    class MockRunCommand(object):
        def __init__(self):
            self.out = 'C' + '\n' + 'en_CA.UTF-8'
            self.err = ''
            self.rc = 0

        def __call__(self, args):
            return self.rc, self.out, self.err

    class MockGetBinPath(object):
        def __init__(self):
            self.path = '/usr/bin/locale'

        def __call__(self, args):
            return self.path

    # ------- Tests using a mocked module ----------------
    best_locale

# Generated at 2022-06-11 01:13:25.418339
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''
    preferences=['en_US.utf8', 'POSIX', 'C']
    assert get_best_parsable_locale(None, preferences) == 'en_US.utf8'

# This is the class that all collection callbacks must inherit from

# Generated at 2022-06-11 01:13:30.678930
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys

    class MyModule:
        def __init__(self):
            self.params = dict()
            self.fail_json_called = False

        def get_bin_path(self, tool):
            if tool == 'locale':
                return sys.executable
            else:
                return None

        def run_command(self, command):
            if command[1] == '-a':
                return 0, '\n'.join([
                    'C',
                    'C.utf8',
                    'POSIX',
                    'en_US.utf8',
                    'en_US.utf8@foobar',
                    'en_US.utf8@barbaz'
                ]), ''
            else:
                raise RuntimeError('Unexpected command: %s' % command)


# Generated at 2022-06-11 01:13:41.783821
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    # test that we are getting a locale back
    assert module.get_parsable_locale()
    # test that we are getting the specified locale back
    assert module.get_parsable_locale(preferences=['en_US.utf8']) == 'en_US.utf8'
    # test that we are getting the first available locale back
    assert module.get_parsable_locale(preferences=['en_US.utf8', 'C']) == 'C'
    # test that we are getting the first available locale back

# Generated at 2022-06-11 01:13:48.525594
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={'preferences': dict(required=False)})
    pref = [
        'foo',  # Test that a non-existent locale is handled correctly
        'C.utf8', 'en_US.utf8', 'C', 'POSIX'
    ]
    res = get_best_parsable_locale(module, preferences=pref)
    assert res == 'en_US.utf8', "Locale should be en_US.utf8, not %s" % res

# Generated at 2022-06-11 01:13:59.589817
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import platform

    class TestAnsibleModule:

        def __init__(self):
            self.run_command_called = 0

        def get_bin_path(self, arg):
            if sys.version_info >= (3, 6):
                # get_bin_path() raises exceptions on Python 3.6+.
                return '/bin/' + arg

            if platform.system() == 'Darwin':
                # On Mac OS X, 'locale' is aliased to 'locale_utf8' in
                # /usr/bin/locale, so get_bin_path() will return '/bin/locale_utf8'.
                return '/bin/' + arg

# Generated at 2022-06-11 01:14:09.870124
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Importing modules here and not in the beginning of the file
    # because this function import to_text from module_utils.text
    # and this is later called from the module_utils.basic
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule({})  # empty params dict

    assert am.get_bin_path("locale") is not None

    # By default we should return 'C' if no preferred locale is given
    assert get_best_parsable_locale(am) == 'C'

    # 'C.utf8' is preferred and we should return it
    assert get_best_parsable_locale(am, preferences=['C.utf8']) == 'C.utf8'

    # 'C.utf8' and 'C.utf8' is preferred but 'C.utf

# Generated at 2022-06-11 01:14:12.846049
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['en_US.utf8', 'en_GB.utf8']) == 'en_US.utf8'

# Generated at 2022-06-11 01:14:34.893480
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_cmd_utf8 = "locale -a"
    locale_cmd_c = "locale -a"

    class AnsibleModule():
        def __init__(self, *args, **kwargs):
            self.run_command_calls = 0
            self.locale_cmd = None
            self.rc = 0
            self.out = None
            self.err = None

        def run_command(self, args):
            self.run_command_calls += 1
            self.locale_cmd = args
            rc = 0
            out = None
            err = None
            if self.run_command_calls == 1:
                out = locale_cmd_c
            elif self.run_command_calls == 2:
                out = locale_cmd_utf8

# Generated at 2022-06-11 01:14:44.595539
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    module = AnsibleModule()
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    available = os.environ.get('TEST_LOCALE_AVAILABLE', '').split()
    module.run_command = lambda x: (0, '\n'.join(available), '')

    # Test when a preference is found
    preferences = ['en_US.utf8', 'C.utf8', 'POSIX', 'C']
    locale = get_best_parsable_locale(module)
    assert locale == preferences[0]

    # Test when a preference is not found
    available = available[:1]
    locale = get_best_parsable_locale(module)
   

# Generated at 2022-06-11 01:14:54.965885
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX', 'test.test']

    fake_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    fake_module.run_command = lambda arg: (2, 'test', 'testing')

    locale = get_best_parsable_locale(fake_module, preferences, raise_on_locale=True)
    assert locale != 'C'

    fake_module.run_command = lambda arg: (1, 'test', 'testing')

    locale = get_best_parsable_locale(fake_module, preferences, raise_on_locale=True)
    assert locale != 'C'


# Generated at 2022-06-11 01:15:00.579094
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    class KArgs(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    args = KArgs(
        preferred_locales=[
            'nl_NL.utf8',
            'nl_NL.UTF-8',
            'nl_NL',
            'nl.utf8',
            'nl.UTF-8',
            'nl',
            'en_GB.utf8',
            'en_GB.UTF-8',
            'en_GB',
            'en.utf8',
            'en.UTF-8',
            'en',
            'C.utf8',
            'C.UTF-8',
            'C',
            'POSIX',
        ],
    )


# Generated at 2022-06-11 01:15:08.108113
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test best locale available

    :return: --
    '''
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    try:
        best_locale = get_best_parsable_locale(module, preferences=['C.UTF-8', 'C.utf8', 'C'])
    except Exception as e:
        module.fail_json(msg=to_native(e))

    module.exit_json(msg="Best locale is %s" %best_locale)

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-11 01:15:16.609777
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    res = get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8', 'POSIX'])
    assert res == 'C.utf8', 'Posix systems should use C.utf8 locale'

    res = get_best_parsable_locale(None, ['C', 'POSIX'])
    assert res == 'C', 'Posix systems should use C locale'

    res = get_best_parsable_locale(None, ['en_US.utf8', 'POSIX'])
    assert res == 'C', 'Posix systems should default to C locale'

# Generated at 2022-06-11 01:15:17.738546
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-11 01:15:21.850731
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:15:31.798470
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import mock
    from ansible.module_utils.common.locale import best_parsable_locale

    # we are going to get cli.run_command to run this module
    mo = mock.mock_module()

    # override module.get_bin_path so we can know what the cli arg is
    bin_path = '/usr/bin/locale'
    mo.get_bin_path.return_value = bin_path

    # override module.run_command so we can control the output
    # https://docs.python.org/2/library/subprocess.html#subprocess.Popen.returncode

# Generated at 2022-06-11 01:15:41.685533
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import shutil
    import tempfile
    import sys

    if sys.version_info[0] == 2:
        import commands as commands
    else:
        import subprocess as commands

    # Create temp dir and files
    temp_dir = tempfile.mkdtemp()
    locale_path = os.path.join(temp_dir, 'locale')
    locale_file = tempfile.NamedTemporaryFile(dir=temp_dir)

    # Fake locale command
    with open(locale_path, 'w') as f:
        f.write("#!/bin/bash\n")
        f.write("cat %s\n" % locale_file.name)

    # Create module instance
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 01:16:04.972021
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def get_bin_path(name):
        return name

    def run_command(cmd):
        results = {
            'locale -a': [0, 'C\nC.UTF-8\nde_DE.utf8\nPOSIX\n', ''],
            'locale -a C': [0, 'C\nC.UTF-8\n', ''],
            'locale -a C.UTF-8': [0, 'C.UTF-8\n', ''],
            'locale -a de_DE': [0, '', 'de_DE: No such file or directory\n'],
            'locale -a POSIX': [0, 'POSIX\n', ''],
        }
        return results[str(cmd)]


# Generated at 2022-06-11 01:16:14.678971
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['C.UTF-8', 'POSIX', 'C.UTF-8', 'en_US.UTF-8', 'en_US.UTF-8', 'en_US.UTF-8', 'en_US.UTF-8', 'en_US.UTF-8']
    pass_preference = 'POSIX'
    fail_preference = 'C.UTF-8'
    got_preference = get_best_parsable_locale(preferences=preferences)
    assert not got_preference is None
    assert got_preference == pass_preference

    got_preference = get_best_parsable_locale(preferences=[fail_preference])
    assert not got_preference is None
    assert got_preference == 'C'

# Generated at 2022-06-11 01:16:24.139272
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, None) == 'C'
    assert get_best_parsable_locale(None, []) == 'C'
    assert get_best_parsable_locale(None, ['non_existent_locale']) == 'C'
    assert get_best_parsable_locale(None, ['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, ['POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(None, ['en_US.utf8', 'POSIX', 'C']) == 'en_US.utf8'

# Generated at 2022-06-11 01:16:34.517588
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 01:16:43.888042
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    ansible.module_utils.i18n - Test get_best_parsable_locale
    '''

    from ansible.module_utils.basic import ModuleTestCase
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(AnsibleModule):
        def get_bin_path(self, name, required=True):
            return name

        def run_command(self, args, check_rc=False):
            return (0, 'C.utf8\nen_US.utf8\nC\nPOSIX\n', '')

    module = TestModule(argument_spec={})

    # test that function works as expected with no exception
    output = get_best_parsable_locale(module)
    assert output == 'C.utf8'

    # test that exception gets

# Generated at 2022-06-11 01:16:51.385999
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class Module:
        def __init__(self):
            self.run_command_pos = 0
            self.run_command_calls = [
                (0, 'C\nen_US.utf8\nPOSIX\n', ''),
                (0, 'C\nen_US.utf8\nPOSIX\n', ''),
                (127, '', 'Command \'locale\' not found.'),
            ]
            self.run_command_exception_calls = [
                OSError('locale command does not exist'),
            ]
        def get_bin_path(self, arg, *args, **kwargs):
            if arg == 'locale':
                return '/usr/bin/locale'
            else:
                return None

# Generated at 2022-06-11 01:17:00.269257
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Load the test module
    from ansible.module_utils.basic import AnsibleModule

    # Initialize the test module
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Simple function call
    assert get_best_parsable_locale(test_module) == 'C'

    # Function call with arguments
    assert get_best_parsable_locale(test_module, preferences=['en_US.utf8']) == 'en_US.utf8'

    # Function call with arguments
    assert get_best_parsable_locale(test_module, preferences=['en_US.utf8', 'C.utf8', 'C', 'POSIX']) == 'en_US.utf8'

# Generated at 2022-06-11 01:17:03.772782
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    fake_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    assert get_best_parsable_locale(fake_module) == 'C'  # return default if locale is not found

# Generated at 2022-06-11 01:17:11.760375
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    am = ansible.module_utils.basic.AnsibleModule(argument_spec={})

    assert am.get_bin_path("locale")

    # We don't really expect these to exist, but we can test for them
    assert get_best_parsable_locale(am, ['C.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(am, ['en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(am, ['foobar']) == 'C'
    assert get_best_parsable_locale(am, ['en_US.utf8', 'C.utf8']) == 'en_US.utf8'

    # Now let

# Generated at 2022-06-11 01:17:22.164639
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test for each possible case in get_best_parsable_locale()
    from ansible.module_utils.basic import AnsibleModule

    # Test for rc=0, out=C with preferences containing C
    m = AnsibleModule(argument_spec={})
    m.run_command = lambda x: (0, 'C\nen_US', '')
    assert get_best_parsable_locale(m, preferences=['C']) == 'C'

    # Test for rc=0, out=C without preferences
    m = AnsibleModule(argument_spec={})
    m.run_command = lambda x: (0, 'C\nen_US', '')
    assert get_best_parsable_locale(m, preferences=None) == 'C'

    # Test for rc=0, out=C without

# Generated at 2022-06-11 01:17:47.331083
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Fake module to fool locale checking
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    module.run_command = lambda args, check_rc=False: (0, args[1], None)
    assert 'C.utf8' == get_best_parsable_locale(module, preferences=['C.utf8', 'c.utf8', 'C'])
    assert 'C.utf8' == get_best_parsable_locale(module, preferences=['C.utf8', 'c.utf8', 'C'])
    assert 'C' == get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8', 'c.utf8', 'C'])


# Generated at 2022-06-11 01:17:56.819177
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import mock

    test_preferences = ['pref1', 'pref2']

    # Testcase 1: locale command is not present on system
    with mock.patch.dict(os.environ, {'PATH': '/bin'}):
        module = mock.MagicMock()
        module.run_command = mock.MagicMock(side_effect=RuntimeWarning('Could not find locale'))
        loc = get_best_parsable_locale(module, test_preferences, raise_on_locale=True)
        assert loc == 'C'

    # Testcase 2: locale command is present on system
    with mock.patch.dict(os.environ, {'PATH': '/bin'}):
        module = mock.MagicMock()

# Generated at 2022-06-11 01:17:59.398399
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    assert get_best_parsable_locale(AnsibleModule()) == 'C'

# Generated at 2022-06-11 01:18:10.454517
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_sequence
    module = AnsibleModule(
        argument_spec=dict(
            locale=dict(type='str', required=False)
        )
    )
    
    default_preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    locale = get_best_parsable_locale(module)
    assert locale == 'C'
    assert module.params['locale'] is None
    assert is_sequence(default_preferences)

    preferences = ['de_DE.utf8', 'es_ES.utf8', 'C.utf8']
    locale = get_best_parsable_locale(module, preferences=preferences)


# Generated at 2022-06-11 01:18:20.955263
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
    )

    # First check that error handling is working
    try:
        get_best_parsable_locale(module, raise_on_locale=True)
    except RuntimeWarning as e:
        assert "Could not find 'locale' tool" in to_native(e)
        assert "Unable to get locale information" not in to_native(e)

    # Now check that it is working successfully
    try:
        get_best_parsable_locale(module)
    except RuntimeWarning:
        assert False, "Failed to perform the test successfully"

    # Now check that we are handling the case of no output from command
    mock_module = ansible.module_

# Generated at 2022-06-11 01:18:29.523884
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule(
        argument_spec=dict()
    )

    # This is what the output of 'locale -a' looks like on MacOSX

# Generated at 2022-06-11 01:18:37.182290
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path
    import sys

    mockModule = AnsibleModuleMock()
    mockModule.run_command = func_mock_run_command

    # Mock get_bin_path to return the full path to the test case's locale binary
    mockModule.get_bin_path = lambda bin_name, required=False: \
                              os.path.join(os.path.dirname(sys.argv[0]), "fake_locale_for_unittest")

    # Test with no prefs, expect 'C' returned
    assert "C" == get_best_parsable_locale(mockModule)

    # Test with a variety of prefs but only one supported,
    # and except that one returned
    assert "en_US.utf8" == get