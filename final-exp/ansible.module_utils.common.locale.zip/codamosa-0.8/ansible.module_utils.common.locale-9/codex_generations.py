

# Generated at 2022-06-11 01:08:45.569924
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(supports_check_mode=True)

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['en_US.utf8']) == 'en_US.utf8'

# Generated at 2022-06-11 01:08:55.671499
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test module stub
    class TestModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = None
            self.run_command_err = None

        def run_command(self, args):
            self.run_command_args = args
            return self.run_command_rc, self.run_command_out, self.run_command_err

    # Test ascii in output
    test_module = TestModule()
    test_module.run_command_out = 'C.UTF-8\nen_US.UTF-8\nPOSIX\n'
    test_module.run_command_args = None

# Generated at 2022-06-11 01:09:04.283897
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import os
    import tempfile
    import pytest

    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        def __init__(self):
            self.params = dict()
            self.debug = dict()

        def get_bin_path(self, name):
            return os.path.exists("/usr/bin/%s" % name) and "/usr/bin/%s" % name

        def run_command(self, args):
            return 0, "C\nen_US.utf8", ""

    fake_module = FakeModule()

    assert get_best_parsable_locale(fake_module) == 'en_US.utf8'

    def run_command(args):
        return 0, "C\nen_US.utf8", ""

    fake_

# Generated at 2022-06-11 01:09:14.036932
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.utils.unicode import to_bytes
    from ansible.modules.system.locale import get_best_parsable_locale

    class AnsibleModule(object):
        def run_command(self, cmd, check_rc=True):
            if cmd[1] == '-a':
                return (0, '\n'.join(['C.utf8', 'C', 'POSIX']), '')

        def get_bin_path(self, name):
            return name

    module = AnsibleModule()
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    assert(get_best_parsable_locale(module) == "C.utf8")

# Generated at 2022-06-11 01:09:19.727164
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == 'C'
    assert get_best_parsable_locale(preferences=['de_DE', 'en_US']) == 'C'
    assert get_best_parsable_locale(preferences=['en_US.utf8', 'de_DE.utf8']) == 'en_US.utf8'



# Generated at 2022-06-11 01:09:21.784009
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    best_locale = get_best_parsable_locale()
    assert best_locale == 'C'


# Generated at 2022-06-11 01:09:31.427696
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    temp_paths = [
        '/var/tmp/ansible-locale-1.0/bin',
        '/var/tmp/ansible-locale-2.0/bin',
        '/var/tmp/ansible-locale-3.0/bin',
        '/var/tmp/ansible-locale-4.0/bin',
        '/var/tmp/ansible-locale-5.0/bin',
        '/var/tmp/ansible-locale-6.0/bin'
    ]


# Generated at 2022-06-11 01:09:35.635982
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test the function using mock
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock
    import os
    # It's a common pattern to just mock the module and not use the data below
    module = Mock()
    modul

# Generated at 2022-06-11 01:09:44.849465
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # This test doesn't work on windows
    import platform
    if platform.system() != 'Windows':
        try:
            assert get_best_parsable_locale(None, raise_on_locale=True).startswith('C')
        except RuntimeWarning as e:
            print("Runtime Exception '%s' should not have occurred" % to_native(e))
            return False
        except AssertionError:
            raise

        try:
            get_best_parsable_locale(None, raise_on_locale=True)  # will not raise exception
            assert True
        except RuntimeWarning as e:
            print("Runtime Exception '%s' should not have occurred" % to_native(e))
            return False
        except AssertionError:
            raise


# Generated at 2022-06-11 01:09:55.104415
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test that get_best_parsable_locale returns the default 'C' when it cannot
    find locale tool
    '''
    from ansible.module_utils.basic import AnsibleModule
    # Mock AnsibleModule
    mock_module = AnsibleModule(argument_spec={})

    # Can't find locale tool
    mock_module.get_bin_path = lambda s: None
    assert get_best_parsable_locale(mock_module) == 'C'

    # Have locale tool but cannot parse its output
    mock_module.get_bin_path = lambda s: "locale"
    mock_module.run_command = lambda s: (1, '', '')
    assert get_best_parsable_locale(mock_module) == 'C'

    # Have locale tool and

# Generated at 2022-06-11 01:10:07.350099
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    def test_result(module_mock, locale_results, preference_results, raise_on_locale_results, expected_results):
        def mock_module_run_command(params, check_rc=True, **kwargs):
            if params == ['locale', '-a'] and check_rc:
                return 0, locale_results, None
            else:
                raise AssertionError("Unexpected params: %s" % (params))

        module_mock.run_command = mock_module_run_command

        def mock_module_get_bin_path(params, **kwargs):
            if params == "locale":
                return params
            else:
                raise AssertionError("Unexpected params: %s" % (params))

        module_mock.get_bin_path = mock_module_get_bin

# Generated at 2022-06-11 01:10:18.548298
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['.utf8', 'C.utf8', 'C', 'POSIX']
    locale_output = 'C\nen_US.utf8\nen_US.utf\nen_US.utf8@bogus'

    class mock_module():
        def __init__(self):
            self.run_command = lambda x: (0, locale_output, '')

    module = mock_module()
    assert get_best_parsable_locale(module, preferences=preferences) == 'en_US.utf8'

    locale_output = 'C\nen_US.utf8\nen_US.utf\nen_US.utf8@bogus'
    preferences = ['en_US.utf8@bogus', 'en_US.utf8']

    module = mock_module()
    assert get_

# Generated at 2022-06-11 01:10:26.898144
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import mock
    import shutil
    import sys
    import tempfile
    import ansible.module_utils

    # (mocks a module and lang installed)
    module = mock.MagicMock()
    module.get_bin_path.return_value = '/bin/true'
    module.run_command.return_value = (0, 'C', '')
    assert ansible.module_utils.get_best_parsable_locale(module) == 'C'

    module.run_command.return_value = (0, '', '')
    assert ansible.module_utils.get_best_parsable_locale(module) == 'C'

    module.run_command.return_value = (0, 'C\nen_US', '')
    assert ansible.module_utils.get_best_p

# Generated at 2022-06-11 01:10:38.241699
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import sys
    import os
    import platform
    import ansible.module_utils.basic
    import ansible.module_utils.basic

    class FakeModule(object):

        def __init__(self, what_os, locale_cmd_rc, locale_cmd_out, locale_cmd_err, **kwargs):
            self.os_name = what_os
            self.os_family = "FakeOS"
            self.run_command_rc = locale_cmd_rc
            self.run_command_out = locale_cmd_out
            self.run_command_err = locale_cmd_err

        def __getattr__(self, key):
            return "Not implemented"


# Generated at 2022-06-11 01:10:48.897304
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 01:10:58.940784
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule(
        argument_spec=dict(
        )
    )

    # POSIX locales, POSIX locales, POSIX locales
    assert get_best_parsable_locale(mod) == 'C'

    # Asserting pseudo locale
    assert get_best_parsable_locale(mod, ['C']) == 'C'

    # Asserting pseudo locale
    assert get_best_parsable_locale(mod, ['C.utf8']) == 'C'


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-11 01:11:09.403281
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''
    import os
    import sys

    sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(command_line='', argument_spec={})
    # set path to the local locale
    # this must be an executable that returns the list of supported locales
    # in the output
    os.environ['PATH'] += ':' + os.path.dirname(__file__)
    os.environ['LANG'] = 'en_US.UTF-8'
    os.environ['LANGUAGE'] = 'en_US.UTF-8'

# Generated at 2022-06-11 01:11:19.048781
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec={})
    module.run_command = mock.Mock()

    module.run_command.return_value = (0, 'C.utf8\nen_US.utf8\nC\nPOSIX\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

    module.run_command.return_value = (0, 'en_GB.utf8\nC.utf8\nC', '')
    assert get_best_parsable_locale(module) == 'en_GB.utf8'

    module.run_command.return_value = (0, '', '')
    assert get_best_parsable_locale(module) == 'C'


# Generated at 2022-06-11 01:11:25.846621
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    # mock is not available for python3
    if getattr(test_get_best_parsable_locale, 'mock_module', None) is None:
        from ansible.module_utils.six.moves import mock
        test_get_best_parsable_locale.mock_module = mock.Mock(wraps=AnsibleModule)
    mock_module = AnsibleModule.mock_module
    mock_module.run_command.return_value = (0, 'C\nen_US.UTF-8', '')

# Generated at 2022-06-11 01:11:27.714163
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale = get_best_parsable_locale(None)
    assert locale == 'C'

# Generated at 2022-06-11 01:11:41.928591
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    def get_bin_path(binary):
        if binary == "locale":
            return sys.executable
        return None

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )

    module.get_bin_path = get_bin_path

    rc, out, err = module.run_command([module.get_bin_path("locale"), '-a'])
    available = out.strip().splitlines()
    for pref in ['C.utf8', 'en_US.utf8', 'C', 'POSIX']:
        if pref in available:
            best_parsable_locale = get_best_pars

# Generated at 2022-06-11 01:11:49.162172
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    # Set use_inclusive_locale to True
    def _run_command(args):
        command = args[0]
        if command == 'locale':
            if args[1] == '-a':
                return (0, 'C.utf8\nPOSIX\nen_US.utf8\nC\n', '')
        return (0, '', '')
    module = AnsibleModule(argument_spec={}, check_invalid_arguments=False)
    module._ansible_version = 'HEAD'
    module.run_command = _run_command

    # When locale tool is present and locale *a* is successfull, it should
    # return first locale which is C.utf8

# Generated at 2022-06-11 01:12:00.125491
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    from ansible.module_utils import basic
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.callback import CallbackBase

    class AnsibleModule:
        def __init__(self):
            self.e = None

        def fail_json(self, **kwargs):
            print(kwargs)
            self.e = kwargs['msg']


# Generated at 2022-06-11 01:12:11.673991
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    # The module parse_lsblk makes use of the list of locales
    module = AnsibleModule(argument_spec=dict())
    rc, out, err = module.run_command(['locale', '-a'])
    if rc == 0:
        available_i18n_locales = out.strip().splitlines()
    else:
        available_i18n_locales = []


# Generated at 2022-06-11 01:12:23.104923
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.basic import AnsibleModule

    # Test the defaults
    module = AnsibleModule(
        argument_spec=dict()
    )
    assert get_best_parsable_locale(module) == 'C'

    # Test the first of two preferred locales are set
    module = AnsibleModule(
        argument_spec=dict()
    )
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C']) == 'en_US.utf8'

    # Test the second of two preferred locales is set
    module = AnsibleModule(
        argument_spec=dict()
    )

# Generated at 2022-06-11 01:12:34.163569
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-11 01:12:42.649508
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = FakeAnsibleModule()

    # preferred locale list
    module.run_command_result = (0, 'POSIX\nC\nC.utf8\nC.utf8.utf8\nC.utf8.utf8.utf8', '')
    assert get_best_parsable_locale(module, ['C.utf8', 'POSIX']) == 'C.utf8'

    module.run_command_result = (0, 'POSIX\nC\nC.utf8\nC.utf8.utf8\nC.utf8.utf8.utf8', '')
    assert get_best_parsable_locale(module, ['POSIX', 'C.utf8']) == 'POSIX'

    # default preferred locale list

# Generated at 2022-06-11 01:12:54.372080
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    if sys.version_info < (2, 7):
        # Import for unittest2
        import unittest2 as unittest
    else:
        import unittest

    from ansible.module_utils.common.text.utils import get_best_parsable_locale

    class AnsibleTestModule(object):

        def __init__(self):
            self.run_command_results = {}
            self.result = {}

        def get_bin_path(self, name, required=False):
            return '/usr/bin/%s' % name


# Generated at 2022-06-11 01:13:01.483749
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeModule:
        class FakeAnsibleModule:
            class FakeRunCommand:
                returncode = 0
                stdout = 'C\nen_US\nen_US.utf8\nfr_FR\nfr_FR.utf8\nPOSIX'
                stderr = ''
            def __init__(self):
                self.run_command = self.FakeRunCommand()
        def __init__(self):
            self.ansibleModule = self.FakeAnsibleModule()
        # Pre-defined locale list - To be returned by the test
        def get_bin_path(self, cmd):
            return cmd
    # Run the test with following argument list
    # 1. Raise exception on not being able to find the locale
    # 2. Raise exception on not being able to find the locale & No preference list
    # 3.

# Generated at 2022-06-11 01:13:08.870478
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec=dict(), supports_check_mode=False)

    result = get_best_parsable_locale(module, preferences=['POSIX', 'C'])
    assert result == 'POSIX' or result == 'C'

    result = get_best_parsable_locale(module, preferences=['not-existent-locale'])
    assert result == 'C'

# Generated at 2022-06-11 01:13:22.985608
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    # Use C locale
    if get_best_parsable_locale(module) != 'C':
        raise Exception('get_best_parsable_locale should return C by default')

    # Use POSIX locale
    if get_best_parsable_locale(module, ['POSIX', 'C.utf8', 'C']) != 'POSIX':
        raise Exception('get_best_parsable_locale should return POSIX')

# following code is for unit testing and is not run when
# module is included

# Generated at 2022-06-11 01:13:26.618417
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # import module snippets
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    # test a variety of valid locale preferences
    module.set_command_resul

# Generated at 2022-06-11 01:13:30.388082
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    try:
        m = AnsibleModule()
        assert get_best_parsable_locale(m) == 'C'
    except ImportError:
        # Avoid masking the exception thrown when importing AnsibleModule
        pass

# Generated at 2022-06-11 01:13:41.510846
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Mock the AnsibleModule class
    class MockedModule:
        class MockedRunCommand:
            def __init__(self, rc=0, out='en_US.utf8', err=''):
                self.rc = rc
                self.out = out
                self.err = err

            def run_command(self, command, check_rc=True, close_fds=True, executable=None, data=None):
                return self.rc, self.out, self.err

        class MockedGetBinPath:
            def __init__(self, path='/usr/bin/locale'):
                self.path = path

            def get_bin_path(self, bin, required=False):
                return self.path

        run_command = MockedRunCommand()
        get_bin_path = MockedGetB

# Generated at 2022-06-11 01:13:43.351469
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None)  == "C"

# Generated at 2022-06-11 01:13:51.094526
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    locales = module.get_bin_path("locale")

    if not locales:
        module.fail_json(msg="Cannot find 'locale' tool in PATH for unit test")

    # Typical locale -a output
    locale_a_output = '''C
en_US.utf8
POSIX
'''
    # Typical locale -a output with extended information
    locale_va_output = '''C
C.utf8
en_US.utf8
POSIX
'''

    # We have en_US.utf8
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'en_US.utf8'

    # We do not have the

# Generated at 2022-06-11 01:14:02.196444
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3, StringIO

    # Create a custom AnsibleModule that can run locale in various scenarios
    class TestModule(AnsibleModule):
        def __init__(self):
            self.run_count = 0
            self.out_val = StringIO()
            self.rc_val = 0
            self.err_val = StringIO()

        def run_command(self, cmd):
            cmd[0] = 'locale'
            self.run_count += 1


# Generated at 2022-06-11 01:14:11.646471
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    locale = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())
    locale.get_bin_path = lambda x: '/usr/bin/locale'
    locale.run_command = lambda x: (0, 'abc\nC\n', '')
    assert get_best_parsable_locale(locale, ['C']) == 'C'
    assert get_best_parsable_locale(locale, ['C', 'C.utf8']) == 'C'

    locale.run_command = lambda x: (0, 'abc\nC\nC.UTF-8\n', '')
    assert get_best_parsable_locale(locale, ['C']) == 'C'
    assert get_best_p

# Generated at 2022-06-11 01:14:23.307311
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.utils.module_docs_fragments
    from ansible.modules.system import locale_gen
    from ansible.module_utils.six import PY3

    # Use the first preference if available
    preferences = ['en_US.utf8', 'C']
    locale = locale_gen._get_best_parsable_locale(None, preferences)
    assert locale == preferences[0]

    # Use the second preference if the first is not available
    preferences = ['fr_FR.utf8', 'C']
    locale = locale_gen._get_best_parsable_locale(None, preferences)
    assert locale == preferences[1]

    # Use the first preference if available
    preferences = ['fr_FR.utf8', 'C']
    locale = locale_gen._get_best_parsable_loc

# Generated at 2022-06-11 01:14:32.927535
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' testcases for get_best_parsable_locale '''

    class MockModule(object):
        ''' fake module '''
        def __init__(self, out=None, err=None, rc=0):
            self._out = out
            self._err = err
            self._rc = rc

        def get_bin_path(self, _):
            ''' fake the _ansiballz_wrapper '''
            return '/usr/bin/mock_locale'

        def run_command(self, _):
            ''' fake the _ansiballz_wrapper '''
            return self._rc, self._out, self._err

    locale_out = '''
C
POSIX
en_US.utf8
'''
    default_out = '''
C
POSIX
'''

   

# Generated at 2022-06-11 01:14:57.295385
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import sys
    import os
    import tempfile
    import shutil

    class TestModule:

        def __init__(self):
            self.params = dict(
                IGNORE_LOCALE=False
            )
            self.check_mode = False
            self.debug = False

        def get_bin_path(self, tool, required=False, opt_dirs=[]):
            if tool == 'locale':
                return os.path.join('test', tool)
            return shutil.which(tool)


# Generated at 2022-06-11 01:15:03.573706
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class MockModule(object):

        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd):
            out = '''C
en_US.utf8
POSIX'''
            return (0, out, '')

    test_module = MockModule()

    assert 'en_US.utf8' == get_best_parsable_locale(test_module, ['en_US.utf8', 'en_US.UTF8'])
    assert 'C' == get_best_parsable_locale(test_module)

# Generated at 2022-06-11 01:15:15.248468
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    This is a unit test for the get_best_parsable_locale function to ensure
    it gets the expected output.
    '''

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    import os

    mock_module = AnsibleModule({'name': 'test'})
    mock_module.run_command = basic._ANSIBLE_ARGS.get('module_stub_for_tests', 'basic.run_command')

    locale_data = [
        'C',
        'C.UTF-8',
        'de_DE.utf8'
    ]

    available_locales_location = '/tmp/available.locales'

# Generated at 2022-06-11 01:15:17.235125
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:15:20.781942
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'



# Generated at 2022-06-11 01:15:30.875493
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    assert get_best_parsable_locale(module, preferences=['C.utf8', 'fr_FR.UTF-8', 'C']) == 'C.utf8', \
        "get_best_parsable_locale doesn't return the first match in the preferred locales list"

    assert get_best_parsable_locale(module, preferences=['fr_FR.UTF-8', 'en_US.UTF-8', 'C']) == 'en_US.UTF-8', \
        "get_best_parsable_locale doesn't return the first match in the preferred locales list"

    assert get_best_pars

# Generated at 2022-06-11 01:15:37.620660
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.modules.system import locale_gen
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import iteritems

    module = AnsibleModule(argument_spec={})
    result = locale_gen.check_locale(module)
    if result[0]:
        assert get_best_parsable_locale(module) in result[1]
    else:
        assert get_best_parsable_locale(module) in 'POSIX'

# Generated at 2022-06-11 01:15:45.582244
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test with module_utils/basic.py
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import b
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import PY3

    def run_command(args, check_rc=True, close_fds=True, executable=None, data=None):
        stdout = b('C\nen_US.utf8')

        if args[0] == b('locale'):
            return 0, stdout, b('')

        return 1, stdout, b('unkown command')

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    module.run_command = run_command

    assert run_

# Generated at 2022-06-11 01:15:55.693049
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    module = AnsibleModule()

    # Verifying locale CLI
    locale_cli = module.get_bin_path("locale")
    if locale_cli is None:
        return 1
    rc, out, err = module.run_command([locale_cli, '-a'])
    assert rc == 0, out

    # Verifying the default, which is 'C'
    found = get_best_parsable_locale(module)
    assert found == 'C', "Default locale should be 'C' but got '%s' instead" % found

    # Verifying locale CLI
    locale_cli = module.get_bin_path("locale")

# Generated at 2022-06-11 01:16:04.585380
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    test_mod_1 = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict()
    )

    assert isinstance(get_best_parsable_locale(test_mod_1, None, True), str)
    assert isinstance(get_best_parsable_locale(test_mod_1, ['en_US.utf8'], True), str)
    assert isinstance(get_best_parsable_locale(test_mod_1, ['en_US.utf8', 'abc'], True), str)
    assert isinstance(get_best_parsable_locale(test_mod_1, ['abc', 'def', 'ghi'], True), str)

# Generated at 2022-06-11 01:16:26.320921
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Test function get_best_parsable_locale
    """
    def test_run_command(self, args, check_rc=None, close_fds=True, executable=None, data=None, binary_data=False):
        if args[1] == '-a':
            # return a list of available locales
            return (0, 'C.utf8\nen_US.utf8\nC\nPOSIX', None)
        else:
            # return the requested locale
            return (0, args[1], None)

    import ansible.module_utils.basic
    import ansible.module_utils.six
    class TestAnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.result = {}

# Generated at 2022-06-11 01:16:36.228545
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from collections import namedtuple

    MockModule = namedtuple('MockModule', ['run_command', 'get_bin_path'])
    MockBinary = namedtuple('MockBinary', ['rc', 'out', 'err'])

    output = os.linesep.join([
        'C',
        'C.UTF-8',
        'en_US.utf8',
        'POSIX',
    ])

    binary = MockBinary(0, output, "")
    module = MockModule(lambda x: binary, lambda: "/usr/bin/locale")

    locale = get_best_parsable_locale(module, preferences=['en_US.utf8'])
    assert locale == 'en_US.utf8'

    locale = get_best_parsable_locale(module)

# Generated at 2022-06-11 01:16:45.790450
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def get_bin_path(name, **kwargs):
        if name == "locale":
            return True
        else:
            return False

    module_args = {}
    am = AnsibleModule(argument_spec=module_args)
    am.get_bin_path = get_bin_path

    # Successful run with a specific set of locales
    am.run_command = lambda x, **kwargs: (0, "C\nC.UTF-8\nC.utf8\nen_US.UTF-8\nen_US.utf8\nPOSIX\n", "")
    locale_name = get_best_parsable_locale(am, preferences=['en_US.utf8', 'C.utf8'])
    assert locale_

# Generated at 2022-06-11 01:16:51.056037
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    print('Testing get_best_parsable_locale')

    preferences = ['en_US.utf8', 'en_CA.utf8', 'C.utf8']
    found = get_best_parsable_locale(preferences=preferences)
    print('Found: ' + str(found))

    preferences = ['en_US.utf8', 'en_CA.utf8', 'C.utf8']
    found = get_best_parsable_locale(preferences=preferences)
    print('Found: ' + str(found))

# Generated at 2022-06-11 01:17:00.268851
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.modules.system.setup import setup
    import ansible.module_utils.basic as basic_module

    module = basic_module.AnsibleModule(
        argument_spec=setup.argspec,
    )

    # test if an exception is raised due to not finding locale
    # function returns 'C' in this case
    res = get_best_parsable_locale(module)
    assert res == 'C'

    # test if an exception raised due to locale CLI issues
    module = basic_module.AnsibleModule(
        argument_spec={},
    )

    try:
        res = get_best_parsable_locale(module, raise_on_locale=True)
    except Exception:
        res = True

    assert res is True

    # test the case when preferred locale found
    module

# Generated at 2022-06-11 01:17:09.010277
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test function get_best_parsable_locale with various
        outputs and make sure we get the desired locale
    '''

    from ansible.module_utils.basic import AnsibleModule

    test_string = None

    # in this case we want 'en_US.utf8'
    locale_a = ("en_US.utf8\n"
                "C\n"
                "POSIX\n"
                "C.utf8\n")
    test_string = locale_a
    module_a = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module_a, None) == 'en_US.utf8'

    # in this case we want 'C'

# Generated at 2022-06-11 01:17:18.841373
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import json
    import sys

    from ansible.module_utils.common.process import get_bin_path as AnsibleModule_get_bin_path
    from ansible.module_utils.common.process import get_bin_path_input_args as AnsibleModule_get_bin_path_input_args
    from ansible.module_utils.common.process import _clean_args as AnsibleModule__clean_args
    from ansible.module_utils.common.process import _quote_args as AnsibleModule__quote_args
    from ansible.module_utils.common.process import _build_cmd as AnsibleModule__build_cmd
    from ansible.module_utils.common.process import _executor_impl as AnsibleModule__executor_impl

# Generated at 2022-06-11 01:17:28.626791
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class MockModule:
        def get_bin_path(self, bin_name):
            return ''

        def run_command(self, cmd):
            return (0, '\n'.join(['C', 'POSIX', 'C.UTF-8']), '')

    class MockLocaleModule:
        def get_bin_path(self, bin_name):
            return ''

        def run_command(self, cmd):
            return (0, '', '')

    assert 'C' == get_best_parsable_locale(MockModule())
    assert 'POSIX' == get_best_parsable_locale(MockModule(), ['POSIX', 'en_US.utf8'])

# Generated at 2022-06-11 01:17:35.674929
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule:
        def get_bin_path(self, tool):
            return tool

        def run_command(self, command):
            return 0, '', ''

    class AnsibleModule2:
        def get_bin_path(self, tool):
            return None

        def run_command(self, command):
            return 0, '', ''

    assert get_best_parsable_locale(AnsibleModule(), ['en_US.utf8', 'C']) == 'en_US.utf8'
    assert get_best_parsable_locale(AnsibleModule(), ['en_US.utf8', 'C'], False) == 'en_US.utf8'

# Generated at 2022-06-11 01:17:37.773561
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # import ansible.module_utils.basic as basic
    # basic.AnsibleModule()

    # TODO
    pass

# Generated at 2022-06-11 01:17:59.829728
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import mock
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    class TestGetBestParsableLocale(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(
                argument_spec={},
                supports_check_mode=True)

        @mock.patch('ansible.module_utils.basic.AnsibleModule.get_bin_path')
        @mock.patch('ansible.module_utils.basic.AnsibleModule.run_command')
        def test_locale_not_found(self, _run_command, _get_bin_path):
            _get_bin_path.return_value = None
            result = get_best_parsable_

# Generated at 2022-06-11 01:18:10.771143
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.common.process
    test_module = ansible.module_utils.basic.AnsibleModule
    test_module.get_bin_path = lambda self, x: '/usr/bin/locale'
    test_module.run_command = lambda self, x: (0, 'C\nen_US.utf8\nen_US.UTF-8\nen_US.UTF8\nen_US\nPOSIX\n', '')
    assert get_best_parsable_locale(test_module) is 'C.utf8'

# Generated at 2022-06-11 01:18:16.632409
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule(object):
        def __init__(self):
            self.run_command = run_command_locale_a
    def run_command_locale_a(self, command):
        """
        Mock function of run_command
        """
        return 0, '', ''
    assert get_best_parsable_locale(AnsibleModule()) == 'C'


# Generated at 2022-06-11 01:18:24.875069
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(  # pylint: disable=unused-argument
        argument_spec=dict(),
    )

    # Locale aa_DJ.UTF-8 is supported by my system

# Generated at 2022-06-11 01:18:29.555216
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    requirements = m.get_bin_path("locale")
    if not requirements:
        m.fail_json(msg="locale not found in PATH")

    assert(get_best_parsable_locale(m) == 'C')

# Generated at 2022-06-11 01:18:37.207568
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    found = get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'])
    assert found == 'C', 'Unexpected locale for default user'

    found = get_best_parsable_locale(module, preferences=['POSIX', 'C'])
    assert found == 'C', 'Unexpected locale for default user'

    found = get_best_parsable_locale(module, preferences=['en_US.utf8', 'POSIX', 'C'])
    assert found == 'C', 'Unexpected locale for default user'
