

# Generated at 2022-06-11 01:08:38.990418
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, preferences=['c.utf8']) == 'C.utf8'

# Generated at 2022-06-11 01:08:49.374962
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    class TestModule(object):
        def __init__(self, module):
            self._ansible_module = module

        def get_bin_path(self, tool):
            return 'locale'

        def run_command(self, cmd):
            if cmd[1] != '-a':
                raise RuntimeError("Unexpected command: %s" % cmd)

            res = [0, '', '']

            if cmd[2] == '-unknown-option':
                res[1] = to_bytes('locale: unknown option -- %s\n' % cmd[2])
                res[2] = to_bytes('Try "locale -a" for a list of supported locales.\n')


# Generated at 2022-06-11 01:08:56.461052
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils.common._collections_compat import MutableMapping
    except ImportError:
        return False

    # Create as close of an approximation as possible of an AnsibleModule
    class AnsibleModuleMock(MutableMapping):
        def __init__(self):
            self._data = dict()
            self.params = dict()

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/locale'

        def run_command(self, *args, **kwargs):
            if args[0][0] == '/usr/bin/locale':
                out = 'en_US.utf8\nC.utf8\nC\nPOSIX\n'

# Generated at 2022-06-11 01:09:04.724343
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test version of get_best_parsable_locale that is
    available for unit testing this code.
    '''

    import sys

    class FakeModule(object):
        '''
        fake ansible module to use in testing this code.
        '''

        @staticmethod
        def get_bin_path(name):
            return name

        @staticmethod
        def run_command(cmd):
            if cmd[1] != '-a':
                return -1, '', 'fake module error testing %s' % ' '.join(cmd)

            if sys.version_info[0] == 3:
                return 0, '\n'.join(['C.utf8', 'C.UTF-8', 'C', 'POSIX']), ''

# Generated at 2022-06-11 01:09:15.483429
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Testing function get_best_parsable_locale
        with different input lists
    '''

    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(argument_spec={})
    test_module.exit_json = lambda **kwargs: kwargs

    assert get_best_parsable_locale(test_module) == 'C'

    preferences = ['C', 'C.utf8']
    assert get_best_parsable_locale(test_module, preferences=preferences) == 'C'
    preferences = ['C.utf8', 'C']
    assert get_best_parsable_locale(test_module, preferences=preferences) == 'C'

# Generated at 2022-06-11 01:09:18.872051
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:09:29.151199
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    import lib_locale
    import ansible.module_utils.basic
    if sys.version_info[0] == 3:
        file_type = io.TextIOWrapper
    else:
        file_type = file

    am = ansible.module_utils.basic.AnsibleModule(
    argument_spec = dict(),
    )

    # set environment variables for tests
    env = dict(os.environ)
    env.update({'LC_ALL': 'C'})  # test that it uses priorities over LC_ALL
    am.run_command_environ_update = env.copy()


# Generated at 2022-06-11 01:09:40.113754
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    LOCALE_4_4 = """
c
C.UTF-8
de_DE.utf8
en_US.utf8
en_US.UTF-8"""

    LOCALE_6_2 = """
C.utf8
en_US.utf8
POSIX"""

    LOCALE_10_0 = """
C
POSIX"""

    LOCALE_10_11 = """
de_DE.utf8
en_US.utf8"""

    PREFERENCES = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    class MyMock(object):
        def __init__(self, rc, out):
            self.rc = rc
            self.stdout = out

# Generated at 2022-06-11 01:09:49.374376
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Result from MacOS

# Generated at 2022-06-11 01:09:59.449087
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = MockModule()
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.UTF-8']) == 'C'
    assert get_best_parsable_locale(module, preferences=['C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX']) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C.utf8']) == 'C'

# Generated at 2022-06-11 01:10:14.653535
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys
    import tempfile
    import shutil
    import filecmp

    # Start with a fixture
    base = tempfile.mkdtemp()
    fixtures = os.path.join(os.path.dirname(__file__), 'fixtures')
    if sys.version_info < (3,):
        filecmp = filecmp.dircmp(fixtures, base)
        for name in filecmp.left_only:
            src = os.path.join(fixtures, name)
            dst = os.path.join(base, name)
            if os.path.isdir(src):
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)

    # Import our module
    sys.path.insert(0, base)

# Generated at 2022-06-11 01:10:24.515838
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import Namespace

    def fail_json(*args, **kwargs):
        assert False, 'fail_json should not be called'

    def exit_json(*args, **kwargs):
        assert False, 'exit_json should not be called'

    class FakeModule:
        arguments = {'locale': None}

        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            fail_json(*args, **kwargs)

        def exit_json(self, *args, **kwargs):
            exit_json(*args, **kwargs)


# Generated at 2022-06-11 01:10:35.973545
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    global _module
    _module = FakeAnsibleModule()

    assert get_best_parsable_locale(_module) == 'C'

    assert get_best_parsable_locale(_module, ['C', 'POSIX']) == 'C'

    _module.run_command_rc = 1
    assert get_best_parsable_locale(_module) == 'C'

    _module.run_command_rc = 0
    _module.run_command_out = ""
    assert get_best_parsable_locale(_module) == 'C'

    _module.run_command_rc = 0
    _module.run_command_out = "en_IN\nen_US\nen_GB\nen_CA"

# Generated at 2022-06-11 01:10:43.424979
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # fake module with get_bin_path, run_command
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    # mock run_command
    module.run_command = lambda x: (0, "C", "")
    assert get_best_parsable_locale(module) == 'C'


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-s'])

# Generated at 2022-06-11 01:10:52.621946
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.run_command = mock_run_commands
    module.get_bin_path = mock_get_bin_path
    assert module.get_bin_path("locale")
    assert get_best_parsable_locale(module) == 'en_US.utf8'
    assert get_best_parsable_locale(module, ['en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, ['en_GB.utf8', 'en_US.utf8']) == 'en_US.utf8'

# Generated at 2022-06-11 01:11:04.266852
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    def run_command(*args, **kwargs):
        command = args[0]
        if command == ['locale']:
            raise RuntimeWarning("Mocked exception.")
        elif command == ['locale', '-a']:
            return 0, "am_ET.utf8\nC.utf8\nen_US.utf8\nC", ""
        return None, None, None

    module_mock = AnsibleModule('test-mod')
    module_mock.run_command = run_command
    module_mock.get_bin_path = lambda x: "locale"

# Generated at 2022-06-11 01:11:13.101320
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Testing with module.run_command properly mocked.
    from ansible.module_utils.basic import AnsibleModule
    import mock
    
    # Importing this module within the test function circumvents the
    # setuptools import hooks.
    from ansible import constants as C

    module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(type='list'),
        )
    )
    module.params['preferences'] = ['fake1', 'fake2', 'fake3']

    # Two cases, one for success, one for failure

# Generated at 2022-06-11 01:11:22.558859
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    # no preferences
    assert get_best_parsable_locale(module) == 'C'

    # no preferences, with raise_on_locale
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

    # with preferences
    assert get_best_parsable_locale(module, preferences=['C', 'POSIX', 'en_US.utf8']) == 'C'

    # with preferences and raise_on_locale
    assert get_best_parsable_locale(module, preferences=['C', 'POSIX', 'en_US.utf8'], raise_on_locale=True) == 'C'



# Generated at 2022-06-11 01:11:30.055839
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os

    from ansible.module_utils.basic import AnsibleModule

    class StubModule:
        def fail_json(self, **kwargs):
            pass

        def get_bin_path(self, executable):
            if os.name == 'posix':
                return executable
            return None

        def run_command(self, command):
            if os.name == 'posix':
                return 0, os.environ.get('LANG', ''), None
            return 0, '', None

    assert get_best_parsable_locale(StubModule()) == 'C'

# Generated at 2022-06-11 01:11:39.999296
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test that get_best_parsable_locale returns the first preferred locale
        available, or the default 'C' if none found.
    '''
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    # test None preferences, expect 'C'
    found = get_best_parsable_locale(module)
    assert found == 'C'

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX', 'en_US.ISO8859-1']

    # test preferences with None, expect 'C'

# Generated at 2022-06-11 01:11:56.076736
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(preferences=preferences) == 'C'

# Generated at 2022-06-11 01:11:58.454335
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test function get_best_parsable_locale
    '''
    from ansible.module_utils.facts.utils.get_locale import get_best_parsable_locale
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    locale = 'C'
    assert locale == get_best_parsable_locale(module=None, preferences=preferences, raise_on_locale=True)

# Generated at 2022-06-11 01:12:03.364582
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic as basic

    module = basic.AnsibleModule(
        argument_spec=dict(),
    )

    found = get_best_parsable_locale(module, ['I_dont_exist', 'C'])

    assert found == 'C', 'Expected returned locale to be C'

# Generated at 2022-06-11 01:12:14.963506
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # check to see that all of the defaults work fine
    module.get_bin_path = lambda *args: '/bin/locale'
    module.run_command = lambda *args: (0, "en_US.UTF-8\nanother_locale\nC\nen_US.utf8\nanother\n", "")
    assert get_best_parsable_locale(module) == 'C.utf8'

    # test to make sure we handle the case where locale is not available
    module.get_bin_path = lambda *args: None

# Generated at 2022-06-11 01:12:20.758282
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['dummy']) == 'C'
    assert get_best_parsable_locale(module, ['C']) == 'C'

# Generated at 2022-06-11 01:12:27.987365
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Fake ansible module arguments
    module_args = {
        "fake_argument": "fake_value",
    }
    class AnsibleModule:
        def __init__(self, arg, **kw):
            self.result = {"changed": False, "rc": 0, "ansible_facts": {}, "failed": False}
            self.run_command_map = {
                ('locale', '-a'): (0, "C\nen_US.utf8\nen_US.UTF-8\nen_US\nen_GB.utf8\nen_GB.UTF-8\nen_GB\nc", ""),
            }

        def run_command(self, args):
            out = self.run_command_map.get(tuple(args), (1, "", ""))
            return out


# Generated at 2022-06-11 01:12:39.191256
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test function for testing get_best_parsable_locale
    '''

    import os
    import tempfile
    import sys

    tempd = tempfile.gettempdir()

    # call the function
    locale = get_best_parsable_locale(None)
    assert locale == 'C'

    # now create a locale file
    open(os.path.join(tempd, 'en_US.utf8'), 'w').close()
    open(os.path.join(tempd, 'not_en_US.utf8'), 'w').close()

    # set the environment up
    os.environ['LC_ALL'] = 'en_US.utf8'
    os.environ['LANGUAGE'] = 'en_US.utf8'

# Generated at 2022-06-11 01:12:51.515904
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test get_best_parsable_locale function
    '''
    import ansible.module_utils.basic as module_basic

    # test case 1
    module = module_basic.AnsibleModule(
        argument_spec=dict(),
    )
    locale = get_best_parsable_locale(module, preferences=None, raise_on_locale=False)
    assert isinstance(locale, str)

    # test case 2
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    module = module_basic.AnsibleModule(
        argument_spec=dict(),
    )
    locale = get_best_parsable_locale(module, preferences, raise_on_locale=False)

# Generated at 2022-06-11 01:12:59.827410
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    test_cases = [
        # test case 1
        {
            'preferences': [],
            'return_value': 'C'
        },
        # test case 2
        {
            'preferences': ['C'],
            'return_value': 'C'
        },
        # test case 3
        {
            'preferences': ['POSIX'],
            'return_value': 'C'
        },
    ]


# Generated at 2022-06-11 01:13:11.269150
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    bin_path_results = {
        'locale': '/usr/bin/locale',
        'locale_not_in_path': None
    }


# Generated at 2022-06-11 01:13:47.997204
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeModule:
        def __init__(self, out, rc=0):
            self.out = out
            self.rc = rc

        def get_bin_path(self, command):
            return '/usr/bin/locale'

        def run_command(self, command):
            return self.rc, self.out, None

    class FakeModuleNoLocale:
        def __init__(self, out, rc=0):
            self.out = out
            self.rc = rc

        def get_bin_path(self, command):
            return None

        def run_command(self, command):
            return self.rc, self.out, None

    class NoLocale:
        def __init__(self, rc=0):
            self.rc = rc


# Generated at 2022-06-11 01:13:58.418045
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # If locale tool found, return in this order
    # 'C.utf8', 'en_US.utf8', 'C', 'POSIX'
    # If locale tool not found, return 'C'
    # If locale tool fails, return 'C'
    # If locale tool returns no locales, return 'C'
    # If locale tool returns an incomplete locale, return 'C'

    # dummy AnsibleModule object
    mod = AnsibleModule(argument_spec=dict())

    # locale tool found, no locales
    mod.run_command = lambda x: (0, "", "")
    out = get_best_parsable_locale(mod)
    assert out == 'C'

    # locale tool found, C.utf8 available
    mod.run_command

# Generated at 2022-06-11 01:14:09.173791
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test to make sure it returns 'C' if the locale binary does not exist
    # this is technically a race condition though as the module could be installed
    # as part of the setup.  So we're really just making sure it handles the
    # return code and output properly.
    # We have to use a special class so we can set the module's bin_path which would
    # otherwise not be set in a unit test

    from ansible.module_utils.basic import AnsibleModule, get_bin_path

    class TestModule(AnsibleModule):
        def __init__(self):
            AnsibleModule.__init__(self, argument_spec=dict())
            self.bin_path = get_bin_path('/usr/bin:/bin:/usr/sbin:/sbin')


# Generated at 2022-06-11 01:14:19.355058
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    args = dict(
        preferences=['en_US.utf8', 'C', 'POSIX'],
        raise_on_locale=True,
    )

    class MockModule:
        pass

    module = MockModule()
    module.get_bin_path = lambda x: x
    module.run_command = lambda x: 0, '', ''

    if not get_best_parsable_locale(module, **args):
        raise AssertionError('Expected True got False')

    # It should raise exception
    args['raise_on_locale'] = False

    try:
        get_best_parsable_locale(module, **args)
    except Exception:
        raise AssertionError('Expected False got True')

if __name__ == '__main__':
    test_get_best

# Generated at 2022-06-11 01:14:30.128894
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # make sure we can import these
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        raise AssertionError("Could not import AnsibleModule. Cannot proceed")

    # can't create instance of AnsibleModule without a stub
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # try with an invalid locale, should fallback to C
    assert get_best_parsable_locale(module, ['foo']) == 'C'

    # try with a valid locale
    assert get_best_parsable_locale(module, ['POSIX']) == 'C'
    assert get_best_parsable_locale(module, ['en_US.utf8']) == 'en_US.utf8'

# Generated at 2022-06-11 01:14:36.876071
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic as module
    # Returns C as default
    assert('C' == get_best_parsable_locale(module))

    # Returns POSIX which exists in this list
    assert('POSIX' == get_best_parsable_locale(module, ['POSIX', 'C.UTF-8'], True))

    # Returns C.UTF-8 which exists in this list
    assert('C.UTF-8' == get_best_parsable_locale(module, ['POSIX', 'C.UTF-8'], False))

    # Returns C as POSIX does not exist in this list
    assert('C' == get_best_parsable_locale(module, ['POSIX', 'C.UTF-8'], True))

    # Returns C.UTF-8 as only it exists in

# Generated at 2022-06-11 01:14:46.560314
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    class MyModule(AnsibleModule):
        def __init__(self):
            super(MyModule, self).__init__(argument_spec={}, supports_check_mode=False)

        def get_bin_path(self, name):
            return '/usr/bin/locale'

        def run_command(self, args):
            if args[-1] == '-a':
                return (0, 'C\nen_US.utf8\nC\nPOSIX', None)
            else:
                return (0, 'LANG=en_US.utf8', None)

    new_module = MyModule()


# Generated at 2022-06-11 01:14:56.910664
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cStringIO as StringIO
    import sys

    _old_stdout = sys.stdout
    _old_stderr = sys.stderr
    sys.stdout = StringIO()
    sys.stderr = StringIO()

    am = AnsibleModule(supports_check_mode=False)

    def run_command_tests(arg, expected):
        try:
            am.run_command(arg)
            assert False, "should have raised"
        except Exception as e:
            assert "No output from locale, rc=0" in str(e) or "Unable to get locale information, rc=0" in str(e)


# Generated at 2022-06-11 01:15:04.574244
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = None
    import sys
    if sys.version_info[0] == 2:
        try:
            import ansible.module_utils.basic
            module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())
        except ImportError:
            pass

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path

    locale = get_bin_path('locale')
    if not locale:
        return 'SKIP could not find locale'

    rc, out, err = module.run_command([locale, '-a'])
    if rc != 0:
        return 'SKIP locale -a failed'

    out = to_bytes(out)
    available = out.strip().splitlines()

# Generated at 2022-06-11 01:15:15.812236
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.compat.tests.mock import patch, MagicMock

    # test: 'C' is the default or the first preferred
    module = AnsibleModule(argument_spec={})
    locale_path = module.get_bin_path('locale')
    m1 = MagicMock(return_value=(0, 'C', ''))
    with patch.dict(module.ANSIBLE_MODULE_ARGS, {'locale': 'C'}):
        with patch.object(module, 'run_command', m1):
            assert get_best_parsable_locale(module) == 'C'

    # test: 'C' and another preferred is available, return first
    module = AnsibleModule(argument_spec={})
    locale_path = module

# Generated at 2022-06-11 01:16:14.519783
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict(),
    )

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:16:21.415049
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            test_param=dict(type='bool', required=False, default=True)
        )
    )

    choices = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    try:
        ret = get_best_parsable_locale(module, preferences=choices)
    except Exception:
        ret = None
    assert ret == 'C.utf8'

# Generated at 2022-06-11 01:16:27.929741
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(argument_spec={}, supports_check_mode=False)

    # test default preferences param
    best_locale = get_best_parsable_locale(m)
    assert best_locale == 'C'

    # test when locales are available we get one
    m.run_command = lambda cmd: (0, 'C.utf8\nen_US.utf8\nascii\nC\nPOSIX\n', '')
    best_locale = get_best_parsable_locale(m)
    assert best_locale == 'C.utf8'

    # test when preferred locale is not available, it returns first preferred

# Generated at 2022-06-11 01:16:37.894353
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path

    module_mock = AnsibleModule({})
    module_mock.run_command = lambda *args, **kwargs: (0, 'C\nen_US.utf8\n', '')

    locale = get_bin_path(module_mock, "locale")
    if not locale:
        print("Failed to find 'locale' tool")
        return 1

    assert get_best_parsable_locale(module_mock) == 'C'

    module_mock.run_command = lambda *args, **kwargs: (0, 'C\nen_US.utf8\nC\nen_US.utf8\n', '')
    assert get_best

# Generated at 2022-06-11 01:16:47.338811
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os

    # Make it work in both Python2 & Python3
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        from ansible.module_utils.basic import *

    # Fake module for use in unit tests
    class AnsibleModuleFake(object):

        def __init__(self, **kwargs):
            self.params = kwargs
            self.check_mode = False
            self.debug_enabled = False
            self.fail_json = lambda **kwargs: sys.exit(1)
            self.exit_json = lambda **kwargs: sys.exit(0)

        def run_command(self, cmd):
            return (0, "C", "")

        def get_bin_path(self, name):
            return "/bin/" + name

# Generated at 2022-06-11 01:16:56.628195
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # TEST: no locale information
    try:
        module.run_command([])
        assert False
    except RuntimeWarning:
        assert True

    # TEST: no locale, but we catch it and return 'C'
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

    # TEST: no locale, but we catch it and return 'C'
    module.run_command = lambda args: (0, 'C\nen_US\nfr\n', '')
    assert get_best_parsable_locale(module) == 'C'
    assert get_best

# Generated at 2022-06-11 01:16:57.499112
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # TODO: Unit tests
    pass

# Generated at 2022-06-11 01:16:58.420121
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    get_best_parsable_locale()

# Generated at 2022-06-11 01:17:07.582213
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})

    # Check that the default behavior returns the default locale
    try:
        assert get_best_parsable_locale(module) == 'C'
    except RuntimeWarning:
        # There was no locale tool found
        pass

    module.run_command = lambda argv: (0, 'C\nen_US.UTF8', '')
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['en_US.UTF8']) == 'en_US.UTF8'

    module.run_command = lambda argv: (0, 'C\nen_US.UTF8', '')

# Generated at 2022-06-11 01:17:12.539234
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module_args = dict()
    module_args['preferences'] = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
    )

    assert get_best_parsable_locale(module, module_args['preferences']) == 'C'

# Generated at 2022-06-11 01:18:15.413262
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec = dict())
    module.run_command = MagicMock(return_value=(0, "C.utf8\nen_US.utf8\nC\nPOSIX\nanother_lang", ""))

    # First preference should be returned
    assert get_best_parsable_locale(module, preferences=['C']) == 'C'

    # Second preference should be returned when first is not available
    assert get_best_parsable_locale(module, preferences=['first', 'C']) == 'C'

# Generated at 2022-06-11 01:18:23.911380
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ["aa_BB.utf8", "en_US.utf8", "C", "POSIX"]) == "en_US.utf8"
    assert get_best_parsable_locale(None, ["en_US.utf8", "C", "POSIX"]) == "en_US.utf8"
    assert get_best_parsable_locale(None, ["aa_BB.utf8", "C", "POSIX"]) == "C"
    assert get_best_parsable_locale(None, ["ba_BB.utf8", "aa_bb.utf8", "c", "posix"]) == "c"
    assert get_best_parsable_locale(None) == "C"

# Generated at 2022-06-11 01:18:26.018538
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.modules.shell import locale
    assert locale.get_best_parsable_locale({}) == 'C'

# Generated at 2022-06-11 01:18:32.486525
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import json
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    test_module_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'ansible_collections', 'community', 'general', 'plugins', 'modules', 'test_get_best_parsable_locale.py'))

    # These tests are run outside of a running Ansible environment, so we have to fake AnsibleModule
    am = AnsibleModule(argument_spec={})
    am.run_command = lambda args, check_rc=True: (0, None, None)
    am.get_bin_path = lambda *args, **kwargs: test_module_path