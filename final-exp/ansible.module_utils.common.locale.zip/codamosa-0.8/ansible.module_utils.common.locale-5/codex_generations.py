

# Generated at 2022-06-11 01:08:46.123557
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # We are testing a module utility function so let's mock the module.
    # See https://docs.python.org/2/library/unittest.mock.html
    import unittest.mock as mock

    # Mocking a class
    mock_module = mock.Mock()

    # Setting attributes on our mock object
    mock_module.get_bin_path.return_value = '/bin/locale'
    mock_module.run_command.return_value = (0, 'aa_DJ.utf8\nC.utf8\nen_US.utf8\nPOSIX', '')

    # Testing the function
    test_locale = get_best_parsable_locale(mock_module)
    assert test_locale == 'C.utf8'


# Generated at 2022-06-11 01:08:56.070004
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule
    import os

    class TestModule(object):
        def get_bin_path(self, name=None, required=False, opt_dirs=None):
            return get_bin_path(name, required, opt_dirs)

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            (rc, out, err) = os.popen3(args)
            out = out.read()
            err = err.read()
            return (rc, out, err)


# Generated at 2022-06-11 01:09:04.502050
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    mock_m = make_mock_module()
    mock_m.run_command.return_value = tuple([0, 'C\nen_US.utf8\nen_US.utf8', ''])
    assert get_best_parsable_locale(mock_m, raise_on_locale=True) == 'C'

    import mock

    # In order for this to work, we must mock the module to say that we found the `locale` tool
    mock_m.get_bin_path.return_value = '/usr/bin/locale'
    mock_m.run_command.return_value = tuple([0, 'C\nen_US.utf8\nen_US.utf8', ''])


# Generated at 2022-06-11 01:09:11.133505
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    preferences = ['bg_BG.utf8', 'fr_FR.utf8', 'C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(AnsibleModule(), preferences) == 'C.utf8'
    assert get_best_parsable_locale(AnsibleModule(), preferences, raise_on_locale=True) == 'C.utf8'

# Generated at 2022-06-11 01:09:21.247169
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('C') == 'C'
    assert get_best_parsable_locale(['C']) == 'C'
    assert get_best_parsable_locale(['c']) == 'C'
    assert get_best_parsable_locale(['c', 'posix']) == 'C'
    assert get_best_parsable_locale(['c', 'POSIX']) == 'C'
    assert get_best_parsable_locale(['c', 'POSIX', 'POSIX', 'C']) == 'C'
    assert get_best_parsable_locale(['c.utf-8', 'en_US.utf-8', 'POSIX', 'C']) == 'en_US.utf-8'

    #

# Generated at 2022-06-11 01:09:26.758310
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    results = get_best_parsable_locale(module)
    assert(results in preferences)



# Generated at 2022-06-11 01:09:29.056798
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule()
    locale = get_best_parsable_locale(m)
    assert locale == 'C'

# Generated at 2022-06-11 01:09:40.068980
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )

    # do not use required=true as that forces fail_json
    assert module.get_bin_path("locale"), "Could not find 'locale' tool"

    rc, out, err = module.run_command([module.get_bin_path("locale"), '-a'])
    assert rc == 0, "Unable to get locale information, rc=%s: %s" % (rc, to_native(err))
    assert out, "No output from locale, rc=%s: %s" % (rc, to_native(err))

    available = out.strip().splitlines()

# Generated at 2022-06-11 01:09:49.337883
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.display import Display

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path

    display = Display()

    fake_env = os.environ.copy()

    play_context_instance = PlayContext()
    fake_args = {}


# Generated at 2022-06-11 01:09:54.389476
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    This function is meant to be unit tested.
    '''
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(None, preferences=preferences) == 'C'
    assert get_best_parsable_locale(None) == 'C'



# Generated at 2022-06-11 01:10:04.971382
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils
    import ansible.module_utils.basic

    class MyModule(ansible.module_utils.basic.AnsibleModule):
        def __init__(self, locale_path, locale_args, locale_prefs):
            ansible.module_utils.basic.AnsibleModule.__init__(self)
            self.get_bin_path_mock = self.mock_get_bin_path
            self.run_command_mock = self.mock_run_command
            self.locale_bin_path = locale_path
            self.locale_available_locales = locale_args
            self.locale_prefs = locale_prefs
            self.locale_run_command_rc = 0


# Generated at 2022-06-11 01:10:16.060845
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-11 01:10:25.335881
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    # Make sure we have no locale bin in path
    module = AnsibleModule(
        argument_spec={
            'prefs': {
                'type': 'list',
                'required': False,
            },
        },
    )
    # This can throw exception when no locale found
    assert get_best_parsable_locale(module) == 'C'
    # This must return 'C' as no prefs list
    assert get_best_parsable_locale(module, []) == 'C'
    # This should return C.utf8, if available
    assert get_best_parsable_locale(module, ['C.utf8']) == 'C.utf8'
    # This should return C.utf8, if available
    assert get_

# Generated at 2022-06-11 01:10:30.446015
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.common import FAKE_LOADER

    am = AnsibleModule(argument_spec={})

    found = get_best_parsable_locale(am)
    assert found == 'C'

# Generated at 2022-06-11 01:10:38.630620
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Import Ansible internals
    from ansible.module_utils.basic import AnsibleModule

    # Create an Ansible module object
    module = AnsibleModule(
        argument_spec=dict(),
    )

    # Test default behavior
    result = get_best_parsable_locale(module, raise_on_locale=False)
    assert result == 'C'

    # Test proper locale is returned
    result = get_best_parsable_locale(module, ['en_US.utf8'], raise_on_locale=False)
    assert result == 'en_US.utf8'

# Generated at 2022-06-11 01:10:49.071171
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import tempfile
    import locale

    from ansible.module_utils.common._collections_compat import StringIO
    from ansible.module_utils.common.errors import AnsibleModuleError
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # This test needs a locale tool to succeed, but we may not have it available
    # in the environment so create a fake one
    FAKE_LOCALE_SH = (
        '#!/bin/sh\n'
        'echo "en_US.utf8\n'
        'C\n'
        'POSIX"\n'
    )

# Generated at 2022-06-11 01:11:00.273313
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    If module.get_bin_path("locale") returns a path,
    then return the first matched preferred locale in
    the list preferences. Otherwise, return 'C'.
    """

    # Mock module.get_bin_path("locale") to return a path
    import ansible.module_utils
    from ansible.module_utils import basic
    from ansible.module_utils import six
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path

    def dummy_str():
        return 'fake/locale'

    class TestModule(AnsibleModule):
        def __init__(self):
            super(TestModule, self).__init__(argument_spec={})

    # The first matched preferred locale in the list preferences.
    preferences

# Generated at 2022-06-11 01:11:02.383794
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # The function get_best_parsable_locale has no unit tests.
    # TODO: Write unit tests for this.
    assert True

# Generated at 2022-06-11 01:11:07.331454
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    assert 'C' == get_best_parsable_locale(module, raise_on_locale=False)
    assert 'C' == get_best_parsable_locale(module)

# Generated at 2022-06-11 01:11:14.393069
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import mock
    import six

    # Best POSIX locale
    if six.PY3:
        with mock.patch('ansible.module_utils.basic.get_best_parsable_locale.ModuleUtilDebug') as mock_mud:
            mock_mud.return_value = True
            with mock.patch('ansible.module_utils.basic.get_best_parsable_locale.AnsibleModule') as mock_ansmod:
                mock_ansmod.get_bin_path.return_value = "locale"
                mock_ansmod.run_command.return_value = (0, 'a.utf8\nb.utf8\nc.utf8\nC\nPOSIX\n', None)
                result = get_best_parsable_locale(mock_ansmod)

# Generated at 2022-06-11 01:11:30.880509
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import imp
    import json
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence

    test_path = 'tests/module_utils/test_utils_locale.py'
    mod = imp.load_source('ansible.module_utils.test_utils_locale', test_path)

    # Testing for issue #38161
    if sys.version_info[:2] == (2, 6):
        # Load the module with a mock that uses the old call to
        # get_bin_path.
        mod.AnsibleModule = mod.AnsibleModuleOld
        mod.AnsibleModule.get_bin_path = mod.get_bin_path_old

    # Testing for issue #38161

# Generated at 2022-06-11 01:11:40.402349
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    import sys
    import os

    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    # Test case 1: C, C.utf8, POSIX, en_US.utf8 available
    if sys.version_info[0] > 2:
        file_name = os.path.join(os.path.dirname(__file__), 'testcase_get_best_parsable_locale_1.txt')
        with open(file_name, 'r', encoding='utf8') as f:
            testcase_get_best_parsable_locale_1 = f.read()
    else:
        file_name = os

# Generated at 2022-06-11 01:11:48.507904
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class AnsibleModule:
        def __init__(self, **kwargs):
            self.params = kwargs
            self.no_log = "no_log"
            self.verbose = "verbose"
            self.debug = "debug"

        def get_bin_path(self, bin_list):
            if bin_list == "locale":
                return True
            else:
                return False

        def run_command(self, _arg):
            if _arg[1] == '-a':
                return [0, 'C', 'en_US.utf8', 'en_US', 'C', 'en_US.utf8']

    # Case 1:
    # Preferred List: C.utf8, en_US.utf8, C, POSIX
    # Available Locale: C, en_US.utf

# Generated at 2022-06-11 01:11:52.294989
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import pytest

    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)

    assert locale == 'C'



# Generated at 2022-06-11 01:12:01.773786
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class FakeModule:
        def __init__(self):
            self.params = {}

        def fail_json(self, **kwargs):
            assert False, kwargs

        def get_bin_path(self, value, required=False):
            # Cannot use a closure to capture 'fake_locale' in python2.
            if value == 'locale':
                return self.fake_locale
            if required:
                self.fail_json(msg='Binary %s is not installed.' % value)
            else:
                return value


# Generated at 2022-06-11 01:12:11.096242
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    result = get_best_parsable_locale(module)
    assert result == 'C', "Got %s" % result
    result = get_best_parsable_locale(module, preferences=['C', 'en_US.utf8'])
    assert result == 'C', "Got %s" % result
    result = get_best_parsable_locale(module, preferences=['en_US.utf8', 'C'])
    assert result == 'C', "Got %s" % result

# Generated at 2022-06-11 01:12:22.534376
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.text.converters import to_bytes

    class FakeModule(AnsibleModule):
        def __init__(self):
            super(FakeModule, self).__init__()
            self.locale = b'POSIX\nC\nen_US.utf8\nC.utf8\n'

        def get_bin_path(self, name):
            return get_bin_path(name, True, ['/usr/bin'])


# Generated at 2022-06-11 01:12:34.011739
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.modules.system.locale import get_best_parsable_locale

    # Test with no locale binary
    class FakeModule:
        def get_bin_path(self, program):
            return None
        def run_command(self, args):
            raise RuntimeWarning("Unable to get locale information")
    module = FakeModule()
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    result = get_best_parsable_locale(module, preferences, False)
    assert result == 'C'

    # Test with language not found in preferences
    class FakeModule:
        def get_bin_path(self, program):
            return 'locale'

# Generated at 2022-06-11 01:12:42.565784
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_cases = {}
    test_cases[0] = 'C'
    test_cases[1] = 'de_DE.utf8'
    test_cases[2] = 'POSIX'
    test_cases[3] = 'C'
    test_cases[4] = 'en_US.utf8'
    test_cases[5] = 'C'
    test_cases[6] = 'C'

    #test_cases[0]
    # No preferences given.
    # The available locales are C, en_US.utf8, POSIX
    # The expected result is 'C'
    preferences = None
    available = ['C', 'de_DE.utf8', 'POSIX']
    assert get_best_parsable_locale(None,preferences,False) == test_cases[0]

# Generated at 2022-06-11 01:12:54.286195
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):

        def __init__(self):
            self.fail_json = lambda **kwargs: False
            self.params = {}

        def get_bin_path(self, item):
            if item == "locale":
                return "/usr/bin/locale"
            else:
                return False

        def run_command(self, args):
            if args == ['/usr/bin/locale', '-a']:
                return 0, 'ec_EC.utf8\nen_US.iso88591\nen_US.utf8\n', ''
            else:
                return 1, '', ''

    module = TestModule()

# Generated at 2022-06-11 01:13:19.015092
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    locale_list = [
        'C.utf8', 'en_US.utf8', 'C', 'POSIX', 'de_DE.iso88591', 'de_DE@euro', 'de_DE.utf8',
        'de_DE@euro.utf8', 'zh_TW', 'zh_TW.big5', 'zh_TW.eucTW', 'zh_CN.gb2312',
        'zh_CN.gb18030', 'ja_JP.eucJP', 'ja_JP.eucJP'
    ]

# Generated at 2022-06-11 01:13:26.669582
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils import basic
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import shlex_quote

    if PY3:
        from unittest import mock
    else:
        import mock

    #assume we're on a POSIX and don't have any fancy locales
    posix_locales = ['C', 'POSIX']

    # extract returns from our mock
    mock_locale, mock_out, mock_err = mock.MagicMock(), mock.MagicMock(), mock.MagicMock()

    #create a simple fake ansible module
    am = basic.AnsibleModule(argument_spec={})
    am.run_command = mock.Mock(return_value=(0, mock_out, mock_err))

# Generated at 2022-06-11 01:13:37.489442
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys


# Generated at 2022-06-11 01:13:47.535305
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import copy
    import io
    import os
    import tempfile
    import unittest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    class MockAnsibleModule(object):

        def __init__(self, locale=None, locale_a=None, rc=None):
            self._locale = locale
            self._locale_a = locale_a
            self._rc = rc

        def get_bin_path(self, name):
            # we ignore the arg and return what was in the cache
            return self._locale

        def run_command(self, name):
            # we ignore the arg and return what was in the cache
            return self._rc, self._locale_a, None


# Generated at 2022-06-11 01:13:53.431742
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['en-US.utf8']) == 'C'
    assert get_best_parsable_locale(None, ['C.utf8']) == 'C'
    assert get_best_parsable_locale(None, ['en-US.utf8', 'en-US.utf1']) == 'C'
    assert get_best_parsable_locale(None, ['en_US.utf8']) == 'C'

# Generated at 2022-06-11 01:14:05.232871
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class MockModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = """C
C.UTF-8
en_US.utf8
POSIX
zh_CN.CP936
zh_CN.GB18030
zh_CN.GB2312
zh_CN.GBK
zh_CN.UTF-8"""
            self.run_command_err = ""
            self.run_command_failed = False
            self.get_bin_path_rc = 0
            self.get_bin_path_out = "/usr/bin/locale"
            self.get_bin_path_err = ""
            self.get_bin_path_failed = False

        def get_bin_path(self, name):
            return self.get_bin_path

# Generated at 2022-06-11 01:14:13.342577
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Import system module
    import sys

    # Import mock module
    from ansible.module_utils.six.moves import builtins
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock

    # Create module mock
    module = Mock()

    # Create custom fail_json method
    def fail_json_custom(msg):
        print(msg)
        sys.exit(1)

    # Add mock methods
    module.fail_json = fail_json_custom
    module.get_bin_path = Mock(return_value=1)
    module.run_command = Mock()

    # Create first set of results
    results_1 = [0, 'C.utf8', '']

    # Create second set of results
    results_2 = [0, 'C', '']

# Generated at 2022-06-11 01:14:24.695635
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class AnsibleModule:

        def __init__(self, name):
            self.name = name

        def get_bin_path(self, binary):
            if binary == 'locale':
                return 'locale'
            else:
                return ''

        def run_command(self, arguments):
            # rc, out and err are the responses returned by locale -a
            rc = 0
            if self.name == 'test1':
                # POSIX and C locales are present
                out = "POSIX\nC"
                err = ''
            elif self.name == 'test2':
                # no locales available
                out = ''
                err = ''
            else:
                rc = 1
                out = ''
                err = 'Locale not found'

            return rc, out, err

    # POSIX and C

# Generated at 2022-06-11 01:14:26.874803
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(preferences=['en_US.utf8']) == 'C'

# Generated at 2022-06-11 01:14:32.855218
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test the get_best_parsable_locale function
    '''
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={
        }
    )
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.get_bin_path = lambda *args, **kwargs: 'locale'
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:14:53.463944
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale('module', ['fake1_fake2_FA.UTF-8']) == 'C'
    assert get_best_parsable_locale('module', ['fake1_fake2_FA.UTF-8', 'C.UTF-8']) == 'C.UTF-8'
    assert get_best_parsable_locale('module', ['fake1_fake2_FA.UTF-8', 'en_US.UTF-8']) == 'C'

# Generated at 2022-06-11 01:15:02.215439
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''Unit test for function get_best_parsable_locale'''

    import os

    from ansible.module_utils.basic import AnsibleModule

    # Mock class for AnsibleModule.run_command
    class mock_run_command(object):
        '''Mock class for AnsibleModule.run_command'''
        def __init__(self, rc=0, out='', err=''):
            self.rc = rc
            self.out = out
            self.err = err

        def __call__(self, args, check_rc=True, close_fds=True, executable=None, data=None):
            return self.rc, self.out, self.err

    # Mock class for AnsibleModule

# Generated at 2022-06-11 01:15:07.914500
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    # Import the modules under test here
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_best_parsable_locale

    class Test_Best_Parsable_Locale(unittest.TestCase):
        """Test module for best_parsable_locale"""

        # Correct output for locale -a, first part only

# Generated at 2022-06-11 01:15:18.306795
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    if PY3:
        from shlex import quote
    else:
        from pipes import quote

    from ansible.module_utils.common.locales import get_best_parsable_locale
    from ansible.module_utils.common.json import json
    from ansible.module_utils.common.run_command import run_command
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

    module = AnsibleModule(argument_spec={})

    tmp = tempfile.NamedTemporaryFile()

# Generated at 2022-06-11 01:15:20.830549
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert 'C' == get_best_parsable_locale(None)

# Generated at 2022-06-11 01:15:30.905626
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule  # noqa
    from ansible.module_utils.common.locales import get_best_parsable_locale  # noqa

    assert get_best_parsable_locale(AnsibleModule(argument_spec={}, bypass_checks=True)) == 'C'
    assert get_best_parsable_locale(AnsibleModule(argument_spec={}, bypass_checks=True), ['foo']) == 'C'
    assert get_best_parsable_locale(AnsibleModule(argument_spec={}, bypass_checks=True), ['C']) == 'C'
    assert get_best_parsable_locale(AnsibleModule(argument_spec={}, bypass_checks=True), ['POSIX']) == 'C'

# Generated at 2022-06-11 01:15:40.908079
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule:
        def __init__(self, args, debug=False):
            self.debug = debug
            self.params = args['params']
            self.args = args

        def get_bin_path(self, command):
            if self.params['get_bin_path'][0]:
                return self.args['bin_path'][0]
            return None

        def run_command(self, args, check_rc=True):
            # If there was a problem with the command, return an error
            if self.params['find_locale'][0]:
                rc = 0
                msg = self.args['locale'][0]
                err = self.args['locale'][0]
            else:
                rc = 1
                msg = self.args['locale'][0]

# Generated at 2022-06-11 01:15:50.731865
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''

    import os
    import unittest

    from ansible.module_utils.basic import AnsibleModule

    # Simple fake module
    class MockModule(object):

        def __init__(self):
            self.params = {}
            self.debug = True
            self.verbose = True

        def get_bin_path(self, tool, required=False):
            return tool


# Generated at 2022-06-11 01:15:54.412512
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
    )
    assert get_best_parsable_locale(module, raise_on_locale=True) is not None

# Generated at 2022-06-11 01:16:03.896028
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """Test if get_best_parsable_locale returns expected values"""
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule
    class MockAnsibleModule:
        bin = {'locale': '/bin/locale'}
        def __init__(self):
            self.run_command = MockAnsibleModule.MockRunCommand(self)

        def get_bin_path(self, command, required=False):
            return self.bin[command]

        class MockRunCommand:
            def __init__(self, mock_ansible_module):
                self.mock_ansible_module = mock

# Generated at 2022-06-11 01:16:25.059405
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['en_US.utf8']) == 'en_US.utf8', 'en_US.utf8 should be first in the list'
    assert get_best_parsable_locale(None, ['C.utf8']) == 'C.utf8', 'C.utf8 should be just after en_US.utf8'
    assert get_best_parsable_locale(None, ['POSIX']) == 'C', 'POSIX should be just after C.utf8'
    assert get_best_parsable_locale(None, ['C']) == 'C', 'C should be at the end of the list'

# Generated at 2022-06-11 01:16:29.159413
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, ['POSIX', 'C']) == 'C'

# Generated at 2022-06-11 01:16:38.780044
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import random
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    class FakeModule(AnsibleModule):
        def get_bin_path(self, tool):
            return tool

        def run_command(self, cmd):
            return 0, '\n'.join(list(set(self.available))), ''

    if PY2:
        xrange = range

    # create a random list of available locales
    available = ['C', 'POSIX']
    available.extend(['%d%s.utf8' % (i, random.choice(['', '_' + random.choice(['US', 'AU'])])) for i in xrange(30)])

# Generated at 2022-06-11 01:16:48.141830
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class MockAnsibleModule():
        def __init__(self, params):
            self.params = params

        def run_command(self, cmd):
            if not cmd[0] == "locale":
                raise RuntimeError("Unexpected cmd %s" % cmd)
            if self.params[0] == "locale":
                cmd.pop(0)
            if cmd == ['locale', '-a']:
                return (0, self.params[1], "")
            else:
                raise RuntimeError("Unexpected cmd %s" % cmd)

        def get_bin_path(self, cmd):
            if cmd == "locale":
                return self.params[0]
            raise RuntimeError("Unexpected cmd %s" % cmd)

    class MockModuleError(Exception):
        pass


# Generated at 2022-06-11 01:16:57.461123
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class DummyModule(object):
        def get_bin_path(self, name):
            return name
        def run_command(self, cmd):
            return 0, "POSIX\nC\nen_US.utf8\nC.utf8\nC.UTF-8\nen_US.UTF-8", None

    module = DummyModule()
    # default preferences, default locale = C, no exception
    assert "C" == get_best_parsable_locale(module)
    # default preferences, default locale = C, exception does not raise
    assert "C" == get_best_parsable_locale(module, raise_on_locale=True)
    # default preferences, default locale = C, exception does raise

# Generated at 2022-06-11 01:17:03.651688
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class Module:
        def __init__(self):
            self.params = {}
        def get_bin_path(self, bin):
            return 'locale'

        def run_command(self, command):
            if command == ['locale', '-a']:
                return (0, 'C\nC.UTF-8\nPOSIX\n', '')
            else:
                raise Exception("Unsupported command %s" % command)
    module = Module()
    assert get_best_parsable_locale(module) == 'POSIX'

# Generated at 2022-06-11 01:17:11.681498
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Setup a test module
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: '/usr/bin/locale'

    # Mocking run_command
    def run_command(cmd):
        if cmd == ['/usr/bin/locale', '-a']:
            return (0, 'C.UTF-8', '')
        else:
            return (1, '', 'unmocked command: {0}'.format(cmd))
    module.run_command = run_command

    # Test default values
    assert(get_best_parsable_locale(module) == 'C.UTF-8')

    # Test preferred values

# Generated at 2022-06-11 01:17:22.080860
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Create some data to use in the tests
    class Options:
        def __init__(self, remote_tmp=None, remote_user=None, connection=None, module_path=None,
                     forks=None, become=None, become_method=None, become_user=None, check=None,
                     diff=None, syntax=None, start_at_task=None):
            self.remote_tmp = remote_tmp
            self.remote_user = remote_user
            self.connection = connection
            self.module_path = module_path
            self.forks = forks
            self.become = become
            self.become_method = become_method
            self.become_user = become_user
            self.check = check
            self.diff = diff

# Generated at 2022-06-11 01:17:31.389493
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def test_locale(module, result):
        assert get_best_parsable_locale(module) == result

    # Mock an AnsibleModule object
    module = AnsibleModule(argument_spec=dict())
    module.run_command = lambda command: (0 if command[1] == '-a' else 1,
                                          'en_US.UTF-8\nen_US.utf8\nC', '')

    test_locale(module, 'en_US.utf8')

    module.run_command = lambda command: (0 if command[1] == '-a' else 1,
                                          'POSIX\nC\nen_US.UTF-8\nen_US.utf8', '')

# Generated at 2022-06-11 01:17:40.930022
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os

    class FakeModule:

        def __init__(self, name, path):
            self.name = name
            self.path = path

        def get_bin_path(self, name):
            return os.path.join(self.path, self.name)

        def run_command(self, cmd):
            if cmd[0] == 'locale':
                if self.name == 'locale':
                    return 0, 'C\nen_US\nen_US.utf8\nzh_CN.utf8\n', ''
                else:
                    return 1, '', 'locale: command not found'
            else:
                print('run_command: Unknown command: %s' % cmd)
                return 1, '', ''

    module = FakeModule('locale', '/usr/bin')
    assert get_best

# Generated at 2022-06-11 01:17:57.781930
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})

    locale = get_best_parsable_locale(module, None)

    assert(locale == 'C')

# Generated at 2022-06-11 01:18:09.134257
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    if sys.version_info[0] == 2:
        # Mock module is not compatible with python 2.7
        # disabling tests for python 2.7
        return

# Generated at 2022-06-11 01:18:19.828666
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )

    # List of locale preferences
    preferences1 = ['fr_FR.utf8', 'C.utf8', 'C', 'POSIX']
    preferences2 = ['C.utf8', 'C', 'en_US.utf8', 'POSIX']
    preferences3 = ['C', 'POSIX']
    preferences4 = None

    # Get expected locale
    expected_locale1 = 'C'
    expected_locale2 = 'C.utf8'
    expected_locale3 = 'POSIX'
    expected_locale4 = 'C'

    # List of locale preferences

# Generated at 2022-06-11 01:18:23.824880
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict()
    )

    module.run_command = mock_command
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['foo.bar']) == 'C'



# Generated at 2022-06-11 01:18:31.473202
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule

    # AssertionError: 'C' != u'en_US.utf8'
    module = AnsibleModule(argument_spec={})
    system_locales = ['en_US.iso88591', 'en_US.iso885915@euro', 'en_US.utf8', 'en_US.UTF-8']
    preferred_locales = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    module.run_command = lambda x: (0, '\n'.join(system_locales), '')

    # preferred_locales == ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    # system_locales

# Generated at 2022-06-11 01:18:38.029040
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''test_get_best_parsable_locale'''

    from ansible.modules.system import locale_gen
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    # Test 1 - should return en_US.UTF-8
    preferences = ['en_US.UTF-8', 'C.UTF-8', 'C.utf8']

    assert(preferences[0] == locale_gen.get_best_parsable_locale(module, preferences))

    # Test 2 - should return 'C'
    preferences = ['ru_RU.UTF-8', 'pl_PL.UTF-8', 'it_IT.UTF-8', 'C.UTF-8', 'C.utf8']
