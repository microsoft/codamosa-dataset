

# Generated at 2022-06-11 01:08:50.203739
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Tests for function get_best_parsable_locale
    '''

    # Mock AnsibleModule
    ansible_module = type('ansible_module', (object,),
                          dict(get_bin_path=lambda self, x: '/usr/bin/locale',
                               run_command=lambda self, x: (0, '', '')))

    # No preference passed
    locale = get_best_parsable_locale(ansible_module())
    assert locale == 'C'

    # With a preference passed
    locale = get_best_parsable_locale(ansible_module(), preferences=['POSIX'])
    assert locale == 'POSIX'

# Generated at 2022-06-11 01:08:55.954524
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    preferences = ['POSIX.utf8', 'en_US.utf8']
    assert get_best_parsable_locale(module, preferences) == 'C'

# Generated at 2022-06-11 01:09:04.439744
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    module = Mock(run_command=Mock(return_value=(0, 'C\nen_US.utf8\nen_US.UTF-8\nen_US\nC.UTF-8\n', '')), get_bin_path=Mock(return_value='locale'))
    assert get_best_parsable_locale(module) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'en_US.UTF-8']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'en_US.UTF-8']) == 'en_US.utf8'



# Generated at 2022-06-11 01:09:15.153480
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import platform
    import tempfile
    import textwrap

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    if platform.system() == 'Darwin':
        preferences = ['C', 'en_US.UTF-8']
        expected = 'C'
    else:
        preferences = ['C.utf8', 'C', 'POSIX']
        expected = 'C.utf8'

    if platform.system() == 'SunOS':
        # We're using Python 3 on Solaris + GNU coreutils locale which is broken
        expected = 'C'

    # Monkeypatch get_bin_path to always return the current
    # interpreter's path and to make PATH

# Generated at 2022-06-11 01:09:23.313925
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class AnsibleModuleMock:

        def __init__(self, params=None):
            self.params = dict(
                params if not params is None else dict()
            )

        def fail_json(self, msg):
            raise AssertionError(msg)

        def get_bin_path(self, path, required=False):
            return '/usr/bin/locale'

        def run_command(self, args, check_rc=True):
            # rc=0
            # out=  "C\nen_US.utf8\nC.utf8\nPOSIX"
            return 0, "C\nen_US.utf8\nC.utf8\nPOSIX", ""
    # end of class AnsibleModuleMock


# Generated at 2022-06-11 01:09:31.895619
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.six import PY2
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping

    class AnsibleModule:

        def __init__(self):
            self.params = {}
            self.fail_json = lambda self, **kwargs: 1/0

        def get_bin_path(self, command, **kwargs):
            return command

        def run_command(self, command, **kwargs):
            # $ locale -a
            # C
            # en_GB.UTF-8
            # en_US@euro
            # en_US.UTF-8
            # en_US
            # POSIX
            if PY2 and isinstance(command, unicode):
                command = [command]

# Generated at 2022-06-11 01:09:35.689229
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    test_module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    assert isinstance(get_best_parsable_locale(test_module), list)

# Generated at 2022-06-11 01:09:44.883369
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    import tempfile
    import shutil
    from ansible.module_utils import basic
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import reload_module

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as meta:
        meta.write('{"ANSIBLE_MODULE_ARGS":{},')
        meta.write('"ANSIBLE_MODULE_UTILS":"basic",')

        # set ANSIBLE_MODULE_BIN_PATH to a nonexistent directory
        # to test that an exception is raised if locale can't be found
        meta.write('"ANSIBLE_MODULE_BIN_PATH":"/does/not/exist",')


# Generated at 2022-06-11 01:09:45.398061
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-11 01:09:55.807761
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test that the get_best_parsable_locale works as expected
    '''

    # The os.path is to emulate what ansible.module_utils.basic.AnsibleModule
    # would do on import. No need to mock up AnsibleModule to make this work.

    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule

    import os
    import pprint
    import tempfile

    class FakeModule(object):
        def __init__(self, arguments):
            self.params = arguments
            self.fail_json_rc = 1

        def run_command(self, cmd):
            """
                This function will be mocked to return desired CMD results
            """
            return (0, cmd[0], None)


# Generated at 2022-06-11 01:10:07.405709
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    locales_list = ['C.UTF-8', 'en_US.UTF-8', 'C', 'POSIX', 'en_US.UTF-8', 'C.UTF-8', 'en_US.UTF-8']
    locale_output = 'C.UTF-8\nen_US.UTF-8\nC\nPOSIX'
    best_locale = get_best_parsable_locale(module, preferences=locales_list)

    assert best_locale == 'C.UTF-8', "Expected %s got %s" % ('C.UTF-8', best_locale)

    best_locale = get_best_

# Generated at 2022-06-11 01:10:18.595605
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    test_module = type("AnsibleModule", (object,), {"run_command": run_command})
    test_module.get_bin_path = lambda self, module_name: "locale"
    test_module = test_module()
    locale = get_best_parsable_locale(test_module)
    assert locale == "C.utf8"
    test_module = type("AnsibleModule", (object,), {"run_command": run_command})
    test_module.get_bin_path = lambda self, module_name: "locale"
    test_module = test_module()
    locale = get_best_parsable_locale(test_module, preferences=['invalid_locale'])
    assert locale == "C"

# Generated at 2022-06-11 01:10:26.922884
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert module.get_best_parsable_locale() == 'C'
    assert module.get_best_parsable_locale(preferences=['C']) == 'C'
    assert module.get_best_parsable_locale(preferences=['C', 'en_US.utf8']) == 'C'
    assert module.get_best_parsable_locale(preferences=['en_US.utf8', 'POSIX']) == 'C'
    assert module.get_best_parsable_locale(preferences=['en_US.utf8', 'POSIX', 'C']) == 'C'
    assert module.get_best_pars

# Generated at 2022-06-11 01:10:38.240664
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile
    import os
    import unittest

    class ShellTest(unittest.TestCase):
        def setUp(self):
            stdin = tempfile.TemporaryFile()
            stdout = tempfile.TemporaryFile()
            stderr = tempfile.TemporaryFile()
            self.test_module = FakeModule(stdin=stdin, stdout=stdout, stderr=stderr)

        def tearDown(self):
            self.test_module.cleanup()
            self.test_module = None

    class FakeModule():
        """
        Fake module class to interact with module_utils.basic._AnsibleModule.
        """
        def __init__(self, stdin, stdout, stderr):
            self.stdin = stdin
            self.stdout = stdout

# Generated at 2022-06-11 01:10:48.896856
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys
    import unittest

    class AnsibleModule(object):

        def __init__(self, bin_path):
            self.bin_path = bin_path
            self.params = {}

        def get_bin_path(self, tool, required=False):
            return self.bin_path

        @staticmethod
        def run_command(command, *args, **kwargs):
            return 0, os.linesep.join(self.command_output), ''

    class MockModule():

        def run_command(self, cmd):
            return 0, self.command_output, ''


# Generated at 2022-06-11 01:10:58.330947
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    module = AnsibleModule()

    try:
        assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX'], True) == 'C'
    except Exception:
        e = get_exception()
        print(e.message)
        assert e.message == "Could not find 'locale' tool"
        assert module.run_command.call_args_list[0][0][1] == [u'locale', '-a']

# Generated at 2022-06-11 01:11:09.086658
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit tests for get_best_parsable_locale
    '''
    from ansible.module_utils.basic import AnsibleModule

    # Test case 1: Success case, returning "C" default locale
    module1 = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module1) == 'C'

    # Test case 2: Success case, returning first matched preferred locale when given
    module2 = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module2, preferences=['C.utf8', 'C', 'POSIX']) == 'C.utf8'

    # Test case 3: Success case, returning "C" default locale when none of the preferred locales
    #              is available

# Generated at 2022-06-11 01:11:18.699715
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(
        argument_spec=dict()
    )
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'

    module = AnsibleModule(
        argument_spec=dict()
    )
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'C.utf8', 'C', 'POSIX']) == 'en_US.utf8'

    module = AnsibleModule(
        argument_spec=dict()
    )
    assert get_best_parsable_locale(module, preferences=['C', 'en_US.utf8', 'C.utf8', 'POSIX']) == 'C'

    module

# Generated at 2022-06-11 01:11:25.744384
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule()

    am.get_bin_path = lambda x: "/usr/bin/locale"

    am.run_command = lambda x: (
        0,
        """C
C.UTF-8
C.utf8
de_DE.utf8
de_DE.UTF-8
de_AT.utf8
en_US.utf8
en_US.UTF-8
en_GB.utf8
en_GB.UTF-8
en_AU.utf8
en_AU.UTF-8
POSIX
""",
        ""
    )

    assert get_best_parsable_locale(am) == 'C.utf8'

# Generated at 2022-06-11 01:11:34.335076
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import unittest
    import ansible.constants
    import ansible.module_utils as utils

    orig_locale = ansible.constants.DEFAULT_SYS_LOCALE_ENCODING
    orig_warnings = ansible.constants.DEPRECATION_WARNINGS
    orig_debug = ansible.constants.DEBUG

    class AnsibleModuleMock():
        def __init__(self, debug=False):
            self.called_with = {}
            self.debug = debug
            self.result = {
                'changed': False,
                'failed': False,
                'rc': 0,
                'stdout': '',
                'stdout_lines': [],
                'warnings': []
            }


# Generated at 2022-06-11 01:11:46.973560
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US']) == 'C.utf8'
    assert get_best_parsable_locale(None, ['en_US', 'C']) == 'C'
    assert get_best_parsable_locale(None, ['en_US.utf8', 'C']) == 'C'
    assert get_best_parsable_locale(None, ['en_US.utf8', 'C.utf8']) == 'C.utf8'
    assert get_best_parsable_locale(None, ['en_US.utf8', 'en_US']) == 'en_US.utf8'

# Generated at 2022-06-11 01:11:58.634182
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.compat.tests import unittest
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    class MyAnsibleModule(AnsibleModule):

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            return '/usr/bin/locale'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='surrogate_or_strict'):

            return (0, '', '')

    module = MyAnsible

# Generated at 2022-06-11 01:12:04.386270
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        # not running in ansible context
        import pytest
        pytest.skip('skipping as not running in ansible context')

    module = AnsibleModule()
    assert get_best_parsable_locale(module, raise_on_locale=False) == 'C'

# Generated at 2022-06-11 01:12:15.624010
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from . import AnsibleModule
    from . import TemporaryDirectory
    from . import get_bin_path
    import sys

    if sys.version_info[0] == 2:
        module_path = 'ansible.builtin.get_best_parsable_locale'
    else:
        module_path = 'ansible.module_utils.basic.get_best_parsable_locale'
    if get_bin_path('locale'):
        locale_bin = get_bin_path('locale')

        mock_module = AnsibleModule(
            argument_spec={},
            supports_check_mode=True
        )
        assert get_best_parsable_locale(mock_module) == 'C'


# Generated at 2022-06-11 01:12:25.733485
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit tests for function get_best_parsable_locale
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    def test_basic_functionality_english(monkeypatch, mocker):
        '''
            Basic functionality test for English
        '''
        def failed_locale_mock_run_command(module):
            '''
                Mock for function run_command in AnsibleModule
            '''
            return 1, "", ""

        mocker.patch.object(AnsibleModule, 'run_command', side_effect=failed_locale_mock_run_command)

        locale_module = AnsibleModule(
            argument_spec={},
        )

        # POSIX is default locale
        assert get_

# Generated at 2022-06-11 01:12:37.653138
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    mod = AnsibleModule(argument_spec={})

    def mock_run_command(cmd, cwd=None, use_unsafe_shell=False, environ_update=None):
        if cmd == ['locale', '-a']:
            out = StringIO()
            out.write('C\nC.UTF-8\nC.utf8\nen_US.UTF-8\nen_US.utf8\nen_US.US-ASCII\nen_US\nen_US.us\nPOSIX\n')
            if PY3:
                out.seek(0)
           

# Generated at 2022-06-11 01:12:43.160898
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.local import LocalAnsibleModule

    test_module = LocalAnsibleModule()
    # test_module.run_command(['do', 'stuff'])
    test_module.fail_json = lambda *args, **kwargs: None
    assert get_best_parsable_locale(test_module) == 'C'

# Generated at 2022-06-11 01:12:54.750884
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """Test scenario when we have a best locale. 
    """
    import unittest
    import mock
    import os
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.basic import AnsibleModule

    class TestModule(unittest.TestCase):

        def setUp(self):
            self.a_module = AnsibleModule(
                argument_spec=dict()
            )
            self.a_module.get_bin_path = mock.MagicMock()
            self.a_module.run_command = mock.MagicMock()
            self.preferred_locales = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

# Generated at 2022-06-11 01:13:01.712642
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 01:13:13.661056
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile
    import os
    class MockModule(object):
        def __init__(self):
            pass

        def get_bin_path(self, app):
            return app
        def run_command(self, command):
            try:
                cmd_out = open(os.path.join(tempfile.gettempdir(), 'ansible_test_locale_cmd_out'), 'r').read()
                cmd_err = open(os.path.join(tempfile.gettempdir(), 'ansible_test_locale_cmd_err'), 'r').read()
            except IOError:
                pass
            return 0, cmd_out, cmd_err


# Generated at 2022-06-11 01:13:22.700321
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    if sys.version_info >= (3,):
        assert get_best_parsable_locale(None) == 'C.UTF-8'
    else:
        assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-11 01:13:34.110723
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import unittest

    # Import the test libs
    from ansible.module_utils.six import PY3

    from ansible.modules.system.locale import get_best_parsable_locale

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.local import LocalAnsibleModule

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_uname_path
    from units.mock.sys_module import AnsibleSysModule

    class TestLocale(unittest.TestCase):

        def setUp(self):
            self._save_uname = sys.modules['platform.uname']
            sys.modules['platform.uname'] = mock_uname_path([])
            self._save_

# Generated at 2022-06-11 01:13:44.904663
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import re

    test_passed = True

    class MockModule:
        def __init__(self, name='command_run', module_args=None):
            self.params = {
                'warn': False,
                'executable': None
            }
            for key, value in module_args.items():
                self.params[key] = value
            self.run_command_called = 0
            self.run_command_stderr = None
            self.run_command_rc = 0
            self.run_command_stdout = None

        def fail_json(self, **args):
            pass


# Generated at 2022-06-11 01:13:46.858031
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    assert get_best_parsable_locale(AnsibleModule()) == 'C'

# Generated at 2022-06-11 01:13:53.027078
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for the get_best_parsable_locale function
    '''

    # create a mock module object
    module = AnsibleModule({})
    module.run_command = run_command_mock

    # Test 1 with no preferences
    try:
        # ignore exception due to locale CLI issues
        best_locale = get_best_parsable_locale(module, preferences=None, raise_on_locale=False)
        assert best_locale == 'C'
    except RuntimeWarning:
        assert False

    # Test 2 with preferences

# Generated at 2022-06-11 01:14:04.400802
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})

    # first test if function returns 'C' if no preferences exists
    assert get_best_parsable_locale(module) == 'C'

    # test if function returns 'C' if 'locale' tool is missing
    module.params['module_utils.locale'] = None
    assert get_best_parsable_locale(module) == 'C'

    # test if function returns 'C' if no output from 'locale' tool
    module.params['module_utils.locale'] = 'locale'
    class ReturnValue():
        def __init__(self, rc, out, err):
            class RunCommandReturn():
                def __init__(self, rc, out, err):
                    self.rc = rc


# Generated at 2022-06-11 01:14:13.107991
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    module.run_command = lambda cmd: (0, 'C.utf8\nen_US.utf8\nC\nPOSIX\nmoose\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'
    module.run_command = lambda cmd: (0, 'C.utf8\nen_US.utf8\nmoose\nPOSIX\nC\n', '')
    assert get_best_parsable_locale(module) == 'C.utf8'

# Generated at 2022-06-11 01:14:15.888264
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale = 'C'
    pass


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-11 01:14:27.266117
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import locale

    class FakeModule(AnsibleModule):
        def __init__(self):
            self.params = {}
            self.run_command_args = []

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            if name != 'locale':
                raise MissingBinary(name)
            return self.locale_path

        def run_command(self, command):
            if self.run_command_args:
                assert command == self.run_command_args[0]
                args = self.run_command_args[1:]
                if args[2] == 'exc':
                    raise Exception('Test exception')
                return args[:3]

# Generated at 2022-06-11 01:14:33.103889
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Test that get_best_parsable_locale correctly chooses the locale to use.
    """
    assert get_best_parsable_locale(None, [], True) == 'C'
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-11 01:14:42.566397
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module) == 'C'



# Generated at 2022-06-11 01:14:46.664841
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    module.run_command = lambda args: (0, 'C', '')
    assert get_best_parsable_locale(module) == 'C'


# Generated at 2022-06-11 01:14:56.990845
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # TODO: Fails on macOS
    # import pytest
    # pytest.xfail("Fails on macOS")

    import os
    import tempfile
    import json

    from ansible.utils.hashing import md5s
    from ansible.module_utils.basic import AnsibleModule

    tmpdir = tempfile.mkdtemp()
    fake_locale = os.path.join(tmpdir, 'locale')
    # The locale program will fail on macOS without this in place.
    open(fake_locale, 'a').close()
    os.chmod(fake_locale, 0o755)

    test_prefs = ['en_US.utf8', 'en_US.us', 'C', 'POSIX']


# Generated at 2022-06-11 01:14:59.536854
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    test_module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict()
    )

    found = get_best_parsable_locale(test_module)
    assert found == 'C'



# Generated at 2022-06-11 01:15:05.194700
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Set up some fake data.
    class FakeModule(object):
        class FakeRunCommand(object):
            def __init__(self, retcode, out, err):
                self.retcode = retcode
                self.out = out
                self.err = err

        def get_bin_path(self, name):
            return name

        def run_command(self, command, check_rc=True):
            if command[0] == 'locale':
                return self.FakeRunCommand(0, 'C\nen_US.utf8\nen_US.ISO8859-1\n', '')
            else:
                return self.FakeRunCommand(1, '', '')

    module = FakeModule()


# Generated at 2022-06-11 01:15:16.379335
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_output = '''
C
en_US.utf8
'''


# Generated at 2022-06-11 01:15:27.590437
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    class FakeModule:
        def __init__(self):
            self.params = {}

        def run_command(self, args):
            if args == [locale, '-a']:
                return 0, "C.utf8\nen_US.utf8\nen_US.utf8", ''
            return 0, "C.utf8\nen_US.utf8", ''

        def get_bin_path(self, name, **kwargs):
            if name == 'C':
                return 'C'

    assert get_best_parsable_locale(FakeModule()) == 'C.utf8'

    class FakeModule:
        def __init__(self):
            self.params = {}


# Generated at 2022-06-11 01:15:29.977059
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:15:39.947974
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_bin = to_native('/bin/true')

    # Mock the module
    module = AnsibleModule(argument_spec=dict())
    # Mock module.run_command()

# Generated at 2022-06-11 01:15:44.954192
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    # Initializing AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    found = get_best_parsable_locale(module, preferences)

    assert found == 'C'

# Generated at 2022-06-11 01:16:06.132893
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' get_best_parsable_locale  unit tests'''
    from ansible.module_utils.basic import AnsibleModule

    # initialize a test instance of AnsibleModule
    module = AnsibleModule(argument_spec={})
    try:
        module.run_command([module.get_bin_path('locale'), '-a'])
    except Exception:
        # this test will only pass if 'locale' exists on the underlying system
        module.exit_json(changed=False)

    # test the default positional args
    assert get_best_parsable_locale(module) is 'C', "get_best_parsable_locale output should be 'C'"

    # test no preferred locales

# Generated at 2022-06-11 01:16:16.397956
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test the get_best_parsable_locale function in module_utils.basic.py.
        Test that it returns a locale name as expected.
    '''
    import ansible.module_utils.basic as module_utils
    from ansible.module_utils.basic import AnsibleModule

    # Default test
    module = AnsibleModule(argument_spec={})
    test_preferences = None
    raise_on_locale = False
    result = module_utils.basic.get_best_parsable_locale(module, test_preferences, raise_on_locale)
    assert result == "C"

    # Test a non-default first preference
    test_preferences = ['en_US.utf8', 'C', 'POSIX']
    result = module_utils.basic.get_

# Generated at 2022-06-11 01:16:25.260903
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import contextlib
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves.queue import Queue
    from ansible.module_utils.six.moves.urllib.error import HTTPError

    prefs = ['C', 'en_US.utf8', 'POSIX']
    default = get_best_parsable_locale(AnsibleModule([]), raise_on_locale=False)
    if default == 'C':
        prefs.remove('C')
        prefs.remove('POSIX')
    else:
        prefs.remove(default)
        prefs.insert(0, default)

    q = Queue()

# Generated at 2022-06-11 01:16:35.321356
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class TestModule:
        def __init__(self, params):
            self.params = params
        def get_bin_path(self, x):
            return self.params['bin_path']
        def run_command(self, x):
            return self.params['run_command']

    # Should error when locale tool is not found
    t1 = TestModule({
        'bin_path': None,
        'run_command': (1, None, None)
    })
    assert get_best_parsable_locale(t1) == 'C'

    # Should return C when no output is returned
    t2 = TestModule({
        'bin_path': 'locale',
        'run_command': (0, '', None)
    })
    assert get_best_parsable_locale(t2)

# Generated at 2022-06-11 01:16:44.777299
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test the get_best_parsable_locale function with a plugin that has required=false
    :return: None
    '''

    # Mock up the module
    from ansible.module_utils.basic import AnsibleModule
    class MyModule(object):
        def __init__(self):
            pass
        def get_bin_path(self, name, required=False):
            return "/usr/bin/local"
        def run_command(self, cmd):
            return (0, "  C\n C.UTF-8\n en_US.UTF-8", "")
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )
    module.AnsibleModule = MyModule


# Generated at 2022-06-11 01:16:51.768556
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Locale not available (posix) - C is returned
    module = MockAnsibleModule(run_command_return_values=[(1, "", ""), (0, "", "")])
    assert get_best_parsable_locale(module) == 'C'

    # Locale available (en_US.utf8) - en_US.utf8 is returned
    module = MockAnsibleModule(run_command_return_values=[(1, "", ""), (0, "C.UTF-8\nen_US.utf8", "")])
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    # Locale available (C) - C is returned

# Generated at 2022-06-11 01:17:00.957817
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-11 01:17:09.581083
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    if sys.version_info[:2] == (2, 6):
        # Python 2.6 doesn't have mock
        return None

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    m = AnsibleModule(argument_spec={})

    # mock locale -a calls
    with patch.object(m, 'run_command') as run_cmd_mock:
        run_cmd_mock.return_value = 0, 'C.utf8\nen_US.utf8', ''
        # Test 1: Test that we get a UTF8 locale when we have it and ask for it
        result = get_best_parsable_locale(m, ['C.utf8'])

# Generated at 2022-06-11 01:17:19.606971
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Unit test for function get_best_parsable_locale
    '''
    class ModuleMock:
        '''
        Mock class for AnsibleModule
        '''
        def get_bin_path(self, name):
            """
            Mock function for get_bin_path from AnsibleModule
            :param name:
            :return:
            """
            if name == "locale":
                return True
            else:
                return False

        def run_command(self, command):
            """
            Mock function for run_command from AnsibleModule
            :param command:
            :return:
            """
            class CmdMock:
                """
                Mock class for command
                """
                def __init__(self):
                    self.stdout = ""
                    # self.stderr = ""


# Generated at 2022-06-11 01:17:29.222741
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    def get_best_parsable_locale_mock(module, preferences=None, raise_on_locale=False):
        available = ['C', 'C.UTF-8', 'POSIX']
        found = 'C'

        for pref in preferences:
            if pref in available:
                found = pref
                break

        return found

    # check module_utils.basic.get_best_parsable_locale
    assert get_best_parsable_locale_mock('module', ['C.UTF-8', 'POSIX']) == 'C.UTF-8'
    assert get_best_parsable_locale_mock('module', ['en_US.UTF-8', 'POSIX']) == 'POSIX'

    # check default value

# Generated at 2022-06-11 01:18:08.313149
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()

    found = get_best_parsable_locale(module, ['en_US.utf8'])
    assert found == 'en_US.utf8', "Default locale was not found"

    found = get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX'])
    assert found == 'C.utf8', "First preference locale was not found"

    found = get_best_parsable_locale(module, ['C.utf8', 'does_not_exist', 'C', 'POSIX'])
    assert found == 'C.utf8', "Second preference locale was not found"


# Generated at 2022-06-11 01:18:19.381890
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)
        def get_bin_path(self, cmd):
            return self.path
        def run_command(self, cmd):
            return self.rc, self.out, self.err
    available_locales = ['C', 'C.UTF-8', 'POSIX']
    module = AnsibleModule(path='/usr/bin/locale', out='\n'.join(available_locales), rc=0)
    assert get_best_parsable_locale(module) == 'C'
    module = AnsibleModule(path='/usr/bin/locale', out=None, rc=0)
    assert get_best_pars

# Generated at 2022-06-11 01:18:27.223015
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale({'get_bin_path': lambda x: x,
                                     'run_command': lambda x: (0, 'C\nC.utf8\nen_US.utf8', '')}) == 'C.utf8'
    assert get_best_parsable_locale({'get_bin_path': lambda x: None,
                                     'run_command': lambda x: (0, 'C\nC.utf8\nen_US.utf8', '')}) == 'C'
    assert get_best_parsable_locale({'get_bin_path': lambda x: x,
                                     'run_command': lambda x: (1, '', '')}) == 'C'

# Generated at 2022-06-11 01:18:32.693514
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test if we get the best possible locale for parsing
    '''
    try:
        # Mock AnsibleModule
        from ansible.module_utils.basic import AnsibleModule

        module = AnsibleModule()
        preferences = ['de_DE.utf8', 'C']
        found = get_best_parsable_locale(module, preferences)
        assert found == 'C', 'Should return locale C'
    except ImportError:
        print ('can not import AnsibleModule, function probably not running under Ansible')

# Generated at 2022-06-11 01:18:41.867038
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    def get_bin_path(path):
        if path == "locale":
            return "/usr/bin/locale"

    def run_command(cmd_args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='surrogate_or_strict', expand_user_and_vars=True):
        if cmd_args == ['/usr/bin/locale', '-a']:
            return (0, "C\nen_US.utf8\nen_GB.utf8\n", "")
        return