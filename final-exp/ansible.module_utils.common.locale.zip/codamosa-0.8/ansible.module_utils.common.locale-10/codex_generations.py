

# Generated at 2022-06-11 01:08:50.710467
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''Unit test for function get_best_parsable_locale'''

    import collections
    import mock

    import ansible.module_utils.basic

    # imports
    module = mock.MagicMock()
    module.run_command = collections.namedtuple('rc', 'stdout,stderr')(0, 'C\nen_US.utf8\nen_US\nC.UTF-8', '')

    # tests
    assert get_best_parsable_locale(module, ['C',]) == 'C'
    assert get_best_parsable_locale(module, ['C', 'en_US.utf8']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, ['en_US.utf8', 'C.UTF-8'])

# Generated at 2022-06-11 01:08:57.557862
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test is as a module
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    m_obj = AnsibleModule(argument_spec={})

    locale_result = get_best_parsable_locale(m_obj)

    assert (locale_result is not None)


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-11 01:09:04.937846
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(
        test=dict(type='bool', default=True),
    ))

    if module.params['test']:
        assert ('C' == get_best_parsable_locale(module=module, raise_on_locale=False))
        assert ('en_US.utf8' == get_best_parsable_locale(module=module, preferences=['en_US.utf8', 'C'], raise_on_locale=False))

    module.exit_json(msg="Passed all tests")

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-11 01:09:11.614048
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import os
    import random
    import shutil
    import sys
    import tempfile
    import unittest

    # Stub out the module class
    class StubModule(object):
        def __init__(self, locale_bin):
            self.locale_bin = locale_bin

        def get_bin_path(self, binary):
            return self.locale_bin

        def run_command(self, args):
            return self.cmd_output(args[0], args[1:])

        def cmd_output(self, path, args):
            output = ''

            if path == self.locale_bin:
                if len(args) == 1 and args[0] == '-a':
                    keys = self.locales.keys()
                    random.shuffle(keys)


# Generated at 2022-06-11 01:09:21.585750
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # test without preferences
    result = get_best_parsable_locale(None)
    assert result == 'C'

    # test with invalid locale command
    class AnsibleModule(object):
        def get_bin_path(self, value):
            return None

        def run_command(self, value):
            out = ''
            err = ''
            return 1, out, err

    preferences = ['C.utf8', 'en_US.utf8']

    test_module = AnsibleModule()
    result = get_best_parsable_locale(test_module, preferences=preferences)
    assert result == 'C'

    # test with valid locale command but with no output
    class AnsibleModule(object):
        def get_bin_path(self, value):
            return value


# Generated at 2022-06-11 01:09:31.370639
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 01:09:41.953652
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic

    test_cases = (
        {
            'preferences': ['C.utf8', 'en_US.utf8', 'C', 'POSIX'],
            'return_val': ['C', 'C', 'C', 'C']
        },
        {
            'preferences': ['de_DE.utf8', 'en_US.utf8', 'C', 'POSIX'],
            'return_val': ['C', 'C', 'C', 'C']
        },
    )

    for test_case in test_cases:
        # Py2 doesn't support mock.patch.object, so just use mocks directly
        m_module = basic.AnsibleModule({})
        m_module.run_command = lambda x: (1, '', '')
        m_

# Generated at 2022-06-11 01:09:51.954647
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test for get_best_parsable_locale
    '''

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    locale_prefers = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    assert get_best_parsable_locale(module) == locale_prefers[0]
    assert get_best_parsable_locale(module, ['C']) == 'C'
    assert get_best_parsable_locale(module, ['POSIX']) == 'POSIX'
    assert get_best_parsable_locale(module, ['abcdefg']) == locale_prefers[0]

# Generated at 2022-06-11 01:10:01.361278
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule, ModuleFailException

    module = AnsibleModule(
        argument_spec=dict(
            locale_preference=dict(type='list', default=[]),
            fail_on_locale=dict(type='bool', default=False),
        )
    )

    # Test get_best_parsable_locale when an error is encountered
    with module.assertRaisesRegexp(ModuleFailException, "Unable to get locale information"):
        get_best_parsable_locale(module, preferences=['C.utf8'], raise_on_locale=True)

    # Test get_best_parsable_locale when an error is not encountered and the preferred locale is found.

# Generated at 2022-06-11 01:10:08.600272
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    m = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    assert get_best_parsable_locale(m) == 'C'

    m.run_command = lambda *args: (0, 'C\nen_US.utf8', '')
    assert get_best_parsable_locale(m) == 'C'
    assert get_best_parsable_locale(m, preferences=['en_US.utf8']) == 'en_US.utf8'

    m.run_command = lambda *args: (0, 'C\nen_US.utf8', '')

# Generated at 2022-06-11 01:10:23.306094
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys

    test_prefs = ['C.iso885915', 'C.iso885915@euro', 'C.utf8', 'C',
                  'en_US.utf8', 'en_US', 'POSIX']

    # Save current locale
    current_locale = os.environ.get('LC_ALL', None)

    # Create an AnsibleModule object
    module = AnsibleModule(argument_spec=dict())

    # Test with no locale
    os.environ.pop('LC_ALL', None)
    found = get_best_parsable_locale(module, test_prefs)
    assert found == 'C'

    # Test with existing locale
    os.environ['LC_ALL'] = current_locale

# Generated at 2022-06-11 01:10:33.861148
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest.mock as mock

    # Test function get_best_parsable_locale() raises RuntimeWarning when
    # the user's default locale is not in 'available' locale list

    class MyModule(mock.MagicMock):

        def __init__(self):
            super().__init__()
            self.run_command = mock.MagicMock()

        def get_bin_path(self, executable):
            return executable

    def _run_command(args, input_data=None, stdin=None):
        err = to_native(input_data)
        out = "/\n/en_US.utf8\n/C\n/POSIX"
        return 0, out, err

    module = MyModule()
    module.run_command = _run_command
    assert get_best_p

# Generated at 2022-06-11 01:10:41.762575
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # test without locale binary
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.local import LOCALHOST
    from ansible.module_utils.six import string_types
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        required_one_of = (),
        mutually_exclusive = (),
        added_to_check_mode_in = 2.4
    )
    result = get_best_parsable_locale(module, raise_on_locale=True)
    assert result == 'C'

    # test with locale binary but no output

# Generated at 2022-06-11 01:10:51.485751
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """Function to unit test get_best_parsable_locale"""
    import sys
    import unittest

    class FakeModule(object):
        def __init__(self, out=None, err=None, rc=0):
            self.out = out
            self.err = err
            self.rc = rc

        def get_bin_path(self, tool):
            if tool == 'locale':
                return sys.executable

        def run_command(self, cmd, check_rc=True):
            return (self.rc, self.out, self.err)

    class FakeModuleLocaleToolRaise(FakeModule):
        def __init__(self):
            super(FakeModuleLocaleToolRaise, self).__init__(None, None, 1)


# Generated at 2022-06-11 01:10:56.554737
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['POSIX']) == 'C'
    assert get_best_parsable_locale(None, ['C.utf8', 'POSIX']) == 'C'

# Generated at 2022-06-11 01:11:07.560086
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import pytest
    # Test 1: test with an invalid locale, and verify we default to 'C'
    assert get_best_parsable_locale(AnsibleModule(), ['not_a_locale']) == 'C'
    # Test 2: test with a french locale that we know, and verify we don't default to 'C'
    assert get_best_parsable_locale(AnsibleModule(), ['fr_FR.utf8']) == 'fr_FR.utf8'
    # Test 3: test with an invalid locale and default to another known locale fr_FR.utf8

# Generated at 2022-06-11 01:11:17.766233
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    input1 = ['C', 'POSIX', 'en_US.utf8', 'C.utf8']
    input2 = ['C', 'en_US.utf8', 'POSIX', 'en_US.utf8']
    input3 = ['C', 'C.utf8', 'en_US.utf8', 'POSIX']

    input4 = ['C', 'POSIX', 'en_US.utf8', 'C.utf8']
    input5 = ['C', 'en_US.utf8', 'POSIX', 'en_US.utf8']
    input6 = ['C', 'C.utf8', 'en_US.utf8', 'POSIX']

    input7 = ['C', 'POSIX', 'en_US.utf8', 'C.utf8']

# Generated at 2022-06-11 01:11:21.237795
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec={})
    try:
        locale = get_best_parsable_locale(m)
        assert locale is not None
    except:
        pass # This is for testing the exception conditions
    # No error means it passed

# Generated at 2022-06-11 01:11:31.169772
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module_mock = AnsibleModule(argument_spec={})

    # This function is mocked to return 'foo' with the third call and to raise a RuntimeWarning on the fourth
    def get_bin_path(exe, opts=None, required=False):
        if exe == 'locale':
            # We will return a bin path only 3 times
            module_mock.get_bin_path.call_count += 1
            if module_mock.get_bin_path.call_count > 3:
                # on the fourth call we raise a RuntimeWarning, the function should return the default locale
                raise RuntimeWarning("could not find 'locale' tool")
            else:
                return 'foo'
        return 'foo'


# Generated at 2022-06-11 01:11:37.602893
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['fr', 'C']) == 'C'
    assert get_best_parsable_locale(module, ['fr', 'fr_FR', 'fr_FR.utf8']) == 'fr_FR.utf8'

# Generated at 2022-06-11 01:11:47.016370
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-11 01:11:58.637300
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-11 01:12:10.166144
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Importing AnsibleModule has side-effects and must be
    # done in a separate function and after the unit test
    # framework is imported.
    class AnsibleModule:
        def __init__(self, argument_spec, check_invalid_arguments=None, bypass_checks=False):
            self.argument_spec = argument_spec
            self.check_invalid_arguments = check_invalid_arguments
            self.bypass_checks = bypass_checks

        def get_bin_path(self, arg):
            return arg

        def run_command(self, arglist):
            return (0, '', '')

    from ansible.module_utils import basic

    class TestAnsibleModule(AnsibleModule):
        def __init__(self):
            self.argument_spec = {}
            self.check

# Generated at 2022-06-11 01:12:16.008105
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # This test is not run as part of normal testcases and not covered by
    # docker-test.sh. It is run during the application of a PR in CI to
    # run as a smoke test.  It is designed to run in Travis CI and not
    # on a system that has locale installed and configured.
    try:
        import unittest
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        import unittest2 as unittest
        from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    class TestGetBestParsableLocale(unittest.TestCase):
        """
        Test Cases for get_best_parsable_locale function
        """

# Generated at 2022-06-11 01:12:25.927070
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import pytest
    if sys.version_info[0] > 2:
        basestring = (str, bytes)
    else:
        basestring = basestring

    class mock_module():
        params = {}
        def get_bin_path(self, bin):
            return "/bin/locale"

        def run_command(self, cmd):
            return 0, 'C\nen_US.utf8\nC.utf8\nPOSIX', ''

    module = mock_module()
    locale = get_best_parsable_locale(module)
    assert locale == "C", "C locale expected"

    # mock a run_command with no output
    module.run_command = lambda cmd: (0, '', '')

# Generated at 2022-06-11 01:12:37.865586
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile
    import os
    import shutil
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    tmpdir = tempfile.mkdtemp()
    locale_file = os.path.join(tmpdir, 'locale')


# Generated at 2022-06-11 01:12:40.262819
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    assert get_best_parsable_locale(AnsibleModule({})) == 'C'

# Generated at 2022-06-11 01:12:43.682105
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    locale = get_best_parsable_locale(module)

    assert locale == 'C'

# Generated at 2022-06-11 01:12:48.981923
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    best_locale = get_best_parsable_locale(module)
    assert best_locale in ["C.utf8", "en_US.utf8", "C", "POSIX"]

# Generated at 2022-06-11 01:12:52.115752
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test that get_best_parsable_locale returns 'C' by default
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-11 01:13:10.580779
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    preferences = ['C', 'POSIX']
    found = get_best_parsable_locale(module, preferences, raise_on_locale=True)
    assert found == 'C'

# Generated at 2022-06-11 01:13:21.255422
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModuleMock():
        def __init__(self):
            self.params = {}

        def get_bin_path(self, command):
            return '/bin/' + command

        def run_command(self, command):
            if command[1] == '-a':
                return 0, 'C.ascii\nen_US.utf8\nC.utf8\nPOSIX\nC\nen_US\n', ''
            elif command[0] == '/bin/locale' and command[1] == 'C.ascii':
                return 0, '', ''
            else:
                return 1, '', ''

    # Locale is not in preference list
    module = AnsibleModuleMock()
    preferences = ['es_ES.utf8', 'es_ES']
    result = get_

# Generated at 2022-06-11 01:13:30.106352
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys
    import tempfile
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'lib'))
    from ansible.module_utils.basic import AnsibleModule

    tmpdir = tempfile.mkdtemp()
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )
    module.tmpdir = tmpdir
    module.get_bin_path = lambda x: '/usr/bin/%s' % x
    assert get_best_parsable_locale(module) == 'C'
    os.unlink(tmpdir)

# Generated at 2022-06-11 01:13:37.314265
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})

    if PY3:
        assert module.get_best_parsable_locale() == 'C.UTF-8'

    # This test requires the locale executable to be present
    # assert module.get_best_parsable_locale() == 'C'
    assert module.get_best_parsable_locale() == 'C'

# Generated at 2022-06-11 01:13:41.042271
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    try:
        locale = get_best_parsable_locale(AnsibleModule(argument_spec={}))
    except RuntimeWarning:
        locale = None

    assert locale is not None

# Generated at 2022-06-11 01:13:49.926778
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def run_command(args):
        return [0, "", ""]

    module = AnsibleModule(run_command=run_command)

    # Set to True if you have the locale utility and want to validate
    # that the best locale will be found
    validate_locales = False

    try:
        best_locales = get_best_parsable_locale(module)
    except RuntimeWarning as e:
        print('WARNING: Skipping locale check, %s' % to_native(e))
        best_locales = 'C'


# Generated at 2022-06-11 01:14:01.374514
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys
    import pytest

    os.chdir('tests/unit')

    # Our example system reports these locales available
    locales = "C.UTF-8\nC\nPOSIX\nen_US.UTF-8\nen_US\nen_US.iso88591\nen_US.iso885915@euro\nen_US.utf8\nPOSIX"

    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path

    # fake an ansible module for get_bin_path()
    fake_module = basic.AnsibleModule(
        argument_spec = dict(),
    )

    locale_command = [pytest.helpers.command('locale -a')]


# Generated at 2022-06-11 01:14:11.018323
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['C.utf8', 'en_US.utf8', 'en_US', 'C', 'POSIX']
    assert get_best_parsable_locale(preferences=preferences) == 'C'
    preferences = ['en_US.utf8', 'en_US', 'C', 'POSIX']
    assert get_best_parsable_locale(preferences=preferences) == 'C'
    preferences = ['en_AU.utf8', 'en_AU', 'C', 'POSIX']
    assert get_best_parsable_locale(preferences=preferences) == 'C'
    preferences = ['en_AU.utf8', 'en_AU']

# Generated at 2022-06-11 01:14:22.451567
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.common.process import get_bin_path

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(None, preferences) == 'C'
    assert get_best_parsable_locale(None) == 'C'

    # check if a module with set_bin_path is enough for the function get_best_parsable_locale
    class BinPath(object):
        @staticmethod
        def set_bin_path(binary, paths):
            return True

    class FakeModule:
        def __init__(self, params):
            self.set_bin_path = BinPath.set_bin_path

    # test when locale is available

# Generated at 2022-06-11 01:14:32.272957
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # pylint: disable=W0621,C0103
    from tempfile import NamedTemporaryFile

    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.common.locale import get_best_parsable_locale


    test = NamedTemporaryFile()

    # set locale to UTF-8 POSIX
    test.write(b'C.UTF-8\n')
    test.flush()

    module = AnsibleModule(argument_spec={})

    # get a UTF-8 locale
    locale = get_best_parsable_locale(module, preferences=['C.UTF-8'])
    assert locale == 'C.UTF-8', "Expected 'C.UTF-8', instead got: %s" % locale

    # get a POSIX locale

# Generated at 2022-06-11 01:15:10.739553
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec=dict(
        locale_list=dict(type='list', default=['C.utf8', 'en_US.utf8', 'C', 'POSIX'])
    ))
    result = m.get_bin_path("locale")

    test_cases = dict(
        positive=([0, 'C.UTF-8 UTF-8\nen_US.utf8 UTF-8', ''], 'C.UTF-8'),
        locale_error=([1, '', ''], "C"),
        output_error=([0, '', ''], "C"),
    )


# Generated at 2022-06-11 01:15:19.534629
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    module.fail_json(msg='foo')

    # The following is a work-around to make the unit test pass.
    # The call to fail_json() creates a dummy mocks 'run_command()'.
    def run_command(self, command):
        return 1, command[0], None
    module.run_command = run_command

    assert 'C' == get_best_parsable_locale(module)
    assert 'C' == get_best_parsable_locale(module, preferences=['C'])
    assert 'en_US.utf8' == get_best_parsable_locale(module, preferences=['en_US.utf8'])

# Generated at 2022-06-11 01:15:29.840256
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def run_command(args):
        if args[0] == 'locale':
            return 0, 'C\nen_US.UTF-8\nen_US.UTF8\nen_US.utf8\nen_US.utf-8\n', None
        return 1, None, None

    module = AnsibleModule(run_command=run_command)
    locale = get_best_parsable_locale(module, ['en_US.UTF-8', 'C.UTF-8'])
    assert locale == 'en_US.UTF-8'
    locale = get_best_parsable_locale(module, ['en_US.UTF-8', 'C.UTF-8'], raise_on_locale=True)

# Generated at 2022-06-11 01:15:39.818867
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.utils.unicode import to_str

    module = AnsibleModule(
        argument_spec=dict(
        ),
        add_file_common_args=False,
        supports_check_mode=True,
    )

    # Case when locale cli not found
    assert get_best_parsable_locale(module) == 'C'

    # normal run
    module.get_bin_path = lambda x: 'locale'
    module.run_command = lambda x: (0, 'C\nen_US.utf8\n', '')
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    # no best found
   

# Generated at 2022-06-11 01:15:43.652084
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Ensure we find the best parsable locale
    '''
    import ansible.utils.unsafe_proxy

    class TestModule(ansible.utils.unsafe_proxy.AnsibleUnsafeText):
        pass

    # when given an empty list, get the default
    assert get_best_parsable_locale(TestModule()) == 'C'

# Generated at 2022-06-11 01:15:54.053645
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test utility function get_best_parsable_locale.
    Mock module is used instead of real AnsibleModule so that the tests can be
    run with or without ansible.
    '''
    from ansible.module_utils.basic import AnsibleModule
    import re
    import os

    LOCALE_ERROR_MSG = 'Error calling external command'

    # Mock module class
    class MockModule():

        def __init__(self):
            self.params = {}
            self.fail_json = self.exit_json = lambda x:x
            self.run_command_result = 0
            self.run_command_stdout = ''
            self.run_command_stderr = ''
            self.run_command_exception = None


# Generated at 2022-06-11 01:16:03.611010
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' test_get_best_parsable_locale() '''
    import mock

    test_module = mock.Mock()
    test_module.params = dict()
    # normal use case
    test_module.get_bin_path.return_value = 'locale'
    test_module.run_command.return_value = (0, 'en_US.utf8\nPOSIX\nC.utf8', '')
    assert get_best_parsable_locale(test_module) == 'C.utf8'
    test_module.run_command.reset_mock()
    assert get_best_parsable_locale(test_module, preferences=['POSIX']) == 'POSIX'
    test_module.run_command.reset_mock()
    assert get_best_p

# Generated at 2022-06-11 01:16:13.449139
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    assert get_best_parsable_locale(module) == 'C'
    module = AnsibleModule({'_ansible_module_locale': 'en_US.utf8'})
    assert get_best_parsable_locale(module) == 'en_US.utf8'
    module = AnsibleModule({'_ansible_module_locale': 'en_US.utf8', '_ansible_module_preferred_locales': ['C.utf8', 'C', 'POSIX']})
    assert get_best_parsable_locale(module) == 'C.utf8'

# Generated at 2022-06-11 01:16:23.082334
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    # There are no available locales, so the "C" locale must be returned
    assert get_best_parsable_locale(module) == 'C'

    # The "C" locale is available, so it must be returned
    assert get_best_parsable_locale(module, ['C']) == 'C'

    # The first available locale from preferences will be returned
    assert get_best_parsable_locale(module, preferences) == 'POSIX'

    # The second available locale from preferences will be returned

# Generated at 2022-06-11 01:16:33.347770
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import shlex
    import tempfile

    class TestModule(object):
        class TestModuleFailJson(object):
            def __init__(self, **kwargs):
                self.kwargs = kwargs
                self.called = False

            def __call__(self, *args, **kwargs):
                self.called = True

                if "msg" in self.kwargs:
                    raise Exception(self.kwargs["msg"])

        def __init__(self, **kwargs):
            self.kwargs = kwargs
            self.called = False
            self.fail_json = TestModuleFailJson(**kwargs)

        @property
        def params(self):
            return self.kwargs

        def get_bin_path(self, *args, **kwargs):
            return

# Generated at 2022-06-11 01:17:11.018857
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

    class am:
        def get_bin_path(self, tool): return '/bin/locale'
        def run_command(self, cmd):
            class rc:
                def __init__(self, out, err):
                    self.stdout = out
                    self.stderr = err
                def __bool__(self): return True
                __nonzero__ = __bool__

            if cmd[1] == '-a':
                return rc(
'''C
C.utf8
en_US.utf8
POSIX
''', '')
            else:
                return rc('', '')

    assert get_best_parsable_locale(am()) == 'POSIX'

# Generated at 2022-06-11 01:17:21.376818
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import ansible.module_utils.common.process as process

    # POSIX style output, UTF-8 preferred (C.UTF-8)
    posix_out = 'C\nC.UTF-8\nPOSIX\nen_US.utf8\n'

    # Windows style output, UTF-8 is not supported, English preferred
    windows_out = 'en_US\nen_US\nen_US.ISO-8859-1\nen_US.ISO8859-15\nen_US.US-ASCII\nen_US.UTF-8\n'

    # No output
    empty_out = ''

    def get_bin_path(item):
        return item

    def run_command(cmd):
        status = 0
        out = ''
        err = ''


# Generated at 2022-06-11 01:17:30.774831
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModule(object):
        def __init__(self):
            pass

        def get_bin_path(self, name):
            if name == 'locale':
                return '/bin/locale'
            else:
                return None

        def run_command(self, command):
            rc = 0
            out = ''
            err = ''
            if command[1] == '-a':
                out = 'C\nen_US.utf8\ncac_ZA.utf8\ncac_ZA.utf8'
            else:
                rc = 3
                out = ''
                err = 'Cannot set locale, unsupported'

            return rc, out, err

    module = AnsibleModule()

    # Testing with locale set to 'C', should pick 'en_US.utf8' as the most sensible option

# Generated at 2022-06-11 01:17:33.506378
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    fake_module = type("AnsibleModule", (object,), {"run_command": "function"})
    assert get_best_parsable_locale(fake_module) == 'C'

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-11 01:17:41.841109
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )

    # Simulate first use case, where no preferred locale is provided
    assert 'C' == get_best_parsable_locale(am)


    # Simulate second use case, where locale tool is not available
    am._debug = True
    assert 'C' == get_best_parsable_locale(am, raise_on_locale=False)

    # Simulate third use case, where locale tool is not available
    # but the caller wants an exception to be raised
    

# Generated at 2022-06-11 01:17:52.526121
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''

    list_of_available_locales = ['C', 'POSIX', 'af_ZA.utf8', 'ar_AE.utf8', 'ar_BH.utf8']
    preferences = ['POSIX', 'C.utf8', 'en_US.utf8', 'C']
    assert get_best_parsable_locale(list_of_available_locales, preferences) == 'POSIX'
    assert get_best_parsable_locale(list_of_available_locales, ['C.utf8', 'ar_BH.utf8']) == 'C'

# Generated at 2022-06-11 01:17:57.664868
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Set up a mock AnsibleModule
    am = AnsibleModule(argument_spec={},
                       supports_check_mode=False)

    # Test default parameter 'preferences'
    assert get_best_parsable_locale(am) in ('C', 'POSIX')

    # Test custom parameter 'preferences'
    assert get_best_parsable_locale(am, preferences=['foo', 'bar']) == 'C'

# Generated at 2022-06-11 01:18:09.008094
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
    '''

    # Import required modules
    import os
    import tempfile

    # Create a temporary file and named pipe.
    # Have to use a named pipe, otherwise
    # the stdout is closed before AnsibleModule can read it
    temp_dir = tempfile.mkdtemp()
    fd, temp_file = tempfile.mkstemp()
    temp_fifo = os.path.join(temp_dir, 'temp_fifo')
    os.mkfifo(temp_fifo)


# Generated at 2022-06-11 01:18:19.750010
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Simple unit test for get_best_parsable_locale
    import os
    import tempfile
    import shutil
    import pipes
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    # Make a fake module
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    def _runCommand(command, env=None, check_rc=True):
        if check_rc is None:
            check_rc = True
        outs = ''
        errs = ''
        rc = 0

# Generated at 2022-06-11 01:18:24.029433
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})

    def run_command(args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False):
        return (0, "C", None)

    module.run_command = run_command

    assert get_best_parsable_locale(module) == "C"