

# Generated at 2022-06-11 01:08:42.957110
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:08:52.553899
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Test that the function takes the first preference
    my_pref = [
        "C.utf8",
        "en_US.utf8",
        "C",
        "POSIX"
    ]

    module_out = AnsibleModule(
        argument_spec=dict(),
    )

    module_out.run_command = lambda args: (0, "\n".join(my_pref), '')

    assert get_best_parsable_locale(module_out) == my_pref[0]

    # Test that the function takes the last preference
    my_pref = [
        "en_US.utf8",
        "en_UK.utf8",
        "C",
        "POSIX"
    ]


# Generated at 2022-06-11 01:08:54.574428
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale = get_best_parsable_locale()
    assert(locale == 'C')

# Generated at 2022-06-11 01:09:03.458110
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    import tempfile

    basic._ANSIBLE_ARGS = to_native(tempfile.mkstemp()[1])

    # This tests with a preferences list which contains a locale
    # that is available on the system
    module = AnsibleModule({})
    preferences = ['C.utf8']
    assert get_best_parsable_locale(module, preferences=preferences) == 'C.utf8'

    # This tests with a preferences list which contains a locale
    # that is not available on the system
    preferences2 = ['en_US.utf8']
    assert get_best_parsable_locale(module, preferences=preferences2) == 'C'

# Generated at 2022-06-11 01:09:10.674555
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Can't really generate a mock for module, as it will end up calling os.environ
    # and we would need to mock that as well.
    class mock_module:
        pass

    # Test case 1
    module = mock_module()
    module.run_command = mock_run_command
    found_locale = get_best_parsable_locale(module)
    assert found_locale == 'ja_JP.utf8'

    # Test case 2
    module = mock_module()
    module.run_command = mock_run_command
    found_locale = get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX'])
    assert found_locale == 'ja_JP.utf8'

    # Test case 3


# Generated at 2022-06-11 01:09:21.000149
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Tests that we can find the best locale
    import ansible.module_utils.basic as ansible_basic
    class fake_module_class:
        def __init__(self):
            self.params = {}
            self.params['locale'] = 'C'
        def get_bin_path(self, path):
            if isinstance(path, list) and path[0] == 'locale': return True
            if isinstance(path, str) and path == 'locale': return True
            return False

# Generated at 2022-06-11 01:09:30.916712
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def get_bin_path_mock(args):
        return args

    def run_command_mock(args):
        return 0, '\n'.join(['C', 'POSIX', 'en_US.utf8', 'C.utf8']), None

    m = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    m.get_bin_path = get_bin_path_mock
    m.run_command = run_command_mock

    # Test1: get_best_parsable_locale should return the first matched preferred locale
    assert get_best_parsable_locale(m) == 'POSIX'

    # Test2: get_best_parsable_locale should

# Generated at 2022-06-11 01:09:39.096805
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=False)

    # test various preferred locales
    assert "C.utf8" == get_best_parsable_locale(module, preferences=['C.utf8'])
    assert "C.utf8" == get_best_parsable_locale(module, preferences=['C.utf8', 'POSIX'])

# Generated at 2022-06-11 01:09:43.452208
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['en_US.utf8', 'en_US.UTF-8', 'C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, ['en_US.utf8', 'en_US.UTF-8', 'POSIX']) == 'POSIX'

# Generated at 2022-06-11 01:09:49.629476
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class TestModule:
        def __init__(self):
            self.run_command_results = [0, "C.utf8\nen_US.utf8\nen_US.utf8\nC\nPOSIX\n"]
            self.get_bin_path_results = ['locale']

        def run_command(self, args):
            # Default state is success, for unit tests
            # we may return a tuple with a return code
            # other than 0 or a different response from
            # the locale command.
            res = self.run_command_results

            # If we have a list, pop the next response from the list
            if isinstance(res, list):
                res = self.run_command_results.pop(0)

            if isinstance(res, int):
                return res, "", ""
            return res

# Generated at 2022-06-11 01:10:02.522460
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.basic import AnsibleModule
    import os

    context = PlayContext()
    fake_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    fake_module.check_mode = False
    script = [
        'import sys',
        'from ansible.module_utils.basic import AnsibleModule',
        'from ansible.module_utils.connection import Connection',
        'from ansible.module_utils.six import StringIO',
        'import json',
        'import tempfile',
        'import time',
        'import os',
    ]
    script.append('_CONNECTION = Connection(module=AnsibleModule(argument_spec={}))')
    script

# Generated at 2022-06-11 01:10:08.982578
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import pytest
    from units.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(type='list', default=None),
            raise_on_locale=dict(type='bool', default=False),
        ),
        supports_check_mode=False,
    )

    # First test which should pass through
    result = get_best_parsable_locale(module, preferences=['C.UTF-8', 'en_US.UTF-8', 'C'])
    assert result == 'C.UTF-8'

    # Second test which should return default locale
    result = get_best_parsable_locale(module)
    assert result == 'C'

    # Third test which should return 'en_US.UTF-8'

# Generated at 2022-06-11 01:10:20.444817
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    from ansible.module_utils.common._collections_compat import Mapping

    class FakeAnsibleModule():

        def __init__(self, *args, **kwargs):
            self.command_results = {}
            self.bin_path = {}

        def run_command(self, cmd, check_rc, exc_on_err_rc, environ_update, data=None):
            if cmd[0] == 'locale':
                return (0, 'C\nen_US.utf8\nen_US.utf8\nen_US.UTF-8')
            else:
                return (255, 'Unable to get locale information', 'err')


# Generated at 2022-06-11 01:10:27.731878
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    assert get_best_parsable_locale(AnsibleModule(argument_spec={}), preferences=['C.utf8', 'en_US.utf8', 'POSIX'], raise_on_locale=False) == 'C'
    assert get_best_parsable_locale(AnsibleModule(argument_spec={}), preferences=['C.utf8', 'en_US.utf8', 'POSIX'], raise_on_locale=True) == 'C'
    assert get_best_parsable_locale(AnsibleModule(argument_spec={}), preferences=['C.utf8', 'en_US.utf8', 'POSIX']) == 'C'

# Generated at 2022-06-11 01:10:38.705222
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys

    try:
        # Python 2
        from ansible.module_utils._text import to_text
    except ImportError:
        # Python 3
        from ansible.module_utils._text import to_text
        unicode = str

    # Mock class for AnsibleModule
    class MockAnsibleModule(object):
        @staticmethod
        def get_bin_path(*args, **kwargs):
            raise RuntimeWarning

        @staticmethod
        def run_command(*args, **kwargs):
            return 0, '', ''

    def _test(module, preferences, expected):
        assert expected in get_best_parsable_locale(module, preferences)


# Generated at 2022-06-11 01:10:45.832883
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic as basic

    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)

    preferences = ['C.utf8', 'en_US.utf8']
    assert get_best_parsable_locale(module, preferences) == "C.utf8"

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(module, preferences) == "C.utf8"

# Generated at 2022-06-11 01:10:51.197629
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Assume that the locale command exists and works, return the first locale in preferences
    assert get_best_parsable_locale(preferences=['en_US.utf8', 'en_GB.utf8', 'C.utf8']) == 'en_US.utf8'

    # Assume that the locale command doesn't exist or fails, default to C
    assert get_best_parsable_locale(preferences=[]) == 'C'

# Generated at 2022-06-11 01:11:02.336711
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys

    class Module:
        def get_bin_path(self, name):
            if name == "locale":
                return "/usr/bin/locale"

        def run_command(self, args):
            # echo C.UTF-8 en_US.utf8 en_US.iso88591 POSIX C
            if args[0] == "/usr/bin/locale" and args[1] == "-a":
                return (0, "C.UTF-8\nen_US.utf8\nen_US.iso88591\nPOSIX\nC\n", None)
            else:
                raise AssertionError(args)


# Generated at 2022-06-11 01:11:12.055760
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    # Test whether the module.run_command method works
    results = module.run_command(['ls', '-1'])
    assert results[0] == 0

    # Test whether a RuntimeWarning is thrown if the locale command does not exist
    result = get_best_parsable_locale(module, raise_on_locale=False)
    assert result == 'C'

    # Test whether a RuntimeWarning is thrown if locale command does not return any output
    result = get_best_parsable_locale(module, raise_on_locale=True)
    assert result == 'C'

    # Test whether expected behavior when a preferred language is available

# Generated at 2022-06-11 01:11:21.634399
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.common.collections as collections

    # Stub out AnsibleModule for testing
    class AnsibleModuleStub:
        def __init__(self):
            self.params = {}
            self.result = collections.namedtuple('Result', ['__getitem__'])
            self.result.rc = 0
            self.result.stdout = "Output"
            self.result.stderr = "No error"

        def get_bin_path(self, path):
            return "locale"

        def run_command(self, command):
            return self.result

    # Test with an empty list of preferences
    ansible_module = AnsibleModuleStub()
    preferences = []

    # Assert that an exception is raised when an empty list of preferences is
    # used and that the default locale of '

# Generated at 2022-06-11 01:11:31.789850
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        pytest.skip("Couldn't load AnsibleModule - skipping test_get_best_parsable_locale")

    m = AnsibleModule()
    assert get_best_parsable_locale(m) == 'C'

# Generated at 2022-06-11 01:11:34.572421
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) is not None
    assert get_best_parsable_locale(module, raise_on_locale=True) is not None

# Generated at 2022-06-11 01:11:39.933145
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule(
        argument_spec=dict()
    )

    # should return the default 'C'
    assert get_best_parsable_locale(mod) == 'C'

    # should return the utf8 locale
    assert get_best_parsable_locale(mod, preferences=['en_US.utf8', 'en_US', 'C']) == 'en_US.utf8'

    # should return the utf8 locale again
    assert get_best_parsable_locale(mod, preferences=['en_US.utf8', 'C.utf8', 'C']) == 'en_US.utf8'

    # should return the default 'C'

# Generated at 2022-06-11 01:11:48.148503
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Tests the get_best_parsable_locale function

    :return:
    """
    from ansible.module_utils.basic import AnsibleModule

    def _my_run_command(args):
        """
        Mock function to test the run_command function from the passed AnsibleModule
        :param args:
        :return:
        """
        if args[1] == '-a':
            return 0, 'C\nen_US.utf8\n', ''
        elif args[1] == '-v':
            return 0, '', ''
        else:  # pragma: no cover
            raise Exception("Unknown locale command %s" % args)

    class MyModule(AnsibleModule):
        def __init__(self):
            super(MyModule, self).__init__
            self.params

# Generated at 2022-06-11 01:11:59.371798
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test get best parseable locale, there are two versions. what is available and what is installed,
    Since there is no simple way to test both from a unit test, we will only test the installed
    version, pretending we have a locale on a system that supports it and then testing that we
    are using the first locale in the list as expected.
    '''

    from ansible.module_utils.basic import AnsibleModule

    # save original locale
    tmp_locale = os.environ['LC_ALL']
    os.environ['LC_ALL'] = 'POSIX'

    # test path to the POSIX style
    module = AnsibleModule(argument_spec=dict())
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    # restore locale to original
    os.environ

# Generated at 2022-06-11 01:12:07.051404
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test that we use 'C' when no locale tool is available
    from ansible.modules.system import get_best_parsable_locale
    import ansible.module_utils.basic

    class FakeAnsibleModule:
        @staticmethod
        def get_bin_path(name):
            return None

        @staticmethod
        def run_command(name):
            return None

    assert get_best_parsable_locale(FakeAnsibleModule) == 'C'

# Generated at 2022-06-11 01:12:17.881465
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class Struct:
        pass

    mod = Struct()
    mod.run_command = lambda *args, **kwargs: (0, 'C\nC.UTF-8\nPOSIX', None)
    mod.get_bin_path = lambda *args, **kwargs: '/usr/bin/locale'
    assert get_best_parsable_locale(mod) == 'POSIX'

    mod.run_command = lambda *args, **kwargs: (0, 'C\nC.UTF-8\nPOSIX', None)
    mod.get_bin_path = lambda *args, **kwargs: None
    assert get_best_parsable_locale(mod) == 'C'

    mod.run_command = lambda *args, **kwargs: (1, None, 'failed')
    mod.get_

# Generated at 2022-06-11 01:12:26.871956
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # First test, no binary provided
    try:
        get_best_parsable_locale(None, raise_on_locale=True)
    except RuntimeError:
        pass
    else:
        raise AssertionError("Test failed. Expected failure.")
    # Second test, binary provided, but no stdout from binary
    try:
        get_best_parsable_locale({'run_command': lambda x, **y: (0, '', '')}, raise_on_locale=True)
    except RuntimeError:
        pass
    else:
        raise AssertionError("Test failed. Expected failure.")
    # Third test, binary provided, stdout from binary, but rc != 0

# Generated at 2022-06-11 01:12:38.682721
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # unit test is a bit weird, it assumes that the locale
    # program is there, on most systems it will be
    import random
    # in case where the locale program is not there, we will
    # get a fake module (mock_module)
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        from ansible.module_utils.basic import mock_module as AnsibleModule

    from ansible.compat.tests.mock import patch

    module = AnsibleModule(
        argument_spec=dict(),
    )

    # test that some random locale is there
    locale = module.get_bin_path('locale')

# Generated at 2022-06-11 01:12:50.838047
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class MockModule:
        def run_command(self, cmd):
            return (0, "C\nen_US.utf8\nen_US.iso88591\n", "")

        def get_bin_path(self, cmd):
            return '/usr/bin/locale'

    prefs = None
    module = MockModule()
    found_locale = get_best_parsable_locale(module, prefs)
    assert found_locale == 'C'

    prefs = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    module = MockModule()
    found_locale = get_best_parsable_locale(module, prefs)
    assert found_locale == 'en_US.utf8'


# Generated at 2022-06-11 01:13:16.525751
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(type='list', default=None)
        )
    )
    for i in range(len(module.params['preferences'])):
        if module.params['preferences'][i] != 'C':
            module.params['preferences'][i] = 'en_US.utf8'

    if module.params['preferences']:
        assert get_best_parsable_locale(module) == 'en_US.utf8'
    else:
        assert get_best_parsable_locale(module) == 'C'


if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-11 01:13:25.059290
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3

    test_data = {
        "hello": u'hello',
        "i18n": u'i18n',
        "i18nn": u'i18\ufffdn',
    }

    def gettext_noop(message, *args, **kwargs):
        if PY3:
            if isinstance(message, bytes):
                return message.decode('utf-8')
            else:
                return message
        else:
            return message

    def gettext_i18n(message, *args, **kwargs):
        if PY3:
            if isinstance(message, bytes):
                return test

# Generated at 2022-06-11 01:13:35.942399
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    assert get_best_parsable_locale(None) == 'C'

    assert get_best_parsable_locale(None, preferences=['C']) == 'C'
    assert get_best_parsable_locale(None, preferences=['POSIX']) == 'C'

    assert get_best_parsable_locale(None, preferences=['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, preferences=['POSIX', 'C']) == 'C'

    assert get_best_parsable_locale(None, preferences=['C', 'POSIX', 'en_US.utf8']) == 'C'

# Generated at 2022-06-11 01:13:46.282845
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    from shutil import rmtree

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    test_content = """
        #!/bin/sh
        case "$1" in
        -a)
            echo "C"
            ;;
        *)
            echo "locale: unknown option: $1"
            echo "Try 'locale --help' for more information."
            exit 1
            ;;
        esac
        """
    locale_bin_path = os.path.join(temp_dir, "locale")

    test_module = AnsibleModule(argument_spec={})
    test_module.get_bin_path = lambda args: locale_bin_path

    # create a test locale bin that returns

# Generated at 2022-06-11 01:13:54.442675
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    test_module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    # Test on a system where the locale command is not available
    test_module.run_command = lambda args: (1, '', '')
    assert get_best_parsable_locale(test_module, preferences=None, raise_on_locale=False) == 'C'

    # Test on a system where the locale command is available and works, and the C locale is present
    test_module.run_command = lambda args: (0, 'de_CH.UTF-8\nC\nC.UTF-8\nen_US.UTF-8', '')

# Generated at 2022-06-11 01:14:06.077887
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.common.removed as removed
    from ansible.module_utils.basic import AnsibleModule

    def get_bin_path(arg):
        return arg

    module = type("AnsibleModuleStub", (object,), {
        "run_command": lambda self, cmd: (0, "C\nen_US.utf8\nfr_FR\nfr_FR.iso88591\nfr_FR.utf8\nen_GB.iso88591", ""),
        "get_bin_path": get_bin_path,
        "fail_json": removed.fail_json,
        "warn": removed.warn,
    })()

    assert get_best_parsable_locale(module) == "C"


# Generated at 2022-06-11 01:14:08.844818
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    rc, out, err = module.run_command(['locale', '-a'])
    assert (rc == 0)
    assert ('en_US.utf8' in out.strip().splitlines())

# Generated at 2022-06-11 01:14:15.299281
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic as basic
    from ansible.module_utils.common._collections_compat import Mapping

    module = basic.AnsibleModule(argument_spec=dict())
    preferences = ['C.utf8', 'en_US.utf8']
    assert get_best_parsable_locale(module, preferences, raise_on_locale=True) in preferences

    class FakeModule(object):
        argument_spec = Mapping()

        def __init__(self, **kwargs):
            self.params = kwargs

        def run_command(self, command, use_unsafe_shell=False, close_fds=True):
            return 0, "", ""


# Generated at 2022-06-11 01:14:26.611315
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test that get_best_parsable_locale returns an expected value when run.
    '''

    # If no available or preferred locales are specified at all, then we
    # should get the default locale.
    assert get_best_parsable_locale(None) == 'C'

    # If the preferred locale is available, then we should get the preferred
    # locale back.
    assert get_best_parsable_locale(None, ['en_US.utf8', 'C'], True) == 'en_US.utf8'

    # If a preferred locale is not available, and the next preferred locale
    # is available, we should get the next preferred locale back.

# Generated at 2022-06-11 01:14:34.822520
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Validate that it returns first matched preferred locale or 'C' if not found
    '''
    invalid_locale = 'C'


# Generated at 2022-06-11 01:15:13.519112
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test for English locale.
    '''
    module = mock.MagicMock(spec=AnsibleModule)
    module.run_command.return_value = (0, 'C en_US en_US.utf8', None)
    module.get_bin_path.return_value = '/usr/bin/locale'
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'en_US.utf8'
    assert get_best_parsable_locale(module, None, raise_on_locale=True) == 'en_US.utf8'
    assert get_best_parsable_locale(module, ['C', 'C.utf8'], raise_on_locale=True) == 'C'
    assert get_best_p

# Generated at 2022-06-11 01:15:20.855633
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    preferences = ['test', 'test2', 'test3']

    def _run_func(result=0, out=None, err=None, path='', getting_locale_results=True,
                  raising_warnings=False, getting_warnings=False, locale_found=True):
        am = AnsibleModule(argument_spec={})

        def _run_command(cmd_list, tmp_path, executable_search_paths=None, binary_data=False, environ_update=None, encoding=None, errors='surrogate_then_replace', data=None, binary_data_suffix=None):
            return result, out, err

        def _get_bin_path(name):
            return path

        am.run_command = _run_command
       

# Generated at 2022-06-11 01:15:30.906315
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Simple test-case :
    test_get_best_parsable_locale
    '''

    from ansible.module_utils.basic import AnsibleModule

    # Test case 1
    # Test-case with default
    module = AnsibleModule()
    assert get_best_parsable_locale(module) == 'C'

    # Test case 2
    # Test-case with locale
    module = AnsibleModule()
    assert get_best_parsable_locale(module, preferences=['POSIX', 'C.utf8']) == 'C'

    # Test case 3
    # Test-case with non existing preferences, raise_on_locale=True
    module = AnsibleModule()

# Generated at 2022-06-11 01:15:40.907670
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    try:
        import unittest2
        import mock
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils.six import PY3
    except ImportError:
        raise ImportError("get_best_parsable_locale is unittest2 compatible only")

    class TestGetBestParsableLocale(unittest2.TestCase):

        def setUp(self):
            self.module_mock = mock.Mock(spec=AnsibleModule)
            self.module_mock.get_bin_path.return_value = 'locale'

        def test_no_prefs(self):
            self.module_mock.run_command.return_value = (0, 'en_US.utf8\nC\nen_US.utf8', '')


# Generated at 2022-06-11 01:15:50.731758
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import sys
    import os
    import mock

    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector import setup_locale_facts

    from ansible.module_utils._text import to_bytes

    fake_module = basic.AnsibleModule(
        argument_spec={},
    )

    fake_module.run_command = mock.Mock()

    best_locale = setup_locale_facts(fake_module)

    # We test for 3 different locale types
    #
    # The first is a locale that does not exist on the system, no matter how much we want it to exist.
    # In this case the function should return the default locale, 'C'.
    #
    # The second is a locale that exists on the system and is returned (the first available locale in
    # the

# Generated at 2022-06-11 01:16:00.735138
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # pylint: disable=import-error,redefined-outer-name,unused-import

    import mock
    mock_module = mock.Mock()
    mock_module.run_command.return_value = (0, "POSIX\nC\nC.UTF-8", "")
    result = get_best_parsable_locale(mock_module)
    assert result == "C"

    mock_module.run_command.return_value = (0, "POSIX\nC\nC.UTF-8", "")
    result = get_best_parsable_locale(mock_module, preferences=['POSIX', 'C.UTF-8'])
    assert result == 'C.UTF-8'


# Generated at 2022-06-11 01:16:05.094331
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test that the function get_best_parsable_locale returns the correct
    locale based on the current system.
    '''

    module = None
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    locale = get_best_parsable_locale(module, preferences)

    # Should be C until error check is properly handled
    assert locale == 'C'

# Generated at 2022-06-11 01:16:15.170600
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-11 01:16:24.522806
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = None

    # Test locale, locale -a, and get_bin_path failure
    assert get_best_parsable_locale(module) == 'C'

    # Test locale -a failure and get_bin_path failure
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

    # Test no preferences and get_bin_path failure
    preferences = None
    assert get_best_parsable_locale(module, preferences) == 'C'

    # Test locale, locale -a and preference failure
    preferences = ['de_DE.utf8', 'fr_FR.utf8', 'it_IT.utf8']
    assert get_best_parsable_locale(module, preferences) == 'C'

    # Test locale, locale -a and preference failure

# Generated at 2022-06-11 01:16:34.799021
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule({})
    module.get_bin_path = lambda x: '/usr/bin/locale'
    module.run_command = lambda x: (0, 'C\nen_CA.utf8\nen_US.utf8\nen_US.utf8\nen_CA.utf8\nen_US.utf8', '')

    locale = get_best_parsable_locale(module)
    assert locale == 'C'

    module.run_command = lambda x: (0, 'C\nen_CA.utf8\nen_US.utf8\nen_US.utf8\nen_CA.utf8\nen_US.utf8', '')
    preferences = ['en_US.utf8', 'en_CA.utf8']

# Generated at 2022-06-11 01:17:39.028515
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    # Testing 1: The function gets the right locales without any problems
    assert get_best_parsable_locale(module) == 'C'

    # Testing 2: Given preferences, the function returns the right locales
    preferences = ['fr_FR.UTF-8', 'C']
    assert get_best_parsable_locale(module, preferences=preferences) == 'C'

    # Testing 3: Given no available locales, the function should return C
    rc, out, err = module.run_command(['locale', '-a'])
    assert rc == 0
    assert out == ''
    assert err == ''

# Generated at 2022-06-11 01:17:50.204983
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale({}, ["en_US.utf8", "en_US.UTF-8", "C.UTF-8", "en_US.ISO8859-1", "en_US.ISO8859-15", "C", "POSIX"]) == "en_US.utf8"
    assert get_best_parsable_locale({}, ["en_US.utf8", "C.UTF-8", "en_US.ISO8859-1", "en_US.ISO8859-15", "C", "POSIX"]) == "en_US.utf8"

# Generated at 2022-06-11 01:17:58.789743
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # default test
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

    # test with existing locale
    assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX', 'de_DE.utf8']) == 'de_DE.utf8'

    # test error checking
    assert get_best_parsable_locale(module, ['de_DE.utf8']) == 'C'
    assert get_best_p

# Generated at 2022-06-11 01:18:09.879308
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    locale_path = os.getcwd()
    locale_files = []
    for filename in ['locale.mock', 'locale.mock.1', 'locale.mock.2', 'locale.mock.3', 'locale.mock.4']:
        locale_files.append(os.path.join(locale_path, filename))
    available_locales = ['C', 'POSIX', 'en_US.UTF-8', 'es_MX.UTF-8']

    test_results_pass = []
    test_results_fail = []

    for locale_file in locale_files:
        f = open(locale_file, 'w')

# Generated at 2022-06-11 01:18:16.012816
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # mock an AnsibleModule instance
    class AnsibleModule(object):
        def get_bin_path(self, name):
            if name == "locale":
                return "/usr/bin/locale"
            return None

        def run_command(self, arg):
            return 0, "C.utf8\n", None

    m = AnsibleModule()
    assert get_best_parsable_locale(m) == "C.utf8"

# Generated at 2022-06-11 01:18:23.520064
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    my_bin_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))))
    sys.path.insert(0, my_bin_path)
    from test.lib.ansible_module_runner import AnsibleModule
    import ansible.module_utils.basic

    module = AnsibleModule(
        argument_spec=dict()
    )

    locale = get_best_parsable_locale(module)

    print("Locale: %s" % locale)
    ansible.module_utils.basic.syslog(str(locale))

# Generated at 2022-06-11 01:18:31.283606
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    class FakeModule(object):
        def __init__(self):
            self._result = dict(
                failed=False,
                changed=False,
                rc=0,
                stderr='',
                stdout=''
            )

        def get_bin_path(self, name, required=False):
            if name == 'locale':
                return '/usr/bin/locale'

            raise ValueError("Unexpected bin_path = %s" % name)

        def run_command(self, cmd, check_rc=None, close_fds=False, executable=None, data=None):
            if cmd == ['/usr/bin/locale', '-a']:
                self._result

# Generated at 2022-06-11 01:18:41.303389
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Sample output from 'locale -a'
    LANGUAGE_LIST = '''C
en_US.utf8
en_US
en_GB.utf8
en_GB'''.splitlines()

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()

    found = get_best_parsable_locale(module, preferences=None)
    assert found in LANGUAGE_LIST
    assert found in ['C', 'en_US.utf8']

    found = get_best_parsable_locale(module, preferences=['be_BY.utf8'])
    assert found in LANGUAGE_LIST
    assert found in ['C', 'be_BY.utf8']

    found = get_best_parsable_locale(module, preferences=['C'])