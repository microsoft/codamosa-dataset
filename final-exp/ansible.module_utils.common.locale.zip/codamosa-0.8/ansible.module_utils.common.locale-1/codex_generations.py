

# Generated at 2022-06-11 01:08:45.379105
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    update_environment('LANG', 'INVALID_LOCALE')
    assert 'C' == get_best_parsable_locale()

    set_environment('INVALID_LOCALE')
    assert 'C' == get_best_parsable_locale()

    set_environment('POSIX')
    assert 'POSIX' == get_best_parsable_locale()

    set_environment('en_US.UTF-8')
    assert 'en_US.utf8' == get_best_parsable_locale()

    set_environment('C')
    assert 'C' == get_best_parsable_locale()

    set_environment('C.UTF-8')
    assert 'C.utf8' == get_best_parsable_locale()


# Generated at 2022-06-11 01:08:47.482782
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, None) == 'C'



# Generated at 2022-06-11 01:08:54.926578
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import mock

    preferences = ['en_US.UTF-8', 'fr_FR.UTF-8', 'C.UTF-8', 'en_US.UTF-8', 'fr_FR.UTF-8', 'C']


# Generated at 2022-06-11 01:09:03.951820
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test the functionality of the get_best_parsable_locale function
    '''
    import unittest

    class TestAvailalbeLocales(unittest.TestCase):
        '''
            A class that tests the availablity of locales on a system
        '''
        def setUp(self):
            '''
                A function that initializes the test class
            '''
            # Dummy AnsibleModule instance
            import ansible.module_utils.basic

            class DummyModule(ansible.module_utils.basic.AnsibleModule):
                '''
                    A dummmy ansible module class
                '''
                def get_bin_path(self, binary):
                    '''
                        A function that returns the binary path
                    '''
                    return '/usr/bin/locale'

# Generated at 2022-06-11 01:09:10.984484
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    fake_module = type('fake_module', (object,), {
        'get_bin_path': lambda self, application: '/bin/locale',
        'run_command': lambda self, args: (0, 'en_US.utf8', ''),
    })

    best_locale = get_best_parsable_locale(fake_module())

    assert best_locale == 'en_US.utf8'

    fake_module = type('fake_module', (object,), {
        'get_bin_path': lambda self, application: '/bin/locale',
        'run_command': lambda self, args: (0, '', 'Hello, this is your computer speaking'),
    })

    best_locale = get_best_parsable_locale(fake_module())


# Generated at 2022-06-11 01:09:16.332835
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, None, False) == 'C'
    assert get_best_parsable_locale(None, ['en_US.utf8'], False) == 'C'
    assert get_best_parsable_locale(None, ['non_existent.utf8'], False) == 'C'

# Generated at 2022-06-11 01:09:17.701624
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale = get_best_parsable_locale()
    assert locale == 'C'

# Generated at 2022-06-11 01:09:28.392358
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test function: get_best_parsable_locale
    '''

    import pytest

    from ansible.module_utils import basic
    from ansible.module_utils.platform import get_os_platform

    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.basic import AnsibleModule

    # Create a mocked ansible module
    module = basic._AnsibleModule({})

    # Mock os.uname() to return a known result
    def uname(system_call):
        '''
        Mock function for os.uname()
        '''

# Generated at 2022-06-11 01:09:39.340630
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Bad scenario when 'locale' command is not found
    # Expected result: Fall back to 'C'
    assert get_best_parsable_locale(
        module=None,
        preferences=None,
        raise_on_locale=False,
    ) == 'C'

    # Bad scenario when locale information is not found
    # Expected result: Fall back to 'C'
    assert get_best_parsable_locale(
        module=MockModule(MockRunCommand([0, '', ''])),
        preferences=None,
        raise_on_locale=False,
    ) == 'C'

    # Good scenario when preferred locales are available
    # Expected result: Return the first found preferred locale

# Generated at 2022-06-11 01:09:47.935691
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import os
    import mock
    import ansible.module_utils.locale


# Generated at 2022-06-11 01:09:53.305249
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    raise AnsibleModule

# Generated at 2022-06-11 01:09:58.323461
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # TODO:  This tests the function, but it would be nice if we had a better way to do this
    try:
        locale = get_best_parsable_locale(None, ['C.UTF-8'])
        assert locale == 'C.UTF-8'
    except:
        pass

test_get_best_parsable_locale()

# Generated at 2022-06-11 01:10:04.652247
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
      Unit test for function get_best_parsable_locale
    '''

    from ansible.module_utils.basic import AnsibleModule

    class AnsibleModuleMock(AnsibleModule):
        '''
            Fake class for AnsibleModule
        '''

        def __init__(self, *args, **kwargs):
            '''
                Constructor
            '''

            AnsibleModule.__init__(self, *args, **kwargs)

        def run_command(self, args, check_rc=True):
            '''
                Fake run_command function
            '''

            rc = 0
            out = ''
            err = ''

            if args == ['locale', '-a']:

                if AnsibleModuleMock.raise_warning_on_locale:
                    raise RuntimeWarning

# Generated at 2022-06-11 01:10:07.552704
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:10:18.828682
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Test for 'C'
    module = AnsibleModule(argument_spec=dict())
    locale = get_best_parsable_locale(module, ['NoLocaleExists.utf8'])
    assert locale == 'C'

    # Test for 'en_US.utf8'
    module = AnsibleModule(argument_spec=dict())
    locale = get_best_parsable_locale(module, ['en_US.utf8'])
    assert locale == 'en_US.utf8'

    # Test for 'POSIX'
    module = AnsibleModule(argument_spec=dict())
    locale = get_best_parsable_locale(module, ['POSIX'])
    assert locale == 'POSIX'

    # Test for 'en

# Generated at 2022-06-11 01:10:27.022982
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    preferences = ['en_US.UTF-8', 'C.utf8', 'POSIX']
    # Test that missing locale raises
    try:
        module = AnsibleModule(argument_spec={})
        get_best_parsable_locale(module, preferences=preferences, raise_on_locale=True)
        assert False, 'Should raise'
    except:
        pass
    # Test that missing preferences default to 'C'
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['no_such_thing']) == 'C'

# Generated at 2022-06-11 01:10:38.279824
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # This requires a system that has "C"
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.local import get_bin_path
    from ansible.module_utils.common.process import get_bin_path as get_bin_path_common
    import sys

    # Mock AnsibleModule as it cannot be instantiated without arguments
    module = AnsibleModule(argument_spec=dict())
    # Mock module.get_bin_path()
    module.get_bin_path = get_bin_path
    # Mock module.run_command()

# Generated at 2022-06-11 01:10:39.008330
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-11 01:10:49.443212
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils
    class FakeModule():
        def __init__(self):
            self.debug_called = False
            self.warn_called = False
            self.params = []

        def get_bin_path(self, *args, **kwargs):
            return 'locale'

        def run_command(self, *args, **kwargs):
            rc = 0
            out = None
            err = None
            if args[0] == ['locale', '-a']:
                out = ['en_US.utf8', 'C', 'POSIX']
            elif args[0] == ['locale', '-a'] and kwargs['check_rc']:
                rc = 1
            return rc, out, err

        def debug(self, *args, **kwargs):
            self.debug

# Generated at 2022-06-11 01:11:00.556516
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module=module)
    assert locale == 'C'

    # setup test
    module = AnsibleModule(argument_spec={})
    module.run_command = mock_run_command
    locale = get_best_parsable_locale(module=module)
    assert locale == 'C'

    # setup test
    module = AnsibleModule(argument_spec={})
    module.run_command = mock_bad_run_command
    locale = get_best_parsable_locale(module=module)
    assert locale == 'C'

    # setup test
    module = AnsibleModule(argument_spec={})
    module.run_command = mock

# Generated at 2022-06-11 01:11:13.532653
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    options_dummy = object()
    basic = {'run_command': lambda x, encoding=None, check_rc=True, close_fds=True, executable=None, data=None: (0, x[1], '')}
    module_dummy = type("Module", (object,), basic)
    assert get_best_parsable_locale(module_dummy, preferences=['POSIX']) == 'POSIX'
    assert get_best_parsable_locale(module_dummy, preferences=['POSIX'], raise_on_locale=True) == 'POSIX'

    # if locale command is not found, we don't care, only when you set to raise exception

# Generated at 2022-06-11 01:11:23.154547
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.six import StringIO

    class AnsibleModuleFake(object):
        def __init__(self, text):
            self._text = text

        def get_bin_path(self, app, required=False):
            if app == 'locale':
                return 'locale'
            elif app == 'foo':
                raise RuntimeWarning("Could not find 'foo' tool")
            else:
                return None

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            if args[0] == 'locale' and args[1] == '-a':
                return 0, self._text, None
            else:
                return 1, '', None

    # Test with no module argument

# Generated at 2022-06-11 01:11:32.656548
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic as basic

    # Test case where basic.get_bin_path('locale') returns True
    def get_bin_path(name):
        if name == 'locale':
            return name

    module = basic.AnsibleModule(argument_spec={
    })
    module.get_bin_path = get_bin_path

    # try_exec_command
    def try_exec_command(name, args, run_in_check_mode=False, executable=None, shell=False,
                         environ_update=None, encoding='utf-8', errors='surrogate_or_strict',
                         binary_data=False,
                         path_prefix=None, cwd=None):
        if name == 'locale':
            return (0, 'C.utf8', '')

   

# Generated at 2022-06-11 01:11:41.128943
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test with tool not available
    class MockModule(object):
        def get_bin_path(self, tool):
            return None

        def run_command(self, args):
            raise Exception("Should not happen")

    module = MockModule()

    # Should not raise exception
    result = get_best_parsable_locale(module, preferences=['foo', 'bar'], raise_on_locale=False)
    assert result == 'C'

    # Should raise exception
    try:
        result = get_best_parsable_locale(module, preferences=['foo', 'bar'], raise_on_locale=True)
        assert False, "Should have raised exception"
    except Exception as e:
        assert str(e) == "Could not find 'locale' tool"

    # Test when the locale tool works

# Generated at 2022-06-11 01:11:48.119770
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})

    # Test case 1
    # The function should return 'en_US.utf8' or 'POSIX' by default.
    # If neither locales are present, 'C' is returned
    assert get_best_parsable_locale(module) in ['en_US.utf8', 'POSIX', 'C']

    # Test case 2
    # The function should return 'en_US.utf8' if it's present in the list
    # of available locales
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.utf8'

# Generated at 2022-06-11 01:11:59.320524
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.locale import get_best_parsable_locale
    from ansible.module_utils.basic import AnsibleModule
    assert get_best_parsable_locale(AnsibleModule(argument_spec={})) == 'C'
    # Test that get_best_parsable_locale gets the first match, works
    # with sublocales and works with things that aren't in the locales list
    preferences = ['en_US.UTF-8', 'en_US', 'en_US.utf8', 'en_GB.utf8',
                   'en_GB.UTF-8', 'en_GB', 'fr_FR.utf8', 'fr_FR.UTF-8', 'fr_FR',
                   'C']
    for locale in preferences:
        assert get_best_

# Generated at 2022-06-11 01:12:09.010077
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Import required for testing
    import ansible.module_utils.basic as basic_module

    # Create an Ansible module
    module = basic_module.AnsibleModule(
        argument_spec=dict(),
    )

    # No preferences given, call get_best_parsable_locale
    get_best_parsable_locale(module,None,False)

    # With preference given, call get_best_parsable_locale
    preference = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    get_best_parsable_locale(module,preference,False)

# Generated at 2022-06-11 01:12:13.996377
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    module = AnsibleModule(argument_spec={})

    found = get_best_parsable_locale(module, preferences)

    if found is None:
        print('fail: expected %s got %s' % (preferences[0], found))
    else:
        print('success: expected %s got %s' % (preferences[0], found))

# Generated at 2022-06-11 01:12:24.936652
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Sequence

    locale_a = to_bytes(
'''
C
C.UTF-8
de_DE.utf8
en_US.utf8
POSIX
'''
    )
    locale_b = to_bytes(
'''
C
de_DE.utf8
POSIX
'''
    )
    locale_c = to_bytes(
'''
fr_FR.utf8
'''
    )
    locale_d = to_bytes(
'''
C.UTF-8
C.UTF8
de_DE.utf8
en_US.utf8
POSIX
'''
    )
    locale

# Generated at 2022-06-11 01:12:36.986976
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    p = []
    p.append({"ANSIBLE_LOCALE_UTILS_LOCALE": "/usr/bin/locale"})
    p.append({"ANSIBLE_LOCALE_UTILS_LOCALE": "/usr/bin/locale",
              "ANSIBLE_LOCALE_UTILS_LOCALE_OUTPUT": """C
C.UTF-8
en_US.utf8""",
             "ANSIBLE_LOCALE_UTILS_LOCALE_RETURN_CODE": 0})

# Generated at 2022-06-11 01:12:56.403252
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'C'
    assert get_best_parsable_locale(module, ['C']) == 'C'
    assert get_best_parsable_locale(module, ['C.utf8']) == 'C'
    assert get_best_parsable_locale(module, ['POSIX']) == 'C'

# Generated at 2022-06-11 01:13:02.812731
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test to check if the best locale is identified as expected
    '''
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    locale_file = tempfile.NamedTemporaryFile(delete=False)
    locale_file.write("C\nC.utf8\nen_US.utf8\nen_US.utf8\nen_US.")
    locale_file.flush()
    def get_path(self, name):
        if name == 'locale':
            return locale_file.name
        else:
            return None

    def run_command(self, command):
        return (0, locale_file.read(), '')

    def test_module():
        AnsibleModule.get_bin_path = get_path
        AnsibleModule.run_command = run_command



# Generated at 2022-06-11 01:13:07.050716
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    preferred_locales = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']


# Generated at 2022-06-11 01:13:18.697805
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    r'''
    Smoketest three cases:
        1) `locale -a` returns a locale,
        2) `locale -a` returns nothing,
        3) `locale -a` errors.

    Expected output:
        "de_DE.utf8"
        "C"
        "C"

    :return None:
    '''

    from ansible.module_utils import basic

    class MockModule:
        def __init__(self, rc, out, err, bin_path):
            self.rc = rc
            self.out = out
            self.err = err
            self.bin_path = bin_path

        def get_bin_path(self, name):
            return self.bin_path


# Generated at 2022-06-11 01:13:25.671184
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class FakeModule:
        def __init__(self):
            self.__bin_path_cache = {}
            self.__bin_path_check_cache = {}
            self.__bin_path_empty_cache = {}

        def get_bin_path(self, name, **kwargs):
            if name in kwargs.get('required_binaries', []) or name not in self.__bin_path_cache:
                raise RuntimeWarning("Could not find %s" % name)
            return self.__bin_path_cache[name]

        def run_command(self, args):
            if len(args) != 2:
                raise RuntimeError("locale command invoked with incorrect number of arguments")

# Generated at 2022-06-11 01:13:36.619220
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences = ['en_US.utf8', 'en_US.utf8', 'en_US.utf8', 'en_US.utf8', 'en_US.utf8', 'en_US.utf8', 'en_US.utf8', 'en_US.utf8', 'en_US.utf8', 'en_US.utf8', 'en_US.utf8', 'en_US.utf8', 'en_US.utf8', 'en_US.utf8']
    found = 'en_US.utf8'

# Generated at 2022-06-11 01:13:46.898380
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import common_koji

    preference_list = ["de_DE.utf8", "fr_FR.utf8", "fr_FR.UTF-8", "C", "POSIX"]

    # Mock an AnsibleModule object
    # Note: Module is mocked in order to avoid false failures due to locale differences
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda l: (0, "de_DE.utf8\nfr_FR.utf8\nC\nPOSIX", "")
    assert common_koji.get_best_parsable_locale(module, preference_list) == "de_DE.utf8"


# Generated at 2022-06-11 01:13:56.357708
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test function for function get_best_parsable_locale.
        Arguments:
        module (object): AnsibleModule object
        preferences (list): A list of preferred locales, in order of preference
        raise_on_locale (bool): boolean that determines if we raise exception or not
                                due to locale CLI issues
    '''

    from ansible.module_utils.six.moves import StringIO

    import ansible.module_utils.basic
    from ansible.module_utils.ansible_release import __version__ as ansible_version

    from ansible.module_utils.basic import AnsibleModule

    # Get best locale function
    def mock_get_bin_path(cmd, required=False):
        '''
            Mock function to get the bin path of the locale command
        '''

# Generated at 2022-06-11 01:14:07.553133
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import gettext
    import locale

    lc, encoding = locale.getdefaultlocale()
    assert lc is not None
    assert encoding is not None
    assert get_best_parsable_locale(None) == lc

    assert get_best_parsable_locale(None, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'
    assert get_best_parsable_locale(None, preferences=['en_US.utf8', 'en_US.utf8', 'en_US.utf8', 'en_US.utf8']) == 'en_US.utf8'

# Generated at 2022-06-11 01:14:16.641095
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # We cannot use ansible.module_utils.basic.AnsibleModule, because that would import
    # the whole ansible.module_utils.basic, which would cause many "zipimporter" errors.
    class AnsibleModule():
        def __init__(self):
            self.params = {}
            self.fail_json = lambda *args, **kwargs: None

        def get_bin_path(self, path):
            if path == 'locale':
                return path

        def run_command(self, cmd):
            if cmd == ['locale', '-a']:
                return 0, 'C\nen_US.utf8\nPOSIX\n', None
            raise Exception('Calling run_command with wrong argument')

    # Test 1: we have 'C.utf8' and 'en_US.utf8', that should

# Generated at 2022-06-11 01:14:40.793135
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO

    module = AnsibleModule(argument_spec={})

    module.run_command = lambda x, **kw: (0, 'C\nen_US.utf8\nen_US.UTF-8\nen_US\n', '')
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    module.run_command = lambda x, **kw: (0, 'de_DE\nde_DE.utf8\nde_DE.UTF-8\nC\nen_US.utf8\nen_US.UTF-8\nen_US\n', '')

# Generated at 2022-06-11 01:14:46.833016
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import C

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    found = 'C'
    for pref in preferences:
        if pref in C:
            found = pref
            break

    assert get_best_parsable_locale(AnsibleModule(argument_spec={})) == found

# Generated at 2022-06-11 01:14:57.255587
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class MockModule(object):
        def __init__(self):
            self.called = []
        def get_bin_path(self, c):
            self.called.append(c)
            return c
        def run_command(self, cmd):
            if cmd[0] != 'locale':
                raise RuntimeError("Called with non-locale command %s" % cmd[0])
            if cmd[-1] == '-a':
                return (0, "C\nen_US.utf8", None)
            else:
                raise RuntimeError("Called for non-option %s" % cmd[-1])
    m = MockModule()
    assert get_best_parsable_locale(m) == 'en_US.utf8'
    assert m.called == ['locale']

    m = Mock

# Generated at 2022-06-11 01:15:04.785938
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    locale_good = "/usr/bin/locale"
    locale_bad = "/bin/false"

    good_rc = '''LANG=C
LANGUAGE=C
LC_CTYPE="C"
LC_NUMERIC="C"
LC_TIME="C"
LC_COLLATE="C"
LC_MONETARY="C"
LC_MESSAGES="C"
LC_PAPER="C"
LC_NAME="C"
LC_ADDRESS="C"
LC_TELEPHONE="C"
LC_MEASUREMENT="C"
LC_IDENTIFICATION="C"
LC_ALL=C
'''


# Generated at 2022-06-11 01:15:12.243957
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict()
    )
    # Test with good locale
    locale = get_best_parsable_locale(module, ['C.utf8'])
    assert locale == 'C.utf8'
    # Test with bad locale
    locale = get_best_parsable_locale(module, ['es_MX.utf8'])
    assert locale == 'C'

# Generated at 2022-06-11 01:15:13.169359
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 01:15:20.692704
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test function get_best_parsable_locale with a
    set of hard-coded data.
    :return:
    '''
    from ansible.module_utils.basic import AnsibleModule
    import os
    import os.path

    fake_locale = os.path.join(os.path.dirname(__file__), 'fake_locale')


# Generated at 2022-06-11 01:15:30.440468
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Create a dummy ansible module
    m = AnsibleModule(argument_spec={})

    # Test against all the locales that are in the fixtures
    for locale in TEST_LOCALE_FILES:
        assert get_best_parsable_locale(m, preferences = [locale]) == locale
        assert get_best_parsable_locale(m, preferences = [locale, "es_ES.utf8"]) == locale

    # Make sure it raises an exception when a locale isn't found
    try:
        get_best_parsable_locale(m, preferences = ["asdfasdf"], raise_on_locale=True)
        assert False
    except:
        assert True


# Generated at 2022-06-11 01:15:40.420050
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic as basic
    from ansible.module_utils.common._collections_compat import StringIO
    import mock
    from ansible.module_utils._text import to_bytes

    preferences = ['C', 'en_US.utf8', 'en_US.utf8', 'C']

    rc = 0
    err = ''
    out = 'C\nen_US.utf8\nen_US.utf8\nC'

    # Test that the preferences are in the order that we expect
    mod = basic.AnsibleModule(
        argument_spec=dict(),
    )
    with mock.patch.object(mod, 'run_command') as run_command:
        run_command.return_value = rc, out, err
        locale_found = get_best_parsable_locale

# Generated at 2022-06-11 01:15:49.866779
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test the get_best_parsable_locale function
    '''
    import pwd
    import socket
    import tempfile
    import sys

    # The AnsibleModule class is made globally available by ansible base
    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.local_ansible_utils_extension import get_best_parsable_locale

    # We need the user who is running the test for future tests
    user = pwd.getpwuid(os.geteuid())[0]

    # All successful results

# Generated at 2022-06-11 01:16:14.520783
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import tempfile
    import pytest

    # default preference on CentOS is ['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    test_preferences = [
        ['C.utf8', 'en_US.utf8', 'C', 'POSIX'],
        ['en_US.utf8', 'C.utf8', 'POSIX', 'C'],
        ['C.utf8'],
        ['C'],
        ['POSIX'],
    ]

    # CentOS 7

# Generated at 2022-06-11 01:16:23.992288
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Import system modules
    import sys
    import os
    import shutil
    import tempfile
    import json

    # Import testinfra modules
    from testinfra.utils.ansible_runner import AnsibleRunner
    from testinfra.utils.ansible_runner import ansible_module_args

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    config_filename = os.path.join(tmpdir, 'ansible.cfg')
    with open(config_filename, 'w') as config_file:
        config_file.write('[defaults]\nroles_path=../../')

    # Create a temporary hosts file
    hosts_filename = os.path.join(tmpdir, 'hosts')

# Generated at 2022-06-11 01:16:30.534086
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule, get_bin_path
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = get_bin_path

    test = get_best_parsable_locale(module)
    assert test == 'C'

    # test non-default preference
    test = get_best_parsable_locale(module, preferences=['POSIX'])
    assert test == 'POSIX'

# Generated at 2022-06-11 01:16:39.732897
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module_mock = ansible.module_utils.basic.AnsibleModule(
        argument_spec={}
    )
    locale = module_mock.get_bin_path("locale")
    module_mock.run_command = lambda x, environ_update=None: (0, 'C.utf8\nen_US.utf8\nC', '')
    assert get_best_parsable_locale(module_mock, preferences=None, raise_on_locale=False) == 'C.utf8'

    module_mock.run_command = lambda x, environ_update=None: (0, '\nC.utf8\nen_US.utf8\nC\nPOSIX\n', '')
    assert get_best_pars

# Generated at 2022-06-11 01:16:41.401182
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C', "POSIX locale should be available"

# Generated at 2022-06-11 01:16:50.167253
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    am = ansible.module_utils.basic.AnsibleModule('', '')

    class MockModule(object):
        def __init__(self):
            self.fail_json = am.fail_json
            self.params = {}
            self.params['remote_tmp'] = ''
            self.params['local_tmp'] = ''

        def get_bin_path(self, name):
            if name == 'locale':
                return 'locale'

        def run_command(self, cmd):
            # no locale or command not found
            if cmd == 'locale' or cmd == ['locale', '-a']:
                return (1, '', '')

            # Simulate 2 good conditions

# Generated at 2022-06-11 01:16:53.531954
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-11 01:16:57.379070
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    unit test for get_best_parsable_locale function
    '''

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:17:06.548589
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class MockModule(object):
        def get_bin_path(self, binary):
            ''' Mocking the get_bin_path function in AnsibleModule'''
            locale = '/usr/bin/locale'
            if binary == 'locale':
                return locale
            if binary != '/usr/bin/locale':
                return None

        def run_command(self, cmd):
            ''' Mocking the run_command function in AnsibleModule'''
            return_value = 0
            return_error = ''
            return_output = ''

            if cmd == [locale, '-a']:
                return_output = 'C\nC.UTF-8\nPOSIX\nen_US.utf8'
            else:
                return_value = 1
                return_error = 'Could not find locale'

            return return_

# Generated at 2022-06-11 01:17:13.120274
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # only require locale tool when running as part of locale test
    assert get_best_parsable_locale({'get_bin_path': lambda *args, **kwargs: 'locale'}, raise_on_locale=True) == 'C'
    assert get_best_parsable_locale({'get_bin_path': lambda *args, **kwargs: False}, raise_on_locale=True) == 'C'

    # test when no preference is given

# Generated at 2022-06-11 01:17:35.156373
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    # Testing for an error scenario for command execution
    am = AnsibleModule({})
    am.run_command = lambda x: (1, '', 'No such file')
    assert get_best_parsable_locale(am) == 'C'

    # Testing for an error scenario for empty output
    am = AnsibleModule({})
    am.run_command = lambda x: (0, '', '')
    try:
        get_best_parsable_locale(am)
    except RuntimeWarning:
        pass
    else:
        raise Exception('Accepting empty out for locale -a')

    # Testing for an error scenario for unexpected output
    am = AnsibleModule({})


# Generated at 2022-06-11 01:17:41.657383
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Attempt using each locale until one is found
    found = get_best_parsable_locale(preferences=['en_US.UTF-8', 'C'])
    assert found == 'en_US.UTF-8' or found == 'C'

    # French language is not found, C is returned
    found = get_best_parsable_locale(preferences=['fr_FR.UTF-8', 'C'])
    assert found == 'C'

# Generated at 2022-06-11 01:17:52.344420
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test 1: All tests here are for 'C' locale
    import logging
    import os
    import unittest

    from ansible.module_utils.basic import AnsibleModule

    class MockModule:
        def __init__(self, logging_level=None):
            self.logging_level = logging_level
            self.logger = logging.getLogger(__name__)
            logging.basicConfig(level=self.logging_level)

        @staticmethod
        def get_bin_path(tool):
            return tool

        def run_command(self, command):
            if command == ['locale', '-a']:
                return 0, 'C\nC.utf8\nen_US.utf8\nen_US.utf8', ''
            else:
                return 1, '', ''


# Generated at 2022-06-11 01:17:53.608280
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-11 01:18:03.357644
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, ['POSIX', 'foo_BAR', 'bar_BAZ']) == 'POSIX'

    # If a locale is available in the available locales list, it should be found.
    preferences = ['POSIX', 'foo_BAR', 'bar_BAZ']
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: x
    module.run_command = lambda x: (0, '\n'.join(preferences) + '\n', '')

# Generated at 2022-06-11 01:18:14.191462
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test function get_best_parsable_locale
    :return: Test results
    '''
    try:
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils.common._collections_compat import Mapping
    except ImportError:
        raise ImportError('Get best parsable locale unit test must be run with ansible.  '
                          'Use "ansible-playbook -i tests/inventory tests/test.get_best_parsable_locale.yml"')

    import platform
    import unittest

    # Helper functions for test suite
    class TestAnsibleModule(AnsibleModule):
        def __init__(self):
            pass


# Generated at 2022-06-11 01:18:23.725051
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test that we get the best locale
    '''
    import unittest.mock as mock

    preferences = ['x.utf8', 'y.utf8', 'z', 'POSIX']

    with mock.patch('ansible.module_utils.basic.get_bin_path') as gbp_mock:
        with mock.patch('ansible.module_utils.basic.AnsibleModule.run_command') as rc_mock:
            # fake locale
            gbp_mock.return_value = '/usr/bin/locale'

            # fake output from locale -a with different prefs

# Generated at 2022-06-11 01:18:26.159966
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    test_get_best_parsable_locale
    :return:
    '''
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule(argument_spec={})

    assert am.get_best_parsable_locale() == 'C'

# Generated at 2022-06-11 01:18:31.127007
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    # Check for best locale
    assert get_best_parsable_locale(module) == 'C'

    # Non-existing locale in preferences
    assert get_best_parsable_locale(module, ['fr_FR.utf8']) == 'C'

    # Existing locale from preferences
    assert get_best_parsable_locale(module, ['en_US.utf8']) == 'en_US.utf8'

# Generated at 2022-06-11 01:18:33.698205
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule(argument_spec=dict())
    locale = get_best_parsable_locale(am)
    assert locale == 'C'