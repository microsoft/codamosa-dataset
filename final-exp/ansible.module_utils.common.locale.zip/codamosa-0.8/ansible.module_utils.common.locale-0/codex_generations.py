

# Generated at 2022-06-11 01:08:45.933630
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale

        :returns: True if unit test passed, otherwise False
    '''

    import tempfile
    import os

    names = ['C', 'POSIX', 'en_US.utf8', 'test_test.test', 'test_test.test.test', 'test_test.test.test.test']
    accepted = [True, True, True, True, False, False]
    test_passed = True

    tempdir = tempfile.mkdtemp()
    file_path = os.path.join(tempdir, 'locale')

    with open(file_path, 'w') as test_file:
        for index, name in enumerate(names):
            test_file.write(name)
            test_file.write('\n')



# Generated at 2022-06-11 01:08:55.955028
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    # Test case 1 - happy path, find one of the preferred locales
    available_locales = [
        'en_US.utf8',
        'en_US.utf-8',
        'POSIX'
    ]
    preferred_locales = [
        'en_US.utf8',
        'POSIX'
    ]

    found = get_best_parsable_locale(module, preferred_locales)
    assert found in available_locales

    # Test case 2 - can't find the preferred locale, default to C locale
    available_locales = [
        'POSIX'
    ]

# Generated at 2022-06-11 01:08:58.763457
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Create a new AnsibleModule instance
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Run the function with a given locale and assert the expected result
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:09:00.383367
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    assert get_best_parsable_locale(ansible.module_utils.basic.AnsibleModule(argument_spec={})) == 'C'

# Generated at 2022-06-11 01:09:08.292092
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    AnsibleModule is a class defined in common/module_common.py
    constructor for AnsibleModule requires only 2 arguments
    1. argument_spec(argument spec)
    2. supports_check_mode(support check mode)
    '''
    class AnsibleModule(object):
        def __init__(self, argument_spec, support_check_mode):
            self.argument_spec = argument_spec
            self.support_check_mode = support_check_mode

        def get_bin_path(self, tool):
            '''
                get_bin_path returns the path to the executable program 'tool'

                :param tool: name of a program
                :returns: path to the program
            '''
            if tool == 'locale':
                return tool


# Generated at 2022-06-11 01:09:18.960759
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    import sys

    class FakeModule(object):
        ''' Class to mock AnsibleModule. '''

        def __init__(self):
            self.params = {}
            self.fail_json = None
            self.run_command_response = 0, 'C C.UTF-8 POSIX en_US.utf8', 'OK'

        def get_bin_path(self, command, required=True):
            return command

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            return self.run_command_response


# Generated at 2022-06-11 01:09:29.228627
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile
    import shutil
    import os
    import sys

    class FakeModule(object):
        def __init__(self, tmpdir, rc, out, err):
            self.tmpdir = tmpdir
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, name):
            return os.path.join(self.tmpdir, name)

        def run_command(self, cmd):
            return (self.rc, self.out, self.err)

    # Dummy locale output for English and French
    locale_output = '''
C
C.UTF-8
en_US.utf8
fr_FR.utf8
'''
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-11 01:09:40.216581
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Case when no preferences are passed, then C should be returned as default
    # This test case also check whether the default default value is C
    assert get_best_parsable_locale(None) == 'C'

    # Case when preferences are passed and matched, the first matched preferred
    # locale should be returned
    preferences = ['C', 'C.utf8', 'POSIX', 'POSIX.utf8', 'en_US.utf8']
    assert get_best_parsable_locale(None, preferences) == 'C'

    # Case when preferences are passed but NO ONE of them matched, the first
    # preferred locale should be returned
    preferences = ['test', 'no_match', 'test_test']
    assert get_best_parsable_locale(None, preferences) == 'test'

    # Case when preferences are passed

# Generated at 2022-06-11 01:09:42.735235
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:09:45.274475
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale = get_best_parsable_locale(None)
    assert locale == 'C' or locale == 'POSIX', 'locale is not POSIX or C: %s' % locale

# Generated at 2022-06-11 01:09:51.222899
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale() == 'C'

# Generated at 2022-06-11 01:10:00.867032
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(argument_spec=dict())

    # test get_best_parsable_locale when we expect to return C:
    try:
        assert (m.get_bin_path("locale") is None)
        assert (get_best_parsable_locale(m, preferences=["C", "en_US.utf8"]) == 'C')
    except (AttributeError, RuntimeWarning):
        assert False

    # test get_best_parsable_locale when we expect to return en_US.utf8:

# Generated at 2022-06-11 01:10:05.569196
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # function requires a module instance
    module = AnsibleModule(argument_spec=dict())
    try:
        # Get best locale available
        locale = get_best_parsable_locale(module)
    except Exception:
        # No locale tool available
        assert False

    # The best (and most reliable) locale is C which is ascii only
    assert locale == 'C'

# Generated at 2022-06-11 01:10:16.653433
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test that get_best_parsable_locale is returning
        the right value based on the preferred locales list
    '''

    import ansible.module_utils.basic as basic_utils
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import PY2

    class TestModule(object):
        class AnsibleModule(object):
            def __init__(self):
                self.params = dict()
                self.run_command_environ_update = dict()

            def get_bin_path(self, tool, required=False, opt_dirs=[]):
                if tool == 'locale':
                    return '/usr/bin/locale'
                else:
                    return None


# Generated at 2022-06-11 01:10:25.758788
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

    assert get_best_parsable_locale(None, ['foo']) == 'C'

    assert get_best_parsable_locale(None, ['C.utf8', 'C', 'POSIX']) == 'C'

    assert get_best_parsable_locale(None, ['POSIX', 'C', 'C.utf8']) == 'C'

    assert get_best_parsable_locale(None, ['posix', 'C', 'C.utf8']) == 'C'

    assert get_best_parsable_locale(None, ['C']) == 'C'

    assert get_best_parsable_locale(None, ['C.utf8']) == 'C'


# Generated at 2022-06-11 01:10:37.428383
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class AnsibleModuleFake:
        def __init__(self, locale_bin_path, locale_info):
            self.locale_bin_path = locale_bin_path
            self.locale_info = locale_info

        def get_bin_path(self, bin_path):
            if bin_path == 'locale':
                return self.locale_bin_path
            else:
                return None

        def run_command(self, command):
            if command[0] == 'locale' and command[1] == '-a':
                return (0, self.locale_info, None)
            else:
                return (1, None, None)

    def run_test(locale_bin_path, locale_info, expected_locale, raise_on_locale=False):
        ansible_module

# Generated at 2022-06-11 01:10:45.551843
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = dict()
    module['get_bin_path'] = lambda x: True
    module['run_command'] = lambda x, y, z: (0, "C\nen_US.utf8\nen_US.utf8", "")
    result_locale = get_best_parsable_locale(module, preferences=None)
    assert result_locale == 'C.utf8'
    result_locale = get_best_parsable_locale(module, preferences=["en_US.utf8"])
    assert result_locale == 'en_US.utf8'

# Generated at 2022-06-11 01:10:48.324381
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule()

    assert get_best_parsable_locale(m) == 'C'

# Generated at 2022-06-11 01:10:51.159794
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:10:55.052313
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(m, preferences=['C']) == 'C'

# Generated at 2022-06-11 01:11:17.980024
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    if sys.version_info[0] == 2:
        class FakeModule:
            def __init__(self, locale='locale', locale_list=None):
                self._locale = locale
                self._locale_list = locale_list

            def get_bin_path(self, _):
                return self._locale

            def run_command(self, args):  # pylint: disable=unused-argument
                out = self._locale_list
                if out:
                    out = '\n'.join(out)
                elif out is None:
                    return 1, '', 'locale not found'

                return 0, out, ''

        module = FakeModule()


# Generated at 2022-06-11 01:11:25.320534
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test the get_best_parsable_locale() function, which returns the best parsable locale
    for parsing output in English.
    '''

    # Use a simple dictionary for the AnsibleModule fake
    class AnsibleModuleFake:
        def __init__(self, argument_spec):
            self.params = {}
        def get_bin_path(self, path):
            return path
        def run_command(self, cmd, check_rc=None):
            return (0, '', '')

    module = AnsibleModuleFake({})

    # Verify that we get a proper best parsable locale back
    assert get_best_parsable_locale(module, raise_on_locale=False) == 'C'

    # Use a simple dictionary for the AnsibleModule fake

# Generated at 2022-06-11 01:11:30.963272
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # This function has no way of knowing when it's being
    # run by unit tests and it will just complain about not
    # being able to find the 'locale' tool.
    locale, locale_error = get_best_parsable_locale(module, raise_on_locale=True), None
    assert locale == 'C'

# Generated at 2022-06-11 01:11:36.829292
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule, get_exception

    module = AnsibleModule(
        argument_spec=dict()
    )

    try:
        locale = get_best_parsable_locale(module)
    except Exception as e:
        module.fail_json(msg=get_exception())

    assert isinstance(locale, str)



# Generated at 2022-06-11 01:11:40.488426
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'

# Generated at 2022-06-11 01:11:48.560966
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    module = AnsibleModule()

    # Mocking run_command

# Generated at 2022-06-11 01:11:59.632579
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    # If no locale command exists, the 'C' locale is returned
    assert get_best_parsable_locale(module, ['C.UTF-8']) == 'C'

    # Test the C locale being returned when no preferred locales are provided
    assert get_best_parsable_locale(module, None) == 'C'

    # Test the C locale being returned when a preference list is provided
    # but none are found on the system
    assert get_best_parsable_locale(module, ['D.UTF-8']) == 'C'

    # Test the first preferred locale being returned when one is provided
    # and is found on the system

# Generated at 2022-06-11 01:12:05.148468
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['C', 'POSIX']) == 'C'
    assert get_best_parsable_locale(None, ['fr_FR.utf8', 'POSIX']) == 'fr_FR.utf8'

# Generated at 2022-06-11 01:12:13.401721
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_list = ['C.utf8', 'en_US.utf8', 'C', 'POSIX', 'en_US.utf8', 'foobar.UTF-8', 'POSIX']
    assert get_best_parsable_locale(locale_list) in ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    preferences = ['foobar.UTF-8', 'POSIX', 'C', 'C.utf8', 'en_US.utf8']
    assert get_best_parsable_locale(locale_list, preferences) == 'POSIX'

# Generated at 2022-06-11 01:12:24.548057
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    defaults = {
        'ANSIBLE_TEST': True,
    }

    # Fails on py2.6
    try:
        module = ansible.module_utils.basic.AnsibleModule(defaults=defaults)
    except:
        pass
    else:
        module.get_bin_path = lambda x: x
        module.run_command = lambda x: (0, x[1], None)

        locale = get_best_parsable_locale(module, ['en_US.utf8'], raise_on_locale=True)
        assert locale == 'en_US.utf8'

        module.run_command = lambda x: (0, x[1]+'\nC.utf8', None)
        locale = get_best_parsable

# Generated at 2022-06-11 01:12:59.765287
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    # create an empty module
    module = AnsibleModule(argument_spec={})

    # Test output to return en_US.utf8 if available
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.utf8'

    # Test output to return C.utf8 if available
    assert get_best_parsable_locale(module, preferences=['C.utf8']) == 'C.utf8'

    # Test output to return C if available
    assert get_best_parsable_locale(module, preferences=['C']) == 'C'

    # Test output to return POSIX if available

# Generated at 2022-06-11 01:13:11.269401
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        # Intentionally provoke an exception
        assert get_best_parsable_locale(None, raise_on_locale=True) == None
        raise ValueError("Should've raised exception")
    except RuntimeWarning:
        pass

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
    )
    assert get_best_parsable_locale(module,
                                    ['C.utf8', 'en_US.utf8', 'C', 'POSIX'],
                                    raise_on_locale=True) == 'C'

    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'


# Generated at 2022-06-11 01:13:21.843031
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class M:
        def __init__(self, out):
            self.out = out
        def get_bin_path(self, cmd):
            return cmd
        def run_command(self, cmd):
            return 0, self.out, ''
    m = M('''
C
C.UTF-8
en_US.utf8
POSIX
''')
    assert(get_best_parsable_locale(m) == 'C.UTF-8')
    assert(get_best_parsable_locale(m, preferences=['POSIX', 'en_US.utf8']) == 'POSIX')
    assert(get_best_parsable_locale(m, preferences=['no-such-locale']) == 'C')

# Generated at 2022-06-11 01:13:28.329523
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    fake_module = None
    locale = get_best_parsable_locale(fake_module, ['en_US.utf8', 'C.utf8', 'POSIX'])
    assert locale == 'C.utf8'
    # Unit test with custom locale list
    locale = get_best_parsable_locale(fake_module, ['en_ZA.utf8', 'en_GB.utf8'])
    assert locale == 'C'

# Generated at 2022-06-11 01:13:35.476429
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    if not module.get_bin_path("locale"):
        return

    assert get_best_parsable_locale(module) == "C"

    # if we use a locale with UTF8 character, the locale should be returned
    assert get_best_parsable_locale(module, preferences=['C.utf8', 'C']) == "C.utf8"

# Generated at 2022-06-11 01:13:45.949343
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import mock
    import os
    ansible_module = mock.Mock()
    ansible_module.get_bin_path.return_value = os.path.join(os.path.dirname(__file__), 'locale_test')

    # Test case when locale is present
    ansible_module.run_command.return_value = (0, 'en_US.utf8\nC\nPOSIX\nfr_FR.utf8', '')

    # Test case when locale is not present
    ansible_module.run_command.return_value = (0, '', 'locale: Command not found.')
    ansible_module.fail_json.side_effect = RuntimeWarning()

    # Test case when locale output is empty

# Generated at 2022-06-11 01:13:52.651368
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class TestModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err
        def get_bin_path(self, name, **kwargs):
            if name == 'locale':
                return 1
            else:
                raise RuntimeError('get_bin_path: Invalid')
        def run_command(self, cmd, **kwargs):
            if cmd[0] == 'locale' and cmd[1] == '-a':
                return self.rc, self.out, self.err
            else:
                raise RuntimeError('run_command: Invalid')

    # Successfully get locales
    module = TestModule(0, "C\nen_US.utf8\nC.utf8\n", '')
    assert get

# Generated at 2022-06-11 01:14:03.995262
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class Module(object):

        _global_args = {}

        def __init__(self, **kwargs):
            self.params = kwargs
            self.fail_json = kwargs.get('fail_json')
            self.run_command = kwargs.get('run_command')
            self.get_bin_path = kwargs.get('get_bin_path')

        def fail_json(self, **kwargs):
            self._global_args['_failed'] = True

    class TestException(Exception):
        pass

    def test_run_command(command):
        if command == ['/usr/bin/locale', '-a']:
            return (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')

# Generated at 2022-06-11 01:14:12.828029
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    # testing for en_US when it's not there
    fake_module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(fake_module, ['en_US'], raise_on_locale=False) == 'C'
    # testing that en_US when it's there
    fake_module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(fake_module, ['en_US.utf8'], raise_on_locale=False) == 'en_US.utf8'
    # testing default
    fake_module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(fake_module) == 'C'

# Generated at 2022-06-11 01:14:24.390366
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test with a set of "locale -a" output, and see if it return the right locale
    '''

    class TestResult:
        def __init__(self):
            self.results = {
                'C': 0,
                'POSIX': 0,
                'C.utf8': 0,
                'en_US.utf8': 0,
                'Unknown': 0
            }
        def busy(self):
            self.results['C'] += 1
        def POSIX(self):
            self.results['POSIX'] += 1
        def cutf8(self):
            self.results['C.utf8'] += 1
        def enutf8(self):
            self.results['en_US.utf8'] += 1
        def other(self):
            self.results['Unknown'] += 1

   

# Generated at 2022-06-11 01:15:01.433917
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test get_best_parsable_locale function using unittest.
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.utils.display import Display
    from ansible.utils.color import stringc

    display = Display()
    display.color = False

    # Setup the module
    module = AnsibleModule(
        argument_spec={
        },
    )
    try:
        locale = get_best_parsable_locale(module)
    except RuntimeWarning as e:
        module.fail_json(msg="Unable to get best locale: %s" % to_native(e),
                         exception=traceback.format_exc())
    else:
        module.exit_json(changed=False, locale=locale)

# Generated at 2022-06-11 01:15:11.869707
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path

    try:
        import ansible
        from ansible.modules.system import get_best_parsable_locale
    except ImportError:
        import sys
        import os

        ansible_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
        sys.path.append(ansible_path)

        from ansible.modules.system import get_best_parsable_locale

    class FakeModule(object):
        def __init__(self):
            self._fail = False

        def fail_json(self, **kwargs):
            self._fail = kwargs


# Generated at 2022-06-11 01:15:17.001267
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Unit test for function get_best_parsable_locale
    '''
    import sys
    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.common.locale
    from ansible.module_utils.common.locale import get_best_parsable_locale


# Generated at 2022-06-11 01:15:22.862924
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic

    module = ansible.module_utils.basic.AnsibleModule
    results = get_best_parsable_locale(module)
    # Check type is string
    assert isinstance(results, str)
    # Check string C is in the results string
    assert results == 'C'

# Generated at 2022-06-11 01:15:32.557618
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = type('module', (object,), dict())
    module.run_command = lambda x: (0, 'C\nen_US.utf8', '')
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    module.run_command = lambda x: (0, 'C\nen_US.utf8', '')
    assert get_best_parsable_locale(module, ['fr_FR.utf8', 'en_US.utf8']) == 'en_US.utf8'

    module.run_command = lambda x: (0, 'en_US.utf8\nC\nen_US.utf8', '')
    assert get_best_parsable_locale(module, ['fr_FR.utf8', 'en_US.utf8'])

# Generated at 2022-06-11 01:15:42.236821
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys, os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    best_parsable_locale = get_best_parsable_locale(module)
    if best_parsable_locale != 'C':
        module.fail_json(msg='get_best_parsable_locale returned unexpected value')

    best_parsable_locale = get_best_parsable_locale(module, preferences=['foo', 'bar'])

# Generated at 2022-06-11 01:15:52.490955
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Function to test get_best_parsable_locale
    """
    # for testing we create a fake module
    # the module is a dictionary with the required fields
    module = {}
    # the required fields are: 'run_command', 'get_bin_path' and 'fail_json'
    # we just create functions with the same name as the keys and are very simple
    # in this test they just return what we pass in as arguments
    module['get_bin_path'] = lambda a: a
    module['run_command'] = lambda a: (0, '', '')
    module['fail_json'] = lambda a: 'FAIL'

    # create a list of possible locales
    preferences = ['C', 'POSIX']

    # now test get_best_parsable_locale
    # first test with a

# Generated at 2022-06-11 01:16:02.360086
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Unit test for function get_best_parsable_locale
        the test verifies that the function returns the default locale if
        the locale command is missing and that the function returns the default
        locale if the locale command fails to execute.
    '''
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})

    locale = module.get_bin_path("locale")
    module.run_command = lambda args, check_rc=True: (1, '', 'could not find `locale`')
    assert module.get_bin_path("locale") is None
    assert get_best_parsable_locale(module) == 'C'

    module.run_command = lambda args, check_rc=True: (0, 'C.utf-8', '')
   

# Generated at 2022-06-11 01:16:05.433524
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=False)
    locale = get_best_parsable_locale(module, preferences=['C.utf8'])
    module.exit_json(changed=False, locale=locale)



# Generated at 2022-06-11 01:16:15.517586
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Only the 'C' locale is available in this output of `locale -a`
    #  C
    #  POSIX
    #  en_US.utf8
    #  nl_NL
    #  nl_NL.utf8
    #  nl_NL.utf-8@euro
    locale_list1 = ['C\n', 'POSIX\n', 'en_US.utf8\n', 'nl_NL\n', 'nl_NL.utf8\n', 'nl_NL.utf-8@euro\n']

    # Simple test
    assert(get_best_parsable_locale(locale_list1) == 'C')

    # Test with a preferred language list; this list should pick the
    # 'en_US.utf8' locale

# Generated at 2022-06-11 01:16:51.362941
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''Test that get_best_parsable_locale will return the default locale if locale are not available'''
    from ansible.module_utils.basic import AnsibleModule

    def _fake_run_command(args):
        return 0, ''.join(args), ''

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    module.run_command = _fake_run_command
    module.get_bin_path = lambda x: x
    assert get_best_parsable_locale(module) == 'C', "Default locale must be 'C'"

    def _fake_run_command_with_failing_path(args):
        return 0, None, ''


# Generated at 2022-06-11 01:17:00.594454
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    sys.path.insert(0, '../')
    import ansible.module_utils

    # Function test
    if not hasattr(ansible.module_utils, 'basic'):
        print("Could not find ansible.module_utils.basic")
    else:
        class MockModule(object):
            def __init__(self):
                self.fail_json = lambda **kwargs: sys.exit(1)

            def get_bin_path(self, tool):
                if tool == 'locale':
                    return '/usr/bin/locale'

            def run_command(self, command):
                if command == ['/usr/bin/locale', '-a']:
                    return 0, 'posix\nC\nC.UTF-8', ''

# Generated at 2022-06-11 01:17:04.096469
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    assert get_best_parsable_locale(AnsibleModule({})) == 'C'
    assert get_best_parsable_locale(AnsibleModule({}), ['C', 'POSIX']) == 'C'

# Generated at 2022-06-11 01:17:11.585824
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    test_module = AnsibleModule(argument_spec={})

    # If none of the preferred locales exist in the system, 'C' locale should be returned
    assert get_best_parsable_locale(test_module) == 'C'

    # 'POSIX' locale should be returned, even if it does not exist in the system
    assert get_best_parsable_locale(test_module, priorities = ['POSIX']) == 'POSIX'

    # Test for valid multibyte output
    assert get_best_parsable_locale(test_module, priorities = ['ru_RU.utf8']) == 'ru_RU.utf8'

# Generated at 2022-06-11 01:17:14.378352
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module)
    assert locale == 'C'

# Generated at 2022-06-11 01:17:25.089728
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test works like:
    1) Fake locale is installed.
    2) Get list of all available locales
    3) If specified locale present in output of locale -a, return found locale
    '''

    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    import mock
    import sys

    # Verify C locale returned as we expect when nothing else available
    with mock.patch.dict(sys.modules):
        sys.modules["ansible.module_utils.basic"] = mock.MagicMock()
        sys.modules.update({'ansible.module_utils.basic': mock.MagicMock(AnsibleModule=AnsibleModule)})
        from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 01:17:27.555810
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale({}, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'

# Generated at 2022-06-11 01:17:32.878222
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    # Test without preferences to make sure it defaults to C
    assert get_best_parsable_locale(module) == 'C'
    # Test with preferences and existing locale in preferences list
    assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'

# Generated at 2022-06-11 01:17:33.510936
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-11 01:17:35.888188
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale = get_best_parsable_locale(module, preferences=['en_US.utf8'])
    assert locale == 'en_US.utf8'

# Generated at 2022-06-11 01:18:14.437597
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import os
    import pytest
    m = basic.AnsibleModule(
        argument_spec=dict(),
    )

    # Create a temporary file that does not cause errors in get_bin_path()
    with m.tmpdir() as tmpdir:
        # Using a hardcoded python binary here, because that's what Ansible will find
        # if "python" is running on the system. If we change the path below, Ansible
        # will fail to find that path in get_bin_path().
        tmp_locale = os.path.join(tmpdir, 'locale')

# Generated at 2022-06-11 01:18:23.823536
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    def _test(preferences, err, out, ret, expected):
        ''' helper method to test get_best_parsable_locale '''
        raise_on_locale = True
        module = AnsibleModule({}, {})
        module.run_command = lambda command: (ret, out, err)
        assert get_best_parsable_locale(module, preferences, raise_on_locale) == expected

    _test(None, 'err', 'out', 0, 'C')
    _test(None, 'err', 'af_ZA.utf8', 0, 'C')

# Generated at 2022-06-11 01:18:29.880371
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys

    # Create a temporary module to test with
    tmp_module = AnsibleModule(argument_spec={})
    # Get the path of the current python executable
    python = sys.executable
    # Create an empty list to hold the command
    cmd = []
    # Create the list that will hold the arguments we want to pass to the module
    argv = []
    # This is the first argument and needs to be the path of the current python executable
    argv.append(python)
    # This is the second argument and needs to be the path of the module file to test
    argv.append(tmp_module.path)
    # This is the third and final argument that we will pass to the module and is defined by the user

# Generated at 2022-06-11 01:18:37.405693
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    assert get_best_parsable_locale(AnsibleModule({})) == 'C'
    assert get_best_parsable_locale(AnsibleModule({}), ['en_US.utf8']) == 'C'

    assert get_best_parsable_locale(AnsibleModule({}), raise_on_locale=True) == 'C'
    assert get_best_parsable_locale(AnsibleModule({}), ['en_US.utf8'], raise_on_locale=True) == 'C'

    assert get_best_parsable_locale(AnsibleModule({}), ['C.utf8']) == 'C.utf8'