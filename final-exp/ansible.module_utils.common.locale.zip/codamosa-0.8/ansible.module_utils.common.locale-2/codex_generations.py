

# Generated at 2022-06-11 01:08:49.847860
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text

    module = AnsibleModule(
        argument_spec=dict(),
    )

    # get_best_parsable_locale
    # ========================
    # trivial case
    result = get_best_parsable_locale(module)
    assert result == 'C', "Should have returned C"

    # make sure it works with a list
    result = get_best_parsable_locale(module, ["C", "POSIX"])
    assert result == 'C', "Should have returned C"

    # make sure it does not break on an empty list
    result = get_best_parsable_locale(module, [])
    assert result == 'C', "Should have returned C"



# Generated at 2022-06-11 01:09:00.061309
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import textwrap
    from ansible.module_utils.basic import AnsibleModule

    def test_bin_path(path):
        if path == 'locale':
            return 'locale'

    dummy_module = AnsibleModule(
        argument_spec={'locale': {'type': 'dict'}},
        supports_check_mode=True,
    )

    dummy_module.get_bin_path = test_bin_path

    # test when locales are not available
    dummy_module.run_command = lambda command, check_rc=False, environ_update=None, data=None: (1, "", "")
    assert dummy_module.get_best_parsable_locale() == 'C'

    # test when we can't find the locale command
    dummy_module.run_command = None
   

# Generated at 2022-06-11 01:09:06.362602
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    # When there is no locale bin path, we should get a warning back as we cannot
    # determine what to use.
    assert get_best_parsable_locale(module) == 'C'

    # If there is a locale bin path, but it doesn't return anything or the locale
    # -a command doesn't return anything, we should still get the default.
    module.run_command = lambda a, b: (0, None, None)
    assert get_best_parsable_locale(module) == 'C'

    # If the locale command fails, we should get the default.
    module.run_command = lambda a, b: (1, None, None)
    assert get_best_parsable

# Generated at 2022-06-11 01:09:12.291240
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    # Mock an AnsibleModule without it actually running
    module = AnsibleModule(argument_spec={})
    # Mock the underlying system

    # Mock the RC and output of locale -a
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', '')

    # First check we get the best locale
    locale = get_best_parsable_locale(module)
    assert locale == 'C.utf8'

    # Now set the preferences to ensure we get the second preference
    locale = get_best_parsable_locale(module, ['en_US.utf8', 'POSIX'])
    assert locale == 'en_US.utf8'

    # Now set an empty preferences

# Generated at 2022-06-11 01:09:22.040202
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # simulate locale can be found
    def ansible_get_bin_path_locale(self, arg1):
        return True

    # simulate locale is not available when called
    def ansible_run_command_no_locale(self, arg1):
        return 1, '', 'Can not find locale'

    # simulate locale is available when called
    def ansible_run_command_good_locale(self, arg1):
        return 0, '', ''

    # simulate locale is available when called
    def ansible_run_command_empty_locale(self, arg1):
        return 0, '', ''

    # simulate locale is with multiple choices when called
    def ansible_run_command_multiple_locale(self, arg1):
        return 0,

# Generated at 2022-06-11 01:09:26.997145
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(argument_spec={}, skip_conditions=True)

    assert get_best_parsable_locale(module, ['bogus']) == 'C'

    assert get_best_parsable_locale(module, ['POSIX']) == 'POSIX'

# Generated at 2022-06-11 01:09:37.260437
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """Test get_best_parsable_locale functionality with different input. """
    from ansible.module_utils.common.collections import ImmutableDict

    language_locale = 'C'
    # Test for valid input
    results = get_best_parsable_locale(ImmutableDict({
        'get_bin_path': lambda x: x,
        'run_command': lambda x: (0, '\n'.join(['C', 'C.utf8', 'POSIX']), None),
    }), preferences=['POSIX', 'C.utf8', 'C'], raise_on_locale=False)
    assert results == 'POSIX'

    # Test for invalid input(locale command fails)

# Generated at 2022-06-11 01:09:44.264361
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # mock up module and command output
    from ansible.module_utils.basic import AnsibleModule
    import os

    class MockModule(AnsibleModule):
        def run_command(self, cmd):
            if len(cmd) == 1:
                cmd1 = ['csh', '-c', 'locale -a']
            else:
                cmd1 = cmd

            return os.system(str(cmd1))

        def get_bin_path(self, file):
            return 1

    module = MockModule(argument_spec={})

    ret = get_best_parsable_locale(module)
    assert ret

# Generated at 2022-06-11 01:09:47.420823
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.modules.system.locale
    m = ansible.modules.system.locale.AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(m) == 'C'

# Generated at 2022-06-11 01:09:57.891753
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # This is the least expensive approach to creating an empty module instance
    module = AnsibleModule(argument_spec=dict())

    # Expected behavior for different cases
    no_locale = None
    no_locale_expected = 'C'
    locale_en = ['en_US.utf8', 'C', 'POSIX']
    locale_en_expected = 'en_US.utf8'
    locale_tr = ['tr_TR.utf8', 'C', 'POSIX']
    locale_tr_expected = 'C'

    assert get_best_parsable_locale(module) == no_locale_expected
    assert get_best_parsable_locale(module, no_locale) == no_locale_expected
    assert get_best_

# Generated at 2022-06-11 01:10:08.701077
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = {},
        supports_check_mode = True
    )

    local_pref = ['en_US.utf8', 'C.utf8', 'POSIX', 'C']
    assert get_best_parsable_locale(module) in local_pref

# Generated at 2022-06-11 01:10:20.119607
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    mod_path = 'ansible/module_utils/urls.py'
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        bypass_checks=False
    )

    def mock_get_bin_path():
        return 'locale'

    module.get_bin_path = mock_get_bin_path

    # Scenario 1: locale -a has 'C' or positive exit code but no error message
    # locale -a should return 'C'
    def scenario_one():
        out = 'C'
        err = ''
        module.run_command = lambda x: (0, out, err)
        return module

    # Scenario 2: locale -a has 'C.utf8' or 'POSIX

# Generated at 2022-06-11 01:10:27.639931
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    fake_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # The best supported locale will always be one of the first ones, if not the first one.
    # Assumed settings for tests:
    # - C is always supported
    # - POSIX is supported on some systems
    assert get_best_parsable_locale(fake_module, ['badlocale', 'C']) == 'C'
    assert get_best_parsable_locale(fake_module, ['C', 'badlocale']) == 'C'
    assert get_best_parsable_locale(fake_module, ['C']) == 'C'

    # Should get POSIX if it is available and C if it is not

# Generated at 2022-06-11 01:10:38.715339
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_available = "C\nC.UTF-8\nC.utf8\nen_US.UTF-8\nen_US.utf8\nen_US\nen_US.ISO8859-1\nen_US.ISO8859-15\nen_US.ISO8859-1@euro\nen_US.us-ascii"
    locale_not_available = ""
    locale_not_installed = None
    locale_bin_fail = "locale: command not found"

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    def run_command_mock(args, check_rc=True):
        if 'locale' not in args:
            raise AssertionError("Unexpected args passed to run_command: %s" % args)


# Generated at 2022-06-11 01:10:44.496934
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    am = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(am) == 'C'  # default
    assert get_best_parsable_locale(am, preferences=['abc']) == 'C'
    assert get_best_parsable_locale(am, preferences=['C', 'POSIX']) == 'C'

# Generated at 2022-06-11 01:10:53.193440
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os.path

    module_args = dict()
    module = AnsibleModule(
        argument_spec=module_args,
        check_invalid_arguments=False,
        supports_check_mode=True,
        bypass_checks=True
    )
    assert module.get_bin_path("locale")
    locale_found = module.get_bin_path("locale")
    assert locale_found
    assert os.path.exists(locale_found)

    assert get_best_parsable_locale(module) not in ['', None]

# Generated at 2022-06-11 01:11:04.481509
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # create a fake module class to use
    class MyModule:
        def __init__(self):
            self.bin_path = None

        def get_bin_path(self, app):
            return self.bin_path

        def run_command(self, args):
            return (1, None, None)

    # when no locales are present, we prefer C
    my_module = MyModule()
    my_module.bin_path = '/usr/bin/locale'

    assert get_best_parsable_locale(my_module) == 'C'

    # setup a default locales to test
    my_module = MyModule()
    my_module.bin_path = '/usr/bin/locale'


# Generated at 2022-06-11 01:11:13.248039
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import get_exception
    import ansible.module_utils.basic as basic_module_utils

    def test_bin_path(name):
        return name

    class MockAnsibleModule(object):

        def __init__(self):
            self._from_error = None
            self._from_fail_json = None

        def run_command(self, cmd):
            if cmd == [u"locale", u"-a"]:
                return (0, u"C\nen_US.utf8", b'')
            raise Exception("Bad call to run_command")

        def get_bin_path(self, name):
            return test_bin_path(name)

        def fail_json(self, **kwargs):
            self._from_fail_json = dict(**kwargs)

# Generated at 2022-06-11 01:11:22.673582
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    # get_best_parsable_locale should return the default value 'C'
    # when no `locale` is provided
    assert(get_best_parsable_locale(module) == 'C')

    # get_best_parsable_locale should return the default value 'C'
    # when `locale` provides no output
    module = AnsibleModule(
        argument_spec=dict(),
        binary_module_interpreter='no_output'
    )
    assert(get_best_parsable_locale(module) == 'C')

    # get_best_parsable_locale should return the default value 'C'
    # when `loc

# Generated at 2022-06-11 01:11:32.360565
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = MockModule()

    # Case 1: "Commands succeeded"
    # Case 1.1: "C" Locale available
    module.run_command = Mock(return_value=(0, "C.utf8 C C.utf8 C.UTF-8 en_US.utf8 POSIX", ""))
    assert "C" == get_best_parsable_locale(module, ['C', 'C.utf8', 'en_US.utf8', 'POSIX'])
    # Case 1.2: "en_US.utf8" Locale available
    module.run_command = Mock(return_value=(0, "C.utf8 C C.utf8 C.UTF-8 en_US.utf8 POSIX", ""))

# Generated at 2022-06-11 01:11:47.651496
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self):
            self.params = {}
            self._result = {}
            self._debug = {}

        def fail_json(self, **kwargs):
            exit_code = kwargs.pop('rc', None)
            exit_msg = kwargs.pop('msg', None)
            fail_reason = kwargs.pop('failed', None)
            self._result.update(kwargs)
            self._result['failed'] = True
            self._result['rc'] = exit_code
            self._result['msg'] = exit_msg

# Generated at 2022-06-11 01:11:53.229002
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    assert get_best_parsable_locale(AnsibleModule(argument_spec={}), ['abcd', 'C']) == 'C'
    assert get_best_parsable_locale(AnsibleModule(argument_spec={}), ['abcd', 'C', 'utf8']) == 'C'

# Generated at 2022-06-11 01:12:02.240641
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(type='list', default=None),
            raise_on_locale=dict(type='bool', default=False),
        ),
    )
    # Test without any preferences
    assert get_best_parsable_locale(module) == 'C'

    # Test with 'POSIX' as a preference
    preferences = ['POSIX']
    assert get_best_parsable_locale(module, preferences=preferences) == 'C'
    # Test with a preference of 'POSIX' and setting to raise an exception
    assert get_best_parsable_locale(module, preferences=preferences, raise_on_locale=True) == 'C'

    # Test

# Generated at 2022-06-11 01:12:06.544009
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(mod) == 'C'

# Generated at 2022-06-11 01:12:16.910622
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test setting preferences
    preferences = ['C.utf8']
    assert get_best_parsable_locale(None, preferences=preferences) == "C.utf8"
    preferences = ['fr_FR.utf8']
    assert get_best_parsable_locale(None, preferences=preferences) == "fr_FR.utf8"
    preferences = ['not_existing_locale']
    assert get_best_parsable_locale(None, preferences=preferences) == "C"

    # Test default preferences
    preferences = None
    assert get_best_parsable_locale(None, preferences=preferences) == "C"
    assert get_best_parsable_locale(None, preferences=preferences) == "C"

# Generated at 2022-06-11 01:12:26.400439
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule(argument_spec={})

    # Test for error return
    am.get_bin_path = lambda x: None
    assert get_best_parsable_locale(am) == 'C'

    # Test for good return
    am.get_bin_path = lambda x: '/usr/bin/locale'
    am.run_command = lambda x: [0, 'C.utf8\nen_US.utf8\nC\nPOSIX\nxx', '']
    assert get_best_parsable_locale(am) == 'C.utf8'

    # Test for good return when C locale not found

# Generated at 2022-06-11 01:12:38.277617
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import types

    # Setup the fake module and preferences
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def get_bin_path(self, arg, *args, **kwargs):
            return 'locale'

        def run_command(self, args, *args, **kwargs):
            self.run_command_calls.append(args)
            # Return a fake result
            return self.run_command_results.pop(0)

    fake_module = FakeModule()

    # Assuming the locale tool is present
    assert fake_module.get_bin_path('locale')
    assert isinstance(fake_module.get_bin_path('locale'), types.StringType)

    # Return a fake result

# Generated at 2022-06-11 01:12:49.110329
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = None
    preferences = ['C.utf8']
    assert 'C' == get_best_parsable_locale(module, preferences)

    preferences = ['C']
    assert 'C' == get_best_parsable_locale(module, preferences)

    preferences = ['en_US.utf8']
    assert 'C' == get_best_parsable_locale(module, preferences)

    preferences = ['C.utf8', 'en_US.utf8']
    assert 'C' == get_best_parsable_locale(module, preferences)

    preferences = ['en_US.utf8', 'C.utf8']
    assert 'C' == get_best_parsable_locale(module, preferences)

# Generated at 2022-06-11 01:12:58.600084
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from shutil import which
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import PY3

    # base parameters for the AnsibleModule
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    module.params = dict()

    # force locale to a temp dir
    module.run_command_environ_update = ImmutableDict({'PATH': module.run_command_environ_update['PATH'], 'LC_ALL': '/tmp'})

    # ensure command exists on path
    assert which('locale') is not None

    # ensure we set LC_ALL
    assert module.run_command_environ_update['LC_ALL'] == '/tmp'



# Generated at 2022-06-11 01:13:09.779402
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Test success
    # 1. Test when the preferred list is empty
    assert get_best_parsable_locale(None, []) == 'C'

    # 2. Test when the preferred list is not empty but not available
    assert get_best_parsable_locale(None, ['zh_CN.utf8', 'zh_CN.utf8']) == 'C'

    # 3. Test when 'locale' is not in PATH
    pytest_twisted.inlineCallbacks(None, get_best_parsable_locale, None, None, True)

    # 4. Test when 'locale' is in PATH
    pytest_twisted.inlineCallbacks(None, get_best_parsable_locale, None, ['zh_CN.utf8'], True)

    # Test failure
    # 1.

# Generated at 2022-06-11 01:13:34.637609
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Function to test get_best_parsable_locale() returns the expected output
    """

    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    cmd = """#!/bin/bash
echo "POSIX
en_US.utf8
C.utf8
C
en_US
"
exit 0
"""
    fh, tmp_path = tempfile.mkstemp()
    with open(tmp_path, 'w') as f:
        f.write(cmd)

    a_module = AnsibleModule(argument_spec=dict())
    a_module.get_bin_path = lambda x: tmp_path
    a_module.run_command = lambda x: (0, cmd, '')

# Generated at 2022-06-11 01:13:45.311813
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    import ansible.module_utils.common.process
    import ansible.module_utils.six
    import mock

    module = mock.Mock()
    module.get_bin_path.return_value = None
    module.run_command.return_value = (1, None, None)

    with pytest.raises(RuntimeWarning):
        get_best_parsable_locale(module, raise_on_locale=True)

    module.get_bin_path.assert_called_with("locale")
    module.run_command.assert_not_called()

    module.get_bin_path.reset_mock()
    module.run_command.reset_mock()
    module.get_bin_path.return_value = "locale"
    module

# Generated at 2022-06-11 01:13:51.923976
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    # should return C if preferences are passed in
    assert get_best_parsable_locale(module) == 'C'
    # should return C if preferences are passed in
    assert get_best_parsable_locale(module, preferences=['de_DE.utf8', 'en_US.utf8']) == 'C'
    # should return en_US.utf8 if preferences are passed in
    assert get_best_parsable_locale(module, preferences=['en_US.utf8']) == 'en_US.utf8'

# Generated at 2022-06-11 01:14:00.564288
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    ansible_module = AnsibleModule()
    ansible_module.get_bin_path = lambda x: True  # dummy function
    ansible_module.run_command = lambda x: (0, '', '')  # dummy function
    assert get_best_parsable_locale(ansible_module) == 'C.utf8'
    ansible_module.run_command = lambda x: (1, '', '')  # dummy function
    assert get_best_parsable_locale(ansible_module) == 'C'

# Generated at 2022-06-11 01:14:10.490737
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # At this time, we cannot figure out how to test the case when locale
    # command fails. We would need to patch it, but it is written in C, so
    # that is difficult.

    # The rest of the cases are tested by reading real data and generating
    # a fake module

    # Grab real data
    with open('/usr/bin/locale', 'r') as f:
        dummy_locale_binary = f.read()
    with open('/usr/share/i18n/locales/C', 'r') as f:
        dummy_locale_c = f.read()

# Generated at 2022-06-11 01:14:21.832494
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # This class is used to mock an AnsibleModule

    class FakeModule():
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            if name == "locale":
                return "/usr/bin/locale"
            return None

        def run_command(self, cmd):
            if cmd[1] != "-a":
                return (1, "", "")
            if cmd[0] == "/usr/bin/locale":
                return (0, "C\nen_US.utf8\n", "")
            return (0, "C.utf8\nen_US.utf8\n", "")

    # With no preferences, we should get C
    mymod = FakeModule()

# Generated at 2022-06-11 01:14:31.858540
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible import constants as C
    from ansible.module_utils.basic import AnsibleModule
    # We will just do a mock here, it is tested by integration tests.
    def run_command(cmd):
        if cmd == ['locale', '-a']:
            if C.DEFAULT_MODULE_LANG in ['C', 'POSIX'] or 'en_US.utf8' in C.DEFAULT_MODULE_LANG:
                return 0, C.DEFAULT_MODULE_LANG, ''
            else:
                return 0, '\n'.join(['C', 'POSIX', 'en_US.utf8', 'en_US.utf8', C.DEFAULT_MODULE_LANG]), ''
        else:
            raise AssertionError("Unexpected command: %s" % cmd)

    # For

# Generated at 2022-06-11 01:14:41.276835
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from distutils.version import LooseVersion

    test_spec = dict(
        ansible_python_interpreter='/usr/bin/python',
        ansible_version='2.3.0',
        platform='Linux',
        distribution='CentOS',
        distribution_version='7',
        distribution_release='Core',
        distributioin_major_version='7',
        locale='en_US.utf8',
        lang='en_US.utf8',
        lsb=dict(
            codename='Core',
            description='CentOS Linux 7 (Core)',
            distributor_id='CentOS',
            release='7.2.1511',
            major_release='7',
        ),
    )


# Generated at 2022-06-11 01:14:42.675686
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'



# Generated at 2022-06-11 01:14:48.941150
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={
            'preferences': {'type': 'list', 'default': ['C.utf8', 'en_US.utf8', 'C', 'POSIX']},
            'raise_on_locale': {'type': 'bool', 'default': False},
        }
    )
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:15:06.530251
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic as module_utils_basic
    module = module_utils_basic.AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:15:17.340662
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile
    from ansible.module_utils.six import PY3
    from ansible.module_utils import basic
    import os

    # add some locale to temporary directory
    fd = tempfile.NamedTemporaryFile(delete=False)
    if PY3:
        locale_path = fd.name
    else:
        locale_path = fd.name.decode(basic._ANSIBLE_ENCODING)

    with os.fdopen(fd.fileno(), 'w') as handle:
        handle.write('test_test.utf8')

    m = basic.AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', default=locale_path),
        ),
    )


# Generated at 2022-06-11 01:15:28.685020
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        """
        Just a mock class for test_get_best_parsable_locale
        """
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            self.params = {}
            self.params['name'] = name
            return '/usr/bin/locale'

        def run_command(self, args):
            self.params = {}
            self.params['args'] = args
            if args[1] == '-a':
                return (0, 'en_US.utf8\nC.utf8\nC', '')
            else:
                return (0, '', '')

    # Test input with preferences

# Generated at 2022-06-11 01:15:32.964465
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    # check if the default is a valid locale
    assert module.run_command(['locale', '-a'])[1].strip().splitlines().count(get_best_parsable_locale(module)) == 1

# Generated at 2022-06-11 01:15:42.593976
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile
    import os
    import shutil
    import sys

    class MyModule:
        @staticmethod
        def get_bin_path(name):
            return name

        @staticmethod
        def run_command(cmd):
            try:
                fd, tmpfile = tempfile.mkstemp()
                fh = os.fdopen(fd, 'w')
                for line in cmd[1:]:
                    fh.write('%s\n' % line)
                fh.close()
                return (0, None, None)
            finally:
                os.unlink(tmpfile)

    with tempfile.TemporaryDirectory() as tmpdir:
        # Setup locale files
        os.mkdir(os.path.join(tmpdir, 'en_US.utf8'))

# Generated at 2022-06-11 01:15:49.867232
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'en_US.UTF8']) == 'en_US.utf8'
    assert get_best_parsable_locale(module, preferences=['en_US.utf8', 'en_US.UTF8'], raise_on_locale=True) == 'en_US.utf8'

# Generated at 2022-06-11 01:16:00.072725
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import unittest
    import tempfile
    from ansible.module_utils.six import PY3
    try:
        from ansible.module_utils.common._collections_compat import MutableMapping
    except ImportError:
        from collections import MutableMapping

    class ExecuteResult:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.stdout = out
            self.stderr = err

    class FakeModule:
        def __init__(self, params, ansible_version):
            self.params = params
            self.ansible_version = ansible_version

        def get_bin_path(self, cmd):
            return self.params[cmd]


# Generated at 2022-06-11 01:16:05.312976
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
  import ansible.module_utils.basic
  module = ansible.module_utils.basic.AnsibleModule(
    argument_spec={
      'raise_on_locale': dict(type='bool'),
      'preferences': dict(type='list'),
    },
    supports_check_mode=False,
  )
  module.run_command = lambda cmd, check_rc=True: (0, '', '')
  result = get_best_parsable_locale(module)
  assert result == 'C'

# Generated at 2022-06-11 01:16:05.831776
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    pass

# Generated at 2022-06-11 01:16:16.103455
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    mock_module = {
        'run_command': lambda x, check_rc=True, environ_update=None: (0, "C.UTF-8\nen\nen_US.UTF-8\nen_US", None),
        'get_bin_path': lambda x, opt_dirs=None: True,
    }

    assert get_best_parsable_locale(mock_module) == "C.UTF-8"

    mock_module['run_command'] = lambda x, check_rc=True, environ_update=None: (0, "C.UTF-8\nen\nen_US.UTF-8\nen_US", None)

    preferences = ['foo', 'bar', 'baz']

# Generated at 2022-06-11 01:16:51.454270
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    mock_module = MockModule()
    
    # When all available locales are in preferences list
    mock_module.run_command = Mock(return_value=(0, "C\nen_US_UTF-8", ""))
    assert get_best_parsable_locale(mock_module) == "C"
    assert get_best_parsable_locale(mock_module, preferences=['en_US.UTF-8', 'C']) == "en_US.UTF-8"
    assert get_best_parsable_locale(mock_module, preferences=['C.UTF-8', 'fr_FR.UTF-8']) == "C"

# Generated at 2022-06-11 01:16:58.702710
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeMod:
        def __init__(self):
            self.call_results = {
                'get_bin_path': '/usr/bin/locale'
            }
            self.call_count = 0

        def get_bin_path(self, name):
            return self.call_results[name]

        def run_command(self, cmd):
            self.call_count += 1
            return (0, 'en_US.utf8\nen_US\nC\nC.utf8', '')
    module = FakeMod()

# Generated at 2022-06-11 01:17:06.856925
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Function performing a unit test of the function get_best_parsable_locale.

        :return: True if test succeeded, False if not.
    '''
    from ansible.module_utils.basic import AnsibleModule

    mock_module = AnsibleModule({})
    found = get_best_parsable_locale(mock_module, preferences=['fr_FR.utf8'], raise_on_locale=False)
    assert found == 'C'

    found = get_best_parsable_locale(mock_module, preferences=['fr_FR.utf8'], raise_on_locale=True)
    assert found == 'C'

# Generated at 2022-06-11 01:17:13.104019
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import sys
    import unittest
    from ansible.module_utils.basic import AnsibleModule

    class MockOS(object):
        '''Fake OS'''
        @staticmethod
        def environ():
            '''Fake environment'''
            return {}

        @staticmethod
        def getenv(name, default=None):
            '''Fake getenv()'''
            return {}.get(name, default)

    class MockAnsibleModule(object):
        '''Fake AnsibleModule'''
        def __init__(self):
            self.params = {}
            self.check_mode = False

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            '''Fake get_bin_path()'''

# Generated at 2022-06-11 01:17:14.378335
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-11 01:17:23.188663
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # This is a test module
    module = AnsibleModule(argument_spec={'called_from_test': {'type': 'bool', 'required': False}}, supports_check_mode=False)

    # test if calling the module method raise_on_locale=True
    try:
        module.get_locale()
    except Exception as e:
        module.fail_json(msg='Exception raised: %s' % to_native(e))

    # test if English locale is returned
    module.get_locale(preferences=['en_US.utf8'])

# Generated at 2022-06-11 01:17:32.094724
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=False, add_file_common_args=False)

    # Test system with locale -a = [u'C', u'C.utf8', u'en_US.utf8']
    # we should return u'en_US.utf8'
    prefs = [u'en_US.utf8']
    assert get_best_parsable_locale(module, prefs) == u'en_US.utf8'

    # Test system with locale -a = [u'C', u'C.utf8', u'en_US.utf8']
    # we should return u'C.utf8'
    prefs = [u'C.utf8']
    prefs.extend

# Generated at 2022-06-11 01:17:42.252438
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(
        argument_spec={'locale': {'default': 'C.utf8', 'type': 'str', 'choices': ['C.utf8', 'en_US.utf8', 'C', 'POSIX']},
                      'raise_on_locale': {'default': False, 'type': 'bool'}}
    )

    if PY3:
        locale_out = b'C\nC.UTF-8\nen_US.utf8\nPOSIX\n'
    else:
        locale_out = 'C\nC.UTF-8\nen_US.utf8\nPOSIX\n'


# Generated at 2022-06-11 01:17:50.249653
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class FakeModule(object):
        @staticmethod
        def get_bin_path(cmd):
            return cmd

        @staticmethod
        def run_command(cmd):
            return (0, '', '')

    locale = FakeModule()
    assert get_best_parsable_locale(locale) == 'C'
    assert get_best_parsable_locale(locale, ['non_existent']) == 'C'
    assert get_best_parsable_locale(locale, ['non_existent1', 'non_existent2']) == 'C'

# Generated at 2022-06-11 01:17:55.474834
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-11 01:18:31.139536
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import BytesIO

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    base_locale = b'''
C.
C.UTF-8
C.UTF8
en_US.iso88591
en_US.iso885915@euro
en_US.utf8
'''

    module.run_command = lambda args, check_rc=None: (0, BytesIO(base_locale.strip()), '')

    # first case is using default preferences
    assert get_best_parsable_locale(module) == 'C.utf8'

    # second case is using custom preferences

# Generated at 2022-06-11 01:18:34.369976
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    mock_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    locale = get_best_parsable_locale(module=mock_module)
    assert locale in ['C', 'POSIX', 'en_US.utf8', 'C.utf8']

    locale = get_best_parsable_locale(module=mock_module, preferences=['C'])
    assert locale == 'C'

    locale = get_best_parsable_locale(module=mock_module, preferences=['en_US.utf8'])
    assert locale == 'en_US.utf8'