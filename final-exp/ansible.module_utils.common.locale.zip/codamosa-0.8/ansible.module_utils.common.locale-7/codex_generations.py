

# Generated at 2022-06-11 01:08:51.179884
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule({}, {}, {})

    rc, out, err = am.run_command(["locale", "-a"])
    available = out.strip().splitlines()

    # If we have available locales, check that we get one of them back
    if available:
        result = get_best_parsable_locale(am, preferences=available)
        assert result in available, "result should be in available locales"

    # if no locale is available, we should get 'C' back
    else:
        result = get_best_parsable_locale(am, preferences=available)
        assert result == 'C', "result should be 'C' when no locale is available"

    # if locales are available and none of our preferences are available, we

# Generated at 2022-06-11 01:09:01.306865
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    import errno
    import shutil
    import tempfile
    import os

    module = AnsibleModule(argument_spec={})

    # Mock out the parts we need
    old_get_bin_path = module.get_bin_path
    old_run_command = module.run_command
    old_open = open

    t = tempfile.mkdtemp()

# Generated at 2022-06-11 01:09:09.160162
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' get_best_parsable_locale: functional tests '''
    from ansible.module_utils.basic import AnsibleModule

    # Basic test with no additional preferences
    m = AnsibleModule(argument_spec={})

    found_locale = get_best_parsable_locale(m)
    assert found_locale == 'C'

    # Test the raise on error path
    m = AnsibleModule(argument_spec={})

    try:
        get_best_parsable_locale(m, preferences=['C.utf8', 'en_US.utf8', 'POSIX'], raise_on_locale=True)
    except RuntimeWarning:
        # Expected, don't fail test
        pass
    else:
        assert False, "Expected RuntimeWarning exception on missing locale"

    # Test

# Generated at 2022-06-11 01:09:19.767061
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest.mock as mock
    from ansible.module_utils.basic import AnsibleModule

    mocked_run_command = lambda x, y: (0, "C.utf8\nen_US.utf8\nen_US.UTF-8\n", '')
    with mock.patch('ansible.module_utils.basic.AnsibleModule.run_command', side_effect=mocked_run_command):
        mocked_get_bin_path = lambda x: '/bin/locale'
        with mock.patch('ansible.module_utils.basic.AnsibleModule.get_bin_path', side_effect=mocked_get_bin_path):
            module = AnsibleModule(
                argument_spec=dict(),
            )
            # Test preferences with the first preference not existing

# Generated at 2022-06-11 01:09:29.906728
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' Unit tests for get_best_parsable_locale '''
    from ansible.module_utils.basic import AnsibleModule

    # No locale tool, we should get a warning and the default "C" locale
    module = AnsibleModule(argument_spec=dict())
    module.get_bin_path = lambda path: None
    assert get_best_parsable_locale(module) == 'C'

    # No locale entries, we should get a warning and the default "C" locale
    module = AnsibleModule(argument_spec=dict())
    module.get_bin_path = lambda path: 'locale'
    module.run_command = lambda command: (0, '', '')
    assert get_best_parsable_locale(module) == 'C'

    # No locale entries, we should get a

# Generated at 2022-06-11 01:09:34.974582
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    assert AnsibleModule(argument_spec={}).get_bin_path("locale")
    assert get_best_parsable_locale(AnsibleModule(argument_spec={}), raise_on_locale=True) == 'C'


# Generated at 2022-06-11 01:09:37.823787
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:09:42.840108
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic as basic

    test_module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)

    assert get_best_parsable_locale(test_module) == 'C'

    assert get_best_parsable_locale(test_module, preferences=['en_US.utf8', 'C']) == 'C'

# Generated at 2022-06-11 01:09:53.014772
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class TestModule(object):
        def get_bin_path(self, tool):
            if tool != 'locale':
                return None

            return tool

        def run_command(self, command):
            returncode = 0
            out = ""
            err = ""

            if command[-1] == '-a':
                out = "C\nen_US.utf8\nC.UTF-8\nC.utf8\nPOSIX\n"
            elif command[-1] == '-k':
                err = "Unsupported option: -k\n"
                returncode = 1

            return (returncode, out, err)

    module = TestModule()

    # case I: output from locale has 4 possible parsable locales, but only first one is matched
    #         (and 3rd and 4th are the same

# Generated at 2022-06-11 01:10:01.891526
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # If a preference is not in the list of locales, return "C"
    assert get_best_parsable_locale(None, ["en_US.utf8"]) == "C"
    # If the preference is in the list of locales, return that preference
    # This example was found on Debian, which has it's locale data inside
    # /usr/share/i18n/locales
    assert get_best_parsable_locale(None, ["en_US.utf8"], ["en_US.utf8"]) == "en_US.utf8"
    # This example was found on SLES, which has it's locale data inside
    # /usr/lib64/locale

# Generated at 2022-06-11 01:10:16.653996
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Unit test for get_best_parsable_locale
    """
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['C']) == 'C'
    assert get_best_parsable_locale(None, ['C.utf8']) == 'C'
    assert get_best_parsable_locale(None, ['en_US.utf8']) == 'C'
    assert get_best_parsable_locale(None, ['C', 'C.utf8']) == 'C'
    assert get_best_parsable_locale(None, ['POSIX', 'en_US.utf8']) == 'C'

# Generated at 2022-06-11 01:10:25.757891
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    module = AnsibleModule(argument_spec=dict(type='str'))
    std_err = StringIO()
    std_out = StringIO()
    std_err.write('''The program 'locale' is currently not installed. To run 'locale' please ask your administrator to install the package 'locales'
''')
    std_out.write('''C
C.UTF-8
en_US.utf8
POSIX
''')
    module.run_command_environ_update = {}
    module.no_log_values.update(dict(stdout=True, stderr=True, changed=False))
    module.run_command_encoding = None
    module.run_command

# Generated at 2022-06-11 01:10:37.428011
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    # test when locale is working as expected
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nen_US.UTF-8\nPOSIX', '')
    assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

    # test when locale is not installed
    module.get_bin_path = lambda x: ''
    module.run_command = lambda x: (1, '', '')
    path = None
    try:
        path = module.get_bin_path("locale")
    except RuntimeError:
        pass
    assert path is None

    # test when locale is installed but unable to get availabled locales

# Generated at 2022-06-11 01:10:48.142739
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    if sys.version_info[0] == 2:
        import __builtin__ as builtins
    else:
        import builtins

    import unittest

    class FindLocaleMock(object):
        def __init__(self, every_nth_command_fails=None):
            self.failed_commands = []
            self.every_nth_command_fails = every_nth_command_fails
            self.commands = 0

        def run_command(self, args):
            self.commands += 1
            if self.every_nth_command_fails is not None and \
               self.commands % self.every_nth_command_fails == 0:
                return -1, "", ""
            elif "locale -a" in args:
                return

# Generated at 2022-06-11 01:10:59.272015
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import ansible.module_utils.basic
    import os
    # Setup mock module object
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict()
    )

    def mock_get_bin_path(arg1, arg2=None):
        return arg2

    def mock_run_command(arg1, arg2=None, arg3=None):
        return (0, 'C\nPOSIX\n', '')

    # Patch AnsibleModule instance to mock object
    module.get_bin_path = mock_get_bin_path
    module.run_command = mock_run_command

    # get_best_parsable_locale function
    preferences = ['C', 'POSIX']

# Generated at 2022-06-11 01:11:09.713955
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.modules.system.locale import AnsibleModule
    import ansible.module_utils.basic
    module_args = {}
    # AnsibleModule is a *class* so it needs to be instantiated
    mod = AnsibleModule(argument_spec=module_args)
    mod.run_command = lambda args: (0, 'C\nen_US.utf8\nen_US.UTF-8\nen_US.UTF8\nC.UTF-8\n', '')

    assert get_best_parsable_locale(mod, preferences=None) == 'en_US.utf8'
    assert get_best_parsable_locale(mod, preferences=['en_US.utf8', 'en_US.UTF-8', 'C']) == 'en_US.utf8'
    assert get_

# Generated at 2022-06-11 01:11:17.332919
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    preferences = ['C.utf8', 'C']
    assert get_best_parsable_locale(None, preferences) == 'C'

    preferences = ['en_US.utf8', 'C.utf8', 'en_US', 'C', 'POSIX']
    assert get_best_parsable_locale(None, preferences) == 'C'

    preferences = ['en_US.utf8', 'C.utf8', 'en_US', 'C', 'POSIX']
    assert get_best_parsable_locale(None, preferences, raise_on_locale=True) == 'C'

# Generated at 2022-06-11 01:11:22.032101
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path as get_module_bin_path
    module = None  # pass tests
    module.get_bin_path = get_module_bin_path
    preferences = ['C.utf8', 'C', 'POSIX']
    raise_on_locale = True
    found = get_best_parsable_locale(module, preferences, raise_on_locale)

# Generated at 2022-06-11 01:11:25.075325
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'

# Generated at 2022-06-11 01:11:30.389591
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()
    assert get_best_parsable_locale(module) == 'C'

    module = AnsibleModule(locale=['en_GB.utf8', 'en_US.utf8'])
    assert get_best_parsable_locale(module) == 'en_GB.utf8'

# Generated at 2022-06-11 01:11:42.161575
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    def _assert_locale(locale, module, preferences=None, raise_on_locale=False):
        if not preferences:
            preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
        assert locale == get_best_parsable_locale(module, preferences, raise_on_locale=raise_on_locale)

    # Test that the function returns the first match, (in order of preferences), from the list of available locales
    # Note: the available locales are mocked by module.run_command()
    _assert_locale('en_US.utf8', FakeModule(['C.utf8', 'posix', 'en_US.utf8']))

# Generated at 2022-06-11 01:11:49.270430
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # no locale so return C
    locale = get_best_parsable_locale(module)
    assert locale == "C"

    # no locale, raise on locale so exception
    try:
        locale = get_best_parsable_locale(module, raise_on_locale=True)
        assert False, "Exception should have been raised"
    except Exception as e:
        assert not None

    # output list with preferences which is not in the list so return C
    module.get_bin_path = lambda x: "/usr/bin/locale"

# Generated at 2022-06-11 01:12:00.197270
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' Test function for get_best_parsable_locale '''

    from ansible.module_utils.facts.locale import LazyLocaleFacts
    from ansible.module_utils.facts.namespace import Namespace

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path

    def fake_run_command(module, command):
        ''' Returns fake output to mimick the locale command '''

        if command[1] == '-a':
            # english locale
            return 0, '/usr/bin/locale: C\n/usr/bin/locale: en_US\n', ''
        return -1, '', ''


# Generated at 2022-06-11 01:12:11.793877
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils import basic

    def _fake_get_bin_path(cmd, required=False):
        if cmd.endswith("/locale"):
            return "/bin/locale"
        return None

    def _fake_run_command(cmd, cwd=None):
        if cmd == ['/bin/locale', '-a']:
            return (0, 'C.utf8\nen_US.utf8\nC\nPOSIX', '')
        elif cmd == ['/bin/locale', '-a'] and cwd is not None:
            return (0, '', "failed to change working directory")
        else:
            assert False, "Unexpected command: %r " % cmd


    # get

# Generated at 2022-06-11 01:12:13.261773
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-11 01:12:24.428055
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test the function get_best_parsable_locale
    '''
    mock_module = Mock()
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    mock_module.run_command.return_value = 3, '', ''

    assert get_best_parsable_locale(mock_module, preferences, False) == 'C'

    preferences_2 = ['de_DE.utf8', 'de_DE.utf8', 'C', 'POSIX']
    rc, out, err = (0, 'C', '')
    mock_module.run_command.return_value = rc, out, err
    assert get_best_parsable_locale(mock_module, preferences_2,
                                    False) == 'C'

   

# Generated at 2022-06-11 01:12:35.918306
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # locale is not installed - will return 'C'
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, raise_on_locale=False) == 'C'

    # locale is installed, but the output is empty
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda args: (0, '', '')
    assert get_best_parsable_locale(module, raise_on_locale=False) == 'C'

    # locale is installed, but only 'en_US.utf8' is available
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda args: (0, 'en_US.utf8', '')
   

# Generated at 2022-06-11 01:12:46.238006
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Return the first matched preferred locale or 'C' which is the default
    # Mock some modules
    class FakeModule:
        def get_bin_path(self, bin):
            # Return a path to a binary
            return "/usr/bin/locale"
        def run_command(self, command):
            # Return a set of stdout and stderr
            # rc should be 0
            return 0, "C\nen_US.utf8\nC.utf8", ""

    # Test the first two preferred locales
    module = FakeModule()
    preferences = ['C.utf8', 'en_US.utf8']
    assert get_best_parsable_locale(module, preferences) == 'C.utf8'

    # Test the last two preferred locales, which should return the last locale

# Generated at 2022-06-11 01:12:56.777333
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(argument_spec=dict())
    test_module.get_bin_path = lambda x: x
    test_module.run_command = lambda x: (0, StringIO('C'), '')
    assert get_best_parsable_locale(test_module) == 'C'
    test_module.run_command = lambda x: (1, StringIO(''), '')
    assert get_best_parsable_locale(test_module) == 'C'
    test_module.run_command = lambda x: (0, StringIO('C\nen_US.utf8'), '')

# Generated at 2022-06-11 01:13:02.955396
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert module.get_best_parsable_locale(module) == module.get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX', 'C'])
    assert module.get_best_parsable_locale(module) != module.get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C'])
    assert module.get_best_parsable_locale(module) != module.get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'POSIX'])

# Generated at 2022-06-11 01:13:19.059844
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    locale = get_best_parsable_locale(module)
    assert locale == 'C'
    locale = get_best_parsable_locale(module, raise_on_locale=True)
    assert locale == 'C'
    module.get_bin_path = lambda term: term
    locale = get_best_parsable_locale(module)
    assert locale == 'C'
    locale = get_best_parsable_locale(module, raise_on_locale=True)
    assert locale == 'C'
    module.run_command = lambda term: (0, 'C\nen_US.utf8\nPOSIX\n', '')
    locale = get_best_parsable_loc

# Generated at 2022-06-11 01:13:26.757779
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule()
    locale = get_best_parsable_locale(module, preferences=['C.utf8'])
    assert locale == 'C.utf8'

    # 'C.utf8' is not available. Make it fallback to 'C'
    module.run_command = lambda command: (0, 'C\nc\n', '')
    locale = get_best_parsable_locale(module, preferences=['C.utf8'])
    assert locale == 'C'

    # 'C' is not available. Make it fallback to 'POSIX'
    module.run_command = lambda command: (0, 'POSIX.utf8\nc.utf8\n', '')
    locale = get_best_parsable_locale(module, preferences=['C', 'POSIX'])


# Generated at 2022-06-11 01:13:37.577861
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import tempfile
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 01:13:47.612590
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    preferences = ['en_US.utf8', 'C.utf8', 'en_US.UTF-8', 'POSIX', 'C']
    preferences_none = None
    preferences_empty = []

    # Testing function with no preferences
    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module, preferences_none)
    assert locale == 'C.utf8'

    # Testing function with empty preferences
    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale(module, preferences_empty)
    assert locale == 'C'

    # Testing function with preferences
    module = AnsibleModule(argument_spec={})
    locale = get_best_parsable_locale

# Generated at 2022-06-11 01:13:51.699034
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    assert(get_best_parsable_locale(module) == 'C')
    assert(get_best_parsable_locale(module, preferences=['foo_FOO.utf8', 'bar_BAR.utf8']) == 'C')

# Generated at 2022-06-11 01:13:56.639962
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule({})

    assert 'C' == get_best_parsable_locale(am)
    assert 'C' == get_best_parsable_locale(am, preferences=['POSIX', 'C', 'C.UTF-8'])

# Generated at 2022-06-11 01:14:05.938879
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = AnsibleModule(
        argument_spec=dict()
    )

    cmd = module.get_bin_path('locale', required=True)

    # An execution of `locale -a` without setting anything in the environment should
    # return the default locale and a list of locales available on the system.
    rc, out, err = module.run_command([cmd, '-a'])
    assert rc == 0
    assert err == b''

    # The output of the previous command should contain the locale specified in
    # LOCALE_PREFERENCES by default.
    assert get_best_parsable_locale(module) in out

# Generated at 2022-06-11 01:14:13.790578
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test function for get_best_parsable_locale
    '''

    from ansible.module_utils.basic import AnsibleModule
    amodule = AnsibleModule()
    locale = get_best_parsable_locale(amodule)
    assert locale == "C"

    locale = get_best_parsable_locale(amodule, ['en_US.utf8', 'en_US.utf8'])
    assert locale == "en_US.utf8"

    locale = get_best_parsable_locale(amodule, ['doesntexist', 'en_US.utf8'])
    assert locale == "en_US.utf8"


# Generated at 2022-06-11 01:14:24.919784
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import mock
    from ansible.module_utils.basic import AnsibleModule

    m = mock.Mock()
    found = get_best_parsable_locale(m)
    assert found == 'C'

    m.run_command.return_value = (0, '', '')
    found = get_best_parsable_locale(m)
    assert found == 'C'

    m.run_command.return_value = (0, 'C', '')
    found = get_best_parsable_locale(m)
    assert found == 'C'

    m.run_command.return_value = (0, 'en_US.utf8', '')
    found = get_best_parsable_locale(m)
    assert found == 'en_US.utf8'

    m

# Generated at 2022-06-11 01:14:33.925995
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    try:
        from ansible.module_utils.common._collections_compat import MutableMapping
    except ImportError:
        from collections import MutableMapping
    class FakeModule():
        def __init__(self):
            self.params = {}
        def get_bin_path(self, arg):
            if arg == "locale":
                return "locale"
            else:
                return None
        def run_command(self, arg):
            if arg == ['locale', '-a']:
                return (0, "en_US.utf8\nen_US\nen_GB.utf8\nen_GB\nnb_NO.utf8\nnb_NO", None)
            else:
                return (1, None, "Unable to get locale information")


# Generated at 2022-06-11 01:14:50.986805
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import io
    import os

    try:
        import mock
    except ImportError:
        from unittest import mock

    class FakeModule(object):
        def __init__(self):
            self.run_command_stdout = (
                'C\n'
                'C.UTF-8\n'
                'en_US.utf8\n'
                'en_US.UTF-8\n'
                'POSIX\n'

            )
            self.run_command_stderr = ''
            self.run_command_rc = 0
            self.run_command_exception = None

        def run_command(self, args, check_rc=True, close_fds=True):
            out = io.StringIO(self.run_command_stdout)

# Generated at 2022-06-11 01:14:56.911026
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    locale = get_best_parsable_locale(module, preferences=preferences)
    print(locale)

if __name__ == '__main__':
    test_get_best_parsable_locale()

# Generated at 2022-06-11 01:15:04.573292
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    class FakeModule:
        def get_bin_path(self, arg):
            return "/usr/bin/locale"

        def run_command(self, arg):
            if arg[1] == "-a":
                return 0, "C.utf8\nen_US.utf8\nC\nPOSIX", ""
            else:
                return 0, "LANG=" + arg[1], ""

    fakemodule = FakeModule()

    assert(get_best_parsable_locale(fakemodule) == "C.utf8")

    assert(get_best_parsable_locale(fakemodule, ['C']) == "C")

    assert(get_best_parsable_locale(fakemodule, ['de_DE']) == "C")

    fakemodule.get_bin_path = lambda x: None


# Generated at 2022-06-11 01:15:15.819052
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import mock

    if sys.version_info[0:2] > (2, 6):
        import unittest
        class TestGetBestParsableLocale(unittest.TestCase):
            @mock.patch('ansible.module_utils.common.locale.get_best_parsable_locale')
            def test_get_best_parsable_locale(self, mocked_get_best_parsable_locale):
                # test when locale is not present, assume C locale
                mocked_get_best_parsable_locale.return_value = 'C'
                self.assertEquals(get_best_parsable_locale(mocked_get_best_parsable_locale), 'C')


# Generated at 2022-06-11 01:15:26.907900
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Test module to get_best_parsable_locale
    """
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    from ansible.module_utils.common.process import get_bin_path

    # Define the class to be tested
    class MyClass():
        """
        Dummy class for testing get_best_parsable_locale
        """
        def get_bin_path(self, cmd):
            """
            Dummy method for testing get_best_parsable_locale

            :param cmd: Command to run
            """
            return get_bin_path(cmd)


# Generated at 2022-06-11 01:15:33.477324
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    :return: Unit test results
    '''

    # The -a option produces a list of locales in ascending order.
    # We want the last line in the returned output to be a locale we can use.
    # The list provided below is the output from 'locale -a' on a standard Ubuntu system.
    # We have reordered the last line to be one we can use, here.
    #
    # The function should return 'C.UTF-8'.
    # We have placed that at the start of the list, here.
    #
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule
    expected_result = 'C.utf8'

# Generated at 2022-06-11 01:15:43.017889
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils import basic
    import tempfile

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
        check_invalid_arguments=False,
    )

    fd, locale_path = tempfile.mkstemp()

# Generated at 2022-06-11 01:15:53.440109
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    # raise on locale not found
    am = DummyAnsibleModule(params={})
    am.run_command = DummyCommand
    if PY2:
        assert get_best_parsable_locale(am, ['xx_YY.UTF-8'], True) == 'C'
        assert get_best_parsable_locale(am, ['xx_YY', 'yy_ZZ'], True) == 'C'
        assert get_best_parsable_locale(am, ['en_US.UTF-8'], True) == 'en_US.utf8'

# Generated at 2022-06-11 01:16:02.398661
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Importing module in test function to cicrular dependency
    from ansible.module_utils import basic
    locale = basic.AnsibleModule(argument_spec={})

    best_locale = get_best_parsable_locale(locale)
    assert best_locale == 'C'

    best_locale = get_best_parsable_locale(locale, preferences=['C.utf8', 'C', 'POSIX'])
    assert best_locale == 'C'

    best_locale = get_best_parsable_locale(locale, preferences=['C.utf8', 'C', 'POSIX', 'en_US.utf8'])
    assert best_locale == 'C'

# Generated at 2022-06-11 01:16:11.987824
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from collections import namedtuple
    FakeModule = namedtuple('FakeModule', ['run_command', 'get_bin_path'])

    # This tests the case where we have no 'locale' executable
    test_list = [
        'C'  # default posix, its ascii but always there
    ]
    mod = FakeModule(run_command=None, get_bin_path=lambda x: None)
    for test in test_list:
        assert get_best_parsable_locale(mod) == test, "Expected %s found %s" % (test, get_best_parsable_locale(mod))

    # This tests the case where we have a 'locale' executable
    # but we fail to get the locales list

# Generated at 2022-06-11 01:16:35.001133
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    ''' test get_best_parsable_locale '''

    from ansible.modules.pm_locale import get_best_parsable_locale
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={
            'preferences': {'required': True, 'type': 'list'},
            'raise_on_locale': {'required': False, 'type': 'bool'},
        },
        supports_check_mode=True,
    )

    locale = get_best_parsable_locale(module)
    module.exit_json(msg="best locale: %s" % locale, changed=True)

# Generated at 2022-06-11 01:16:44.401995
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    This tests ansible.module_utils.get_best_parsable_locale function.
    We use locale_a_cmd and locale_a_output to emulate the output of locale -a command.
    """
    try:
        from ansible.module_utils.basic import AnsibleModule, get_bin_path
        from ansible.modules.system.raw import RawModule
    except Exception:
        print("Could not import required modules for testing get_best_parsable_locale")
        return False
    class AnsibleModuleStub(object):
        def __init__(self):
            self.params = {}
            self.argument_spec = {}
            self.check_mode = False
            self.fake_ansible_module = True

# Generated at 2022-06-11 01:16:51.637131
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda cmd: (0, 'C\nen_US\nen_US.utf8', None)
    assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'en_US.utf8'
    module.run_command = lambda cmd: (0, 'en_US\nen_US.utf8', None)
    assert get_best_parsable_locale(module, ['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'en_US.utf8'

# Generated at 2022-06-11 01:17:00.838865
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 01:17:09.512434
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    def mock_run_command(self, args, **kwargs):
        if args[0] == 'locale' and args[1] == '-a':
            if args[2] == 'C.utf8':
                return 0, 'C.utf8\nen_US.utf8\nen_US.utf8', None
            elif args[2] == 'POSIX':
                return 0, 'POSIX\nen_US.utf8\nen_US.utf8', None
            else:
                return 0, 'C.utf8\nen_US.utf8', None

    def test_get_best_parsable_locale(module, preferences, raise_on_locale, expected):
        actual = get_best_parsable_locale(module, preferences, raise_on_locale)
        assert actual == expected

# Generated at 2022-06-11 01:17:19.464939
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    def check_locale(desc, preferences, expected_locale, raise_on_locale=False):
        module = AnsibleModule(argument_spec={})
        locale = get_best_parsable_locale(module, preferences, raise_on_locale)

        if locale != expected_locale:
            print("Error with %s. Got %s, expected %s" % (desc, locale, expected_locale))

    check_locale("Default preferences", None, 'C')
    check_locale("Out of order", ['en_US.utf8', 'C', 'POSIX'], 'C')
    check_locale("Last of all", ['any_random.utf8', 'another.utf8', 'POSIX'], 'POSIX')
    check

# Generated at 2022-06-11 01:17:26.511388
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path

    nolocale_bin_paths = get_bin_path('locale')
    print(nolocale_bin_paths)

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = None
    module = AnsibleModule(
        argument_spec=dict(),
    )
    print(get_best_parsable_locale(module, preferences=None, raise_on_locale=False))


# Generated at 2022-06-11 01:17:34.526326
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

    # get_best_parsable_locale only checks the first element of the output of 'locale -a'
    # which is fine in most cases. But to unit test the function we want to check whether
    # the output of 'locale -a' is actually checked.
    assert get_best_parsable_locale(None, ['ThisLocaleDoesNotExist']) == 'C'

    # the preferred locale 'C' is always available.
    assert get_best_parsable_locale(None, ['C']) == 'C'

    # The preferred locale list is ordered by preference. The first preferred locale
    # which is available is returned.

# Generated at 2022-06-11 01:17:44.976547
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    module = AnsibleModule(argument_spec={})

    # 1. Test when locale is found in environment
    class MockModule(object):
        def __init__(self, out, rc=0):
            self.out = out
            self.rc = rc

        def get_bin_path(self, binary):
            if binary == 'locale':
                return '/usr/bin/locale'
            else:
                return None

        def run_command(self, cmd):
            return self.rc, self.out, ''

    # 1.1 with a fully matched preferred locale
    out = to_bytes

# Generated at 2022-06-11 01:17:52.437520
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({}, check_invalid_arguments=False)
    module.run_command = run_command_mock
    assert get_best_parsable_locale(module) == 'en_US.utf8'
    assert get_best_parsable_locale(module, ['en_GB.utf8']) == 'en_GB.utf8'
    assert get_best_parsable_locale(module, []) == 'C'



# Generated at 2022-06-11 01:18:18.238355
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    correct_locale_preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({'ANSIBLE_LOCALE_UTILS': True})
    locale = get_best_parsable_locale(module, None)
    assert locale == 'C'
    module = AnsibleModule({'ANSIBLE_LOCALE_UTILS': False})
    locale = get_best_parsable_locale(module, None)
    assert locale is None
    module = AnsibleModule({'ANSIBLE_LOCALE_UTILS': True})
    module.run_command = test_run_command
    locale = get_best_parsable_locale(module, correct_locale_preferences)
   

# Generated at 2022-06-11 01:18:21.564765
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import os
    import tempfile
    #from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestAnsibleModule:
        def __init__(self):
            self.run_command_return_value = (0, '', '')
            self.run_command_calls = []

        def get_bin_path(self, _):
            return 'run'

        def run_command(self, args, check_rc=None):
            print(args)
            self.run_command_calls.append(args)
            rc, out, err = self.run_command_return_value
            return rc

# Generated at 2022-06-11 01:18:29.852233
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    locale_results = [
        {'rc': 0, 'out': 'C\nC.UTF-8\nen_US.utf8\nPOSIX\n'},
        {'rc': 0, 'out': 'C\nC.UTF-8\nen_US.utf8\nPOSIX\n', 'err': 'This is non-empty'},
        {'rc': 0, 'out': '', 'err': 'This is non-empty'},
        {'rc': 1, 'out': '', 'err': 'This is non-empty'},
    ]

# Generated at 2022-06-11 01:18:37.382096
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    with open(__file__) as locale_list_file:
        test_list = locale_list_file.readlines()
    # test for locale en_US.utf8 on test file
    assert get_best_parsable_locale(module, preferences=['en_US.utf8'], raise_on_locale=True) == 'en_US.utf8'
    # test for locale en_US.utf8 on actual system, might fail on system without this locale
    assert get_best_parsable_locale(module, preferences=['en_US.utf8'], raise_on_locale=True) == 'en_US.utf8'
    # test for locale en