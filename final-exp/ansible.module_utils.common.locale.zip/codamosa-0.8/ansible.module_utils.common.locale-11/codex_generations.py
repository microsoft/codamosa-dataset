

# Generated at 2022-06-11 01:08:46.124713
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Tests the get_best_parsable_locale function
    '''

    from ansible.module_utils.basic import AnsibleModule

    class FakeAnsibleModule:

        def __init__(self):
            self.params = {"fail_on_locale": False}

        def get_bin_path(self, executable, required=False, opt_dirs=None):
            if executable == 'locale':
                return executable
            else:
                return None

        def run_command(self, cmd):
            # Set up desired values for test cases
            rc = 0
            err = ''

            if not isinstance(cmd, str):
                cmd = ' '.join(cmd)

            if cmd == 'locale -a':
                out = 'C.utf8 en_US.utf8 C POSIX'


# Generated at 2022-06-11 01:08:56.069529
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import tempfile
    import os

    # add something that would show up if locale -a was run
    lc = tempfile.NamedTemporaryFile(delete=False)
    lc.close()
    os.environ["LANG"] = os.path.basename(lc.name).split('-')[0]

    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, preferences=[]) == 'C'
    assert get_best_parsable_locale(None, preferences=[os.path.basename(lc.name)]) == os.path.basename(lc.name)
    assert get_best_parsable_locale(None, preferences=['does-not-exist', os.path.basename(lc.name)])

# Generated at 2022-06-11 01:09:04.500595
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    if sys.version_info[0] < 3:
        import mock
    else:
        from unittest import mock
    class AnsibleModule():
        def get_bin_path(self, binary):
            return binary
        def run_command(self, command):
            if "locale" in command:
                return 0, "C.utf8\nen_US.utf8\nen_US.utf8\n", ""
            return 0, "", ""

    # test 1:
    # test with existing locale
    # Best locale is C.utf8
    preferences = ['C.utf8', 'en_US.utf8']
    ansible_module = AnsibleModule()
    found = get_best_parsable_locale(ansible_module, preferences, raise_on_locale=False)
   

# Generated at 2022-06-11 01:09:06.120032
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'

# Generated at 2022-06-11 01:09:16.934834
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    assert get_best_parsable_locale(module, ['C.utf8'], True) == 'C.utf8'
    assert get_best_parsable_locale(module, ['POSIX'], True) == 'POSIX'
    assert get_best_parsable_locale(module, ['C.utf8'], False) == 'C.utf8'
    assert get_best_parsable_locale(module, ['POSIX'], False) == 'POSIX'

    # Test for Language preferences
    assert get_best_parsable_locale(module, ['POSIX', 'C.utf8'], True) == 'POSIX'
    assert get_best_parsable

# Generated at 2022-06-11 01:09:24.097665
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = Mock()

# Generated at 2022-06-11 01:09:32.318047
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import mock

    class module_mock():
        def __init__(self):
            self.exit_args = None

        def run_command(self, cmd):
            return None, None, None

        def get_bin_path(self, cmd):
            return "locale"

        def fail_json(self, **args):
            self.exit_args = args

    available_locales = ['en_US.utf8', 'en_US.utf8@mutant', 'en_US.utf8@heisensprung',
                         'C', 'C.UTF-8', 'C.utf8', 'POSIX']


# Generated at 2022-06-11 01:09:42.724599
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    out = StringIO()
    out.write('C\n')
    out.write('POSIX\n')
    out.seek(0)

    mod = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    mod.run_command = lambda x: (0, out.read(), "")
    assert get_best_parsable_locale(mod) == 'C'

    out.seek(0)
    mod.run_command = lambda x: (0, out.read(), "")
    assert get_best_parsable_locale(mod, preferences=['zz_ZZ.utf8']) == 'C'


# Generated at 2022-06-11 01:09:53.015855
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    locale_for_test = ['C.utf8', 'en_US.utf8', 'POSIX']

    # Test 1:
    # Test if the function returns the correct locale when it is in the list of preferred locales
    assert (get_best_parsable_locale(None, locale_for_test) == 'C.utf8')

    # Test 2:
    # Test if the function returns the last locale in the list as the default is not in the list of preferred locales
    locale_for_test_without_default_locale = locale_for_test[1:]
    assert (get_best_parsable_locale(None, locale_for_test_without_default_locale) == 'POSIX')

    # Test 3:
    # Test if the function returns the default locale if no locale in the list of preferred locales

# Generated at 2022-06-11 01:09:58.416459
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == "C"
    assert get_best_parsable_locale(None, ['asdf']) == "C"
    assert get_best_parsable_locale(None, ['C']) == "C"
    assert get_best_parsable_locale(None, ['C', 'asdf']) == "C"

# Generated at 2022-06-11 01:10:08.917553
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import StringIO


# Generated at 2022-06-11 01:10:14.881800
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    assert 'C' == get_best_parsable_locale(module)

    preferences = ['en_US.utf8', 'en_US.utf8']

    assert 'en_US.utf8' == get_best_parsable_locale(module, preferences=preferences)

# Generated at 2022-06-11 01:10:16.504575
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert(get_best_parsable_locale('C') == 'C')

# Generated at 2022-06-11 01:10:25.655456
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    rc = 0
    out = 'C.utf8\nen_US.utf8\nC\nPOSIX\n'
    err = ''
    run_command_mock = Mock(return_value=(rc, out, err))
    module_mock = Mock()
    module_mock.run_command = run_command_mock
    module_mock.get_bin_path = Mock(return_value='locale')

    found = 'C'
    locale_list = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    result = get_best_parsable_locale(module_mock, preferences=locale_list)
    assert result == found


from ansible.module_utils import basic
from ansible.module_utils.six.moves.queue import Que

# Generated at 2022-06-11 01:10:29.189027
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule({})
    assert get_best_parsable_locale(mod) == "C"

# Generated at 2022-06-11 01:10:36.528161
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    assert module
    found = get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True)
    assert isinstance(found, str)
    assert found == 'C'

# Generated at 2022-06-11 01:10:47.209447
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import sys
    import unittest

    # we cannot use normal mock because core modules are imported inside of
    # AnsibleModule. this is a very simple version of mock that we do not use in
    # production
    class Mock(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def get_bin_path(self, *args, **kwargs):
            # C is always available
            return 'C'

        def run_command(self, *args, **kwargs):
            return 0, 'C\nen_US.utf8\nFr', ''

    mock = Mock()

    # On windows this usually raises an exception because the locale tool is
    # not available
    stdout_orig = sys.stdout

# Generated at 2022-06-11 01:10:51.696284
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module) == 'C'
    preferences=['de_DE.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(module, preferences=preferences) == 'C'

# Generated at 2022-06-11 01:10:58.041414
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Setup test module
    d = dict(ANSIBLE_MODULE_ARGS={})
    module = AnsibleModule(argument_spec=d)

    assert get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C'


# Generated at 2022-06-11 01:11:02.735712
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=['a_US.utf8', 'b_US.utf8']) == 'C'

# Generated at 2022-06-11 01:11:14.242168
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    global module
    global locale
    locale = 'locale'
    module = AnsibleModule(argument_spec={})
    assert get_best_parsable_locale(module, ['de_DE.utf8', 'C.utf8', 'en_US.utf8', 'C', 'POSIX']) == 'C.utf8'
    global settings
    settings = {'nocolor': True, 'no_log': True, 'stdout_callback': None, '_ansible_verbosity': 3}
    module.basic._ansible_verbosity = 3
    module.params = {}
    module.warnings = []
    module.no_log_values = set()
    module.deprecations = []
    module.exit_json = lambda a, b, changed=False: True

# Generated at 2022-06-11 01:11:23.796370
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-11 01:11:33.121226
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # No locale in path
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda x, **kwargs: (0, "C.utf-8\nen_US.utf8", '')
    assert get_best_parsable_locale(module, ['C.utf-8', 'en_US.utf8']) == 'C.utf-8'

    # Locale tool not found
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: None
    assert get_best_parsable_locale(module, ['C.utf-8', 'en_US.utf8']) == 'C'

    # /usr/bin/locale exits with non-zero status
    module = AnsibleModule(argument_spec={})
    module.run_

# Generated at 2022-06-11 01:11:36.196608
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None) == 'C'
    assert get_best_parsable_locale(None, ['de_DE.utf8', 'C.utf8']) == 'C'

# Generated at 2022-06-11 01:11:45.535183
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test function get_best_parsable_locale
    '''

    case1 = "C.UTF-8"
    preferences = ['en_US.UTF-8', 'C.UTF-8']
    assert get_best_parsable_locale(None, preferences) == case1
    preferences = ['es_US.UTF-8', 'C.UTF-8']
    assert get_best_parsable_locale(None, preferences) == case1
    preferences = ['es_US.UTF-8', 'en_US.UTF-8']
    assert get_best_parsable_locale(None, preferences) == 'C'
    preferences = ['zh_CN.UTF-8', 'en_US.UTF-8']
    assert get_best_parsable_locale(None, preferences)

# Generated at 2022-06-11 01:11:49.437087
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    """
    Unit test for the get_best_parsable_locale method
    """

    # just testing that it returns found
    assert "C" == get_best_parsable_locale(None), "Unit test for the get_best_parsable_locale method failed"

# Generated at 2022-06-11 01:11:59.709286
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Make sure _text will not be loaded during unit test
    import sys
    sys.modules['ansible.module_utils._text'] = None

    # Run the get_best_parsable_locale function with a locale -a output
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.locales import get_best_parsable_locale

    module = AnsibleModule(argument_spec={})
    out = '''C
C.utf8
en_US.utf8
POSIX
'''

    expected = 'C.utf8'
    assert get_best_parsable_locale(module, preferences=['C.utf8'], raise_on_locale=True) == expected

# Generated at 2022-06-11 01:12:11.258033
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # In a unit test avoid having to mock modules
    class FakeAnsibleModule:
        def __init__(self, locale_path=None):
            self.locale_path = locale_path

        def get_bin_path(self, _):
            return self.locale_path

        def run_command(self, cmd):
            assert len(cmd) == 2
            assert cmd[0] == self.locale_path
            assert cmd[1] == '-a'
            if self.locale_path == '/bin/locale':
                # This is what POSIX locale -a would return, missing C.UTF-8 and C.utf8
                return 0, '\n'.join(['C', 'POSIX']), ''

# Generated at 2022-06-11 01:12:14.962768
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    my_locales = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(None, my_locales) in my_locales

# Generated at 2022-06-11 01:12:18.567690
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path

    assert get_best_parsable_locale(dict(get_bin_path=get_bin_path), ['doesnotexist', 'C']) == 'C'

# Generated at 2022-06-11 01:12:34.113446
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
        Test our locale detection algorithms.
        This is a tricky one so we need to be sure it works for all possible cases.
    '''

    import os

    from ansible.module_utils.basic import AnsibleModule

    # the real test is in the return value, the rest of this is just checking we can get to success
    module = AnsibleModule(
        argument_spec=dict(
            locale=dict(default='C', required=False),
            preferences=dict(default=None, required=False),
            raise_on_locale=dict(default=False, type='bool', required=False),
        ),
        supports_check_mode=True
    )


# Generated at 2022-06-11 01:12:42.624130
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    import mock
    import test.ansible_module_mock as mock_module

    class FakeModule(mock_module.AnsibleModule):

        def __init__(self, locale_list, locale_path=None, is_locale_available=True):
            super(FakeModule, self).__init__(argument_spec={})

            def fake_run_command(args, tmp_path=None, timeout=0, check_rc=None):
                if args[0] == 'locale' and is_locale_available is True:
                    return (0, '\n'.join(locale_list), '')
                else:
                    return (1, '', '')


# Generated at 2022-06-11 01:12:50.941197
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule()
    mod.run_command = lambda args, check_rc=True, close_fds=True, executable=None, data=None: (0, '', '')
    mod.get_bin_path = lambda name, opt_dirs=None: True
    assert get_best_parsable_locale(mod, raise_on_locale=False) == 'C'

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-11 01:12:59.484942
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    # Mock the module class for use in the test
    class MockModule:

        return_value = ''

        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, command):
            return self.rc, self.out, self.err

        def fail_json(self, **kwargs):
            return

        def get_bin_path(self, tool):
            if tool == 'locale':
                return 'locale'
            else:
                return None

    # Mock locale -a output
    locale_a_command_output = u'''
C
posix
en_US.utf8
en_US.UTF-8
en_US
C.utf8
C.UTF-8
'''

   

# Generated at 2022-06-11 01:13:10.953371
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    module = AnsibleModule(
        argument_spec=dict(
            preferences=dict(type='list', default=None),
        ),
        supports_check_mode=False,
    )

    def run_command_fails(args, check_rc=None, close_fds=None, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None):
        return 1, '', ''

    module.run_command = run_command_fails

# Generated at 2022-06-11 01:13:21.553849
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class FakeModule:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err
            self.fail_json_called = False
            self.warn = self.warn_called = False

        def run_command(self, cmd):
            return self.rc, self.out, self.err

        def fail_json(self, *args, **kwargs):
            self.fail_json_called = True

        def warn(self, msg):
            self.warn_called = True

    # test case 1: to get 'C' locale
    m = FakeModule(0, None, None)
    assert get_best_parsable_locale(m) == 'C'
    assert m.fail_json_called == False
    assert m.warn

# Generated at 2022-06-11 01:13:32.267011
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    from ansible.module_utils.basic import _load_params
    from ansible.module_utils._text import to_bytes
    module = _load_params()
    test_preferences = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    lang = os.environ.get('LANG', None)
    if lang is not None:
        del os.environ['LANG']
    try:
        locale = module.get_bin_path("locale")
    except Exception:
        locale = None
    if locale is None:
        try:
            # not using required=true as that forces fail_json
            module.run_command([locale, '-a'])
        except Exception:
            found = 'C'
    else:
        module.run_

# Generated at 2022-06-11 01:13:43.612444
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX']

    # Return first preference - make sure we return the top of the list
    assert get_best_parsable_locale(None, preferences=['C', 'C.utf8']) == 'C'
    assert get_best_parsable_locale(None, preferences=['C.utf8', 'C']) == 'C.utf8'

    # Return first preference - make sure we return a preference even if there are none
    assert get_best_parsable_locale(None, preferences=['xyzzy']) == 'xyzzy'

    # Return first found - make sure we return the first preference in the list of available locales

# Generated at 2022-06-11 01:13:47.493857
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.common.process import get_bin_path

    if get_bin_path('locale'):
        assert get_best_parsable_locale('C.UTF-8') in ['C.UTF-8']
    else:
        assert get_best_parsable_locale() == 'C'

# Generated at 2022-06-11 01:13:53.277223
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    class TestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.tmpdir = '/tmp'
            self.boost_prefs = ['de_DE.utf8', 'C']
            kwargs['argument_spec'] = dict()
            kwargs['supports_check_mode'] = False
            super(TestModule, self).__init__(*args, **kwargs)

        def exit_json(self, *args, **kwargs):
            return None

        def fail_json(self, *args, **kwargs):
            return None


# Generated at 2022-06-11 01:14:09.251812
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(argument_spec=dict())
    found = get_best_parsable_locale(module)
    assert found == 'C'

    rc, out, err = module.run_command([to_bytes(module.get_bin_path('locale'), errors='surrogate_or_strict'), to_bytes('-a', errors='surrogate_or_strict')])
    assert rc == 0
    if out:
        available = out.strip().splitlines()
    else:
        assert False == True, "No output from locale"

    if available:
        assert 'C' in available


# Generated at 2022-06-11 01:14:19.509092
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test 1: Testing getting best locale for specific preference
    preference = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(preferences=preference) == 'C'

    # Test 2: Testing getting best locale for specific preference
    preference = ['en_US.utf8', 'C', 'POSIX']
    assert get_best_parsable_locale(preferences=preference) == 'C'

    # Test 3: Testing getting best locale for specific preference
    preference = ['C', 'POSIX']
    assert get_best_parsable_locale(preferences=preference) == 'C'

    # Test 4: Testing getting best locale for specific preference
    preference = ['POSIX']
    assert get_best_parsable

# Generated at 2022-06-11 01:14:30.249483
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    class MockAnsibleModule(object):
        def __init__(self, err, out, rc):
            # module_utils/basic.py
            class MockFailJsonException(Exception):
                def __init__(self, msg):
                    self.msg = msg
            self.fail_json = MockFailJsonException
            # module_utils/basic.py
            self.basic = type('', (), {})()
            self.basic.run_command = lambda args, environ_update=None, check_rc=None, close_fds=None, executable=None, data=None, binary_data=None: (rc, out, err)
            # module_utils/command.py
            self.get_bin_path = lambda arg, required=False, opt_dirs=[] : arg
            self.params = {}
            self

# Generated at 2022-06-11 01:14:39.804173
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    # Need a better way to test this
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: '/usr/bin/%s' % x
    module.run_command = lambda x: (0, 'C\nPOSIX\n', '')

    assert 'C' == get_best_parsable_locale(module)

    module.run_command = lambda x: (0, 'C\nPOSIX\nC.utf8\n', '')
    assert 'C.utf8' == get_best_parsable_locale(module)

    module.run_command = lambda x: (0, 'sv_SE.utf8', '')
    assert 'C' == get_best_parsable_loc

# Generated at 2022-06-11 01:14:41.030783
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    module = Ansib

# Generated at 2022-06-11 01:14:51.035162
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    # Test with an AnsibleModule that has a get_bin_path() method
    class TestModule:

        def __init__(self):
            self.bin_path_locale = None

        def get_bin_path(self, program):
            return self.bin_path_locale

        def run_command(self, cmds):
            if self.bin_path_locale is None:
                raise RuntimeWarning("Could not find 'locale' tool")

            # test several different outputs from locale -a

# Generated at 2022-06-11 01:14:57.947842
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    from ansible.module_utils.localization import get_best_parsable_locale

    # make sure we can get a valid locale to use
    got_best_locale = get_best_parsable_locale(module, preferences=['C.utf8', 'en_US.utf8', 'C', 'POSIX'], raise_on_locale=True)

    assert got_best_locale is not None

# Generated at 2022-06-11 01:15:05.285337
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import os
    import ansible.module_utils.basic

    class MockModule():
        def __init__(self, fail_json_in=False, rc=0, out='', err='', path=None):
            self.fail_json = fail_json_in
            self.rc = rc
            self.out = out
            self.err = err
            self.path = path

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            if arg == 'locale':
                return '/usr/bin/locale'

        def run_command(self, args):
            return self.rc, self.out, self.err

    # Tests
    #
    # Test with empty output from locale
    m_empty = MockModule(out='')
    assert get_best_pars

# Generated at 2022-06-11 01:15:16.456160
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import iteritems

    test_cases = dict()
    test_cases['available_locales'] = [
        'en_US.utf8',
        'en_US.UTF-8',
        'C',
        'POSIX',
    ]
    test_cases['output_from_locale_tool'] = '\n'.join(test_cases['available_locales'])
    for k, v in iteritems(test_cases):
        module = AnsibleModule({})
        module.get_bin_path = lambda x: x
        module.run_command = lambda x: (0, test_cases['output_from_locale_tool'], '')
        assert get_best_parsable_locale(module)

# Generated at 2022-06-11 01:15:27.716406
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible_collections.misc.tests.unit.modules.utils import AnsibleModule
    from ansible_collections.misc.tests.unit.compat.mock import patch

    module_default = AnsibleModule({})

    # 1st case: locale exists with utf8 and C, C.utf8 is the first preference
    with patch.object(module_default.__class__, 'run_command') as mock_run_command:
        mock_run_command.return_value = 0, '''
            C
            C.UTF-8
            en_US.utf8
            en_US.UTF-8
        ''', ''
        locale = module_default.get_best_parsable_locale(module_default)
        assert 'C.UTF-8' == locale

    # 2nd case: no locale available,

# Generated at 2022-06-11 01:15:39.027320
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    test_preferences = ['en_US.UTF-8', 'en_US.iso88591', 'en_US.UTF-8', 'en_US', 'C']
    assert get_best_parsable_locale(None, test_preferences, True) in test_preferences

# Generated at 2022-06-11 01:15:46.415160
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Need to create a module class to test
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule({})

    # No preference, only C is available, should return C
    assert get_best_parsable_locale(test_module, preferences=None) == 'C'

    # Preference is C and C is available, should return C
    assert get_best_parsable_locale(test_module, preferences=['C']) == 'C'

    # Preference is C, C and en_US are available, should return C
    assert get_best_parsable_locale(test_module, preferences=['C'],
                                    raise_on_locale=True) == 'C'

    # Preference is en_US and en_US is available, should return en_US

# Generated at 2022-06-11 01:15:49.268450
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule(argument_spec=dict())
    print(get_best_parsable_locale(m))

# Generated at 2022-06-11 01:15:59.521197
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    from ansible.module_utils.basic import AnsibleModule
    import os

    # Test 1
    # Preferred locale not available
    # Fallback to default POSIX
    mod = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    preferred = ['not-a-locale.utf8', 'not-here.utf8', 'C.utf8']
    default_locale = 'C'
    best_locale = get_best_parsable_locale(mod, preferred)
    assert (best_locale == default_locale)

    # Test 2
    # Preferred locale available
    # Fallback to set preferred locale
    mod = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

# Generated at 2022-06-11 01:16:06.310049
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import unittest
    import sys
    import os
    import shutil
    import tempfile
    from ansible.module_utils.common.process import get_bin_path

    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    from ansible.module_utils.basic import AnsibleModule

    if sys.version_info < (2, 7):
        import unittest2 as unittest

    class MyAnsibleModule(AnsibleModule):

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            return get_bin_path(arg, required, opt_dirs)


# Generated at 2022-06-11 01:16:16.558641
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    mock_module = MockModule()
    assert get_best_parsable_locale(mock_module) == 'C'

    mock_module.return_value = "sh: locale: command not found"
    assert get_best_parsable_locale(mock_module, raise_on_locale=True) == 'C'

    mock_module.return_value = "C\nC.utf8\nPOSIX\nen_US.utf8"
    assert get_best_parsable_locale(mock_module) == 'C'

    preferences = ['de_DE.utf8', 'C.utf8', 'POSIX', 'en_US.utf8']
    mock_module.return_value = "C\nC.utf8\nPOSIX\nen_US.utf8"
    assert get

# Generated at 2022-06-11 01:16:18.630353
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, preferences=['C', 'SomeLocale.utf8']) == 'C'

# Generated at 2022-06-11 01:16:26.586718
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    module = object()
    m = type('Module', (object,), {'get_bin_path': lambda x, y: '/bin/locale'})
    module = m()
    module.run_command = lambda x: (0, 'C\nen_US.utf8\nC.UTF-8', '')
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    module.run_command = lambda x: (0, 'en_US.utf8\nC.UTF-8', '')
    assert get_best_parsable_locale(module) == 'en_US.utf8'

    module.run_command = lambda x: (0, 'C.UTF-8\nen_US.utf8', '')
    assert get_best_parsable_loc

# Generated at 2022-06-11 01:16:36.454382
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''
    Test get_best_parsable_locale function
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.local import LocalAnsibleModule

    query_command = ['locale', '-a']

    # test case 1, all preferences are supported
    module = LocalAnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        bypass_checks=False
    )
    preferences = ['POSIX', 'C.utf8', 'C.utf-8', 'C', 'en_US.utf-8']
    best_locale = get_best_parsable_locale(module, preferences=preferences)
    assert preferences[0] == best_locale

    # test case 2, only POSIX is supported


# Generated at 2022-06-11 01:16:46.032341
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Test without preferences
    assert get_best_parsable_locale(None) == 'C'

    # Test with preferences
    assert get_best_parsable_locale(None, ['en_GB.utf8', 'en_US.utf8']) == 'en_GB.utf8'
    assert get_best_parsable_locale(None, ['en_US.utf8', 'en_GB.utf8']) == 'en_US.utf8'

    # Test with preferences and fall back to 'C'
    assert get_best_parsable_locale(None, ['en_GB.utf8', 'en_US.utf8', 'en_CA.utf8']) == 'en_GB.utf8'

# Generated at 2022-06-11 01:17:09.546831
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Python 2.6 does not allow module to be mocked.
    # This is the best we can do.
    class MockModule:
        def get_bin_path(self, name):
            return name

        def run_command(self, args):
            if args[0] == 'locale':
                if args[1] == '-a':
                    return 0, 'ja_JP.utf8\nen_US.utf8\nC\nC.utf8', ''
            return 1, '', ''

    test_module = MockModule()
    # We don't have to test C here because we are mocking the command.
    # It will always return C in this test

    # Test en_US.utf8

# Generated at 2022-06-11 01:17:15.567820
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    '''unit tests for get_best_parsable_locale'''

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())
    assert get_best_parsable_locale(module) == 'C'
    assert get_best_parsable_locale(module, preferences=["POSIX", "French"]) == 'C'
    assert get_best_parsable_locale(module, preferences=["POSIX", "POSIX"]) == 'C'

# Generated at 2022-06-11 01:17:26.282134
# Unit test for function get_best_parsable_locale

# Generated at 2022-06-11 01:17:31.654059
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    # Import ansible.module_utils.basic so that we can create a fake ansible module
    import ansible.module_utils.basic

    # Create a fake module
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict()
    )

    # Call the get_best_parsable_locale function and check that it returns correctly
    assert get_best_parsable_locale(module) == 'C'



# Generated at 2022-06-11 01:17:41.657924
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    locale = get_best_parsable_locale(module)

    # we should at least get the POSIX locale back
    assert locale == 'C'

    module.run_command = lambda args: [0, 'C.UTF-8\nen_US.UTF-8\nPOSIX\n', None]

    prefs = ['C.utf8', 'en_US.utf8', 'C', 'POSIX']
    locale = get_best_parsable_locale(module, prefs)

    assert locale in prefs

    prefs = ['en_US.utf8', 'C', 'POSIX']
    locale = get_best_

# Generated at 2022-06-11 01:17:52.343989
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(None, ['C.UTF-8', 'en_US.UTF-8', 'C']) == 'C.UTF-8', \
        'Failed when user preferred locale is available.'
    assert get_best_parsable_locale(None, ['C', 'en_US.UTF-8']) == 'C', \
        'Failed when first user preferred locale is available.'
    assert get_best_parsable_locale(None, ['en_US.UTF-8', 'C']) == 'C', \
        'Failed when second user preferred locale is available.'
    assert get_best_parsable_locale(None, ['zh_CN.UTF-8', 'C']) == 'C', \
        'Failed when only default locale is available.'

# Generated at 2022-06-11 01:18:01.001959
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.facts.system.locale as locale
    mock_module = Mock(params={})
    mock_module.get_bin_path.return_value = True
    # Does it return a default in case of errors?
    mock_module.run_command.return_value = (1, None, 'Error')
    assert locale.get_best_parsable_locale(mock_module) == 'C'
    assert locale.get_best_parsable_locale(mock_module, raise_on_locale=True) == 'C'
    # Does it parse the locales properly?
    mock_module.run_command.return_value = (0, 'C\nen_US.utf8\nC.utf8\nPOSIX\n', None)
    assert locale.get_best

# Generated at 2022-06-11 01:18:12.122904
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    import ansible.module_utils.basic
    m = ansible.module_utils.basic.AnsibleModule(argument_spec={},
                                                 check_invalid_arguments=False,
                                                 bypass_checks=True)
    m.run_command = run_command

    # test default
    locale1 = get_best_parsable_locale(m)
    assert locale1 == 'C'

    # test with list of preferences
    locale2 = get_best_parsable_locale(m, ['C', 'en_US.utf8', 'POSIX'])
    assert locale2 == 'C'

    # test with a list of preferences and the primary in the output

# Generated at 2022-06-11 01:18:19.747848
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        # ansible.module_utils.basic may not be available if the import itself is being tested
        pass
    else:
        module = AnsibleModule(argument_spec={})
        assert get_best_parsable_locale(module) == 'C'  # do not check for valid locale, and return 'C' by default.
        assert get_best_parsable_locale(module, raise_on_locale=True) == 'C'

# Generated at 2022-06-11 01:18:21.185207
# Unit test for function get_best_parsable_locale
def test_get_best_parsable_locale():
    assert get_best_parsable_locale(MockModule()) == 'C'
