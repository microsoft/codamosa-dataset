

# Generated at 2022-06-21 21:33:47.494936
# Unit test for function ok
def test_ok():
    with ok():
        raise ValueError
    with ok(ValueError):
        raise ValueError
    with ok(TypeError):
        pass
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(TypeError, ValueError):
        raise ValueError
    with ok(TypeError, ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise RuntimeError
    with ok(TypeError, ValueError):
        raise RuntimeError
    try:
        with ok(TypeError):
            raise ValueError
        raise AssertionError
    except AssertionError:
        pass
    except Exception as e:
        raise AssertionError("'ok' should let ValueError pass")

# Generated at 2022-06-21 21:33:53.417119
# Unit test for function ok
def test_ok():
    print("Testing function ok")
    try:
        with ok(ZeroDivisionError):
            a = 1 / 0
    except BaseException as e:
        print("Not expected result: ", type(e))
        return False
    else:
        print("Ok!")
        return True


# Tests
if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-21 21:33:59.736192
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        raise TypeError
    # raises AssertionError because NotImplementedError is not in exceptions
    with raises(AssertionError):
        with ok(TypeError):
            raise NotImplementedError
    with raises(TypeError):
        with ok(AttributeError):
            raise TypeError
    # raises AssertionError because with statement is executed successfully
    with raises(AssertionError):
        with ok(TypeError):
            pass



# Generated at 2022-06-21 21:34:01.064300
# Unit test for function ok
def test_ok():
    assert next(ok(), None) is None



# Generated at 2022-06-21 21:34:03.478974
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with ok(ValueError):
        ok()
    try:
        with ok(ValueError):
            raise ValueError
    except:
        assert True



# Generated at 2022-06-21 21:34:04.801727
# Unit test for function ok

# Generated at 2022-06-21 21:34:07.424866
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        pass
    # with ok(ValueError):
    #     raise TypeError()



# Generated at 2022-06-21 21:34:09.288084
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-21 21:34:11.214703
# Unit test for function ok
def test_ok():
    """
    Test implementation of ok method
    """
    try:
        # Raise exception
        with ok(TypeError):
            raise TypeError('I am not an integer')
            raise ValueError('I am a string')
    except ValueError:
        # If a different exception gets raised, raise an error
        raise AssertionError('This should not be an exception')
    # If no error gets raised at all, raise an error
    raise AssertionError('This should be an exception')



# Generated at 2022-06-21 21:34:12.613347
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        1 / 0



# Generated at 2022-06-21 21:34:18.010112
# Unit test for function ok
def test_ok():
    with ok():
        pass

    try:
        with ok():
            raise AssertionError("test")
    except AssertionError:
        pass
    else:
        raise AssertionError("test")



# Generated at 2022-06-21 21:34:21.010240
# Unit test for function ok
def test_ok():
    with ok(FileNotFoundError, FileExistsError):
        open('/file/not/found')
    assert True



# Generated at 2022-06-21 21:34:25.988446
# Unit test for function ok
def test_ok():
    with ok(Exception):
        pass
    with ok(Exception):
        raise Exception
    with ok(TypeError):
        raise TypeError
    try:
        with ok(TypeError):
            raise ValueError
    except ValueError:
        pass
    assert ok


# Full unit testing
if __name__ == "__main__":
    test_ok()
    print("Unit tests for this module are passed.")

# Generated at 2022-06-21 21:34:27.912523
# Unit test for function ok
def test_ok():
    with ok():
        pass
    with ok(ValueError):
        raise ValueError
    with ok(TypeError):
        raise ValueError



# Generated at 2022-06-21 21:34:34.514384
# Unit test for function ok
def test_ok():
    """Unit test function to check if a function successfully
    ignores exceptions passed.
    """
    with ok(TypeError, IndexError):
        # This block should not raise an exception
        dummy = "test"
        dummy[1] = "t"
        raise TypeError()

    with raises(ZeroDivisionError):
        # This block should raise an exception
        div = 1/0



# Generated at 2022-06-21 21:34:37.137618
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print('TypeError will be passed')
        raise TypeError
    print('Test passed')



# Generated at 2022-06-21 21:34:42.836502
# Unit test for function ok
def test_ok():
    """Test function ok."""
    # All exceptions are passed, and no exception is raised
    with ok(Exception):
        pass

    # An exception is passed, and no exception is raised
    with ok(ValueError):
        raise ValueError()

    # An exception is not passed, and an exception is not raised
    with ok(TypeError):
        raise ValueError()



# Generated at 2022-06-21 21:34:48.055977
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        {}['key']
    with ok(KeyError):
        {}['key']
    with ok(KeyError, TypeError):
        {}['key']

# Generated at 2022-06-21 21:34:52.451804
# Unit test for function ok
def test_ok():
    assert ok().__enter__() is None
    with ok():
        pass

    with raises(ValueError):
        with ok(AttributeError):
            raise ValueError()

    with ok(AttributeError, ValueError):
        raise ValueError()



# Generated at 2022-06-21 21:34:53.893164
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1/0
        assert False
    assert True

# Generated at 2022-06-21 21:35:03.879027
# Unit test for function ok
def test_ok():
    i = 0
    try:
        with ok(ValueError, ZeroDivisionError):
            i = 1 / 0
            i = 1 / "1"
    except ValueError as e:
        i = 2
    except TypeError as e:
        i = 3
    assert i == 2


# --------------------------------------------------------------------------------------
#
# 3.2 Write a Context Manager to handle file open/close
#
# --------------------------------------------------------------------------------------

# Generated at 2022-06-21 21:35:09.348843
# Unit test for function ok
def test_ok():
    with ok(KeyError):
        x = {}[1]

    with ok(AttributeError, TypeError):
        print(2 + 's')
    with raises(KeyError):
        with ok(ValueError, TypeError):
            x = {}[1]

    with ok(KeyError):
        x = {}[1]
    with raises(IndexError):
        with ok(KeyError):
            x = [1][2]



# Generated at 2022-06-21 21:35:13.718163
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    # This will raise AssertionError
    with assert_raises(AssertionError):
        with ok(ZeroDivisionError):
            1 / 1
    # This will raise AssertionError
    with assert_raises(ZeroDivisionError):
        with ok(ZeroDivisionError):
            raise ZeroDivisionError

# Generated at 2022-06-21 21:35:17.866572
# Unit test for function ok
def test_ok():
    with ok(ValueError, IndexError):
        x = int('foo')
    with ok(ValueError, IndexError):
        raise IndexError
    with raises(TypeError):
        with ok(ValueError, IndexError):
            raise TypeError

# Generated at 2022-06-21 21:35:20.100521
# Unit test for function ok
def test_ok():
    with ok():
        raise KeyError
        assert False
    assert True

    with ok(ValueError):
        raise KeyError
        assert False
    assert True



# Generated at 2022-06-21 21:35:22.278699
# Unit test for function ok
def test_ok():
    with ok(AttributeError):
        [].get()



# Generated at 2022-06-21 21:35:28.153993
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(FileNotFoundError):
        open('file_not_exist.txt')
    with ok(FileNotFoundError):
        open('file_not_exist.txt')
    with raises(ZeroDivisionError):
        with ok(FileNotFoundError):
            1 / 0



# Generated at 2022-06-21 21:35:38.041405
# Unit test for function ok
def test_ok():
    try:
        # Test simple raise
        with ok():
            raise Exception()
        assert False
    except:
        pass

    try:
        # Test simple raise with Exceptions
        with ok(Exception):
            raise Exception()
        assert False
    except:
        pass

    try:
        # Test simple raise with Exceptions
        with ok(Exception):
            pass
    except:
        assert False

    try:
        # Test simple raise with Exceptions
        with ok(TypeError):
            raise Exception()
        assert False
    except:
        pass

    try:
        # Test multi exceptions
        with ok(Exception, TypeError):
            raise Exception()
        assert False
    except:
        pass


# Generated at 2022-06-21 21:35:43.880757
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError('ok')
    with ok(TypeError):
        raise ValueError('not ok')
    with ok(KeyError, IndexError):
        raise IndexError('ok')
    with ok(KeyError, IndexError):
        raise KeyError('ok')


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-21 21:35:48.126958
# Unit test for function ok
def test_ok():
    # Check that a exception is passed
    with ok(ValueError):
        raise ValueError("Exception")

    # Check that a exception is not passed
    with pytest.raises(ValueError):
        with ok(TypeError):
            raise ValueError("Exception")

    # Check that a exception is passed
    with ok(ValueError, TypeError):
        raise TypeError("Exception")

    # Check that a exception is passed
    with ok(ValueError, TypeError):
        raise ValueError("Exception")

# Generated at 2022-06-21 21:35:59.136270
# Unit test for function ok
def test_ok():
    with ok():
        pass

    with ok(ValueError):
        raise ValueError("Passed")



# Generated at 2022-06-21 21:36:09.308188
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False

    with ok(AssertionError):
        assert True

    with ok(ZeroDivisionError):
        1 / 0

    try:
        with ok():
            1 / 0
    except ZeroDivisionError:
        pass


# ############################################################################
# contextlib.suppress
# https://docs.python.org/3/library/contextlib.html#contextlib.suppress

# @contextmanager
# def suppress(*exceptions):
#     """Context manager to suppress specified exceptions.
#     After the exception is suppressed, execution proceeds with the next
#     statement following the with statement.
#     :param exceptions: Exceptions to suppress
#     """
#     pass



# Generated at 2022-06-21 21:36:10.961582
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')


# Exception to reraise

# Generated at 2022-06-21 21:36:15.018255
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with raises(TypeError):
        raise TypeError
    try:
        with ok(ValueError, TypeError):
            raise ValueError
    except TypeError:
        pass



# Generated at 2022-06-21 21:36:17.935352
# Unit test for function ok
def test_ok():
    with ok(AssertionError, ValueError):
        assert(1 == 1)

    with ok(AssertionError):
        assert(1 == 2)

    with ok(ValueError):
        int('foo')


##############################################################################
# Decorators


# Generated at 2022-06-21 21:36:22.062366
# Unit test for function ok
def test_ok():
    """
    Test function ok
    """
    with ok(Exception, ValueError):
        raise ValueError("easy error")

    with pytest.raises(NameError):
        with ok(Exception, ValueError):
            raise NameError("difficult error")

    with ok(ZeroDivisionError):
        raise ZeroDivisionError("easy division by zero")



# Generated at 2022-06-21 21:36:28.678480
# Unit test for function ok
def test_ok():
    with ok(RuntimeError):
        raise RuntimeError("regular")

    with raises(ValueError):
        with ok(RuntimeError):
            raise ValueError("regular - fail")

    try:
        with ok(RuntimeError):
            raise ValueError("in ok - fail")
    except Exception as e:
        assert isinstance(e, ValueError)
        assert e.args[0] == "in ok - fail"



# Generated at 2022-06-21 21:36:30.570828
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False



# Generated at 2022-06-21 21:36:35.438434
# Unit test for function ok
def test_ok():
    """Ensure that the ok context manager works."""
    with ok(ZeroDivisionError, ValueError):
        raise ZeroDivisionError("Division by zero")
    with pytest.raises(TypeError):
        with ok(ZeroDivisionError, ValueError):
            raise TypeError("Wrong type")



# Generated at 2022-06-21 21:36:41.938959
# Unit test for function ok
def test_ok():
    with ok():
        print("ok")
    with ok(TypeError):
        raise TypeError("not here")
    with ok(TypeError, KeyError):
        raise KeyError("not here")
    try:
        with ok(ValueError):
            raise TypeError("not here")
    except TypeError:
        pass
    with ok() as e:
        raise TypeError("not here")
    print(e.type)

# Generated at 2022-06-21 21:37:00.121817
# Unit test for function ok
def test_ok():
    """Test ok(__exception__) context manager."""
    assert ok(ZeroDivisionError) is not None



# Generated at 2022-06-21 21:37:12.635434
# Unit test for function ok
def test_ok():
    with pytest.raises(ZeroDivisionError):
        with ok():
            a = 1 / 0
    with ok(ZeroDivisionError):
        a = 1 / 0
    with ok(ZeroDivisionError, TypeError):
        a = 1 / 0
    with pytest.raises(TypeError):
        with ok(ZeroDivisionError):
            a = 'a' + 1
    with pytest.raises(TypeError):
        with ok(ZeroDivisionError, TypeError):
            a = 'a' + 1
    with ok(TypeError):
        a = 'a' + 1
    with ok(ZeroDivisionError):
        a = 1 / 1
        a = 'a' + 1
        a = 1 / 0
        a = 1 / 2



# Generated at 2022-06-21 21:37:14.493000
# Unit test for function ok
def test_ok():
    """Test function ok."""
    assert ok


if __name__ == "__main__":
    # Test functions.
    test_ok()

# Generated at 2022-06-21 21:37:20.412039
# Unit test for function ok
def test_ok():
    # Test no exception
    with ok(IndexError, IOError):
        pass
    # Test exception
    with ok(IndexError, IOError):
        raise ValueError
    # Test exception match
    with ok(ValueError):
        raise ValueError
    # Test exception not match
    try:
        with ok(ValueError):
            raise IOError
    except IOError as e:
        pass
    else:
        raise AssertionError('Test ok failed')

# Generated at 2022-06-21 21:37:22.346363
# Unit test for function ok
def test_ok():
    with ok():
        pass

    with ok(Exception):
        pass

    with ok(AssertionError):
        assert False

    with ok(Exception, AssertionError):
        raise IndexError

# Generated at 2022-06-21 21:37:29.753759
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    # Raise exception
    try:
        with ok():
            raise TypeError
        assert False  # Should not get here
    except Exception as e:
        assert isinstance(e, TypeError)

    # Raise exception
    try:
        with ok(ValueError):
            raise TypeError
        assert False  # Should not get here
    except Exception as e:
        assert isinstance(e, TypeError)

    # Raise exception
    try:
        with ok(ValueError, TypeError):
            raise KeyError
        assert False  # Should not get here
    except Exception as e:
        assert isinstance(e, KeyError)
        
    # Do not raise exception
    with ok(TypeError):
        assert True

    # Do not raise exception

# Generated at 2022-06-21 21:37:33.733184
# Unit test for function ok
def test_ok():
    with ok(Exception):
        pass

    with ok(Exception):
        raise Exception('Test Exception')

    with ok(ValueError):
        raise ValueError('Test ValueError')


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-21 21:37:39.049033
# Unit test for function ok
def test_ok():
    """Check if exceptions are passed."""
    with ok(FileNotFoundError):
        with open('test_non_existence_file.txt') as file:
            file.read()
    with pytest.raises(UnexpectedException):
        with ok(FileNotFoundError):
            raise UnexpectedException
    with ok(FileNotFoundError):
        pass



# Generated at 2022-06-21 21:37:43.420002
# Unit test for function ok
def test_ok():
    """Test ok() function.
    """
    with ok():
        pass
    with ok(ValueError):
        raise ValueError()
    with ok(TypeError, ValueError) as cm:
        raise TypeError()
    with ok(TypeError):
        raise ValueError()



# Generated at 2022-06-21 21:37:51.954583
# Unit test for function ok
def test_ok():
    """Tests for the ok context manager."""
    with ok(RuntimeError):
        pass
    try:
        with ok(TypeError):
            raise RuntimeError("_")
        assert False
    except RuntimeError:
        pass
    try:
        with ok(TypeError):
            raise ValueError("_")
        assert False
    except ValueError:
        pass
    try:
        with ok(TypeError, ValueError):
            raise ValueError("_")
        assert False
    except ValueError:
        pass
    with ok():
        raise ValueError("_")
    assert False



# Generated at 2022-06-21 21:38:29.153945
# Unit test for function ok
def test_ok():
    """Test context manager to pass exceptions."""
    with ok(TypeError):
        pass


# Test ============================================================
if __name__ == "__main__":
    import doctest

    doctest.testmod()
    doctest.testfile("ok_test.txt")

# Generated at 2022-06-21 21:38:34.617452
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        print("ValueError occurred")
        raise ValueError("This is ValueError")
    with ok(ValueError, TypeError):
        print("This is TypeError")
        raise TypeError("This is TypeError")
    with ok(ValueError):
        print("This is a NameError")
        raise NameError("This is a NameError")

# Generated at 2022-06-21 21:38:39.596473
# Unit test for function ok
def test_ok():
    """Unit test for the ok context manager."""
    with ok():
        pass
    with ok(TypeError):
        raise TypeError
    with raises(ValueError):
        with ok(TypeError):
            raise ValueError
    try:
        with ok(TypeError):
            raise IndexError
    except IndexError:
        pass
    else:
        raise Exception('IndexError not re-raised by ok')


__all__ = ['ok']

# Generated at 2022-06-21 21:38:41.526201
# Unit test for function ok
def test_ok():
    """Test for ok context manager."""
    with ok():
        pass
    with raises(ValueError):
        with ok(TypeError):
            raise ValueError



# Generated at 2022-06-21 21:38:43.348607
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0



# Generated at 2022-06-21 21:38:46.363543
# Unit test for function ok
def test_ok():
    a = 1
    with ok(Exception):
        a = 1 / 0


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-21 21:38:50.437982
# Unit test for function ok
def test_ok():
    # All exceptions pass
    with ok(KeyError, NameError):
        raise KeyError
    # Only targeted exception pass
    with ok(NameError):
        raise KeyError
    # Exception is raised
    with pytest.raises(KeyError):
        with ok(NameError):
            raise KeyError

# Generated at 2022-06-21 21:38:54.969307
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with ok():
        pass
    try:
        with ok(TypeError):
            raise ValueError
    except ValueError:
        pass
    else:
        raise AssertionError("no error raised")



# Generated at 2022-06-21 21:39:00.365943
# Unit test for function ok
def test_ok():
    """Test function ok in case_with.py."""
    with ok(ZeroDivisionError):
        1 / 0
    try:
        with ok(ZeroDivisionError):
            1 / 0
            1 / 1
            assert False
    except ZeroDivisionError:
        assert True
        pass
    except Exception as e:
        raise e


test_ok()

# Generated at 2022-06-21 21:39:06.583347
# Unit test for function ok
def test_ok():
    with ok():
        pass
    try:
        with ok([ValueError]):
            raise ValueError
    except ValueError:
        pass
    try:
        with ok([ValueError]):
            raise AttributeError
    except AttributeError:
        pass
    try:
        with ok():
            raise ValueError
    except ValueError:
        pass
    try:
        with ok():
            raise AttributeError
    except AttributeError:
        pass



# Generated at 2022-06-21 21:40:23.408532
# Unit test for function ok
def test_ok():
    with ok(IOError):
        raise IOError



# Generated at 2022-06-21 21:40:24.950361
# Unit test for function ok
def test_ok():
    try:
        with ok(ZeroDivisionError, TypeError):
            1 / 0
    except NameError:
        pass



# Generated at 2022-06-21 21:40:29.298227
# Unit test for function ok
def test_ok():
    """Test context manager ok."""
    x = 3

    with ok(ValueError):
        x = int('dog')

    # Assert that ValueError didn't pass
    assert x == 3

    with ok(ValueError, TypeError):
        x = int('dog')

    # Assert that TypeError did pass
    assert x == 0

    with ok(TypeError):
        x = int(3)

    # Assert that TypeError did pass
    assert x == 3

    try:
        raise Exception
    except:
        # Assert that it didn't pass
        pass



# Generated at 2022-06-21 21:40:32.076569
# Unit test for function ok
def test_ok():
    n = 0
    with ok(AttributeError):
        n += 1
        print('n =', n)
        raise AttributeError
    assert n == 1

# Generated at 2022-06-21 21:40:41.420493
# Unit test for function ok
def test_ok():
    """Test function ok."""
    try:
        with ok(ZeroDivisionError):
            1 / 0
    except ZeroDivisionError:
        assert True
    else:
        assert False

    try:
        with ok(ZeroDivisionError):
            int('a')
    except ValueError:
        assert True
    else:
        assert False

    with ok():
        int('a')

# Generated at 2022-06-21 21:40:43.756097
# Unit test for function ok
def test_ok():
    with ok():
        raise TypeError()
    with ok(TypeError):
        raise TypeError()
    with raises(ValueError):
        with ok(TypeError):
            raise ValueError()

# Generated at 2022-06-21 21:40:51.050416
# Unit test for function ok
def test_ok():
    # test function ok with normal exceptions
    try:
        raise ValueError('ValueError exception')
    except Exception as e:
        with ok(*[ZeroDivisionError, ValueError]):
            raise ValueError('ValueError exception')
        with pytest.raises(ValueError):
            raise e

    # test function ok with custom exception
    class MyException(BaseException):
        pass

    try:
        raise MyException('MyException exception')
    except Exception as e:
        with ok(*[ZeroDivisionError, ValueError]):
            raise MyException('MyException exception')
        with pytest.raises(MyException):
            raise e



# Generated at 2022-06-21 21:40:57.121192
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(TypeError):
        int('N/A')
    try:
        with ok(TypeError):
            raise ValueError
    except ValueError:
        print("ValueError")


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-21 21:41:04.808461
# Unit test for function ok
def test_ok():
    """Tests for function ok"""

    # Exceptions to pass
    exceptions = (IndexError, AttributeError)

    # Test ok context manager to pass exceptions
    try:
        with ok(*exceptions):
            raise IndexError
    except AttributeError:
        pass
    except IndexError:
        raise AssertionError("ok did not pass exception")

    # Test ok context manager to not pass exceptions
    # IndexError should not be passed as it is not in exceptions
    with raises(IndexError):
        with ok(*exceptions):
            raise IndexError


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-21 21:41:07.416718
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with raises(ValueError):
        with ok(ZeroDivisionError):
            1 / 0

