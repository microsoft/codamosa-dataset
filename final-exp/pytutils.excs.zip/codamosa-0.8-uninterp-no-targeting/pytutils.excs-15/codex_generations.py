

# Generated at 2022-06-21 21:33:47.304187
# Unit test for function ok
def test_ok():
    # Test for exceptions not raised
    with ok():
        print('No exceptions were raised')
    # Test for exceptions raised and ignored
    with ok(TypeError):
        print(1+'1')
    # Test for exceptions not passed
    with raises(ZeroDivisionError):
        with ok(TypeError):
            1 / 0


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-21 21:33:52.017132
# Unit test for function ok
def test_ok():
    """Test function ok by calling it with an exception."""
    with raises(Exception):
        print(1)
        with ok(ZeroDivisionError):
            print(2)
            raise NameError('HiThere')
        print(3)
    print(4)

# Generated at 2022-06-21 21:33:59.071536
# Unit test for function ok
def test_ok():
    with ok(AttributeError, ValueError):
        "foo".encode
    with ok(AttributeError, ValueError):
        "foo".encode(encoding='UTF-8')
    with ok(AttributeError, ValueError):
        int('string')
    with ok(AttributeError, ValueError):
        int(0x13)
    try:
        with ok(AttributeError, ValueError):
            int('string', base=0x13)
    except Exception:
        pass
    else:
        raise AssertionError('should raise exception')



# Generated at 2022-06-21 21:34:00.791143
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False
    print("ok() test passed")



# Generated at 2022-06-21 21:34:03.775876
# Unit test for function ok
def test_ok():
    # Test with ok
    with ok(TypeError):
        x = 1 + 'a'

    # Test without ok
    with assert_raises(TypeError):
        with ok(RuntimeError):
            x = 1 + 'a'



# Generated at 2022-06-21 21:34:08.055337
# Unit test for function ok
def test_ok():
    """Test for ok contextmanager."""
    with ok(TypeError):
        assert int('2') == 2
    with ok(OSError):
        raise OSError
    with pytest.raises(ZeroDivisionError):
        with ok(TypeError):
            assert int('2') == 2
        with ok(OSError):
            raise OSError



# Generated at 2022-06-21 21:34:12.872165
# Unit test for function ok
def test_ok():
    with ok(NameError):
        print(x)

    with ok(ZeroDivisionError, IndexError):
        a = 1/0
        print(a[4])


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-21 21:34:16.901909
# Unit test for function ok
def test_ok():
    with ok(Exception):
        print('ok')
    with ok(FileNotFoundError):
        raise FileNotFoundError
    with raises(Exception):
        with ok():
            raise Exception('Not OK!')


if __name__ == "__main__":
    test_ok()
    print('OK')

# Generated at 2022-06-21 21:34:26.489740
# Unit test for function ok
def test_ok():
    """Test the context manager ok"""
    with ok(ZeroDivisionError):
        1/0
    with ok(ZeroDivisionError, TypeError):
        1/0
    with ok(ZeroDivisionError, TypeError):
        int("a")
    with ok(ZeroDivisionError, TypeError):
        raise IndexError
    with ok(ZeroDivisionError, TypeError):
        1/0
        int("a")
    with ok(ZeroDivisionError, TypeError):
        1/1
    with ok(ZeroDivisionError):
        1/1
        int("a")


if __name__ == '__main__':
    # Unit test
    test_ok()

# Generated at 2022-06-21 21:34:35.513657
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int("Hello")


import unittest
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import ElementNotVisibleException
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.support.select import Select
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup



# Generated at 2022-06-21 21:34:41.267547
# Unit test for function ok

# Generated at 2022-06-21 21:34:43.277151
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-21 21:34:48.433412
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        x = 1 / 0
    with ok(ZeroDivisionError, NameError):
        x = 1 / 0
    with ok(NameError):
        1 / 0

# Generated at 2022-06-21 21:34:59.291309
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
        raise ValueError
    with ok(TypeError, ZeroDivisionError):
        1 / 0

# Alternative implementation of the contextmanager:
#   try ... except ... else ...
#
# @contextmanager
# def ok(*exceptions):
#     try:
#         yield
#     except Exception as e:
#         if isinstance(e, exceptions):
#             pass
#         else:
#             raise e
#     else:
#         pass
#
#
# # Unit test for function ok
# def test_ok():
#     with ok(ValueError):
#         int('N/A')
#         raise ValueError
#     with ok(TypeError, ZeroDivisionError):
#         1 / 0

# Generated at 2022-06-21 21:35:04.388516
# Unit test for function ok
def test_ok():
    """Test for the context manager ok."""
    with ok(ValueError):
        int('N/A')
    try:
        with ok(TypeError):
            int('N/A')
        assert False, 'Failed to raise an error'
    except ValueError:
        pass



# Generated at 2022-06-21 21:35:07.264613
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with pytest.raises(ValueError):
        with ok(TypeError) as e:
            raise ValueError



# Generated at 2022-06-21 21:35:10.855662
# Unit test for function ok
def test_ok():
    with ok(TypeError, ValueError):
        raise TypeError
    with ok(TypeError, ValueError):
        raise ValueError
    with ok(TypeError, ValueError):
        raise Exception
    with ok(TypeError, ValueError):
        raise "Exception"

# Generated at 2022-06-21 21:35:16.150284
# Unit test for function ok
def test_ok():
    try:
        with ok(ValueError, TypeError):
            raise TypeError

        with ok(ValueError, TypeError):
            raise ValueError

        with ok(ValueError, TypeError):
            raise Exception
    except Exception as e:
        print(e)

# Generated at 2022-06-21 21:35:18.740598
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(TypeError):
        1 + '1'

    with raises(ZeroDivisionError):
        1 / 0



# Generated at 2022-06-21 21:35:20.541733
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')

    with ok(TypeError):
        int('N/A')

# Generated at 2022-06-21 21:35:32.628723
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        pass

    with ok(TypeError, ZeroDivisionError):
        pass

    with ok(ZeroDivisionError, TypeError):
        pass

    with ok(ZeroDivisionError, TypeError):
        pass

    with ok():
        raise TypeError

    try:
        with ok(ZeroDivisionError):
            raise TypeError
    except TypeError:
        pass

    try:
        with ok():
            raise TypeError
    except TypeError:
        pass

    with ok():
        raise StopIteration


# Generated at 2022-06-21 21:35:35.834372
# Unit test for function ok
def test_ok():
    """Test function ok.
    """
    with ok(FileNotFoundError):
        raise FileNotFoundError
    with raises(ValueError):
        with ok(FileNotFoundError):
            raise ValueError



# Generated at 2022-06-21 21:35:44.710865
# Unit test for function ok
def test_ok():
    # You can handle the exception
    try:
        with ok(AssertionError):
            assert False
        print("AssertionError handled")
    except AssertionError:
        pass
    # You can't handle the exception
    try:
        with ok(AssertionError):
            raise TypeError
    except TypeError:
        print("Exception TypeError passed")
    # You can't handle the exception because you haven't passed it
    try:
        with ok(AssertionError):
            pass
    except AssertionError:
        print("AssertionError didn't passed")
    print('Test ok: passed')



# Generated at 2022-06-21 21:35:48.932648
# Unit test for function ok
def test_ok():
    """Test for ok() context manager."""
    with pytest.raises(TypeError):
        with ok(TypeError):
            raise ValueError()



# Generated at 2022-06-21 21:35:51.338993
# Unit test for function ok
def test_ok():
    """This function tests the context manager ok.
    """
    with ok(ZeroDivisionError):
        1 / 0
    with ok(ZeroDivisionError):
        raise Exception()



# Generated at 2022-06-21 21:35:56.964995
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1/0

    with pytest.raises(NameError):
        with ok(ZeroDivisionError):
            1/0
            raise NameError

    with ok(NameError):
        raise NameError

    with pytest.raises(ZeroDivisionError):
        with ok(NameError):
            1/0



# Generated at 2022-06-21 21:35:59.999054
# Unit test for function ok
def test_ok():
    """Test method for ok context manager."""
    def do_stuff():
        """Function that causes exceptions."""
        i = 1
        just_zeroth(i)
        with ok(ZeroDivisionError):
            i / 0
        return i

    assert_(do_stuff() == 1)



# Generated at 2022-06-21 21:36:05.024905
# Unit test for function ok

# Generated at 2022-06-21 21:36:13.638640
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""

    @ok(ValueError)
    def bad_value():
        raise ValueError('')

    @ok(TypeError)
    def bad_type():
        raise TypeError('')

    @ok()
    def bad_base():
        raise BaseException()

    expected = 'IndexError'
    try:
        @ok(ValueError)
        def bad_index():
            raise IndexError('')
    except IndexError:
        actual = 'IndexError'
    else:
        actual = 'No IndexError'
    assert actual == expected

    expected = 'ValueError'
    try:
        bad_value()
    except ValueError:
        actual = 'ValueError'
    else:
        actual = 'No ValueError'
    assert actual == expected

    expected = 'TypeError'

# Generated at 2022-06-21 21:36:22.990447
# Unit test for function ok
def test_ok():
    with ok():
        raise Exception()
    with raises(Exception):
        with ok(ZeroDivisionError):
            raise Exception()
    with ok(Exception):
        raise Exception()
    with ok(ZeroDivisionError, Exception):
        raise Exception()
    with ok(Exception):
        raise Exception()
    with ok(Exception):
        raise Exception()
    with ok(ZeroDivisionError, Exception):
        raise Exception()
    with ok(Exception):
        raise Exception()
    with ok(ZeroDivisionError, Exception):
        raise Exception()
    with ok(ZeroDivisionError, NameError):
        raise ZeroDivisionError()
    with ok(ZeroDivisionError, NameError):
        raise NameError()
    with raises(Exception):
        with ok(ZeroDivisionError, NameError):
            raise Exception()


# Unit

# Generated at 2022-06-21 21:36:36.902253
# Unit test for function ok
def test_ok():
    """Test ok function."""
    # Test passing exception when not passing any exception
    with pytest.raises(ValueError):
        with ok():
            raise ValueError

    # Test passing exception when passing an exception
    with ok(NameError):
        raise NameError

    # Test not passing exception when passing the wrong exception
    with pytest.raises(NameError):
        with ok(ValueError):
            raise NameError



# Generated at 2022-06-21 21:36:39.720181
# Unit test for function ok
def test_ok():
    with ok(TypeError, IndexError, NameError):
        pass
    with ok():
        raise TypeError



# Generated at 2022-06-21 21:36:40.800851
# Unit test for function ok
def test_ok():
    assert ok()



# Generated at 2022-06-21 21:36:43.331092
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        raise TypeError()
    with ok(TypeError):
        raise TypeError('This must be handled.')
    with raises(ValueError):
        with ok(TypeError):
            raise ValueError('This must not be handled.')


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-21 21:36:48.855574
# Unit test for function ok
def test_ok():
    """Test for function ok"""
    try:
        with ok(TypeError):
            2 + 'a'
    except TypeError:
        pass
    else:
        raise Exception('ok failed')

    try:
        with ok(TypeError, ZeroDivisionError):
            2 / 0
    except ZeroDivisionError:
        pass
    else:
        raise Exception('ok failed')

    try:
        with ok(TypeError, ZeroDivisionError):
            raise ValueError
    except ValueError:
        pass
    else:
        raise Exception('ok failed')


# Unit test

# Generated at 2022-06-21 21:36:51.985015
# Unit test for function ok
def test_ok():
    """Test ok() context manager."""
    with ok(ValueError, IndexError):
        print(1/0)
    try:
        with ok(ValueError, IndexError):
            raise TypeError()
    except TypeError as e:
        print(e)


test_ok()

# Generated at 2022-06-21 21:36:54.157360
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError



# Generated at 2022-06-21 21:36:55.789750
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        with ok(ValueError):
            raise TypeError
    assert True



# Generated at 2022-06-21 21:36:57.364076
# Unit test for function ok
def test_ok():
    """Test function ok."""
    assert ok(AssertionError)



# Generated at 2022-06-21 21:36:59.400252
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise ValueError("Pass")
    with ok(FileNotFoundError):
        raise ValueError("Fail")

# Generated at 2022-06-21 21:37:19.750313
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        [1, 2, 3]['a']
    with ok(IndexError):
        [1, 2][2]
    with pytest.raises(ValueError):
        with ok(TypeError):
            1 + '2'



# Generated at 2022-06-21 21:37:22.019110
# Unit test for function ok
def test_ok():
    with ok(IndexError):
        lst = [1, 2, 3]
        print(lst[6])


# example how to use with ok()

# Generated at 2022-06-21 21:37:24.493560
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        pass
    # the next line should rise an exception
    with ok(ZeroDivisionError):
        1 / 0



# Generated at 2022-06-21 21:37:29.448013
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        1 + '1'
    with ok(TypeError, ValueError):
        int('1e')

    with pytest.raises(ZeroDivisionError):
        with ok(TypeError):
            1 / 0

    with pytest.raises(TypeError):
        with ok(ValueError):
            int('1e')



# Generated at 2022-06-21 21:37:37.938088
# Unit test for function ok
def test_ok():
    """Test context manager ok()
    """
    with ok(ValueError):
        raise ValueError()
    with ok(TypeError):
        raise TypeError()
    with pytest.raises(ValueError):
        with ok(TypeError):
            raise ValueError()
    with pytest.raises(TypeError):
        with ok(ValueError):
            raise TypeError()
    # Multiple exceptions to be passed as a tuple
    with pytest.raises(TypeError):
        with ok((ValueError, ArithmeticError)):
            raise TypeError()


# A sample test case

# Generated at 2022-06-21 21:37:40.227964
# Unit test for function ok
def test_ok():
    try:
        raise Exception
    except Exception as e:
        with ok(Exception):
            raise e


# Define function round_sig

# Generated at 2022-06-21 21:37:45.105656
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        pass
    with ok(Exception, Exception):
        raise Exception
    with ok(TypeError, TypeError):
        pass


if __name__ == '__main__':
    test_ok()
    print('Test passed')

# Generated at 2022-06-21 21:37:50.340267
# Unit test for function ok
def test_ok():
    with ok(TypeError):  # TypeError will be passed (do nothing)
        assert sum([1, 2]) == 3
    with ok(TypeError):  # TypeError will be passed (do nothing)
        assert sum([1], [2]) == 3
    with ok(TypeError):  # AssertionError will be raised
        assert sum([1], [2]) == 4


# Function to make directory if necessary

# Generated at 2022-06-21 21:37:54.377936
# Unit test for function ok
def test_ok():
    "Unit test for function ok."
    with ok(TypeError):
        int('hello')
        # this should not raise an exception
    with ok(TypeError, ValueError):
        int('hello')
        # this should not raise an exception
    with raises(AttributeError):
        [].get
        # this should raise an exception

# Generated at 2022-06-21 21:37:56.269182
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        7 / 0



# Generated at 2022-06-21 21:38:37.057375
# Unit test for function ok
def test_ok():
    """Test for the ok context manager."""
    try:
        with ok(TypeError):
            raise ValueError('Value error.')
    except ValueError as e:
        assert e.message == 'Value error.'
    else:
        assert False, 'Didn\'t pass exception.'
    with ok(TypeError):
        pass



# Generated at 2022-06-21 21:38:38.906639
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')

    with ok(TypeError):
        int('123')



# Generated at 2022-06-21 21:38:41.999160
# Unit test for function ok
def test_ok():
    """Unit test for function ok.
    """
    try:
        with ok(TypeError):
            int('hello, world!')
    except ValueError:
        print('ValueError')
    else:
        print('Passed.')


# Execute function test_ok
test_ok()

# Generated at 2022-06-21 21:38:43.924120
# Unit test for function ok
def test_ok():
    assert ok(TypeError) is not None



# Generated at 2022-06-21 21:38:48.603869
# Unit test for function ok
def test_ok():
    """Tests the function ok."""
    a = 1
    b = 0

    with ok(ZeroDivisionError):
        a / b
    with pytest.raises(NameError):
        b / a



# Generated at 2022-06-21 21:38:52.019766
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with ok(TypeError):
        a = 4 + 's'
    try:
        with ok(TypeError):
            a = 4 + 5
    except TypeError:
        pass
    else:
        raise Exception("Test failed")


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-21 21:39:03.546476
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError, IndexError):
        1 / 0
        a = [0]
        a[1]
    with ok(ZeroDivisionError, IndexError):
        1 / 0
        a = [0]
        a[1]
    with ok(ZeroDivisionError, IndexError):
        1 / 0
        a = [0]
        a[1]
    with ok(ZeroDivisionError):
        1 / 0
    with ok(IndexError):
        a = [0]
        a[1]
    with ok(Exception):
        1 / 0
        a = [0]
        a[1]
    with ok(TypeError):
        1 + 'a'
    with ok(AttributeError):
        None.a
    with ok(ZeroDivisionError):
        1 / 0

# Generated at 2022-06-21 21:39:08.905502
# Unit test for function ok
def test_ok():
    """Test context manager ok."""

# Generated at 2022-06-21 21:39:12.785405
# Unit test for function ok
def test_ok():
    with ok(RuntimeError, TypeError):
        raise TypeError()
    with ok(RuntimeError, TypeError):
        raise RuntimeError()
    with pytest.raises(RuntimeError):
        with ok(RuntimeError, TypeError):
            raise IndexError()



# Generated at 2022-06-21 21:39:19.294276
# Unit test for function ok
def test_ok():
    """Function to test function ok.
    """
    from pyquickhelper.pycode import assert_raises
    try:
        with ok(ValueError):
            raise ValueError
    except Exception:
        raise AssertionError("this should not happened")
    try:
        with ok(ValueError, KeyboardInterrupt):
            raise ValueError
    except Exception:
        raise AssertionError("this should not happened")
    assert_raises(RuntimeError, lambda: with_ok(ValueError, KeyboardInterrupt)(lambda: raise_exc(RuntimeError)))



# Generated at 2022-06-21 21:40:43.836288
# Unit test for function ok
def test_ok():
    with pytest.raises(KeyError):
        with ok(ValueError, TypeError):
            raise KeyError
    with pytest.raises(KeyError):
        with ok(ValueError, TypeError):
            raise KeyError('example')
    with pytest.raises(KeyError):
        with ok():
            raise KeyError('example')



# Generated at 2022-06-21 21:40:47.034277
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    print('Test ok')
    logging.info('Test ok')
    with ok(TypeError, ValueError):
        pass
    logging.info('')



# Generated at 2022-06-21 21:40:51.778438
# Unit test for function ok
def test_ok():
    """Test if the context manager behaves as expected."""

    class CustomException(Exception):
        """Custom exception"""

    pass_ex = (Exception, CustomException)

    with ok(*pass_ex):
        raise Exception('Failed intentionally')

    with ok():
        pass

    try:
        with ok(Exception):
            raise CustomException('Failed intentionally')
    except CustomException:
        pass
    else:
        assert False, 'Should not come here'



# Generated at 2022-06-21 21:40:56.836141
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception()

    with ok(TypeError):
        raise TypeError()

    with ok((TypeError, ValueError)):
        raise TypeError()

    with ok((TypeError, ValueError)):
        raise ValueError()

    with ok(ZeroDivisionError):
        1 / 0

# Generated at 2022-06-21 21:41:01.579663
# Unit test for function ok
def test_ok():
    with ok():
        pass
    with ok(RuntimeError):
        print(1 / 0)
    with ok(NameError, RuntimeError):
        print(a)
    with ok(Exception):
        pass
    with pytest.raises(NameError):
        with ok(IndexError):
            print(a)



# Generated at 2022-06-21 21:41:11.939541
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    assert False, "Test failed"

# Generated at 2022-06-21 21:41:14.143064
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError("ok!")
    with ok(TypeError):
        raise ValueError("not ok!")


# Cache singleton

# Generated at 2022-06-21 21:41:19.070939
# Unit test for function ok
def test_ok():
    # Check for wrong exception
    with pytest.raises(ValueError) as e:
        with ok(ZeroDivisionError):
            raise ValueError
    assert 'ValueError' in str(e)

    # Check for correct exception
    with ok(ZeroDivisionError):
        raise ZeroDivisionError

    # Check for multiple correct exception
    with ok(ZeroDivisionError, ValueError, TypeError):
        raise ZeroDivisionError

    with ok(ZeroDivisionError, ValueError, TypeError):
        raise ValueError

    with ok(ZeroDivisionError, ValueError, TypeError):
        raise TypeError

# Generated at 2022-06-21 21:41:21.708436
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int('N/A')



# Generated at 2022-06-21 21:41:23.648020
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        1 + '1'