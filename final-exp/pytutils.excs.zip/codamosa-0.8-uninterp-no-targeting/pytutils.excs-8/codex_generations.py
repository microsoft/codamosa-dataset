

# Generated at 2022-06-21 21:33:50.092793
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""

    with ok(TypeError):
        print(1 + 'a')

    with ok(TypeError):
        raise IndexError



# Generated at 2022-06-21 21:33:56.557654
# Unit test for function ok
def test_ok():

        with ok(ZeroDivisionError, FileNotFoundError):
            print(1 / 0)

        try:
            with ok(ZeroDivisionError, FileNotFoundError):
                print(1 / 0)
        except FileNotFoundError as e:
            assert type(e) is not FileNotFoundError

        try:
            with ok(ZeroDivisionError):
                raise IOError
        except ZeroDivisionError as e:
            assert type(e) is not ZeroDivisionError



# Generated at 2022-06-21 21:34:01.146762
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False

    with ok(AssertionError):
        assert False

    with pytest.raises(ZeroDivisionError):
        with ok(AssertionError):
            1 / 0



# Generated at 2022-06-21 21:34:06.950615
# Unit test for function ok
def test_ok():
    """Tests the ok function."""
    with ok(ValueError):
        raise ValueError()

    with ok(RuntimeError):
        with ok(ValueError):
            raise ValueError()

    with raises(ValueError) as ex:
        with ok():
            raise ValueError()
    assert ex.value.args == ()

    with ok(TypeError):
        raise TypeError(ValueError())

    with raises(TypeError) as ex:
        with ok(ValueError):
            raise TypeError(ValueError())

    assert isinstance(ex.value.args[0], ValueError)



# Generated at 2022-06-21 21:34:12.709089
# Unit test for function ok
def test_ok():
    """ Test function ok
    """
    # Test : raise exceptions
    with pytest.raises(IndexError):
        with ok(TypeError):
            raise IndexError('bla')
    # Test : No exception
    with ok(IndexError):
        pass
    # Test : Multiple exceptions
    with pytest.raises(IndexError):
        with ok(TypeError, IndexError):
            raise IndexError('bla')
    # Test : No multiple exceptions
    with pytest.raises(IndexError):
        with ok(TypeError, KeyError):
            raise IndexError('bla')

# Generated at 2022-06-21 21:34:14.073975
# Unit test for function ok
def test_ok():
    with ok(IOError):
        raise IOError("Some error")



# Generated at 2022-06-21 21:34:20.143103
# Unit test for function ok

# Generated at 2022-06-21 21:34:22.647004
# Unit test for function ok
def test_ok():
    """Test for ok context manager."""
    with ok(IOError):
        raise IOError

    with ok(IOError):
        raise IndexError



# Generated at 2022-06-21 21:34:30.313623
# Unit test for function ok
def test_ok():
    """Test docstring of ok."""
    from random import choice
    from string import ascii_letters
    from contextlib import ExitStack

    with ExitStack() as stack:
        for i in range(1, 5):
            stack.callback(print, 'test', i)
        stack.callback(print, 'test')
        with ok(IndexError):
            a = choice(ascii_letters)
            print(a)
            print(a[i])


if __name__ == '__main__':
    # Unit test for function ok
    test_ok()

# Generated at 2022-06-21 21:34:35.879321
# Unit test for function ok
def test_ok():
    pass_exception_list = ['test1', 'test2', 'test3']
    name_list = ['test1', 'test2', 'test4']
    with ok(*pass_exception_list):
        for name in name_list:
            if name not in pass_exception_list:
                raise Exception(name)

        raise Exception('test3')


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-21 21:34:40.470992
# Unit test for function ok
def test_ok():

    with ok(ZeroDivisionError):
        1/0

    with ok(ZeroDivisionError):
        1/1
    return True

# Generated at 2022-06-21 21:34:44.157193
# Unit test for function ok

# Generated at 2022-06-21 21:34:48.922125
# Unit test for function ok
def test_ok():
    # Test context manager with no exceptions
    with ok():
        pass

    # Test context manager with exceptions
    with pytest.raises(ValueError):
        with ok(TypeError):
            raise ValueError



# Generated at 2022-06-21 21:34:51.174457
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0



# Generated at 2022-06-21 21:34:54.363914
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int("a")
    with ok(TypeError):
        int(1)
    with ok():
        int("a")


ask = input


# Generated at 2022-06-21 21:34:58.172487
# Unit test for function ok
def test_ok():
    with ok(KeyError):
        raise KeyError
    with ok(ValueError):
        raise ValueError
    with ok(TypeError):
        raise TypeError
    with ok(KeyError, ValueError, TypeError):
        raise TypeError



# Generated at 2022-06-21 21:34:59.842372
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        1 / 0



# Generated at 2022-06-21 21:35:03.385855
# Unit test for function ok
def test_ok():
    """Test that ok works."""
    with ok(ValueError):
        int("1")
    with ok(ValueError, TypeError):
        int("1")
        int(1)



# Generated at 2022-06-21 21:35:06.588189
# Unit test for function ok
def test_ok():
    """Test for ok function"""
    with ok(ValueError):
        raise ValueError
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError
    with ok(TypeError, ValueError):
        raise ValueError



# Generated at 2022-06-21 21:35:10.673869
# Unit test for function ok
def test_ok():
    """Test function ok"""
    class MyException(Exception):
        """Custom exception class."""
        pass
    with ok(MyException):
        raise MyException
    with ok(MyException):
        raise IndexError

if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-21 21:35:14.389506
# Unit test for function ok
def test_ok():
    with ok(OSError):
        os.chdir("/thisdirectorydoesnotexist")



# Generated at 2022-06-21 21:35:19.284277
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception
    try:
        with ok(KeyError):
            raise Exception
    except Exception:
        pass
    else:
        assert False, 'Incorrect exception was raised'

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 21:35:22.676815
# Unit test for function ok
def test_ok():
    with ok(AttributeError):
        setattr(int, 'new_attribute', 'test')


test_ok()

# Generated at 2022-06-21 21:35:26.679618
# Unit test for function ok
def test_ok():

    # Test for normal operations without exception
    with ok(Exception):
        1 + 1

    # Test for raising exceptions
    with pytest.raises(TypeError):
        with ok(Exception):
            raise TypeError

# Generated at 2022-06-21 21:35:30.821254
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception()

    with ok(Exception):
        pass

    with pytest.raises(ZeroDivisionError) as e:
        with ok(Exception):
            1 / 0
    assert isinstance(e, ZeroDivisionError)



# Generated at 2022-06-21 21:35:34.199022
# Unit test for function ok
def test_ok():
    with ok(OSError, SystemError):  # exceptions passed
        pass
    with ok(OSError, SystemError):
        raise OSError

# Generated at 2022-06-21 21:35:35.914819
# Unit test for function ok
def test_ok():
    a = 10
    with ok():
        a = 1 / 0
    assert a == 10



# Generated at 2022-06-21 21:35:39.189929
# Unit test for function ok
def test_ok():
    with pytest.raises(ValueError):
        with ok(TypeError, IndexError):
            raise ValueError
    with ok(TypeError, IndexError):
        pass



# Generated at 2022-06-21 21:35:42.442189
# Unit test for function ok
def test_ok():
    with ok():
        raise ValueError()
    with ok(ValueError):
        raise ValueError()
    with ok(TypeError):
        raise ValueError()


# Generated at 2022-06-21 21:35:46.015357
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1/0
    with ok(OSError):
        raise OSError
    with ok(ZeroDivisionError):
        raise OSError
    with ok(ZeroDivisionError):
        1/0


# Utility Functions
# ----------------

# Generated at 2022-06-21 21:35:54.963530
# Unit test for function ok
def test_ok():
    """Test for function ok."""
    with ok(ValueError):
        a = 1
        b = 2
        a / (1-b)

    try:
        with ok(ValueError):
            a = 1
            b = 2
            a / b
    except Exception as e:
        assert isinstance(e, ZeroDivisionError)


# ----------------------------------------------------------------------------
# http://code.activestate.com/recipes/576980/
# ----------------------------------------------------------------------------
# Utility functions

# Generated at 2022-06-21 21:35:59.159883
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        pass

    with ok((TypeError, ValueError)):
        raise ValueError

    with ok((TypeError, ValueError)):
        raise TypeError

    with pytest.raises(ZeroDivisionError):
        with ok((TypeError, ValueError)):
            raise ZeroDivisionError



# Generated at 2022-06-21 21:36:06.969659
# Unit test for function ok
def test_ok():
    """Test for function ok"""
    try:
        with ok(TypeError):
            int("string")
            assert False
    except ValueError:
        assert True
    else:
        assert False

    try:
        with ok(TypeError):
            int([])
            assert False
    except TypeError:
        assert True
    else:
        assert False

    try:
        with ok(TypeError):
            int("string")
            assert False
    except ValueError:
        assert True
    else:
        assert False



# Generated at 2022-06-21 21:36:11.790677
# Unit test for function ok
def test_ok():
    """Code for unit test for function ok."""
    with ok(Exception):
        assert ok(Exception)
    with ok(Exception):
        raise Exception
        assert False
    try:
        with ok(ValueError):
            raise Exception
        assert False
    except Exception:
        pass

    try:
        with ok(ValueError):
            raise ValueError
        assert True
    except Exception:
        assert False

# Generated at 2022-06-21 21:36:15.709564
# Unit test for function ok
def test_ok():
    with ok(Exception):
        assert 1, "OK"

    with pytest.raises(ZeroDivisionError):
        with ok(AssertionError, TypeError):
            assert 1, "OK"



# Generated at 2022-06-21 21:36:19.638292
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with ok(ValueError):
        raise ValueError()
    try:
        with ok(ValueError):
            raise TypeError()
    except TypeError:
        pass
    else:
        raise AssertionError("Byte should raise TypeError")



# Generated at 2022-06-21 21:36:24.801952
# Unit test for function ok
def test_ok():
    import io
    import os
    import pytest

    # Output exceptions
    with io.StringIO() as buf, redirect_stderr(buf):
        with ok(TypeError):
            raise Exception('hello')
        with ok(TypeError):
            raise TypeError('hello')
        with pytest.raises(Exception):
            with ok(TypeError):
                raise IndexError('hello')
                raise KeyError('hello')
                raise ValueError('hello')
        assert str(buf.getvalue()).strip() == 'hello'

    # Remove session file
    os.remove(SESSION_FILE)



# Generated at 2022-06-21 21:36:27.330449
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0


# tmpdir pytest fixture allows to create a temporary directory inside a test

# Generated at 2022-06-21 21:36:34.313340
# Unit test for function ok
def test_ok():
    """Test function ok context manager"""
    a = 2
    b = 0
    with ok(ZeroDivisionError):
        a = a/b
    assert a == 2
    a = 2
    bad = False
    try:
        with ok(ZeroDivisionError):
            a = a/b
            raise TypeError
    except TypeError:
        bad = True
    assert bad


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-21 21:36:36.550591
# Unit test for function ok
def test_ok():
    """Test for function ok."""
    assert ok()



# Generated at 2022-06-21 21:36:51.416940
# Unit test for function ok
def test_ok():
    try:
        1 / 0
    except ZeroDivisionError:
        pass

    with ok(ZeroDivisionError):
        1 / 0

    with ok(TypeError, ZeroDivisionError):
        1 / 0

    with ok(TypeError, ValueError, ZeroDivisionError):
        1 / 0

    try:
        with ok(TypeError, ValueError):
            1 / 0
    except ZeroDivisionError:
        pass

    try:
        with ok(TypeError, ValueError, ZeroDivisionError):
            raise KeyError
    except KeyError:
        pass

    try:
        with ok(TypeError):
            raise KeyError
    except KeyError:
        pass


try:
    test_ok()
except AssertionError:
    print("AssertionError in ok() tests")

# Generated at 2022-06-21 21:36:58.968029
# Unit test for function ok
def test_ok():
    """Test the ok context manager."""
    try:
        with ok(ZeroDivisionError, AssertionError):
            1 / 0
    except ZeroDivisionError:
        pass
    try:
        with ok(ZeroDivisionError, AssertionError):
            assert 0
    except AssertionError:
        pass
    try:
        with ok(ZeroDivisionError, AssertionError):
            raise ValueError
    except ValueError:
        pass
    assert isinstance(ValueError, type)



# Generated at 2022-06-21 21:37:02.935076
# Unit test for function ok
def test_ok():
    with ok(TypeError, ValueError):
        f = open('file.txt')
    with ok(TypeError):
        raise TypeError()
    with raises(AttributeError):
        with ok(TypeError):
            raise AttributeError()



# Generated at 2022-06-21 21:37:11.477186
# Unit test for function ok
def test_ok():
    """Test function ok"""
    with ok(TypeError):
        print(1 + '1')
    try:
        with ok(TypeError):
            print(1 + 2)
    except TypeError:
        pass
    else:
        raise Exception


# Main
if __name__ == '__main__':
    # Unit test
    test_ok()

    # Print author information
    print('Author: Hiram')
    print('Email: hram.pitt@gmail.com')

# Generated at 2022-06-21 21:37:14.021860
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError, ValueError):
        1.0 / 0.0
    with raises(TypeError):
        with ok(ZeroDivisionError, ValueError):
            0 / 0



# Generated at 2022-06-21 21:37:18.109513
# Unit test for function ok
def test_ok():
    """Test function ok."""

# Generated at 2022-06-21 21:37:22.134982
# Unit test for function ok
def test_ok():
    # Test with no exception
    with ok():
        pass
    # Test with valid exception
    with ok(ValueError):
        raise ValueError
    # Test with invalid exception
    with pytest.raises(TypeError, match=r".*not caught.*"):
        with ok(ValueError):
            raise TypeError



# Generated at 2022-06-21 21:37:24.575372
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        x = int('hello')
    print(x)

    with ok(TypeError, ValueError):
        y = int('hello')



# Generated at 2022-06-21 21:37:26.163982
# Unit test for function ok
def test_ok():
    with ok(IndexError):
        list()[1] == 2


# Task 1.18

# Generated at 2022-06-21 21:37:31.567559
# Unit test for function ok
def test_ok():
    ok_context = None
    try:
        with ok(ValueError):
            # this block will not raise Exception,
            # and also will not raise an error in "finally" clause
            raise ValueError('We expect this')
    except ValueError:
        # we should get the exception
        ok_context = True
    assert(ok_context)



# Generated at 2022-06-21 21:37:54.059421
# Unit test for function ok
def test_ok():
    with ok():
        pass

    with ok(ValueError, TypeError):
        pass

    with ok(ValueError, TypeError):
        raise ValueError

    def should_raise_exception():
        with ok(ValueError, TypeError):
            1 / 0

    assert_raises(ZeroDivisionError, should_raise_exception)

# Generated at 2022-06-21 21:38:01.463750
# Unit test for function ok
def test_ok():
    """Test for ok context manager."""
    def _test(e):
        with ok(ValueError):
            raise e
        with ok(ValueError):
            pass
        with ok():
            pass
        with ok(ValueError):
            raise TypeError()
    _test(ValueError())  # test ValueError
    _test(TypeError())  # test TypeError


# Code here

# Generated at 2022-06-21 21:38:03.278684
# Unit test for function ok
def test_ok():
    with ok(IndexError):
        l = []
        i = l[0]



# Generated at 2022-06-21 21:38:06.858635
# Unit test for function ok
def test_ok():
    pass_exceptions = (KeyError,)
    random_exceptions = (ValueError,)
    assert ok(pass_exceptions)
    assert not ok(random_exceptions)


# Problem 5
from contextlib import contextmanager



# Generated at 2022-06-21 21:38:12.302188
# Unit test for function ok
def test_ok():
    with ok():
        raise TypeError

    with ok(NameError):
        raise NameError

    with raises(TypeError):
        with ok(NameError):
            raise TypeError

    with ok(NameError, TypeError):
        raise TypeError

    with raises(TypeError):
        with ok(NameError):
            raise TypeError

# Generated at 2022-06-21 21:38:19.630463
# Unit test for function ok
def test_ok():
    """Unit Test for function ok"""
    with ok(Exception):
        pass
    with ok(Exception, NameError):
        pass
    with ok(Exception, ArithmeticError):
        pass
    with ok(ZeroDivisionError):
        pass
    with ok(ZeroDivisionError, IndexError):
        pass



# Generated at 2022-06-21 21:38:23.016795
# Unit test for function ok
def test_ok():
    """Function to test function ok"""
    with ok(AssertionError):
        assert False
    with raises(ZeroDivisionError):
        with ok(AssertionError):
            1 / 0

# Generated at 2022-06-21 21:38:29.676879
# Unit test for function ok
def test_ok():
    """Test for function ok"""
    with ok():
        raise StopIteration()

    with ok(ValueError):
        raise ValueError()

    with ok(StopIteration, ValueError):
        raise ValueError()

    with ok(StopIteration, ValueError):
        raise StopIteration()

    try:
        with ok(StopIteration):
            raise ValueError()
    except ValueError:
        pass
    else:
        print("exception not raised")


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-21 21:38:36.760992
# Unit test for function ok
def test_ok():
    """Function which tests ok function."""
    s = "this is a string"
    with ok(TypeError, ValueError):
        i = int(s)
    print(i)
    # the following will raise error, because it is not a TypeError
    with ok(TypeError):
        i = int(s)
    print(i)


# ---------------------------------------------------------------------
# ---------------------------------------------------------------------
# ---------------------------------------------------------------------


# FROM PYTHON DOCS
# http://effbot.org/zone/python-with-statement.htm


# Generated at 2022-06-21 21:38:39.860418
# Unit test for function ok
def test_ok():
    """
    >>> with ok(Exception):
    ...     pass
    >>> with ok(Exception):
    ...     raise Exception
    >>> with ok(Exception):
    ...     raise IndexError
    Traceback (most recent call last):
    IndexError
    """



# Generated at 2022-06-21 21:39:25.894409
# Unit test for function ok
def test_ok():
    with ok():
        raise RuntimeError("expected exception")
    with ok(RuntimeError):
        raise RuntimeError("expected exception")
    with ok(RuntimeError, NameError):
        raise RuntimeError("expected exception")
    with ok(NameError, RuntimeError):
        raise RuntimeError("expected exception")
    with ok(RuntimeError, NameError):
        raise NameError("expected exception")
    with ok(RuntimeError, NameError):
        raise ValueError("unexpected exception")


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-21 21:39:34.654689
# Unit test for function ok
def test_ok():
    """Check if context manager passes exceptions."""
    from contextlib import contextmanager
    @contextmanager
    def throwing():
        raise ValueError()
    with throwing():
        pass
    with pytest.raises(ValueError):
        with throwing():
            raise TypeError()
    with ok(ValueError):
        with throwing():
            raise TypeError()
    with ok(ValueError):
        with throwing():
            raise ValueError()

# Generated at 2022-06-21 21:39:44.484577
# Unit test for function ok
def test_ok():
    """Test for function ok"""
    with ok(TypeError):
        int('string')
        assert False
    with ok(TypeError, ValueError):
        int('string')
        assert False
    with ok(TypeError, ValueError):
        int(3.14159)
        assert False
    with ok(TypeError, ValueError):
        int('4')
    with ok(TypeError, ValueError):
        int(2)
    with ok(TypeError):
        int('a')
        assert False
    with ok(TypeError):
        int([1, 2, 3])
        assert False


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-21 21:39:47.627523
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('a')
    with raises(TypeError):
        with ok(ValueError):
            int(None)



# Generated at 2022-06-21 21:39:50.491467
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with ok(ZeroDivisionError):
        raise ZeroDivisionError
    with raises(ZeroDivisionError):
        with ok(TypeError):
            1 / 0



# Generated at 2022-06-21 21:39:54.549096
# Unit test for function ok
def test_ok():
    value = "Exception wanted"

    try:
        with ok(ValueError):
            raise ValueError(value)

        assert False, "Exception wanted"

    except ValueError as e:
        assert e.args[0] == value



# Generated at 2022-06-21 21:40:00.368126
# Unit test for function ok
def test_ok():
    with ok():
        pass
    with ok(ValueError):
        raise ValueError("Invalid")
    with pytest.raises(ValueError):
        with ok(IOError):
            raise ValueError("Invalid")
    with pytest.raises(ValueError):
        with ok(IOError, ImportError):
            raise ValueError("Invalid")



# Generated at 2022-06-21 21:40:04.283187
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        pass
    with ok(ValueError):
        raise ValueError('Exception should be passed.')
    with pytest.raises(TypeError):
        with ok(ValueError):
            raise TypeError('Exception should be raised')



# Generated at 2022-06-21 21:40:09.364119
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print("This is ok")

    with ok(TypeError):
        raise TypeError("This is permitted")

    with ok(TypeError):
        raise BaseException("This is NOT permitted")


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-21 21:40:11.900974
# Unit test for function ok
def test_ok():
    with ok(AssertionError) as x:
        assert False, "This is a test of ok()"

    assert type(x.exception) == AssertionError



# Generated at 2022-06-21 21:41:37.562688
# Unit test for function ok
def test_ok():
    """Test ok context manager."""
    assert 42 == next(yield_contextmanager(ok, ZeroDivisionError))
    assert 42 == next(yield_contextmanager(ok, KeyError))
    try:
        next(yield_contextmanager(ok, TypeError))
    except TypeError:
        pass
    else:
        raise Exception



# Generated at 2022-06-21 21:41:43.905978
# Unit test for function ok
def test_ok():
    """Pass excepition types in ok."""
    import time
    with ok(ZeroDivisionError):
        time.sleep(0.01)
        1 / 0
    try:
        with ok(ZeroDivisionError):
            time.sleep(0.01)
            raise Exception
    except Exception:
        print('Passed test for function ok.')


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-21 21:41:46.410492
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError, IndexError):
        x = 1 / 0
        y = [1][1]



# Generated at 2022-06-21 21:41:53.333082
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
        print('ValueError passed')
    with ok(ValueError, IndexError):
        raise IndexError
        print('IndexError passed')
    with ok(TypeError, IndexError):
        raise IndexError
        print('IndexError passed')

    try:
        with ok():
            raise ValueError
    except ValueError:
        print('ValueError passed')
    else:
        print('ValueError not passed')


# test_ok()


# 创建一个类隐藏所有属性

# Generated at 2022-06-21 21:41:55.312666
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with ok():
        pass



# Generated at 2022-06-21 21:41:57.798717
# Unit test for function ok
def test_ok():
    """Unit test for function ok
    """
    with ok(TypeError):
        print("Pass!")


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-21 21:42:04.372830
# Unit test for function ok
def test_ok():
    """
        Test script for context manager ok
    """
    try:
        with ok(ValueError):
            raise ValueError('value error')
        with ok(ValueError, TypeError):
            raise TypeError('type error')
            raise TypeError('test')
        with ok(ValueError):
            pass
    except Exception as e:
        print(e)
        assert isinstance(e, TypeError)
    else:
        pass


if __name__ == '__main__':
    test_ok()
    print('Done.')

# Generated at 2022-06-21 21:42:07.589542
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError("meh")
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError("meh")
    with ok(TypeError):
        raise TypeError("meh")



# Generated at 2022-06-21 21:42:10.732167
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError("test")
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError("test")



# Generated at 2022-06-21 21:42:14.305942
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception("ok.")
    with raises(Exception):
        with ok():
            raise ValueError("not ok.")

