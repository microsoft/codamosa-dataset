

# Generated at 2022-06-12 07:23:03.375545
# Unit test for function ok
def test_ok():
    try:
        assert 1 != 0
    except Exception as e:
        print("Got exception.")

    try:
        assert 1 == 0
    except Exception as e:
        print("Got exception.")

    with ok(AssertionError):
        assert 1 == 0

    try:
        assert 1 == 0
    except Exception as e:
        print("Got exception.")

    try:
        with ok(AssertionError):
            assert 1 == 0
    except Exception as e:
        print("Got Exception")

    with ok(AssertionError):
        assert 1 != 0

# Generated at 2022-06-12 07:23:08.327137
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print("ok")
        raise TypeError("Type Error")
    with raises(ValueError):
        print("raise ValueError")
        raise ValueError("Value Error")


# Run unit tests
if __name__ == "__main__":
    run_module_suite()

# Generated at 2022-06-12 07:23:13.258696
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(OSError):
        os.chdir('/foo/bar')
    with ok(Exception):
        raise Exception
    with ok(ValueError):
        raise ValueError
    with ok(AttributeError):
        os.getcwd()
    # with ok(AttributeError):
    #     raise ValueError


test_ok()

# Generated at 2022-06-12 07:23:18.564480
# Unit test for function ok
def test_ok():
    @ok(TypeError)
    def foo(x):
        return x["a"]

    try:
        foo(1)
    except:
        pass
    else:
        assert False

    try:
        foo({'a': 1})
    except:
        assert False
    else:
        assert True



# Generated at 2022-06-12 07:23:22.123724
# Unit test for function ok
def test_ok():
    x = None
    with ok(TypeError):
        x = 1 + "1"
    assert 1 == x

    with raises(ZeroDivisionError):
        with ok(AttributeError):
            1 / 0




# Generated at 2022-06-12 07:23:25.446339
# Unit test for function ok
def test_ok():
    with ok(False):
        print("No exception")

    with ok(ValueError) as cm:
        raise ValueError("value error")

    with ok():
        raise ValueError("value error")

# Generated at 2022-06-12 07:23:26.677084
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        1 / 0
    print("This is printed")

# Generated at 2022-06-12 07:23:31.120466
# Unit test for function ok
def test_ok():
    """
    Test the contexts ok manager
    """
    with ok(TypeError):
        print('Hello')
        # This is not a type error
        raise ValueError
    with ok(RuntimeError):
        # This is not a runtime error
        raise TypeError



# Generated at 2022-06-12 07:23:33.898247
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        'foo'.encode('ascii')



# Generated at 2022-06-12 07:23:37.558547
# Unit test for function ok
def test_ok():
    with ok(TypeError, ValueError):
        a = 3 + '3'
    with ok(TypeError, ValueError):
        a = 3 + 3
    with raises(ZeroDivisionError):
        with ok(TypeError, ValueError):
            a = 3 / 0



# Generated at 2022-06-12 07:23:46.788500
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int(5)
    with ok(ValueError):
        int("a")
    with ok(ValueError):
        int("a")
    with ok(ValueError):
        int(5)
    with ok(ValueError):
        int("a")
    with ok(ValueError):
        int("a")
    with ok(ValueError):
        int("a")
    with ok(ValueError):
        int("a")
    with ok(ValueError):
        int("a")
    with ok(ValueError):
        int("a")
    with ok(ValueError):
        int("a")
    with ok(ValueError):
        int("a")



# Generated at 2022-06-12 07:23:53.890572
# Unit test for function ok
def test_ok():
    import exceptions

    # Ensure ok is testing properly
    with ok():
        pass
    with ok():
        raise exceptions.Exception()

    # Ensure ok is catching the proper exceptions
    try:
        with ok(exceptions.Exception):
            raise exceptions.Exception()
    except Exception:
        raise AssertionError("Exception should have been caught.")

    # Ensure ok is catching the proper exceptions
    try:
        with ok(exceptions.ArithmeticError):
            raise exceptions.Exception()
    except Exception as e:
        if isinstance(e, exceptions.ArithmeticError):
            raise AssertionError("The wrong exception was caught.")

# Generated at 2022-06-12 07:23:57.484696
# Unit test for function ok
def test_ok():
    """Test for function ok"""
    try:
        with ok(TypeError):
            eval(1)
    except SyntaxError:
        pass
    else:
        raise Exception



# Generated at 2022-06-12 07:24:05.085962
# Unit test for function ok
def test_ok():
    """
    >>> with ok(ValueError, TypeError):
    ...     raise ValueError()
    >>> with ok(ValueError, TypeError):
    ...     raise TypeError()
    >>> with ok(Exception):
    ...     raise TypeError()
    >>> with ok(ValueError, TypeError):
    ...     raise Exception() # doctest: +ELLIPSIS
    Traceback (most recent call last):
    ...
    Exception: ...
    """


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:24:08.414281
# Unit test for function ok
def test_ok():

    @ok(TypeError)
    def success():
        print(1 + 'a')

    @ok(TypeError, ValueError)
    def success2():
        print(1 + 'a')

    success()

    with assert_raises(TypeError):
        success2()

# Generated at 2022-06-12 07:24:11.541738
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception
    with ok(Exception):
        raise Exception()


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:24:12.916082
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        1 + "1"



# Generated at 2022-06-12 07:24:16.620748
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('hello')
        assert False

    with ok(TypeError):
        raise TypeError('Not here')

    with ok(TypeError):
        raise ValueError('Not here')



# Generated at 2022-06-12 07:24:18.664241
# Unit test for function ok
def test_ok():
    # Won't raise exception
    with ok(ZeroDivisionError):
        2 / 0

    with ok():
        pass



# Generated at 2022-06-12 07:24:20.179472
# Unit test for function ok
def test_ok():
    assert ok().__next__() is None



# Generated at 2022-06-12 07:24:29.238214
# Unit test for function ok
def test_ok():
    with ok():
        pass

    with ok(ValueError):
        raise ValueError

    with ok(Exception):
        raise ValueError

    with ok((ValueError, TypeError)):
        raise ValueError

    with ok((ValueError, TypeError)):
        raise TypeError

    with ok():
        raise ValueError

    with ok():
        raise TypeError

# Generated at 2022-06-12 07:24:33.887054
# Unit test for function ok
def test_ok():
    # Test 1: Normal test case
    with ok(ZeroDivisionError):
        1 / 0

    # Test 2: Normal test case, raise exception
    with pytest.raises(ZeroDivisionError):
        with ok(FileNotFoundError):
            1 / 0

    # Test 3: Exception raised, with wrong exception passed
    with pytest.raises(FileNotFoundError):
        with ok(ZeroDivisionError):
            raise FileNotFoundError



# Generated at 2022-06-12 07:24:35.257177
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        x = 1 / 0



# Generated at 2022-06-12 07:24:40.468388
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('hello')

    with ok(TypeError, ValueError):
        pass
    with ok(TypeError, ValueError):
        int('hello')

    with raises(IOError):
        with ok(TypeError, ValueError):
            raise IOError

    with raises(TypeError):
        with ok(ValueError):
            int('hello')

# Generated at 2022-06-12 07:24:44.542376
# Unit test for function ok
def test_ok():
    # Valid exception will not be raised
    with ok(ZeroDivisionError):
        1/0
    # Invalid exception will be raised
    with pytest.raises(ZeroDivisionError):
        with ok(NameError):
            1/0



# Generated at 2022-06-12 07:24:47.875446
# Unit test for function ok
def test_ok():
    allowed_exception = [OSError, TypeError]
    with ok(*allowed_exception):
        raise TypeError

    with ok(*allowed_exception):
        raise ValueError('Some error')


with ok(TypeError):
    # raise Exception
    raise TypeError

print('End')

# Generated at 2022-06-12 07:24:52.126965
# Unit test for function ok
def test_ok():
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-variable
    try:
        with ok(ZeroDivisionError):
            1/0
    except ZeroDivisionError as e:
        assert True
    else:
        assert False
    # pylint: enable=redefined-outer-name
    # pylint: enable=unused-variable


if __name__ == "__main__":
    # Run the unit test
    test_ok()

# Generated at 2022-06-12 07:24:55.357971
# Unit test for function ok
def test_ok():
    """Test the ok context manager."""
    try:
        with ok(ValueError):
            raise ValueError
    except TypeError:
        assert False

    try:
        with ok(ValueError):
            raise TypeError
    except TypeError:
        assert True



# Generated at 2022-06-12 07:24:58.353206
# Unit test for function ok
def test_ok():
    """Unit test for ok context manager."""
    def raise_exception():
        with ok(ValueError):
            raise ValueError('Ok')
        with ok(ValueError):
            raise TypeError('Not ok')
    with pytest.raises(TypeError):
        raise_exception()

# Generated at 2022-06-12 07:25:00.384087
# Unit test for function ok
def test_ok():
    with raises(IndexError):
        with ok():
            [][5]
    with raises(IndexError):
        with ok(IndexError):
            [][5]



# Generated at 2022-06-12 07:25:10.293500
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    value = int('5')
    assert value == 5



# Generated at 2022-06-12 07:25:11.893796
# Unit test for function ok
def test_ok():
    """
    Unit test function to test function ok
    """
    assert 1 == 1

# Generated at 2022-06-12 07:25:15.847096
# Unit test for function ok
def test_ok():
    """
    >>> with ok(TypeError):
    ...     int('abc')
    >>> with ok(TypeError):
    ...     print 'hello'
    Traceback (most recent call last):
        ...
    NameError: name 'hello' is not defined
    """
    pass



# Generated at 2022-06-12 07:25:16.700962
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int()



# Generated at 2022-06-12 07:25:19.199000
# Unit test for function ok
def test_ok():
    """Unit test for ok context manager."""
    with raises(ValueError):
        with ok(ZeroDivisionError):
            1 / 0

    with ok(ValueError):
        1 / 0



# Generated at 2022-06-12 07:25:28.665475
# Unit test for function ok
def test_ok():
    with ok():
        pass
    with ok(TypeError):
         raise TypeError
    try:
       with ok(TypeError):
            raise ValueError
    except ValueError:
        pass
    try:
       with ok(TypeError, ValueError):
            raise ValueError
    except ValueError:
        pass
    try:
       with ok(TypeError, ValueError):
            raise ValueError
    except ValueError:
        pass
    try:
       with ok(TypeError, ValueError):
            raise ValueError
    except ValueError:
        pass
    try:
       with ok(TypeError, ValueError):
            raise TypeError
    except TypeError:
        pass
    try:
       with ok(ValueError):
            raise TypeError
    except TypeError:
        pass

# Generated at 2022-06-12 07:25:30.104483
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError, TypeError):
        1 / 0



# Generated at 2022-06-12 07:25:36.232657
# Unit test for function ok
def test_ok():
    """Test for function ok."""
    with ok(Exception, ValueError):
        raise Exception("general exception raised")
    with pytest.raises(ValueError):
        with ok(Exception, ValueError):
            raise ValueError("value error raised")
    with pytest.raises(TypeError):
        with ok(Exception, ValueError):
            raise TypeError("type error raised")



# Generated at 2022-06-12 07:25:39.167219
# Unit test for function ok
def test_ok():
    """Test function ok
    """
    with ok(Exception):
        raise Exception
    with raises(ValueError):
        with ok(Exception):
            raise ValueError('Error')



# Generated at 2022-06-12 07:25:41.646442
# Unit test for function ok
def test_ok():
    """Test ok function."""
    with pytest.raises(ValueError):
        with ok(TypeError):
            int("six")
    with ok(TypeError, ValueError):
        int("six")



# Generated at 2022-06-12 07:25:57.898314
# Unit test for function ok
def test_ok():
    """Tests function ok."""
    with ok(KeyError, TypeError):
        {}['foo']()



# Generated at 2022-06-12 07:26:01.028418
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(float('nan'))
    with ok(TypeError, ValueError):
        print(float('nan'))
    with ok(TypeError, ValueError):
        print(float('nan'))
        # print(int('nan'))  # raises ValueError
    with ok(TypeError):
        print(int('nan'))  # raises ValueError



# Generated at 2022-06-12 07:26:03.420505
# Unit test for function ok
def test_ok():
    with ok(AttributeError, ArithmeticError):
        1 / 0



# Generated at 2022-06-12 07:26:04.766271
# Unit test for function ok
def test_ok():
    with ok():
        pass



# Generated at 2022-06-12 07:26:11.119994
# Unit test for function ok
def test_ok():
    # Test raised exception
    with pytest.raises(Exception):
        with ok():
            raise Exception()
    # Test exception not raised
    with ok(Exception):
        pass
    # Test multiple exceptions
    with pytest.raises(ValueError):
        with ok(ArithmeticError, TypeError):
            raise ValueError()



# Generated at 2022-06-12 07:26:15.065324
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with pytest.raises(ValueError):
        with ok(ValueError):
            raise AttributeError("a'a")
    with ok(TypeError):
        raise ValueError("a'a")
    with pytest.raises(ValueError):
        with ok():
            raise ValueError("a'a")

# Generated at 2022-06-12 07:26:15.971069
# Unit test for function ok
def test_ok():
    pass



# Generated at 2022-06-12 07:26:17.971276
# Unit test for function ok
def test_ok():
    with ok(ValueError, TypeError):
        i = int('foo')
    assert i == int('foo')



# Generated at 2022-06-12 07:26:20.438028
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:26:24.857292
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with ok(IndexError):
        [][1]
    with ok(ZeroDivisionError):
        [ZeroDivisionError][0]
    with ok():
        {ZeroDivisionError: 1}[ZeroDivisionError]


# Main for test
test_ok()

# Generated at 2022-06-12 07:26:57.349195
# Unit test for function ok
def test_ok():
    with ok(RuntimeError, ValueError):
        raise RuntimeError("can't happen")
    with ok(RuntimeError, ValueError):
        raise ValueError("can't happen")
    with pytest.raises(NameError):
        with ok(RuntimeError, ValueError):
            raise NameError("can't happen")



# Generated at 2022-06-12 07:27:00.868048
# Unit test for function ok
def test_ok():
    """Test ok context manager"""

    with ok():
        raise AttributeError

    with raises(TypeError):
        with ok(AttributeError):
            raise TypeError

# Generated at 2022-06-12 07:27:05.683547
# Unit test for function ok
def test_ok():
    """Test function ok"""
    with ok(ValueError):
        a = 1/0
    with ok(ZeroDivisionError):
        c = 1/0
    try:
        with ok(ValueError):
            b = 1/0
    except ZeroDivisionError:
        pass
    try:
        with ok(ValueError):
            raise Exception()
    except ValueError:
        pass
    try:
        with ok(ValueError):
            raise Exception()
    except Exception:
        pass



# Generated at 2022-06-12 07:27:10.674848
# Unit test for function ok
def test_ok():
    with ok(ValueError), ok(Exception), suppress(NameError):
        {}["a"] = 1
        raise ValueError
    try:
        with ok(ValueError), ok(Exception), suppress(NameError):
            {}["a"] = 1
            raise Exception
    except Exception:
        assert True
    else:
        assert False


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-12 07:27:15.678400
# Unit test for function ok
def test_ok():
    """Test function ok."""
    ok_ = ok(ValueError)
    with ok_:
        pass
    with ok_:
        raise ValueError("ok")
    # with ok_:
    #     raise TypeError("no")
    with ok_:
        raise AttributeError("no")



# Generated at 2022-06-12 07:27:22.611140
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with ok(Exception):
        raise Exception
    try:
        with ok(OSError):
            raise Exception
    except Exception:
        pass
    else:
        assert False, "An exception os expected"
    # Try with an exception that's not expected
    try:
        with ok(OSError):
            raise ValueError
    except Exception:
        pass
    else:
        assert False, "An exception os expected"

# END OF FILE

# Generated at 2022-06-12 07:27:27.691773
# Unit test for function ok
def test_ok():
    try:
        with ok(ValueError):
            int("a")
    except TypeError:
        raise AssertionError("Context manager should pass ValueErrors")

    try:
        with ok(ValueError):
            raise TypeError("Some error")
    except TypeError:
        pass
    else:
        raise AssertionError("Context manager should not pass TypeErrors")


# Main program
if __name__ == "__main__":
    # Run the unit tests
    test_ok()

# Generated at 2022-06-12 07:27:35.203373
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        pass
    try:
        with ok(ValueError):
            raise TypeError
        assert False
    except TypeError:
        assert True
    try:
        with ok(ValueError, TypeError):
            raise NameError
        assert False
    except NameError:
        assert True



# Generated at 2022-06-12 07:27:41.810765
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    # Test the function catching an exception
    with ok(ValueError):
        raise ValueError
    with raises(IOError):
        with ok(ValueError):
            raise IOError
    # Test the function not catching an exception
    with ok(ValueError):
        pass
    # Test TypeError from not passing a single exception
    with raises(TypeError):
        with ok():
            pass
    # Test TypeError from not passing a single exception
    with raises(TypeError):
        with ok(ValueError, TypeError):
            pass
    # Test TypeError from not passing a single exception
    with raises(TypeError):
        with ok(ValueError, TypeError)():
            pass
    # Test TypeError from not passing a single exception

# Generated at 2022-06-12 07:27:43.549426
# Unit test for function ok
def test_ok():
    with pytest.raises(ValueError):
        with ok():
            raise ValueError



# Generated at 2022-06-12 07:28:48.148616
# Unit test for function ok
def test_ok():
    """Test the context manager ok."""

    @ok(IOError)
    def f():
        raise IOError('error')
    with f():
        pass



# Generated at 2022-06-12 07:28:50.880114
# Unit test for function ok
def test_ok():
    with ok(RuntimeError):
        pass

    try:
        with ok(RuntimeError):
            raise TypeError
    except TypeError:
        pass
    else:
        assert False, 'Did not raise TypeError'

# Generated at 2022-06-12 07:28:54.696538
# Unit test for function ok
def test_ok():
    with ok(Exception):
        print("Hooray!")

    try:
        with ok(Exception):
            print("Oh no!")
            raise TypeError
    except TypeError:
        pass

    try:
        with ok(TypeError):
            print("TypeError!")
            raise ZeroDivisionError
    except ZeroDivisionError:
        pass



# Generated at 2022-06-12 07:29:00.877576
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print("Hello")
        raise TypeError("TypeError")

    with raises(ValueError):
        with ok(TypeError):
            print("Hello")
            raise ValueError("ValueError")

    with ok(TypeError, ValueError):
        print("Hello")
        raise ValueError("ValueError")

    with ok(TypeError, ValueError):
        print("Hello")
        raise TypeError("TypeError")

    with ok(TypeError, ValueError):
        print("Hello")
        raise SystemExit("SystemExit")

    with ok(TypeError, ValueError):
        print("Hello")
        rai

# Generated at 2022-06-12 07:29:03.695198
# Unit test for function ok
def test_ok():
    def test():
        with ok():
            1 / 0

    try:
        test()
        raise AssertionError
    except ZeroDivisionError:
        pass

# Generated at 2022-06-12 07:29:04.818981
# Unit test for function ok
def test_ok():  # simple assert, not testing for exceptions
    with ok():
        assert True

# Generated at 2022-06-12 07:29:07.645221
# Unit test for function ok
def test_ok():
    with ok(TypeError) as cm:
        raise TypeError("The exception to be raised")
    print("The exception passed")
    with cm:  # type: ignore
        raise IndexError("The exception will be raised")
    print("The exception not passed")

# Generated at 2022-06-12 07:29:12.877602
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print('This is ok!')

    with ok(TypeError, ValueError):
        print('This is also ok!')

    with ok(TypeError, ValueError, NameError):
        pass

    with pytest.raises(SyntaxError):
        with ok(TypeError, ValueError):
            raise SyntaxError



# Generated at 2022-06-12 07:29:16.419958
# Unit test for function ok
def test_ok():
    def error_func():
        raise ZeroDivisionError('Error')
    try:
        with ok(ZeroDivisionError):
            error_func()
    except ZeroDivisionError as e:
        pass
    else:
        assert False



# Generated at 2022-06-12 07:29:18.888712
# Unit test for function ok
def test_ok():
    with ok(RuntimeError):
        raise RuntimeError
    with ok(RuntimeError):
        raise IndexError
    with raises(IndexError):
        with ok(RuntimeError):
            raise IndexError



# Generated at 2022-06-12 07:31:34.385746
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError()

# Generated at 2022-06-12 07:31:36.503520
# Unit test for function ok
def test_ok():
    with ok():
        raise RuntimeError()
    with raises(RuntimeError):
        with ok(ValueError):
            raise RuntimeError()



# Generated at 2022-06-12 07:31:40.633315
# Unit test for function ok
def test_ok():
    """Test ok context manager."""
    with ok(StandardError):
        raise ValueError("ok context manager")
    with ok(ReferenceError, TypeError):
        raise TypeError("Variable referenced before assignment")
    try:
        with ok(ValueError):
            raise ReferenceError("Variable referenced before assignment")
    except:
        pass



# Generated at 2022-06-12 07:31:44.515397
# Unit test for function ok
def test_ok():
    with ok():
        pass

    with ok(ZeroDivisionError):
        1 / 0

    with ok(ValueError, TypeError):
        "str" + 3

    with ok(BaseException):
        raise Exception("test")

    try:
        with ok():
            1 / 0
    except ZeroDivisionError:
        pass
    else:
        assert False, "ZeroDivisionError not passed"



# Generated at 2022-06-12 07:31:52.507914
# Unit test for function ok
def test_ok():
    """Test function ok"""
    with ok(ValueError):
        print('Pass ValueError')
        raise ValueError
    with ok(ValueError):
        print('Pass KeyError')
        raise KeyError
    try:
        with ok(ValueError):
            print('Pass ValueError')
            raise ValueError
        with ok(ValueError):
            print('Not Pass ZeroDivisionError')
            raise ZeroDivisionError
    except Exception as e:
        print('Expected')
    else:
        print('Something wrong')
    # wrap in if to skip on Travis
    if not os.getenv('TRAVIS'):
        with ok(ValueError):
            print('Pass ValueError')
            raise ValueError
        with ok(ValueError):
            print('Not Pass ZeroDivisionError')
            raise ZeroDivisionError

# Generated at 2022-06-12 07:31:58.398253
# Unit test for function ok
def test_ok():
    """Unit test for function ok.
    """
    with ok(KeyError, ValueError):
        {'a': 'b', 'c': 'd'}['e']
    try:
        with ok(KeyError):
            {'a': 'b', 'c': 'd'}['e']
    except KeyError:
        pass
    else:
        raise Exception('ok does not pass all exceptions.')



# Generated at 2022-06-12 07:32:05.980722
# Unit test for function ok
def test_ok():
    # Test for when exception occurs
    try:
        with ok(KeyError, IndexError):
            l = [1, 2]
            # This does not raise an exception
            a = l[2]
        assert False, "Exception should be raised"
    except:
        assert True

    # Test for the different exceptions
    try:
        with ok(KeyError, IndexError):
            l = [1, 2]
            # This raises a KeyError
            a = l[1:2]['a':'b']
        assert False, "Exception should be raised"
    except:
        assert True

    # Test for when no exception should be raised

# Generated at 2022-06-12 07:32:11.493646
# Unit test for function ok
def test_ok():
    """Test context manager ok."""
    with raises(Exception) as e:
        with ok(ZeroDivisionError):
            raise Exception
        assert True
    with ok(Exception):
        raise Exception
    with raises(ZeroDivisionError) as e:
        with ok(IndexError):
            raise ZeroDivisionError
        assert True


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-12 07:32:15.139074
# Unit test for function ok
def test_ok():
    from io import StringIO
    expected = "test\n"
    with ok():
        try:
            raise ValueError()
        except Exception:
            pass
    try:
        raise ValueError()
    except ValueError:
        pass



# Generated at 2022-06-12 07:32:16.972957
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()

