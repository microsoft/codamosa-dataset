

# Generated at 2022-06-12 07:23:00.761844
# Unit test for function ok
def test_ok():
    """Test for ok() context manager.
    :return: None
    """
    with ok():
        raise IOError('No such file or directory')
    try:
        with ok(IOError):
            raise Exception('Help, I\'ve fallen, and I can\'t get up.')
    except Exception as e:
        print(e)
    with ok():
        raise Exception('Something bad happened')



# Generated at 2022-06-12 07:23:04.424582
# Unit test for function ok
def test_ok():
    with ok(FileNotFoundError):
        raise FileNotFoundError
    with raises(TypeError):
        with ok(FileNotFoundError):
            raise TypeError

# Generated at 2022-06-12 07:23:06.485251
# Unit test for function ok
def test_ok():
    with ok(IOError):
        raise IOError('test')
    with ok():
        raise ValueError('test')



# Generated at 2022-06-12 07:23:12.544572
# Unit test for function ok
def test_ok():
    with ok(AssertionError, IOError):
        print("foo")
    with ok(AssertionError):
        print("foo")
        raise AssertionError
    try:
        with ok(AssertionError, IOError):
            raise ValueError
    except ValueError:
        pass
    try:
        with ok(AssertionError):
            raise ValueError
    except ValueError:
        pass



# Generated at 2022-06-12 07:23:18.871434
# Unit test for function ok
def test_ok():
    with ok():
        print("This is ok context")

    try:
        with ok(AttributeError):
            print("This is also ok context")
            raise KeyError
    except KeyError:
        pass

    try:
        with ok(AttributeError, KeyError):
            print("This is also ok context")
            raise IndexError
    except IndexError:
        pass


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:23:21.187500
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with ok(KeyError):
        {}["key"]



# Generated at 2022-06-12 07:23:24.302437
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        print("1")
        raise ValueError()
        print("2")
    assert True


test_ok()


# Generated at 2022-06-12 07:23:35.431030
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    values = [1, 2, 4, 5]
    with ok(IndexError):
        values[5]
    try:
        with ok(IndexError):
            values[5]
            values[5]
    except IndexError:
        pass
    else:
        assert False, "Did not raise IndexError"
    try:
        with ok(ZeroDivisionError):
            1 / 0
            1 / 0
    except ZeroDivisionError:
        pass
    else:
        assert False, "Did not raise ZeroDivisionError"
    with ok():
        pass
    try:
        with ok():
            1 / 0
    except ZeroDivisionError:
        pass
    else:
        assert False, "Did not re-raise ZeroDivisionError"

# Generated at 2022-06-12 07:23:38.192969
# Unit test for function ok
def test_ok():
    """Test for ok(()).
    """
    with ok(Exception):
        raise ValueError


# If a class is inherited from Exception,
# then it is considered as an exception type

# Generated at 2022-06-12 07:23:40.639141
# Unit test for function ok
def test_ok():
    """Unit test for context manager ok"""
    with ok(ValueError):
        s = '123'
        value = int(s)


test_ok()

# Generated at 2022-06-12 07:23:47.387021
# Unit test for function ok
def test_ok():
    assert ok(TypeError).__enter__() is None
    with assert_raises(TypeError):
        ok(TypeError).__exit__(*sys.exc_info())
    with assert_raises(TypeError):
        with ok(TypeError):
            raise TypeError('Good exception')
    with ok(TypeError):
        raise ValueError('Bad exception')



# Generated at 2022-06-12 07:23:52.718677
# Unit test for function ok
def test_ok():
    try:
        with ok(ValueError):
            raise ValueError("val_err")
    except:
        raise AssertionError('ok() not working')
    try:
        with ok(ValueError):
            raise RuntimeError("unexpected")
    except RuntimeError:
        return True
    except:
        raise AssertionError('ok() not working')


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:23:55.916883
# Unit test for function ok
def test_ok():
    """Test function ok"""
    with ok(ZeroDivisionError):
        5 / 0
    try:
        with ok(ZeroDivisionError):
            5 / 2
    except Exception:
        pass
    else:
        raise AssertionError("Expected exception")



# Generated at 2022-06-12 07:24:00.021792
# Unit test for function ok
def test_ok():
    """Test function ok
    """
    with ok(TypeError):
        foo = 2
        foo()

# Generated at 2022-06-12 07:24:06.423304
# Unit test for function ok
def test_ok():
    # Test ok.
    with ok():
        raise RuntimeError

    with ok(RuntimeError):
        raise RuntimeError

    with ok(OSError):
        raise OSError

    with ok(KeyError, IndexError, TypeError):
        raise TypeError

    with raises(KeyError):
        with ok(IndexError, TypeError):
            raise KeyError

    with raises(TypeError):
        with ok(IndexError, TypeError):
            raise TypeError


# Tests for the function to_bytes.

# Generated at 2022-06-12 07:24:09.538747
# Unit test for function ok
def test_ok():
    """Tests function ok"""
    with ok(ValueError, TypeError):
        if int('a') / 0:
            pass
    with ok(AssertionError):
        assert 0



# Generated at 2022-06-12 07:24:13.826573
# Unit test for function ok
def test_ok():
    """Test the context manager ok."""
    with ok(TypeError, ValueError):
        with ok(ValueError):
            pass
        raise ValueError

    with ok(TypeError):
        raise NotImplementedError



# Generated at 2022-06-12 07:24:17.591226
# Unit test for function ok
def test_ok():
    """Unittest for ok context manager."""
    with ok(TypeError):
        print(int('Hello, world!'))
    with ok(TypeError):
        print(int(3.14159))
    with ok(TypeError):
        print(int('Foo'))



# Generated at 2022-06-12 07:24:19.149607
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:24:26.982922
# Unit test for function ok
def test_ok():
    """Test for function ok."""
    with ok(KeyError):
        dict_ = {'abc': 123}
        dict_['def']
    try:
        with ok(KeyError):
            dict_ = {'abc': 123}
            dict_['abc'] = 456
    except Exception as e:
        assert type(e) is KeyError
    try:
        with ok(KeyError):
            dict_ = {'abc': 123}
            dict_['abc'] = 456
    except Exception as e:
        assert type(e) is TypeError

# Generated at 2022-06-12 07:24:38.651763
# Unit test for function ok
def test_ok():
    try:
        with ok(IndexError, ValueError):
            print(1000)
            raise IndexError()
            print(1001)
    except IndexError:
        pass
    except Exception as e:
        raise AssertionError(e)

    try:
        with ok(IndexError, ValueError):
            print(2000)
            raise ValueError()
            print(2001)
    except ValueError:
        pass
    except Exception as e:
        raise AssertionError(e)

    try:
        with ok(IndexError, ValueError):
            print(3000)
            raise AssertionError()
            print(3001)
    except AssertionError:
        pass
    except Exception as e:
        raise AssertionError(e)



# Generated at 2022-06-12 07:24:44.736618
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with ok(AssertionError):
        assert False

    with ok(AssertionError):
        assert True

    with ok(ZeroDivisionError):
        1 + 1

    with raises(ZeroDivisionError):
        with ok(AssertionError):
            1 / 0

    with raises(AssertionError):
        with ok(ZeroDivisionError):
            assert False



# Generated at 2022-06-12 07:24:50.656777
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError("This is a test")

    with ok(ValueError):
        raise TypeError("This is a test")

    with ok():
        raise TypeError("This is a test")

    with ok(ValueError):
        assert True

    with ok(ValueError):
        assert False

    with ok(ValueError):
        with ok(ValueError):
            raise TypeError("This is a test")

    with ok():
        with ok():
            assert False

    with ok(TypeError):
        with ok(ValueError):
            assert False



# Generated at 2022-06-12 07:24:54.747744
# Unit test for function ok
def test_ok():
    with ok(OSError):
        raise TypeError()

    with ok(ZeroDivisionError, IndexError):
        pass

    with raises(TypeError):
        with ok(ZeroDivisionError, IndexError):
            raise TypeError()

    with raises(ZeroDivisionError):
        with ok(ZeroDivisionError, IndexError):
            raise ZeroDivisionError()



# Generated at 2022-06-12 07:25:00.347779
# Unit test for function ok
def test_ok():
    with ok(NameError):
        print ("Function called")
        raise NameError('a')
    with ok(ValueError, NameError):
        print ("Function called")
        raise NameError('a')
    try:
        with ok(TypeError):
            print ("Function called")
            raise NameError('a')
    except NameError as e:
        print ("NameError: %s" % e)
    try:
        with ok():
            print ("Function called")
            raise NameError('a')
    except NameError as e:
        print ("NameError: %s" % e)

# Generated at 2022-06-12 07:25:04.030655
# Unit test for function ok
def test_ok():
    """Function to test function ok
    """
    with ok(ValueError):
        raise ValueError('test')

    with ok(ValueError, TypeError):
        raise ValueError('test')

    with ok(ValueError):
        raise TypeError('test')



# Generated at 2022-06-12 07:25:14.710452
# Unit test for function ok
def test_ok():
    """Test function ok."""
    # First let's handle normal exceptions
    with ok(ValueError):
        int('N/A')

    # This one will still raise AssertionError
    with pytest.raises(AssertionError):
        with ok(TypeError):
            int('N/A')

    # Now let's try a more complex exception handling with ok
    with ok(AssertionError, ValueError):
        int('N/A')

    # This one will still raise the exception
    with pytest.raises(TypeError):
        with ok(ValueError):
            int('N/A')

    # Now let's try with a custom exception
    class CustomException(Exception):
        pass

    with ok(TypeError, CustomException):
        raise CustomException


# Generated at 2022-06-12 07:25:15.927738
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        n = 1 / 0



# Generated at 2022-06-12 07:25:17.350060
# Unit test for function ok
def test_ok():
    with ok(TypeError, ValueError):
        a = 10
        print(a)



# Generated at 2022-06-12 07:25:19.139228
# Unit test for function ok
def test_ok():
    """Test function ok
    """
    with ok(AttributeError):
        int('a')
    with ok(AttributeError, ValueError):
        int('a')



# Generated at 2022-06-12 07:25:34.923747
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        {1, 2, 3}[4]
        raise TypeError('A message')
    # This should fail
    with ok(TypeError):
        {1, 2, 3}[4]
    # This should fail
    with ok(TypeError):
        raise ValueError('A message')
    # This should succeed
    with ok(TypeError, ValueError):
        raise ValueError('A message')
    # This should fail
    with ok(TypeError, ValueError):
        raise OSError('A message')
    # This should fail
    with ok(TypeError, ValueError):
        raise OSError

# Generated at 2022-06-12 07:25:40.312440
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(Exception):
        with ok(ValueError):
            raise Exception
    with ok(ValueError):
        with ok(ValueError):
            raise ValueError
    with ok(ValueError):
        with ok(ValueError, TypeError):
            raise ValueError
    with ok(ValueError, TypeError):
        with ok(ValueError):
            raise ValueError


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-12 07:25:50.850576
# Unit test for function ok
def test_ok():
    with ok(IndexError, TypeError):
        x = [1, 2, 3]
        x.index(5)
    with ok(IndexError, TypeError):
        x = [1, 2, 3]
        x[5]
    with ok(IndexError, TypeError):
        x = (1, 2, 3)
        x[5]
    with ok(IndexError, TypeError):
        x = "abc"
        x[5]

    with ok(IndexError):
        x = [1, 2, 3]
        x.index(5)
    with ok(IndexError):
        x = [1, 2, 3]
        x[5]
    with ok(IndexError):
        x = (1, 2, 3)
        x[5]

# Generated at 2022-06-12 07:25:55.259532
# Unit test for function ok
def test_ok():
    """
    Test for the ok function.
    """
    try:
        with ok(ZeroDivisionError):
            1 // 0
    except:
        print("Unexpected exception raised.")
    else:
        print("ZeroDivisionError not raised.")



# Generated at 2022-06-12 07:25:58.706368
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False

    with ok(AssertionError, IndexError):
        assert False

    with ok(AssertionError):
        assert True

    with ok(AssertionError):
        raise IndexError('test')

    with ok():
        raise IndexError('test')



# Generated at 2022-06-12 07:26:02.693874
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print("hello")
    try:
        with ok(TypeError):
            int('hello')
    except NameError as e:
        print(str(e))



# Generated at 2022-06-12 07:26:03.727679
# Unit test for function ok
def test_ok():
    @ok()
    def ok_test():
        raise Exception("Error")

    ok_test()



# Generated at 2022-06-12 07:26:06.296311
# Unit test for function ok
def test_ok():
    with ok():
        print(1 / 0)

    with pytest.raises(ValueError):
        with ok(ZeroDivisionError):
            print(1 / 0)



# Generated at 2022-06-12 07:26:12.734323
# Unit test for function ok
def test_ok():
    try:
        with ok(SystemExit):
            raise SystemExit
    except Exception as e:
        assert(isinstance(e, SystemExit))

    try:
        with ok(SystemExit):
            raise ValueError
    except Exception as e:
        assert(isinstance(e, ValueError))


#
# Decorator to handle exceptions
#

# Generated at 2022-06-12 07:26:13.912326
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0



# Generated at 2022-06-12 07:26:32.397146
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        raise TypeError("I'm good")
    with ok(TypeError, ValueError):
        raise ValueError("I'm good")
    with ok(RuntimeError):
        raise RuntimeError("I'm bad!")
    with ok():
        raise RuntimeError("I'm bad!")


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:26:36.623474
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError("Invalid value")

    with ok(Exception):
        raise ValueError("Invalid value")

    with ok(Exception):
        raise Exception("Unknown Exception")

    with raises(ValueError):
        with ok(ValueError):
            raise KeyError("Key not found")


# Test: Pass some exceptions
test_ok()

# Code from Algolab
import datetime as dt



# Generated at 2022-06-12 07:26:41.797185
# Unit test for function ok
def test_ok():

    with ok(TypeError):
        print(1 + 1)

    with ok(ValueError):
        print(1 + 'a')

    with pytest.raises(TypeError):
        with ok(ValueError):
            print(1 + 'a')

    with pytest.raises(TypeError):
        with ok(ValueError):
            print(1 + 1)



# Generated at 2022-06-12 07:26:46.133388
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        {}['a'] = 1

    try:
        with ok(TypeError):
            raise ValueError
    except ValueError:
        pass

    print('Pass!')


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:26:54.737578
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        pass

    with ok(TypeError):
        pass

    try:
        with ok(ValueError):
            raise TypeError()
    except TypeError:
        pass
    else:
        raise AssertionError("contextmanager didn't work.")

    try:
        with ok(ValueError):
            raise ValueError()
    except ValueError:
        raise AssertionError("contextmanager didn't work.")

    try:
        with ok(ValueError, TypeError):
            raise ValueError()
    except ValueError:
        pass
    else:
        raise AssertionError("contextmanager didn't work.")

    try:
        with ok(ValueError, TypeError):
            raise TypeError()
    except TypeError:
        pass

# Generated at 2022-06-12 07:27:02.004689
# Unit test for function ok
def test_ok():
    def raise_first():
        raise ZeroDivisionError()

    def raise_second():
        raise AssertionError()

    def raise_third():
        raise AttributeError()

    with ok(ZeroDivisionError):
        raise_first()  # Should pass

    with raises(AssertionError):
        with ok(ZeroDivisionError):
            raise_second()

    with raises(AttributeError):
        with ok(ZeroDivisionError):
            raise_third()



# Generated at 2022-06-12 07:27:05.575705
# Unit test for function ok
def test_ok():
    with ok(Exception):
        pass
    with ok(TypeError):
        raise KeyError('foo')
    with ok((TypeError, ValueError)):
        raise KeyError('foo')
    try:
        with ok(TypeError):
            raise ValueError('bar')
    except ValueError:
        pass
    else:
        assert False, 'ValueError should be raised'



# Generated at 2022-06-12 07:27:11.685623
# Unit test for function ok
def test_ok():
    """
    Tests the ok function.
    """
    with ok(TypeError):
        raise TypeError
    with ok(TypeError):
        raise ValueError
    try:
        with ok(TypeError):
            raise ValueError
    except ValueError:
        pass
    else:
        raise AssertionError("Failed to pass ValueError!")
    with ok(TypeError, ValueError):
        raise TypeError
    with ok(TypeError, ValueError):
        raise ValueError



# Generated at 2022-06-12 07:27:14.546100
# Unit test for function ok

# Generated at 2022-06-12 07:27:20.173290
# Unit test for function ok
def test_ok():
    """Test the function ok."""
    with pytest.raises(Exception):
        with ok(AttributeError, ImportError):
            test = {}
            test.get_attr()
    with ok(AttributeError, ImportError):
        test = {}
        test.get_attr()


if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-12 07:27:51.955389
# Unit test for function ok
def test_ok():
    class CustomException(Exception):
        pass

    with ok():
        raise Exception()

    with ok():
        raise CustomException()

    with ok(CustomException):
        raise CustomException()

    with ok(CustomException):
        raise Exception()

# Generated at 2022-06-12 07:27:55.770053
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with ok(KeyboardInterrupt):
        raise KeyboardInterrupt

    with ok(KeyError, ValueError):
        raise ValueError

    with ok(KeyError, ValueError):
        raise KeyError

    with ok(KeyError, ValueError):
        raise Exception

# Generated at 2022-06-12 07:27:58.420052
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('str')

OK = ok

#############
#   TESTS   #
#############


# Generated at 2022-06-12 07:28:03.349735
# Unit test for function ok
def test_ok():
    """Tests ok()
    """
    x = 1
    with ok(Exception):
        if x == 1:
            raise Exception()
        else:
            x = 2
    assert x == 2

    x = 1
    try:
        with ok(AssertionError):
            if x == 1:
                raise AssertionError()
            else:
                x = 2
    except Exception as e:
        pass
    else:
        assert False
    assert x == 1


# 3.2.1

# Generated at 2022-06-12 07:28:07.655704
# Unit test for function ok
def test_ok():
    """Test for function ok."""
    with ok(ZeroDivisionError):
        1/0
    try:
        with ok(ZeroDivisionError):
            raise ValueError
    except ValueError:
        pass
    else:
        assert False, 'did not raise'


# Generated at 2022-06-12 07:28:11.703751
# Unit test for function ok
def test_ok():

    def f():
        raise ValueError()

    with ok():
        pass

    with ok(TypeError):
        f()

    with pytest.raises(ValueError):
        with ok(TypeError):
            raise ValueError()



# Generated at 2022-06-12 07:28:14.920756
# Unit test for function ok
def test_ok():
    """
    Test the ok context manager
    """
    with ok(TypeError, ValueError):
        print(s)
    assert True


test_ok()

# Generated at 2022-06-12 07:28:15.977545
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        raise ZeroDivisionError



# Generated at 2022-06-12 07:28:19.394761
# Unit test for function ok
def test_ok():
    """Test function ok()
    The function ok() pass the exception
    """

    class TestException(Exception):
        pass

    with ok(TestException):
        raise TestException


if __name__ == '__main__':
    if sys.argv[1] == '-t':
        test_ok()

# Generated at 2022-06-12 07:28:22.666906
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        raise ZeroDivisionError()
    with ok(ZeroDivisionError):
        pass


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-12 07:29:31.331895
# Unit test for function ok
def test_ok():
    """Test for function ok."""
    try:
        with ok(ValueError):
            raise ValueError("Testing ok context manager")
    except ValueError as e:
        assert False
    try:
        with ok(ValueError, TypeError):
            raise TypeError("Testing ok context manager")
    except TypeError as e:
        assert False
    try:
        with ok(ValueError, TypeError):
            raise NameError("Testing ok context manager")
    except NameError as e:
        pass



# Generated at 2022-06-12 07:29:37.376648
# Unit test for function ok
def test_ok():
    with ok():
        raise AssertionError

    with ok(AssertionError, ValueError):
        raise AssertionError

    with ok(AssertionError, ValueError):
        raise ValueError

    with pytest.raises(TypeError):
        with ok():
            raise TypeError

    with pytest.raises(TypeError):
        with ok(Exception, ValueError):
            raise TypeError



# Generated at 2022-06-12 07:29:40.561020
# Unit test for function ok
def test_ok():
    with ok():
        pass
    with ok(Exception):
        raise Exception()
    with ok(AssertionError):
        pass
    with ok(AssertionError, Exception):
        raise AssertionError()
    with raises(ZeroDivisionError):
        with ok(AssertionError, Exception):
            1 / 0



# Generated at 2022-06-12 07:29:43.962532
# Unit test for function ok
def test_ok():
    """Test context mamager ok
    """
    with ok(ValueError):
        a = int('abc')
        print(a)


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:29:51.022960
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with ok(ValueError, TypeError):
        pass

    with ok(ValueError, TypeError):
        int('abc')

    with ok(TypeError):
        int('abc')

    with ok(ValueError):
        ValueError('abc')

    with ok(ValueError):
        int('abc')


# Demo of context manager 'ok'

# Generated at 2022-06-12 07:29:53.578855
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise KeyError
        # If Exception is not ValueError, then it will raise



# Generated at 2022-06-12 07:29:57.519297
# Unit test for function ok
def test_ok():
    """Test for ok."""
    @ok(ZeroDivisionError)
    def div(x, y):
        """Divide x by y."""
        return x / y

    result = div(1, 0)
    assert result is None



# Generated at 2022-06-12 07:30:02.209094
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok():
        pass

    with ok(Exception):
        raise Exception()

    with ok(Exception):
        raise TypeError()

    try:
        with ok(TypeError):
            raise Exception()
    except Exception:
        pass



# Generated at 2022-06-12 07:30:05.155427
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        int('123')
    with ok(ValueError, TypeError):
        int('N/A')



# Generated at 2022-06-12 07:30:09.065578
# Unit test for function ok
def test_ok():
    """Testing ok function"""
    with ok(ZeroDivisionError):
        1/0
    with ok(FloatingPointError, ZeroDivisionError):
        1/0
    try:
        with ok(TypeError):
            1/0
    except ZeroDivisionError:
        pass



# Generated at 2022-06-12 07:32:26.603090
# Unit test for function ok
def test_ok():
    with ok(Exception):
        r

# Generated at 2022-06-12 07:32:28.552852
# Unit test for function ok

# Generated at 2022-06-12 07:32:31.128758
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        raise TypeError('test')

    with raises(ValueError):
        with ok(TypeError):
            raise ValueError('test')


if __name__ == '__main__':
    run_tests()

# Generated at 2022-06-12 07:32:33.987142
# Unit test for function ok
def test_ok():
    with ok(ValueError, IndexError):
        test_list = ['item']
        int(test_list[1])


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:32:36.258391
# Unit test for function ok
def test_ok():
    with pytest.raises(ZeroDivisionError):
        with ok(ValueError):
            1 / 0



# Generated at 2022-06-12 07:32:38.606813
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        raise TypeError
    with ok(TypeError):
        raise ValueError



# Generated at 2022-06-12 07:32:49.431626
# Unit test for function ok
def test_ok():

    t1 = ok(UnicodeDecodeError)
    with t1:
        raise UnicodeDecodeError("Bam!", b"Y", 1, 2, "")
    assert True

    t2 = ok(UnicodeDecodeError, ValueError)
    with t2:
        raise UnicodeDecodeError("Bam!", b"Y", 1, 2, "")
    assert True

    t3 = ok(UnicodeDecodeError)
    try:
        with t3:
            raise ValueError("Bam!")
    except ValueError as e:
        assert str(e) == "Bam!"
    else:
        assert False

    t4 = ok(UnicodeDecodeError, ValueError)

# Generated at 2022-06-12 07:32:52.250039
# Unit test for function ok
def test_ok():
    try:
        with ok(ValueError):
            raise ValueError
    except Exception as e:
        assert False, "Error raised"

