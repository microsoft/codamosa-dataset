

# Generated at 2022-06-12 07:23:01.175715
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception()

    with ok(TypeError):
        raise TypeError()

    with ok(Exception, TypeError):
        raise TypeError()

    with ok(Exception, TypeError):
        raise Exception()



# Generated at 2022-06-12 07:23:04.375227
# Unit test for function ok
def test_ok():
    with ok():
        pass

    with ok(TypeError):
        raise ValueError

    with ok(TypeError, ZeroDivisionError):
        raise ValueError

# Generated at 2022-06-12 07:23:07.982995
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        pass
    with ok():
        pass
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise RuntimeError



# Generated at 2022-06-12 07:23:12.181886
# Unit test for function ok
def test_ok():
    with ok(TypeError, IndexError):
        [][0] = 1
    with ok(TypeError):
        int('N/A')
    with ok(TypeError):
        [][0] = 1


########################################################################
# 13.2.4. Suppressing Exceptions
########################################################################

# Generated at 2022-06-12 07:23:18.270011
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    def foo():
        with ok(ZeroDivisionError):
            1 / 0

    def bar():
        with ok(ZeroDivisionError):
            1 / 1

    try:
        foo()
    except ZeroDivisionError:
        raise AssertionError

    try:
        bar()
    except ZeroDivisionError:
        raise AssertionError



# Generated at 2022-06-12 07:23:22.121820
# Unit test for function ok
def test_ok():
    def bad_division(x, y):
        return x / y

    with ok(ZeroDivisionError):
        bad_division(1, 0)

    with raises(ZeroDivisionError):
        with ok(NameError):
            bad_division(1, 0)



# Generated at 2022-06-12 07:23:27.102770
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError('Passed')
    with raises(ZeroDivisionError):
        with ok(ValueError):
            raise ZeroDivisionError('Failed')
    with raises(ValueError):
        with ok(ZeroDivisionError):
            raise ValueError('Failed')
    with raises(ZeroDivisionError):
        with ok(ValueError, IndexError):
            raise ZeroDivisionError('Failed')



# Generated at 2022-06-12 07:23:33.833576
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception

    with ok(ValueError, TypeError):
        raise TypeError

    with ok(Exception):
        print('Boom!')

    with ok(ValueError, TypeError):
        raise ValueError

    with ok(ValueError):
        raise ValueError

    with ok(ValueError):
        print('Boom!')



# Generated at 2022-06-12 07:23:41.942008
# Unit test for function ok
def test_ok():
    """Tests the ok context manager."""
    with ok(ZeroDivisionError):
        1 / 0
    with ok(IndexError, ZeroDivisionError):
        [][0]
    with raises(TypeError):
        with ok(IndexError, ZeroDivisionError):
            {}[0]


# @contextmanager
# def success_on(*exceptions):
#     """Success on exceptions context manager.
#     :param exceptions: Exceptions to raise
#     """
#     try:
#         yield
#     except Exception as e:
#         if isinstance(e, exceptions):
#             raise Success
#         else:
#             raise e


# # Unit test for function success_on
# def test_success_on():
#     """Tests function success_on."""
#     with success_on(Success):
#

# Generated at 2022-06-12 07:23:42.783484
# Unit test for function ok
def test_ok():
    with ok(Exception):
        pass



# Generated at 2022-06-12 07:23:48.106782
# Unit test for function ok
def test_ok():
    with ok(KeyboardInterrupt, ValueError):
        raise KeyboardInterrupt()

    with ok(KeyboardInterrupt, ValueError):
        raise ValueError()

    with ok(KeyboardInterrupt, ValueError):
        raise NameError()



# Generated at 2022-06-12 07:23:50.477968
# Unit test for function ok
def test_ok():
    """Test of function ok."""
    with ok(TypeError):
        int('hello')
    with ok(TypeError):
        int(1)



# Generated at 2022-06-12 07:23:53.083831
# Unit test for function ok
def test_ok():
    with pytest.raises(IndexError):
        with ok(ZeroDivisionError):
            [][1]

    with ok(IndexError, ZeroDivisionError):
        [][1]

# Generated at 2022-06-12 07:23:53.921221
# Unit test for function ok

# Generated at 2022-06-12 07:23:58.028861
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with ok(TypeError, ZeroDivisionError):
        1 / 'a'
    with ok():
        1 / 'a'


# Task 1

# Generated at 2022-06-12 07:24:01.979270
# Unit test for function ok
def test_ok():
    try:
        with ok(IOError, IndexError):
            print('test is working')
            raise ValueError
    except IndexError:
        print('error')
    except ValueError:
        print('value error')


test_ok()

# Generated at 2022-06-12 07:24:05.005075
# Unit test for function ok
def test_ok():
    with ok():
        raise Exception()

    with raises(Exception):
        with ok(Exception):
            raise Exception()

    with raises(ValueError):
        with ok(Exception):
            raise ValueError()

# Generated at 2022-06-12 07:24:09.861948
# Unit test for function ok
def test_ok():
    with ok(TypeError, ZeroDivisionError):
        print('ok')

    try:
        with ok():
            print(1 / 0)
    except Exception as e:
        assert isinstance(e, ZeroDivisionError)
    else:
        assert False

    try:
        with ok(ValueError, TypeError):
            print(1 / 0)
    except Exception as e:
        assert isinstance(e, ZeroDivisionError)
    else:
        assert False


# Main test
if __name__ == '__main__':
    test_ok()

    print('OK!')

# Generated at 2022-06-12 07:24:16.103364
# Unit test for function ok
def test_ok():
    """
    Test function ok using mock library

    :return: None
    """

# Generated at 2022-06-12 07:24:17.200398
# Unit test for function ok
def test_ok():
    assert(isinstance(ok, GeneratorType))



# Generated at 2022-06-12 07:24:27.603369
# Unit test for function ok

# Generated at 2022-06-12 07:24:32.384055
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with ok(KeyError):
        {}['key']
    with ok(NameError):
        {}['key']
    with ok(ZeroDivisionError, NameError):
        {}['key']
        1 / 0
        assert False
    try:
        with ok(ZeroDivisionError, NameError):
            1 / 0
    except ZeroDivisionError:
        pass



# Generated at 2022-06-12 07:24:34.445614
# Unit test for function ok
def test_ok():
    try:
        with ok(ValueError):
            raise ValueError
        assert False
    except:
        assert True

# Generated at 2022-06-12 07:24:35.401542
# Unit test for function ok
def test_ok():
    with ok(ValueError, KeyError):
        pass
    # Do nothing
    assert True

# Generated at 2022-06-12 07:24:44.291210
# Unit test for function ok
def test_ok():
    assert ok(ValueError).__enter__() == None
    try:
        with ok(ValueError):
            raise ValueError
    except Exception as e:
        assert isinstance(e, ValueError) is True
    try:
        with ok(ValueError):
            raise SyntaxError
    except Exception as e:
        assert isinstance(e, ValueError) is False
        assert isinstance(e, SyntaxError) is True
    try:
        with ok(ValueError, TypeError):
            raise TypeError
    except Exception as e:
        assert isinstance(e, ValueError) is False
        assert isinstance(e, TypeError) is True

# Generated at 2022-06-12 07:24:47.609838
# Unit test for function ok
def test_ok():
    with ok():
        raise ValueError()
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with pytest.raises(ValueError):
        with ok(TypeError):
            raise ValueError()



# Generated at 2022-06-12 07:24:49.820642
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False

    with raises(ZeroDivisionError):
        w = 10 / 0

    with raises(TypeError):
        w = [1, 2, 3] + 5

# Generated at 2022-06-12 07:24:52.585188
# Unit test for function ok
def test_ok():
    """Test for context manager ok."""
    with ok(ValueError):
        print('ValueError')
        raise ValueError
    try:
        with ok(ValueError):
            print('TypeError')
            raise TypeError
    except Exception as e:
        print(e)

# Generated at 2022-06-12 07:24:55.255699
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception()
    with ok(IndexError, ValueError):
        raise ValueError()
    with ok(IndexError, ValueError):
        raise IndexError()



# Generated at 2022-06-12 07:24:58.250091
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception
    with ok(KeyError, IndexError):
        raise KeyError
    with ok(KeyError, IndexError):
        raise IndexError

    with ok(KeyError, IndexError):
        raise ValueError



# Generated at 2022-06-12 07:25:07.423752
# Unit test for function ok
def test_ok():
    with ok(AttributeError):
        print('This should raise attribute error')
    with ok(ValueError):
        raise ValueError()

# Generated at 2022-06-12 07:25:11.709021
# Unit test for function ok
def test_ok():
    with ok(AssertionError, TypeError):
        assert 1 == 0     # AssertionError exception is passed
    with ok(AssertionError, TypeError):
        raise TypeError  # TypeError exception is passed



# Generated at 2022-06-12 07:25:16.005735
# Unit test for function ok
def test_ok():
    """Test function ok."""
    try:
        with ok(Exception, e=False):
            raise Exception()
    except Exception:
        assert 0, "did not work"

    try:
        with ok(ValueError, e=False):
            raise Exception()
        assert 0, "did not work"
    except Exception:
        pass

# Generated at 2022-06-12 07:25:17.986264
# Unit test for function ok
def test_ok():
    """
    :return: True if test is passed
    """
    with ok(ValueError):
        x = int('Hello World')
    with ok(ValueError):
        x = int('Hello World')
    return True



# Generated at 2022-06-12 07:25:23.240097
# Unit test for function ok
def test_ok():
    class MyError(Exception):
        pass

    def do():
        with ok(MyError):
            print('do something')

    def test():
        with ok(TypeError, MyError):
            print('do something')

    do()
    try:
        test()
    except Exception as e:
        print(e)
    finally:
        print('test_ok done.')



# Generated at 2022-06-12 07:25:24.960076
# Unit test for function ok
def test_ok():
    with ok(ValueError, TypeError):
        int('')
    with ok(ValueError):
        int('')

# Generated at 2022-06-12 07:25:30.104678
# Unit test for function ok
def test_ok():
    with ok():
        print('ok')

    with ok(TypeError, NameError):
        print('ok')

    with ok(TypeError):
        print('ok')

    # raises exception
    try:
        with ok(KeyError, TypeError):
            {}['key']
    except KeyError:
        pass
    else:
        assert False


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:25:36.636208
# Unit test for function ok
def test_ok():
    with ok():
        pass

    with ok(ValueError):
        raise ValueError

    with ok(ValueError):
        pass

    with ok(ValueError, KeyError):
        pass

    with assert_raises(ZeroDivisionError):
        with ok(ValueError):
            raise ZeroDivisionError

    with assert_raises(ZeroDivisionError):
        with ok(ValueError, KeyError):
            raise ZeroDivisionError



# Generated at 2022-06-12 07:25:44.789144
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        x = int(input("your number: "))
        if x < 5:
            raise ValueError('x must not be less than 5')
        elif x > 10:
            raise ValueError('x must not be greater than 10')
        print(x)
    assert x >= 5
    assert x <= 10

    with ok(ValueError):
        x = int(input("your number: "))
        if x < 100:
            raise ValueError('x must not be less than 100')
        elif x > 200:
            raise ValueError('x must not be greater than 200')
        print(x)
    assert x >= 100
    assert x <= 200

    with ok(ValueError):
        x = int(input("your number: "))

# Generated at 2022-06-12 07:25:47.547456
# Unit test for function ok
def test_ok():
    """Function to test ok function."""
    with ok(KeyboardInterrupt):
        print("KeyboardInterrupt")
    print("Ok")



# Generated at 2022-06-12 07:26:03.612736
# Unit test for function ok
def test_ok():
    assert ok(Exception)


# Generated at 2022-06-12 07:26:04.996940
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception()



# Generated at 2022-06-12 07:26:15.952661
# Unit test for function ok
def test_ok():
    import random
    import string

    pre_existing_exception = _make_exception()
    prefix = ''.join(random.choice(string.ascii_lowercase)
                     for _ in range(random.randint(3, 10)))
    suffix = ''.join(random.choice(string.ascii_lowercase)
                     for _ in range(random.randint(3, 10)))
    raise_exception = _make_exception(
        prefix + pre_existing_exception.__name__ + suffix)
    passed_exception = _make_exception(
        prefix + pre_existing_exception.__name__ + suffix)


# Generated at 2022-06-12 07:26:16.898308
# Unit test for function ok
def test_ok():
    assert ok()



# Generated at 2022-06-12 07:26:21.352772
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(int('hello'))
    with ok(TypeError):
        print(int(1.5))
    with ok(TypeError):
        print('hello')
    with ok(TypeError):
        print(int('hello1'))

# Generated at 2022-06-12 07:26:26.480987
# Unit test for function ok
def test_ok():
    """Test for function ok."""
    with ok(ValueError):
        int('hello')
    try:
        with ok(ValueError):
            print([1, 2, 3][3])
    except IndexError:
        pass
    else:
        assert False, 'IndexError not raised'


if __name__ == '__main__':
    # import doctest
    # doctest.testmod()
    test_ok()

# Generated at 2022-06-12 07:26:30.844809
# Unit test for function ok
def test_ok():
    with ok(ValueError, TypeError):
        pass
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise IndexError
        # TypeError: IndexError not in (ValueError, TypeError)



# Generated at 2022-06-12 07:26:36.867080
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('hello')
    with ok(TypeError, ValueError):
        x = int('hello')
    with pytest.raises(NameError):
        with ok(TypeError, ValueError):
            x = int('hello')
    with ok(TypeError, ValueError):
        x = int('hello')
        raise NameError('b')
    with ok(TypeError, ValueError) as cm:
        int('hello')
        pytest.fail('This should not be reached')
    assert type(cm.exception) is TypeError



# Generated at 2022-06-12 07:26:42.744331
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        "No Exception should be raised"
        raise ValueError
    try:
        with ok(ValueError):
            raise KeyError
    except KeyError:
        assert True, "KeyError exception should be raised"
    try:
        with ok(ValueError):
            raise Exception
    except Exception:
        assert True, "ValueError exception should not be raised"


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-12 07:26:49.034613
# Unit test for function ok
def test_ok():
    with ok():
        assert True
    with ok(AssertionError, TypeError):
        assert True
        raise TypeError
    with ok(AssertionError):
        assert True
        raise TypeError
    with ok(AssertionError):
        raise AssertionError
    with ok(TypeError):
        raise TypeError
    with ok(AssertionError):
        assert False



# Generated at 2022-06-12 07:27:23.108342
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()

    with ok(IndexError):
        raise IndexError()

    with pytest.raises(TypeError):
        with ok(ValueError):
            raise TypeError()

    with pytest.raises(TypeError):
        with ok():
            raise TypeError()

# Generated at 2022-06-12 07:27:26.111332
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        pass

    with raises(TypeError):
        with ok(ValueError):
            raise TypeError()

    with ok():
        raise ValueError()

    with raises(ValueError):
        with ok():
            raise TypeError()



# Generated at 2022-06-12 07:27:29.333453
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int("hello")
    with ok(TypeError):
        int("hello")
    assert_raises(ValueError, int, "world")



# Generated at 2022-06-12 07:27:31.774771
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        'hello'.index('a')



# Generated at 2022-06-12 07:27:33.126677
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception



# Generated at 2022-06-12 07:27:37.067496
# Unit test for function ok
def test_ok():
    with ok():
        raise ValueError('foo')
    with ok(ValueError):
        raise ValueError('foo')

    with pytest.raises(ValueError):
        with ok(TypeError):
            raise ValueError('foo')



# Generated at 2022-06-12 07:27:39.848417
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False

    with raises(ZeroDivisionError):
        with ok(AssertionError):
            1 / 0



# Generated at 2022-06-12 07:27:42.598108
# Unit test for function ok
def test_ok():
    """Test function ok"""
    with ok():
        print("Context")

    with ok(FileNotFoundError):
        print("Context")

    print("End")


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-12 07:27:45.484259
# Unit test for function ok
def test_ok():
    with ok(TypeError, IndexError):
        raise TypeError()
    with raises(NameError):
        with ok(TypeError, IndexError):
            raise NameError()
test_ok()



# Generated at 2022-06-12 07:27:49.133561
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        pass
    raised = False
    try:
        with ok(ValueError):
            raise TypeError()
    except TypeError as e:
        raised = True
    assert raised

# Generated at 2022-06-12 07:28:52.910057
# Unit test for function ok
def test_ok():
    with ok():
        pass



# Generated at 2022-06-12 07:28:57.926894
# Unit test for function ok
def test_ok():
    """Test ok function."""
    # When incorrect exceptions are passed to ok, an error is returned
    with pytest.raises(ValueError, match='msg1'):
        with ok(IOError):
            raise ValueError('msg1')

    # When no exception is raised, ok() returns nothing
    with ok(ValueError):
        pass

    # When correct exception is raised, ok() returns nothing
    with ok(ValueError):
        raise ValueError('msg1')



# Generated at 2022-06-12 07:28:59.303826
# Unit test for function ok
def test_ok():
    try:
        with ok(OSError):
            raise OSError()
    except OSError:
        pass

# Generated at 2022-06-12 07:29:03.084061
# Unit test for function ok
def test_ok():
    """
    Test ok function
    """
    with ok(TypeError):
        1 + "2"

    with ok(TypeError):
        print("Hello")


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-12 07:29:07.573416
# Unit test for function ok
def test_ok():
    with ok():
        print('ok')
    with ok(TypeError):
        raise TypeError
    with ok(TypeError, ValueError):
        raise TypeError
    with ok(TypeError, ValueError):
        raise ValueError
    with ok(TypeError, ValueError):
        raise KeyError
    with ok():
        raise KeyError


if __name__ == '__main__':
    pass

# Generated at 2022-06-12 07:29:16.501554
# Unit test for function ok
def test_ok():
    """Test for OK function."""
    # Testing failure without exception
    try:
        with ok():
            raise ValueError()
    except Exception as e:
        assert type(e) is ValueError

    # Testing success with exception
    try:
        with ok(ValueError):
            raise ValueError()
    except Exception as e:
        assert False

    # Testing success with multiple exceptions
    try:
        with ok(ValueError, TypeError):
            raise TypeError()
    except Exception as e:
        assert False


# Driver code
if __name__ == '__main__':
    test_ok()

# This code is contributed by Shashank Mishra (admin)

# Generated at 2022-06-12 07:29:21.166634
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        pass
    with ok(TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        pass
    with ok(ValueError, TypeError):
        raise TypeError
    # Test exception ordering
    with raises(TypeError):
        with ok(ValueError, TypeError):
            raise TypeError
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError
    with raises(ValueError):
        with ok(TypeError):
            raise ValueError



# Generated at 2022-06-12 07:29:25.932289
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    error = None
    try:
        raise TypeError
    except TypeError as e:
        error = e
    with ok(TypeError):
        pass
    assert error is None
    with raises(AttributeError):
        with ok(TypeError):
            raise AttributeError


# Test class for ok

# Generated at 2022-06-12 07:29:29.573896
# Unit test for function ok
def test_ok():
    """Unit test to test context manager ok.
    """
    with ok(AssertionError):
        assert False
    with ok(TypeError, ValueError):
        int('hello')
    with raises(ZeroDivisionError):
        with ok(OSError):
            1/0



# Generated at 2022-06-12 07:29:38.538306
# Unit test for function ok
def test_ok():
    # Test case with no exception, should return ok
    with ok():
        pass

    # Test case with a predefined exception, should return ok for that one
    with ok(ValueError):
        raise ValueError

    # Test case with a predefined exception, should return ok for that one, but
    # not for another one
    with ok(ValueError):
        with pytest.raises(TypeError):
            raise TypeError

    # Test case with a predefined exception, should return ok for that one, but
    # not for two other ones
    with ok(ValueError):
        with pytest.raises(TypeError):
            raise TypeError
        with pytest.raises(IndexError):
            raise IndexError



# Generated at 2022-06-12 07:31:59.817183
# Unit test for function ok
def test_ok():
    with ok():
        pass

    with ok(AttributeError):
        {}.foo

    with pytest.raises(TypeError):
        with ok(AttributeError):
            int('a')


# Create a custom exception

# Generated at 2022-06-12 07:32:02.983186
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        1/0
    with ok(ValueError, TypeError):
        [][5] = 5
    with ok(ValueError, TypeError):
        {5:5}[{}] = 1


# Generated at 2022-06-12 07:32:05.919324
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int("Hello")

    with raises(ValueError):
        with ok(TypeError):
            int("Hello")



# Generated at 2022-06-12 07:32:08.637236
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        pass
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:32:13.040456
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        "{0}".format(1)
    with raises(TypeError):
        with ok():
            raise TypeError
    with ok(ValueError):
        raise TypeError()
    with raises(TypeError):
        with ok(TypeError):
            raise ValueError()



# Generated at 2022-06-12 07:32:16.110551
# Unit test for function ok
def test_ok():
    """
    Test function: ok()
    """
    try:
        with ok(IOError, HTTPError):
            raise IOError()
    except Exception:
        raise Exception('Wrong exception was raised')
    assert True



# Generated at 2022-06-12 07:32:24.920082
# Unit test for function ok
def test_ok():
    with ok(TypeError, ValueError):
        my_list = [1, 2, 3]
        print(my_list[5])
    with ok(TypeError, ValueError):
        my_list = [1, 2, 3]
        print(my_list[1])


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:32:27.028418
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with ok(Exception):
        pass

    with ok(TypeError):
        1 + '2'



# Generated at 2022-06-12 07:32:29.533496
# Unit test for function ok
def test_ok():
    with ok():
        raise ValueError('ok')
    with raises(ValueError):
        with ok(ValueError):
            raise ValueError('ok')
        raise TypeError('not ok')



# Generated at 2022-06-12 07:32:33.647530
# Unit test for function ok
def test_ok():
    """Test for ok"""

    def test_raises_exception():
        raise IOError('io error')

    def test_raises_error():
        # The following line deliberately triggers a SyntaxError.
        raise 'error'

    with ok(IOError):
        test_raises_exception()

    # In the following line, it is possible to catch both the
    # AssertionError and the SyntaxError.
    with ok(AssertionError, SyntaxError):
        test_raises_error()

