

# Generated at 2022-06-12 07:23:02.839517
# Unit test for function ok
def test_ok():
    assert ok(TypeError)
    with ok(TypeError):
        pass
    try:
        with ok(TypeError):
            raise ValueError
    except ValueError:
        pass
    else:
        assert False, 'Did not raise ValueError'
    try:
        with ok(TypeError):
            raise TypeError
    except TypeError:
        assert False, 'TypeError should be passed'



# Generated at 2022-06-12 07:23:06.753923
# Unit test for function ok
def test_ok():
    with ok(Exception):
        pass
    with ok(Exception):
        raise Exception
    with ok(KeyError):
        raise KeyError
    with ok():
        pass
    with ok():
        raise KeyError



# Generated at 2022-06-12 07:23:15.051991
# Unit test for function ok
def test_ok():
    with ok():
        1 / 0  # Raises ZeroDivisionError
    with ok(ZeroDivisionError, ValueError):
        1 / 0  # Raises ZeroDivisionError
    with ok(ZeroDivisionError, ValueError):
        foo = 'bar'
        int(foo)  # Raises ValueError
    with assert_raises(TypeError):
        with ok(ZeroDivisionError, ValueError):
            1 / 0  # Raises ZeroDivisionError
    with assert_raises(TypeError):
        with ok():
            foo = 'bar'
            int(foo)  # Raises ValueError



# Generated at 2022-06-12 07:23:19.322026
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with ok():
        raise AttributeError
    with ok(ValueError):
        raise AttributeError
    with ok(ValueError):
        raise ValueError
    with raises(AttributeError):
        with ok(ValueError):
            raise AttributeError



# Generated at 2022-06-12 07:23:21.457077
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int(None)



# Generated at 2022-06-12 07:23:26.730550
# Unit test for function ok
def test_ok():
    with ok(SystemExit):
        raise SystemExit
    with ok(SystemExit, ValueError, IndexError):
        raise SystemExit
    with ok(SystemExit, ValueError, IndexError) as cm:
        raise ValueError
    with ok(SystemExit, ValueError, IndexError) as cm:
        raise IndexError
    with raises(SystemError):
        with ok(SystemExit, ValueError, IndexError) as cm:
            raise SystemError

# Generated at 2022-06-12 07:23:38.497258
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        '''ok with TypeError'''
        print('ok with TypeError')
        a = {}
        b = {}
        a[1] = b[2]
    logging.info('pass ok with TypeError')
    with ok(TypeError, IndexError):
        '''ok with TypeError or IndexError'''
        print('ok with TypeError or IndexError')
        a = {}
        b = {}
        a[1] = b[2]
    logging.info('pass ok with TypeError or IndexError')
    try:
        '''ok without error'''
        print('ok without error')
        a = {}
        b = {}
        a[1] = b[1]
    except:
        logging.error('Failed ok without error')

# Generated at 2022-06-12 07:23:42.598200
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception()
    with raises(AttributeError):
        with ok(KeyError):
            raise AttributeError()
    #  print "OK. ok() works fine."

#  test_ok()

# Generated at 2022-06-12 07:23:46.600891
# Unit test for function ok
def test_ok():
    with ok(IndexError):
        raise IndexError
    with ok(IndexError, TypeError):
        raise TypeError
    with ok(IndexError, TypeError):
        pass
    with pytest.raises(ValueError):
        with ok(IndexError, TypeError):
            raise ValueError

# Generated at 2022-06-12 07:23:49.173836
# Unit test for function ok
def test_ok():
    """Test function ok."""
    x = None
    with ok(ValueError):
        int('N/A')

    with ok(ValueError):
        x = int('N/A')

    assert x is None

# Generated at 2022-06-12 07:23:57.022093
# Unit test for function ok
def test_ok():
    """
    Tests context_managers.ok
    """
    with ok(AttributeError):
        'a'.get_attribute()

    with ok(TypeError, ValueError):
        int('N/A')

    with raises(NameError):
        with ok(AttributeError):
            'a'.get_name()

    with raises(TypeError):
        with ok(AttributeError, ValueError):
            int('N/A')

    with raises(ValueError):
        with ok(AttributeError, TypeError):
            'a'.get_value()

# Generated at 2022-06-12 07:24:02.832947
# Unit test for function ok
def test_ok():
    a = 1
    try:
        with ok(IndexError):
            a = l[1]
    except TypeError:
        a = 2
    assert a == 2
    l = [1]
    try:
        with ok(IndexError):
            a = l[1]
    except IndexError:
        a = 3
    assert a == 3



# Generated at 2022-06-12 07:24:07.641594
# Unit test for function ok
def test_ok():
    """Test ok() context manager works properly."""
    # This element should be deleted when ok() is used
    with ok(ValueError):
        lst = [0, 1, 2, 3]  # noqa
    # This element should be deleted when ok() is used
    with ok(ValueError):
        a = '1234'  # noqa
        b = int(a)  # noqa
    assert 3 == 3



# Generated at 2022-06-12 07:24:12.422477
# Unit test for function ok
def test_ok():
    result = ""

    with ok(KeyError):
        result += "a"
        {}["b"]
        result += "c"

    assert result == "a", "The variable contains correct value"


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:24:15.384748
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        1 + "1"
    with ok(TypeError, ZeroDivisionError):
        1 + "1"



# Generated at 2022-06-12 07:24:18.250253
# Unit test for function ok
def test_ok():
    """Testing ok method."""
    with ok(ValueError):
        raise ValueError
    with ok(TypeError):
        raise TypeError
    with ok(TypeError, ValueError):
        raise ValueError



# Generated at 2022-06-12 07:24:21.943564
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError

    with ok(ValueError):
        raise KeyError  # Should not trigger

    with ok(KeyError, ValueError):
        raise KeyError

    with ok(KeyError, ValueError):
        raise ValueError

    # This one should trigger an exception
    with ok(KeyError, ValueError):
        raise Exception


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:24:24.175280
# Unit test for function ok

# Generated at 2022-06-12 07:24:24.924336
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False
    return True


assert test_ok()

# Generated at 2022-06-12 07:24:29.504812
# Unit test for function ok
def test_ok():

    # should raise an exception
    with ok():
        raise ValueError

    # should pass an exception
    with ok(ValueError):
        raise ValueError

    # should raise an exception
    with ok(TypeError):
        raise ValueError


# noinspection PyShadowingBuiltins

# Generated at 2022-06-12 07:24:36.819051
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print('Type error here')

    with ok(TypeError, ValueError):
        print('Type or value error here')

    with ok(TypeError, ValueError, NameError):
        print('Type or value or name error here')



# Generated at 2022-06-12 07:24:42.407615
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with pytest.raises(TypeError):
        with ok(TypeError, ValueError):
            raise TypeError
    with pytest.raises(TypeError):
        with ok(ValueError, TypeError):
            raise TypeError
    with pytest.raises(TypeError):
        with ok(ValueError):
            raise TypeError


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-12 07:24:45.770198
# Unit test for function ok
def test_ok():
    """Test the context manager ok()."""

# Generated at 2022-06-12 07:24:50.375483
# Unit test for function ok
def test_ok():
    # Test setup
    error_message = "The exception should still pop out"
    try:
        with ok(TypeError):
            raise IndexError("This is a demonstration error")
    except IndexError:
        pass
    except Exception:
        print(error_message)

    # Test execution
    try:
        with ok(TypeError):
            raise TypeError("This is a demonstration error")
    except Exception:
        print(error_message)



# Generated at 2022-06-12 07:24:53.284887
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(123 + 'str')
    assert 123 + 'str' == 123
    with raises(ZeroDivisionError):
        with ok(TypeError):
            print(1 / 0)
    assert 1 / 0 == 1


# print

# Generated at 2022-06-12 07:24:54.979176
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        raise TypeError

    with ok(TypeError):
        raise ValueError



# Generated at 2022-06-12 07:24:56.217463
# Unit test for function ok
def test_ok():
    """Test function ok."""
    pass


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:24:59.591261
# Unit test for function ok
def test_ok():
    """
    Test that the context manager correctly handles the exceptions.
    """
    with ok(TypeError, ValueError):
        raise TypeError("This raises a TypeError")
    with ok(ValueError):
        raise ValueError("This raises a ValueError")
    with ok():
        raise Exception("This raises an exception")



# Generated at 2022-06-12 07:25:03.176372
# Unit test for function ok
def test_ok():
    """Unit test function.
    """

# Generated at 2022-06-12 07:25:05.230079
# Unit test for function ok
def test_ok():
    with ok(IndexError):
        x = [1, 2, 3]
        y = x[3]
    assert True



# Generated at 2022-06-12 07:25:18.715033
# Unit test for function ok
def test_ok():
    """Unit test function for function ok."""
    with ok(TypeError):
        int("Hi")

    with ok(TypeError, IndexError, ValueError):
        int("Hi")

    with pytest.raises(ValueError):
        with ok(TypeError):
            int("Hello")

    with pytest.raises(AttributeError):
        with ok(TypeError):
            int("Hello").DoNotExist

    with pytest.raises(AttributeError):
        with ok(TypeError, AttributeError):
            int("Hello").DoNotExist



# Generated at 2022-06-12 07:25:24.872343
# Unit test for function ok
def test_ok():
    # Test ok
    with ok(ValueError):
        try:
            raise ValueError
        except:
            print('value error')
    # Test ok
    with ok(TypeError):
        try:
            raise TypeError
        except:
            print('type error')
    # Test ok
    with ok(OSError):
        try:
            raise OSError
        except:
            print('os error')


# Unit test
if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-12 07:25:29.273310
# Unit test for function ok
def test_ok():
    """ Unit testing the context manager."""
    try:
        with ok(NameError, TypeError):
            raise TypeError
        with ok(NameError, TypeError):
            raise NameError
        with ok(NameError, TypeError):
            raise ValueError
    except ValueError:
        return True
    raise False



# Generated at 2022-06-12 07:25:31.486399
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-12 07:25:34.967854
# Unit test for function ok
def test_ok():
    with ok(TypeError, ZeroDivisionError):
        print("Hello")
        print(1 / 0)
        print("World")


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:25:39.647311
# Unit test for function ok
def test_ok():
    """
    Unit Test for function ok
    :return: None
    """
    # Test that a ZeroDivisionError is caught
    with ok(ZeroDivisionError):
        print(1 / 0)

    # Test that a ZeroDivisionError is raised
    with raises(ZeroDivisionError):
        with ok(ValueError):
            print(1 / 0)


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:25:41.231217
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        a = int('one')
    assert True



# Generated at 2022-06-12 07:25:51.613330
# Unit test for function ok
def test_ok():
    """Test function ok."""
    # test ok()
    with ok():
        pass

    # test ok(int)
    with ok(int):
        raise ValueError("Ah ah ah, you didn't say the magic word.")

    # test ok(int, ZeroDivisionError)
    with ok(int, ZeroDivisionError):
        raise ValueError("Ah ah ah, you didn't say the magic word.")

    # test ok(int, ZeroDivisionError)
    with raises(ValueError):
        with ok(int, ZeroDivisionError):
            raise ValueError("Ah ah ah, you didn't say the magic word.")

    # test ok(int, ZeroDivisionError)
    with raises(ZeroDivisionError):
        with ok(int, ZeroDivisionError):
            raise ZeroDivisionError("Illegal divisor.")

   

# Generated at 2022-06-12 07:25:55.351617
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    try:
        with ok(TypeError):
            raise TypeError
    except:
        raise AssertionError("Context manager function ok is not operating")



# Generated at 2022-06-12 07:25:59.472038
# Unit test for function ok
def test_ok():
    """Test function ok."""
    # Attempt to remove a file that exists
    with ok(FileNotFoundError):
        os.remove('non_existent_file')
    # Attempt to remove a file that does not exist
    with pytest.raises(FileNotFoundError):
        with ok(NotImplementedError):
            os.remove('non_existent_file')



# Generated at 2022-06-12 07:26:20.121920
# Unit test for function ok
def test_ok():
    """Test function ok, directly."""
    with ok(TypeError):
        int('N/A')
    with ok(TypeError):
        int('123')

    with ok(TypeError):
        int('N/A')
    with ok(TypeError):
        raise NameError('Bob')



# Generated at 2022-06-12 07:26:24.551411
# Unit test for function ok
def test_ok():
    """
    Unit test for the contextmanager ok.
    """
    with ok(ValueError):
        print("Everything fine")
        raise ValueError("An error has occurred")

    with ok():
        print("Everything fine")
        raise Exception("an error has occurred")


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-12 07:26:26.532178
# Unit test for function ok
def test_ok():

    # Test function where error is raised
    with ok(TypeError):
        raise TypeError("Test TypeError")

    # Test function where error is not raised
    with ok(RuntimeError):
        pass



# Generated at 2022-06-12 07:26:28.259872
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False



# Generated at 2022-06-12 07:26:35.575683
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    def test_ok_raise():
        """Test function to raise exception."""
        with ok(ZeroDivisionError, TypeError):
            raise TypeError

    def test_ok_pass():
        """Test function to pass exception."""
        with ok(ZeroDivisionError, TypeError):
            raise ZeroDivisionError

    def test_ok_fail():
        """Test function to fail exception."""
        with ok(ZeroDivisionError, TypeError):
            raise IndexError

    assert test_ok_raise() is None
    assert test_ok_pass() is None
    with pytest.raises(IndexError):
        test_ok_fail()

# Generated at 2022-06-12 07:26:38.061123
# Unit test for function ok
def test_ok():
    """Unit test for function ok
    :return: None
    """
    with ok(ZeroDivisionError, TypeError):
        x = 1/0
    print("The test for ok finished")



# Generated at 2022-06-12 07:26:41.842097
# Unit test for function ok
def test_ok():
    with pytest.raises(Exception):
        with ok():
            raise Exception()

    with ok(Exception):
        raise Exception()

    with pytest.raises(Exception):
        with ok(ValueError):
            raise Exception()



# Generated at 2022-06-12 07:26:47.326734
# Unit test for function ok
def test_ok():
    with ok(TypeError, AttributeError):
        1 + '1'

    # Exception is raised
    with raises(TypeError):
        with ok(TypeError):
            1 + '1'

    # Exception is raised
    with raises(TypeError):
        with ok(TypeError, AttributeError):
            1 / 0



# Generated at 2022-06-12 07:26:47.964424
# Unit test for function ok
def test_ok():
    with ok(RuntimeError):
        raise IndexError

    with ok():
        raise IndexError



# Generated at 2022-06-12 07:26:55.736779
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print('ok({}) passed'.format(TypeError))
        raise TypeError
    with ok(TypeError):
        print('ok({}) passed'.format(TypeError))
    with ok(TypeError):
        print('ok({}) passed'.format(TypeError))
        raise ValueError
    with ok(TypeError, ValueError):
        print('ok({}, {}) passed'.format(TypeError, ValueError))
        raise ValueError
    with ok(TypeError, ValueError):
        print('ok({}, {}) passed'.format(TypeError, ValueError))
        raise KeyError
    try:
        with ok(TypeError):
            print('ok({}) passed'.format(TypeError))
            raise NameError
    except NameError as e:
        print('NameError raised')

# Generated at 2022-06-12 07:27:33.265047
# Unit test for function ok
def test_ok():
    with ok(ValueError, TypeError):
        int('test')

    # Correct exception handled internally
    with ok(ValueError, TypeError):
        raise ValueError()

    # Correct exception handled internally
    with ok(ValueError, TypeError):
        raise TypeError()

    # Incorrect exception passes through
    with pytest.raises(KeyError):
        with ok(ValueError, TypeError):
            raise KeyError()



# Generated at 2022-06-12 07:27:37.187054
# Unit test for function ok
def test_ok():
    try:
        with ok(None):
            raise RuntimeError("Test")
    except RuntimeError as e:
        assert "Test" == str(e)
    else:
        assert False

    with ok(None):
        pass



# Generated at 2022-06-12 07:27:40.136087
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False

    with raises(LookupError):
        with ok(AssertionError):
            assert False

    with ok(AssertionError, LookupError):
        assert False

# Generated at 2022-06-12 07:27:44.166540
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with ok(Exception):
        raise Exception()
    try:
        with ok(ValueError):
            raise Exception()
    except Exception as e:
        assert e.__class__ == Exception


# FIXME: This currently fails, for reasons I'm not sure about.
# @raises(AssertionError)

# Generated at 2022-06-12 07:27:45.797357
# Unit test for function ok
def test_ok():
    try:
        with ok(Exception):
            raise Exception
    except:
        assert False



# Generated at 2022-06-12 07:27:47.665784
# Unit test for function ok
def test_ok():
    """Test for context manager ok."""
    with ok(IOError):
        raise IOError('File not found')
    assert ok



# Generated at 2022-06-12 07:27:55.241411
# Unit test for function ok
def test_ok():
    """Test ok function."""
    # Pass None
    with ok():
        raise RuntimeError
        ok(RuntimeError)
        print('Should not get here.')
    # Pass singleton
    with ok(RuntimeError):
        raise RuntimeError
    assert True
    # Pass multiple
    with ok(ValueError, IOError):
        raise RuntimeError
    assert True
    # Fail the pass
    with pytest.raises(RuntimeError):
        with ok(ValueError, IOError):
            raise RuntimeError
    # Fail the raise
    with pytest.raises(ValueError):
        with ok():
            raise ValueError

# Generated at 2022-06-12 07:28:03.349174
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    pass_exception_1 = None
    pass_exception_2 = None

    @contextmanager
    def is_exceptions():
        global pass_exception_1
        global pass_exception_2

        try:
            yield
        except AttributeError as e:
            pass_exception_1 = e
        except Exception as e:
            pass_exception_2 = e

    with is_exceptions():
        with ok(AttributeError):
            raise AttributeError()

    with is_exceptions():
        with ok(ZeroDivisionError):
            pass

    with is_exceptions():
        with ok(ZeroDivisionError):
            raise ValueError()

    assert isinstan

# Generated at 2022-06-12 07:28:07.090409
# Unit test for function ok
def test_ok():
    try:
        with ok(TypeError):
            7 + '15'
    except:
        print('Type Error not allowed')


# code to run if called
if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:28:09.676248
# Unit test for function ok
def test_ok():
    with ok():
        pass

    with ok(ValueError):
        raise ValueError

    with raises(TypeError):
        with ok(ValueError):
            raise TypeError



# Generated at 2022-06-12 07:29:19.955269
# Unit test for function ok
def test_ok():
    """Test function ok."""
    print("-- Testing function ok...")
    with ok(ZeroDivisionError, TypeError) as expect:
        42 / 0
        '42' + 42
    print("-- Function ok works fine.")



# Generated at 2022-06-12 07:29:22.776835
# Unit test for function ok
def test_ok():
    print('Test ok()')
    with ok(Exception, AttributeError):
        raise Exception('1')
    try:
        with ok(Exception, AttributeError):
            raise TypeError
    except Exception as e:
        pass



# Generated at 2022-06-12 07:29:28.830674
# Unit test for function ok
def test_ok():
    sio = StringIO()
    with redirect_stdout(sio), ok(ValueError):
        print("Oi")

    assert sio.getvalue() == "Oi\n"

    with ok(ValueError):
        raise ValueError("Oh no")

    with assert_raises(SystemExit) as cm:
        with ok(ValueError):
            print("Oi")

    assert cm.exception.code == 0



# Generated at 2022-06-12 07:29:31.330886
# Unit test for function ok
def test_ok():
    with ok(FileNotFoundError):
        with open('file.ext') as f:
            return f.read()
        return 'file not found'



# Generated at 2022-06-12 07:29:35.432620
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')

    with ok(TypeError):
        int('N/A')  # Wrong exception is raised


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 07:29:38.467466
# Unit test for function ok
def test_ok():
    ok(AssertionError)
    with ok(AssertionError):
        raise AssertionError

    try:
        with ok(AssertionError):
            raise ValueError
    except ValueError:
        pass



# Generated at 2022-06-12 07:29:40.800125
# Unit test for function ok
def test_ok():
    def f(x):
        with ok(ValueError):
            int('a')
        return x
    assert 1 == f(1)



# Generated at 2022-06-12 07:29:44.999277
# Unit test for function ok
def test_ok():
    @ok(ZeroDivisionError)
    def divide(a, b):
        return a / b

    assert(divide(1, 1) == 1)
    assert(divide(1, 0))


if __name__ == '__main__':
    # Run unit tests
    test_ok()

# Generated at 2022-06-12 07:29:49.556672
# Unit test for function ok
def test_ok():
    with ok():
        pass
    with ok(ValueError):
        raise ValueError
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError



# Generated at 2022-06-12 07:29:53.423942
# Unit test for function ok
def test_ok():
    with ok(Exception):
        print("exception")

    class MyException(Exception):
        pass

    with ok(MyException):
        raise MyException

    with raises(Exception):
        with ok(MyException):
            raise Exception



# Generated at 2022-06-12 07:32:24.764692
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('hello')

    with ok(ValueError, TypeError):
        int(None)

    with ok(ValueError, TypeError):
        None + 0

    with pytest.raises(ZeroDivisionError):
        1 / 0



# Generated at 2022-06-12 07:32:32.436422
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    # Pass RuntimeError
    try:
        with ok(RuntimeError):
            raise RuntimeError
    except Exception:
        assert False  # Expected exception should not have been thrown

    # Pass ValueError
    try:
        with ok(ValueError):
            raise ValueError
    except Exception:
        assert False  # Expected exception should not have been thrown

    # Should raise TypeError
    try:
        with ok(RuntimeError):
            raise TypeError
    except TypeError:
        assert True
    except Exception:
        assert False  # Expected TypeError should have been thrown

    # Should raise RuntimeError
    try:
        with ok(ValueError):
            raise RuntimeError
    except RuntimeError:
        assert True
    except Exception:
        assert False  # Expected RuntimeError should have been thrown



# Generated at 2022-06-12 07:32:36.048335
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with raises(TypeError):
        with ok(ValueError):
            int(None)


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:32:39.203248
# Unit test for function ok
def test_ok():
    with ok(TypeError, AttributeError):
        foo()
    with ok(TypeError):
        foo()


# Unit tests for function ok
import unittest



# Generated at 2022-06-12 07:32:41.866884
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-12 07:32:45.762516
# Unit test for function ok
def test_ok():
    # Test for exception
    with pytest.raises(RuntimeError):
        with ok(ValueError):
            raise RuntimeError()

    # Test for not raising
    with ok():
        pass

    # Test for not raising
    with ok(RuntimeError):
        raise ValueError()

# Generated at 2022-06-12 07:32:47.597173
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        pass
    with ok(TypeError):
        raise TypeError



# Generated at 2022-06-12 07:32:49.054740
# Unit test for function ok
def test_ok():
    with ok(ArithmeticError):
        1/0
    assert True



# Generated at 2022-06-12 07:32:54.053723
# Unit test for function ok
def test_ok():
    """Test function of context manager ok"""
    with ok(ValueError):
        x = int('6')
        assert type(x) is int
    with ok:
        x = int('a')
        assert type(x) is int
    with raises(ValueError), ok:
        int('c')



# Generated at 2022-06-12 07:32:57.596418
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False

    with pytest.raises(TypeError):
        with ok(AssertionError):
            raise TypeError("Boom!")

