

# Generated at 2022-06-12 07:23:02.484256
# Unit test for function ok
def test_ok():
    """Test the ok function
    """
    with ok(TypeError, ValueError):
        result = int('1')
    assert result == 1

    with ok(TypeError, ValueError):
        result = int('foo')
    assert result == 42
    assert False


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:23:08.450295
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(TypeError, ValueError):
        '{}'.format(1)
        try:
            raise TypeError()
        except TypeError as e:
            pass
        '{}'.format(2)
    try:
        with ok(TypeError, ValueError):
            raise Exception()
    except Exception:
        pass



# Generated at 2022-06-12 07:23:12.681270
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        print('1')
        raise ValueError
    print('2')
    with ok(TypeError):
        print('3')
        raise ValueError
    print('4')


if __name__ == '__main__':
    print('Testing ok()')
    test_ok()

# Generated at 2022-06-12 07:23:16.795970
# Unit test for function ok
def test_ok():
    with ok(ValueError, TypeError):
        int(None)
    with ok(TypeError):
        int(None)


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:23:20.462664
# Unit test for function ok
def test_ok():
    from mock import Mock

    with ok(ValueError):
        Mock()()

    with ok(Exception):
        Mock()()

    try:
        with ok(ValueError):
            Mock()(Exception())
    except Exception:
        pass

# Generated at 2022-06-12 07:23:25.549557
# Unit test for function ok
def test_ok():
    assert ok().__enter__() is None
    assert ok(ValueError).__enter__() is None
    assert ok().__exit__(None, None, None) is None
    assert ok(ValueError).__exit__(
        ValueError(""), None, None) is None
    with assert_raises(RuntimeError):
        with ok(ValueError):
            raise RuntimeError()

# Generated at 2022-06-12 07:23:28.277427
# Unit test for function ok
def test_ok():
    with ok(FileNotFoundError):
        open("invalid_file")


if __name__ == "__main__":
    test_ok()
    # with ok():
    #     open("invalid_file")

# Generated at 2022-06-12 07:23:33.831291
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0

    with ok():
        raise ValueError()
    with ok(ZeroDivisionError):
        1 / 0
    with raises(ValueError):
        with ok(ZeroDivisionError):
            raise ValueError()



# Generated at 2022-06-12 07:23:35.877163
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        3 / 0
    with ok(TypeError, ZeroDivisionError):
        3 / 0



# Generated at 2022-06-12 07:23:38.238604
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        print("Error")
        raise TypeError("This is not an error")

test_ok()




# Generated at 2022-06-12 07:23:44.346535
# Unit test for function ok
def test_ok():
    @ok(ZeroDivisionError)
    def div(a, b):
        return a / b

    assert div(1, 2) == 0.5
    assert div(1, 0)
    try:
        div('1', 2)
    except TypeError as e:
        assert(e)



# Generated at 2022-06-12 07:23:52.528970
# Unit test for function ok
def test_ok():

    # Test cases:
        # Raise exception
        try:
            # with ok(TypeError):
                # print('Raise a TypeError')
                # raise TypeError()
            with ok(AssertionError):
                print('Raise an AssertionException')
                raise AssertionError()
        except:
            print('Caught TypeError')

        # Pass exceptions
        try:
            with ok(TypeError, AssertionError):
                print('Raise an AssertionError')
                raise AssertionError()
        except:
            print('Caught something')

if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:23:55.430810
# Unit test for function ok
def test_ok():
    """Tests the functionality of ok context manager."""
    with ok(AssertionError):
        assert False

    with raises(KeyError):
        with ok(AssertionError):
            {0: 1}[1]



# Generated at 2022-06-12 07:23:57.671467
# Unit test for function ok
def test_ok():
    """Test function ok."""
    assert ok((TypeError))



# Generated at 2022-06-12 07:24:01.709758
# Unit test for function ok
def test_ok():
    with ok():
        1/0
        assert False, "여기는 실행되지 않게 해야 함"
    assert True


# Generated at 2022-06-12 07:24:06.033989
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(4 + 'a')
    with ok(TypeError):
        print('hi')
    with ok(TypeError):
        print(1 + 'a')
    try:
        with ok(TypeError):
            1 + 3
    except:
        print('ok!')



# Generated at 2022-06-12 07:24:09.021383
# Unit test for function ok
def test_ok():
    with ok(ValueError, IndexError):
        d = {}
        d[3]
        1 / 0

    try:
        with ok(ValueError):
            d = {}
            d[3]
    except IndexError:
        return 'Exception raised in with block'
    else:
        raise AssertionError



# Generated at 2022-06-12 07:24:14.848749
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with ok(AssertionError):
        assert True == False

    with ok(AssertionError):
        assert True == False, "Some error message"

    with ok(AssertionError):
        raise AssertionError("Some error message")


###
# Context manager that keeps track of time
###
import time


# Generated at 2022-06-12 07:24:19.148305
# Unit test for function ok
def test_ok():
    with ok():
        pass
    with ok(ZeroDivisionError):
        raise ZeroDivisionError
    try:
        with ok(ZeroDivisionError):
            raise TypeError
    except TypeError:
        pass
    else:
        raise Exception("Catched incorrect exception")


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-12 07:24:21.309737
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('python')
    with ok(ValueError, TypeError):
        int('python')



# Generated at 2022-06-12 07:24:24.175355
# Unit test for function ok
def test_ok():
    with ok():
        pass



# Generated at 2022-06-12 07:24:26.330546
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    try:
        with ok(ValueError):
            1 / 0
    except ArithmeticError:
        pass
    else:
        assert False, "with ok(ZeroDivisionError): 1 / 0 should raise " \
                      "ArithmeticError"
    try:
        with ok(TypeError):
            1 / 0
    except ArithmeticError:
        assert False, "with ok(TypeError): 1 / 0 should not raise " \
                      "ArithmeticError"



# Generated at 2022-06-12 07:24:30.345017
# Unit test for function ok
def test_ok():
    logger = logging.getLogger(__name__)
    try:
        with ok(ValueError):
            logger.info("Raise ValueError")
            raise ValueError('Invalid val')
    except Exception as e:
        logger.error(e)



# Generated at 2022-06-12 07:24:35.704076
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError("OK1")

    with ok(TypeError):
        raise ValueError("Error1")

    with ok(TypeError, ValueError):
        raise ValueError("OK2")

    with ok(TypeError, ValueError):
        raise TypeError("OK3")

    with ok(TypeError, ValueError):
        raise RuntimeError("Error2")


test_ok()

# Generated at 2022-06-12 07:24:44.197247
# Unit test for function ok
def test_ok():
    with ok():
        raise TypeError
    with ok(TypeError):
        raise TypeError
    try:
        with ok(NameError):
            raise TypeError
    except TypeError:
        pass
    else:
        assert False, 'Did not see TypeError'


# Part 2: Repeat after me
# Create a @repeat(num_times) decorator, that makes the decorated function run
# num_times times. For example:
# @repeat(3)
# def f():
#    print "Testing!"
# Then:
# f()
# Testing!
# Testing!
# Testing!

# Generated at 2022-06-12 07:24:46.634270
# Unit test for function ok
def test_ok():
    with ok(TypeError, ValueError):
        a = "abcd"
        int(a)
    with ok(ValueError):
        a = "abcd"
        int(a)



# Generated at 2022-06-12 07:24:48.615010
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()

    with ok(ValueError):
        raise TypeError()

    with ok(ValueError):
        raise IOError()



# Generated at 2022-06-12 07:24:50.526317
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with pytest.raises(KeyError):
        with ok(TypeError, ValueError):
            {}['key']



# Generated at 2022-06-12 07:24:58.091120
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    try:
        with ok(FileNotFoundError):
            raise FileNotFoundError
    except Exception as e:
        raise AssertionError("test_ok_1 failed.")
    try:
        with ok(FileNotFoundError):
            raise FileExistsError
    except FileNotFoundError:
        raise AssertionError("test_ok_2 failed.")
    try:
        with ok(FileNotFoundError):
            raise TypeError
    except TypeError:
        pass
    else:
        raise AssertionError("test_ok_3 failed.")
    try:
        with ok():
            raise FileExistsError
    except FileExistsError:
        pass
    else:
        raise AssertionError("test_ok_4 failed.")



# Generated at 2022-06-12 07:25:02.843318
# Unit test for function ok
def test_ok():
    """Test function for context manager ok."""
    # Tests for NotImplementedError, AttributeError
    with ok(NotImplementedError, AttributeError):
        raise NotImplementedError
    with ok(NotImplementedError, AttributeError):
        raise AttributeError
    # Test for NameError
    with ok(NotImplementedError, AttributeError):
        raise NameError



# Generated at 2022-06-12 07:25:08.992438
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception
    with ok(Exception):
        raise TypeError
    with ok(Exception, TypeError):
        raise TypeError

    try:
        with ok(TypeError):
            raise ValueError
    except ValueError:
        pass



# Generated at 2022-06-12 07:25:16.930903
# Unit test for function ok
def test_ok():
    @ok()
    def test_function():
      
        with raises(Exception):
            raise Exception()
        
        with raises(Exception):
            'some value'.value
            
    @ok(KeyError, ValueError)
    def test_function():
        with raises(Exception):
            raise Exception()
        
        with raises(KeyError):
            'some value'.value


# How to use it

#@ok(KeyError, ValueError)
#def test_function():
#    with raises(Exception):
#        raise Exception()
#    
#    with raises(KeyError):
#        'some value'.value
        
#test_function()

# Generated at 2022-06-12 07:25:20.335047
# Unit test for function ok
def test_ok():
    """Test the context manager ok.
    """
    with ok():
        pass
    with ok(Exception):
        raise Exception
    with ok(ValueError):
        raise ValueError
    with pytest.raises(ValueError):
        with ok(TypeError):
            raise ValueError
    with pytest.raises(ValueError):
        with ok(Exception):
            raise ValueError



# Generated at 2022-06-12 07:25:30.013386
# Unit test for function ok
def test_ok():
    try:
        with ok(NameError):
            print('Ran "raise NameError()"')
            raise NameError()  # This will be passed
    except NameError:
        print('We caught the exception passed by "with ok"')
    print('Running "with ok(ValueError):"')
    with ok(ValueError):
        pass
    try:
        with ok(ValueError):
            print('Raise ValueError!')
            raise ValueError()
    except ValueError:
        print('We caught the exception passed by "with ok"')
    print('Running "with ok(ValueError):"')
    with ok(ValueError):
        pass

# Generated at 2022-06-12 07:25:36.141051
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print (1, 1)

# Generated at 2022-06-12 07:25:39.407185
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print('ok')

    with ok(TypeError, ValueError):
        print('with 2 exceptions')

    with ok((TypeError, ValueError)):
        print('with 2 exceptions')



# Generated at 2022-06-12 07:25:41.569452
# Unit test for function ok
def test_ok():
    """Raise error if no exception is passed.
    """
    with pytest.raises(ValueError):
        with ok():
            raise ValueError



# Generated at 2022-06-12 07:25:48.536659
# Unit test for function ok
def test_ok():
    with ok(PermissionError):
        raise PermissionError
    with ok(PermissionError, FileNotFoundError):
        raise FileNotFoundError
    with ok(FileNotFoundError, PermissionError):
        raise PermissionError
    with ok(PermissionError):
        raise FileNotFoundError


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-12 07:25:51.144291
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        raise TypeError("This error should be passed")
    try:
        with ok(TypeError):
            raise ValueError("This error should not be caught")
    except ValueError as e:
        print(e)

# Generated at 2022-06-12 07:25:54.290113
# Unit test for function ok
def test_ok():
    with pytest.raises(ValueError):
        with ok(ValueError):
            raise ValueError()
    with ok(TypeError):
        raise TypeError()



# Generated at 2022-06-12 07:26:00.316761
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise KeyError
    with ok(ValueError, TypeError):
        int('N/A')
    with ok(ValueError, TypeError):
        raise KeyError



# Generated at 2022-06-12 07:26:03.421564
# Unit test for function ok
def test_ok():
    try:
        with ok(ValueError):
            int('a')
    except Exception as e:
        assert isinstance(e, TypeError)



# Generated at 2022-06-12 07:26:10.301416
# Unit test for function ok
def test_ok():
    try:
        with ok(IndexError, TypeError):
            'papaya'.index('p')
    except ValueError:
        assert True
    else:
        assert False

    with ok(IndexError, TypeError):
        ['papaya'].index(0)
    assert True

    with ok(IndexError):
        'papaya'.index('p')
    assert True

    try:
        with ok(TypeError):
            ['papaya'].index(0)
    except IndexError:
        assert True
    else:
        assert False



# Generated at 2022-06-12 07:26:12.120967
# Unit test for function ok
def test_ok():
    with pytest.raises(ZeroDivisionError):
        with ok(ZeroDivisionError):
            1 / 0

# Generated at 2022-06-12 07:26:15.238113
# Unit test for function ok
def test_ok():
    with ok(NameError):
        foo = bar
        assert True
    with ok(TypeError, NameError):
        print(1 + '1')
        assert True
    with ok(TypeError, NameError):
        print(1 + '1')
        print(foo)



# Generated at 2022-06-12 07:26:18.512882
# Unit test for function ok
def test_ok():
    with ok(VaultError):
        raise VaultError

    try:
        with ok(TypeError):
            raise AssertionError
    except AssertionError:
        pass



# Generated at 2022-06-12 07:26:22.644952
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with ok(TypeError, ValueError):
        raise TypeError()
    with ok(TypeError, ValueError):
        raise ValueError()
    with raises(OSError):
        with ok(TypeError, ValueError):
            raise OSError()



# Generated at 2022-06-12 07:26:25.734792
# Unit test for function ok
def test_ok():
    with ok():
        pass

    with ok(ZeroDivisionError):
        pass
    try:
        with ok(ZeroDivisionError):
            raise NameError
    except NameError:
        pass


test_ok()



# Generated at 2022-06-12 07:26:34.680114
# Unit test for function ok
def test_ok():
    with ok(*[TypeError, IndexError]):
        print('Type error occurred')
        raise TypeError
        print('This sentence will never be printed')
    try:
        with ok(*[TypeError]):
            print('Type error occurred')
            raise IndexError
            print('This sentence will never be printed')
    except IndexError:
        pass


# IMPORTANT NOTE: The material introduced in this script is not
# covered in the video communication session. It is only here to
# allow you to learn a bit on your own if you want.

# You do NOT need to understand the code below to solve this exercise!

if __name__ == '__main__':
    import sys
    import pytest

    raise SystemExit(pytest.main([__file__] + sys.argv[1:]))

# Generated at 2022-06-12 07:26:40.122897
# Unit test for function ok
def test_ok():
    """Test for the ok() context manager."""
    try:
        with ok(TypeError):
            5 + '5'
    except TypeError as e:
        pass
    else:
        print("Something went wrong.")
    try:
        with ok(TypeError):
            5 + 5
    except TypeError as e:
        print("Something went wrong:", e)
    else:
        pass

# Generated at 2022-06-12 07:26:52.546615
# Unit test for function ok
def test_ok():
    """Test for function ok."""
    # No exception: no error
    with ok(RuntimeError, MemoryError):
        pass
    # Good exception: no error
    with ok(RuntimeError, MemoryError):
        raise RuntimeError("it's ok")
    # Bad exception: error
    try:
        with ok(RuntimeError, MemoryError):
            raise ValueError("it's not ok")
    except ValueError:
        pass



# Generated at 2022-06-12 07:26:53.907719
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        a = 5 + "Hello"
    assert a == "5Hello"



# Generated at 2022-06-12 07:26:57.830387
# Unit test for function ok

# Generated at 2022-06-12 07:27:05.259617
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        1 + "1"
    with ok(TypeError, NameError):
        print(a)
    with ok(TypeError, NameError):
        1 + "1"
    with ok(TypeError, NameError):
        print(a)
    with raises(NameError):
        with ok(TypeError, NameError):
            print(a)
    with raises(TypeError):
        with ok(NameError, TypeError):
            1 + "1"

    with raises(TypeError, match="str"):
        with ok(TypeError, NameError):
            "1" + 1



# Generated at 2022-06-12 07:27:08.595840
# Unit test for function ok
def test_ok():
    with ok():
        pass

    with ok(TypeError):
        print("hello")

    with ok(TypeError):
        int("1")

    with ok(TypeError):
        1 + 'a'



# Generated at 2022-06-12 07:27:09.906521
# Unit test for function ok
def test_ok():
    with ok(Exception):
        pass



# Generated at 2022-06-12 07:27:12.121594
# Unit test for function ok
def test_ok():
    with pytest.raises(ZeroDivisionError):
        with ok(KeyError, ValueError):
            1/0

    with ok(TypeError):
        1 / 0

# Generated at 2022-06-12 07:27:17.665868
# Unit test for function ok
def test_ok():
    assert list(ok(ValueError)(list(range(1, -5, -1)))) == [1, 0, -1, -2, -3, -4]
    assert list(ok(ValueError, IndexError)(list(range(1, -5, -1)))) == [1, 0, -1, -2, -3, -4]


# Unit tests for function monad

# Generated at 2022-06-12 07:27:21.152621
# Unit test for function ok
def test_ok():
    with ok():
        pass

    with ok(ValueError):
        raise ValueError
    with pytest.raises(TypeError):
        with ok(TypeError):
            raise ValueError



# Generated at 2022-06-12 07:27:25.915796
# Unit test for function ok
def test_ok():
    try:
        with ok(AssertionError):
            assert False
    except AssertionError:
        pass

    try:
        with ok(AssertionError):
            raise KeyError
    except KeyError:
        pass

    try:
        with ok(AssertionError):
            raise KeyError('xx')
    except KeyError:
        pass



# Generated at 2022-06-12 07:27:42.393262
# Unit test for function ok
def test_ok():
    """Unit test
    """
    with ok(TypeError):
        print("Hello")



# Generated at 2022-06-12 07:27:49.761219
# Unit test for function ok
def test_ok():
    """ Tests the context manager ok(...)
    """
    # create list of exceptions
    exceptions = [ValueError, AttributeError]

    # assert ok(...) context manager correctly raises exception
    with pytest.raises(AttributeError):
        with ok(*exceptions):
            raise AttributeError

    # assert ok(...) context manager correctly ignores exception
    with ok(*exceptions):
        raise ValueError

    # assert ok(...) context manager correctly raises exception (other than ValueError)
    with pytest.raises(NameError):
        with ok(*exceptions):
            raise NameError


# Sample function to test

# Generated at 2022-06-12 07:27:52.223571
# Unit test for function ok
def test_ok():
    with raises(TypeError):
        with ok():
            raise TypeError

    with raises(AttributeError):
        with ok(TypeError):
            raise AttributeError

# Generated at 2022-06-12 07:28:01.853317
# Unit test for function ok
def test_ok():
    assert ok(TypeError).__enter__() is None
    with ok(TypeError):
        pass
    with ok(TypeError, IndexError):
        pass

    def f():
        raise TypeError

    def g():
        raise IndexError

    def h():
        raise ValueError

    assert hasattr(ok(TypeError).__exit__, '__call__')
    assert ok(TypeError).__exit__(None, None, None) is None
    assert ok(TypeError).__exit__(TypeError, None, None) is None
    assert ok(TypeError).__exit__(IndexError, None, None) is None
    assert ok(TypeError).__exit__(ValueError, None, None) is True

    with ok(TypeError):
        f()

# Generated at 2022-06-12 07:28:09.604997
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with ok(ValueError):
        raise ValueError('should not be raised')
    with ok(ValueError):
        raise TypeError('should be raised')
    with ok():
        raise ValueError('should be raised')
    with ok(ValueError):
        with ok(TypeError):
            raise ValueError('should not be raised')
        raise TypeError('should not be raised')
    with ok(TypeError):
        with ok(ValueError):
            raise TypeError('should be raised')
    with ok(ValueError):
        with ok(TypeError):
            raise TypeError('should be raised')


# ----------------------------------------------------------------------
# Test decorators
# ----------------------------------------------------------------------



# Generated at 2022-06-12 07:28:15.800548
# Unit test for function ok
def test_ok():
    with ok(TypeError, ZeroDivisionError):
        a = 10/0
    with ok(TypeError, ZeroDivisionError):
        a = [] + {}
    with ok(TypeError, ZeroDivisionError):
        a = {} + []


# Task 2. Context manager that implements the functionality of the with statement.

# Generated at 2022-06-12 07:28:19.771015
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    # type: () -> None
    with ok(Exception):
        raise Exception
    try:
        with ok(ValueError):
            raise Exception
        with ok():
            raise Exception
        with ok(ValueError):
            raise ValueError
            raise Exception
    except Exception:
        assert True
    else:
        assert False



# Generated at 2022-06-12 07:28:26.754555
# Unit test for function ok
def test_ok():
    """Test for ok context manager."""
    with ok(IndexError):
        l = list()
        l[1] = 1

    try:
        with ok(IndexError):
            l = list()
            l[1] = 1
            l[2] = 2
            l[3] = 3
    except IndexError:
        pass

    try:
        with ok(IndexError):
            l = list()
            l[1] = 1
            l[2] = 2
            l[3] = 3
            raise ValueError
    except ValueError:
        pass


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:28:29.714528
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    try:
        with ok(ValueError):
            raise TypeError
    except Exception as e:
        assert isinstance(e, TypeError)



# Generated at 2022-06-12 07:28:37.733450
# Unit test for function ok
def test_ok():
    """
    Function to use ok() context manager.
    """
    try:
        with ok(ValueError, TypeError):
            raise Exception('Some exception')
    except:
        print('Exception was raised')
    else:
        print('No exception raised')
    try:
        with ok(ValueError, TypeError):
            ls = [3, '4', 2, 3]
            for item in ls:
                print(1/int(item))
    except ValueError:
        print('ValueError detected')


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:29:13.836748
# Unit test for function ok
def test_ok():
    def div0(n, m):
        return n / m

    def div1(n, m):
        with ok(ZeroDivisionError):
            return n / m

    assert div0(8, 0) == None
    assert div1(8, 0) == None

# Generated at 2022-06-12 07:29:16.022965
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        1 + "1"
    assert ok(TypeError)



# Generated at 2022-06-12 07:29:18.567878
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int("whoops")
    with ok(TypeError, ValueError):
        int("whoops")


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:29:20.125574
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    assert ok



# Generated at 2022-06-12 07:29:25.974540
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')  # Raises ValueError
        print('Error passed')
    with ok(TypeError):
        int('kevin')  # Raises TypeError
        print('Error passed')
    with ok(NameError):
        int('N/A')  # Still raises ValueError
        print('Error passed')


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:29:28.696812
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        raise TypeError

    try:
        with ok(TypeError):
            raise ValueError
    except ValueError:
        return True
    else:
        return False



# Generated at 2022-06-12 07:29:30.138412
# Unit test for function ok
def test_ok():
    with ok(KeyError):
        {}['a']



# Generated at 2022-06-12 07:29:36.642776
# Unit test for function ok
def test_ok():
    with ok(ValueError, TypeError):
        raise ValueError('ValueError is OK')
    with ok(ValueError, TypeError):
        raise TypeError('TypeError is OK')
    with pytest.raises(AssertionError) as e:
        with ok(ValueError, TypeError):
            raise AssertionError('AssertionError is not OK')
    assert str(e.value) == 'AssertionError is not OK'



# Generated at 2022-06-12 07:29:44.560604
# Unit test for function ok
def test_ok():
    """Test the function ok."""
    with ok():
        pass
    with ok(NameError):
        raise NameError("NameError exception")
    with ok(AttributeError):
        raise AttributeError("AttributeError exception")
    with ok(ValueError):
        raise ValueError("ValueError exception")
    with ok(TypeError):
        raise TypeError("TypeError exception")
    with raises(AssertionError):
        with ok(AttributeError):
            raise AssertionError("AssertionError exception")



# Generated at 2022-06-12 07:29:49.454251
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with ok():
        raise IndexError()

    with ok(TypeError, IndexError):
        raise IndexError()

    with ok(TypeError):
        raise IndexError()



# Generated at 2022-06-12 07:31:04.598720
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0



# Generated at 2022-06-12 07:31:08.819277
# Unit test for function ok
def test_ok():
    try:
        with ok(ValueError, TypeError):
            int('123')
    except NameError:
        assert False
    try:
        with ok(ValueError, TypeError):
            int('foo')
        assert False
    except ValueError:
        pass



# Generated at 2022-06-12 07:31:11.277205
# Unit test for function ok
def test_ok():
    with ok(Exception):
        print("Test")
    try:
        with ok(KeyError):
            raise Exception
    except Exception:
        print("Exception raised")

# Generated at 2022-06-12 07:31:14.414818
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with pytest.raises(AssertionError):
        for i in [1, 2, 3, 4]:
            with ok(ValueError):
                i  # pylint: disable=unused-variable



# Generated at 2022-06-12 07:31:17.383117
# Unit test for function ok
def test_ok():
    with ok():
        raise Exception
    with ok():
        raise Exception
    with ok(Exception):
        raise Exception
    with ok(TypeError):
        pass
    with ok(Exception, TypeError):
        raise TypeError



# Generated at 2022-06-12 07:31:20.476608
# Unit test for function ok
def test_ok():
    """Test ok() context manager."""
    with ok():
        pass
    with raises(TypeError):
        with ok(TypeError):
            raise NameError('\nWrong exception raised.')



# Generated at 2022-06-12 07:31:23.321278
# Unit test for function ok
def test_ok():
    import urllib2

    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise urllib2.URLError('Something happened')

# Generated at 2022-06-12 07:31:24.502300
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception("Test OK!")
    with ok(ValueError):
        raise Exception("Test NOT OK!")



# Generated at 2022-06-12 07:31:30.463838
# Unit test for function ok
def test_ok():
    with ok(KeyError):
        dict_ = {"a": 1, "b": 2}
        dict_.pop("c")
        assert True, "Context manager ok() ignored KeyError"
    with raises(NameError):
        with ok(KeyError):
            dict_ = {"a": 1, "b": 2}
            dict_.pop("c")
            raise NameError("Raising NameError")



# Generated at 2022-06-12 07:31:35.375608
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(TypeError, ValueError):
        raise TypeError
    with ok(TypeError, ValueError):
        raise ValueError

    with pytest.raises(ZeroDivisionError):
        with ok():
            1 / 0

