

# Generated at 2022-06-12 07:22:57.993915
# Unit test for function ok
def test_ok():
    with ok(Exception) as cm:
        foo()



# Generated at 2022-06-12 07:23:02.158841
# Unit test for function ok
def test_ok():
    """Test for function ok"""
    @ok(IndexError)
    def test_ok():
        return [][1]

    test_ok()
    with pytest.raises(ZeroDivisionError):
        @ok(IndexError)
        def test_ok():
            return 1 / 0



# Generated at 2022-06-12 07:23:10.118904
# Unit test for function ok
def test_ok():
    with ok(TypeError, IndexError):
        [][3]
        dict()[5]
        'a' + 1
    with ok(TypeError):
        [][3]
        dict()[5]
        int('a')
    with ok(ValueError):
        dict()[5]
        int('q')
    with ok(IndexError):
        int('a')
        [][6]
    with ok(StopIteration, StopIteration):
        it = iter(())
        next(it)
        [][6]

# Generated at 2022-06-12 07:23:12.450119
# Unit test for function ok
def test_ok():
    with ok(*[IOError]):
        raise IOError()
    with ok(*[IOError, NameError]):
        raise IOError()
    with ok(*[IOError, NameError]):
        raise NameError()
    try:
        with ok(*[IOError]):
            raise AssertionError()
        assert False  # Should not be reached
    except AssertionError as e:
        pass



# Generated at 2022-06-12 07:23:18.493859
# Unit test for function ok
def test_ok():
    """Test function ok."""

    try:
        with ok():
            raise NameError

    except NameError:
        pass
    else:
        raise AssertionError

    try:
        with ok(NameError):
            raise NameError

    except NameError:
        raise AssertionError

    try:
        with ok(AttributeError):
            raise NameError

    except NameError:
        pass



# Generated at 2022-06-12 07:23:20.970321
# Unit test for function ok
def test_ok():
    """Test function ok"""
    with ok(ValueError):
        value = int('hello')
        print(value)
    return True



# Generated at 2022-06-12 07:23:22.258453
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError



# Generated at 2022-06-12 07:23:26.787901
# Unit test for function ok
def test_ok():
    with pytest.raises(ZeroDivisionError):
        with ok(TypeError, ValueError):
            1 / 0

    with pytest.raises(ValueError):
        with ok(TypeError):
            raise ValueError

    with ok(TypeError):
        pass

# Generated at 2022-06-12 07:23:31.267783
# Unit test for function ok
def test_ok():
    with ok(ValueError, NameError):
        raise ValueError

    with ok(ValueError, NameError):
        raise NameError

    with pytest.raises(TypeError):
        with ok(ValueError, NameError):
            raise TypeError



# Generated at 2022-06-12 07:23:33.046372
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception



# Generated at 2022-06-12 07:23:37.817616
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print("This is Exception, but it's OK!")
    with raises(ZeroDivisionError):
        print("This is Exception and it's NOT OK!")



# Generated at 2022-06-12 07:23:39.747595
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        1 + '1'



# Generated at 2022-06-12 07:23:40.985185
# Unit test for function ok
def test_ok():
    assert ok(ZeroDivisionError).__class__.__name__ == 'generator'

# Generated at 2022-06-12 07:23:48.204687
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    # Exceptions not passed
    with ok():
        a = 1 / 0
    # Exceptions passed
    with ok(ZeroDivisionError):
        a = 1 / 0
    # Exceptions not passed
    with ok(AssertionError):
        a = 1 / 0
    # Exceptions not passed
    with ok(ZeroDivisionError, AssertionError):
        a = 1 / 0
    # Exceptions passed
    with ok(ZeroDivisionError, IndexError, AssertionError):
        a = 1 / 0
    # Exceptions passed
    with ok(ZeroDivisionError, IndexError, AssertionError):
        a = a[1]
    # Exceptions passed
    with ok(ZeroDivisionError, IndexError, AssertionError):
        assert False

# Generated at 2022-06-12 07:23:51.307952
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(Exception):
        raise Exception

    with raises(ValueError):
        with ok(ValueError):
            raise Exception

    with raises(Exception):
        with ok(ValueError):
            raise Exception

# Generated at 2022-06-12 07:23:53.845876
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        raise TypeError
    with ok(IndexError):
        raise ValueError
    with ok(IndexError):
        raise IndexError



# Generated at 2022-06-12 07:23:56.982413
# Unit test for function ok
def test_ok():
    with ok():
        pass
    with ok(ValueError):
        raise ValueError
    with raises(ValueError):
        with ok(TypeError):
            raise ValueError



# Generated at 2022-06-12 07:24:02.785998
# Unit test for function ok
def test_ok():
    """Test the ok context manager.
    :return: None
    """
    with ok(Exception):
        raise RuntimeError
    with ok(Exception, ValueError):
        raise ValueError
    try:
        with ok(ValueError):
            raise RuntimeError
    except RuntimeError:
        pass
    else:
        raise AssertionError

###############################################################################

# Generated at 2022-06-12 07:24:05.840195
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False
    with ok(ValueError, TypeError):
        x = 5
        y = 'Hello'
        z = x + y


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:24:07.769481
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with pytest.raises(NameError):
        with ok(ZeroDivisionError):
            raise NameError

# Generated at 2022-06-12 07:24:19.372814
# Unit test for function ok
def test_ok():
    # Raise an exception
    with pytest.raises(RuntimeError) as e_info:
        with ok(RuntimeError):
            raise RuntimeError()

    # Don't raise an exception
    with ok(RuntimeError):
        pass

    # Don't raise an exception for the wrong exception
    with pytest.raises(TypeError) as e_info:
        with ok(RuntimeError):
            raise TypeError()

    # Raise an exception for TypeError
    with pytest.raises(TypeError) as e_info:
        def f(a):
            with ok(RuntimeError):
                a()

        f(lambda: None)

# Generated at 2022-06-12 07:24:20.744898
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('a')
        int('1')



# Generated at 2022-06-12 07:24:21.961425
# Unit test for function ok
def test_ok():
    with ok(IndexError):
        [][0]



# Generated at 2022-06-12 07:24:31.622559
# Unit test for function ok
def test_ok():
    """
    Using the context manager 'ok'
    to pass exceptions.
    """
    print("Unit test for the function ok")

    # Defining the exceptions
    class MyException1(Exception):
        """Exception 1"""
        pass

    class MyException2(Exception):
        """Exception 2"""
        pass

    with ok(MyException1):
        raise MyException1

    with ok(MyException1, MyException2):
        raise MyException2

    try:
        with ok(MyException1):
            raise MyException2
    except MyException2:
        pass


# Script in case the file is run as a script
if __name__ == '__main__':
    # Unit tests
    test_ok()

# Generated at 2022-06-12 07:24:35.917180
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()

    with ok(ValueError):
        raise TypeError()

    with ok(TypeError, ValueError):
        raise TypeError()

    with ok(TypeError, ValueError):
        raise ValueError()

    with ok(TypeError, ValueError):
        raise AttributeError()



# Generated at 2022-06-12 07:24:39.583994
# Unit test for function ok
def test_ok():
    assert ok(ValueError).__class__ == GeneratorContextManager
    with ok(ValueError):
        ...
    with ok(ValueError):
        raise ValueError
    with pytest.raises(ValueError):
        with ok(ValueError):
            raise TypeError



# Generated at 2022-06-12 07:24:41.629114
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception
    with ok(Exception, ZeroDivisionError):
        raise ZeroDivisionError

# Generated at 2022-06-12 07:24:48.685145
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        # This will raise a ValueError, so the test will pass
        raise ValueError

    try:
        # This will raise a TypeError, so the test will fail
        raise TypeError
    except Exception as e:
        if isinstance(e, ValueError):
            raise AssertionError("The except of ok() should pass ValueError")
        elif isinstance(e, TypeError):
            pass
        else:
            raise AssertionError("The except of ok() should only pass ValueError and TypeError "
                                 "but it only passed TypeError")
    else:
        raise AssertionError("The except of ok() didn't even raise an exception")

# Generated at 2022-06-12 07:24:51.153411
# Unit test for function ok
def test_ok():
    assert_raises(TypeError, ok, str)
    with ok(KeyError, TypeError):
        {0: 0}[1]
    assert_raises(NameError, ok, KeyError, TypeError)
    

test_ok()

# Generated at 2022-06-12 07:24:52.234742
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    assert ok()



# Generated at 2022-06-12 07:25:00.689879
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0

# Output: ERROR: test_contextlib.py:31: ZeroDivisionError

# Generated at 2022-06-12 07:25:05.488112
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1/0

    with raises(TypeError):
        with ok(ZeroDivisionError):
            {[]}

    with raises(TypeError):
        with ok(ZeroDivisionError):
            {[]}

    with raises(ArithmeticError):
        with ok(ZeroDivisionError):
            raise ArithmeticError


# Generated at 2022-06-12 07:25:09.284202
# Unit test for function ok
def test_ok():
    # Should not raise
    with ok(ValueError):
        int('x')

    # Should raise
    with pytest.raises(TypeError):
        with ok(ValueError):
            int('x')



# Generated at 2022-06-12 07:25:14.874962
# Unit test for function ok
def test_ok():
    from contextlib import contextmanager

    @contextmanager
    def ok(*exceptions):
        """Context manager to pass exceptions.
        :param exceptions: Exceptions to pass
        """
        try:
            yield
        except Exception as e:
            if isinstance(e, exceptions):
                pass
            else:
                raise e

    with ok(ValueError, TypeError):
        print('Pass')



# Generated at 2022-06-12 07:25:17.349924
# Unit test for function ok
def test_ok():

    with ok(AttributeError):
        "".meth

    try:
        with ok(AttributeError):
            "".undefined_meth
    except NameError:
        print("NameError")

# Generated at 2022-06-12 07:25:19.798821
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print('this raises a TypeError!')

    with ok(AssertionError, TypeError):
        print('this raises a TypeError!')

    with ok(AssertionError):
        print('this raises an AssertionError!')



# Generated at 2022-06-12 07:25:21.882904
# Unit test for function ok
def test_ok():
    """Test for ok function.
    :return:
    """
    with ok(Exception):
        raise Exception()


# True if string contains only numbers

# Generated at 2022-06-12 07:25:25.386124
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int("hello world")

    with ok(TypeError, ValueError):
        int("hello world")

    with pytest.raises(ZeroDivisionError):
        with ok(TypeError, ValueError):
            1 / 0



# Generated at 2022-06-12 07:25:33.632653
# Unit test for function ok
def test_ok():
    """Test ok function."""
    with pytest.raises(TypeError):
        with ok():
            ert = 5 + 'a'
    with pytest.raises(TypeError):
        with ok(TypeError):
            7 + 'a'
    with ok(ZeroDivisionError):
        7 / 0
    with ok(ZeroDivisionError, TypeError):
        7 / 0
    with ok(ZeroDivisionError, TypeError):
        7 + 'a'
    with pytest.raises(TypeError):
        with ok(ZeroDivisionError):
            7 + 'a'



# Generated at 2022-06-12 07:25:36.317606
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""

# Generated at 2022-06-12 07:25:51.037900
# Unit test for function ok
def test_ok():
    with pytest.raises(ValueError):
        with ok(TypeError):
            raise ValueError



# Generated at 2022-06-12 07:25:55.488174
# Unit test for function ok
def test_ok():
    """Test the ok context manager."""
    assert_true(ok.__doc__ is not None)

    with ok(AssertionError):
        assert_true(False)

    # Will raise an assertion error
    with ok():
        assert_tru

# Generated at 2022-06-12 07:26:00.054351
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('1')
    with ok(TypeError, ValueError):
        int('1')
    with ok(TypeError, ValueError) as e:
        int('1')
        assert str(e) == ''
    with pytest.raises(IndexError):
        with ok(TypeError) as e:
            int('1')
            assert str(e) == ''
    assert ok().__exit__() is None

# Generated at 2022-06-12 07:26:05.089366
# Unit test for function ok
def test_ok():
    with pytest.raises(Exception):
        with ok():
            raise Exception()

    with ok(Exception):
        raise Exception()

    with ok(IndexError):
        raise IndexError()

    with pytest.raises(AttributeError):
        with ok(IndexError):
            raise AttributeError()



# Generated at 2022-06-12 07:26:11.562062
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print('This is ok!')

    with ok(KeyError, TypeError):
        with ok(KeyError):
            print('This is ok!')

    with pytest.raises(KeyError):
        with ok(TypeError):
            print('This is not ok!')



# Generated at 2022-06-12 07:26:14.818768
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('hello')

    with raises(ZeroDivisionError):
        with ok(ZeroDivisionError):
            1 / 0

    with raises(TypeError):
        with ok(ZeroDivisionError):
            int('hello')



# Generated at 2022-06-12 07:26:20.121150
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        1 + '1'

    with ok(TypeError, ZeroDivisionError):
        1 + '1'
        1 / 0

    with ok(TypeError, ZeroDivisionError):
        raise NotImplementedError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:26:22.279186
# Unit test for function ok
def test_ok():
    """Test function."""
    try:
        with ok(TypeError):
            int('a')
    except ValueError:
        pass



# Generated at 2022-06-12 07:26:25.427958
# Unit test for function ok
def test_ok():
    with ok(IndexError):
        l = []
        l[1]
    with ok(IndexError):
        print(locals())


# print(*args, sep=' ', end='\n', file=sys.stdout, flush=False)

# Generated at 2022-06-12 07:26:28.034822
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError, ValueError):
        a = 1 / 0

    with ok(ZeroDivisionError, ValueError):
        a = 'a' + 1



# Generated at 2022-06-12 07:27:02.988280
# Unit test for function ok
def test_ok():
    """
    >>> with ok(ValueError):
    ...     raise TypeError
    ...
    Traceback (most recent call last):
    ...
    TypeError

    >>> with ok(ValueError):
    ...     raise ValueError
    ...
    >>> with ok(ValueError, TypeError):
    ...     raise ValueError
    ...
    >>> with ok(ValueError, TypeError):
    ...     raise TypeError
    ...
    >>> with ok(ValueError, TypeError):
    ...     raise TypeError('pass')
    ...
    """

# Generated at 2022-06-12 07:27:05.060793
# Unit test for function ok
def test_ok():
    with ok(OSError, AssertionError):
        f = open('tmp', 'r')
        assert f
        f.close()
    assert not os.path.exists('tmp')



# Generated at 2022-06-12 07:27:15.237421
# Unit test for function ok
def test_ok():
    """Test ok() for context manager."""
    with ok(Exception):
        raise Exception
    try:
        with ok(ValueError):
            raise IndexError
    except Exception as e:
        assert isinstance(e, IndexError)
    with ok(IndexError):
        pass
    with ok():
        raise Exception
    with ok(Exception):
        1/0
    with ok(ZeroDivisionError, IndexError, KeyError):
        1/0
    with ok(IndexError, ZeroDivisionError):
        1/0
    try:
        with ok():
            1/0
    except Exception as e:
        assert isinstance(e, ZeroDivisionError)
    try:
        with ok(IndexError):
            1/0
    except Exception as e:
        assert isinstance(e, ZeroDivisionError)


# Generated at 2022-06-12 07:27:19.881862
# Unit test for function ok
def test_ok():
    """Test for the context manager ok."""
    with ok(ValueError):
        print(int("ValueError"))
    with ok(ValueError, TypeError):
        print(int("TypeError"))
    with pytest.raises(Exception):
        with ok(ValueError, TypeError):
            print(int("Exception"))

# Generated at 2022-06-12 07:27:24.370938
# Unit test for function ok
def test_ok():
    """Test contextmanager ok."""

# Generated at 2022-06-12 07:27:27.764600
# Unit test for function ok
def test_ok():
    a = 0
    with ok(ValueError, TypeError):
        a += 1
        a += "hh"
        a += 1
    assert a == 1



# Generated at 2022-06-12 07:27:32.898144
# Unit test for function ok
def test_ok():
    # valid exception
    # UserWarning is a subclass of Warning.
    with ok(UserWarning):
        warnings.warn("UserWarning")

    with ok(Exception):
        raise Exception("Exception")

    # invalid exception
    with ok(UserWarning):
        warnings.warn("Warning")

    with ok(Exception):
        raise Warning("Warning")

# Generated at 2022-06-12 07:27:37.499861
# Unit test for function ok
def test_ok():
    try:
        with ok(ZeroDivisionError, TypeError):
            # this should be ok
            1 / 0
        # this should throw exception
        with ok(ZeroDivisionError, TypeError):
            1 / 'hello'
        assert False
    except:
        assert True



# Generated at 2022-06-12 07:27:44.001449
# Unit test for function ok
def test_ok():
    # With
    with ok():
        raise IndexError

    try:
        with ok():
            raise IndexError
    except IndexError:
        raise Exception('IndexError should have been ignored')

    try:
        with ok(IndexError):
            raise IndexError
    except IndexError:
        raise Exception('IndexError should have been ignored')

    try:
        with ok(ValueError):
            raise IndexError
    except IndexError:
        pass

    # Test not passing exceptions
    try:
        with ok():
            raise ValueError
    except ValueError:
        pass

# Generated at 2022-06-12 07:27:47.930746
# Unit test for function ok
def test_ok():
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError
    with raises(AssertionError):
        with ok():
            raise TypeError



# Generated at 2022-06-12 07:28:51.877379
# Unit test for function ok
def test_ok():
    with ok(RuntimeError):
        raise RuntimeError
    with ok(TypeError, ZeroDivisionError):
        raise TypeError
    with ok(TypeError, ZeroDivisionError):
        raise ZeroDivisionError
    with raises(AssertionError):
        with ok(RuntimeError, ZeroDivisionError):
            raise ValueError

# Generated at 2022-06-12 07:28:53.985726
# Unit test for function ok
def test_ok():
    """Function  for testing ok context manager."""
    with ok(TypeError):
        int('hello')
    with ok(TypeError):
        raise TypeError('')  # pass

# Generated at 2022-06-12 07:29:00.323037
# Unit test for function ok
def test_ok():
    """Test for function ok
    """
    # Test for TypeError
    with ok(TypeError):
        eval("1 + 'string'")
    print("TypeError is OK")
    # Test for ValueError
    with ok(ValueError):
        eval("int('string')")
    print("ValueError is OK")
    # Test for Exception
    with ok(TypeError, ValueError):
        eval("int('string') * 10")
    print("Exception is OK")
    # Test for AttributeError
    with ok(Exception):
        eval("int('string') * 10")
    print("AttributeError is OK")

test_ok()

# Generated at 2022-06-12 07:29:02.610388
# Unit test for function ok
def test_ok():
    assert ok(Exception)
    assert not ok(TypeError)



# Generated at 2022-06-12 07:29:04.786882
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print('Inside ok context manager')
        raise TypeError('test ok function')


test_ok()

print('\n')



# Generated at 2022-06-12 07:29:06.082428
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False



# Generated at 2022-06-12 07:29:16.249805
# Unit test for function ok
def test_ok():
    # Test with no exceptions raised
    with ok():
        pass
    # Test with an exception
    try:
        with ok():
            raise Exception("Exception raised")
    except Exception as e:
        assert str(e) == "Exception raised"
    # Test with an exception inside mentioned exceptions list
    try:
        with ok(TypeError):
            raise TypeError("TypeError raised")
    except Exception as e:
        assert str(e) == "TypeError raised"
    # Test with an exception not inside mentioned exceptions list
    try:
        with ok(TypeError):
            raise IndexError("IndexError raised")
    except Exception as e:
        assert str(e) == "IndexError raised"


### Generators
# Write a generator function which returns the Fibonacci series.
# The Fibonacci Series is the series of numbers:
#

# Generated at 2022-06-12 07:29:17.521337
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""

# Generated at 2022-06-12 07:29:25.516623
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError("I'm OK")

    try:
        with ok(TypeError):
            raise ValueError("I'm not OK")
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError was not raised')

    try:
        with ok(TypeError):
            raise TypeError("I'm OK")
            raise ValueError("I'm not OK")
    except ValueError:
        raise AssertionError('ValueError was raised')
    except TypeError:
        pass
    else:
        raise AssertionError('TypeError was not raised')


# Code for formatting a gcode file

# Generated at 2022-06-12 07:29:27.434997
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with raises(NameError):
        1 / 'a'



# Generated at 2022-06-12 07:31:36.502553
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with pytest.raises(KeyError):
        with ok(ValueError):
            d = {}
            d['a']



# Generated at 2022-06-12 07:31:39.518084
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        return 1 + '1'
    with ok(TypeError, ValueError):
        return 1 + int('a')
    with ok(TypeError, ValueError, NameError):
        return 1 + 'a'



# Generated at 2022-06-12 07:31:41.635029
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('a')
    with pytest.raises(ValueError):
        with ok(TypeError):
            int('a')

# Generated at 2022-06-12 07:31:44.730885
# Unit test for function ok
def test_ok():

    with ok(TypeError, ValueError) :
        raise ValueError()
    with ok(TypeError, ValueError) :
        raise TypeError()
    with ok(TypeError, ValueError) :
        raise StopIteration()



if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:31:46.676575
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError) as cm:
        1 / 0
    assert cm.exception


if __name__ == "__main__":
    doctest.testmod()

# Generated at 2022-06-12 07:31:48.910097
# Unit test for function ok
def test_ok():
    with ok(AssertionError, ZeroDivisionError):
        assert 2 + 1 == 2
    with ok(AssertionError):
        assert 2 + 2 == 5

# Generated at 2022-06-12 07:31:51.120484
# Unit test for function ok
def test_ok():
    """Unittest for ok context manager."""
    with ok(ValueError):
        raise ValueError
    with raises(IndexError):
        with ok(TypeError, ValueError):
            raise IndexError

# Generated at 2022-06-12 07:31:53.462108
# Unit test for function ok
def test_ok():
    """Test function ok."""

    print('test_ok')
    with ok(ValueError):
        print('ok')
        # raise ValueError('go')



# Generated at 2022-06-12 07:31:58.435862
# Unit test for function ok
def test_ok():
    with ok(TypeError) as ok_cm:
        raise TypeError("Ignored exception")
    assert isinstance(ok_cm, ok)
    with pytest.raises(IndexError):
        with ok(TypeError):
            raise IndexError("Unignored exception")



# Generated at 2022-06-12 07:32:04.917496
# Unit test for function ok
def test_ok():
    with ok():
        pass

    with ok(Exception):
        pass

    with ok(TypeError):
        pass

    try:
        with ok(TypeError):
            raise ValueError
    except ValueError:
        pass

    try:
        with ok(ValueError):
            raise ValueError
    except ValueError:
        pass

    try:
        with ok(TypeError, ValueError):
            raise ValueError
    except ValueError:
        pass

    try:
        with ok(TypeError, ValueError):
            raise TypeError
    except TypeError:
        pass


if __name__ == "__main__":
    test_ok()