

# Generated at 2022-06-12 07:23:08.630973
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise RuntimeError("Caught RunTimeError")

    with ok(TypeError):
        raise ValueError("Caught ValueError")

    with ok(ValueError, TypeError):
        raise KeyError("Caught KeyError")

    try:
        with ok(TypeError):
            raise ValueError("Caught ValueError")
    except Exception as e:
        assert isinstance(e, ValueError)

    try:
        with ok(ValueError):
            raise KeyError("Caught KeyError")
    except Exception as e:
        assert isinstance(e, KeyError)

# Generated at 2022-06-12 07:23:19.197764
# Unit test for function ok
def test_ok():
    """
    >>> with ok(TypeError):
    ...     int('hello')
    Traceback (most recent call last):
    ValueError: invalid literal for int() with base 10: 'hello'
    >>> with ok(ValueError, TypeError):
    ...     int('hello')
    >>> int('hello')
    Traceback (most recent call last):
    ValueError: invalid literal for int() with base 10: 'hello'
    """


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    argc = len(sys.argv)
    if argc > 2 or argc < 2:
        print('\nUsage:\n  python ok.py <function_name>')
        sys.exit(0)

# Generated at 2022-06-12 07:23:25.800412
# Unit test for function ok
def test_ok():
    # Try with ok(Exception) as nothing should be raised
    with ok(Exception):
        pass

    # Check if it raises a ValueError
    with raises(ValueError):
        with ok(TypeError):
            raise ValueError

    # Check if it passes a TypeError as expected
    with ok(TypeError):
        raise TypeError

    # Check if it raises a ValueError even if TypeError is ok
    with raises(ValueError):
        with ok(TypeError):
            raise ValueError



# Generated at 2022-06-12 07:23:28.140998
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(TypeError):
        raise ValueError
    with ok(TypeError):
        raise TypeError



# Generated at 2022-06-12 07:23:33.045922
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    # with ok(TypeError):
    #     raise ValueError()
    # with ok(OverflowError):
    #     raise ValueError()



# Generated at 2022-06-12 07:23:39.226596
# Unit test for function ok
def test_ok():
    """Test context manager ok"""
    with ok(Exception):
        raise Exception("ok")
    with ok(ValueError):
        raise ValueError("ok")
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError("not ok")
    with raises(ValueError):
        with ok(TypeError, ValueError):
            raise ValueError("ok")
    with raises(TypeError):
        with ok(TypeError, ValueError):
            raise TypeError("ok")

# Generated at 2022-06-12 07:23:42.742229
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError, ValueError):
        x = 1/0
    assert 'ZeroDivisionError' in str(e)


if __name__ == '__main__':
    main()

# Generated at 2022-06-12 07:23:45.712193
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('str')
    with ok():
        int('str')
    with ok(ValueError):
        int('str')



# Generated at 2022-06-12 07:23:48.681378
# Unit test for function ok
def test_ok():
    with ok(IndexError, KeyError):
        a = [1, 2, 3]
        print(f"value at index 4 is: {a[4]}")


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-12 07:23:50.341593
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    assert ok()



# Generated at 2022-06-12 07:23:55.242014
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('hello world')
    with pytest.raises(ZeroDivisionError):
        1 / 0
    with pytest.raises(TypeError):
        1 > 'a'



# Generated at 2022-06-12 07:23:58.680882
# Unit test for function ok
def test_ok():
    """Unit testing for ok."""
    with ok(Exception):
        raise Exception
    with raises(ZeroDivisionError):
        with ok(Exception):
            raise ZeroDivisionError



# Generated at 2022-06-12 07:24:03.912945
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        pass
    with ok(ValueError):
        raise ValueError('value error')
    with ok(ValueError, TypeError):
        raise TypeError('type error')
    with raises(ValueError):
        with ok(TypeError):
            raise ValueError('value error')



# Generated at 2022-06-12 07:24:06.225433
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False

    with raises(ZeroDivisionError):
        with ok(AssertionError):
            1 / 0



# Generated at 2022-06-12 07:24:09.588793
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(IndexError, TypeError):
        [][42] = 'dummy'
    with ok(IndexError, TypeError):
        x = [][42]
    with ok(IndexError, TypeError):
        [][42] = 'dummy'


# Decorator to retry function call

# Generated at 2022-06-12 07:24:14.654478
# Unit test for function ok
def test_ok():
    # TODO: Implement something like this
    # with ok(Exception):
    #     local_only_exc_test()
    # with ok(Exception):
    #     global_only_exc_test()
    # with ok(Exception):
    #     local_global_exc_test()
    pass



# Generated at 2022-06-12 07:24:17.636203
# Unit test for function ok
def test_ok():
    with ok():
        raise RuntimeError()
    with ok(RuntimeError, TypeError):
        raise TypeError()
    with raises(KeyError):
        with ok(RuntimeError):
            raise KeyError()

# Generated at 2022-06-12 07:24:20.768745
# Unit test for function ok
def test_ok():
    with ok():
        print('OK, no exceptions happened')

    with ok(TypeError, KeyError):
        print('OK, no exceptions happened')

    try:
        with ok(KeyError):
            print('BAD, TypeError raised')
            raise TypeError
    except:
        pass


test_ok()

# Generated at 2022-06-12 07:24:31.472156
# Unit test for function ok
def test_ok():
    import unittest
    import unittest.mock

    class TestOk(unittest.TestCase):
        def test_function_ok(self):
            # Test that if exception is passed, it is not propagated
            with unittest.mock.patch('builtins.print') as mock_out:
                try:
                    with ok(ZeroDivisionError):
                        1 / 0
                except Exception:
                    self.fail()
                mock_out.assert_not_called()

            # Test that exception is propagated if not passed
            with unittest.mock.patch('builtins.print') as mock_out:
                with self.assertRaises(ZeroDivisionError):
                    with ok():
                        1 / 0
                mock_out.assert_not_called()

    unittest.main()


# if

# Generated at 2022-06-12 07:24:35.776513
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        1 / 0
    with ok(ValueError, ZeroDivisionError):
        1 / 0
    with ok(ZeroDivisionError):
        1 / 'This is a string'
    with ok(ZeroDivisionError):
        1 / {}
    with ok(TypeError):
        1 / 'a'

# Generated at 2022-06-12 07:24:45.730961
# Unit test for function ok
def test_ok():
    """Test for the ok context manager."""
    with pytest.raises(TypeError):
        with ok(TypeError):
            raise TypeError('Test OK')
    with pytest.raises(TypeError):
        with ok(TypeError, ValueError):
            raise ValueError('Test OK')
    with pytest.raises(ValueError):
        with ok(TypeError, AttributeError):
            raise ValueError('Test OK')
    assert True

# Generated at 2022-06-12 07:24:47.723017
# Unit test for function ok
def test_ok():
    """Test function ok"""
    # Initialize and call function

    with ok(ZeroDivisionError):
        1 / 0


# Doctest for function ok

# Generated at 2022-06-12 07:24:51.396850
# Unit test for function ok
def test_ok():
    with ok(IndexError):
        print([1, 2, 3][4])
    # no exception is raised

    with ok(TypeError, IndexError):
        print([1, 2, 3][4])
    # no exception is raised

    with ok(TypeError):
        print([1, 2, 3][4])
    # an IndexError is raised


# A function to substitute for print so we can trace call argument

# Generated at 2022-06-12 07:24:55.545391
# Unit test for function ok
def test_ok():
    """
    Unit test for function ok
    """
    with ok(IndexError, KeyError):
        raise IndexError
        raise KeyError
        raise ValueError
    with ok(IndexError, KeyError):
        raise IndexError
    with pytest.raises(ValueError):
        with ok(IndexError, KeyError):
            raise ValueError



# Generated at 2022-06-12 07:24:58.870441
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1/0

    try:
        with ok(ZeroDivisionError):
            raise IndexError('Boom!')
    except IndexError as e:
        print('Passed: {}'.format(e))
    else:
        assert False



# Generated at 2022-06-12 07:25:08.739443
# Unit test for function ok
def test_ok():
    """Test for function ok"""
    with ok(TypeError, ValueError):
        raise TypeError("Hello")

    with ok(TypeError, ValueError) as c:
        c.__enter__()
        c.__exit__(TypeError("Hello"), "", "")

    with ok(TypeError, ValueError) as c:
        c.__enter__()
        c.__exit__("", "", "")

    with ok(TypeError, ValueError) as c:
        c.__exit__(TypeError("Hello"), "", "")

    with ok(TypeError, ValueError) as c:
        c.__exit__("", "", "")

    with ok(TypeError, ValueError):
        pass

    with ok(TypeError, ValueError):
        raise ValueError("Hello")


# Generated at 2022-06-12 07:25:13.729636
# Unit test for function ok
def test_ok():
    """Test for function ok
    """
    with ok(ValueError):
        int('one')
    try:
        with ok(ValueError):
            1 / 0
    except ZeroDivisionError as e:
        assert type(e) == ZeroDivisionError
    with ok(ZeroDivisionError):
        1 / 0



# Generated at 2022-06-12 07:25:15.300841
# Unit test for function ok
def test_ok():
    with ok(OSError, IndexError):
        with ok(Exception):
            assert "not in list"



# Generated at 2022-06-12 07:25:18.519629
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with raises(IOError):
        with ok(ValueError, TypeError):
            raise IOError



# Generated at 2022-06-12 07:25:21.833552
# Unit test for function ok
def test_ok():
    with pytest.raises(ZeroDivisionError):
        with ok(TypeError):
            1 / 0
    with ok(ZeroDivisionError):
        with pytest.raises(ZeroDivisionError):
            1 / 0

# Generated at 2022-06-12 07:25:31.618804
# Unit test for function ok
def test_ok():
    with ok(RuntimeError):
        raise RuntimeError

    with pytest.raises(TypeError):
        with ok(RuntimeError):
            raise TypeError



# Generated at 2022-06-12 07:25:36.849676
# Unit test for function ok
def test_ok():
    with ok(TypeError, ValueError):
        raise ValueError("This is a test.")
    with raises(TypeError):
        ok(TypeError, ValueError)
        raise TypeError("This is a test.")
    with raises(ValueError):
        ok(TypeError, ValueError)
        raise ValueError("This is a test.")


# Generated at 2022-06-12 07:25:43.276783
# Unit test for function ok
def test_ok():
    try:
        with ok(ValueError):
            value = int("A")
    except NameError:
        raise AssertionError("NameError not handled")
    except:
        pass
    else:
        raise AssertionError("ValueError not raised")
    try:
        with ok(TypeError, ValueError):
            value = int("A")
    except NameError:
        raise AssertionError("NameError not handled")
    except:
        pass
    else:
        raise AssertionError("ValueError not raised")


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-12 07:25:45.169104
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False



# Generated at 2022-06-12 07:25:48.163611
# Unit test for function ok
def test_ok():
    x = -1

    def inner():
        nonlocal x
        x = 1 / 0

    with ok(ZeroDivisionError):
        inner()
    assert x == -1

# Generated at 2022-06-12 07:25:51.335022
# Unit test for function ok
def test_ok():
    """Test ok context manager."""
    with ok():
        pass
    with ok(TypeError):
        raise TypeError
    with ok(AttributeError, TypeError):
        raise TypeError
    with pytest.raises(ZeroDivisionError):
        with ok(AttributeError, TypeError):
            raise ZeroDivisionError

# Generated at 2022-06-12 07:25:59.914937
# Unit test for function ok
def test_ok():
    """Unit test for function ok
    """
    # Test with 0
    with ok():
        print("0")

    # Test with 1
    with ok(Exception):
        raise Exception

    # Test with 2
    with ok(ValueError, TypeError):
        raise TypeError

    # Test with 3
    with ok(ValueError, TypeError):
        raise ValueError

    # Test with 4
    try:
        with ok(ValueError, TypeError):
            raise NameError
    except NameError:
        pass

    # Test with 5
    try:
        with ok(ValueError, TypeError):
            raise FileNotFoundError
    except FileNotFoundError:
        pass



# Generated at 2022-06-12 07:26:01.939967
# Unit test for function ok
def test_ok():
    """ ok function test.
    """
    with ok(TypeError):
        int("asdf")



# Generated at 2022-06-12 07:26:05.884739
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print('Type Error')
    with ok(TypeError, ZeroDivisionError):
        print('Zero Division Error')
    with ok(TypeError, ZeroDivisionError):
        1 / 0



# Generated at 2022-06-12 07:26:13.054982
# Unit test for function ok
def test_ok():
    """Unit test for ok."""
    with ok(KeyError):
        print(5 + 'x')

    try:
        with ok(KeyError):
            print('x' + 5)
    except TypeError:
        pass
    else:
        raise Exception('TypeError was not raised')


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:26:33.619231
# Unit test for function ok
def test_ok():
    """Test function ok"""
    with ok(ValueError):
        raise ValueError

    with ok(ValueError):
        raise TypeError

    try:
        with ok(ValueError):
            raise TypeError
    except TypeError:
        pass
    else:
        assert False, 'TypeError must be caught'

    assert_raises(TypeError, ok(ValueError).__enter__)


if __name__ == '__main__':
    import nose

    nose.runmodule()

# Generated at 2022-06-12 07:26:35.806531
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(3 + "5")

    try:
        with ok(TypeError):
            print(3 + 5)
    except NameError:
        print("An exception was raised")

# Generated at 2022-06-12 07:26:41.567720
# Unit test for function ok
def test_ok():

    # Initialize variables
    err_msg = 'Unrecognized exception'

    # Pass exception
    with ok(ValueError):
        raise ValueError('Value error')

    # Fail to pass exception
    try:
        with ok(ZeroDivisionError):
            raise ValueError('Value error')
    except ValueError:
        pass
    except Exception:
        err_msg = 'Additional exception found'

    # Return error message
    return err_msg

# Generated at 2022-06-12 07:26:51.779065
# Unit test for function ok
def test_ok():
    with ok():
        print("ok")
    # should print "ok"

    with ok(ZeroDivisionError, IndexError):
        print(1 / 0)

    with ok(ZeroDivisionError, IndexError):
        print(1 / 1)
    # should print 1

    with ok(ZeroDivisionError, IndexError):
        a = [1, 2, 3]
        print(a[4])
    # should raise IndexError
    #
    # with ok(ZeroDivisionError, IndexError):
    #     print(1 / 0)  # should raise ZeroDivisionError
    # with ok(ZeroDivisionError, IndexError):
    #     a = [1, 2, 3]
    #     print(a[4])  # should raise IndexError
    # with ok():
    #     print(1 / 0)

# Generated at 2022-06-12 07:26:55.386448
# Unit test for function ok
def test_ok():
    with ok(ValueError, ArithmeticError):
        print("Value error is ignored 1 + 'a'")
        print(1 + 'a')
    try:
        with ok(ValueError, ArithmeticError):
            print("ZeroDivisionError will pass")
            print(1/0)
    except ZeroDivisionError:
        print("ZeroDivisionError passed")


test_ok()

# Generated at 2022-06-12 07:26:58.989289
# Unit test for function ok
def test_ok():
    with ok(IOError):
        assert 1 == 1
    try:
        with ok(IOError):
            assert 1 == 2
    except Exception:
        assert True



# Generated at 2022-06-12 07:27:00.706724
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        print('OK')



# Generated at 2022-06-12 07:27:02.523163
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        1 + "1"

    with raises(ZeroDivisionError):
        with ok(TypeError):
            1 / 0

# Generated at 2022-06-12 07:27:04.998914
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        1+'1'

    with pytest.raises(IndexError):
        with ok(TypeError):
            [] + []



# Generated at 2022-06-12 07:27:06.624165
# Unit test for function ok
def test_ok():
    assert ok(ValueError)
    assert ok()



# Generated at 2022-06-12 07:27:37.497332
# Unit test for function ok

# Generated at 2022-06-12 07:27:39.883459
# Unit test for function ok
def test_ok():
    """Test the context manger ok.
    """
    assert ok(ZeroDivisionError).__enter__()
    # assert ok(ZeroDivisionError).__exit__()



# Generated at 2022-06-12 07:27:42.314448
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError


if __name__ == '__main__':
    test_ok()
    print('All tests were passed')

# Generated at 2022-06-12 07:27:44.083520
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print('OK')



# Generated at 2022-06-12 07:27:46.399090
# Unit test for function ok
def test_ok():
    ok(AssertionError)
    with raises(AssertionError):
        with ok():
            raise AssertionError

    with ok():
        pass



# Generated at 2022-06-12 07:27:51.992968
# Unit test for function ok
def test_ok():
    with ok(KeyError):
        info = {'x': 1}
        x = info['y']

    with ok(AttributeError, KeyError):
        info = {'x': 1}
        x = info['y']
        x = info['x'].p
    
    with ok(KeyError):
        info = {'x': 1}
        x = info['y']
        x = info['x'].p



# Generated at 2022-06-12 07:27:54.062035
# Unit test for function ok
def test_ok():
    """Test ok context manager.
    """
    with ok(ValueError):
        raise ValueError()



# Generated at 2022-06-12 07:27:55.287585
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('hello')



# Generated at 2022-06-12 07:27:59.612908
# Unit test for function ok
def test_ok():
    with ok(RuntimeError):
        raise RuntimeError
    with ok(RuntimeError, TypeError):
        raise RuntimeError
    with ok(RuntimeError, TypeError):
        raise TypeError
    with raises(NameError):
        with ok(RuntimeError):
            raise NameError

# Generated at 2022-06-12 07:28:00.735377
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')



# Generated at 2022-06-12 07:29:09.214030
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        x = 'foo' - 4
    with raises(ZeroDivisionError):
        x = 0 / 0



# Generated at 2022-06-12 07:29:13.279321
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()

    try:
        with ok(ValueError):
            raise TypeError()
    except TypeError:
        pass
    else:
        raise AssertionError('Uncaught TypeError')



# Generated at 2022-06-12 07:29:16.159152
# Unit test for function ok
def test_ok():
    """Unittest for contextmanager ok."""
    with ok():
        pass
    with ok(TypeError):
        raise TypeError
    with ok(TypeError):
        raise KeyError

# Generated at 2022-06-12 07:29:21.399795
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError("Error")
    try:
        with ok(ValueError):
            pass
    except ValueError:
        raise AssertionError("Error should be passed")
    with ok(ValueError):
        pass
    try:
        with ok(ValueError):
            raise TypeError("Error")
    except TypeError:
        pass
    else:
        raise AssertionError("TypeError should be thrown")
    try:
        with ok(ValueError):
            raise TypeError("Error")
    except ValueError:
        raise AssertionError("ValueError should not be thrown")

# Generated at 2022-06-12 07:29:23.632765
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(AssertionError):
        assert False

    with ok(ValueError, AssertionError):
        value = 10
        assert value > 100

# Generated at 2022-06-12 07:29:29.820786
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    # Normal input
    with ok():
        print('Passed')

    # Input that was it supposed to except, so it does not raise any exceptions
    with ok(Exception):
        raise Exception('Pass')

    # Input that was not supposed to happen, so it raises the exception
    with pytest.raises(Exception):
        with ok(KeyboardInterrupt):
            raise Exception('Fail')



# Generated at 2022-06-12 07:29:37.578066
# Unit test for function ok
def test_ok():
    """Unit test for the 'ok' context manager."""
    # Test ok takes the exception and passes it
    with ok(ZeroDivisionError):
        5 / 0
    # Test ok takes multiple exceptions and passes it
    with ok(ImportError, ZeroDivisionError):
        import hallelujah
    # Test ok lets other exceptions propagate
    try:
        with ok(ImportError, ZeroDivisionError):
            import hallelujah
    except Exception as e:
        assert isinstance(e, ModuleNotFoundError)


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-12 07:29:40.753743
# Unit test for function ok
def test_ok():
    """Unit test for ok context manager."""

    with ok(ZeroDivisionError):
        5 / 0

    with ok(ZeroDivisionError):
        with ok(ZeroDivisionError):
            5 / 0



# Generated at 2022-06-12 07:29:47.025994
# Unit test for function ok
def test_ok():
    """Function to test function ok."""
    print('Unit test for function ok.')
    try:
        with ok(TypeError):
            int('a')
    except ValueError:
        """ We don't expect ValueError. """
        print('ERROR: Expected TypeError, recieved ValueError.')
    except:
        """ We expect TypeError, anything else is an error. """
        print('ERROR: Expected TypeError, recieved something else.')
    else:
        print('Expected TypeError, recieved nothing.')
    with ok(TypeError):
        int('a')
    print('Passed unit test for function ok.')



# Generated at 2022-06-12 07:29:50.926215
# Unit test for function ok
def test_ok():
    with ok(KeyError):
        raise KeyError()
        assert False
    with ok(Exception):
        raise KeyError()
        assert False


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:32:17.816079
# Unit test for function ok
def test_ok():
    """Tests for ok function"""
    def test_exception(n):
        if n != 1:
            raise ValueError("test")
        else:
            return "test_ok"
    with ok(ValueError):
        assert test_exception(0) == 'test_ok'

# Generated at 2022-06-12 07:32:19.611589
# Unit test for function ok
def test_ok():
    with ok(Exception):
        try:
            raise Exception("test exception")
        except:
            pass
    pass



# Generated at 2022-06-12 07:32:20.712926
# Unit test for function ok
def test_ok():
    with ok():
        1 / 0
    assert True



# Generated at 2022-06-12 07:32:24.294327
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int(None)
    with ok(ValueError, TypeError):
        int('N/A')

    with raises(ZeroDivisionError):
        with ok(TypeError):
            1 / 0

# Generated at 2022-06-12 07:32:28.817805
# Unit test for function ok
def test_ok():
    with ok():
        print("This is printed")

    with ok(TypeError, ZeroDivisionError):
        print("This is also printed")
        raise TypeError

    with ok(KeyError):
        print("This is finally printed")
        raise KeyError

    try:
        with ok():
            print("This is not printed")
    except Exception:
        print("And an exception occurred")



# Generated at 2022-06-12 07:32:31.631993
# Unit test for function ok
def test_ok():
    """Test expected exceptions are not raised"""
    with ok(AssertionError):
        assert True
    with ok(AssertionError):
        raise AssertionError
    with ok(AssertionError, TypeError):
        raise TypeError



# Generated at 2022-06-12 07:32:39.783885
# Unit test for function ok
def test_ok():
    """Test for function ok."""
    class MyError(Exception):
        pass

    def buggy_func(num):
        """Function that raise exception."""
        if num > 0:
            raise ValueError("Only positive number accepted")
        elif num < 0:
            raise MyError("Only positive number accepted")
        else:
            pass

    with ok(MyError):
        buggy_func(1)

    with ok(MyError):
        buggy_func(0)

    with ok(MyError):
        buggy_func(-1)

# Generated at 2022-06-12 07:32:42.546472
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with ok(Exception):
        raise ValueError()
    with raises(TypeError):
        with ok(IndexError):
            raise TypeError()



# Generated at 2022-06-12 07:32:44.161772
# Unit test for function ok
def test_ok():
    """Test for function ok."""
    with ok():
        pass



# Generated at 2022-06-12 07:32:49.855225
# Unit test for function ok
def test_ok():
    """
    >>> with ok(ZeroDivisionError):
        5 / 0
    >>> with ok(ZeroDivisionError):
        5 / 0
    Traceback (most recent call last):
    ...
    ZeroDivisionError
    >>> with ok(ZeroDivisionError, TypeError):
        "a" / "b"
    Traceback (most recent call last):
    ...
    TypeError
    """
    pass

