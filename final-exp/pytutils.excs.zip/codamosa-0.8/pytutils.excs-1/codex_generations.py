

# Generated at 2022-06-12 07:23:02.768367
# Unit test for function ok
def test_ok():
    """
    >>> test_ok()
    True
    """
    with ok(Exception):
        print("I'm ok")
    print("I'm very ok")
    with ok(TypeError, ZeroDivisionError):
        1 / 0
    print("I'm bad!")
    return True


if __name__ == '__main__':
    import doctest
    docte

# Generated at 2022-06-12 07:23:05.284458
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    assert ok


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:23:06.571058
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False



# Generated at 2022-06-12 07:23:08.976520
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        1 + '1'
    assert 1 + '1' == '11'



# Generated at 2022-06-12 07:23:13.221185
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int('N/A')
    with ok(Exception):
        int('N/A')

    with raises(TypeError):
        with ok(ValueError):
            int('N/A')



# Generated at 2022-06-12 07:23:17.658989
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with raises(AttributeError):
        with ok(ValueError):
            raise AttributeError()



# Generated at 2022-06-12 07:23:21.638790
# Unit test for function ok
def test_ok():
    try:
        with ok(ZeroDivisionError):
            x = 1 / 0
    except:
        assert False

    try:
        with ok(ZeroDivisionError):
            x = 1 / 1
    except:
        assert True


# Generated at 2022-06-12 07:23:23.313930
# Unit test for function ok
def test_ok():
    """
    Test the ok context manager.
    """
    with ok(ValueError):
        raise ValueError()



# Generated at 2022-06-12 07:23:25.605619
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with ok(ZeroDivisionError):
        print(1 / 0)

    with ok(ValueError):
        print(int("test"))


test_ok()

# Generated at 2022-06-12 07:23:27.471606
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ZeroDivisionError):
        1 / 0



# Generated at 2022-06-12 07:23:36.711674
# Unit test for function ok
def test_ok():
    with pytest.raises(KeyError):
        with ok(IOError):
            raise KeyError
    with pytest.raises(ZeroDivisionError):
        with ok(IOError, ZeroDivisionError):
            raise ZeroDivisionError
    with pytest.raises(IndexError):
        with ok(IndexError):
            raise IndexError
    with ok(ValueError, IOError):
        pass



# Generated at 2022-06-12 07:23:39.147461
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
        print("ok!")
    with ok(TypeError, ValueError):
        raise TypeError
        print("ok!")

# Generated at 2022-06-12 07:23:43.026873
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(Exception):
        raise Exception("Expected exception")

    with raises(ValueError):
        with ok(Exception):
            raise ValueError("Unexpected exception")



# Generated at 2022-06-12 07:23:47.461622
# Unit test for function ok
def test_ok():
    with pytest.raises(TypeError):
        with ok(TypeError):
            a = 1 + '2'
    with ok(TypeError, ZeroDivisionError):
        a = 1 + '2'
    with ok(TypeError, ZeroDivisionError):
        a = 1 / 0



# Generated at 2022-06-12 07:23:51.638314
# Unit test for function ok
def test_ok():
    """Test for function ok
    """
    with ok(TypeError):
        int('hello', 16)
    try:
        int('hello', 8)
    except ValueError as e:
        print(e, file=sys.stderr)
        raise e


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:23:53.032711
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int("No")
    int("No")

# Generated at 2022-06-12 07:23:54.723708
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('hello')
    with raises(NameError):
        int('hello')

# Generated at 2022-06-12 07:23:59.972751
# Unit test for function ok
def test_ok():
    """Testing function ok."""
    with ok():
        pass
    with ok(ZeroDivisionError):
        1 / 0
    with ok(TypeError, ZeroDivisionError):
        1 / '0'
    with raises(ValueError):
        with ok(TypeError, ZeroDivisionError):
            1 + '0'

# Generated at 2022-06-12 07:24:03.598756
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('a')

    with ok(ValueError):
        raise ValueError()

    with pytest.raises(TypeError):
        with ok(ValueError):
            raise TypeError()



# Generated at 2022-06-12 07:24:05.454337
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError, IndexError):
        x = 1 / 0
        y = [][0]



# Generated at 2022-06-12 07:24:16.240623
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError, TypeError):
        x = 5 + 'N/A'

    try:
        int('N/A')
    except ValueError:
        pass
    else:
        assert False

    try:
        x = 5 + 'N/A'
    except (ValueError, TypeError):
        pass
    else:
        assert False


# Example use
if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:24:21.511143
# Unit test for function ok
def test_ok():
    """ Test for ok() function
    """
    with ok(AssertionError):
        # OK to not do anything
        pass

    # Raises AssertionError
    with ok(AssertionError):
        assert 1 == 2

    # Exception is not raised
    with ok(AssertionError, TypeError):
        assert 1 == 1

    # Raises TypeError
    with ok(AssertionError, TypeError):
        int("Aa")


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:24:30.884852
# Unit test for function ok
def test_ok():
    with ok(Exception):
        assert True
    with ok(*[Exception]):
        assert True
    with ok(Exception, Exception):
        assert True
    with ok(*[Exception, Exception]):
        assert True
    with ok():
        raise Exception
    with ok(Exception):
        raise Exception
        assert False
    with ok(*[Exception, TypeError]):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(*[ValueError, TypeError]):
        raise ValueError
    with ok(Exception, TypeError):
        raise ValueError

    with pytest.raises(ValueError):
        with ok(Exception):
            raise ValueError

# Generated at 2022-06-12 07:24:33.578066
# Unit test for function ok
def test_ok():
    class SomeError(Exception):
        pass

    with ok(SomeError):
        raise SomeError

    with raises(AssertionError):
        with ok():
            raise AssertionError

    with raises(TypeError):
        with ok():
            raise TypeError

# Generated at 2022-06-12 07:24:36.087930
# Unit test for function ok
def test_ok():

    with ok(ValueError):
        int("a")

    with pytest.raises(TypeError):
        with ok(ValueError):
            int("a")
            [][1]

# Generated at 2022-06-12 07:24:38.997465
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    try:
        with ok(NameError):
            print('hello')
        print('world')
    except NameError:
        print('bye')



# Generated at 2022-06-12 07:24:42.004298
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1/0
    with raises(OverflowError):
        with ok(ZeroDivisionError):
            1 / 0
            1 + 'a'



# Generated at 2022-06-12 07:24:45.208134
# Unit test for function ok
def test_ok():
    with ok(IndexError):
        a = []
        a[0]
    with assert_raises(NameError):
        with ok(IndexError):
            a = []
            a[0]



# Generated at 2022-06-12 07:24:49.960397
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        a = 1 + '1'
    with ok(TypeError, NameError):
        a = 1 + '1'
    with ok(TypeError, ValueError):
        a = dict()
        a[1.0] = 'hello'
    with pytest.raises(KeyError):
        with ok(TypeError, NameError):
            a = dict()
            a[1.5] = 'hello'



# Generated at 2022-06-12 07:24:55.508966
# Unit test for function ok
def test_ok():
    """Test ok() context manager."""
    # Test to ensure it works if no exception is raised
    with ok():
        pass

    # Test to ensure it works if an exception is raised
    with ok(ValueError):
        raise ValueError

    # Test to ensure it works if the right exception is raised
    with ok(ValueError):
        raise ValueError

    # Test to ensure it works if the wrong exception is raised
    with pytest.raises(ZeroDivisionError):
        with ok(ValueError):
            raise ZeroDivisionError



# Generated at 2022-06-12 07:25:06.159632
# Unit test for function ok
def test_ok():
    """Test ok function.
    """
    def func():
        with ok(ValueError, TypeError):
            raise ValueError('Value error')
        with ok(ValueError, TypeError):
            raise KeyError('Key error')
    assert_raises(KeyError, func)



# Generated at 2022-06-12 07:25:13.295877
# Unit test for function ok
def test_ok():
    # Test with a known error
    try:
        with ok():
            raise ValueError('I am a know error')
    except ValueError:
        pass
    else:
        print('error1')

    # Test with an unknown error
    try:
        with ok():
            raise TypeError('I am an unknown error')
    except TypeError:
        print('Life is good.')
    except:
        print('error2')
    else:
        print('error3')

# Generated at 2022-06-12 07:25:15.219996
# Unit test for function ok
def test_ok():
    assert ok()
    assert ok(Exception)
    assert ok(Exception, ValueError)
    assert ok(TypeError, ValueError)



# Generated at 2022-06-12 07:25:17.935940
# Unit test for function ok
def test_ok():
    try:
        with ok(Exception):
            raise Exception
    except Exception:
        pass

    try:
        with ok(ValueError):
            raise Exception
    except Exception:
        assert True
    else:
        assert False



# Generated at 2022-06-12 07:25:20.840822
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with ok(IOError):
        raise IOError("Threw IOError")

    try:
        with ok():
            raise IOError("Threw IOError")
    except:
        pass

# Generated at 2022-06-12 07:25:29.059377
# Unit test for function ok
def test_ok():
    # Make sure ok doesn't pass anything
    try:
        with ok():
            assert False
    except AssertionError:
        pass

    # Make sure even passing an exception doesn't pass
    try:
        with ok():
            raise Exception()
    except Exception:
        pass

    # Make sure only passing the right exception passes
    try:
        with ok(AssertionError):
            assert False
        assert True
    except Exception:
        assert False

    # Make sure multiple exceptions work
    try:
        with ok(AssertionError, TypeError):
            assert True
            raise TypeError()
        assert True
    except Exception:
        assert False



# Generated at 2022-06-12 07:25:34.922737
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with ok(ZeroDivisionError):
        1 / 0
    with ok(TypeError, ValueError):
        int(True)
    with pytest.raises(TypeError):
        with ok(ZeroDivisionError):
            int(True)
    with pytest.raises(ZeroDivisionError):
        with ok(TypeError):
            1 / 0

# Generated at 2022-06-12 07:25:36.545877
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False



# Generated at 2022-06-12 07:25:41.607429
# Unit test for function ok
def test_ok():
    """Test function ok"""
    # Test pass exceptions
    with ok(ValueError):
        raise ValueError()

    # Test don't pass exceptions
    with pytest.raises(TypeError):
        with ok(TypeError):
            raise ValueError()

    # Test don't pass exceptions with 2 exceptions
    with pytest.raises(TypeError):
        with ok(TypeError, ValueError):
            raise UnicodeDecodeError()



# Generated at 2022-06-12 07:25:47.687974
# Unit test for function ok
def test_ok():
    """
    Test ok context manager
    """
    with ok():
        pass
    try:
        raise Exception('error')
    except Exception as e:
        with ok(Exception):
            raise e


if __name__ == "__main__":
    print('Test ok context manager')
    test_ok()

# Generated at 2022-06-12 07:26:05.455061
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError()
    with ok(TypeError):
        int('N/A')



# Generated at 2022-06-12 07:26:13.873677
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with ok(TypeError, ValueError):
        print("Testing ok")
        pass

    with ok(TypeError, ValueError):
        print("Testing ok")
        raise TypeError("Testing ok")

    with ok(TypeError, ValueError):
        print("Testing ok")
        raise ValueError("Testing ok")

    with pytest.raises(AssertionError):
        with ok(TypeError, ValueError):
            print("Testing ok")
            raise AssertionError("Testing ok")

# Generated at 2022-06-12 07:26:16.350637
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False
    with ok():
        assert True
    with ok():
        assert False



# Generated at 2022-06-12 07:26:20.299091
# Unit test for function ok
def test_ok():
    with pytest.raises(ZeroDivisionError):
        with ok(TypeError):
            1 / 0

    with pytest.raises(TypeError):
        with ok(ZeroDivisionError):
            1 / 0



# Generated at 2022-06-12 07:26:26.882530
# Unit test for function ok
def test_ok():
    try:
        with ok(ValueError, TypeError):
            val = int('a')
            raise TypeError
            return val
    except ValueError:
        print('ValueError')
    except TypeError:
        print('TypeError')

    try:
        with ok(ValueError, TypeError):
            val = int('a')
            return val
    except ValueError:
        print('ValueError')
    except TypeError:
        print('TypeError')
    except Exception as e:
        print(e)


#
# Cleaner
#
# Trim strings

# Generated at 2022-06-12 07:26:32.651549
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False

    with ok(ValueError, AssertionError):
        assert False

    with raises(ZeroDivisionError):
        with ok(AssertionError):
            1 / 0

    # with doesn't raise AssertionError, exception is not passed
    with raises(AssertionError):
        with ok(ZeroDivisionError):
            assert False


# Context manager to ensure a function was called exactly n times

# Generated at 2022-06-12 07:26:36.317657
# Unit test for function ok
def test_ok():
    with ok():
        pass
    try:
        with ok():
            raise Exception('error')
        assert False, 'Exception was not raised'
    except Exception:
        pass
    with ok(Exception):
        raise Exception('error')
    try:
        with ok(ValueError):
            raise Exception('error')
        assert False, 'Exception was not raised'
    except Exception:
        pass

# Generated at 2022-06-12 07:26:39.850121
# Unit test for function ok
def test_ok():
    """Unit test for function ok.
    """
    with ok(ValueError):
        int('a')
    with ok(ValueError, ZeroDivisionError):
        int('a')
        1/0



# Generated at 2022-06-12 07:26:44.246474
# Unit test for function ok
def test_ok():
    """Test function ok"""
    with ok(ValueError):
        raise ValueError
    try:
        with ok(ValueError):
            raise TypeError
    except TypeError:
        pass
    else:
        raise AssertionError("TypeError should have been raised")



# Generated at 2022-06-12 07:26:47.841917
# Unit test for function ok
def test_ok():
    """Test the ok function."""
    with ok():
        raise ValueError()

    with ok(ValueError):
        raise ValueError()

    with raises(ZeroDivisionError):
        with ok(ValueError):
            raise ZeroDivisionError()

# Generated at 2022-06-12 07:27:22.194163
# Unit test for function ok
def test_ok():
    # Do stuff but don't raise the exception
    with ok(builtins.KeyError):
        pass

    try:
        # Do stuff but raise an exception
        with ok(builtins.KeyError):
            raise builtins.ZeroDivisionError('Test zero division')
        assert False
    except ZeroDivisionError:
        # Test passes since zero division error is raised
        pass


# Function to test the ok function

# Generated at 2022-06-12 07:27:25.535848
# Unit test for function ok
def test_ok():
    """Test function ok"""
    from contextlib import suppress
    with suppress(ValueError):
        "This"  # pylint: disable=unused-variable
    with ok(ValueError):
        "This"  # pylint: disable=unused-variable



# Generated at 2022-06-12 07:27:28.449112
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError

# Generated at 2022-06-12 07:27:37.265275
# Unit test for function ok
def test_ok():
    with ok(TypeError, ValueError):
        raise TypeError()

# Generated at 2022-06-12 07:27:41.130547
# Unit test for function ok
def test_ok():
    """Test function ok"""
    with ok(UnicodeDecodeError):
        u"".encode("ascii")
    try:
        with ok(UnicodeDecodeError):
            1 / 0
    except ZeroDivisionError:
        return
    assert False



# Generated at 2022-06-12 07:27:49.400956
# Unit test for function ok
def test_ok():
    with ok(NameError):
        x = ''
    with ok(NameError):
        x = 1
    with raises(NameError):
        with ok(IndexError):
            x = ''
            raise NameError
    with raises(NameError):
        with ok(TypeError):
            x = ''
            raise NameError


#@contextmanager
#def file_open(file_name, mode='r'):
#    """Context manager to open files.
#    :param file_name: File name
#    :param mode: Opening mode
#    """
#    fh = open(file_name, mode)
#    yield fh
#    fh.close()



# Generated at 2022-06-12 07:27:50.650870
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')



# Generated at 2022-06-12 07:27:52.107505
# Unit test for function ok
def test_ok():
    with ok(ValueError, TypeError):
        raise TypeError



# Generated at 2022-06-12 07:27:58.368673
# Unit test for function ok
def test_ok():
    
    # Test a case where there is no exception
    with ok(KeyError):
        print("No exception")
    
    # Test a case where the exception is not in the list of exceptions to pass
    with pytest.raises(ValueError):
        with ok(KeyError):
            raise ValueError("Raise ValueError")
    
    # Test a case where the exception is in the list of exceptions to pass
    with ok(KeyError):
        raise KeyError("Raise KeyError")

# Generated at 2022-06-12 07:28:00.175796
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        x = 1 / 0
    assert x == None



# Generated at 2022-06-12 07:29:04.595439
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    pass


if __name__ == "__main__":
    # Unit test
    # test_ok()

    pass

# Generated at 2022-06-12 07:29:07.137144
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        print("test")
        raise ValueError
    with ok(ValueError):
        print("test2")
        raise TypeError
    print("test ok")



# Generated at 2022-06-12 07:29:10.351860
# Unit test for function ok
def test_ok():
    with ok(KeyError):
        {}["key"] = None

    # Test for unexpected exceptions
    with pytest.raises(IndexError):
        {}["key"] = None

# Generated at 2022-06-12 07:29:12.838972
# Unit test for function ok
def test_ok():
    with ok(FileNotFoundError):
        with open('foo.txt') as file:
            for line in file:
                print(line)



# Generated at 2022-06-12 07:29:20.981887
# Unit test for function ok
def test_ok():
    # Test for ok function
    with ok(ZeroDivisionError, TypeError):
        1 / 0
    try:
        with ok(ZeroDivisionError):
            1 / 0
    except Exception as e:
        assert str(e) == 'division by zero'

    # Test for context manager
    @contextmanager
    def test_ok():
        try:
            yield
        except Exception as e:
            if isinstance(e, (ZeroDivisionError, TypeError)):
                pass
            else:
                raise e

    with test_ok():
        1 / 0
    try:
        with test_ok():
            1 / 0
    except Exception as e:
        assert str(e) == 'division by zero'


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:29:26.760963
# Unit test for function ok
def test_ok():
    """Unit test for context manager ok."""
    with ok(ZeroDivisionError):
        q = 1 / 0

    @contextmanager
    def ok1(*exceptions):
        try:
            yield
        except Exception as e:
            assert e == ZeroDivisionError
            if isinstance(e, exceptions):
                pass
            else:
                raise e
    with ok1(ZeroDivisionError):
        q = 1 / 0



# Generated at 2022-06-12 07:29:30.375627
# Unit test for function ok
def test_ok():
    """Test function ok"""

    def _test(e):
        with ok(ZeroDivisionError):
            1 / 0
        assert e

    _test(False)
    with pytest.raises(AssertionError, match='condition is not true'):
        _test(True)

# Generated at 2022-06-12 07:29:35.021426
# Unit test for function ok
def test_ok():
    ok_exception = (TypeError, ValueError)
    with ok(*ok_exception):
        raise TypeError()
    with raises(ValueError):
        with ok(*ok_exception):
            raise ValueError()
    with raises(RuntimeError):
        with ok(*ok_exception):
            raise RuntimeError()

# Generated at 2022-06-12 07:29:41.460604
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        print("OK:", 1)
    with ok(ValueError, TypeError):
        print("OK:", 1, 2)
    with ok(IndexError, ValueError):
        print("OK:", 1, 2)


if __name__ == '__main__':
    # Unit test to print every line of code
    import line_profiler
    import atexit
    profiler = line_profiler.LineProfiler()
    profiler.add_function(ok)
    atexit.register(profiler.print_stats)

    test_ok()
    # ok(ValueError)(test_ok)

# Generated at 2022-06-12 07:29:46.124083
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError('Wrong value!')
    with ok(ValueError, NameError):
        raise ValueError('Wrong value!')
    try:
        with ok(ValueError, NameError):
            raise SyntaxError('Wrong syntax!')
    except SyntaxError as e:
        print('Exception:', e, sep='\n', end='\n\n')

    print('Ok')



# Generated at 2022-06-12 07:32:04.613948
# Unit test for function ok
def test_ok():
    # Pass when it's ok
    @ok(TypeError)
    def foobar():
        raise TypeError

    foobar()

    # Pass when it's not ok
    @ok(TypeError, NameError)
    def foobar2():
        raise ValueError

    with pytest.raises(ValueError):
        foobar2()

# Generated at 2022-06-12 07:32:08.911558
# Unit test for function ok
def test_ok():
    """Test function ok"""
    with ok(TypeError):
        int('hello')
    with pytest.raises(ValueError):
        int('hello')


# Homework: use context manager to write a solution for the exercise
# in the README.md.
# BEGIN

# Generated at 2022-06-12 07:32:12.889867
# Unit test for function ok
def test_ok():
    ok(ValueError)

    with ok(ValueError) as e:
        raise ValueError()
    assert e is None
    print(e)


try:
    with ok(ValueError):
        raise IndexError()
except IndexError:
    pass



# Generated at 2022-06-12 07:32:14.762074
# Unit test for function ok
def test_ok():
    with ok(Exception) as x:
        raise Exception
    assert x is None



# Generated at 2022-06-12 07:32:16.232717
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with ok(AssertionError):
        assert False



# Generated at 2022-06-12 07:32:18.128635
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        print('passed')
        raise ValueError


# Test for wrong exception

# Generated at 2022-06-12 07:32:19.921405
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(IndexError):
        [][1]



# Generated at 2022-06-12 07:32:20.712677
# Unit test for function ok
def test_ok():
    """Test function ok"""
    assert ok()



# Generated at 2022-06-12 07:32:29.234842
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        {'a': 1}[1]
    # OK because ok lets it pass
    with ok(Exception) as e:
        raise ValueError('oops')
        assert isinstance(e, ValueError), 'ValueError not raised'

    with ok(Exception):
        pass
    with ok(Exception):
        raise ValueError('oops')
    with ok(Exception):
        raise KeyError('oops')
    with ok(Exception):
        raise StopIteration('oops')
    with ok(Exception):
        raise StopAsyncIteration('oops')
    with ok(Exception):
        raise TimeoutError('oops')
    with ok(Exception):
        raise ArithmeticError('oops')
    with ok(Exception):
        raise LookupError('oops')
    with ok(Exception):
        raise AttributeError('oops')

# Generated at 2022-06-12 07:32:31.730102
# Unit test for function ok
def test_ok():
    """Test for ok"""
    with ok():
        pass
    with ok(ZeroDivisionError, ArithmeticError):
        pass
    with raises(NameError):
        with ok(ZeroDivisionError, ArithmeticError):
            raise NameError