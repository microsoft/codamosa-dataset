

# Generated at 2022-06-12 07:23:03.011856
# Unit test for function ok
def test_ok():
    """
    >>> with ok(ValueError):
    ...    raise ValueError
    >>> with ok(ValueError):
    ...    raise ValueError()
    >>> with ok(ValueError):
    ...    raise TypeError
    Traceback (most recent call last):
    ...
    TypeError
    """


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 07:23:08.718774
# Unit test for function ok
def test_ok():
    """Test function ok"""
    with ok(Exception):
        raise Exception()

    with raises(Exception):
        with ok():
            raise Exception()

    with raises(Exception):
        with ok(ZeroDivisionError):
            raise Exception()


if __name__ == '__main__':
    import pytest
    pytest.main(["-s", __file__])

# Generated at 2022-06-12 07:23:11.827305
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError



# Generated at 2022-06-12 07:23:17.737936
# Unit test for function ok
def test_ok():
    """Tests if function ok works."""
    with ok():
        1 / 0
    with ok(ZeroDivisionError, TypeError):
        1 / 0
    with ok(TypeError):
        1 / 0
    with ok(ZeroDivisionError):
        1 / 0


# Placing code under tests
if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:23:20.144649
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('hello')
    with raises(ValueError):
        int('hello')



# Generated at 2022-06-12 07:23:24.348262
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError

    try:
        with ok(ValueError):
            raise TypeError
    except TypeError:
        pass


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-12 07:23:26.438477
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError("ValueError")
    with ok(ValueError):
        raise AssertionError("AssertionError")



# Generated at 2022-06-12 07:23:29.912060
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with ok(TypeError):
        1 / 0  # This should pass
    with raises(ValueError):
        with ok(TypeError):
            1 + 'a'  # This should raise ValueError



# Generated at 2022-06-12 07:23:37.917554
# Unit test for function ok
def test_ok():
    """Test for function ok.
    """
    with ok(AssertionError):
        assert False
    with pytest.raises(AssertionError):
        with ok():
            assert False
    with ok(AssertionError, ValueError):
        assert False
    with pytest.raises(TypeError) as excinfo:
        with ok(ValueError):
            raise TypeError('test_ok')
    assert 'test_ok' in str(excinfo.value)



# Generated at 2022-06-12 07:23:44.708246
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""

    # Test correct handling of exceptions
    with ok(OSError, ValueError):
        os.remove('/file/not/there')
        int('6')

    # Test exception gets raised if not specified
    with pytest.raises(OSError):
        with ok(ValueError):
            os.remove('/file/not/there')

    # Test exception gets raised if not specified
    with pytest.raises(ValueError):
        with ok(OSError):
            int('6')

# Generated at 2022-06-12 07:23:48.285337
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')

# Generated at 2022-06-12 07:23:52.623450
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError('I am ok.')
    with ok(ValueError, TypeError):
        raise TypeError('I am ok.')
    with raises(KeyboardInterrupt):
        with ok(ValueError, TypeError):
            raise KeyboardInterrupt('I am not ok.')



# Generated at 2022-06-12 07:23:54.579851
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with ok(TypeError, ValueError):
        int('A')



# Generated at 2022-06-12 07:23:59.767719
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception
    with ok():
        raise Exception
    with ok(RuntimeError, TypeError):
        raise TypeError

    with pytest.raises(TypeError):
        with ok(IOError):
            raise TypeError



# Generated at 2022-06-12 07:24:03.418304
# Unit test for function ok
def test_ok():
    # Should not raise any exceptions
    with ok(Exception):
        pass

    # Should raise an AssertionError
    with assert_raises(AssertionError):
        with ok(AssertionError):
            raise AssertionError

# Generated at 2022-06-12 07:24:04.788425
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        pass



# Generated at 2022-06-12 07:24:05.810164
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0



# Generated at 2022-06-12 07:24:09.258712
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + '2')
    try:
        with ok(TypeError, ValueError):
            raise ValueError
    except ValueError:
        print('ValueError')

    try:
        with ok(TypeError, ValueError):
            print(1 + '2')
    except TypeError:
        print('TypeError')

    assert ok(1) == 1

# Generated at 2022-06-12 07:24:13.923240
# Unit test for function ok
def test_ok():
    with ok(RuntimeError):
        raise RuntimeError('test')
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(RuntimeError, ValueError, TypeError):
        raise ValueError
    with ok(TypeError):
        pass
    with ok():
        pass

# Generated at 2022-06-12 07:24:21.896400
# Unit test for function ok
def test_ok():
    # Raise error, but pass it
    with ok(ValueError):
        raise ValueError(1)

    # Raise error and not pass it
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError(1)
        with ok():
            raise TypeError(1)

    # Raise error and pass it
    with ok(TypeError):
        raise TypeError(1)

    # Raise error and pass it
    with ok(TypeError, ValueError):
        raise ValueError(1)

    # Raise error and pass it
    with ok((TypeError, ValueError)):
        raise ValueError(1)

    # Raise error and not pass it
    with raises(ValueError):
        with ok(TypeError):
            raise ValueError(1)

    # Raise error and not pass it

# Generated at 2022-06-12 07:24:34.124511
# Unit test for function ok
def test_ok():
    """Test for function ok"""
    with ok():
        print('This should run because no exception was raised')
    with ok(ValueError):
        print('This should run because ValueError was raised')
    with ok(Exception):
        print('This should run because Exception was raised')
        raise ValueError
    with ok(IndexError):
        print('This should not run because a ValueError was raised')
        raise ValueError
    with ok(ValueError):
        print('This should not run because IndexError was raised')
        raise IndexError
    with ok(IndexError, ValueError):
        print('This should not run because a RuntimeError was raised')
        raise RuntimeError

# Generated at 2022-06-12 07:24:36.996498
# Unit test for function ok
def test_ok():
    # Test 1
    with ok(TypeError, ValueError):
        int('N/A')
    try:
        with ok(TypeError, ValueError):
            int('N/A')
    except Exception as e:
        assert type(e) == Exception



# Generated at 2022-06-12 07:24:39.980355
# Unit test for function ok
def test_ok():
    """Test function ok"""
    with ok(OSError, TypeError):
        1/0
    with ok(TypeError):
        "a" + 1
    with ok(TypeError):
        raise OSError()



# Generated at 2022-06-12 07:24:45.577264
# Unit test for function ok
def test_ok():
    """Test ok context manager to pass exceptions."""
    result = 0
    try:
        with ok(ArithmeticError):
            1 / 0
            result = 1
    except ZeroDivisionError:
        result = 2
    assert result == 1
    with ok(ArithmeticError):
        1 / 0
        result = 3
    assert result == 2



# Generated at 2022-06-12 07:24:47.269472
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception
    with raises(TypeError):
        with ok(TypeError):
            raise Exception



# Generated at 2022-06-12 07:24:50.592635
# Unit test for function ok
def test_ok():
    with ok(IndexError):
        a = 1
        a[1] = 3
    with ok(TypeError):
        1 + '1'
    with ok(IndexError, TypeError):
        a = 1
        a[1] = 3


if __name__ == "__main__":
    # test_ok()
    pass

# Generated at 2022-06-12 07:24:54.978634
# Unit test for function ok
def test_ok():
    # Should not raise exceptions
    with ok(ValueError):
        int('1')

    with ok(Exception, ValueError, TypeError):
        int('1')

    # Should raise an exception (TypeError), because we pass exceptions ValueError and TypeError
    try:
        with ok(ValueError, TypeError):
            int('abc')
    except TypeError:
        pass
    else:
        assert False



# Generated at 2022-06-12 07:25:03.408822
# Unit test for function ok
def test_ok():
    # Test normal operation
    with ok(TypeError):
        a = 1 + ''
    with ok(TypeError, StandardError):
        a = 1 + ''

    # Test that an exception that isn't covered by ok raises an exception
    with raises(TypeError):
        with ok(TypeError, UnboundLocalError):
            a = 1 + ''

    # Test that an exception that is covered by ok doesn't raise an exception
    with ok(TypeError, UnboundLocalError):
        a = 1 + ''

    # Test that an exception that is covered by ok doesn't raise an exception
    with ok(TypeError, StandardError):
        a = 1 + ''

    # Test that if nothing is raised, there is no exception
    with ok(TypeError, UnboundLocalError):
        a = 1 + 2



# Generated at 2022-06-12 07:25:05.766813
# Unit test for function ok
def test_ok():
    with ok(OSError):
        raise OSError
    with raises(TypeError):
        with ok(OSError):
            raise TypeError



# Generated at 2022-06-12 07:25:07.986020
# Unit test for function ok
def test_ok():
    try:
        with ok(AssertionError):
            assert False
    except Exception:
        assert False



# Generated at 2022-06-12 07:25:16.701077
# Unit test for function ok
def test_ok():
    try:
        with ok(RuntimeError):
            raise RuntimeError
        raise SyntaxError
    except SyntaxError:
        pass

# Generated at 2022-06-12 07:25:22.925512
# Unit test for function ok
def test_ok():
    assert_raises(RuntimeError, ok(), RuntimeError()).__exit__()
    assert_raises(RuntimeError, ok(RuntimeError), RuntimeError()).__exit__()
    assert_raises(RuntimeError, ok(ZeroDivisionError), RuntimeError()).__exit__()
    assert_raises(ZeroDivisionError, ok(RuntimeError), ZeroDivisionError()).__exit__()
    assert_raises(ZeroDivisionError, ok(RuntimeError, ZeroDivisionError), ZeroDivisionError()).__exit__()



# Generated at 2022-06-12 07:25:29.555425
# Unit test for function ok
def test_ok():
    """Test for module ok"""
    # Test for different exceptions to be passed
    with ok(ValueError):
        test = int('boo')

    with ok(ValueError, TypeError):
        test = int('boo')

    # Test for an exception to be raised
    with pytest.raises(TypeError):
        with ok(ValueError):
            test = int()

    # Test for an exception to be raised
    with pytest.raises(SyntaxError):
        with ok(ValueError):
            test = eval('/')

# Generated at 2022-06-12 07:25:35.014744
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False

    with ok(AssertionError):
        assert True

    with ok(AssertionError, TypeError):
        assert False

    with ok(AssertionError, TypeError):
        assert True

    with ok(AssertionError, TypeError):
        raise TypeError

# Run tests
test_ok()

# Generated at 2022-06-12 07:25:38.692108
# Unit test for function ok
def test_ok():
    """Test for the ok context manager."""
    with pytest.raises(TypeError):
        with ok(ValueError, TypeError):
            raise TypeError

    with ok(TypeError):
        raise TypeError
    with ok(ValueError):
        pytest.fail('ValueError raised')



# Generated at 2022-06-12 07:25:40.162302
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        1 + '1'
    assert False, 'TypeError not raised'

# Generated at 2022-06-12 07:25:44.987111
# Unit test for function ok
def test_ok():
    """Test function ok in module mytools
    """
    with ok():
        raise ValueError
    with ok(ValueError):
        raise TypeError

    with raises(TypeError):
        with ok(ValueError):
            raise TypeError


# Main application

# Generated at 2022-06-12 07:25:47.391181
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        ok()


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-12 07:25:52.837844
# Unit test for function ok
def test_ok():
    assert_raises(Exception, ok, IOError)
    assert_raises(IOError, ok, ValueError, IOError)
    assert_raises(ValueError, ok)


try:
    from contextlib import redirect_stdout
except ImportError:
    @contextmanager
    def redirect_stdout(target, *args, **kwargs):
        """Context manager to temporarily redirect stdout.
        Example:
            with redirect_stdout(open('/dev/null', 'w')):
                pass
        """
        old, sys.stdout = sys.stdout, target
        try:
            yield
        finally:
            sys.stdout = old

# Generated at 2022-06-12 07:25:54.500698
# Unit test for function ok
def test_ok():
    # Test ok
    with ok(ZeroDivisionError):
        1 / 0
    # Test Exception
    with pytest.raises(TypeError):
        with ok(ZeroDivisionError):
            1 + '1'



# Generated at 2022-06-12 07:26:12.826530
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(TypeError):
        int('hello')

    try:
        int('')
    except Exception as e:
        assert isinstance(e, ValueError)
        assert not isinstance(e, TypeError)



# Generated at 2022-06-12 07:26:14.594364
# Unit test for function ok
def test_ok():
    with ok(TypeError, ValueError):
        raise TypeError()
    with ok(TypeError):
        raise ValueError()



# Generated at 2022-06-12 07:26:17.521532
# Unit test for function ok
def test_ok():
    with ok():
        raise Exception('Boom!')

    with raises(Exception):
        with ok(ValueError):
            raise Exception('Boom!')



# Generated at 2022-06-12 07:26:23.607908
# Unit test for function ok
def test_ok():
    """Test function ok."""
    val = True
    try:
        with ok(TypeError, IndexError, ZeroDivisionError):
            0/0
        val = False
    except ArithmeticError:
        pass
    finally:
        assert val

    try:
        with ok(TypeError, IndexError, ZeroDivisionError):
            1/0
        val = False
    except ArithmeticError:
        pass
    finally:
        assert val

    try:
        with ok(TypeError, IndexError, ZeroDivisionError):
            raise TypeError
        val = False
    except TypeError:
        pass
    finally:
        assert val

    try:
        with ok(TypeError, IndexError, ZeroDivisionError):
            raise IndexError
        val = False
    except IndexError:
        pass

# Generated at 2022-06-12 07:26:25.618080
# Unit test for function ok
def test_ok():
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok():
        raise ValueError()



# Generated at 2022-06-12 07:26:28.551069
# Unit test for function ok
def test_ok():
    """Test function ok"""
    with ok(KeyError, ValueError):
        d = {}
        d['a']
    with ok(Exception):
        d = {}
        d['a']



# Generated at 2022-06-12 07:26:32.349127
# Unit test for function ok
def test_ok():
    with ok():
        raise Exception('spam')

    with raises(Exception):
        with ok(Exception):
            raise Exception('foo')

    with ok(ValueError):
        raise ValueError('foo')

    with raises(Exception):
        with ok(ValueError):
            raise Exception('foo')

# Generated at 2022-06-12 07:26:35.179083
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        pass

    with ok(ValueError, TypeError):
        int('test')

    with ok(ValueError, TypeError):
        {}['test']

    with ok(Exception):
        raise Exception



# Generated at 2022-06-12 07:26:36.860323
# Unit test for function ok
def test_ok():
    with ok(IndexError):
        a = []
        a[5] = 0
        print(a)



# Generated at 2022-06-12 07:26:41.342696
# Unit test for function ok
def test_ok():
    with ok(RuntimeError):
        raise RuntimeError()

    with ok(RuntimeError) as okexception:
        okexception.__exit__(None, None, None)

    with raises(AssertionError):
        with ok(RuntimeError):
            raise AssertionError()



# Generated at 2022-06-12 07:27:13.952033
# Unit test for function ok
def test_ok():
    """Tests for function ok."""
    with ok(TypeError, IndexError):
        1 + "s"

    with ok(TypeError, IndexError):
        x = [1, 2, 3]
        x[10]

    try:
        with ok(TypeError, IndexError):
            1 / 0
    except ZeroDivisionError:
        pass



# Generated at 2022-06-12 07:27:15.723065
# Unit test for function ok
def test_ok():
    with ok():
        a = 1 / 0



# Generated at 2022-06-12 07:27:20.781011
# Unit test for function ok
def test_ok():
    """Funciton ok unit test.
    """
    with ok(Exception):
        raise Exception("Test")
    try:
        with ok(TypeError):
            raise ValueError("Test")
    except ValueError:
        pass
    else:
        assert False, "Test failed"


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:27:24.412929
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception()

    with ok():
        raise Exception()

    with ok(ValueError, AttributeError):
        raise AttributeError()

    with ok(ValueError):
        raise TypeError()



# Generated at 2022-06-12 07:27:28.154296
# Unit test for function ok
def test_ok():

    with ok(ValueError):
        raise ValueError
    try:
        with ok(ValueError):
            raise TypeError
        assert False
    except TypeError as e:
        assert True



# Generated at 2022-06-12 07:27:33.219667
# Unit test for function ok
def test_ok():
    # Test ok()
    with ok(KeyError, TypeError):
        raise KeyError('Key')
    with ok(KeyError, TypeError):
        raise TypeError('Type')
    with pytest.raises(ZeroDivisionError):
        with ok(KeyError, TypeError):
            raise ZeroDivisionError('Zero')



# Generated at 2022-06-12 07:27:38.609431
# Unit test for function ok
def test_ok():
    try:
        with ok():
            raise TypeError
    except TypeError:
        pass

    try:
        with ok(TypeError):
            raise TypeError
    except TypeError:
        pass

    try:
        with ok(TypeError):
            raise NameError
    except NameError:
        pass

    try:
        with ok(TypeError):
            raise KeyError
    except KeyError:
        pass

# Generated at 2022-06-12 07:27:40.054998
# Unit test for function ok

# Generated at 2022-06-12 07:27:43.419882
# Unit test for function ok
def test_ok():
    """Test ok()."""

    # This test should not raise an exception
    with ok(AssertionError):
        assert False

    # This test should raise an exception
    with pytest.raises(NameError):
        with ok(AssertionError):
            assert True



# Generated at 2022-06-12 07:27:47.091856
# Unit test for function ok
def test_ok():
    """Test for function 'ok'"""
    try:
        with ok(ValueError):
            int('N/A')
    except Exception as e:
        raise AssertionError("Function 'ok' raised an exception {}".format(e))


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-12 07:28:49.949307
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception
    with raises(OSError):
        with ok(Exception):
            raise OSError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-12 07:28:51.929349
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False


try:
    raise ValueError('Beep Beep')
except ValueError as e:
    print(e)



# Generated at 2022-06-12 07:28:54.658909
# Unit test for function ok
def test_ok():
    l = [1, 2, 3]

    with ok(IndexError):
        print("IndexError occurs")
        print(l[3])

    with ok(TypeError):
        print("TypeError occurs")
        print(l[4])



# Generated at 2022-06-12 07:28:58.150143
# Unit test for function ok
def test_ok():
    """Test function ok."""

    # Function ok can pass exceptions when they are specified
    with ok(IndexError):
        raise IndexError

    # Function ok can raise exceptions when they are not specified
    with pytest.raises(ZeroDivisionError):
        with ok(IndexError):
            raise ZeroDivisionError

# Generated at 2022-06-12 07:28:59.790049
# Unit test for function ok
def test_ok():
    with ok(IndexError):
        lst = []
        bad_index = lst[1]
    assert True



# Generated at 2022-06-12 07:29:08.872669
# Unit test for function ok
def test_ok():
    """Test the context manager ok works as intended."""
    with ok():
        pass

    with raises(Exception):
        with ok(Exception):
            raise Exception

    with raises(ZeroDivisionError):
        with ok(ZeroDivisionError):
            raise ZeroDivisionError

    with raises(TypeError):
        with ok(ZeroDivisionError):
            raise TypeError


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-12 07:29:15.881994
# Unit test for function ok
def test_ok():
    """Tests that ok() context manager passes exceptions."""

    @ok(ValueError)
    def f():
        raise ValueError()

    with ok(ValueError):
        raise ValueError()

    with pytest.raises(TypeError):
        with ok(TypeError):
            raise ValueError()

    with pytest.raises(ZeroDivisionError):
        with ok(TypeError):
            raise ZeroDivisionError()

    with pytest.raises(ZeroDivisionError):
        f()

# Generated at 2022-06-12 07:29:19.227741
# Unit test for function ok
def test_ok():
    # Test ok context manager
    # Test to ensure error is not raised
    with ok(KeyError):
        d = dict()
        d['a']  # Raises KeyError

    # Test to ensure error is raised
    with raises(TypeError):
        with ok(KeyError):
            raise TypeError

# Generated at 2022-06-12 07:29:27.041546
# Unit test for function ok
def test_ok():
    """Testing function ok."""
    with ok(Exception):
        print('test_ok: ok(Exception): No exception')
    with ok(ValueError) as cm:
        raise ValueError
    assert cm.exception is not None
    with ok(ValueError, TypeError) as cm:
        raise TypeError
    assert cm.exception is not None
    with pytest.raises(IndexError):
        with ok(TypeError, ValueError):
            raise IndexError
    with pytest.raises(ValueError):
        with ok(TypeError) as cm:
            raise ValueError
    assert cm.exception is not None

# Generated at 2022-06-12 07:29:37.533705
# Unit test for function ok
def test_ok():
    """Test function ok.
    """
    # define exceptions
    class TooBigNumber(Exception):
        pass

    class NoNumber(Exception):
        pass

    def check_exception(a, b):
        try:
            with ok(TooBigNumber):
                print(a + b)
                print('This is a too big number!')
        except Exception:
            print('Something happened.')

    # a = 2, b = 2
    print('\nTest for a = 2, b = 2')
    check_exception(2, 2)

    # a = 2, b = 3
    print('\nTest for a = 2, b = 3')
    check_exception(2, 3)


if __name__ == '__main__':
    # test function ok
    test_ok()

# Generated at 2022-06-12 07:31:53.278346
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        raise TypeError
    with ok(Exception):
        raise Exception
    with ok(KeyError):
        raise TypeError

    def f():
        with ok():
            raise TypeError

    with pytest.raises(TypeError):
        f()
    with pytest.raises(Exception):
        with ok(KeyError):
            raise Exception



# Generated at 2022-06-12 07:31:59.150090
# Unit test for function ok
def test_ok():
    """Test for ok function"""

    # Test normal behavior
    with ok(TypeError):
        print(1 + 'a')
    with ok(TypeError):
        raise TypeError
    with pytest.raises(ZeroDivisionError):
        with ok(TypeError):
            raise ZeroDivisionError

    # Test context manager with no exceptions
    with ok():
        raise TypeError



# Generated at 2022-06-12 07:32:00.143844
# Unit test for function ok
def test_ok():
    with ok():
        1 / 0

# Generated at 2022-06-12 07:32:01.532707
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print('Tested successful!')



# Generated at 2022-06-12 07:32:02.813677
# Unit test for function ok

# Generated at 2022-06-12 07:32:04.493264
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int("foo")

    with ok(TypeError):
        int("bar")



# Generated at 2022-06-12 07:32:07.041586
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0

    with ok(ValueError):
        1 / 0



# Generated at 2022-06-12 07:32:11.225036
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with pytest.raises(IndexError):
        with ok(ValueError, TypeError):
            raise IndexError

# Generated at 2022-06-12 07:32:17.561993
# Unit test for function ok
def test_ok():
    """Test the ok function."""
    try:
        with ok():
            raise Exception('an exception')
    except Exception:
        pass
    else:
        assert False, 'should have raised an exception'
    try:
        with ok(Exception):
            raise Exception('another exception')
    except Exception:
        pass
    else:
        assert False, 'should have raised an exception'
    with ok((KeyError, ValueError)):
        raise KeyError("a key error")



# Generated at 2022-06-12 07:32:20.602432
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
        raise Exception()
    assert True
    try:
        with ok(ValueError):
            raise ValueError()
            raise KeyError()
    except Exception as e:
        assert isinstance(e, KeyError)
    assert True