

# Generated at 2022-06-18 03:53:12.773361
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception



# Generated at 2022-06-18 03:53:15.081104
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:53:20.792947
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:53:30.974199
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('hello')
    with ok(TypeError):
        int(3.14)
    with ok(TypeError):
        int(3.14)
    with ok(TypeError):
        int('hello')
    with ok(TypeError):
        int('hello')
    with ok(TypeError):
        int('hello')
    with ok(TypeError):
        int('hello')
    with ok(TypeError):
        int('hello')
    with ok(TypeError):
        int('hello')
    with ok(TypeError):
        int('hello')
    with ok(TypeError):
        int('hello')
    with ok(TypeError):
        int('hello')
    with ok(TypeError):
        int('hello')
    with ok(TypeError):
        int('hello')

# Generated at 2022-06-18 03:53:41.184472
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:53:43.698829
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError



# Generated at 2022-06-18 03:53:49.057699
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise NameError



# Generated at 2022-06-18 03:53:51.855288
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise NameError()



# Generated at 2022-06-18 03:53:56.942872
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:54:02.676577
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:54:14.374897
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:54:18.961767
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:54:28.661548
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:54:39.200048
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:54:43.631779
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:54:47.937899
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int(None)
    with ok(TypeError, ValueError):
        int('N/A')



# Generated at 2022-06-18 03:54:53.461767
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:54:56.376442
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()



# Generated at 2022-06-18 03:55:00.412048
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:55:05.778945
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise StopIteration
    with ok(ValueError):
        raise KeyboardInterrupt



# Generated at 2022-06-18 03:55:11.028693
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')



# Generated at 2022-06-18 03:55:20.602325
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('a')

    with ok(TypeError, ValueError):
        int('a')

    with ok(TypeError, ValueError):
        int('1')

    with ok(TypeError, ValueError):
        int(1)

    with ok(TypeError, ValueError):
        int(1.0)

    with ok(TypeError, ValueError):
        int(1.1)

    with ok(TypeError, ValueError):
        int(1.9)

    with ok(TypeError, ValueError):
        int(1.11)

    with ok(TypeError, ValueError):
        int(1.99)

    with ok(TypeError, ValueError):
        int(1.111)

    with ok(TypeError, ValueError):
        int(1.999)

   

# Generated at 2022-06-18 03:55:24.008398
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise RuntimeError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 03:55:33.228268
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:55:37.089901
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:55:41.775403
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise AttributeError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 03:55:44.440607
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception



# Generated at 2022-06-18 03:55:46.811290
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')

    with ok(ValueError):
        raise ValueError('N/A')

    with ok(ValueError):
        raise TypeError('N/A')



# Generated at 2022-06-18 03:55:53.513758
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(int('a'))
    with ok(TypeError, ValueError):
        print(int('1'))
    with ok(TypeError, ValueError):
        print(1 + 1)
    with ok(TypeError, ValueError):
        print(1 + '1')



# Generated at 2022-06-18 03:55:56.838357
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:56:09.417430
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 03:56:13.389913
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError

# Generated at 2022-06-18 03:56:20.046734
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:56:23.436181
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
        raise TypeError



# Generated at 2022-06-18 03:56:29.002273
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
        raise TypeError
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
        raise ValueError
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
        raise NameError



# Generated at 2022-06-18 03:56:33.653183
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:56:37.597505
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int(None)
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int(None)



# Generated at 2022-06-18 03:56:40.457452
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError("test")
    with ok(ValueError):
        raise TypeError("test")
    with pytest.raises(TypeError):
        with ok(ValueError):
            raise TypeError("test")



# Generated at 2022-06-18 03:56:45.112977
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError



# Generated at 2022-06-18 03:56:47.952017
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError



# Generated at 2022-06-18 03:57:11.772755
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise BaseException



# Generated at 2022-06-18 03:57:15.709784
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise Exception()



# Generated at 2022-06-18 03:57:24.917729
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
   

# Generated at 2022-06-18 03:57:30.685213
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:57:33.760096
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int('N/A')



# Generated at 2022-06-18 03:57:41.424516
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:57:48.751800
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError



# Generated at 2022-06-18 03:57:51.204804
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:57:55.700781
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise RuntimeError



# Generated at 2022-06-18 03:57:59.904210
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        int('N/A')
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise NameError



# Generated at 2022-06-18 03:58:38.452701
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise RuntimeError()



# Generated at 2022-06-18 03:58:45.978467
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(int('a'))
    with ok(TypeError, ValueError):
        print(int('1'))
    with ok(TypeError):
        print(int('a'))
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(int('a'))
    with ok(TypeError, ValueError):
        print(int('1'))
    with ok(TypeError):
        print(int('a'))
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(int('a'))

# Generated at 2022-06-18 03:58:55.073010
# Unit test for function ok
def test_ok():
    """Test for function ok"""
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + 1)
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(int('a'))
    with ok(TypeError, ValueError):
        print(1 + 1)
    with ok(TypeError, ValueError):
        print(int('a'))



# Generated at 2022-06-18 03:59:00.536148
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError

# Generated at 2022-06-18 03:59:04.912247
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError



# Generated at 2022-06-18 03:59:09.397156
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception()
    with ok(Exception):
        raise ValueError()
    with ok(Exception):
        raise TypeError()
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()
    with ok(ValueError):
        raise Exception()


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-18 03:59:12.968321
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise RuntimeError



# Generated at 2022-06-18 03:59:19.344559
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception
    with ok(Exception):
        raise ValueError
    with ok(Exception):
        raise TypeError
    with ok(Exception):
        raise NameError
    with ok(Exception):
        raise AttributeError
    with ok(Exception):
        raise SyntaxError
    with ok(Exception):
        raise IndexError
    with ok(Exception):
        raise KeyError
    with ok(Exception):
        raise ZeroDivisionError
    with ok(Exception):
        raise RuntimeError
    with ok(Exception):
        raise NotImplementedError
    with ok(Exception):
        raise ImportError
    with ok(Exception):
        raise TypeError
    with ok(Exception):
        raise ValueError
    with ok(Exception):
        raise StopIteration
    with ok(Exception):
        raise StopAsyncIter

# Generated at 2022-06-18 03:59:24.603905
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print('TypeError')
        raise TypeError
    with ok(TypeError, ValueError):
        print('TypeError')
        raise TypeError
    with ok(TypeError, ValueError):
        print('ValueError')
        raise ValueError
    with ok(TypeError, ValueError):
        print('IndexError')
        raise IndexError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 03:59:32.351949
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()



# Generated at 2022-06-18 04:00:54.032945
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise Exception



# Generated at 2022-06-18 04:01:03.277937
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
        int('N/A')
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
        int('N/A')
        int('N/A')
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
        int('N/A')
        int('N/A')
        int('N/A')
        int('N/A')

# Generated at 2022-06-18 04:01:06.601934
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 04:01:09.417643
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('42')
    with ok(TypeError, ValueError):
        int(42)
    with ok(TypeError, ValueError):
        int(42.0)



# Generated at 2022-06-18 04:01:13.007988
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise Exception



# Generated at 2022-06-18 04:01:15.801582
# Unit test for function ok
def test_ok():
    """Test for function ok."""
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 04:01:22.621767
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('hello')
    with ok(TypeError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
   

# Generated at 2022-06-18 04:01:27.357959
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('42')
    with ok(TypeError, ValueError):
        int(42)
    with ok(TypeError, ValueError):
        int(42.0)



# Generated at 2022-06-18 04:01:35.420634
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ZeroDivisionError):
        1 / 0
    with ok(ZeroDivisionError):
        raise ZeroDivisionError
    with ok(ZeroDivisionError):
        raise ValueError
    with ok(ZeroDivisionError):
        raise TypeError
    with ok(ZeroDivisionError, TypeError):
        raise TypeError
    with ok(ZeroDivisionError, TypeError):
        raise ValueError
    with ok(ZeroDivisionError, TypeError):
        raise ZeroDivisionError
    with ok(ZeroDivisionError, TypeError):
        1 / 0
    with ok(ZeroDivisionError, TypeError):
        raise TypeError
    with ok(ZeroDivisionError, TypeError):
        raise ValueError
    with ok(ZeroDivisionError, TypeError):
        raise ZeroDivisionError

# Generated at 2022-06-18 04:01:37.571614
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError

