

# Generated at 2022-06-18 03:53:19.336928
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")

# Generated at 2022-06-18 03:53:23.878283
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:53:27.806776
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with ok(ZeroDivisionError):
        raise ValueError
    with ok(ZeroDivisionError, ValueError):
        raise ValueError
    with ok(ZeroDivisionError, ValueError):
        raise TypeError



# Generated at 2022-06-18 03:53:32.194652
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 03:53:37.889667
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise NameError



# Generated at 2022-06-18 03:53:44.922780
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print('TypeError')
        raise TypeError
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
        raise TypeError
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
        raise ValueError
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
        raise NameError
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
        raise NameError
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
        raise NameError
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
        raise NameError
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
        raise

# Generated at 2022-06-18 03:53:48.364331
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:53:51.475150
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:53:55.362543
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError



# Generated at 2022-06-18 03:54:06.193451
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:54:16.083921
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')

# Generated at 2022-06-18 03:54:20.979338
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError

# Generated at 2022-06-18 03:54:23.010817
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int(None)



# Generated at 2022-06-18 03:54:32.779262
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError

# Generated at 2022-06-18 03:54:36.054933
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:54:38.957240
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:54:47.733204
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError

# Generated at 2022-06-18 03:54:51.058357
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise IndexError



# Generated at 2022-06-18 03:54:53.461750
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()



# Generated at 2022-06-18 03:55:01.606360
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise AttributeError
    with ok(ValueError, TypeError):
        raise AttributeError
    with ok(ValueError, TypeError):
        raise AttributeError
    with ok(ValueError, TypeError):
        raise AttributeError
    with ok(ValueError, TypeError):
        raise AttributeError
    with ok(ValueError, TypeError):
        raise AttributeError
    with ok(ValueError, TypeError):
        raise AttributeError
    with ok(ValueError, TypeError):
        raise AttributeError
    with ok(ValueError, TypeError):
        raise AttributeError
   

# Generated at 2022-06-18 03:55:07.173936
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()



# Generated at 2022-06-18 03:55:13.795383
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with ok(TypeError):
        1 + '1'
    with ok(ZeroDivisionError, TypeError):
        1 / '1'
    with ok(ZeroDivisionError, TypeError):
        1 / 0
    with ok(ZeroDivisionError, TypeError):
        1 + '1'



# Generated at 2022-06-18 03:55:15.783173
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int('N/A')



# Generated at 2022-06-18 03:55:19.245422
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError, TypeError):
        int('N/A')
    with ok(ValueError, TypeError):
        int('N/A')
    with ok(ValueError, TypeError):
        int('N/A')
    with ok(ValueError, TypeError):
        int('N/A')
    with ok(ValueError, TypeError):
        int('N/A')
    with ok(ValueError, TypeError):
        int('N/A')
    with ok(ValueError, TypeError):
        int('N/A')
    with ok(ValueError, TypeError):
        int('N/A')
    with ok(ValueError, TypeError):
        int('N/A')

# Generated at 2022-06-18 03:55:29.325516
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise StopIteration
    with ok(ValueError):
        raise StopAsyncIteration
    with ok(ValueError):
        raise GeneratorExit
    with ok(ValueError):
        raise SystemExit
    with ok(ValueError):
        raise KeyboardInterrupt
    with ok(ValueError):
        raise SystemError
    with ok(ValueError):
        raise ImportError
    with ok(ValueError):
        raise EOFError
    with ok(ValueError):
        raise RuntimeError
    with ok(ValueError):
        raise NotImplementedError
    with ok(ValueError):
        raise NameError

# Generated at 2022-06-18 03:55:37.836115
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:55:45.848866
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
   

# Generated at 2022-06-18 03:55:51.917042
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError



# Generated at 2022-06-18 03:55:56.838915
# Unit test for function ok
def test_ok():
    """Test function ok"""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise NameError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 03:56:00.319073
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(TypeError):
        int('N/A')
    with ok(TypeError):
        raise ValueError



# Generated at 2022-06-18 03:56:09.479797
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with ok(ZeroDivisionError, TypeError):
        1 / 0
    with ok(TypeError):
        1 / 0



# Generated at 2022-06-18 03:56:17.535387
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('a')
    with ok(TypeError, ValueError):
        int('a')
    with ok(TypeError, ValueError):
        int('1')
    with ok(TypeError, ValueError):
        int('1')
    with ok(TypeError, ValueError):
        int('1')
    with ok(TypeError, ValueError):
        int('1')
    with ok(TypeError, ValueError):
        int('1')
    with ok(TypeError, ValueError):
        int('1')
    with ok(TypeError, ValueError):
        int('1')
    with ok(TypeError, ValueError):
        int('1')
    with ok(TypeError, ValueError):
        int('1')

# Generated at 2022-06-18 03:56:19.678170
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError

    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:56:23.694550
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:56:34.515027
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError

# Generated at 2022-06-18 03:56:37.864798
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:56:47.085641
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError

# Generated at 2022-06-18 03:56:48.712512
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int('N/A')



# Generated at 2022-06-18 03:56:50.647868
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:56:52.872741
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()



# Generated at 2022-06-18 03:57:11.817134
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:57:12.767910
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:57:14.335514
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int('N/A')



# Generated at 2022-06-18 03:57:17.544930
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        pass



# Generated at 2022-06-18 03:57:18.638397
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise Exception



# Generated at 2022-06-18 03:57:23.093962
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with raises(ValueError):
        with ok(TypeError):
            raise ValueError
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError



# Generated at 2022-06-18 03:57:28.337292
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise StopIteration



# Generated at 2022-06-18 03:57:33.519368
# Unit test for function ok
def test_ok():
    """Test function ok"""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise NameError



# Generated at 2022-06-18 03:57:36.886584
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:57:40.043956
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:58:24.279996
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(TypeError):
        print(1 + '1')

    with ok(TypeError):
        print(1 + 1)

    with ok(TypeError):
        print(1 + '1')

    with ok(TypeError, ValueError):
        print(1 + '1')

    with ok(TypeError, ValueError):
        print(1 + 1)

    with ok(TypeError, ValueError):
        print(1 + '1')

    with ok(TypeError, ValueError):
        raise ValueError

    with ok(TypeError, ValueError):
        raise TypeError

    with ok(TypeError, ValueError):
        raise NameError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 03:58:33.687108
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError

# Generated at 2022-06-18 03:58:43.224743
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
   

# Generated at 2022-06-18 03:58:51.097180
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError



# Generated at 2022-06-18 03:58:54.188176
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError



# Generated at 2022-06-18 03:58:57.134538
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:59:01.977156
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:59:08.059922
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(Exception):
        raise Exception
    with ok(Exception):
        raise ValueError
    with ok(Exception):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise AttributeError



# Generated at 2022-06-18 03:59:11.790863
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError

    try:
        with ok(ValueError):
            raise TypeError
    except TypeError:
        pass
    else:
        assert False, "TypeError not raised"



# Generated at 2022-06-18 03:59:18.535980
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 04:00:40.529606
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception



# Generated at 2022-06-18 04:00:41.807942
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')



# Generated at 2022-06-18 04:00:46.454823
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 04:00:52.894656
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')

# Generated at 2022-06-18 04:00:57.305040
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise StopIteration
    with ok(ValueError):
        raise KeyError



# Generated at 2022-06-18 04:01:00.976846
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 04:01:07.331128
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError

# Generated at 2022-06-18 04:01:12.011266
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError, ValueError):
        print(1 + "1")
    with ok(TypeError, ValueError):
        print(1 + 1)
    with ok(TypeError, ValueError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError, ValueError):
        print(1 + "1")
    with ok(TypeError, ValueError):
        print(1 + 1)
   

# Generated at 2022-06-18 04:01:14.305356
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()



# Generated at 2022-06-18 04:01:19.493372
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError

