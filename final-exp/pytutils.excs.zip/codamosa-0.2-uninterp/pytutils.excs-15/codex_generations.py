

# Generated at 2022-06-18 03:53:08.760581
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:53:14.904917
# Unit test for function ok
def test_ok():
    """Test for function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:53:19.716697
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise AttributeError



# Generated at 2022-06-18 03:53:22.715235
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise KeyError



# Generated at 2022-06-18 03:53:24.320578
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()



# Generated at 2022-06-18 03:53:33.195895
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')

# Generated at 2022-06-18 03:53:38.716804
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise NameError



# Generated at 2022-06-18 03:53:40.961138
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')

    with ok(ValueError):
        raise ValueError

    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:53:44.068835
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception



# Generated at 2022-06-18 03:53:51.991217
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')

# Generated at 2022-06-18 03:54:03.958036
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:54:08.246719
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + '1')

    with ok(TypeError, ValueError):
        print(1 + '1')

    with ok(TypeError, ValueError):
        print(1 + 1)

    with ok(TypeError, ValueError):
        print(1 + '1')



# Generated at 2022-06-18 03:54:14.039931
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:54:18.356739
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:54:28.078693
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')

# Generated at 2022-06-18 03:54:31.257649
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:54:32.987563
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError



# Generated at 2022-06-18 03:54:39.268114
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:54:42.235885
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:54:49.239871
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('a')

    with ok(TypeError):
        int('a')

    with ok(TypeError, ValueError):
        int('a')

    with ok(TypeError, ValueError):
        int('a')

    with ok(TypeError, ValueError):
        int('a')

    with ok(TypeError, ValueError):
        int('a')

    with ok(TypeError, ValueError):
        int('a')

    with ok(TypeError, ValueError):
        int('a')

    with ok(TypeError, ValueError):
        int('a')

    with ok(TypeError, ValueError):
        int('a')

    with ok(TypeError, ValueError):
        int('a')

    with ok(TypeError, ValueError):
        int('a')

   

# Generated at 2022-06-18 03:54:56.968839
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError



# Generated at 2022-06-18 03:55:01.024398
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise Exception



# Generated at 2022-06-18 03:55:10.754397
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:55:14.088332
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()



# Generated at 2022-06-18 03:55:16.005466
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with pytest.raises(TypeError):
        with ok(ValueError):
            raise TypeError



# Generated at 2022-06-18 03:55:19.044553
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:55:23.164866
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:55:29.477655
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError

# Generated at 2022-06-18 03:55:30.880687
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:55:34.805979
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise Exception



# Generated at 2022-06-18 03:55:48.910077
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise BaseException
    with ok(ValueError, TypeError):
        raise StopIteration
    with ok(ValueError, TypeError):
        raise GeneratorExit
    with ok(ValueError, TypeError):
        raise SystemExit
    with ok(ValueError, TypeError):
        raise KeyboardInterrupt
    with ok(ValueError, TypeError):
        raise ImportError

# Generated at 2022-06-18 03:55:58.626405
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError

# Generated at 2022-06-18 03:56:02.269065
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:56:08.470661
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError



# Generated at 2022-06-18 03:56:09.944433
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError()
    with ok(TypeError):
        int('N/A')
    with ok(TypeError):
        raise ValueError()



# Generated at 2022-06-18 03:56:11.363987
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + 1)



# Generated at 2022-06-18 03:56:15.111695
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:56:18.445901
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:56:22.501206
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with raises(ValueError):
        with ok(TypeError):
            raise ValueError



# Generated at 2022-06-18 03:56:33.341275
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:56:51.381340
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception
    with ok(Exception):
        raise ValueError

    with pytest.raises(ValueError):
        with ok(Exception):
            raise ValueError



# Generated at 2022-06-18 03:56:55.918391
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with ok(ZeroDivisionError, TypeError):
        1 / 0
    with ok(ZeroDivisionError, TypeError):
        1 + 'a'
    with ok(ZeroDivisionError, TypeError):
        1 + 1
    with ok(ZeroDivisionError, TypeError):
        raise ValueError('a')



# Generated at 2022-06-18 03:56:59.200143
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 03:57:00.224672
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')



# Generated at 2022-06-18 03:57:05.782342
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError

# Generated at 2022-06-18 03:57:11.520245
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise AttributeError



# Generated at 2022-06-18 03:57:19.316482
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError

# Generated at 2022-06-18 03:57:24.239809
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError



# Generated at 2022-06-18 03:57:26.433712
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int('N/A')



# Generated at 2022-06-18 03:57:33.476156
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        raise TypeError
    with ok(TypeError):
        raise ValueError
    with ok(TypeError, ValueError):
        raise ValueError
    with ok(TypeError, ValueError):
        raise TypeError
    with ok(TypeError, ValueError):
        raise Exception
    with ok(TypeError, ValueError):
        raise TypeError
    with ok(TypeError, ValueError):
        raise ValueError



# Generated at 2022-06-18 03:58:13.987944
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:58:17.309393
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:58:21.066786
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception
    with ok(Exception):
        raise ValueError
    with pytest.raises(ValueError):
        with ok(Exception):
            raise ValueError



# Generated at 2022-06-18 03:58:24.304685
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int(None)
    with ok(ValueError, TypeError):
        int('N/A')



# Generated at 2022-06-18 03:58:29.440623
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise SyntaxError



# Generated at 2022-06-18 03:58:31.815697
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()



# Generated at 2022-06-18 03:58:37.081187
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        int('N/A')
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise RuntimeError
    with ok(ValueError, TypeError):
        raise RuntimeError('N/A')


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 03:58:40.697674
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int(None)
    with ok(ValueError, TypeError):
        int('N/A')
    with ok(ValueError, TypeError):
        int(None)



# Generated at 2022-06-18 03:58:43.820272
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:58:54.330291
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError

# Generated at 2022-06-18 04:00:14.543011
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise RuntimeError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 04:00:17.983585
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception



# Generated at 2022-06-18 04:00:23.091332
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 04:00:24.781822
# Unit test for function ok
def test_ok():
    """Test for function ok."""
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise StopIteration



# Generated at 2022-06-18 04:00:32.151429
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError

# Generated at 2022-06-18 04:00:41.679259
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError

# Generated at 2022-06-18 04:00:46.069329
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception



# Generated at 2022-06-18 04:00:48.538406
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise KeyError



# Generated at 2022-06-18 04:00:53.610626
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 04:00:58.307445
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(TypeError):
        raise TypeError
    with ok(TypeError):
        raise ValueError
    with ok(TypeError, ValueError):
        raise ValueError
    with ok(TypeError, ValueError):
        raise TypeError
    with ok(TypeError, ValueError):
        raise NameError

