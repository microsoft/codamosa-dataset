

# Generated at 2022-06-18 03:53:07.123601
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')



# Generated at 2022-06-18 03:53:09.743346
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:53:16.947870
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + 2)
    with ok(TypeError, ValueError):
        print(1 + int('a'))


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 03:53:19.178411
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:53:21.237702
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise Exception



# Generated at 2022-06-18 03:53:23.712117
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:53:26.564278
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:53:34.543975
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:53:40.770606
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception()
    with ok(Exception):
        raise ValueError()
    with ok(Exception):
        raise TypeError()
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise Exception()



# Generated at 2022-06-18 03:53:48.655668
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:53:53.810746
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise NameError



# Generated at 2022-06-18 03:53:57.265583
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError



# Generated at 2022-06-18 03:54:02.322772
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise KeyError



# Generated at 2022-06-18 03:54:03.880170
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()



# Generated at 2022-06-18 03:54:06.990257
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError("test")
    with pytest.raises(TypeError):
        with ok(ValueError):
            raise TypeError("test")



# Generated at 2022-06-18 03:54:12.664156
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 03:54:16.650469
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception



# Generated at 2022-06-18 03:54:20.525891
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise StopIteration



# Generated at 2022-06-18 03:54:24.801961
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise StopIteration



# Generated at 2022-06-18 03:54:28.888200
# Unit test for function ok
def test_ok():
    """Test ok function."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception



# Generated at 2022-06-18 03:54:41.172699
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError

# Generated at 2022-06-18 03:54:44.429008
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:54:48.808899
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int(None)
    with ok(ValueError, TypeError):
        int('N/A')
    with ok(ValueError, TypeError):
        int(None)



# Generated at 2022-06-18 03:54:51.653029
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int('N/A')



# Generated at 2022-06-18 03:54:55.495925
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError, ValueError):
        print(1 + "1")
    with ok(TypeError, ValueError):
        print(1 + 1)
    with ok(TypeError, ValueError):
        print(1 + int("1"))
    with ok(TypeError, ValueError):
        print(1 + int("a"))
    with ok(TypeError, ValueError):
        print(1 + "a")


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-18 03:54:58.973468
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:55:09.377521
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError

# Generated at 2022-06-18 03:55:19.710755
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(int('a'))
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(int('a'))
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(int('a'))
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(int('a'))
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(int('a'))
    with ok(TypeError):
        print(1 + '1')

# Generated at 2022-06-18 03:55:25.910115
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise AttributeError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:55:28.457463
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError



# Generated at 2022-06-18 03:55:43.737398
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        raise TypeError
    with ok(TypeError):
        raise ValueError
    with ok(TypeError, ValueError):
        raise ValueError
    with ok(TypeError, ValueError):
        raise TypeError
    with ok(TypeError, ValueError):
        raise IndexError
    with ok(TypeError, ValueError):
        raise IndexError
    with ok(TypeError, ValueError):
        raise IndexError
    with ok(TypeError, ValueError):
        raise IndexError
    with ok(TypeError, ValueError):
        raise IndexError
    with ok(TypeError, ValueError):
        raise IndexError
    with ok(TypeError, ValueError):
        raise IndexError
    with ok(TypeError, ValueError):
        raise IndexError
    with ok(TypeError, ValueError):
        raise

# Generated at 2022-06-18 03:55:49.507928
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError

# Generated at 2022-06-18 03:55:51.037597
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:56:00.570882
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError, ValueError):
        int('a')
    with ok(TypeError, ValueError):
        int('a')
    with ok(TypeError, ValueError):
        int('a')
    with ok(TypeError, ValueError):
        int('a')
    with ok(TypeError, ValueError):
        int('a')
    with ok(TypeError, ValueError):
        int('a')
    with ok(TypeError, ValueError):
        int('a')
    with ok(TypeError, ValueError):
        int('a')
    with ok(TypeError, ValueError):
        int('a')

# Generated at 2022-06-18 03:56:10.437503
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError

# Generated at 2022-06-18 03:56:14.290269
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:56:23.398989
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int(1.5)
    with ok(TypeError, ValueError):
        int('1.5')
    with ok(TypeError, ValueError):
        int(1.5)
    with ok(TypeError, ValueError):
        int('1.5')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')

# Generated at 2022-06-18 03:56:29.002250
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise Exception



# Generated at 2022-06-18 03:56:39.370723
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise StopIteration
    with ok(ValueError, TypeError):
        raise GeneratorExit
    with ok(ValueError, TypeError):
        raise SystemExit
    with ok(ValueError, TypeError):
        raise KeyboardInterrupt
    with ok(ValueError, TypeError):
        raise ImportError
    with ok(ValueError, TypeError):
        raise IndexError

# Generated at 2022-06-18 03:56:44.010135
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError



# Generated at 2022-06-18 03:57:05.618077
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('123')
    with ok(TypeError, ValueError):
        int('123')
    with ok(TypeError, ValueError):
        int('123')
    with ok(TypeError, ValueError):
        int('123')
    with ok(TypeError, ValueError):
        int('123')
    with ok(TypeError, ValueError):
        int('123')
    with ok(TypeError, ValueError):
        int('123')
    with ok(TypeError, ValueError):
        int('123')
    with ok(TypeError, ValueError):
        int('123')

# Generated at 2022-06-18 03:57:10.304411
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:57:14.959190
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError("Catch me if you can!")



# Generated at 2022-06-18 03:57:21.252725
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(TypeError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('123')
    with ok(TypeError, ValueError):
        int('123')
    with ok(TypeError, ValueError):
        int('123')
    with ok(TypeError, ValueError):
        int('123')
    with ok(TypeError, ValueError):
        int('123')
    with ok(TypeError, ValueError):
        int('123')
    with ok(TypeError, ValueError):
        int('123')
    with ok(TypeError, ValueError):
        int('123')
    with ok(TypeError, ValueError):
        int('123')

# Generated at 2022-06-18 03:57:28.917883
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:57:38.508730
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:57:40.750448
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise RuntimeError



# Generated at 2022-06-18 03:57:50.715209
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise Exception
    with ok(ValueError):
        raise ValueError("error")
    with ok(ValueError):
        raise TypeError("error")
    with ok(ValueError):
        raise Exception("error")
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise ValueError("error")
    with ok(ValueError, TypeError):
        raise TypeError("error")
    with ok(ValueError, TypeError):
        raise Exception("error")



# Generated at 2022-06-18 03:57:59.897528
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(TypeError):
        print('TypeError')
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')

# Generated at 2022-06-18 03:58:03.809888
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception



# Generated at 2022-06-18 03:58:43.227149
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')

# Generated at 2022-06-18 03:58:46.285925
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with ok(ZeroDivisionError):
        raise ValueError("Not a zero division error")



# Generated at 2022-06-18 03:58:51.633033
# Unit test for function ok
def test_ok():
    """Test function ok"""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:58:58.472302
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:59:08.974629
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')

# Generated at 2022-06-18 03:59:12.380417
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:59:16.815122
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        raise ValueError
    with ok(TypeError, ValueError):
        raise TypeError
    with ok(TypeError, ValueError):
        raise NameError
    with ok(TypeError, ValueError):
        raise IndexError



# Generated at 2022-06-18 03:59:21.693746
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError

# Generated at 2022-06-18 03:59:22.787734
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')



# Generated at 2022-06-18 03:59:32.662310
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError

# Generated at 2022-06-18 04:00:51.369070
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('a')

    with ok(TypeError, ValueError):
        int('a')

    with ok(TypeError, ValueError):
        int('1')

    with ok(TypeError, ValueError):
        int(1)

    with raises(ZeroDivisionError):
        with ok(TypeError, ValueError):
            1 / 0

    with raises(ZeroDivisionError):
        with ok(TypeError, ValueError):
            int('a')
            1 / 0

    with raises(ZeroDivisionError):
        with ok(TypeError, ValueError):
            int('1')
            1 / 0

    with raises(ZeroDivisionError):
        with ok(TypeError, ValueError):
            int(1)
            1 / 0



# Generated at 2022-06-18 04:00:57.196748
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise Exception


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 04:01:00.317516
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int('N/A')
    with ok(ValueError, TypeError):
        int('N/A')



# Generated at 2022-06-18 04:01:03.057941
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError



# Generated at 2022-06-18 04:01:06.452047
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 04:01:08.055826
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise Exception



# Generated at 2022-06-18 04:01:13.201403
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + 1)



# Generated at 2022-06-18 04:01:16.565253
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 04:01:19.364518
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int('N/A')
    with ok(ValueError, TypeError):
        int('N/A')



# Generated at 2022-06-18 04:01:20.365208
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError("test")
    with ok(ValueError):
        raise TypeError("test")

