

# Generated at 2022-06-18 03:53:12.693482
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError



# Generated at 2022-06-18 03:53:22.022412
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError

# Generated at 2022-06-18 03:53:25.441786
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int(None)
    with ok(ValueError, TypeError):
        int('N/A')
    with ok(ValueError, TypeError):
        int(None)



# Generated at 2022-06-18 03:53:28.989628
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:53:32.263123
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:53:37.626369
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:53:44.779139
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + '1')

# Generated at 2022-06-18 03:53:48.218710
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:53:54.946188
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError

# Generated at 2022-06-18 03:53:57.884392
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')

    with ok(ValueError):
        raise ValueError

    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:54:09.441406
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print('TypeError')
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
    with ok(TypeError, ValueError, NameError):
        print('TypeError or ValueError or NameError')
    with ok(TypeError, ValueError, NameError, ZeroDivisionError):
        print('TypeError or ValueError or NameError or ZeroDivisionError')
    with ok(TypeError, ValueError, NameError, ZeroDivisionError, IndexError):
        print('TypeError or ValueError or NameError or ZeroDivisionError or IndexError')
    with ok(TypeError, ValueError, NameError, ZeroDivisionError, IndexError, Exception):
        print('TypeError or ValueError or NameError or ZeroDivisionError or IndexError or Exception')

# Generated at 2022-06-18 03:54:14.775931
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise AttributeError
    with ok(ValueError, TypeError):
        raise AttributeError
    with ok(ValueError, TypeError):
        raise AttributeError



# Generated at 2022-06-18 03:54:16.574706
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:54:22.552693
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:54:26.854384
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:54:29.264424
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise AttributeError
    with ok(ValueError, TypeError):
        raise AttributeError



# Generated at 2022-06-18 03:54:39.729565
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:54:44.011418
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print("hello")
    with ok(TypeError, ZeroDivisionError):
        print("hello")
        1 / 0
    with ok(TypeError, ZeroDivisionError):
        print("hello")
        "a" + 1


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-18 03:54:47.938334
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception
    with ok(Exception):
        raise TypeError

    with pytest.raises(TypeError):
        with ok(Exception):
            raise TypeError



# Generated at 2022-06-18 03:54:53.010667
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:55:00.777230
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    try:
        with ok(ValueError, TypeError):
            raise KeyError
    except KeyError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-18 03:55:10.529659
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:55:15.298409
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()

    with ok(ValueError):
        raise TypeError()

    with ok(ValueError, TypeError):
        raise TypeError()

    with ok(ValueError, TypeError):
        raise ValueError()

    with ok(ValueError, TypeError):
        raise IndexError()



# Generated at 2022-06-18 03:55:18.944223
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:55:20.562645
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError('test')
    with ok(ValueError):
        raise TypeError('test')



# Generated at 2022-06-18 03:55:23.229319
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('1')
    with ok(TypeError, ValueError):
        int(1)



# Generated at 2022-06-18 03:55:27.841643
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise AttributeError



# Generated at 2022-06-18 03:55:30.103734
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int('N/A')



# Generated at 2022-06-18 03:55:38.741485
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError

# Generated at 2022-06-18 03:55:42.052438
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise RuntimeError
    with ok(ValueError, TypeError):
        raise RuntimeError
    with ok(ValueError, TypeError):
        raise RuntimeError
    with ok(ValueError, TypeError):
        raise RuntimeError



# Generated at 2022-06-18 03:55:52.229894
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:55:58.116861
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise AttributeError
    with ok(ValueError, TypeError):
        raise KeyError



# Generated at 2022-06-18 03:56:04.523015
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise NameError
    with ok(ValueError, TypeError):
        raise RuntimeError
    with ok(ValueError, TypeError):
        raise StopIteration
    with ok(ValueError, TypeError):
        raise KeyboardInterrupt
    with ok(ValueError, TypeError):
        raise SystemExit
    with ok(ValueError, TypeError):
        raise SystemExit(1)
    with ok(ValueError, TypeError):
        raise SystemExit(0)
    with ok(ValueError, TypeError):
        raise SystemExit(2)

# Generated at 2022-06-18 03:56:10.808032
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-18 03:56:19.080195
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with ok(ZeroDivisionError):
        raise ValueError
    with ok(ZeroDivisionError, ValueError):
        raise ValueError
    with ok(ZeroDivisionError, ValueError):
        raise ZeroDivisionError
    with ok(ZeroDivisionError, ValueError):
        raise TypeError
    with ok(ZeroDivisionError, ValueError):
        raise TypeError
    with ok(ZeroDivisionError, ValueError):
        raise TypeError
    with ok(ZeroDivisionError, ValueError):
        raise TypeError
    with ok(ZeroDivisionError, ValueError):
        raise TypeError
    with ok(ZeroDivisionError, ValueError):
        raise TypeError
    with ok(ZeroDivisionError, ValueError):
        raise TypeError

# Generated at 2022-06-18 03:56:20.808266
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()



# Generated at 2022-06-18 03:56:24.963298
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        pass



# Generated at 2022-06-18 03:56:29.864783
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        pass



# Generated at 2022-06-18 03:56:34.366281
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:56:38.709439
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:57:03.493431
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise ValueError

# Generated at 2022-06-18 03:57:13.146800
# Unit test for function ok
def test_ok():
    """Test for function ok."""
    with ok(ZeroDivisionError):
        1 / 0
    with ok(ZeroDivisionError):
        raise ValueError
    with ok(ZeroDivisionError):
        raise ZeroDivisionError
    with ok(ZeroDivisionError):
        raise ZeroDivisionError
    with ok(ZeroDivisionError):
        raise ZeroDivisionError
    with ok(ZeroDivisionError):
        raise ZeroDivisionError
    with ok(ZeroDivisionError):
        raise ZeroDivisionError
    with ok(ZeroDivisionError):
        raise ZeroDivisionError
    with ok(ZeroDivisionError):
        raise ZeroDivisionError
    with ok(ZeroDivisionError):
        raise ZeroDivisionError
    with ok(ZeroDivisionError):
        raise ZeroDivisionError

# Generated at 2022-06-18 03:57:22.729107
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError

# Generated at 2022-06-18 03:57:29.557934
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise Exception

# Generated at 2022-06-18 03:57:33.433804
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(TypeError):
        int('N/A')



# Generated at 2022-06-18 03:57:34.679435
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int(None)



# Generated at 2022-06-18 03:57:42.098886
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise Exception

# Generated at 2022-06-18 03:57:46.113394
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        pass



# Generated at 2022-06-18 03:57:50.454705
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:57:54.851025
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise KeyError



# Generated at 2022-06-18 03:58:38.777024
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError

# Generated at 2022-06-18 03:58:41.601657
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise RuntimeError



# Generated at 2022-06-18 03:58:44.488672
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:58:54.544836
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + 1)
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + 1)
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + '1')

# Generated at 2022-06-18 03:58:57.445200
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise RuntimeError



# Generated at 2022-06-18 03:58:59.529426
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:59:04.409295
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:59:05.701734
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError("Error")
    with ok(ValueError):
        raise TypeError("Error")



# Generated at 2022-06-18 03:59:08.671561
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with pytest.raises(TypeError):
        with ok(ValueError):
            raise TypeError



# Generated at 2022-06-18 03:59:16.534073
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')

# Generated at 2022-06-18 04:00:43.723883
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception
    with ok(Exception):
        raise ValueError
    with ok(Exception):
        raise TypeError
    with ok(Exception):
        raise IndexError
    with ok(Exception):
        raise KeyError
    with ok(Exception):
        raise NameError
    with ok(Exception):
        raise AttributeError
    with ok(Exception):
        raise SyntaxError
    with ok(Exception):
        raise AssertionError
    with ok(Exception):
        raise LookupError
    with ok(Exception):
        raise ArithmeticError
    with ok(Exception):
        raise ZeroDivisionError
    with ok(Exception):
        raise FloatingPointError
    with ok(Exception):
        raise OverflowError
    with ok(Exception):
        raise ReferenceError
    with ok(Exception):
        raise System

# Generated at 2022-06-18 04:00:45.297217
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()



# Generated at 2022-06-18 04:00:47.937594
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int(None)
    with ok(ValueError, TypeError):
        int('N/A')
    with ok(ValueError, TypeError):
        int(None)



# Generated at 2022-06-18 04:00:52.446616
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError

# Generated at 2022-06-18 04:00:53.996849
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int(None)



# Generated at 2022-06-18 04:00:59.593945
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with raises(ValueError):
        with ok(TypeError):
            raise ValueError
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError



# Generated at 2022-06-18 04:01:01.690457
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise AttributeError



# Generated at 2022-06-18 04:01:02.367900
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')



# Generated at 2022-06-18 04:01:04.291701
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError



# Generated at 2022-06-18 04:01:11.192610
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError