

# Generated at 2022-06-18 03:53:12.601566
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise NameError



# Generated at 2022-06-18 03:53:17.511523
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise AttributeError



# Generated at 2022-06-18 03:53:24.468717
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + 1)
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + '1')

# Generated at 2022-06-18 03:53:33.290059
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError

# Generated at 2022-06-18 03:53:39.778244
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:53:43.698467
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise NameError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 03:53:49.057407
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-18 03:53:51.022276
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + 1)



# Generated at 2022-06-18 03:54:01.107745
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:54:03.649673
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:54:08.650315
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise Exception



# Generated at 2022-06-18 03:54:14.373818
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with ok(ZeroDivisionError):
        raise TypeError
    with ok(ZeroDivisionError, TypeError):
        raise TypeError
    with ok(ZeroDivisionError, TypeError):
        raise ZeroDivisionError
    with ok(ZeroDivisionError, TypeError):
        1 / 0
    with ok(ZeroDivisionError, TypeError):
        raise ValueError



# Generated at 2022-06-18 03:54:20.527185
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:54:29.297308
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:54:33.125239
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError



# Generated at 2022-06-18 03:54:39.027628
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:54:45.356745
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError("test")
    with ok(ValueError, TypeError):
        raise TypeError("test")
    with ok(ValueError, TypeError):
        raise Exception("test")



# Generated at 2022-06-18 03:54:48.663928
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int(None)
    with ok(ValueError, TypeError):
        int('N/A')



# Generated at 2022-06-18 03:54:49.796986
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int("a")
    with ok(ValueError):
        raise ValueError("a")
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError("a")



# Generated at 2022-06-18 03:54:51.888544
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()



# Generated at 2022-06-18 03:55:00.187657
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise Exception



# Generated at 2022-06-18 03:55:08.370420
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        raise ValueError
    with ok(TypeError, ValueError):
        raise TypeError
    with ok(TypeError, ValueError):
        raise NameError
    with ok(TypeError, ValueError):
        raise NameError
    with ok(TypeError, ValueError):
        raise NameError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 03:55:19.480131
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:55:21.361256
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(TypeError):
        int('N/A')



# Generated at 2022-06-18 03:55:27.477069
# Unit test for function ok
def test_ok():
    """Test for function ok."""
    with ok(TypeError):
        raise TypeError
    with ok(TypeError, ValueError):
        raise ValueError
    with ok(TypeError, ValueError):
        raise TypeError
    with ok(TypeError, ValueError):
        raise KeyError
    with ok(TypeError, ValueError):
        raise AttributeError



# Generated at 2022-06-18 03:55:35.997874
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('hello')
    with ok(TypeError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
   

# Generated at 2022-06-18 03:55:41.389582
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise AttributeError



# Generated at 2022-06-18 03:55:48.197665
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError

# Generated at 2022-06-18 03:55:50.921882
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')



# Generated at 2022-06-18 03:55:54.457908
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError

    with pytest.raises(TypeError):
        with ok(ValueError):
            raise TypeError



# Generated at 2022-06-18 03:56:11.232475
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ZeroDivisionError):
        1 / 0
    with ok(ZeroDivisionError, TypeError):
        1 / 0
    with ok(ZeroDivisionError, TypeError):
        1 / 'a'
    with ok(ZeroDivisionError, TypeError):
        1 / 'a'
    with ok(ZeroDivisionError, TypeError):
        1 / 'a'
    with ok(ZeroDivisionError, TypeError):
        1 / 'a'
    with ok(ZeroDivisionError, TypeError):
        1 / 'a'
    with ok(ZeroDivisionError, TypeError):
        1 / 'a'
    with ok(ZeroDivisionError, TypeError):
        1 / 'a'

# Generated at 2022-06-18 03:56:19.261935
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(TypeError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int(5)
    with ok(TypeError, ValueError):
        int('5')
    with ok(TypeError, ValueError):
        int('5.0')
    with ok(TypeError, ValueError):
        int('5.1')
    with ok(TypeError, ValueError):
        int('5.9')
    with ok(TypeError, ValueError):
        int('-5')
    with ok(TypeError, ValueError):
        int('-5.0')
    with ok(TypeError, ValueError):
        int('-5.1')

# Generated at 2022-06-18 03:56:23.842306
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 03:56:25.822466
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:56:28.693351
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()



# Generated at 2022-06-18 03:56:31.946365
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')

    with ok(ValueError):
        raise ValueError

    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:56:35.469767
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:56:40.129537
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        pass



# Generated at 2022-06-18 03:56:44.805341
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:56:48.998430
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print('TypeError')
        raise TypeError
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
        raise ValueError
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
        raise TypeError
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
        raise IndexError



# Generated at 2022-06-18 03:57:07.325040
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        int('N/A')

    with ok(ValueError):
        raise ValueError()

    with ok(ValueError):
        raise TypeError()



# Generated at 2022-06-18 03:57:11.728735
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError

    with pytest.raises(TypeError):
        with ok(ValueError):
            raise TypeError



# Generated at 2022-06-18 03:57:15.353210
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:57:19.108268
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('123')
    with ok(TypeError, ValueError):
        int(123)
    with ok(TypeError, ValueError):
        int(None)
    with ok(TypeError, ValueError):
        int()



# Generated at 2022-06-18 03:57:22.287025
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('a')
    with ok(TypeError, ValueError):
        int('a')
    with ok(TypeError):
        int(1)
    with ok(TypeError, ValueError):
        int(1)



# Generated at 2022-06-18 03:57:24.689002
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()



# Generated at 2022-06-18 03:57:35.151338
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(int('a'))
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(int('a'))
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(int('a'))
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(int('a'))
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(int('a'))

# Generated at 2022-06-18 03:57:42.379410
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        raise ValueError
    with ok(TypeError, ValueError):
        raise TypeError
    with ok(TypeError, ValueError):
        raise NameError
    with ok(TypeError, ValueError):
        raise NameError
    with ok(TypeError, ValueError):
        raise NameError
    with ok(TypeError, ValueError):
        raise NameError
    with ok(TypeError, ValueError):
        raise NameError
    with ok(TypeError, ValueError):
        raise NameError
    with ok(TypeError, ValueError):
        raise NameError

# Generated at 2022-06-18 03:57:45.182383
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise StopIteration



# Generated at 2022-06-18 03:57:49.693687
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        pass



# Generated at 2022-06-18 03:58:28.739910
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError



# Generated at 2022-06-18 03:58:32.528055
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise StopIteration
    with ok(ValueError):
        raise RuntimeError



# Generated at 2022-06-18 03:58:43.003043
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
        int('N/A')
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
        int('N/A')
        int('N/A')
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
        int('N/A')
        int('N/A')
        int('N/A')
        int('N/A')

# Generated at 2022-06-18 03:58:53.792834
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError

# Generated at 2022-06-18 03:58:59.716069
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:59:04.635455
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception



# Generated at 2022-06-18 03:59:08.969438
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print('TypeError')
    with ok(TypeError, ValueError):
        print('TypeError or ValueError')
    with ok(TypeError, ValueError, IndexError):
        print('TypeError or ValueError or IndexError')
    with ok(TypeError, ValueError, IndexError, ZeroDivisionError):
        print('TypeError or ValueError or IndexError or ZeroDivisionError')
    with ok(TypeError, ValueError, IndexError, ZeroDivisionError, Exception):
        print('TypeError or ValueError or IndexError or ZeroDivisionError or Exception')



# Generated at 2022-06-18 03:59:16.923496
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError

# Generated at 2022-06-18 03:59:21.218132
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError



# Generated at 2022-06-18 03:59:31.538089
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 04:00:46.558295
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise AttributeError



# Generated at 2022-06-18 04:00:48.651102
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        print('This should pass')
        raise ValueError
    with ok(ValueError):
        print('This should fail')
        raise TypeError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 04:00:50.678932
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')

    with ok(ValueError):
        raise ValueError
    with pytest.raises(TypeError):
        with ok(ValueError):
            raise TypeError



# Generated at 2022-06-18 04:00:53.513723
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError



# Generated at 2022-06-18 04:01:02.873958
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(TypeError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('42')
    with ok(TypeError, ValueError):
        int(42)
    with ok(TypeError, ValueError):
        int(42.0)
    with ok(TypeError, ValueError):
        int(42.1)
    with ok(TypeError, ValueError):
        int(42.9)

# Generated at 2022-06-18 04:01:10.476517
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print("This is ok")

    with ok(TypeError, ValueError):
        print("This is ok")

    with ok(TypeError, ValueError):
        print("This is ok")

    with ok(TypeError, ValueError):
        print("This is ok")

    with ok(TypeError, ValueError):
        print("This is ok")

    with ok(TypeError, ValueError):
        print("This is ok")

    with ok(TypeError, ValueError):
        print("This is ok")

    with ok(TypeError, ValueError):
        print("This is ok")

    with ok(TypeError, ValueError):
        print("This is ok")

    with ok(TypeError, ValueError):
        print("This is ok")


# Generated at 2022-06-18 04:01:14.954563
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 04:01:21.996693
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError):
        int('N/A')
    with ok(TypeError):
        int('N/A')
    with ok(TypeError):
        int('N/A')
    with ok(TypeError):
        int('N/A')
    with ok(TypeError):
        int('N/A')
    with ok(TypeError):
        int('N/A')
    with ok(TypeError):
        int('N/A')
    with ok(TypeError):
        int('N/A')
    with ok(TypeError):
        int('N/A')

# Generated at 2022-06-18 04:01:24.593850
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 04:01:30.392241
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + 1)
    with ok(TypeError, ValueError):
        print(int('a'))
    with ok(TypeError, ValueError):
        print(int('1'))

