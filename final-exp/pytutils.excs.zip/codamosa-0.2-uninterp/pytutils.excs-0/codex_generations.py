

# Generated at 2022-06-18 03:53:14.708807
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:53:19.220677
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise Exception()



# Generated at 2022-06-18 03:53:22.606204
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise AttributeError



# Generated at 2022-06-18 03:53:31.820706
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:53:37.533168
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise IndexError()



# Generated at 2022-06-18 03:53:41.122710
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError



# Generated at 2022-06-18 03:53:42.726321
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:53:44.501774
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()



# Generated at 2022-06-18 03:53:47.078165
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError



# Generated at 2022-06-18 03:53:50.213983
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:53:55.085844
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int('N/A')
    with ok(ValueError, TypeError):
        int('N/A')
    with ok(ValueError, TypeError):
        int(None)



# Generated at 2022-06-18 03:54:05.896377
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + 1)
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + 1)
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + '1')

# Generated at 2022-06-18 03:54:07.919235
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:54:15.992806
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError


# Generated at 2022-06-18 03:54:19.539241
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise Exception



# Generated at 2022-06-18 03:54:24.128364
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise StopIteration



# Generated at 2022-06-18 03:54:30.803513
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:54:35.266199
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        1 + '1'
    with ok(TypeError, ValueError):
        1 + '1'
    with ok(TypeError, ValueError):
        int('1')
    with ok(TypeError, ValueError):
        int('a')



# Generated at 2022-06-18 03:54:40.325561
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:54:48.131242
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError

# Generated at 2022-06-18 03:54:57.019102
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:55:00.464629
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with raises(ZeroDivisionError):
        with ok(ValueError, TypeError):
            raise ZeroDivisionError



# Generated at 2022-06-18 03:55:10.258381
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError

# Generated at 2022-06-18 03:55:14.988236
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with raises(ZeroDivisionError):
        with ok(ValueError, TypeError):
            raise ZeroDivisionError()



# Generated at 2022-06-18 03:55:20.070353
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 03:55:26.221957
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 03:55:30.769324
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 03:55:33.038348
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:55:36.235638
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError, TypeError):
        raise AttributeError()



# Generated at 2022-06-18 03:55:40.298051
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:55:51.875675
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception



# Generated at 2022-06-18 03:55:58.165491
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception



# Generated at 2022-06-18 03:55:59.643010
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:56:05.204987
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + "1")
    with ok(TypeError):
        print(1 + 1)
   

# Generated at 2022-06-18 03:56:13.823498
# Unit test for function ok
def test_ok():
    """Test for function ok."""
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + 1)
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(1 + '1')

# Generated at 2022-06-18 03:56:14.746282
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')



# Generated at 2022-06-18 03:56:19.234033
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError("ValueError")
    with ok(ValueError):
        raise TypeError("TypeError")
    with ok(ValueError, TypeError):
        raise TypeError("TypeError")
    with ok(ValueError, TypeError):
        raise ValueError("ValueError")
    with ok(ValueError, TypeError):
        raise KeyError("KeyError")


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-18 03:56:26.793926
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise KeyError

# Generated at 2022-06-18 03:56:37.400549
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('a')
    with ok(TypeError, ValueError):
        int('a')
    with ok(TypeError, ValueError):
        int('1')
    with ok(TypeError, ValueError):
        int('1')
    with ok(TypeError, ValueError):
        int('1')
    with ok(TypeError, ValueError):
        int('1')
    with ok(TypeError, ValueError):
        int('1')
    with ok(TypeError, ValueError):
        int('1')
    with ok(TypeError, ValueError):
        int('1')
    with ok(TypeError, ValueError):
        int('1')
    with ok(TypeError, ValueError):
        int('1')

# Generated at 2022-06-18 03:56:39.917897
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with ok(ZeroDivisionError):
        raise ValueError
    with ok(ZeroDivisionError):
        raise ZeroDivisionError



# Generated at 2022-06-18 03:56:58.037267
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError("Test")

    with ok(ValueError):
        raise TypeError("Test")



# Generated at 2022-06-18 03:57:00.932464
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:57:02.401076
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int(None)



# Generated at 2022-06-18 03:57:05.157353
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with ok(ZeroDivisionError):
        raise ZeroDivisionError
    with ok(ZeroDivisionError):
        raise TypeError
    with ok(ZeroDivisionError):
        raise ZeroDivisionError
    with ok(ZeroDivisionError):
        raise TypeError



# Generated at 2022-06-18 03:57:15.518374
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        int('a')
    with ok(TypeError, ValueError):
        int('a')
    with ok(TypeError, ValueError):
        int('a')
    with ok(TypeError, ValueError, ZeroDivisionError):
        int('a')
    with ok(TypeError, ValueError, ZeroDivisionError):
        int('a')
    with ok(TypeError, ValueError, ZeroDivisionError):
        int('a')
    with ok(TypeError, ValueError, ZeroDivisionError):
        int('a')
    with ok(TypeError, ValueError, ZeroDivisionError):
        int('a')
    with ok(TypeError, ValueError, ZeroDivisionError):
        int('a')

# Generated at 2022-06-18 03:57:19.322697
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('a')
    with ok(TypeError):
        raise TypeError
    with ok(TypeError):
        raise ValueError



# Generated at 2022-06-18 03:57:24.009775
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 03:57:34.630721
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError

# Generated at 2022-06-18 03:57:38.766483
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception



# Generated at 2022-06-18 03:57:41.380482
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 03:58:24.730696
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('hello')
    with ok(TypeError, ValueError):
        int('hello')
    with ok(TypeError, ValueError):
        int('123')
    with ok(TypeError, ValueError):
        int(123)
    with ok(TypeError, ValueError):
        int(123.5)
    with ok(TypeError, ValueError):
        int(True)
    with ok(TypeError, ValueError):
        int(False)
    with ok(TypeError, ValueError):
        int(None)
    with ok(TypeError, ValueError):
        int([])
    with ok(TypeError, ValueError):
        int({})
    with ok(TypeError, ValueError):
        int(())
    with ok(TypeError, ValueError):
        int(set())

# Generated at 2022-06-18 03:58:27.159981
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError



# Generated at 2022-06-18 03:58:28.739193
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')



# Generated at 2022-06-18 03:58:36.751376
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with ok(ZeroDivisionError):
        raise TypeError
    with ok(ZeroDivisionError, TypeError):
        raise TypeError
    with ok(ZeroDivisionError, TypeError):
        raise ZeroDivisionError
    with ok(ZeroDivisionError, TypeError):
        1 / 0
    with ok(ZeroDivisionError, TypeError):
        raise ValueError
    with ok(ZeroDivisionError, TypeError):
        raise ValueError
    with ok(ZeroDivisionError, TypeError):
        raise ValueError
    with ok(ZeroDivisionError, TypeError):
        raise ValueError
    with ok(ZeroDivisionError, TypeError):
        raise ValueError
    with ok(ZeroDivisionError, TypeError):
        raise ValueError

# Generated at 2022-06-18 03:58:41.499724
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise AttributeError



# Generated at 2022-06-18 03:58:46.656430
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        raise ValueError
    with ok(TypeError, ValueError):
        raise TypeError
    with ok(TypeError, ValueError):
        raise NameError
    with ok(TypeError, ValueError):
        raise NameError
    with ok(TypeError, ValueError):
        raise NameError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 03:58:50.325051
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:58:52.165557
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError

    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-18 03:58:56.716185
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(1 + 1)
    with ok(TypeError, ValueError):
        print(1 + int('1'))
    with ok(TypeError, ValueError):
        print(1 + int('a'))


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-18 03:59:07.453972
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise

# Generated at 2022-06-18 04:00:27.699591
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError
    with ok(ValueError, TypeError):
        raise IndexError



# Generated at 2022-06-18 04:00:37.624861
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        int('N/A')

# Generated at 2022-06-18 04:00:42.610312
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(TypeError):
        int('a')
    with ok(TypeError, ValueError):
        int('a')
    with ok(TypeError, ValueError, IndexError):
        int('a')
    with ok(TypeError, ValueError, IndexError):
        int('a')
    with ok(TypeError, ValueError, IndexError):
        int('a')
    with ok(TypeError, ValueError, IndexError):
        int('a')
    with ok(TypeError, ValueError, IndexError):
        int('a')
    with ok(TypeError, ValueError, IndexError):
        int('a')
    with ok(TypeError, ValueError, IndexError):
        int('a')
    with ok(TypeError, ValueError, IndexError):
        int('a')


# Generated at 2022-06-18 04:00:45.056436
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError):
        raise IndexError



# Generated at 2022-06-18 04:00:46.661672
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int(None)



# Generated at 2022-06-18 04:00:48.692057
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        int('N/A')

    with ok(ValueError):
        raise ValueError()

    with ok(ValueError):
        raise TypeError()



# Generated at 2022-06-18 04:00:50.695664
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError
    with ok(TypeError):
        int('N/A')
    with ok(TypeError):
        raise ValueError



# Generated at 2022-06-18 04:01:00.386082
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise KeyError
    with ok(ValueError, TypeError):
        raise Exception
    with ok(ValueError, TypeError):
        raise BaseException
    with ok(ValueError, TypeError):
        raise KeyboardInterrupt
    with ok(ValueError, TypeError):
        raise SystemExit
    with ok(ValueError, TypeError):
        raise StopIteration
    with ok(ValueError, TypeError):
        raise GeneratorExit
    with ok(ValueError, TypeError):
        raise MemoryError

# Generated at 2022-06-18 04:01:06.837238
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError

# Generated at 2022-06-18 04:01:08.216963
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError("test")
    with ok(ValueError):
        raise TypeError("test")

