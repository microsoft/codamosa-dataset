

# Generated at 2022-06-26 02:02:38.266384
# Unit test for function ok
def test_ok():
    with pytest.raises(Exception):
        test_case_0()

# Generated at 2022-06-26 02:02:39.050663
# Unit test for function ok
def test_ok():
    assert ok() == None

# Generated at 2022-06-26 02:02:40.370384
# Unit test for function ok
def test_ok():
    try:
        test_case_0()
    except:
        raise TypeError

# Generated at 2022-06-26 02:02:43.106466
# Unit test for function ok
def test_ok():
    try:
        test_case_0()
    except:
        print("Error executing test_case_0")


# Main function.
if __name__ == "__main__":

    # Test ok.
    test_ok()

# Generated at 2022-06-26 02:02:47.216475
# Unit test for function ok
def test_ok():
    # Set up test data
    var_0 = ok()
    with ok(Exception):
        raise Exception()
    with ok(Exception):
        raise ValueError()

# Generated at 2022-06-26 02:02:48.676119
# Unit test for function ok
def test_ok():
    var_0 = ok()
    assert type(var_0) == contextmanager

# Generated at 2022-06-26 02:02:49.937215
# Unit test for function ok
def test_ok():
    with ok(Exception, None):
        pass



# Generated at 2022-06-26 02:02:54.657782
# Unit test for function ok
def test_ok():
    # pass exception type to ok
    with pytest.raises(Exception):
        with ok(Exception):
            raise Exception()
    # pass none exception type to ok
    with ok(Exception):
        pass
    # pass nothing to ok, then raise exception
    with pytest.raises(Exception):
        with ok():
            raise Exception()
    # pass nothing to ok, then don't raise exception
    with ok():
        pass

# Generated at 2022-06-26 02:02:56.641461
# Unit test for function ok
def test_ok():
    assert ok()
    return "ok ok-ed"


# Generated at 2022-06-26 02:03:00.347726
# Unit test for function ok
def test_ok():
    try:
        assert var_0.__exit__() == True
    except AssertionError as e:
        raise(e)

# Unit test main
if __name__ == '__main__':
    test_case_0()
    test_ok()

# Generated at 2022-06-26 02:03:08.178540
# Unit test for function ok
def test_ok():
    """Function ok does not raise exceptions"""
    assert ok([ValueError, TypeError], int("1")), "No int to str conversion"
    assert ok([ValueError, TypeError], 1 + "1"), "No concatenation of int, str"
    assert ok(ValueError, int("1")), "No int to str conversion"
    assert ok(ValueError, 1 + 1), "No add of int, str"
    string = '1'
    with ok([TypeError]):
        int(string)
    with ok(TypeError):
        int(string)

# Generated at 2022-06-26 02:03:12.589073
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(Exception):
        pass
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError()



# Generated at 2022-06-26 02:03:15.063070
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1/0

    with ok(TypeError):
        1.0/0
        # An exception would pop up



# Generated at 2022-06-26 02:03:18.082422
# Unit test for function ok
def test_ok():
    with ok(Exception):
        print('\nAll OK')
    with ok(ValueError):
        print(2 + 3 + 's')
    with ok(TypeError, ValueError):
        print(1 + 's')


test_ok()

# Generated at 2022-06-26 02:03:24.432686
# Unit test for function ok
def test_ok():
    class CaughtException(Exception):
        pass

    with raises(CaughtException):
        with ok(AttributeError):
            raise CaughtException()
    with raises(CaughtException):
        with ok(AttributeError, KeyError):
            raise CaughtException()
    with ok(AttributeError):
        pass
    with ok():
        pass
    with ok(AttributeError):
        raise AttributeError()

# Generated at 2022-06-26 02:03:29.184636
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        print('ok to raise ValueError')
        raise ValueError

    with ok(ValueError, IndexError):
        print('ok to raise ValueError or IndexError')
        raise KeyError

    with ok:
        print('ok to raise any type of exception')
        raise KeyError



# Generated at 2022-06-26 02:03:33.600817
# Unit test for function ok
def test_ok():
    with ok():
        pass

    with ok(TypeError, ValueError):
        raise TypeError()

    with raises(LookupError):
        with ok(TypeError, ValueError):
            raise LookupError()


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-26 02:03:35.255271
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False



# Generated at 2022-06-26 02:03:39.132470
# Unit test for function ok
def test_ok():
    """ Test ok context manager. """
    with ok(ZeroDivisionError):
        # Will succeed without exception
        1 / 1
    with raises(ValueError):
        with ok(ZeroDivisionError):
            # Will raise a ValueError
            raise ValueError
    with ok(ZeroDivisionError):
        # Will raise a ZeroDivisionError
        1 / 0

# Generated at 2022-06-26 02:03:48.680079
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        "Foo" + 1
    with ok(ValueError):
        pass
    with ok(ValueError, TypeError):
        "Foo" + 1
    with ok(ValueError, TypeError):
        pass
    with ok(ValueError, ValueError):
        raise ValueError("Foo")
    with ok(ValueError, TypeError):
        raise ValueError("Foo")
    with ok(ValueError, TypeError):
        raise TypeError("Foo")



# Generated at 2022-06-26 02:03:55.077871
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(Exception):
        raise Exception
    with ok(ZeroDivisionError):
        raise ValueError



# Generated at 2022-06-26 02:04:04.392873
# Unit test for function ok
def test_ok():
    # stop test if no exception raised
    with ok(ZeroDivisionError):
        a = 12 / 0
        assert a == 12
    # pass exception
    with ok(ZeroDivisionError):
        a = 12 / 0
        assert a == 12
    # raise other exceptions
    with pytest.raises(ValueError):
        with ok(ZeroDivisionError):
            raise ValueError



# Generated at 2022-06-26 02:04:07.267975
# Unit test for function ok
def test_ok():
    with ok(TypeError, ValueError):
        raise TypeError
    with ok(TypeError, ValueError):
        pass


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-26 02:04:15.235676
# Unit test for function ok
def test_ok():
    """Test function ok"""
    # Normal
    with ok(ZeroDivisionError):
        a = 1 / 0
    # An exception is passed
    with ok(ZeroDivisionError):
        1 / 0
    # An exception is not passed
    # ValueError: zero length field name in format
    # with ok(ZeroDivisionError):
    #    raise ValueError
    # A exception is passed
    with ok(ZeroDivisionError, ValueError):
        1 / 0


# Scripting start
if __name__ == '__main__':
    print('Test function ok')
    print(test_ok.__doc__)
    test_ok()

# Generated at 2022-06-26 02:04:18.440146
# Unit test for function ok

# Generated at 2022-06-26 02:04:20.951838
# Unit test for function ok
def test_ok():
    """Test for context manager ok"""
    error = None
    try:
        with ok(Exception):
            raise ValueError
    except ValueError:
        error = True

    assert error is not None



# Generated at 2022-06-26 02:04:23.439859
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with ok(IndexError):
        lst = []

# Generated at 2022-06-26 02:04:25.680026
# Unit test for function ok
def test_ok():
    with ok(ValueError, RuntimeError):
        raise ValueError("")

    with raises(TypeError):
        with ok(ValueError):
            raise TypeError("")



# Generated at 2022-06-26 02:04:29.132791
# Unit test for function ok
def test_ok():
    with ok(RuntimeError):
        raise RuntimeError

    with ok(RuntimeError, TypeError):
        raise TypeError('fail')

    with pytest.raises(IndexError):
        with ok(RuntimeError, TypeError):
            raise IndexError('oops')

# Generated at 2022-06-26 02:04:33.654276
# Unit test for function ok
def test_ok():
    with ok():
        pass

    with ok(ValueError) as cm:
        raise ValueError
    assert cm.exception
    with pytest.raises(TypeError):
        with ok(ValueError) as cm:
            raise TypeError

    with ok():
        raise ValueError
    with ok():
        raise TypeError
    with ok(ValueError):
        raise TypeError



# Generated at 2022-06-26 02:04:43.554365
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with ok(ValueError):
        raise ValueError
    with ok():
        raise ValueError
    with ok(NameError, ValueError):
        raise ValueError



# Generated at 2022-06-26 02:04:53.250212
# Unit test for function ok
def test_ok():
    with ok(TypeError, ValueError):
        x = 5
        x += 1
        x.append(7)
        print(x)


test_ok()


# ------------------------------------
# 	Chapter 6: Networking
# ------------------------------------

# Connecting two sockets

import socket
import sys

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = 'www.webcode.me'
port = 80
s.connect((host, port))
s.send(b'GET / HTTP/1.1\r\n\r\n')
response = s.recv(4096)
s.close()

print(response)

# Sending and receiving TCP packets

import socket
import sys


# Generated at 2022-06-26 02:05:03.255823
# Unit test for function ok
def test_ok():
    """Unit test for ok."""
    with ok(IndexError, TypeError):
        int('1')
    try:
        with ok(IndexError, TypeError):
            raise IndexError
    except:
        raise Exception("Context did not pass IndexError")
    try:
        with ok(IndexError, TypeError):
            raise TypeError
    except:
        raise Exception("Context did not pass TypeError")
    try:
        with ok(IndexError, TypeError):
            raise IndexError()
    except:
        raise Exception("Context did not pass IndexError")
    try:
        with ok(IndexError, TypeError):
            raise TypeError()
    except:
        raise Exception("Context did not pass TypeError")

# Generated at 2022-06-26 02:05:07.402929
# Unit test for function ok
def test_ok():
    """Unit test for function ok
    """
    with ok():
        pass

    with ok(ZeroDivisionError):
        1 / 0

    with ok(TypeError):
        [].index(1)

    with ok(ZeroDivisionError):
        with ok(TypeError):
            [].index(1)



# Generated at 2022-06-26 02:05:10.193140
# Unit test for function ok
def test_ok():
    with ok(TypeError, ValueError):
        raise TypeError
    with ok(TypeError, ValueError):
        raise ValueError
    with ok(TypeError, ValueError):
        raise NotImplementedError



# Generated at 2022-06-26 02:05:15.393439
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False
    with ok(Exception, IOError):
        raise IOError
    with ok(Exception):
        raise ValueError
    with ok(AssertionError):
        assert False
    try:
        with ok(AssertionError):
            assert True
        with ok(IOError):
            raise ValueError
    except ValueError:
        pass
    else:
        assert False



# Generated at 2022-06-26 02:05:17.670196
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with ok(TypeError):
        raise TypeError()

    with ok(TypeError):
        raise ValueError()

# Generated at 2022-06-26 02:05:21.270083
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(TypeError, ValueError):
        raise TypeError
    with pytest.raises(TypeError):
        with ok(ValueError):
            raise TypeError



# Generated at 2022-06-26 02:05:23.552959
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError



# Generated at 2022-06-26 02:05:27.075352
# Unit test for function ok
def test_ok():
    with ok(OSError):
        raise OSError("Test")

    with ok(OSError, TypeError):
        raise OSError("Test")

    with ok(OSError):
        raise Exception("Test")



# Generated at 2022-06-26 02:05:51.814232
# Unit test for function ok
def test_ok():
    """Test the function ok."""

    def test_ok_exceptions():
        """Test the exceptions pass."""

        ok_list = [Exception("test"), ZeroDivisionError("ok"), ValueError("test")]

        for ok_test in ok_list:
            with ok(ZeroDivisionError):
                raise ok_test

            with ok(ZeroDivisionError):
                raise ZeroDivisionError()

    test_ok_exceptions()

    def test_ok_not_exceptions():
        """Test the exceptions raise."""

        ok_list = [Exception("test"), ZeroDivisionError("ok"), ValueError("test")]

        for ok_test in ok_list:
            with ok(ZeroDivisionError):
                raise ZeroDivisionError("ok")

    test_ok_not_exceptions()



# Generated at 2022-06-26 02:05:56.734119
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception

    with ok(ValueError):
        raise ValueError

    with ok(ValueError, TypeError):
        raise ValueError

    with ok(ValueError, TypeError):
        raise TypeError

    with raises(Exception):
        with ok(ValueError):
            raise Exception



# Generated at 2022-06-26 02:06:00.572634
# Unit test for function ok
def test_ok():
    # no exception
    with ok(Exception):
        pass

    # pass exceptions
    with ok(Exception):
        raise Exception("Exception")

    # raise other exceptions
    with pytest.raises(TypeError):
        with ok(Exception):
            raise TypeError("TypeError")



# Generated at 2022-06-26 02:06:03.173107
# Unit test for function ok
def test_ok():
    with ok():
        raise ValueError('This is a test value error')
    with ok(TypeError):
        raise ValueError('This is a test value error')



# Generated at 2022-06-26 02:06:12.153060
# Unit test for function ok
def test_ok():
    # Test for passing case
    with ok(ZeroDivisionError):
        1 / 0

    # Test for raise other exception
    with pytest.raises(TypeError):
        with ok(ZeroDivisionError):
            1 + 'abc'

    # Test for raise exception in exceptions
    with pytest.raises(ZeroDivisionError):
        with ok(TypeError):
            1 / 0

    # Test for no exception
    with ok():
        pass



# Generated at 2022-06-26 02:06:14.341441
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        raise TypeError
    with ok(TypeError):
        pass
    with ok(Exception):
        raise TypeError
    with ok(TypeError, Exception):
        raise TypeError



# Generated at 2022-06-26 02:06:16.541293
# Unit test for function ok
def test_ok():
    with ok(NameError):
        pass
    assert 1 == 1



# Generated at 2022-06-26 02:06:24.014594
# Unit test for function ok
def test_ok():
    try:
        with ok(ZeroDivisionError):
            1 / 0
    except:
        pass  # OK
    try:
        with ok(ZeroDivisionError):
            raise Exception
    except:
        pass  # NOK
    try:
        with ok(Exception):
            pass  # OK
        with ok():
            pass  # OK
    except:
        raise Exception("Should not raise exception")  # NOK



# Generated at 2022-06-26 02:06:30.435894
# Unit test for function ok
def test_ok():
    # Test 1: Exception should be passed and not raised
    with ok(AssertionError, Exception):
        raise AssertionError
    # Test 2: Exception should not be passed and thus raised
    with assert_raises(ValueError):
        with ok(AssertionError, Exception):
            raise ValueError

# Generated at 2022-06-26 02:06:33.767563
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with ok():
        print("This will print")
    # with raise_exception():
    #     print("This will not print")



# Generated at 2022-06-26 02:07:13.394005
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        print('hello world')
        raise ValueError('hello world')
    print('done')



# Generated at 2022-06-26 02:07:17.054401
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError) as context:
        res = 1 / 0

    assert context is None
    with ok(ZeroDivisionError) as context:
        res = 1 / 1

    assert context is not None



# Generated at 2022-06-26 02:07:21.138671
# Unit test for function ok
def test_ok():
    @ok(TypeError, NameError)
    def foo(x):
        return x ** 2

    assert foo(2) == 4



# Generated at 2022-06-26 02:07:24.917608
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception()

    with ok(AttributeError):
        1 / 0

    with ok(ValueError):
        1 / 0



# Generated at 2022-06-26 02:07:30.690842
# Unit test for function ok
def test_ok():
    with pytest.raises(Exception):
        with ok(RuntimeError):
            raise ValueError('test')

    with ok(ValueError):
        raise ValueError('test')

    with ok(RuntimeError):
        raise RuntimeError('test')

# Generated at 2022-06-26 02:07:34.141065
# Unit test for function ok
def test_ok():
    """
    Test function ok
    :return:
    """
    with ok(TypeError):
        a = 5 + "a"
        print(a)

# Generated at 2022-06-26 02:07:38.864594
# Unit test for function ok
def test_ok():
    try:
        with ok(ValueError):
            raise ValueError
    except ValueError as e:
        pass
    except Exception as e:
        assert False, 'Should have passed ValueError'

    try:
        with ok():
            raise ValueError
        assert False, 'Should have raised ValueError'
    except ValueError as e:
        pass

# Generated at 2022-06-26 02:07:39.927575
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with ok(ValueError):
        int('a')



# Generated at 2022-06-26 02:07:41.650159
# Unit test for function ok
def test_ok():
    """Test ok context manager."""
    with ok(ZeroDivisionError):
        1/0
    with raises(TypeError):
        with ok(ZeroDivisionError):
            raise TypeError



# Generated at 2022-06-26 02:07:47.242553
# Unit test for function ok
def test_ok():
    with ok(KeyError):
        d = {}
        d['key']  # Raises KeyError
    with ok(KeyError):
        d = {'key': 'value'}
        d['key']  # Does not raise KeyError



# Generated at 2022-06-26 02:09:09.652335
# Unit test for function ok
def test_ok():
    with ok():
        raise LookupError('blah')

    with pytest.raises(NameError):
        with ok(LookupError):
            raise NameError('blah')



# Generated at 2022-06-26 02:09:13.353826
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with raises(NameError):
        with ok(ZeroDivisionError):
            x / 0



# Generated at 2022-06-26 02:09:23.640060
# Unit test for function ok
def test_ok():
    print("Test 1 -------------------------")
    with ok(ValueError):
        pass
    print("Passed OK")

    print("Test 2 -------------------------")
    def div(a, b):
        if b == 0:
            raise ZeroDivisionError("Division by zero")
        return a / b

    with ok(ZeroDivisionError):
        div(5, 0)

    print("Passed OK")

    print("Test 3 -------------------------")
    with ok(TypeError, KeyError):
        raise ValueError("ValueError raised")

    print("Passed OK")

    print("Test 4 -------------------------")
    try:
        with ok(TypeError, KeyError):
            raise ZeroDivisionError("TypeError not raised")
    except ZeroDivisionError:
        print("ZeroDivisionError raised")


# Generated at 2022-06-26 02:09:31.721302
# Unit test for function ok
def test_ok():
    import traceback
    exc1 = Exception("First Error")
    exc2 = Exception("Second Error")
    try:
        with ok(Exception):
            raise exc2
    except Exception as e:
        assert e is exc2
    try:
        with ok(Exception):
            raise exc1
    except Exception as e:
        assert e is exc1
    try:
        with ok(Exception):
            raise Exception("Error")
    except Exception as e:
        assert e.__class__.__name__ == "Exception"



# Generated at 2022-06-26 02:09:37.433499
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        x = 1 / 0  # noqa
    with pytest.raises(ZeroDivisionError):
        with ok(TypeError):
            x = 1 / 0  # noqa



# Generated at 2022-06-26 02:09:41.237479
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False
    with ok(IndexError):
        [][1]
    with ok(IndexError, AssertionError):
        [][1]
    with ok(IndexError, AssertionError):
        assert False


# Generated at 2022-06-26 02:09:43.046493
# Unit test for function ok
def test_ok():
    """Test function ok()"""
    assert ok() is None


# Generated at 2022-06-26 02:09:49.588370
# Unit test for function ok
def test_ok():
    """This is the unit test for this funtion."""
    with ok(TypeError):
        int('2')
    try:
        int('foo')
    except (TypeError, ValueError):
        pass
    else:
        assert False



# Generated at 2022-06-26 02:09:50.510516
# Unit test for function ok
def test_ok():
    assert ok()



# Generated at 2022-06-26 02:10:01.017063
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print("hello")
        print("world")
    try:
        with ok(TypeError):
            print("hello")
            print("world")
            raise RuntimeError("I'm in trouble")
    except RuntimeError:
        print("RuntimeError raised")
    try:
        with ok(TypeError):
            print("hello")
            print("world")
            raise TypeError("I'm in trouble")
    except TypeError:
        print("TypeError raised")

