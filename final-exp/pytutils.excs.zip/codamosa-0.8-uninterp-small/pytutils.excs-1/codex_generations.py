

# Generated at 2022-06-26 02:02:27.264518
# Unit test for function ok
def test_ok():
    try:
        test_case_0()
    except AssertionError as e:
        print("Test function raised AssertionError! Message: " + str(e))
        raise(e)


test_ok()

# Generated at 2022-06-26 02:02:28.611919
# Unit test for function ok
def test_ok():
    with pytest.raises(RuntimeError):
        test_case_0()

# Generated at 2022-06-26 02:02:31.094371
# Unit test for function ok
def test_ok():
    try:
    # Test case0
        test_case_0()
    except Exception as e:
        print(e)

test_ok()

# Generated at 2022-06-26 02:02:34.564471
# Unit test for function ok
def test_ok():
    with ok():
        print('hello')
    try:
        with ok(Exception):
            raise Exception('bye')
    except Exception as e:
        assert e.args[0] == 'bye'

# Generated at 2022-06-26 02:02:36.769459
# Unit test for function ok
def test_ok():
    """Test function ok."""
    # raise Exception("Test not implemented.")
    assert 42 == 42


# Unit tests for main

# Generated at 2022-06-26 02:02:38.372305
# Unit test for function ok
def test_ok():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-26 02:02:45.554197
# Unit test for function ok
def test_ok():
    with ok(Exception):
        pass
    with ok(Exception):
        raise Exception
    with ok(Exception):
        raise ValueError
    try:
        with ok(ValueError):
            raise Exception
    except Exception:
        pass
    try:
        with ok(ValueError):
            raise Exception
    except ValueError:
        raise AssertionError('Should not get here')
    with ok(Exception):
        with ok(Exception):
            with ok(Exception):
                raise ValueError
    try:
        with ok(Exception):
            with ok(Exception):
                with ok(ValueError):
                    raise ValueError
    except ValueError:
        pass

# Generated at 2022-06-26 02:02:48.918198
# Unit test for function ok
def test_ok():

    with ok():
        pass

    with pytest.raises(ValueError):
        with ok(TypeError):
            raise ValueError

    with pytest.raises(TypeError):
        with ok(ValueError):
            raise TypeError

# Generated at 2022-06-26 02:02:50.186318
# Unit test for function ok
def test_ok():
    # this is an assert
    assert ok()

test_ok()

# Generated at 2022-06-26 02:02:51.455816
# Unit test for function ok
def test_ok():
  with pytest.raises(Exception):
    test_case_0()

# Generated at 2022-06-26 02:02:55.311219
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with ok(ZeroDivisionError):
        print("Hello")



# Generated at 2022-06-26 02:02:58.788239
# Unit test for function ok
def test_ok():
    with pytest.raises(TypeError):
        with ok(TypeError):
            int(1.5)

    with ok(TypeError):
        int('1')



# Generated at 2022-06-26 02:03:02.078750
# Unit test for function ok
def test_ok():
    """Test function ok."""
    try:
        with ok(ValueError):
            1 / 0
    except ZeroDivisionError:
        assert True
    else:
        assert False



# Generated at 2022-06-26 02:03:07.059782
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        raise TypeError
    try:
        with ok(FileNotFoundError):
            raise TypeError
    except TypeError:
        pass
    else:
        raise Exception
    try:
        with ok(Exception):
            raise TypeError
    except TypeError:
        pass
    else:
        raise Exception
    with ok(FileNotFoundError):
        pass



# Generated at 2022-06-26 02:03:08.958773
# Unit test for function ok
def test_ok():
    """Unit test for function ok()"""
    assert isinstance(ok, contextmanager)



# Generated at 2022-06-26 02:03:14.190191
# Unit test for function ok
def test_ok():
    try:
        with ok(TypeError):
            int("ABC")
    except ValueError:
        pass
    finally:
        try:
            with ok(TypeError, ValueError):
                int("ABC")
        except ValueError:
            pass

__all__ = ["ok"]

# Generated at 2022-06-26 02:03:16.618092
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int('1')

    with ok():
        int('N/A')



# Generated at 2022-06-26 02:03:20.381498
# Unit test for function ok
def test_ok():
    with ok(ValueError, TypeError):
        my_int = 'abc'
        print(my_int + 1)
    with ok(ValueError, TypeError):
        raise TypeError

# Generated at 2022-06-26 02:03:24.545407
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False

    with raises(ZeroDivisionError):
        with ok(AssertionError):
            1 / 0

    with raises(AssertionError):
        with ok(ZeroDivisionError):
            assert False



# Generated at 2022-06-26 02:03:25.817827
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    assert ok()



# Generated at 2022-06-26 02:03:32.715880
# Unit test for function ok
def test_ok():
    with ok(ValueError, TypeError):
        dict()['non_existent_key']
    with ok(ValueError, TypeError):
        int('not a number')



# Generated at 2022-06-26 02:03:35.685611
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        pass
    try:
        with ok(ZeroDivisionError):
            raise ValueError
    except ValueError:
        pass



# Generated at 2022-06-26 02:03:37.873446
# Unit test for function ok
def test_ok():
    try:
        with ok(ZeroDivisionError):
            x = 1 / 0
    except Exception as e:
        print("Error: {}".format(e))



# Generated at 2022-06-26 02:03:41.197516
# Unit test for function ok
def test_ok():
    with ok(ValueError) as ctx_mgr:
        raise ValueError()
    with ok(Exception, ValueError) as ctx_mgr:
        raise TypeError()
    with ok(ValueError) as ctx_mgr:
        raise TypeError()


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-26 02:03:47.028842
# Unit test for function ok
def test_ok():
    with ok():
        pass
    with ok(Exception):
        raise Exception
    with ok(Exception, TypeError):
        raise Exception
    with ok(Exception, TypeError):
        raise TypeError
    with raises(ValueError):
        with ok(TypeError):
            raise ValueError


# Unit test

# Generated at 2022-06-26 02:03:50.519245
# Unit test for function ok
def test_ok():

    # Test with no exception
    with ok():
        True is True

    # Test with exception
    with pytest.raises(IOError):
        with ok(MemoryError):
            1 / 0



# Generated at 2022-06-26 02:03:53.547339
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False

    with raises(AssertionError):
        with ok(ValueError):
            assert False

# Generated at 2022-06-26 02:03:55.688657
# Unit test for function ok
def test_ok():
    with ok(Exception):
        pass
    with pytest.raises(AssertionError):
        with ok(TypeError):
            raise TypeError



# Generated at 2022-06-26 02:04:02.634961
# Unit test for function ok
def test_ok():
    with ok(AttributeError):
        {}.not_exist
    with ok(TypeError, AttributeError):
        {}.not_exist
    with ok(AttributeError):
        int('a')
    with ok(TypeError, AttributeError):
        int('a')



# Generated at 2022-06-26 02:04:08.402161
# Unit test for function ok
def test_ok():
    def raise_error(num):
        raise TypeError("Num is not an integer")

    with ok(TypeError, ValueError):
        raise_error(10.0)

    try:
        with ok(ValueError):
            raise_error(10.0)
    except TypeError as e:
        assert type(e) == TypeError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-26 02:04:16.316754
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('Test')



# Generated at 2022-06-26 02:04:22.593115
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False

    with ok(AssertionError):
        assert True

    with ok(AssertionError):
        assert True

    with ok(KeyError, IndexError):
        my_list = ['item']
        my_list[1]

    with ok(KeyError, IndexError):
        my_list = ['item']
        my_list[0]

    try:
        with ok(AssertionError):
            assert False
    except:
        print('An exception was raised')


# Run unit tests
test_ok()

# Generated at 2022-06-26 02:04:25.450608
# Unit test for function ok
def test_ok():
    """Test for context manager ok.
    """

# Generated at 2022-06-26 02:04:31.645601
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    try:
        # with ok(Exception):
        #     raise TypeError
        with ok(TypeError):
            raise TypeError
        with ok(TypeError):
            raise Exception
    except Exception as e:
        assert isinstance(e, Exception)
    finally:
        pass
    # with ok(TypeError):
    #     raise TypeError
    # with ok(TypeError):
    #     pass


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-26 02:04:37.624911
# Unit test for function ok
def test_ok():
    with ok():
        pass

    with ok(ValueError):
        pass

    with ok(TypeError, ValueError):
        pass

    with ok(ValueError, TypeError):
        pass

    with pytest.raises(ValueError):
        with ok(TypeError):
            raise TypeError

    with pytest.raises(ValueError):
        with ok(ValueError):
            raise TypeError



# Generated at 2022-06-26 02:04:39.129591
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False



# Generated at 2022-06-26 02:04:42.916985
# Unit test for function ok
def test_ok():
    context = ok(ValueError, TypeError)
    context.__enter__()
    try:
        raise KeyError
    except KeyError:
        pass
    try:
        raise TypeError
    except TypeError:
        pass


test_ok()

# Generated at 2022-06-26 02:04:45.940060
# Unit test for function ok
def test_ok():
    """test_ok()-- verify that the ok context manager
    passes exceptions ok, and raises Exceptions that
    are not in exceptions"""
    assert(ok(ValueError))
    with ok(ValueError):
        raise ValueError
    with raises(SyntaxError):
        with ok(ValueError):
            raise SyntaxError



# Generated at 2022-06-26 02:04:49.470553
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(ValueError):
        raise ValueError()
    with ok(IndexError, ValueError):
        raise ValueError()
    with ok(IndexError, ValueError):
        raise IndexError()
    with ok():
        raise TypeError()



# Generated at 2022-06-26 02:04:52.475757
# Unit test for function ok
def test_ok():
    with raises(ZeroDivisionError):
        with ok(TypeError):
            1 / 0
    with ok(ZeroDivisionError):
        with raises(TypeError):
            1 / 0



# Generated at 2022-06-26 02:05:10.289481
# Unit test for function ok
def test_ok():
    try:
        with ok(ValueError):
            int('a')
    except Exception as e:
        assert type(e) == ValueError

    try:
        with ok(ValueError):
            raise TypeError
    except Exception as e:
        assert type(e) == TypeError



# Generated at 2022-06-26 02:05:11.917413
# Unit test for function ok
def test_ok():
    ok_list = [ValueError, TypeError]
    assert ok(ok_list)



# Generated at 2022-06-26 02:05:13.983597
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('N/A')
    with ok(TypeError):
        int('two')



# Generated at 2022-06-26 02:05:20.061024
# Unit test for function ok
def test_ok():
    with ok(Exception):
        pass

    with ok(TypeError):
        pass

    with ok(KeyError):
        raise KeyError()

    with raises(TypeError):
        with ok(TypeError):
            raise TypeError()

    with raises(KeyError):
        with ok(TypeError):
            raise KeyError()

    # If a generator raises StopIteration, the caller isn't going to see it anyway
    @ok(StopIteration)
    def f():
        raise StopIteration()
    f()

# Generated at 2022-06-26 02:05:24.312211
# Unit test for function ok
def test_ok():
    with ok(TypeError, ValueError):
        pass
    with ok(TypeError, ValueError):
        raise TypeError
    with pytest.raises(ValueError):
        with ok(TypeError, ValueError):
            raise ValueError
    with pytest.raises(NameError):
        with ok(TypeError, ValueError):
            raise NameError

# Generated at 2022-06-26 02:05:26.215011
# Unit test for function ok
def test_ok():
    """Tests function ok."""
    with ok(ValueError):
        raise ValueError("No error")



# Generated at 2022-06-26 02:05:29.001673
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with assert_raises(KeyError):
        with ok():
            raise KeyError()



# Generated at 2022-06-26 02:05:30.912095
# Unit test for function ok
def test_ok():
    """Test context manager to pass exceptions."""
    with ok(ZeroDivisionError):
        x = 1 / 0
    assert True

# Generated at 2022-06-26 02:05:37.095535
# Unit test for function ok
def test_ok():
    with ok(IndexError):
        [1, 2, 3][4]
    with ok(IndexError):
        raise IndexError('passed')
    with ok(IndexError, TypeError):
        [1, 2, 3][4]
        {}[4]
    with raises(ZeroDivisionError):
        with ok(IndexError, TypeError):
            [1, 2, 3][4]
            raise ZeroDivisionError('fail')



# Generated at 2022-06-26 02:05:37.676932
# Unit test for function ok
def test_ok():
    assert True



# Generated at 2022-06-26 02:06:14.574119
# Unit test for function ok
def test_ok():
    with ok(TypeError, ValueError):
        print("OK")


try:
    with ok(TypeError, ValueError):
        print("OK")
        raise IndexError("INDEX")
except IndexError as e:
    print("Error has been raised")


# Unit tests for yield_return.

# Generated at 2022-06-26 02:06:17.477773
# Unit test for function ok
def test_ok():
    """unit test for function ok
    """
    with ok(AssertionError):
        assert False



# Generated at 2022-06-26 02:06:23.643998
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int("a")
    with ok(ValueError, TypeError):
        raise TypeError()
    with ok(ValueError):
        raise TypeError()

    # Fails
    try:
        with ok(ValueError, TypeError):
            raise Exception()
    except Exception:
        assert True



# Generated at 2022-06-26 02:06:30.242749
# Unit test for function ok
def test_ok():
    with ok():
        print("This will be printed")
        raise ValueError()
    try:
        with ok(ValueError):
            raise ValueError()
    except NameError:
        pass
    try:
        with ok(NameError):
            raise ValueError()
    except ValueError:
        pass

# Generated at 2022-06-26 02:06:39.235125
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False

    with ok(ZeroDivisionError, AssertionError):
        assert False

    with ok(ZeroDivisionError, AssertionError):
        pass

    with ok(ZeroDivisionError, AssertionError):
        raise ZeroDivisionError

    with ok(ZeroDivisionError, AssertionError):
        raise AssertionError

    with pytest.raises(ZeroDivisionError):
        with ok(AssertionError):
            raise ZeroDivisionError

    with pytest.raises(ZeroDivisionError):
        with ok(AssertionError):
            raise ZeroDivisionError

    with pytest.raises(Exception):
        with ok(ZeroDivisionError):
            raise Exception

# Generated at 2022-06-26 02:06:44.953613
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(ValueError, TypeError):
        raise ValueError
    with ok(ValueError, TypeError):
        raise TypeError
    with ok(TypeError):
        raise IndexError



# Generated at 2022-06-26 02:06:49.675264
# Unit test for function ok
def test_ok():
    with ok(OSError):
        raise OSError('This exception is to be passed')
    with ok(OSError):
        raise OSError('This exception is to be raised')

# Generated at 2022-06-26 02:06:56.433799
# Unit test for function ok
def test_ok():
    """Unit test for function ok.
    :return:
    """

    with ok(TypeError, ValueError):
        print('Hello world')

    with ok(TypeError, ValueError):
        raise TypeError('Error message')

    with ok(TypeError, ValueError):
        raise NameError('Error message')


# Only run unit test if run as main
if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-26 02:07:05.180363
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        print("Division is ok.")
        division = 1 / 0
    with ok(Exception, ZeroDivisionError):
        print("Division is ok.")
        division = 1 / 0
    try:
        with ok(ZeroDivisionError):
            print("Division is ok.")
            division = 1 / 'a'
    except TypeError as e:
        print(e)
        pass

# Generated at 2022-06-26 02:07:11.950548
# Unit test for function ok
def test_ok():
    with ok():
        pass

    with ok(TypeError):
        raise TypeError()

    try:
        with ok():
            raise AssertionError()
    except AssertionError:
        pass
    else:
        assert False, "AssertionError should be raised"



# Generated at 2022-06-26 02:08:25.777551
# Unit test for function ok
def test_ok():
    with ok(AttributeError):
        with ok(LookupError):
            [][0]  # Raises IndexError
        {}['hello']  # Raises KeyError
    [][0]  # Raises IndexError



# Generated at 2022-06-26 02:08:30.677949
# Unit test for function ok
def test_ok():
    """Test function ok"""
    with ok(AssertionError):
        assert False
    try:
        with ok(AssertionError):
            assert True
    except Exception as e:
        print(e)
        ok_flag = False
    else:
        ok_flag = True
    assert ok_flag


# No need to modify below this line
# ______________________________________________________________________________


# Generated at 2022-06-26 02:08:40.690825
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError, ValueError):
        l = [1, 2, 3]
        int('N/A')
        l[4]
    with ok(TypeError, IndexError):
        l = [1, 2, 3]
        int('N/A')
        l[4]
    with ok(TypeError):
        l = [1, 2, 3]
        int('N/A')
        l[4]



# Generated at 2022-06-26 02:08:52.692959
# Unit test for function ok
def test_ok():
    """Unit test for function ok
    """
    # Test exceptions
    try:
        with ok(RuntimeError) as r:
            raise RuntimeError
        assert r is None, 'r should be None'
    except Exception as e:
        assert False, 'exception raised: {}'.format(e)

    try:
        with ok(ValueError) as r:
            raise RuntimeError
    except RuntimeError as e:
        assert True
    else:
        assert False, 'exception not raised'

    try:
        with ok(ValueError, TypeError) as r:
            raise RuntimeError
    except RuntimeError as e:
        assert True
    else:
        assert False, 'exception not raised'


# Generated at 2022-06-26 02:08:59.936125
# Unit test for function ok
def test_ok():
    """A unit test for function ok"""
    print(ok.__doc__)
    # assert ok.__doc__ == docstring
    with ok(ValueError):
        assert int("oops") == 1

    # Failure
    with ok(ValueError):
        assert int("oops") == 2

    # Failure
    with ok(TypeError):
        assert int("oops") == 1

# Generated at 2022-06-26 02:09:02.818833
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception
    with raises(Exception):
        with ok(TypeError):
            raise Exception



# Generated at 2022-06-26 02:09:12.800441
# Unit test for function ok
def test_ok():
    # Test no exception
    try:
        with ok():
            pass
        assert True, "no exception passed"
    except Exception:
        assert False, "test_ok_okay_no_exception failed"

    # Test good exception
    try:
        with ok(ZeroDivisionError) as e:
            raise ZeroDivisionError
        assert e is None, "test_ok_okay_good_exception failed"
    except Exception:
        assert False, "test_ok_okay_good_exception failed"

    # Test bad exception
    try:
        with ok(ZeroDivisionError) as e:
            raise AttributeError
    except AttributeError:
        assert True, "test_ok_bad_exception passed"
    except Exception:
        assert False, "test_ok_bad_exception failed"

# Generated at 2022-06-26 02:09:18.968743
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        print("Expected output not displayed. See description.")
    with pytest.raises(AttributeError):
        with ok(ValueError):
            raise AttributeError("This is an attribute error.")



# Generated at 2022-06-26 02:09:20.692995
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with ok():
        raise IndexError



# Generated at 2022-06-26 02:09:22.551604
# Unit test for function ok
def test_ok():
    """Verify that the ok context manager passes exceptions
    """
    assert ok(Exception)

# Generated at 2022-06-26 02:12:02.702750
# Unit test for function ok
def test_ok():
    # Test that an exception is passed through
    with ok(TypeError):
        raise TypeError()
    # Test that an exception is not passed through
    with pytest.raises(ValueError):
        raise ValueError()



# Generated at 2022-06-26 02:12:03.961781
# Unit test for function ok
def test_ok():
    with ok():
        pass



# Generated at 2022-06-26 02:12:06.862899
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    with ok(Exception):
        raise Exception("Valid Exception")
    with ok(ValueError):
        raise ValueError("Valid Exception")
    with ok((ValueError, ZeroDivisionError)):
        raise ZeroDivisionError("Valid Exception")
    with ok(Exception):
        raise ValueError("Invalid exception")



# Generated at 2022-06-26 02:12:09.089433
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int("bla")



# Generated at 2022-06-26 02:12:15.738783
# Unit test for function ok
def test_ok():
    """Test function ok"""
    try:
        with ok(IndexError):
            raise IndexError
    except Exception as e:
        assert isinstance(e, IndexError)

    try:
        with ok(IndexError):
            raise ValueError
    except Exception as e:
        assert isinstance(e, ValueError)



# Generated at 2022-06-26 02:12:24.853924
# Unit test for function ok
def test_ok():
    """Simple test for context manager ok"""
    with ok(TypeError, ValueError):
        print('Hello')
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError):
        print(int('N/A'))
    with ok(ValueError):
        print(int('100'))

