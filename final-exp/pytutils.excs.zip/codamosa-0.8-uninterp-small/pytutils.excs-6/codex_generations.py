

# Generated at 2022-06-26 02:02:38.742050
# Unit test for function ok
def test_ok():
    var_0 = ok()
    assert var_0 == True

# Generated at 2022-06-26 02:02:39.581153
# Unit test for function ok
def test_ok():
    test_case_0()


# Main
if __name__ == "__main__":
    test_ok()
    print("Ok")

# Generated at 2022-06-26 02:02:39.969050
# Unit test for function ok
def test_ok():
    assert callable(ok)

# Generated at 2022-06-26 02:02:45.718171
# Unit test for function ok
def test_ok():
    try:
        test_case_0()
        pass
    except Exception as e:
        print("Error(test_ok): " + str(e))
        assert False
    else:
        pass
    finally:
        pass


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-26 02:02:47.884795
# Unit test for function ok
def test_ok():
    assert 1 == 1, 'Test OK'
    assert 2 > 1, 'Test OK'
    assert 0 == 1, 'Test FAILED'

# Generated at 2022-06-26 02:02:57.655076
# Unit test for function ok

# Generated at 2022-06-26 02:03:07.391367
# Unit test for function ok
def test_ok():
    with pytest.raises(Exception) as excinfo:
        ok(ValueError, IndexError)
        # test_case_0()
    assert excinfo.type == Exception

# Generated at 2022-06-26 02:03:08.958624
# Unit test for function ok
def test_ok():

    # Test case 0
    test_case_0()

# Generated at 2022-06-26 02:03:13.829311
# Unit test for function ok
def test_ok():
    with ok():
        pass

    with ok(ValueError):
        raise ValueError()

    with raises(ValueError):
        with ok(TypeError):
            raise ValueError()



if __name__ == '__main__':
    main()

# Generated at 2022-06-26 02:03:16.618433
# Unit test for function ok
def test_ok():
    """
    Verifies that ok function works as expected
    """
    with ok(ValueError):
        test_case_0()
        
if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-26 02:03:19.920773
# Unit test for function ok
def test_ok():
    assert sum([ok, ok]) == 2



# Generated at 2022-06-26 02:03:23.821733
# Unit test for function ok
def test_ok():
    # Given
    with ok(ValueError):
        # When
        raise ValueError()

    # Then
    with raises(AssertionError):
        with ok(ValueError):
            # When
            raise TypeError()

# Generated at 2022-06-26 02:03:26.636156
# Unit test for function ok
def test_ok():
    with ok(FileNotFoundError):
        open('wrong_file.txt', 'r')
    with raises(NameError):
        with ok(FileNotFoundError):
            print(variable_which_doesnt_exist)

# Generated at 2022-06-26 02:03:29.514488
# Unit test for function ok
def test_ok():
    try:
        with ok(ValueError):
            raise ValueError
    except ValueError:
        pass
    else:
        raise ValueError



# Generated at 2022-06-26 02:03:33.178887
# Unit test for function ok
def test_ok():
    # Test for simple ok
    with ok():
        pass
    # Test for exception
    with pytest.raises(Exception, match=r".*"):
        with ok(ZeroDivisionError):
            raise Exception()



# Generated at 2022-06-26 02:03:35.641394
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    row = None
    with ok(Exception):
        row = "snow"

    assert row is not None

# Generated at 2022-06-26 02:03:36.885863
# Unit test for function ok
def test_ok():
    with ok(ArithmeticError):
        1 / 0



# Generated at 2022-06-26 02:03:39.019878
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0

# Generated at 2022-06-26 02:03:42.143634
# Unit test for function ok
def test_ok():
    """Test ok function."""
    with ok(ValueError):
        raise ValueError


# Print an error message and abort the process

# Generated at 2022-06-26 02:03:45.270076
# Unit test for function ok
def test_ok():
    """Test ok function(context manager)"""
    with ok(ValueError):
        int('N/A')



# Generated at 2022-06-26 02:03:54.034502
# Unit test for function ok
def test_ok():
    with ok():
        with ok():
            with ok(Exception):
                raise Exception()
            raise ValueError()
        with ok(Exception, ValueError):
            raise ValueError()
    with ok(Exception):
        with ok(ValueError):
            raise TypeError()



# Generated at 2022-06-26 02:03:56.837132
# Unit test for function ok
def test_ok():
    """
    Unit test for function ok
    :return: None
    """
    with ok(Exception):
        raise Exception("Exception")

    try:
        with ok(IndexError):
            raise KeyError("wrong exception")
    except Exception as e:
        assert isinstance(e, Exception)

# Generated at 2022-06-26 02:04:01.164471
# Unit test for function ok
def test_ok():
    with ok(Exception, ValueError):
        raise ValueError
    with pytest.raises(KeyError):
        with ok(Exception, ValueError):
            raise KeyError



# Generated at 2022-06-26 02:04:09.114760
# Unit test for function ok
def test_ok():
    # as context manager
    with ok():
        1
    with ok(TypeError):
        a = 1 + []
    with ok(TypeError):
        a = 1 + {}
    # as decorator
    @ok
    def ok_test():
        1
    ok_test()
    @ok(TypeError)
    def ok_test():
        a = 1 + []
    ok_test()
    try:
        @ok(TypeError)
        def ok_test():
            a = 1 + {}
        ok_test()
        assert False
    except Exception:
        pass



# Generated at 2022-06-26 02:04:11.969078
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('a')

    with raises(TypeError):
        with ok(ValueError):
            1 + 'a'



# Generated at 2022-06-26 02:04:14.040982
# Unit test for function ok
def test_ok():
    try:
        with ok(ZeroDivisionError):
            print(1 / 0)
    except:
        print("Exception raised")


test_ok()

# Generated at 2022-06-26 02:04:16.836718
# Unit test for function ok
def test_ok():
    try:
        with ok(AssertionError):
            assert 0
    except:
        pass
    else:
        raise AssertionError("ok did not pass exception")



# Generated at 2022-06-26 02:04:19.566631
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError):
        raise TypeError()
    with raises(TypeError):
        with ok(ValueError):
            raise TypeError()



# Generated at 2022-06-26 02:04:22.182743
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        a, b = 1, 'a'
    assert a == 1
    with ok(TypeError, ValueError):
        try:
            [][0]
        except:
            pass


# Test Case 1

# Generated at 2022-06-26 02:04:23.669888
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError("Not an error")



# Generated at 2022-06-26 02:04:32.709134
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0



# Generated at 2022-06-26 02:04:37.100757
# Unit test for function ok
def test_ok():
    # Test 1
    with ok(ValueError):
        print("Test 1: value error")
        raise ValueError
    # Test 2
    with ok(ValueError):
        print("Test 2: value error")
        raise Exception


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-26 02:04:38.559525
# Unit test for function ok
def test_ok():
    with ok(OSError):
        raise OSError('Some Message')



# Generated at 2022-06-26 02:04:42.034692
# Unit test for function ok
def test_ok():
    with ok(Exception) as e:
        raise Exception('Pass the exception')

    with ok(AssertionError) as e:
        assert False

    with ok():
        raise Exception('Do not pass this exception')

# Generated at 2022-06-26 02:04:46.016928
# Unit test for function ok
def test_ok():
    """Tests ok function"""
    # Ok with no exception
    with ok():
        raise ValueError

    # Ok with ValueError
    with ok(ValueError):
        raise ValueError

    # Ok with TypeError and ValueError
    with ok(TypeError, ValueError):
        raise ValueError

    # Not ok with ValueError (TypeError)
    with assert_raises(TypeError):
        with ok(ValueError):
            raise TypeError



# Generated at 2022-06-26 02:04:48.845135
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        print('I am OK')
        raise ValueError('I do not pass')
        print('I am still OK')


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-26 02:04:54.238842
# Unit test for function ok
def test_ok():
    """Test case for function ok."""

    def inner():
        return 3.0 / 0.0

    with ok(ZeroDivisionError):
        inner()
    assert inner() == 3.0 / 0.0

    with ok(ZeroDivisionError):
        inner()
    assert inner() == 3.0 / 0.0


if __name__ == '__main__':
    import pytest

    pytest.main('test_ok.py')

# Generated at 2022-06-26 02:04:58.499800
# Unit test for function ok
def test_ok():
    """Test function ok to check if exceptions are passed"""
    with ok(ValueError):
        1/0
        assert False, "ZeroDivisionError should have been passed by ok()"
    with ok(TypeError):
        1 + '1'
        assert False, "TypeError should have been passed by ok()"



# Generated at 2022-06-26 02:05:00.641122
# Unit test for function ok
def test_ok():

    with ok(AttributeError):
        ok()

    with ok(AttributeError):
        raise ValueError('Foo')

    with ok(AttributeError):
        raise AttributeError('Foo')

# Generated at 2022-06-26 02:05:04.642116
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(AssertionError):
        assert False

    with ok(ZeroDivisionError):
        1 / 0

    with raises(NameError):
        with ok(AttributeError):
            undefined_variable

# Generated at 2022-06-26 02:05:23.076934
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok():
        raise Exception
    with pytest.raises(Exception):
        with ok():
            raise Exception



# Generated at 2022-06-26 02:05:30.707880
# Unit test for function ok
def test_ok():
    """Test function for ok"""
    #
    # Test for no exception
    with ok(TypeError, ValueError):
        print("Test")
    #
    # Test for TypeError
    try:
        with ok(TypeError, ValueError):
            print(['a'], 'b')
    except TypeError:
        pass
    #
    # Test for ValueError
    try:
        with ok(TypeError, ValueError):
            d = {'a': 1, 'b': 2, 'c': 3}
            print(d['d'])
    except ValueError:
        pass



# Generated at 2022-06-26 02:05:32.881059
# Unit test for function ok
def test_ok():
    assert isinstance(ok(), ContextDecorator)


if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-26 02:05:34.359380
# Unit test for function ok
def test_ok():
    """Unit test for ok function."""
    assert ok(AssertionError) is not None



# Generated at 2022-06-26 02:05:37.677491
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('N/A')
    with raises(ValueError):
        int('N/A')


# Find files recursively

# Generated at 2022-06-26 02:05:40.123172
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(1 + '1')
    with ok(TypeError, ValueError):
        print(int('1'))



# Generated at 2022-06-26 02:05:41.524251
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print(a)
    assert True



# Generated at 2022-06-26 02:05:44.173352
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with pytest.raises(ZeroDivisionError):
        with ok(TypeError):
            1 / 0



# Generated at 2022-06-26 02:05:44.724231
# Unit test for function ok
def test_ok():
    pass

# Generated at 2022-06-26 02:05:48.963936
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False
    with ok(AssertionError, TypeError, AttributeError):
        raise ValueError
    with ok(ValueError):
        raise ValueError
    with ok():
        pass


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-26 02:06:25.739412
# Unit test for function ok
def test_ok():
    with ok():
        pass

    with pytest.raises(ValueError):
        with ok():
            raise ValueError("Raised ValueError exception")



# Generated at 2022-06-26 02:06:33.321267
# Unit test for function ok
def test_ok():
    with ok(OSError):
        raise OSError("go away")
    with raises(ValueError):
        with ok(OSError):
            raise ValueError("hello")



# Generated at 2022-06-26 02:06:39.489157
# Unit test for function ok
def test_ok():
    """Test function ok.
    """
    with ok(ValueError):
        int('N/A')
    with ok(ValueError):
        raise ValueError()
    with ok(ValueError, ArithmeticError):
        raise ArithmeticError()



# Generated at 2022-06-26 02:06:43.078313
# Unit test for function ok
def test_ok():
    with ok(Exception):
        a = 1 / 0
    with not_raises(ZeroDivisionError):
        a = 1 / 1



# Generated at 2022-06-26 02:06:43.795727
# Unit test for function ok
def test_ok():
    pass

# Generated at 2022-06-26 02:06:46.182855
# Unit test for function ok
def test_ok():
    # test with an exception
    with pytest.raises(ValueError):
        with ok(IndexError):
            raise ValueError("Testing value error")

    # test without an exception
    with ok(ValueError):
        pass



# Generated at 2022-06-26 02:06:51.592864
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    print('OK')
    # with ok(ZeroDivisionError):
    #     1 / 1
    # print('OK')



# Generated at 2022-06-26 02:06:55.748534
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int("abc")
    with ok(TypeError):
        int("abc")

    # with ok(TypeError):
    #     int("10", base=2)



# Generated at 2022-06-26 02:06:58.273712
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        x = 1/0
        assert False



# Generated at 2022-06-26 02:07:03.120220
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    try:
        with ok(TypeError):
            raise ValueError()
    except ValueError:
        pass
    else:
        assert ValueError



# Generated at 2022-06-26 02:08:21.245899
# Unit test for function ok
def test_ok():
    """Test the ok context manager."""
    def f():
        with ok(ValueError):
            raise ValueError("a")
        with ok(ValueError):
            raise TypeError("b")
            assert False
    f()

    try:
        with ok(ValueError):
            raise TypeError("b")
            assert False
        assert False
    except TypeError:
        pass


# Test for function mkdir

# Generated at 2022-06-26 02:08:24.961351
# Unit test for function ok
def test_ok():
    with ok():
        raise ValueError
    with ok():
        raise TypeError



# Generated at 2022-06-26 02:08:30.158702
# Unit test for function ok
def test_ok():
    with ok():
        raise Exception('1')
    with ok(ValueError):
        raise ValueError('2')
    with pytest.raises(TypeError):
        with ok(ValueError):
            raise TypeError('2')

# This will run only if this module was called directly
if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-26 02:08:32.395931
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1/0
    with ok(ZeroDivisionError, TypeError):
        pass
    with raises(AssertionError):
        with ok(ZeroDivisionError, TypeError):
            1/0



# Generated at 2022-06-26 02:08:35.966278
# Unit test for function ok
def test_ok():
    with ok(IndexError):
        [][0]



# Generated at 2022-06-26 02:08:37.310493
# Unit test for function ok
def test_ok():
    assert ok()



# Generated at 2022-06-26 02:08:39.026269
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception
        assert False



# Generated at 2022-06-26 02:08:43.103671
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        # Will pass through
        pass

    with ok(TypeError, ValueError):
        # Will pass through
        pass

    with ok(TypeError, ValueError):
        1 / 0

    with ok(TypeError):
        'abc' + 1


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-26 02:08:47.967014
# Unit test for function ok
def test_ok():
    """Test function ok with context manager
    """
    with ok(TypeError):
        print("hello")
        print("hello")
        int("hello")
        print("hello")


if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-26 02:08:51.827604
# Unit test for function ok
def test_ok():
    with ok(ValueError, TypeError):
        int("a")

    with ok(ValueError):
        int("a")

    try:
        with ok(TypeError):
            int("a")
    except ValueError:
        pass


test_ok()

# Generated at 2022-06-26 02:11:46.299225
# Unit test for function ok
def test_ok():
    import sys
    from io import StringIO
    out: StringIO = StringIO()
    saved_stdout: sys.__stdout__ = sys.stdout
    try:
        sys.stdout = out
        for _ in ok(ValueError):
            print('spam')
            raise ValueError('test_ok')
    except ValueError:
        pass
    finally:
        sys.stdout = saved_stdout
    assert out.getvalue() == 'spam\n'


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-26 02:11:50.327045
# Unit test for function ok
def test_ok():
    """Unit test for ok context manager."""
    with ok(AssertionError):
        assert False
    with pytest.raises(AssertionError):
        with ok(TypeError):
            assert False

# Generated at 2022-06-26 02:11:56.337923
# Unit test for function ok
def test_ok():
    def raiser(arg=None, *exceptions):
        @contextmanager
        def wrapper():
            try:
                yield
            except Exception as e:
                if isinstance(e, exceptions):
                    pass
                else:
                    raise e
        return wrapper

    with ok(IndexError):
        raise Exception()

    with raises(Exception):
        with ok(IndexError):
            raise Exception()

    with ok(Exception, IndexError):
        raise IndexError()

    with raises(IndexError):
        with ok(Exception, IndexError):
            raise IndexError()

    with raises(NotImplementedError):
        with raiser(Exception, IndexError):
            raise NotImplementedError()



# Generated at 2022-06-26 02:12:02.868481
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print('hello')
    try:
        with ok(ValueError):
            raise ValueError
    except ValueError:
        raise AssertionError("Context manager does not pass the exception.")


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-26 02:12:04.622567
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0


# Without using the ok function

# Generated at 2022-06-26 02:12:09.094124
# Unit test for function ok
def test_ok():
    with ok(TypeError, KeyError):
        'a' + 1
    with ok(TypeError, KeyError):
        1['a']

# Generated at 2022-06-26 02:12:13.833173
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with raises(TypeError):
        with ok(KeyError):
            raise TypeError()



# Generated at 2022-06-26 02:12:16.214515
# Unit test for function ok
def test_ok():
    """Test function ok."""
    # Test for normal operation
    try:
        with ok(TypeError):
            int('1')
    except Exception as e:
        raise e
    else:
        pa

# Generated at 2022-06-26 02:12:24.189908
# Unit test for function ok
def test_ok():
    with ok(TypeError, ValueError):
        print('No error')
    with ok(TypeError, ValueError):
        raise TypeError
    with ok(TypeError, ValueError):
        raise ValueError
    with ok(TypeError, ValueError):
        raise NameError



# Generated at 2022-06-26 02:12:26.295856
# Unit test for function ok
def test_ok():
    with ok(Exception):
        a = int('a')
    assert foo() == 'ok'

