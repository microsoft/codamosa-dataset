

# Generated at 2022-06-26 02:02:28.897030
# Unit test for function ok
def test_ok():
    assert callable(ok)

# Generated at 2022-06-26 02:02:39.690706
# Unit test for function ok
def test_ok():
    # Start
    with pytest.raises(ValueError):
        with ok():
            raise ValueError

    try:
        with ok():
            raise ValueError
    except NoException:
        pass

    # Mid
    with ok(ValueError):
        raise ValueError

    with ok(ValueError):
        raise ValueError

    # End
    with ok(TypeError, ValueError):
        raise ValueError

    with ok(TypeError, ValueError):
        raise ValueError

# Generated at 2022-06-26 02:02:50.617339
# Unit test for function ok
def test_ok():
    try:
        with ok():
            raise Exception("Not a problem")
    except Exception:
        assert False
    else:
        assert True

    try:
        with ok(TypeError):
            raise ValueError("Problem")
    except TypeError:
        assert False
    except ValueError:
        assert True
    else:
        assert False

    try:
        with ok(TypeError):
            raise TypeError("Not a problem")
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-26 02:02:52.846715
# Unit test for function ok
def test_ok():
    """Test function ok with passing exceptions"""
    try:
        with var_0:
            raise exception_1
    except exception_2:
        pass

# Generated at 2022-06-26 02:02:55.520747
# Unit test for function ok
def test_ok():
    print("Test case 0:")
    test_case_0()
    print("Test case 1:")
    with ok(Exception) as e:
        raise Exception
    print(e)



# Generated at 2022-06-26 02:02:57.875177
# Unit test for function ok
def test_ok():
    """
    Function ok
    """
    assert ok == None



# Generated at 2022-06-26 02:03:07.555350
# Unit test for function ok
def test_ok():
    # Test case 0
    # ok()
    with pytest.raises(Exception):
        test_case_0()
    # Test case 1
    # ok(Exception)
    with ok(Exception):
        raise Exception
    with pytest.raises(BaseException):
        with ok(Exception):
            raise BaseException
    # Test case 2
    # ok(Exception, Exception)
    with ok(Exception, Exception):
        raise Exception
    with pytest.raises(BaseException):
        with ok(Exception, Exception):
            raise BaseException
    # Test case 3
    # ok(Exception, Exception, Exception)
    with ok(Exception, Exception, Exception):
        raise Exception
    with pytest.raises(BaseException):
        with ok(Exception, Exception, Exception):
            raise BaseException
    # Test case 4
   

# Generated at 2022-06-26 02:03:18.617145
# Unit test for function ok
def test_ok():
    # Try to execute test case 0
    with test_case_0() as e:
        assert e == None, "Failing test case 0"
    # Try to execute test case 1
    with test_case_1() as e:
        assert e == Exception, "Failing test case 1"
    # Try to execute test case 2
    with test_case_2() as e:
        assert e == None, "Failing test case 2"
    # Try to execute test case 3
    with test_case_3() as e:
        assert e == None, "Failing test case 3"
    # Try to execute test case 4
    with test_case_4() as e:
        assert e == None, "Failing test case 4"
    # Try to execute test case 5
    with test_case_5() as e:
        assert e

# Generated at 2022-06-26 02:03:29.968505
# Unit test for function ok
def test_ok():
    """ Function: function ok"""
    with ok():
        pass

    with ok(ValueError):
        raise ValueError

    with ok(ValueError):
        raise TypeError

    with ok(TypeError, ValueError):
        raise ValueError

    with ok(IndexError, TypeError, ValueError):
        raise ValueError



if __name__ == "__main__":
    import os
    import sys
    import inspect
    import pytest

    current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parent_dir = os.path.dirname(current_dir)
    sys.path.insert(0, parent_dir)
    from contextlib import ok
    # from contextlib import raise_ok
    pytest.main([__file__])

# Generated at 2022-06-26 02:03:32.137344
# Unit test for function ok
def test_ok():
    test_case_0()


# Unit tests
if __name__ == "__main__":
    test_ok()

# Generated at 2022-06-26 02:03:36.931490
# Unit test for function ok
def test_ok():
    with ok(ValueError, TypeError):
        int('hello')
    with ok(ValueError, TypeError):
        [][0]
    with ok(ValueError, TypeError):
        5 + 'hello'

# Generated at 2022-06-26 02:03:39.354186
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int("a")
    with ok(ValueError):
        raise IndexError
    try:
        with ok(ValueError):
            raise IndexError
    except IndexError:
        pass

# Generated at 2022-06-26 02:03:48.771944
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        pass
    try:
        with ok(ValueError):
            raise NameError()
    except NameError:
        assert True
    else:
        assert False
    try:
        with ok(ValueError, TypeError):
            raise TypeError()
    except TypeError:
        assert True
    else:
        assert False
    try:
        with ok(ValueError, TypeError):
            raise KeyError()
    except KeyError:
        assert True
    else:
        assert False

# Generated at 2022-06-26 02:03:52.296444
# Unit test for function ok
def test_ok():
    with ok(TypeError, ZeroDivisionError):
        x = 10
        y = 0
        z = x / y
    with ok(ZeroDivisionError):
        x = 10
        y = 0
        z = x / y



# Generated at 2022-06-26 02:03:54.256418
# Unit test for function ok

# Generated at 2022-06-26 02:04:05.337507
# Unit test for function ok
def test_ok():
    """Test function ok"""
    # Test 1. If an exception is passed, the function does nothing
    with ok(Exception):
        raise Exception()

    # Test 2. If a nonexistent exception, the function does nothing
    with ok(NameError):
        raise ZeroDivisionError()

    # Test 3. If a valid exception, then a new exception
    with raises(ZeroDivisionError):
        with ok(Exception):
            raise ZeroDivisionError()



# Generated at 2022-06-26 02:04:12.013607
# Unit test for function ok
def test_ok():
    # Test defined exceptions are not raised
    with ok(ValueError, TypeError):
        int("a")
    with ok():
        int("a")
    with ok(Exception):
        int("a")

    # Test exception is propagated
    with raises(KeyError):
        with ok(ValueError, TypeError):
            int("a")

    with raises(KeyError):
        with ok():
            int("a")

    # Test exception is propagated
    with raises(KeyError):
        with ok(ValueError):
            int("a")

# Generated at 2022-06-26 02:04:15.057940
# Unit test for function ok
def test_ok():
    with ok(ValueError, TypeError):
        pass
    with ok(ValueError, TypeError):
        1 / 0
    with pytest.raises(TypeError):
        with ok(ValueError):
            1 / 0



# Generated at 2022-06-26 02:04:18.440202
# Unit test for function ok
def test_ok():
    with ok():
        raise Exception('error')
    with ok(Exception):
        raise Exception('error')
    try:
        with ok(ValueError):
            raise Exception('error')
    except Exception:
        pass
    else:
        raise Exception('Should not pass.')

    try:
        with ok(Exception):
            raise Exception('error')
        with ok(ValueError):
            raise ValueError('error')
    except Exception:
        raise Exception('Should not pass.')

# Generated at 2022-06-26 02:04:21.559001
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError, ValueError):
        int('a')
    with ok(ZeroDivisionError):
        int('a')
    with ok():
        int('a')


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-26 02:04:29.016441
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')


# Code that uses function ok
with ok(ValueError):
    int('N/A')


# Code that doesn't use function ok
try:
    int('N/A')
except ValueError:
    pass



# Generated at 2022-06-26 02:04:31.684584
# Unit test for function ok
def test_ok():
    a = 1
    with ok(ValueError):
        raise ValueError
    assert (a == 1)
    with pytest.raises(AttributeError):
        with ok(ValueError):
            raise AttributeError

# Generated at 2022-06-26 02:04:38.559849
# Unit test for function ok
def test_ok():
    """Unit test for function ok"""
    # Case 1: No exception raised
    with ok(ValueError, TypeError):
        print("No exception raised")
    # Case 2: Expected exception raised
    with pytest.raises(ValueError):
        with ok(ValueError):
            raise ValueError
    # Case 3: Unexpected exception raised
    with pytest.raises(TypeError):
        with ok(ValueError):
            raise TypeError


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-26 02:04:42.728673
# Unit test for function ok
def test_ok():
    """
    Testing the ok contextmanager
    :return:
    """
    with ok(ValueError):
        print("Something went wrong!")
        raise ValueError("Error")
    # This print should never be executed
    print("No exceptions raised")



# Generated at 2022-06-26 02:04:45.598417
# Unit test for function ok
def test_ok():
    with ok(TypeError, ValueError):
        pass
    with ok(TypeError, ValueError):
        raise TypeError()
    with ok(TypeError, ValueError):
        raise ValueError()
    with ok(TypeError, ValueError):
        raise ZeroDivisionError()



# Generated at 2022-06-26 02:04:48.114433
# Unit test for function ok
def test_ok():
    with ok(Exception):
        raise Exception('foo')

    with raises(ZeroDivisionError):
        with ok(Exception):
            raise ZeroDivisionError



# Generated at 2022-06-26 02:04:50.962418
# Unit test for function ok
def test_ok():
    """Test function ok"""
    try:
        with ok(IndexError):
            l = [1, 2, 3]
            l[5]
    except NameError:
        pass
    else:
        assert False

# Generated at 2022-06-26 02:04:55.767055
# Unit test for function ok

# Generated at 2022-06-26 02:04:59.064970
# Unit test for function ok
def test_ok():
    import random
    # Test for int type
    with ok(TypeError):
        int(['a', 'b', 'c'])
    # Test for ValueError
    with ok(ValueError):
        random.choice(['a'])



# Generated at 2022-06-26 02:05:01.558487
# Unit test for function ok
def test_ok():
    """Test for function ok"""
    with ok(ValueError):
        print('OK to continue')
    with ok(ValueError, TypeError):
        print('OK to continue')


test_ok()

# Generated at 2022-06-26 02:05:10.421481
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        1 / 0
    with ok(ZeroDivisionError, IndexError):
        [][1]
    with ok(ZeroDivisionError, IndexError):
        1 / 0

# Generated at 2022-06-26 02:05:12.997482
# Unit test for function ok
def test_ok():
    """test that function ok works correctly and raises correct exception"""
    with ok():
        pass
    with raises(BaseException):
        with ok(AssertionError):
            raise BaseException



# Generated at 2022-06-26 02:05:19.102075
# Unit test for function ok
def test_ok():
    # Test ok with no exception
    with ok():
        print('ok test')
    try:
        with ok(Exception):
            raise TypeError()
    except Exception as e:
        assert isinstance(e, TypeError)
    # Test ok with exception
    try:
        with ok(TypeError):
            raise ValueError()
    except Exception as e:
        assert isinstance(e, ValueError)


# Test code
if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-26 02:05:21.552465
# Unit test for function ok
def test_ok():
    """Unit tests for function ok."""

# Generated at 2022-06-26 02:05:24.465549
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False
    with ok(AssertionError):
        assert True

    with pytest.raises(KeyError):
        with ok(AssertionError):
            {}['a']



# Generated at 2022-06-26 02:05:29.662702
# Unit test for function ok
def test_ok():
    with pytest.raises(Exception):
        with ok():
            raise Exception()

    try:
        with ok(Exception):
            raise Exception()
    except Exception:
        pytest.fail('ok function did not ignore specific exceptions')

    try:
        with ok(ValueError):
            raise Exception()
    except ValueError:
        pytest.fail('ok function did not ignore specific exceptions')

# Generated at 2022-06-26 02:05:31.400701
# Unit test for function ok
def test_ok():
    """Test function ok."""
    with ok(AssertionError):
        assert False



# Generated at 2022-06-26 02:05:34.981642
# Unit test for function ok
def test_ok():
    def check(exc):
        with ok(TypeError):
            raise exc
        print('no error')

    check(TypeError('X'))
    try:
        check(ValueError())
    except ValueError:
        print('value error')


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-26 02:05:36.985536
# Unit test for function ok
def test_ok():
    assert ok()



# Generated at 2022-06-26 02:05:42.132611
# Unit test for function ok

# Generated at 2022-06-26 02:06:06.650582
# Unit test for function ok
def test_ok():
    """Test ok function."""
    import sys
    import pexpect

    with ok(ValueError, TypeError, pexpect.EOF):
        assert ok.__qualname__ == 'ok'

    with ok(ValueError, TypeError):
        assert ok.__qualname__ == 'ok'

    with ok(ValueError, Exception):
        raise Exception('one exception')

    with ok(ValueError, Exception):
        raise Exception('another exception')

    with ok(ValueError, Exception):
        raise Exception('yet another exception')

    with ok(ValueError, Exception):
        raise Exception('and another exception')

    with ok(ValueError, Exception):
        raise Exception('something else')

    with ok(ValueError, Exception):
        raise Exception('another thing')


# Generated at 2022-06-26 02:06:11.205584
# Unit test for function ok
def test_ok():
    with ok(ValueError, TypeError):
        int("abc")
    with ok():
        int("abc")



# Generated at 2022-06-26 02:06:13.853375
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with ok():
        assert True
    with ok(ValueError):
        raise ValueError
    with ok(ValueError):
        raise TypeError
    with ok(TypeError):
        raise ValueError

# Generated at 2022-06-26 02:06:23.941656
# Unit test for function ok
def test_ok():
    # OnlyException
    with ok(ValueError):
        raise ValueError()
    # MultipleExceptions
    with ok(ValueError, TypeError):
        raise ValueError()
    with ok(ValueError, TypeError):
        raise TypeError()
    # NonRaisedException
    with ok(ValueError):
        pass
    # NotAllowedException
    with pytest.raises(ValueError):
        with ok(TypeError):
            raise ValueError()
    # NoException
    with pytest.raises(Exception):
        with ok():
            raise ValueError()

# Generated at 2022-06-26 02:06:29.647533
# Unit test for function ok
def test_ok():
    """Unit test for function ok."""
    with ok():
        pass

    with ok(BaseException):
        raise BaseException('No exception raised')

    with ok(BaseException):
        raise ValueError('Exception raised')


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-26 02:06:39.068115
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        x = 1 / 0
    try:
        with ok(IndexError):
            x = 1 / 0
    except ZeroDivisionError:
        pass
    else:
        assert False, "ZeroDivisionError not raised"
    try:
        with ok(TypeError):
            x = 1 / 0
    except ZeroDivisionError:
        pass
    else:
        assert False, "ZeroDivisionError not raised"
    try:
        with ok(IndexError):
            x = 1 / 0
    except ZeroDivisionError as e:
        assert e.__str__() == "division by zero", "Unexpected error"
    else:
        assert False, "ZeroDivisionError not raised"



# Generated at 2022-06-26 02:06:44.653867
# Unit test for function ok
def test_ok():
    """
    Test case for context manager ok
    """
    with ok(TypeError, ValueError):
        raise ValueError
    with ok(TypeError, ValueError):
        raise TypeError
    with ok(TypeError, ValueError):
        raise ZeroDivisionError

# Generated at 2022-06-26 02:06:48.025065
# Unit test for function ok
def test_ok():
    """
    """
    with ok(TypeError, ValueError):
        raise ValueError()


if __name__ == '__main__':
    """
    """
    test_ok()

# Generated at 2022-06-26 02:06:51.805058
# Unit test for function ok
def test_ok():
    """Test function ok"""
    with ok(Exception):
        raise Exception



# Generated at 2022-06-26 02:06:58.134517
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        print("Type error is ok")
        x = (1, 2) + 3
    with ok((ValueError, TypeError)):
        print("Value and type errors are ok")
        x = int([1, 2] + "3")
    with ok(TypeError):
        print("Type error is ok")
        x = (1, 2) + 3
    with ok(ValueError):
        print("Value error is ok")
        import os
        with open("/foo") as f:
            pass



# Generated at 2022-06-26 02:07:41.385351
# Unit test for function ok
def test_ok():
    # If a = 1, then raise an exception
    a = 1
    try:
        with ok(AssertionError):
            assert a == 0, "a is not 0"
    except AssertionError:
        print('AssertionError')
    else:
        print('ok')



# Generated at 2022-06-26 02:07:43.620677
# Unit test for function ok
def test_ok():
    """Test for ok() context manager."""
    with assert_raises(ValueError):
        with ok(Exception):
            raise ValueError('Not that kind of exception')
    with ok(ValueError):
        raise ValueError('Test value error')


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-26 02:07:46.748087
# Unit test for function ok
def test_ok():
    """Test ok function."""
    with ok(TypeError, ValueError):
        for a, b in ['12', '34', '5']:
            print(a // b)

    print('Done.')



# Generated at 2022-06-26 02:07:55.045636
# Unit test for function ok
def test_ok():
    """Test context manager ok"""
    class Exception1(Exception):
        pass

    class Exception2(Exception):
        pass

    def test_ok(e):
        try:
            with ok(Exception1):
                raise e
        except Exception2:
            return True
        except Exception1:
            return False

    assert test_ok(Exception1()) is False
    assert test_ok(Exception2()) is True

# Generated at 2022-06-26 02:07:57.581291
# Unit test for function ok
def test_ok():
    with pytest.raises(ValueError):
        with ok(TypeError):
            raise ValueError

    with ok():
        raise TypeError

    with ok():
        raise ValueError



# Generated at 2022-06-26 02:08:00.938643
# Unit test for function ok
def test_ok():
    a = 1
    b = 0
    with ok(ZeroDivisionError):
        a / b



# Generated at 2022-06-26 02:08:05.122261
# Unit test for function ok
def test_ok():
    assert ok(ZeroDivisionError, KeyError)
    assert ok(ZeroDivisionError)



# Generated at 2022-06-26 02:08:08.775896
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        x = 1 / 0
    with ok(ZeroDivisionError, ValueError):
        x = 1 / 0
    with ok():
        x = 1 / 1



# Generated at 2022-06-26 02:08:13.457549
# Unit test for function ok
def test_ok():
    with ok():
        raise Exception
    with ok():
        raise ValueError
    with ok(ValueError):
        raise Exception
    with ok(Exception):
        raise ValueError



# Generated at 2022-06-26 02:08:15.508773
# Unit test for function ok
def test_ok():
    """Test context manager ok."""
    with ok(ValueError):
        raise ValueError()
    with ok(Exception):
        raise ValueError()
    with ok(Exception):
        raise IndexError()



# Generated at 2022-06-26 02:09:40.517715
# Unit test for function ok
def test_ok():
    with ok(ValueError, TypeError):
        int('not int')

    with ok(TypeError):
        int('not int')

    with ok(TypeError):
        int('not int')
        raise ValueError
    with pytest.raises(ValueError):
        with ok(ValueError, TypeError):
            raise ValueError
    with pytest.raises(TypeError):
        with ok(ValueError, TypeError):
            int('not int')



# Generated at 2022-06-26 02:09:45.724874
# Unit test for function ok
def test_ok():
    with ok(ZeroDivisionError):
        x = 1 / 0
    with ok():
        x = 1 / 0
    with raises(ZeroDivisionError):
        with ok(NameError):
            x = 1 / 0

# Generated at 2022-06-26 02:09:50.609748
# Unit test for function ok
def test_ok():
    with pytest.raises(IOError):
        with ok(ValueError):
            raise IOError()
    with ok(IOError):
        raise ValueError()
    with ok(IOError, TypeError):
        raise ValueError()



# Generated at 2022-06-26 02:09:55.485680
# Unit test for function ok
def test_ok():
    ok_func = ok(TypeError, ValueError)
    with ok_func:
        '2' + 2
    with ok_func:
        int('a')
    with ok_func:
        raise IndexError



# Generated at 2022-06-26 02:10:01.190338
# Unit test for function ok
def test_ok():
    """Unit test for ok.
    """
    try:
        if True:
            raise IndexError
        yield 0
    except IndexError:
        yield 1
    except BaseException:
        yield 2
    except:
        yield 3



# Generated at 2022-06-26 02:10:06.269462
# Unit test for function ok
def test_ok():
    """Unit test for ok
    """
    try:
        with ok(IndexError):
            list(range(10))[15]
    except IndexError:
        print("IndexError")


if __name__ == '__main__':
    test_ok()

# Generated at 2022-06-26 02:10:10.395415
# Unit test for function ok
def test_ok():
    with ok(TypeError):
        int('1')
    with ok(ZeroDivisionError, TypeError):
        int('1')
        1 / 0



# Generated at 2022-06-26 02:10:11.995253
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        int('N/A')
    with ok(TypeError):
        int(None)



# Generated at 2022-06-26 02:10:19.132959
# Unit test for function ok
def test_ok():
    with ok(ValueError):
        raise ValueError()
    with ok(Exception):
        raise ValueError()

    with pytest.raises(ValueError):
        with ok(TypeError):
            raise ValueError()

    with pytest.raises(TypeError):
        with ok():
            raise ValueError()

# Generated at 2022-06-26 02:10:21.751277
# Unit test for function ok
def test_ok():
    with ok(AssertionError):
        assert False

