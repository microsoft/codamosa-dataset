

# Generated at 2022-06-25 02:12:14.563736
# Unit test for function main
def test_main():
    var_1 =  {'name': 'tzdata'}
    var_2 =  {'check_mode': False, 'name': 'tzdata'}
    try:
        var_3 =  {'diff_mode': False, 'check_mode': False, 'name': 'tzdata'}
    except LookupError:
        var_3 =  var_2
    try:
        var_4 =  {'no_log': False, 'diff_mode': False, 'check_mode': False, 'name': 'tzdata'}
    except LookupError:
        var_4 =  var_3

# Generated at 2022-06-25 02:12:16.000019
# Unit test for function main
def test_main():
    # Get a function reference and then call it
    func_ref = main
    func_ref()

# template of testcase

# Generated at 2022-06-25 02:12:18.376730
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule({
        "name": "",
        "question": "",
        "vtype": "",
        "value": "",
        "unseen": True
    })

    assert module.set_selection("", "", "", "", "", True) == None


# Generated at 2022-06-25 02:12:23.709843
# Unit test for function get_selections
def test_get_selections():
    tmp_cmd = "debconf-show"
    tmp_pkg = "foobar"
    var_0 = get_selections(module, tmp_pkg)
    assert(tmp_pkg == "foobar")
    assert(tmp_cmd == "debconf-show")


# Generated at 2022-06-25 02:12:24.461020
# Unit test for function get_selections
def test_get_selections():
    assert True


# Generated at 2022-06-25 02:12:32.067901
# Unit test for function set_selection
def test_set_selection():
    class Mock_module(object):
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/debconf-set-selections'

        def run_command(self, arg0, **kwargs):
            procs.append(arg0)
            return 0, "success", ""

    procs = []
    module = Mock_module()
    rc, out, err = set_selection(module, 'a', 'b', 'c', 'd', True)
    assert rc == 0
    assert '/usr/bin/debconf-set-selections -u' in procs
    assert 'a b c d' in procs

    # The second argument to run_command is a data argument, which if set
    # prints data to the process instead of the string in the second argument.
    #
    #

# Generated at 2022-06-25 02:12:33.138856
# Unit test for function main
def test_main():
    assert test_case_0() == None


# Generated at 2022-06-25 02:12:33.915021
# Unit test for function main
def test_main():
    assert main



# Generated at 2022-06-25 02:12:35.611509
# Unit test for function get_selections
def test_get_selections():
    rc, out, err = main.get_selections()
    assert rc == 0
    assert "No such file or directory" in err
    assert out == ''


# Generated at 2022-06-25 02:12:41.114740
# Unit test for function set_selection
def test_set_selection():
    test_data = (('Hello', 'Hello', 'Hello'), ('Hello', 'Hello', 'Hello'), ('Hello', 'Hello', 'Hello'), ('Hello', 'Hello', 'Hello'), ('Hello', 'Hello', 'Hello'), ('Hello', 'Hello', 'Hello'), ('Hello', 'Hello', 'Hello'))
    set_selection_tuples_0 = []
    for i in range(len(test_data)):
        test_data_0 = test_data[i][0]
        test_data_1 = test_data[i][1]
        test_data_2 = test_data[i][2]
        set_selection_tuples_0.append((test_data_0, test_data_1, test_data_2))


# Generated at 2022-06-25 02:12:51.707025
# Unit test for function get_selections
def test_get_selections():
    assert get_selections is not None


# Generated at 2022-06-25 02:12:52.622557
# Unit test for function main
def test_main():
    var_0_0 = main()


# Generated at 2022-06-25 02:12:53.198058
# Unit test for function set_selection
def test_set_selection():
    pass

# Generated at 2022-06-25 02:13:03.772452
# Unit test for function main
def test_main():
    import sys
    import json
    import ansible.module_utils.debconf 
    import ansible.module_utils.six 
    import ansible.module_utils.action._ANSUtil 
    import ansible.module_utils.basic 
    import ansible.module_utils.pycompat24 
    import ansible.module_utils.urls 
    import ansible.module_utils.connection 
    import ansible.module_utils.six.moves.urllib.parse 
    import ansible.module_utils.six.moves.urllib.error 
    import ansible.module_utils.six.moves.urllib.request 
    import ansible.module_utils.six.moves.urllib.response 

    # AnsibleModule class import is dynamically done by the action,

# Generated at 2022-06-25 02:13:04.891281
# Unit test for function get_selections
def test_get_selections():
    try:
        assert True
        assert True
        assert True
        assert var_0 == 42
    except AssertionError:
        raise AssertionError()

# Generated at 2022-06-25 02:13:06.087052
# Unit test for function set_selection
def test_set_selection():
    assert False


# Generated at 2022-06-25 02:13:14.939940
# Unit test for function set_selection
def test_set_selection():
    mock_module = Mock(return_value=None)
    mock_module.get_bin_path.return_value = "debconf-set-selections"
    mock_module.run_command.return_value = (0, "a", "b")

    with patch.object(AnsibleModule, '__new__') as mock_class:
        mock_module = mock_class.return_value
        mock_module.get_bin_path.return_value = "debconf-set-selections"
        mock_module.run_command.return_value = (0, "a", "b")
        mock_module.check_mode = False

        set_selection(mock_module, "a", "b", "c", "d", True)


# Generated at 2022-06-25 02:13:20.551202
# Unit test for function main
def test_main():
    # Input parameters tests
    module = AnsibleModule(argument_spec=dict(name=dict(type='str', required=True, aliases=['pkg']), question=dict(type='str', aliases=['selection', 'setting']), vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']), value=dict(type='str', aliases=['answer']), unseen=dict(type='bool', default=False)), required_together=(['question', 'vtype', 'value'],), supports_check_mode=True)
    main()

# Generated at 2022-06-25 02:13:21.019054
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:13:31.759241
# Unit test for function set_selection
def test_set_selection():
    var_1 = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

# Generated at 2022-06-25 02:13:57.478089
# Unit test for function set_selection
def test_set_selection():
    try:
        assert set_selection() == [0, "", ""]
    except:
        assert False


# Generated at 2022-06-25 02:13:58.268826
# Unit test for function main
def test_main():
    assert (main() == None)


# Generated at 2022-06-25 02:14:05.262732
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    setsel = module.get_bin_path('debconf-set-selections', True)
    cmd = [setsel]

# Generated at 2022-06-25 02:14:14.517709
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = module.params["name"]
    question = module.params["question"]
    vtype = module.params["vtype"]


# Generated at 2022-06-25 02:14:17.918388
# Unit test for function set_selection
def test_set_selection():

    class MockModule(object):
        def fail_json(self, *args, **kwargs): pass
        def run_command(self, *args, **kwargs): return 0, '', ''
        def get_bin_path(self, *args, **kwargs): return 'test'

    mock_module = MockModule()
    set_selection(mock_module, 'package', 'question', 'string', 'answer', False)

# Generated at 2022-06-25 02:14:27.422274
# Unit test for function get_selections
def test_get_selections():
    # TODO: add unit test for get_selections
    var_1 = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from

# Generated at 2022-06-25 02:14:28.241631
# Unit test for function get_selections
def test_get_selections():
    assert main() == True


# Generated at 2022-06-25 02:14:28.981657
# Unit test for function set_selection
def test_set_selection():
    # test complete
    assert True

# Generated at 2022-06-25 02:14:35.186413
# Unit test for function set_selection
def test_set_selection():
    setsel = 'debconf-set-selections'
    pkg = 'local'
    question = 'local'
    vtype = 'local'
    value = 'local'
    unseen = False
    cmd = 'debconf-set-selections'    
    data = 'local local local local'
    assert cmd == setsel
    assert pkg == 'local'
    assert question == 'local'
    assert vtype == 'local'
    assert value == 'loal'
    assert unseen == False
    assert data == 'local local local local'

# Generated at 2022-06-25 02:14:40.562397
# Unit test for function set_selection
def test_set_selection():
    setsel = module.get_bin_path('debconf-set-selections', True)
    cmd = [setsel]
    if unseen:
        cmd.append('-u')

    if vtype == 'boolean':
        if value == 'True':
            value = 'true'
        elif value == 'False':
            value = 'false'
    data = ' '.join([pkg, question, vtype, value])

    return module.run_command(cmd, data=data)


# Generated at 2022-06-25 02:15:19.462875
# Unit test for function set_selection
def test_set_selection():
    pkg = ""
    question = ""
    vtype = ""
    value = ""
    unseen = ""
    try:
        set_selection(pkg, question, vtype, value, unseen)
    except Exception as error:
        print (error)

# Generated at 2022-06-25 02:15:23.856072
# Unit test for function set_selection
def test_set_selection():
    import ansible.module_utils.debconf as debconf
    var_1 = ansible.module_utils.debconf.get_selections()
    setsel = set_selection(module, pkg, question, vtype, value, unseen)
    assert setsel == var_1


# Generated at 2022-06-25 02:15:25.959000
# Unit test for function get_selections
def test_get_selections():
    var__0 = var_0["pkg"]
    var__1 = var_0["module"]
    var = get_selections(var__1, var__0)


# Generated at 2022-06-25 02:15:34.120446
# Unit test for function set_selection
def test_set_selection():
    from Debconf import Debconf
    from Debconf import DebconfError

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )


# Generated at 2022-06-25 02:15:35.190404
# Unit test for function get_selections
def test_get_selections():
    assert callable(get_selections)


# Generated at 2022-06-25 02:15:40.387958
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-25 02:15:41.176090
# Unit test for function get_selections
def test_get_selections():
    assert False, "not implemented"

# Generated at 2022-06-25 02:15:51.236299
# Unit test for function get_selections
def test_get_selections():
    var_0 = {'name': 'ansible', 'question': 'ansible/question', 'vtype': 'ansible/vtype', 'value': 'ansible/value', 'unseen': 'ansible/unseen'}

# Generated at 2022-06-25 02:15:58.102818
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    tmp_dir = tempfile.mkdtemp()

    # create test file

# Generated at 2022-06-25 02:16:04.920797
# Unit test for function get_selections
def test_get_selections():
    # Add your own test here
    with open('tests/test_get_selections.txt') as data_file:
        data = json.loads(data_file.read())
    # Create an instance of the class
    x = AnsibleModule()
    # set the module args
    x.params = load_fixture('test_get_selections.json')
    # set the active user
    x.params['REMOTE_USER'] = os.environ['USER']
    # run the test function
    results = main()
    assert results['ansible_facts']['debconf']['tzdata']['tzdata/Zones/Pacific'] == 'Etc/UTC'




# Generated at 2022-06-25 02:17:46.826235
# Unit test for function get_selections
def test_get_selections():
    assert get_selections == main().get_selections

# Generated at 2022-06-25 02:17:58.012264
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    # README: change generated code for function
    # README: please edit the function body, not just this comment.

# Generated at 2022-06-25 02:18:00.782085
# Unit test for function get_selections
def test_get_selections():
    var_0 = main()
    assert var_0 == [{'debconf_selections': {'tzdata': {'tzdata/Areas': 'Europe',
                                                        'tzdata/Zones/Europe': 'Berlin'}}}]


# Generated at 2022-06-25 02:18:06.210500
# Unit test for function set_selection
def test_set_selection():
    rc = 0
    msg = 'The value of msg'
    e = 'The value of e'
    # Set up mock
    set_mock = mock.MagicMock(return_value=(rc, msg, e))
    module.run_command = set_mock

    # Call the function
    set_selection(pkg, question, vtype, value, unseen)

    # Check if the mock was called
    assert set_mock.called


# Generated at 2022-06-25 02:18:10.751961
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.builtin.plugins.module_utils import debconf
    module = AnsibleModule()
    assert(debconf.set_selection(module, 'test_pkg', 'test_question', 'test_vtype', 'test_value', 'test_unseen')) == None


# Generated at 2022-06-25 02:18:11.561603
# Unit test for function get_selections
def test_get_selections():
    assert isinstance(get_selections('module_1'), dict)


# Generated at 2022-06-25 02:18:14.678506
# Unit test for function get_selections
def test_get_selections():
    # Create the mock object for for main() function
    pkg = main()
    # Check the result of get_selections() function
    retVal = get_selections(pkg)
    # Assert if the result is TRUE or FALSE
    assert retVal == True


# Generated at 2022-06-25 02:18:20.687817
# Unit test for function get_selections
def test_get_selections():
    import subprocess
    import json

    pkg = 'tzdata'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf

# Generated at 2022-06-25 02:18:23.503268
# Unit test for function get_selections
def test_get_selections():
    assert main() == get_selections()

# Generated at 2022-06-25 02:18:24.579499
# Unit test for function main
def test_main():
    # no return, so should be empty
    assert main() == None

