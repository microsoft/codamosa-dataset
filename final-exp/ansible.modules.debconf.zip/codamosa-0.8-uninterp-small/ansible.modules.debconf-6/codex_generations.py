

# Generated at 2022-06-25 02:12:18.045912
# Unit test for function get_selections
def test_get_selections():
    class AnsibleModule:
        def get_bin_path(self):
            return 'string'

        def run_command(self):
            return (0, 'string', 'string')

    class AnsibleModule_fail_json:
        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception

    m = AnsibleModule()
    assert get_selections(m, 'string') == {'foo': 'bar'}
    m = AnsibleModule_fail_json()
    try:
        get_selections(m, 'string')
    except:
        assert m.exit_args[0]['failed'] == True


# Generated at 2022-06-25 02:12:28.242752
# Unit test for function set_selection
def test_set_selection():
  # defaultcase
  module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
  pkg='string'
  question='string'
  vtype='string'
  value='string'
  unseen

# Generated at 2022-06-25 02:12:35.309221
# Unit test for function set_selection
def test_set_selection():

    test_params = (
        {
            'vtype': 'string',
            'value': 'True',
            'unseen': False,
        },
        {
            'vtype': 'string',
            'value': 'False',
            'unseen': False,
        },
        {
            'vtype': 'string',
            'value': 'unseen',
            'unseen': True,
        },
        {
            'vtype': 'string',
            'value': 'seen',
            'unseen': False,
        },
    )
    for test_param in test_params:
        vtype = test_param['vtype']
        value = test_param['value']
        unseen = test_param['unseen']
        print ("Testing with parameters")

# Generated at 2022-06-25 02:12:36.613692
# Unit test for function set_selection
def test_set_selection():
    # NOTE: Ignore this test in Python 2.6
    if sys.version_info[:2] != (2, 6):
        assert True == True

# Generated at 2022-06-25 02:12:39.150064
# Unit test for function main
def test_main():
    file_path = os.path.realpath(__file__)
    file_dir = os.path.dirname(file_path)
    start_module(file_dir, 'action', 'debconf')
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 02:12:44.466220
# Unit test for function main
def test_main():
    mock_params = {'changed': True, 'unseen': True, '_ansible_check_mode': False, '_ansible_module_name': 'ansible.builtin.debconf', 'question': 'test_question', '_ansible_version': '2.7.11', 'name': 'test_name', 'vtype': 'test_vtype', '_ansible_no_log': False, 'msg': 'test_msg', 'value': 'test_value'}
    mock_ansible_module = Mock(AnsibleModule(params=mock_params))
    mock_get_selections = MagicMock()
    mock_get_selections.return_value = {}
    mock_set_selection = MagicMock()
    mock_set_selection.return_value = 0

# Generated at 2022-06-25 02:12:45.531831
# Unit test for function get_selections
def test_get_selections():
    assert False


# Generated at 2022-06-25 02:12:55.519908
# Unit test for function set_selection

# Generated at 2022-06-25 02:13:04.744885
# Unit test for function get_selections
def test_get_selections():
    pkg = {'format': 'default', 'name': 'zabbix-agent', 'platfroms': 'all'}
    question = {'name': 'echo', 'value': None}
    vtype = {'name': 'when', 'value': None}
    value = {'name': 'where', 'value': None}
    unseen = {'name': 'install', 'value': None}

    out = get_selections(pkg, question, vtype, value, unseen)
    expected = None
    print("Actual " + str(out) + " output")
    print("Expected " + str(expected) + " output")
    assert out == expected


# Generated at 2022-06-25 02:13:05.268950
# Unit test for function set_selection
def test_set_selection():
    test_case_1()


# Generated at 2022-06-25 02:13:23.098603
# Unit test for function main
def test_main():
    var_1 = 'master'
    var_1 = ('unreachable=True', 'no_log=True')
    var_1 = ('unreachable=True', 'no_log=True')
    var_1 = 'raw'
    var_1 = dict(msg="could not connect to host",unreachable=True)
    var_1 = 'raw'

    var_1 = 'ssh_pass'
    var_1 = 'ssh_pass'
    var_1 = 'ssh_pass'
    var_1 = dict()
    var_1 = dict(msg="could not connect to host",unreachable=True)
    var_1 = dict(msg="could not connect to host",unreachable=True,failed=True)

# Generated at 2022-06-25 02:13:31.046652
# Unit test for function get_selections
def test_get_selections():
    pkg = '$param_0'
    module = '$param_1'
    cmd = [module.get_bin_path('debconf-show', True), pkg]
    rc, out, err = module.run_command(' '.join(cmd))

    if rc != 0:
        module.fail_json(msg=err)

    selections = {}

    for line in out.splitlines():
        (key, value) = line.split(':', 1)
        selections[key.strip('*').strip()] = value.strip()

    return selections


# Generated at 2022-06-25 02:13:38.780618
# Unit test for function get_selections
def test_get_selections():
    state = {}
    assert True
    # Module(argument_spec=dict(name=dict(type='str', required=True, aliases=['pkg']), question=dict(type='str', aliases=['selection', 'setting']), vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']), value=dict(type='str', aliases=['answer']), unseen=dict(type='bool', default=False)), required_together=(['question', 'vtype', 'value'],), supports_check_mode=True, run_command=AnsibleModule.run_command, get_bin_path=AnsibleModule.get_bin_path, check_mode=True, diff=True)

# Generated at 2022-06-25 02:13:46.892101
# Unit test for function set_selection
def test_set_selection():
    # Get the path to the module, set the argument spec and
    # call the module.
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(type='str', required=True, aliases=['pkg']),
            question = dict(type='str', aliases=['selection', 'setting']),
            vtype = dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value = dict(type='str', aliases=['answer']),
            unseen = dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # Set the module input parameters

# Generated at 2022-06-25 02:13:47.884732
# Unit test for function set_selection
def test_set_selection():
    assert main() == None


# Generated at 2022-06-25 02:13:48.639008
# Unit test for function set_selection
def test_set_selection():
    assert set_selection is not None


# Generated at 2022-06-25 02:13:50.685591
# Unit test for function main
def test_main():
    exit_msg = "[Errno 2] No such file or directory: 'foo': 'foo'"
    var_0 = main()
    assert var_0 == exit_msg

# Generated at 2022-06-25 02:13:53.629357
# Unit test for function get_selections
def test_get_selections():

    debconf_utils = ansible_module_debconf.debconf_utils

    assert debconf_utils.get_selections(module, pkg)


# Generated at 2022-06-25 02:14:01.654871
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-25 02:14:02.678333
# Unit test for function set_selection
def test_set_selection():
    # Testing function
    set_selection()


# Generated at 2022-06-25 02:14:33.481106
# Unit test for function main
def test_main():
    with patch('ansible.module_utils.basic.AnsibleModule', autospec=True) as _mock_AnsibleModule:
        with patch('ansible.module_utils.basic.AnsibleModule.get_bin_path', autospec=True) as _mock_get_bin_path:
            with patch('ansible.module_utils.basic.AnsibleModule.run_command', autospec=True) as _mock_run_command:
                with patch('ansible.module_utils.basic.AnsibleModule.fail_json', autospec=True) as _mock_fail_json:
                    with patch('ansible.module_utils.six.moves.builtins.open', create=True) as _mock_open:
                        module = _mock_AnsibleModule.return_value
                       

# Generated at 2022-06-25 02:14:41.637819
# Unit test for function main
def test_main():
    ansible_mock = MagicMock(return_value={"msg":"msg"})
    debconf_utils_mock = MagicMock(return_value={"msg":"msg"})
    module_utils_mock = MagicMock(return_value={"msg":"msg"})
    ansible_mock.module_utils = module_utils_mock
    module_utils_mock.debconf = debconf_utils_mock
    debconf_utils_mock.get_selections = MagicMock(return_value="previous")
    debconf_mock = MagicMock(return_value={"msg":"msg"})
    run_command_mock = MagicMock(return_value={"msg":"msg"})
    debconf_mock.run_command = run_command_mock
    debconf_

# Generated at 2022-06-25 02:14:42.081648
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:14:43.034937
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 02:14:48.852038
# Unit test for function set_selection
def test_set_selection():
  # Uses python2
  # From https://github.com/ansible/ansible/blob/devel/test/units/modules/utils/test_debconf.py
    mock_module = Mock(spec=AnsibleModule)
    mock_module.check_mode = False
    mock_run_command = mock_module.run_command
    mock_get_bin_path = mock_module.get_bin_path = Mock(return_value='/usr/bin/debconf-set-selections')

    mock_module.run_command = Mock(return_value=(0, "", ""))

    result = set_selection(mock_module, 'pkg', 'question', 'vtype', 'value', False)

    assert mock_run_command.call_count == 1

# Generated at 2022-06-25 02:14:59.954762
# Unit test for function get_selections

# Generated at 2022-06-25 02:15:00.839115
# Unit test for function get_selections
def test_get_selections():
    assert True



# Generated at 2022-06-25 02:15:09.432474
# Unit test for function get_selections
def test_get_selections():
    var_0 = AnsibleModule(argument_spec={
    'name': {'required': True, 'aliases': ['pkg'], 'type': 'str'},
    'question': {'aliases': ['selection', 'setting'], 'type': 'str'},
    'vtype': {'choices': ['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title'], 'type': 'str'},
    'value': {'aliases': ['answer'], 'type': 'str'},
    'unseen': {'type': 'bool', 'default': False}}, supports_check_mode=True)

# Generated at 2022-06-25 02:15:13.014523
# Unit test for function set_selection
def test_set_selection():
    cmd = [module.get_bin_path('debconf-set-selections', True)]
    if unseen:
        cmd.append('-u')

    if vtype == 'boolean':
        if value == 'True':
            value = 'true'
        elif value == 'False':
            value = 'false'
    data = ' '.join([pkg, question, vtype, value])

    return module.run_command(cmd, data=data)


# Generated at 2022-06-25 02:15:13.588721
# Unit test for function get_selections
def test_get_selections():
    assert True


# Generated at 2022-06-25 02:16:01.536711
# Unit test for function main

# Generated at 2022-06-25 02:16:02.393054
# Unit test for function set_selection
def test_set_selection():
    assert True == True


# Generated at 2022-06-25 02:16:08.423698
# Unit test for function get_selections

# Generated at 2022-06-25 02:16:15.621570
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-25 02:16:21.522689
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    # Set params
    pkg = 'main'
    question = 'question'
    vtype = 'vtype'

# Generated at 2022-06-25 02:16:27.410202
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

# Generated at 2022-06-25 02:16:32.904960
# Unit test for function set_selection
def test_set_selection():
    var_2 = AnsibleModule(argument_spec={'selection': {'type': 'str', 'aliases': ['setting']}, 'question': {'type': 'str', 'aliases': ['pkg']}, 'vtype': {'type': 'str', 'choices': ['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']}, 'value': {'type': 'str', 'aliases': ['answer']}, 'unseen': {'type': 'bool', 'default': False}, 'name': {'type': 'str', 'required': True, 'aliases': ['pkg']}}, required_together=[['question', 'vtype', 'value']], supports_check_mode=True)
    var_3 = ' '
    var_4 = var_2.get_

# Generated at 2022-06-25 02:16:40.084365
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-25 02:16:45.459440
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    test_module = module
    get_selections(test_module, var_0)


# Generated at 2022-06-25 02:16:48.496489
# Unit test for function set_selection
def test_set_selection():
    class module():
        def get_bin_path(*args, **kwargs):
            return "/usr/bin/debconf-set-selections"

        def run_command(*args, **kwargs):
            return (0, "", "")

    assert set_selection(module(), "localepurge", "localepurge/nopurge", "multiselect", "en_US.UTF-8 fr_FR.UTF-8", True) == (0, "", "")

# Generated at 2022-06-25 02:18:26.557846
# Unit test for function get_selections
def test_get_selections():
    var_1 = os.environ.get('ANSIBLE_MODULE_ARGS')
    var_1 = json.loads(var_1)
    var_2 = var_1.get('name')
    assert type(var_2) == str
    assert var_2 == 'tzdata'
    var_3 = var_1.get('question')
    assert var_3 == None
    var_4 = var_1.get('vtype')
    assert var_4 == None
    var_5 = var_1.get('value')
    assert var_5 == None
    var_6 = var_1.get('unseen')
    assert type(var_6) == bool
    assert var_6 == False

# Generated at 2022-06-25 02:18:28.272959
# Unit test for function get_selections
def test_get_selections():
    var_1 = main()



# Generated at 2022-06-25 02:18:28.947686
# Unit test for function main
def test_main():

    with pytest.raises(AnsibleModuleFail):
        main()

# Generated at 2022-06-25 02:18:37.726838
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    # Test this function
    # Get selections
    get_selections(module, 'pkg')


# Generated at 2022-06-25 02:18:44.246679
# Unit test for function get_selections
def test_get_selections():
    global f_handle
    global fc_trace
    global fc_error
    global fc_return
    global fc_write
    global fc_read
    global fc_close
    global int_0
    global int_1
    global int_2
    global int_3
    global int_4
    global int_5
    global int_6
    global int_7
    global int_8
    global int_9
    global int_10
    global int_11
    global int_12
    global int_13
    global int_14
    global int_15
    global int_16
    global int_17
    global int_18
    global int_19
    global int_20
    global int_21
    global int_22
    global int_23
    global int_24
   

# Generated at 2022-06-25 02:18:48.030154
# Unit test for function main
def test_main():
    # Test case 0
    # Test case 1:
    var_1 = main()

# Test cases for function test_main()

# Generated at 2022-06-25 02:18:51.430775
# Unit test for function set_selection
def test_set_selection():
    main()


# Generated at 2022-06-25 02:18:58.832166
# Unit test for function set_selection
def test_set_selection():
    import mock

    mock_module = mock.MagicMock()

    main_values = {
                'name': 'name',
                'question': 'question',
                'vtype': 'vtype',
                'value': 'value',
                'unseen': 'unseen'
                }

    set_selection_values = {
                'module.get_bin_path': 'module.get_bin_path',
                'module.run_command': 'module.run_command'
                }

    module_values = {
                'params': main_values,
                'get_bin_path': set_selection_values['module.get_bin_path'],
                'run_command': set_selection_values['module.run_command']
                }

    mock_module.configure_mock(**module_values)

    result

# Generated at 2022-06-25 02:18:59.195558
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:18:59.712083
# Unit test for function set_selection
def test_set_selection():
    pass
