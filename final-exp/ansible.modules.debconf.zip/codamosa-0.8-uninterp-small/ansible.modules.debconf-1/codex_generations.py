

# Generated at 2022-06-25 02:12:07.406733
# Unit test for function set_selection
def test_set_selection():
    main()


# Generated at 2022-06-25 02:12:09.364343
# Unit test for function main
def test_main():
    set_selection(module, pkg, question, vtype, value, unseen)
    get_selections(module, pkg)
    var_0 = main()
    assert var_0 == 'var_0'

# Generated at 2022-06-25 02:12:13.346324
# Unit test for function main
def test_main():

    #
    # Argument spec
    #
    module_args = {
        'arg_0': {"required": False, "type": "int", "default": None, "description": ""},
        'arg_1': {"required": False, "type": "str", "default": None, "description": ""},
    }

    result = main(module_args)
    assert_equals(result['ansible_facts']['some_fact'], 'some_value')

# Generated at 2022-06-25 02:12:13.831539
# Unit test for function set_selection
def test_set_selection():
    assert True


# Generated at 2022-06-25 02:12:16.469057
# Unit test for function set_selection
def test_set_selection():
	# Test params
	pkg = "keystone"
	question = "keystone/password"
	vtype = "password"
	value = "openstack"
	unseen = True


	# Run function
	set_selection(pkg, question, vtype, value, unseen)



# Generated at 2022-06-25 02:12:17.761589
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(sys.argv[2], sys.argv[3]) == 0, "Could not find the function"


# Generated at 2022-06-25 02:12:21.545541
# Unit test for function set_selection
def test_set_selection():
    var_0 = module.get_bin_path('debconf-set-selections', True)
    var_1 = [var_0]
    var_2 = module.params['unseen']
    var_3 = module.params['name']
    var_4 = module.params['question']
    var_5 = module.params['vtype']
    var_6 = module.params['value']
    var_7 = ' '.join([var_3, var_4, var_5, var_6])
    var_8 = module.run_command(var_1, data=var_7)
    return var_8


# Generated at 2022-06-25 02:12:29.980334
# Unit test for function set_selection
def test_set_selection():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    import os
    import os.path
    from ansible_collections.ansible.builtin.plugins.module_utils._text import to

# Generated at 2022-06-25 02:12:30.633906
# Unit test for function set_selection
def test_set_selection():
    pass



# Generated at 2022-06-25 02:12:32.174871
# Unit test for function main
def test_main():
    assert len(main()) == 0  # len is used to test if a list/tuple is returned; used here as a boolean

# Generated at 2022-06-25 02:12:43.062782
# Unit test for function set_selection
def test_set_selection():
    pass


# Generated at 2022-06-25 02:12:46.159065
# Unit test for function main
def test_main():
    try:
        main()
    except NameError as e:
        print("Something went wrong executing this function: " + str(e))
        return False
    except Exception as e:
        print("Something went wrong: " + str(e))
        return False
    return True



# Generated at 2022-06-25 02:12:54.396954
# Unit test for function set_selection
def test_set_selection():
    var = DebconfModule()
    var.params = {"question":  "",
                  "unseen": None,
                  "pkg": "",
                  "vtype":  "",
                  "value": ""}
    var2 = DebconfModule()
    var2.params = {"question":  "",
                   "unseen": None,
                   "pkg": "",
                   "vtype":  "",
                   "value": ""}
    set_selection(var, var2.params["pkg"], var2.params["question"], var2.params["vtype"], var2.params["value"], var2.params["unseen"])



# Generated at 2022-06-25 02:12:56.502226
# Unit test for function get_selections
def test_get_selections():
    print('Testing get_selections ...')
    assert(get_selections(module, pkg) == selections)


# Generated at 2022-06-25 02:12:57.858152
# Unit test for function get_selections
def test_get_selections():
    assert get_selections((module, 'pkg')) == 0


# Generated at 2022-06-25 02:12:59.447684
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-25 02:13:09.739069
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = module.params["name"]

    # Get unit test params
    args = list()
    args.append(module)
   

# Generated at 2022-06-25 02:13:19.801536
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec={
            'name': {'type': 'str', 'required': True, 'aliases': ['pkg']},
            'question': {'type': 'str', 'aliases': ['selection', 'setting']},
            'vtype': {'type': 'str', 'choices': ['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']},
            'value': {'type': 'str', 'aliases': ['answer']},
            'unseen': {'type': 'bool', 'default': False}
        },
        required_together=({'question', 'vtype', 'value'}),
        supports_check_mode=True
    )
    pkg = 'bar'
    question = 'foo'

# Generated at 2022-06-25 02:13:20.802338
# Unit test for function get_selections
def test_get_selections():
    assert get_selections() == "get_selections"


# Generated at 2022-06-25 02:13:21.696816
# Unit test for function set_selection
def test_set_selection():
    set_selection()


# Generated at 2022-06-25 02:13:46.431436
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = 'ansible-test'
    question = module.params["question"]
    vtype = module.params["vtype"]


# Generated at 2022-06-25 02:13:55.069983
# Unit test for function get_selections
def test_get_selections():
    var_0 = dict()
    var_0['_ansible_parsed'] = False
    var_0['_ansible_module'] = 'debconf'
    var_0['_ansible_version'] = 2.9
    var_0['_ansible_no_log'] = False
    var_0['_ansible_check_mode'] = False
    var_0['_ansible_diff'] = False
    var_0['_ansible_verbosity'] = 0
    var_0['_ansible_debug'] = False
    var_0['_ansible_module_name'] = 'debconf'
    var_0['_ansible_module_uses_check_mode'] = True
    var_0['_ansible_module_uses_diff'] = True

# Generated at 2022-06-25 02:14:03.090922
# Unit test for function set_selection
def test_set_selection():
  from ansible.module_utils.basic import AnsibleModule
  from ansible.module_utils._text import to_text
  var_1 = 'debconf-set-selections'
  var_2 = [var_1]
  var_3 = '-u'
  var_4 = var_2.append(var_3)
  var_5 = to_text(value).lower()
  var_6 = 'true'
  var_7 = var_5 == var_6
  var_8 = to_text(value).lower()
  var_9 = 'false'
  var_10 = var_8 == var_9
  var_11 = ' '.join([pkg, question, vtype, value])

# Generated at 2022-06-25 02:14:06.850297
# Unit test for function set_selection
def test_set_selection():
    setsel = module.get_bin_path('debconf-set-selections', True)
    cmd = [setsel]
    if unseen:
        cmd.append('-u')

    if vtype == 'boolean':
        if value == 'True':
            value = 'true'
        elif value == 'False':
            value = 'false'
    data = ' '.join([pkg, question, vtype, value])

    return module.run_command(cmd, data=data)

# Generated at 2022-06-25 02:14:15.112147
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    var_0 = module.params["name"]
    var_1 = module.params["question"]

# Generated at 2022-06-25 02:14:15.760326
# Unit test for function main
def test_main():
    assert True == True


# Generated at 2022-06-25 02:14:26.277033
# Unit test for function get_selections
def test_get_selections():
    assert os.path.exists(os.path.join(sys.path[0], 'ansible/module_utils/basic.py')), "Module not found"
    assert os.path.exists(os.path.join(sys.path[0], 'ansible/module_utils/debconf.py')), "Module not found"
    assert os.path.exists(os.path.join(sys.path[0], 'ansible/module_utils/_text.py')), "Module not found"


# Generated at 2022-06-25 02:14:26.881839
# Unit test for function set_selection
def test_set_selection():
    pass

# Generated at 2022-06-25 02:14:28.316721
# Unit test for function set_selection
def test_set_selection():
    var_1 = set_selection(None, None, None, None, None, None)


# Generated at 2022-06-25 02:14:29.379970
# Unit test for function get_selections
def test_get_selections():
    assert func_get_selections() == False


# Generated at 2022-06-25 02:15:09.691382
# Unit test for function set_selection
def test_set_selection():
    #
    # Configure the arguments that would be sent to the Ansible module
    module_args = dict(
        name='test',
        question='test',
        vtype='select',
        value='test',
        unseen=True,
    )
    #
    # Instantiate our AnsibleModule object.
    # This sets up logging, and sets the module_utils path from CWD.
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True,
    )
    #
    #################
    # Instantiate the required module to be tested
    #
    main()
    #
    #################


# Generated at 2022-06-25 02:15:16.540000
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-25 02:15:18.993994
# Unit test for function get_selections
def test_get_selections():
    # Setup
    var_0 = ansible.module_utils.basic.AnsibleModule()
    var_1 = get_selections(var_0, 'name')
    assert var_1 == {}

# Generated at 2022-06-25 02:15:20.736365
# Unit test for function get_selections
def test_get_selections():
    var_0 = main()

    # test get_selections
    assert var_0 == "test"



# Generated at 2022-06-25 02:15:24.362174
# Unit test for function main
def test_main():
    pass_0 = {'unseen': True, 'value': '36', 'question': 'tzdata/Zones/America', 'pkg': 'tzdata', 'vtype': 'select'}
    var_0 = main(pass_0)
# main()

# Generated at 2022-06-25 02:15:25.785724
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(module = str, pkg = str) == str


# Generated at 2022-06-25 02:15:27.427299
# Unit test for function main
def test_main():
    param_0 = None
    var_0 = main(param_0)
    assert var_0 is None


# Generated at 2022-06-25 02:15:35.575389
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        require_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    setsel = module.get_bin_path('debconf-set-selections', True)
    cmd = [setsel]

# Generated at 2022-06-25 02:15:36.329931
# Unit test for function get_selections
def test_get_selections():
    main()


# Generated at 2022-06-25 02:15:39.625631
# Unit test for function get_selections
def test_get_selections():
    try:
        actual_result = get_selections(module, pkg)
    except Exception:
        actual_result = None
    assert actual_result == expected_result

# Generated at 2022-06-25 02:17:13.648773
# Unit test for function main
def test_main():
    assert "TODO" == main()


# Generated at 2022-06-25 02:17:16.534060
# Unit test for function set_selection
def test_set_selection():
    pkg = var_0[0]
    question = var_0[1]
    vtype = var_0[2]
    value = var_0[3]
    unseen = var_0[4]
    rc, msg, e = set_selection(module, pkg, question, vtype, value, unseen)
    if rc:
        module.fail_json(msg=e)


# Generated at 2022-06-25 02:17:26.338392
# Unit test for function set_selection

# Generated at 2022-06-25 02:17:26.723786
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-25 02:17:31.088692
# Unit test for function set_selection
def test_set_selection():
    # Test a normal input.
    var_1 = set_selection(module, pkg, question, vtype, value, unseen)
    # Test an error.
    # TODO: Test error scenarios.

# Generated at 2022-06-25 02:17:41.537997
# Unit test for function main
def test_main():
   mock_module = mock.MagicMock()

   class Test0(object):
      def __init__(self):
         self.name = 1
         self.pkg = 1

   class Test1(object):
      def __init__(self):
         self.name = 1
         self.pkg = 1

   def outer_side_effect(*args, **kwargs):
      tmp_args = args[0]
      if tmp_args[0].split(' ')[0] == '/usr/bin/debconf-show':
         return (0, '* locale/preferred-locales\tmultiselect\ten_US.UTF-8 UTF-8\n * timezone\tnote\t\n * time/zone\tselect\tAmerica/Los_Angeles\n', '')

# Generated at 2022-06-25 02:17:42.485229
# Unit test for function main
def test_main():
    response = main()



# Generated at 2022-06-25 02:17:51.041057
# Unit test for function main
def test_main():
#    var_0 = 'ANSIBLE_MODULE_ARGS'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

#    var_0 = module.params["name"]
    question

# Generated at 2022-06-25 02:17:59.302432
# Unit test for function set_selection
def test_set_selection():

    class Args:

        def __init__(self):
            self.selection = None
            self.value = None
            self.vtype = None

        def __setitem__(self, key, value):
            self.__setattr__(key, value)

        def __getitem__(self, item):
            self.__getattribute__(item)

        def __getattribute__(self, item):
            return self.__dict__[item]

        def __setattr__(self, key, value):
            self.__dict__[key] = value


    arg = Args()
    arg.selection = 'selection'
    arg.vtype = 'vtype'
    arg.value = 'value'
    assert set_selection(main(), arg) is None

# Generated at 2022-06-25 02:18:00.916839
# Unit test for function get_selections
def test_get_selections():
    var_0 = main()
    assert str(type(var_0)) == "<class 'ansible.module_utils.basic.AnsibleModule'>"

# Generated at 2022-06-25 02:21:09.110934
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-25 02:21:13.034259
# Unit test for function set_selection
def test_set_selection():
    questions = [
        {
            "question" : "",
            "vtype" : "",
            "value" : "",
        },
    ]

    pkg = "null"
    unseen = False

    for q in questions:
        rc, out, err = set_selection("", pkg, q["question"], q["vtype"], q["value"], unseen)

        if rc != 0:
            print(out)
            exit()

# Generated at 2022-06-25 02:21:23.768421
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = module.params["name"]
    question = module.params["question"]
    vtype = module.params["vtype"]


# Generated at 2022-06-25 02:21:33.554789
# Unit test for function get_selections
def test_get_selections():
    var_0 = dict()
    var_0['name'] = 'tzdata'
    var_0['question'] = None
    var_0['vtype'] = None
    var_0['value'] = None
    var_0['unseen'] = False
    var_1 = dict()
    var_1['name'] = 'tzdata'
    var_1['question'] = 'tzdata/Areas'
    var_1['vtype'] = 'select'
    var_1['value'] = 'Asia'
    var_1['unseen'] = False
    var_2 = dict()
    var_2['name'] = 'tzdata'
    var_2['question'] = 'tzdata/Zones/Asia'
    var_2['vtype'] = 'multiselect'

# Generated at 2022-06-25 02:21:35.350640
# Unit test for function main
def test_main():
    var_1 = main()
    assert var_1['changed'] == True

# Generated at 2022-06-25 02:21:36.852363
# Unit test for function get_selections
def test_get_selections():
    var_1 = get_selections(module, pkg)
    assert 'test_string' == var_1


# Generated at 2022-06-25 02:21:43.967565
# Unit test for function set_selection
def test_set_selection():
    print("Test start")
    import os
    import sys
    import json
    import collections
    import tempfile
    import random

    import ansible.module_utils.basic as basic
    import ansible.module_utils.action as action
    import ansible.module_utils.urls as urls
    import ansible.module_utils.six as six
    from ansible.module_utils._text import to_text

    # import ansible.module_utils.facts as facts
    # import ansible.module_utils.wait as wait
    # import ansible.module_utils.database as database
    # import ansible.module_utils.helpers as helpers
    # import ansible.module_utils.search as search
    # import ansible.module_utils.six as six
    # from ansible.module_utils.urls import

# Generated at 2022-06-25 02:21:46.081906
# Unit test for function main
def test_main():
    AnsibleModule.run_command = run_command
    AnsibleModule.get_bin_path = get_bin_path
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:21:52.575380
# Unit test for function get_selections
def test_get_selections():
    # Test with dummy file
    test_file = os.path.join(ROOTDIR, 'test', 'get_selections.out')
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )