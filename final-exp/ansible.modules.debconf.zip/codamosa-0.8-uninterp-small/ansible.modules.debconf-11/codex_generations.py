

# Generated at 2022-06-25 02:12:06.690109
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-25 02:12:08.751478
# Unit test for function main
def test_main():
    var_dict, var_file_str, var_line_str, var_name_dict, var_name_str, var_package_name, var_statement_str, var_value_dict, var_value_str = main()



# Generated at 2022-06-25 02:12:09.515538
# Unit test for function get_selections
def test_get_selections():
    assert (test_case_0())


# Generated at 2022-06-25 02:12:15.246507
# Unit test for function get_selections
def test_get_selections():
    mock_module = MagicMock()
    mock_module.run_command = MagicMock(side_effect=main)
    expected_value = "test_value"

    var_0 = get_selections(mock_module, expected_value)

    mock_module.run_command.assert_called_with(
        'debconf-show test_value',
        check_rc=True,
        close_fds=True,
        data=None,
        binary_data=False,
        path_prefix=None,
        cwd=None,
        use_unsafe_shell=False,
        encoding=None
    )
    assert var_0 == "test_value"


# Generated at 2022-06-25 02:12:16.410918
# Unit test for function main
def test_main():
    assert var_0 == 0
    return 0
# vim: set ft=python :

# Generated at 2022-06-25 02:12:19.974116
# Unit test for function set_selection
def test_set_selection():

    with patch('ansible_collections.ansible.builtin.plugins.module_utils.basic.AnsibleModule.run_command', return_value='a'):
        assert set_selection('a', 'b', 'c', 'd', 'e') == 'a'


# Generated at 2022-06-25 02:12:29.216544
# Unit test for function set_selection
def test_set_selection():
    # Make a local reference to the dependencies module
    import ansible.module_utils.basic
    import ansible.module_utils.common.params
    import ansible.module_utils.debconf
    import ansible.module_utils.basic

    # Create private references to Ansible params and ansible.module_utils.basic for resuse
    ansible_params = ansible.module_utils.common.params.AnsibleParams
    ansible_module_utils_basic = ansible.module_utils.basic

    # Set defaults for the parameters
    name = 'tzdata'
    question = None
    vtype = None
    value = None
    unseen = True

    # BEGIN of Ansible code

# Generated at 2022-06-25 02:12:30.379964
# Unit test for function main
def test_main():
    # Get data from command.
    args = get_arguments()
    var = main()


# Generated at 2022-06-25 02:12:31.440072
# Unit test for function main
def test_main():
    print("Test main")

    main()


# Generated at 2022-06-25 02:12:36.324312
# Unit test for function get_selections
def test_get_selections():
    var_0 = 'debconf-show'
    var_2 = str()
    var_3 = str()
    var_4 = False
    var_5 = False
    var_6 = True
    var_7 = 'local'
    var_8 = module(var_0, var_2, var_3, var_4, var_5, var_6, var_7)
    var_10 = 'locales'
    var_11 = get_selections(var_8, var_10)



# Generated at 2022-06-25 02:12:52.111231
# Unit test for function set_selection
def test_set_selection():
    var_param_list = {'module': 'module', 'pkg': 'pkg', 'question': 'question', 'vtype': 'vtype', 'value': 'value', 'unseen': 'unseen'}
    set_selection(var_param_list, module=None, pkg=None, question=None, vtype=None, value=None, unseen=None, )


# Generated at 2022-06-25 02:12:54.625928
# Unit test for function main
def test_main():
    # Returns a dictionary of all the keys in a.
    assert hasattr(keys, "__call__")
    assert isinstance(keys(a={}), list)


# Generated at 2022-06-25 02:13:05.306431
# Unit test for function set_selection
def test_set_selection():
    var_0 = {'changed': False, 'unreachable': False,
             'msg': u'', 'invocation': {'module_args': {'value': u'postgresql-9.4',
             'no_log': False, 'no_target_syslog': False,
             'pkg': u'postgresql-common', 'question': u'postgresql/version_upgrade',
             'remote_user': None, 'remote_addr': None, 'selevel': None,
             'unseen': False, 'setype': None, 'seuser': None, 'serole': None,
             'vtype': u'password', 'check': False}, 'module_name': u'ansible.builtin.debconf'}}
    var_1 = u'postgresql-common'

# Generated at 2022-06-25 02:13:13.040840
# Unit test for function set_selection
def test_set_selection():
    import os.path
    import subprocess

    setsel = os.path.join(os.path.dirname(subprocess.__file__), "runpy.py")
    pkg = 'tzdata'
    question = 'tzdata/Zones/America'
    vtype = 'multiselect'
    value = 'Europe/Amsterdam,Europe/Andorra,Europe/Astrakhan,Europe/Athens'
    unseen = True
    rc, msg, e = set_selection(pkg, question, vtype, value, unseen)
    assert(rc) == 0
    assert(msg) == '\n'
    assert(e) == ''

# Generated at 2022-06-25 02:13:20.458718
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    
    param_0 = 'shared/accepted-oracle-license-v1-1'
    param_1 = 'select'


# Generated at 2022-06-25 02:13:26.848077
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    module.run_command = Mock(return_value=0)
    pkg = "pkg_0"

    # Call function get_select

# Generated at 2022-06-25 02:13:27.903675
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:13:29.702393
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == "", "The values returned do not match."

# Generated at 2022-06-25 02:13:30.678529
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:13:31.628810
# Unit test for function get_selections
def test_get_selections():
    pass


# Generated at 2022-06-25 02:13:59.977295
# Unit test for function set_selection
def test_set_selection():
    setsel = module.get_bin_path('debconf-set-selections', True)
    cmd = [setsel]
    if unseen:
        cmd.append('-u')

    if vtype == 'boolean':
        if value == 'True':
            value = 'true'
        elif value == 'False':
            value = 'false'
    data = ' '.join([pkg, question, vtype, value])

    return module.run_command(cmd, data=data)


# Generated at 2022-06-25 02:14:06.569586
# Unit test for function main
def test_main():
    assert 'set_selection' in globals()
    assert 'setsel' in globals()
    assert 'pkg' in globals()
    assert 'e' in globals()
    assert 'value' in globals()
    assert 'question' in globals()
    assert 'cmd' in globals()
    assert 'vtype' in globals()
    assert 'unseen' in globals()
    assert 'prev' in globals()
    assert 'err' in globals()
    assert 'data' in globals()
    assert 'msg' in globals()
    assert 'changed' in globals()
    assert 'get_selections' in globals()
    assert 'rc' in globals()
    assert 'out' in globals()
    assert 'module' in globals()
    assert 'selections' in globals()


# Generated at 2022-06-25 02:14:08.848367
# Unit test for function main
def test_main():
    # main()
    var_0 = None
    # main()
    var_1 = None


# ##################
# Unit test

import unittest


# Generated at 2022-06-25 02:14:11.812188
# Unit test for function set_selection
def test_set_selection():
    print("===test_set_selection(test_case_0)===")
    r = set_selection(test_case_0)
    assert r.status_code == 0, 'status_code != 0'


# Generated at 2022-06-25 02:14:18.756597
# Unit test for function main
def test_main():

    import ansible.modules.system.debconf
    import ansible.module_utils.basic
    import ansible.module_utils._text
    import ansible.module_utils.action
    import ansible.module_utils.action.__init__
    import ansible.module_utils.action.core
    import ansible.module_utils.action.network
    import ansible.module_utils.action.storage
    import ansible.module_utils.action.windows
    import ansible.module_utils.debconf

    import ansible.module_utils.ansible_release
    import ansible.module_utils.distribution
    import ansible.module_utils.net_tools
    import ansible.module_utils.parsing
    import ansible.module_utils.six
    import ansible.module_utils.system
   

# Generated at 2022-06-25 02:14:22.135668
# Unit test for function get_selections
def test_get_selections():
    rc, out, err = set_selection(module, pkg, question, vtype, value, unseen)
    assert rc == 0
    assert out is None
    assert err is None



# Generated at 2022-06-25 02:14:29.960369
# Unit test for function main
def test_main():
    from unittest import mock
    from ansible.module_utils.basic import AnsibleModule

    def test_get_selections(module, pkg):
        mock_get_selections = mock.MagicMock()
        mock_get_selections.return_value = {'question': "value"}

        mock_get_selections(module, pkg)
        mock_get_selections.assert_called_with(module, pkg)

    def test_set_selection(module, pkg, question, vtype, value, unseen):
        mock_set_selection = mock.MagicMock()
        mock_set_selection.return_value = (0, "test_msg", "test_err")

        mock_set_selection(module, pkg, question, vtype, value, unseen)

# Generated at 2022-06-25 02:14:31.395805
# Unit test for function get_selections
def test_get_selections():
    assert True


# Generated at 2022-06-25 02:14:36.407283
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils import debconf
    from ansible.module_utils import debconf_utils
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils._text import to_text

    # TODO: Fix this test
    return

    try:
        assert get_selections() == None
    except AssertionError as e:
        print(e.message)
        raise AssertionError

# Generated at 2022-06-25 02:14:44.069818
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            pkg=dict(type='str', required=True),
            question=dict(type='str'),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str'),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    setsel = module.get_bin_path('debconf-set-selections', True)
    cmd = [setsel]

# Generated at 2022-06-25 02:15:20.776480
# Unit test for function main
def test_main():
    var_0 = {
        "name": "test_value_1",
        "question": "test_value_2",
        "vtype": "test_value_3",
        "value": "test_value_4",
        "unseen": True,
    }
    test_case_0()

# Generated at 2022-06-25 02:15:23.096845
# Unit test for function main
def test_main():
    try:
        _0 = main()
    except NameError:
        pass


# Generated at 2022-06-25 02:15:26.431798
# Unit test for function get_selections
def test_get_selections():
    var_0 = 'None'
    var_1 = 'debconf-utils'
    var_2 = main()

    var_3 = get_selections(var_2, var_1)

    var_2.fail_json(msg=var_3)

    assert var_0 == var_1



# Generated at 2022-06-25 02:15:34.577042
# Unit test for function get_selections
def test_get_selections():
    var_0 = AnsibleModule(dict(action=dict(required=False, type='str', aliases=list(), default=None, no_log=False), dest=dict(required=False, type='str', aliases=list(), default=None, no_log=False), pattern=dict(required=False, type='str', aliases=list(), default=r'\.pyc$', no_log=False), args=dict(required=False, type='list', aliases=list(), default=list(), no_log=False)))
    var_1 = '/usr/bin/debconf-show'
    var_2 = 'tzdata'
    var_3 = [var_1, var_2]
    var_4 = var_0.run_command(' '.join(var_3))[1:]
    var_5 = dict()

# Generated at 2022-06-25 02:15:35.372264
# Unit test for function set_selection
def test_set_selection():
    assert True == True


# Generated at 2022-06-25 02:15:37.574465
# Unit test for function set_selection
def test_set_selection():
    var_0 = main()
    var_1 = set_selection(var_0, 'oracle-java7-installer', 'shared/accepted-oracle-license-v1-1', 'text', 'true', 'false')


# Generated at 2022-06-25 02:15:40.058941
# Unit test for function set_selection
def test_set_selection():
    var_0 = set_selection(module, pkg, question, vtype, value, unseen)
    assert var_0 == 'password'

# Generated at 2022-06-25 02:15:40.803460
# Unit test for function main
def test_main():
    main();


# Generated at 2022-06-25 02:15:42.427665
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None, 'Assertion Error: Test_main - 0'


# Generated at 2022-06-25 02:15:43.558467
# Unit test for function get_selections
def test_get_selections():
    assert callable(get_selections)


# Generated at 2022-06-25 02:17:20.756586
# Unit test for function main
def test_main():
    var_1 = 'test text'
    var_2 = {'a': 'test text'}
    var_3 = 'change'
    var_4 = 'test text'
    var_5 = {'a': 'test text'}
    var_6 = {'a': 'test text'}
    var_7 = {'a': 'test text'}
    var_8 = False

    var_9 = 'test text'
    var_10 = {'a': 'test text'}
    var_11 = 'change'
    var_12 = 'test text'
    var_13 = {'a': 'test text'}
    var_14 = {'a': 'test text'}
    var_15 = {'a': 'test text'}
    var_16 = False


# Generated at 2022-06-25 02:17:26.020043
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule

    main_0 = main()
    main_1 = main()
    main_2 = main()
    main_3 = main()
    main_4 = main()
    main_5 = main()
    main_6 = main()
    main_7 = main()


# Generated at 2022-06-25 02:17:34.662528
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-25 02:17:37.425501
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(var_0, 'pkg') == 200


# Generated at 2022-06-25 02:17:39.244004
# Unit test for function get_selections
def test_get_selections():
    prev = {"Question1": None, "Question2": None, "Question3": None}
    assert prev == get_selections(None, "pk1")


# Generated at 2022-06-25 02:17:41.814906
# Unit test for function set_selection
def test_set_selection():
    print("Testing set_selection...")
    # Tests:
    # cmnd = ['debconf-set-selections']
    # data = ' '.join([pkg, question, vtype, value])
    # return self.module.run_command(cmnd, data=data)
    print("Done testing set_selection.")


# Generated at 2022-06-25 02:17:42.594911
# Unit test for function get_selections
def test_get_selections():
    var_0 = main()

# Generated at 2022-06-25 02:17:43.409901
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule([])

    # TODO: write test function



# Generated at 2022-06-25 02:17:51.714866
# Unit test for function main
def test_main():
    param_0 = mock.MagicMock()
    var_1 = param_0.params
    var_2 = {'name': None, 'vtype': None, 'value': None, 'question': None, 'unseen': False}
    var_3 = {'question': None, 'value': None, 'vtype': None}
    var_2["name"] = var_3
    var_2["unseen"] = False
    var_1.__getitem__.return_value = var_2
    var_4 = param_0.params
    var_5 = {'name': None, 'vtype': None, 'value': None, 'question': None, 'unseen': False}
    var_6 = {'question': None, 'value': None, 'vtype': None}
    var_5["name"] = var_

# Generated at 2022-06-25 02:17:53.435608
# Unit test for function set_selection
def test_set_selection():
    assert set_selection(module, pkg, question, vtype, value, unseen) == (rc, msg, e)


# Generated at 2022-06-25 02:21:12.170099
# Unit test for function main
def test_main():
    # build test arguments using default values
    arguments = dict(
        name='PKG_NAME',
        question='QUESTION',
        vtype='SELECT',
        value='VTYPE',
    )

    # execute function with mocked arguments
    test_case_0(arguments)

# unit test execution code
#if __name__ == '__main__':
#    # test the function
#    test_main()

# Generated at 2022-06-25 02:21:16.206680
# Unit test for function set_selection
def test_set_selection():
    assert True


# Generated at 2022-06-25 02:21:16.899635
# Unit test for function get_selections
def test_get_selections():

    assert get_selections() is False


# Generated at 2022-06-25 02:21:21.586255
# Unit test for function main
def test_main():

    from ansible.module_utils._text import to_text

    # This expression is written in example but not in code
    # assert True

    # Change these values to test the module

    # TODO: This is not used in code.

    # TODO: This is not used in code.


    assert True

# Generated at 2022-06-25 02:21:28.854334
# Unit test for function set_selection
def test_set_selection():
    args0 = {}
    args1 = {}
    args2 = {}
    args3 = {}
    args4 = {}
    args5 = {}
    local_var_args = list(args0, args1, args2, args3, args4, args5)


# Generated at 2022-06-25 02:21:30.340457
# Unit test for function set_selection
def test_set_selection():
    question = 'string'
    vtype = 'string'
    value = 'string'
    unseen = True

    print(set_selection(question, vtype, value, unseen))



# Generated at 2022-06-25 02:21:30.945700
# Unit test for function get_selections
def test_get_selections():
    test_case_0()

# Generated at 2022-06-25 02:21:32.641943
# Unit test for function get_selections
def test_get_selections():
    test_1 = 'test_1'
    module_1 = AnsibleModule(argument_spec={})
    test_case_1 = get_selections(module_1, test_1)


# Generated at 2022-06-25 02:21:41.805832
# Unit test for function set_selection
def test_set_selection():
    # initialization
    file_path = ""
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    # mock the arguments
    pkg = ""
    question = ""
    vtype = ""

# Generated at 2022-06-25 02:21:43.722133
# Unit test for function get_selections
def test_get_selections():
    rc, out, err = set_selection(module, pkg, question, vtype, value, unseen)
    assert rc == 0
    assert out == ""
    assert err == ""

