

# Generated at 2022-06-20 21:30:10.564069
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = module.params["name"]

    prev = get_selections(module, pkg)

    assert prev == {'tzdata/Areas': '', 'tzdata/Zones/Europe': '', 'tzdata/Zones/Asia': '', 'tzdata/Zones/America': '', 'tzdata/Zones/Australia': '', 'tzdata/Zones/Africa': ''}

# Generated at 2022-06-20 21:30:20.008424
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    rc, out, err = get_selections(module, 'tzdata')
    assert rc == 0
    assert 'tzdata/Areas' in out
    assert 'tzdata/Zones/Asia' in out


# Generated at 2022-06-20 21:30:28.047701
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule()
    assert set_selection(module, 'tzdata', 'tzdata/Areacode', 'string', '0', False) == (0, '', '')
    assert set_selection(module, 'tzdata', 'tzdata/Areacode', 'string', '1', False) == (0, '', '')


# Generated at 2022-06-20 21:30:37.333761
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    module = basic.AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    module.run_command = MagicMock(return_value=(0, b"foo bar: baz\n", ""))
    assert get_selections(module, "foo") == {"foo": "bar", "bar": "baz"}
    module.run_command = MagicMock(return_value=(1, "", "Some error"))
    assert get_selections(module, "foo") == {}

# Unit tests for function set_selection

# Generated at 2022-06-20 21:30:46.431301
# Unit test for function get_selections
def test_get_selections():
    # Assume debconf-utils is installed in the system, this is a valid package
    module = AnsibleModule(argument_spec={'name': {'type': 'str', 'required': True, 'aliases': ['pkg']}})
    selections = get_selections(module, 'debconf-utils')
    assert isinstance(selections, dict)
    assert '* shared/warn-on-old-templates' in selections
    assert '* tzdata/Zones/Europe' in selections
    assert '* debconf-utils/newversion' in selections


# Generated at 2022-06-20 21:30:53.619594
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', required=True, aliases=['selection', 'setting']),
            vtype=dict(type='str', required=True, choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', required=True, aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections

# Generated at 2022-06-20 21:30:56.975621
# Unit test for function set_selection

# Generated at 2022-06-20 21:31:01.536822
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils import basic

    filename = '~/test.txt'
    m = basic.AnsibleModule({'a': 'b'}, check_invalid_arguments=False)
    m.run_command = lambda cmd, data=None: (0, 'ok', 'failed')
    set_selection(m, 'pkginstall', 'question', 'vtype', 'value', False)

# Generated at 2022-06-20 21:31:07.995890
# Unit test for function main
def test_main():
    monkeypatch.setattr(AnsibleModule, 'run_command', lambda *args, **kwargs: 0)
    monkeypatch.setattr(AnsibleModule, 'get_bin_path', lambda *args, **kwargs: 'ansible')


# Generated at 2022-06-20 21:31:17.491182
# Unit test for function get_selections
def test_get_selections():
  module = AnsibleModule( argument_spec = dict(name=dict(type='str', required=True, alias=['pkg']), question=dict(type='str', alias=['selection', 'setting']), vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']), value=dict(type='str', alias=['answer']), unseen=dict(type='bool', default=False)), required_together=(['question', 'vtype', 'value', 'unseen'],), supports_check_mode=True,)

  pkg = 'tzdata'
  question = module.params["question"]


# Generated at 2022-06-20 21:31:43.781942
# Unit test for function set_selection
def test_set_selection():
    import os
    import tempfile

    fd, fn = tempfile.mkstemp()
    os.close(fd)
    os.remove(fn)

    # No need to actually run this, but just in case
    assert not os.path.exists(fn)


# Generated at 2022-06-20 21:31:56.044628
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = 'python-pytest'
    question = 'pytest/test_question'
    vtype = 'select'
    value

# Generated at 2022-06-20 21:32:10.917452
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    rc, msg, e = set_selection(module, 'testpkg', 'testquestion', 'testvtype', 'testvalue', True)



# Generated at 2022-06-20 21:32:25.993908
# Unit test for function main
def test_main():
    task = {
        'name': 'locales',
        'question': 'locales/default_environment_locale',
        'value': 'value',
        'vtype': 'select'
    }

# Generated at 2022-06-20 21:32:33.281780
# Unit test for function set_selection
def test_set_selection():

    # import the debconf module so we can use its functions
    global debconf
    import debconf

    # tell debconf to not prompt, so we don't suspend
    debconf.p.set('debconf/frontend', 'noninteractive')
    debconf.p.set('debconf/priority', 'critical')

    # use an in-memory database
    db = debconf.DebconfCommunicator()
    db.set('foo/bar', 'baz')

    # using this is equivalent to running "debconf-set-selections -u < input"
    for line in 'foo foo/bar string baz\n'.split('\n'):
        db.command('SET', line)

    # assert that the database value is unchanged
    assert db.get('foo/bar') == 'baz'

# Generated at 2022-06-20 21:32:37.484251
# Unit test for function get_selections
def test_get_selections():
    assert get_selections({}, 'tzdata') == {
        'tzdata/Areas': 'main',
        'tzdata/Zones/Etc': 'UTC'
        }

# Generated at 2022-06-20 21:32:38.031140
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:32:52.544942
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils import basic
    from ansible.module_utils.common.process import get_bin_path

    class ModuleMock(basic.AnsibleModule):
        def __init__(self, **kwargs):
            kwargs['argument_spec'] = dict(
                name=dict(type='str', required=True, aliases=['pkg']),
                question=dict(type='str', aliases=['selection', 'setting']),
                vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
                value=dict(type='str', aliases=['answer']),
                unseen=dict(type='bool', default=False),
            )

# Generated at 2022-06-20 21:33:04.753101
# Unit test for function main
def test_main():
    # TODO: (a) Mock the module class, (b) mock the debconf-show and debconf-set-selections commands
    # and (c) create a fake /tmp/debconf-test.log file with known contents.
    class module:
        def __init__(self, supported_check_mode, required_together, params, requires_ansible_2_2):
            self.check_mode = False
            self.params = params
            self._diff = True

        def exit_json(self, changed):
            assert changed


# Generated at 2022-06-20 21:33:10.723280
# Unit test for function set_selection
def test_set_selection():
    setsel = module.get_bin_path('debconf-set-selections', True)
    cmd = [setsel]
    if unseen:
        cmd.append('-u')

    if vtype == 'boolean':
        if value == 'True':
            value = 'true'
        elif value == 'False':
            value = 'false'
    data = ' '.join([pkg, question, vtype, value])

    return module.run_command(cmd, data=data)

# Generated at 2022-06-20 21:33:30.914691
# Unit test for function main
def test_main():
    # FIXME: call function with params,
    # assert correct result, etc.
    # See: https://github.com/ansible/ansible/pull/39529
    pass

# Generated at 2022-06-20 21:33:39.313438
# Unit test for function main
def test_main():

    # Create a mock module and use it to call main()
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # Execute main()
    #main(module)



# Generated at 2022-06-20 21:33:50.404214
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils import basic
    import ansible.module_utils.debconf
    import unittest

    class TestGetSelections(unittest.TestCase):
        def setUp(self):
            self.module = basic.AnsibleModule(
                argument_spec=dict(
                )
            )

        def test_get_last_line_for_simple_data(self):
            fake_data = """
* locales/default_environment_locale: en_US.UTF-8
* tzdata/Zones/America: US
"""
            selections = ansible.module_utils.debconf.get_selections(self.module, fake_data)


# Generated at 2022-06-20 21:34:03.527071
# Unit test for function get_selections
def test_get_selections():
    '''
    Test get_selections function
    '''
    import sys
    import shutil
    import tempfile
    import collections
    import subprocess

    # Create a temp file to redirect stdout to.
    tmpfile_handle, tmpfilename = tempfile.mkstemp(prefix='ansible-tmp')
    os.close(tmpfile_handle)

    # Create a temp folder to store command output
    current_folder = os.getcwd()
    temp_folder = tempfile.mkdtemp(prefix='ansible-tmp')
    os.chdir(temp_folder)

    # Fake two .deb packages
    package1 = 'fake1'
    package2 = 'fake2'

    # Create a debconf-show ansible-fake stub file

# Generated at 2022-06-20 21:34:10.602359
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = 'tzdata'

# Generated at 2022-06-20 21:34:20.479017
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    result = get_selections(module, 'tzdata')
    # print(result)
    assert type(result) == dict

# Generated at 2022-06-20 21:34:30.156469
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-20 21:34:35.953099
# Unit test for function set_selection
def test_set_selection():
    with AnsibleModule() as module:
        rc, msg, e = set_selection(module, 'test-package', 'test_question', 'test_vtype', 'test_value', False)
        assert rc == 0
        assert msg == b''
        assert e == b''

# Generated at 2022-06-20 21:34:39.651466
# Unit test for function get_selections
def test_get_selections():
    import re
    assert(re.match('\w+', get_selections(module, pkg)) == True)

# Generated at 2022-06-20 21:34:44.798348
# Unit test for function get_selections
def test_get_selections():
    import os
    test_path = os.path.dirname(__file__)
    os.environ['PATH'] = ':'.join([test_path, os.environ['PATH']])
    out = get_selections(('debconf-show tzdata'))
    assert out['tzdata/Areas'] == 'Europe'


# Generated at 2022-06-20 21:35:27.824327
# Unit test for function get_selections
def test_get_selections():
    pkg = 'tzdata'
    prev = get_selections(m, pkg)
    assert isinstance(prev, dict)



# Generated at 2022-06-20 21:35:43.942534
# Unit test for function main
def test_main():
    import os
    import json
    import re
    import sys
    # import tempfile
    # import traceback
    # import warnings
    # import platform
    # import time
    # import subprocess
    # import datetime
    # import string
    # import shutil
    # import copy
    # import email

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    # from ansible.module_utils.six import PY3

    if not basic._ANSIBLE_TEST_INVOCATION:
        sys.stderr.write("FAIL: test_main is only for unit testing.\n")
        sys.exit(1)

    ansible_test = basic._ANSIBLE_TEST
    if ansible_test.options.verbosity >= 1:
        print

# Generated at 2022-06-20 21:35:49.435542
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule({
        "question": "test/test_question",
        "vtype": "boolean",
        "value": True
    })

    (rc, msg, err) = set_selection(module, 'test', 'test/test_question', 'boolean', 'true', False)

    assert rc == 0
    assert err == ''
    assert 'test/test_question' in msg

# Generated at 2022-06-20 21:36:03.428980
# Unit test for function set_selection
def test_set_selection():
    # Create a fake module
    class FakeModule(object):
        def __init__(self, changed=False, msg=""):
            self.changed = changed
            self.msg = msg

        def fail_json(self, msg=""):
            self.msg = msg
            return "failed"

        def run_command(self, cmd, data=None):
            return 0, self.msg, ""

        def get_bin_path(self, arg1, arg2):
            return "/bin/fake/" + arg1

    module = FakeModule()
    assert set_selection(module, "fake", "question", "boolean", "true", False) is None

    # Test with error
    module = FakeModule()
    assert set_selection(module, "fake", "question", "boolean", "true", False) is None

    # Test unic

# Generated at 2022-06-20 21:36:05.397670
# Unit test for function main
def test_main():
  assert isinstance(main(), object)

# Generated at 2022-06-20 21:36:15.758946
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.modules.system.debconf
    import json

    module_name = 'ansible.modules.system.debconf.main'
    module = ansible.modules.system.debconf

    module_args = dict(
        name=dict(type='str', required='true', aliases=['pkg']),
        question=dict(type='str', aliases=['selection', 'setting']),
        vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
        value=dict(type='str', aliases=['answer']),
        unseen=dict(type='bool', default='false'),
    )

# Generated at 2022-06-20 21:36:28.450918
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(argument_spec=dict(
        value=dict(type='str', required=True, aliases=['answer']),
        vtype=dict(type='str', required=True, choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
        question=dict(type='str', required=True, aliases=['selection', 'setting']),
        name=dict(type='str', required=True, aliases=['pkg']),
        unseen=dict(type='bool', default=False),
        ))
    pkg = 'test'
    question = 'test/test_question'
    vtype = 'test_type'
    value = 'test_value'
    unseen = False

# Generated at 2022-06-20 21:36:33.244445
# Unit test for function set_selection
def test_set_selection():
        setsel = module.get_bin_path('debconf-set-selections', True)
        cmd = [setsel]
        if unseen:
            cmd.append('-u')

        if type == 'boolean':
            if value == 'True':
                value = 'true'
            elif value == 'False':
                value = 'false'
        data = ' '.join([pkg, question, vtype, value])

        return module.run_command(cmd, data=data)

# Generated at 2022-06-20 21:36:43.925508
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-20 21:36:53.829262
# Unit test for function get_selections
def test_get_selections():

    from ansible.module_utils.basic import AnsibleModule
    import os

    # create some values - ansible does not require  strings to be escaped
    test_name = 'locales'
    test_question = 'shared/accepted-oracle-license-v1-1'
    test_vtype = 'select'
    test_answer = 'true'
    test_unseen = True

    # put them in a dictionary
    test_params = {'name': test_name, 'question': test_question, 'vtype': test_vtype, 'answer': test_answer, 'unseen': test_unseen}

    # setup the module

# Generated at 2022-06-20 21:38:34.096566
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = 'test'
    question = 'test_question'
    vtype = 'test_vtype'

# Generated at 2022-06-20 21:38:36.557595
# Unit test for function set_selection
def test_set_selection():
    a = set_selection(module, pkg, question, vtype, value, unseen)
    return "ok"

# Generated at 2022-06-20 21:38:44.632009
# Unit test for function set_selection
def test_set_selection():
    import os
    import stat
    import unittest

    from ansible.module_utils.basic import AnsibleModule

    def set_selection(module, pkg, question, vtype, value, unseen):
        setsel = module.get_bin_path('debconf-set-selections', True)
        cmd = [setsel]
        if unseen:
            cmd.append('-u')

        if vtype == 'boolean':
            if value == 'True':
                value = 'true'
            elif value == 'False':
                value = 'false'
        data = ' '.join([pkg, question, vtype, value])

        return module.run_command(cmd, data=data)

    class TestDebconfModule(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule

# Generated at 2022-06-20 21:38:57.980784
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-20 21:39:06.157776
# Unit test for function get_selections

# Generated at 2022-06-20 21:39:18.796094
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
        # Supports basic test with AnsibleModule.exit_json and AnsibleModule.fail_json
        check_invalid_arguments=False
    )



# Generated at 2022-06-20 21:39:19.364880
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:39:25.387368
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = dict()
            self.params['name'] = 'tzdata'
            self

# Generated at 2022-06-20 21:39:37.324626
# Unit test for function get_selections
def test_get_selections():
    package = 'tzdata'

    command = ['/usr/bin/debconf-show', package]
    rc, out, err = module.run_command(' '.join(command))

    if rc != 0:
        module.fail_json(msg=err)

    selections = []

    for line in out.splitlines():
        (key, value) = line.split(':', 1)
        selections[key.strip('*').strip()] = value.strip()

    return selections


# Generated at 2022-06-20 21:39:44.318870
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(argument_spec=dict(
        name=dict(type='str', required=True, aliases=['pkg']),
        question=dict(type='str', aliases=['selection', 'setting']),
        vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
        value=dict(type='str', aliases=['answer']),
        unseen=dict(type='bool', default=False),
    ))
    command_success = set_selection(module, pkg="tzdata", question="tzdata/Areas", vtype="select", value="America", unseen=False)
    assert command_success == (True, '', '')