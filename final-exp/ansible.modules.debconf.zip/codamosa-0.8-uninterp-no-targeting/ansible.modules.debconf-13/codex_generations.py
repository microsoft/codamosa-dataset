

# Generated at 2022-06-20 21:30:08.459525
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True
    )

    expected_cmd = "debconf-set-selections"

# Generated at 2022-06-20 21:30:18.724771
# Unit test for function get_selections
def test_get_selections():
    # Test 1: Package with simple selection
    class FakeModule(object):
        @staticmethod
        def fail_json(msg):
            print("FAIL: " + msg)

        @staticmethod
        def get_bin_path(name):
            return "/usr/bin/%s" % name

        @staticmethod
        def run_command(cmd, data=None, check_rc=True):
            if cmd == '/usr/bin/debconf-show locales':
                return (0, "locales/default_environment_locale: en_US.UTF-8\n* locales/locales_to_be_generated: en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8\n", "")
            else:
                print("ERROR: unknown command: %s" % cmd)

    result

# Generated at 2022-06-20 21:30:25.723325
# Unit test for function get_selections
def test_get_selections():
    class module_mock:
        def run_command(self, cmd):
            return (0, float_result_text, float_result_text)

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return executable

    class AnsibleModule_mock(object):
        def __init__(self, argument_spec, supports_check_mode=False, required_together=None):
            self.params = {}
            self.supports_check_mode = supports_check_mode
            self.argument_spec = {}


# Generated at 2022-06-20 21:30:26.896558
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:30:29.155444
# Unit test for function main
def test_main():
    # TODO: Write test, I have no idea how to test this
    return

# Generated at 2022-06-20 21:30:31.294673
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:30:45.519381
# Unit test for function set_selection
def test_set_selection():
    set_selection(ansible.builtin.debconf, 'locale', 'locale/locales_to_be_generated', 'select', 'fr_FR.UTF-8', False)
    set_selection(ansible.builtin.debconf, 'locale', 'locale/locales_to_be_generated', 'multiselect', 'fr_FR.UTF-8', False)
    set_selection(ansible.builtin.debconf, 'locale', 'locale/default_environment_locale', 'select', 'fr_FR.UTF-8', False)
    set_selection(ansible.builtin.debconf, 'locale', 'locale/default_environment_locale', 'multiselect', 'fr_FR.UTF-8', False)

# Generated at 2022-06-20 21:30:52.952973
# Unit test for function main
def test_main():
    import os
    import tempfile

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path

    # Create result struct
    result = dict(
        changed=False,
        rc=0,
        stderr='',
        stdout=''
    )

    # Do not create a log file
    log_file = None

    # Create temp directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary directory for package config
    package_conf_dir = '%s/config' % temp_dir

    # Create a temporary ansible_module_runner
    class FakeAnsibleModule:

        def __init__(self, result):
            self.result = result


# Generated at 2022-06-20 21:31:07.805240
# Unit test for function main
def test_main():
    module=AnsibleModule(argument_spec=dict(name=dict(type='str', required=True, aliases=['pkg']), question=dict(type='str', aliases=['selection', 'setting']), vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']), value=dict(type='str', aliases=['answer']), unseen=dict(type='bool', default=False))
, required_together=(['question', 'vtype', 'value'],)
, supports_check_mode=True
)
    # TODO: implement unit test
    # main(module)
    assert True


# Generated at 2022-06-20 21:31:10.710097
# Unit test for function get_selections
def test_get_selections():
    print(get_selections('zabbix-agent', 'zabbix-agent'))

# Generated at 2022-06-20 21:31:28.721004
# Unit test for function set_selection

# Generated at 2022-06-20 21:31:44.099449
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = module.params["name"]

    # Test for case where /bin/debconf-show exists

# Generated at 2022-06-20 21:31:56.133865
# Unit test for function main
def test_main():
    import sys
    import os
    import shutil
    import json
    import stat
    import tempfile
    import time
    import datetime
    import unittest

    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    # Replacing basic._ANSIBLE_ARGS so we can provide our own for testing
    basic._ANSIBLE_ARGS = ['ansible']
    basic.ANNOTATE_ARGS = ['diff'] + basic._ANSIBLE

# Generated at 2022-06-20 21:32:00.388820
# Unit test for function set_selection
def test_set_selection():
    assert set_selection(module, "locales", "locales/default_environment_locale", "select", "fr_FR.UTF-8", False) == (0, "", "")

# Generated at 2022-06-20 21:32:11.598669
# Unit test for function set_selection
def test_set_selection():
    # Test error condition
    cmd = ['/bin/true']
    data = ' '.join(['kiwi-templates', 'unknown_question', 'string', 'value'])
    rc, msg, e = set_selection(cmd, data)
    assert False, "Didn't return error condition"

    # Test succesful set
    cmd = ['/usr/bin/debconf-set-selections']
    data = ' '.join(['kiwi-templates', 'kiwi_install_types', 'multiselect', 'vmx'])
    rc, msg, e = set_selection(cmd, data)
    assert rc == 0, "Failed to set selection"


# Generated at 2022-06-20 21:32:24.776181
# Unit test for function get_selections

# Generated at 2022-06-20 21:32:32.433949
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # test with string
    msg = "this is a test"
    rc, out, err = module.run_command('printf "%s" "%s"' % (msg, msg))

    if rc != 0:
        module.exit_json(msg=msg)

    selections = {}

    for line in out.splitlines():
        (key, value) = line.split(':', 1)
        selections[key.strip('*').strip()] = value.strip()

    module.exit_json(msg=selections)


# Generated at 2022-06-20 21:32:43.097631
# Unit test for function get_selections
def test_get_selections():
    #Create mock object for module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # Create the response the run_command() will return

# Generated at 2022-06-20 21:32:48.281126
# Unit test for function main

# Generated at 2022-06-20 21:32:57.655179
# Unit test for function main
def test_main():
    # FIXME: test set_selection, check_mode, diff_mode
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', default=False, choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    module.run_command = mock.Mock

# Generated at 2022-06-20 21:33:29.381336
# Unit test for function get_selections
def test_get_selections():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    def fake_run_command(cmd, data=None):
        """ fake run_command for testing get_selections method """
       

# Generated at 2022-06-20 21:33:38.810993
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys
    import shutil
    import tempfile
    import subprocess
    import types

    # create directory
    original = os.curdir
    tempdir = tempfile.mkdtemp()
    os.chdir(tempdir)

    # create test package
    cmd = "echo 'toto' > toto; dpkg-deb --build toto dpkg-deb -I dpkg-deb -c"
    subprocess.Popen(cmd, shell=True).wait()
    shutil.move('/'.join((tempdir,'toto.deb')), '/'.join((tempdir, 'toto.deb.stub')))

    # create test data

# Generated at 2022-06-20 21:33:51.972731
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(AnsibleModule(argument_spec=dict()), "tzdata") == {
        'tzdata/Areas': '',
        'tzdata/Zones/Europe': '',
        'tzdata/Zones/US': '',
    }
    assert get_selections(AnsibleModule(argument_spec=dict()), "man-db") == {
        'man-db/auto-update': 'false',
        'man-db/install-setuid': 'true',
    }
    assert get_selections(AnsibleModule(argument_spec=dict()), "openssh-client") == {
        'openssh-client/permit-user-environment': '',
    }

# Generated at 2022-06-20 21:34:04.240462
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    question = 'local/test'
    vtype = 'string'
    value = 'true'
    pkg = 'locales'


# Generated at 2022-06-20 21:34:10.934513
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule
    tmp_path = '/tmp/'
    module = AnsibleModule(argument_spec=dict(
            name=dict(type='str', aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', aliases=['type']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = 'locales'
    question = 'locales/default_environment_locale'
    vtype = 'select'
    value = 'fr_FR.UTF-8'

# Generated at 2022-06-20 21:34:20.545346
# Unit test for function set_selection
def test_set_selection():
    import os
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    os.environ['DEBIAN_FRONTEND'] = 'noninteractive'

    # Test debconf-set-selections binary
    assert module.get_bin_path('debconf-set-selections') is not None

    # Test debconf-get-selections binary
    assert module.get_bin_path('debconf-get-selections') is not None

    # Create debconf-set-selections command for testing
    setsel = module.get_bin_path('debconf-set-selections', True)
    cmd = [setsel]

    # Test run_command with data parameter
    rc, _, err = module.run_command(cmd, data="")

    # Ensure command returns with rc code 0
   

# Generated at 2022-06-20 21:34:26.875020
# Unit test for function get_selections
def test_get_selections():
    test_data = """debconf: delaying package configuration, since apt-utils is not installed
* tzdata/Zones/Europe: Europe/London
* tzdata/Zones/US: US/Eastern
* tzdata/Zones/UTC: UTC"""

    selections = get_selections(AnsibleModule, "tzdata")
    assert len(selections) == 3

    for line in test_data.splitlines():
        (key, value) = line.split(':', 1)
        key = key.strip('*').strip()
        value = value.strip()
        assert selections[key] == value

# Generated at 2022-06-20 21:34:42.954064
# Unit test for function set_selection
def test_set_selection():
  from ansible.module_utils.six import StringIO
  from ansible.module_utils._text import to_bytes
  import sys
  import os
  import mocker
  mock_module = mocker.Mocker()
  class MockAnsibleModule(object):
    def __init__(self):
      self.params = {
        'name': 'unittest',
        'question': 'question',
        'vtype': 'type',
        'value': 'value',
        'unseen': False
      }
      self.check_mode = False

# Generated at 2022-06-20 21:34:49.142400
# Unit test for function main
def test_main():
    import os
    import sys
    import StringIO
    import textwrap
    import shlex
    import platform
    import pytest
    import ansible.module_utils.basic
    import ansible.module_utils.action
    import ansible.module_utils._text

    def execute_module():
        curr_dir = os.path.dirname(os.path.realpath(__file__)) + "/"
        os.chdir(curr_dir)
        sys.path.append(curr_dir)

        test_args = {
            'name': 'nginx',
            'question': 'nginx/bin-path',
            'vtype': 'string',
            'value': '/usr/sbin',
            'unseen': False
        }

        test_args = ansible.module_utils.basic.DE

# Generated at 2022-06-20 21:34:59.280541
# Unit test for function set_selection
def test_set_selection():
    import subprocess
    from ansible.module_utils._text import to_bytes

    def subprocess_run(*popenargs, **kwargs):
        # Monkey patch subprocess.run instead of subprocess.Popen
        # so we can catch the data argument and assert it's as expected
        # This is a copy of set_selection called inside main()
        # with 'show_command' -C added at the end
        setsel = 'debconf-set-selections'
        cmd = [setsel]
        if unseen:
            cmd.append('-u')

        if vtype == 'boolean':
            if value == 'True':
                value = 'true'
            elif value == 'False':
                value = 'false'
        data = ' '.join([pkg, question, vtype, value])


# Generated at 2022-06-20 21:35:41.975425
# Unit test for function main
def test_main():
    # Assert with no parameters that the module does not fail
    assert main()

# Generated at 2022-06-20 21:35:44.330846
# Unit test for function main
def test_main():
  """
  Test main function for class debconf
  """

if __name__ == '__main__':
  test_main()

# Generated at 2022-06-20 21:35:47.831143
# Unit test for function get_selections
def test_get_selections():
    data = get_selections('locales')
    assert data['locales/locales_to_be_generated'] == 'en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8'


# Generated at 2022-06-20 21:35:58.269765
# Unit test for function set_selection
def test_set_selection():
    # Execute command: debconf-set-selections -u <DATA>
    rc, out, err = set_selection(
        module=MockModule(),
        pkg='couchdb',
        question='couchdb/mode',
        vtype='select',
        value='single',
        unseen=True
    )

    # Execute command: debconf-set-selections <DATA>
    rc, out, err = set_selection(
        module=MockModule(),
        pkg='couchdb',
        question='couchdb/mode',
        vtype='select',
        value='single',
        unseen=False
    )

    # Execute command: debconf-set-selections -u <DATA>

# Generated at 2022-06-20 21:35:59.664648
# Unit test for function set_selection
def test_set_selection():
    assert set_selection(" ", " ", " ", " ", " ") == 0

# Generated at 2022-06-20 21:36:00.697116
# Unit test for function set_selection
def test_set_selection():
    assert set_selection() == 'something'

# Generated at 2022-06-20 21:36:10.772834
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.common.removed import removed_module
    from ansible.module_utils.common.system import System
    from ansible.module_utils.common.compat import subprocess
    System.run_command = subprocess.check_output
    System.run_command.returncode = 0
    System.run_command.stderr = ""
    System.distribution = "Debian"
    System.distribution_version = "9"
    subprocess.Popen.returncode = 0
    subprocess.Popen.stderr = ""
    removed_module("ansible.builtin.Debconf")

    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()

    assert pytest_wrapped_e.type == SystemExit

# Generated at 2022-06-20 21:36:26.728835
# Unit test for function main
def test_main():
    # Execute main with argument_spec and return
    # the result
    args = {
        'name': 'tzdata',
        'question': 'tzdata/Areas',
        'vtype': 'text',
        'value': 'Asia',
        'unseen': False,
    }
    result = main(args)
    assert result
    # Execute main with argument_spec and return
    # the result
    args = {
        'name': 'tzdata',
        'question': 'tzdata/Zones/Asia',
        'vtype': 'text',
        'value': 'Kuala_Lumpur',
        'unseen': False,
    }
    result = main(args)
    assert result
    # Execute main with argument_spec and return
    # the result

# Generated at 2022-06-20 21:36:32.455890
# Unit test for function main
def test_main():
    '''
    Unit test for function main
    '''
    module = AnsibleModule(argument_spec={'name':{'required':True, 'type':'str'}})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.exit_json = MagicMock()

    main()

    module.exit_json.assert_called_once_with(changed=False, msg='', current={})

# Generated at 2022-06-20 21:36:48.178814
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True),
            question=dict(type='str'),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str'),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = module.params["name"]
    question = module.params["question"]
    vtype = module.params["vtype"]
    value = module.params["value"]
    unseen = module.params["unseen"]



# Generated at 2022-06-20 21:38:36.077065
# Unit test for function get_selections
def test_get_selections():
    output = 'blah: blah blah\nfoo: bar'
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock(return_value=(0, output, ''))
    module.get_bin_path = Mock(return_value='/usr/bin/debconf-show')
    r = get_selections(module, 'tomcat6')
    assert r == {'foo': 'bar', 'blah': 'blah blah'}


# Generated at 2022-06-20 21:38:42.592504
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(argument_spec=dict(
        set_selection=dict(type='str', required=True),
    ))
    module.run_command = MagicMock(return_value=(0, "ok", ""))

    result = set_selection(module, "locales", "locales/default_environment_locale", "select", "fr_FR.UTF-8", False)
    assert result['rc'] == 0
    assert result['stdout'] == "ok"
    assert result['stderr'] == ""



# Generated at 2022-06-20 21:38:46.756648
# Unit test for function set_selection
def test_set_selection():
    assert set_selection(module, pkg, question, vtype, value, unseen) == False

# Generated at 2022-06-20 21:38:53.044359
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = 'locales'
    question = 'locales/locales_to_be_generated'

# Generated at 2022-06-20 21:38:59.633137
# Unit test for function set_selection
def test_set_selection():
    # If there is no log argument, it is set to false
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    cmd = [module.get_bin_path('debconf-set-selections', True)]

    fmodule = FakeModule(cmd)
    module.run_command(fmodule.args[0], **fmodule.kwargs)

    assert 'log' in fmodule.kwargs, "log argument not present"
    assert fmodule.kwargs.get('log') is False, "log argument not set to False"

# Generated at 2022-06-20 21:39:03.465539
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule
    setsel = module.get_bin_path('debconf-set-selections', True)
    cmd = [setsel]
    data = ' '.join([pkg, question, vtype, value])
    module.run_command(cmd, data=data)

# Generated at 2022-06-20 21:39:17.997647
# Unit test for function set_selection
def test_set_selection():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = module.params["name"]
    question = module.params["question"]
    vtype = module.params["vtype"]


# Generated at 2022-06-20 21:39:22.738080
# Unit test for function get_selections
def test_get_selections():
    pkg = 'tzdata'
    q = get_selections(pkg)
    assert q == {'tzdata/Areas': '', 'tzdata/Zones/UTC': '', 'tzdata/Zones/Etc': '', 'tzdata/Zones/Etc/GMT': '', 'tzdata/Zones/Etc/UTC': '', 'tzdata/Zones/Europe': '', 'tzdata/Zones/Europe/Andorra': '', 'tzdata/Zones/Europe/Vaduz': ''}

# Generated at 2022-06-20 21:39:24.793811
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(argument_spec={})
    selected = get_selections(module, "tzdata")
    assert type(selected) == dict
    assert "tzdata/Areas" in selected

# Generated at 2022-06-20 21:39:29.429438
# Unit test for function set_selection
def test_set_selection():
    # debconf-set-selections <test.debconf
    # test.debconf: locales locales/locales_to_be_generated multiselect en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8
    # test.debconf: locales locales/default_environment_locale select en_US.UTF-8
    # test.debconf: openssh-server openssh-server/permit-root-login boolean true
    pass