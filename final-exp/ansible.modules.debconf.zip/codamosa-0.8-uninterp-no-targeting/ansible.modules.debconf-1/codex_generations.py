

# Generated at 2022-06-20 21:30:09.458342
# Unit test for function main

# Generated at 2022-06-20 21:30:19.370868
# Unit test for function set_selection
def test_set_selection():
    import os
    import subprocess
    import tempfile

    test_setsel_path = tempfile.mkstemp('test_set_selection_')[1]

    # shell script returning 0 to indicate success
    with open(test_setsel_path, 'w') as test_setsel:
        test_setsel.write("""#!/usr/bin/env bash
set -ex
echo "Got: $@"
if [ "$@" == '-u test_pkg test_question test_vtype test_value' ]; then
    exit 0
else
    exit 1
fi
""")

    os.chmod(test_setsel_path, 0o777)

    # Mock debconf-set-selections script

# Generated at 2022-06-20 21:30:24.576592
# Unit test for function set_selection
def test_set_selection():
    set_selection("test", "test", "test", "test", "test", False)

# Generated at 2022-06-20 21:30:29.053322
# Unit test for function main
def test_main():
    test_data = {
        'package': 'package1',
        'question': 'question1',
        'vtype': 'select',
        'value': 'value1',
        'unseen': False
    }

    result = get_selections(test_data)
    assert result is not None, 'TODO: add test'

# Generated at 2022-06-20 21:30:39.515156
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    test_module = ActionModule(module.params, module.check_mode)
    test_module.run_command_environ_update = {}

    test_module.get_bin_path('debconf-set-selections')
    test_module.run_command.assert_called_with(test_module.run_command_environ_update, 'debconf-set-selections', check_rc=True)

    test_module.run_command.reset_mock()
    test_module.run_command.return_value = (0, '', '')

    test_module.set_selection(test_module, 'test_pkg', 'test_question', 'boolean', 'True', 'unseen')
    test_module.set_selection

# Generated at 2022-06-20 21:30:45.120815
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    import sys
    module = __import__('ansible.modules.system.debconf', fromlist=['*'])
    module.AnsibleModule = ansible.module_utils.basic.AnsibleModule
    module.AnsibleModule = ansible.module_utils.basic.AnsibleModule
    module.exit_json = sys.exit
    module.fail_json = sys.exit
    module.main()
test_main()

# Generated at 2022-06-20 21:30:49.238912
# Unit test for function get_selections
def test_get_selections():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
        ),
    )
    test_module.params = {'name': 'tzdata'}
    selections = get_selections(test_module, test_module.params['name'])
    assert selections
    assert len(selections) > 0



# Generated at 2022-06-20 21:30:54.120509
# Unit test for function get_selections
def test_get_selections():
    class Module(object):
        def run_command(self, command, data = ''):
            entries = {
                "tzdata tzdata/Areas select Europe": "tzdata tzdata/Areas select Europe",
                "tzdata tzdata/Zones/Europe select Paris": "tzdata tzdata/Zones/Europe select Paris"
            }
            return 0, entries[command], ''

    module = Module()
    assert get_selections(module, "tzdata") == {'tzdata/Zones/Europe': 'select Paris', 'tzdata/Areas': 'select Europe'}

# Generated at 2022-06-20 21:31:02.752774
# Unit test for function set_selection
def test_set_selection():
    pkg = "debconf_test_pkg"
    question = "debconf_test_question"
    vtype = "debconf_test_vtype"
    value = "debconf_test_value"
    unseen = "debconf_test_unseen"
    try:
        set_selection(pkg, question, vtype, value, unseen)
        assert False
    except AnsibleModule:
        assert True

# Generated at 2022-06-20 21:31:11.336535
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(argument_spec={})
    pkg = 'tzdata'
    rc, out, err = module.run_command('debconf-show ' + pkg)
    if rc != 0:
        assert False, 'failed to run debconf-show'
    selections = get_selections(module, pkg)
    assert out == '', 'debconf-show should not have generated output'
    assert selections['tzdata/Areas'] == 'Europe', 'bad tzdata/Areas value'
    assert selections['tzdata/Zones/Europe'] == 'Rome', 'bad tzdata/Zones/Europe value'

# Generated at 2022-06-20 21:31:23.600003
# Unit test for function main
def test_main():
    pkg = 'locales'
    question = 'locales/default_environment_locale'
    vtype = 'select'
    value = 'fr_FR.UTF-8'
    unseen = False
    main()
    main()
    main()

# Generated at 2022-06-20 21:31:30.769570
# Unit test for function get_selections
def test_get_selections():

    test_fixture = [
        {"name": "hello", "question": "no", "vtype": "string", "value": "no", "unseen": True},
        {"name": "hello", "question": "yes", "vtype": "string", "value": "yes", "unseen": True}
    ]

    m = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(required=False),
            vtype=dict(required=False, choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(required=False),
            unseen=dict(type='bool', default=False),
        ),
    )

# Generated at 2022-06-20 21:31:40.740534
# Unit test for function get_selections
def test_get_selections():
    # Testing on a clean system
    import debconf
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule
    pkg="tzdata"
    selections=debconf.get_selections("test_lib/test_data/"+pkg)
#    print("Selections data:\n"+str(selections))
    assert isinstance(selections, dict)
    assert len(selections) > 0
    assert "tzdata/Zones/Asia" in selections.keys()
    assert "tzdata/Zones/Africa" in selections.keys()
    assert selections["tzdata/Zones/Asia"] == "Asia"


# Generated at 2022-06-20 21:31:46.618996
# Unit test for function get_selections
def test_get_selections():
   from ansible.module_utils.basic import AnsibleModule
   module = AnsibleModule(argument_spec=dict(name=dict(type='str', required=True, aliases=['pkg']),))
   selections = get_selections(module, 'tzdata')

   if 'tzdata/Zones/UTC' not in selections:
      print("Unit test for function get_selections failed.")

# Generated at 2022-06-20 21:31:53.142744
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )
    pkg = "tzdata"

    rc, out, err = module.run_command("/usr/bin/debconf-show tzdata")
    if rc != 0:
        module.fail_json(msg=err)

    selections = {}

    for line in out.splitlines():
        (key, value) = line.split(':', 1)
        selections[key.strip('*').strip()] = value.strip()

    assert isinstance(get_selections(module, pkg), dict)

# Generated at 2022-06-20 21:32:02.621443
# Unit test for function get_selections
def test_get_selections():
    import json
    import unittest

    # Test empty response
    class TestEmptyResponse(unittest.TestCase):
        def test_get_selections(self):
            from ansible.module_utils.basic import AnsibleModule
            from ansible.module_utils.six import b
            # Test empty response
            test_module = AnsibleModule(argument_spec={})
            test_module.run_command = lambda *args, **kwargs: (0, b(''), b(''))
            self.assertEqual(get_selections(test_module, 'foo'), {})

    # Test successful response
    class TestSuccessfulResponse(unittest.TestCase):
        def test_get_selections(self):
            from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-20 21:32:12.072331
# Unit test for function main
def test_main():
    import sys
    import tempfile
    import shutil
    import os

    # Hack to add symlink of module to a fake 'ansible.builtin' package
    real_module = os.path.realpath(__file__)
    ret = os.path.split(os.path.dirname(real_module))
    ret = os.path.split(os.path.dirname(ret[0]))
    ret = os.path.split(os.path.dirname(ret[0]))
    module_dir = os.path.join(ret[0], 'lib', 'ansible', 'modules', 'cloud')
    if os.path.islink(module_dir):
        os.unlink(module_dir)

# Generated at 2022-06-20 21:32:24.583560
# Unit test for function main
def test_main():
    args = dict(
        name='tzdata',
        question='tzdata/Zones/Etc',
        vtype='select',
        value='UTC',
        unseen=True
    )

# Generated at 2022-06-20 21:32:33.686225
# Unit test for function get_selections
def test_get_selections():
    import unittest
    import collections
    
    class AnsibleModuleStub(object):
        def __init__(self,status,stdout,stderr):
            self.status  = status
            self.stdout = stdout
            self.stderr = stderr

        def run_command(self,cmd):
            return (self.status,self.stdout,self.stderr)
            
    class AnsibleModuleTestCase(unittest.TestCase):
        def setUp(self):
            self.status = 0
            self.stdout = "stdout"
            self.stderr = "stderr"

            self.am = AnsibleModuleStub(self.status,self.stdout,self.stderr)


# Generated at 2022-06-20 21:32:43.575899
# Unit test for function main
def test_main():
    from ansible.modules.system.debconf import main

    m = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-

# Generated at 2022-06-20 21:32:54.037184
# Unit test for function main
def test_main():
  main()

# Generated at 2022-06-20 21:32:59.924616
# Unit test for function set_selection
def test_set_selection():
    assert set_selection(
        module=None,
        pkg='test',
        question='test',
        vtype='password',
        value='1234',
        unseen=None
    ) == (0, '', '')

# Generated at 2022-06-20 21:33:00.541718
# Unit test for function get_selections
def test_get_selections():
    pass

# Generated at 2022-06-20 21:33:09.860350
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.pycompat24 import get_exception

    import platform
    import shutil
    import tempfile

    setsel = get_bin_path('debconf-set-selections')

    tmpdir = tempfile.mkdtemp()
    tmpname = tmpdir + "/ansible-set-selection"

    # create temp script
    path = shutil.which(setsel) or setsel
    script = """#!/bin/sh
echo "$@" >> %s
    """ % (tmpname)

    with open(path, 'w') as fil:
        fil.write(script)
        fil.close()


# Generated at 2022-06-20 21:33:23.110656
# Unit test for function get_selections
def test_get_selections():
    import json
    import debconf
    from io import StringIO
    from unittest.mock import patch

    with patch('debconf.Debconf') as mock_debconf:
        mock_debconf.side_effect = debconf.Debconf(
            frontend='noninteractive',
            read=StringIO('debconf-show: tzdata/Areas: Europe\r\n'
                          'debconf-show: tzdata/Zones/UTC: UTC\r\n'
                          'debconf-show: tzdata/Zones/Europe: Prague\r\n'
                          'debconf-show: tzdata/Zones/Africa: Casablanca\r\n')
        )
        selections = get_selections(None, 'tzdata')

# Generated at 2022-06-20 21:33:27.043380
# Unit test for function set_selection
def test_set_selection():
    assert set_selection(None, "package_name", "question_name", "type_name", "value", True)[2] == "No command passed to run"



# Generated at 2022-06-20 21:33:37.455752
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = 'tzdata'
    result = get_selections(module, pkg)

# Generated at 2022-06-20 21:33:42.189168
# Unit test for function main
def test_main():
    import json

    json_file = open('./test_main.json', 'r')
    result = json.load(json_file)
    for data in result:
        if data['in'] == 'name':
            assert data['out'] == 'tzdata'

# Generated at 2022-06-20 21:33:52.729158
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    # TODO: replace with a test pkg
    pkg = 'locales'
    check = get_selections(module, pkg)
    assert(dict(check))

# Generated at 2022-06-20 21:34:04.414159
# Unit test for function set_selection
def test_set_selection():
    module = MockAnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    rc = 0
    msg = 'Installation of the %s package was successful.' % pkg

# Generated at 2022-06-20 21:34:45.942609
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-20 21:35:00.381404
# Unit test for function main

# Generated at 2022-06-20 21:35:07.882444
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    # Here we fake the command line inputs that were normally parsed by the AnsibleModule object.
    # These are the valid inputs according to the module doc

# Generated at 2022-06-20 21:35:12.043107
# Unit test for function set_selection
def test_set_selection():
    class arguments:
        def __init__(self, name, question, vtype, value):
            self.name = name
            self.question = question
            self.vtype = vtype
            self.value = value

    class module:
        def __init__(self, params):
            self.params = params

        def fail_json(self, msg):
            assert False, msg

        def run_command(self, cmd, data=''):
            assert data.startswith(self.params.name)
            return 0, '', ''

    set_selection(module(arguments('test', 'question', 'string', 'value')), 'test', 'question', 'string', 'value', False)

# Generated at 2022-06-20 21:35:16.461116
# Unit test for function main
def test_main():
    try:
        from ansible.module_utils import basic
        from ansible.module_utils import action
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils._text import to_text
    except ImportError:
        from ansible.module_utils import basic
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils._text import to_text

    class AnsibleModuleMock(AnsibleModule):

        def _diff(self, diff_type, diff_options=None):
            return True

        @classmethod
        def no_log(cls, arg):
            return arg

        @property
        def _ansible_diff(self):
            return self._diff


# Generated at 2022-06-20 21:35:22.973328
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()
    module.run_command.return_value = 0, '', ''
    result = get_selections(module, 'tzdata')
    assert result == {}


# Generated at 2022-06-20 21:35:34.093109
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.ansible_release import __version__ as ansible_version

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    rc, out, err = set_selection

# Generated at 2022-06-20 21:35:46.946144
# Unit test for function set_selection
def test_set_selection():
    from unittest.mock import MagicMock, patch

    mock_module = MagicMock(
        params={
            'name': 'localepurge',
            'question': 'localepurge/nopurge',
            'vtype': 'multiselect',
            'value': 'en_US.UTF-8 UTF-8',
            'unseen': True,
        },
        run_command=MagicMock()
    )

    mock_module.get_bin_path = MagicMock()
    mock_module.get_bin_path.return_value = '/usr/bin/debconf-set-selections'

    mock_module.run_command.return_value = 0, 'ok', ''

# Generated at 2022-06-20 21:35:50.630501
# Unit test for function set_selection
def test_set_selection():

    test_module = type("module", (object,), {
        "run_command": run_command
    })

    my_module = test_module()

    test_case = {
        'pkg': 'locales',
        'question': 'locales/default_environment_locale',
        'vtype': 'select',
        'value': 'fr_FR.UTF-8',
        'unseen': False
    }

    rc, msg, err = set_selection(my_module, test_case['pkg'], test_case['question'], test_case['vtype'], test_case['value'], test_case['unseen'])
    assert rc == 0


# Generated at 2022-06-20 21:35:54.064673
# Unit test for function main
def test_main():
    # import sys
    # sys.stderr.write("Calling main()\n")
    # main()
    # print("Done")
    pass

# Generated at 2022-06-20 21:36:45.783857
# Unit test for function set_selection
def test_set_selection():
    import datetime
    import time

    # timeout setting
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=False,
    )

    pkg = 'tzdata'

# Generated at 2022-06-20 21:36:54.712001
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    expected = {'tzconfig/convert': 'true', 'tzdata/Zones/Europe': 'Europe/Berlin'}


# Generated at 2022-06-20 21:37:04.722366
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.six import b
    # import module snippets
    from ansible.module_utils.basic import AnsibleModule

    # built in to ansible
    from ansible.module_utils.basic import get_bin_path
    from ansible.module_utils.basic import AnsibleFallbackNotFound
    from ansible.module_utils.basic import ModuleDeprecationWarning
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.pycompat24 import get_exception
    # import our own snippets
    from ansible.module_utils.basic import _AnsibleFall

# Generated at 2022-06-20 21:37:05.771321
# Unit test for function get_selections
def test_get_selections():
    assert get_selections('ansible.builtin', 'locales') is not None

# Generated at 2022-06-20 21:37:12.277947
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
     argument_spec=dict(
         name=dict(type='str', required=True, aliases=['pkg']),
         question=dict(type='str', aliases=['selection', 'setting']),
         vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
         value=dict(type='str', aliases=['answer']),
         unseen=dict(type='bool', default=False),
     ),
     required_together=(['question', 'vtype', 'value'],),
     supports_check_mode=True)

    # Test case number 1
    pkg = "tzdata"
    question = "tzdata/Zones/America"
    vtype = "select"

# Generated at 2022-06-20 21:37:28.437076
# Unit test for function main
def test_main():
    import tempfile

    def test_whitespace(s):
        return s and all(c.isspace() for c in s)

    test_args = {
        'name': 'tzdata',
        'question': 'tzdata/Areas',
        'vtype': 'select',
        'value': 'America',
        'unseen': False
    }

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    orig_list_selections = module.run_command
    orig_set_selections = module.run_command
    module.run_command = lambda *args, **kwargs: [0, '', '']

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-20 21:37:38.356450
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg'])
        )
    )

    name = 'locales'
    pkg = 'locales'
    out = """
    locales/default_environment_locale: en_US.UTF-8
    locales/locales_to_be_generated:
    """
    selections = get_selections(module, pkg, out)
    assert selections == {
        'locales/default_environment_locale': 'en_US.UTF-8',
        'locales/locales_to_be_generated': ''
    }

# Generated at 2022-06-20 21:37:40.479998
# Unit test for function main
def test_main():
    p1 = 'test'
    q1 = 'test'
    v1 = 'test'
    assert get_selections(p1, q1, v1) == True


# Generated at 2022-06-20 21:37:52.046435
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = module.params["name"]
    question = module.params["question"]
    vtype = module.params["vtype"]


# Generated at 2022-06-20 21:37:58.659284
# Unit test for function get_selections
def test_get_selections():
    import collections
    import sys

    # First test, pkg not installed.
    module = AnsibleModule(argument_spec={})
    pkg = "foo"
    sel = get_selections(module, pkg)
    assert len(sel) == 0

    # Second test, pkg installed.
    module = AnsibleModule(argument_spec={})
    pkg = "tzdata"
    sel = get_selections(module, pkg)
    assert len(sel) > 0
    assert type(sel) is collections.OrderedDict, "Test_get_selections: Selections are not an OrderedDict"