

# Generated at 2022-06-20 21:30:07.168628
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    mock_module = basic.AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

# Generated at 2022-06-20 21:30:07.756753
# Unit test for function get_selections
def test_get_selections():
    pass

# Generated at 2022-06-20 21:30:14.860909
# Unit test for function main
def test_main():
    import os
    import subprocess
    import tempfile

    (fd, tf) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('Hello')
    f.close()
    try:
        assert subprocess.call(['md5sum', tf]) == 0
    except:
        os.remove(tf)
        raise

    os.remove(tf)

# Generated at 2022-06-20 21:30:23.984992
# Unit test for function main
def test_main():
    import os
    import sys
    import subprocess
    import platform
    import tempfile
    import shutil

    # Note: we don't want to test actually calling debconf-set-selections
    # we want to test that the commands are formatted properly
    # this is a hack, but should work until we split module_utils.deb_packages
    for cmd in ['debconf-set-selections', 'debconf-show']:
        if cmd in os.environ['PATH']:
            os.environ['PATH'] = os.environ['PATH'].replace(cmd, sys.executable)

    class args:
        def __init__(self):
            self.name = 'testpackage'
            self.question = 'testquestion'
            self.vtype= 'string'
            self.value = 'testvalue'

    # create

# Generated at 2022-06-20 21:30:29.040195
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    get_selections(module, "oracle-java8-installer")


# Generated at 2022-06-20 21:30:45.165633
# Unit test for function get_selections

# Generated at 2022-06-20 21:30:45.588833
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 21:30:46.591128
# Unit test for function get_selections
def test_get_selections():
    get_selections(module, pkg)

# Generated at 2022-06-20 21:30:53.695073
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.common._collections_compat import Mapping
    tester = AnsibleModule(argument_spec=dict(name=dict(type='str'),
                         question=dict(type='str', aliases=['selection', 'setting']),
                         vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
                         value=dict(type='str', aliases=['answer']),
                         unseen=dict(type='bool', default=False),
                         ),
                         required_together=(['question', 'vtype', 'value'],),
                         supports_check_mode=True,
                         )
    pkg = 'pkg'
    question = 'question'
    vtype = 'vtype'
    value

# Generated at 2022-06-20 21:30:54.663219
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:31:12.772251
# Unit test for function get_selections
def test_get_selections():
    # Return a dictionary with the key/value pairs
    # in the test input.
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # Test input

# Generated at 2022-06-20 21:31:19.646168
# Unit test for function get_selections
def test_get_selections():
    import debconf
    debconf.run.return_value = (0, '* locales/default_environment_locale: fr_FR.UTF-8')
    assert debconf.get_selections(0, 'locales')[0]['locales/default_environment_locale'] == 'fr_FR.UTF-8'


# Generated at 2022-06-20 21:31:24.633626
# Unit test for function main
def test_main():
    # Test with simple input
    module_args = dict(
        name='test_package',
        question='test_question',
        vtype='boolean',
        value='test_value',
        unseen=True,
    )
    result = main(module_args)
    assert result
    assert result['changed']
    assert result['msg']
    assert result['current']
    assert result['previous']
    assert result['diff']

# Generated at 2022-06-20 21:31:29.719080
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(0,'','success'))
    test_selections = get_selections(module, pkg)
    assert test_selections == {'locales/default_environment_locale': '', 'locales/locales_to_be_generated': ''}


# Generated at 2022-06-20 21:31:40.310758
# Unit test for function get_selections
def test_get_selections():
    # from mock import patch, Mock, MagicMock
    from collections import namedtuple

    # Module = namedtuple('Module', ['run_command', 'get_bin_path'])
    # m = Module(Mock(), MagicMock())
    # m.run_command.return_value = (0, 'a:b\nc:d', '')
    # m.get_bin_path.return_value = '/bin/debconf-show'
    selections = get_selections(m, 'foo')


# Generated at 2022-06-20 21:31:50.991698
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common.dict_transformations import dict_merge
    from ansible.module_utils.common.dict_transformations import *
    import io
    import ast
    import sys
    stream = io.StringIO()
    sys.stdout = stream
    argv = sys.argv.copy()
    argv.append('-vvvv')
    argv.append('--check')
    argv.append('--diff')

# Generated at 2022-06-20 21:32:00.858946
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule()
    assert get_selections(module, "tzdata") == {'tzdata/Zones/Etc': 'UTC',
                                                'tzdata/Zones/America': 'Los_Angeles',
                                                'tzdata/Zones/Indian': 'Mauritius',
                                                'tzdata/Zones/Pacific': 'Honolulu',
                                                'tzdata/Zones/Antarctica': 'Rothera'}


# Generated at 2022-06-20 21:32:02.864653
# Unit test for function get_selections
def test_get_selections():
    pass


# Generated at 2022-06-20 21:32:13.531083
# Unit test for function get_selections
def test_get_selections():
    import sys
    import io

    my_module = AnsibleModule(name='debconf', argument_spec={'name': {'type': 'str', 'required': True, 'aliases': ['pkg']}})

    # Ensure that debconf-show tzdata returns acceptable output, if not print and return

# Generated at 2022-06-20 21:32:27.017738
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        name=dict(type='str', required=True, aliases=['pkg']),
        question=dict(type='str', aliases=['selection', 'setting']),
        vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
        value=dict(type='str', aliases=['answer']),
        unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    main()

# Generated at 2022-06-20 21:32:48.112709
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule({
        "name": "tzdata",
    })
    selections = get_selections(module, module.params["name"])
    assert selections

# Generated at 2022-06-20 21:32:57.565579
# Unit test for function main
def test_main():
    import debconf.client as client
    from ansible_module_debconf import main
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text

    package = "ansible-test-debconf"

    # Create a dummy debconf frontend cache for testing
    client.DebconfClient('test')

    # Build a data structure representing the parameters passed to main()
    params = dict(
        name     = package,
        question = 'test/foo',
        vtype    = 'string',
        value    = 'bar',
        unseen   = False,
    )

    # Build a data structure representing the AnsibleModule mock

# Generated at 2022-06-20 21:33:02.285432
# Unit test for function set_selection
def test_set_selection():
    pkg = ''
    question = ''
    vtype = ''
    value = ''
    unseen = False
    rc = 0
    rc, msg, e = set_selection(pkg, question, vtype, value, unseen)
    assert rc == 0

test_set_selection()

# Generated at 2022-06-20 21:33:11.291592
# Unit test for function main
def test_main():
    # setup module args, file doesn't exist so debconf should error
    module_args = {
      'name': 'this-is-a-test',
      'file': 'this-is-a-file-that-does-not-exist'
    }

    # setup module object
    module = AnsibleModule(
      argument_spec = module_args
    )

    # run the module
    rc, out, err = main()

    # ensure we got an error code
    assert rc != 0


# Generated at 2022-06-20 21:33:24.151377
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

# Generated at 2022-06-20 21:33:25.361482
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(argument_spec={})
    assert get_selections(module, 'tzdata')['tzdata/UseUTC'] == 'true'

# Unit tests for function set_selection

# Generated at 2022-06-20 21:33:35.694338
# Unit test for function get_selections
def test_get_selections():
    assert get_selections('tzdata') == 'tzdata/configure_other boolean false tzdata/zones/Asia select Asia/Kolkata tzdata/Zones/Etc select Etc/UTC tzdata/Zones/Etc select UTC'
    assert get_selections('nonexistent package') == 'debconf-show: failure opening /var/cache/debconf/config.dat: No such file or directory'
    assert get_selections('tzdata','tzdata/configure_other') == 'boolean false'


# Generated at 2022-06-20 21:33:50.190839
# Unit test for function get_selections
def test_get_selections():
    """ Test: get_selections. """
    class MockModule:
        """ Mock module. """
        def get_bin_path(self, binname, required):
            """ Mock get_bin_path, return true. """
            return True

        def run_command(self, command, data=None):
            """ Mock run_command, return false. """
            return False, '', ''

    class MockModuleTrue:
        """ Mock module. """
        def get_bin_path(self, binname, required):
            """ Mock get_bin_path, return true. """
            return True

        def run_command(self, command, data=None):
            """ Mock run_command, return true. """
            return True, '', ''

    class MockModuleError:
        """ Mock module. """

# Generated at 2022-06-20 21:34:02.273908
# Unit test for function set_selection
def test_set_selection():
    test_cmd = 'debconf-set-selections'
    pkg = 'pkg'
    question = 'question'
    vtype = 'vtype'
    value = 'value'
    args = [
        '-u',
        '%s %s %s %s' % (pkg, question, vtype, value)
    ]
    rc, out, err = set_selection(test_cmd, pkg, question, vtype, value, True)
    assert rc == 0, 'Exit status was %d, expected 0' % rc
    assert ' '.join(args) in out, 'Expected "%s" in "%s"' % (args, out)


# Generated at 2022-06-20 21:34:03.313545
# Unit test for function get_selections
def test_get_selections():
    pass


# Generated at 2022-06-20 21:34:49.548204
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec={'name': dict(required=True, type='str')})
    pkg = 'tzdata'

# Generated at 2022-06-20 21:34:59.534535
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = module.params["name"]
    question = "test_question"
    vtype = "test_vtype"
    value = "test_value"

    rc_expected, msg_

# Generated at 2022-06-20 21:35:01.320888
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(module, pkg) == {}



# Generated at 2022-06-20 21:35:05.907495
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(mod, 'tzdata') == {'tzdata/Areas': 'America', 'tzdata/Zones/America': 'Los_Angeles', 'tzdata/Zones/Atlantic': 'Reykjavik', 'tzdata/Zones/Etc': 'UTC', 'tzdata/Zones/Indian': 'Kolkata', 'tzdata/Zones/Pacific': 'Honolulu', 'tzdata/Zones/US': 'Los_Angeles', 'tzdata/Zones/UTC': ''}

# Generated at 2022-06-20 21:35:21.583994
# Unit test for function main
def test_main():
    import json
    import subprocess

    # 1. Prepare a temporary test file and add it to the test directory
    result = subprocess.run(
        args=['debconf-show',
            '-f', 'custom',
            'tzdata',
            ],
        check=True,
        universal_newlines=True,
        stdout=subprocess.PIPE,
    )
    with open('test/test_main.json', 'w') as f:
        f.write(result.stdout)

    # 2. Set the test file as UNITTEST_DEBIAN_DEBCONF_SHOW with environment variable
    import os
    old_env = os.environ.copy()

# Generated at 2022-06-20 21:35:31.239115
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-20 21:35:32.495092
# Unit test for function get_selections
def test_get_selections():
    get_selections(None,'tzdata')


# Generated at 2022-06-20 21:35:36.468184
# Unit test for function get_selections
def test_get_selections():
       from ansible.module_utils._text import to_text
       from ansible.module_utils.basic import AnsibleModule

       cmd = [module.get_bin_path('debconf-show', True), 'tzdata']
       rc, out, err = module.run_command(' '.join(cmd))

       assert rc == 0
       assert out.strip() == ''

# Generated at 2022-06-20 21:35:46.064720
# Unit test for function set_selection
def test_set_selection():
    filename = "test.deb"
    pkg = "test-pkg"
    question = "test-question"
    vtype = "select"
    value = "test-value"
    unseen = True

    # NOTE: if debconf-set-selections or debconf-get-selections is not in
    # the path this fails
    test_module = AnsibleModule(argument_spec=dict(path=dict(type='path')))
    set_selection(test_module, pkg, question, vtype, value, unseen)
    get_selections(test_module, pkg)

# Generated at 2022-06-20 21:35:57.136528
# Unit test for function set_selection
def test_set_selection():
    import os
    import subprocess
    from tempfile import NamedTemporaryFile
    from textwrap import dedent

    setsel = module.get_bin_path('debconf-set-selections', True)

    os.environ['DEBIAN_FRONTEND'] = 'noninteractive'

    def write_defaults_file(pkg, question, vtype, value):
        with NamedTemporaryFile(mode='w', delete=False) as f:
            f.write(dedent("""\
            {pkg} {question} {vtype} {value}
            """.format(pkg=pkg, question=question, vtype=vtype, value=value)))
            return f.name


# Generated at 2022-06-20 21:37:30.819881
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-20 21:37:31.590642
# Unit test for function get_selections
def test_get_selections():
    pass

# Generated at 2022-06-20 21:37:32.943408
# Unit test for function main
def test_main():
    assert main() is None


# Generated at 2022-06-20 21:37:35.615444
# Unit test for function main
def test_main():

    # Need to add additional tests
    # Tested only with 1.6
    pass

# Generated at 2022-06-20 21:37:50.679038
# Unit test for function set_selection

# Generated at 2022-06-20 21:37:57.664409
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    pkg = 'test'
    settings = [
        ( 'question1', 'value1', 'string' ),
        ( 'question2', 'true', 'boolean' ),
        ( 'question3', 'value3', 'string' ),
    ]
    for question, value, vtype in settings:
        rc, msg, e = set_selection(module, pkg, question, vtype, value, False)
        if rc:
            module.fail_json(msg=e)
    module.exit_json(msg="OK")

# Generated at 2022-06-20 21:38:13.097179
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = module.params["name"]
    question = module.params["question"]
    vtype = module.params["vtype"]


# Generated at 2022-06-20 21:38:27.728319
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = 'mysql-server'

# Generated at 2022-06-20 21:38:30.974108
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    pkg = 'tzdata'
    res = get_selections(module, pkg)
    assert res['tzdata/Zones/Africa/Cairo'] == 'Africa/Cairo'

# Generated at 2022-06-20 21:38:36.777683
# Unit test for function set_selection
def test_set_selection():
    from mock import patch

    class FakeModule():
        def __init__(self):
            self.fail_json = self.mock_fail_json
            self.params = {'unseen': False}

        def mock_fail_json(self, rc, msg):
            pass

        def get_bin_path(self, cmd, required):
            return '/bin/' + cmd

        def run_command(self, cmd, data=None):
            if cmd[0] == '/bin/debconf-set-selections':
                return (0, '', '')
            elif cmd[0] == '/bin/debconf-show':
                if data == 'testpackage':
                    return (1, 'testpackage: testquestion: testvtype', '')