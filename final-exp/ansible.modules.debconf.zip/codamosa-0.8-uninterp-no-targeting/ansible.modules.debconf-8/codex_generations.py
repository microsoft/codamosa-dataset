

# Generated at 2022-06-20 21:30:04.011610
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(argument_spec={})
    answer = get_selections(module, 'coreutils')
    return ans

# Generated at 2022-06-20 21:30:17.143235
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = module.params["name"]
    question = module.params["question"]
    vtype = module.params["vtype"]


# Generated at 2022-06-20 21:30:22.396218
# Unit test for function set_selection
def test_set_selection():

    import pty
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.debconf import set_selection

    module = AnsibleModule({})

    pty.spawn(["set_selection", "test_pkg", "test_question", "test_vtype", "test_value", "True"])

    set_selection(module, "test_pkg", "test_question", "test_vtype", "test_value", True)

# Generated at 2022-06-20 21:30:30.140017
# Unit test for function set_selection
def test_set_selection():
    # Testing all cases of value, using debconf to create test file
    (rc, out, err) = set_selection(module, 'ansible-debconf', 'ansible-debconf/test', 'string', 'test', False)
    assert rc == 0
    assert out == ''
    assert err == ''

    (rc, out, err) = set_selection(module, 'ansible-debconf', 'ansible-debconf/test', 'string', 'test2', False)
    assert rc == 0
    assert out == ''
    assert err == ''

    # Testing for 'seen' flag
    (rc, out, err) = set_selection(module, 'ansible-debconf', 'ansible-debconf/test', 'string', 'test2', True)
    assert rc == 0
    assert out == ''

# Generated at 2022-06-20 21:30:40.349209
# Unit test for function main
def test_main():
    from .mock_module import AnsibleModule
    import sys
    import os
    import json

    # Mock the options
    arguments = {'name': 'test_pkg', 'question': 'test_question', 'vtype': 'test_vtype', 'value': 'test_value', 'unseen': True}
    if sys.version_info[0] == 2:
        arguments = json.dumps(arguments)
    elif sys.version_info[0] == 3:
        arguments = json.dumps(arguments).encode('utf-8')

    # Mock the moudle input
    sys.argv = [sys.argv[0]]
    if sys.version_info[0] == 2:
        sys.argv.append(arguments)

# Generated at 2022-06-20 21:30:48.135120
# Unit test for function main
def test_main():
    # Module may use the copy command so need to import it
    import copy
    pkg = 'test_package'
    question = 'a_question'
    vtype = 'boolean'
    value = 'false'
    unseen = False
    rc = 0
    msg = "selection changed"
    e = "error"
    prev = {question: value}
    curr = {question: value}
    diff_dict = {'before': prev, 'after': curr}

    def run_command(self, cmd, data=None):
        # Mocked function run_command
        return (rc, msg, e)

    def get_bin_path(self, name, required=False):
        # Mocked function get_bin_path
        return "/usr/bin/debconf-show"


# Generated at 2022-06-20 21:30:51.443303
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(argument_spec=dict(name=dict(type='str', required=True)))
    pkg = "tzdata"
    selections = get_selections(module, pkg)
    assert "tzdata/Areas" in selections
    assert "tzdata/Areas/Africa" in selections


# Generated at 2022-06-20 21:30:56.006167
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    # TODO: write a test with a real module
    assert True

# Generated at 2022-06-20 21:31:00.038102
# Unit test for function get_selections
def test_get_selections():
    result = {}
    assert result == get_selections(mock, 'tzdata')
    assert result['tzdata/Zones/Europe'] == 'Europe/Paris'

# Generated at 2022-06-20 21:31:03.581681
# Unit test for function set_selection
def test_set_selection():
    if set_selection(module, pkg, question, vtype, value, unseen):
        assert True
    else:
        assert False

# Generated at 2022-06-20 21:31:21.186068
# Unit test for function set_selection
def test_set_selection():
    def get_selections(pkg):
        return {}

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda a, b: '/usr/bin/echo'
    module.run_command = lambda a, b=None: (0, a, '')
    set_selection(module, 'test_pkg', 'test_question', 'test_vtype', 'test_value', True)
    assert module.run_command.called

# Generated at 2022-06-20 21:31:28.732206
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
    )
    pkg = module.params["name"]
    assert get_selections(module, pkg)

# Generated at 2022-06-20 21:31:41.339988
# Unit test for function set_selection
def test_set_selection():
    import unittest
    import types

    class TestDebconf(unittest.TestCase):

        def setUp(self):

            class AnsibleModule:

                class RunCommand:

                    def __init__(self, args, data=None):
                        self.args = args
                        self.data = data

                    def __call__(self):
                        self.rc = self.args[0]
                        self.out = self.args[1]
                        self.err = self.args[2]
                        return (self.rc, self.out, self.err)

                def __init__(self, argument_spec, supports_check_mode, **kwargs):
                    self.argument_spec = argument_spec
                    self.supports_check_mode = supports_check_mode
                    self.params = kwargs


# Generated at 2022-06-20 21:31:51.784334
# Unit test for function main
def test_main():
    test_main_result = {
        'changed': True,
        'current': {'example': 'value'},
        'previous': {'example': ''},
        'diff': {'after': {'example': 'value'}, 'before': {'example': ''}},
    }
    import ansible
    ansible.utils.plugins.module_loader.load_plugins(['./ansible/plugins/modules'])
    test_main_module = ansible.utils.plugins.module_loader.get_module_path('debconf')

# Generated at 2022-06-20 21:31:59.625618
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    
    pkg = module.params["name"]
    question = module.params["question"]

# Generated at 2022-06-20 21:32:10.706808
# Unit test for function set_selection
def test_set_selection():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )


# Generated at 2022-06-20 21:32:16.197568
# Unit test for function set_selection
def test_set_selection():
    class MockModule:
        def __init__(self, return_code=0, stderr=''):
            self.params = {
                'path': '/usr/bin:/bin:/usr/sbin:/sbin',
                'no_log': False
            }
            self.return_code = return_code
            self.stderr = stderr

        def fail_json(self, **args):
            pass

        def get_bin_path(self, *args, **kwargs):
            return 'debconf-set-selections'

        def run_command(self, *args, **kwargs):
            return self.return_code, '', self.stderr

    def call_set_selection(module, *args, **kwargs):
        return set_selection(module, *args, **kwargs)

   

# Generated at 2022-06-20 21:32:30.207111
# Unit test for function set_selection
def test_set_selection():
    global module
    class TestModule(object):
        def __init__(self, params):
            self.params = params
            self.run_command_called = False
            self.run_command_data = None
        def get_bin_path(self, command, required):
            return command
        def run_command(self, cmd, data=None):
            self.run_command_called = True
            self.run_command_data = data
            self.run_command_cmd = cmd
            if self.params['fail']:
                return 1, '', 'Something failed'
            return 0, '', ''
    data = {'pkg': 'foo', 'question': 'bar', 'vtype': 'string',
            'value': 'baz', 'unseen': False, 'fail': False}

# Generated at 2022-06-20 21:32:31.040354
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:32:38.435607
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-20 21:32:55.363263
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-20 21:32:59.081854
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        support_check_mode=True,
    )

    # test success
    rc, msg, err = set_selection('system', 'question', 'boolean', 'true', False)
    assert rc == 0
    assert msg == ''
    assert err == ''

    #

# Generated at 2022-06-20 21:33:03.341012
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(argument_spec={}, check_invalid_arguments=False)
    rc, msg, e = set_selection(module, 'pkg', 'question', 'multiselect', 'value1 value2 value3', False)
    assert rc == 0
    assert msg == ''
    assert e == ''

# Generated at 2022-06-20 21:33:05.492931
# Unit test for function get_selections
def test_get_selections():
    pass

# Generated at 2022-06-20 21:33:13.843619
# Unit test for function main
def test_main():
    class Options(object):
      check_mode = False
      diff = False
      name = 'tzdata'
      question = None
      unseen = False
      vtype = None
      value = None

    class Module(object):
      # Mock class
      def __init__(self):
          self.options = Options()
          self.params = Options()
          self.params.name = 'tzdata'
          self.params.unseen = False
          self.params.value = None
          self.params.question = None
          self.params.vtype = None
          self.check_mode = False
          self.changed = False

      def get_bin_path(self, bin, **kwargs):
          return '/usr/bin/' + bin


# Generated at 2022-06-20 21:33:27.286750
# Unit test for function main
def test_main():
    # Set up arguments to be passed to main function
    args = dict(
        name=dict(type='str', required=True, aliases=['pkg']),
        question=dict(type='str', aliases=['selection', 'setting']),
        vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
        value=dict(type='str', aliases=['answer']),
        unseen=dict(type='bool', default=False),
    )
    # Set up mock environment
    results = dict(
                        changed=False,
                        msg='',
			current='hi',
			previous='hi',
			diff=''

                )
    # Call main function with mocked args and environment,

# Generated at 2022-06-20 21:33:33.455321
# Unit test for function get_selections
def test_get_selections():
    answer = {}
    answer['tzdata/Areas'] = 'Europe'
    answer['tzdata/Zones/Europe'] = 'Berlin'
    answer['tzdata/Zones/Europe/Berlin'] = ''
    answer['tzdata/Zones/UTC'] = 'UTC'
    answer['tzdata/Zones/UTC/UTC'] = ''

    assert answer == get_selections(None, 'tzdata')

# Generated at 2022-06-20 21:33:34.706028
# Unit test for function get_selections
def test_get_selections():
    assert get_selections("", "") == {}

# Generated at 2022-06-20 21:33:47.197313
# Unit test for function get_selections
def test_get_selections():
    # Test get_selections for the package 'dpkg'
    rc, out, err = get_selections("dpkg")
    assert rc == 0
    assert out.split("\n") == ['dpkg/architecture: amd64', 'dpkg/upgrade: 1',
                               'dpkg/upgrade/debian: 1', 'dpkg/upgrade/fink: 0', 'dpkg/upgrade/local: 0',
                               'dpkg/upgrade/slink: 1', 'dpkg/upgrade/sites:',
                               'dpkg/urge-upgrade: 0', 'dpkg/use-new-distributions: true']
    # Test get_selections for a packaging without any value
    rc, out, err = get_selections("mysql-server")
    assert rc == 0

# Generated at 2022-06-20 21:33:55.292778
# Unit test for function set_selection
def test_set_selection():
    import subprocess
    from ansible.module_utils.basic import AnsibleModule
    # 1. Test invalid vtype
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
    )
    pkg = module.params["name"]

# Generated at 2022-06-20 21:34:47.893724
# Unit test for function set_selection
def test_set_selection():
    """ test set_selection """
    assert set_selection(None, 'pkg', 'question', 'vtype', 'value', False) is False
    assert set_selection(None, 'pkg', 'question', 'vtype', 'value', False) is False
    assert set_selection(None, 'pkg', 'question', 'vtype', 'value', True) is False
    assert set_selection(None, 'pkg', 'question', 'vtype', 'value', True) is False
    assert set_selection(None, 'pkg', 'question', 'vtype', 'value', True) is False
    assert set_selection(None, 'pkg', 'question', 'vtype', 'value', False) is False


# Generated at 2022-06-20 21:34:58.710282
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # This is the 'module' object that we need to mock

# Generated at 2022-06-20 21:35:06.410013
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = 'my-package'
    question = 'my-package/question'
    vtype = 'select'
    value = 'my-package/value'


# Generated at 2022-06-20 21:35:22.148136
# Unit test for function set_selection
def test_set_selection():
    # Test debconf set-selection using the local function
    success = [0, 'debconf: DbDriver "passwords" warning: could not open /var/cache/debconf/passwords.dat: Permission denied\n']
    failure = [1, 'debconf: DbDriver "passwords" warning: could not open /var/cache/debconf/passwords.dat: Permission denied\n', 'debconf: DbDriver "passwords" warning: could not open /var/cache/debconf/passwords.dat: Permission denied', False]

    print("Successful debconf set-selection: test_set_selection()")
    assert success == set_selection(module, pkg, question, vtype, value, unseen)

    print("Unsuccessful debconf set-selection: test_set_selection()")
    assert failure == set_

# Generated at 2022-06-20 21:35:33.556762
# Unit test for function main
def test_main():
    import ansible.lib.module_utils.basic
    import ansible.module_utils.action
    import ansible.module_utils.debconf
    import sys
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping

# Generated at 2022-06-20 21:35:40.741990
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(argument_spec={})
    (rc, msg, e) = set_selection(module, "pkg", "question", "password", "value", "unseen")
    assert rc == 0
    assert msg == "debconf-set-selections -u 'pkg question password value'"

# Generated at 2022-06-20 21:35:49.662045
# Unit test for function set_selection
def test_set_selection():
    setsel = '/usr/bin/debconf-set-selections'
    pkg = 'toto_package'
    question = 'toto/tata'
    vtype = 'boolean'
    value = 'false'
    unseen = 'False'

    cmd = [setsel]
    if unseen:
        cmd.append('-u')

    if vtype == 'boolean':
        if value == 'True':
            value = 'true'
        elif value == 'False':
            value = 'false'
    data = ' '.join([pkg, question, vtype, value])

    return module.run_command(cmd, data=data)



# Generated at 2022-06-20 21:36:03.429135
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import unittest
    import ansible
    mock_module = ansible.module_utils.basic.AnsibleModule
    mock_get_bin_path = ansible.module_utils.basic.get_bin_path
    mock_run_command = ansible.module_utils.basic.AnsibleModule.run_command
    mock_fail_json = ansible.module_utils.basic.AnsibleModule.fail_json
    mock_exit_json = ansible.module_utils.basic.AnsibleModule.exit_json
    from ansible.module_utils.basic import _AnsibleModule
    from ansible.module_utils.debconf import main
    from ansible.module_utils.debconf import get_selections

# Generated at 2022-06-20 21:36:15.197162
# Unit test for function main
def test_main():

    # TODO: write unit test for get_selections
    def get_selections(module, pkg):
        selections = {'nginx/enable_dav_ext': 'false'}
        return selections

    # TODO: write unit test for set_selection
    def set_selection(module, pkg, question, vtype, value, unseen):
        return True


# Generated at 2022-06-20 21:36:26.358568
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    # 1st test
    pkg = 'testpkg'
    question = 'testquestion'
    vtype = 'select'
    value = 'testvalue'
    unseen = True

# Generated at 2022-06-20 21:37:49.662499
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 21:37:58.102272
# Unit test for function main
def test_main():
    import sys
    import argparse
    from ansible.module_utils.debconf import *

    if not hasattr(sys.modules["__main__"], "__file__"):
        print('Unit tests must be run as script. "python -m ansible.modules.extras.packaging.os.debconf"')
        sys.exit(1)

    # test empty parameters
    p = argparse.Namespace(name=None, question=None, vtype=None, value=None)
    assert main() == "", "empty params should return empty"

    # test parameters
    p = argparse.Namespace(name="tzdata", question="tzdata/Zones/Etc", vtype="select", value="UTC")
    assert main() == "", "empty params should return empty"

# Generated at 2022-06-20 21:38:13.290466
# Unit test for function get_selections
def test_get_selections():
  ''' Test for function get_selections '''
  module = AnsibleModule(argument_spec={}, supports_check_mode=False)
  pkg = 'openssh-server'

# Generated at 2022-06-20 21:38:27.941997
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.builtin.plugins.module_utils.debconf import set_selection

    module = AnsibleModule(argument_spec=dict(
        name=dict(type='str', required=True, aliases=['pkg']),
        question=dict(type='str', aliases=['selection', 'setting']),
        vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
        value=dict(type='str', aliases=['answer']),
        unseen=dict(type='bool', default=False),
    ))

# Generated at 2022-06-20 21:38:28.434880
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:38:32.876071
# Unit test for function set_selection
def test_set_selection():
    class ModuleMock():
        def run_command(self, x, data=None):
            return 0, '', ''
        def get_bin_path(self, x, y):
            return ''
    module = ModuleMock()

    rc, msg, err = set_selection(module, 'local', 'locales/default_environment_locale', 'select', 'A', 'B')
    assert rc == 0
    assert msg == ''
    assert err == ''

# Generated at 2022-06-20 21:38:34.764358
# Unit test for function set_selection
def test_set_selection():
    # TODO: unit testing is not working, for now using assert
    assert set_selection(module, pkg, question, vtype, value, unseen) == ' '

# Generated at 2022-06-20 21:38:43.982459
# Unit test for function set_selection
def test_set_selection():
    # Tests
    import unittest
    import os
    import tempfile
    import shutil
    import subprocess
    import datetime

    class TestSetSelection(unittest.TestCase):

        def setUp(self):
            # create a directory to be used to hold the profile
            self.path = tempfile.mkdtemp()
            self.pkg = 'ansible.test'
            self.question = 'foo/bar/baz'
            self.vtype = 'boolean'
            self.value = 'true'
            self.input_data = ' '.join([self.pkg, self.question, self.vtype, self.value])

        def tearDown(self):
            shutil.rmtree(self.path)

        # Result of calling the set_selection function

# Generated at 2022-06-20 21:38:51.602217
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = 'locales'
    question = 'locales/default_environment_locale'
    vtype = 'select'
   

# Generated at 2022-06-20 21:38:59.818806
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = 'country'
    question = 'locales/default_environment_locale'
    vtype = 'select'
    value