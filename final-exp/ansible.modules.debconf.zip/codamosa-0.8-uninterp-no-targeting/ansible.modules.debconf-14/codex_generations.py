

# Generated at 2022-06-20 21:30:12.432097
# Unit test for function set_selection
def test_set_selection():
    '''Returns whether the command is executed with success or not'''

    import subprocess
    import os
    import sys

    if sys.version_info[0] == 3:
        from io import StringIO
    elif sys.version_info[0] == 2:
        from cStringIO import StringIO


    # Define command to set selection for debconf-set-selection python package
    setsel = '/usr/bin/debconf-set-selections'
    pkg = 'python-debconf'
    cmd = [setsel, '-u', '-f', 'noninteractive']
    data = ' '.join([pkg, 'python-debconf/title',
                          'string', 'Title'])


# Generated at 2022-06-20 21:30:22.365122
# Unit test for function set_selection
def test_set_selection():
    # testing the set_selection function
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # Test one
    pkg = 'local'
    question = 'local/question'
    v

# Generated at 2022-06-20 21:30:23.097192
# Unit test for function get_selections
def test_get_selections():
    pass


# Generated at 2022-06-20 21:30:31.852957
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = 'hello'
    question

# Generated at 2022-06-20 21:30:32.572691
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-20 21:30:33.536348
# Unit test for function get_selections
def test_get_selections():
    import doctest
    doctest.testmod()

# Generated at 2022-06-20 21:30:35.042826
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()
    

# Generated at 2022-06-20 21:30:46.796623
# Unit test for function get_selections
def test_get_selections():
    def mock_run_command(cmd, data):
        assert cmd == '/usr/bin/debconf-show locales'
        return 0, 'locales/default_environment_locale: fr_FR.UTF-8\nlocales/locales_to_be_generated: en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8\n', ''
    module = AnsibleModule(argument_spec={})
    module.run_command = mock_run_command
    assert get_selections(module, 'locales') == {'locales/default_environment_locale': 'fr_FR.UTF-8', 'locales/locales_to_be_generated': 'en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8'}


# Generated at 2022-06-20 21:30:47.569780
# Unit test for function main
def test_main():
    print("TESTING")


# Generated at 2022-06-20 21:30:48.034590
# Unit test for function set_selection
def test_set_selection():
    assert True

# Generated at 2022-06-20 21:31:09.608563
# Unit test for function get_selections
def test_get_selections():
    pkg = 'tzdata'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str'),
            vtype=dict(type='str'),
            value=dict(type='str', aliases=['answer']),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    result = get_selections(module, pkg)
    print(result)

    assert result['tzdata/Areas'] == 'Europe'
    assert result['tzdata/Zones/Europe'] == 'Oslo'



# Generated at 2022-06-20 21:31:25.162174
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-20 21:31:31.689153
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.debconf import set_selection
    import os
    import shutil

    # Create tmp folder for "debconf" environment
    tmp_debconf = os.path.join(os.path.expanduser("~"), ".ansible_test")
    if os.path.isdir(tmp_debconf):
        shutil.rmtree(tmp_debconf)
    os.makedirs(tmp_debconf)
    os.environ["DEBIAN_FRONTEND"] = "noninteractive"
    os.makedirs(os.path.join(tmp_debconf, "debconf.conf"))


# Generated at 2022-06-20 21:31:41.292965
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    main()

# Generated at 2022-06-20 21:31:51.756608
# Unit test for function set_selection
def test_set_selection():
    class FakeModule():
        def __init__(self):
            self.params = {
                'name': 'puppet',
                'question': 'question',
                'vtype': 'vtype',
                'value': 'value',
                'unseen': False,
                'run_command': None
            }
            self.run_command = None
            
        def get_bin_path(self, path, check, opt_dirs=[]):
            return path

        def run_command(self, cmd, data=None):
            return self.run_command(cmd, data)

        def fail_json(self, msg=None, **kwargs):
            raise Exception(msg)

    module = FakeModule()

# Generated at 2022-06-20 21:31:59.625732
# Unit test for function main
def test_main():
    name = 'test-package'
    curr_question = 'test-question'
    curr_vtype = 'string'
    curr_value = 'test-value'
    question = 'test-question'
    vtype = 'string'
    value = 'test-value'
    unseen = False
    module = AnsibleModule(argument_spec=dict(name=dict(type='str', required=True, aliases=['pkg']), question=dict(type='str', aliases=['selection', 'setting']), vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']), value=dict(type='str', aliases=['answer']), unseen=dict(type='bool', default=False),))
    pkg

# Generated at 2022-06-20 21:32:03.645872
# Unit test for function get_selections
def test_get_selections():
    print("Tested in module test")
    # TODO: test get_selections function
    # get_selections()


# Generated at 2022-06-20 21:32:13.806739
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.debconf import (get_selections, set_selection, main)
    from ansible.module_utils.common.collections import ImmutableDict
    import json
    import pytest
    import sys

    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    def setUpModule():
        basic._ANSIBLE_ARGS = to_bytes(ImmutableDict(tags={'__ansible_unittest_skip_other_calls__': False}, connection='local'))

# Generated at 2022-06-20 21:32:29.093956
# Unit test for function get_selections
def test_get_selections():
    # Set up environment for unit test
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = 'locales'
    question = 'locales/default_environment_locale'


# Generated at 2022-06-20 21:32:33.935953
# Unit test for function set_selection
def test_set_selection():
    # Test if function set_selection can set a value correctly
    assert set_selection('test-package', 'test-selection', 'test-type', 'test-value') == 0
    # Test if function set_selection can fail setting a value
    assert set_selection('test-package', 'test-selection', 'test-type', 'test-value-fail') == 1

# Generated at 2022-06-20 21:32:50.433429
# Unit test for function set_selection
def test_set_selection():
    print('TODO')

# Generated at 2022-06-20 21:32:52.542566
# Unit test for function set_selection
def test_set_selection():
    set_selection(
        module,
        'foo',
        'question',
        'string',
        'answer',
        False
        )

# Generated at 2022-06-20 21:32:59.665921
# Unit test for function main
def test_main():
    # try with name = locales
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )


    pkg = "locales"
    question = "locales/default_environment_locale"

# Generated at 2022-06-20 21:33:08.621176
# Unit test for function get_selections
def test_get_selections():
    testmodule = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
        ),
    )
    pkg = "tzdata"
    selections = get_selections(testmodule, pkg)

# Generated at 2022-06-20 21:33:16.139730
# Unit test for function set_selection
def test_set_selection():
    import subprocess

    # test to ensure no errors
    assert set_selection('test-package', 'example-question', 'boolean', 'true', False) == None
    assert set_selection('test-package', 'example-question', 'boolean', 'false', False) == None
    assert set_selection('test-package', 'example-question', 'select', 'exmaple-value', False) == None
    assert set_selection('test-package', 'example-question', 'string', 'exmaple-value', False) == None
    # test to ensure any non-valid type errors
    try:
        set_selection('test-package', 'example-question', 'not-a-valid-type', 'exmaple-value', False)
    except subprocess.CalledProcessError as e:
        assert e.returncode == -1

# Generated at 2022-06-20 21:33:29.108321
# Unit test for function main
def test_main():
    print('\ntest_main\n')
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )


# Generated at 2022-06-20 21:33:34.099378
# Unit test for function main
def test_main():
    pkg = 'tzdata'
    question = 'tzdata/Areas'
    vtype = 'select'
    value = 'America'
    unseen = False
    main(pkg, question, vtype, value, unseen)

# Generated at 2022-06-20 21:33:36.320513
# Unit test for function set_selection
def test_set_selection():
    # some tests
    assert 'something' == 'something'
    assert set_selection('A', 'B', 'C', 'D', 'E') == 'F'

# Generated at 2022-06-20 21:33:41.633152
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    pkg = "tzdata"
    out = get_selections(module, pkg)
    assert isinstance(out, dict), "returns a dictionary"

# Generated at 2022-06-20 21:33:53.262470
# Unit test for function get_selections
def test_get_selections():
    """
    Test function get_selections from module debconf.py
    """
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )


# Generated at 2022-06-20 21:34:33.308103
# Unit test for function set_selection
def test_set_selection():
    rc = set_selection(module, pkg, question, vtype, value, unseen)
    assert rc == true

# Generated at 2022-06-20 21:34:46.184055
# Unit test for function get_selections
def test_get_selections():
    import subprocess
    import sys
    # Simple test for get_selections function
    # Load the module and then query for any package installed with debconf-show.
    module = AnsibleModule(argument_spec={'name': {'type': 'str', 'required': True, 'aliases': ['pkg']}})
    # Only adminutils is installed on ansible test image at the time of writing.
    pkg = "adminutils"
    cmd = [module.get_bin_path('debconf-show', True), pkg]
    rc, out, err = module.run_command(' '.join(cmd))
    if rc != 0:
        module.fail_json(msg=err)
    # In a reference system output looks like:
    # adminutils:adminutils/install-setuid-programs boolean true
    # adminutils:admin

# Generated at 2022-06-20 21:34:46.789760
# Unit test for function set_selection
def test_set_selection():
    pass

# Generated at 2022-06-20 21:34:58.050996
# Unit test for function main
def test_main():
    import re
    import sys
    import os
    import getpass
    import subprocess

    # Save current working directory and change to the directory where
    # test_debconf.py is located. The 'tests' directory is assumed to be a
    # subdirectory of current working directory.
    my_cwd = os.getcwd()
    os.chdir(os.path.join(my_cwd, 'tests'))
    test_file = os.path.join(os.path.split(__file__)[0], 'test_debconf.py')

    # Does this python interpretter support the 'unittest' module?
    try:
        import unittest
    except:
        print('\n*** Unit tests require unittest. ***\n')
        sys.exit(1)

    # Get the Python version
   

# Generated at 2022-06-20 21:35:05.818101
# Unit test for function main
def test_main():
    test_parms = dict(
                      name=dict(type='str', required=True, aliases=['pkg']),
                      question=dict(type='str', aliases=['selection', 'setting']),
                      vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
                      value=dict(type='str', aliases=['answer']),
                      unseen=dict(type='bool', default=False),
                      )

    results = AnsibleModule(
        argument_spec=test_parms,
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
        )


# Generated at 2022-06-20 21:35:09.703635
# Unit test for function main
def test_main():
    test_cases = [({'check_mode': True}, {}),
                  ({'check_mode': False}, {'changed': False, 'msg': '', 'current': {}}),
                  ]
    for argspec, expected in test_cases:
        assert main(**argspec) == expected
