

# Generated at 2022-06-20 21:30:11.320738
# Unit test for function get_selections
def test_get_selections():
    """Test get_selections function"""
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    selections = get_selections(module, 'tzdata')
    assert 'tzdata/Zones/Europe' in selections
    assert selections['tzdata/Zones/Europe'] == 'Berlin'

# Generated at 2022-06-20 21:30:23.329253
# Unit test for function main
def test_main():
    import sys
    import json
    import shutil
    import tempfile
    import traceback
    import ansible.module_utils
    import ansible.module_utils.basic
    import ansible.module_utils.common.json
    import ansible.module_utils.common.text
    import ansible.module_utils.common.dict

    # Ansible 2.8 imports
    try:
        from ansible.module_utils.common.removed import removed_module
    except ImportError:
        pass

    # python 2.6 needs a different mock location
    if sys.version_info[:2] == (2, 6):
        from ansible.module_utils.six import unittest2 as unittest
        from ansible.module_utils.six.moves import builtins

# Generated at 2022-06-20 21:30:31.879516
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.debconf import (
        get_selections,
        set_selection
    )


# Generated at 2022-06-20 21:30:46.062319
# Unit test for function main
def test_main():
    my_input = dict(name='localepurge',question='localepurge/keep_all_locales',vtype='boolean',value='true')
    my_module = AnsibleModule(argument_spec=dict(name=dict(type='str', required=True, aliases=['pkg']),question=dict(type='str', aliases=['selection', 'setting']),vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),value=dict(type='str', aliases=['answer']),unseen=dict(type='bool', default=False),),required_together=(['question', 'vtype', 'value'],),supports_check_mode=True,)
    my_module.params = my_input


# Generated at 2022-06-20 21:30:51.664294
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
        )
    )

    # test with a fake package
    pkg = 'fake_pkg'
    cmd = [module.get_bin_path('debconf-show', True), pkg]
    rc, out, err = module.run_command(' '.join(cmd))
    assert rc == 0
    selections = get_selections(module, pkg)
    assert pkg in selections and selections[pkg] == pkg

# Generated at 2022-06-20 21:31:05.157781
# Unit test for function set_selection
def test_set_selection():
    # Tests
    def set_selection_default():
        assert set_selection(module, pkg, question, vtype, value, unseen)

    def set_selection_no_unseen():
        assert set_selection(module, pkg, question, vtype, value, unseen)

    # Parameters
    pkg = 'package'
    question = 'question'
    vtype = 'select'
    value = 'answer'
    unseen = False

    # module
    module = AnsibleModule()

    # Tests
    set_selection_default()
    assert set_selection_default() == set_selection_no_unseen()



# Generated at 2022-06-20 21:31:16.542054
# Unit test for function get_selections
def test_get_selections():
    # Test case 1
    class module():
        def get_bin_path(self, path, required):
            return '/usr/bin/debconf-show'
        def run_command(self, parameter):
            return 0, 'debconf-show \n' \
                      '* locales\n' \
                      'locales/default_environment_locale\tselect\tfr_FR.UTF-8\n' \
                      'locales/locales_to_be_generated\tmultiselect\ten_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8\n', ''

    module = module()

# Generated at 2022-06-20 21:31:25.518365
# Unit test for function main
def test_main():
    pkg = 'tzdata'
    question = 'foo/bar'
    vtype = 'string'
    value = 'foo'
    unseen = False

    class DummyModule:
        class DummyModuleResult:
            def __init__(self, changed=False, msg='', current=None, previous=None, diff=None):
                self.changed = changed
                self.msg = msg
                self.current = current
                self.previous = previous
                self.diff = diff

        def __init__(self, params={}):
            self.params = params
            self.fail_json = lambda msg: 1
            self.exit_json = lambda changed=False, msg='', current=None, previous=None, diff=None: DummyModuleResult(changed, msg, current, previous, diff)
            self.get_bin_

# Generated at 2022-06-20 21:31:27.934869
# Unit test for function get_selections
def test_get_selections():
    selections = get_selections(module, 'tzdata')

    assert 'tzdata/Zones/UTC' in selections
    assert selections['tzdata/Zones/UTC'] == 'true'


# Generated at 2022-06-20 21:31:40.864966
# Unit test for function set_selection
def test_set_selection():
    import mock
    import json

    tempdir = tempfile.mkdtemp()
    test_file = '%s/test_file' % tempdir

    # Test that we do not get an error
    for command, rc, out, err, data in [
        ('echo "test_pkg test_question test_vtype test_value" | debconf-set-selections', 0, '', '', 'test_pkg test_question test_vtype test_value'),
        ('echo "test_pkg test_question test_vtype test_value" | debconf-set-selections -u', 0, '', '', 'test_pkg test_question test_vtype test_value'),
    ]:

        m_run_command = mock.Mock(return_value=(rc, '', ''))

# Generated at 2022-06-20 21:31:57.809361
# Unit test for function main
def test_main():
    import lib.ansible_test
    test_obj = lib.ansible_test.AnsibleTest(
        module_name = 'debconf',
        module_args = '''name=dummy question=dummy/question vtype=string value=yes''',
        module_kwargs = '''action=set''',
        task_action = '''get''',
        task_args = '''path=/''',
        task_kwargs = '''permissions=rwx''',
        task_supports_check_mode = True
    )
    result = test_obj.run_test()
    assert result['msg'] == 'could not find package that provides debconf-utils'
    assert result['failed']


# Generated at 2022-06-20 21:32:11.598216
# Unit test for function set_selection
def test_set_selection():
    import subprocess
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = 'test_pkg'
    question = 'test_question'
    vtype = 'string'

# Generated at 2022-06-20 21:32:24.136090
# Unit test for function set_selection
def test_set_selection():
    import shutil
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class TestAnsibleModule(basic.AnsibleModule):
        """We're only overriding a few functions here, but we still need
           to be an AnsibleModule so we can consume all their logic.
           """
        def __init__(self, *args, **kwargs):
            super(self.__class__, self).__init__(*args, **kwargs)
            self._ansible_selinux_special_fs = None

        def get_bin_path(self, *args, **kwargs):
            return shutil.which('true')

        def run_command(self, *args, **kwargs):
            return

# Generated at 2022-06-20 21:32:31.992955
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-20 21:32:42.733689
# Unit test for function set_selection
def test_set_selection():
    # Set variables
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
        )
    )
    pkg = "test-package"
    question = "test-question"
    vtype = "string"
    value = "test-value"
    unseen = False

    # TODO: check if all variables are already set
    # TODO: check if running as root

    # Run the function

# Generated at 2022-06-20 21:32:52.545186
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg'])
        )
    )
    expected_selections = {'tzdata/Areas': 'Europe',
                           'tzdata/Zones/Europe': 'Belgium'}
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='')
    selections = get_selections(module, 'tzdata')
    assert selections == expected_selections


# Generated at 2022-06-20 21:33:04.752504
# Unit test for function set_selection
def test_set_selection():
    argv = [
        'ansible-test',
        'debconf',
        '/etc/ansible/roles/test_debconf/tasks/main.yml',
        './library'
    ]

# Generated at 2022-06-20 21:33:13.640804
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False)
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True
    )


# Generated at 2022-06-20 21:33:27.222949
# Unit test for function get_selections
def test_get_selections():
    result = get_selections(test_module,test_package)

# Generated at 2022-06-20 21:33:28.721186
# Unit test for function set_selection
def test_set_selection():
    set_selection(module, pkg, question, vtype, value, unseen)

# Generated at 2022-06-20 21:33:54.352097
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    from ansible.module_utils.basic import AnsibleModule

    module.exit_json = exit_json

# Generated at 2022-06-20 21:34:01.253289
# Unit test for function set_selection
def test_set_selection():
    setsel = module.get_bin_path('debconf-set-selections', True)
    cmd = [setsel]
    if unseen:
        cmd.append('-u')

    if vtype == 'boolean':
        if value == 'True':
            value = 'true'
        elif value == 'False':
            value = 'false'
    data = ' '.join([pkg, question, vtype, value])

    return module.run_command(cmd, data=data)

# Generated at 2022-06-20 21:34:14.045930
# Unit test for function set_selection
def test_set_selection():
    from ansible.modules.system.debconf import set_selection
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule()
    m.get_bin_path = lambda x: x
    pkg = "locales"
    question = "locales/default_environment_locale"
    vtype = "select"
    value = "fr_FR.UTF-8"
    unseen = False
    rc, msg, e = set_selection(m, pkg, question, vtype, value, unseen)
    assert rc == 0
    assert msg == ""
    assert e == ""


# Generated at 2022-06-20 21:34:19.336694
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule

    test_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    test_module.run_command = run_command_wrapper

    set_selection(test_module, 'locales', 'locales/locales_to_be_generated', 'multiselect', 'en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8', False)

# Generated at 2022-06-20 21:34:28.629384
# Unit test for function get_selections
def test_get_selections():
    import os
    import tempfile
    from ansible.utils.path import makedirs_safe

    test_file_name = 'test_debconf_show.txt'
    test_file_path = os.path.join(tempfile.mkdtemp(prefix='ansible_test_debconf_'), test_file_name)

# Generated at 2022-06-20 21:34:31.643949
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(None, 'locales') == {'locales/default_environment_locale': 'en_US.UTF-8',
                                               'locales/locales_to_be_generated': '',
                                               'passwd/user-password': '',
                                               'passwd/user-password-again': ''}


# Generated at 2022-06-20 21:34:45.527027
# Unit test for function main
def test_main():
    # From bin/ansible-doc ansible.builtin.debconf
    test_str = dict(
        name='localepurge',
        question='localepurge/nopurge',
        value="en en_US en_US.UTF-8",
        vtype="multiselect",
        unseen=False
    )

    # From bin/ansible-doc ansible.builtin.debconf
    test_str_1 = dict(
        name='locales',
        question='locales/default_environment_locale',
        value='fr_FR.UTF-8',
        vtype="select",
        unseen=False
    )

    # From bin/ansible-doc ansible.builtin.debconf

# Generated at 2022-06-20 21:34:54.689080
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.basic import AnsibleModule

    import os
    os.environ['DEBIAN_FRONTEND'] = 'noninteractive'

    pkg = 'zsh'
    module = AnsibleModule(argument_spec=dict(name=dict(type='str', required=True)))
    selections = get_selections(module, pkg)

    assert(len(selections) > 0)
    assert('zsh/first_run' in selections)


# Generated at 2022-06-20 21:35:04.269767
# Unit test for function get_selections
def test_get_selections():
    import sys
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    test_value_1 = '''* locales/default_environment_locale: en_US.UTF-8
* locales/locales_to_be_generated: en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8'''
    test_value_2 = '''* locales/default_environment_locale: "en_US.UTF-8"
* locales/locales_to_be_generated: "en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8"'''

# Generated at 2022-06-20 21:35:19.619877
# Unit test for function main
def test_main():
    pkg = "tzdata"
    question = "tzdata/Zones/Asia"
    vtype = "select"
    value = "Tokyo"
    unseen = False

# Generated at 2022-06-20 21:36:04.134624
# Unit test for function set_selection
def test_set_selection():
    import os
    import tempfile
    debconf_file = tempfile.NamedTemporaryFile(mode="a", delete=False)
    debconf_file.close()
    debconf_file_path = debconf_file.name
    # os.unlink is used instead of debconf_file.unlink because the file
    # is still opened.
    os.unlink(debconf_file_path)
    os.environ['DEBIAN_FRONTEND'] = 'passive'
    pkg = 'python'
    question = 'junk/setting1'
    vtype = 'select'
    value = '"junk answer1"'
    unseen = False
    rc, msg, e = set_selection(module, pkg, question, vtype, value, unseen)
    assert(rc == 0)
    rc,

# Generated at 2022-06-20 21:36:15.228680
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # Test value that doesn't exist
    pkg = "test-package"
    question = "test-question"

# Generated at 2022-06-20 21:36:28.360837
# Unit test for function set_selection
def test_set_selection():
    from random import random
    from mock import patch
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
        ),
        required_together=(['question', 'vtype', 'value'],),
    )


# Generated at 2022-06-20 21:36:35.410819
# Unit test for function get_selections
def test_get_selections():
    # Create a fake module, since the actual module calls exit()
    class FakeModule():
        def __init__(self, params):
            self.params = params
            self.exit_json = lambda x: None
            self.fail_json = lambda x: None
            self.run_command = lambda x: (0, 'fake output', '')
        def get_bin_path(self, name, required):
            return 'fake'

    pkg = 'tzdata'
    question = 'fake_question'

    # This is the expected deserialized output of
    # debconf-show tzdata

# Generated at 2022-06-20 21:36:49.265516
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = module.params["name"]
    question = module.params["question"]
    vtype = module.params["vtype"]
    value = module.params["value"]
    result = set

# Generated at 2022-06-20 21:36:49.934311
# Unit test for function set_selection
def test_set_selection():
    assert True

# Generated at 2022-06-20 21:37:05.113434
# Unit test for function set_selection
def test_set_selection():
    ''' If the debconf-set-selections command was executed correctly, then the
        exit code would be 0.
    '''
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(name='test_set_selection', argument_spec={'name': {'type': 'str', 'required': True, 'aliases': ['pkg']}, 'question': {'type': 'str', 'aliases': ['selection', 'setting']}, 'vtype': {'type': 'str', 'choices': ['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']}, 'value': {'type': 'str', 'aliases': ['answer']}, 'unseen': {'type': 'bool', 'default': False}})
    assert set_

# Generated at 2022-06-20 21:37:12.153877
# Unit test for function main
def test_main():
    import sys
    import os
    import unittest
    import uuid
    import xmlrpc.client
    import pytest
    import importlib
    from unittest.mock import patch
    from ansible.module_utils.basic import AnsibleModule, _load_params

    importlib.reload(sys)
    tmpdir = os.path.realpath(
        os.path.join(os.path.realpath(os.path.dirname(__file__)), '../../../tests/tmp'))

    _load_params()

    @pytest.mark.skipif(sys.version_info < (3, 0), reason="requires python3")
    class TestMain(unittest.TestCase):
        '''Unit test for Ansible module: ansible.modules.packaging.language.debconf.main'''

# Generated at 2022-06-20 21:37:28.216555
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils._text import to_bytes
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = "test_pkg"

# Generated at 2022-06-20 21:37:39.553673
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.common._collections_compat import Mapping
    import json
    import io

    # Read in expected test output
    with io.open('/vagrant/tests/debconf_selections.txt', 'r', encoding='utf-8') as f:
        test = json.loads(f.read(), encoding='utf-8')

    # Ensure output has expected format
    assert isinstance(test, Mapping)

    # Ensure output has expected key/values
    assert test['tzdata']
    assert test['tzdata']['tzdata/Areas'] == 'Europe'
    assert test['tzdata']['tzdata/Zones/Europe'] == 'Berlin'
    assert test['tzdata']['tzdata/Zones/Europe/Berlin'] == ''

    # Verify outputs match
    assert test

# Generated at 2022-06-20 21:39:21.059298
# Unit test for function set_selection
def test_set_selection():
    assert set_selection() == ()


# Generated at 2022-06-20 21:39:26.365348
# Unit test for function get_selections
def test_get_selections():
    import unittest
    import sys
    import ansible.module_utils.debconf as dc
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes

    class TestDebconf(unittest.TestCase):

        def fake_module_run_command(self, cmd, data=None):
            self.cmd = cmd
            self.data = data

            if PY3:
                self.out = to_bytes(self.out)

            return (0, self.out, '')


# Generated at 2022-06-20 21:39:40.257623
# Unit test for function get_selections
def test_get_selections():
    content_input = r'''
* locales/default_environment_locale: fr_FR.UTF-8
* locales/locales_to_be_generated: en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8
'''
    content_expected = {'locales/default_environment_locale': 'fr_FR.UTF-8',
                        'locales/locales_to_be_generated': 'en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8'}


# Generated at 2022-06-20 21:39:56.055514
# Unit test for function get_selections
def test_get_selections():
    import debconf
    debconf.runFrontEnd()
    db = debconf.Debconf()
    db.set('tzdata', 'tzdata/zones/Africa', 'Africa')
    db.set('tzdata', 'tzdata/zones/America', 'America')
    db.set('tzdata', 'tzdata/zones/Asia', 'Asia')
    db.set('tzdata', 'tzdata/zones/Atlantic', 'Atlantic')
    db.set('tzdata', 'tzdata/zones/Australia', 'Australia')
    db.set('tzdata', 'tzdata/zones/Europe', 'Europe')
    db.set('tzdata', 'tzdata/zones/Indian', 'Indian')
    db.set('tzdata', 'tzdata/zones/Pacific', 'Pacific')