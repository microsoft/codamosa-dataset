

# Generated at 2022-06-20 21:30:17.148604
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = module.params["name"]
    question = module.params["question"]
    vtype = module.params["vtype"]


# Generated at 2022-06-20 21:30:24.803812
# Unit test for function get_selections
def test_get_selections():
    # Test with valid input
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = "tzdata"
    selections = get_selections(module, pkg)

    assert selections

# Generated at 2022-06-20 21:30:27.069686
# Unit test for function get_selections
def test_get_selections():
    # results = get_selections(self, pkg)
    assert True


# Generated at 2022-06-20 21:30:38.554406
# Unit test for function set_selection
def test_set_selection():
    mock_module = Mock(check_mode=True,
                       params=dict(name='mocked_pkg',
                                   question='mocked_question',
                                   vtype='mocked_vtype',
                                   value='mocked_value',
                                   unseen=False))

    os_mock = Mock()
    module_fn = 'ansible.module_utils.basic.AnsibleModule'

# Generated at 2022-06-20 21:30:46.161746
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-20 21:30:53.712013
# Unit test for function main

# Generated at 2022-06-20 21:31:04.113847
# Unit test for function get_selections
def test_get_selections():
    assert get_selections('apt') == {
        'apt/force-confdef': 'false', 'apt/force-confold': 'false',
        'apt/show-upgraded': 'false', 'apt/purge': '0', 'apt/new': '',
        'apt/listchanges/show-install': 'false', 'apt/listchanges/which': 'backport',
        'apt/listchanges/confirm': 'false', 'apt/listchanges/download': '0',
        'apt/listchanges/bts': 'false', 'apt/listchanges/email': 'false',
        'apt/listchanges/suite': '', 'apt/listchanges/show-remove': 'false',
        'apt/listchanges/only-download': 'false', 'apt/listchanges/new': ''
    }

# Generated at 2022-06-20 21:31:15.548475
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = 'test_pkg'
    question = 'test_question'
    vtype = 'test_type'

# Generated at 2022-06-20 21:31:28.603497
# Unit test for function set_selection
def test_set_selection():
    display.display("Running test_set_selection")
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )
    rc, msg, e = set_selection(module, 'x', 'y', 'z', 'a')
    assert rc == 0
    rc, msg, e

# Generated at 2022-06-20 21:31:44.019892
# Unit test for function set_selection
def test_set_selection():
    """
    Test valid values of set_selection function
    """
    setsel = '/usr/bin/debconf-set-selections'
    pkg = 'tzdata'
    question = 'tzdata/Areas'
    vtype = 'select'
    value = 'America/Los_Angeles'

    # Test valid input
    cmd = [setsel, pkg, question, vtype, value]
    valid_result = [0, '', '']
    result = set_selection(setsel, pkg, question, vtype, value)
    assert result == valid_result

    # Test question without value
    question = ''
    cmd = [setsel, pkg, question, vtype, value]

# Generated at 2022-06-20 21:32:09.212757
# Unit test for function set_selection
def test_set_selection():
    import os
    import sys
    import tempfile
    import gzip
    import pytest
    import zipfile

    from ansible import errors
    from ansible.module_utils import basic
    from ansible.module_utils.debconf import set_selection

    # set up temporary file
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    tempfile_name = temp_file.name
    temp_file.close()

    temp_file_bin = tempfile.NamedTemporaryFile(delete=False)
    tempfile_name_bin = temp_file_bin.name
    temp_file_bin.close()

    # create a test module

# Generated at 2022-06-20 21:32:21.362988
# Unit test for function main
def test_main():
    import os
    # TODO: these tests don't really assert anything,
    #       need to change this to mock run_command and check value
    #       ot at least use a debconf fake package
    #
    #       For now just check it returns valid json
    #       and can be called w/o errors

# Generated at 2022-06-20 21:32:32.012381
# Unit test for function set_selection
def test_set_selection():
    class test_module():
        def __init__(self):
            self.changed = False
            self.warnings = []
        def fail_json(self, **kwargs):
            raise Exception(kwargs)
        def get_bin_path(self, cmd, required):
            return cmd
        def run_command(self, cmd, data=None):
            if isinstance(cmd, list):
                cmd = ' '.join(cmd)
            if cmd != "/usr/bin/debconf-set-selections":
                self.fail_json(msg="unexpected command " + cmd)
            if data != "tzdata tzdata/Areas select Europe":
                self.fail_json(msg="unexpected data " + data)
            return (0, "", "")
    m = test_module()
    rc, stdout,

# Generated at 2022-06-20 21:32:39.078588
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-20 21:32:52.836731
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = 'locales'
    question = 'locales/default_environment_locale'
    vtype = 'select'
   

# Generated at 2022-06-20 21:32:59.840798
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule()
    rc, msg, e = set_selection(module, 'localepurge', 'LOCALEPURGE_OPTIONS', 'string', '', False)
    assert rc == 0 and msg == ""
    rc, msg, e = set_selection(module, 'localepurge', 'LOCALEPURGE_OPTIONS', 'string', '', True)
    assert rc == 0 and msg == ""
    rc, msg, e = set_selection(module, 'localepurge', 'LOCALEPURGE_OPTIONS', 'string', '--all', False)
    assert rc == 0 and msg == ""
    rc, msg, e = set_selection(module, 'localepurge', 'LOCALEPURGE_OPTIONS', 'string', '--all', True)
    assert rc == 0

# Generated at 2022-06-20 21:33:09.229402
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = 'locales'
   

# Generated at 2022-06-20 21:33:10.974097
# Unit test for function get_selections
def test_get_selections():
    pass


# Generated at 2022-06-20 21:33:23.913944
# Unit test for function main
def test_main():
    import sys
    class AnsibleModule(object):
        def __init__(self, argument_spec, required_together, supports_check_mode, **kwargs):
            self.argument_spec = argument_spec
            self.required_together = required_together
            self.supports_check_mode = supports_check_mode
        def fail_json(self, msg, **kwargs):
            print(msg)
            print(kwargs)
            sys.exit()
        def exit_json(self, **kwargs):
            print(kwargs)
            sys.exit()
        def run_command(self, cmd, data=None):
            print('Running command:')
            print(cmd)
            if data:
                print('Data:')
                print(data)
            return 0, '', ''

# Generated at 2022-06-20 21:33:36.127034
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils import basic
    from ansible.module_utils.debconf import set_selection

    module = basic.AnsibleModule(argument_spec={'name': {'required': True, 'type': 'str', 'aliases': ['pkg']}, 'question': {'type': 'str', 'aliases': ['selection', 'setting']}, 'vtype': {'type': 'str', 'choices': ['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']}, 'value': {'type': 'str', 'aliases': ['answer']}, 'unseen': {'type': 'bool', 'default': False}})
    module.run_command = lambda cmd, data: (0, data, '')

    # This should not fail
    set

# Generated at 2022-06-20 21:34:04.214540
# Unit test for function set_selection
def test_set_selection():

    from ansible.module_utils.debconf import set_selection
    from ansible.module_utils.basic import AnsibleModule

    def dummy_run_command(cmd, data=None):
        print(cmd)
        print(data)
        return 0, "", ""

    def dummy_get_bin_path(cmd, required):
        return cmd

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
        ),
    )
    module.get_bin_path = dummy_get_bin_path
    module.run_command = dummy_run_command
    set_selection(module, "ntpdate", "ntpdate/ntpservers", "note", "font_color", False)

# Generated at 2022-06-20 21:34:12.332993
# Unit test for function set_selection
def test_set_selection():
    import sys
    import os
    import py
    import pytest

    #Remove sys.argv so Ansible module doesn't try to parse arguments,
    # and set sys.exit to throw an exception, so Ansible doesn't
    # exit prematurely.
    temp_args = sys.argv
    sys.argv = None
    sys.exit = lambda : sys.exit(_thread.exit())

    #Redirect stdout temporarily so we can test for specific output
    temp_stdout = sys.stdout
    sys.stdout = open('/tmp/temp_stdout', 'w')

    # Redirect stderr temporarily so we can test for specific output
    temp_stderr = sys.stderr
    sys.stderr = open('/tmp/temp_stderr', 'w')


    # Test debconf exception handling

# Generated at 2022-06-20 21:34:21.549052
# Unit test for function main
def test_main():
    # This is the parameter list that will be passed to the module
    # The unit test will call the module with the parameters below
    # and inspect the result.

    module_args = dict(
        name='tzdata',
        question='tzdata/Zones/Etc',
        vtype='multiselect',
        value='UTC',
        unseen=False
    )

    # Result from the module execution.
    result = dict(
        success=True,
        changed=True,
        msg='Success'
    )
    # Instantiate the module with mock arguments and result.
    # The params and result values are passed to the module.
    module = AnsibleModule(**module_args)
    module.exit_json = MagicMock(return_value=result)
    main()
    module.exit_json.assert_called_once_

# Generated at 2022-06-20 21:34:28.926619
# Unit test for function main
def test_main():
    args = dict(
        name="debconf",
        question="debconf/test",
        vtype='string',
        value='test',
    )
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
    )

# Generated at 2022-06-20 21:34:39.294726
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(argument_spec={})
    rc, out, err = get_selections(module, 'locales')
    assert not rc
    assert not err
    assert out
    assert isinstance(out, dict)
    assert 'locales/locales_to_be_generated' in out
    assert out['locales/locales_to_be_generated'] in ['en_US.UTF-8\nen_US.UTF-8', 'en_US.UTF-8 UTF-8']

# Generated at 2022-06-20 21:34:47.967219
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-20 21:34:58.805104
# Unit test for function main
def test_main():
    from ansible.module_utils import basic, arguments
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_text
    import tempfile
    import os
    import sys
    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.check_mode = kwargs.get('_ansible_check_mode', False)
        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')
        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

# Generated at 2022-06-20 21:35:05.755153
# Unit test for function get_selections
def test_get_selections():
    # Unit test for function get_selections
    # we have to do something similar to what ansible does
    import os
    import json
    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.basic import *
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils._text import to_text
    from ansible.module_utils.urls import *

    package = 'debconf'

    selections = get_selections(AnsibleModule(argument_spec={}), package)

    # we should have seen something
    assert selections



# Generated at 2022-06-20 21:35:08.367869
# Unit test for function get_selections

# Generated at 2022-06-20 21:35:23.231484
# Unit test for function set_selection
def test_set_selection():
    import tempfile
    import subprocess

    # Tests for the function set_selection with the value set to 42 and the vtype set to string   
    def test_value_set_to_42_and_vtype_set_to_string():
        print('\n>>> Testing set_selection with the value set to 42 and the vtype set to string')
        vtype = 'string'
        value = '42'
        question = 'Question1'
        pkg = 'package1'
        tmp_file = tempfile.NamedTemporaryFile(mode='w+t')
        test_set_selection_with_value_vtype_and_question(vtype=vtype, value=value, question=question, pkg=pkg, tmp_file=tmp_file)

    # Tests for the function set_selection with the value set to Hello World and

# Generated at 2022-06-20 21:36:09.839710
# Unit test for function get_selections
def test_get_selections():
    test = {
        '_ansible_no_log': False,
        '_ansible_verbosity': 0,
        'ansible_loop_var': 'item',
        'changed': False,
        'loop_control': {
            'label': 'item',
        },
        'name': 'tzdata',
        'playbook_dir': '/path/to/playbook',
    }


# Generated at 2022-06-20 21:36:25.916721
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.debconf import set_selection
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    test_data = '''testpackage testquestion boolean false
testpackage testquestion boolean true
testpackage testquestion boolean true
testpackage testquestion boolean false
testpackage testquestion boolean true
testpackage testquestion boolean false
testpackage testquestion boolean false
testpackage testquestion boolean false
testpackage testquestion boolean false
testpackage testquestion boolean false
testpackage testquestion boolean true
testpackage testquestion boolean true
testpackage testquestion boolean true
testpackage testquestion boolean true
testpackage testquestion boolean true
'''

# Generated at 2022-06-20 21:36:34.731743
# Unit test for function main
def test_main():
    import sys
    import module_utils # pylint: disable=unused-import
    module = AnsibleModule(argument_spec=dict(
        name=dict(type='str', required=True),
        question=dict(type='str'),
        vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
        value=dict(type='str'),
        unseen=dict(type='bool', default=False),
    ),
    required_together=(['question', 'vtype', 'value'],),
    supports_check_mode=True,)

    pkg = module.params["name"]
    question = module.params["question"]
    vtype = module.params["vtype"]

# Generated at 2022-06-20 21:36:49.035711
# Unit test for function set_selection
def test_set_selection():
    import os, tempfile
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg

# Generated at 2022-06-20 21:36:53.306116
# Unit test for function get_selections
def test_get_selections():
    from cStringIO import StringIO
    from ansible.modules.packaging.os import debconf

    module = object()
    module.run_command = lambda *_: (0, 'foo: bar', '')

    out = ''
    for k, v in debconf.get_selections(module, 'foo').items():
        out += "%s: %s\n" % (k, v)

    assert out == '''foo: bar\n'''

# Generated at 2022-06-20 21:37:02.531214
# Unit test for function set_selection
def test_set_selection():
    def mock_run_command(cmd, data=None):
        if data is None:
            print(e)
            return 1, '', e
        else:
            return 0, '', ''

    import mock
    module = mock.MagicMock()
    module.get_bin_path = mock.Mock(return_value='/usr/bin/debconf-set-selections')
    module.run_command = mock_run_command
    pkg = 'test_pkg'
    question = 'test_question'
    vtype = 'select'
    value = 'test_value'
    unseen = False
    rc, _, e = set_selection(module, pkg, question, vtype, value, unseen)
    assert rc == 0, e

# Generated at 2022-06-20 21:37:11.800789
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
        ),
        required_together=(['question', 'vtype', 'value'],),
    )

    pkg = "locales"
    question = "locales/locales_to_be_generated"
    vtype = "multiselect"

# Generated at 2022-06-20 21:37:27.831274
# Unit test for function set_selection
def test_set_selection():
    import subprocess
    from ansible.module_utils.basic import AnsibleModule
    path_to_bin = "/usr/bin"
    module = AnsibleModule({'yes': {'required': False, 'type': 'bool', 'default': False}})
    module.run_command = lambda cmd, data=None, check_rc=True: (0, '', '')
    module.get_bin_path = lambda cmd, required: "%s/%s" % (path_to_bin, cmd)
    # Test call with all options set
    set_selection(module, 'test-pkg', 'test-selection', 'test-type', 'test-value', True)
    call_args, _ = module.run_command.call_args

# Generated at 2022-06-20 21:37:28.451427
# Unit test for function get_selections
def test_get_selections():
    pass

# Generated at 2022-06-20 21:37:39.673133
# Unit test for function main
def test_main():
    from ansible.modules.system.debconf import main as debconf_main
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.compat import mock
    from ansible.module_utils.common.compat import raw_input
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six import StringIO
    import sys
    import unittest

    # Unittest for handling no input parameters
    class TestHandleNonSpecified(unittest.TestCase):
        def setUp(self):
            builtins.input = lambda _: ''
            builtins.raw_input = lambda _: ''


# Generated at 2022-06-20 21:39:40.796192
# Unit test for function main
def test_main():
    # 'value' is a required argument, but that causes difficulties with testing.
    # So here we create a mock module class directly and override the one argument
    # we need to run the test.
    class mockModule:
        def __init__(self, params):
            self.params = params

        def fail_json(self, **kwargs):
            raise Exception('fail_json')

        def run_command(self, cmd, **kwargs):
            if cmd[0].endswith('debconf-show'):
                # This is the call to retrieve the current value.
                if params['question'] in ['locales/default_environment_locale',
                                          'locales/locales_to_be_generated']:
                    return 0, '', ''
                else:
                    raise Exception('unexpected call to debconf-show')


# Generated at 2022-06-20 21:39:48.028201
# Unit test for function main
def test_main():
    import os
    import sys
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping, Sequence

    path = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(path)
    from module_utils.debconf import get_selections
    from module_utils.debconf import set_selection

    # Needs to be run with module_utils/debconf.py in same folder

# Generated at 2022-06-20 21:40:01.368977
# Unit test for function get_selections
def test_get_selections():
    import os

    module = AnsibleModule({}, supports_check_mode=True)
    selections = get_selections(module, 'tzdata')
    assert('tzdata/Areas' in selections)
    assert(os.path.exists(selections['tzdata/Areas']))
    assert(selections['tzdata/Zones/Europe'] == 'Amsterdam')
    assert(selections['tzdata/Zones/Africa'] == 'Algiers')
    assert(selections['tzdata/Zones/America'] == 'New_York')
    assert(selections['tzdata/Zones/Asia'] == 'Hong_Kong')
    assert(selections['tzdata/Zones/Canada'] == 'America/Toronto')
    assert(selections['tzdata/Zones/Etc'] == 'UTC')