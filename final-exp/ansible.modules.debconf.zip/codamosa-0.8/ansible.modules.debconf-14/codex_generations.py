

# Generated at 2022-06-11 06:49:32.546966
# Unit test for function set_selection
def test_set_selection():
    result1 = set_selection(module, pkg, question, vtype, value, unseen)
    assert result1 == 0

# Generated at 2022-06-11 06:49:35.516582
# Unit test for function get_selections
def test_get_selections():
    mock_module = AnsibleModule({'name': 'tzdata'}, check_invalid_arguments=False)
    result = get_selections(mock_module, 'tzdata')
    assert result['tzdata/Zones/America'] == 'America'


# Generated at 2022-06-11 06:49:44.525696
# Unit test for function get_selections
def test_get_selections():
    test_module = type('module', (object,), {
        'run_command': lambda self, command, data=None: (0, '*locales/default_environment_locale\tselect\tfr_FR.UTF-8' + '\n' +
                                                        '*locales/locales_to_be_generated\tmultiselect\ten_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8', ''),
        'fail_json': lambda self, msg: exit(1)
    })
    test_module = test_module()

    # Testing with a good input
    result = get_selections(test_module, 'test')

# Generated at 2022-06-11 06:49:53.878184
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    test_pkg = 'locales'
    pkg = module.params["name"]
    assert(test_pkg == pkg)
   

# Generated at 2022-06-11 06:50:00.040453
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda **kwargs: kwargs
    module.get_bin_path = lambda x, y: x
    module.run_command = lambda x, **kwargs: (0,'','',)
    assert module.exit_json(changed=False, msg='', current='', previous='') == \
           {'changed': False, 'msg': '', 'current': '', 'previous': ''}

# Generated at 2022-06-11 06:50:10.277358
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile
    import os

    test_setselection_nocmd = (1, '', 'Could not find debconf-set-selections')
    test_setselection_badcmd = (1, 'BADCMD', 'Could not run command')
    test_setselection_goodcmd = (0, '', '')
    test_setselection_nofile = (0, '', '')
    test_setselection_badfile = (1, '', 'No such file or directory')
    test_setselection_goodfile = (0, '', '')
    test_setselection_badvtype = (0, '', 'Invalid vtype')

    tmp_fh, tmp_fname = tempfile.mkstemp()
    tmp_fname2 = tmp

# Generated at 2022-06-11 06:50:20.306127
# Unit test for function main
def test_main():

    # Test no question supplied, default to getting existing selections
    m = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=["boolean", "error", "multiselect", "note", "password", "seen", "select", "string", "text", "title"]),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(["question", "vtype", "value"],),
        supports_check_mode=True,
    )
    m.run_command = MagicMock(return_value=(0, "", ""))

# Generated at 2022-06-11 06:50:32.115828
# Unit test for function main
def test_main():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    test_module.run_command = Mock(return_value=(0, 'test', ''))
    test_module.get_bin

# Generated at 2022-06-11 06:50:43.343875
# Unit test for function main
def test_main():
    test = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # test with question
    test.params['name'] = 'tzdata'

# Generated at 2022-06-11 06:50:53.185747
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec={
            'name': dict(type='str', required=True),
            'question': dict(type='str', required=True),
            'vtype': dict(type='str', required=True),
            'value': dict(type='str', required=True),
            'unseen': dict(type='bool', default=False),
        },
        required_together=(['question', 'vtype', 'value']),
    )
    rc, msg, err = set_selection(module, 'name', 'question', 'vtype', 'value', False)

    assert rc == 0
    assert msg == ''
    assert err == ''

# Generated at 2022-06-11 06:51:16.628404
# Unit test for function get_selections
def test_get_selections():
    test_module = ''
    test_pkg = 'tzdata'

# Generated at 2022-06-11 06:51:26.439601
# Unit test for function main
def test_main():
    """
    Test module
    """
    import platform
    import os

    # Test -platform
    if platform.system() == "Linux":
        assert 'linux' in platform.platform().lower()
    if platform.system() == "Darwin":
        assert 'darwin' in platform.platform().lower()
    if platform.system() == "Windows":
        assert 'windows' in platform.platform().lower()

    # Test -debconf
    if platform.system() == "Linux":
        assert 'debconf-show' in os.environ['PATH']

    # Test -require
    assert 'debconf-utils' in os.environ['PATH']

    # Test -when
    assert 'debconf-set-selections' in os.environ['PATH']

# Generated at 2022-06-11 06:51:30.516587
# Unit test for function get_selections
def test_get_selections():
    import debconf
    # Testing with package named "debconf-utils"
    dpkg = debconf.command.Command("debconf-show", "debconf-utils")
    dpkg.start()
    dpkg.communicate()
    assert dpkg.status == 0, "Error executing command."

# Generated at 2022-06-11 06:51:35.360143
# Unit test for function get_selections
def test_get_selections():
    # Create a mock module
    from collections import namedtuple
    module = namedtuple('module', 'run_command')
    module.get_bin_path = lambda x,y: '/usr/bin/' + x

    rc, out, err = get_selections(module, 'sudo')
    assert rc == 0
    assert len(out) > 1

# Generated at 2022-06-11 06:51:45.710791
# Unit test for function main
def test_main():
   from io import StringIO
   from .mock import patch, call

# Generated at 2022-06-11 06:51:55.186881
# Unit test for function set_selection

# Generated at 2022-06-11 06:51:58.007475
# Unit test for function main
def test_main():
    pkg = 'ntp'
    question = 'ntp/ntpdate_disable_with_ntp_stop'
    vtype = 'boolean'
    value = 'True'



# Generated at 2022-06-11 06:52:02.231012
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.debconf import get_selections

    pkg = 'locales'

    selections = get_selections(pkg)

    assert 'locales/default_environment_locale' in selections
    assert 'locales/locales_to_be_generated' in selections

# Generated at 2022-06-11 06:52:12.950131
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
            ),
            required_together=(['question', 'vtype', 'value'],),
            supports_check_mode=True,
        )
    pkg = "tzdata"
    selections = get_selections(module, pkg)
    assert "tzdata/Areas" in selections


# Generated at 2022-06-11 06:52:22.363076
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule

    b_selection = b"""* locales/default_environment_locale: en_US\n  locales/locales_to_be_generated: en_US.UTF-8 UTF-8\n"""
    t_selection = to_text(b_selection)

    module = AnsibleModule({})

    module.run_command = MagicMock()
    module.run_command.return_value = (0,t_selection)

    result = get_selections(module, 'locales')
    assert result['locales/default_environment_locale'] == 'en_US'
    assert result['locales/locales_to_be_generated'] == 'en_US.UTF-8 UTF-8'

# Generated at 2022-06-11 06:52:49.729166
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(argument_spec = dict())
    setsel = module.get_bin_path('debconf-set-selections', True)
    cmd = [setsel]
    data = ' '.join(['locales', 'locales/default_environment_locale', 'select', 'fr_FR.UTF-8'])
    module.run_command(cmd, data=data)
    cmd = [setsel, '-u']
    data = ' '.join(['locales', 'locales/locales_to_be_generated', 'multiselect', 'en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8'])
    module.run_command(cmd, data=data)


# Generated at 2022-06-11 06:52:57.513636
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    assert 0

# Generated at 2022-06-11 06:52:59.867376
# Unit test for function get_selections
def test_get_selections():
    get_selections = get_selections(module, pkg)
    assert rc == 0
    assert out == selections

# Generated at 2022-06-11 06:53:02.994968
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(module, 'tzdata') == {'tzdata/Zones/America': 'America', 'tzdata/Areas': 'America', 'tzdata/Zones/Etc': 'Etc'}

# Generated at 2022-06-11 06:53:04.050793
# Unit test for function main
def test_main():
    result = main()
    assert result is None

# Generated at 2022-06-11 06:53:14.663604
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-11 06:53:24.742086
# Unit test for function main
def test_main():

    import os
    import tempfile
    import json
    import shutil

    os.environ['ANSIBLE_MODULE_NO_JSON'] = '1'
    os.environ['ANSIBLE_MODULE_NO_PIPE'] = '1'

    # instantiate module object

# Generated at 2022-06-11 06:53:34.644577
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = 'python-psycopg2'
    question = 'python-psycopg2/main'

# Generated at 2022-06-11 06:53:43.443915
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """
    import os
    import tempfile
    source = 'tests/unit/modules/debconf/'

    def run_module(module_name, module_args):
        """
        Helper to run module
        """
        module_path = os.path.join(source, module_name)
        module_args = ' '.join(module_args)
        cmd = 'ANSIBLE_LIBRARY=%s ANSIBLE_MODULE_UTILS=%s ANSIBLE_MODULE_REQUIREMENTS=%s ANSIBLE_MODULE_REQUIREMENTS_PATH=%s ansible-playbook -i %s %s %s' % (
            source, source, source, source, "localhost", module_path, module_args)

# Generated at 2022-06-11 06:53:51.584848
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = module.params["name"]
    question = module.params["question"]
    vtype = module.params["vtype"]


# Generated at 2022-06-11 06:54:50.968851
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-11 06:54:51.684718
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-11 06:54:54.539868
# Unit test for function set_selection
def test_set_selection():
    set_selection(
        module=None,
        pkg='pkg',
        question='question',
        vtype='vtype',
        value='value',
        unseen=False
    )

# Generated at 2022-06-11 06:55:01.989465
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = 'tzdata'
    selections = get_selections(module, pkg)
    assert selections is not None
    assert 'tzdata/Areas' in selections
    assert 'tzdata/Zones/America' in selections
    assert 'tzdata/Zones/Europe' in selections
    assert 'tzdata/Zones/US' in selections
    assert selections['tzdata/Zones/Europe'] == 'Amsterdam'

# Generated at 2022-06-11 06:55:12.262164
# Unit test for function set_selection
def test_set_selection():
    import tempfile
    import subprocess
    import os

    test_params = [
        ("pkg", "question", "vtype", "value", "unseen", "command"),
        ("dummy", "question", "string", "value", False, ["debconf-set-selections", "--", "dummy", "question", "string", "value"]),
        ("dummy", "question", "string", "value", True, ["debconf-set-selections", "-u", "--", "dummy", "question", "string", "value"]),
        ("dummy", "question", "string", "value with spaces", True, ["debconf-set-selections", "-u", "--", "dummy", "question", "string", "value with spaces"]),
    ]


# Generated at 2022-06-11 06:55:17.010657
# Unit test for function set_selection
def test_set_selection():
    import pytest

    pkg = "localepurge"
    question = "localepurge/nopurge"
    value = "en_US.UTF-8"
    vtype = "select"
    unseen = False

    set_selection(module, pkg, question, vtype, value, unseen)

# Generated at 2022-06-11 06:55:27.874349
# Unit test for function set_selection
def test_set_selection():
    def run(data, **kwargs):
        return (1, '', 'Error')
    module = AnsibleModule(argument_spec=dict(
        name=dict(type='str', required=True, aliases=['pkg']),
        question=dict(type='str', aliases=['selection', 'setting']),
        vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
        value=dict(type='str', aliases=['answer']),
        unseen=dict(type='bool', default=False),
    ))
    module.run_command = run
    rc, output, err = set_selection(module, 'hello', 'world', 'string', 'earth', False)
    assert (rc == 1)

# Generated at 2022-06-11 06:55:39.498631
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.debconf import set_selection
    import os

    # given
    module = AnsibleModule()
    question = 'test'
    vtype = 'test'
    value = 'test'

    # when
    set_selection(module, 'test', question, vtype, value, False)

    # then
    cmd = ['debconf-set-selections']
    data = ' '.join(['test', question, vtype, value])
    assert os.environ['DEBIAN_FRONTEND'] == 'noninteractive'
    assert os.environ['DEBIAN_PRIORITY'] == 'critical'
    assert module.run_command.call_count == 1

# Generated at 2022-06-11 06:55:50.411550
# Unit test for function get_selections
def test_get_selections():
    """
    Function to test_get_selections function.
    """
    class AnsibleModuleStub:
        """
        Stub class to mimic AnsibleModule class.
        """
        def __init__(self):
            pass

        def get_bin_path(self, *args, **kwargs):
            """
            Bin path function stub.
            """
            return '/usr/bin/'

        def run_command(self, *args, **kwargs):
            """
            Run command function stub.
            """
            return 0, "debconf-show output", ''

    def get_selections_function(module, pkg):
        """
        Call get_selections function and return output.
        """
        return get_selections(module, pkg)

    module_stub = AnsibleModuleStub()

# Generated at 2022-06-11 06:55:57.599358
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump

    pkg = module.params["name"]

# Generated at 2022-06-11 06:57:40.637734
# Unit test for function set_selection
def test_set_selection():
    # Given
    class ModuleStub(object):
        def __init__(self):
            self.command_executed = None

    def run_command_side_effect(command, data=None):
        self.command_executed = command[0] + " " + data

        class RunCommandStubReturn(object):
            returncode = 0
            stderr = None

            def __init__(self, returncode, stderr):
                self.returncode = returncode
                self.stderr = stderr

        if self.command_executed.startswith("debconf-set-selections"):
            if self.command_executed.find("-u") > -1:
                return RunCommandStubReturn(1, "You are trying to run debconf-set-selections non-interactively")
           

# Generated at 2022-06-11 06:57:49.354495
# Unit test for function main
def test_main():

    module = AnsibleModule({
        'vtype': 'string',
        'value': 'test',
        'question': 'testquestion',
        'name': 'testpkg',
        'unseen': False
    })

    rc, out, err = set_selection(module, 'testpkg', 'testquestion', 'string', 'test', False)
    assert rc == 0
    assert out == ''
    assert err == ''

    rc, out, err = set_selection(module, 'testpkg', 'testquestion', 'boolean', 'True', False)
    assert rc == 0
    assert out == ''
    assert err == ''

    rc, out, err = set_selection(module, 'testpkg', 'testquestion', 'boolean', 'False', False)
    assert rc == 0
    assert out == ''
    assert err == ''

# Generated at 2022-06-11 06:57:59.115177
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    print(get_selections(module, 'tzdata'))


# Generated at 2022-06-11 06:58:07.206030
# Unit test for function get_selections
def test_get_selections():
    class MockModule(object):
        def __init__(self):
            self.params = { "name" : "tzdata" }

        def run_command(self, command, data=None):
            return command

        def get_bin_path(self, name, required):
            return "test"

    class MockResponse(object):
        def __init__(self, cmd, out, err):
            self.cmd = cmd
            self.stdout = out
            self.stderr = err

    mock = MockModule()

    rc = 0
    out = "tzdata/Areas: Africa\ntzdata/Zones/Africa: Abuja\n"
    err = ""
    response = MockResponse(rc, out, err)


# Generated at 2022-06-11 06:58:08.704705
# Unit test for function main
def test_main():
  test_params = {
    'name': 'tzdata',
  }

  main(test_params)

# Generated at 2022-06-11 06:58:18.496703
# Unit test for function get_selections
def test_get_selections():
    # Unit test for function when pkg is present but question is None
    class MockModule(object):
        params = {'name':'tzdata'}
        def __init__(self):
            self.run_command_calls = 0
            self.fail_json_calls = 0
        def get_bin_path(self, exe, required):
            return 'debconf-show'
        def run_command(self, cmd, data=None):
            self.run_command_calls += 1
            return 0, 'tzdata\tzdata/Areas\tselect\tAmerica', ''
        def fail_json(self, msg):
            self.fail_json_calls += 1
    m = MockModule()
    prev = get_selections(m, 'tzdata')
    assert m.run_command_calls

# Generated at 2022-06-11 06:58:27.297615
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = module.params["name"]
    question = module.params["question"]
    vtype = module.params["vtype"]


# Generated at 2022-06-11 06:58:32.252920
# Unit test for function get_selections
def test_get_selections():

    test_module = __import__('ansible.module_utils.basic', globals(), locals(), [], -1)
    test_module = test_module.AnsibleModule
    test_module = test_module(argument_spec={})

    test_module.run_command = lambda x: (0, '', '')

    assert get_selections(test_module, 'locales') is not None

# Generated at 2022-06-11 06:58:33.905618
# Unit test for function get_selections
def test_get_selections():
    for i in range(2):
        assert_equal(get_selections(i+1), i+1)

# Generated at 2022-06-11 06:58:36.412017
# Unit test for function main
def test_main():
    args = dict(name = 'pkg', question = 'question', vtype = 'vtype', value = 'value', unseen = 'unseen')
    returned = main(args)
    assert returned == None