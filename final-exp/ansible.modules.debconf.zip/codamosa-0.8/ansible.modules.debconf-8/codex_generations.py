

# Generated at 2022-06-11 06:49:40.854396
# Unit test for function get_selections
def test_get_selections():
    print("Testing get_selections")

# Generated at 2022-06-11 06:49:49.992629
# Unit test for function set_selection
def test_set_selection():
    '''
    debconf module - test set_selection() function
    '''
    # Given there is a module named:
    module = 'test_module'

    # And I have a command named:
    cmd = '/usr/bin/fake_bin_path'

    # And I have a pkg named:
    pkg = 'test_pkg'

    # And I have a question named:
    question = 'test_question'

    # And I have a vtype named:
    vtype = 'test_vtype'

    # And I have a value named:
    value = 'test_value'

    # And I have an unseen named:
    unseen = 'test_unseen'

    # When I set_selection
    result = set_selection(module, pkg, question, vtype, value, unseen)

    # Then I

# Generated at 2022-06-11 06:49:59.749443
# Unit test for function main
def test_main():
  # Create a test environment
  module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
  )
  class MockMoudleReturnValue(object):
    rc = 0

# Generated at 2022-06-11 06:50:09.902571
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    from ansible.module_utils.basic import AnsibleModule_mock
    from ansible.module_utils.basic import AnsibleModule_

# Generated at 2022-06-11 06:50:16.924270
# Unit test for function set_selection
def test_set_selection():
    """
    Unit test for function set_selection
    """
    # Simple unit test to see if we get our return values back
    # This is saving time, but we realize that it's not a real test
    # of functionality
    mock_module = Mock()
    mock_module.run_command.return_value = (1, 'Success', 'Success')
    ret = set_selection(mock_module, 'pkg', 'question', 'vtype', 'value', 'unseen')
    assert ret is None

# Generated at 2022-06-11 06:50:21.390788
# Unit test for function set_selection
def test_set_selection():
    import os

    d = {}
    test_file = '.test_debconf'
    d['setsel'] = test_file
    d['data'] = ' '.join(['pkg', 'question', 'vtype', 'value'])
    d['rc'] = 0

    assert set_selection(d) == 0
    assert os.path.isfile(test_file) == True
    os.remove(test_file)

# Generated at 2022-06-11 06:50:21.920829
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 06:50:23.854657
# Unit test for function set_selection
def test_set_selection():

    out = set_selection(None, 'my_package', 'my_question', 'my_type', 'my_value', True)



# Generated at 2022-06-11 06:50:34.838129
# Unit test for function set_selection
def test_set_selection():
    import StringIO

    # Mock module.run_command
    # First with success
    def mock_run_command_success(cmd, data):
        return (0, "", "")


# Generated at 2022-06-11 06:50:47.289096
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = 'tzdata'
   

# Generated at 2022-06-11 06:50:56.638271
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 06:51:06.280454
# Unit test for function set_selection
def test_set_selection():
    # Unit test for function set_selection and get_selections
    import os
    import tempfile

    ansible_module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # create a test package

# Generated at 2022-06-11 06:51:15.044747
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    selections = get_selections(module, "tzdata")
    assert 'tzdata/Zone/Etc' in selections

# Generated at 2022-06-11 06:51:18.709057
# Unit test for function get_selections
def test_get_selections():
    result = get_selections(module, pkg)
    assert result is not None
    assert result,{u'tzdata/Zones/US': u'America/New_York'}


# Generated at 2022-06-11 06:51:24.479959
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    cmd = ['debconf-set-selections']
    data = ''.join(['pkg_name', 'question_name', 'value_type', 'value'])

    rc, out, err = module.run_command(cmd, data)

    assert rc == 0

# Generated at 2022-06-11 06:51:31.327708
# Unit test for function main
def test_main():
    # Must pass since we made no changes
    module = AnsibleModule(dict(
        name=dict(type='str', required=True, aliases=['pkg']),
        question=dict(type='str', aliases=['selection', 'setting']),
        vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
        value=dict(type='str', aliases=['answer']),
        unseen=dict(type='bool', default=False),
    ))
    module.run_command = MagicMock(return_value=(0, "", ""))
    module.exit_json = MagicMock()
    main()

# Generated at 2022-06-11 06:51:31.996335
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-11 06:51:38.465652
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
        )
    )
    pkg = 'locales'
    result = get_selections(module, pkg)

    assert len(result) == 2
    assert result['locales/default_environment_locale'] == 'en_US.UTF-8'
    assert result['locales/locales_to_be_generated'] == 'en_US.UTF-8 UTF-8'


# Generated at 2022-06-11 06:51:46.355538
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(argument_spec={})
    module.run_command = mock.MagicMock(return_value=(0, '', ''))
    assert set_selection(module, 'system_local_settings', 'all', 'multiselect', 'America/New_York America/Los_Angeles', False) == (0, '', '')
    module.run_command.assert_called_with([module.get_bin_path('debconf-set-selections', True)], data=' '.join(['system_local_settings', 'all', 'multiselect', 'America/New_York America/Los_Angeles']))

# Generated at 2022-06-11 06:51:52.395617
# Unit test for function get_selections
def test_get_selections():
    result = {'tzconfig/choosen_country': 'US',
              'tzdata/Areas': 'US',
              'tzdata/Zones/US': 'America/New_York',
              'tzdata/Zones/US/New_York': 'America/New_York',
              'tzdata/Zones/US/New_York/New_York': 'America/New_York'}
    assert get_selections(None, 'tzdata') == result

# Generated at 2022-06-11 06:52:13.667927
# Unit test for function get_selections
def test_get_selections():
    """
    Test a simple case where the return is searchable
    """
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = 'tzdata'

    prev = get_select

# Generated at 2022-06-11 06:52:23.517100
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import actions
    from ansible.module_utils.debconf import (
        get_selections,
        set_selection,
        )
    from ansible.module_utils.common.collections import ImmutableDict
    import ansible.module_utils.basic
    import ansible.module_utils.action
    import ansible.module_utils.actions
    import ansible.module_utils.debconf
    import os
    import sys
    import unittest

    test_obj = debconf_mock()

    # main() uses positional args, so we cant pass kwargs
    os_path_splitext_orig = os.path.splitext
    os_path_splitext_mock = os_path_splitext_orig


# Generated at 2022-06-11 06:52:32.508370
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
        no_log=True,
    )


# Generated at 2022-06-11 06:52:43.392135
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(type='str', required=True, aliases=['pkg']),
            question = dict(type='str', aliases=['selection', 'setting']),
            vtype = dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value = dict(type='str', aliases=['answer']),
            unseen = dict(type='bool', default=False),
        )
    )
    pkg = 'testpkg'
    question = 'testquestion'
    vtype = 'select'
    value = 'testvalue'
    unseen = False
    output = set_selection(module, pkg, question, vtype, value, unseen)
   

# Generated at 2022-06-11 06:52:47.184267
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(module, pkg) == \
        {'tzdata/Areas': 'Europe',
        'tzdata/Zones/Europe': 'Berlin'}


# Generated at 2022-06-11 06:52:55.263366
# Unit test for function set_selection
def test_set_selection():
    class FakeModule:
        def __init__(self):
            self.run_command = lambda cmd, data: (0, '', '')
        def get_bin_path(self, path, required=True):
            return path
    module = FakeModule()
    pkg = 'localepurge'
    question = 'localepurge/nopurge'
    vtype = 'select'
    value = 'en*'
    unseen = False

    rc, stdout, stderr = set_selection(module, pkg, question, vtype, value, unseen)
    assert(rc == 0)


# Generated at 2022-06-11 06:53:05.711926
# Unit test for function get_selections
def test_get_selections():
  module = AnsibleModule(
      argument_spec=dict(
          name=dict(type='str', required=True, aliases=['pkg']),
          question=dict(type='str', aliases=['selection', 'setting']),
          vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
          value=dict(type='str', aliases=['answer']),
          unseen=dict(type='bool', default=False),
      ),
      required_together=(['question', 'vtype', 'value'],),
      supports_check_mode=True,
  )

# Generated at 2022-06-11 06:53:06.335794
# Unit test for function set_selection
def test_set_selection():
    assert True == True

# Generated at 2022-06-11 06:53:08.496820
# Unit test for function set_selection
def test_set_selection():
    set_selection('/usr/bin/debconf-show', 'ansible', 'ansible/askhostname', 'boolean', 'true', False)

# Generated at 2022-06-11 06:53:19.240954
# Unit test for function main
def test_main():
    # set up basic args
    module = AnsibleModule({
        "name": "dummy",
        "question": None
    })
    # set up basic mocks
    module.run_command = MagicMock()
    module.run_command.return_value = 0, "", ""
    module.exit_json = MagicMock()
    module.fail_json = MagicMock()

    # get_selections test
    prev = get_selections(module, "dummy")
    assert len(prev) > 0, "get_selections returns something"
    assert module.run_command.called, "run_command is called"
    assert module.run_command.call_count == 1, "run_command is called exactly once"

    # set_selection test

# Generated at 2022-06-11 06:54:08.887773
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(argument_spec=dict(name=dict(type='str')), supports_check_mode=True)
    assert get_selections(module, 'tzdata') == {'tzdata/Areas': '', 'tzdata/Zones/Africa': '', 'tzdata/Zones/America': '', 'tzdata/Zones/Antarctica': '', 'tzdata/Zones/Arctic': '', 'tzdata/Zones/Asia': '', 'tzdata/Zones/Atlantic': '', 'tzdata/Zones/Australia': '', 'tzdata/Zones/Europe': '', 'tzdata/Zones/Indian': '', 'tzdata/Zones/Pacific': '', 'tzdata/Zones/UTC': ''}, 'get_selections failed: returned value does not match'


# Generated at 2022-06-11 06:54:09.393181
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 06:54:15.491386
# Unit test for function set_selection
def test_set_selection():
    from mock import Mock, patch

    def run_command_wrapper(cmd, data):
        assert cmd == ['/usr/bin/debconf-set-selections']
        assert data == 'mypackage myquestion select myanswer'
        return (0, '', '')

    module = Mock()
    module.get_bin_path.return_value = '/usr/bin/debconf-set-selections'
    module.run_command = run_command_wrapper
    set_selection(module, 'mypackage', 'myquestion', 'select', 'myanswer', False)

# Generated at 2022-06-11 06:54:20.318606
# Unit test for function set_selection
def test_set_selection():
    setsel = main.get_bin_path('debconf-set-selections', True)
    if vtype == 'boolean':
        if value == 'True':
            value = 'true'
        elif value == 'False':
            value = 'false'
    data = ' '.join([pkg, question, vtype, value])

    return module.run_command(cmd, data=data)

# Generated at 2022-06-11 06:54:29.586051
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    # TODO: enable passing array of options and/or debconf file from get

# Generated at 2022-06-11 06:54:36.424479
# Unit test for function set_selection
def test_set_selection():
    value = 'Some random string'
    pkg = 'mypackage'
    question = 'myquestion'
    vtype = 'password'
    expected_cmd_list = ['/usr/bin/debconf-set-selections', '-u', '/usr/bin/debconf-set-selections']
    expected_data = ' '.join([pkg, question, vtype, value])

    def mock_run_command(cmd, data=None):
        if cmd not in expected_cmd_list:
            return 1, '', 'cmd not found'
        if data != expected_data:
            return 1, '', 'data not found'
        return 0, '', ''


# Generated at 2022-06-11 06:54:46.712530
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.basic import AnsibleModule
    import sys

    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
    else:
        import unittest


# Generated at 2022-06-11 06:54:56.603463
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(AnsibleModule):
        def run_command(self, cmd, data=None, check_rc=False):
            self.assertEqual(cmd[0], "debconf-set-selections")
            self.assertEqual(cmd[1], "-u")
            self.assertEqual(data, "test_package test_question text test_value")
            return 0, "", ""

        def get_bin_path(self, name, required, opt_dirs=None):
            return name

    module = TestModule(argument_spec={})
    rc, msg, e = set_selection(module, 'test_package', 'test_question', 'text', 'test_value', True)
    assert rc == 0

# Generated at 2022-06-11 06:54:57.937084
# Unit test for function set_selection
def test_set_selection():
    #No real tests since we only call run_command with mocked commands
    pass

# Generated at 2022-06-11 06:55:08.237331
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = 'tzdata'
    question = 'tzdata/Areas'
    vtype = 'select'

# Generated at 2022-06-11 06:56:27.430370
# Unit test for function main
def test_main():
    print(main())

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 06:56:28.501178
# Unit test for function get_selections
def test_get_selections():
    get_selections(module, pkg)

# Generated at 2022-06-11 06:56:30.041547
# Unit test for function main
def test_main():
    '''
    Function main tests
    :return:
    '''

    assert(main() == 0)

# Generated at 2022-06-11 06:56:34.807400
# Unit test for function main
def test_main():

    def mock_run_command(cmd, data=None, check_rc=False):
        return 0, '', None

    with mock.patch('ansible.module_utils.basic.AnsibleModule.run_command', new=mock_run_command):
        main()

# Generated at 2022-06-11 06:56:43.283779
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    module.get_bin_path = MagicMock()

# Generated at 2022-06-11 06:56:52.564170
# Unit test for function get_selections
def test_get_selections():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    selections = get_selections(test_module, 'tzdata')
    assert(len(selections) == 7)


# Generated at 2022-06-11 06:56:54.258188
# Unit test for function set_selection

# Generated at 2022-06-11 06:57:00.718307
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-11 06:57:01.247877
# Unit test for function set_selection
def test_set_selection():
    assert True is True

# Generated at 2022-06-11 06:57:10.144225
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils import basic
    # Since set_selection() is a helper function, it does not have an AnsibleModule instance as parameter.
    # It uses module.run_command(), which expects the following parameters on the module object:
    #
    # {
    # "params": {
    #     "binary_module": true,
    #     "check_mode": true,
    #     "debug": false,
    #     "diff": true,
    #     "force": false,
    #     "http_timeout": 30,
    #     "ignore_unreachable": false,
    #     "no_log": false,
    #     "remote_tmp": "/tmp/.ansible/tmp",
    #     "run_command_environ_update": {
    #         "PATH": "/usr/local/s