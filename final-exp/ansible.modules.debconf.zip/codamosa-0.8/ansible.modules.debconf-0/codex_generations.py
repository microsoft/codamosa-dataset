

# Generated at 2022-06-11 06:49:38.320126
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(module, pkg)



# Generated at 2022-06-11 06:49:47.459743
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(
        name=dict(type='str', required=True, aliases=['pkg']),
        question=dict(type='str', aliases=['selection', 'setting']),
        vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
        value=dict(type='str', aliases=['answer']),
        unseen=dict(type='bool', default=False),
    ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    ## function test_set_selection
    m1 = module
    m1.params

# Generated at 2022-06-11 06:49:48.089179
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 06:49:48.756040
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 06:49:53.630833
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule()
    pkg = 'local'
    question = 'test'
    vtype = 'select'
    value = 'value'
    rc, msg, err = set_selection(module, pkg, question, vtype, value, False)
    assert rc == 0
    assert msg == ''
    assert err == ''

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-11 06:50:03.128536
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-11 06:50:04.070189
# Unit test for function get_selections
def test_get_selections():
    print(get_selections())

# Generated at 2022-06-11 06:50:09.349788
# Unit test for function main
def test_main():
    import ansible.module_utils.common.removed
    from ansible.modules.system import debconf as debconf

    module = debconf
    module.ANSIBLE_MODULE_ARGS = {'name': 'tzdata', '_ansible_check_mode': True}
    module.set_ansible_module()

    print(module.main())

# Generated at 2022-06-11 06:50:10.017308
# Unit test for function get_selections
def test_get_selections():
    pass

# Generated at 2022-06-11 06:50:20.116473
# Unit test for function main

# Generated at 2022-06-11 06:50:38.157105
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )


#     def get_selections(module, pkg):
#         cmd = [module.get_bin_path('debconf-show',

# Generated at 2022-06-11 06:50:41.074587
# Unit test for function get_selections
def test_get_selections():
    assert get_selections('tzdata') == ['tzdata/Zones/America', 'tzdata/Zones/Asia']

# Generated at 2022-06-11 06:50:52.160404
# Unit test for function main
def test_main():
    module = AnsibleModule(
            argument_spec=dict(
                name=dict(type='str', required=True, aliases=['pkg']),
                question=dict(type='str', aliases=['selection', 'setting']),
                vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
                value=dict(type='str', aliases=['answer']),
                unseen=dict(type='bool', default=False),
            ),
            required_together=(['question', 'vtype', 'value'],),
            supports_check_mode=True,
        )
    module.run_command = MagicMock(return_value=('1', '', ''))
    module.exit_json = MagicMock

# Generated at 2022-06-11 06:51:02.269660
# Unit test for function get_selections
def test_get_selections():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    test_module.run_command=MagicMock(return_value=(0, '', ''))

    test_module.exit_

# Generated at 2022-06-11 06:51:04.282691
# Unit test for function get_selections
def test_get_selections():
    assert {'tzdata/Areas': 'Europe', 'tzdata/Zones/Europe': 'London'} == get_selections(module, pkg)

# Generated at 2022-06-11 06:51:13.579415
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils import basic
    import os
    import sys
    # test_get_selections is being called from the current path
    # so we need to chdir to the test path
    test_path = os.path.join(os.path.dirname(__file__), '..', '..', 'test')
    os.chdir(test_path)
    test_data_path = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'unit', 'module_utils', 'debconf')
    sys.path.append(test_data_path)

    print(test_data_path)

    # module arguments and return values
    pkg = 'tzdata'
    module

# Generated at 2022-06-11 06:51:25.096537
# Unit test for function set_selection

# Generated at 2022-06-11 06:51:31.619270
# Unit test for function get_selections
def test_get_selections():
    import subprocess as sub
    # Run the command: debconf-show locales
    proc = sub.Popen(['debconf-show', 'locales'], stdout=sub.PIPE)
    # Get the output of this command
    out = proc.communicate()[0]
    # Get the return code of the previous command
    rc = proc.returncode
    # Create an instance of the module

# Generated at 2022-06-11 06:51:42.156423
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = 'bash'
    question = 'bash/bashrc'
    vtype = 'boolean'
    value = 'true'

# Generated at 2022-06-11 06:51:52.222142
# Unit test for function set_selection
def test_set_selection():
    import sys
    import subprocess
    import os
    import re
    
    # test_debconf_get_selection_returns_list_of_dictionaries
    # Checking that get_selections returns list of dictionaries of questions and answers
    list_of_selections = debconf.get_selections(pkg='locales')
    assert(isinstance(list_of_selections, list))
    assert(isinstance(list_of_selections[0], dict))
    assert('question' in list_of_selections[0])
    assert('answer' in list_of_selections[0])
    
    # test_set_selection_returns_bool_and_changes_selection
    # Check that debconf set_selection returns a boolean and that the selection indeed changed
    rc, msg, e = debconf.set_

# Generated at 2022-06-11 06:52:17.924491
# Unit test for function set_selection
def test_set_selection():
    import os
    import shutil
    from ansible.module_utils.basic import AnsibleModule

    fixture_path = os.path.dirname(__file__) + '/debconf-set-selections-test'
    os.makedirs(fixture_path)
    cmd = [fixture_path + '/bin/debconf-set-selections']
    module = AnsibleModule({})
    module.run_command = os.system
    module.get_bin_path = lambda module, required=False: fixture_path + '/bin/' + module

    # create a debconf-set-selections test binary which will create a file after setting a selection
    with open(fixture_path + '/bin/debconf-set-selections', 'w') as fh:
        fh.write('#!/bin/sh\n')

# Generated at 2022-06-11 06:52:26.966992
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
        ),
        supports_check_mode=True,
    )

    pkg = 'tzdata'  # test package

    prev = get_selections(module, pkg)

    assert isinstance(prev, dict)
    assert 'tzdata/Areas' in prev.keys()
    assert prev['tzdata/Areas'] in ['', 'America', 'Antarctica', 'Arctic', 'Asia', 'Atlantic', 'Australia', 'Brazil', 'Canada', 'Chile', 'Europe', 'Indian', 'Mexico', 'Pacific', 'US']

# Generated at 2022-06-11 06:52:34.968381
# Unit test for function set_selection
def test_set_selection():
    def mock_module(**kwargs):
        data = dict(
            get_bin_path=lambda *args, **kwargs: '/bin/debconf-set-selections',
            run_command=lambda *args, **kwargs: (0, "", None)
        )
        data.update(kwargs)
        return Mock(**data)
    from ansible.module_utils import basic
    basic.ANSIBLE_MODULE_UTILS = True

    m = mock_module()
    rc, msg, e = set_selection(m, 'pkg', 'question', 'vtype', 'value', 'unseen')
    assert rc == 0

# Generated at 2022-06-11 06:52:46.516351
# Unit test for function get_selections
def test_get_selections():
    import imp

    import unittest2 as unittest

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class TestGetSelections(unittest.TestCase):

        def setUp(self):
            self.fixture = imp.load_source('ansible.builtin.debconf', '/usr/lib/python2.7/site-packages/ansible/modules/packaging/os/debconf.py')
            self.fixture.get_selections.__globals__['__builtins__'] = dict()


# Generated at 2022-06-11 06:52:46.836439
# Unit test for function main
def test_main():
  assert main()

# Generated at 2022-06-11 06:52:49.941616
# Unit test for function set_selection
def test_set_selection():
    set_selection(
        name='debconf',
        question='debconf/priority',
        vtype='select',
        value='low',
        unseen=False
        )

# Generated at 2022-06-11 06:52:58.271900
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = module.params["name"]
    question = module.params["question"]
    vtype = module.params["vtype"]


# Generated at 2022-06-11 06:53:08.677661
# Unit test for function set_selection
def test_set_selection():

    class WrapperClass:
        def __init__(self):
            self.run_command_calls = 0
            self.run_command_params = []
            self.run_command_passed = False

        def get_bin_path(self, name, ignore_errors=False, opt_dirs=None):
            return '../bin/' + name

        def fail_json(self, *args, **kwargs):
            raise RuntimeError(args[0])

        def run_command(self, *args, **kwargs):
            self.run_command_calls += 1
            self.run_command_params.append(args)
            self.run_command_passed = True

    w = WrapperClass()

# Generated at 2022-06-11 06:53:09.310122
# Unit test for function get_selections
def test_get_selections():
    pass

# Generated at 2022-06-11 06:53:19.293564
# Unit test for function get_selections
def test_get_selections():

    class TestModule(object):
        def __init__(self):
            self._ansible_module = AnsibleModule(argument_spec={})

        def get_bin_path(self, executable, required):
            return str(executable)

        def run_command(self, cmd, data=None):
            return 0, 'debconf-show oracle-java7-installer', ''

    m = TestModule()

    selections = get_selections(m, 'oracle-java7-installer')
    assert len(selections) == 6
    assert 'shared/accepted-oracle-license-v1-1' in selections
    assert selections['shared/accepted-oracle-license-v1-1'] == 'true'

# Generated at 2022-06-11 06:54:09.286196
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = module.params["name"]
    question = module.params["question"]
    vtype = module.params["vtype"]


# Generated at 2022-06-11 06:54:15.444071
# Unit test for function get_selections
def test_get_selections():
    #m = AnsibleModule(argument_spec=dict())
    m = object
    m.get_bin_path = lambda x, y: x
    assert get_selections(m, 'localepurge') == {'localepurge/use-dpkg-feature': 'false', 'localepurge/showfreedspace': 'true', 'localepurge/nopurge': 'en en_US', 'localepurge/quickndirtycalc': 'false', 'localepurge/verbose': 'true'}

# Generated at 2022-06-11 06:54:24.435182
# Unit test for function main
def test_main():
    import sys, os
    from ansible.module_utils import basic

    def _mock_run_command(module, cmd, data=None):
        rc = 0
        out = err = ''
        if cmd[-1] == 'sleep':
            rc = 1
            out = err = 'sleep: cannot read realtime clock: Invalid argument'
        elif cmd[-1] == 'false':
            rc = 1
            out = err = 'false'
        elif cmd[-1] == 'true':
            out = 'fake stdout'
            err = 'fake stderr'

        return rc, out, err

# Generated at 2022-06-11 06:54:25.197041
# Unit test for function set_selection
def test_set_selection():
    pass

# Generated at 2022-06-11 06:54:27.287063
# Unit test for function main
def test_main():
    rc, out, err = set_selection(module, pkg, question, vtype, value, unseen)
    assert rc is 0

# Generated at 2022-06-11 06:54:35.045199
# Unit test for function get_selections
def test_get_selections():
    import sys
    import platform

    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    if sys.hexversion < 0x20703f0:
        import mock
        from mock import patch
    else:
        import unittest.mock as mock
        from unittest.mock import patch

    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.debconf import get_selections

    class TestDebconf(unittest.TestCase):

        @mock.patch('ansible.module_utils.basic.AnsibleModule')
        def test_get_selections(self, mock_module):
            mock_module.run_command.return_value = 0, \
               

# Generated at 2022-06-11 06:54:38.393417
# Unit test for function get_selections
def test_get_selections():
    # Unit test for function get_selections
    module = None
    pkg = 'tzdata'
    rc, out, err = get_selections(module, pkg)

    assert rc == 0
    assert isinstance(out, dict)

# Generated at 2022-06-11 06:54:40.867964
# Unit test for function set_selection
def test_set_selection():
    set_selection(pkg, question, vtype, value)
    assert question in get_selections(pkg) and get_selections(pkg)[question] == value

# Generated at 2022-06-11 06:54:45.022350
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
      argument_spec=dict(),
      required_together=(),
      supports_check_mode=False,
    )
    pkg = 'locales'
    settings = get_selections(module, pkg)
    assert 'locales/default_environment_locale' in settings

# Generated at 2022-06-11 06:54:52.219130
# Unit test for function get_selections
def test_get_selections():
    from mock import patch, Mock, MagicMock
    import ansible.module_utils.debconf as debconf
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path

    class MockedDebconfModule(object):
        def __init__(self):
            self.fail_json = lambda **kwargs: self
            self.get_bin_path = get_bin_path
            self.run_command = Mock(return_value=(0, ' * locales/locales_to_be_generated:  en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8', ''))
            self.params = ['locales', 'locales/default_environment_locale', 'select', 'fr_FR.UTF-8']

   

# Generated at 2022-06-11 06:56:08.039675
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # Ask for non-existent package
    pkg = "does_not_exist"
    expected = {}
    actual = get_selections

# Generated at 2022-06-11 06:56:08.591007
# Unit test for function set_selection
def test_set_selection():
    assert False

# Generated at 2022-06-11 06:56:14.312926
# Unit test for function get_selections
def test_get_selections():
    #no such pkg
    assert ({} == get_selections("nosuchpkg")), "expected: {}, result: {}".format({}, get_selections("nosuchpkg"))
    #check for locales
    assert ("locales/locales_to_be_generated" in get_selections("locales")), "did not find expected question: locales/locales_to_be_generated"


# Generated at 2022-06-11 06:56:23.793101
# Unit test for function get_selections
def test_get_selections():
    # arguments
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = 'tzdata'

    selections = get_selections(module, pkg)


# Generated at 2022-06-11 06:56:34.276039
# Unit test for function set_selection
def test_set_selection():
    import sys
    import subprocess
    from tempfile import NamedTemporaryFile
    from ansible.module_utils.basic import AnsibleModule
    test_data = [
        ("""testpackage""", """testquestion""", """testvtype""", """testvalue""", """False""")
    ]
    with NamedTemporaryFile(mode='w', delete=False) as tmp_file:
        tmp_file.write("""""")
        tmp_file.close()
        stdin = sys.stdin
        proc = subprocess.Popen([sys.executable, __file__, tmp_file.name], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
        stdin = proc.stdin
        stdout = proc.stdout

# Generated at 2022-06-11 06:56:42.839376
# Unit test for function get_selections
def test_get_selections():
    test_cases = [
        {
            'name': 'test get_selections with no package',
            'params': dict(pkg=''),
            'want_rc': True,
        },
        {
            'name': 'test get_selections on a fake package',
            'params': dict(pkg='_fake'),
            'want_rc': True,
        },
        {
            'name': 'test get_selections on an existing package',
            'params': dict(pkg='bash'),
            'want_rc': False,
        },
    ]

    import os
    import sys
    import tempfile
    import textwrap
    import time

    # We have to create a fake module instance, because we are not actually
    # running this module through Ansible.

# Generated at 2022-06-11 06:56:52.043107
# Unit test for function set_selection
def test_set_selection():
    class FakeModule(object):
        def __init__(self):
            self.paths = []
            self.cmd_results = {
                '/usr/bin/debconf-set-selections': [
                    0,
                    ('', '')
                ]
            }
        def run_command(self, cmd, data=None):
            if data is not None:
                self.cmd_results[cmd[0]] = data
            return self.cmd_results[cmd[0]]
        def get_bin_path(self, name, required=False):
            return self.paths[name]
    module = FakeModule()

    pkg = 'mypackage'
    question = 'myquestion'
    vtype = 'myvtype'
    value = 'myvalue'
    unseen = False


# Generated at 2022-06-11 06:56:59.637378
# Unit test for function main
def test_main():
    mc_ansible = import_module("ansible")
    mc_AnsibleModule = mc_ansible.module_utils.basic.AnsibleModule
    import sys
    sys.modules['ansible.module_utils.debconf'] = import_module('ansible.module_utils.debconf')


# Generated at 2022-06-11 06:57:04.583771
# Unit test for function set_selection
def test_set_selection():
    my_module = AnsibleModule(argument_spec={})
    my_module.set_bin_path('/usr/bin:/usr/sbin:/bin:/usr/local/bin:/sbin')
    rc, msg, err = set_selection(my_module, "test_pkg", "test_question", "test_type", "test_value", False)
    assert rc == 0
    assert msg == ""
    assert err == ""

# Generated at 2022-06-11 06:57:13.929133
# Unit test for function main
def test_main():
    import ansible
    from ansible.utils.path import unfrackpath
    from ansible.module_utils import deb_utils, debconf_utils
    from ansible.module_utils.debconf_utils import get_selections
    from ansible.module_utils.debconf_utils import set_selection

    ansible.module_utils.deb_utils.DEBCONF_UTILS_PATH = '/usr/bin'
    ansible.module_utils.deb_utils.DEBCONF_PATH = '/usr/bin'
