

# Generated at 2022-06-11 06:49:39.933946
# Unit test for function set_selection
def test_set_selection():
    question = "mysql-server/root_password"
    vtype = "password"
    value = "hello"
    unseen = False
    pkg = "mysql-server-5.7"

    # FIXME: parameter contains sensitive information
    # def set_selection(module, pkg, question, vtype, value, unseen):

# Generated at 2022-06-11 06:49:47.010687
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock()
    module.run_command.return_value = (0, "tzdata tzdata/Areas select US", "")
    result = get_selections(module, 'tzdata')
    assert result == {'tzdata': 'US'}
    result = get_selections(module, 'fake')
    assert result == {}


# Generated at 2022-06-11 06:49:56.174472
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # Test value != existing

# Generated at 2022-06-11 06:50:06.501249
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-11 06:50:16.821672
# Unit test for function get_selections
def test_get_selections():
    package = "bash" 
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    print (get_selections(test_module, package))

# Generated at 2022-06-11 06:50:24.775560
# Unit test for function main
def test_main():
    pkg = "ansible"
    question = "password"
    vtype = "boolean"
    value = "true"
    unseen = "true"


# Generated at 2022-06-11 06:50:35.252082
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    assert get_selections(module, 'tzdata')


# Generated at 2022-06-11 06:50:45.601185
# Unit test for function set_selection
def test_set_selection():
    import subprocess
    p = subprocess.Popen(["debconf-get-selections | grep tripwire"], shell=True, stdout=subprocess.PIPE)
    out, err = p.communicate()
    if not out or not err:
        raise Exception("Couldn't execute command")
    result = set_selection(module, "tripwire", "tripwire/site-passphrase", "password", "ansible-test".join(out), False)
    if not result:
        raise Exception("Unexpected result")
    assert result[0] == 0
    assert result[1] == "apt-utils debconf-utils"

# Generated at 2022-06-11 06:50:50.189809
# Unit test for function set_selection
def test_set_selection():
    setsel = module.get_bin_path('debconf-set-selections', True)
    cmd = [setsel]
    if unseen:
        cmd.append('-u')
    data = ' '.join([pkg, question, vtype, value])
    module.run_command(cmd, data=data)

# Generated at 2022-06-11 06:50:51.240081
# Unit test for function get_selections
def test_get_selections():
    assert(True)



# Generated at 2022-06-11 06:51:09.283479
# Unit test for function main
def test_main():
    # pylint: disable=W0212,C0111
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    ## prepare the test environment
    # create a config file
    tfile = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-11 06:51:09.634032
# Unit test for function get_selections
def test_get_selections():
    assert 1 == 1

# Generated at 2022-06-11 06:51:14.404078
# Unit test for function get_selections
def test_get_selections():
    out = b'* locales/default_environment_locale: fr_FR.UTF-8'
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, out, b''))
    result = get_selections(module, 'locales')
    assert(result == {'locales/default_environment_locale': 'fr_FR.UTF-8'})


# Generated at 2022-06-11 06:51:25.737241
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

# Generated at 2022-06-11 06:51:36.960540
# Unit test for function set_selection
def test_set_selection():
    # Initialization
    global module

    class MyModule(object):
        class params(object):
            name = "example"
            question = "question"
            vtype = "string"
            value = "value"
            unseen = False

        def get_bin_path(self, path, required):
            return path

        def run_command(self, cmd, data=None):
            return [0, '', '']

    module = MyModule()

    # Call function
    module.run_command = lambda cmd, data=None: [0, '', '']
    rc, msg, out = set_selection(module, "example", "question", "string", "value", False)

    # Check results
    assert(rc == 0)
    assert(msg == '')
    assert(out == '')

# Generated at 2022-06-11 06:51:37.981302
# Unit test for function get_selections
def test_get_selections():
    pass


# Generated at 2022-06-11 06:51:48.225572
# Unit test for function set_selection
def test_set_selection():
    import os, tempfile, shutil

    module_name = 'ansible.builtin.debconf'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True),
            question=dict(type='str'),
            vtype=dict(type='str',
                       choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string',
                                'text', 'title']),
            value=dict(type='str'),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value']),
        supports_check_mode=True,
    )
    module.params["name"] = "dummy_package"

# Generated at 2022-06-11 06:51:56.878065
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule()
    pkg = "tzdata"
    question = "tzdata/Zones/US"
    vtype = "multiselect"
    value = "America/New_York"
    unseen = False
    cmd = module.get_bin_path('debconf-show', True) + " " + pkg
    rc, out, err = module.run_command(cmd)
    before = rc
    rc, msg, e = set_selection(module, pkg, question, vtype, value, unseen)
    rc, out, err = module.run_command(cmd)
    after = rc
    if before != 0:
        return False # before should be 0
    if after != 0:
        return False # after should be 0
    if msg != True:
        return False # msg should be True

# Generated at 2022-06-11 06:52:08.473937
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-11 06:52:13.031672
# Unit test for function set_selection
def test_set_selection():
    assert set_selection("test_set_selection","test_set_selection","test_set_selection","test_set_selection","test_set_selection","1") == set_selection("test_set_selection","test_set_selection","test_set_selection","test_set_selection","test_set_selection","1")

# Generated at 2022-06-11 06:52:39.882475
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = 'tzdata'
    question = 'tzdata/Zones/Europe'
    vtype = 'multiselect'
   

# Generated at 2022-06-11 06:52:51.595424
# Unit test for function main
def test_main():
    # Import here to avoid issues in CI
    import os
    import sys
    import unittest

    # Don't complain if we have no arguments or a subcommand
    if len(sys.argv) > 1 and sys.argv[1] not in ('--help', '-h'):
        print(sys.argv[0], 'takes no arguments')
        sys.exit(1)

    # Append to Python import path so we find our module
    if os.path.exists('../ansible_collections'):
        sys.path.append('../ansible_collections/ansible_collections/community/general/tests')
    else:
        sys.path.append('../lib')
        sys.path.append('../plugins/modules')

    # Unit test module

# Generated at 2022-06-11 06:52:53.208039
# Unit test for function get_selections
def test_get_selections():
    pass

# Generated at 2022-06-11 06:52:54.579243
# Unit test for function set_selection
def test_set_selection():
    assert set_selection('main.debconf', 'set_selection')

# Generated at 2022-06-11 06:53:04.852199
# Unit test for function get_selections
def test_get_selections():
    '''
    Tests for function get_selections and module debconf
    '''
    import unittest
    from ansible.module_utils import debconf
    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils._text import to_native
    import os
    import sys

    def setUpModule():

        if sys.version_info[0] < 3:
            import __builtin__ as builtins
        else:
            import builtins

        builtins.__dict__['sys'] = sys
        builtins.__dict__['debconf'] = debconf


# Generated at 2022-06-11 06:53:15.460903
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.common._collections_compat import (
        MutableMapping,
    )
    import sys

    class TestModule(object):
        def __init__(self):
            self.run_command_called = 0
            self.debug = False

        def get_bin_path(self, executable, required):
            return 'true'

        def run_command(self, cmd, data=None):
            if self.debug:
                print(cmd, file=sys.stderr)
            self.run_command_called += 1

            return (0, "", "")

    class MutableMappingTest(MutableMapping):
        """
        MutableMapping that has keys that may not be strings.
        """
        def __init__(self, *args, **kwargs):
            self

# Generated at 2022-06-11 06:53:19.009827
# Unit test for function set_selection
def test_set_selection():
    import tempfile
    dtemp = tempfile.mkdtemp()
    rc, msg, err = set_selection(module, pkg, 'question', 'string', 'value', False)
    assert(rc == 0)

# Generated at 2022-06-11 06:53:28.836530
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = module.params.get("name")

    # TODO: Mock run_command()

# Generated at 2022-06-11 06:53:38.785460
# Unit test for function set_selection
def test_set_selection():

    class AnsibleModuleFake(object):

        def __init__(self, argument_spec, required_together):
            self.argument_spec = argument_spec
            self.required_together = required_together

            self.check_mode = False
            self.module_args = {}

            for key, value in argument_spec.iteritems():
                self.module_args[key] = value['default']

        def get_bin_path(self, name, required):
            return name

        def run_command(self, cmd, data=None):
            if data is not None:
                pass

        def fail_json(self, msg):
            raise ValueError(msg)


# Generated at 2022-06-11 06:53:45.959849
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-11 06:54:39.493747
# Unit test for function get_selections
def test_get_selections():
    global get_selections
    get_selections = __import__('debconf').get_selections

    assert get_selections(None, 'fake_program') == {}

# Unit tests for function set_selection

# Generated at 2022-06-11 06:54:43.821119
# Unit test for function set_selection
def test_set_selection():
    cmd_result = subprocess.run(['debconf-set-selections', '-u', 'tzdata'], data='tzdata tzdata/Areas select Africa', stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    assert cmd_result.returncode == 0


# Generated at 2022-06-11 06:54:47.066696
# Unit test for function get_selections
def test_get_selections():
    test_module = AnsibleModule(argument_spec={})
    test_result = get_selections(test_module, 'locales')
    assert 'locales/default_environment_locale' in test_result


# Generated at 2022-06-11 06:54:57.475358
# Unit test for function set_selection
def test_set_selection():
    # Test normal case
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = "tester"
    question = "question"
    vtype = "string"

# Generated at 2022-06-11 06:55:07.653047
# Unit test for function set_selection
def test_set_selection():
    # call the set_selection function passing test data to the previously created module
    ret_code, stdout, stderr = set_selection(AnsibleModule(argument_spec={}), 'testpackage', 'testquestion', 'testvtype', 'testvalue', 'testunseen')
    # if the return code is not 0, fail with the stderr message
    assert ret_code == 0, "Error while running set_selection: " + stderr
    # if the stderr is not empty, fail with the stderr
    assert stderr == "", "set_selection return stderr: " + stderr
    # if the stdout does not contain the correct value, fail
    assert stdout == "", "set_selection did not return correctly, stdout: " + stdout


# Generated at 2022-06-11 06:55:16.705572
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

# Generated at 2022-06-11 06:55:23.293216
# Unit test for function get_selections
def test_get_selections():
    import json
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    pkg = 'apt'
    res = get_selections(module, pkg)
    data = json.dumps(res)

# Generated at 2022-06-11 06:55:32.000823
# Unit test for function get_selections
def test_get_selections():
  module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
  pkg = 'tzdata'
  selections = get_selections(module, pkg)

# Generated at 2022-06-11 06:55:43.300589
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    config = {'name': 'tzdata', 'question': None, 'vtype': None, 'value': None, 'unseen': None}
    selections = get_selections(AnsibleModule(argument_spec=config), config['name'])
    keys = ['tzdata/Zones/Etc', 'tzdata/Zones/Asia', 'tzdata/Zones/Africa', 'tzdata/Zones/America', 'tzdata/Zones/Europe', 'tzdata/Areas', 'tzdata/Zones', 'tzdata/Zone', 'tzdata/Zones/Pacific', 'tzdata/Zones/Atlantic']
    for key in keys:
        assert key in selections

# Unit test

# Generated at 2022-06-11 06:55:53.275639
# Unit test for function get_selections
def test_get_selections():
    from unittest.mock import patch
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

    class Mock(object):

        def __init__(self):
            self.exit_json_called = False
            self.fail_json_called = False
            self.run_command_called = False
            self.run_command_rc = 0
            self.run_command_output = '/bin/mock'

        def exit_json(self, **kwargs):
            self.exit_json_called = True

        def fail_json(self, **kwargs):
            self.fail_json_called = True

        def get_bin_path(self, cmd, required=False):
            return 'mock.bin'


# Generated at 2022-06-11 06:57:35.459225
# Unit test for function set_selection
def test_set_selection():
  module = None
  assert set_selection(module, "test", "question", "boolean", "true", False) == 0
  assert set_selection(module, "test", "question", "boolean", "false", False) == 0
  assert set_selection(module, "test", "question", "boolean", "yes", False) == 0
  assert set_selection(module, "test", "question", "boolean", "no", False) == 0
  assert set_selection(module, "test", "question", "boolean", "on", False) == 0
  assert set_selection(module, "test", "question", "boolean", "off", False) == 0

# Generated at 2022-06-11 06:57:43.635751
# Unit test for function main
def test_main():

    # Set up some test data
    p = dict(
        name='tzdata',
        question=None,
        vtype=None,
        value=None,
        unseen=False
    )

    # Set up expected results

# Generated at 2022-06-11 06:57:52.747010
# Unit test for function main
def test_main():
    global pkg, question, vtype, value
    pkg = "tzdata"
    question = "Geographic area"
    vtype = "select"
    value = "Europe"
    test_dict = {"name": pkg,
                 "question": question,
                 "vtype": vtype,
                 "value": value}
    test_module = AnsibleModule(argument_spec = test_dict)
    prev = get_selections(test_module, pkg)
    if not prev:
        test_module.fail_json(msg="Debconf tool not found. Please verify it is installed on this system.")
    elif question not in prev:
        main()

# Generated at 2022-06-11 06:57:58.021046
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(['debconf', 'locales']) == [u'locales/default_environment_locale: fr_FR.UTF-8', u'locales/locales_to_be_generated: en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8']
# Test if question is already set

# Generated at 2022-06-11 06:58:06.477657
# Unit test for function get_selections
def test_get_selections():

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {'name': 'locales'}
            self.run_command_result_list = [
                (0, "* locales/default_environment_locale select en_US.UTF-8\n* locales/locales_to_be_generated multiselect en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8\n", ''),
                (1, '', 'Unsupported command: /usr/sbin/debconf-show\n')
            ]
            self.run_command_counter = 0
            self.fail_json_msg = []


# Generated at 2022-06-11 06:58:15.826461
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=False,
    )

    pkg = 'tzdata'
    question = 'tzdata/Zones/Europe'
    vtype = 'select'
    value = 'Europe/Paris'


# Generated at 2022-06-11 06:58:24.544728
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.debconf import main
    from ansible.module_utils._text import to_text


# Generated at 2022-06-11 06:58:33.906181
# Unit test for function main
def test_main():
    import pytest
    import os
    import json
    import platform

    retval = main()

    # Test is not valid on windows
    if platform.system() == 'Windows':
        pytest.skip("  skipping test on windows")

    # if we have a cached version of the return data, use it
    test_dir = os.path.dirname(os.path.realpath(__file__)) + '/test/runner/'
    module_path = 'ansible.builtin.debconf'
    rval = json.loads(retval)

    # set the file name
    test_file = '{}-{}-{}-{}'.format(module_path, rval['changed'], rval['msg'], '-'.join(rval['current'].keys()))

# Generated at 2022-06-11 06:58:42.519185
# Unit test for function set_selection
def test_set_selection():
    # Test defaults
    r1 = set_selection(module, 'tzdata', 'tzdata/Zones/Asia', 'multiselect', 'Asia/Tokyo', False)
    assert r1.status == 0
    assert r1.stdout == ''
    assert r1.stde
    # Test that -u can be used
    r2 = set_selection(module, 'tzdata', 'tzdata/Zones/Asia', 'multiselect', 'Asia/Tokyo', True)
    assert r2.status == 0
    assert r2.stdout == ''
    assert r2.stderr == ''
    # Test that an invalid vtype causes failure
    r3 = set_selection(module, 'tzdata', 'tzdata/Zones/Asia', 'invalid', 'Asia/Tokyo', False)
    assert r3.status

# Generated at 2022-06-11 06:58:48.187404
# Unit test for function main
def test_main():

    # Wrap module imports so this test will work in windows and linux
    module_name = 'ansible.builtin.debconf'
    module = import_module(module_name)

    # To prevent errors when testing in linux we need to override os.name
    module.os.name = 'posix'

    # To prevent errors when testing in linux we need to override get_selections
    # to mimic a real system
    def mock_get_selections(self, module, pkg):

        selections = {}
        return selections

    module.get_selections = mock_get_selections

    # To prevent errors when testing in linux we need to override set_selection
    # to mimic a real system
    def mock_set_selection(module, pkg, question, vtype, value, unseen):

        rc = 0