

# Generated at 2022-06-11 06:49:41.284226
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils import basic
    import ansible.module_utils.debconf as debconf
    import tempfile
    # your test code goes here ...

# Generated at 2022-06-11 06:49:42.486499
# Unit test for function set_selection
def test_set_selection():
    set_selection(pkg, question, vtype, value, unseen)

# Generated at 2022-06-11 06:49:51.671179
# Unit test for function get_selections
def test_get_selections():
    import io
    import os
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.common.sys_info import get_distribution

    if sys.version_info[:2] < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    # We need to fake the return of the command to test our parsing
    def get_module_args():
        return {
            'name': 'locales',
        }


# Generated at 2022-06-11 06:49:55.239073
# Unit test for function get_selections
def test_get_selections():
    test = AnsibleModule(argument_spec={})
    test_result = get_selections(test, 'tzdata')
    assert(test_result['tzdata/Areas']) == 'Europe'
    assert(test_result['tzdata/Zones/Europe']) == 'Amsterdam'

# Generated at 2022-06-11 06:50:04.714323
# Unit test for function set_selection
def test_set_selection():
    import mock
    from ansible.module_utils.basic import AnsibleModule

    def mock_run_command(*args, **kwargs):
        stdout = "".encode('utf-8')
        stderr = "".encode('utf-8')
        return (0, stdout, stderr)
    module = mock.MagicMock(name='AnsibleModule')
    module.run_command = mock_run_command
    setsel = "/usr/bin/debconf-set-selections"
    unseen = False
    pkg = "some-package"
    question = "some-question"
    vtype = "string"
    value = "some-value"
    cmd = [setsel]
    if unseen:
        cmd.append('-u')


# Generated at 2022-06-11 06:50:16.047392
# Unit test for function set_selection
def test_set_selection():
    import sys
    import os
    import os.path
    import tempfile
    import subprocess
    import shlex
    import unittest
    import filecmp
    import re
    import shutil
    import difflib

    class TestDebconf(unittest.TestCase):
        tmpdir = None

        @classmethod
        def setUpClass(cls):
            # Create a temporary directory
            cls.tmpdir = tempfile.mkdtemp(prefix='ansible_test_debconf')

        @classmethod
        def tearDownClass(cls):
            # Remove the directory after the test
            shutil.rmtree(cls.tmpdir)

        def setUp(self):
            self.test_script = os.path.join(self.tmpdir, 'test_debconf.py')
            self.module

# Generated at 2022-06-11 06:50:17.148267
# Unit test for function set_selection
def test_set_selection():
    # TODO
    # Ensure module fails if debconf-show fails
    # Ensure module fails if debconf-set-selection fails
    # Ensure set selection succeeds
    pass

# Generated at 2022-06-11 06:50:19.755376
# Unit test for function set_selection
def test_set_selection():
    # in check_mode it will not modify anything in fact
    set_selection(module, pkg, question, vtype, value, unseen)
    set_selection(module, pkg, question, vtype, value, unseen)

# Generated at 2022-06-11 06:50:24.204521
# Unit test for function main
def test_main():
    get_bin_path_orig = AnsibleModule.get_bin_path
    run_command_orig = AnsibleModule.run_command
    set_selection_orig = set_selection
    get_selections_orig = get_selections

    def run_command(self, cmd, data=None):
        return 0, 'test', ''

    def get_bin_path(self, arg, required=False):
        return arg

    class TestModule(AnsibleModule):
        pass

    def set_selection(module, pkg, question, vtype, value, unseen):
        return 0, '', ''


# Generated at 2022-06-11 06:50:35.130026
# Unit test for function set_selection
def test_set_selection():
    # Create a module object
    fake_module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # set up

# Generated at 2022-06-11 06:50:54.279885
# Unit test for function set_selection
def test_set_selection():
    # Builtins used
    import os
    # Imports for test
    import errno
    from tempfile import mkstemp
    from mock import patch

    # Mocking a debconf-set-selection
    debconf_set_selection = '#!/bin/sh\n'\
        'cat $3 > $1\n'\
        'chmod -R g-wx,o-rwx $1\n'

    (fd, debconf_set_selection_path) = mkstemp()
    try:
        os.write(fd, debconf_set_selection)
    finally:
        os.close(fd)

    # Patching ansible.module_utils.basic.AnsibleModule to return a fake module
    # and using a temporary path for debconf-set-selection

# Generated at 2022-06-11 06:51:04.196723
# Unit test for function set_selection
def test_set_selection():
    import os
    import json

    try:
        import debconf
        HAS_DEBCONF = True
    except ImportError:
        HAS_DEBCONF = False

    import sys
    from  subprocess import PIPE

    from ansible_collections.ansible.community.tests.unit.compat import mock

    from ansible_collections.ansible.community.tests.unit.mock import patch

    from ansible_collections.ansible.community.plugins.modules import debconf

    from ansible_collections.ansible.community.tests.unit.modules.utils import (
        AnsibleModule,
        set_module_args,
    )

    module_path = os.path.join(os.path.dirname(__file__), '../../../plugins/modules/debconf.py')
    deb

# Generated at 2022-06-11 06:51:13.511856
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg='tzdata'

# Generated at 2022-06-11 06:51:17.579030
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(['openssh-server', 'openssh-server/enable_X11_forwarding', 'boolean', 'true']) == 'openssh-server/enable_X11_forwarding'


# Generated at 2022-06-11 06:51:27.812145
# Unit test for function set_selection
def test_set_selection():
    # Test set_selection() for success
    m_mod_rc = True
    m_mod_msg = 'Successful'
    m_mod_err = ''
    m_mod_run_command_rc = 0
    m_mod_run_command_output = ''
    m_mod_run_command_err = ''
    m_mod_run_command_ret = (m_mod_run_command_rc, m_mod_run_command_output, m_mod_run_command_err)
    m_mod = MagicMock()
    m_mod.get_bin_path = MagicMock(return_value='/usr/bin')
    m_mod.run_command = MagicMock(return_value=m_mod_run_command_ret)
    m_pkg = 'test'

# Generated at 2022-06-11 06:51:38.379990
# Unit test for function get_selections
def test_get_selections():

    # Test run_command mock (returns an empty result - no debconf selections)
    def mock_run_command(command, data=None):
        return (0, '', '')

    # Test run_command mock (returns non-empty values for debconf selections)
    def mock_run_command_non_empty(command, data=None):
        return (0, 'locales/default_environment_locale: en_US.UTF-8', '')

    # Test run_command fails (returns exit code of 1)
    def mock_run_command_fails(command, data=None):
        return (1, '', '')

    # Create AnsibleModule for function get_selections
    module = AnsibleModule(argument_spec=dict())

    # Set module.run_command to return an error (exit code of 1

# Generated at 2022-06-11 06:51:48.734907
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
    )

    pkg = 'ansible'
    question = 'question'
    vtype = 'string'
    value = 'value'
    unseen = False
    setsel = module.get

# Generated at 2022-06-11 06:51:57.206581
# Unit test for function main
def test_main():
    # Insert return values for unit test
    return_values = {
        'name': 'openssh-server',
        'question': 'openssh-server/permit-root-login',
        'vtype': 'select',
        'value': 'True',
        'unseen': False
    }

    # grab the return values
    pkg = return_values['name']
    question = return_values['question']
    vtype = return_values['vtype']
    value = return_values['value']
    unseen = return_values['unseen']

    # make sure the question does not exist yet
    prev = {}
    print('prev: {}'.format(prev))

    changed = False


# Generated at 2022-06-11 06:52:08.256872
# Unit test for function main
def test_main():
    import sys
    import os
    import json

    # Test input for function main
    test_params = {
        "name": "tzdata",
        "question": "",
        "vtype": "",
        "value": "",
        "unseen": False,
    }
    if "check_mode" not in test_params:
        test_params["check_mode"] = False
    if "diff_mode" not in test_params:
        test_params["diff_mode"] = False
    if "platform" not in test_params:
        test_params["platform"] = "debian"

    # Example of return value for function main
    test_ret = {
        "changed": False,
        "current": {},
        "msg": ""
    }

    # Unit test for function main

# Generated at 2022-06-11 06:52:17.661290
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-11 06:52:45.238224
# Unit test for function get_selections
def test_get_selections():
    # This test requires access to a Debian/Ubuntu box
    import os
    import tempfile
    module = AnsibleModule(argument_spec={})
    (fd, temp_path) = tempfile.mkstemp()
    os.close(fd)
    pkg = "debconf"
    rc, out, err = module.run_command(' '.join([module.get_bin_path('debconf-show', True), pkg]))

    if rc != 0:
        module.fail_json(msg=err)

    selections = {}

    for line in out.splitlines():
        (key, value) = line.split(':', 1)
        selections[key.strip('*').strip()] = value.strip()

    assert ('debconf/frontend' in selections)
    assert ('debconf/priority' in selections)

# Generated at 2022-06-11 06:52:47.252190
# Unit test for function set_selection
def test_set_selection():
    module.set_selection(module, pkg, question, vtype, value, unseen)

# Generated at 2022-06-11 06:52:56.861682
# Unit test for function set_selection
def test_set_selection():

    settings = {
        ('pkg1', 'question1', 'vtype1', 'value1', True): ('', '', ''),
        ('pkg2', 'question2', 'vtype2', 'value2', True): ('', '', ''),
        ('pkg3', 'question3', 'vtype3', 'value3', True): ('', '', '')
    }

    def mock_run_command(module, cmd, data):
        return settings[tuple(cmd+[data])]

    m = AnsibleModule(argument_spec={})
    m.run_command = mock_run_command
    rc, msg, err = set_selection(m, 'pkg1', 'question1', 'vtype1', 'value1', True)
    assert rc == 0
    assert msg == ''
    assert err == ''

# Generated at 2022-06-11 06:52:59.965474
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(['test-package1', 'test-package2']) == {'test-package1': 'test-value1', 'test-package2': 'test-value2'}


# Generated at 2022-06-11 06:53:10.316367
# Unit test for function get_selections
def test_get_selections():
    from ansible.modules.packaging.os import debconf
    import os
    import tempfile

    tmpdir = tempfile.mkdtemp()
    f = open(tmpdir + '/debconf-show', 'w')
    f.write('''#!/bin/bash
cat << 'EOF'
* locales/locales_to_be_generated: 
  en_US.UTF-8 UTF-8
  fr_FR.UTF-8 UTF-8
* locales/default_environment_locale:   
  fr_FR.UTF-8
EOF
''')
    f.close()
    os.chmod(tmpdir + '/debconf-show', 0o755)
    f = open(tmpdir + '/ansible.cfg', 'w')

# Generated at 2022-06-11 06:53:10.923455
# Unit test for function get_selections
def test_get_selections():
    pass

# Generated at 2022-06-11 06:53:21.852167
# Unit test for function set_selection
def test_set_selection():
    # Import here instead of top of file to avoid polluting the namespace
    import sys
    from io import StringIO
    class FakeModule(object):
        def __init__(self):
            self.run_command = mock_run_command

        def get_bin_path(self, foo, bar):
            return foo

        def fail_json(self, **kwargs):
            return dict(failed=True, kwargs=kwargs)

    module = FakeModule()
    from ansible.module_utils.debconf import set_selection

    # Happy path - no errors
    def mock_run_command(cmd, data):
        return (0, "stdout", "stderr")

    # Error should be passed through

# Generated at 2022-06-11 06:53:31.848412
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = module.params["name"]
    question = module.params["question"]
    vtype = module.params["vtype"]


# Generated at 2022-06-11 06:53:41.153070
# Unit test for function set_selection
def test_set_selection():
    import os
    import tempfile
    import shutil
    import ansible.module_utils.debconf
    import ansible.module_utils.action_common
    import ansible.module_utils.basic
    import ansible.module_utils.common.strict_kwargs
    import ansible.module_utils.common.display
    import ansible.module_utils.ansible_release
    import ansible.module_utils.six
    from ansible.module_utils.six import PY2

    test_pkg = 'test_debconf'
    test_question = 'test_question'
    test_vtype = 'test_vtype'
    test_value = 'test_value'
    test_unseen = False


# Generated at 2022-06-11 06:53:41.709011
# Unit test for function main
def test_main():
    assert main([]) == False


# Generated at 2022-06-11 06:54:33.857806
# Unit test for function main
def test_main():
    # Setup
    p = mock_module.params
    p.update({'name':'tzdata', 'question': 'tzdata/Areas', 'vtype': 'select', 'value': 'Europe'})

    # Test
    main()

    # Teardown
    # None needed

    # Return
    return

# Generated at 2022-06-11 06:54:43.869928
# Unit test for function set_selection
def test_set_selection():
    import datetime as dt
    import os
    import shutil
    import tempfile

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    from ansible.modules.system.debconf import set_selection

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught
        by the test case"""
        pass

    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught
        by the test case"""
        pass

    # Create temporary directory to be used in test_set_selection
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-11 06:54:51.699516
# Unit test for function get_selections
def test_get_selections():
    out = (
        "* locales/locales_to_be_generated: en_US.UTF-8 UTF-8, fr_US.UTF-8 UTF-8, de_DE.UTF-8 UTF-8, ja_JP.UTF-8 UTF-8, es_ES.UTF-8 UTF-8, en_GB.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8, it_IT.UTF-8 UTF-8, zh_CN.UTF-8 UTF-8, zh_TW.UTF-8 UTF-8\n"
        "* locales/default_environment_locale: fr_FR.UTF-8\n"
        "* locales/update-locale: \n"
    )
    selections = get_selections(None, None, out)

# Generated at 2022-06-11 06:55:01.186007
# Unit test for function main
def test_main():
    # Test case 1
    test_1_pkg = 'locales'
    test_1_question = 'locales/default_environment_locale'
    test_1_vtype = 'select'
    test_1_value = 'fr_FR.UTF-8'


# Generated at 2022-06-11 06:55:03.170483
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(None, 'tzdata') is not None
    assert get_selections(None, 'invalid') is None


# Generated at 2022-06-11 06:55:07.999993
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(argument_spec=dict())
    assert get_selections(module, 'tzdata') == {'tzdata/Areas': 'Europe', 'tzdata/Zones/Europe': 'Berlin', 'tzdata/Zones/Etc': 'UTC', 'tzdata/Zone': 'Europe/Berlin'}


# Generated at 2022-06-11 06:55:15.673650
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(argument_spec={})
    rc, msg, err = set_selection(module, "locales", "locales/locales_to_be_generated", "multiselect", "en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8", False)
    assert rc == 0
    rc, msg, err = set_selection(module, "locales", "locales/locales_to_be_generated", "multiselect", "en_US.UTF-8 UTF-8", True)
    assert rc == 0

# Generated at 2022-06-11 06:55:26.921301
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    module.boolean = lambda x: True

# Generated at 2022-06-11 06:55:28.891743
# Unit test for function set_selection
def test_set_selection():
    assert set_selection(None, 'foo', 'bar', 'baz', 'boo') == 'baz'

# Generated at 2022-06-11 06:55:40.773776
# Unit test for function get_selections
def test_get_selections():
    pkg = "ansible.builtin.debconf"
    question = "test_question"
    # Create a module_args dict specifying the test values for a debconf-set-selections command
    module_args = {
        'name': pkg,
        'question': question
    }
    # Create a module_results dict to store the results of the command
    module_results = {
        'changed': False,
        'rc': 0,
        'stdout': "",
        'stderr': "",
        'msg': ""
    }
    # Populate the module_results dict with the results from a test run of the command
    module_results['stdout'] = "test_question: test_value\n"
    # Create a test_selections dict to store the test values for the expected output of get_selections


# Generated at 2022-06-11 06:57:20.244431
# Unit test for function set_selection
def test_set_selection():
    class FakeModule(object):
        def __init__(self):
            self.check_mode = False
            self.run_command_results = []

        def run_command(self, command, data=None):
            return self.run_command_results.pop(0)

        def get_bin_path(self, app, required=False):
            if app == 'debconf-show':
                return '/usr/bin/debconf-show'
            if app == 'debconf-set-selections':
                return '/usr/bin/debconf-set-selections'

    # Test success
    module = FakeModule()

# Generated at 2022-06-11 06:57:29.046107
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    test_pkg = 'tzdata'

# Generated at 2022-06-11 06:57:31.680050
# Unit test for function get_selections
def test_get_selections():
    res = get_selections('tzdata')
    assert sorted(res) == sorted({'tzdata/Areas': 'America', 'tzdata/Zones/America': 'Los_Angeles'})



# Generated at 2022-06-11 06:57:40.373332
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    module.run_command = MagicMock(return_value=('', '', ''))

# Generated at 2022-06-11 06:57:43.071181
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(argument_spec={})
    try:
        pkg = "tzdata"
        result = get_selections(module, pkg)
        assert result
    except Exception:
        assert False



# Generated at 2022-06-11 06:57:52.083572
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = "coreutils"
    question = "coreutils/noreplace"
    vtype = "boolean"

# Generated at 2022-06-11 06:58:01.181778
# Unit test for function get_selections
def test_get_selections():
    question = 'debconf_selections'
    vtype = 'string'
    value = 'some value'
    pkg = 'my_fake_pkg'
    cmd = "debconf-show %s |grep '^%s:.*$' | sed \"s/[^:]*: //\" " % (pkg, question)
    rc, out, err = module.run_command(cmd)
    (rc, out, err) = set_selection(module, pkg, question, vtype, value, False)
    (rc, out, err) = set_selection(module, pkg, question, vtype, value, False)
    if rc:
        print("error: %s" % err)
    assert err == ''
    assert rc == 0

# Generated at 2022-06-11 06:58:08.274087
# Unit test for function main
def test_main():
    # Testing pkg with a single option
    pkg = "tzdata"
    question = "tzdata/Areas"
    vtype = "select"
    value = "America"
    unseen = False

    prev = get_selections(module, pkg)
    prev = {question: prev[question]}

    changed = False
    if vtype == 'boolean':
        value = to_text(value).lower()
        existing = to_text(prev[question]).lower()
    else:
        existing = prev[question]
    if value != existing:
        changed = True

    module.exit_json(changed=changed, current=prev)


# Generated at 2022-06-11 06:58:10.928344
# Unit test for function set_selection
def test_set_selection():
    assert set_selection(None, 'test_package', 'test_question', 'test_type', 'test_value', False) == (1, '', 'test_package test_question test_type test_value\n')

# Generated at 2022-06-11 06:58:12.161587
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(module, pkg) is not None