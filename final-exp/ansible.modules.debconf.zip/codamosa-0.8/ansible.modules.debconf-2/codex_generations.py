

# Generated at 2022-06-11 06:49:36.787972
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(None, 'locales') == {'locales/default_environment_locale': 'en_GB.UTF-8', 'locales/locales_to_be_generated': 'en_GB.UTF-8 UTF-8'}
    assert get_selections(None, 'tzdata') == {'tzdata/Areas': 'Europe', 'tzdata/Zones/Europe': 'London'}

# Generated at 2022-06-11 06:49:38.868338
# Unit test for function get_selections
def test_get_selections():
    """Test that get_selections returns the correct output"""
    result = get_selections('module', 'package')
    assert result == {}

# Generated at 2022-06-11 06:49:48.080013
# Unit test for function main
def test_main():
    # AnsibleModule subclass with a faked exit_json, fail_json and no_log
    class TestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(TestModule, self).__init__(*args, **kwargs)
            self.exit_json = lambda x: None
            self.fail_json = lambda x: None
            self.no_log = lambda x: None

    # Test data for function main
    test_data = [{'name': 'locales', 'question': 'locales/locales_to_be_generated', 'vtype': 'multiselect', 'value': 'en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8'}]

    # Mock AnsibleModule.run_command

# Generated at 2022-06-11 06:49:56.477485
# Unit test for function set_selection
def test_set_selection():
    if os.geteuid() != 0:
        return
    module_path = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, module_path + '/../')
    from ansible.module_utils.basic import AnsibleModule
    import debconf
    assert debconf.set_selection(module, 'tzdata', 'tzdata/Areas', 'select', 'Asia', unseen) == None
    assert debconf.set_selection(module, 'tzdata', 'tzdata/Zones/Asia', 'select', 'Seoul', unseen) == None
    assert debconf.set_selection(module, 'tzdata', 'tzdata/Zones/Asia', 'select', 'Tokyo', unseen) != None

# Generated at 2022-06-11 06:50:06.825392
# Unit test for function main
def test_main():
    # Set up arguments used by the ansible module
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text

    mock_module = MagicMock()
    mock_module.get_bin_path = MagicMock()

    # Set up the return values of the mocked function
    mock_module.check_mode = False
    mock_module.params = {'name':'oracle-java7-installer',
                            'question':'shared/accepted-oracle-license-v1-1',
                            'unseen':False,
                            'value':'true',
                            'vtype':'select'}
    p

# Generated at 2022-06-11 06:50:17.527276
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        assert(main()) == None
    def set_module_args(args):
        args = json.dumps({'ANSIBLE_MODULE_ARGS': args})
        basic._ANSIBLE_ARGS = to_text(args)

    if not os.path.exists('/bin/debconf-show'):
        pytest.skip("debconf-show not found")

    # Configure the parameters that would be returned by querying the
    # remote device
    set_module_args({'name': 'foo',
                     'question': 'bar',
                     'vtype': 'boolean',
                     'value': 'True'})

    # Add the modules underlying code path as one of the
    # paths that we search for modules.  This allows
    # the unit test framework to find any Ans

# Generated at 2022-06-11 06:50:22.337808
# Unit test for function set_selection
def test_set_selection():
    output_data = 'testpkg testquestion testvtype testvalue'
    set_selection_mock = Mock(return_value=(0, '', ''))
    with patch.dict(debconf.__salt__, {'cmd.run_all': set_selection_mock}):
        debconf.set_selection('testpkg', 'testquestion', 'testvtype', 'testvalue', False)
        set_selection_mock.assert_called_once_with(['debconf-set-selections'], data=output_data)

    output_data = '-u testpkg testquestion testvtype testvalue'
    set_selection_mock = Mock(return_value=(0, '', ''))

# Generated at 2022-06-11 06:50:33.230067
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg'])
        )
    )
    module.run_command = MagicMock(return_value=(0, "* debconf/frontend: noninteractive\n* locales/locales_to_be_generated: en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8\n* locales/default_environment_locale: en_US.UTF-8\n", ""))

    result = get_selections(module, "package")

# Generated at 2022-06-11 06:50:33.729647
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 06:50:45.708905
# Unit test for function get_selections
def test_get_selections():
    print("testing get_selections")
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = 'locales'

# Generated at 2022-06-11 06:51:04.429038
# Unit test for function main

# Generated at 2022-06-11 06:51:13.693971
# Unit test for function get_selections
def test_get_selections():

    o = (0, "* apt-setup/universe_deb boolean true\n"
            "* clock-setup/ntp boolean true\n"
            "* debconf debconf/frontend select noninteractive\n"
            "* debconf debconf/priority select critical\n"
            "* debconf debconf/retriever select Canna\n",
            "")
    m = Mock()
    m.run_command.return_value = o
    m.get_bin_path.return_value = 'fake'
    m.check_mode.return_value = False
    m.params = {'name': 'debian-installer'}
    x = get_selections(m, 'debian-installer')
    assert x['apt-setup/universe_deb'] == 'true'

# Generated at 2022-06-11 06:51:18.165129
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(argument_spec=dict(
        name=dict(type='str', required=True, aliases=['pkg'])
    ))
    assert get_selections(module, 'tzdata') == [dict(name='tzdata'), dict(name='common')]

# Generated at 2022-06-11 06:51:22.373350
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(['locales', 'locales/locales_to_be_generated', 'multiselect', 'en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8']) == None

# Generated at 2022-06-11 06:51:30.197591
# Unit test for function get_selections
def test_get_selections():
    from os.path import expanduser, join
    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible.module_utils.basic import AnsibleModule

    if 'USER' in os.environ:
        user = os.environ['USER']
    else:
        user = 'default_user'

    def set_dest_dir():
        mkdtemp(prefix='ansible_test_debconf')

    dest_dir = set_dest_dir()

    fixtures_path = expanduser(join("~", ".ansible", "tmp", "tests", "fixtures", "tmp", "test_install_debconf", "test_package"))

    def install_package():
        shutil.copytree(fixtures_path, dest_dir)

    install_package()


# Generated at 2022-06-11 06:51:40.598897
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
                           argument_spec=dict(
                                                name=dict(type='str', required=True, aliases=['pkg']),
                                                question=dict(type='str', aliases=['selection', 'setting']),
                                                vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
                                                value=dict(type='str', aliases=['answer']),
                                                unseen=dict(type='bool', default=False),
                                             ),
                           required_together=(['question', 'vtype', 'value'],),
                           supports_check_mode=True,
                          )
    pkg = ''
    expectedResult = {}
    result = get_

# Generated at 2022-06-11 06:51:49.395384
# Unit test for function get_selections
def test_get_selections():
    # getting package list
    cmd = ['debconf-show', 'locales']
    rc, out, err = module.run_command(cmd)

    if rc != 0:
        module.fail_json(msg=err)

    # variable to store the results
    selections = []

    for line in out.splitlines():
        (key, value) = line.split(':', 1)
        selections.append(line.strip('*').strip())

    # check if 'locales/default_environment_locale' exist if yes, then return True
    if 'locales/default_environment_locale' in selections:
        return True
    else:
        return False


# Generated at 2022-06-11 06:51:53.825374
# Unit test for function get_selections
def test_get_selections():
    test_module = AnsibleModule(argument_spec=dict(
        name=dict(type='str', required=True, aliases=['pkg']),
    ))

    # Create a test data set
    selections = {'debconf-show': './test/debconf-show', 'pkg': 'tzdata'}

    # Create a test instance
    test = get_selections(test_module, selections['pkg'])

    # Expected output of test_get_selections
    expected = {'debconf-show': './test/debconf-show', 'pkg': 'tzdata'}

    # Assert if the test output and expected output is not equal.
    assert test == expected

# Generated at 2022-06-11 06:51:54.995959
# Unit test for function get_selections
def test_get_selections():
    assert(get_selections('foo') == {'bar': 'baz'})

# Generated at 2022-06-11 06:51:55.492444
# Unit test for function get_selections
def test_get_selections():
    pass

# Generated at 2022-06-11 06:52:22.122312
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=False,
    )
    module.run_command = MagicMock(name='run_command')

# Generated at 2022-06-11 06:52:29.576982
# Unit test for function get_selections
def test_get_selections():
    try:
        # Try to import Python 2 modules using their Python 3 names.
        from StringIO import StringIO
    except ImportError:
        # Import modules using their Python 2 names instead.
        from io import StringIO
    import sys
    try:
        # Try to import Python 2 modules using their Python 3 names.
        from mock import patch
    except ImportError:
        # Import modules using their Python 2 names instead.
        from unittest.mock import patch

    from ansible.modules.packaging.os.debconf import get_selections

    class AnsibleModule(object):
        def __init__(self, argument_spec, required_together=None, supports_check_mode=False):
            self.argument_spec = argument_spec
            self.required_together = required_together
            self.supports_check_mode = supports

# Generated at 2022-06-11 06:52:40.356076
# Unit test for function set_selection
def test_set_selection():
    """ Mock function to test debconf.set_selection
    """
    from ansible.module_utils.basic import AnsibleModule
    class MockModule(AnsibleModule):
        ''' Mock class to test debconf.set_selection
        '''
        def __init__(self):
            self.failjson_called = False
            self.run_command_called = 0
        def fail_json(self, **kwargs):
            self.failjson_called = True
        def run_command(self, **kwargs):
            self.run_command_called = self.run_command_called + 1
            return 0, "", ""
    test_module = MockModule()
    debconf.get_bin_path = lambda x, y: ""

# Generated at 2022-06-11 06:52:50.810237
# Unit test for function main
def test_main():
    # Tests for main()
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

# Generated at 2022-06-11 06:52:53.083688
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 06:52:58.601163
# Unit test for function main
def test_main():
    # Mock module.exit_json()
    def exit_json_mock(changed, msg, current, previous):
        module.exit_json = exit_json_mock
        assert changed == False
        assert msg == 'question not found'
        assert current is None
        assert previous is None
    module = AnsibleModule(dict(name='fail', question='fail'))
    module.exit_json = exit_json_mock
    main()

# Generated at 2022-06-11 06:53:09.002610
# Unit test for function main
def test_main():
    module = AnsibleModule(
            argument_spec=dict(
                name=dict(type='str', required=True, aliases=['pkg']),
                question=dict(type='str', aliases=['selection', 'setting']),
                vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
                value=dict(type='str', aliases=['answer']),
                unseen=dict(type='bool', default=False),
            ),
            required_together=(['question', 'vtype', 'value'],),
            supports_check_mode=True,
            )
    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-11 06:53:19.706772
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-11 06:53:29.646268
# Unit test for function set_selection
def test_set_selection():
    #Function to get the module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    #Package name
    pkg = 'tzdata'
    #Question name

# Generated at 2022-06-11 06:53:39.438676
# Unit test for function main
def test_main():
    test_args = ['ansible.builtin.debconf', '-a', 'name=tzdata']
    module = AnsibleModule(argument_spec=dict(
        name = dict(type='str', required=True, aliases=['pkg']),
        question = dict(type='str', aliases=['selection', 'setting']),
        vtype = dict(type='str', required=True, choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
        value = dict(type='str', aliases=['answer']),
        unseen = dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

# Generated at 2022-06-11 06:54:44.540760
# Unit test for function set_selection
def test_set_selection():
    #  If a .deb package is selected, set_selection will return the settings for that package, otherwise it will return nothing.
    assert set_selection('debconf', 'pkg', 'question', 'boolean', 'true', 'unseen') == 'settings'

    #  If a package is not selected, set_selection will return nothing
    assert set_selection('debconf', 'pkg', 'question', 'select', 'true', 'unseen') == ''

    #  If the vtype is invalid, set_selection will return nothing
    assert set_selection('debconf', 'pkg', 'question', '', 'true', 'unseen') == ''


# Generated at 2022-06-11 06:54:45.935514
# Unit test for function set_selection
def test_set_selection():
    """
    Test the set_selection function.
    """
    assert True

# Generated at 2022-06-11 06:54:52.597597
# Unit test for function main
def test_main():
    import os
    import tempfile
    pkg = 'tzdata'
    question = 'tzdata/Zones/Etc'
    vtype = 'select'
    value = 'Universal'

    # Make sure we have the tzdata package and the question we are looking for
    assert os.system('dpkg-query -l %s > /dev/null' % pkg) == 0
    assert os.system('debconf-show %s | grep %s' % (pkg, question)) == 0
    assert os.system('debconf-get-selections | grep %s' % pkg) == 0

    # Get the current value of the setting, it will change if the module works

# Generated at 2022-06-11 06:55:01.638035
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = "tzdata"

# Generated at 2022-06-11 06:55:11.861712
# Unit test for function get_selections
def test_get_selections():
   assert get_selections(None, "vim") == {'vim/question1': 'value1', 'vim/question2': 'value2'}
   assert get_selections(None, "toto") == {'toto/question1': 'value1', 'toto/question2': 'value2', 'toto/question3': 'value3'}

# Generated at 2022-06-11 06:55:22.848912
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(argument_spec=dict(
        name = dict(required = True),
        question = dict(required = True),
        value = dict(required = True),
        vtype = dict(required = True),
        unseen = dict(required = False, default = False)
    ),
    supports_check_mode = False)

    pkg = module.params["name"]
    question = module.params["question"]
    vtype = module.params["vtype"]
    value = module.params["value"]
    unseen = module.params["unseen"]

    (rc, out, err) = set_selection(module, pkg, question, vtype, value, unseen)
    return err

# Generated at 2022-06-11 06:55:30.712321
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

# Generated at 2022-06-11 06:55:36.679320
# Unit test for function set_selection
def test_set_selection():
    setsel = get_bin_path('debconf-set-selections', True)
    cmd = [setsel, '-u']
    data = ' '.join(['locales', 'locales/default_environment_locale', 'select', 'fr_FR.UTF-8'])

    rc, msg, e = set_selection(cmd, data)
    assert e is None


# Generated at 2022-06-11 06:55:39.278812
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(None, "tzdata")['tzdata/Areas'] == 'Africa America Antarctica Asia Atlantic Australia Europe Indian Pacific Arctic'

# Generated at 2022-06-11 06:55:50.225511
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: Test with different debconf query output
    return_msg = get_selections(module, 'tzdata')

# Generated at 2022-06-11 06:57:37.302305
# Unit test for function set_selection
def test_set_selection():
    # Check that set_selection returns the correct exit codes
    # Basic tests
    result = set_selection(module, pkg, question, vtype, value, unseen)
    assert result[0] == 0
    assert result[1] == ''
    assert result[2] == ''

    # Test for error
    result = set_selection(module, 'errorpackage', question, vtype, value, unseen)
    assert result[0] == 1
    assert result[1] == ''
    assert result[2] != ''

    # Test for password
    result = set_selection(module, pkg, question, 'password', value, unseen)
    assert result[0] == 0
    assert result[1] == ''
    assert result[2] == ''


# Generated at 2022-06-11 06:57:41.648488
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(1, 'base-files') == {
        'base-files/kernel/name': 'linux-image-amd64',
        'base-files/postinst_kernel/name': 'linux-image-amd64',
        'base-files/postinst_kernel/type': 'string',
        'base-files/postinst_kernel/value': 'linux-image-amd64'
    }

# Generated at 2022-06-11 06:57:50.486943
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    # Test selection with no value set
    selections = get_selections(module, 'locales')

# Generated at 2022-06-11 06:58:00.298068
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    result = {}
    result["name"] = "tzdata"
    result["question"] = None
    result["vtype"] = None


# Generated at 2022-06-11 06:58:02.605922
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    result = get_selections(module,"tzdata")

    assert len(result) > 0


# Generated at 2022-06-11 06:58:07.435496
# Unit test for function set_selection
def test_set_selection():
    cmd = ['debconf-set-selections']
    data = ' '.join(['locales', 'locales/locales_to_be_generated', 'multiselect', 'en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8'])
    rc, msg, e = set_selection(data)
    if rc:
        print(e)
    else:
        print(msg)


# Generated at 2022-06-11 06:58:08.600634
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(pkg=['test']) == ['test']

# Generated at 2022-06-11 06:58:13.242542
# Unit test for function get_selections
def test_get_selections():
    from ansible.utils.path import unfrackpath
    assert unfrackpath(get_selections(module.get_bin_path('debconf-show', True), 'debconf-show'), module.get_bin_path('debconf-show', True)) == {u'*debconf-show/purge': u'false', u'*debconf-show/nowarn': u'false'}



# Generated at 2022-06-11 06:58:19.265374
# Unit test for function main
def test_main():
    import os, tempfile
    tmpfd, tmpfile = tempfile.mkstemp()
    os.close(tmpfd)
    module = AnsibleModule({})
    module._diff = False
    module.run_command = lambda x, data=None, check_rc=False, close_fds=True: (0, '', '')
    assert main() == {'changed': False, 'current': {}, 'msg': ''}


# Generated at 2022-06-11 06:58:28.156624
# Unit test for function main
def test_main():
    import json
    from ansible.module_utils import basic

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    module._diff = True
