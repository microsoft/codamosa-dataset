

# Generated at 2022-06-11 06:49:41.040413
# Unit test for function set_selection
def test_set_selection():
    setsel = module.get_bin_path('debconf-set-selections', True)
    cmd = [setsel]
    if unseen:
        cmd.append('-u')

    if vtype == 'boolean':
        if value == 'True':
            value = 'true'
        elif value == 'False':
            value = 'false'
    data = ' '.join([pkg, question, vtype, value])

    return module.run_command(cmd, data=data)


# Generated at 2022-06-11 06:49:50.156840
# Unit test for function main
def test_main():
    from ansible.module_utils.common._json_compat import json
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.ec2 import camel_dict_to_snake_dict, date_time_handler
    from ansible.module_utils.ec2 import boto3_tag_list_to_ansible_dict
    import pytest
    import os
    import json
    import tempfile

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass


# Generated at 2022-06-11 06:49:59.915246
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule({})

    # Given
    pkg = 'tzdata'

    # When
    selections = get_selections(module, pkg)

    # Then

# Generated at 2022-06-11 06:50:10.121831
# Unit test for function get_selections
def test_get_selections():
    class AnsibleModule_local(object):

        def run_command(self, cmd, data=None):
            return 0, """locales package/installation/keymap: Select keymap from full list
locales shared/default-country: Select your country_of_origin from the list
locales shared/language-pack-patterns: Select the language patterns you would like to have installed
locales shared/language-pack-patterns-remove: Select the language patterns you would like to have removed""", ''

        def fail_json(self, msg):
            raise ValueError(msg)

        def get_bin_path(self, name, required):
            return '/usr/bin/' + name

        def exit_json(self, changed, msg, current, previous):
            assert False

    mod = AnsibleModule_local()
    result = get_selections

# Generated at 2022-06-11 06:50:20.194138
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = "tzdata"
    question = "selections/default_environment_locale"
    vtype = "select"
   

# Generated at 2022-06-11 06:50:31.640081
# Unit test for function get_selections
def test_get_selections():
    # unit test for function get_selections
    class TestAnsibleModule:
        def __init__(self):
            self.params = []
        def fail_json(self, a):
            return False
        def get_bin_path(self, a, b):
            return "/bin/false"
        def run_command(self, a):
            return 0
    testArgs = {
        'name': 'locales',
    }
    testModule = TestAnsibleModule()
    testModule.params = testArgs

    # Execute the code to test
    results = get_selections(testModule, testArgs['name'])
    assert(results['locales/locales_to_be_generated'] == 'en_US.UTF-8 UTF-8')

# Generated at 2022-06-11 06:50:39.513504
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(argument_spec=dict())
    import tempfile
    fd, fname = tempfile.mkstemp(suffix='.deb')
    os.close(fd)

    try:
        # Unknown file should return a non-zero return code
        rc, out, err = set_selection(module, fname, 'foo', 'boolean', 'true')
        assert rc != 0

        # debconf-set-selections needs stdin data
        rc, out, err = set_selection(module, fname, 'foo', 'boolean', 'true')
        assert rc != 0
    finally:
        os.remove(fname)

# Generated at 2022-06-11 06:50:41.025759
# Unit test for function get_selections
def test_get_selections():
    assert get_selections('tzdata') is True

# Generated at 2022-06-11 06:50:41.725011
# Unit test for function get_selections
def test_get_selections():
    pass

# Generated at 2022-06-11 06:50:52.655462
# Unit test for function get_selections

# Generated at 2022-06-11 06:51:10.615793
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    module = basic.AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        #supports_check_mode=True,
    )
    p

# Generated at 2022-06-11 06:51:17.130329
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule
    ret = set_selection(AnsibleModule(argument_spec={}), 'tzdata', 'tzdata/Zones/Europe', 'select', 'Amsterdam', False)
    assert ret[0] == 0
    assert ret[1] == ''
    assert ret[2] == ''
    ret = set_selection(AnsibleModule(argument_spec={}), 'tzdata', 'tzdata/Zones/Europe', 'select', 'Bad Zone', False)
    assert ret[0] != 0
    assert ret[1] == ''
    assert ret[2] != ''

# Generated at 2022-06-11 06:51:24.480414
# Unit test for function get_selections
def test_get_selections():
    test_module = AnsibleModule({})
    test_pkg = 'tzdata'
    test_result = get_selections(test_module, test_pkg)
    assert test_result is not None
    assert test_result['debconf/frontend'] == 'readline'
    assert test_result['tzdata/Areas'] == 'America'
    assert test_result['tzdata/Zones/America'] == 'Chicago'
    assert test_result['tzdata/Zones/America/Chicago'] == ''


# Generated at 2022-06-11 06:51:31.331845
# Unit test for function main
def test_main():
    """ Test module's main function """
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.debconf import get_selections, set_selection
    from ansible.module_utils.action.builtin import AnsibleModule

    # test data for function get_selections
    # returns dict with debconf keys
    get_selections_correct_data = {
        'rc': 0,
        'out': '\n',
        'err': ''
    }

    # test data for function get_selections
    # returns dict with debconf keys

# Generated at 2022-06-11 06:51:32.393207
# Unit test for function main
def test_main():
    import pdb; pdb.set_trace()

# Generated at 2022-06-11 06:51:37.317085
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.basic import AnsibleModule
    test_ansible_module = AnsibleModule({'name':'foo','question':'bar','vtype':'boolean','value':'True'})
    test_pkg = 'bar'
    assert get_selections(test_ansible_module,test_pkg) == {}


# Generated at 2022-06-11 06:51:47.533877
# Unit test for function get_selections
def test_get_selections():
    '''
    Running the module in check mode should get the current value for the question.
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.ansible_galaxy import GalaxyError


# Generated at 2022-06-11 06:51:49.393909
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(
        "",
        "bla") == {}


# Generated at 2022-06-11 06:51:57.634967
# Unit test for function main
def test_main():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.debconf import get_selections, set_selection
    from ansible.builtin._command import _execute_unix_shell_commands
    import unittest


# Generated at 2022-06-11 06:51:58.548967
# Unit test for function set_selection
def test_set_selection():
    main()

# Generated at 2022-06-11 06:52:19.572283
# Unit test for function get_selections
def test_get_selections():
    import debconf
    debconf_module = debconf.Debconf()
    # The function get_selections accepts a module as its first argument
    # so we need to pass any module to it
    ansible_module = AnsibleModule(argument_spec=dict())
    pkg = 'locales'
    assert get_selections(ansible_module, pkg) == debconf_module.get_selections(pkg)


# Generated at 2022-06-11 06:52:24.042078
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={'state': dict(choices=['absent', 'present'], default='present'), 'repository': dict(required=True), 'key': dict(required=True)}, supports_check_mode=True)
    main()


# Generated at 2022-06-11 06:52:33.302902
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile
    import sys
    import unittest

    class DebugLogger(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            unittest.TestCase.__init__(self, *args, **kwargs)
            self.args = args
            self.kwargs = kwargs
            self.log = ''

        def __call__(self, func):
            def wrapper(*args, **kwargs):
                _args = self.args + args
                _kwargs = dict(self.kwargs)
                _kwargs.update(kwargs)
                self.log = _kwargs['log']
                return func(*_args, **_kwargs)
            return wrapper


# Generated at 2022-06-11 06:52:44.280513
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
    )

    pkg = 'test-package'
    question = 'test-question'
    vtype = 'select'
    value = 'test-value'
    unseen = True

# Generated at 2022-06-11 06:52:44.973470
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 06:52:55.695244
# Unit test for function set_selection
def test_set_selection():
    import mock
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or deb

# Generated at 2022-06-11 06:53:06.089673
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule
    import tempfile

    module = AnsibleModule(argument_spec={}, add_file_common_args=True)
    module.params['_ansible_check_mode'] = False
    module.params['_ansible_diff'] = False

    (fd, tempfilename) = tempfile.mkstemp(prefix='ansible_test_')

    os.write(fd, b"""question1:answer1
question2:answer2
""")

    os.close(fd)
    module.params['path'] = tempfilename
    module.params['show_content'] = True
    x = get_selections(module, 'pkg')

    assert x['question1'] == 'answer1'

# Generated at 2022-06-11 06:53:15.130168
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.debconf import DebconfHelper
    # TODO: What is the best way to test this kind of stuff ?
    # I don't like the use of /usr/bin/python.
    h = DebconfHelper('/usr/bin/python', '/usr/sbin/debconf-set-selections', '-u')
    h.set_selection('test_module', 'test_question', 'test_vtype', 'test_value', True)
    assert h.cmd == '/usr/bin/python /usr/sbin/debconf-set-selections -u'
    assert h.input == 'test_module test_question test_vtype test_value'

# Generated at 2022-06-11 06:53:21.895544
# Unit test for function get_selections
def test_get_selections():
    test_module = AnsibleModule(
            argument_spec=dict(
                name=dict(type='str'),
                question=dict(type='str'),
                vtype=dict(type='str'),
                value=dict(type='str'),
                unseen=dict(type='bool', default=False),
            ),
            required_together=(['question', 'vtype', 'value'],),
            supports_check_mode=True,
        )
    assert get_selections(test_module, "tzdata")



# Generated at 2022-06-11 06:53:31.898427
# Unit test for function main
def test_main():
    """test_main"""
    # Set up mock values to test module
    pkg = "test"
    question = "q1"
    vtype = "string"
    value = "abc"
    unseen = True
    module_args = {"name": pkg, "question": question, "vtype": vtype, "value": value, "unseen": unseen}

# Generated at 2022-06-11 06:54:26.436404
# Unit test for function main
def test_main():
    # Test 1
    # No arguments
    args = {}
    result = main(args)
    assert result['failed'] is True
    assert 'missing required arguments' in result['msg']

    # Test 2
    # Only name
    args = {'name': 'sudo'}
    result = main(args)
    assert result['changed'] is False
    assert result['msg'] == ''

    # Test 3
    # Question, vtype, value with no matching existing question
    args = {'name': 'sudo', 'question': 'test', 'vtype': 'string', 'value': 'test'}
    result = main(args)
    assert result['changed'] is True
    assert result['current'] == {'test': 'test'}
    assert result['previous'] == {'test': ''}

    # Test 4
    # Question

# Generated at 2022-06-11 06:54:34.485216
# Unit test for function set_selection

# Generated at 2022-06-11 06:54:44.633666
# Unit test for function get_selections
def test_get_selections():

    import subprocess
    from tempfile import NamedTemporaryFile
    from ansible.module_utils.six import PY3

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # Create

# Generated at 2022-06-11 06:54:46.040167
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(__name__, "tzdata") != None

# Generated at 2022-06-11 06:54:48.551114
# Unit test for function get_selections
def test_get_selections():
    (rc, out, err) = get_selections(module, 'tzdata')
    assert rc == 0
    assert err == ''
    assert out['tzdata/Areas'] == 'America'

# Generated at 2022-06-11 06:54:49.197158
# Unit test for function set_selection
def test_set_selection():
    assert True

# Generated at 2022-06-11 06:54:59.550079
# Unit test for function set_selection
def test_set_selection():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
    )
    test_module.get_bin_path = lambda *args, **kwargs: 'debconf-set-selections'

# Generated at 2022-06-11 06:55:00.202567
# Unit test for function get_selections
def test_get_selections():
    pass

# Generated at 2022-06-11 06:55:09.630975
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
    )
    assert get_selections(module, 'tzdata') == {
        'tzdata/Zones/Europe': 'Europe/London',
        'tzdata/Zones/UTC': '',
        'tzdata/Zones/Africa': '',
        'tzdata/Zones/SystemV': '',
        'tzdata/Zones/America': '',
        'tzdata/Zones/Asia': '',
        'tzdata/Zones/Indian': '',
        'tzdata/Zones/Pacific': '',
        'tzdata/Zones/Atlantic': '',
        'tzdata/Zones/Australia': '',
        'tzdata/Zones/Etc': ''
    }


# Generated at 2022-06-11 06:55:11.807476
# Unit test for function set_selection
def test_set_selection():
    set_selection('test_module', 'test_pkg', 'test_question', 'test_vtype', 'test_value', False)

# Generated at 2022-06-11 06:56:29.499070
# Unit test for function get_selections

# Generated at 2022-06-11 06:56:38.746622
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = 'tzdata'
   

# Generated at 2022-06-11 06:56:47.913220
# Unit test for function main
def test_main():
    import sys
    import mock

    sys.modules['ansible'] = mock.Mock()
    sys.modules['ansible.module_utils'] = mock.Mock()
    sys.modules['ansible.module_utils.basic'] = mock.Mock()

    # Set up argument spec
    module = mock.Mock()
    module.params = {
        "name": "tzdata",
        "question": None,
        "vtype": None,
        "value": None,
        "unseen": False,
    }
    module.check_mode = False
    module.run_command.return_value = (0, "", "")

# Generated at 2022-06-11 06:56:56.842473
# Unit test for function main
def test_main():
    args = dict(
        name='tzdata',
        question=None,
        unseen=False,
        vtype=None,
        value=None
    )
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-11 06:57:01.895058
# Unit test for function main
def test_main():
    try:
        from ansible.modules.system.debconf import get_selections, set_selection
    except:
        from ansible.modules.system.debconf import debconf as get_selections, debconf as set_selection
    import unittest
    import sys
    import os.path
    import subprocess

    class TestAnsibleModule(unittest.TestCase):
        def setUp(self):
            self.actual_stdout = sys.stdout
            self.actual_stderr = sys.stderr
            sys.stdout = open(os.devnull, 'w')
            sys.stderr = open(os.devnull, 'w')

# Generated at 2022-06-11 06:57:03.241274
# Unit test for function get_selections
def test_get_selections():
    assert get_selections('dummy_module','dummy_pkg')==True

# Generated at 2022-06-11 06:57:03.845015
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 06:57:13.155980
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    orig_run_command = module.run_command


# Generated at 2022-06-11 06:57:21.662551
# Unit test for function get_selections

# Generated at 2022-06-11 06:57:30.362980
# Unit test for function main
def test_main():
    from ansible.modules import debconf

    keys = ['name', 'question', 'vtype', 'value', 'unseen']
    params = {
        'name': 'tzdata',
    }
    m = debconf.AnsibleModule(argument_spec={})
    m.params = params
    get_selections = debconf.get_selections(m, params['name'])
    assert any(key in get_selections for key in keys)

    params['value'] = 'Europe/Paris'
    params['vtype'] = 'select'
    params['question'] = 'tzdata/Zone'
    set_selection = debconf.set_selection(m, params['name'], params['question'], params['vtype'], params['value'], params['unseen'])