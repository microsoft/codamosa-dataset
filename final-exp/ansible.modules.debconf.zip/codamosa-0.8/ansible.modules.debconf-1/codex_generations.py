

# Generated at 2022-06-11 06:49:41.524422
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.six import StringIO

    # Test no arguments
    argument_spec = {
        'name': dict(type='str', required=True),
        'question': dict(type='str', aliases=['selection', 'setting']),
        'vtype': dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
        'value': dict(type='str', aliases=['answer']),
        'unseen': dict(type='bool', default=False),
    }
    module = AnsibleModule(argument_spec=argument_spec, supports_check_mode=True)
    module.main()

# Generated at 2022-06-11 06:49:50.646005
# Unit test for function get_selections
def test_get_selections():
    test_input = {
        "name": "tzdata",
        "question": "selections",
        "vtype": "multiselect",
        "value": "us_US.UTF-8 UTF-8 and US english",
        "unseen": "False"
    }

    print('Testing function get_selections with input: \"%s\"' % test_input)


# Generated at 2022-06-11 06:50:00.417072
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = 'package_name'
    question = 'somequestion'
    vtype = 'select'
    value = 'somevalue'

# Generated at 2022-06-11 06:50:10.796924
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    # set values for each option
    module.params["name"] = "locales"

# Generated at 2022-06-11 06:50:14.710805
# Unit test for function set_selection
def test_set_selection():
    rc, msg, e = set_selection(None, 'local', 'locales/default_environment_locale', 'select', 'fr_FR.UTF-8', False)
    assert rc == 0
    assert msg == ''
    assert e == ''



# Generated at 2022-06-11 06:50:15.357256
# Unit test for function get_selections
def test_get_selections():
    pass

# Generated at 2022-06-11 06:50:23.940585
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-11 06:50:34.921730
# Unit test for function get_selections
def test_get_selections():
    class ModuleTest(AnsibleModule):

        def run_command(self, args, data=None):
            return 0, '', ''

        def get_bin_path(self, arg, req):
            return arg


# Generated at 2022-06-11 06:50:39.084645
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(argument_spec={})
    selections = get_selections(module, 'tzdata')
    assert selections['tzdata/Zones/Africa/Harare'] == 'Africa/Harare'


# Generated at 2022-06-11 06:50:41.193140
# Unit test for function set_selection
def test_set_selection():
    set_selection(module, pkg, question, vtype, value, unseen)

# Generated at 2022-06-11 06:50:57.356051
# Unit test for function get_selections
def test_get_selections():

    pkg_name = 'test_package'
    pkg_selection = 'test_setting'
    pkg_selection_value = 'test_value'

    pkg_output = '\n'.join([
        '* {}/{}: {}'.format(pkg_name, pkg_selection, pkg_selection_value),
    ])

    pkg_returncode = 0
    pkg_err = ''

    module = AnsibleModule({}, check_invalid_arguments=False, bypass_checks=True)

    module.run_command = MagicMock(return_value=(pkg_returncode, pkg_output, pkg_err))

    result = get_selections(module, pkg_name)

    assert result == { pkg_selection: pkg_selection_value }, 'debconf output does not match expected value'


# Generated at 2022-06-11 06:50:58.002740
# Unit test for function set_selection
def test_set_selection():
  pass

# Generated at 2022-06-11 06:51:07.579449
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    from ansible.modules.packaging.os.debconf import set_selection
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 06:51:15.887490
# Unit test for function set_selection
def test_set_selection():
    # Set up the module, we'll use a fake one
    class FakeModule:
        def __init__(self, *args):
            # print "__init__", args
            args[0]['name']='fake_package'
            self.params = args[0]

        def get_bin_path(self, executable, require_exec=True):
            # print "get_bin_path", executable, require_exec
            return executable

        def run_command(self, args, data=None):
            # print "run_command", args, data
            from subprocess import Popen, PIPE
            from tempfile import NamedTemporaryFile

            if data:
                with NamedTemporaryFile() as f:
                    f.write(data)
                    f.flush()


# Generated at 2022-06-11 06:51:16.493946
# Unit test for function set_selection
def test_set_selection():
    pass

# Generated at 2022-06-11 06:51:27.025273
# Unit test for function get_selections
def test_get_selections():
    """ Test reading of the debconf database from the module """
    import os
    import shutil
    from ansible.module_utils.basic import AnsibleModule
    from tempfile import mkdtemp
    from textwrap import dedent

    def get_test_module(package_name, package_selections):
        """
        Construct a templar module that can return the mock debconf database
        """
        db_path = mkdtemp()
        package_path = os.path.join(db_path, package_name)
        os.mkdir(package_path)
        with open(os.path.join(package_path, 'Selections'), 'w') as selections_file:
            selections_file.write(dedent(package_selections))


# Generated at 2022-06-11 06:51:33.315411
# Unit test for function set_selection
def test_set_selection():
    class FakeModule:
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/debconf-set-selections'

        def run_command(self, *args, **kwargs):
            return (0, '', '')

    mod = FakeModule()
    # TODO: Use a mock module instead
    assert set_selection(mod, 'pkg', 'question', 'string', 'value', False) == (0, '', '')

# Generated at 2022-06-11 06:51:41.030190
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.debconf import set_selection
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({}, supports_check_mode=True)

    pkg = 'curl'
    question = 'curl/http/User-Agent'
    vtype = 'text'
    value = 'Ansible'

    (rc, out, err) = set_selection(module, pkg, question, vtype, value, False)

    print(str(out))
    print(str(err))
    print(str(rc))

# Generated at 2022-06-11 06:51:42.990502
# Unit test for function set_selection
def test_set_selection():

    assert set_selection(module, pkg, question, vtype, value, unseen) == '0'



# Generated at 2022-06-11 06:51:51.212864
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule
    setsel = '/usr/bin/debconf-set-selections'
    cmd = [setsel]
    data = ' '.join(['locales', 'locales/locales_to_be_generated', 'multiselect', 'en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8'])
    module = AnsibleModule(argument_spec=dict())
    rc, out, err = module.run_command(cmd, data=data)
    if rc != 0:
        module.fail_json(msg=err)

# Generated at 2022-06-11 06:52:16.207329
# Unit test for function get_selections
def test_get_selections():
    class TestModule(AnsibleModule):
        def run_command(self, cmd, data=None, check_rc=True, environ_update=None, binary_data=False):
            output = '''tzdata  tzdata/Areas  select  America
tzdata  tzdata/Zones/America  select  Los_Angeles
tzdata  tzdata/Zones/America  text  Pacific
tzdata  tzdata/Zones/Asia  select  Tokyo'''
            return (0, output, '')
    module = TestModule({'name':'tzdata'})
    selections = get_selections(module, 'tzdata')
    assert isinstance(selections, dict)
    assert selections['tzdata/Areas'] == 'America'


# Generated at 2022-06-11 06:52:16.926387
# Unit test for function get_selections
def test_get_selections():
    pass


# Generated at 2022-06-11 06:52:22.711554
# Unit test for function main
def test_main():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, aliases=['pkg']),
            question=dict(required=False, aliases=['selection', 'setting']),
            vtype=dict(required=False, choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(required=False, aliases=['answer']),
            unseen=dict(required=False, default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # Test the function get_selections

# Generated at 2022-06-11 06:52:31.158276
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
        ),
    )
    pkg = 'openssh-server'
    # Return value from debconf-show openssh-server

# Generated at 2022-06-11 06:52:41.909102
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = module.params["name"]
    question = module.params["question"]
    vtype = module.params["vtype"]


# Generated at 2022-06-11 06:52:53.369780
# Unit test for function set_selection
def test_set_selection():
    import subprocess
    import os.path

    module = AnsibleModule(argument_spec=dict(
        name=dict(type='str', required=True, aliases=['pkg']),
        question=dict(type='str', aliases=['selection', 'setting']),
        vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
        value=dict(type='str', aliases=['answer']),
        unseen=dict(type='bool', default=False),
        ))
    pkg = 'apt'
    question = 'apt/move'
    vtype = 'boolean'
    value = 'true'

# Generated at 2022-06-11 06:52:58.161140
# Unit test for function get_selections
def test_get_selections():
    # Test for the standard case
    try:
        get_selections_result = get_selections('pkg')
    except Exception as exception:
        print(exception)

    # Test for the named parameter
    try:
        get_selections_result = get_selections(pkg='pkg')
    except Exception as exception:
        print(exception)


# Generated at 2022-06-11 06:53:08.590318
# Unit test for function set_selection
def test_set_selection():
    mock_module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    m = mock_module

# Generated at 2022-06-11 06:53:19.339131
# Unit test for function set_selection
def test_set_selection():
    import ansible.module_utils.basic
    import os

    args = {
        'name': 'test_package',
        'question': 'test_question',
        'value': 'test_value',
        'vtype': 'test_vtype',
        'unseen': False,
    }

# Generated at 2022-06-11 06:53:23.536559
# Unit test for function set_selection
def test_set_selection():
    setsel = module.get_bin_path('debconf-set-selections', True)
    cmd = [setsel]
    data = ' '.join([pkg, question, vtype, value])
    rc, out, err = module.run_command(cmd, data=data)
    assert rc is 0

# Generated at 2022-06-11 06:54:12.041484
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = 'tzdata'
    prev = get_selections(module, pkg)

# Generated at 2022-06-11 06:54:12.577033
# Unit test for function get_selections
def test_get_selections():
    pass

# Generated at 2022-06-11 06:54:21.614320
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-11 06:54:30.271631
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True, type='str'),
        question=dict(required=True, type='str'),
        vtype=dict(required=True, type='str'),
        value=dict(required=True, type='str'),
    ))
    pkg = module.params['name']
    question = module.params['question']
    vtype = module.params['vtype']
    value = module.params['value']

    (rc, msg, err) = set_selection(module, pkg, question, vtype, value, False)
    if rc != 0:
        raise Exception("set_selection returned %d, %s, %s" % (rc, msg, err))

# Generated at 2022-06-11 06:54:36.759895
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-11 06:54:37.398350
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-11 06:54:47.566437
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.common.process import get_bin_path

    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    debconf = get_bin_path(module, 'debconf-show', True)
    if debconf is not None:
        # This is how it normally comes from debconf-show
        testdata = """
* locales/default_environment_locale: fr_FR.UTF-8
  locales/locales_to_be_generated: en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8
""".strip()

# Generated at 2022-06-11 06:54:48.176953
# Unit test for function get_selections
def test_get_selections():
    main()

# Generated at 2022-06-11 06:54:58.642498
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True
    )

    pkg = "test"
    question = "question"
    vtype = "boolean"
    value = "false"

# Generated at 2022-06-11 06:55:00.981407
# Unit test for function set_selection

# Generated at 2022-06-11 06:56:17.551738
# Unit test for function main
def test_main():
    data = {
        "name": "locales",
        "question": "locales/default_environment_locale",
        "vtype": "select",
        "value": "fr_FR.UTF-8",
        "unseen": False
    }

# Generated at 2022-06-11 06:56:26.996863
# Unit test for function main

# Generated at 2022-06-11 06:56:36.979853
# Unit test for function get_selections
def test_get_selections():
    def run_get_selections(d):
        module = AnsibleModule(argument_spec={})
        for key in ('rc', 'out', 'err'):
            setattr(module, 'run_command', lambda x: d[key])
        d.setdefault('err', '')
        try:
            return get_selections(module, 'testpkg')
        except Exception:
            return False

    # command ok / no error

# Generated at 2022-06-11 06:56:46.258541
# Unit test for function get_selections
def test_get_selections():
    import os
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = "tzdata"
    os.environ['DEBIAN_FRONTEND'] = 'noninteractive'

# Generated at 2022-06-11 06:56:55.259842
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    class MockModule:
        class MockAnsibleModule(AnsibleModule):
            def __init__(self):
                self.params

# Generated at 2022-06-11 06:57:01.207368
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-11 06:57:10.144539
# Unit test for function main
def test_main():
    pkg = 'tzdata'
    question = 'tzdata/Zones/Etc'
    vtype = 'select'
    value = 'UTC'
    unseen = False

    rc, msg, e = set_selection(module, pkg, question, vtype, value, unseen)
    if rc:
        module.fail_json(msg=e)

    curr = {question: value}
    if question in prev:
        prev = {question: prev[question]}
    else:
        prev[question] = ''
    if module._diff:
        after = prev.copy()
        after.update(curr)
        diff_dict = {'before': prev, 'after': after}
    else:
        diff_dict = {}


# Generated at 2022-06-11 06:57:11.781270
# Unit test for function set_selection
def test_set_selection():
    assert set_selection(module, pkg, question, vtype, value, unseen)

# Generated at 2022-06-11 06:57:20.319542
# Unit test for function set_selection
def test_set_selection():
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    #
    # Fake task
    #
    class FakeModule(object):
        def __init__(self):
            self.params = {'name':'tzdata',
                           'question':'question',
                           'vtype':'vtype',
                           'value':'value'}
            self.check_mode = False
            self.tmpdir = '/tmp'
            self.changed = False
            self.fail_json = lambda x: None
            self.exit_json = lambda x: None

        def get_bin_path(self, name, mandatory, opt_dirs=[]):
            if name == 'debconf-set-selections':
                return '/usr/bin/debconf-set-selections'

# Generated at 2022-06-11 06:57:29.167259
# Unit test for function get_selections
def test_get_selections():
    def fake_run_command(self, cmd):
        return 0, "* udev/log/lvmupdate:\n  true", ""

    def new_return(self):
        return dict(ansible_facts={'ansible_lvm': {'devices': {'vgs': {}}, 'filter': ['a/.*/']}})

    setattr(AnsibleModule, 'run_command', fake_run_command)
    setattr(AnsibleModule, 'exit_json', new_return)