

# Generated at 2022-06-11 06:49:43.941515
# Unit test for function set_selection
def test_set_selection():
    # if vtype == 'boolean', then value == 'True' is converted to 'true'
    assert set_selection(None, 'foo', 'bar', 'boolean', 'True', False) == 0
    # if vtype == 'boolean', then value == 'False' is converted to 'false'
    assert set_selection(None, 'foo', 'bar', 'boolean', 'False', False) == 0
    # if vtype is not 'boolean', then value is not converted
    assert set_selection(None, 'foo', 'bar', 'select', 'True', False) == 0
    assert set_selection(None, 'foo', 'bar', 'select', 'False', False) == 0

# Generated at 2022-06-11 06:49:47.543228
# Unit test for function set_selection
def test_set_selection():
    assert set_selection(module, pkg, question, vtype, value, unseen) == [
        setsel,
        '-u',
        'pixelserv-tls locales/default_environment_locale select fr_FR.UTF-8',
    ]

# Generated at 2022-06-11 06:49:56.734578
# Unit test for function set_selection
def test_set_selection():
    import tempfile
    import shutil
    import os
    import sys
    import debconf
    import copy

    backup_env = copy.copy(os.environ)
    backup_argv = copy.copy(sys.argv)

    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)

    with open('test_set_selection.deb', 'w') as f:
        f.write('#!/bin/sh\nexec echo install $@')
    os.chmod('test_set_selection.deb', 0o755)
    shutil.copyfile(os.path.dirname(__file__) + '/test_set_selection.postinst', 'test_set_selection.postinst')
    os.environ['PATH'] = tmpdir + ':' + os.environ['PATH']

# Generated at 2022-06-11 06:50:07.006945
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/

# Generated at 2022-06-11 06:50:17.345682
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
        )
    current = get_selections(module, 'tzdata')
    assert isinstance(current, dict)

# Generated at 2022-06-11 06:50:22.136735
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = 'foo'
    question = 'bar'
    vtype = 'boolean'
    value = 'true'
    unseen

# Generated at 2022-06-11 06:50:28.257225
# Unit test for function main
def test_main():
    import os
    import json

    import ansible.module_utils.debconf as module_debconf

    # Test with valid values
    pkg = 'mypkg'
    question = 'myquestion'
    vtype = 'mytype'
    value = 'myvalue'

    set_selection_response = (0, "Sample Command Run", '')
    get_selections_response = {question: value}
    class module_mock:
        def __init__(self):
            self.check_mode = False
            self.params = json.dumps({'name': pkg, 'question': question, 'vtype': vtype, 'value': value, 'unseen': False})
            self._diff = False

# Generated at 2022-06-11 06:50:36.343033
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule

    failed_dict = {'failed':True}

    class AnsibleModuleMock(AnsibleModule):

        def __init__(self):
            self.fail_json = self.fail_json_mock

        def fail_json_mock(self, **kwargs):
            return failed_dict

        def run_command(self, cmd, data=''):
            return 0, '', ''

    module = AnsibleModuleMock()

    test = set_selection(module, 'pkg', 'question', 'vtype', 'value', False)
    assert test == failed_dict

# Generated at 2022-06-11 06:50:46.902198
# Unit test for function set_selection
def test_set_selection():
    # Set a selection
    rc, msg, e = set_selection(module, pkg, question, vtype, value, unseen)
    assert rc == 0
    assert e is None
    assert msg == ""

    # Try to set the same selection
    rc, msg, e = set_selection(module, pkg, question, vtype, value, unseen)
    assert rc == 0
    assert e is None
    assert msg == ""

    # Try to set a different selection
    rc, msg, e = set_selection(module, pkg, question, vtype, value, unseen)
    assert rc == 0
    assert e is None
    assert msg == ""

# Generated at 2022-06-11 06:50:55.904758
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={
        'pkg': dict(type='str', required=True),
        'question': dict(type='str', required=True),
        'vtype': dict(type='str', required=True),
        'value': dict(type='str', required=True),
        'unseen': dict(type='bool', default=False)
    })
    rc, out, err = set_selection(module, 'locales', 'locales/default_environment_locale', 'select', 'fr_FR.UTF-8', unseen=False)
    assert rc == 0
    assert ''.join(out).strip() == ''
    assert ''.join(err).strip() == ''


# Generated at 2022-06-11 06:51:23.322461
# Unit test for function main
def test_main():
    import pytest
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args
    from ansible_collections.notstdlib.moveitallout.plugins.modules import debconf

    with pytest.raises(AnsibleExitJson):
        set_module_args({'name': 'tzdata'})
        debconf.main()

    with pytest.raises(AnsibleExitJson):
        set_module_args({
            'name': 'tzdata',
            'question': 'tzdata/Zones/Europe',
            'vtype': 'select',
            'value': 'France'
        })
        debconf.main()


# Generated at 2022-06-11 06:51:30.732245
# Unit test for function main
def test_main():
    # pkg = 'locales'
    # question = 'locales/locales_to_be_generated'
    # vtype = 'multiselect'
    # value = 'en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8'

    pkg = 'tzdata'
    question = ''
    vtype = ''
    value = ''

    # pkg = 'tripwire'
    # question = 'tripwire/site-passphrase'
    # vtype = 'password'
    # value = 'tripwiresitepass123'
    # unseen = True

    # prev = get_selections(pkg)
    # print(prev)

    # set_selection(pkg, question, vtype, value, unseen)
    # print(set_selection(pkg, question, vtype, value,

# Generated at 2022-06-11 06:51:41.125199
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(argument_spec=dict(
        name=dict(type='str', required=True),
        question=dict(type='str'),
        vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
        value=dict(type='str', aliases=['answer']),
        unseen=dict(type='bool', default=False),
    ), required_together=(['question', 'vtype', 'value'],), supports_check_mode=True)

    rc, __, __ = set_selection(module, 'oracle-java7-installer', 'shared/accepted-oracle-license-v1-1', 'select', 'true', 'unseen')

    assert(rc == 0)

# Generated at 2022-06-11 06:51:51.480805
# Unit test for function get_selections

# Generated at 2022-06-11 06:51:51.911943
# Unit test for function set_selection
def test_set_selection():
    pass

# Generated at 2022-06-11 06:51:52.488534
# Unit test for function main
def test_main():
    pass


# End

# Generated at 2022-06-11 06:51:59.195657
# Unit test for function set_selection
def test_set_selection():
    os.environ['PYTHONPATH'] += ':.'
    # Arrange
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['setting']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
            vtype=dict(type='str', required=True, choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
        ),
        supports_check_mode=True,
    )
    pkg = 'locales'
    question = 'locales/default_environment_locale'

# Generated at 2022-06-11 06:52:02.870095
# Unit test for function set_selection
def test_set_selection():
    ''' Test module set_selection '''

    # Test if the function returns a tuple (and with the expected content)
    assert isinstance(set_selection(module, pkg, question, vtype, value, unseen), tuple)


# Generated at 2022-06-11 06:52:07.249497
# Unit test for function get_selections
def test_get_selections():
    args = {"name":"tzdata"}
    test_module = AnsibleModule(argument_spec=dict(**args), supports_check_mode=True)
    result = get_selections(test_module, args["name"])
    print(result)
    assert result is not None


# Generated at 2022-06-11 06:52:16.877026
# Unit test for function set_selection
def test_set_selection():
    # Set module_utils path for the test to find modules
    import os
    module_utils_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),'../module_utils')
    os.environ['ANSIBLE_MODULE_UTILS_PATH'] = module_utils_path

    from ansible.module_utils.common.process import get_bin_path


# Generated at 2022-06-11 06:52:40.773200
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.debconf import get_selections
    import types
    module = AnsibleModule(argument_spec={})
    results = get_selections(module, 'tzdata')
    assert (type(results) == types.DictType)
    assert (len(results) > 0)
    assert ('tzdata/Areas' in results)
    assert (results['tzdata/Areas'] == 'Europe')

# Generated at 2022-06-11 06:52:52.368677
# Unit test for function set_selection
def test_set_selection():
    import unittest
    import logging
    logging.basicConfig(level=logging.INFO)
    #logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)

    class TestModule(AnsibleModule):
        def __init__(self, argument_spec, check_invalid_arguments=True, mutually_exclusive=None, required_together=None,
                     required_one_of=None, add_file_common_args=False, supports_check_mode=False,
                     required_if=None, required_by=None):
            self.params = {'name': 'lsb-release', 'question': 'lsb/codename', 'vtype':'select', 'value':'jessie'}
            self.run_command_called = False
            self.last

# Generated at 2022-06-11 06:52:59.315933
# Unit test for function main
def test_main():
    pkg = 'tzdata'

    # Schema of return object
    rc = {
        'changed': False,
        'msg': '',
        'current':  {},
        'previous': {},
        'diff': {}
    }


# Generated at 2022-06-11 06:53:09.628305
# Unit test for function set_selection

# Generated at 2022-06-11 06:53:20.474000
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-11 06:53:21.227709
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-11 06:53:30.864783
# Unit test for function set_selection
def test_set_selection():
    test_input = (pkg_name, question, value, vtype)
    test_output = (rc, out, err)
    test_outputs = []
    test_outputs.append(test_output)

    # add more test_inputs
    test_inputs = []
    test_inputs.append(test_input)

    for test_index in range(len(test_inputs)):
        test_input = test_inputs[test_index]
        test_output = test_outputs[test_index]

        # set_selection(pkg, question, vtype, value, unseen)
        set_selection(test_input[0], test_input[1], test_input[2], test_input[3], True)

        assert rc == test_output[0]

# Generated at 2022-06-11 06:53:40.467239
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(argument_spec={
        "no_log": {"default": True},
    })
    # No value -> failure
    assert set_selection(module, 'newpkg', 'newquestion', 'string', '', True) == (1, '', '')
    # No question -> failure
    assert set_selection(module, 'newpkg', '', 'string', 'newvalue', True) == (1, '', '')
    # No vtype -> failure
    assert set_selection(module, 'newpkg', 'newquestion', '', 'newvalue', True) == (1, '', '')
    # Not correct vtype -> failure
    assert set_selection(module, 'newpkg', 'newquestion', 'string', 'newvalue', True) == (1, '', '')
    # Everything correct -> success
    assert set

# Generated at 2022-06-11 06:53:47.008669
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    question = None
    vtype = None
    value = None
    unseen = False
    prev = {'question': 'value'}



# Generated at 2022-06-11 06:53:56.443578
# Unit test for function get_selections
def test_get_selections():
    import tempfile

    fd, file = tempfile.mkstemp()
    with open(file, 'w+') as f:
        f.write('''
locales locales/locales_to_be_generated multiselect en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8
''')

    cmd = ['cat /usr/share/debconf/show/locales']
    rc, out, err = module.run_command(' '.join(cmd))

    if rc != 0:
        module.fail_json(msg=err)

    selections = {}

    for line in out.splitlines():
        (key, value) = line.split(':', 1)
        selections[key.strip('*').strip()] = value.strip()

    return selections

# Generated at 2022-06-11 06:54:49.297787
# Unit test for function set_selection
def test_set_selection():
    rc, msg, e = set_selection({}, 'locales', 'locales/default_environment_locale', 'select', 'fr_FR.UTF-8')
    assert rc == 0
    assert e == ''
    assert msg == ''


# Generated at 2022-06-11 06:54:59.614630
# Unit test for function set_selection
def test_set_selection():
    import tempfile
    import os.path
    import ansible.module_utils.basic
    import ansible.module_utils.pycompat24
    x = tempfile.NamedTemporaryFile()
    x.close()
    setsel = os.path.normpath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'packaging', 'debconf', 'bin', 'debconf-set-selections'))
    setsel = setsel.replace('/bin/ansible', '/libexec/ansible')
    module = ansible.module_utils.basic.AnsibleModule(
    )

# Generated at 2022-06-11 06:55:09.814272
# Unit test for function main
def test_main():
    import json
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
            diff_mode=dict(type='bool', default=False)
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )


# Generated at 2022-06-11 06:55:16.794378
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(argument_spec=dict(
        name=dict(type='str', required=True),
    ),
    supports_check_mode=True,
    )

    pkg = 'tzdata'

    selections = get_selections(module, pkg)

    assert selections != None
    assert 'tzdata/Zones/Africa/Mbabane' in selections
    assert selections['tzdata/Zones/Africa/Mbabane'] == 'Africa/Mbabane'


# Generated at 2022-06-11 06:55:27.757011
# Unit test for function set_selection
def test_set_selection():
    def run_set_selection(module, pkg, question, vtype, value, unseen):
        setsel = module.get_bin_path('debconf-set-selections', True)
        cmd = [setsel]
        if unseen:
            cmd.append('-u')

        if vtype == 'boolean':
            data = ' '.join([pkg, question, vtype, value])
        else:
            data = ' '.join([pkg, question, vtype, value])

        return module.run_command(cmd, data=data)


# Generated at 2022-06-11 06:55:34.825344
# Unit test for function set_selection
def test_set_selection():
    setsel = module.get_bin_path('debconf-set-selections', True)
    cmd = [setsel]
    if unseen:
        cmd.append('-u')

    if vtype == 'boolean':
        if value == 'True':
            value = 'true'
        elif value == 'False':
            value = 'false'
    data = ' '.join([pkg, question, vtype, value])

    return module.run_command(cmd, data=data)

# Generated at 2022-06-11 06:55:46.030354
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    gs_test = '''testpkg:
	testpkg/testquestion:
* testpkg/testquestion: mytestvalue
* testpkg/testquestion: testvalue
	testpkg/testquestion:
    '''
    def get_run_command(module, cmd, data=None):
        rc = 0
        stdout = gs_test
        stderr = ''
        return (rc, stdout, stderr)
    AnsibleModule.run_command = get_run_command
    module = AnsibleModule(argument_spec={})
    result = get_selections(module, 'testpkg')

# Generated at 2022-06-11 06:55:54.991628
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(argument_spec = { 'name' : { 'type' : 'str', 'required' : True, 'aliases' : ['pkg'] } })
    test_pkg = "tzdata"
    test_results = get_selections(module, test_pkg)
    test_selection_values = { 'tzdata/Areas': 'Europe', 'tzdata/Zones/Europe': 'Berlin', 'tzdata/Zone': 'Europe/Berlin', 'tzdata/LongZones/Europe': 'Berlin', 'tzdata/Zones/Berlin': 'Berlin', 'tzdata/LongZones/Berlin': 'Berlin', 'tzdata/ZoneInfoDir': '/usr/share/zoneinfo' }
    assert test_results == test_selection_values

# Generated at 2022-06-11 06:56:01.383415
# Unit test for function set_selection
def test_set_selection():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str'),
            question=dict(type='str'),
            vtype=dict(type='str'),
            value=dict(type='str'),
            unseen=dict(type='bool'),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    test_set_selection(test_module)

# Generated at 2022-06-11 06:56:09.479328
# Unit test for function main
def test_main():
    import os
    import sys
    import unittest

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.debconf import (
        get_selections,
        set_selection,
    )

    from ansible.modules.packaging.os import debconf


# Generated at 2022-06-11 06:57:53.426329
# Unit test for function set_selection
def test_set_selection():
    """ Unit tests for debconf.set_selection """
    # Arrange
    import sys
    import os.path
    import tempfile

    # Add directory with ansible modules to sys.path
    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_lib_dir = os.path.join(test_dir, "..", "..", "..", "..", "lib")
    sys.path.append(test_lib_dir)

    test_data = dict(name="", question="", vtype="", value="")
    test_data_unseen = dict(name="", question="", vtype="", value="", unseen=True)
    test_data_nolog = dict(name="", question="", vtype="", value="", no_log=True)

    # Create

# Generated at 2022-06-11 06:58:01.639178
# Unit test for function set_selection
def test_set_selection():
	module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
	return set_selection(module, pkg, question, vtype, value, unseen)

# Generated at 2022-06-11 06:58:04.533865
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(module, 'locales') == {'locales/default_environment_locale': 'en_US.UTF-8', 'locales/locales_to_be_generated': 'en_US.UTF-8 UTF-8'}

# Generated at 2022-06-11 06:58:09.837712
# Unit test for function get_selections
def test_get_selections():
    from mock import patch, Mock
    from StringIO import StringIO

    module = Mock()
    module.run_command = Mock(return_value=(0, '', ''))
    module.get_bin_path = Mock(return_value='/usr/bin/debconf-show')
    selections = get_selections(module, 'tzdata')

    assert(len(selections) > 0)
    assert('tzdata/Areas' in selections)


# Generated at 2022-06-11 06:58:19.419829
# Unit test for function main
def test_main():
    try:
        import shutil
        shutil.rmtree('/tmp/ansible_debconf_test')
    except:
        pass

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = module.params["name"]


# Generated at 2022-06-11 06:58:23.926697
# Unit test for function get_selections
def test_get_selections():
    module_hack=AnsibleModule(argument_spec={})
    module_hack.run_command=DummyRunCommand().run_command
    res=get_selections(module_hack,"tzdata")
    assert "tzdata/Areas" in res
    assert "tzdata/Zones/Europe" in res
    assert "tzdata/Zones/Etc" in res


# Generated at 2022-06-11 06:58:33.298483
# Unit test for function set_selection
def test_set_selection():
  def run_command(cmd, data=None):
    return 0, '', ''

  module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
  )

  module.run_command = run_command
 

# Generated at 2022-06-11 06:58:41.925594
# Unit test for function main
def test_main():
    '''
    test main()
    '''
    #
    # Mock out the module
    class module_mock:
        def __init__(self):
            module_mock.run_command = mock_run_command
            module_mock.get_bin_path = mock_get_bin_path
            self.params = {
                'name': 'package',
                'question': None,
                'vtype': None,
                'value': None,
                'unseen': False,
            }
            self.check_mode = False
            self._diff = False
            self._diff_peek = False
        def fail_json(self, **kwargs):
            '''
            test fail_json
            '''
            print(kwargs)
            assert False

# Generated at 2022-06-11 06:58:46.305660
# Unit test for function set_selection
def test_set_selection():
    setsel = module.get_bin_path('debconf-set-selections', True)
    cmd = [setsel]
    if unseen:
        cmd.append('-u')

    if vtype == 'boolean':
        if value == 'True':
            value = 'true'
        elif value == 'False':
            value = 'false'
    data = ' '.join([pkg, question, vtype, value])

    return module.run_command(cmd, data=data)


# Generated at 2022-06-11 06:58:49.561172
# Unit test for function get_selections
def test_get_selections():
    pkg = 'tzdata'

    module = AnsibleModule(
        argument_spec={},
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    #print(get_selections(module, pkg))