

# Generated at 2022-06-23 03:16:40.803626
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = "tzdata"

# Generated at 2022-06-23 03:16:47.066213
# Unit test for function get_selections
def test_get_selections():
    # Set module_utils path for unit testing
    import os
    import sys
    sys.path.append(os.path.join(os.path.dirname(__file__), '../../module_utils'))

    # Set Ansible args
    import collections
    import json
    ansible_args = collections.namedtuple('AnsibleArgs', ['no_log'])
    ansible_args.no_log = False

    # Set params
    params = {'name': 'tzdata'}

    # Set log
    class ModuleLog:
        def __init__(self, stream=sys.stdout):
            self.stream = stream
    log = ModuleLog()

    # Setup
    import ansible.module_utils.debconf as debconf

# Generated at 2022-06-23 03:16:48.305985
# Unit test for function set_selection
def test_set_selection():
    pass

# Generated at 2022-06-23 03:16:58.467751
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    module.get_bin_path = Mock(return_value='/usr/bin/debconf-set-selections')
    module.run

# Generated at 2022-06-23 03:17:07.774674
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # /usr/share/debconf/confmodule
    pkg = 'tzdata'

# Generated at 2022-06-23 03:17:17.076533
# Unit test for function main
def test_main():
    import os
    import tempfile
    import ansible
    from ansible.module_utils.common._collections_compat import MutableMapping as AnsibleMutableMapping
    from ansible.module_utils.basic import AnsibleModule, argv
    from ansible.module_utils import basic

    def dummy_module(*args, **kwargs):
        # Load module content from the *real* module for unit testing
        path = os.path.join(os.path.dirname(__file__), os.path.splitext(__file__)[0] + ".py")
        with open(path, 'rb') as f:
            content = f.read().decode('utf-8')

        # Replace shebang (the first line) with a simple one

# Generated at 2022-06-23 03:17:29.574322
# Unit test for function get_selections
def test_get_selections():
    # Setup test module
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # Setup module parameters
    pkg = 'locales'

    # Run function
    selections = get_selections

# Generated at 2022-06-23 03:17:40.627363
# Unit test for function set_selection
def test_set_selection():
    import os
    import shutil
    import tempfile
    import subprocess
    import ansible.module_utils.basic
    import ansible.module_utils.debconf
    import ansible.module_utils.debconf_get_selections
    import ansible.module_utils.get_bin_path
    import ansible.module_utils.run_command
    # Create a directory for the test
    tmpdir = tempfile.mkdtemp()
    # Create a test package
    os.makedirs(tmpdir+'/tmp/DEBIAN')
    open(tmpdir+'/tmp/DEBIAN/control', 'w').write('Package: example\nVersion: 1.0\n')
    os.makedirs(tmpdir+'/tmp/usr/share/example/')

# Generated at 2022-06-23 03:17:49.409002
# Unit test for function set_selection
def test_set_selection():
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    def test_runner(module, *args, **kwargs):
        return set_selection(module, args[0], args[1], args[2], args[3], args[4])

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            question=dict(required=True),
            vtype=dict(required=True),
            value=dict(required=True)
        )
    )

    # Specifing different path for debconf-set-selections
    setsel = tempfile.NamedTemporaryFile(mode='w+', prefix='ansible_module_test_module_utils_basic_',
                                         suffix='_debconf-set-selections', delete=False)

    #

# Generated at 2022-06-23 03:17:54.953140
# Unit test for function set_selection
def test_set_selection():
  import os
  import mock
  from ansible.module_utils.basic import AnsibleModule
  from ansible.builtin.debconf import set_selection
  module = AnsibleModule(
  )
  pkg = "test"
  question = "test"
  vtype = "string"
  value = "test"
  unseen = "false"
  with mock.patch.object(os.path, 'exists', return_value=True):
     set_selection(module, pkg, question, vtype, value, unseen)

# Generated at 2022-06-23 03:17:58.989361
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(module, 'tzdata') == {'tzdata/Areas': 'Europe', 'tzdata/Zones/Europe': 'Berlin'}

# Generated at 2022-06-23 03:18:10.899128
# Unit test for function main
def test_main():
    from ansible.builtin.debconf import main

    class my_module(object):
        class dummy_module(object):
            def run_command(self, a, b=None, c=None, data=None):
                return 0, "", ""
            def get_bin_path(self, a, b=None, c=None, data=None):
                return ""
        def __init__(self):
            self.params = {
                "name": '',
                "question": None,
                "vtype": None,
                "value": None
            }
            self.check_mode = False
            self.fail_json = None
            self.exit_json = None
            self.run_command = dummy_module.run_command
            self.get_bin_path = dummy_module.get_bin_path


# Generated at 2022-06-23 03:18:21.092654
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-23 03:18:21.409448
# Unit test for function get_selections
def test_get_selections():
    assert True

# Generated at 2022-06-23 03:18:23.709137
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(module, 'tzdata') == {
        "tzdata/Areas": "Europe",
        "tzdata/Zones/Europe": "Berlin",
        "tzdata/Zones/Africa": "Cairo"
    }



# Generated at 2022-06-23 03:18:36.226645
# Unit test for function get_selections
def test_get_selections():
    """
    Test of get_selections
    """
    import os
    import re
    from ansible.module_utils.basic import AnsibleModule
    
    # Get path of module
    if os.path.exists('/usr/local/lib/python3.7/site-packages/ansible/modules/cloud/amazon/'):
        path_module = '/usr/local/lib/python3.7/site-packages/ansible/modules/cloud/amazon/'
    elif os.path.exists('/home/raphael/Bureau/ECS1/ansible/lib/ansible/modules/cloud/amazon'):
        path_module = '/home/raphael/Bureau/ECS1/ansible/lib/ansible/modules/cloud/amazon/'
    else:
        print('Return none')


# Generated at 2022-06-23 03:18:46.080232
# Unit test for function main
def test_main():
    def _get_selections(module, pkg):
        selections = {}
        selections['default_environment_locale'] = 'en_US.UTF-8 UTF-8'
        selections['locales_to_be_generated'] = 'en_US.UTF-8 UTF-8'
        return selections
    def _set_selection(module, pkg, question, vtype, value, unseen):
        return 0, "value changed"

    class _modules:
        class AnsibleModule(object):
            def __init__(self, arg_spec, required_together=None, supports_check_mode=None, supports_diff=None):
                self.params = {}
                self.params['name'] = 'local'
                self.params['question'] = 'default_environment_locale'

# Generated at 2022-06-23 03:18:54.957534
# Unit test for function get_selections
def test_get_selections():
    m = AnsibleModule({}, {}, {})
    test_data = '''
* openssh-server/permit-root-login: true
* openssh-server/password-authentication: true
* openssh-server/use-privilege-separation: false
* openssh-server/allow-user-environment: false
* openssh-server/use-pam: false
* openssh-server/use-etc-default-ssh-dir: false'''
    m.run_command = lambda x: (0, test_data, '')
    module = {'run_command': m.run_command}
    module = {'fail_json': m.fail_json}
    module = {'get_bin_path': m.get_bin_path}

# Generated at 2022-06-23 03:19:06.690536
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    module.params["name"] = "tzdata"
    selections = get_selections(module, module.params["name"])

# Generated at 2022-06-23 03:19:12.335390
# Unit test for function get_selections
def test_get_selections():
    returncode, out, err = get_selections(module, 'tzdata')
    assert out.find('tzdata/Areas: Europe') != -1
    assert out.find('tzdata/Zones/Europe: Vienna') != -1

# Generated at 2022-06-23 03:19:22.776304
# Unit test for function get_selections
def test_get_selections():
    test_module = AnsibleModule(argument_spec=dict())


# Generated at 2022-06-23 03:19:27.047301
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(module, pkg) == {
        'tzdata/Areas': 'Europe',
        'tzdata/Zones/Etc': 'UTC',
        'tzdata/Zones/Europe': 'Amsterdam'
    }


# Generated at 2022-06-23 03:19:36.054424
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
        ),
        required_together=(['question', 'vtype', 'value'],)
    )
    module.run_command = Mock(return_value=(0, '', ''))
    result = get_selections(module, "test")
    assert result == {}

# Generated at 2022-06-23 03:19:39.665256
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-23 03:19:45.426467
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    pkg = 'tzdata'
    module = AnsibleModule(argument_spec={})
    result = get_selections(module, pkg)
    assert type(result) == dict
    assert 'APT::Periodic::Unattended-Upgrade' in result
    assert result['APT::Periodic::Unattended-Upgrade'] == '0'

# Generated at 2022-06-23 03:19:57.390529
# Unit test for function set_selection
def test_set_selection():
    import os
    import sys
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import StringIO

    def cleanup():
        setsel = module.get_bin_path('debconf-set-selections', True)
        if os.path.exists(setsel):
            os.unlink(setsel)


# Generated at 2022-06-23 03:20:04.157637
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
                            name=dict(type='str', required=True, aliases=['pkg']),
                            question=dict(type='str', aliases=['selection', 'setting']),
                            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
                            value=dict(type='str', aliases=['answer']),
                            unseen=dict(type='bool', default=False),
                            ),
                            required_together=(['question', 'vtype', 'value'],),
                            supports_check_mode=True,
                            )
    module.get_bin_path = MagicMock(return_value="test_bin")
    module.run

# Generated at 2022-06-23 03:20:08.715354
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.debconf import get_selections
    module = AnsibleModule(argument_spec=dict())
    result = get_selections(module, 'tzdata')
    assert(result['tzdata/Areas'] == 'Europe')
    assert(result['tzdata/Zones/Europe'] == 'Berlin')


# Generated at 2022-06-23 03:20:21.354801
# Unit test for function main
def test_main():
    # Test cases
    module_args = dict(
        name=dict(type='str', required=True, aliases=['pkg']),
        question=dict(type='str', aliases=['selection', 'setting']),
        vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
        value=dict(type='str', aliases=['answer']),
        unseen=dict(type='bool', default=False),
    ),
    module_args["name"] = test_name
    module_args["question"] = test_question
    module_args["vtype"] = test_vtype
    module_args["value"] = test_value
    module_args["unseen"] = test_unseen


# Generated at 2022-06-23 03:20:23.279882
# Unit test for function set_selection
def test_set_selection():
    result1 = set_selection(pkg, question, vtype, value, unseen)
    assert result1 == "no changes"

# Generated at 2022-06-23 03:20:32.848787
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
    )

    setsel = module.get_bin_path('debconf-set-selections', True)

# Generated at 2022-06-23 03:20:43.713149
# Unit test for function main
def test_main():
    MOD = {
        'check_mode': False,
        'no_log': False,
        '_diff': True,
    }
    SELECTIONS = {'tzdata/Zones/Etc': 'UTC'}
    def fake_get_selections(module, pkg):
        return SELECTIONS

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )
    module.params = {'name': 'a-package'}
    module.get_bin_path = lambda p, f: p
    module.run_command = lambda cmd, data=None: (0, None, None)
    module.exit_json = lambda **kwargs: kwargs
    module.fail_json = lambda **kwargs: kwargs

    main()['msg'] = 'OK'


# Generated at 2022-06-23 03:20:45.578336
# Unit test for function set_selection
def test_set_selection():
    rc, msg, e = set_selection(module, pkg, question, vtype, value, unseen)


# Generated at 2022-06-23 03:20:55.618099
# Unit test for function get_selections
def test_get_selections():
    # Warning: If the debconf-utils package is not installed this unit test will fail
    # For now, we will just skip it if the package isn't installed
    import os
    import sys
    import unittest

    if not os.path.isfile("/usr/bin/debconf-show"):
        print("Skipping test_get_selections because debconf-utils package is not installed")
        return

    class TestDebconf(unittest.TestCase):

        def test_get_selections(self):
            self.assertEqual(get_selections("tzdata", "tzdata/Areas"), ['Africa', 'America', 'Antarctica', 'Arctic', 'Asia', 'Atlantic', 'Australia', 'Brazil', 'Canada', 'Chile', 'Europe', 'Indian', 'Mexico', 'Pacific', 'US'])


# Generated at 2022-06-23 03:21:00.056588
# Unit test for function set_selection
def test_set_selection():
    assert set_selection('debconf', 'fake-package', 'fake-question', 'select', 'A') == 'true'
    assert set_selection('debconf', 'fake-package', 'fake-question', 'select', '') == 'A'
    assert set_selection('debconf', 'fake-package', 'fake-question', 'select', '') == ''

# Generated at 2022-06-23 03:21:09.959269
# Unit test for function main
def test_main():
    import os
    import sys
    import errno
    import tempfile
    import types
    import subprocess

    def mkstemp_wrapper(*args, **kwargs):
        class tempfile_wrapper:
            def __init__(self, *args, **kwargs):
                self.file = tempfile.NamedTemporaryFile(*args, **kwargs)
                self.name = self.file.name
            def __getattr__(self, name):
                return getattr(self.file, name)
            def __enter__(self, *args, **kwargs):
                return self
            def __exit__(self, *args, **kwargs):
                self.file.close()
        return (3, tempfile_wrapper(*args, **kwargs))


# Generated at 2022-06-23 03:21:10.858045
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-23 03:21:13.272256
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(pkg='lsb-release') == {'lsb-release/precise/codename': 'precise'}

# Generated at 2022-06-23 03:21:22.241223
# Unit test for function get_selections
def test_get_selections():
    import unittest
    from collections import OrderedDict
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(object):
        def get_bin_path(self, executable, required):
            return executable

        def run_command(self, cmd, data=None):
            return 0, "", ""

    module = FakeModule()

    # Test all values
    expected_selection0 = OrderedDict()
    expected_selection0["* locales/default_environment_locale"] = "fr_FR.UTF-8"
    expected_selection0["* locales/locales_to_be_generated"] = "en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8"
    expected_selection0["* shared/accepted-oracle-license-v1-1"]

# Generated at 2022-06-23 03:21:34.331679
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str'),
            question=dict(type='str', required=True, aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = module.params["name"]
    assert pkg == "tzdata"
    output_dict = get_selections(module, pkg)

# Generated at 2022-06-23 03:21:42.803981
# Unit test for function set_selection
def test_set_selection():
    assert set_selection(pkg='locales', question='locales/locales_to_be_generated', vtype='multiselect', value='en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8')
    assert set_selection(pkg='locales', question='locales/locales_to_be_generated', vtype='multiselect', value='en_US.UTF-8 UTF-8')
    assert set_selection(pkg='locales', question='locales/locales_to_be_generated', vtype='multiselect', value='en_US.UTF-8 UTF-8, en_US.UTF-8 UTF-8')


# Generated at 2022-06-23 03:21:44.394477
# Unit test for function main

# Generated at 2022-06-23 03:21:52.355158
# Unit test for function get_selections
def test_get_selections():
    import unittest

    # It is assumed that 'locales' is installed.
    # The test will fail if 'locales' is not installed
    class testGetSelections(unittest.TestCase):
        def test(self):
            self.assertTrue(len(get_selections(None, "locales")) > 0)

    suite = unittest.TestLoader().loadTestsFromTestCase(testGetSelections)
    unittest.TextTestRunner(verbosity=2).run(suite)


# Generated at 2022-06-23 03:22:04.515565
# Unit test for function main
def test_main():
  from mock import MagicMock, patch, call
  
  def fake_get_selections(module, pkg):
    return {"question1": "value1", "question2": "value2", "question3": "value3"}

  def fake_run_command(cmd, data=None):
    if data is not None:
      if question is "question1":
        if vtype == "boolean":
          return (1, "", "Error on debconf-set-selections")
        else:
          return (0, "", "")
      else:
        return (0, "", "")
    else:
      return (0, "", "")

  def fake_get_bin_path(bin, required=False):
    return "bin/" + bin


# Generated at 2022-06-23 03:22:15.930911
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    cmd = [module.get_bin_path('debconf-show', True), 'test_pkg']

# Generated at 2022-06-23 03:22:28.853424
# Unit test for function set_selection
def test_set_selection():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    # test case 1: rc = 0, err = ""

# Generated at 2022-06-23 03:22:36.976513
# Unit test for function get_selections
def test_get_selections():
    mymodule = FakeAnsibleModule()
    mymodule.run_command = run_command_mock
    mymodule.get_bin_path = get_bin_path_mock

    mymodule.get_bin_path_return_value = '/usr/bin/debconf-show'
    mymodule.run_command_return_value = (0, "locales/locales_to_be_generated: \n"
                                            "local/locales_to_be_generated: fr_FR.UTF-8 UTF-8", "")
    current_selections = get_selections(mymodule, 'locales')

# Generated at 2022-06-23 03:22:46.735783
# Unit test for function get_selections
def test_get_selections():
    """unit test for function get_selections"""
    inputs = ['tzdata', 'nodata', 'nonexistentpkg']
    outputs = [True, False, False]
    params = dict(
        name=None,
        question=None,
        vtype=None,
        value=None,
        unseen=None,
    )
    m = AnsibleModule(argument_spec=params)
    for index in range(len(inputs)):
        if get_selections(m, inputs[index]) is not None:
            assert True == outputs[index]
        else:
            assert False == outputs[index]


# Generated at 2022-06-23 03:22:49.544646
# Unit test for function main
def test_main():
    test = ['ansible-test', 'do', '-t', 'test/test_module_action_debconf.py']
    import sys
    sys.argv = test
    main()

# Generated at 2022-06-23 03:22:53.307877
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    
    selections = get_selections(module, "tzdata")
    assert(len(selections.keys()) > 0)
    assert("locales/are_you_sure" in selections.keys())

# Generated at 2022-06-23 03:22:53.861997
# Unit test for function get_selections
def test_get_selections():
    pass

# Generated at 2022-06-23 03:22:59.442444
# Unit test for function get_selections
def test_get_selections():
    # Create fake module
    test_module = AnsibleModule(argument_spec=dict())
    test_module.run_command = MagicMock(return_value = (0, 'testname: testvalue', ''))
    test_module.get_bin_path = MagicMock(return_value = '/bin/debconf-show')
    test_selections = get_selections(test_module, 'testpkg')
    assert test_selections['testname'] == 'testvalue'


# Generated at 2022-06-23 03:23:11.185159
# Unit test for function main
def test_main():
    import tempfile
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = "locales"
    question = "locales/default_environment_locale"

# Generated at 2022-06-23 03:23:18.564194
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec=dict(),
    )
    res = get_selections(module, 'tzdata')
    assert res['tzdata/Zones/Atlantic/Canary'] == 'Europe/Madrid'
    assert res['tzdata/Zones/Europe/Vaduz'] == 'Europe/Vaduz'


# Generated at 2022-06-23 03:23:26.727402
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import StringIO
    from StringIO import StringIO

    s = StringIO()

    class ModuleFailException(Exception):
        pass

    class AnsibleModuleFake:
        def __init__(self, argument_spec=None, required_together=None, supports_check_mode=False):
            self.argument_spec = argument_spec
            self.required_together = required_together
            self.supports_check_mode = supports_check_mode

        def get_bin_path(self, executable, required=False, opt_dirs=None):
            return executable


# Generated at 2022-06-23 03:23:29.474855
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(module, 'locales') == {"locales/default_environment_locale": "en_US.UTF-8", "locales/locales_to_be_generated": "en_US.UTF-8 UTF-8"}


# Generated at 2022-06-23 03:23:40.025405
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note',
                                           'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    
    # Normal case

# Generated at 2022-06-23 03:23:51.803772
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-23 03:23:58.872237
# Unit test for function set_selection
def test_set_selection():
    setsel = module.get_bin_path('debconf-set-selections', True)
    cmd = [setsel, '-u' ]
    data = ' '.join(['tzdata', 'tzdata/Areas', 'select', 'Europe'])

    if vtype == 'boolean':
        if value == 'True':
            value = 'true'
        elif value == 'False':
            value = 'false'
    return module.run_command(cmd, data=data)

# Generated at 2022-06-23 03:24:07.932320
# Unit test for function main
def test_main():
  module = AnsibleModule(argument_spec={})
  # test for module.run_command
  module.run_command = MagicMock(return_value=(0, "", ""))
  # test for module.fail_json
  module.fail_json = MagicMock(return_value=None)

  # test for module.check_mode
  module.check_mode = MagicMock(return_value=False)
  module._diff = MagicMock(return_value=False)
  module.params = {"name": "", "question": "", "vtype": "", "value": "", "unseen": False}
  main()

  # test for valid vtype and value
  # module.get_bin_path
  module.get_bin_path = MagicMock(return_value=True)

# Generated at 2022-06-23 03:24:19.825586
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import namedtuple
    from ansible.module_utils._text import to_bytes
    import tempfile
    module = AnsibleModule(argument_spec={})
    data = """* locales/locales_to_be_generated:
 en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8
* locales/default_environment_locale:
 fr_FR.UTF-8
"""
    (fd, filename) = tempfile.mkstemp(suffix='.log')
    f = open(filename, 'w')
    f.write(to_bytes(data))
    f.close()
    results = get_selections(module, filename)

# Generated at 2022-06-23 03:24:21.511542
# Unit test for function get_selections
def test_get_selections():
    # Check for load of function
    assert get_selections


# Generated at 2022-06-23 03:24:32.582989
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True
    )

    pkg = module.params["name"]
    question = module.params["question"]
    vtype = module.params["vtype"]
   

# Generated at 2022-06-23 03:24:37.553556
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    selections = get_selections(module, "locales")
    assert selections['locales/default_environment_locale'] == 'en_US.UTF-8'
    assert selections['locales/locales_to_be_generated'] == 'en_US.UTF-8 UTF-8'

# Generated at 2022-06-23 03:24:42.199147
# Unit test for function set_selection
def test_set_selection():

    #test normal call
    assert set_selection(None, 'mypackage', 'my/question', 'string', 'myvalue', False) == (0, '', '')

    #test normal call
    assert set_selection(None, 'mypackage', 'my/question', 'string', 'myvalue', True) == (0, '', '')

# Generated at 2022-06-23 03:24:54.660919
# Unit test for function main
def test_main():
    # Test no question and value settings
    ######################################
    m = AnsibleModule(dict(name="tzdata"),
                      check_invalid_arguments=False)
    rc, out, err = main()
    assert rc == 0
    assert err == ''
    assert out['changed'] is False
    assert out['msg'] == ''

    # Test question is None and vtype/value settings
    ########################################
    m = AnsibleModule(dict(name="tzdata", vtype="boolean", value=True))
    rc, out, err = main()
    assert rc == 0
    assert err == ''
    assert out['changed'] == False
    assert out['msg'] == ''

    # Test question and not vtype/value settings
    #########################################

# Generated at 2022-06-23 03:25:06.850337
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = 'name'
    question = 'question'
    vtype = 'vtype'
    value = 'value'
    unseen

# Generated at 2022-06-23 03:25:17.934463
# Unit test for function get_selections
def test_get_selections():
    # Mock module to be able to test get_selections()
    class MockModule:
        class RunCommand:
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

            def __call__(self, cmd, data=None):
                return (self.rc, self.out, self.err)

        def run_command(self, command, *args, **kwargs):
            cmd = command[:]
            cmd[0] = cmd[0].split()[0]

# Generated at 2022-06-23 03:25:18.606188
# Unit test for function set_selection
def test_set_selection():
    pass

# Generated at 2022-06-23 03:25:26.888193
# Unit test for function get_selections
def test_get_selections():
  from ansible.module_utils.basic import AnsibleModule
  data = {
    'name': 'tzdata',
    'question': None,
    'vtype': None,
    'value': None,
    'unseen': False,
  }
  module = AnsibleModule(argument_spec={})
  setattr(module, 'params', data)
  result = get_selections(module, data['name'])
  assert('tzdata/Zones/Etc' in result)
  assert(result['tzdata/Zones/Etc'] == 'UTC')

# Generated at 2022-06-23 03:25:37.760123
# Unit test for function get_selections
def test_get_selections():
    test_get_selections.__name__ = 'test_get_selections'

# Generated at 2022-06-23 03:25:49.140481
# Unit test for function main
def test_main():
    test0 = {
        "name": "localepurge",
        "question": "localepurge/use-dpkg-feature",
        "vtype": "boolean",
        "value": False
    }
    test1 = {
        "name": "tzdata",
        "question": "",
        "vtype": None,
        "value": None
    }
    test2 = {
        "name": "apt",
        "question": "apt-setup/unsupported-codename",
        "vtype": "note",
        "value": None
    }
    test3 = {
        "name": "tzdata",
        "question": "",
        "vtype": None,
        "value": None
    }

# Generated at 2022-06-23 03:25:52.589217
# Unit test for function get_selections
def test_get_selections():
    result = get_selections(
        module = module,
        pkg = 'tzdata',
    )
    assert result['tzdata/Areas'] == 'Europe'
    assert result['tzdata/Zones/Europe'] == 'Berlin'

# Generated at 2022-06-23 03:26:01.632211
# Unit test for function main
def test_main():
    play = os.path.realpath(os.path.join(os.getcwd(), "../../../playbooks/ansible_test_play.yml"))
    test_module = os.path.realpath(os.path.join(os.getcwd(), "../../../library/debconf.py"))
    test_module = test_module.replace('\\', '\\\\')


# Generated at 2022-06-23 03:26:13.669941
# Unit test for function main
def test_main():
    import tempfile
    fh = tempfile.NamedTemporaryFile()
    # Set vars used by main function
    pkg = 'tzdata'
    question = 'tzdata/Zones/US'
    vtype = 'select'
    value = 'America/New_York'
    unseen = False
    check_mode = False
    diff_mode = False
    # Create test data

# Generated at 2022-06-23 03:26:20.464061
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
    )
    rc, msg, err = set_selection(module, "tzdata", "tzdata/Zones/Europe", "select", "Amsterdam", False)
    assert(rc is 0)

# Generated at 2022-06-23 03:26:30.071683
# Unit test for function get_selections
def test_get_selections():
    try:
        from ansible.modules.system.debconf import get_selections
    except ImportError:
        return
    import sys
    import os

    class Module:

        def __init__(self):
            self.params = {
                'name': 'tzdata'
            }
            self.run_command_calls = []
            self.fail_json_calls = []
            self.run_command_rc = 0
            self.run_command_stdout = '''tzdata/Zones/Europe: Europe/Andorra
tzdata/Zones/Europe: Europe/Oslo
tzdata/Zones/Europe: Europe/Zagreb'''
