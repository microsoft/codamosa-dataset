

# Generated at 2022-06-23 03:16:41.161083
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        name=dict(type='str', required=True, aliases=['pkg'], default='locales'),
        question=dict(type='str', aliases=['selection', 'setting'], default='locales/locales_to_be_generated'),
        vtype=dict(type='str', default='multiselect'),
        value=dict(type='str', aliases=['answer'], default='en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8'),
        unseen=dict(type='bool', default=False),
    ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    main()

# Generated at 2022-06-23 03:16:47.243205
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    pkg = module.params["name"]
    question = module.params["question"]
    vtype = module.params["vtype"]


# Generated at 2022-06-23 03:16:56.881263
# Unit test for function get_selections
def test_get_selections():
    import unittest
    import sys

    class TestGetSelections(unittest.TestCase):

        def setUp(self):
            self.dbc = Debconf()
            self.module = self.dbc

        def test_get_selections(self):
            self.assertEqual(get_selections(self.module, 'locales'), {
                'locales/default_environment_locale': '',
                'locales/locales_to_be_generated': '',
            })

    suite = unittest.TestLoader().loadTestsFromTestCase(TestGetSelections)
    unittest.TextTestRunner(verbosity=2).run(suite)


# Generated at 2022-06-23 03:17:05.797851
# Unit test for function get_selections
def test_get_selections():
    #tests
    '''
    os.path.exists(path) checks if path exists
    os.access(path, mode) checks if it is executable
    '''
    test_file = {"path":"ansible/test_module_utils/test_debconf.py","mode":os.R_OK}
    #creating a test module
    test_module = AnsibleModule(argument_spec={})
    #testing if file exists
    test_module.assertTrue(os.path.exists(test_file["path"]))
    #testing if file is executable
    test_module.assertTrue(os.access(test_file["path"], test_file["mode"]))
    #instantiating test_module
    module = AnsibleModule(argument_spec={})
    #TODO: find a better way to check if command is

# Generated at 2022-06-23 03:17:12.459730
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # Extract out the debconf settings for the "tzdata" package.
    # This should work with most Debian derived distros
    results = get_selections(module, 'tzdata')

    assert results is not None
    assert len(results) > 0
    assert 'tzdata/Areas' in results
    assert 'tzdata/Zones/America' in results

# Generated at 2022-06-23 03:17:24.221353
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-23 03:17:34.786000
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.exit_json = lambda changed, msg, current, previous, diff: (changed, msg, current, previous, diff)
    set_selection = lambda module, pkg, question, vtype, value, unseen: (0, "", "")
    name = "locales"
    question = "locales/default_environment_locale"
    vtype = "select"
    value = "fr_FR.UTF-8"
    selection = {'locales/default_environment_locale': 'fr_FR.UTF-8'}
    res = main()
    assert res[2] == selection, "Should return a debconf selection"
    assert res[4] == {}, "Should return empty diff"


# Generated at 2022-06-23 03:17:47.181246
# Unit test for function main
def test_main():
    args = dict(
            name="tzdata",
            question=None,
            vtype=None,
            value=None,
            unseen=False
        )

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-23 03:17:53.803422
# Unit test for function get_selections
def test_get_selections():
    module = AnsibleModule(argument_spec={'name': {'required': True, 'type': 'str'}, 'test_module': {'required': False, 'type': 'bool', 'default': True}})
    module.run_command = MagicMock(return_value=(0, '* tzdata/Areas: US\n* tzdata/Zones/US: America/Los_Angeles\n', ''))
    selections = get_selections(module, 'tzdata')
    assert selections == {'tzdata/Areas': 'US', 'tzdata/Zones/US': 'America/Los_Angeles'}



# Generated at 2022-06-23 03:17:54.310337
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-23 03:17:54.811351
# Unit test for function get_selections
def test_get_selections():
    assert True

# Generated at 2022-06-23 03:18:06.633830
# Unit test for function get_selections

# Generated at 2022-06-23 03:18:09.100174
# Unit test for function main
def test_main():
    args = \
        {
            "name": "tzdata",
        }
    set_module_args(args)
    main()

# Generated at 2022-06-23 03:18:18.208844
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule
    import os.path

    class MockModule(AnsibleModule):
        def fail_json(self, **kw):
            self.fail_json = True

        def run_command(self, cmd, data=None):
            self.command = cmd
            self.data = data
            return 0, None, None

        def get_bin_path(self, command, required=True):
            return os.path.join('/usr/bin', command)


# Generated at 2022-06-23 03:18:21.285451
# Unit test for function set_selection
def test_set_selection():
    # Set
    set_selection(True, '', '', 'boolean', 'True', False)
    # No set
    set_selection(False, '', '', 'boolean', 'False', False)

# Generated at 2022-06-23 03:18:23.451928
# Unit test for function set_selection
def test_set_selection():
    assert set_selection('pkg', 'question', 'vtype', 'value') == 0

# Basic unit test for function get_selections

# Generated at 2022-06-23 03:18:36.122631
# Unit test for function get_selections
def test_get_selections():
  from sys import version_info
  from ansible.module_utils.basic import AnsibleModule
  if version_info[0] <= 2:
    from mock import MagicMock, Mock
  else:
    from unittest.mock import MagicMock, Mock
  module = MagicMock()
  module.ansible_version = '2.7.0'
  module.config = MagicMock()
  module.check_mode = False
  module.debug = False
  module.args = ['/tmp/ansible_debconf_payload_mX0tyE']
  module.params = {}
  module.run_command = MagicMock()

# Generated at 2022-06-23 03:18:46.662337
# Unit test for function get_selections
def test_get_selections():
    print("Test get_selections")

    import tempfile
    import shutil
    import os
    import ansible.module_utils.debconf_utils
    import ansible.module_utils.basic

    def get_bin_path(name, required):
        return name


# Generated at 2022-06-23 03:18:53.095835
# Unit test for function set_selection
def test_set_selection():
    assert set_selection(None, pkg="master", question="slave", vtype="boolean", value="False", unseen=False) == "False"
    assert set_selection(None, pkg="debian", question="ubuntu", vtype="string", value="yes", unseen=False) == "yes"
    assert set_selection(None, pkg="test", question="test", vtype="text", value="not working", unseen=False) == "not working"

# Generated at 2022-06-23 03:19:04.225624
# Unit test for function get_selections
def test_get_selections():
    pkg = 'tzdata'
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )
    assert len(get_selections(module, pkg)) > 0

# Generated at 2022-06-23 03:19:04.885707
# Unit test for function set_selection
def test_set_selection():
    pass

# Generated at 2022-06-23 03:19:12.936291
# Unit test for function get_selections
def test_get_selections():
    param = {
        'name': 'test',
        'question': None,
        'vtype': None,
        'value': None,
        'unseen': None,
    }

    class MockModule:
        params = param
        check_mode = False
        run_command = lambda self, cmd: (0, 'test: value', '')
        get_bin_path = lambda self, cmd, required: 'test_cmd'
        fail_json = lambda self, msg: print(msg)
        exit_json = lambda self, changed, msg, current: print(changed, msg, current)

    out = get_selections(MockModule(), param['name'])
    assert out == {'test': 'value'}

# Generated at 2022-06-23 03:19:16.475111
# Unit test for function set_selection
def test_set_selection():
    # Create example input string
    data = "pkg question vtype value"

    # Check that return code is 0 and there is no error output
    assert set_selection(data) == (0, "")

# Generated at 2022-06-23 03:19:18.741726
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(None, 'foo') == {}



# Generated at 2022-06-23 03:19:29.909037
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text

# Generated at 2022-06-23 03:19:37.382613
# Unit test for function main
def test_main():
    testval = dict(
        name='tzdata',
        question='tzdata/Areas',
        value='Africa',
        vtype='multiselect'
    )
    module = AnsibleModule(argument_spec=testval)
    setattr(module, 'run_command', lambda *args, **kwargs: (0, 'fake out', ''))

# Generated at 2022-06-23 03:19:45.876159
# Unit test for function set_selection
def test_set_selection():
    class FakeModule:
        def run_command(self, args, data=None):
            assert data == 'tripwire tripwire/site-passphrase password "secret"\n'
            return 0, '', ''

        def get_bin_path(self, app, required=False):
            return app

    module = FakeModule()
    pkg = 'tripwire'
    question = 'tripwire/site-passphrase'
    vtype = 'password'
    value = 'secret'
    unseen = False
    set_selection(module, pkg, question, vtype, value, unseen)

# Generated at 2022-06-23 03:19:57.756820
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils import basic

    class Test(object):
        def __init__(self):
            self.ansible_module = basic.AnsibleModule(
                argument_spec=dict(
                    name=dict(type='str', required=True, aliases=['pkg'])
                ),
                supports_check_mode=True,
            )

        def run_command(self, cmd, data=None):
            arguments = ' '.join(cmd)
            self.ansible_module.log('running: {}\n{}'.format(arguments, data))
            if data:
                fid = StringIO(data)
            else:
                fid = None
            return 0, '', ''


# Generated at 2022-06-23 03:20:07.581648
# Unit test for function main
def test_main():
    module = AnsibleModule(
            argument_spec=dict(
                name=dict(type='str', required=True, aliases=['pkg']),
                question=dict(type='str', aliases=['selection', 'setting']),
                vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
                value=dict(type='str', aliases=['answer']),
                unseen=dict(type='bool', default=False),
                ),
            required_together=(['question', 'vtype', 'value'],),
            supports_check_mode=True,
            )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]

# Generated at 2022-06-23 03:20:13.522650
# Unit test for function get_selections
def test_get_selections():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.module_utils.basic import AnsibleModule, get_module_path
    from ansible.module_utils import basic
    import sys

    output = StringIO()
    sys.stdout = output

    def run_command_mock(args):
        if args == "debconf-show apt":
            return (0, "test_key:test_value\ntest_key2:test_value2\n", "")
        else:
            return (0, "test_key:test_value\ntest_key2:test_value2\n", "")

    basic._ANSIBLE_

# Generated at 2022-06-23 03:20:23.566905
# Unit test for function set_selection
def test_set_selection():
    import ansible.modules.system.debconf as debconf

    pkg = 'foo'
    question = 'bar'
    vtype = 'baz'
    value = 'qux'
    unseen = True

    set_selection = debconf.set_selection

    class Module(object):
        def __init__(self):
            self.params = {'unseen': unseen}
            self.tmpdir = 'tmpdir'
            self._ansible_no_log = True

        def get_bin_path(self, arg, true):
            return 'debconf-set-selections'

        def run_command(self, cmd, data=''):
            self.cmd = cmd
            self.data = data
            return (0, '', '')

    module = Module()


# Generated at 2022-06-23 03:20:31.326791
# Unit test for function set_selection
def test_set_selection():
    class Module(object):
        def __init__(self, bin_path, run_command):
            self.bin_path = bin_path
            self.run_command = run_command

        def get_bin_path(self, cmd, required):
            return self.bin_path

    success = (0, "OK\n", '')
    fail = (1, "", "FAILURE")

    def run_command(cmd, data):
        assert cmd == ['ok']
        assert data == 'debian debconf-show locales/locales_to_be_generated multiselect fr_FR.UTF-8 UTF-8,en_US.UTF-8 UTF-8'
        return success

    module = Module('ok', run_command)

# Generated at 2022-06-23 03:20:42.865420
# Unit test for function get_selections
def test_get_selections():
    from ansible.modules.packaging.os import debconf
    from ansible.module_utils.basic import AnsibleModule
    import sys

    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    stdin = StringIO(''.encode('utf-8'))
    stdout = StringIO('this test had no error!'.encode('utf-8'))
    stderr = StringIO(''.encode('utf-8'))


# Generated at 2022-06-23 03:20:52.840456
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    # TODO: enable passing array of options and/or debconf file from get-selections dump
    pkg = module.params["name"]
    question = module.params["question"]
    vtype

# Generated at 2022-06-23 03:21:04.170067
# Unit test for function main
def test_main():
    import json
    import imp
    import os
    import sys

    from ansible.module_utils import basic

    tmpdir = os.path.realpath(os.path.join(sys.path[0], '..', '..', 'test', 'lib'))

    test_module = imp.load_source("test_module", os.path.join(tmpdir, "test_module.py"))

    play = {
      "hosts": "localhost",
      "become_user": "root",
      "vars": {
        "ansible_become": "yes"
      }
    }

    params = [
        "name",
        "question",
        "vtype",
        "value",
        "unseen"
    ]

    # Run check command

# Generated at 2022-06-23 03:21:06.893453
# Unit test for function get_selections
def test_get_selections():
    assert get_selections({}, 'tzdata')

# Generated at 2022-06-23 03:21:11.942360
# Unit test for function get_selections
def test_get_selections():
    module.params['name'] = 'tzdata'
    previous = get_selections(module, 'tzdata')
    assert previous
    module.exit_json(changed=False, msg='', current=previous)


# Generated at 2022-06-23 03:21:21.416640
# Unit test for function set_selection
def test_set_selection():
    # Pre-requisites for unit test
    import tempfile

    fd, tmpfile = tempfile.mkstemp()
    tmpfilename = tmpfile.name

    # Test set_selection for the case where value is a string
    # and all the arguments passed to the function are of expected type,
    # including the value which is a string, should return exit code 0.
    result = set_selection(tmpfilename, tmpfilename, tmpfilename, 'string', 'value', False)
    assert result == 0

    # Test set_selection for the case when we try to set a password,
    # the function should return exit code 0.
    result = set_selection(tmpfilename, tmpfilename, tmpfilename, 'password', 'value', False)
    assert result == 0

    # Test set_selection for the case when we try to set a boolean type data
    # and

# Generated at 2022-06-23 03:21:33.403465
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils import helpers

    import ansible.module_debconf


# Generated at 2022-06-23 03:21:43.042629
# Unit test for function main
def test_main():
    # Test with question
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
    )

    question = 'question_test'
    vtype = 'string'
    value = 'value_test'
    unseen = False
    prev = {}
   

# Generated at 2022-06-23 03:21:51.349421
# Unit test for function set_selection
def test_set_selection():

    class A:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, cmd, opt):
            self.cmd = cmd
            self.opt = opt
            return 'debconf-set-selections'

        def run_command(self, cmd, data):
            self.data = data
            return(0, '', '')

        def fail_json(self, msg):
            self.msg = msg

    m = A()
    rc, msg, err = set_selection(m, 'tzdata', 'GE', 'select', 'America/New York', False)
    assert m.cmd == 'debconf-set-selections'
    assert m.opt == True
    assert m.data == 'tzdata GE select America/New York'

# Generated at 2022-06-23 03:22:04.385399
# Unit test for function set_selection
def test_set_selection():
    # We only have a module set up for the unit test if we are run under a
    # unit test framework
    if 'module' not in vars():
        module = None

    # Assert that calling set_selection() without a module will fail
    try:
        set_selection(module, 'test_pkg', 'test_question', 'test_vtype',
                      'test_value', 'test_unseen')
    except UnboundLocalError:
        pass
    except:
        raise
    else:
        raise Exception('expected UnboundLocalError was not raised')

    # For the rest of the test, we only need to mock the module.run_command()
    # function.
    class MockModule:
        def get_bin_path(self, _, __):
            return 'MOCK_BIN'


# Generated at 2022-06-23 03:22:15.823899
# Unit test for function set_selection
def test_set_selection():
    # Test default behavior
    def test_default(mocker, monkeypatch):
        import ansible.module_utils.basic
        import ansible.module_utils.common.process
        mocker.patch.object(ansible.module_utils.basic, 'AnsibleModule')
        mocker.patch.object(ansible.module_utils.common.process, 'run_command')
        mocker.patch.object(ansible.module_utils.common.process, 'get_bin_path')
        class RunCommandMock:
            def __init__(self):
                self.returncode = 0
                self.stdout = b""
                self.stderr = b""

# Generated at 2022-06-23 03:22:28.811237
# Unit test for function get_selections
def test_get_selections():
    test_module = AnsibleModule(
        argument_spec= dict(
            name=dict(type='str'),
        )
    )

    actual_return = get_selections(test_module,'tzdata')
    expected_return = {'dialog': 'Dialog-based frontend', 'tzdata/Zones/Etc': 'UTC', 'tzdata/Zones/Asia': 'Tokyo', 'tzdata/Zones/Europe': 'Paris', 'tzdata/Areas': '', 'tzdata/Zones/America': 'New_York', 'tzdata/Zones/Africa': 'Algiers', 'tzdata/Zones/Australia': 'Sydney', 'tzdata/Zones/Antarctica': '', 'tzdata/Zones/SystemV': '', 'tzdata/Zones/Pacific': 'Fiji'}



# Generated at 2022-06-23 03:22:34.465494
# Unit test for function main
def test_main():
    setsel = module.get_bin_path('debconf-set-selections', True)
    pkg = 'locales'
    question = 'locales/default_environment_locale'
    vtype = 'select'
    value = 'fr_FR.UTF-8'
    unseen = False
    cmd = [setsel]
    if unseen:
        cmd.append('-u')
    data = ' '.join([pkg, question, vtype, value])
    module.run_command(cmd, data=data)


# Generated at 2022-06-23 03:22:36.458083
# Unit test for function set_selection
def test_set_selection():
    assert set_selection(module='', pkg='', question='', vtype='', value='', unseen='') == ''

# Generated at 2022-06-23 03:22:48.882318
# Unit test for function main
def test_main():
    global rc, out, err
    rc, out, err = 0, "", ""

    def mock_run_command(*args, **kwargs):
        global rc, out, err
        rc = args
        out = kwargs['data']
        return (0, "", "")

    def mock_fail_json(*args, **kwargs):
        global rc, out, err
        rc = args
        out = kwargs['msg']
        return (1, "", "")

    def mock_exit_json(*args, **kwargs):
        global rc, out, err
        rc = args
        out = kwargs['changed']
        return (0, "", "")

    def mock_get_bin_path(*args, **kwargs):
        global rc, out, err
        rc = args
        out = k

# Generated at 2022-06-23 03:22:49.460258
# Unit test for function set_selection
def test_set_selection():
    pass

# Generated at 2022-06-23 03:22:58.569104
# Unit test for function set_selection
def test_set_selection():
    import os
    import tempfile
    import random
    import string

    import ansible.utils.module_docs_fragments as mdf
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.pycompat24 import get_exception
    import ansible.module_utils.common.process

    # Support AnsibleModule.debug
    def debug(msg):
        print(msg)

    class TestModule(AnsibleModule):

        def run_command(self, args, data=None, check_rc=False):
            self.rc = 1
            self.out = ''
            self.err

# Generated at 2022-06-23 03:22:59.650003
# Unit test for function main
def test_main():
    assert main() == 'valid'

# Generated at 2022-06-23 03:23:11.319994
# Unit test for function main
def test_main():
    test_vars = dict(
        name='ansible',
        question='ansible/test_question',
        vtype='text',
        value='Test question',
        unseen=False,
    )

# Generated at 2022-06-23 03:23:23.492136
# Unit test for function set_selection
def test_set_selection():
    import ansible.module_utils.basic as basic_util
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.command import get_bin_path as ansiballz_get_bin_path
    import os
    import shutil
    import tempfile
    import unittest

    class FakeModule(object):
        def __init__(self):
            self.binary_module = True
            self._diff = False

        def get_bin_path(self, tool, required=False, opt_dirs=[]):
            return get_bin_path(tool, required, opt_dirs)

        def fail_json(self, *args, **kwargs):
            raise Exception(args[0])


# Generated at 2022-06-23 03:23:34.255835
# Unit test for function get_selections
def test_get_selections():
    # Test get_selections() on a package with selections
    assert get_selections(None, 'locales') == {
        'locales/default_environment_locale': '',
        'locales/locales_to_be_generated': 'en_US.UTF-8 UTF-8',
        'locales/locales_to_be_generated_cjknarrow': 'en_US.UTF-8 UTF-8',
        'locales/locales_to_be_generated_cjkwide': 'en_US.UTF-8 UTF-8',
    }
    # Test get_selections() on a package without selections
    assert get_selections(None, 'zsh') == {}


# Generated at 2022-06-23 03:23:44.489619
# Unit test for function get_selections
def test_get_selections():
    import tempfile
    cfg = tempfile.NamedTemporaryFile()
    cfg.write(b'''
# Ansible managed

# debconf pre-seed file for testing debconf module

# selections
testpkg testpkg/question boolean true
testpkg2 testpkg2/question boolean false
testpkg3 testpkg3/question boolean true
testpkg3 testpkg3/question2 boolean false
''')
    cfg.flush()
    import ansible
    module = ansible.module_utils.debconf.DebconfModule(
        argument_spec={},
        required_together=[],
        supports_check_mode=False,
    )
    module.run_command = mock_run_command
    module.run_command.cfg = cfg.name
    ret = get_selections(module, 'testpkg')

# Generated at 2022-06-23 03:23:49.770032
# Unit test for function get_selections
def test_get_selections():
    pkg = "tzdata"
    cmd = [txt.get_bin_path('debconf-show', True), pkg]
    rc, out, err = txt.run_command(' '.join(cmd))
    txt.assertEqual(rc, 0)
    txt.assertEqual(out, b"")
    txt.assertEqual(err, b"")

# Generated at 2022-06-23 03:24:01.833599
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(argument_spec=dict(name=dict(type='str', required=True), question=dict(type='str'), vtype=dict(type='str'), value=dict(type='str'), unseen=dict(type='bool', default=False)))

    module.get_bin_path = lambda x, y: '/usr/bin/%s' % x

    pkg = 'tzdata'
    question = 'tzdata/Zones/Etc'
    vtype = 'select'
    value = 'UTC'
    unseen = False
    rc, msg, err = set_selection(module, pkg, question, vtype, value, unseen)
    assert rc == 0
    assert msg == ''
    assert err == ''

    pkg = 'tzdata'
    question = 'tzdata/Zones/Etc'
   

# Generated at 2022-06-23 03:24:02.822083
# Unit test for function set_selection
def test_set_selection():

    assert set_selection == None

# Generated at 2022-06-23 03:24:16.045882
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )


# Generated at 2022-06-23 03:24:18.537587
# Unit test for function get_selections
def test_get_selections():
    data = get_selections('test','test')
    # test debconf_get_selections return null
    assert not data

# Generated at 2022-06-23 03:24:28.684129
# Unit test for function set_selection
def test_set_selection():
    module = AnsibleModule(argument_spec={})

    def run_command(cmd, data=None):
        set_selection.cmd = cmd
        set_selection.data = data

        return (0, '', '')

    module.run_command = run_command

    set_selection(module, 'test_debconf_package', 'test_debconf_question', 'test_debconf_type', 'test_debconf_value', False)

    assert set_selection.cmd == ['debconf-set-selections']
    assert set_selection.data == ' '.join(['test_debconf_package', 'test_debconf_question', 'test_debconf_type', 'test_debconf_value'])

# Generated at 2022-06-23 03:24:39.910195
# Unit test for function set_selection
def test_set_selection():
    test_module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = 'tzdata'
    question = 'tzdata/Areas'
    vtype = 'select'

# Generated at 2022-06-23 03:24:42.171158
# Unit test for function get_selections
def test_get_selections():
    assert get_selections(pkg) == {'tzdata/Areas': 'Europe', 'tzdata/Zones/Europe': 'Amsterdam'}

# Generated at 2022-06-23 03:24:54.660852
# Unit test for function main
def test_main():
    # Test with no parameter
    with pytest.raises(AnsibleFailJson) as excinfo:
        module = AnsibleModule(
            argument_spec=dict(
                name=dict(type='str', required=True, aliases=['pkg']),
                question=dict(type='str', aliases=['selection', 'setting']),
                vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
                value=dict(type='str', aliases=['answer']),
                unseen=dict(type='bool', default=False),
            ),
            required_together=(['question', 'vtype', 'value'],),
            supports_check_mode=True,
        )
    assert excinfo.value

# Generated at 2022-06-23 03:25:07.304277
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY2

    class TestModule(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
        VERSION_ADDED = basic.ANSIBLE_VERSION
        VERSION_COMPATIBLE = basic.ANSIBLE_VERSION

    #
    # Unit tests for module_utils/debconf.py main()
    #

# Generated at 2022-06-23 03:25:16.653132
# Unit test for function set_selection
def test_set_selection():
    import subprocess

    module = AnsibleModule()
    #Trying to set an error type. This will fail
    rc,msg,e = set_selection(module,'tzdata','tzdata/Zones/Etc','error','UTC',False)

    assert rc == 1
    assert e == 'debconf: DbDriver "passwords" warning: could not open /var/cache/debconf/passwords.dat: Permission denied\n'

    #Trying to set a selection. This will not fail
    rc,msg,e = set_selection(module,'tzdata','tzdata/Zones/Etc','select','UTC',False)

    assert rc == 0
    assert msg == ''

# Generated at 2022-06-23 03:25:17.816663
# Unit test for function set_selection
def test_set_selection():
    pass


# Generated at 2022-06-23 03:25:29.090423
# Unit test for function main
def test_main():
    import tempfile

    class AnsibleModuleMock(object):
        def __init__(self, argument_spec, required_together, supports_check_mode, **kwargs):
            self.argument_spec = argument_spec
            self.required_together = required_together
            self.supports_check_mode = supports_check_mode
        def fail_json(self, **kwargs):
            self.fail_args = kwargs.copy()
            raise Exception("fail_json called")
        def exit_json(self, **kwargs):
            self.exit_args = kwargs.copy()
        def run_command(self, cmd, data=None):
            self.cmd_calls.append({'cmd': cmd, 'data': data})
            return 0, "return value is a tuple", ""

# Generated at 2022-06-23 03:25:38.673469
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule

    m0 = AnsibleModule(argument_spec={})

    m0.run_command = MagicMock()
    m0.run_command.return_value = (0, 'out', 'err')
    m0.get_bin_path = MagicMock()
    m0.get_bin_path.return_value = ''

    return_value = set_selection(m0, 'pkg', 'question', 'vtype', 'value', False)
    m0.run_command.assert_called_with(['debconf-set-selections'], data='pkg question vtype value')
    assert return_value == (0, 'out', 'err')

    return_value = set_selection(m0, 'pkg', 'question', 'vtype', 'value', True)

# Generated at 2022-06-23 03:25:49.953280
# Unit test for function set_selection
def test_set_selection():
    import os
    import tempfile
    from ansible.module_utils._text import to_text
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(object):
        def __init__(self):
            self.params = {
                'name': 'test_package',
                'question': 'test_question',
                'vtype': 'string',
                'value': 'test_value',
                'unseen': False
            }

            self.tmpdir = tempfile.mkdtemp()
            self.fail_json = self.tmpdir.__del__
            self.run_command = self._run_command
            self.get_bin_path = self._get_bin_path


# Generated at 2022-06-23 03:25:54.666267
# Unit test for function get_selections
def test_get_selections():
    name = 'locales'
    expected_out = {
        'locales/locales_to_be_generated': '',
        'locales/default_environment_locale': '',
        'locales/preferred_environment_locale': '',
    }

    # Test with mocked input.
    module = instance(mock_module)
    out = get_selections(module, name)
    assert out == expected_out, out


# Generated at 2022-06-23 03:25:57.026631
# Unit test for function get_selections
def test_get_selections():

    assert get_selections(module, pkg) == {
        'tzdata/Areas': 'America',
        'tzdata/Zones/America': 'Sao_Paulo'
    }


# Generated at 2022-06-23 03:26:05.450982
# Unit test for function get_selections
def test_get_selections():
    import os
    import sys

    # Create some selections
    os.system('echo "selinux-policy-default\tselect\ttargeted" | debconf-set-selections')
    os.system('echo "selinux-policy-default\tselect\tmls" | debconf-set-selections')
    os.system('echo "selinux-policy-default\tselect\ttargeted" | debconf-set-selections')

    from ansible import context
    from ansible.module_utils.common.collections import ImmutableDict

    # Create module

# Generated at 2022-06-23 03:26:16.314540
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True, aliases=['pkg']),
            question=dict(type='str', aliases=['selection', 'setting']),
            vtype=dict(type='str', choices=['boolean', 'error', 'multiselect', 'note', 'password', 'seen', 'select', 'string', 'text', 'title']),
            value=dict(type='str', aliases=['answer']),
            unseen=dict(type='bool', default=False),
        ),
        required_together=(['question', 'vtype', 'value'],),
        supports_check_mode=True,
    )

    pkg = module.params["name"]

# Generated at 2022-06-23 03:26:28.703957
# Unit test for function set_selection
def test_set_selection():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            pkg       = dict(type='str'),
            question  = dict(type='str'),
            vtype     = dict(type='str'),
            value     = dict(type='str'),
            unseen    = dict(type='bool')
        ),
        supports_check_mode = True
    )

    pkg       = 'locales'
    question  = 'locales/locales_to_be_generated'
    vtype     = 'multiselect'
    value     = 'en_US.UTF-8 UTF-8, fr_FR.UTF-8 UTF-8'
    unseen    = False


# Generated at 2022-06-23 03:26:40.174212
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils import basic

    class FakeModule(object):
        def __init__(self):
            self.exit_json = basic.AnsibleModule.exit_json
            self.fail_json = basic.AnsibleModule.fail_json
            self.run_command = basic.AnsibleModule.run_command

    class FakeCmd(object):
        def __init__(self):
            self.returncode = 0
            self.stdout = '''* locales/default_environment_locale: en_US.UTF-8
* locales/locales_to_be_generated: en_US.UTF-8 UTF-8,fr_FR.UTF-8 UTF-8
'''
            self.stderr = ''
