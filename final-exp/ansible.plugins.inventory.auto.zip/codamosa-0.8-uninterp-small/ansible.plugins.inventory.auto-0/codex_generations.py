

# Generated at 2022-06-25 09:40:35.511478
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Instantiate the class
    inventory_module_0 = InventoryModule()
    # Test with valid arguments
    inventory = dict()
    loader = dict()
    path = ''
    cache = True
    # Call the method
    inventory_module_0.parse(inventory, loader, path, cache)


# Generated at 2022-06-25 09:40:39.313091
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory = inventory_module_1.parse() # should raise NotImplementedError

# Generated at 2022-06-25 09:40:40.676194
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(None,None,None,None)

# Generated at 2022-06-25 09:40:44.204399
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file('/etc/ansible/hosts') == True


# Generated at 2022-06-25 09:40:51.613046
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    yaml_file_path = 'yaml_fixture'
    yaml_file_name = 'yaml_file'
    yaml_file_data = '''
    plugin: auto
    '''

    inventory_module_0 = InventoryModule()
    inventory_loader_0 = inventory_loader
    inventory_loader_0.get = MagicMock()
    inventory_loader_0.get.return_value = inventory_module_0

    yaml_file_inst_0 = fake_yaml(yaml_file_data)
    open_mock = MagicMock(return_value=yaml_file_inst_0)

# Generated at 2022-06-25 09:40:54.664205
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    loader_0 = 'foo'
    path_0 = 'foo'
    cache_0 = False
    inventory_module_0.parse(loader_0, path_0, cache_0)


# Generated at 2022-06-25 09:41:02.222430
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Test type 'yml'
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file("test_inventory.yml") == True

    # Test type 'yaml'
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.verify_file("test_inventory.yaml") == True

    # Test type 'json'
    inventory_module_2 = InventoryModule()
    assert inventory_module_2.verify_file("test_inventory.json") == False

    # Test type 'ini'
    inventory_module_3 = InventoryModule()
    assert inventory_module_3.verify_file("test_inventory.ini") == False

# Generated at 2022-06-25 09:41:05.578711
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory = None
    loader = None
    path = None
    cache = True
    try:
        inventory_module_1.parse(inventory, loader, path, cache)
    except:
        pass



# Generated at 2022-06-25 09:41:08.069323
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory = object()
    loader = object()
    path = str()
    cache = bool()
    inventory_module_0.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:41:12.476355
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = 'inventory'
    loader_0 = 'loader'
    path_0 = 'path'
    cache_0 = True
    ret = inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)
    assert ret is None



# Generated at 2022-06-25 09:41:20.452547
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    	Test the parse method of class InventoryModule: By whitelisting C(auto) inventory plugin, any YAML inventory config
        file with a C(plugin) key at its root will automatically cause the named plugin to be loaded and executed with that
        config. This effectively provides automatic whitelisting of all installed/accessible inventory plugins.
    '''
    test_path = "test_path"
    test_cache = True
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(test_path, test_path, test_path,test_cache)


test_case_0()
test_InventoryModule_parse()

# Generated at 2022-06-25 09:41:25.583199
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = []
    loader_0 = []
    path_0 = ''
    cache_0 = False

    inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)


# Generated at 2022-06-25 09:41:30.530009
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    config_data = 'a'
    loader = './myfile'
    path = 'b'
    inventory_module_0.parse((config_data, loader, path))

# Generated at 2022-06-25 09:41:33.618328
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_obj = InventoryModule()
    inventory_loader_obj = PluginLoader()
    path = "foo.yaml"
    cache = True

    # Calling parse method of class InventoryModule
    inventory_module_parse_obj = inventory_module_obj.parse(inventory_loader_obj, path, cache)

# Generated at 2022-06-25 09:41:42.339491
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_1 = InventoryModule()
    inventory_module_2 = InventoryModule()
    inventory_module_3 = InventoryModule()
    inventory_module_4 = InventoryModule()
    inventory_module_5 = InventoryModule()

    inventory_0 = [{'_meta': {'hostvars': {}}}, {'_meta': {'hostvars': {}}}, {'_meta': {'hostvars': {}}}, {'_meta': {'hostvars': {}}}, {'_meta': {'hostvars': {}}}]

# Generated at 2022-06-25 09:41:44.844853
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.get_option()
    inventory_module_0.parse()

# Generated at 2022-06-25 09:41:53.613243
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv_mod = InventoryModule()

    # test that None is returned if path does not end with '.yml' or '.yaml'
    path = 'test.test'

    # test that there is no plugin_name in the config, a plugin name is required
    loader = 'loader'
    inventory = 'inventory'
    config_data = {'test': 'test'}
    loader.load_from_file.return_value = config_data
    cache = True
    with pytest.raises(AnsibleParserError):
        inv_mod.parse(inventory, loader, path, cache=cache)
    loader.load_from_file.assert_called_once_with(path, cache=False)

    # test that there is a plugin_name in the config, a plugin name is required, plugin is returned
    loader = 'loader'


# Generated at 2022-06-25 09:41:54.914960
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    # not implemented yet
#    inventory_module.parse(private_data, loader, options, cache=True)

# Generated at 2022-06-25 09:41:56.110222
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.parse(None, None, None) == None

# Generated at 2022-06-25 09:42:07.829418
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_1 = InventoryModule()
    ans_loader_0 = AnsibleLoader()
    inventory_loader_0 = InventoryLoader()
    inventory_0 = Inventory()
    path_0 = 'path'
    cache_0 = True
    ans_parser_error_0 = AnsibleParserError()
    try:
        inventory_module_1.parse(inventory_0, ans_loader_0, path_0, cache_0)
    except AnsibleParserError as err:
        ans_parser_error_1 = err
    else:
        ans_parser_error_1 = False

    assert ans_parser_error_0.message == ans_parser_error_1.message
    assert ans_parser_error_0.column == ans_parser_error_1.column
    assert ans

# Generated at 2022-06-25 09:42:15.980194
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_test_parse = InventoryModule()
    inventory_module_test_parse.update_cache_if_changed = lambda arg: None
    inventory_module_test_parse.parse("inventory", "loader", "path")


# Generated at 2022-06-25 09:42:17.010921
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:42:21.970200
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory = []
    loader = []
    path = "path"
    cache = True
    try:
        inventory_module_0.parse(inventory, loader, path, cache)
    except AnsibleParserError as e:
        print(e)


# Generated at 2022-06-25 09:42:28.357558
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    # Inject argument `inventory`
    # Inject argument `loader`
    # Inject argument `path`
    # Inject argument `cache`
    # Execution of parse method
    # Execution of parse method
    # Execution of parse method
    # Execution of parse method
    # Execution of parse method
    # Execution of parse method
    # Execution of parse method
    inventory_module_1.parse(None, None, './docs/examples/hosts', None)


# Generated at 2022-06-25 09:42:33.793071
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module = InventoryModule()

    # Test with no arguments passed
    try:
        inventory_module.parse()
    except Exception as e:
        assert(str(e) == "missing 1 required positional argument: 'path'")
    # END test_parse_with_no_args

    # Test with no verify_file function
    with mock.patch.object(InventoryModule, 'verify_file', return_value=None):
        try:
            inventory_module.parse('inventory_module_test_file')
        except Exception as e:
            assert(str(e) == "Could not find an acceptable plugin for this file. Verify that the file exists and is in YAML or JSON format.")
    # END test_parse_with_no_verify_file_function
# END test_InventoryModule_parse



# Generated at 2022-06-25 09:42:36.231852
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = AnsibleInventory((('set_variable', 'inventory_0'), ('set_variable', 'inventory_0')))
    loader_0 = DataLoader()
    path_0 = "vx"
    cache_0 = True
    try:
        inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)
    except AnsibleParserError:
        pass

# Generated at 2022-06-25 09:42:41.725423
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = ''
    loader_0 = ''
    path_0 = ''
    cache_0 = True
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)
    

# Generated at 2022-06-25 09:42:43.408782
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(B_0_0, B_0_1, B_0_2, B_0_3)


# Generated at 2022-06-25 09:42:49.876982
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import os
    import os.path
    import tempfile
    import yaml

    path = os.path.join(os.path.dirname(__file__), 'data', 'inventory.yaml')

    (fd, path) = tempfile.mkstemp()
    os.write(fd, 'plugin: ini\n')
    os.close(fd)

    config_data = yaml.safe_load(open(path).read())
    plugin_name = config_data.get('plugin', None)
    assert plugin_name == 'ini'
    os.remove(path)

    (fd, path) = tempfile.mkstemp()
    os.write(fd, 'plugin_name: ini\n')
    os.close(fd)


# Generated at 2022-06-25 09:42:52.849329
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    path = "/tmp/ansible-test/inventory/plugins/inventory"
    path = "./tests/unit/inventory/plugins/inventory/test_data"
    path = "/ansible-test/inventory/plugins/inventory"
    inventory_module_1.parse(inventory=None, loader=None, path=path)

# Generated at 2022-06-25 09:43:05.494605
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse([], [], [])

# Generated at 2022-06-25 09:43:07.636152
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:43:09.941404
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    path_str = 'test_str'
    cache_bool = False
    expected_succeed = True
    res = inventory_module_0.parse(inventory_module_0, inventory_loader, path_str, cache=cache_bool)
    assert res == expected_succeed


# Generated at 2022-06-25 09:43:13.070204
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = None
    loader_0 = None
    path_0 = ''
    cache_0 = True
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)

# Generated at 2022-06-25 09:43:17.634308
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = {}
    loader = {}
    path = './hosts'
    cache = True
    plugin = {
        "type": "script",
        "inventory_shortname": "ansible.builtin.script",
        "inventory_filename": "ansible/plugins/inventory/script.py"
    }

    assert inventory_module_0.verify_file(path) == True

# Generated at 2022-06-25 09:43:19.736480
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.parse(inventory_module_0, inventory_module_0, 'string_0').__class__ == None.__class__


# Generated at 2022-06-25 09:43:23.329096
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

# Generated at 2022-06-25 09:43:26.136655
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse("inventory", "loader", "path", "cache")

# Generated at 2022-06-25 09:43:30.501021
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    fake_loader = FakeLoader()
    fake_inventory = FakeInventory()
    path_to_fake_config_file = 'path/to/fake/config/file'
    cache = True
    inventory_module_1.parse(fake_inventory, fake_loader, path_to_fake_config_file, cache)



# Generated at 2022-06-25 09:43:31.009597
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    assert(False)

# Generated at 2022-06-25 09:43:44.400507
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.parse()

# Generated at 2022-06-25 09:43:54.946262
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    config_data = loader.load_from_file(path, cache=False)

    try:
        plugin_name = config_data.get('plugin', None)
    except AttributeError:
        plugin_name = None

    if not plugin_name:
        raise AnsibleParserError("no root 'plugin' key found, '{0}' is not a valid YAML inventory plugin config file".format(path))

    plugin = inventory_loader.get(plugin_name)

    if not plugin:
        raise AnsibleParserError("inventory config '{0}' specifies unknown plugin '{1}'".format(path, plugin_name))

    if not plugin.verify_file(path):
        raise AnsibleParserError("inventory config '{0}' could not be verified by plugin '{1}'".format(path, plugin_name))



# Generated at 2022-06-25 09:43:58.219199
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_case_0()

# Generated at 2022-06-25 09:44:00.994858
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    str_0 = 'Mfxd\'QYR"]zwfS,gAG'
    str_1 = 'Mfxd\'QYR"]zwfS,gAG'
    inventory_parse(str_0, str_1)


# Generated at 2022-06-25 09:44:10.672224
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Assert that the method parse of InventoryModule exists
    assertInventoryModule_parseMethodExists = True
    try:
        InventoryModule.parse
    except AttributeError:
        assertInventoryModule_parseMethodExists = False

    assert assertInventoryModule_parseMethodExists == True
    # Assert that the method parse of InventoryModule can be called
    assertInventoryModule_parseMethodCanBeCalled = False
    try:
        str_0 = 'Mfxd\'QYR"]zwfS,gAG'
        inventory_module_0 = InventoryModule()
        var_0 = inventory_module_0.parse(str_0)
        assertInventoryModule_parseMethodCanBeCalled = True
    except AttributeError:
        pass
    assert assertInventoryModule_parseMethodCanBeCalled == True

# Unit

# Generated at 2022-06-25 09:44:19.313855
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'Q\'Z5e5r)V5O=OFT`XR'
    str_4 = '^P\"'
    str_1 = ''
    str_3 = 'bG'
    str_2 = 'm pJ'
    inventory_module_0 = InventoryModule()
    class_0 = inventory_loader.get(str_4)
    module_0 = class_0.load_from_file(str_0, cache=False)
    class_0.verify_file(str_4)
    class_0.parse(inventory_module_0, str_3, str_2, cache=False)
    class_0.update_cache_if_changed()

if __name__ == "__main__":
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 09:44:25.252177
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'Mfxd\'QYR"]zwfS,gAG'
    cache_0 = True
    arg_0 = 'O@VrI.Qi,tVCHaYA'
    arg_1 = 'e~#o\'B'
    arg_2 = 'O@VrI.Qi,tVCHaYA'
    ansible_parser_error_0 = AnsibleParserError('cq$\'p&U;TmU?T')
    try:
        parse(str_0, arg_0, arg_1, arg_2, cache=cache_0)
    except Exception as exception_0:
        assert type(exception_0) == ansible_parser_error_0

# Generated at 2022-06-25 09:44:27.597419
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    try:
        inventory_module_0 = InventoryModule()
        inventory_module_0.parse()
    except Exception:
        return False
    else:
        return True


# Generated at 2022-06-25 09:44:31.309009
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    inventory_module_1 = InventoryModule()
    inventory_manager_1 = InventoryManager(loader=None, sources='localhost')
    str_1 = 'SvJ]MZ{/q3hC(w\x7fjKD'
    inventory_module_1.parse(inventory=inventory_manager_1, loader=None, path=str_1)


# Generated at 2022-06-25 09:44:41.379147
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_1 = 'Mfxd\'QYR"]zwfS,gAG'
    inventory_module_1 = InventoryModule(str_1,'i8n')
    str_2 = 'Fn!_8mTl'
    bytes_0 = b'\x1a\xf1\xfd\x16\x90'
    int_0 = 84
    var_1 = InventoryLoader.get_loader(str_2)
    str_3 = '|\x1d&&\xa2\xec\xb6'
    var_2 = inventory_module_1.get_loader(str_3)
    if (var_1 != var_2):
        raise ValueError
    str_4 = '\x1a\x1f\x1dU6\r\x98'

# Generated at 2022-06-25 09:45:10.260307
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'auto'
    inventory_module_0 = InventoryModule()
    plugin_name_0 = 'plugin'
    loader_0 = None
    path_0 = 'xXR.E'
    var_0 = inventory_parse(str_0, loader_0, path_0)


# Generated at 2022-06-25 09:45:20.232987
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'XzP"Sw"\x07\nC'
    var_0 = InventoryModule()
    var_1 = 'U1' # TODO: Make this random
    var_2 = 'M)qS1vS8\x12' # TODO: Make this random
    var_3 = '_QJgWi[wF%H' # TODO: Make this random
    var_4 = 'Q\'1\t-IxOd' # TODO: Make this random
    inventory_parse(var_0, var_1, var_2, var_3, var_4)


# Generated at 2022-06-25 09:45:22.084659
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    var_0 = parse(InventoryModule, loader)
    var_1 = parse(InventoryModule, loader, inventory)

# Generated at 2022-06-25 09:45:31.011390
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    var_0 = InventoryModule()
    str_0 = 'rqY,i"Ksa0ifgAC}#o9m'
    str_1 = 'V/>)M,i\';WHw%1q3b:y'
    str_2 = 'YVYiG&%ZhV7<dI#;$>7L'
    # Create the inventory object
    var_1 = Inventory(loader=var_0)
    str_3 = 'V/>)M,i\';WHw%1q3b:y'
    str_4 = 'YVYiG&%ZhV7<dI#;$>7L'
    var_2 = var_0.parse(str_3, str_4, inventory=var_1)


# Generated at 2022-06-25 09:45:40.097727
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    str_0 = 'sJARg"('
    str_1 = 'Qc'
    str_2 = '$'
    parser_error_0 = AnsibleParserError()
    loader_0 = MockLoader(str_0, str_1, str_2, parser_error_0)
    inventory_0 = MockInventory()
    var_0 = inventory_parse(loader_0, inventory_0)

if __name__ == '__main__':
    print(str(os.getenv('Bog')))
    print(str('Qc'))
    print(str('$'))
    test_case_0()
    print(str('$'))
    test_InventoryModule_parse()
    print(str('Y>*'))

# Generated at 2022-06-25 09:45:42.481340
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    try:
        inventory_module_parse(inventory_module_0, None, None, True)
    except AnsibleParserError as e:
        pass

# Generated at 2022-06-25 09:45:48.994690
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    dict_0 = dict()
    dict_0['gd.inp'] = 'hidden.hp'
    str_0 = 'Aldwych'
    dict_1 = dict()
    dict_1[5] = 'afzc'
    dict_1[6] = 'my.hu'
    dict_1[7] = 'hidden.ci'
    dict_1[8] = 'my.hu'
    dict_0['xh]mK|+m;IF>X)~,:Z' + '0' + '='] = dict_1
    dict_0['hidden.zc'] = 'afzc'
    dict_0['hidden.nh'] = 'hidden.dv'
    dict_0['hidden.zc'] = 'afzc'

# Generated at 2022-06-25 09:45:58.487293
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'gI~y.\x7f&%\x18\r\rG'
    loader_0 = BaseInventoryPlugin()

# Generated at 2022-06-25 09:46:03.181538
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    try:
        inventory_module_0.parse()
    # Exception raised
    except NameError:
        pass



# Generated at 2022-06-25 09:46:08.867294
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'G?Vufc3Fx,lV~'
    str_1 = '}Z/tB]+P,j'
    str_2 = 'G?Vufc3Fx,lV~'
    str_3 = '}Z/tB]+P,j'
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(str_0, str_1, str_2, str_3)



# Generated at 2022-06-25 09:47:16.372825
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    str_0 = 'f\x15\x02\x1e\x04T\x16\x0c\x18\x17\x17\x0e\x1e\x02\x1b\x1e\x18\x16'
    str_1 = '\x17\x02\x1d\x16\x1d\x18\x1d\x17\x1c\x02\x18\x18\x04\x17\x01\x14'
    str_2 = '\x07\x1b\x0f'
    var_0 = inventory_module_0.parse(str_0,str_1,str_2)



# Generated at 2022-06-25 09:47:17.480995
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
  assert test_case_0() == 'Mfxd\'QYR"]zwfS,gAG'

# Generated at 2022-06-25 09:47:24.215899
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    path = './tests/test_inventory_auto.py'
    config_data = {
        'plugin': 'ini'
    }

    inventory = []

    loader = MockInventoryLoader
    cache = True

    InventoryModule.parse(path, loader, config_data, cache)
    assert not parse_error
    assert InventoryModule.parse()


# Generated at 2022-06-25 09:47:26.769757
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    str_0 = 'Mfxd\'QYR"]zwfS,gAG'
    loader_0 = 'zm=XkX$p/'
    inventory_module.parse(str_0, loader_0, inventory_module)


# Generated at 2022-06-25 09:47:33.118204
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    loader_0 = FileLoader()
    #Failed to inject FileLoader
    path_0 = 'aGwW%cxru(A*\'-<]@b'
    assert InventoryModule.parse(inventory_module_0, loader_0, path_0) is None, "Failed to parse inventory 'aGwW%cxru(A*\'-<]@b' using plugin auto"


# Generated at 2022-06-25 09:47:34.543470
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_loader_1 = inventory_loader.get("auto")

# Generated at 2022-06-25 09:47:36.541523
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    i_0 = InventoryModule()
    i_1 = []
    l_0 = DictLoader()
    s_0 = ''
    assert(i_0.parse(i_1, l_0, s_0) == None)


# Generated at 2022-06-25 09:47:39.562776
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'G\'R"pTmMjy[B3UxLu#]^Y|)'
    inventory_module_0 = InventoryModule()
    var_0 = inventory_parse(str_0)

# Generated at 2022-06-25 09:47:45.692674
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    path_0 = './test_data/' + test_inventory_path + '.yaml'
    loader_0 = './test_data/' + test_loader_path

    path_1 = './test_data/' + test_inventory_path + '.yml'
    loader_1 = './test_data/' + test_loader_path

    path_2 = './test_data/' + test_inventory_path + '.yaml'
    loader_2 = './test_data/' + test_loader_path + '/'

    path_3 = './test_data/' + test_inventory_path + '.yml'
    loader_3 = './test_data/' + test_loader_path + '/'


# Generated at 2022-06-25 09:47:47.634528
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'Mfxd\'QYR"]zwfS,gAG'
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(int_0, int_1, str_0)

# Generated at 2022-06-25 09:50:19.253196
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'Mfxd\'QYR"]zwfS,gAG'
    inventory_module_0 = InventoryModule()
    var_0 = inventory_parse(str_0)
    str_1 = "no root 'plugin' key found,"
    str_2 = 'Mfxd\'QYR"]zwfS,gAG'
    str_3 = 'is not a valid YAML inventory plugin config file'
    if not ((str_1 in var_0) and (str_2 in var_0) and (str_3 in var_0)):
        raise AssertionError("Expected: " + str(str_1 + str_2 + str_3) + "\nActual: " + str(var_0))

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 09:50:24.813691
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = '%%D'
    str_1 = '8o;'
    str_2 = 'a\' '
    inventory_module_0 = InventoryModule()
    inventory_loader_0 = InventoryLoader(None)
    str_3 = '{I'
    var_0 = inventory_parse(str_3, inventory_loader_0, str_2, str_1)


# Generated at 2022-06-25 09:50:26.251354
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str = 'Mfxd\'QYR"]zwfS,gAG'
    inventory_module = InventoryModule()
    inventory_module.parse(inventory, loader, str)

