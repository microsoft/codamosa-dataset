

# Generated at 2022-06-25 09:40:34.799579
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse('test_inventory_module_1', 'test_loader_0', 'test_path_0', cache=True)


# Generated at 2022-06-25 09:40:44.329855
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    # Test with simple value
    inventory_module_0.parse(inventory="ccaa9625-19a0-45a6-ad7b-5c6a5d6f89b6",
                             loader='a0f8d2c0-a5bf-4bb0-b5f6-89e6ebbc9bc1',
                             path="53bd7869-b91a-4e73-a385-b7c3b1ac3b65",
                             cache='994a4f96-3a4b-4c23-8ff7-a0cf9e9f88ca')
    # Test with value None

# Generated at 2022-06-25 09:40:48.198354
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.parse(inventory="inventory_0", loader="loader_0", path="path_0") is None


# Generated at 2022-06-25 09:40:56.877884
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    assert('False' == inventory_module_1.verify_file('/tmp/test.cfg'))
    inventory_module_1 = InventoryModule()
    assert('False' == inventory_module_1.verify_file('/tmp/test.ini'))
    inventory_module_1 = InventoryModule()
    assert('True' == inventory_module_1.verify_file('/tmp/test.yml'))
    inventory_module_1 = InventoryModule()
    assert('True' == inventory_module_1.verify_file('/tmp/test.yaml'))


# Generated at 2022-06-25 09:40:59.808728
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:41:01.426340
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    assert True

# Generated at 2022-06-25 09:41:02.303011
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert True



# Generated at 2022-06-25 09:41:05.661606
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv_mod = InventoryModule()
    inventory = {'host1': 'foo.example.com'}
    loader = {'ip_address': '1.2.3.4'}
    path = 'foo'
    inv_mod.parse(inventory, loader, path)

# Generated at 2022-06-25 09:41:08.760515
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_loader_0 = Mock_InventoryLoader()
    inventory_1 = Mock_Inventory()
    inventory_module_0.parse('', inventory_loader_0, '', True)
    pass


# Generated at 2022-06-25 09:41:16.197098
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory import Inventory

    import pytest

    # Create a collection of hosts, groups and an inventory object
    host_0 = Host('host_name_0', port=0)
    host_1 = Host('host_name_1', port=1)
    host_2 = Host('host_name_2', port=2)
    host_3 = Host('host_name_3', port=3)
    host_4 = Host('host_name_4', port=4)
    host_5 = Host('host_name_5', port=5)
    host_6 = Host('host_name_6', port=6)
    host_7 = Host('host_name_7', port=7)

# Generated at 2022-06-25 09:41:26.103982
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory=None, loader=None, path='test_path', cache=True)
    inventory_module_2 = InventoryModule()
    inventory_module_2.parse(inventory=None, loader=None, path='test_path', cache=False)


# Generated at 2022-06-25 09:41:32.514473
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'l\t5!(*Vc-*O\\['
    inventory_module_0 = InventoryModule()
    inventory_loader_0 = InventoryLoader()
    inventory_0 = BaseInventory()
    cache_0 = None
    inventory_module_parse(str_0, inventory_0, inventory_loader_0, cache_0)


# Generated at 2022-06-25 09:41:34.888936
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:41:37.647172
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    p_0 = os.path.basename(__file__)
    var_0 = plugin_name
    str_0 = '#This plugin is not intended for direct use; it is a fallback mechanism for automatic whitelisting of'
    if str_0:
        InventoryModule.parse(str_0)
    p_2 = inventory_verify_file(str_0)


# Generated at 2022-06-25 09:41:39.118192
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_parse('\x7f\x96\x0b\x0c\xc4\x12\x9b\x0e', inventory_module_0)

# Generated at 2022-06-25 09:41:43.064268
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    str_0 = '2!S#SjP9'
    int_0 = 12
    inventory_module_0.parse(str_0, int_0)


# Generated at 2022-06-25 09:41:44.558983
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    with pytest.raises(AnsibleParserError):
        InventoryModule().parse()

# Generated at 2022-06-25 09:41:47.242927
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # inventory_parse
    # Argument specfication with path variable
    test_case_0()

if __name__ == "__main__":
    test_InventoryModule_parse()

# Generated at 2022-06-25 09:41:51.887964
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test if the method parse of class InventoryModule is working properly.
    str_0 = 'par*}$-_cer'
    str_1 = '?X8*yF(!v'

    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(str_0, str_1)

print(test_case_0())
print(test_InventoryModule_parse())

# Generated at 2022-06-25 09:41:56.099892
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    assert inventory_module.parse() == 'l\t5!(*Vc-*O\\['


# Generated at 2022-06-25 09:42:04.426501
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'test_inventory_0'
    inventory_module_0 = InventoryModule()
    inventory_module_parse(str_0)

# Generated at 2022-06-25 09:42:06.907238
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'l\t5!(*Vc-*O\\['
    inventory_module_0 = InventoryModule()
    var_0 = inventory_verify_file(str_0)

# Generated at 2022-06-25 09:42:16.912309
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:42:21.265232
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = dict()
    loader = dict()
    path = dict()
    cache = True
    inventory_module_0 = InventoryModule()
    var_0 = inventory_module_0.parse(inventory, loader, path, cache)


# Generated at 2022-06-25 09:42:25.133189
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    InventoryModule_parse_0 = InventoryModule()
    cache = True
    path = 'inventory.yml'
    loader = InventoryLoader()
    inventory = Inventory()
    InventoryModule_parse_0.parse(inventory, loader, path, cache=cache)


# Generated at 2022-06-25 09:42:28.069972
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_1 = 'x\x0b\xe6\x0f=\xf2'
    inventory_module_1 = InventoryModule()
    var_1 = inventory_module_1.parse(str_1)


# Generated at 2022-06-25 09:42:31.467122
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    file_path = "path/to/inventory_config_file"
    loader = "loader"
    inventory = "inventory"
    cache = True

    inventory_module = InventoryModule()

    # test with valid plugin_name
    inventory_module.parse(inventory, loader, file_path, cache)


# Generated at 2022-06-25 09:42:36.475935
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_class = InventoryModule
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 09:42:44.436755
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # setup
    str_0 = 'l\t5!(*Vc-*O\\['
    inventory_module_0 = InventoryModule()
    loader_0 = AnsibleLoader()
    path_0 = 'l\t5!(*Vc-*O\\['
    cache_0 = True

    # test
    try:
        inventory_module_parse(inventory_module_0, loader_0, path_0, cache_0)
    except Exception as e:
        # Except that the exception raised is not an instance of the type
        # expected.
        assert(type(e) == AnsibleParserError)

# Test case for the InventoryModule class
# Test case for the parse method of the class InventoryModule

# Generated at 2022-06-25 09:42:46.678198
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    # test with one parameter
    inventory_module_0.parse(None)


# Generated at 2022-06-25 09:43:07.356967
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module_name = 'auto'
    loader_name = 'auto'
    path_name = 'auto'
    cache_name = 'auto'

    # Test Case 0
    inventory_module_0 = InventoryModule()
    plugin = inventory_loader.get(loader_name)

    try:
        # inventory_module_0.parse(inventory, loader, path, cache=True)
        plugin.parse(inventory, loader, path, cache=True)
    except AnsibleParserError:
        raise AnsibleParserError("inventory config '{0}' specifies unknown plugin '{1}'".format(path, plugin_name))


# Generated at 2022-06-25 09:43:09.695840
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # TODO: This test might need to be updated later.
    assert True


# Generated at 2022-06-25 09:43:15.203688
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    var_1 = InventoryFile(Loader())
    str_1 = 'n/<*Y$/Qyz@r'
    str_2 = 'h \\{`\\%[b-A9'
    str_3 = 'h \\{`\\%[b-A9'
    bool_0 = True
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(var_1, str_1, str_2, str_3, bool_0)


# Generated at 2022-06-25 09:43:25.189466
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Empty call to argument parser to get inventory_loader property
    arg_parser = AnsibleArgumentParser()
    arg_parser.parse_args(args=[])

    inv_loader = arg_parser.inventory_loader

    # Construct test config data
    test_config_data = {}
    test_config_data['plugin'] = 'quasimodo'

    # Construct test inventory plugin
    test_plugin = InventoryModule()

    # Construct test loader
    test_loader = MockLoader()

    # Construct test inventory
    test_inventory = MockInventory()

    # Construct test path
    test_path = ''

    # Construct test cache
    test_cache = True

    # Construct test plugin
    test_plugin = InventoryModule()

    # Call test method

# Generated at 2022-06-25 09:43:28.032679
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'Plugin for group creation by splitting group name on a token.'
    inventory_module_0 = InventoryModule()
    var_0 = inventory_module_0.parse(str_0)


# Generated at 2022-06-25 09:43:33.068221
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'Jjfw4+$yFg:o=6D5j6'
    inventory_module_0 = InventoryModule()
    str_1 = '!Oo,xc@*]Khr[c0'


# Generated at 2022-06-25 09:43:35.586573
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'l\t5!(*Vc-*O\\['
    ansible_loader_0 = ansible.plugins.loader.inventory_loader.get(str_0)


# Generated at 2022-06-25 09:43:41.473937
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():


    # Test config_data
    config_data['plugin'] = 'example_inventory'

    # Test inventory
    inventory = dict({'example_inventory': dict({'hosts': dict({'host_0': dict({'ansible_host': 'host_0', 'inventory_hostname': 'host_0'})})})})

    # Test loader
    loader = AnsibleLoader()

    # Test path
    path = 'path'

    # Test cache
    cache = True

    # Test plugin_name
    plugin_name = 'example_inventory'

    # Test plugin
    plugin = dict({'verify_file': test_InventoryModule_parse_verify_file})

    # Test return
    return inventory



# Generated at 2022-06-25 09:43:46.538941
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = '.+jKl!1~6CG\x7f+G'
    inventory_module_0 = InventoryModule()
    # The following call may throw the specified exception, but it doesn't have the right arguments
    # assert_raises(AnsibleParserError, inventory_parse, str_0)


# Generated at 2022-06-25 09:43:51.940996
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = '.\\E6G1D_Hh\x7f\\o'
    listdir_0 = os.listdir(str_0)
    inventory_module_0 = InventoryModule()
    var_0 = inventory_module_0.parse(listdir_0)



# Generated at 2022-06-25 09:44:16.440563
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    var_0 = inventory_module_0.parse()

    assert (var_0 == None)

# Generated at 2022-06-25 09:44:20.083473
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = '58+^.N|-[d*l\n>t'
    inventory_module_0 = InventoryModule()
    inventory_module_0.verify_file(str_0)
    var_0 = InventoryModule.parse(inventory_module_0, str_0)


# Generated at 2022-06-25 09:44:25.143332
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'l\t5!(*Vc-*O\\['
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(str_0)


# Generated at 2022-06-25 09:44:32.070023
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    str_0 = '?Awv@f}F1FC9uA5'
    loader_0 = ansible_loader.get(str_0)
    str_1 = 'UH\\6zP&oJsI}C'
    bool_0 = True
    inventory_module_0.parse(str_0, loader_0, str_1, bool_0)
    str_2 = 'aYk2.jsxtE0z'
    loader_1 = ansible_loader.get(str_2)
    str_3 = 'PQo^Pt@!WOA9l{'
    bool_1 = True
    inventory_module_0.parse(str_2, loader_1, str_3, bool_1)

# Generated at 2022-06-25 09:44:34.876469
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Set up test fixture
    str_0 = "'"
    inventory_module_0 = InventoryModule()

    # Invoke method
    inventory_module_0.parse()
    assert True

# Generated at 2022-06-25 09:44:43.967842
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    str_0 = '\"/piE.\\r\\r`aF-Cn)\\r\\r`'
    str_1 = '(/piE.\\r\\r`aF-Cn)\\r\\r`'
    str_2 = 'plugin_0'
    # The exception context:
    class ExceptionContext_0: 
        def __init__(self, original_exception=None, traceback_string=None): 
            self.original_exception = original_exception 
            self.__cause__ = None 
            self.traceback_string = traceback_string 
    # The exception is created here:
    exception_0 = AttributeError()
    exception_0.__context__ = ExceptionContext_0()
    exception_1 = ValueError()

# Generated at 2022-06-25 09:44:48.140247
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = '\'\x01\x00o\xe2\x1b\x04\x08\x00\x00\x00\x01\x00\x00\x00\x12\x00'
    var_0 = test_case_0()
    str_1 = 'l\t5!(*Vc-*O\\['
    var_1 = inventory_parse(str_0, str_1)

# Generated at 2022-06-25 09:44:53.689891
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module_0 = InventoryModule()
    # Test case is from ansible/plugins/inventory/auto.py
    str_0 = 'l\t5!(*Vc-*O\\['
    str_1 = 'l\t5!(*Vc-*O\\['
    inventory_0 = InventoryModule.parse(module_0, str_0, str_1)
    var_0 = str_0

if __name__ == '__main__':
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 09:44:59.966497
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'l\t5!(*Vc-*O\\['
    inventory_module_0 = InventoryModule()
    inventory_loader_0 = InventoryLoader()
    loader_0 = inventory_loader.get(str_0)
    assert inventory_module_0.parse(str_0, loader_0, str_0, cache=True) is None
    assert inventory_module_0.parse(str_0, loader_0, str_0, cache=None) is None
    assert inventory_module_0.parse(str_0, loader_0, str_0, cache=None) is None
    assert inventory_module_0.parse(str_0, loader_0, str_0, cache=None) is None


# Generated at 2022-06-25 09:45:06.935417
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    temp_dict = {
        "path": "test file path",
        "inventory": {},
        "loader": {},
        "cache": True
    }
    inventory_module_object = InventoryModule()
    inventory_module_object.parse(temp_dict['path'], temp_dict['inventory'], temp_dict['loader'], temp_dict['cache'])

# Generated at 2022-06-25 09:46:09.761739
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_1 = 'E_Q2tACR<P7@"L-O!z'
    var = 'CY'
    inventory_module_1 = load_plugin_from_class('InventoryModule')
    kwargs = dict()
    kwargs.update(inventory_module_1())
    var_1 = inventory_module_1.parse(var, **kwargs)


# Generated at 2022-06-25 09:46:12.569991
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = '8ZbSRqr_>JF<zb\x7f'
    inventory_module_0 = InventoryModule()
    inventory_loading_5 = loader()
    var_0 = inventory_module_parse(str_0,inventory_loading_5)



# Generated at 2022-06-25 09:46:16.623241
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'l\t5!(*Vc-*O\\['
    inventory_module_0 = InventoryModule()
    var_0 = inventory_module_parse(str_0)


# Generated at 2022-06-25 09:46:22.472418
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    # Exception inventory_module_0._populate()
    # Exception inventory_module_0._populate()
    # Exception inventory_module_0._populate()
    # Exception inventory_module_0._populate()
    # Exception inventory_module_0._populate()
    # Exception inventory_module_0._populate()
    # Exception inventory_module_0._populate()
    # Exception inventory_module_0._populate()
    # Exception inventory_module_0._populate()
    # Exception inventory_module_0._populate()
    # Exception inventory_module_0._populate()
    # Exception inventory_module_0._populate()
    # Exception inventory_module_0._populate()
    # Exception inventory_module_0._populate()
    # Exception inventory_module

# Generated at 2022-06-25 09:46:23.346841
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse()


# Generated at 2022-06-25 09:46:28.652899
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Setup
    str_0 = 'l\t5!(*Vc-*O\\['
    inventory_module_0 = InventoryModule()
    inventory_0 = get_inventory()
    loader_0 = get_loader()
    cache_0 = False

    # Unit test
    inventory_module_0.parse(inventory_0, loader_0, str_0, cache_0)

    # Teardown
    inventory.clear_pattern_cache()

# Generated at 2022-06-25 09:46:32.663377
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_1 = InventoryModule()
    inventory_module_0.parse(inventory_module_0, inventory_module_1, str_0, var_0)


# Generated at 2022-06-25 09:46:38.693649
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    str_0 = 'j\x1a-L\x19'
    str_1 = '1t/'
    str_2 = '\\~H\\Z'
    var_0 = inventory_loader.get(str_0)
    if (var_0):
        if (var_0.verify_file(str_1)):
            var_0.parse(str_1, str_2)
        else:
            pass
    else:
        pass
    var_0.update_cache_if_changed()
    var_1 = inventory_module_0.verify_file(str_2)


# Generated at 2022-06-25 09:46:40.226745
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    host = 'localhost'
    port = 9022
    connection = 'ssh'
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:46:43.512017
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'l\t5!(*Vc-*O\\['
    inventory_module_0 = InventoryModule()
    loader_0 = DataLoader()
    str_1 = 'l\t5!(*Vc-*O\\['
    inventory_0 = Inventory()
    var_0 = inventory_module_0.parse(inventory_0, loader_0, str_1)

if __name__ == '__main__':
    test_InventoryModule_parse()

# Generated at 2022-06-25 09:48:56.975843
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_1 = '/home/travis/build/ansible/ansible/test/utils/inventory/test_dynamic.yml'
    inventory_module_1 = InventoryModule()
    var_1 = inventory_module_1.verify_file(str_1)
    assert var_1 == True, "InventoryModule.verify_file() returned False when it should have returned True"
    assert inventory_module_1.parse('/home/travis/build/ansible/ansible/test/utils/inventory/test_dynamic.yml') == None, "InventoryModule.parse() did not return the expected value"

# Generated at 2022-06-25 09:49:01.693820
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Initialize class
    inventory_module = InventoryModule()

    # TODO: Impliment this test.



# Generated at 2022-06-25 09:49:03.814547
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create an instance of the InventoryModule class
    inventory_module_0 = InventoryModule()

    # Test the parse method
    inventory_parse(inventory_module_0)


# Generated at 2022-06-25 09:49:09.509309
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'c='
    inventory_module_0 = InventoryModule()
    loader_0 = None
    str_1 = 'e'
    _test_parse(inventory_module_0, loader_0, str_0, str_1)


# Generated at 2022-06-25 09:49:14.613471
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'l\t5!(*Vc-*O\\['
    inventory_module_0 = InventoryModule()
    inventory_loader_0 = InventoryLoader()
    path_0 = ']|Cc:QP<>`c)`X'
    cache_0 = False
    inventory_module_0.parse(str_0, inventory_loader_0, path_0, cache_0)

# Generated at 2022-06-25 09:49:20.745159
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.set_options(var_2={'server': '10.1.1.26', 'port': 443, 'private_key': None, 'password': 'root', 'timeout': 10, 'url_username': 'USERID', 'remote_user': 'root', 'url': 'https://10.1.1.26/redfish/v1/Systems/System.Embedded.1/Memory/Memory.0/DIMMs/DIMM.1', 'use_ssl': True, 'validate_certs': True, 'url_password': 'PASSW0RD'})

# Generated at 2022-06-25 09:49:22.079097
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_1 = 'Y&C?+p~aJg|_:8'
    inventory_module_1 = InventoryModule()
    var_1 = inventory_parse(str_1)

# Generated at 2022-06-25 09:49:27.579631
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'l\t5!(*Vc-*O\\['
    inventory_module_0 = InventoryModule()
    var_0 = inventory_module_0.parse(str_0)


# Generated at 2022-06-25 09:49:32.992788
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.inventory import BaseInventoryPlugin
    from ansible.plugins.loader import inventory_loader
    from ansible.errors import AnsibleParserError
    # Params for InventoryModule.parse
    # Params for BaseInventoryPlugin.parse
    # Params for BaseInventoryPlugin.parse
    # Params for BaseInventoryPlugin.parse
    # Params for BaseInventoryPlugin.parse
    # Params for BaseInventoryPlugin.parse
    # TODO
    return


# Generated at 2022-06-25 09:49:34.361427
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    var_0 = inventory_module_0.parse()
