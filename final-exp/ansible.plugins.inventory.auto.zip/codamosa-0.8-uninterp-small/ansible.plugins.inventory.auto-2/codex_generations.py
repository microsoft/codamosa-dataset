

# Generated at 2022-06-25 09:40:39.133267
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    class InventoryDummy(object):
        hosts = {}
        groups = {}
        cache = {}
        vars = {}
        def get_host(self, hostname):
            return {hostname: {'hostvars': {}}}

    class LoaderDummy(object):
        def load_from_file(self, path, cache=True):
            return {'plugin': 'foo'}

    class InventoryLoaderDummy(object):
        def get(self, plugin_name):
            class InventoryPluginDummy(object):
                NAME = 'foo'
                def verify_file(self, path):
                    return True
                def parse(self, inventory, loader, path, cache=True):
                    inventory.vars = {'foo': 'bar'}
            return InventoryPluginDummy()

    inventory_module = InventoryModule()
    inventory

# Generated at 2022-06-25 09:40:42.619671
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_InventoryModule_parse_inv = InventoryModule() 
    try:
        assert test_InventoryModule_parse_inv
    except:
        raise



# Generated at 2022-06-25 09:40:51.480740
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    assert False == inventory_module_0.verify_file("test_InventoryModule_verify_file_0")
    assert False == inventory_module_0.verify_file("test_InventoryModule_verify_file_1")
    assert True == inventory_module_0.verify_file("test_InventoryModule_verify_file_2")
    assert True == inventory_module_0.verify_file("test_InventoryModule_verify_file_3")

# Generated at 2022-06-25 09:40:56.684205
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    assert (inventory_module_1.verify_file('/etc/ansible/hosts') is False)
    inventory_module_2 = InventoryModule()
    assert (inventory_module_2.verify_file('/etc/ansible/hosts.yaml') is True)
    inventory_module_3 = InventoryModule()
    assert (inventory_module_3.verify_file('/etc/ansible/hosts.yml') is True)

# Generated at 2022-06-25 09:41:07.483939
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()

    # Call with inventory
    inventory = dict()
    loader = dict()
    path = dict()
    cache = dict()
    module.parse(inventory, loader, path, cache)

    # Call with inventory, loader = None
    inventory = dict()
    loader = None
    path = dict()
    cache = dict()
    module.parse(inventory, loader, path, cache)

    # Call with inventory, loader, path = None
    inventory = dict()
    loader = dict()
    path = None
    cache = dict()
    module.parse(inventory, loader, path, cache)

    # Call with inventory, loader, path, cache = None
    inventory = dict()
    loader = dict()
    path = dict()
    cache = None
    module.parse(inventory, loader, path, cache)

   

# Generated at 2022-06-25 09:41:09.248578
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    initialize_inventory_module()
    initialize_loader()
    initialize_path()
    inventory_module_0.parse(inventory, loader, path)


# Generated at 2022-06-25 09:41:16.995271
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # parse with valid parameters
    inventory_module = InventoryModule()
    inventory_module.parse(inventory=None, loader=None, path='hosts', cache=True)
    # parse with missing inventory parameter
    inventory_module = InventoryModule()
    inventory_module.parse(loader=None, path='hosts', cache=True)
    # parse with missing loader parameter
    inventory_module = InventoryModule()
    inventory_module.parse(inventory=None, path='hosts', cache=True)
    # parse with missing path parameter
    inventory_module = InventoryModule()
    inventory_module.parse(inventory=None, loader=None, cache=True)
    # parse with missing cache parameter
    inventory_module = InventoryModule()
    inventory_module.parse(inventory=None, loader=None, path='hosts')


# Generated at 2022-06-25 09:41:23.433376
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    verification_result_1 = inventory_module_1.verify_file(path_to_file="/tmp/ansible_inventory_module_test_1.yml")
    assert(not verification_result_1)

    inventory_module_2 = InventoryModule()
    verification_result_2 = inventory_module_2.verify_file(path_to_file="/tmp/ansible_inventory_module_test_2.yaml")
    assert(not verification_result_2)

    inventory_module_3 = InventoryModule()
    verification_result_3 = inventory_module_3.verify_file(path_to_file="/tmp/ansible_inventory_module_test_3.py")
    assert(not verification_result_3)

    inventory_module_4 = InventoryModule()


# Generated at 2022-06-25 09:41:29.518064
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    assert inventory_module_0 != None
    assert inventory_module_0.NAME != None
    # TODO:  Maybe we could replace the following line with a call to the parse method of the
    #  inventory_module_0 instance. Currently the parse function calls a function called
    #  load_from_file on loader.  I was not able to instantiate a loader.
    # assert inventory_module_0.parse("string_0") == None

# Generated at 2022-06-25 09:41:31.206867
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse('inventory_module.inventory', 'loader', 'path', 'cache=True')


# Generated at 2022-06-25 09:41:35.161974
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert InventoryModule().parse('inventory', 'loader', 'path', True) == None


# Generated at 2022-06-25 09:41:36.834461
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory='inventory_module_0')

# Generated at 2022-06-25 09:41:39.378963
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Normal cases
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory, loader, path, cache=True)


# Generated at 2022-06-25 09:41:40.316889
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert_raises()


# Generated at 2022-06-25 09:41:46.565376
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = {"auto": []}
    loader = {"auto": []}
    path = {"auto": []}
    cache = {"auto": []}
    # Test does not throw exception
    try:
        inventory_module.parse(inventory, loader, path, cache)
    except Exception as e:
        assert(0)


# Generated at 2022-06-25 09:41:47.002384
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    InventoryModule_parse = InventoryModule()


# Generated at 2022-06-25 09:41:53.073311
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # simple test for InventoryModule.parse
    inventory_module_test_0 = InventoryModule()
    # assert callable
    assert isinstance(inventory_module_test_0.parse, collections.Callable)
    # assert return type
    assert isinstance(inventory_module_test_0.parse(), types.NoneType)


# Generated at 2022-06-25 09:41:54.765468
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    assert False == inventory_module_parse.parse(inventory=None, loader=None, path=None, cache=None)


# Generated at 2022-06-25 09:41:57.412101
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = {}
    loader_0 = {}
    path_0 = './dummy_plugin.yml'
    cache_0 = True
    retval_0 = inventory_module_0.parse(inventory_0, loader_0, path_0, cache=cache_0)


# Generated at 2022-06-25 09:41:59.729585
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_obj = InventoryModule()
    inventory_module_obj.parse()

# Generated at 2022-06-25 09:42:13.751583
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Valid input
    path = 'test.yml'
    loader = None
    cache = True
    inventory = None
    inventory_module_0 = InventoryModule()
    try:
        inventory_module_0.parse(inventory, loader, path, cache)
    except AnsibleParserError as e:
        if not e.message == "no root 'plugin' key found, '{0}' is not a valid YAML inventory plugin config file".format(path):
            raise Exception("Incorrect exception thrown")
    else:
        raise Exception("No exception thrown")

# Generated at 2022-06-25 09:42:17.727789
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_case_1 = InventoryModule()
    test_case_1.parse()


# Generated at 2022-06-25 09:42:26.482829
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Setup test data for parsing the given config file path
    config_file = 'test.yml'
    plugin_name = 'test'

    # Setup test inventory loader
    loader = FakeLoader()
    loader.set_data(get_config_data())

    # Setup test inventory
    inventory = FakeInventory()

    # Actual test case to validate the given inventory config file
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory, loader, config_file)

    # Assert the expected inventory name
    assert inventory_module_1.name == plugin_name


# Generated at 2022-06-25 09:42:28.940560
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    instance0 = InventoryModule()
    assert hasattr(instance0, 'parse')
    assert callable(getattr(instance0, 'parse', None))


# Generated at 2022-06-25 09:42:31.532797
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
  inventory_module_1 = InventoryModule()
  host = Host()
  inventory = Inventory()
  loader = PluginLoader()
  path = "test_path"
  inventory_module_1.parse(inventory, loader, path)
  

# Generated at 2022-06-25 09:42:36.518631
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    
    assert inventory_module_0.parse("dummy inventory","dummy loader", "dummy path", "dummy cache") == None


# Generated at 2022-06-25 09:42:38.982181
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory = 'inventory'
    loader = 'loader'
    path = 'path'
    cache = True
    inventory_module_0.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:42:43.106525
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test case 0
    inventory_module_test_case_0 = InventoryModule()
    inventory_module_test_case_0.parse(None, None, None)
    # Test case 1
    inventory_module_test_case_1 = InventoryModule()
    inventory_module_test_case_1.parse("asdf", None, None)
    # Test case 2
    inventory_module_test_case_2 = InventoryModule()
    inventory_module_test_case_2.parse(None, "asdf", None)
    # Test case 3
    inventory_module_test_case_3 = InventoryModule()
    inventory_module_test_case_3.parse(None, None, "asdf")
    # Test case 4
    inventory_module_test_case_4 = InventoryModule()
    inventory_module_test_case_

# Generated at 2022-06-25 09:42:49.658988
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    from ansible.plugins.loader import inventory_loader

    yml_config_file = "./test_data/test_inventory_plugin/test_config_file.yml"
    config_data = loader.load_from_file(yml_config_file, cache=False)
    plugin_name = config_data.get('plugin', None)
    plugin = inventory_loader.get(plugin_name)
    from ansible.parsing.dataloader import DataLoader
    loader_mock = DataLoader()
    inv_mock = plugin.InventoryModule()

    with patch.object(plugin.InventoryModule, 'parse') as mock_method:
        plugin.InventoryModule.parse(inv_mock, loader_mock, yml_config_file)
        mock_method.assert_called_once()
       

# Generated at 2022-06-25 09:42:53.640202
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    inventory_module_0.parse(None)


# Generated at 2022-06-25 09:43:15.067041
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Declaration of mock object
    inventory = type('inventory_mock_object', (object,), dict(vars={}, hosts={}, groups={}))()
    # Instantiation of object
    inventory_module_1 = InventoryModule()
    # Declaration of mock object
    loader = type('loader_mock_object', (object,), dict(load_from_file=lambda self, arg1, arg2=True: {'plugin': 'test_plugin_0'}, get=lambda self, arg1: None))()
    # Calling parse method
    with pytest.raises(AnsibleParserError):
        inventory_module_1.parse(inventory, loader, path='test_path_0', cache=False)


# Generated at 2022-06-25 09:43:20.447825
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = []
    loader = []
    path = 'pathname'
    cache = True

    # Call method
    retval = inventory_module.parse(inventory, loader, path, cache)

    assert retval == None

# Generated at 2022-06-25 09:43:24.275617
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory, loader, path, cache=True)


# Generated at 2022-06-25 09:43:27.372714
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert False == inventory_module_0.parse(inventory=(), loader=(), path=(), cache=True)


# Generated at 2022-06-25 09:43:31.268677
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()


# Generated at 2022-06-25 09:43:33.177875
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory=None, loader=None, path=None, cache=None)

# Generated at 2022-06-25 09:43:40.554614
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:43:47.631981
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = object()
    loader_0 = object()
    # format: off
    path_0 = '<path>'
    # format: on
    # format: off
    cache_0 = True
    # format: on

    try:
        inventory_module_0.parse(inventory_0, loader_0, path_0, cache=cache_0)
    except AnsibleParserError:
        pass


# Generated at 2022-06-25 09:43:52.372696
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = {}
    loader_0 = {}
    path_0 = '/etc/ansible/hosts'
    cache_0 = True
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)


# Generated at 2022-06-25 09:43:54.490760
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory, loader, path, cache=True)


# Generated at 2022-06-25 09:44:19.905119
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Testcase0 setup
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory=inventory, loader=loader, path=path, cache=cache)

# Generated at 2022-06-25 09:44:30.177396
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    inventory = {'_meta': {u'subscriptions': [(u'all', u'/etc/ansible/hosts')]}}


# Generated at 2022-06-25 09:44:33.672643
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    obj = InventoryModule()
    parseMethod = getattr(obj, 'parse')
    if not callable(parseMethod):
        raise Exception("'parse' is not a callable method")
    parseMethod()

# Generated at 2022-06-25 09:44:43.025300
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.verify_file('.yml')

    class Inventory:
        def __init__(self):
            pass

    def __init__(self):
        pass

    Inventory.__init__ = __init__

    class Loader:
        def __init__(self):
            pass

    def load_from_file(self, path, cache=True):
        config_data = path
        return config_data

    def get(self, plugin_name):
        plugin = plugin_name
        return plugin

    def verify_file(self, path):
        plugin_name = path
        return plugin_name

    def parse(self, inventory, loader, path, cache=True):
        config_data = loader
        return config_data

    Loader.load_from

# Generated at 2022-06-25 09:44:48.402502
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    with pytest.raises(AnsibleParserError, match=r".* Unable to parse .* as a YAML inventory source"):
        inventory_module_1.parse("TestString", "TestString", "TestString")

# Generated at 2022-06-25 09:44:52.671317
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    path = "/Users/johndoe/MyProject/ansible.cfg"
    inventory = {}
    loader = inventory_loader
    cache = True
    inventory_module_1.parse( inventory, loader, path, cache )


if __name__ == '__main__':
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 09:44:54.237113
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = BaseInventoryPlugin()
    loader = BaseInventoryPlugin()
    path = BaseInventoryPlugin()
    cache = BaseInventoryPlugin()
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:45:00.928391
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    with open("test/mock_inventory_file_path.yml", "r") as inventory_file:
        inventory_file = inventory_file.read()
    with open("test/mock_inventory_config_data.yml", "r") as config_file:
        config_file = config_file.read()
    with open("test/mock_inventory_object.yml", "r") as inventory_object_file:
        inventory_object_file = inventory_object_file.read()
    inventory_module_0 = InventoryModule()
    inventory_loader_0 = inventory_module_0.loader
    def parse_mock(inventory_module_0, inventory, loader, path, cache=True):
        assert inventory.__dict__ == yaml.load(inventory_object_file)

# Generated at 2022-06-25 09:45:04.075761
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory, loader, path, cache=True
    # Calling parse method
    result = inventory_module.parse(inventory, loader, path,cache=True)
    # Verifying the parse call and pass case

# Generated at 2022-06-25 09:45:07.002636
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory = inventory_module_0
    loader = inventory_module_0
    path = None
    cache = False
    assert inventory_module_0.parse(inventory, loader, path, cache) is None

# Generated at 2022-06-25 09:46:09.947348
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = object()
    loader_0 = object()
    path_0 = object()
    cache_0 = object()
    inventory_module_0.parse(inventory_0,loader_0,path_0,cache_0)

# Generated at 2022-06-25 09:46:18.209867
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_parse_0 = InventoryModule()
    inventory = {'subscriptions': {'subscription': {'subscription_id': 'subscription_id', 'tenant_id': 'tenant_id'}}}
    loader = 'loader'
    path = 'path'
    cache = 'cache'

    # Dialect expression fails to evaluate
    inventory_module_parse_0.verify_file = mock_verify_file_0
    inventory_module_parse_0.parse(inventory, loader, path, cache)

    # Return value of method parse of class InventoryModule
    assert (inventory_module_parse_0.parse(inventory, loader, path, cache) == (None))


# Generated at 2022-06-25 09:46:26.245700
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test that the plugin is not auto-whitelisted by default
    assert inventory_loader.get('auto') is None

    # Test that it appears when auto-whitelisted
    assert not inventory_loader.enabled
    # Data is a dict.
    inventory_loader.set_options(auto_whitelist=True)
    assert inventory_loader.get('auto') is not None

    # Perform a parse, using the file under test
    test_inventory = dict()
    test_loader = dict()
    test_path = 'test/test_auto.yaml'
    # Data is a dict.
    output = inventory_loader.get('auto').parse(test_inventory, test_loader, test_path)

    # Test that the correct group and host has been added
    assert output['all']['hosts']['localhost']

# Generated at 2022-06-25 09:46:34.212607
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inv_arg_1 = dict()
    inv_arg_2 = dict()
    inv_arg_3 = 'test'
    inv_arg_4 = dict()
    inv_arg_5 = True  # cache

    result = inventory_module_0.parse(inv_arg_1, inv_arg_2, inv_arg_3, cache=inv_arg_5)
    assert result is None


# Generated at 2022-06-25 09:46:37.354205
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Testing variation #1
    mock_inventory = "mock_inventory"
    mock_loader = "mock_loader"
    mock_path = "mock_path"
    inventory_module_1 = InventoryModule()
    # Calling the method
    inventory_module_1.parse(mock_inventory, mock_loader, mock_path)

# Generated at 2022-06-25 09:46:37.747734
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert False

# Generated at 2022-06-25 09:46:40.399510
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = object()
    loader_0 = object()
    path_0 = object()
    cache_0 = object()
    try:
        inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)
    except Exception as err:
        assert False, "Could not parse the file"


# Generated at 2022-06-25 09:46:46.398110
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.inventory import InventoryModule
    test_loader = DataLoader()
    test_group = Group('test')
    test_group.hosts = ['test']
    test_inventory = InventoryManager(loader=test_loader, sources=[])
    test_inventory.add_group(test_group)
    test_variable_manager = VariableManager(loader=test_loader, inventory=test_inventory)
    test_variable_manager._

# Generated at 2022-06-25 09:46:49.300865
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()

# Generated at 2022-06-25 09:46:55.028623
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    try:
        inventory_module_1.parse("inventory_module_1.inventory", "inventory_module_1.loader", "inventory_module_1.path")
    except Exception as excep:
        print("Exception : ", excep)
        assert True
    else:
        assert False


# Generated at 2022-06-25 09:48:13.354992
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_0 = Inventory(loader=None, variable_manager=None, host_list=set())
    loader_1 = DataLoader()
    str_0 = ':}+Xd8J'
    bool_0 = True
    inventory_parse(inventory_0, loader_1, str_0, bool_0)

# Generated at 2022-06-25 09:48:21.557312
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = None
    loader = None
    path = 'C:\\Users\\pjmahoney\\Desktop\\ansible-config'
    cache = True
    inventory_module_1 = InventoryModule()
    str_1 = 'H#i,`#D`9]B3^i<ARh\\K'
    var_1 = inventory_parse(inventory, loader, path, cache)



# Generated at 2022-06-25 09:48:26.636857
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    str_0 = '^_/u\rz![Z>}QT?\tB!'
    # Test method arguments
    loader = inventory_loader
    path = str_0
    cache = True
    inventory_module.parse(inventory, loader, path, cache=True)

# Generated at 2022-06-25 09:48:30.107207
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    str_0 = '^_/u\rz![Z>}QT?\tB!'
    loader = InventoryLoader(str_0)
    str_1 = '.['
    inventory = host_list(str_1)
    parse(inventory_module_0, inventory, loader, str_0, True)


# Generated at 2022-06-25 09:48:32.604766
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory = ''
    loader = ''
    path = ''
    cache = True
    inventory_module_0.parse(inventory, loader, path, cache)


# Generated at 2022-06-25 09:48:38.335962
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    str_1 = 'tUSTn'
    str_2 = '~|{(C5|>N5R#0i'
    str_3 = '2.5'
    str_4 = '^_/u\rz![Z>}QT?\tB!'
    str_5 = 'gA@(;X'
    str_6 = '^_/u\rz![Z>}QT?\tB!'
    var_1 = parse(str_1, str_2, str_3, str_4, str_5, str_6)



# Generated at 2022-06-25 09:48:39.938603
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    var_1 = inventory_parse(str_0, 'my_loader', str_0)

# Generated at 2022-06-25 09:48:48.799146
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    str_0 = '~\x0b3\-=9*4\x1eYb\x1cF'
    str_1 = '\x17\x02\x1d\x1f\x1e\x1f\x02\x1d6\x1a7\x1d\x02\x1a\x1f'
    var_0 = inventory_parse(str_0, str_1, str_0)
    inventory_module_0.update_cache_if_changed()


# Generated at 2022-06-25 09:48:52.301962
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = InventoryModule()
    loader_0 = InventoryModule()
    path_0 = 'a'
    cache_0 = True
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache=cache_0)


# Generated at 2022-06-25 09:48:59.049256
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    mock_InventoryModule = InventoryModule()
    inventory_0 = dict()
    loader_0 = dict()
    path_0 = 'C#}+!/T)T!\tF!]~l'
    cache_0 = True
    mock_InventoryModule.parse(inventory_0, loader_0, path_0, cache_0)
