

# Generated at 2022-06-25 09:40:34.564557
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create instance of class InventoryModule
    inventory_module = InventoryModule()
    # Test inventory plugin method parse
    assert inventory_module.parse('inventory', 'loader', 'path', 'cache=True') == None


# Generated at 2022-06-25 09:40:40.372186
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory=inventory_0, loader=loader_mock_factory.LoaderMockFactory(testcase_instance=test_case_0()), path='path_0')


# Generated at 2022-06-25 09:40:45.359452
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_2 = InventoryModule()
    inventory = "inventory"
    loader = "loader"
    path = "path"
    try:
        inventory_module_2.parse(inventory,loader,path,cache=True)
    except Exception as e:
        assert type(e) == AttributeError


# Generated at 2022-06-25 09:40:49.199348
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path = 'example.ini'
    arg_2 = False
    result = inventory_module_0.verify_file(path, arg_2)
    assert result is False
    path = 'example.yml'
    arg_2 = True
    result = inventory_module_0.verify_file(path, arg_2)
    assert result is True


# Generated at 2022-06-25 09:40:54.862674
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('/etc/hosts.yaml') == True
    assert inventory_module.verify_file('/etc/hosts.yml') == True
    assert inventory_module.verify_file('/etc/hosts.yaml/etc') == False

# Generated at 2022-06-25 09:40:57.902404
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    if not inventory_module_0.verify_file('/etc/ansible/hosts'):
        raise AssertionError()


# Generated at 2022-06-25 09:41:05.408038
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()

    # Input parameters:
    inventory = None
    loader = None
    path='./inventory/dummy.yaml'
    cache=None

    # Expected return value:
    expected = ['plugin']

    # Actual return value:
    actual = inventory_module.parse(inventory, loader, path, cache)

    # Testing if the expected value equals the actual value
    assert expected == actual


# Generated at 2022-06-25 09:41:07.912428
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.parse(inventory=inventory(), loader=loader(), path='/etc/ansible/hosts', cache=False) == None


# Generated at 2022-06-25 09:41:10.423358
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
  inventory_module_1 = InventoryModule()
  assert inventory_module_1.parse() == None

# Generated at 2022-06-25 09:41:12.149144
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    config_data = ["plugin"]
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(config_data)


# Generated at 2022-06-25 09:41:18.489300
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv_mod = InventoryModule()
    inv_mod.parse(None, None, "", cache=True)


# Generated at 2022-06-25 09:41:20.677435
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    path="abc.yml"
    inventory=None
    loader=None
    cache=True
    inventory_module_0 = InventoryModule()
    #assert raises(AnsibleParserError, inventory_module_0.parse, inventory, loader, path, cache)

# Generated at 2022-06-25 09:41:22.571073
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    # inventory_module_1.parse()

# Generated at 2022-06-25 09:41:24.947754
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(None, None, 'test/test.yml')

# Generated at 2022-06-25 09:41:28.909376
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()

# Generated at 2022-06-25 09:41:35.570079
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    config_data_0 = loader.load_from_file(path, cache=False)
    path_test_0 = '/etc/ansible/hosts'
    try:
        assert (((isinstance(config_data_0, dict)) and (config_data_0['plugin'] == 'ec2')) or ((isinstance(config_data_0, dict)) and (config_data_0['plugin'] == 'rax')) or ((isinstance(config_data_0, dict)) and (config_data_0['plugin'] == 'gce')))
    except AssertionError as e:
        raise(AnsibleParserError("no root 'plugin' key found, '{0}' is not a valid YAML inventory plugin config file".format(path)))

# Generated at 2022-06-25 09:41:38.913482
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory = ''
    loader = ''
    path = ''
    cache = ''
    return_value = inventory_module_0.parse(inventory, loader, path, cache)
    assert return_value is None

# Generated at 2022-06-25 09:41:47.663753
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    with pytest.raises(AnsibleParserError, match=r".*inventory config 'path/to/file' specifies unknown plugin 'test_inventory_plugin'.*"):
        inventory_module.parse(inventory=None, loader=object, path='path/to/file', cache=False)
    with pytest.raises(AnsibleParserError, match=r".*inventory config 'path/to/file' could not be verified by plugin 'test_inventory_plugin'.*"):
        inventory_module.parse(inventory=None, loader=object, path='path/to/file', cache=False)

# Generated at 2022-06-25 09:41:52.139876
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Setup the test data
    path = "/dev/null"

    # Parse test case 0
    test_0 = test_case_0()
    test_0.parse(None, None, path)

# Generated at 2022-06-25 09:41:54.408137
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    args = {'path': 'inventory_path', 'cache': 'cache', 'loader': 'loader', 'inventory': 'inventory'}
    try:
        module.parse(**args)
    except Exception as err:
        assert False, err


# Generated at 2022-06-25 09:42:09.186141
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module = InventoryModule()
    mock_inventory = 'mock_inventory'
    mock_loader = 'mock_loader'
    mock_path = 'mock_path'
    mock_cache = 'mock_cache'
    mock_config_data = 'mock_config_data'
    mock_plugin = 'mock_plugin'

    inventory_module.load_from_file = MagicMock(return_value=mock_config_data)
    inventory_module.get = MagicMock(return_value=mock_plugin)
    inventory_module.verify_file = MagicMock(return_value=True)

    inventory_module.parse(mock_inventory, mock_loader, mock_path, mock_cache)

# Generated at 2022-06-25 09:42:12.756486
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_case_0()

if __name__ == '__main__':
    test_InventoryModule_parse()

# Generated at 2022-06-25 09:42:16.637484
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_param_0 = None
    loader_param_0 = None
    path_param_0 = None
    cache_param_0 = True

    try:
        inventory_module_0.parse(inventory_param_0, loader_param_0, path_param_0, cache_param_0)
    except AnsibleParserError:
        pass


# Generated at 2022-06-25 09:42:17.933605
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    assert isinstance(inventory_module_1.parse, object)

# Generated at 2022-06-25 09:42:21.464973
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    assert not inventory_module_1.parse(inventory, loader, path, cache=True)


# Generated at 2022-06-25 09:42:24.405366
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()
    setattr(inv,"get_file_loader",Mock(return_value=Mock()))
    inv.parse({},{},{})

# Generated at 2022-06-25 09:42:25.905711
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    test1_parse = inventory_module_parse.parse()

# Generated at 2022-06-25 09:42:32.379458
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_loader_2 = ansible.plugins.loader.inventory_loader
    path_3 = mock.Mock()
    ansible.plugins.loader.inventory_loader.get.return_value = ansible.plugins.loader.inventory_loader
    ansible.plugins.loader.inventory_loader.get = mock.Mock(return_value='', side_effect=ansible.errors.AnsibleParserError("inventory config '/etc/ansible/hosts.ini' specifies unknown plugin 'myplugin'"))
    inventory_module_1.parse(inventory_loader_2, path_3)

# Generated at 2022-06-25 09:42:36.986471
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory = None
    loader = None
    path = None
    cache = None

    inventory_module_1.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:42:44.573147
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Unit tests for method parse of class InventoryModule.
    '''

    # Test arguments
    inventory = {
        "plugin": "auto",
        "hosts": "myhost",
    }
    loader = {
        "plugin": "auto",
        "hosts": "myhost",
    }
    path = {
        "plugin": "auto",
        "hosts": "myhost",
    }
    cache = {
        "plugin": "auto",
        "hosts": "myhost",
    }

    # Make the call
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:43:00.544394
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_2 = InventoryModule()
    inventory_module_2.parse('inventory', 'loader', 'path', 'cache')




# Generated at 2022-06-25 09:43:08.615721
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # We can not use nose because of the way Ansible plugins are loaded
    # so we use the stock unittest to test the plugin.
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    fake_loader = DataLoader()
    yaml_inventory = Inventory(loader=fake_loader, variable_manager=None, host_list=['/dev/null'])
    yaml_inventory.parse_source('/dev/null')
    # test good yaml
    yaml_inventory_plugin_test = InventoryModule()
    yaml_inventory_plugin_test.parse(yaml_inventory, fake_loader, 'test/inventory_test.yml')

# Generated at 2022-06-25 09:43:11.746319
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    parser = InventoryModule()
    assert parser.parse(None, None, None) is None

# Generated at 2022-06-25 09:43:14.949284
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = {}
    loader = {}
    path = './test_data/test_case_0.yml'
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file(path), 'Cannot verify the file.'
    inventory_module_0.parse(inventory, loader, path, cache=True)

# Generated at 2022-06-25 09:43:25.009889
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print("In test_InventoryModule_parse")

    inventory_module_0 = InventoryModule()
    argv_inventory_0 = ansible.inventory.Inventory(loader=ansible.parsing.dataloader.DataLoader())
    argv_loader_0 = ansible.parsing.dataloader.DataLoader()
    argv_path_0 = "/path/to/file.yml"
    argv_cache_0 = True

    try:
        inventory_module_0.parse(argv_inventory_0, argv_loader_0, argv_path_0, argv_cache_0)
    except AnsibleParserError as argument:
        print("AnsibleParserError caught")

# Generated at 2022-06-25 09:43:29.870379
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = Inventory()
    loader_0 = DataLoader()
    path_0 = ''
    cache_0 = True
    # assert_raises(AnsibleParserError, inventory_module_0.parse, inventory_0, loader_0, path_0, cache_0)
    pass


# Generated at 2022-06-25 09:43:33.196762
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    with pytest.raises(AnsibleParserError) as exception_info:
        result = inventory_module_1.parse('inventory_0', 'loader_0', 'path_0')
    assert exception_info.match('no root \'plugin\' key found, \'path_0\' is not a valid YAML inventory plugin config file')



# Generated at 2022-06-25 09:43:40.579708
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    from ansible.plugins.loader import inventory_loader
    inventory_loader.get_plugin_loader.cache_clear()
    loader_0 = inventory_loader.get_plugin_loader('yaml')
    ans_obj = lambda: None
    ans_obj.__setattr__('_restriction', None)
    ans_obj.__setattr__('_subset', None)
    ans_obj.__setattr__('_inventory_basedirs', None)

    # Testing error case when content of yaml file is empty
    m = 'No inventory sources set'
    assert m in inventory_module_0.parse(None, loader_0, inventory_module_0.find_file("empty.yml"), cache=True)

    # Testing error case when content of yaml file does not have a plugin

# Generated at 2022-06-25 09:43:45.154317
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module =  InventoryModule()
    inventory = dict()
    loader = dict()
    path = '/home/ansible/ansible/plugins/inventory/auto.py'
    cache = True
    inventory_module.parse(inventory,loader,path,cache)

# Generated at 2022-06-25 09:43:48.364534
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = object()
    loader = object()
    path = '/path/to/inventory'
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory, loader, path)


# Generated at 2022-06-25 09:44:16.051885
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse(inventory, loader, path, cache=True)

# Generated at 2022-06-25 09:44:23.394113
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create testcase object
    inventory_module_testcase_0 = InventoryModule()

    # Create test objects
    inventory_test_0 = dict()
    loader_test_0 = dict()
    path_test_0 = dict()

    # Set test variables
    inventory_test_0['_restriction'] = None
    loader_test_0['_basedir'] = None
    loader_test_0['_vars_plugins'] = None
    loader_test_0['_module_cache'] = None
    loader_test_0['_filter_loader'] = None
    loader_test_0['_connection_loader'] = None
    loader_test_0['_lookup_loader'] = None
    loader_test_0['_cwd'] = None
    loader_test_0['_module_paths'] = None
   

# Generated at 2022-06-25 09:44:25.697425
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(None, None, 'test/unit/plugins/inventory/test.yml')

# Generated at 2022-06-25 09:44:27.017733
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse()

# Generated at 2022-06-25 09:44:29.716075
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Execute test
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse('my_inventory', 'my_loader', 'my_path', 'my_cache')


# Generated at 2022-06-25 09:44:35.482257
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    # TODO: update for parameterized inventory lookup
    # inventory_module_1.parse(
    #     inventory = None,
    #     loader = None,
    #     path = 'test/test_inventory_module_parse_1.yaml',
    #     cache = None,
    # )

    return 0


# Generated at 2022-06-25 09:44:37.671005
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_InventoryModule = InventoryModule()
    test_InventoryModule.parse(inventory, loader, path, cache=True)


# Generated at 2022-06-25 09:44:41.727892
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_0 = InventoryModule()
    inventory_loader_0 = InventoryLoader()
    path_0 = ".example/inventory_test/test.yml"
    result = inventory_module_0.parse(inventory_loader_0, path_0)

    assert result == None, "Failed to parse valid input"



# Generated at 2022-06-25 09:44:45.444378
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Make sure parse method can be called
    inventory_module_0 = InventoryModule()
    loader_0 = inventory_module_0.loader
    inventory_module_0.parse(
        inventory=inventory_module_0.inventory,
        loader=loader_0,
        path='/dev/null'
    )


# Generated at 2022-06-25 09:44:46.256248
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_InventoryModule_parse_0()


# Generated at 2022-06-25 09:45:51.309668
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_case_0()

test_InventoryModule_parse()

# Generated at 2022-06-25 09:45:58.859727
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule();
    config_data = {
        "_meta": {
            "hostvars": {
                "host1": {
                    "ansible_host": "192.168.56.101",
                    "ansible_ssh_port": 2222
                }
            }
        },
        "group1": {
            "hosts": [
                "host1",
                "192.168.56.101"
            ],
            "vars": {
                "var1": "value1",
                "var2": "value2"
            }
        }
    }

    config_file_path = "./test/unittests/inventory/test_plugin_auto.yml"
    loader = {
        "load_from_file": lambda path, cache=True: config_data
    }


# Generated at 2022-06-25 09:46:03.859509
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    # store values here to compare later
    test_case_0_result = {}

    # setup variables
    inventory_module_0.parse()

    # test assertions
    # check results
    assert test_case_0_result == {}

# Generated at 2022-06-25 09:46:06.199526
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # InventoryModule.parse(inventory, loader, path, cache=True)

    # Check inventory.hosts
    # Check inventory.groups
    pass



# Generated at 2022-06-25 09:46:08.503856
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory = {}
    loader = {}
    path = {}
    inventory_module_1.parse(inventory, loader, path)


# Generated at 2022-06-25 09:46:17.555355
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_2 = InventoryModule()
    inventory_module_3 = InventoryModule()
    inventory_module_4 = InventoryModule()

    # initialize with test data
    inventory_module_1.parse(inventory = {}, loader = {'load_from_file': 'load_from_file'}, path = "path", cache = True)
    inventory_module_2.parse(inventory = {}, loader = {'load_from_file': 'load_from_file'}, path = "path", cache = False)
    inventory_module_3.parse(inventory = {'plugin': "plugin"}, loader = {'load_from_file': 'load_from_file'}, path = "path", cache = True)

# Generated at 2022-06-25 09:46:20.364657
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    l = ['inventory/sample_static.yml']
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.parse(0, l, 0) == []

# Generated at 2022-06-25 09:46:21.060845
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

# Generated at 2022-06-25 09:46:23.391338
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = AnsibleInventory()
    loader_0 = AnsibleLoader()
    path_0 = 'ansible_inventory.txt'
    cache_0 = False
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)


# Generated at 2022-06-25 09:46:25.973979
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse('inventory_module_1', 'loader_0', 'path_0', True)

# Generated at 2022-06-25 09:47:45.747222
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:47:50.678770
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    float_0 = -0.095
    int_0 = -1530
    float_1 = -0.095
    str_0 = 'undefined'
    bool_0 = bool_0 = bool(str_0)
    bool_0 = bool(str_0)
    int_1 = -1530
    bool_1 = bool_1 = bool(str_0)
    bool_1 = bool(str_0)
    bool_1 = bool(str_0)
    bool_1 = bool(str_0)
    bool_1 = bool(str_0)
    bool_1 = bool(str_0)
    bool_1 = bool(str_0)
    bool_1 = bool(str_0)
    bool_1 = bool(str_0)

# Generated at 2022-06-25 09:47:53.113144
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print("InventoryModule.parse")
    obj_0 = InventoryModule()
    obj_0.parse("inventory", "loader", "path", cache=True)

# Generated at 2022-06-25 09:47:56.376310
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    float_0 = -2322.149977
    inventory_module_0 = InventoryModule()
    var_0 = inventory_module_0.verify_file(float_0)
    var_0 = inventory_module_0.parse(0)

# Generated at 2022-06-25 09:47:58.500073
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import inspect
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse()
    func_args = inspect.getargspec(inventory_module_0.parse).args
    assert len(func_args) == 4


# Generated at 2022-06-25 09:48:00.841917
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    float_0 = 427.43
    inventory_parse(float_0)

# Generated at 2022-06-25 09:48:02.940216
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    path = "/home/automation/test_framework/test_data/"
    # inventory_module_0.parse(inventory, loader, path, cache=True)
    inventory_module_0.parse()

# Generated at 2022-06-25 09:48:07.414362
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    float_0 = -928.680233
    inventory_0 = float_0
    loader_0 = inventory_module_1.loader
    float_1 = -2827.629041
    float_2 = -989.390905
    var_0 = inventory_module_1.parse(inventory_0, loader_0, float_1, float_2)


# Generated at 2022-06-25 09:48:14.828834
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    data = dict()
    data['plugin'] = 'nvidia_gpu'
    assert inventory_module_0._parse_options(data) is None
    assert inventory_module_0.params() is None
    assert inventory_module_0.get_option('plugin') == "nvidia_gpu"
    assert inventory_module_0.get_option('this_does_not_exist') is None

# Generated at 2022-06-25 09:48:21.243090
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    loader_0 = InventoryLoader()
    inventory_0 = Inventory()
    inventory_module_0.parse(inventory_0, loader_0, '', cache=True)

if __name__ == "__main__":
    test_case_0()
    test_InventoryModule_parse()