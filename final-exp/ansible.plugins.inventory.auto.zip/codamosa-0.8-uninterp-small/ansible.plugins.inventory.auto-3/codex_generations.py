

# Generated at 2022-06-25 09:40:35.802714
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    assert not inventory_module_1.verify_file('/tmp/test/foo.bar')
    assert inventory_module_1.verify_file('/tmp/test/foo.yml')
    assert inventory_module_1.verify_file('/tmp/test/foo.yaml')

# Generated at 2022-06-25 09:40:40.336739
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path_0 = './test_file.yml'
    test_result = inventory_module_0.verify_file(path_0)
    assert test_result

# Generated at 2022-06-25 09:40:47.197882
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    """Test the verify_file method of InventoryModule"""
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file('Path to file') == False
    # Test True case
    assert inventory_module_0.verify_file('Path to file.yml') == True
    assert inventory_module_0.verify_file('Path to file.yaml') == True
    # Test with args
    assert inventory_module_0.verify_file('Path to file',True) == False

# Generated at 2022-06-25 09:40:49.962117
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory=None, loader=None, path=None, cache=None)


# Generated at 2022-06-25 09:40:50.734171
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_case_0()

# Generated at 2022-06-25 09:41:00.248754
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
# Generate inventory_module_1
    inventory_module_1 = InventoryModule()

# Generate path_1
    path_1 = "./test_cases/ansible-2.6.16/plugins/inventory/"

# Generate inventory_2
    inventory_2 = "test_inventory_2"

# Generate loader_3
    loader_3 = "test_loader_3"

# Generate cache_5
    cache_5 = True

# Generate path_2
    path_2 = "./test_cases/ansible-2.6.16/plugins/inventory/host_list"

# Call inventory_module_1.parse with inventory_2, loader_3, path_2, and cache_5

# Generated at 2022-06-25 09:41:01.429568
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory, loader, path, cache)


# Generated at 2022-06-25 09:41:04.042596
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_obj = InventoryModule()
    assert_string = 'The identify of this test_case is: %s' % 'test_InventoryModule_parse'
    print(assert_string)


# Generated at 2022-06-25 09:41:09.199906
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    my_inventory_module = InventoryModule()
    assert not my_inventory_module.verify_file('my_file.txt')
    assert not my_inventory_module.verify_file('my_file.conf')
    assert my_inventory_module.verify_file('my_file.yml')
    assert my_inventory_module.verify_file('my_file.yaml')
    assert not my_inventory_module.verify_file('my_file.json')

# Generated at 2022-06-25 09:41:12.341244
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file(path='/etc/ansible/hosts') == False
    assert inventory_module_0.verify_file(path='/etc/ansible/hosts.yml') == True


# Generated at 2022-06-25 09:41:18.513401
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse('', 'inventory_loader_0', 'path_0', cache = True)


# Generated at 2022-06-25 09:41:19.572755
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    target = InventoryModule()
    inventory = None
    loader = None
    path = 'test_case_0'
    cache = True
    target.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:41:21.911780
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print("Parsing inventory_file")

# Generated at 2022-06-25 09:41:23.288127
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    assert True

# Generated at 2022-06-25 09:41:25.582721
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    assert True == inventory_module_1.parse()

# Generated at 2022-06-25 09:41:29.279439
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse()

# Generated at 2022-06-25 09:41:32.042474
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Instantiate class
    InventoryModule_instance = InventoryModule()

    # Set params
    inventory = 0
    loader = 0
    path = ""
    cache = True

    # Invoke method
    InventoryModule_instance.parse(inventory, loader, path, cache)



# Generated at 2022-06-25 09:41:42.249417
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    dict1 = { 'plugin':'auto' }
    dict2 = { 'plugin':'auto', 'cache':True }
    dict3 = { 'plugin':'auto', 'path':"/home/mohit/ansible-mohit-workspace-0/code/plugins/inventory/azure_rm.yml", 'cache':True }
    dict4 = { 'plugin':'auto', 'path':"/home/mohit/ansible-mohit-workspace-0/code/plugins/inventory/azure_rm.yml", 'cache':False }

    inventory_module_0 = InventoryModule()
    inventory_module_1 = InventoryModule()
    inventory_module_2 = InventoryModule()
    inventory_module_3 = InventoryModule()

    inventory_module_0.parse(dict1)
    inventory_module

# Generated at 2022-06-25 09:41:45.575134
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    im = InventoryModule()
    path = '/tmp/testing'
    assert im.parse(path) == "inventory config '{0}' could not be verified by plugin '{1}'".format(path, plugin_name)

# Generated at 2022-06-25 09:41:51.369930
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create a test inventory file for running test_case_0.
    test_file = open("test_InventoryModule_parse.yaml", "w+")
    test_file.write("""
- plugin: test_file
""")
    test_file.close()

    # Create a test inventory module to run test_case_0.
    test_module = InventoryModule()
    test_module.parse("inventory", "loader", "test_InventoryModule_parse.yaml")

# Generated at 2022-06-25 09:42:00.878419
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:42:06.160045
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    with pytest.raises(AnsibleParserError) as excinfo:
        inventory_module_0.parse(plugin, loader, path="bad_path.yaml")
    assert "inventory config 'bad_path.yaml' specifies unknown plugin 'bad_plugin'" in str(excinfo.value)


# Generated at 2022-06-25 09:42:08.258686
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse('inventory', 'loader', 'path', 'cache')

# Generated at 2022-06-25 09:42:13.043385
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory = inventory_module_0.inventory
    loader = inventory_module_0.loader
    path = inventory_module_0.path
    inventory_module_0.parse(inventory, loader, path)

# Generated at 2022-06-25 09:42:16.638165
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
	parser = MockInventoryParser()
	loader = MockDataLoader()
	path = "data_source"
	cache = True
	module = InventoryModule()

	module.parse(parser, loader, path, cache)

	loader.load_from_file.assert_called_with(path, cache)
	parser.clear_pattern_cache.assert_called_with()


# Generated at 2022-06-25 09:42:21.815619
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_loader_1 = AnsiblePluginLoader('inventory')
    inventory_1 = AnsibleCollection()
    path_1 = './test/data/test_0/test_file.yml'
    inventory_module_1.parse(inventory_1, inventory_loader_1, path_1)

# Generated at 2022-06-25 09:42:27.332218
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create an instance of InventoryModule
    inventory_module = InventoryModule()

    # Create the inventory object.
    inventory = "inventory"
    # Create a loader object.
    loader = "loader"
    # Create the path.
    path = "path"
    # Create the cache value.
    cache = True
    # Parse the inventory.
    result = inventory_module.parse(inventory, loader, path, cache)
    assert(result is None)

# Generated at 2022-06-25 09:42:29.114824
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.parse(inventory=None, loader=None, path=None, cache=True) is None

# Generated at 2022-06-25 09:42:33.966977
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    i = type("temp", (object,), {"NAME" : "ansible_inventory_plugin"})
    inv_mod = InventoryModule()
    inv = type("temp", (object,), {"_restriction": None, "hosts": [], "groups": [], "parser": i,
                                   "cache": {}, "inventory": "my_inventory"})
    loader = type("temp", (object,), {"_inventory_filename": "my_file"})
    path = "./test_auto_plugin"
    inv_mod.parse(inv, loader, path, cache=True)

# Generated at 2022-06-25 09:42:35.153776
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = []
    loader = []
    path = []
    cache = True
    InventoryModule_obj = InventoryModule()
    InventoryModule_obj.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:42:59.126341
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = {}
    loader = None
    path = '~/.ansible/plugins/inventory/test/test_case_0'
    cache = True

    # Parse
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory, loader, path, cache)


# Generated at 2022-06-25 09:43:05.029126
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    loader_0 = inventory_loader
    path_0 = str()
    inventory_module_0.parse('', loader_0, path_0)


# Generated at 2022-06-25 09:43:07.253970
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    # Set up test data
    inventory = object()
    loader = object()
    path = '/etc/ansible/hosts'
    # set the test case
    inventory_module_0.parse(inventory, loader, path)

# Generated at 2022-06-25 09:43:11.222052
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = {}
    loader_0 = {}
    path_0 = "/ansible/test/inventory/test_inventory_auto.yml"
    assert inventory_module_0.parse(inventory_0, loader_0, path_0) == None

# Generated at 2022-06-25 09:43:13.835443
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory = {}
    loader = {}
    path = {}
    cache = {}
    result = inventory_module_0.parse(inventory, loader, path, cache=cache)


# Generated at 2022-06-25 09:43:20.488438
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    with pytest.raises(AnsibleParserError) as excinfo:
        inventory_module_0.parse("inventory", "loader", "auto", "cache=True")
    assert 'no root \'plugin\' key found, \'auto\' is not a valid YAML' in str(excinfo.value)

# Generated at 2022-06-25 09:43:26.499219
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inven = InventoryModule()
    path = 'path'
    loader = 'loader'
    cache = True
    result = inven.parse('inven', loader, path, cache)
    expected_result = 'loader'
    assert result == expected_result


# Generated at 2022-06-25 09:43:33.177768
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    with pytest.raises(AnsibleParserError) as excinfo:
        inventory_module_0.parse('inventory', 'loader', 'path')
    assert 'no root \'plugin\' key found' in str(excinfo.value)

# Generated at 2022-06-25 09:43:35.141194
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    assert isinstance(inventory_module_0.parse(inventory, loader, path, cache), None)

# Generated at 2022-06-25 09:43:41.555280
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv_mod = InventoryModule()
    test1 = 'test_data/test_auto_inventory'
    test2 = 'test_data/test_auto_inventory.yml'
    test3 = 'test_data/test_auto_inventory.yaml'
    test4 = 'test_data/test_auto_inventory.json'
    test5 = 'test_data/test_auto_inventory_plugin'
    test6 = 'test_data/test_auto_inventory_plugin.yml'
    test7 = 'test_data/test_auto_inventory_plugin.yaml'
    assert(inv_mod.parse(test1) is False)
    assert(inv_mod.parse(test2) is False)
    assert(inv_mod.parse(test3) is False)

# Generated at 2022-06-25 09:44:18.097993
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    inventory_2 = {}
    inventory_module_1._read_config_data = {}
    path_3 = "/etc/ansible/hosts"
    loader_4 = {}
    cache_5 = True

    result = inventory_module_1.parse(inventory_2, loader_4, path_3, cache_5)


# Generated at 2022-06-25 09:44:20.358245
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inv_0 = inventory_module_0.parse("loader_0", "loader_1", "path_0", True)
    assert inv_0 is None


# Generated at 2022-06-25 09:44:23.915929
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    assert(inventory_module_1 != None)


# Generated at 2022-06-25 09:44:27.154227
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    inventory = dict()
    loader = dict()
    path = dict()
    cache = False

    assert inventory_module_0.parse(inventory, loader, path, cache=cache) == None

# Generated at 2022-06-25 09:44:29.913377
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory = object()
    loader = object()
    path = "path"
    cache = True
    inventory_module_1.parse(inventory, loader, path, cache)


# Generated at 2022-06-25 09:44:40.191742
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # create a new instance for InventoryModule
    inventory_module = InventoryModule()

    # create a new loader
    loader = [{'plugin_name':'ec2.py', 'plugin_path':'ec2.py', 'name':'ec2.py', 'module_name':'ec2', 'is_file':True}]

    # create a new inventory
    inventory = ['ec2.py', 'ec2.py']

    # call parse method for class InventoryModule
    try:
        inventory_module.parse(inventory, loader, 'ec2.py', cache=None)
    except AnsibleParserError as err:
        assert err.message == "no root 'plugin' key found, 'ec2.py' is not a valid YAML inventory plugin config file"
    except:
        assert False

    # call parse method for class Inventory

# Generated at 2022-06-25 09:44:41.855949
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.parse() == None

# Generated at 2022-06-25 09:44:44.327906
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.parse(inventory=None, loader=None, path=None, cache=True) is None

# Generated at 2022-06-25 09:44:45.861129
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    assert inventory_module_parse.parse() == None


# Generated at 2022-06-25 09:44:49.648312
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory='inventory', loader='loader', path='path', cache='cache')


# Generated at 2022-06-25 09:46:18.004728
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    config_data_0 = SimpleInventoryModule()
    local_loader_0 = PluginLoader('')
    file_path_0 = 'test_case_0'
    try:
        inventory_module_0.parse('SimpleInventoryModule', local_loader_0, file_path_0, False)
    except AnsibleParserError:
        pass


# Generated at 2022-06-25 09:46:20.474852
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_1 = None
    loader_1 = None
    path_1 = None
    cache_1 = None
    assert \
        InventoryModule.parse(inventory_module_1, inventory_1, loader_1, path_1, cache_1) is None


# Generated at 2022-06-25 09:46:24.000198
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    plugin = "t0"
    inventory = "t1"
    loader = "t2"
    path = "t3"
    try:
        inventory_module_0.parse(inventory, loader, path)
    except AttributeError as e:
        assert True



# Generated at 2022-06-25 09:46:24.347005
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert 1 == 1

# Generated at 2022-06-25 09:46:32.850575
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Stub of inventory_loader.get() return the instance of `InventoryPlugin` class that represent a dummy inventory plugin.
    def get_stub(plugin_name):
        class InventoryPlugin_Stub:
            def verify_file(self, path):
                if path == '/etc/ansible/hosts.yaml':
                    return True
                return False

            def parse(self, inventory, loader, path, cache):
                if path == '/etc/ansible/hosts.yaml':
                    self.called_parse = True

            def assert_called_parse():
                assert self.called_parse

        plugin = InventoryPlugin_Stub()
        return plugin

    inventory_module_1 = InventoryModule()
    inventory_module_1.get_option = lambda _: None

    # Stub Test Case
    inventory_module_1.inventory_

# Generated at 2022-06-25 09:46:37.132808
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Initialize the test inventory module
    mock_inventory = Mock(spec=BaseInventoryPlugin)
    inventory_module_test = InventoryModule()
    inventory_module_test._read_config_data = Mock()
    inventory_module_test._read_config_data.return_value = False
    inventory_module_test.parse(mock_inventory, Mock(), "test/data/test_auto_parse.yaml")


# Generated at 2022-06-25 09:46:38.004934
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()


# Generated at 2022-06-25 09:46:40.217711
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory = dict()
    loader = dict()
    path = 'test/resources/ansible.cfg'
    cache = True
    inventory_module_1.parse(inventory, loader, path, cache)


# Generated at 2022-06-25 09:46:47.202234
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = object()
    loader_0 = object()
    path_0 = 'example.yml'
    cache_0 = False

    # Call method parse of inventory_module_0 with args inventory_0, loader_0, path_0 and kwargs cache_0
    # test error raises AnsibleParserError
    with pytest.raises(AnsibleParserError) as excinfo:
        inventory_module_0.parse(inventory_0, loader_0, path_0, cache=cache_0)
    assert 'AnsibleParserError' in str(excinfo.value)

# Generated at 2022-06-25 09:46:50.037064
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    yaml_file_0 = '/etc/ansible/hosts'
    path_0 = yaml_file_0
    BaseInventoryPlugin_class_0 = BaseInventoryPlugin()
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(BaseInventoryPlugin_class_0, yaml_file_0, path_0)


# Generated at 2022-06-25 09:48:32.689648
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
   # Initialize InventoryModule class
   inventory_module_1 = InventoryModule()

   # Get the value of attribute loader of inventory_module_1
   loader_0 = inventory_loader.get('plugins')

   # Get the value of attribute path of inventory_module_1
   path_0 = 'https://raw.githubusercontent.com/ansible/ansible/c625f8b8c90b7b798d2456c172a1d38cbbef0f0f/test/sanity/inventory_plugin_test/plugin_2.yaml'

   # Get the value of attribute cache of inventory_module_1
   cache_0 = True

   # Execute method parse of class InventoryModule with arguments (inventory, loader, path, cache)
   inventory_module_1.parse(inventory, loader, path, cache)


# Generated at 2022-06-25 09:48:35.015578
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_loader_0 = inventory_loader
    path_0 = path
    cache_0 = cache
    inventory_module_parse(inventory_module_0, str, inventory_loader_0, path_0, cache_0)
    inventory_module_parse(inventory_module_0, str, inventory_loader_0, path_0, cache_0=True)


# Generated at 2022-06-25 09:48:41.646991
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:48:51.827421
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_loader_0 = InventoryLoader()

# Generated at 2022-06-25 09:49:02.633165
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:49:10.092206
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    InventoryModule()
    inventory = arg_0
    loader = arg_1
    path = arg_2
    cache = True
    var_1 = InventoryModule.parse(inventory, loader, path, cache)
    output_0 = var_1
    assert output_0 == 0


# Generated at 2022-06-25 09:49:14.938285
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    var_1 = ''
    loader = Loader()
    var_2 = False
    path = '/Users/mattdavis/projects/ansible/test/units/mock/inventory/auto_inventory_plugin/auto_inventory_plugin.yml'
    var_3 = True
    var_4 = inventory_parser(var_1, var_2, var_3)


# Generated at 2022-06-25 09:49:20.980481
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:49:21.780033
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:49:23.926282
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_parse_0 = inventory_module_0.parse(cache=True)
    assert inventory_module_parse_0 == 'The method parse() of class InventoryModule is tested!'
    assert inventory_module_0.test_output == 'The method parse() of class InventoryModule is tested!'
