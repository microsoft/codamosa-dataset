

# Generated at 2022-06-25 09:40:33.811032
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse()


# Generated at 2022-06-25 09:40:41.236140
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()

    # Test with different file extention.
    assert inventory_module.verify_file('/root/ansible.yml') == True
    assert inventory_module.verify_file('/root/ansible.yaml') == True
    assert inventory_module.verify_file('/root/ansible.txt') == False


# Generated at 2022-06-25 09:40:45.921278
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = object()
    loader = object()
    path = 'path_value'
    cache = True
    unit = InventoryModule()
    unit.parse(inventory, loader, path, cache)
    assert len(unit.parse_results) == 0


# Generated at 2022-06-25 09:40:52.201942
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = inventory_module_0.inventory

    loader_0 = inventory_module_0.loader
    path = "kiwi"
    cache = True
    try:
        inventory_module_0.parse(inventory_0, loader_0, path, cache)
    except AnsibleParserError as exception_0:
        print(exception_0)
    except Exception as exception_0:
        print(exception_0)


# Generated at 2022-06-25 09:40:59.225588
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()

    # verify_file is a public method. Let's actually call it and
    # assert that it works with a variety of inputs
    #
    # expected result is a boolean indicating success, failure, or
    # that the plugin in question should be skipped (i.e. return
    # None)
    #
    # Actual: verify_file(path)
    # Expected: result

# Generated at 2022-06-25 09:41:01.703331
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = object()
    loader_0 = object()
    path_0 = object()
    inventory_module_0.parse(inventory_0, loader_0, path_0)

# Generated at 2022-06-25 09:41:05.062250
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_1 = None
    loader_1 = None
    path_1 = None
    cache_1 = True

    inventory_module_1.parse(inventory_1, loader_1, path_1, cache_1)


# Generated at 2022-06-25 09:41:08.237060
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_0 = InventoryModule()
    loader_0 = mock.MagicMock()
    path_0 = ""
    cache_0 = True
    inventory_module_0.parse(loader_0, path_0, cache_0)


# Generated at 2022-06-25 09:41:11.845849
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('') == False
    assert inventory_module.verify_file('.yaml') == True
    assert inventory_module.verify_file('.yml') == True
    assert inventory_module.verify_file('.yaml.j2') == False


# Generated at 2022-06-25 09:41:15.040982
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:41:25.457751
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_data = None
    loader_data = None
    path_data = None
    cache_data = None
    inventory_module_1.parse(inventory_data, loader_data, path_data, cache_data)


# Generated at 2022-06-25 09:41:29.534011
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    assert module.parse("inventory", "loader", "path", cache=False) is None


# Generated at 2022-06-25 09:41:30.415626
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    # Test with non-existent plugin name
    # Test with successful parse
    # Test with Error



# Generated at 2022-06-25 09:41:33.182405
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.inventory import BaseInventoryPlugin
    print('Invoking parse of class InventoryModule')
    inventory_module_0 = InventoryModule()
    inventory = []
    loader = None
    path = ''
    cache = True
    inventory_module_0.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:41:35.729233
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = []
    loader = []
    path = []
    cache = False
    inventory_module_0 = InventoryModule()
    try:
        inventory_module_0.parse(inventory, loader, path, cache)
    except Exception as e:
        print("Error caught : {}".format(e))


# Generated at 2022-06-25 09:41:36.495726
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.parse()

# Generated at 2022-06-25 09:41:40.162670
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    loader_2 = unittest.mock.create_autospec(Loader)
    inventory_3 = unittest.mock.create_autospec(BaseInventoryPlugin)
    path_4 = "path/to/fake_file"
    cache_5 = True

    config_data_6 = loader_2.load_from_file.return_value
    plugin_name_7 = config_data_6.get.return_value
    plugin_8 = inventory_loader.get.return_value
    plugin_9 = plugin_8.verify_file.return_value
    plugin_8.parse.return_value = None
    plugin_8.update_cache_if_changed.return_value = None


# Generated at 2022-06-25 09:41:43.216932
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.parse() == None

# Generated at 2022-06-25 09:41:44.225390
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryModule()
    inventory.parse()

# Generated at 2022-06-25 09:41:45.720527
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    assert inventory_module.parse() is None

# Generated at 2022-06-25 09:41:54.343595
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    to_check = InventoryModule()
    assert to_check.parse

# Generated at 2022-06-25 09:41:55.858025
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_case_0()


# Generated at 2022-06-25 09:41:57.862507
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    # Arguments testing
    loader = None
    path = None
    inventory = None
    cache = True

    inventory_module_0.parse(inventory, loader, path, cache)


# Generated at 2022-06-25 09:42:00.221348
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    assert inventory_module_parse


# Generated at 2022-06-25 09:42:04.184279
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_loader_0 = inventory_loader
    inventory_module_0.parse(inventory_module_0, inventory_loader_0, 'inventory_source', True)


# Generated at 2022-06-25 09:42:11.304743
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    loader_obj_1 = ansible.plugins.loader.all.Loader()

    from ansible.plugins.inventory import InventoryDirectory
    inventory_obj_1 = InventoryDirectory(loader_obj_1)

    from tests.unit.mock.loader import DictDataLoader
    loader_obj_2 = DictDataLoader({'/etc/ansible/hosts': """
plugin: yaml_inventory
""", '/etc/ansible/project.yml': """
plugin: project
"""})
    inventory_module_1.parse(inventory_obj_1, loader_obj_2, '/etc/ansible/hosts')
    assert_equals(inventory_obj_1._restriction, '[u"all"]')

    inventory_module_2 = InventoryModule()

# Generated at 2022-06-25 09:42:13.668150
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_mock = Mock()
    loader_mock = Mock()
    inventory_module.parse(inventory_mock, loader_mock, '/path/to/file')
    loader_mock.load_from_file.assert_called_once_with('/path/to/file', cache=False)


# Generated at 2022-06-25 09:42:15.296804
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory=None, loader=None, path=None, cache=True)

# Generated at 2022-06-25 09:42:21.805246
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = None
    loader = None
    path = 'test/fixtures/test_auto.yaml'
    expected_hosts = ['foo', 'bar', 'baz', 'qux']
    plugin = inventory_loader.get('test')
    # plugin.parse(inventory, loader, path, cache=cache)
    assert plugin.parse(inventory, loader, path, cache=cache)._hosts == expected_hosts

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 09:42:26.015692
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    # inventory is the group name and group var
    # loader is the path to the file
    # path is the file name we want to parse
    # cache if we want to cache the file
    inventory_module_1.parse("inventory", "loader", "path", "cache")

# Generated at 2022-06-25 09:42:46.247103
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_0 = InventoryModule()
    loader = 'Loader'
    path = 'test_value'
    assert inventory_module_0.parse('inventory', loader, path, cache='cache') is None


# Generated at 2022-06-25 09:42:49.174198
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse_0 = InventoryModule()


# Generated at 2022-06-25 09:42:50.738470
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    module_return = inventory_module_1.parse()

    assert module_return is None

# Generated at 2022-06-25 09:42:55.237024
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory = {}
    loader = {}
    path = 'abc'
    inventory_module_1.parse(inventory, loader, path)



# Generated at 2022-06-25 09:42:58.655329
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_path = "inventory_file"
    inventory = {
        "hosts" : [],
        "vars" : {},
        "children" : []
    }
    loader = {}
    cache = True
    inventory_module = InventoryModule()
    assert inventory_module.parse(inventory, loader, inventory_path, cache) == None

# Generated at 2022-06-25 09:43:01.114656
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Testing with a valid yml file
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse("inventory", "loader", "sample.yml")


# Generated at 2022-06-25 09:43:05.184789
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    try:
        assert True
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-25 09:43:07.787061
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse({}, {}, {})


# Generated at 2022-06-25 09:43:10.059170
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory = {}
    config_data = {'plugin': 'freepath_inventory'}
    loader = inventory_loader.get('yaml')
    path = './test/test_plugin_auto/test_case_0.yaml'
    inventory_module_0.parse(inventory, loader, path)

# Generated at 2022-06-25 09:43:10.993883
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    path = 'test_data.yml'
    assert not InventoryModule().parse('inventory', 'loader', path, True)

# Generated at 2022-06-25 09:43:28.313476
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'nI`;CoMt<\r'
    inventory_0 = InventoryModule(str_0)
    assert inventory_0.some_property == 'some value'

# Generated at 2022-06-25 09:43:31.092443
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    try:
        inventory_module_3 = inventory_module_0.parse({}, {}, {}, {}, {}, {}, {})
    except:
        inventory_module_0.parse({}, {}, {}, {}, {}, {}, {}, {})

# Generated at 2022-06-25 09:43:33.762190
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = '\n}V9oHfr8}>vzR\x0b'
    inventory_module_0 = InventoryModule()
    var_0 = parse_of_inventory(str_0)


# Generated at 2022-06-25 09:43:40.943138
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    str_0 = '\n}V9oHfr8}>vzR\x0b'

# Generated at 2022-06-25 09:43:52.331949
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    obj_0 = InventoryModule()
    obj_1 = InventoryModule()
    obj_2 = InventoryModule()
    obj_3 = InventoryModule()
    obj_4 = InventoryModule()
    obj_5 = InventoryModule()
    obj_6 = InventoryModule()
    obj_7 = InventoryModule()
    obj_8 = InventoryModule()
    obj_9 = InventoryModule()
    obj_10 = InventoryModule()
    obj_11 = InventoryModule()
    obj_12 = InventoryModule()
    obj_13 = InventoryModule()
    obj_14 = InventoryModule()
    obj_15 = InventoryModule()
    obj_16 = InventoryModule()
    obj_17 = InventoryModule()
    obj_18 = InventoryModule()
    obj_19 = InventoryModule()
    obj_20 = InventoryModule()
    obj_21 = InventoryModule()
   

# Generated at 2022-06-25 09:43:55.056467
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = '/etc/ansible/hosts'
    inventory_module_0 = InventoryModule()
    out_0 = inventory_module_0.parse(str_0)


# Generated at 2022-06-25 09:44:01.587251
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = '\n}V9oHfr8}>vzR\x0b'
    str_1 = '?&6~YU\x0c'
    str_2 = '\x0b\x0c\x0e\x0e'
    inventory_module_0 = InventoryModule()
    var_0 = inventory_module_0.parse(str_0, str_1, str_2, True)
    


# Generated at 2022-06-25 09:44:08.908113
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    str_0 = '4\x1e'
    loader_0 = 'ec2'
    path_0 = '\x0c'
    inventory_module_1.parse(str_0, loader_0, path_0)
    str_0 = 'UpV\x07'
    loader_0 = '#w\x0c'
    path_0 = '\x0c'
    inventory_module_1.parse(str_0, loader_0, path_0)


# Generated at 2022-06-25 09:44:14.536374
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    loader_0 = 'plugin_name'
    path_0 = '}o\\^)Ej\\[L'
    verify_that(inventory_module_0.parse(loader_0, path_0)).is_equal_to(0)


# Generated at 2022-06-25 09:44:20.416238
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    config_data_0 = {
        'plugin': 'gce'
    }
    # 1. Declare inventory as an instance of class 'BaseInventoryPlugin'.
    inventory = BaseInventoryPlugin()
    # 2. Declare inventory_module_0 as an instance of class 'InventoryModule'.
    inventory_module_0 = InventoryModule()
    # 3. Create a list named 'path_0' by assigning the value of __file__ to the local variable.
    path_0 = __file__
    # 4. Call method 'parse' of 'inventory_module_0' with parameters config_data_0, inventory, __loader__, path_0, True.
    inventory_module_0.parse(config_data_0, inventory, __loader__, path_0, True)
    # 2. Call method 'parse' of 'inventory_module_

# Generated at 2022-06-25 09:44:57.162636
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Declare varibales for test_InventoryModule_parse
    InventoryModule.parse()
    inventory = {}
    loader = {}
    path = ''
    cache = True
    
    # Call method of InventoryModule class
    InventoryModule.parse(inventory, loader, path, cache=True)
    var_expect = None
    var_actual = None

    # Fail test case if the two variables are not equal
    assert var_actual == var_expect


# Generated at 2022-06-25 09:44:59.101264
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = '\x0c'
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.parse(str_0) != "str_0"


# Generated at 2022-06-25 09:45:10.315980
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'tD4QOn{z\x0bIaL8'
    inventory_module_0 = InventoryModule()
    if inventory_loader.get(str_0):
        var_0 = inventory_loader.get(str_0)
        var_1 = inventory_loader.get(str_0)
        var_2 = inventory_loader.get(str_0)
        var_3 = inventory_loader.get(str_0)
        var_4 = inventory_loader.get(str_0)
        var_5 = inventory_loader.get(str_0)
        var_6 = inventory_loader.get(str_0)
        var_7 = inventory_loader.get(str_0)
        var_8 = inventory_loader.get(str_0)
        var_9 = inventory_loader

# Generated at 2022-06-25 09:45:19.497346
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'test/test.yaml'
    dict_0 = {'some_key': 'some_value'}
    instance_0 = InventoryModule()
    instance_0.parse(dict_0, str_0)

    # Verify parse method call on class InventoryModule
    dict_1 = {'some_key': 'some_value'}
    str_1 = 'test/test.yaml'
    instance_1 = InventoryModule()
    instance_1.parse(dict_1, str_1)
    assert dict_1 == dict_1


# Generated at 2022-06-25 09:45:20.833248
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    oc = InventoryModule()
    assert oc.verify_file('example.config')
    return 0

# Generated at 2022-06-25 09:45:27.677331
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = '\n}V9oHfr8}>vzR\x0b'
    inventory_module_0 = InventoryModule()
    var_0 = inventory_module_0.parse(str_0)


# Generated at 2022-06-25 09:45:35.965863
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_1 = '\n}V9oHfr8}>vzR\x0b'
    inventory_module_1 = InventoryModule()
    var_0 = {}
    var_1 = {}
    var_2 = {}
    var_2 = {'hosts': 'localhost'}
    var_0 = inventory_module_1.parse(var_1, var_2)
    var_3 = 'localhost'
    var_4 = var_0.get(var_3)
    assert var_4 == {'hosts': 'localhost'}
    str_2 = 'localhost'
    var_5 = inventory_module_1.hosts(str_2)
    assert var_5 == ['localhost']
    var_6 = {}
    var_7 = {}
    var_8 = {}
    var_8

# Generated at 2022-06-25 09:45:37.613117
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Call method
    InventoryModule.parse()


# Generated at 2022-06-25 09:45:40.162358
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = '\n}V9oHfr8}>vzR\x0b'
    inventory_module_0 = InventoryModule()
    inventory_module_parse(str_0)

# Generated at 2022-06-25 09:45:48.430617
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_loader_0 = InventoryLoader()
    inventory_host_0 = InventoryHost()
    inventory_host_1 = InventoryHost()
    inventory_0 = BaseInventory()
    str_0 = '\r6lIfF*z8_E^'
    str_1 = '<TG"T"1\x0c'
    str_2 = '\x0c;wA1x\x0c(\n\x0b'

    inventory_module_0.parse(inventory_0, inventory_loader_0, str_0)

    inventory_loader_0.get_basedir(inventory_host_0)
    inventory_loader_0.get_basedir(inventory_host_1)


# Generated at 2022-06-25 09:47:12.330848
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = '\n}V9oHfr8}>vzR\x0b'
    inventory_module_0 = InventoryModule()
    var_0 = inventory_verify_file(str_0)

# Generated at 2022-06-25 09:47:14.242789
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_verify_file('')


# Generated at 2022-06-25 09:47:16.445083
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test exception raise
    str_0 = '\n}V9oHfr8}>vzR\x0b'
    inventory_module_0 = InventoryModule()
    var_0 = inventory_module_0.parse(str_0)


# Generated at 2022-06-25 09:47:19.229021
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    int_0 = 0
    loader_0 = 0
    str_0 = '\n}V9oHfr8}>vzR\x0b'
    bool_0 = False
    inventory_module_0.parse(int_0, loader_0, str_0, bool_0)



# Generated at 2022-06-25 09:47:25.811292
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    path_0 = 'Z1\x0c_|\x0b'
    loader_0 = '5j5'
    inventory_module_0 = InventoryModule()
    inventory_0 = object()
    module_parse(inventory_0, loader_0, path_0)


# Generated at 2022-06-25 09:47:31.911530
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = '\n}V9oHfr8}>vzR\x0b'
    inventory_module_0 = InventoryModule()
    var_1 = inventory_module_0.parse(str_0)



# Generated at 2022-06-25 09:47:34.565838
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(str_0, loader, str_1, cache=True)

# Generated at 2022-06-25 09:47:37.635416
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'r8p|AoIb>R<v\\'
    str_1 = 'Cz1:\n'
    str_2 = 'Ef|Ll>R'
    str_3 = 'G:GA'
    inventory_module_0 = InventoryModule()
    var_0 = inventory_module_verify_file(str_0)
    var_1 = inventory_module_parse(inventory_module_0, str_1, str_2, str_3)


# Generated at 2022-06-25 09:47:40.045716
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'pip install'
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(str_0)


# Generated at 2022-06-25 09:47:42.639765
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert True
