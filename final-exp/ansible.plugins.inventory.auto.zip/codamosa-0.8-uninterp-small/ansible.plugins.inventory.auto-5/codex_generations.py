

# Generated at 2022-06-25 09:40:43.452164
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    # Validate test case 0
    test_path_0 = '/var/lib/awx/venv/awx/lib/python2.7/site-packages/ansible/plugins/inventory/ini.py'
    inventory_module_0.parser = None
    inventory_module_0.loader = None
    test_case_0_verify_file = inventory_module_0.verify_file(test_path_0)
    assert(test_case_0_verify_file)

    # Validate test case 1
    test_path_1 = '/var/lib/awx/venv/awx/lib/python2.7/site-packages/ansible/plugins/inventory/ini.py'
    inventory_module_0.parser = None
    inventory_module_0

# Generated at 2022-06-25 09:40:54.735225
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()

    # Test with a path value that ends with '.yml'
    if not inventory_module_0.verify_file("/foo/bar/test.yml"):
        raise AssertionError("verify_file is not returning correct value")

    # Test with a path value that ends with '.yaml'
    if not inventory_module_0.verify_file("/foo/bar/test.yaml"):
        raise AssertionError("verify_file is not returning correct value")

    # Test with a path value that doesn't end with either 'yml' or 'yaml'
    if inventory_module_0.verify_file("/foo/bar/test.txt"):
        raise AssertionError("verify_file is not returning correct value")

# Generated at 2022-06-25 09:40:59.632306
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    loader = dict()
    path = dict()
    cache = dict()

    inventory_module_1 = InventoryModule()
    with pytest.raises(AnsibleParserError) as excinfo:
        inventory_module_1.parse(inventory, loader, path, cache=True)
    assert "no root 'plugin' key found" in str(excinfo)


# Generated at 2022-06-25 09:41:07.093143
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create an instance of the InventoryModule class
    inventory_module_1 = InventoryModule()

    # Create an instance of the BaseInventoryPlugin class
    base_inventory_plugin_1 = BaseInventoryPlugin()

    # Try to parse an inventory file with InventoryModule
    try:
        inventory_module_1.parse(base_inventory_plugin_1, None, None)
    except AnsibleParserError as e:
        assert "unknown plugin" in str(e)
        assert "is not a valid YAML inventory plugin config file" in str(e)
    else:
        assert False, "AnsibleParserError not raised"


# Generated at 2022-06-25 09:41:12.520586
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule().verify_file("") == False
    assert InventoryModule().verify_file("plu") == False
    assert InventoryModule().verify_file("plug") == False
    assert InventoryModule().verify_file("plugin") == False
    assert InventoryModule().verify_file("plugin.y") == False
    assert InventoryModule().verify_file("plugin.yml") == True
    assert InventoryModule().verify_file("plugin.yaml") == True
    assert InventoryModule().verify_file("plugin.ym") == False

# Generated at 2022-06-25 09:41:17.279062
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = [{'hosts': ['127.0.0.1'], 'name': 'a_group'}]
    loader = object()
    path = 'path.yml'
    cache = False
    test_object = InventoryModule()
    # Call method
    try:
        test_object.parse(inventory, loader, path, cache)
    except Exception as e:
        print('Exception raised: {0}'.format(e))
    else:
        print('Test passed')

# Generated at 2022-06-25 09:41:22.399057
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    assert(inventory_module_1.verify_file('test_file_0.yml')) == False
    assert(inventory_module_1.verify_file('test_file_0.yaml')) == False
    assert(inventory_module_1.verify_file('test_file_0')) == False
    assert(inventory_module_1.verify_file('test_file_1.yml')) == False
    assert(inventory_module_1.verify_file('test_file_1.yaml')) == False
    assert(inventory_module_1.verify_file('test_file_1')) == False

# Generated at 2022-06-25 09:41:24.551055
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.verify_file('sample.yml')


# Generated at 2022-06-25 09:41:32.624338
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    parser_0 = Mock(**{"parse.return_value": None})
    os_0 = Mock(**{"path.exists.return_value": False})

    inventory_module_0.loader = parser_0
    inventory_module_0.parse(inventory=os_0, loader=parser_0, path="/etc/ansible/hosts", cache=True)

# Generated at 2022-06-25 09:41:36.664205
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.name = None
    inventory_module_0.options = None
    inventory_module_0.basedir = None
    inventory_module_0.vars = None
    inventory_module_0.loader = None
    inventory_module_0.groups = None
    inventory_module_0.hosts = None
    inventory_module_0.settings = None

    assert(inventory_module_0.parse('inventory', 'loader', 'path', cache=True) == None)


# Generated at 2022-06-25 09:41:48.167264
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
  path = "test_path"
  # Create an instance of inventory
  inventory = mock_class('inventory')
  # Create an instance of loader
  loader = mock_class('loader')
  # Create an instance of cache
  cache = True
  # Create an instance of InventoryModule
  inventory_module = InventoryModule()
  # Parse the inventory
  inventory_module.parse(inventory, loader, path, cache)
  

# Generated at 2022-06-25 09:41:50.769723
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:41:57.192915
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()

    inventory_0 = {'hosts': ['host_0'], 'vars': {'var_0': 'host_var_0'}, 'children': {'child_0': {'hosts': ['host_1'], 'children': {'grandchild_0': {'hosts': ['host_2']}}}}}

    loader_0 = inventory_loader
    path_0 = 'test_0.yml'
    cache_0 = False
    assert inventory_module.parse(inventory_0, loader_0, path_0, cache_0)


# Generated at 2022-06-25 09:42:01.360736
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_1 = InventoryModule()

    inventory_module_0.parse(inventory_module_0, inventory_module_1, 'test_path')

# Generated at 2022-06-25 09:42:04.145625
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.parse(None, None, None, None) == None
    assert inventory_module_0.parse(None, None, '', None) == None
    assert inventory_module_0.parse(None, None, 'f2gfo/k/j', None) == None
    assert inventory_module_0.parse(None, None, '', False) == None
    assert inventory_module_0.parse(None, None, 'd0gvb/o,', False) == None

# Generated at 2022-06-25 09:42:05.503800
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:42:10.376035
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Creating object of class InventoryModule
    inventory_module = InventoryModule()
    # Creating object of class InventoryPlugin
    inventory = InventoryPlugin()
    # Creating object of class DataLoader
    loader = DataLoader()
    # Creating object of class Play
    play = Play()
    # Creating object of class Task
    task = Task()
    # Creating object of class PlayContext
    play_context = PlayContext()
    # Creating object of class PlaybookExecutor
    playbook_executor = PlaybookExecutor()
    # Creating list
    variable_manager_list = []
    variable_manager = VariableManager()
    variable_manager_list.append(variable_manager)
    # Creating object of class Play
    play_0 = Play()
    # Creating object of class Task
    task_0 = Task()
    # Creating object of class PlayContext
    play

# Generated at 2022-06-25 09:42:20.827344
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    # Test the case where plugin is not specified in config
    with pytest.raises(AnsibleParserError) as e:
        inventory_module_1.parse(inventory, loader, path)
    assert str(e.value) == "no root 'plugin' key found, '' is not a valid YAML inventory plugin config file"
    # Test the case where plugin specified in config is not found
    inventory_module_1 = InventoryModule()
    with pytest.raises(AnsibleParserError) as e:
        inventory_module_1.plugin = "plugin"
        inventory_module_1.parse(inventory, loader, path)
    assert str(e.value) == "inventory config '' specifies unknown plugin ''"
    # Test the case where verify_file method fails
    inventory_module_1

# Generated at 2022-06-25 09:42:23.899584
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory, loader, path, cache = {}, {}, {}, {}
    inventory_module_1.parse(inventory, loader, path, cache)



# Generated at 2022-06-25 09:42:26.367466
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory = None
    loader = None
    path = None
    cache = None
    inventory_module_0.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:42:40.715760
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory = "inventory"
    loader = "loader"
    path = "path"
    cache = True
    inventory_module_0.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:42:47.124637
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0_test_parse = InventoryModule()
    assert inventory_module_0_test_parse.parse(inventory_module_0_test_parse.parse(),inventory_module_0_test_parse.parse(),inventory_module_0_test_parse.parse(),inventory_module_0_test_parse.parse()) != None

# Generated at 2022-06-25 09:42:50.051742
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    mocked_inventory = "inventory"
    mocked_loader = "loader"
    path = "path"
    cache = "cache"
    inventory_module.parse(mocked_inventory, mocked_loader, path, cache)
    return

# Generated at 2022-06-25 09:42:54.965949
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.parse(inventory=None, loader=None, path=None, cache=None) == None

# Generated at 2022-06-25 09:42:58.926339
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    path_1 = "test_file_name.yml"
    path_1_expect = "test_file_name.yml"
    loader_1 = None
    inventory_1 = None
    cache_1 = None
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory_1, loader_1, path_1, cache_1)


# Generated at 2022-06-25 09:43:01.385958
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    assert not inventory_module.parse('inventory', 'loader', 'path', 'cache')

# Generated at 2022-06-25 09:43:07.053143
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    config_data_2 = dict()
    loader_3 = dict()
    path_4 = 'inventory_1'
    cache_5 = True
    inventory_module_1.parse(config_data_2, loader_3, path_4, cache_5)


# Generated at 2022-06-25 09:43:09.448814
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse()

# Generated at 2022-06-25 09:43:13.677436
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    path = 'ansible/test/test_inventory_auto.yml'
    inventory_module_0 = InventoryModule()
    inventory = dict()
    loader = dict()
    cache = True
    inventory_module_0.parse(inventory,loader,path,cache)

# Generated at 2022-06-25 09:43:21.075094
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = AnsibleInventory(host_list=[], groups={})
    loader_0 = DataLoader()
    path_0 = 'inventory'
    cache_0 = True
    expected_result_0 = None
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache=cache_0)



# Generated at 2022-06-25 09:43:42.752002
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = {}
    loader = 'st'
    path = 'xy'
    cache = 'false'
    inventory_module_1 = InventoryModule()
    result_should_be = {}
    result = inventory_module_1.parse(inventory, loader, path, cache)
    assert result == result_should_be


# Generated at 2022-06-25 09:43:45.386117
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse('test_value_2', 'test_value_3', 'test_value_4')

# Generated at 2022-06-25 09:43:47.097472
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:43:57.150636
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    host_to_add_0 = 'test_inventory_test_host'
    group_name_0 = 'test_inventory_test_group'
    inventory_module_0 = InventoryModule()
    loader_0 = MockInventoryLoader()
    inventory_module_0.parse(MockInventory(), loader_0, 'test_inventory_file_0')
    test_inventory_group_0 = MockInventoryGroup(group_name_0)
    test_inventory_host_0 = MockInventoryHost(host_to_add_0)
    test_inventory_group_0.add_host(test_inventory_host_0)
    test_inventory_group_0.set_variable('test_inventory_var_name_0','test_inventory_var_value_0')

# Generated at 2022-06-25 09:44:01.643124
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    test_var_1 = inventory_module_1.parse(inventory_module_1, inventory_module_1, inventory_module_1, cache=True)
    test_var_1 = inventory_module_1.parse(inventory_module_1, inventory_module_1, inventory_module_1, cache=True)
    test_var_1 = inventory_module_1.parse(inventory_module_1, inventory_module_1, inventory_module_1, cache=True)


# Generated at 2022-06-25 09:44:10.724776
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # This is a generated test case - to be refined later.
    import os
    import tempfile
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # Set up test infrastructure
    host_0 = Host(name="compute-0-0")
    group_0 = Group(name="group_name")
    group_0.add_host(host_0)
    fake_loader_0 = "fake loader"
    # Store original environment
    oldenv = os.environ.copy()
    oldcwd = os.getcwd()
    tempdir, config_file = tempfile.mkstemp()
    os.chdir(tempdir)

    # Invoke method
    inventory_module_0 = InventoryModule()

# Generated at 2022-06-25 09:44:13.687672
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    test_case_1 = inventory_module_1.parse(None, None, 'test_case_1', True)


# Generated at 2022-06-25 09:44:18.681657
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    loader = inventory_loader
    path = "./tests/units/inventory/auto/inventory_file.yml"
    assert inventory_module.parse(inventory_module, loader, path) is None


# Generated at 2022-06-25 09:44:21.330078
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    # Test expectations
    inventory = None
    loader = None
    path = None
    expected_result = None
    result = inventory_module_0.parse(inventory, loader, path)
    assert result == expected_result

# Generated at 2022-06-25 09:44:30.622020
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = None
    loader_0 = None
    path_0 = "./ansible_collections/ansible/builtin/plugins/inventory/auto.py"
    cache_0 = None
    try:
        inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)
    except AnsibleParserError as e:
        assert "no root 'plugin' key found, './ansible_collections/ansible/builtin/plugins/inventory/auto.py' is not a valid YAML inventory plugin config file" in str(e)
    except NotImplementedError as e:
        assert "parse method is not implemented in this plugin" in str(e)


# Generated at 2022-06-25 09:45:12.056436
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    # Insert your test code here
    assert 'No test code found' == 'Fix this'
    # Parse 'test/test_auto_inventory.yml'
    data_tree_4 = {'plugin': 'auto', 'hosts': ['a', 'b']}
    inventory_module_1.parse(data_tree_4)
    assert 'No test code found' == 'Fix this'
    # Parse 'test/test_vars_inventory.yml'
    data_tree_5 = {'plugin': 'auto', 'hosts': ['a', 'b']}
    inventory_module_1.parse(data_tree_5)
    assert 'No test code found' == 'Fix this'
    # Parse 'test/test_children_inventory.yml'
    data

# Generated at 2022-06-25 09:45:20.853247
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Create a new instance of class InventoryModule.
    inventory_module = InventoryModule()

    # Create a new instance of class Inventory.
    inventory = Inventory()

    # Create a new instance of class PluginLoader.
    loader = PluginLoader()

    # Create a dummy path.
    path = 'path'

    # Create a new instance of class Cache.
    cache = Cache()

    # Test execution of method parse with arguments inventory, loader, path, cache = cache.
    inventory_module.parse(inventory, loader, path, cache = cache)

    # Assert that file 'path' was opened.
    open.assert_called_with('path', 'rb')

    # Assert that file 'path' was closed.
    open.return_value.close.assert_called()

# Generated at 2022-06-25 09:45:30.957535
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """
    Test InventoryModule.parse
    """
    inventory_module = InventoryModule()
    inventory_loader = Loader()
    path = '/home/ansible/test/test_inventory_modules/test_folder/test.yml'
    inventory = HostInventory()

    inventory_module.parse(inventory, inventory_loader, path)

    # Check if the hosts have been added to the GroupAll
    hosts = [host for host in inventory.get_hosts()]
    assert hosts == [Host(name='host_0'), Host(name='host_1'), Host(name='host_2')]

    # Check if the variables have been added to the hosts
    host_0 = inventory.get_host('host_0')
    host_1 = inventory.get_host('host_1')
    host_2 = inventory.get_host

# Generated at 2022-06-25 09:45:39.895812
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    loader = DictDataLoader({
        'inventory.yaml': dedent("""
            ---
            plugin: azure_rm
            hostname: '{{ inventory_hostname }}'
            location: westus
            subscription_id: 1234abcd-12ab-34cd-56ef-1234567890ab
            tenant_id: 1234abcd-12ab-34cd-56ef-1234567890ab
            client_id: 1234abcd-12ab-34cd-56ef-1234567890ab
            secret: qwertyuiopasdfghjklzxcvbnmqwertyuio
            """)
    })
    mock_inventory = MagicMock()
    inventory_module_0 = InventoryModule()

# Generated at 2022-06-25 09:45:41.640157
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    # inventory_module_1.parse(inventory, loader, path, cache=True)

# Generated at 2022-06-25 09:45:43.920501
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    path='SampleInventory.yml'
    inventory = None
    loader = None
    cache = False

    inventory_module_obj = InventoryModule()
    inventory_module_obj.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:45:46.812580
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert False is inventory_module_0.verify_file(path_0)
    with pytest.raises(AnsibleParserError):
        inventory_module_0.parse(inventory_0, loader_0, path_0)


# Generated at 2022-06-25 09:45:47.762659
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    pass


# Generated at 2022-06-25 09:45:50.973590
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_0 = [ None ]
    loader_0 = [ None ]
    path_0 = './ansible/test/utils/test_data/inventory.yml'
    inventory_module_1.parse(inventory_0, loader_0, path_0)


# Generated at 2022-06-25 09:45:52.876112
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_0 = InventoryModule()
    inventory_module_0.parse('test_inventory_module_parse', 'loader', 'path', None)

# Generated at 2022-06-25 09:46:36.594309
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    pass


# Generated at 2022-06-25 09:46:38.157051
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    try:
        float_0 = 1.0
        inventory_module_0 = InventoryModule()
        var_0 = inventory_parse(float_0)
    except AnsibleParserError:
        raise


# Generated at 2022-06-25 09:46:39.338748
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    float_0 = 60.0
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(float_0)


# Generated at 2022-06-25 09:46:43.754295
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    temp = InventoryModule()
    assert temp.parse(loader) == None


# Generated at 2022-06-25 09:46:45.240620
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse()


# Generated at 2022-06-25 09:46:49.452043
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_1 = InventoryModule()

    inventory_module_0.parse(inventory_module_1)


# Generated at 2022-06-25 09:46:52.572402
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_case_0()

# Generated at 2022-06-25 09:46:53.268733
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    pass


# Generated at 2022-06-25 09:46:59.116591
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    float_0 = 60.0
    inventory_module_0 = InventoryModule()
    var_0 = inventory_module_0.parse(float_0)
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 09:47:07.685978
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:48:44.277044
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    float_0 = 60.0
    inventory_module_0 = InventoryModule()
    var_0 = inventory_module_0.parse(float_0)


# Generated at 2022-06-25 09:48:46.479326
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    #AnsibleParserError()
    parse(inventory, loader, path, cache=True)
    #
    #
    #


# Generated at 2022-06-25 09:48:51.677982
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.inventory import InventoryFile
    inventory_module_1 = InventoryModule()
    inventory_file_0 = InventoryFile()
    inventory_module_1.parse(inventory_file_0, inventory_module_1, '/private/tmp/ansible_config/etc/ansible/hosts')


if __name__ == '__main__':
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 09:48:56.804644
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory, loader, )


# Generated at 2022-06-25 09:48:58.232346
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    float_0 = 2.1
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(float_0)


# Generated at 2022-06-25 09:49:03.941472
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    str_0 = 'test'
    inventory_module_0 = InventoryModule()
    host_list_0 = HostList()
    data_loader_0 = DataLoader()
    inventory_module_1 = inventory_module_0.parse(host_list_0, data_loader_0, str_0)

# Generated at 2022-06-25 09:49:08.424984
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    float_0 = 60.0
    inventory_module_0 = InventoryModule()
    var_0 = inventory_module_parse(float_0)


# Generated at 2022-06-25 09:49:15.043145
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = Inventory()
    loader = PluginLoader()
    data = {
        "plugin": "script",
        "script": "/usr/share/ansible/inventory/demo"
    }
    path = "/tmp/inventory.yaml"
    with open(path, "w") as f:
        f.write(dumps(data, indent=4))
    inventory_module.parse(inventory, loader, path)

if __name__ == '__main__':
    func_0()

# Generated at 2022-06-25 09:49:16.626273
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    float_0 = 30.0
    inventory_module_0 = InventoryModule()
    inventory_module_parse(float_0)


# Generated at 2022-06-25 09:49:17.528492
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse()
