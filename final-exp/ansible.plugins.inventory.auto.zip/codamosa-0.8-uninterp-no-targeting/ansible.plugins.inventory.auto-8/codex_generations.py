

# Generated at 2022-06-21 05:01:19.121251
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file("test.yaml") is True
    assert inventory_module.verify_file("test.yml") is True
    assert inventory_module.verify_file("test.txt") is False

# Generated at 2022-06-21 05:01:26.107074
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    im = InventoryModule()
    # plugin will return false if it's the wrong file type
    assert not im.verify_file("not-a-yml")
    # plugin will return false if the plugin is able to verify the file is not a valid file
    assert not im.verify_file("invalid")
    # plugin will return true if it's a valid yml file
    assert im.verify_file("valid.yml")
    # plugin will return true if it's a valid yaml file
    assert im.verify_file("valid.yaml")

# Generated at 2022-06-21 05:01:27.613389
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    path = '/tmp/test.yml'
    cache=True
    inventory_module = InventoryModule()
    assert inventory_module.verify_file(path) is False


# Generated at 2022-06-21 05:01:30.820090
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule.update_cache_if_changed() == None
    assert InventoryModule.verify_file() == False
    assert InventoryModule.parse() == None

# Generated at 2022-06-21 05:01:39.139507
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from io import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = StringIO(u"""
    plugin: host_list
    key1: value1
    hosts:
        host1:
         ansible_host: 1.2.3.4
         ansible_port: 22
    """)
    config_data = AnsibleLoader(data, file_name='/dev/null').get_single_data()

    # Mock class ansible.plugins.inventory.BaseInventoryPlugin
    class BaseInventoryPlugin_mock(object):
        NAME = 'auto'
        def __init__(self):
            pass
        def update_cache_if_changed(self):
            pass
        def parse(self, inventory, loader, path, cache=True):
            assert cache == True

# Generated at 2022-06-21 05:01:40.217790
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert 1 == 1

# Generated at 2022-06-21 05:01:44.950649
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    plugin = InventoryModule()
    inventory = dict()
    loader = dict()
    path = ""
    cache = True
    plugin.parse(inventory, loader, path, cache)
    #Test that the loader should start with the path
    assert loader.startswith(path)

# Generated at 2022-06-21 05:01:48.956764
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    m = InventoryModule()
    assert m.verify_file(file="inventoryme") == False
    assert m.verify_file(file="inventoryme.yml") == True

# Generated at 2022-06-21 05:02:02.861457
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    module_instance = InventoryModule()
    return_value = module_instance.verify_file("./test_file.yml")
    assert return_value == False
    return_value = module_instance.verify_file("./test_file.yaml")
    assert return_value == False
    return_value = module_instance.verify_file("test_file.yaml")
    assert return_value == False
    return_value = module_instance.verify_file("./test_file.txt")
    assert return_value == False
    return_value = module_instance.verify_file("test_file.txt")
    assert return_value == False

# Generated at 2022-06-21 05:02:06.876247
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Given
    inventory_module = InventoryModule()
    path = "myfile.yml"

    # When
    result = inventory_module.verify_file(path)

    # Then
    assert result

# Generated at 2022-06-21 05:02:12.666690
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    '''
    InventoryModule.verify_file
    '''
    obj = InventoryModule()

    result = obj.verify_file(True)

    assert result is False

# Generated at 2022-06-21 05:02:18.189563
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv.NAME == "auto"
    assert inv.verify_file("/path/to/file.yml")
    assert not inv.verify_file("/path/to/file.ini")

# Generated at 2022-06-21 05:02:19.942424
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert isinstance(InventoryModule(), InventoryModule)

# Generated at 2022-06-21 05:02:22.039787
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    pass

# Generated at 2022-06-21 05:02:26.303565
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    p = InventoryModule()
    # Test if the file has a correct extension
    assert p.verify_file('/tmp/example.yaml')
    assert not p.verify_file('/tmp/exampl.yaml')
    assert not p.verify_file('/tmp/exampl.txt')
    assert not p.verify_file('/tmp/exampl')

# Generated at 2022-06-21 05:02:28.253162
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule(None, {})

# Generated at 2022-06-21 05:02:38.331115
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    obj = InventoryModule()
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    variable_manager = VariableManager()
    cache = False
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    path = "something.yml"
    config_data = {'plugin': "something"}
    loader.get_basedir = lambda: "something"
    loader.path_exists = lambda path: True
    loader.load_from_file = lambda path, cache: config_data
    inventory_loader.get = lambda plugin_name: obj
    obj.verify_file = lambda path: True
    obj.parse = lambda inventory, loader, path, cache: None

# Generated at 2022-06-21 05:02:41.358062
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    path = '/home/user/abc.yml'
    ret = InventoryModule().verify_file(path)
    assert(ret == True)
    path = '/home/user/abc.yaml'
    ret = InventoryModule().verify_file(path)
    assert(ret == True)
    path = '/home/user/abc.txt'
    ret = InventoryModule().verify_file(path)
    assert(ret == False)

# Generated at 2022-06-21 05:02:43.860882
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    from ansible.plugins.loader import inventory_loader
    assert inventory_loader.get('auto')


# Generated at 2022-06-21 05:02:50.570075
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = {"_hosts":{}, "_patterns":{}}
    loader = fake_loader
    path = "fake_path"
    cache = True

    plugin = InventoryModule()
    pl_name = "plugin_name"
    pl = fake_plugin

    config_data = {"plugin":pl_name}

    inv_loader = fake_inventory_loader
    inv_loader.get = fake_inventory_loader_get

    plugin.parse(inventory, loader, path, cache)

    # Test when no root 'plugin' key
    config_data.pop("plugin", None)

# Generated at 2022-06-21 05:03:06.725152
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv_mod = InventoryModule()
    assert not inv_mod.verify_file('/some/path/some_file.exe')
    assert inv_mod.verify_file('/some/path/some_file.yml')
    assert inv_mod.verify_file('/some/path/some_file.yaml')
    assert not inv_mod.verify_file('/some/path/some_file.yaml_bak')
    assert not inv_mod.verify_file('/some/path/.yaml')

# Generated at 2022-06-21 05:03:09.247892
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert 1 == 1


if __name__ == '__main__':
    test_InventoryModule_parse()

# Generated at 2022-06-21 05:03:11.380438
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_config = "./test/unit/plugins/inventory/test_auto.yml"
    test_obj = InventoryModule()
    temp = test_obj.verify_file(inventory_config)
    assert temp, "Verify if verify_file() is returning the correct value"

# Generated at 2022-06-21 05:03:16.017850
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import ansible.plugins.loader as ploader
    ploader.add_directory(os.path.join(os.path.dirname(__file__), 'fixtures'))
    mod = InventoryModule()
    mod.parse(None, None, os.path.join(os.path.dirname(__file__), 'fixtures/yaml.yml'))

# Generated at 2022-06-21 05:03:23.411763
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    plugin = InventoryModule()
    assert plugin.NAME == 'auto'
    assert plugin.verify_file('/a/b/c') is False
    assert plugin.verify_file('/a/b/c.yml') is True
    assert plugin.verify_file('/a/b/c.yaml') is True

# Generated at 2022-06-21 05:03:25.128046
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    pass

# Generated at 2022-06-21 05:03:26.436148
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule(None, "/path/to/fake/file", None) is not None


# Generated at 2022-06-21 05:03:38.906824
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Arrange
    path = 'test/input/test.yml'
    loader = None
    inventory = None
    expected_result = None
    expected_exception = AnsibleParserError("no root 'plugin' key found, '{0}' is not a valid YAML inventory plugin config file".format(path))

    # Act
    inventory_module = InventoryModule()
    try:
        actual_result = inventory_module.parse(inventory, loader, path)
    except AnsibleParserError as error:
        actual_result = error

    # Assert
    assert actual_result.__class__ == expected_exception.__class__
    assert str(actual_result) == str(expected_exception)

# Generated at 2022-06-21 05:03:45.662086
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    plugin = InventoryModule()
    assert plugin.verify_file(u"/path/to/file.foo") is False
    assert plugin.verify_file(u"/path/to/file.yml") is True
    assert plugin.verify_file(u"/path/to/file.yaml") is True

# Generated at 2022-06-21 05:03:57.675520
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_module = InventoryModule()

    # Test case: verify file should return False for filename
    # that ends with .yaml extension
    assert inventory_module.verify_file("/test_file.yaml") == False

    # Test case: verify file should return False for filename
    # that ends with .yml extension
    assert inventory_module.verify_file("/test_file.yml") == False

    # Test case: verify file should return False for filename
    # that do not end with .yaml or .yml extension
    assert inventory_module.verify_file("/test_file.yaml.txt") == False

# Generated at 2022-06-21 05:04:15.289335
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.loader import inventory_loader
    inventory_module_object = InventoryModule()
    inventory_module_object.parse('inventory', 'loader', 'path')



# Generated at 2022-06-21 05:04:18.450263
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_object = {}
    loader_object = {}
    path_object = '/tmp/'
    cache_object = True
    inventory_module = InventoryModule()
    inventory_module.parse(inventory_object, loader_object, path_object, cache=cache_object)

# Generated at 2022-06-21 05:04:25.931869
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv.verify_file("/tmp/file.yml") == True
    assert inv.verify_file("/tmp/file.yaml") == True
    assert inv.verify_file("/tmp/file.json") == False
    assert inv.verify_file("/tmp/file.ini") == False
    assert inv.verify_file("/tmp/file") == False

# Generated at 2022-06-21 05:04:29.783864
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = dict()
    loader = dict()
    path = ""
    cache = True
    inventory_module.parse(inventory, loader, path, cache)

# Generated at 2022-06-21 05:04:30.669033
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_mod = InventoryModule()
    assert inv_mod.NAME == 'auto'

# Generated at 2022-06-21 05:04:40.008727
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    import sys

    import unittest
    import unittest.mock

    from ansible.errors import AnsibleParserError

    # Rewrite the module path so we can load our test plugin
    sys.modules['ansible.plugins.inventory'] = mock.MagicMock(name='inventory')

    def get_plugin(name):
        if name == 'test_plugin':
            class TestPlugin():
                class InventoryModule(BaseInventoryPlugin):
                    NAME = 'test_plugin'

                    def verify_file(self, path):
                        return True

                    def parse(self, inventory, loader, path, cache=True):
                        try:
                            config = loader.load_from_file(path, cache=False)
                        except Exception:
                            config = None


# Generated at 2022-06-21 05:04:48.742655
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()

    # result should be False for all extension
    assert inventory_module.verify_file('') == False
    assert inventory_module.verify_file('.y') == False
    assert inventory_module.verify_file('.ym') == False
    assert inventory_module.verify_file('.yaml') == True
    assert inventory_module.verify_file('.yaml.x') == False
    assert inventory_module.verify_file('c:\\auto.yaml') == True
    assert inventory_module.verify_file('c:\\auto\\auto.yaml') == True
    assert inventory_module.verify_file('/auto/auto.yaml') == True
    assert inventory_module.verify_file('auto.yaml') == True

# Generated at 2022-06-21 05:04:53.901428
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module = InventoryModule()

    inv = []
    loader = None
    path = ''
    cache = None

    inventory_module.verify_file(path)
    inventory_module.parse(inv, loader, path, cache)

# Generated at 2022-06-21 05:05:03.991681
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create plugin instance
    plugin = InventoryModule()

    # Create ansible class
    ansible = Ansible()

    # Create inventory class
    loader = DataLoader()
    inventory = InventoryManager(loader=loader)

    # Create plugin config file
    filename = 'test_filename'

    class my_loader:
        def __init__(self):
            self.plugin_name = ''
        def load_from_file(self, filename, cache):
            self.plugin_name = 'my_plugin'
            return self

    # Create plugin loading method
    class my_inventory_loader:
        def __init__(self):
            self.plugin_name = 'my_plugin'

        def get(self, plugin_name):
            if self.plugin_name == plugin_name:
                return my_plugin()

# Generated at 2022-06-21 05:05:04.440618
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule()

# Generated at 2022-06-21 05:05:36.725474
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    my_object = InventoryModule()
    assert isinstance(my_object, InventoryModule)
    assert not my_object.verify_file(str())
    assert my_object.parse(str(), str(), str(), cache=True)

# Generated at 2022-06-21 05:05:38.568930
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv.NAME == 'auto'

# Generated at 2022-06-21 05:05:49.493414
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    """Unit test for method parse of class InventoryModule.
        :return:
        """

    base_plugin = BaseInventoryPlugin()
    inventory = base_plugin.get_option('inventory')

    inventory_module = InventoryModule()

    with patch.object(inventory_loader, "get", return_value=None) as mocked_get:
        with pytest.raises(AnsibleParserError) as excinfo:
            inventory_module.parse(inventory, inventory_loader, "path")

        assert "inventory config 'path' specifies unknown plugin" in str(excinfo.value)

    with patch.object(inventory_loader, "get", return_value=base_plugin) as mocked_get:
        with pytest.raises(AnsibleParserError) as excinfo:
            inventory_module.parse(inventory, inventory_loader, "path")

# Generated at 2022-06-21 05:05:59.007259
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # inventory_file_path passed as kwargs
    # Test for both file extension and return value of super class
    inventory_file_path = "test_data/auto.yml"
    inventory = InventoryModule(filename=inventory_file_path, vault_password='password')
    assert inventory.verify_file(inventory_file_path)

    # inventory_file_path not passed as kwargs
    inventory_file_path = "test_data/auto.yml"
    inventory = InventoryModule(vault_password='password')
    assert inventory.verify_file(inventory_file_path)



# Generated at 2022-06-21 05:06:01.944163
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    i = InventoryModule()
    assert i.get_name() == 'auto'


# Generated at 2022-06-21 05:06:08.353673
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    plugin = InventoryModule()

    # config file should exist
    assert plugin.verify_file('tests/test_plugin_auto/inventory.yml')

    # host file should not exist
    assert not plugin.verify_file('tests/test_plugin_auto/hosts')


# Generated at 2022-06-21 05:06:15.041568
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    mod = InventoryModule()
    assert mod.verify_file('/path/to/file.yml')
    assert mod.verify_file('/path/to/file.yaml')
    assert not mod.verify_file('/path/to/file.xyz')

# Generated at 2022-06-21 05:06:17.709457
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv is not None

# Generated at 2022-06-21 05:06:19.911405
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    config_data = {'plugin': 'ini'}
    plugin = InventoryModule()
    plugin.parse(None, None, None, cache=True)

# Generated at 2022-06-21 05:06:30.413729
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    invLoader = BaseInventoryPlugin()
    # Path has a .yml ending so should return True
    assert invLoader.verify_file("test/test.yml") is True
    # Path has a .yaml ending so should return True
    assert invLoader.verify_file("test/test.yaml") is True
    # Path has a .txt ending so should return False
    assert invLoader.verify_file("test/test.txt") is False
    # Path is None so should return False
    assert invLoader.verify_file(None) is False

# Generated at 2022-06-21 05:07:29.681246
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    pass

# Generated at 2022-06-21 05:07:35.248670
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    path = "/etc/ansible/hosts"
    assert InventoryModule.verify_file(path) == False
    path = "/etc/ansible/hosts.yml"
    assert InventoryModule.verify_file(path) == True
    path = "/etc/ansible/hosts.yaml"
    assert InventoryModule.verify_file(path) == True

# Generated at 2022-06-21 05:07:45.671711
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    loader = None
    path = 'tests/inventory_test/test.yml'
    cache = True
    inv = InventoryModule()
    assert inv.parse(loader, None, path, cache) == None

    # Mock ansible.plugins.inventory.BaseInventoryPlugin.parse
    old_parse = BaseInventoryPlugin.parse
    def mock_parse(self):
        self.name = "InventoryModule"
    BaseInventoryPlugin.parse = mock_parse

    inv = InventoryModule()
    assert inv.parse(loader, None, path, cache) == None
    assert inv.name == "InventoryModule"

    BaseInventoryPlugin.parse = old_parse
    assert inv.parse(loader, None, path, cache) == None


# Generated at 2022-06-21 05:08:00.123816
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # plugin_type: 'auto'
    # Inventories:
    # - plugin: 'static'
    #   host: 'test.example.com'
    #   properties:
    #     testvar: 'testval'
    # - plugin: 'static'
    #   host: 'test2.example.com'
    source = """
    plugin_type: 'auto'
    plugin_name: 'static'
    inventories:
    - plugin: 'static'
      host: 'test.example.com'
      properties:
        testvar: 'testval'
    - plugin: 'static'
      host: 'test2.example.com'
    """

    loader = AnsibleLoader(source)
    source_data = loader.load_from_str()

# Generated at 2022-06-21 05:08:02.330456
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    obj = InventoryModule()
    assert obj.NAME == 'auto'

# Generated at 2022-06-21 05:08:08.485701
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
  myobj = InventoryModule()
  path = 'some_non_yaml_file.txt'
  assert False == myobj.verify_file(path)
  path = 'some_yaml_file.yml'
  assert True == myobj.verify_file(path)

# Generated at 2022-06-21 05:08:15.489752
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Test class InventoryModule parse method
    '''
    import os.path
    import sys
    import tempfile

    # Adding path of inventory directory of ansible
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

    # Since plugin don't have configs, we are creating one
    # to test InventoryModule
    configs = { 'plugin' : 'dummy' }
    config_file = tempfile.NamedTemporaryFile(suffix='.yml')
    config_file.write('{0}'.format(configs).encode('utf-8'))
    config_file.seek(0)

    # Initialize InventoryModule object with config file
    inventory_module = InventoryModule()
    loader = None
    path = config_file.name


# Generated at 2022-06-21 05:08:24.081358
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    class AnsibleOptions(object):
        connection = 'ssh'
        module_path = None
        forks = 10
        become = None
        become_method = None
        become_user = None
        check = False
        diff = False

    x = InventoryModule()

    class Host(object):
        def __init__(self):
            self.vars = {}

    class InventoryManager(object):
        def __init__(self):
            self.groups = {}
            self.hosts = {}
            self.cache = {}
            self.caches_path = '/abc'

        def add_group(self, name):
            g = Group()
            self.groups[name] = g
            return g

        def add_host(self, name, group=None, port=None):
            h = Host()
            self.host

# Generated at 2022-06-21 05:08:33.304775
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Parse path:
    #   <controller>/ansible/test/units/plugins/inventory/test_data/test_auto_inventory_plugin.yml
    path = '<controller>/ansible/test/units/plugins/inventory/test_data/test_auto_inventory_plugin.yml'
    return InventoryModule().parse(None, None, path)


if __name__ == "__main__":
    from pytest import main
    main(["-vv", "-s", "test_InventoryModule.py"])

# Generated at 2022-06-21 05:08:40.863312
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory_path = '/path/to/file'
    my_inventory = InventoryModule()
    assert my_inventory is not None
    assert isinstance(my_inventory, InventoryModule)
    assert my_inventory.verify_file(inventory_path) is False
    assert my_inventory.NAME == 'auto'

# Generated at 2022-06-21 05:11:01.548863
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()


# Generated at 2022-06-21 05:11:10.874066
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    # Create a mock loader object
    class MockLoader():
        def load_from_file(self, path, cache=True):
            return dict(plugin='yaml')

    # Create a mock inventory object
    class MockInventory():
        def __init__(self, host_list=[]):
            self.hosts = host_list

    # Create an instance of plugin
    plugin = InventoryModule()
    loader = MockLoader()
    inventory = MockInventory()

    # Two valid cases
    path = 'test.yml'
    assert plugin.verify_file(path) == True
    path = 'test.yaml'
    assert plugin.verify_file(path) == True

    # Invalid case
    path = 'test.txt'
    assert plugin.verify_file(path) == False

    # Verify if it also