

# Generated at 2022-06-25 06:57:34.645026
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_0 = {'args': {'key': 'key_1'}}
    module_0 = ActionModule(task=task_0)
    assert module_0._VALID_ARGS == frozenset(['key', 'parents'])
    assert module_0.TRANSFERS_FILES == False
    assert module_0._task == {'args': {'key': 'key_1'}}


# Generated at 2022-06-25 06:57:36.925973
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule_instance = ActionModule()
    ActionModule_instance.run()


# Generated at 2022-06-25 06:57:38.029353
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()
    obj.run()


# Generated at 2022-06-25 06:57:40.582971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(hash('dummy'), hash('dummy'), hash('dummy'))
    assert isinstance(action_module_0, ActionModule)
    assert isinstance(action_module_0, action_module_0.ActionBase)


# Generated at 2022-06-25 06:57:47.969307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    b_2 = 1
    int_1 = 2
    str_1 = '|O$jn#Xv\x0c#+U='
    dict_1 = {str_1: int_1}
    tuple_0 = (b_2, dict_1, int_1)
    str_2 = '['
    str_3 = ']'
    list_0 = [b_2, dict_1, int_1, str_2, str_3]
    test = ActionModule(tuple_0, list_0)
    return test


# Generated at 2022-06-25 06:57:58.735718
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '|O$jn#Xv\x0c#+U='
    set_0 = {str_0}
    set_1 = {str_0, set_0}

    # test case 0
    task = dict()
    task['args'] = dict()
    task['args']['key'] = str_0
    task['args']['parents'] = set_0
    action_module = ActionModule(task)

    # test case 0
    result = action_module.run(None, None)
    assert result['changed'] == False
    assert result['add_group'] == '|O-jn#Xv\x0c#+U='
    assert result['parent_groups'] == ['all']

# Generated at 2022-06-25 06:58:01.755669
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'V9pY#?v]nW\x19\x7f,n3q'
    module_0 = ActionModule()
    assert isinstance(module_0, ActionModule)


# Generated at 2022-06-25 06:58:10.426385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test run")
    # Test expectations
    tmp = 'tmp'
    #task_vars = dict()
    #result = dict()
    #result['failed'] = True
    #result['msg'] = "the 'key' param is required when using group_by"
    #action_module = ActionModule(tmp, task_vars)
    #result = action_module.run(tmp, task_vars)
    #assert result['failed'] == True , "Assert failed, result['failed'] should be True"
    #assert result['msg'] == "the 'key' param is required when using group_by" , "Assert failed, result['msg'] should be \"the 'key' param is required when using group_by\""


# Generated at 2022-06-25 06:58:19.215829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare objects and variables
    str_0 = '`|mP|\x0b#\x0c}9\x0b%I\x04S\x1b'
    str_1 = 'f\x13\x0b&\t;\x1d\x0c\x0c?\x1d\x14\x13\x0b'
    str_2 = 'O\x0b\x0b%\x1e\x02\x17\x13\x15\x0b\x0b?\x1d\x1f\x13\x0b'
    dict_0 = {}
    dict_1 = {}
    dict_2 = {'add_group': str_0, 'parent_groups': [str_1, str_2], 'failed': False}

# Generated at 2022-06-25 06:58:19.961476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 06:58:23.356665
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 06:58:26.658222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # input arguments for method run
    tmp = None
    task_vars = None

    # creation of object instance of the ActionModule class
    action_module_obj = ActionModule()
    # call method run with arguments
    method_return_value = action_module_obj.run(tmp, task_vars)
    # assert the return value
    assert method_return_value['add_group'] == 'test'
    assert method_return_value['parent_groups'] == ['all']

# Generated at 2022-06-25 06:58:28.118823
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)


# Generated at 2022-06-25 06:58:29.283463
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule), "constructor not callable"


# Generated at 2022-06-25 06:58:30.857598
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule()

    assert action_module != None

# Generated at 2022-06-25 06:58:31.998970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-25 06:58:35.105273
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: test after made run() method return something testable
    action_module_0 = ActionModule()
    values_0 = action_module_0.run({}, {})
    assert values_0 == {}

# Generated at 2022-06-25 06:58:38.517072
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # Test case 1
  action_module = ActionModule()
  assert action_module is not None, "Test case 1 failed"



# Generated at 2022-06-25 06:58:39.424305
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 06:58:42.971189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Should always fail
    args = { 'key' : 'invalid-key' }
    result = ''
    try:
        result = action_module_0.run(action_module_0, task_vars=args)
    except SystemExit as e:
        result = e.code
    assert (result != '' and result != 0), 'run did not run as expected'

# Generated at 2022-06-25 06:58:52.290606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(
            args=dict(
                key='my_group')
        )
    )
    assert action.run(task_vars=dict()).get('parent_groups') == ['all']
    assert action.run(task_vars=dict()).get('failed') == False

# Generated at 2022-06-25 06:58:59.912075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test Case 0
    result = ActionModule().run()
    assert(result['failed'] == True)
    assert(result['msg'] == "the 'key' param is required when using group_by")

    # Test Case 1
    result = ActionModule().run(key='foo')
    assert(result['changed'] == False)
    assert(result['add_group'] == 'foo')
    assert(result['parent_groups'] == ['all'])

    # Test Case 2
    result = ActionModule().run(key='foo',parents='bar')
    assert(result['changed'] == False)
    assert(result['add_group'] == 'foo')
    assert(result['parent_groups'] == ['bar'])

    # Test Case 3
    result = ActionModule().run(key='foo',parents='bar,xyzzy')

# Generated at 2022-06-25 06:59:09.860023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None

# Generated at 2022-06-25 06:59:13.405292
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test_case_0()
    action_module_0 = ActionModule()

# Generated at 2022-06-25 06:59:21.793240
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert(isinstance(action_module_0, ActionModule))

# get_host_list()
#
# "action_module_1_host_list" is variable name of type list.
#
# This variable is used to store the value returned by
# ActionModule.get_host_list(module_name='')
#
# This method will find the host for the task executing the module
#
action_module_1_host_list = ActionModule.get_host_list(module_name='')

# test_case_1()
#
# This is the test case for 'get_host_list()' method of class ActionModule
#

# Generated at 2022-06-25 06:59:23.056189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()

# Generated at 2022-06-25 06:59:25.189399
# Unit test for constructor of class ActionModule
def test_ActionModule(): 
    action_module = ActionModule()
    assert action_module
    assert action_module._VALID_ARGS == frozenset(['key', 'parents'])

# Generated at 2022-06-25 06:59:29.671962
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test a case with key specified.
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:59:31.913627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:59:35.672367
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    assert action_module_1.run() is None


# Generated at 2022-06-25 06:59:48.453205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Ansible returns False in case of error
    assert test_case_0()


# Generated at 2022-06-25 06:59:55.444102
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule.run")
    action_module_0 = ActionModule()

    # No value provided for 'key'
    result = action_module_0.run(tmp=None, task_vars=None)
    assert result['failed'] == True
    assert result['msg'] == "the 'key' param is required when using group_by"

    result = action_module_0.run(tmp=None, task_vars=None, key="1")
    assert result['changed'] == False
    assert result['add_group'] == "1"

    result = action_module_0.run(tmp=None, task_vars=None, key="1", parents="2")
    assert result['changed'] == False
    assert result['parent_groups'] == ['2']


# Generated at 2022-06-25 06:59:56.764919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:00:00.510228
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert isinstance(action_module_1, ActionModule)
    assert action_module_1


# Generated at 2022-06-25 07:00:08.062992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Parameters expected by constructor of class ActionModule():
    #
    # task:
    #    - Contains data to pass between modules and templating engines
    # connection:
    #    - connection plugin
    # play_context:
    #    - variables and information related to the current play run
    # loader:
    #    - Plugin loader
    # templar:
    #    - Templating engine
    # shared_loader_obj:
    #    - Data loader
    #
    pass

# Generated at 2022-06-25 07:00:09.240346
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True is True

# Generated at 2022-06-25 07:00:10.475257
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module_0.TRANSFERS_FILES == False

# Generated at 2022-06-25 07:00:17.802014
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test target.
    action_module_1 = ActionModule()
    action_module_1._task = {
        'args': {
            'key': 'test',
            'parents': ['all'],
            'none': None,
            'empty': ''
        }
    }

    # Test action.
    result = action_module_1.run(task_vars={})

    # Test assertions
    assert result == {
        'add_group': 'test',
        'changed': False,
        'parent_groups': ['all']
    }


# Generated at 2022-06-25 07:00:20.784759
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action_module_0 = ActionModule()


# Generated at 2022-06-25 07:00:27.778865
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as err:
        print('Test class constructor FAILED')
        print(err)
        return -1
    try:
        action_module_0 = ActionModule()
        assert isinstance(action_module_0._task.args, frozenset), \
            "FAIL: ActionModule._task.args initialized incorrectly"
        assert isinstance(action_module_0._task.args.get('key'), str), \
            "FAIL: ActionModule._task.args['key'] initialized incorrectly"
        assert isinstance(action_module_0._task.args.get('parent'), str), \
            "FAIL: ActionModule._task.args['parent'] initialized incorrectly"
    except:
        print('Test class instantiation FAILED')
        return -1

# Generated at 2022-06-25 07:00:42.672681
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = -765.78802
    int_0 = -433
    str_0 = "\r`//$\\'8\nL121Z"
    int_1 = 282
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_0, int_1)
    assert true # TODO


# Generated at 2022-06-25 07:00:50.667736
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = -765.78802
    int_0 = -433
    str_0 = "\r`//$\\'8\nL121Z"
    int_1 = 282
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_0, int_1)
    var_0 = action_run()

# Generated at 2022-06-25 07:00:58.100066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = -765.78802
    int_0 = -433
    str_0 = "\r`//$\\'8\nL121Z"
    int_1 = 282
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_0, int_1)
    test_case_0()

ActionModule()

# Generated at 2022-06-25 07:01:01.753879
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = -765.78802
    int_0 = -433
    str_0 = "\r`//$\\'8\nL121Z"
    int_1 = 282
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_0, int_1)
    var_0 = action_module_0.run()
    assert var_0["failed"] == False
    
test_ActionModule_run()

# Generated at 2022-06-25 07:01:07.626834
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = -765.78802
    int_0 = -433
    str_0 = "\r`//$\\'8\nL121Z"
    float_1 = -765.78802
    int_1 = 282
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_1, int_1)


# Generated at 2022-06-25 07:01:15.508600
# Unit test for constructor of class ActionModule
def test_ActionModule():

	dict_0 = {}
	float_0 = -765.78802
	int_0 = -433
	str_0 = "\r`//$\\'8\nL121Z"
	float_1 = -765.78802
	int_1 = 282
	action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_1, int_1)
	action_module_0.run()

# Generated at 2022-06-25 07:01:25.420362
# Unit test for constructor of class ActionModule
def test_ActionModule():
  dict_0 = {}
  float_0 = -765.78802
  int_0 = -433
  str_0 = "\r`//$\\'8\nL121Z"
  int_1 = 282
  action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_0, int_1)

  assert_equals('msg' in action_module_0.result, True)
  assert_equals(action_module_0.result['msg'], "the 'key' param is required when using group_by")
  assert_equals(action_module_0.task_vars.get('nested_dict_variable', 'no-nested-dict-in-task-vars'), 'no-nested-dict-in-task-vars')

# Generated at 2022-06-25 07:01:31.444369
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = -765.78802
    int_0 = -433
    str_0 = "\r`//$\\'8\nL121Z"
    int_1 = 282
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_0, int_1)


# Generated at 2022-06-25 07:01:32.492467
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:01:40.488828
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = 688.542
    int_0 = -185
    str_0 = "B0\nh\x1c\x1c\x0c\r~\r&gt;\x00\x0b\x01g\x1a\x17\x00\x1a\x10\x06\x19\x1b"
    int_1 = 662
    test_case_0(dict_0, float_0, int_0, str_0, float_0, int_1)


ActionModule = test_ActionModule

# Generated at 2022-06-25 07:02:13.599543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = -765.78802
    int_0 = -433
    str_0 = "\r`//$\\'8\nL121Z"
    int_1 = 282
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_0, int_1)
    float_1 = 765.78802
    int_2 = 433
    str_1 = "\r`//$\\'8\nL121Z"
    int_3 = 282
    str_2 = ":'*'N"
    int_4 = -224
    action_module_0.run(float_1, str_1, int_3, int_2, int_4, str_2)


# Generated at 2022-06-25 07:02:18.865186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg_0 = -13.319193
    arg_1 = "\\'L-\r\n2JUe"
    arg_2 = 0
    arg_3 = "w\r_{p;j@l"
    arg_4 = -9.916612
    arg_5 = 5
    action_module_0 = ActionModule(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5)
    action_module_0.run()

# Generated at 2022-06-25 07:02:25.776020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = 1786.859
    int_0 = 858
    str_0 = "!j_6Ui(pMz;xs:gY8P-iHbv\u000e"
    int_1 = -66
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_0, int_1)
    var_0 = action_run()

# Generated at 2022-06-25 07:02:31.282664
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = 684.77
    int_0 = -800
    str_0 = "'-}q"
    int_1 = 64
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_0, int_1)
    assert action_module_0.argspec.args == []


# Generated at 2022-06-25 07:02:39.555593
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = 6.683405
    int_0 = -541
    str_0 = "P7V'<t&H:KVp"
    int_1 = 986
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_0, int_1)

# Generated at 2022-06-25 07:02:46.329463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = -765.78802
    int_0 = -433
    str_0 = "\r`//$\\'8\nL121Z"
    int_1 = 282
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_0, int_1)
    var_0 = action_run()


# Generated at 2022-06-25 07:02:50.897623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = -765.78802
    int_0 = -433
    str_0 = "\r`//$\\'8\nL121Z"
    int_1 = 282
    #     tmp=None,
    #     task_vars=None
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_0, int_1)
    action_run()

# Generated at 2022-06-25 07:02:54.123403
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = -765.78802
    int_0 = -433
    str_0 = "\r`//$\\'8\nL121Z"
    int_1 = 282
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_0, int_1)


# Generated at 2022-06-25 07:02:58.339076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = -765.78802
    int_0 = -433
    str_0 = "\r`//$\\'8\nL121Z"
    float_1 = -765.78802
    int_1 = 282
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_1, int_1)
    dict_1 = {}
    dict_2 = {}
    action_module_0.run(dict_1, dict_2)

# Generated at 2022-06-25 07:03:09.221870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = -18.274
    int_0 = -6041

# Generated at 2022-06-25 07:04:13.223460
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = -765.78802
    int_0 = -433
    str_0 = "\r`//$\\'8\nL121Z"
    int_1 = 282
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_0, int_1)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:04:18.380698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = -765.78802
    int_0 = -433
    str_0 = "\r`//$\\'8\nL121Z"
    int_1 = 282
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_0, int_1)
    try:
        ActionModule(dict_0, float_0, int_0, str_0, float_0, int_1)
    except TypeError as exception_0:
        print('TypeError caught:', exception_0)


# Generated at 2022-06-25 07:04:21.691865
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:04:26.212073
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = -5.744
    int_0 = -654
    str_0 = "=='R+E*/!a77"
    float_1 = 0.1543
    int_1 = -431
    obj_0 = ActionModule(dict_0, float_0, int_0, str_0, float_1, int_1)
    assert obj_0.run() == {}


# Generated at 2022-06-25 07:04:27.039606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0()



# Generated at 2022-06-25 07:04:37.500484
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = -895.191
    int_0 = 145
    str_0 = "\'q\"J"
    int_1 = -917
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_0, int_1)
    dict_0 = action_module_0.run()
    dict_0 = {}
    float_0 = -895.191
    int_0 = 145
    str_0 = "\'q\"J"
    int_1 = -917
    action_module_1 = ActionModule(dict_0, float_0, int_0, str_0, float_0, int_1)
    dict_0 = action_module_1.run()
    dict_0 = {}
    float

# Generated at 2022-06-25 07:04:44.337956
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = "Za"
    int_0 = 2
    float_0 = -134.87
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_0, int_0)

    # TODO: Test the run method of ActionModule

    # Test exception
    with raises(AttributeError):
        action_module_0.run()



# Generated at 2022-06-25 07:04:47.840809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = -765.78802
    int_0 = -433
    str_0 = "\r`//$\\'8\nL121Z"
    float_1 = -765.78802
    int_1 = 282
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_1, int_1)

# Generated at 2022-06-25 07:04:55.421983
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = -784.98181
    int_0 = -265
    str_0 = "\f\t\"\n\t"
    float_1 = -522.4167
    int_1 = 283
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_1, int_1)
    var_0 = action_module_0.run()
    int_2 = -478
    assert(int_1 == int_2)
    assert(var_0 == None)


# Generated at 2022-06-25 07:05:02.964159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = -122.6378
    int_0 = -893
    str_0 = "\f\v/X\n\r'z^\r37\r\r"
    int_1 = 393
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_0, int_1)
    action_module_0.action_loader = action_loader_0
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:07:21.887507
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = 1.2
    int_0 = -4
    str_0 = "H1\t2\n"
    float_1 = 1.44313
    int_1 = 2
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_1, int_1)


# Generated at 2022-06-25 07:07:26.211976
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = -765.78802
    int_0 = -433
    str_0 = "\r`//$\\'8\nL121Z"
    float_1 = -765.78802
    int_1 = 282
    action_module_0 = ActionModule(dict_0, float_0, int_0, str_0, float_1, int_1)