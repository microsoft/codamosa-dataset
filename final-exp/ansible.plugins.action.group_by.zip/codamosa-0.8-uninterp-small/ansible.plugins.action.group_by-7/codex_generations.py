

# Generated at 2022-06-25 06:57:39.061205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with valid arguments
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    tuple_0 = ()
    float_0 = 0.5
    bytes_0 = b'[\x9a\xa5\xf7\xeck\x99\xceN\xeeb\rS\xd0\xb5\xc7b\xba\xecx'
    action_module_0 = ActionModule(list_0, tuple_0, float_0, tuple_0, list_0, bytes_0)
    tmp = None

# Generated at 2022-06-25 06:57:50.653616
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    tuple_0 = ()
    float_0 = 0.5
    bytes_0 = b'[\x9a\xa5\xf7\xeck\x99\xceN\xeeb\rS\xd0\xb5\xc7b\xba\xecx'
    action_module_0 = ActionModule(list_0, tuple_0, float_0, tuple_0, list_0, bytes_0)

    # Parameters: tmp, task_vars
    str_0 = '1'
    set_1 = set()
    list_2 = [set_1, set_1, set_1]
    tuple_1 = ()
    float_1 = 0.5
    bytes_1

# Generated at 2022-06-25 06:57:59.345911
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    tuple_0 = ()
    float_0 = 0.5
    bytes_0 = b'[\x9a\xa5\xf7\xeck\x99\xceN\xeeb\rS\xd0\xb5\xc7b\xba\xecx'
    action_module_0 = ActionModule(list_0, tuple_0, float_0, tuple_0, list_0, bytes_0)


# Generated at 2022-06-25 06:58:04.530903
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    tuple_0 = ()
    float_0 = 0.5
    bytes_0 = b'[\x9a\xa5\xf7\xeck\x99\xceN\xeeb\rS\xd0\xb5\xc7b\xba\xecx'
    action_module_0 = ActionModule(list_0, tuple_0, float_0, tuple_0, list_0, bytes_0)
    action_module_0.run()

# Generated at 2022-06-25 06:58:09.868915
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    tuple_0 = ()
    float_0 = 0.5
    bytes_0 = b'[\x9a\xa5\xf7\xeck\x99\xceN\xeeb\rS\xd0\xb5\xc7b\xba\xecx'
    test_case_0()


# Generated at 2022-06-25 06:58:16.593518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    list_1 = [set_0, set_0, set_0]
    tuple_0 = ()
    float_0 = 0.5

# Generated at 2022-06-25 06:58:24.946576
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    tuple_0 = ()
    float_0 = 0.5
    bytes_0 = b'[\x9a\xa5\xf7\xeck\x99\xceN\xeeb\rS\xd0\xb5\xc7b\xba\xecx'
    action_module_0 = ActionModule(list_0, tuple_0, float_0, tuple_0, list_0, bytes_0)
    tuple_0 = ()
    dict_0 = {}
    set_1 = set()
    list_1 = [set_0, set_1, set_1]
    tuple_1 = ()
    float_1 = 1.2

# Generated at 2022-06-25 06:58:32.793942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    set_1 = set()
    list_0 = [set_0, set_1, set_0]
    tuple_0 = ()
    float_0 = 0.5
    bytes_0 = b'[\x9a\xa5\xf7\xeck\x99\xceN\xeeb\rS\xd0\xb5\xc7b\xba\xecx'
    action_module_0 = ActionModule(list_0, tuple_0, float_0, tuple_0, list_0, bytes_0)
    action_module_0.password = 'S\xed\x99\xc4\x9d\xba\x8c\x14\x1a.\x1e\xeb\xf2\x85\xfb\xbe'

# Generated at 2022-06-25 06:58:43.168875
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Assignments for parameter 'hosts' of a Task object
    set_0 = set()
    list_0 = [set_0, set_0, set_0]

    # Assignments for parameter 'task' of a Task object
    tuple_0 = ()

    # Assignments for parameter 'task_vars' of a Task object
    float_0 = 0.5

    # Assignments for parameter 'shared_loader_obj' of a Task object
    tuple_1 = ()

    # Assignments for parameter 'variable_manager' of a Task object
    list_1 = [tuple_0, tuple_0, tuple_0]

    # Assignments for parameter 'loader' of a Task object

# Generated at 2022-06-25 06:58:51.258377
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    list_0 = [set_0, set_0, set_0]
    tuple_0 = ()
    float_0 = 0.5
    bytes_0 = b'[\x9a\xa5\xf7\xeck\x99\xceN\xeeb\rS\xd0\xb5\xc7b\xba\xecx'
    action_module_0 = ActionModule(list_0, tuple_0, float_0, tuple_0, list_0, bytes_0)

    action_module_0.run()


# Generated at 2022-06-25 06:59:04.777921
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_3 = 'default_uv'
    var_4 = 'async'
    var_5 = 'async'
    var_6 = '_'
    var_7 = 'async'
    var_8 = 'module'
    var_9 = 'module'
    var_10 = 'default_uv'
    var_11 = 'module'
    var_12 = []
    var_12.append('default_uv')
    var_12.append('module')
    var_12.append('module')
    var_12.append('module')
    var_12.append('module')
    var_12.append('module')
    var_12.append('module')
    var_12.append('default_uv')
    var_12.append('default_uv')

# Generated at 2022-06-25 06:59:12.398882
# Unit test for constructor of class ActionModule
def test_ActionModule():

    #print('Running constructor test for ActionModule')

    # test for constructor for class ActionModule
    action_module_obj = ActionModule()

    assert_equals(action_module_obj._task, None)
    assert_equals(action_module_obj.connection, 'smart')
    assert_equals(action_module_obj.noop_on_check(False), False)
    assert_equals(action_module_obj.noop_on_check(None), False)
    assert_equals(action_module_obj.noop_on_check(True), True)
    assert_equals(action_module_obj.SUPPORTED_FILTER_PLUGINS, set())

# Generated at 2022-06-25 06:59:15.623686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of the class
    action_module_instance = ActionModule(task_0)

    # Create mock object for tmp
    tmp_instance = mock.Mock()

    # Create mock object for task_vars
    task_vars_instance = mock.Mock()

    # Call method run of the class with parameters tmp and task_vars
    return_value_0 = action_module_instance.run(tmp_instance, task_vars_instance)

    # Check if the return value equals to return_value_0
    assert return_value_0 == return_value_0


# Generated at 2022-06-25 06:59:16.733415
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()


# Generated at 2022-06-25 06:59:19.986091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = test_case_0()
    return

# Generated at 2022-06-25 06:59:29.585792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    plugin_name = 'action_plugin.ActionModule'
    file_name = 'plugins/action_plugins/ActionModule.py'
    module = __import__(plugin_name)
    module = getattr(module, 'action_plugin')
    module = getattr(module, 'ActionModule')
    tmp = None
    task_vars = None
    self = module(task=None, connection=None, _new_stdin=None)
    group_name = 'group_name'
    parent_groups = 'parent_groups'
    result = self.run(tmp, task_vars)

    assert result is not None
    assert result['changed'] == False
    assert type(result['add_group']) == str
    assert result['add_group'] == 'group_name'
    assert type(result['parent_groups'])

# Generated at 2022-06-25 06:59:33.197169
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionBase()
    var_1 = ActionBase()
    var_2 = ActionBase(var_1, var_0)
    var_2 = ActionBase()

# Generated at 2022-06-25 06:59:39.851085
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_facts = dict()
    ansible_facts['inventory_hostname'] = 'localhost'
    task_vars = dict()
    task_vars['ansible_facts'] = ansible_facts
    tmp = None
    self_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    self_0._connection = dict()
    self_0._connection['become_method'] = 'sudo'
    self_0._task = dict()
    self_0._task.args = dict()
    self_0._task.args['key'] = 'localhost'
    self_0._task.args['parents'] = 'remote'
    var_0 = self_0.run(tmp, task_vars)

#

# Generated at 2022-06-25 06:59:40.565340
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:59:46.433202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = None
    actionmodule_0 = ActionModule()

    # Call method run of ActionModule
    test_result_0 = actionmodule_0.run(tmp=tmp_0, task_vars=task_vars_0)
    assert test_result_0['failed']

    # Call method run of ActionModule
    test_result_0 = actionmodule_0.run(tmp=tmp_0, task_vars=task_vars_0)
    assert test_result_0['changed']

# Generated at 2022-06-25 06:59:51.486874
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = dict()
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:59:55.777701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_instance = ActionModule()
    action_module_instance.run(tmp = "tmp")

# Generated at 2022-06-25 07:00:04.991269
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert action_module_1._task.args.get('key') == None
    assert action_module_1._task.args.get('parents', ['all']) == ['all']

    action_module_2 = ActionModule()
    action_module_2._task.args = {'key': 'key', 'parents': 'parent'}
    assert action_module_2._task.args.get('key') == 'key'
    assert action_module_2._task.args.get('parents', ['all']) == 'parent'

    action_module_3 = ActionModule()
    action_module_3._task.args = {'key': 'key', 'parents': ['parent_1', 'parent_2']}

# Generated at 2022-06-25 07:00:08.898731
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(ActionModule()) == ActionModule, "Failed to create object of class ActionModule"

# Generated at 2022-06-25 07:00:10.475319
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert type(action_module_0) == ActionModule


# Generated at 2022-06-25 07:00:14.942872
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert (action_module is not None)


# Generated at 2022-06-25 07:00:18.127165
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = dict()
    print(action_module_0.run(tmp, task_vars))



# Generated at 2022-06-25 07:00:18.969982
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()

# Generated at 2022-06-25 07:00:20.162741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()

# Generated at 2022-06-25 07:00:27.240863
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert(action_module_0.result == {'changed': False, 'invocation': {'module_args': {}, 'module_name': 'group_by'}})

    action_module_1 = ActionModule()
    assert(action_module_1.result == {'changed': False, 'invocation': {'module_args': {}, 'module_name': 'group_by'}})

    action_module_2 = ActionModule()
    assert(action_module_2.result == {'changed': False, 'invocation': {'module_args': {}, 'module_name': 'group_by'}})

    action_module_3 = ActionModule()

# Generated at 2022-06-25 07:00:38.400427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    result = action_module_0.run(tmp=None, task_vars={'test_key': 'test_value'})
    assert result == {'changed': False, 'parent_groups': ['all'], 'add_group': 'test'}

# Generated at 2022-06-25 07:00:39.583531
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:00:42.949123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: add a test for constructor here
    # for example
    assert False, "Test not implemented"


# Generated at 2022-06-25 07:00:49.467230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    result = action_module_0.run(tmp=None, task_vars=None)

    # Method run of class ActionModule has no return statements in its definition.
    # We do not know what should be returned.



# Generated at 2022-06-25 07:00:50.836200
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:00:57.078902
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test get/set of ansible
    ansible = Ansible()
    action_module = ActionModule()
    action_module.ansible = ansible
    expected = ansible
    result = action_module.ansible
    assert expected == result


# Generated at 2022-06-25 07:00:58.656002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # pylint: disable=redefined-outer-name
    test_case_0()
    # pylint: enable=redefined-outer-name

# Generated at 2022-06-25 07:01:09.289912
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(TypeError):
        action_module_1 = ActionModule()

    with pytest.raises(TypeError):
        action_module_2 = ActionModule(task=None)

    with pytest.raises(TypeError):
        action_module_3 = ActionModule(task="None")

    # Test with a empty task
    task_0 = dict()
    action_module_4 = ActionModule(task=task_0)
    assert action_module_4._task==task_0

    # Test with a task with no args
    task_1 = dict(
        args=dict()
    )
    action_module_5 = ActionModule(task=task_1)
    assert action_module_5._task==task_1

    # Test with a task with args as well
    task_2 = dict

# Generated at 2022-06-25 07:01:14.112614
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = 'tmp'
    task_vars = dict()
    action_module_1 = ActionModule()
    p = action_module_1.run(tmp, task_vars)
    assert (p['msg'] == "the 'key' param is required when using group_by")

# Generated at 2022-06-25 07:01:15.532502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()


# Generated at 2022-06-25 07:01:24.800438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock
    tmp = mock.MagicMock()
    task_vars = mock.MagicMock()

    # Call method with dummy args
    test_obj.run(tmp, task_vars)
    test_obj.run(tmp, task_vars)

# Generated at 2022-06-25 07:01:29.370157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    try:
        result_0 = action_module_0.run(tmp, task_vars)
    except:
        result_0 = None
    assert result_0 == None

# Test case for method run of class ActionModule

# Generated at 2022-06-25 07:01:34.785740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()


# Generated at 2022-06-25 07:01:41.037320
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 69
    str_0 = 'A2W'
    bool_1 = False
    bytes_0 = b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
    var_0 = action_module_0.run(bool_0, int_0)

# Generated at 2022-06-25 07:01:47.792630
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 66
    str_0 = '\x1b\x1b'
    bool_1 = True
    bytes_0 = b'b\xee\x99\xdb\x17\xacc\xd0\x8d\x9d\x1aO\x82\x1f\x91\x14w'
    list_0 = [str_0, bytes_0, int_0, bool_1, bytes_0]
    tuple_0 = (int_0, int_0, str_0, bytes_0, int_0)
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)

# Generated at 2022-06-25 07:01:57.519467
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 84
    str_0 = 'a'
    bool_1 = False
    bytes_0 = b'G\xc5\xb2`\xda\xab\xd6\x06\xec\x8d\x9e\xb4"\xca\x8a\xef\x99\xb1'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
    assert(action_module_0.host_name == str_0)
    assert(action_module_0.no_log is False)

# Generated at 2022-06-25 07:02:05.690705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 69
    str_0 = 'A2W'
    bool_1 = False
    bytes_0 = b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
    assert action_module_0 != None

# Test case for run

# Generated at 2022-06-25 07:02:09.757454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 69
    str_0 = 'A2W'
    bool_1 = False
    bytes_0 = b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
    var_0 = action_run(bool_0)

# Generated at 2022-06-25 07:02:16.819782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = 13
    str_0 = '`Z'
    bool_1 = False
    bytes_0 = b'\xbdb\xd9\x04\x12\xa1\x9c\xcf\xad\x89\x1d6'
    list_0 = [int_0, str_0, str_0, bytes_0]
    tuple_0 = (bool_1, bool_1, bytes_0)
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)


# Generated at 2022-06-25 07:02:22.810567
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  bool_0 = False
  int_0 = 69
  str_0 = 'A2W'
  bool_1 = False
  bytes_0 = b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92'
  list_0 = [bool_1, bytes_0, bool_1, bool_1]
  tuple_0 = ()
  action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
  var_0 = action_run(bool_0)


# Generated at 2022-06-25 07:02:39.420567
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 5
    str_0 = '^6\x92\x9eQ\xf2\x9c%\x12\xf4\xaa^\xfc\x01\x1b'
    int_1 = 1
    list_0 = [int_1, int_1, '\xcb\xcd', int_1, int_1]
    str_1 = '\x97\x03\x91\xdd'
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_1, tuple_0)
    assert not isinstance(action_module_0._task, AnsibleModule)
    action_module_0._run_task('-', action_module_0.task_vars)

# Generated at 2022-06-25 07:02:47.845623
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = {}
    key_0 = 'Ihr'
    parents_0 = 'R\x0e\xc4\x84\xd0\x8a\x88\x9cg\x85p'
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
    result['changed'] = False
    result['add_group'] = group_name.replace(' ', '-')
    result['parent_groups'] = [name.replace(' ', '-') for name in parent_groups]


# Generated at 2022-06-25 07:02:52.954459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 69
    str_0 = 'A2W'
    bool_1 = False
    bytes_0 = b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()

    # Test for exception in class constructor
    with pytest.raises(TypeError):
        action_module_0 = ActionModule(int_0)


# Generated at 2022-06-25 07:03:00.887846
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 12
    str_0 = '_l9x'
    int_1 = 61
    list_0 = ['w', 's', '@', 'z', 'b', '9']
    str_1 = '_l9x'
    tuple_0 = ('z', '_l9x', 'H', 'x', 'h')
    action_module_0 = ActionModule(int_0, str_0, int_1, list_0, str_1, tuple_0)
    return action_module_0 is not None


# Generated at 2022-06-25 07:03:10.754407
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # In case you would like to test a specific module
    bool_0 = False
    int_0 = 69
    str_0 = 'A2W'
    bool_1 = False
    bytes_0 = b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
    var_0 = action_module_0.run(str_0)


# Generated at 2022-06-25 07:03:15.248287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 69
    str_0 = 'A2W'
    bool_1 = False
    bytes_0 = b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
    bool_0 = False
    var_0 = action_run(bool_0)

# Generated at 2022-06-25 07:03:23.459388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 69
    str_0 = 'A2W'
    bool_1 = False
    bytes_0 = b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
    var_0 = action_run(bool_0)

# Generated at 2022-06-25 07:03:33.531821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 69
    str_0 = 'A2W'
    bool_1 = False
    bytes_0 = b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
    # assert action_module_0.connection == str_0
    # assert action_module_0.module_name == str_0
    # assert action_module_0.task_vars == list_0
    # assert action_module_0._display == str_0


# Generated at 2022-06-25 07:03:39.196674
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 8
    str_0 = '7jK'
    bool_1 = False
    bytes_0 = b'\xdc\xad,\xdb\xa0\xa5\x177\x08p\xb1\x9b\x17\xd5r'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()
    action_module = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-25 07:03:47.359493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = 69
    str_0 = 'A2W'
    bool_1 = False
    bytes_0 = b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)


# Generated at 2022-06-25 07:04:25.884019
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Init
    bool_0 = True
    int_0 = 73
    str_0 = 'mM'
    list_0 = ['mM', 73, True, True]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
    # Test properties
    assert action_module_0.TRANSFERS_FILES == False
    assert action_module_0.VALID_ARGS == frozenset({'key', 'parents'})
    # Test functions
    var_1 = True
    task_vars_0 = dict()
    var_2 = action_module_0.run(var_1, task_vars_0)
    del(bool_0)
    del(int_0)


# Generated at 2022-06-25 07:04:32.639115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 69
    str_0 = 'A2W'
    bool_1 = False
    bytes_0 = b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
    assert (action_module_0._connection == int_0)
    assert (action_module_0._task == str_0)
    assert (action_module_0._play_context == int_0)
    assert (action_module_0._loader == list_0)

# Generated at 2022-06-25 07:04:37.360025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 69
    str_0 = 'A2W'
    bool_1 = False
    bytes_0 = b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
    del action_module_0

# Generated at 2022-06-25 07:04:41.998443
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing ActionModule')

    test_case_0()
    print('Passed all test cases!')

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:04:47.840298
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = 59
    str_0 = 'Kw6{z\xd4\xe6\x0f\xc5'
    bool_1 = True
    bytes_0 = b'#\xdd\x81\xf4\xc4\xab+j\x82\x99\xf1'
    list_0 = [bool_0, bytes_0, bool_1]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:04:55.420759
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 68
    str_0 = 'D#'
    bool_1 = False
    bytes_0 = b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
    action_module_0.run()


# Generated at 2022-06-25 07:05:04.849286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    value_0 = '\x9d\x87\xd1\x89\x91\x99\xa8\x01\x86\x9c\xd2\x8c\xaa\xc1\x99\x92\x8b\x87\x1a\x13\xff\xf8\x87\xf3\xcf\xe1'
    key_0 = '\xde\x0f\x9d\x84\xcb\x97\xd6\x85\x9c\xc9\xd9\x14\xdd\x99\x85'
    parents_0 = '\x07\xbd\x84\x9e\x87\x82\xbf\x1f\x98\x86\xc3\x2f'
    bool_0 = False

# Generated at 2022-06-25 07:05:12.582420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 69
    str_0 = 'A2W'
    bool_1 = False
    bytes_0 = b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
    action_module_0.run()

# Generated at 2022-06-25 07:05:20.707964
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 69
    str_0 = 'A2W'
    bool_1 = False
    bytes_0 = b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)

# Generated at 2022-06-25 07:05:30.262386
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 69
    str_0 = 'A2W'
    bool_1 = False
    bytes_0 = b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
    dict_0 = action_module_run(dict())
    assert dict_0['add_group'] == '69-A2W'


# Generated at 2022-06-25 07:06:47.013258
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # parameters
    int_0 = 69
    str_0 = 'A2W'
    int_1 = 69
    list_0 = [False, b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92', False, False]
    str_1 = 'A2W'
    tuple_0 = ()
    # call function under test
    action_module_0 = ActionModule(int_0, str_0, int_1, list_0, str_1, tuple_0)
    assert isinstance(action_module_0, ActionBase)


# Generated at 2022-06-25 07:06:55.149301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 69
    str_0 = 'A2W'
    bool_1 = False
    bytes_0 = b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)


# Generated at 2022-06-25 07:07:02.699112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 69
    str_0 = 'A2W'
    bool_1 = False
    bytes_0 = b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
    return action_module_0

# Generated at 2022-06-25 07:07:08.722948
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 69
    str_0 = 'A2W'
    bool_1 = False
    bytes_0 = b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
    test_case_0()

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:07:16.863767
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 69
    str_0 = 'A2W'
    bool_1 = False
    bytes_0 = b'\xad\xbefCC\xa3@k\xad"\xdb\xcb\xafe\x92'
    list_0 = [bool_1, bytes_0, bool_1, bool_1]
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)


# Generated at 2022-06-25 07:07:20.471357
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'abc'
    action_module_0 = ActionModule(str_0)
    str_1 = '123'
    action_module_0.run(str_1)

# Generated at 2022-06-25 07:07:25.142603
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = 87
    str_0 = 'L[c\xca\xca\xca\xca\xca\xca'
    bool_1 = False
    bytes_0 = b'th\x1d\x9a{8\x12\xa7\x15\xe1\x86y\x1d\xf0\x9f\x8a\xdc'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0, bytes_0]
    tuple_0 = (int_0, bytes_0, bool_1)
    action_module_0 = ActionModule(int_0, str_0, int_0, list_0, str_0, tuple_0)
    assert action_module_0.TRANSFERS_FIL