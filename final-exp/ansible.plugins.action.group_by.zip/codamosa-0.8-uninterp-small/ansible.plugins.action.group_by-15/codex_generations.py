

# Generated at 2022-06-25 06:57:37.001374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars_0 = dict()
    task_vars_0['item'] = dict()
    action_module_0 = ActionModule(None, None, None, None, None, None)
    test_case_0 = {
        'add_group': 'all',
        'parent_groups': ['all'],
        'changed': False
    }
    assert test_case_0 == action_module_0.run(None, task_vars_0)

# Generated at 2022-06-25 06:57:48.353902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    bool_0 = False
    bool_1 = False
    list_0 = []
    int_0 = -12
    list_1 = []
    bytes_0 = b'\xcc\xaf\x8d\x12\x92\xd4\xe4\x8e\xb1\xda\xbc\xac\xa8\x83\xbc'
    str_0 = '=1\x99\x04u\x97\x84\x90\xde\xde>\x141\x00\x8c'
    action_module_0 = ActionModule(bool_0, bool_1, list_0, int_0, list_1, bytes_0, str_0)


# Generated at 2022-06-25 06:57:48.909704
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 06:58:00.542142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = [bool_0, bool_0]
    int_0 = 92
    bytes_0 = b'\x8e\xd5)\x9b\xac\xb7\x94f'
    str_0 = 'k,\n\\'
    action_module_0 = ActionModule(bool_0, list_0, int_0, list_0, bytes_0, str_0)
    dict_0 = dict()
    dict_0['key'] = 'foo'
    dict_0['parents'] = ['bar']
    dict_0['dynamic'] = 'all'
    dict_0['foo'] = 'bar'
    dict_1 = dict()
    dict_1['dynamic'] = 'all'
    dict_1['foo'] = 'bar'
    dict

# Generated at 2022-06-25 06:58:10.187188
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    list_0 = [(True, True), (False, False)]
    int_0 = 474
    list_1 = [True, True, True]
    bytes_0 = b'\xfc\x98\xee\x9fn\xe6\xb1\x8d\xfd\xaa\x87\xdd\x91x\x9a\x81.\xf5\xbf\xae\xfb\xc4\xae!R'
    str_0 = 'fv\x01'
    action_module_0 = ActionModule(bool_0, list_0, int_0, list_1, bytes_0, str_0)
    assert (action_module_0._task.action == 'action_module')

# Generated at 2022-06-25 06:58:12.577059
# Unit test for constructor of class ActionModule
def test_ActionModule():
    foo = "bar"
    baz = 42
    action_module_0 = ActionModule(foo, baz)
    assert(isinstance(action_module_0, ActionModule))


# Generated at 2022-06-25 06:58:19.486881
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = bool
    list_0 = [bool_0, bool_0]
    int_0 = 92
    list_0_0 = [bool_0, bool_0]
    bytes_0 = b'\x8e\xd5)\x9b\xac\xb7\x94f'
    str_0 = 'k,\n\\'
    action_module_0 = ActionModule(bool_0, list_0, int_0, list_0_0, bytes_0, str_0)
    result_0 = action_module_0.run(None, None)
    assert bool_0 is bool


# Generated at 2022-06-25 06:58:25.483822
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = [bool_0, bool_0]
    int_0 = 92
    bytes_0 = b'\x8e\xd5)\x9b\xac\xb7\x94f'
    str_0 = 'k,\n\\'
    action_module_0 = ActionModule(bool_0, list_0, int_0, list_0, bytes_0, str_0)

    assert isinstance(action_module_0, ActionModule), "Argument is not an instance of class ActionModule"

# Generated at 2022-06-25 06:58:33.051934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = [bool_0, bool_0]
    int_0 = 92
    bytes_0 = b'\x8e\xd5)\x9b\xac\xb7\x94f'
    str_0 = 'k,\n\\'
    action_module_0 = ActionModule(bool_0, list_0, int_0, list_0, bytes_0, str_0)
    dict_0 = {}
    tmp = None

    # Call method run of class ActionModule with arguments dict_0 and tmp
    # AssertionError: Argument tmp to method run of class ActionModule is expected to be of type NoneType, but is <class 'dict'>, with value: {}

# Generated at 2022-06-25 06:58:40.852843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = dict(a=1, b=2)
    action_module_0 = ActionModule(None, None, None, None, None, None)
    result = action_module_0.run(tmp, task_vars)
    assert result == dict(changed=False, msg='Not a file or URI', parent_groups=['all'], add_group='example-new-group')

# Test the static property _VALID_ARGS of class ActionModule

# Generated at 2022-06-25 06:58:49.354533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    vars_0 = {
    }
    result_0 = action_module_0.run(tmp=None, task_vars=vars_0)
    assert result_0['failed'] == True
    assert result_0['msg'] == 'the \'key\' param is required when using group_by'
    assert result_0['changed'] == False


# Generated at 2022-06-25 06:58:50.325441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    pass

# Generated at 2022-06-25 06:58:55.455482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with arguments key
    ActionModule_run_arg_key = 'hostname'
    # Test with arguments parents
    ActionModule_run_arg_parents = 'all'
    tmp = None
    task_vars = None
    v = ActionModule_run_arg_key
    v = ActionModule_run_arg_parents
    result = ActionModule.run(v,tmp,task_vars)
    assert result == None


    return None

# Generated at 2022-06-25 06:59:03.098043
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import PY3, text_type
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = dict()
    assert isinstance(action_module_0.run(tmp_0, task_vars_0), dict)
    assert isinstance(action_module_0.run(tmp_0, task_vars_0), dict)
    assert isinstance(action_module_0.run(tmp_0, task_vars_0), dict)

# Generated at 2022-06-25 06:59:03.993364
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionBase)


# Generated at 2022-06-25 06:59:06.333351
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    with pytest.raises(NotImplementedError):
        action_module_0.run()


# Generated at 2022-06-25 06:59:09.227615
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 is not None

# Generated at 2022-06-25 06:59:10.182831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:59:11.356982
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run_0 = ActionModule()
    action_module_run_0.run()

# Generated at 2022-06-25 06:59:17.509335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    host_vars = {}
    task_vars = {
        'hostvars': host_vars,
    }
    group_name = 'test_group'
    host_name = 'test_host'
    host_vars[host_name] = {
        'key_name': group_name
    }
    result = action_module.run(task_vars={'host': host_name}, task_vars=task_vars)
    yield assert_equal, result['add_group'], group_name
    yield assert_equal, result['parent_groups'], ['all']

# Generated at 2022-06-25 06:59:26.182702
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Simple test to initialize an instance of ActionModule
    # TODO: Fix an appropriate test
    list_0 = []
    int_0 = 2363
    set_0 = set()
    str_0 = '6=v!eE4|g9C'
    action_module_0 = ActionModule(list_0, int_0, int_0, set_0, str_0, int_0)
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 06:59:33.570169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    int_0 = 0
    set_0 = set()
    str_0 = 'nR<7E2M}'
    action_module_0 = ActionModule(list_0, int_0, int_0, set_0, str_0, int_0)
    var_0 = action_run()
    print(var_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:59:41.325075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    int_0 = -202
    int_1 = -1710
    set_0 = set()
    str_0 = 'h=t+b9<;mD'
    action_module_0 = ActionModule(list_0, int_0, int_1, set_0, str_0, int_0)

    assert action_module_0._connection._shell.SHELL_FAMILY == 'csh'
    assert action_module_0._shared_loader_obj._task._action == 'group_by'
    assert action_module_0._config._shell.SHELL_FAMILY == 'zsh'
    assert action_module_0._task.action == 'group_by'


# Generated at 2022-06-25 06:59:48.617163
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_2 = dict()
    dict_2['key'] = 'key'
    dict_2[str_0] = set_0
    action_module_1 = ActionModule(list_0, int_0, int_0, set_0, str_0, int_0)
    var_1 = action_module_0.run(var_0, dict_2)

# Generated at 2022-06-25 06:59:52.585887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    int_0 = -8088
    set_0 = set()
    str_0 = ']7q3-k'
    action_module_0 = ActionModule(list_0, int_0, int_0, set_0, str_0, int_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:59:55.488147
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    int_0 = 7593
    set_0 = set()
    str_0 = '<q3J2{/4D,'
    action_module_0 = ActionModule(list_0, int_0, int_0, set_0, str_0, int_0)
    action_module_0.run()


# Generated at 2022-06-25 07:00:03.570717
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    str_0 = 'e'
    str_1 = 'a'
    str_2 = 'o'
    str_3 = 'g'
    str_4 = '5'
    str_5 = 'l'
    str_6 = 'o'
    str_7 = 'a'
    str_8 = 'A'
    str_9 = '6'
    str_10 = '7'
    str_11 = 'f'
    str_12 = '9'
    str_13 = '@'
    str_14 = 'q'
    str_15 = 'b'
    str_16 = '7'
    str_17 = 'P'
    str_18 = 'K'
    str_19 = 'r'
    str_20 = 'v'

# Generated at 2022-06-25 07:00:11.838038
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    int_0 = 4374
    str_0 = ','
    int_1 = 0
    list_0 = []
    str_1 = '4_[x'
    int_2 = -64800544
    action_module_0 = ActionModule(list_0, int_0, int_1, set_0, str_1, int_2)
    assert_equals(action_module_0._task.no_log, 0)
    assert_equals(action_module_0._task._role, None)

# Generated at 2022-06-25 07:00:19.821885
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = {'parent_groups': ['all'], 'changed': False, 'add_group': 'top'}
    action_module_0 = ActionModule(str_0)
    cls_0 = action_module_0.__class__
    assert_equals(cls_0, action_module_0.run())
    assert_equals({'parent_groups': ['all'], 'changed': False, 'add_group': 'top'}, action_module_0.run())
    assert_equals(action_module_0.run(), action_module_0.run())

# Generated at 2022-06-25 07:00:21.999304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Running unit test for constructor of ActionModule')
    assert(isinstance(ActionModule(list, int, int, set, str, int), ActionModule))

# Generated at 2022-06-25 07:00:34.008139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    int_0 = 9077
    set_0 = set()
    str_0 = '-&A\\sO\\o~N9'
    action_module_0 = ActionModule(list_0, int_0, int_0, set_0, str_0, int_0)
    var_0 = action_module_0.run()
    assert var_0['failed'] == False
    assert var_0['add_group'] == 'ansible'
    



# Generated at 2022-06-25 07:00:41.993015
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    int_0 = 2288
    int_1 = 1130
    set_0 = set()
    str_0 = '9+n!eE4|g9C'
    int_2 = 4043
    action_module_0 = ActionModule(list_0, int_0, int_1, set_0, str_0, int_2)
    action_module_0_run_0 = action_module_0.run()

# Bug found with afl

# Generated at 2022-06-25 07:00:49.625246
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_1 = []
    int_1 = -7711
    int_2 = -6711
    set_1 = set()
    str_1 = '6=v!eE4|g9C'
    int_3 = -3755
    action_module_1 = ActionModule(list_1, int_1, int_2, set_1, str_1, int_3)
    group_name_0 = action_module_1._task.args.get('key')
    dict_0 = action_module_1._task.args
    parent_groups_0 = dict_0.get('parents', ['all'])
    if isinstance(parent_groups_0, string_types):
        parent_groups_0 = [parent_groups_0]
    # Test for verifiying of lines 'result[\'changed\

# Generated at 2022-06-25 07:00:53.937690
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    int_0 = 2623
    int_1 = 4268
    set_0 = set()
    str_0 = '4Q2?$D&(<+'
    int_2 = 829
    action_module_0 = ActionModule(list_0, int_0, int_1, set_0, str_0, int_2)
    action_module_0.run()


# Generated at 2022-06-25 07:00:57.186149
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 is not None


# Generated at 2022-06-25 07:00:58.517354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(var_0) is dict
    assert len(var_0) == 3


# Generated at 2022-06-25 07:01:05.177714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    int_0 = -150
    set_0 = set()
    str_0 = 'Z[N\\$2#N1%'
    action_module_0 = ActionModule(list_0, int_0, int_0, set_0, str_0, int_0)
    action_run(action_module_0, str_0, str_0)


# Generated at 2022-06-25 07:01:06.552955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-25 07:01:09.870567
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    int_0 = 2464
    int_1 = 1255
    set_0 = set()
    str_0 = ';g|/R %'
    int_2 = 2122
    test_case_0()
    return 0

# Non-main functions


# Generated at 2022-06-25 07:01:12.166179
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert(var_0 != None)

# Generated at 2022-06-25 07:01:29.060479
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # init
    action_module_0 = ActionModule()
    # return
    name = get_class_name(action_module_0)
    if name == "ActionModule":
        return True
    else:
        return False


# Generated at 2022-06-25 07:01:32.198257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    int_0 = 9
    set_0 = set()
    str_0 = '8nJy'
    action_module_0 = ActionModule(list_0, int_0, int_0, set_0, str_0, int_0)
    tuple_0 = ()
    assert action_module_0.run(tuple_0) is True


# Generated at 2022-06-25 07:01:41.536870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # <Input data 1>
    list_0 = []
    int_0 = -3422
    int_1 = -1586
    set_0 = set()
    str_0 = 's"F"<'
    int_2 = 3549
    action_module_0 = ActionModule(list_0, int_0, int_1, set_0, str_0, int_2)
    action_module_0.run()
    # <Input data 2>
    list_0 = []
    int_0 = -5530
    int_1 = -5125
    set_0 = set()
    str_0 = '6=v!eE4|g9C'
    int_2 = 2363

# Generated at 2022-06-25 07:01:45.704902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    int_0 = 6683
    str_0 = '+c%>T}<JQ7l]LL'
    set_0 = set()
    action_module_0 = ActionModule(list_0, int_0, int_0, set_0, str_0, int_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:01:47.414485
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule(list(), int(), int(), set(), str(), int())

# Generated at 2022-06-25 07:01:51.336389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:01:56.200631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    int_0 = 2363
    set_0 = set()
    str_0 = '6=v!eE4|g9C'
    action_module_0 = ActionModule(list_0, int_0, int_0, set_0, str_0, int_0)
    tmp_0 = None
    task_vars_0 = dict()
    var_0 = action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:02:00.640327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    action_run_0 = ActionModule(dict_0, dict_0)
    var_0 = action_run()
    test_case_0()



# Generated at 2022-06-25 07:02:06.400282
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    int_0 = 489
    int_1 = q8
    set_0 = set()
    str_0 = '&0_i1Xk'
    result_Popen = Popen(list_0, int_0, int_1, set_0, str_0, int_0)
    assert result_Popen == None


# Generated at 2022-06-25 07:02:09.548921
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = {"key": "2^s_Xhx!d#>/VqB|qK", "parents": "0h8U6W;^v,0*di@Z"}
    test_case_0(args)

# Generated at 2022-06-25 07:02:35.675674
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    
    

if __name__ == '__main__':
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 07:02:42.947356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = ['f8G-)6!|U1']
    int_0 = 7361
    int_1 = 7242
    set_0 = set()
    str_0 = 'h4?p4Cw1EN'
    int_2 = 9053
    action_module_0 = ActionModule(list_0, int_0, int_1, set_0, str_0, int_2)
    var_0 = action_module_0.run()
    print(var_0)
    assert var_0 == {}

# Generated at 2022-06-25 07:02:50.314423
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (action_module_0.__init__)
    assert action_module_0.action_plugins == ['/Users/hc/Projects/Ansible/ansible/plugins/action']
    assert action_module_0.basedir == '/Users/hc/Projects/Ansible/ansible'
    assert action_module_0.connection == 'smart'
    assert action_module_0.directive_plugin_list == ['/Users/hc/Projects/Ansible/ansible/plugins/action']
    assert action_module_0.directory_layout == 'action'
    assert action_module_0.display.deprecations == ['default']
    assert action_module_0.filesystem_lock == None
    assert action_module_0.host_hash_val == '0'
    assert action_module

# Generated at 2022-06-25 07:02:57.316402
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = list()
    var_1 = 2363
    var_2 = 2363
    var_3 = set()
    var_4 = '6=v!eE4|g9C'
    var_5 = 2363
    assignment_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
    del var_0
    del var_1
    del var_2
    del var_3
    del var_4
    del var_5
    del assignment_0

# Generated at 2022-06-25 07:03:00.065713
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    int_0 = -8479
    set_0 = set()
    str_0 = '!@kM3Xdc'
    action_module_0 = ActionModule(list_0, int_0, int_0, set_0, str_0, int_0)


# Generated at 2022-06-25 07:03:00.934757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-25 07:03:06.635390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Run action
    action_module_0 = ActionModule()
    test_0 = action_run()

    # Test if function return the expected value
    assert test_0 == None


# Generated at 2022-06-25 07:03:10.544698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    int_0 = 2087
    int_1 = 9097
    set_0 = set()
    str_0 = '<9xH'
    int_2 = 5311
    action_module_0 = ActionModule(list_0, int_0, int_1, set_0, str_0, int_2)
    assert_equal(action_module_0.tmp, set_0)
    assert_equal(action_module_0.task_vars, list_0)
    assert_equal(action_module_0.play_context, int_0)
    assert_equal(action_module_0.task, int_1)
    assert_equal(action_module_0.shared_loader_obj, str_0)

# Generated at 2022-06-25 07:03:13.586185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    int_0 = 3964
    int_1 = 4064
    set_0 = set()
    str_0 = '2_9T}T/^I:$@'
    action_module_0 = ActionModule(list_0, int_0, int_1, set_0, str_0, int_0)


# Generated at 2022-06-25 07:03:19.439746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    int_0 = 5
    set_0 = set()
    str_0 = '-'
    action_module_0 = ActionModule(list_0, int_0, int_0, set_0, str_0, int_0)

    action_module_0.run()


# Generated at 2022-06-25 07:04:25.659092
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_1 = []
    int_2 = 7258
    int_3 = 1374
    set_1 = set()
    str_1 = '=Z.C`5'
    int_5 = 6478
    action_module_1 = ActionModule(list_1, int_2, int_3, set_1, str_1, int_5)
    var_6 = action_module_1.run()
    assert var_6 == None

# Generated at 2022-06-25 07:04:29.620468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        list_0 = []
        int_0 = 2861
        set_0 = set()
        str_0 = ','
        action_module_0 = ActionModule(list_0, int_0, int_0, set_0, str_0, int_0)
        result_0 = action_module_0.run()
        pass
    except:
        raise


# Generated at 2022-06-25 07:04:30.369575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 07:04:32.996235
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    int_0 = 3162
    set_0 = set()
    str_0 = '|nZ"`2<I1+'
    action_module_0 = ActionModule(list_0, int_0, int_0, set_0, str_0, int_0)
    int_1 = action_run()
    assert int_1 == 8

if (__name__ == '__main__'):
    test_ActionModule_run()

# Generated at 2022-06-25 07:04:39.514095
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    int_0 = 564
    set_0 = set('^rC>')
    str_0 = 'R'
    action_module_0 = ActionModule(list_0, int_0, int_0, set_0, str_0, int_0)
    value_0 = action_run()
    assert (value_0['add_group'] == 'R'.replace(' ', '-'))


# Generated at 2022-06-25 07:04:44.867505
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Input parameters
    list_0 = []
    int_0 = 3867
    int_1 = 993
    set_0 = set()
    str_0 = 'y+Xb|>o;P!-'
    int_2 = 183
    # Invoke constructor of class ActionModule with parameters
    action_module_0 = ActionModule(list_0, int_0, int_1, set_0, str_0, int_2)


# Generated at 2022-06-25 07:04:48.026812
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing constructor of class ActionModule")
    list_0 = []
    int_0 = 2363
    set_0 = set()
    str_0 = '6=v!eE4|g9C'
    action_module_0 = ActionModule(list_0, int_0, int_0, set_0, str_0, int_0)


# Generated at 2022-06-25 07:04:51.691603
# Unit test for constructor of class ActionModule
def test_ActionModule():
    constructor_0 = ActionModule(list_0, int_0, int_0, set_0, str_0, int_0)
    return constructor_0


# Generated at 2022-06-25 07:04:53.660158
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    var_0 = action_run()
    if var_0 == False:
        assert False
    else:
        assert True


# Generated at 2022-06-25 07:05:04.750182
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    int_0 = 2363
    set_0 = set()
    str_0 = '6=v!eE4|g9C'
    action_module_0 = ActionModule(list_0, int_0, int_0, set_0, str_0, int_0)
    # Check variable action_module_0 is initialized properly
    assert(action_module_0._task.action == str_0)
    assert(action_module_0.name == int_0)
    assert(action_module_0.disabled == int_0)
    assert(action_module_0.TRANSFERS_FILES == int_0)
    assert(action_module_0._valid_args == set_0)
    # Constructor does not return a value

# Unit test of function run from cla

# Generated at 2022-06-25 07:07:25.770401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    int_0 = 8342
    int_1 = -1675
    set_0 = set()
    str_0 = '\"7h@G'
    int_2 = -246
    action_module_0 = ActionModule(list_0, int_0, int_1, set_0, str_0, int_2)
