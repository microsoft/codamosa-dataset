

# Generated at 2022-06-25 06:57:33.468309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:57:34.342568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0() == None

# Generated at 2022-06-25 06:57:38.142532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}

    # Make some changes to the module_utils/facts.py file if it exists
    # action_module_1 = ActionModule(0, 0, 0, 0, 0, 0)
    # action_module_1.run(task_vars)

# Generated at 2022-06-25 06:57:38.920919
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:57:41.865786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:57:51.451284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'One of the nested variables was undefined. The error was: %s'
    set_0 = None
    bytes_0 = None
    bytes_1 = None
    list_0 = [str_0, str_0, bytes_0, set_0]
    int_0 = 127
    action_module_0 = ActionModule(str_0, set_0, bytes_0, bytes_1, list_0, int_0)
    tmp_0 = None
    task_vars_0 = None
    class ActionBase_0:
        def get_loader(self):
            x = 'Loader()'
            return x

    action_module_0.action = ActionBase_0()
    result_0 = action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 06:57:59.113881
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'One of the nested variables was undefined. The error was: %s'
    set_0 = None
    bytes_0 = None
    bytes_1 = None
    list_0 = [str_0, str_0, bytes_0, set_0]
    int_0 = 127
    action_module_0 = ActionModule(str_0, set_0, bytes_0, bytes_1, list_0, int_0)

    action_module_0.run()

# Generated at 2022-06-25 06:58:00.172140
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:58:09.905738
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'One of the nested variables was undefined. The error was: %s'
    set_0 = None
    bytes_0 = None
    bytes_1 = None
    list_0 = [str_0, str_0, bytes_0, set_0]
    int_0 = 127
    action_module_0 = ActionModule(str_0, set_0, bytes_0, bytes_1, list_0, int_0)
    tmp_0 = None
    task_vars_0 = None
    str_1 = 'One of the nested variables was undefined. The error was: %s'
    assert action_module_0.run(tmp_0, task_vars_0) == {'failed': True, 'changed': False, 'msg': str_1}


# Generated at 2022-06-25 06:58:10.738047
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:58:14.918407
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:58:15.806998
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}


# Generated at 2022-06-25 06:58:17.669315
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Call the run method of class ActionModule
    action = ActionModule()
    action.run(var_0, var_0)


# Generated at 2022-06-25 06:58:19.103551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}
    x_0 = ActionModule(var_0)


# Generated at 2022-06-25 06:58:19.884017
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:58:20.777896
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:58:23.194986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}
    var_1 = {}
    var_1 = ActionModule()
    var_0['ActionModule-0'] = var_1


# Generated at 2022-06-25 06:58:31.361716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = {
        'group_by':{
                                                        "key": "os_service_name",
                                                        "parents": [
                                                            "os_service_name"
                                                            "os_version"
                                                        ]
                                                    }
    }
    var_0 = {}
    ansible_task = {}
    ansible_task['vars'] = {}
    ansible_task['host'] = host

    res = ActionModule.run(var_0,ansible_task)
    assert res['parent_groups'][0] == "os_service_name"
    assert res['parent_groups'][1] == "os_version"
    assert res['add_group'] == "os_service_name"

# Generated at 2022-06-25 06:58:34.795372
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = {}
    test_case_0()
    test_case_1()

    #Test for the case which is the default action
    action = ActionModule(tmp, task_vars)




# Generated at 2022-06-25 06:58:38.617204
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    for case in [
        {"key": "test_arg_0"}
    ]:
        print(case)
        assert test_case_0(case) == True

# Generated at 2022-06-25 06:58:47.194965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = {}
    var_1['inv'] = {}
    var_2 = {}
    var_2['0'] = {}
    var_2['1'] = {}
    var_2['1']['hostname'] = {}
    var_2['1']['hostname']['0'] = {}
    var_2['1']['hostname']['0']['ansible_host'] = '127.0.0.1'
    var_2['1']['hostname']['1'] = {}
    var_2['1']['hostname']['1']['ansible_host'] = '192.168.0.1'
    var_2['1']['hostname']['2'] = {}

# Generated at 2022-06-25 06:58:56.260981
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    target_i = ActionModule(
        'task',
        {'name': 'key',
         'value': 'value',
         'parents': 'value',
         '_ansible_module_name': 'setup'},
        {'module': 'setup',
         'module_name': 'setup',
         'parent_args': {'module': 'setup'},
         '_ansible_syslog_facility': 'LOG_USER',
         'action': 'group_by',
         'remote_addr': '127.0.0.1',
         'connection': 'local',
         'delegate_to': '127.0.0.1',
         'ansible_forks': 5},
        '12345',
        'setup')
    target_i.module_args = {'key': 'value'}
    res

# Generated at 2022-06-25 06:59:02.251744
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    var_0 = {}
    var_1 = {}
    var_1['groups'] = var_0

    var_2 = {}
    var_2['vars'] = {}
    var_2['hostvars'] = {}
    var_2['all'] = var_1
    var_3 = {}
    var_3['group_name'] = ''
    var_3['parent_groups'] = []
    var_3['changed'] = True

    var_4 = {}
    var_4['groups'] = var_0
    var_5 = {}
    var_5['vars'] = {}
    var_5['hostvars'] = {}
    var_5['all'] = var_4
    var_6 = {}
    var_6['add_group'] = 'test-group'

# Generated at 2022-06-25 06:59:07.447817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    var_0 = ActionModule(var_0)
    var_1 = {}
    var_2 = {}
    var_2[''] = {'key': 'var_1', 'parents': 'var_2'}
    var_0.run(var_1, var_2)

# Generated at 2022-06-25 06:59:08.273465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (var_0 == {})


# Generated at 2022-06-25 06:59:09.370075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:59:11.094168
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")
    test_case_0()

# Generated at 2022-06-25 06:59:15.991381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    var_1 = None
    var_1 = {}
    var_2 = None
    var_2 = {}
    var_0.update(var_1)
    return var_0


# Generated at 2022-06-25 06:59:20.226654
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0()

# Unit tests for class ActionModule

# Generated at 2022-06-25 06:59:24.334014
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hash_0 = hash_1 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    result = hash_0.run(tmp_0, task_vars_0)
    assert result == hash_1.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 06:59:30.585930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    action_module_0 = ActionModule(dict_0)
    # Check that run returns a dict
    assert(isinstance(action_module_0.run(), dict))

# Generated at 2022-06-25 06:59:36.740163
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.TRANSFERS_FILES == False
    assert action_module_0._VALID_ARGS == frozenset(('key', 'parents'))


# Generated at 2022-06-25 06:59:43.805754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Sk'
    float_0 = 85.3
    set_0 = set()
    action_module_0 = ActionModule(None, set_0, True, float_0, None, float_0)
    str_1 = '#7bT'
    list_0 = []

# Generated at 2022-06-25 06:59:44.894791
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  action_module_0 = ActionModule()
  # Call method run of class ActionModule
  action_module_0.run()

# Generated at 2022-06-25 06:59:49.601238
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    action_module_1 = ActionModule(None, None, None, None, None, None)
    assert action_module_1.run() != action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 06:59:53.881596
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xe9'
    bool_0 = False
    set_0 = set()
    bool_1 = False
    float_0 = 0.250478
    action_module_0 = ActionModule(bool_0, set_0, bool_1, float_0, set_0, float_0)
    var_0 = action_module_0._transfer_files()
    var_1 = action_module_0.run()

# Generated at 2022-06-25 06:59:55.243436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test method run of class ActionModule")
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 07:00:04.968988
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf76\xaa\xe0\x00\xbc\x03\xae`\x1f\xbd\x04\x00\x1a\xd2\x10\xe5%'
    dict_0 = {}
    set_0 = set()
    float_0 = -3.402823e+38
    bool_0 = True
    bool_1 = False
    action_module_0 = ActionModule(bool_0, set_0, bool_1, float_0, set_0, float_0)
    action_module_1 = ActionModule(bytes_0, action_module_0, dict_0, action_module_0, dict_0, dict_0)
    assert not hasattr(action_module_1, '__getnewargs__')
    str_

# Generated at 2022-06-25 07:00:13.101850
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    bool_0 = True
    set_0 = set()
    bool_1 = True
    float_0 = -0.0
    action_module_0 = ActionModule(bytes_0, bool_0, set_0, bool_1, float_0, set_0, float_0)
    assert action_module_0._play_context.become_pass == ''
    assert action_module_0._play_context.password == ''
    assert action_module_0._play_context.remote_addr == '16.0.0.0'
    assert action_module_0._play_

# Generated at 2022-06-25 07:00:14.228053
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:00:23.818437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    set_0 = set()
    action_module_0 = ActionModule(bytes_0, set_0, set_0, set_0)


# Generated at 2022-06-25 07:00:30.108090
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test data
    key = '9n6mZcB2Qm5e'
    parents = ['Fw8m6Cz1Bp0U', '9n6mZcB2Qm5e']
    str_0 = 'A8jQFVsMzf'
    action_module_0 = ActionModule(str_0)
    var_1 = action_module_0.run(key=key, parents=parents)

# Generated at 2022-06-25 07:00:39.693808
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_1 = b'\x12\x1c\xc0o\x13\xce\xf9\x9f\xee\x0e\x7f'
    list_0 = []
    bool_2 = True
    dict_1 = {}
    dict_2 = {}
    str_1 = 'l\xcd =\x0e[\x9d'
    set_1 = set()
    bool_3 = True
    float_1 = -1343.20932419
    dict_3 = {}
    dict_4 = {}
    str_2 = '\x8f\x1c\x9f\x05\xb3\x8b\x95\x1cf\xa6\xe5\x0b'
    set_2 = set()
    dict_5 = {}


# Generated at 2022-06-25 07:00:48.925621
# Unit test for constructor of class ActionModule
def test_ActionModule():
    string_0 = 'P8Hv+|o&u"7,=T'
    bytes_0 = b'\x0e\x1e\x8d\x18'
    bool_0 = True
    set_0 = set()
    bool_1 = False
    float_0 = 4.0642888
    action_module_0 = ActionModule(string_0, bytes_0, bool_0, set_0, bool_1, float_0)

    assert action_module_0._play_context == string_0
    assert action_module_0._shared_loader_obj == bytes_0
    assert action_module_0._task == bool_0
    assert action_module_0._loader == set_0
    assert action_module_0._connection == bool_1
    assert action_module_0._

# Generated at 2022-06-25 07:00:55.054816
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x14\xd9\xb3\xe8\x92\x19'
    bool_0 = True
    set_0 = set()
    bool_1 = True
    float_0 = -1718.249773
    action_module_0 = ActionModule(bool_0, set_0, bool_1, float_0, set_0, float_0)
    tuple_0 = (action_module_0,)
    str_0 = '9XA>'
    list_0 = []
    action_module_1 = ActionModule(bytes_0, action_module_0, tuple_0, action_module_0, str_0, list_0)
    action_module_1.run()


# Generated at 2022-06-25 07:01:02.773766
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_1 = b' \xb8\xbcX\xbc\xf3\xbcO\xbc\xb3\xd3\xbc\x0b\xb8\xbc\xc4\xc4\xb5\xbc5\xbc\xbc\xc4\xbc'
    bool_2 = False
    set_1 = set()
    float_1 = -1975.756333
    action_module_2 = ActionModule(bytes_1, bool_2, set_1, float_1, set_1, float_1)
    assert action_module_2


# Generated at 2022-06-25 07:01:03.348466
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:01:10.832505
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x1f\xbb'
    bool_0 = True
    set_0 = set()
    bool_1 = True
    float_0 = -1011.686723
    action_module_0 = ActionModule(bool_0, set_0, bool_1, float_0, set_0, float_0)
    tuple_0 = (action_module_0,)
    str_0 = '@!\x94\xab\x9c\x91'
    dict_0 = {}
    action_module_1 = ActionModule(bytes_0, action_module_0, tuple_0, action_module_0, str_0, dict_0)

# Generated at 2022-06-25 07:01:13.434336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x1b\xa4\x1d\xe0'
    str_0 = 'lg$'
    action_module_0 = ActionModule(bytes_0, str_0, bytes_0, bytes_0)
    assert(action_module_0.run() != None)

# Generated at 2022-06-25 07:01:23.403553
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf6c\x1c\x1d'
    bool_0 = True
    set_0 = set()
    bool_1 = True
    float_0 = -631.8952
    action_module_0 = ActionModule(bool_0, set_0, bool_1, float_0, set_0, float_0)
    tuple_0 = (action_module_0,)
    str_0 = '\xbf\xa0\x8f\x86'
    dict_0 = {}
    action_module_1 = ActionModule(bytes_0, action_module_0, tuple_0, action_module_0, str_0, dict_0)
    var_0 = action_module_1.run()
    assert var_0 == dict

# Generated at 2022-06-25 07:01:38.436937
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # An object of ActionModule
    action_module_0 = ActionModule()
    print(action_module_0)

if __name__ == '__main__':
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 07:01:39.084629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    TestActionModule = ActionModule()



# Generated at 2022-06-25 07:01:41.994121
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        bytes_0 = b'\xac\x1d\x17\x15'
        bool_0 = False
        set_0 = set()
        float_0 = -731.439238
        action_module_0 = ActionModule(bytes_0, bool_0, set_0, float_0, set_0, float_0)
    except:
        assert True


# Generated at 2022-06-25 07:01:51.954974
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    results = {}
    module = ActionModule()
    # TODO: detect and skip the test if the plugin is not available
    #       if !module.is_plugin_available('<plugin>'):
    #           return results
    execute_command = module.get_bin_path('<command>', True, ['/path/to/command'])
    args = {}
    args['<arg>'] = '<argvalue>'
    # module.run(<module-args>, <task-vars>, <tmp-path>)
    result = module.run('<module-args>', {}, '/path/to/tmp')
    results['<result>'] = result['stdout']
    return results

# Generated at 2022-06-25 07:02:02.295396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    set_0 = set()
    bool_1 = True
    float_0 = -1177.556158
    action_module_0 = ActionModule(bool_0, set_0, bool_1, float_0, set_0, float_0)
    tmp_0 = None
    var_0 = action_module_0.run(tmp_0)
    var_1 = action_module_0.run(tmp_0)
    var_2 = action_module_0.run(tmp_0)
    var_3 = action_module_0.run(tmp_0)
    var_4 = action_module_0.run(tmp_0)
    var_5 = action_module_0.run(tmp_0)

# Generated at 2022-06-25 07:02:11.422072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  bytes_0 = b'd\xb9\xdf\xa0'
  bool_0 = True
  set_0 = set()
  bool_1 = True
  float_0 = -1177.556158
  action_module_0 = ActionModule(bool_0, set_0, bool_1, float_0, set_0, float_0)
  str_0 = '7glu '
  dict_0 = {}
  action_module_1 = ActionModule(bytes_0, action_module_0, dict_0, action_module_0, str_0, dict_0)
  var_0 = action_module_1.run()



# Generated at 2022-06-25 07:02:18.804460
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'sJ'
    long_0 = -9341258595702915077
    str_1 = '+?bVEF!@(!*'
    int_0 = 0
    tuple_0 = (None, str_1, bytes_0, float, False, int_0, long_0)
    float_0 = -27.641484
    float_1 = 48.7
    set_0 = frozenset([int, str, set_0, float_0, False, float_1, float])
    bool_0 = True
    bool_1 = False
    action_module_0 = ActionModule(float_0, tuple_0, set_0, bool_0, bool_1, set_0)

# Generated at 2022-06-25 07:02:21.568283
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:02:25.457857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'9'
    float_0 = -1383.7504447
    set_0 = set()
    action_module_0 = ActionModule(bytes_0, float_0, set_0, float_0, set_0, float_0)
    assert(action_module_0.TRANSFERS_FILES == False)


# Generated at 2022-06-25 07:02:28.882509
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    float_0 = float("inf")
    float_1 = 40.6297
    set_0 = set()
    action_module_0 = ActionModule(bool_0, set_0, bool_0, float_0, set_0, float_1)
    action_module_0.run()


# Generated at 2022-06-25 07:02:57.584351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_4 = b'\x94\xcd\xdc\x04\x944\x10\xb5\x02\x17\n\xd6'
    bool_4 = True
    set_2 = set()
    bool_5 = True
    float_1 = -245.906652
    action_module_2 = ActionModule(bool_4, set_2, bool_5, float_1, set_2, float_1)
    tuple_1 = (action_module_2,)
    str_1 = 'l\x8b\x89\x98\x1e\x1d'
    dict_1 = {}
    action_module_3 = ActionModule(bytes_4, action_module_2, tuple_1, action_module_2, str_1, dict_1)

# Generated at 2022-06-25 07:03:07.634286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x9f\x8c\x0b\x82'
    bool_0 = True
    set_0 = set()
    bool_1 = True
    float_0 = -1177.556158
    action_module_0 = ActionModule(bool_0, set_0, bool_1, float_0, set_0, float_0)
    tuple_0 = (action_module_0,)
    str_0 = 'p.\x84\n'
    dict_0 = {}
    action_module_1 = ActionModule(bytes_0, action_module_0, tuple_0, action_module_0, str_0, dict_0)
    assert action_module_1 is not None

# Generated at 2022-06-25 07:03:13.651500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xab\x0c1\x8d\xdd'
    bool_0 = True
    set_0 = set()
    bool_1 = True
    float_0 = -1194.502658
    action_module_0 = ActionModule(bytes_0, bool_0, set_0, bool_1, float_0, set_0, float_0)
    tuple_0 = (action_module_0,)
    str_0 = 'j'
    dict_0 = {}
    action_module_1 = ActionModule(action_module_0, action_module_0, tuple_0, action_module_0, str_0, dict_0)
    bytes_1 = b'\x17\x8c'

# Generated at 2022-06-25 07:03:16.985589
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for method run(tmp, task_vars)
    pass


# Generated at 2022-06-25 07:03:22.411695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    tuple_0 = ()
    dict_0 = {}
    float_0 = -456.5
    action_module_0 = ActionModule(tuple_0, tuple_0, tuple_0, tuple_0, tuple_0, tuple_0)
    action_module_0._task.args = dict_0
    var_0 = action_module_0.run(float_0, float_0)
    assert var_0 == {'failed': True, 'msg': "the 'key' param is required when using group_by"}


# Generated at 2022-06-25 07:03:29.586614
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfc\xd6\x86\xdb\x86\x01\xb5\xc6\xee\xfb'
    bool_0 = False
    set_0 = frozenset()
    bool_1 = True
    float_0 = 5041.0
    set_1 = frozenset()
    float_1 = -0.134313
    action_module_0 = ActionModule(bool_0, set_0, bool_1, float_0, set_1, float_1)
    action_module_0._task.args = {'key': 'foo', 'parents': 'bar'}
    assert action_module_0.run() == {'parent_groups': ['bar'], 'changed': False, 'add_group': 'foo'}


# Generated at 2022-06-25 07:03:37.322553
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x1e\x00\x10\xb8\xdb\xd9\x03\xcd'
    float_0 = 96.19
    bool_0 = True
    set_0 = {bytes_0}
    set_1 = {set_0}
    float_1 = -144.2946
    tuple_0 = (float_0,)
    str_0 = 'T7\xcc\xc9'
    str_1 = 'p"\xc4\xe4U\xdd\x1a'
    action_module_0 = ActionModule(set_0, tuple_0, set_1, str_1, str_0, bool_0)
    bytes_1 = b'\x8a\xc5\xab\xad'

# Generated at 2022-06-25 07:03:43.944606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x1f\x9d\xb0\xcc\x16\x11\x99\x12\x95\xe1\xea'
    bool_0 = False
    set_0 = set()
    bool_1 = False
    float_0 = -267.520280152
    action_module_0 = ActionModule(bool_0, set_0, bool_1, float_0, set_0, float_0)
    var_0 = action_module_0


# Generated at 2022-06-25 07:03:53.292232
# Unit test for constructor of class ActionModule
def test_ActionModule():
  from ansible.plugins.action import ActionBase
  from ansible.module_utils.six import string_types
  bytes_0 = b'd\xb9\xdf\xa0'
  bool_0 = True
  set_0 = set()
  bool_1 = True
  float_0 = -1177.556158
  action_module_0 = ActionModule(bool_0, set_0, bool_1, float_0, set_0, float_0)
  tuple_0 = (action_module_0,)
  str_0 = '7glu '
  dict_0 = {}
  action_module_1 = ActionModule(bytes_0, action_module_0, tuple_0, action_module_0, str_0, dict_0)

# Generated at 2022-06-25 07:04:00.588776
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    set_0 = set()
    bool_1 = True
    action_module_0 = ActionModule(bool_0, set_0, bool_1, set_0, set_0, set_0)
    action_module_0.run()

# Generated at 2022-06-25 07:05:04.717959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x0c'
    bool_0 = False
    set_0 = set()
    bool_1 = False
    float_0 = -1353.6634747
    action_module_0 = ActionModule(bytes_0, bool_0, set_0, bool_1, float_0, set_0, float_0)
    dict_0 = {}
    var_0 = action_module_0.run(dict_0)
    var_1 = None
    dict_1 = {}
    dict_0 = {'action_module_0': var_1, 'var_1': dict_1}
    var_0 = action_module_0.run(dict_0)
    var_2 = None
    dict_2 = {}
    dict_3 = {}

# Generated at 2022-06-25 07:05:08.524109
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    set_0 = set()
    bool_1 = True
    float_0 = -1177.556158
    action_module_0 = ActionModule(bool_0, set_0, bool_1, float_0, set_0, float_0)
    tuple_0 = (action_module_0,)
    str_0 = '7glu '
    dict_0 = {}
    action_module_1 = ActionModule(bool_0, set_0, bool_1, float_0, set_0, float_0)


# Generated at 2022-06-25 07:05:10.128225
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
# Insert code here to run unit test for constructor of class ActionModule
# End of unit test for constructor of class ActionModule


# Generated at 2022-06-25 07:05:16.496357
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x01Z'
    bool_0 = True
    set_0 = set()
    bool_1 = False
    float_0 = 22.742208
    action_module_0 = ActionModule(bool_0, set_0, bool_1, float_0, set_0, float_0)
    tuple_0 = (action_module_0,)
    dict_0 = {}
    str_0 = '$S\x95\x9c\x94'
    action_module_1 = ActionModule(bytes_0, action_module_0, tuple_0, action_module_0, str_0, dict_0)

# Generated at 2022-06-25 07:05:23.731614
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x9e\x0d\x18'
    bool_0 = True
    set_0 = set()
    bool_1 = True
    float_0 = 0.6309482780483989
    action_module_0 = ActionModule(bool_0, set_0, bool_1, float_0, set_0, float_0)
    tuple_0 = (action_module_0,)
    str_0 = '@s<1\xe3'
    dict_0 = {}
    action_module_1 = ActionModule(bytes_0, action_module_0, tuple_0, action_module_0, str_0, dict_0)
    var_0 = action_module_1.run()
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 07:05:28.776359
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x05\nA'
    action_module_0 = ActionModule(bytes_0, set(), True, -1415.08717, set(), -0.720038)


# Generated at 2022-06-25 07:05:32.488771
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'ma_x4"6\x9f'
    float_0 = float(0.7197)
    action_module_0 = ActionModule(float_0, float_0, float_0, bytes_0, float_0, float_0)
    action_module_0.run()


# Generated at 2022-06-25 07:05:41.660179
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'w\xec\xce\n'
    bool_0 = True
    set_0 = set()
    bool_1 = True
    float_0 = -14.14831
    action_module_0 = ActionModule(bool_0, set_0, bool_1, float_0, set_0, float_0)
    bool_2 = True
    set_1 = set()
    bool_3 = True
    float_1 = -8288.627691
    action_module_1 = ActionModule(bool_2, set_1, bool_3, float_1, set_1, float_1)
    assert(action_module_0._transfer_files == action_module_1._transfer_files)
# End of test for constructor of class ActionModule

# Generated at 2022-06-25 07:05:45.637662
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = None
    obj_0 = ActionModule(tmp_0, task_vars_0)
    res_0 = obj_0.run()
    print(res_0)

## Process call:
print("Test case 0")
test_case_0()
print("Test ActionModule.run()")
test_ActionModule_run()

# Generated at 2022-06-25 07:05:50.442589
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'A\x18\xdc\x9f'
    bool_0 = False
    set_0 = set()
    bool_1 = False
    float_0 = 125.966689039
    action_module_0 = ActionModule(bool_0, set_0, bool_1, float_0, set_0, float_0)
    action_module_0 = ActionModule(bool_1, set_0, bool_1, float_0, set_0, float_0)
    action_module_1 = ActionModule(bytes_0, action_module_0, action_module_0, action_module_0, bytes_0, action_module_0)

