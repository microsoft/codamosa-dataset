

# Generated at 2022-06-25 06:57:31.675090
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-25 06:57:40.766485
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with arguments
    string_0 = '\x9f\x8e'
    string_1 = 'btw{]\x82'
    float_0 = 0.361205
    set_0 = set()

    # Test with arguments
    string_0 = '\x82\xe4@\x13'
    string_1 = '\x82\xe4@\xe4\xebW8'
    float_0 = 0.9031797
    set_0 = set()

    # Test with arguments
    string_0 = ''
    string_1 = '=\x84M\xdb\x90'
    float_0 = 0.9700962628590841
    set_0 = set()

    # Test with arguments

# Generated at 2022-06-25 06:57:50.815886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup mock variables
    tmp = None
    task_vars = dict()

    # Setup mock objects
    self = ActionModule()
    self.runner = dict()
    self.runner['transfer_files'] = None
    self.runner['inventory'] = None
    self.runner['forks'] = None
    self.runner['module_name'] = None
    self.runner['no_log'] = None
    self.runner['module_args'] = None
    self.runner['module_compression'] = None
    self.runner['module_vars'] = None
    self.runner['playbook_vars'] = None
    self.runner['play'] = None
    self.runner['play_basedir'] = None
    self.runner['playbook'] = None
    self.runner['role_names'] = None

# Generated at 2022-06-25 06:57:57.950143
# Unit test for constructor of class ActionModule
def test_ActionModule():
	case_0_result_0 = None
	var_0 = test_case_0()
	action_module_0 = ActionModule('action_module_0', var_0)
	assert action_module_0._task.args.get('key') is None
	assert action_module_0._task.args.get('parents') is None
	assert action_module_0._task.data is case_0_result_0


# Generated at 2022-06-25 06:57:59.166269
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:57:59.919064
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-25 06:58:06.730939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import collections
    import pytest
    from ansible.module_utils.six import string_types

    ActionBaseMock = collections.namedtuple('ActionBaseMock', ['run'])
    action_base = ActionBaseMock(run=test_case_0)
    # Construct fixture
    action_module = ActionModule(action_base)
    action_module._task = collections.namedtuple('_task', ['args'])
    action_module._task.args = {'key': 'key'}

    # Run test and verify results
    result = action_module.run()
    assert isinstance(result, dict)
    assert result['failed'] is False
    assert result['changed'] is True
    assert result['add_group'] == 'key'
    assert result['parent_groups'] == ['all']


# Generated at 2022-06-25 06:58:07.812704
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-25 06:58:15.260423
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args_0 = {'parents': '3'}
    args_1 = {'key': '\x1e'}
    args_2 = {'parents': '6', 'key': '='}
    args_3 = {'parents': '3', 'key': '\x1e'}
    args_4 = {'parents': '\x1e', 'key': '='}
    args_5 = {'parents': '6', 'key': '\x1e'}
    args_6 = {'parents': '3', 'key': '='}
    ActionModule(args_0)
    ActionModule(args_1)
    ActionModule(args_2)
    ActionModule(args_3)
    ActionModule(args_4)
    ActionModule(args_5)
    ActionModule(args_6)

# Generated at 2022-06-25 06:58:16.138682
# Unit test for constructor of class ActionModule
def test_ActionModule():

    test_module = ActionModule()


# Generated at 2022-06-25 06:58:23.475665
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.TRANSFERS_FILES == False
    #
    # _VALID_ARGS is a frozen set with elements, "Key", and "Parents".
    #
    assert len(ActionModule._VALID_ARGS) == 2
    assert "key" in ActionModule._VALID_ARGS
    assert "parents" in ActionModule._VALID_ARGS



# Generated at 2022-06-25 06:58:31.326858
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup a ActionModule
    action_module_1 = ActionModule()

    # Set up test variables
    args = {
        'key': 'keyword_name',
        'parents': ['all'],
    }
    task_vars = {
        'ansible_facts': {
            'distribution': 'Arch Linux',
            'distribution_major_version': '2',
        },
    }

    expected_result = {
        'changed': False,
        'add_group': 'keyword-name',
        'parent_groups': [
            'all',
        ],
    }

    result = action_module_1.run(None, task_vars, args)

    assert result == expected_result, result

# Generated at 2022-06-25 06:58:41.091588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    action_module._task = type('Task', (object,), dict())()

    action_module._task.args = dict()

    action_module._task.args['key'] = type(object)

    action_module._task.args['parents'] = ['all']

    action_module.task_vars = type('TaskVars', (object,), dict())()

    res = action_module.run()

    assert 'msg' in res.keys()

    assert 'failed' in res.keys()

    assert 'changed' in res.keys()

    assert 'add_group' in res.keys()

    assert 'parent_groups' in res.keys()

# Generated at 2022-06-25 06:58:42.447044
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  action_module_0 = ActionModule()
  action_module_0.run(None, None)

# Generated at 2022-06-25 06:58:45.183595
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor without any argument
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:58:46.950095
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_2 = ActionModule()
    action_module_2.run()


# Generated at 2022-06-25 06:58:48.364133
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:58:50.094872
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert action_module_1 is not None


# Generated at 2022-06-25 06:58:51.737620
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 06:58:53.002218
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert True


# Generated at 2022-06-25 06:59:00.195236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 06:59:03.973884
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()

# Generated at 2022-06-25 06:59:05.365770
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()



# Generated at 2022-06-25 06:59:05.928776
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 06:59:09.192905
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert(type(action_module) == ActionModule)


# Generated at 2022-06-25 06:59:11.250592
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run() is None

# Generated at 2022-06-25 06:59:17.434427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert type(action_module_0) == ActionModule
    assert action_module_0.FORCE_COLOR is True
    assert action_module_0.DEFAULT_STDOUT_CALLBACK == 'yaml'
    assert action_module_0.DEFAULT_LOAD_CALLBACK_PLUGINS is True
    assert action_module_0.DEFAULT_TIMEOUT == 0
    assert action_module_0.TRANSFERS_FILES is False
    assert action_module_0._config is None
    assert type(action_module_0._display) == object
    assert type(action_module_0._loader) == object
    assert action_module_0._remote_user is ''
    assert action_module_0._shell is None

# Generated at 2022-06-25 06:59:20.516110
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:59:23.565245
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run() == {'failed': True, 'msg': "the 'key' param is required when using group_by"}


# Generated at 2022-06-25 06:59:25.598244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test ActionModule_run")
    action_module_1 = ActionModule()

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 06:59:39.475322
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Make sure that constructor of class ActionModule works correctly
    bool_0 = True
    tuple_0 = ()
    list_0 = [True, True, False, True]
    str_0 = ','
    dict_0 = {}
    list_1 = [True]
    action_module_0 = ActionModule(bool_0, tuple_0, list_0, str_0, dict_0, list_1)

if __name__ == "__main__":
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 06:59:40.104694
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:59:49.888456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an object of the class ActionModule
    action_module_0 = ActionModule()

    # Verify the object is an instance of ActionModule
    if not isinstance(action_module_0, ActionModule):
        raise Exception("Test #0 failed: action_module_0 is not an instance of ActionModule")
    # Verify the value of attribute TRANSFERS_FILES
    if action_module_0.TRANSFERS_FILES != False:
        raise Exception("Test #1 failed: action_module_0.TRANSFERS_FILES is not False")
    # Verify the value of attribute _VALID_ARGS

# Generated at 2022-06-25 06:59:53.119876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(False, 'module_name', 'test_task_name', 'module_args', 'module_vars', 'task_vars')
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:59:59.640050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {}

    # Invoke method
    result = ActionModule(tuple_0, dict_0).run()

    assert result == dict_0

if __name__ == '__main__':

    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:00:05.421750
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  bool_2 = False
  str_2 = '\x98a\xeb\x89\x17\x12\x1a\x94"\x17\xfa2\xf64\x8f\x18'
  bool_3 = True
  tuple_1 = ()
  list_2 = [bool_2, str_2, bool_2, str_2]
  str_3 = '3]*;'
  dict_1 = {}
  list_3 = [str_2]
  action_module_2 = ActionModule(bool_3, tuple_1, list_2, str_3, dict_1, list_3)

# Generated at 2022-06-25 07:00:10.436206
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    tuple_0 = ()
    action_module_0 = ActionModule(bool_0, tuple_0, tuple_0, None, tuple_0, tuple_0)

# Generated at 2022-06-25 07:00:18.877560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = [0, 1, 2]
    str_0 = ''.join([_ for _ in list_0])
    bool_0 = bool(str_0)
    bool_1 = bool(str_0)
    list_1 = [bool_0, bool_1, bool_0, bool_0]
    str_1 = ''.join([_ for _ in list_1])
    list_2 = [bool_0]
    bytes_0 = b'\xfb\xe7\xf0\x18\xa3\xe1\xc8\xbd\x93\xce\x99\x8a\x82\xd6\x1f\xf9\x8a'
    bool_2 = bool(bytes_0)
    dict_0 = {}

# Generated at 2022-06-25 07:00:19.769885
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:00:26.985932
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_2 = ActionModule.__new__(ActionModule)
    str_2 = 'h<\xc3\xbd\xa4\x0e\xf7\x84\xc4\x14\x10M\x1d\xc9\xb5\xdf\xa5\x12\x85'
    str_3 = '\xd5Z\x1d\xe5\x90P\xfd\x0b\xd2\xfd\x03\x88\xb4\x9e\x9c'
    Exception_0 = Exception(str_3, action_module_2)
    Exception_1 = Exception(str_2, action_module_2)
    action_module_3 = ActionModule.__new__(ActionModule)

# Generated at 2022-06-25 07:00:46.191902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = '[<sBd\x8c'
    bool_1 = True
    tuple_0 = ()
    list_0 = []
    str_1 = 'TOlQ-F%U+\x1f\x9f\xae\x8a'
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, tuple_0, list_0, str_1, dict_0, list_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:00:49.427486
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate an object of the class ActionModule
    action_module_1 = ActionModule()
    if not isinstance(action_module_1, ActionModule):
        raise TypeError('Expected an instance of ActionModule but has received an instance of {} instead'.format(type(action_module_1).__name__))


# Generated at 2022-06-25 07:00:54.159530
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = '\x7f\xf6h\xf6\x85\x8c\xb4\xbd\x9d\x9e@\xb0\x13\xc1\xdc\x06\x00\x80'
    bool_1 = False

# Generated at 2022-06-25 07:01:01.964339
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = '\x0c\x9a\x1a@\x03\xe1l\xa6\x93\xa7\xb6\xf8\x9d'
    bool_1 = True
    tuple_0 = ('',)
    list_0 = [bool_0, str_0, bool_0, str_0]
    str_1 = '*'
    dict_0 = {}
    list_1 = []
    action_module_0 = ActionModule(bool_0, tuple_0, list_0, str_1, dict_0, list_1)
    action_module_0.run(str_0, list_0)

# Generated at 2022-06-25 07:01:10.973669
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    tuple_0 = ()
    dict_0 = {}
    list_0 = ['<', 'mv]9H', '8b:>', '|', '|-%{w']

    action_module_0 = ActionModule(bool_0, tuple_0, dict_0, list_0)
    assert action_module_0.is_playbook == True
    assert action_module_0.loader == ()
    assert action_module_0.templar == {}
    assert action_module_0.shared_loader_obj == ['<', 'mv]9H', '8b:>', '|', '|-%{w']
    assert action_module_0.noop_on_check(dict_0) == (False, '', False)


# Generated at 2022-06-25 07:01:16.194405
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bool_1 = True
    tuple_0 = ()
    list_0 = [bool_0, bool_1]
    str_0 = 'i_\x8f\x9f|\x9f\x0b\x8b\x83@\xdb'
    str_1 = 'cr'
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, tuple_0, list_0, str_0, dict_0, list_0)
    var_0 = action_module_0.run()
    str_2 = 'C#'
    list_1 = [str_2]
    action_module_1 = ActionModule(bool_0, tuple_0, list_1, str_2, dict_0, list_1)
    var_1

# Generated at 2022-06-25 07:01:26.196004
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = 'J[0vh8WQ)$%c+F'
    list_0 = [bool_0, str_0, bool_0, str_0, bool_0]
    list_1 = [bool_0]
    action_module_0 = ActionModule(bool_0, str_0, list_0, str_0, str_0, list_1)
    dict_0 = {}
    str_1 = 'Z\xa5\xdf\xdd\xf4\x8b\xc0\xfb\xf5'
    var_0 = action_module_0.run(str_1, dict_0)
    int_0 = 17

# Generated at 2022-06-25 07:01:36.745146
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = 'h_\x96\x8cWe\x9c\x18\x8e\xad\x91o'
    bool_1 = True
    tuple_0 = ()
    list_0 = [bool_0, bool_1, bool_1, bool_1, bool_1, bool_1, bool_0, bool_0, bool_0, bool_0, bool_1, bool_1, bool_1, bool_1, bool_0, bool_0, bool_0, bool_0, bool_1]
    str_1 = '+'
    dict_0 = {}

# Generated at 2022-06-25 07:01:39.040232
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 07:01:44.072387
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True

# Generated at 2022-06-25 07:02:16.544112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = '#$@x7VuwUB6U'
    list_0 = ['notify']
    str_1 = 'T\x12\x1b\x12G\x0f\x0b'
    dict_0 = {}
    list_1 = [str_0]
    action_module_0 = ActionModule(bool_0, str_0, list_0, str_1, dict_0, list_1)
    bool_1 = False
    str_2 = 'P8*hW\x1d\x1a'
    list_2 = [bool_1, str_0, str_2, str_1]
    str_3 = '&'
    dict_1 = {}
    list_3 = [str_3]
    action_module

# Generated at 2022-06-25 07:02:19.539797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(False, None, [False, '%nd=-1Rv{M[S', True, '%nd=-1Rv{M[S'], '*', {}, ['/'])
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-25 07:02:28.778787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = 'jf7\x83\xd5\x9c\xb8\x96\xaa\xde'
    list_0 = [bool_0, str_0, str_0]
    dict_0 = {}
    list_1 = [str_0, str_0]
    action_module_0 = ActionModule(bool_0, str_0, list_0, str_0, dict_0, list_1)
    str_1 = 'F\x84-\x93C\xcf\xabn\x8a\xa7\x98\x19\x8e'
    str_2 = '%\x87\x0f\x03O\x0f\xd9\x9c\x8a'

# Generated at 2022-06-25 07:02:39.658583
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = './\xf0L\xdd\x17\x1b\x0b\x8b\x9c\xab\xcd\xed\x18\x1d\x13\xa9\xb4\xce\x10'
    bool_1 = False
    str_1 = './\xf0L\xdd\x17\x1b\x0b\x8b\x9c\xab\xcd\xed\x18\x1d\x13\xa9\xb4\xce\x10'
    bool_2 = False

# Generated at 2022-06-25 07:02:49.846543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We need to be able to modify the inventory
    TRANSFERS_FILES = False
    _VALID_ARGS = frozenset(('key', 'parents'))

    def run(self, tmp=None, task_vars=None):
        if task_vars is None:
            task_vars = dict()

        result = super(ActionModule, self).run(tmp, task_vars)
        del tmp  # tmp no longer has any effect

        if 'key' not in self._task.args:
            result['failed'] = True
            result['msg'] = "the 'key' param is required when using group_by"
            return result

        group_name = self._task.args.get('key')
        parent_groups = self._task.args.get('parents', ['all'])

# Generated at 2022-06-25 07:02:56.007510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bytes_0 = b'\xb5\x86\xb5\x97\xac\x9f\xa1\x98\xfb\x92\xc1\xa8'
    tuple_0 = ()
    action_module_0 = ActionModule(bool_0, bytes_0, tuple_0, bytes_0, tuple_0, tuple_0)
    assert action_module_0._handlers is None
    assert action_module_0._templar is None
    assert action_module_0.action is None
    assert action_module_0.runner is None
    assert action_module_0._connection is None
    assert action_module_0._loader is None
    assert action_module_0._display is None
    assert action_module_0._task is None
    assert action_module

# Generated at 2022-06-25 07:02:59.631608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test for method ActionModule.run
    """
    test_case_0()

# Generated at 2022-06-25 07:03:05.652028
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = '.Z@y7CZzrCYb'
    action_module_0 = ActionModule(bool_0, str_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:03:12.476468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = '.Z@y7CZzrCYb'
    bool_1 = True
    tuple_0 = ()
    list_0 = [bool_0, str_0, bool_0, str_0]
    str_1 = '*'
    dict_0 = {}
    list_1 = [str_0]
    action_module_0 = ActionModule(bool_1, tuple_0, list_0, str_1, dict_0, list_1)
    bytes_0 = b'\x83`\x86:\xaeuK\xbf\xd8\xe6\x7f'
    action_module_1 = ActionModule(bool_1, str_0, action_module_0, bytes_0, dict_0, action_module_0)
   

# Generated at 2022-06-25 07:03:23.710620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = '.Z@y7CZzrCYb'
    bool_1 = True
    tuple_0 = ()
    list_0 = [bool_0, str_0, bool_0, str_0]
    str_1 = '*'
    dict_0 = {}
    list_1 = [str_0]
    action_module_0 = ActionModule(bool_1, tuple_0, list_0, str_1, dict_0, list_1)
    bytes_0 = b'\x83`\x86:\xaeuK\xbf\xd8\xe6\x7f'
    action_module_1 = ActionModule(bool_0, str_0, action_module_0, bytes_0, dict_0, action_module_0)
   

# Generated at 2022-06-25 07:04:28.913293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = '.Z@y7CZzrCYb'
    bool_1 = True
    tuple_0 = ()
    list_0 = [bool_0, str_0, bool_0, str_0]
    str_1 = '*'
    dict_0 = {}
    list_1 = [str_0]
    action_module_0 = ActionModule(bool_1, tuple_0, list_0, str_1, dict_0, list_1)
    assert callable(action_module_0.run)
    bytes_0 = b'\x83`\x86:\xaeuK\xbf\xd8\xe6\x7f'

# Generated at 2022-06-25 07:04:33.339096
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(ActionModule) == type
    bool_0 = False
    str_0 = '.Z@y7CZzrCYb'
    bool_1 = True
    tuple_0 = ()
    list_0 = [bool_0, str_0, bool_0, str_0]
    str_1 = '*'
    dict_0 = {}
    list_1 = [str_0]
    action_module_0 = ActionModule(bool_1, tuple_0, list_0, str_1, dict_0, list_1)
    bytes_0 = b'\x83`\x86:\xaeuK\xbf\xd8\xe6\x7f'

# Generated at 2022-06-25 07:04:37.187480
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# vim: set et ts=4 sw=4 ft=python :

# Generated at 2022-06-25 07:04:42.203863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule(True, None, None, None, None, None)
    var_0.run(None, None)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:04:48.986608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = '_B,h*BHBQ%'
    bool_1 = True
    tuple_0 = ()
    list_0 = [bool_0, str_0]
    str_1 = 'A'
    dict_0 = {}
    list_1 = [str_1]
    action_module_0 = ActionModule(bool_1, tuple_0, list_0, str_0, dict_0, list_1)
    action_module_1 = action_module_0.run()
    #assert isinstance(action_module_1, ActionModule) == True
    #assert action_module_1 == 'ansible.plugins.action.ActionModule'
    #assert False
    return action_module_1 == 'ansible.plugins.action.ActionModule'

test_case

# Generated at 2022-06-25 07:04:51.369068
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, object)


# Generated at 2022-06-25 07:04:57.944569
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'y_\x0c|\nc\x1d\xbaZh\x15\xce\xeb\xbc'
    str_1 = 'P\x9b\xa9Tky%s\xab\x17\x14\x06'
    action_module_0 = ActionModule(None, str_0, str_1)
    result_0 = action_module_0.run()
    str_2 = '?'
    assert result_0['add_group'] == str_2
    str_3 = 'W\xfd\xe3\x13\xa7m\xc6\x90\xf5\xdf'
    assert result_0['parent_groups'] == [str_3]


# Generated at 2022-06-25 07:05:04.074341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = '`E`]\xcdv\xeb\x8e\x15\xcd\x0b\xdc\xb5\x1b@'
    bool_1 = True
    tuple_0 = ()
    list_0 = [bool_0, str_0, bool_1, str_0]
    str_1 = '-X'
    dict_0 = {}
    list_1 = [str_0]
    action_module_0 = ActionModule(bool_1, tuple_0, list_0, str_1, dict_0, list_1)

# Generated at 2022-06-25 07:05:10.907431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = '6\xcb\xc0>\x9c\x98'
    str_1 = '!\x18\xc8'
    str_2 = '_\x9f\x8e'
    dict_0 = {}
    str_3 = ''
    list_0 = [str_0, str_1, str_2, str_3]
    action_module_0 = ActionModule(bool_0, list_0, dict_0, list_0, dict_0, dict_0)
    action_module_0.run()



# Generated at 2022-06-25 07:05:15.724434
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing constructor')
    bool_0 = False
    str_0 = '.Z@y7CZzrCYb'
    bool_1 = True
    tuple_0 = ()
    list_0 = [bool_0, str_0, bool_0, str_0]
    str_1 = '*'
    dict_0 = {}
    list_1 = [str_0]
    action_module_0 = ActionModule(bool_1, tuple_0, list_0, str_1, dict_0, list_1)
    print('Unit test completed')
