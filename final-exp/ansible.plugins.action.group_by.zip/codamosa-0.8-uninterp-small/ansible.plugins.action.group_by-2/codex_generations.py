

# Generated at 2022-06-25 06:57:39.257879
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -824
    float_0 = -0.00755723
    tuple_0 = (float_0,)
    dict_0 = {float_0: float_0, float_0: int_0}
    str_0 = 'F1xe%c2j8&1w'
    action_module_0 = ActionModule(int_0, float_0, tuple_0, dict_0, str_0, str_0)
    # Find a way to test ActionModule.run()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:57:50.654014
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  int_0 = -1422271790
  float_0 = -3590.11
  tuple_0 = (float_0, float_0, float_0, float_0, float_0)
  dict_0 = {}
  str_0 = 'as$e8y6o)U^'
  str_1 = '\x1fW@\x0bQE\x7f\x15\x0c\x0b\\\x1a\x1f\x14\n\n'
  bool_0 = False
  bool_1 = True
  action_module_0 = ActionModule(int_0, dict_0, dict_0, dict_0, dict_0, dict_0)
  assert action_module_0.run() == 0, "Expected: 0, Actual: %s"

# Generated at 2022-06-25 06:58:01.750311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 592
    float_0 = 0.13766994063208833
    tuple_0 = (float_0, float_0, float_0)
    dict_0 = {'float_0': tuple_0, 'float_0': tuple_0}
    str_0 = 'ID'
    action_module_0 = ActionModule(int_0, float_0, tuple_0, dict_0, str_0, str_0)
    task_vars = {'dict_0': tuple_0, 'str_0': tuple_0}

# Generated at 2022-06-25 06:58:10.975356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 0
    float_0 = 0.0
    tuple_0 = (1, 2, 3, 4, 5, 6, 7, 8, 9)
    dict_0 = {1: tuple_0, 2: tuple_0, 3: tuple_0, 4: tuple_0, 5: tuple_0, 6: tuple_0, 7: tuple_0, 8: tuple_0, 9: tuple_0}
    str_0 = 'e]9X0LK2UV>lq@<|}p6x8Zw'
    action_module_0 = ActionModule(int_0, float_0, tuple_0, dict_0, float_0, str_0)
    del int_0, float_0, tuple_0, dict_0, str_0, action_module_0

# Unit test

# Generated at 2022-06-25 06:58:16.676145
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_2 = 173
    float_2 = -0.897
    tuple_2 = ()
    dict_2 = {int_2: float_2, float_2: float_2, int_2: float_2}
    float_3 = 0.206
    str_2 = '&|`Dln`'
    assert ActionModule(int_2, float_2, tuple_2, dict_2, float_3, str_2)


# Generated at 2022-06-25 06:58:17.825717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Testing constructor for class ActionModule

# Generated at 2022-06-25 06:58:23.749097
# Unit test for constructor of class ActionModule
def test_ActionModule():
  int_0 = 32
  float_0 = -1592.071
  tuple_0 = ()
  dict_0 = {float_0: float_0, float_0: float_0, tuple_0: float_0}
  str_0 = '9`6bk+p,#}'
  action_module_0 = ActionModule(int_0, float_0, tuple_0, dict_0, float_0, str_0)
  assert type(action_module_0) == ActionModule


# Generated at 2022-06-25 06:58:24.996064
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'ActionModule' == ActionModule.__name__


# Generated at 2022-06-25 06:58:32.147149
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3649
    float_0 = -8706.075
    tuple_0 = (float_0, float_0, float_0)
    dict_0 = {float_0: tuple_0, float_0: int_0, int_0: tuple_0, int_0: int_0}
    str_0 = 'N[=_6D}:Xn'
    action_module_0 = ActionModule(int_0, float_0, tuple_0, dict_0, float_0, str_0)
    del int_0
    del float_0
    del tuple_0
    del dict_0
    del str_0
    del action_module_0


# Generated at 2022-06-25 06:58:40.769823
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        int_0 = 32
        float_0 = -1592.071
        tuple_0 = ()
        dict_0 = {float_0: float_0, float_0: float_0, tuple_0: float_0}
        str_0 = '9`6bk+p,#}'
        action_module_0 = ActionModule(int_0, float_0, tuple_0, dict_0, float_0, str_0)
    except Exception:
        print("Unhandled exception was raised while testing constructor of class ActionModule")


# Generated at 2022-06-25 06:58:50.869744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'dCe#P6~p~,1'
    str_1 = '>S<\tn$2'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:58:56.484790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'dCe#P6~p~,1'
    str_1 = '>S<\tn$2'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    var_0 = action_run(str_0)

# Generated at 2022-06-25 06:59:03.184877
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_2 = 'dCe#P6~p~,1'
    str_3 = '>S<\tn$2'
    list_1 = None
    dict_1 = None
    bool_1 = False
    tuple_1 = (list_1, dict_1, bool_1)
    action_module_1 = ActionModule(str_3, str_3, tuple_1, tuple_1, tuple_1, dict_1)
    var_1 = action_module_1.run(str_1)


# Generated at 2022-06-25 06:59:09.445219
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '>S<\tn$2'
    str_1 = 'dCe#P6~p~,1'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    assert action_module_0.transfers_files() == False


# Generated at 2022-06-25 06:59:14.097133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import StringIO
    buf = StringIO.StringIO()
    debugger = Debugger()
    debugger.runcall(ActionModule, buf)
    buf.close()

# Generated at 2022-06-25 06:59:22.579831
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '#|sB>F\\zqW$QFH^'
    str_1 = ':!8IY'
    str_2 = 'o=P'
    str_3 = 'tVAw'
    str_4 = 'Z7QQ'
    str_5 = '9g%c1'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (str_0, str_1, str_2)
    tuple_1 = (str_3, str_4, list_0)
    tuple_2 = (str_5, dict_0, bool_0)
    action_module_0 = ActionModule(tuple_0, tuple_1, tuple_2, tuple_2, tuple_2, dict_0)

# Unit

# Generated at 2022-06-25 06:59:28.340231
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'dCe#P6~p~,1'
    str_1 = '>S<\tn$2'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:59:36.096837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'dCe#P6~p~,1'
    str_1 = '>S<\tn$2'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    assert(isinstance(action_module_0, ActionModule))


# Generated at 2022-06-25 06:59:43.353203
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'dCe#P6~p~,1'
    dict_0 = dict()
    dict_0['u?L-lzDVrI'] = 'Z5g@Nt'
    dict_0['tM)yEP\nNA'] = '~YIc%'
    dict_0['a1' + '@' * 76] = 'O' + '.' * 21
    dict_0['Hp[d.^F-}i'] = ';9' + '.' * 94
    dict_0['IzM|#' + '+' * 10] = '6<f|>~'
    dict_0['!+)E6' + 'S' * 5] = 'A' + '@' * 59
    dict_0['y_fN/(:M2"']

# Generated at 2022-06-25 06:59:44.466717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'hi' == 'hi'

# Generated at 2022-06-25 06:59:59.290394
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert str_0 == 'dCe#P6~p~,1'
    assert str_1 == '>S<\tn$2'
    assert list_0 == None
    assert dict_0 == None
    assert bool_0 == False
    assert tuple_0 == (list_0, dict_0, bool_0)
    assert action_module_0 == action_module(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)


# Generated at 2022-06-25 07:00:03.000746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Xj'
    str_1 = 'Pl}/p'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    action_module_0.run(str_0)

# Generated at 2022-06-25 07:00:11.990824
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'C&M=\tR'
    str_1 = '+8{1tk'
    tuple_0 = (str_0, str_1)
    tuple_1 = (None, None)
    tuple_2 = (None, None)
    dict_0 = {'+8{1tk': False, 'C&M=\tR': True}
    action_module_0 = ActionModule(str_0, str_1, tuple_0, tuple_1, tuple_2, dict_0)
    var_0 = action_run(str_0)


# Generated at 2022-06-25 07:00:22.116913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '9yGtc$d,{A'
    str_1 = '!YT|T=E'
    dict_0 = dict()
    dict_1 = dict()
    dict_0['parents'] = dict_1
    dict_0['key'] = 'nC>V8WnJF'
    list_0 = ['parents', 'key']
    action_module_0 = ActionModule(str_1, str_1, list_0, list_0, list_0, dict_0)
    action_module_0.run(dict_0, dict_1)
    dict_2 = dict()
    dict_2['parents'] = dict_1
    dict_2['key'] = 'U*<|pBm&#'
    list_1 = list()

# Generated at 2022-06-25 07:00:27.495275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_0['parents'] = test_case_0
    dict_0['key'] = test_case_0
    str_0 = 'dCe#P6~p~,1'
    str_1 = '>S<\tn$2'
    list_0 = None
    dict_1 = None
    bool_0 = False
    tuple_0 = (list_0, dict_1, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_1)
    var_0 = action_run(str_0)

# Generated at 2022-06-25 07:00:36.735801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'dCe#P6~p~,1'
    str_1 = '>S<\tn$2'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    # Test attributes of object

# Generated at 2022-06-25 07:00:45.545196
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test the constructor of class 'ActionModule'
    str_0 = '"5~hQ$fjK'
    str_1 = '>S<\tn$2'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    var_0 = action_module_0.run(str_0)
    pass


# Generated at 2022-06-25 07:00:46.626387
# Unit test for method run of class ActionModule
def test_ActionModule_run():    
    assert  None != False 
    assert  None != False 


# Generated at 2022-06-25 07:00:52.653907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'dCe#P6~p~,1'
    str_1 = '>S<\tn$2'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    var_0 = action_run(str_0)
    dict_0 = var_0.pop('msg')
    dict_1 = var_0.pop('add_group')
    dict_2 = var_0.pop('parent_groups')
    dict_3 = var_0.pop('changed')
    dict_4 = var_0.pop('failed')

# Generated at 2022-06-25 07:00:57.078590
# Unit test for constructor of class ActionModule
def test_ActionModule():
    
    assert action_module_0.run(str_0, dict_0) == None


# Generated at 2022-06-25 07:01:17.415370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'a%U{`gw7M'
    str_1 = '<\x00u$7'
    tuple_0 = None
    def function_0(task_0):
        pass
    class Class_0():
        def __init__(self):
            pass
        def method_0(self, tmp_0, task_vars_0):
            pass
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, Class_0())
    action_module_0.run = function_0
    var_0 = action_module_0.run(str_0)

# Generated at 2022-06-25 07:01:26.665905
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '>S<\tn$2'
    str_1 = 'dCe#P6~p~,1'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    str_2 = '=)4ZpE]'
    # Test for constructor of class ActionModule
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    assert(action_module_0.action_type is str_2)


# Generated at 2022-06-25 07:01:34.652786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'dCe#P6~p~,1'
    str_1 = '>S<\tn$2'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    assert str_1 == str(action_module_0)



# Generated at 2022-06-25 07:01:38.380842
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    run_0 = action_module_0.run()
    run_1 = action_module_0.run()
    run_2 = action_module_0.run()
    run_3 = action_module_0.run()


# Generated at 2022-06-25 07:01:41.572713
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ')M9XsKzT'
    str_1 = 'W`KU^v@'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)


# Generated at 2022-06-25 07:01:46.487878
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'dCe#P6~p~,1'
    str_1 = '>S<\tn$2'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    var_0 = action_run(str_0)

# Generated at 2022-06-25 07:01:50.146510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = None
    tuple_0 = (dict_0, dict_0)
    tuple_1 = (dict_0, tuple_0)
    action_module_0 = ActionModule('6ss;U.+', dict_0, dict_0, dict_0, dict_0, dict_0)



# Generated at 2022-06-25 07:01:55.097798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = { 'msg': 'the \'key\' param is required when using group_by', 'changed': False, 'failed': True}
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    var_0 = action_run(str_0)
    assert var_0 == dict_0, "expected %s to be %s" % (var_0,dict_0)


# Generated at 2022-06-25 07:02:01.503256
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '4A4sjJ^'
    str_1 = 'hd:Zf=tK'
    tuple_0 = ()
    tuple_1 = ()
    tuple_2 = ()
    dict_0 = None
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_1, tuple_2, dict_0)
    action_module_0.run()

# Generated at 2022-06-25 07:02:12.112324
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'dCe#P6~p~,1'
    str_1 = '>S<\tn$2'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)

    # Assert type
    assert isinstance(action_module_0, ActionModule)

    # Assert instance variables
    assert action_module_0._task == '>S<\tn$2'
    assert action_module_0._connection == '>S<\tn$2'
    assert action_module_0._play_context == (None, None, False)

# Generated at 2022-06-25 07:02:39.144638
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(ActionModule(None, None, None, None, None, None)) == ActionModule

# Generated at 2022-06-25 07:02:45.009074
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    result = action_module_0.run()
    assert result == {
        'add_group': 'v2KkQ0h',
        'changed': False,
        'parent_groups': ['all']
    }

# Generated at 2022-06-25 07:02:52.158604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'pE}BJT'
    str_1 = ':M3tE%=t>I@06'
    list_0 = None
    dict_0 = OrderedDict()
    bool_0 = False
    tuple_0 = (str_1, list_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    dict_0['U~8(U'] = 'U~8(U'
    dict_0['U~8(U'] = 'U~8(U'
    dict_0['U~8(U'] = 'U~8(U'
    dict_0['U~8(U'] = 'U~8(U'

# Generated at 2022-06-25 07:02:56.235943
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'dCe#P6~p~,1'
    str_1 = '>S<\tn$2'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    assert action_module_0.action_type == str_1


# Generated at 2022-06-25 07:02:59.211263
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arguments = None
    connection = None
    module_name = None
    module_args = None
    task_vars = None
    tree = None
    action_module_obj = ActionModule(arguments, connection, module_name, module_args, task_vars, tree)
    assert action_module_obj is not None

# Generated at 2022-06-25 07:03:07.600863
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'yB"\x1bxW\x0eQP'
    str_1 = '>S<\tn$2'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    del action_module_0


# Generated at 2022-06-25 07:03:16.021673
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'dCe#P6~p~,1'
    str_1 = '>S<\tn$2'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    assert_equals(action_module_0._task, list_0)
    assert_equals(action_module_0._play_context, dict_0)
    assert_equals(action_module_0._loader, bool_0)
    assert_equals(action_module_0._templar, tuple_0)

# Generated at 2022-06-25 07:03:20.981183
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'n>]/'
    str_1 = 'z$PU7'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    action_module_0.run(str_0, list_0)


# Generated at 2022-06-25 07:03:26.516290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'dCe#P6~p~,1'
    str_1 = '>S<\tn$2'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    var_0 = action_run(str_0)

if __name__ == "__main__":
    run_test(test_case_0)
    run_test(test_ActionModule_run)

# Generated at 2022-06-25 07:03:33.124764
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '7I8Q5<5r7V'
    str_1 = 'qP5yb|0z'
    dict_0 = dict()
    list_0 = [str_0, str_0]
    tuple_0 = (list_0, dict_0, str_1)
    str_2 = 'YX?p3D7V+'
    str_3 = 'F43K3q_!E'
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict

# Generated at 2022-06-25 07:04:33.805510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '/Uc*6,<\n~E'
    str_1 = '|_/]l,x'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    action_module_0.run()

# Generated at 2022-06-25 07:04:38.236360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run() == None, 'test_ActionModule_run assert #0 failed'
    assert action_module_0.run() == None, 'test_ActionModule_run assert #1 failed'

# Generated at 2022-06-25 07:04:44.694901
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'y6!M7<o_/'
    str_1 = '|c(,b}A)k'
    list_0 = None
    dict_0 = None
    bool_0 = True
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)


# Generated at 2022-06-25 07:04:50.158356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'h'
    str_1 = 't'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    str_2 = 'J'
    dict_1 = dict()
    var_0 = action_module_0.run(str_2, dict_1)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:04:51.384837
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run()
    assert isinstance(module, ActionModule)



# Generated at 2022-06-25 07:04:54.743585
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'dCe#P6~p~,1'
    str_1 = '>S<\tn$2'
    list_0 = None
    dict_0 = None
    bool_0 = True
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_0, str_1, tuple_0, tuple_0, tuple_0, dict_0)


# Generated at 2022-06-25 07:05:04.835912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    int_0 = 0
    str_0 = '%}Ra\x1c8WY.<Z'
    int_1 = 1
    list_0 = [int_0, int_0, int_1]
    dict_0[str_0] = list_0
    dict_0[str_0] = list_0
    dict_0[str_0] = list_0
    dict_0[str_0] = list_0
    dict_0[str_0] = list_0
    dict_0[str_0] = list_0
    dict_0[str_0] = list_0
    dict_0[str_0] = list_0
    dict_0[str_0] = list_0
    dict_0[str_0] = list_

# Generated at 2022-06-25 07:05:12.105682
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  str_0 = 'I<9'
  str_1 = 'pyfN{W!8'
  tuple_0 = (str_0, str_1)
  action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, str_0)
  str_2 = 'I[1mH'
  str_3 = 'p@+tM'
  tuple_1 = (str_2, str_2, str_2, str_2)
  str_4 = 'P(5'
  tuple_2 = (str_4, str_4, str_4, str_4)
  str_5 = 'I<9'
  str_6 = 'pyfN{W!8'
  tuple_3 = (str_5, str_6)

# Generated at 2022-06-25 07:05:15.997676
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'dCe#P6~p~,1'
    str_1 = '>S<\tn$2'
    list_0 = None
    dict_0 = None
    bool_0 = False
    tuple_0 = (list_0, dict_0, bool_0)
    action_module_0 = ActionModule(str_1, str_1, tuple_0, tuple_0, tuple_0, dict_0)
    var_0 = action_run(str_0)

# Generated at 2022-06-25 07:05:20.183970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Check if None is accepted
    try:
        ActionModule(None, None, None, None, None, None)
    except TypeError:
        assert False
    # Check if types other than string or tuple are accepted
    try:
        ActionModule(0, 0, 0, 0, 0, 0)
        assert False
    except TypeError:
        assert True
