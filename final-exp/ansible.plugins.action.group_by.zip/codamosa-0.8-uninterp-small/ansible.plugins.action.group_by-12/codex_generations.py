

# Generated at 2022-06-25 06:57:36.284061
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    bool_0 = False
    dict_0 = {'key_0': set_0}
    bool_1 = False
    list_0 = []
    action_module_0 = ActionModule(set_0, bool_0, dict_0, bool_1, set_0, list_0)
    action_module_0.run()



# Generated at 2022-06-25 06:57:41.117458
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of the class we are testing
    set_0 = None
    bool_0 = True
    dict_0 = {set_0: set_0}
    bool_1 = True
    list_0 = []
    action_module_0 = ActionModule(set_0, bool_0, dict_0, bool_1, set_0, list_0)

    assert action_module_0 is not None


if __name__ == '__main__':
    test_case_0()

    # Run unit tests
    test_ActionModule()

# Generated at 2022-06-25 06:57:50.200420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = None
    tmp = None
    action_module_0 = ActionModule()
 
    results = action_module_0.run(tmp, task_vars)
    assert results is not None
    assert len(results) == 4

    #Test the run command
    task_vars = None
    tmp = {'key': 'value'}
    action_module_0 = ActionModule(
        task=None, connection=None, play_context=None, loader=None,
        templar=None, shared_loader_obj=None)
 
    results = action_module_0.run(tmp, task_vars)
    assert results is not None
    assert len(results) == 4



# Generated at 2022-06-25 06:57:51.076878
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:57:59.438943
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    bool_0 = True
    dict_0 = {}
    bool_1 = True
    list_0 = []
    action_module_0 = ActionModule(set_0, bool_0, dict_0, bool_1, set_0, list_0)
    assert action_module_0._VALID_ARGS == frozenset({'parents', 'key'})
    assert isinstance(action_module_0, ActionModule) is True
    assert action_module_0.TRANSFERS_FILES == False


# Generated at 2022-06-25 06:58:06.471250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    bool_0 = True
    dict_0 = {set_0: set_0}
    bool_1 = True
    list_0 = []
    action_module_0 = ActionModule(set_0, bool_0, dict_0, bool_1, set_0, list_0)
    assert_equal(action_module_0._VALID_ARGS, frozenset(('key', 'parents')))
    assert_false(action_module_0.TRANSFERS_FILES)


# Generated at 2022-06-25 06:58:11.323309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    bool_0 = True
    dict_0 = {set_0: set_0}
    bool_1 = True
    list_0 = []
    action_module_0 = ActionModule(set_0, bool_0, dict_0, bool_1, set_0, list_0)
    assert action_module_0._task.args.get('parents') == ['all']


# Generated at 2022-06-25 06:58:12.378987
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:58:20.755461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    bool_0 = True
    dict_0 = {set_0: set_0}
    bool_1 = True
    list_0 = []
    action_module_0 = ActionModule(set_0, bool_0, dict_0, bool_1, set_0, list_0)
    action_module_0.TRANSFERS_FILES = False
    action_module_0.ANSIBLE_MODULE_ARGS = dict_0
    action_module_0.ANSIBLE_MODULE_ARGS['key'] = None
    action_module_0.ANSIBLE_MODULE_ARGS['parents'] = set_0
    action_module_0.ANSIBLE_MODULE_CONSTANTS = dict_0
    action_module_0._task = dict_0
    action_module_

# Generated at 2022-06-25 06:58:21.752383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:58:32.660275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bool_1 = True
    str_0 = 'key'
    str_1 = 'parents'
    str_2 = 'all'
    dict_0 = dict()
    dict_0['key'] = 'foo'
    dict_0['parents'] = 'bar'
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    action_module_0.name = dict_0
    action_module_0._task_fields = {str_0 : str_1, str_1 : [str_2]}
    dict_1 = dict()
    dict_1['changed'] = False
    dict_1['add_group'] = 'foo'
    dict_1['parent_groups'] = ['bar']

# Generated at 2022-06-25 06:58:38.955086
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = bool()
    bool_1 = bool()
    str_0 = str()
    tmp_0 = list()
    task_vars_0 = dict()
    action_module_0 = ActionModule(bool_1, bool_1, bool_1, bool_0, bool_1, bool_0)


# Generated at 2022-06-25 06:58:45.294348
# Unit test for constructor of class ActionModule
def test_ActionModule():

    ansible_runner = ansible.runner.Runner(
        pattern='*',
        module_name='ping',
        module_args='',
        forks=1,
        transport='local',
    )
    task_vars = {}
    host_list = [ansible_runner.inventory.get_host(hostname)]

    for host in host_list:
        for play in ansible_runner.playbook.get_plays_for_host(host):
            task_list = (play.compile_roles_handlers() + play.compile_tasks())
            for task in task_list:
                action_module_0 = ActionModule(task, host, task_vars, ansible_runner.inventory, ansible_runner.loader, ansible_runner.variable_manager)


# Generated at 2022-06-25 06:58:47.933457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-25 06:58:49.687281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as err:
        print(err)

# Generated at 2022-06-25 06:58:53.084779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Make sure the ActionModule class is instantiated
    action_module_0 = ActionModule()

    # TODO: Needs implementation
    # assert_equal(expected, action_module_0.run(tmp, task_vars))
    # expected:
    assert True

# Generated at 2022-06-25 06:58:55.041625
# Unit test for constructor of class ActionModule
def test_ActionModule():
  try:
    test_case_0()
  except Exception as ex:
    print(ex)

print(action_module_0)

# Generated at 2022-06-25 06:59:04.826587
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    # self.assertEqual(len(self.assertEqual(len(self.assertEqual(len(dir(action_module_0)), 0)), 0)), 0)
    # self.assertIsInstance(action_module_0, )
    # self.assertEqual(len(self.assertEqual(len(self.assertEqual(len(dir(action_module_0)), 0)), 0)), 0)
    # self.assertIsInstance(action_module_0, )
    # self.assertEqual(len(self.assertEqual(len(self.assertEqual(len(dir(action_module_0)), 0)), 0)), 0)
    #

# Generated at 2022-06-25 06:59:12.432854
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    action_module_0 = ActionModule(bool_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    action_module_0.get_host_list()
    action_module_0.get_name()
    action_module_0.run_command()
    action_module_0.run_copy()
    action_module_0.run_fetch()
    action_module_0.run_script()
    action_module_0.run_setup()
    action_module_0.run_stat()
    action_module_0.run_template()
    action_module_0.run_win_command()
    action_module_0.run_win_copy()
    action_module_0.run_win_shell()
    action_module

# Generated at 2022-06-25 06:59:13.332153
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(TypeError):
        test_case_0()


# Generated at 2022-06-25 06:59:25.968841
# Unit test for constructor of class ActionModule
def test_ActionModule():

    task_0 = dict(
        args=dict(
            key='{{inventory_hostname}}',
            parents=['all', 'group1', 'group2']
        )
    )

    result_0 = action_module_0.run(
        tmp,
        task_vars=dict(
            inventory_hostname='host1'
        )
    )

    assert_result = dict(
        changed=False,
        add_group='host1',
        parent_groups=['all', 'group1', 'group2']
    )
    assert result_0 == assert_result

# Generated at 2022-06-25 06:59:26.987185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

# Generated at 2022-06-25 06:59:27.496132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 06:59:29.042245
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_object = ActionModule()
    # Test if object created successfully
    assert action_module_object != null

# Generated at 2022-06-25 06:59:31.487727
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-25 06:59:37.421571
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no arguments
    #
    # The following line is needed because the test runner doesn't do auto import
    from ansible.plugins.action import ActionModule

    with pytest.raises(AttributeError):
        action_module_0 = ActionModule()
        action_module_0.run()

# Generated at 2022-06-25 06:59:44.279567
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = dict()
    task_vars.__setitem__(
        'hostvars',
        {
            'localhost': {
                'val': 'true'
            }
        }
    )
    expected_result = dict()
    expected_result.__setitem__(
        'hostvars',
        {
            'localhost': {
                'val': 'true'
            }
        }
    )
    expected_result.__setitem__(
        'changed',
        False
    )
    expected_result.__setitem__(
        '_ansible_no_log',
        False
    )

# Generated at 2022-06-25 06:59:53.049682
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Print test title
    print("\n---\n{}".format(ActionModule.__name__))
    action_module = ActionModule()
    attr_list = ["_config_module", "_constructed", "_display", "_ds", "_loader_class", "_connection_info",
                 "_shell_class", "_shell", "_shell_plugin", "_task", "_task_vars", "_templar", "_shared_loader_obj"]
    for attr in attr_list:
        if not hasattr(action_module, attr):
            print("Error: The attr({}) is missing!".format(attr))
            assert False


'''
Test running this module standalone
'''
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:59:57.567334
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert_equals(action_module_0._VALID_ARGS,frozenset(('key', 'parents')))
    assert_equals(action_module_0.TRANSFERS_FILES,False)


# Generated at 2022-06-25 07:00:01.376018
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert(action_module.TRANSFERS_FILES == False)
    assert(action_module._VALID_ARGS == frozenset(('key', 'parents')))


# Generated at 2022-06-25 07:00:13.138216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 889.723
    float_1 = 434.8335
    int_0 = 656
    list_0 = [float_0, float_1, int_0]
    int_1 = 993
    bytes_0 = b'\x1c\xa7\xef\xf8\xaf\\'
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_1, bytes_0)
    var_0 = action_run(action_module_0)
    var_1 = action_run()


# Generated at 2022-06-25 07:00:15.226693
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object) == True

test_case_0()
test_ActionModule()

print('All test cases passed')

# Generated at 2022-06-25 07:00:17.036407
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()



# Generated at 2022-06-25 07:00:22.153558
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare the data
    tmp = None
    task_vars = {}
    # Instantiate an object of class ActionModule
    action_module_0 = ActionModule()
    # Call the method run of the object
    var_0 = action_module_0.run(tmp, task_vars)
    # Assert the results
    assert str(var_0) == "{'add_group': '', 'changed': False, 'parent_groups': ['all']}"

# Generated at 2022-06-25 07:00:24.938682
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:00:33.174673
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Setup
    dict_0 = dict()
    dict_0['changed'] = False
    dict_0['add_group'] = '-group-name'
    dict_0['parent_groups'] = ['all']
    # Exercise
    action_module_0 = ActionModule(dict_0, dict_0)
    # Verify
    assert isinstance(action_module_0, ActionModule)
    assert isinstance(action_module_0.run, ActionBase.run)
    assert isinstance(action_module_0._VALID_ARGS, frozenset)
    assert isinstance(action_module_0.TRANSFERS_FILES, False)


# Generated at 2022-06-25 07:00:44.101207
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 674.4232137752
    float_1 = 949.68137783
    int_0 = 362
    list_0 = ['m']
    bytes_0 = b'\x11\x19\x84\xd2\x7f\x9f'
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_0, bytes_0)
    task_vars_0 = dict()
    current_path_0 = action_module_0.get_path(action_module_0.workdir, action_module_0.task.uid)
    action_module_0.path_exists(current_path_0)

# Generated at 2022-06-25 07:00:50.172413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 487.376313
    float_1 = 1894.424
    int_0 = 387
    list_0 = [float_0, int_0, int_0]
    bytes_0 = b'\x1c\xa7\xef\xf8\xaf\\'
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_0, bytes_0)
    tmp_0 = None
    task_vars_0 = dict()

# Generated at 2022-06-25 07:00:51.688611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_instance_0 = test_case_0()
    action_module_instance_0.run()


# Generated at 2022-06-25 07:00:59.267976
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 487.376313
    float_1 = 1894.424
    int_0 = 387
    list_0 = [float_0, int_0, int_0]
    bytes_0 = b'\x1c\xa7\xef\xf8\xaf\\'
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_0, bytes_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:01:13.792566
# Unit test for constructor of class ActionModule
def test_ActionModule():
    byte0 = b'\x0f\xa4\x1f\x1c\xab\xf4'
    float0 = 528.3057
    float1 = 627.6567
    int0 = 881
    list0 = [int0, float0]
    int1 = 784
    bytes0 = b'\x1c\xab\x08\xad\x9a\xf5'
    action_module0 = ActionModule(float0, float1, int0, list0, int1, bytes0)


# Generated at 2022-06-25 07:01:23.812992
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test
    # 'key' not in self._task.args
    action_module_0 = ActionModule()
    task_vars_0 = dict()
    result_0 = action_module_0.run(None, task_vars_0)
    assert result_0['failed'] is True
    assert result_0['msg'] == "the 'key' param is required when using group_by"
    assert result_0['changed'] is False

    # Test
    # Test
    # 'key' not in self._task.args
    action_module_0 = ActionModule()
    task_vars_0 = dict()
    result_0 = action_module_0.run(None, task_vars_0)
    assert result_0['failed'] is True

# Generated at 2022-06-25 07:01:30.432354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 398
    int_1 = 645
    float_0 = 0.87
    bytes_0 = b'8W\xbb'
    str_0 = '\x06\xebO\x1a\x12\x0c\x00\x00i\xb6\x03\x00\x00'
    list_0 = [int_0, int_0, int_0, int_1]

# Generated at 2022-06-25 07:01:32.957924
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:01:40.490741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 487.376313
    float_1 = 1894.424
    int_0 = 387
    list_0 = [float_0, int_0, int_0]
    bytes_0 = b'\x1c\xa7\xef\xf8\xaf\\'
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_0, bytes_0)
    var_0 = action_run(action_module_0)

# Test for expected output of ActionModule.run

# Generated at 2022-06-25 07:01:43.366515
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert false
    # TODO: Implement your test here
    # assert (expected_value, action_module_0)


# Generated at 2022-06-25 07:01:46.158624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:01:52.253259
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 3.2
    float_1 = 8.85
    int_0 = 5
    list_0 = [float_0, float_1, int_0]
    int_1 = 2
    bytes_0 = b'\xab\x08\xf8\xe2\x33\x1d\xce'
    int_2 = 60
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_1, bytes_0)
    assert action_module_0.run(int_2) is None

# Generated at 2022-06-25 07:02:00.603382
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 707.0797
    float_1 = 1246.5
    int_0 = 685
    list_0 = [float_1, int_0, float_0]
    bytes_0 = b'c\x98\x94\xa2\x89\xe9\x94\xc1'
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_0, bytes_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:02:01.496604
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 07:02:15.066295
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run()


# Generated at 2022-06-25 07:02:21.484795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2.940
    float_1 = 1.540
    int_0 = 532
    list_0 = [float_0, float_1, int_0]
    int_1 = 741
    bytes_0 = b'\x08\xe7\x14\x02\xb8\xbc\x98\x11\xff\x9d'
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_1, bytes_0)
    var_0 = action_module_0.run()
    # assert var_0 == 'SUCCESS'


# Generated at 2022-06-25 07:02:22.670758
# Unit test for constructor of class ActionModule
def test_ActionModule():
    running = 0
    for case in switch(running):
        if case(0):
            test_case_0()
            break
        if case():
            break

# Generated at 2022-06-25 07:02:28.656741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testcases
    # Running action 'group_by' can change the inventory
    res = ActionModule.run(tmp=None, task_vars=dict())
    assert res['failed'] is True
    assert res['msg'] == "the 'key' param is required when using group_by"
    # Running action 'group_by' without the required parameter 'key' fails
    res = ActionModule.run(tmp=None, task_vars=dict())
    assert res['failed'] is True
    assert res['msg'] == "the 'key' param is required when using group_by"

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:02:38.764265
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    str_0 = '-D^\x1d\xef\xd7\x80\x05\xa3\x8e\x1a'
    str_1 = '-D^\x1d\xef\xd7\x80\x05\xa3\x8e\x1a'
    str_2 = '-D^\x1d\xef\xd7\x80\x05\xa3\x8e\x1a'

    action_module_0 = ActionModule(str_0, str_1, str_2)
    var_2 = action_module_0.run()

    if var_2 == False:
        raise Error('unit test failed')


# Generated at 2022-06-25 07:02:48.857346
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an object of the built-in type 'float'
    float_0 = 487.376313
    # Create an object of the built-in type 'float'
    float_1 = 1894.424
    # Create an object of the built-in type 'int' (line number 18)
    int_0 = 387
    # Create an object of the built-in type 'list'
    list_0 = [float_0, int_0, int_0]
    # Create an object of the built-in type 'int'
    int_1 = 46
    # Create an object of the built-in type 'bytes' (line number 19)
    bytes_0 = b'\x1c\xa7\xef\xf8\xaf\\'
    # Create an object of class 'ActionModule'
    action_module_0

# Generated at 2022-06-25 07:02:49.813531
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 07:02:53.661428
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_object = ActionModule()
    assert action_object.run() == 'Passed'

# Generated at 2022-06-25 07:02:57.009821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 487.376313
    float_1 = 1894.424
    int_0 = 387
    list_0 = [float_0, int_0, int_0]
    bytes_0 = b'\x1c\xa7\xef\xf8\xaf\\'
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_0, bytes_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:03:01.247625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 487.376313
    float_1 = 1894.424
    int_0 = 387
    list_0 = [float_0, int_0, int_0]
    bytes_0 = b'\x1c\xa7\xef\xf8\xaf\\'
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_0, bytes_0)
    dict_0 = dict()
    dict_0['changed'] = False
    dict_0['add_group'] = '387-387-487.376313'
    dict_0['parent_groups'] = ['all']
    dict_1 = dict()
    dict_1['key'] = '387-387-487.376313'

# Generated at 2022-06-25 07:03:37.826083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 487.376313
    float_1 = 1894.424
    int_0 = 387
    list_0 = [float_0, int_0, int_0]
    bytes_0 = b'\x1c\xa7\xef\xf8\xaf\\'
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_0, bytes_0)
    assert action_module_0.run() == False

# Generated at 2022-06-25 07:03:44.217240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 487.211512
    float_1 = 1894.424
    int_0 = 387
    list_0 = [float_0, int_0, int_0]
    bytes_0 = b'\x1c\xa7\xef\xf8\xaf\\'
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_0, bytes_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:03:52.315459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    float_0 = float()
    float_1 = float()
    int_0 = int()
    list_0 = list()
    int_1 = int()
    bytes_0 = bytes()
    action_module_0.set_task(float_0, float_1, int_0, list_0, int_1, bytes_0)
    var_0 = action_module_0.run()
    assert var_0 == {
        'add_group': 'key',
        'changed': False,
        'parent_groups': ['all']
    }


# Generated at 2022-06-25 07:03:53.840666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:03:58.397989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:04:07.291459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 487.376313
    float_1 = 1894.424
    int_0 = 387
    list_0 = [float_0, int_0, int_0]
    bytes_0 = b'\x1c\xa7\xef\xf8\xaf\\'
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_0, bytes_0)
    print('# unit test for constructor of class ActionModule')
    print('# test ActionModule instantiation')
    print('# assert that the new created class is an type of ActionModule')
    print(action_module_0)
# End unit test


# Generated at 2022-06-25 07:04:12.555891
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 745.062
    float_1 = 1027.2886
    int_0 = 59
    list_0 = [float_0, int_0, int_0]
    bytes_0 = b'\x03\x9c\x01\xc5\xec\xd5'
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_0, bytes_0)


# Generated at 2022-06-25 07:04:17.752230
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Call constructor of class
    float_0 = float(0)
    float_1 = float(0)
    int_0 = int(0)
    list_0 = list()
    int_1 = int(0)
    bytes_0 = bytes(0)
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_1, bytes_0)
    # Check if methods of class are callable
    action_module_0.run()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:04:23.121460
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(var_1)
    test_ActionModule_0 = TestClass_0(action_module_0)
    test_ActionModule_0.test_case_0()



# Generated at 2022-06-25 07:04:29.159891
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0
    float_1 = 0
    int_0 = 0
    list_0 = []
    int_1 = 0
    bytes_0 = b''
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_1, bytes_0)
    return


# Generated at 2022-06-25 07:05:30.855817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up a test
    float_0 = 794.5727
    float_1 = 1583.912
    int_0 = 556
    list_0 = [float_1, int_0, int_0]
    bytes_0 = b'\x90\x8e\xdc\xfcs\x1b'
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_0, bytes_0)

    # Test the call
    var_0 = action_module_0.run(None, None)

    # Test the results
    assert var_0 == {}



# Generated at 2022-06-25 07:05:39.740605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 565.3858570089091
    float_1 = 52399.737
    int_0 = 697
    list_0 = [float_0, float_0]
    int_1 = 648
    bytes_0 = b'?\x1fC\x91)B\xdc\x9d\x83\xe4\x08'
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_1, bytes_0)
    action_module_0.run()


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:05:44.531041
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(['var'], {'vars': {'var': 'var'}})
    a.run()

# Generated at 2022-06-25 07:05:52.171859
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 487.376313
    float_1 = 1894.424
    int_0 = 387
    list_0 = [float_0, int_0, int_0]
    bytes_0 = b'\x1c\xa7\xef\xf8\xaf\\'
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_0, bytes_0)
    assert(action_module_0.float_0 == 487.376313)
    assert(action_module_0.float_1 == 1894.424)
    assert(action_module_0.int_0 == 387)
    assert(action_module_0.list_0 == [float_0, int_0, int_0])

# Generated at 2022-06-25 07:05:55.298016
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 487.376313
    float_1 = 1894.424
    int_0 = 387
    list_0 = [float_0, int_0, int_0]
    bytes_0 = b'\x1c\xa7\xef\xf8\xaf\\'
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_0, bytes_0)


# Generated at 2022-06-25 07:06:02.243696
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_1 = 564.396
    float_2 = 896.31
    int_2 = 96
    list_2 = [float_1, int_2, int_2]
    int_3 = 49
    bytes_1 = b'\xbb\x7f\x89\xdd\xcc\x1a'
    action_module_1 = ActionModule(float_1, float_2, int_2, list_2, int_3, bytes_1)
    assert action_module_1.TRANSFERS_FILES == False
    assert action_module_1._VALID_ARGS == frozenset({'parents', 'key'})
    assert action_module_1.run == action_run


# Generated at 2022-06-25 07:06:04.272693
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 2067
    obj_class_0 = test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 07:06:10.992335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 487.376313
    float_1 = 1894.424
    int_0 = 387
    list_0 = [float_0, int_0, int_0]
    bytes_0 = b'\x1c\xa7\xef\xf8\xaf\\'
    action_module_0 = ActionModule(float_0, float_1, int_0, list_0, int_0, bytes_0)
    action_module_0.run()
    assert result['failed'] == True
    assert result['msg'] == "the 'key' param is required when using group_by"


# Generated at 2022-06-25 07:06:13.119808
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule()
        assert False
    except Exception:
        assert True



# Generated at 2022-06-25 07:06:21.118868
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Boolean type, value is True
    float_0 = 1368.55
    float_1 = 1608.33
    # Boolean type, value is False
    list_0 = [float_0, float_1]
    bytes_0 = b'\xce\xd7\xbb\xa2\x0c~'
    action_module_0 = ActionModule(float_0, int_1, list_0, int_0, int_1, bytes_0)
    @add
    def ansible_facts(val):
        return val.get('ansible_facts')
    def test_func_0(name):
        if name == 'ansible_facts':
            return ansible_facts
    action_module_1 = test_func_0(action_module_0)
    group_name = action_module_1