

# Generated at 2022-06-25 06:57:39.726323
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible.GROUP_BY_KEY = ansible.GROUP_BY_PARENTS = ansible.JSON_VARS = None
    ansible.HOST_VARS = {"variable": "value"}
    float_0 = 46.8
    set_0 = set()
    int_0 = 92
    list_0 = []
    action_module_1 = ActionModule(float_0, float_0, set_0, int_0, list_0, None)
    assert action_module_1.run() == {'add_group': 'ansiblized', 'parent_groups': ['all'], 'changed': False}

# Generated at 2022-06-25 06:57:46.176020
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 46.8
    set_0 = {float_0}
    int_0 = 92
    list_0 = [float_0, set_0, int_0, int_0]
    action_module_0 = None
    action_module_1 = ActionModule(float_0, float_0, set_0, int_0, list_0, action_module_0)


# Generated at 2022-06-25 06:57:51.578308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test data
    tmp = None
    task_vars = None

    action_module_0 = None
    action_module_0 = ActionModule(tmp, task_vars)
    assert action_module_0.run(tmp, task_vars) == {"add_group": "key", "changed": False, "failed": True, "msg": "the 'key' param is required when using group_by", "parent_groups": ["all"]}

# Generated at 2022-06-25 06:57:56.542169
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule('value', 'value', 'value', 'value', 'value', 'value')
        print("ActionModule constructor works")
    except Exception:
        print("Error in ActionModule constructor")


# Generated at 2022-06-25 06:58:04.505111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    module_name_0 = 'c0'
    module_args_0 = 'd0'
    task_vars_0 = dict()
    tmp_0 = 'tmp'
    action_module_0.run(tmp_0, task_vars_0)
    action_module_0.run(module_args_0, task_vars_0)
    action_module_0.run(tmp_0, task_vars_0)
    action_module_0.run(module_args_0, task_vars_0)
    action_module_0.run(tmp_0, task_vars_0)
    action_module_0.run(module_args_0, task_vars_0)

# Generated at 2022-06-25 06:58:05.572131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:58:14.441818
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 92
    list_0 = [{'ssh', 46.8}, {'ssh', 46.8}, 92, 92]
    action_module_0 = None
    action_module_1 = ActionModule(46.8, 46.8, {'ssh', 46.8}, 92, list_0, action_module_0)
    action_module_2 = ActionModule(34.8, 34.8, {'ssh', 46.8}, 92, list_0, action_module_0)
    action_module_1.TRANSFERS_FILES = False
    del list_0[int_0]
    print(action_module_2.run(None, None))


if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 06:58:22.180258
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.common._collections_compat import frozenset
    float_0 = 46.8
    set_0 = {float_0}
    int_0 = 92
    list_0 = [float_0, set_0, int_0, int_0]
    action_module_0 = None
    action_module_3 = ActionModule(float_0, float_0, set_0, int_0, list_0, action_module_0)
    assert action_module_3._VALID_ARGS == frozenset({'parents', 'key'})
    assert action_module_3.TRANSFERS_FILES == False
    action_module_4 = ActionModule(float_0, float_0, set_0, int_0, list_0, action_module_0)
   

# Generated at 2022-06-25 06:58:23.034913
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:58:23.896737
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:58:27.718871
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = None
    action_module_0 = ActionModule(var_0, var_1)


# Generated at 2022-06-25 06:58:36.012512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostvars = dict()
    var_0 = 'group_by'
    var_1 = hostvars
    hostvars = dict()
    var_2 = ActionModule(var_0, var_1)
    var_3 = None
    var_4 = 'key'
    var_5 = 'parents'
    var_6 = 'all'
    var_7 = 'group1'
    expected = dict(failed=False, parent_groups=['all'],
                    add_group='group1', changed=False)
    actual = var_2.run(var_3, var_4, var_5, var_6, var_7)
    assert expected == actual


# Generated at 2022-06-25 06:58:44.810050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_3 = None
    var_1 = 'group_by'
    var_2 = {'args': {'key': var_1}}
    var_7 = {}
    var_6 = None
    var_5 = {'msg': 'the \'key\' param is required when using group_by', 'failed': True}
    var_4 = dict(tmp=var_6, task_vars=var_7)
    var_8 = ActionModule(var_2, var_3)
    var_9 = var_8.run(**var_4)
    var_10 = True
    var_12 = {}
    var_11 = 'all'
    var_14 = {}
    var_13 = 'change'

# Generated at 2022-06-25 06:58:54.432890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    action_module_0 = ActionModule(var_0, var_0)
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    action_result = action_module_0.run(var_1, var_2)
    try:
        assert var_1 is None
    except AssertionError as e:
        raise AssertionError(str(e) + " : " + str(var_1))

# Generated at 2022-06-25 06:58:58.673977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: Add test for the constructor here
    print('Test constructor here')


# Generated at 2022-06-25 06:59:02.447548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    action_module_0 = ActionModule(var_0, var_0)
    var_1 = None
    var_2 = None
    var_3 = action_module_0.run(var_1, var_2)
    assert isinstance(var_3, dict)



# Generated at 2022-06-25 06:59:11.299866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostvars_0 = dict()
    tmp_0 = None
    task_vars_0 = dict()

    # Call the method
    result_0 = ActionModule.run(ActionModule, tmp_0, task_vars_0)

    # Here is the expected result
    result_expected_0 = {
        "failed" : True,
        "msg" : "the 'key' param is required when using group_by"
    }

    # Check the result
    if result_0 != result_expected_0:
        print("expected: %s\ngot: %s" % (result_expected_0, result_0))

    # TODO: Check that all attributes match the expected value
    var_1 = None
    action_module_1 = ActionModule(var_1, var_1)


# Generated at 2022-06-25 06:59:13.369851
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = None
    var_2 = None
    action_module_1 = ActionModule(var_1, var_1)
    assert(isinstance(action_module_1, ActionModule))


# Generated at 2022-06-25 06:59:18.984700
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    obj_var_0 = type('', (object,), {})()
    obj_var_0.tmpdir = None
    obj_var_0.tmp = None
    obj_var_0.task_vars = {}
    obj_var_0.action = None
    obj_var_0.task = type('', (object,), {})()
    obj_var_0.task.args = {}
    obj_var_0.connection = None
    obj_var_0.play_context = None
    obj_var_0.new_stdin = None
    obj_var_0.loader = type('', (object,), {})()
    obj_var_0.templar = type('', (object,), {})()
    obj_var_0

# Generated at 2022-06-25 06:59:25.717476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = toto
    var_1 = toto
    action_module_0 = ActionModule()
    try:
        var_2 = toto
        var_3 = toto
        action_module_0.run(var_2, var_3)
        assert(var_2 == "toto")
        assert(var_3 == "toto")
    except:
        assert(var_2 == "toto")
        assert(var_3 == "toto")


# Generated at 2022-06-25 06:59:31.488427
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-25 06:59:38.886396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Init
  action_module_0 = ActionModule()
  task_0 = task()
  task_vars_0 = dict()

  # Test the following cases:
  #
  # Case 0
  #  - 
  tmp_0 = None
  task_vars_0 = None
  kwargs = {}
  result_0 = action_module_0.run(tmp_0, task_vars_0, **kwargs)
 


# Generated at 2022-06-25 06:59:41.117114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Expected parameters
    tmp = None
    task_vars = None

    # Instantiate object
    action_module = ActionModule()

    # Call method run with valid parameters
    action_module.run(tmp, task_vars)


# Generated at 2022-06-25 06:59:47.343698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule.TRANSFERS_FILES, 'TRANSFERS_FILES must be False'
    assert ActionModule._VALID_ARGS == {'parents', 'key'}, '_VALID_ARGS must be {\'parents\', \'key\'}'

# Generated at 2022-06-25 06:59:49.358349
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    print("\nProperties of class ActionModule:")
    print("\nProperties of class ActionModule")

# Generated at 2022-06-25 06:59:50.593029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()


# Generated at 2022-06-25 06:59:55.294802
# Unit test for constructor of class ActionModule
def test_ActionModule():
  instance = dict()
  ret = ActionModule(instance)


# Generated at 2022-06-25 07:00:00.094863
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionBase)


# Generated at 2022-06-25 07:00:01.122831
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    print (action_module_0)

# Generated at 2022-06-25 07:00:07.088271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert action_module_1._task.args.get('key') == None
    assert action_module_1._task.args.get('parents') == None
    assert action_module_1.TRANSFERS_FILES == False


# Generated at 2022-06-25 07:00:16.932026
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 348
    float_0 = 949.2
    list_0 = [int_0, float_0]
    str_0 = 'inactive'
    float_1 = 458.8
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    assert action_module_0 is not None

# Generated at 2022-06-25 07:00:20.353378
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:00:26.751664
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 350
    float_0 = 944.0
    list_0 = [int_0, float_0]
    str_0 = 'inactive'
    float_1 = 443.1
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    assert(action_module_0.TRANSFERS_FILES == False)
    assert(action_module_0._VALID_ARGS == frozenset({'key', 'parents'}))
    assert(action_module_0 == action_module_0)
    

# Generated at 2022-06-25 07:00:35.686624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 941
    float_0 = 988.2
    list_0 = [int_0, float_0]
    str_0 = 'inactive'
    float_1 = 521.8
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    bool_0 = True
    bool_1 = False
    action_module_1 = ActionModule(action_module_0, bool_0, action_module_0, bool_1, list_0, list_0)
    var_1 = action_module_1.run()
    int_1 = 515
    float_2 = 672.1
    list_1 = [int_0, int_1, float_2]

# Generated at 2022-06-25 07:00:38.987258
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:00:39.780007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:00:47.393109
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 638
    float_0 = 567.7
    list_0 = [int_0, float_0]
    str_0 = 'asynchronous'
    float_1 = 845.2
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    bool_0 = False
    bool_1 = True
    action_module_1 = ActionModule(action_module_0, bool_0, action_module_0, bool_1, list_0, list_0)


# Generated at 2022-06-25 07:00:48.133824
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:00:58.462146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 348
    float_0 = 949.2
    list_0 = [int_0, float_0]
    str_0 = 'inactive'
    float_1 = 458.8
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    bool_0 = True
    bool_1 = False
    action_module_1 = ActionModule(action_module_0, bool_0, action_module_0, bool_1, list_0, list_0)
    tmp_0 = None
    task_vars_0 = None
    bool_2 = True
    bool_3 = False
    action_module_1 = Acti

# Generated at 2022-06-25 07:01:09.148410
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = list()
    dict_0 = dict()
    str_0 = str()
    str_1 = str()
    # bool_0 = bool()
    float_0 = float()
    float_1 = float()
    int_0 = int()

    list_1 = list()
    int_1 = int()
    float_2 = float()
    str_2 = str()
    float_3 = float()
    set_0 = set()
    str_3 = str()
    list_2 = list()
    str_4 = str()

    # 1. Test with valid args
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_1)
    # action_module_0.run(tmp: bool_0, task_

# Generated at 2022-06-25 07:01:25.834088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    stdin_0 = Boolean()
    stdin_1 = Boolean()
    stdin_2 = stdin_0
    stdin_3 = stdin_1
    stdin_4 = 'unicorn'
    stdin_5 = -2.31
    tmpdir_1 = '/tmp/ymwec2d3'
    tmpdir_2 = tmpdir_1
    tmpdir_3 = tmpdir_1
    tmpdir_4 = tmpdir_1
    tmpdir_5 = tmpdir_1
    action_module_0 = ActionModule(stdin_4, stdin_5, stdin_2, stdin_3, stdin_4, tmpdir_1, tmpdir_2, tmpdir_3, tmpdir_4, tmpdir_5)
    action_module_0.run()

# Generated at 2022-06-25 07:01:32.992734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 348
    float_0 = 949.2
    list_0 = [int_0, float_0]
    str_0 = 'inactive'
    float_1 = 458.8
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    bool_0 = True
    bool_1 = False
    action_module_1 = ActionModule(action_module_0, bool_0, action_module_0, bool_1, list_0, list_0)
    int_1 = 348
    float_2 = 949.2
    list_1 = [int_0, float_0]
    str_1 = 'inactive'
    float_3 = 458.8
    action_module_2 = ActionModule

# Generated at 2022-06-25 07:01:33.561917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:01:39.197911
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 348
    float_0 = 949.2
    list_0 = [int_0, float_0]
    str_0 = 'inactive'
    float_1 = 458.8
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)


# Generated at 2022-06-25 07:01:39.866567
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:01:44.162807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 348
    float_0 = 949.2
    list_0 = [int_0, float_0]
    str_0 = 'inactive'
    float_1 = 458.8
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    bool_0 = True
    bool_1 = False
    action_module_1 = ActionModule(action_module_0, bool_0, action_module_0, bool_1, list_0, list_0)
    var_0 = action_module_1.run()
    assert var_0 is None

# Generated at 2022-06-25 07:01:46.247331
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:01:52.871475
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 348
    float_0 = 949.2
    list_0 = [int_0, float_0]
    str_0 = 'inactive'
    float_1 = 458.8
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    bool_0 = True
    bool_1 = False
    action_module_1 = ActionModule(action_module_0, bool_0, action_module_0, bool_1, list_0, list_0)
    var_0 = action_module_1.run()

# Generated at 2022-06-25 07:02:02.330287
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test cases for class constructor
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    int_0 = 348
    float_0 = 949.2
    list_0 = [int_0, float_0]
    str_0 = 'inactive'
    float_1 = 458.8
    action_module_1 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    var_1 = action_module_1.run()
    bool_0 = True
    bool_1 = False
    action_module_2 = ActionModule(action_module_0, bool_0, action_module_0, bool_1, list_0, list_0)
    var_2 = action_module_2.run()

# Generated at 2022-06-25 07:02:12.722993
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 348
    float_0 = 949.2
    list_0 = [int_0, float_0]
    str_0 = 'inactive'
    float_1 = 458.8
    action_module_1 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    int_1 = 496
    float_2 = 757.2
    list_1 = [int_1, float_2]
    str_1 = 'inactive'
    float_3 = 157.3
    action_module_2 = ActionModule(int_1, float_2, list_1, str_1, float_3, list_1)
    int_2 = 868
    float_4 = 429.6

# Generated at 2022-06-25 07:02:30.943194
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 567
    float_0 = 823.8
    list_0 = [int_0, float_0]
    str_0 = 'inactive'
    float_1 = 153.4
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    test_case_0()


# Generated at 2022-06-25 07:02:31.916860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:02:40.600157
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 720
    float_0 = 746.4
    list_0 = [int_0, float_0]
    str_0 = 'disabled'
    float_1 = 466.0
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    assert action_module_0._task == 720
    assert action_module_0._connection == 746.4
    assert action_module_0._play_context == [720, 746.4]
    assert action_module_0._tqm == 'disabled'
    assert action_module_0.in_data == 466.0
    assert action_module_0.args == [720, 746.4]

# Generated at 2022-06-25 07:02:49.980499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 348
    float_0 = 949.2
    list_0 = [int_0, float_0]
    str_0 = 'inactive'
    float_1 = 458.8
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    bool_0 = True
    bool_1 = False
    action_module_1 = ActionModule(action_module_0, bool_0, action_module_0, bool_1, list_0, list_0)
    int_1 = 578
    float_2 = 394.28
    list_1 = [int_1, float_2]
    str_1 = 'inactive'
    float_3 = 633.15

# Generated at 2022-06-25 07:02:56.137458
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 348
    float_0 = 949.2
    list_0 = [int_0, float_0]
    str_0 = 'inactive'
    float_1 = 458.8
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    bool_0 = True
    bool_1 = False
    action_module_1 = ActionModule(action_module_0, bool_0, action_module_0, bool_1, list_0, list_0)
    var_0 = action_module_1.run()
    if (var_0 != None):
        if (not (isinstance(var_0, dict))):
            raise Exception('Failed')

# Generated at 2022-06-25 07:02:59.908797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 348
    float_0 = 949.2
    list_0 = [int_0, float_0]
    str_0 = 'inactive'
    float_1 = 458.8
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 07:03:06.216612
# Unit test for constructor of class ActionModule
def test_ActionModule():
    key = 'apache'
    parents = ['webservers']
    action_module_0 = ActionModule(key, parents)
    assert action_module_0.key == 'apache'
    assert action_module_0.parents == ['webservers']


# Generated at 2022-06-25 07:03:12.451946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 922
    float_0 = 938.0
    list_0 = [int_0, float_0]
    str_0 = 'nTgfr'
    float_1 = 80.0
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    dict_0 = dict()
    var_0 = action_module_0.run(None, dict_0)
    var_0 = action_module_0.run(None, dict_0)
    var_0 = action_module_0.run(None, dict_0)
    var_0 = action_module_0.run(None, dict_0)

# Generated at 2022-06-25 07:03:16.610729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:03:24.287460
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 518
    float_0 = 868.7
    float_1 = 985.6
    float_2 = 930.8
    float_3 = 823.5
    list_0 = [int_0, float_0, float_1, float_2, float_3]
    str_0 = 'inactive'
    list_1 = [int_0, float_0, float_1, float_2, float_3]
    str_1 = 'inactive'
    str_2 = 'inactive'
    list_2 = [str_0, list_1, str_1, str_2]
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, list_1, list_2)
    bool_0 = True
    bool

# Generated at 2022-06-25 07:04:02.630547
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3
    float_0 = 6.6
    list_0 = [int_0, float_0]
    str_0 = 'ok'
    float_1 = 5.4
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    assert True # TODO: implement your test here


# Generated at 2022-06-25 07:04:08.415632
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(str_0, int_0, list_0, str_1, float_1, list_1)
    assert type(action_module_0.run()) == dict, "Bad type of type"
    assert type(action_module_0.run(task_vars=23, tmp='tmp')) == dict, "Bad type of type"


# Generated at 2022-06-25 07:04:09.545781
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(0)


# Generated at 2022-06-25 07:04:17.317293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 348
    float_0 = 949.2
    list_0 = [int_0, float_0]
    str_0 = 'inactive'
    float_1 = 458.8
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    bool_0 = True
    bool_1 = False
    action_module_1 = ActionModule(action_module_0, bool_0, action_module_0, bool_1, list_0, list_0)
    var_0 = action_module_1.run()
    bool_0 = True
    bool_1 = False
    action_module_0 = action_module_1

# Generated at 2022-06-25 07:04:28.117403
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from types import NoneType
    from ansible.module_utils.six import string_types
    int_0 = 348
    float_0 = 949.2
    list_0 = [int_0, float_0]
    str_0 = 'inactive'
    float_1 = 458.8
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    bool_0 = True
    bool_1 = False
    action_module_1 = ActionModule(action_module_0, bool_0, action_module_0, bool_1, list_0, list_0)
    var_0 = action_module_1.run()
    assert isinstance(var_0, dict)
    assert 'changed' in var_0

# Generated at 2022-06-25 07:04:30.665117
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 837
    float_0 = 787.0
    list_0 = [int_0, float_0]
    action_module_0 = ActionModule(int_0, float_0, list_0)
    action_module_0.run()

# Generated at 2022-06-25 07:04:36.223683
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule(417.6, 745.2, 'component', 'get_url', 465.8, 490, 'set_fact', 'get_url')
    var_1 = {}
    var_1 = var_0.run(var_1)
    var_2 = int()
    var_2 = var_1['changed']
    var_3 = str()
    var_3 = var_1['add_group']
    var_4 = list()
    var_4 = var_1['parent_groups']
    var_5 = dict()
    var_5 = var_1['failed']
    assert var_2 == False, var_2
    assert var_3 == 'component', var_3
    assert var_4 == ['all'], var_4
    assert var_5 == False, var_5

# Generated at 2022-06-25 07:04:45.593713
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Define parameters and expected result of constructor
    int_0 = 348
    float_0 = 949.2
    list_0 = [int_0, float_0]
    str_0 = 'inactive'
    float_1 = 458.8
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    bool_0 = True
    bool_1 = False
    action_module_1 = ActionModule(action_module_0, bool_0, action_module_0, bool_1, list_0, list_0)
    var_0 = action_module_1.run()



# Generated at 2022-06-25 07:04:56.543828
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 348
    float_0 = 949.2
    list_0 = [int_0, float_0]
    str_0 = 'inactive'
    float_1 = 458.8
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_1['changed'] = True
    dict_1['msg'] = 'fatal'
    dict_1['invocation'] = dict()
    dict_1['invocation']['module_name'] = 'name'
    dict_1['invocation']['module_args'] = dict()

# Generated at 2022-06-25 07:05:00.987852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Default arguments
    action_module_x = ActionModule()
    assert isinstance(action_module_x.TRANSFERS_FILES, bool)
    assert isinstance(action_module_x._VALID_ARGS, frozenset)


# Generated at 2022-06-25 07:06:19.701342
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert actionModule.TRANSFERS_FILES is False
    assert actionModule._VALID_ARGS == frozenset({'parents', 'key'})

# Generated at 2022-06-25 07:06:24.771425
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 348
    float_0 = 949.2
    list_0 = [int_0, float_0]
    str_0 = 'inactive'
    float_1 = 458.8
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    bool_0 = True
    bool_1 = False
    action_module_1 = ActionModule(action_module_0, bool_0, action_module_0, bool_1, list_0, list_0)
    var_0 = action_module_1.run()


# Generated at 2022-06-25 07:06:28.528468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 100
    float_0 = 0.906
    list_0 = [int_0, float_0]
    str_0 = 'changed'
    float_1 = 263.4
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:06:31.520496
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 832
    float_0 = 757.07
    list_0 = [int_0, int_0]
    str_0 = 'no'
    float_1 = 21.22
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    action_module_0.run()

# Generated at 2022-06-25 07:06:33.913547
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    pass

# Generated at 2022-06-25 07:06:39.029853
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = ['th=', '\\', 'gpy']
    str_0 = 'Ht%$'
    tuple_0 = ('z5', str_0, 'BG<')
    dict_0 = dict()
    dict_0['Tu'] = tuple_0
    dict_0['Kj'] = tuple_0
    dict_1 = dict()
    dict_1['8W'] = list_0
    dict_1['R*'] = dict_0
    dict_1['+'] = dict_0
    dict_1['w+'] = dict_0
    dict_1['lK'] = tuple_0
    dict_1['f'] = dict_0
    dict_2 = dict()
    dict_2['x'] = dict_0
    dict_2['HG'] = dict_0
    dict

# Generated at 2022-06-25 07:06:42.321472
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 811.4
    str_0 = 'active'
    action_module_0 = ActionModule(float_0, float_0, float_0, str_0, float_0, float_0)
    float_1 = float_0
    assert float_1 == float_0
    assert action_module_0._handle_warnings
    assert action_module_0._supports_async


# Generated at 2022-06-25 07:06:45.778333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 574
    float_0 = 289.5
    list_0 = ['foo', 'bar']
    str_0 = 'zqfu'
    float_1 = 179.9
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:06:49.704246
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 246
    list_0 = [int_0]
    str_0 = 'always'
    int_1 = 455
    action_module_0 = ActionModule(int_0, int_1, list_0, str_0, int_1, list_0)
    var_0 = action_module_0.run()
    assert(var_0['changed'] == False)
    bool_0 = True
    assert(var_0['failed'] == bool_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:06:59.308833
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 348
    float_0 = 949.2
    list_0 = [int_0, float_0]
    str_0 = 'inactive'
    float_1 = 458.8
    action_module_0 = ActionModule(int_0, float_0, list_0, str_0, float_1, list_0)
    bool_0 = True
    bool_1 = False
    action_module_1 = ActionModule(action_module_0, bool_0, action_module_0, bool_1, list_0, list_0)
    var_0 = action_module_1.run()
    assert isinstance(var_0, dict) and var_0['changed'] == False and var_0['add_group'] == '348' and var_0['parent_groups'] == ['all']