

# Generated at 2022-06-25 06:57:33.637659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 06:57:35.801446
# Unit test for constructor of class ActionModule
def test_ActionModule():
  try:
    ActionModule()
  except NameError:
    assert False


# Generated at 2022-06-25 06:57:42.665343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate an object of class ActionModule
    actionBase_0 = ActionBase()
    actionBase_0.name = 'debug'
    actionBase_0.action = 'debug'
    actionBase_0.args = {'msg': 'Hello World'}
    actionBase_0.retries = 3
    actionBase_0.delay = 5
    actionBase_0.context = dict()
    actionBase_0.static = dict()
    actionBase_0.socket_path = '/path/to/socket'
    actionModule_0 = ActionModule()
    actionModule_0.name = 'debug'
    actionModule_0.action = 'debug'
    actionModule_0.args = {'msg': 'Hello World'}
    actionModule_0.retries = 3
    actionModule_0.delay = 5
    action

# Generated at 2022-06-25 06:57:52.036316
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionBase_0 = ActionBase(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    ActionModule_0 = ActionModule(task=None, connection=ActionBase_0, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    dict_0 = {"foo": "bar", "baz": "qux"}
    dict_1 = {"foo": "bar", "baz": "qux", "zoo": "loo"}

    # Test 'tmp' parameter
    assert ActionModule_0.run(tmp=dict_0) == dict_1

    # Test 'task_vars' parameter
    assert ActionModule_0.run(tmp=None, task_vars=dict_0) == dict_1

# Generated at 2022-06-25 06:57:55.093706
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fixture_gen = test_case_0()


# Generated at 2022-06-25 06:57:57.662196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    t0 = test_int(42)

    while t0 < test_min(t0):
        test_bool(bool())
    test_int(42)



# Generated at 2022-06-25 06:58:04.682020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    ActionModule run
    '''
    task_vars = {list_0: list_0, list_0: list_0}
    tmp = {dict_0: list_0, list_0: list_0}
    #Pass
    group_name = {dict_0: list_0, list_0: list_0}
    parent_groups = {dict_0: list_0, list_0: list_0}
    if ActionModule.run(group_name, parent_groups, tmp, task_vars, group_name, parent_groups) and (not ActionModule.run(group_name, parent_groups, tmp, task_vars, group_name, parent_groups)):
        pass
    #Pass


# Generated at 2022-06-25 06:58:07.619382
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    data_0 = None
    data_1 = None
    action_module_0 = ActionModule()
    data_0 = action_module_0.run(data_1)


# Generated at 2022-06-25 06:58:15.154093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    tmp = None

    # Test case with default params
    _task = {"args":{}}
    _result = {"failed":False, "changed":False}
    _result.update({"add_group":None, "parent_groups":'all'})
    action_module = ActionModule(task=_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp, task_vars)
    assert result == _result

    # Test case with the key 'a' in args
    _task = {"args":{"key":'a'}}
    _result = {"failed":False, "changed":False}

# Generated at 2022-06-25 06:58:21.223933
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {'dict_0': 'dict_0', 'dict_0': 'dict_0', 'dict_0': 'dict_0'}
    list_0 = ['str_0', 'str_0', 'str_0', 'str_0', 'str_0']
    dict_1 = {'list_0': list_0, 'str_0': 'str_0', 'str_0': 'str_0', 'str_0': 'str_0'}
    ActionModule(dict_0, 'dict_0', dict_1, list_0, 'dict_0', 'str_0')


# Generated at 2022-06-25 06:58:29.266138
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    actionbase_0 = ActionBase()

    # These are the variables needed for this test
    # The second one is to keep backward compatibility with ansible < 2.4
    task_vars = {
        'ansible_verbosity': 0,
        'ansible_verbosity_args': ['0']
    }

    # Run the run method for testing.
    actionbase_0.run(tmp, task_vars)

    #assert that the run method is working
    if actionbase_0 == '\n    ActionModule run\n    ':
        test_case_0()
        #print ('The run method of the ActionModule class is working.')
    else:
        print ('The run method of the ActionModule class is not working.')



# Generated at 2022-06-25 06:58:34.565815
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:58:35.962744
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n    ActionModule run\n    '


# Generated at 2022-06-25 06:58:38.615675
# Unit test for constructor of class ActionModule
def test_ActionModule():
    _1 = '\n    ActionModule run\n    '



# Generated at 2022-06-25 06:58:42.226132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\n    ActionModule run\n    '

    action_base_0 = ActionBase(str_0)

    action_module_0 = ActionModule(str_0)
    deque_0 = deque()
    dict_0 = dict()
    action_module_0.run(deque_0, dict_0)
#     test_case_0()


# Generated at 2022-06-25 06:58:47.119393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    this = ActionModule()
    class_name_0 = test_case_0.__name__
    class_name_1 = str(this.__class__).split('.')[-1].strip('>')
    assert class_name_0 == class_name_1

# Generated at 2022-06-25 06:58:56.228929
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test case for method run
    # Test return type for method run of class ActionModule
    assert_equal(isinstance(ActionModule.run(), dict), True)
    # Test return type for method run of class ActionModule
    assert_equal(isinstance(ActionModule.run(tmp, task_vars), dict), True)
    # Test return type for method run of class ActionModule
    assert_equal(isinstance(ActionModule.run(tmp=tmp, task_vars=task_vars), dict), True)
    # Test return type for method run of class ActionModule
    assert_equal(isinstance(ActionModule.run(tmp=tmp), dict), True)
    # Test return type for method run of class ActionModule
    assert_equal(isinstance(ActionModule.run(task_vars=task_vars), dict), True)
   

# Generated at 2022-06-25 06:58:59.643958
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_4 = '\n    Create inventory groups based on variables \n    '
    var_6 = str_4
    var_8 = 'ActionModule'
    var_7 = type(var_8, (), {})
    var_7.run = lambda self, tmp=None, task_vars=None: test_case_0()
    var_6 = var_7()
    var_9 = 'run'
    var_10 = ()
    var_11 = {}
    var_6 = getattr(var_6, var_9)(*var_10, **var_11)
    return var_6


# Generated at 2022-06-25 06:59:04.987120
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-25 06:59:07.025015
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {}
    args = {}
    task_vars = {}

    action_module = ActionModule(task, args, task_vars)


# Generated at 2022-06-25 06:59:20.921181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'tmp'
    str_2 = 'task_vars'
    str_3 = 'the \'key\' param is required when using group_by'
    str_4 = 'failed'
    str_5 = 'msg'
    str_6 = 'key'
    str_7 = 'add_group'
    str_8 = '-'
    str_9 = 'parents'
    str_10 = 'all'
    str_11 = 'parent_groups'
    str_12 = 'changed'


    obj_0 = ActionModule()
    obj_1 = obj_0
    obj_0._task = obj_1

    # Test case call to ActionModule.run
    obj_2 = ActionModule.run(obj_0, str_1, str_2)

# Generated at 2022-06-25 06:59:26.755274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_arg_1 = '\n    ActionModule run\n    '
    str_arg_2 = '\n    ActionModule run\n    '
    # Creation of the test object instance
    obj = ActionModule(str_arg_1, str_arg_2)
    # Calling the run method on this object
    obj.run()


# Tests for the class ActionBase

# Generated at 2022-06-25 06:59:30.531979
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    str_1 = '\n    Create inventory groups based on variables\n    '
    action_module_0.run()
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:59:41.625965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp0 = None
    task_vars0 = None
    action_module0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module0._task.args == None
    assert action_module0._task.dep_chain == None
    assert action_module0._task.loop == None
    assert action_module0._task.loop_args == None
    assert action_module0._task.name == None
    assert action_module0._task.tags == None
    assert action_module0._task.when == None
    assert action_module0._task.notify == None
    assert action_module0._task.notified_by == None
    assert action_module0._task.register == None
    assert action_

# Generated at 2022-06-25 06:59:45.007959
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

# Generated at 2022-06-25 06:59:53.133579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'module_utils.six.string_types'
    str_1 = 'ansible.module_utils.six.string_types'
    str_2 = 'action.ActionBase'
    str_3 = 'ansible.plugins.action.ActionBase'
    str_4 = 'group_by'
    str_5 = '\n    \n        ActionModule run\n        '
    str_6 = 'the \'key\' param is required when using group_by'


# End of unit tests

if __name__ == '__main__':
    import sys
    import os
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:00:03.314529
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:00:13.819714
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\n    ActionModule run\n    '
    str_1 = 'test_files/test_file_0'
    dict_0 = {'Standard': [0, 1, 2, 3], 'Standard': [0, 1, 2, 3], 'Standard': [0, 1, 2, 3]}
    dict_1 = {'META': [5, 4, 3, 2], 'META': [5, 4, 3, 2], 'META': [5, 4, 3, 2]}
    dict_2 = {'DEFAULT': [4, 3, 2, 1], 'DEFAULT': [4, 3, 2, 1], 'DEFAULT': [4, 3, 2, 1]}

# Generated at 2022-06-25 07:00:17.713587
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.plugins.action.group_by
    # Create instance of class ActionModule with fake input
    t = ansible.plugins.action.group_by.ActionModule()

    # Test method call with fake input
    args = {}
    assert t.run(args) == None



# Generated at 2022-06-25 07:00:25.483907
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_0 = ActionModule()
    str_0 = '\n    ActionModule run\n    '
    obj_0._ds = dict()
    obj_0._task = dict()
    obj_0.play_context = dict()
    obj_0._play = dict()
    obj_0.display = dict()
    obj_0._play_context = dict()
    obj_0._loader = dict()
    obj_0._templar = dict()
    tmp = dict()
    task_vars = dict()
    obj_0.run(tmp, task_vars)
    obj_0._VALID_ARGS = frozenset(('key', 'parents'))
    obj_0._task.args = dict()
    obj_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:00:32.975321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_1 = ActionModule()


# Generated at 2022-06-25 07:00:42.788114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('____________________________________')
    print(ActionModule.run.__doc__)
    print('____________________________________')


# Generated at 2022-06-25 07:00:49.122841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule_obj = ActionModule('tmp')
    actionmodule_obj._task = 'tmp'
    actionmodule_obj.TRANSFERS_FILES = 'False'
    assert actionmodule_obj.run() == 'tmp'

# Generated at 2022-06-25 07:00:55.393224
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule()
    assert {} == result._templar.available_variables
    assert {} == result._shared_loader_obj.module_loader.module_vars

# Generated at 2022-06-25 07:01:02.026583
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare variables
    str_0 = '\n    ActionModule run\n    '
    str_1 = '\n    ActionModule run\n    '
    tmp_0 = None
    task_vars_0 = None
    # Setup
    # Cleanup
    # Teardown
    # Template: '\n    ActionModule run\n    '
    # Template: '\n    ActionModule run\n    '
    # Template: '\n    ActionModule run\n    ',
    parent_groups_0 = None
    add_group_0 = None
    changed_0 = None
    msg_0 = None
    failed_0 = None
    result_0 = None
    # Template: '\n    ActionModule run\n    ',
    parent_groups_1 = None
    add_group_1 = None

# Generated at 2022-06-25 07:01:11.004674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'action/group_by.py'
    str_1 = '\n    Create inventory groups based on variables \n    '
    str_2 = '\n        We need to be able to modify the inventory\n        '
    str_3 = 'frozenset({\'parents\', \'key\'})'
    str_4 = 'the \'key\' param is required when using group_by'

# Generated at 2022-06-25 07:01:16.209274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # JobData is an alias of dict
    job_data = dict()
    # We create the instance of ActionModule and pass the job_data in
    # No need to create an instance of ActionModule
    # The class name is enough to call the static method
    tmp = None
    task_vars = None
    # The return value of run is an instance of dict
    res1 = 'ActionModule'[7:].upper() + ' run'
    # We use the run method of ActionModule
    # res2 is an instance of dict
    res2 = ActionModule.run(tmp, task_vars, job_data)
    # Since res2 is an instance of dict, we can traverse it like a dict
    res3 = 'ActionModule'[7:].upper() + ' run'
    # The key of 'msg' exists in res2
   

# Generated at 2022-06-25 07:01:21.500073
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(module, ActionModule)


# Generated at 2022-06-25 07:01:28.214864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if test.test_mode == True:
        test_case_0()
        test_case_ActionBase()
        test_case_Base()
    else:
        action = {}
        task_vars = {}
        action.setdefault('args', {})
        action['args']['key'] = 'values'
        action['args']['parents'] = 'base'
        test = ActionModule(action, task_vars)
        result = test.run()
        print(result)
        print(result['changed'])
        print(result['add_group'])
        print(result['parent_groups'])


# Generated at 2022-06-25 07:01:33.895701
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:01:57.462287
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:02:02.579105
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\n    ActionModule run\n    '
    # It is a mock object type
    # http://docs.python.org/2/library/unittest.mock.html#unittest.mock.Mock
    # The return value of __init__ is None
    assert callable(ActionModule.run)

# Generated at 2022-06-25 07:02:13.254499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create ansible task to mock
    mock_task = AnsibleTask()
    # Create ansible options to mock
    mock_options = AnsibleOptions()
    mock_options.remote_tmp='/tmp/.ansible/tmp'
    # Create ansible result to mock
    mock_result = AnsibleResult()
    # Create ansible module_utils to mock
    mock_module_utils = AnsibleModuleUtils()
    mock_module_utils.HAS_ITERTOOLS = True
    mock_module_utils.HAS_FUTURE_KWARGS = False
    mock_module_utils.HAS_FUTURE_UNPACKING = False
    # Create ansible classloader to mock
    mock_classloader = AnsibleClassLoader()
    # Create ActionModule instance to test

# Generated at 2022-06-25 07:02:16.292192
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp_0 = None
    task_vars_0 = dict()
    action_module_0 = ActionModule(tmp_0, task_vars_0)
    del tmp_0, task_vars_0


# Generated at 2022-06-25 07:02:21.567598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = assert_raises(TypeError, ActionModule)
    str_2 = assert_raises(AnsibleUndefinedVariable, test_case_0)
    # TODO: Test with key, parents
    pass


# Generated at 2022-06-25 07:02:27.210689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with args.
    task_vars_0 = {
        'key': None,
        'y': 'parents',
    }
    tmp_0 = None
    # The _VALID_ARGS value is defined here because it could not be imported
    # directly from the module.
    _VALID_ARGS_0 = frozenset(('key', 'y'))
    ans = ActionModule(task_vars_0, tmp_0, _VALID_ARGS_0)
    ans.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:02:28.883390
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_0 = ActionModule(task=None)
    assert_equals(obj_0._task.call_count, 0)


# Generated at 2022-06-25 07:02:39.661132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook import play
    from ansible.playbook.task import Task

    from ansible.module_utils.six import string_types

    host_0 = Host()
    task_0 = Task()
    task_0._role = None
    task_0._parent = play
    task_0._block = None
    task_0._role = None
    task_0._task_deps = None
    task_0._loop = None
    task_0.action = 'group_by'
    task_0.args = dict(**{'key': 'test1', 'parents': ['all']})
    task_0.name = str_0

    host_0.name = 'test1'
    task_0.delegate_to = None
    task_0.notify = []

# Generated at 2022-06-25 07:02:45.548032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    group_name = 'example'

    parent_groups = 'example'

    str_0 = '\n    ActionModule run\n    '

    str_1 = '\n    ActionModule run\n    '

    str_2 = '\n    ActionModule run\n    '

    pass



# Generated at 2022-06-25 07:02:49.164433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing constructor of class ActionModule')
    print('Creating instance:')
    instance = ActionModule()
    instance.run(None, None)


# Generated at 2022-06-25 07:03:21.839348
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0() == None

# Generated at 2022-06-25 07:03:24.860776
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('\n==== test_ActionModule_run ====')
    print('\n==== test_ActionModule_run ====\n')
    tmp = ActionBase
    task_vars = None
    test_0 = ActionModule(tmp,task_vars)
    test_0.run()



# Generated at 2022-06-25 07:03:33.657260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_base_0 = ActionBase()
    action_module_0 = ActionModule(action_base_0)
    str_0 = '\n    ActionModule run\n    '
    str_1 = '\n    ActionModule run\n    '
    action_module_0.run(str_0, str_1)
    str_2 = '\n    ActionModule run\n    '
    str_3 = '\n    ActionModule run\n    '
    action_module_0.run(str_2, str_3)
    str_4 = '\n    ActionModule run\n    '
    str_5 = '\n    ActionModule run\n    '
    action_module_0.run(str_4, str_5)

if __name__ == '__main__':
    test_

# Generated at 2022-06-25 07:03:34.880592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:03:40.947568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
    task = {
        'args': {
            'key': 'group_name',
            'parents': 'parent_groups'
        }
    }
    connection = 'connection'
    play_context = 'play_context'
    loader = 'loader'
    templar = 'templar'
    shared_loader_obj = 'shared_loader_obj'
    a = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    #testing the instance created
    assert a._task == {
        'args': {
            'key': 'group_name',
            'parents': 'parent_groups'
        }
    }

# Generated at 2022-06-25 07:03:50.362765
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\n    ActionModule constructor\n    '
    str_1 = '\n    ActionModule run\n    '
    str_2 = '\n    ActionModule run\n    '
    str_3 = '\n    ActionModule run\n    '
    str_4 = '\n    ActionModule run\n    '
    str_5 = '\n    ActionModule run\n    '
    str_6 = '\n    ActionModule run\n    '

if __name__ == '__main__':
    import sys
    import pycallgraph
    with pycallgraph.PyCallGraph(output=sys.stdout):
        test_ActionModule()
        test_case_0()

# Generated at 2022-06-25 07:03:54.350012
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert not (obj.run(tmp=None))

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 07:03:58.515116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    j = ActionModule()
    assert False # TODO: implement your test here


# Generated at 2022-06-25 07:04:02.696449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == None, 'test_case_0 failed'

# Function run

# Generated at 2022-06-25 07:04:08.759453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Check the non-existence of variables
    # Arguments:
    #  self: the ActionModule to be checked
    #  tmp: not supported yet
    #  task_vars: the variables of the task to be checked
    # Return:
    #  run result for the test
    # Usage:
    #  run(self, tmp, task_vars)
    str1 = '\n    ActionModule run\n    '
    

# Generated at 2022-06-25 07:05:10.701343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    string_0 = '\n    ActionModule run\n    '
    argument_group_name = '\xfa\x06\xfe\x04\xe4\x8b\x0f'
    argument_parent_groups = '\x05\x1d\xf9\x1c]\x8b\xdb\x84\xde\x01'
    bool_0 = True
    expected_0 = {'msg': "the 'key' param is required when using group_by", 'failed': bool_0}

# Generated at 2022-06-25 07:05:11.205259
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:05:17.152861
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\n    ActionModule run\n    '
    tmp_tuple_0 = (1, 2)
    task_vars_tuple_0 = (None, )
    task_vars_dict_0 = dict()
    task_vars_bool_0 = False
    task_vars_dict_1 = dict()
    task_vars_dict_0['key'] = task_vars_dict_1
    task_vars_dict_1['parents'] = task_vars_bool_0
    task_vars_dict_0['key'] = task_vars_dict_1
    
    obj_actionmodule_0 = ActionModule()
    obj_actionmodule_0.run(tmp_tuple_0, task_vars_tuple_0)

# Generated at 2022-06-25 07:05:18.923435
# Unit test for constructor of class ActionModule
def test_ActionModule():
    group_name = str()
    parent_groups = str()
    result = ActionModule(group_name, parent_groups)


# Generated at 2022-06-25 07:05:24.938977
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\n    ActionModule run\n    '

# Generated at 2022-06-25 07:05:33.653702
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = '\n    ActionModule run\n    '
    # Test with no argument
    result_0 = ActionModule()
    assert isinstance(result_0, ActionModule)
    assert repr(result_0) == repr(ActionModule)
    assert hasattr(result_0, '_VALID_ARGS')
    assert hasattr(result_0, 'TRANSFERS_FILES')
    # Test with arguments
    result_1 = ActionModule('test_str_1', 'test_str_2')
    assert isinstance(result_1, ActionModule)
    assert repr(result_1) == repr(ActionModule)
    assert hasattr(result_1, '_VALID_ARGS')
    assert hasattr(result_1, 'TRANSFERS_FILES')


# Generated at 2022-06-25 07:05:36.989686
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # FIXME: some use case of test_case_0
    assert test_case_0() == '\n    ActionModule run\n    ', 'Test failed because wrong values were returned.'


# Generated at 2022-06-25 07:05:41.233007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Add tests for __init__.
    # TODO: Add tests for load_callback_plugins.
    # TODO: Add tests for _get_task_vars.
    # TODO: Add tests for _get_tmp_path.
    # TODO: Add tests for run_async.
    assert test_case_0()

# Generated at 2022-06-25 07:05:51.473406
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = {u'action': {u'module': u'group_by', u'setup_cache_path': u'/home/vagrant/.ansible/tmp/ansible-tmp-1483503437.95-153778005150325/setup_cache', u'key': u'groups', u'no_log': False, u'delegate_to': u'localhost'}, u'_ansible_line': u' action: group_by key=groups', u'module_name': u'group_by'}
    tmp = u'/home/vagrant/.ansible/tmp/ansible-tmp-1483503437.95-153778005150325/group_by'

# Generated at 2022-06-25 07:05:52.926177
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (ActionModule.__doc__ == str_0)

test_case_0()
test_ActionModule()

# Generated at 2022-06-25 07:07:16.027897
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    var_0 = action_module_0.action_run()

# Generated at 2022-06-25 07:07:18.045217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:07:19.454788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:07:23.444658
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert action_module_0.run(tmp=None, task_vars=None) == result

# Generated at 2022-06-25 07:07:24.457741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if __name__ == "__main__":
        test_ActionModule()

# Generated at 2022-06-25 07:07:30.011193
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -2891
    int_1 = 2850
    set_1 = {int_0, int_1}
    set_0 = {int_0, int_1}
    float_0 = 1532.94
    bool_0 = True
    action_module_0 = ActionModule(int_1, set_0, float_0, bool_0, set_0, set_1)
    assert action_module_0.run(set_1, set_0) == "task_vars is required"
    assert action_module_0.run(set_1, set_0) == "the 'key' param is required when using group_by"
