

# Generated at 2022-06-25 06:57:28.143603
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 06:57:30.407687
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:57:38.707460
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 2700.1
    tuple_0 = ()
    bool_0 = True
    str_0 = '#J\x0c(vK/7q,MlK|mb/A5l'
    action_module_0 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_0)
    dict_0 = dict()
    dict_0['test_key'] = 'test_value'
    result = action_module_0.run(dict_0, dict_0)
    assert ('add_group' in result)
    assert ('parent_groups' in result)

# Generated at 2022-06-25 06:57:46.565319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    tuple_0 = ()
    float_0 = 697.009242
    bool_0 = True
    str_0 = 'uQXV>~0!#5zVjGwEZ\\^]7'
    action_module_0 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_0)

    # Assertions
    assert action_module_0.run() != None

# Generated at 2022-06-25 06:57:57.853675
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 3.2
    tuple_0 = (1.47, 1, '\x8dC\x0b\n')
    bool_0 = True
    str_0 = '&D,p{i3H/0|\x7f\x16h?Q#\x8dp!\x1d7'
    str_1 = '\x0c\x02\x1d5"\nI\x16\x10\x0c\x1f\x1f'
    action_module_0 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_1)
    action_module_1 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_1)
    action_module_

# Generated at 2022-06-25 06:58:00.786216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    action_module_0.run(None, None)
    assert not(ActionModule.parent_groups)

# Generated at 2022-06-25 06:58:10.392196
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_1 = ActionModule(30, (1,), 30, True, '#J\x0c(vK/7q,MlK|mb/A5l', '#J\x0c(vK/7q,MlK|mb/A5l')
    action_module_2 = ActionModule(30, 1, 30, True, '#J\x0c(vK/7q,MlK|mb/A5l', '#J\x0c(vK/7q,MlK|mb/A5l')

# Generated at 2022-06-25 06:58:19.180255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.0
    float_1 = 2700.1
    float_2 = 0.0
    tuple_0 = ()
    bool_0 = True
    bool_1 = True
    str_0 = '#J\x0c(vK/7q,MlK|mb/A5l'
    dict_0 = { }
    dict_1 = { }
    dict_2 = { }
    action_module_0 = ActionModule(float_0, tuple_0, float_1, bool_0, str_0, str_0)
    action_module_1 = ActionModule(float_1, tuple_0, float_2, bool_0, str_0, str_0)

# Generated at 2022-06-25 06:58:23.119150
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 524.9
    tuple_0 = ()
    bool_0 = False
    str_0 = '2nR\r]^r9VI1VEeh'
    action_module_0 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_0)


# Generated at 2022-06-25 06:58:27.718860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 2700.1
    tuple_0 = ()
    bool_0 = True
    str_0 = '#J\x0c(vK/7q,MlK|mb/A5l'
    action_module_0 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_0)


# Generated at 2022-06-25 06:58:38.857335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # arguments passed to run().
    params_0 = dict()
    inven_0 = dict(hostvars=dict())
    # the test ends here.
#    assert res_0 == action_module_0.run()
    # check if there are any errors
    if len(action_module_0.errors) > 0:
        print(action_module_0.errors)
    # execute run() method and check the assertion
    test_case_0()

# Generated at 2022-06-25 06:58:41.199408
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0.run(None, None), dict)
    assert isinstance(action_module_0.run(None, 'task_vars'), dict)


# Generated at 2022-06-25 06:58:42.007694
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 06:58:46.711441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible_collections.notstdlib.moveitallout.plugins.action.group_by


    try:
        test_case_0()
        test_ActionModule_run()
    except:
        print('Test failed')


# Generated at 2022-06-25 06:58:48.511081
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_class = ActionModule()
    assert action_module_class.run is not None


# Generated at 2022-06-25 06:58:57.073053
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test keys
    assert(ActionModule()._VALID_ARGS == frozenset(('key', 'parents')))

    # Test attributes
    assert(ActionModule().TRANSFERS_FILES == False)

    # Test run method
    tmp = None
    task_vars = None
    result = ActionModule().run(tmp, task_vars)
    assert(result['failed'] == True)
    assert(result['msg'] == "the 'key' param is required when using group_by")
    assert(result['changed'] == False)
    assert(result['add_group'] == None)
    assert(result['parent_groups'] == None)

    task_vars = dict()
    action_module_1 = ActionModule()
    action_module_1._task.args = {'key': 'test_key'}

# Generated at 2022-06-25 06:59:02.712951
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {'args': {'key': "value"}}
    task_vars = {}
    action_module = ActionModule(task, task_vars)
    result = action_module.run()
    assert result == {'changed': False, 'add_group': 'value', 'parent_groups': ['all'], 'invocation': {'module_args': {'key': 'value'}, 'module_name': 'group_by'}}


# Generated at 2022-06-25 06:59:04.941133
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert type(action_module_0) == ActionModule


# Generated at 2022-06-25 06:59:05.403943
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:59:06.548653
# Unit test for constructor of class ActionModule
def test_ActionModule():
	assert type(action_module_0) is ActionModule


# Generated at 2022-06-25 06:59:13.845843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run(tmp=None, task_vars=None)

# Generated at 2022-06-25 06:59:14.531502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:59:16.158005
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:59:16.963021
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(callable(ActionModule))


# Generated at 2022-06-25 06:59:20.026835
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 06:59:24.452229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    result = action_module_0.run(tmp=None, task_vars=None)
    assert result == {'add_group': '', 'changed': False, 'failed': True, 'parent_groups': [], 'msg': "the 'key' param is required when using group_by"}


# Generated at 2022-06-25 06:59:27.924729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run(tmp=None, task_vars=None) == \
    {'changed': False, 'add_group': 'key', 'parent_groups': ['all'], 'failed': False}

# Generated at 2022-06-25 06:59:31.387888
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test the constructor
    """
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 06:59:35.008802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    assert a.run() == 1

# Generated at 2022-06-25 06:59:38.663401
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)
    assert result['failed'] == False
    assert 'the' in result['msg']
    assert result['changed'] == False
    assert 'version' in result['add_group']
    assert 'all' in result['parent_groups']

# Generated at 2022-06-25 06:59:51.632399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_t = ActionModule()
    assert action_module_t is not None, "Failed to construct an instance of class ActionModule"

# Generated at 2022-06-25 06:59:54.657838
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 07:00:01.787620
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Given a task that has no key
    args = {'parents': 'parent_groups'}
    task = {}
    task['args'] = args
    action_module = ActionModule()
    action_module._task_vars = {}

    # When the run method is called
    result = action_module.run(task_vars={})

    # Then result is failed
    assert result['failed']


# Generated at 2022-06-25 07:00:07.144141
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    #assert action_module_0 is not None
    #assert action_module_0._VALID_ARGS is 'frozenset({'key', 'parents'})'
#    assert action_module_0.TRANSFERS_FILES is 'False'


# Generated at 2022-06-25 07:00:09.361224
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(test_case_0, '_VALID_ARGS')

# Generated at 2022-06-25 07:00:13.333695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    # Assert that action_module_1 is an instance of ActionModule
    assert isinstance(action_module_1, ActionModule)



# Generated at 2022-06-25 07:00:17.083902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate ActionModule()
    action_module = ActionModule()
    # Call method run of ActionModule()
    result = action_module.run()

    if result['failed']:
        assert True
    else:
        assert False

# Generated at 2022-06-25 07:00:27.164414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_1 = ActionModule()
    action_module_2 = ActionModule()
    action_module_3 = ActionModule()
    action_module_4 = ActionModule()
    action_module_5 = ActionModule()
    action_module_6 = ActionModule()
    action_module_7 = ActionModule()
    action_module_8 = ActionModule()
    action_module_9 = ActionModule()
    action_module_10 = ActionModule()
    action_module_11 = ActionModule()
    action_module_12 = ActionModule()
    action_module_13 = ActionModule()
    action_module_14 = ActionModule()
    action_module_15 = ActionModule()
    action_module_16 = ActionModule()
    action_module_17 = ActionModule()
   

# Generated at 2022-06-25 07:00:30.975662
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 is not None, 'Failed to create ActionModule action plugin'
    assert action_module_0._VALID_ARGS is not None, 'Failed to create ActionModule action plugin'
    assert action_module_0.run is not None, 'Failed to create ActionModule action plugin'
    assert action_module_0.run_safely is not None, 'Failed to create ActionModule action plugin'
    assert action_module_0.TRANSFERS_FILES is not None, 'Failed to create ActionModule action plugin'

# Generated at 2022-06-25 07:00:34.326966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert type(action_module_1._task.args) == dict
    assert type(action_module_1._task.action) == str
    assert action_module_1._task.action == 'group_by'


# Generated at 2022-06-25 07:01:02.281319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of the class under test
    action_module_run_0 = ActionModule()

    # Create an instance of ArgumentSpec
    argument_spec_run_0 = dict()
    
    # Set argument_spec_run_0 equal to the ArgumentSpec instance
    action_module_run_0._task.args = argument_spec_run_0

    # Create an instance of AnsibleModule
    ansible_module_run_0 = dict()
    
    # Set ansible_module_run_0 equal to the AnsibleModule instance
    action_module_run_0._task.action = ansible_module_run_0

    # Create an instance of TaskVars
    task_vars_run_0 = dict()
    
    # Call action_module_run_0.run()
    result = action_module_run_

# Generated at 2022-06-25 07:01:02.922984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:01:03.879802
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(action_module_0, 'run')
    assert action_module_0.run is not None

# Generated at 2022-06-25 07:01:10.695024
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test for missing argument 'key'
    # It should return 'Failed'
    action_module_1 = ActionModule()
    task_1 = dict()
    task_1['args'] = dict()
    task_1['args']['key'] = 'test1'
    task_1['args']['parents'] = 'test2'
    action_module_1._task = task_1
    result_1 = action_module_1.run()
    assert result_1['changed'] == False
    assert result_1['add_group'] == 'test1'
    assert result_1['parent_groups'] == ['test2']

# Generated at 2022-06-25 07:01:11.712747
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class_instance = action_module_0
    class_instance.run()

# Generated at 2022-06-25 07:01:12.444166
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

# Generated at 2022-06-25 07:01:14.078839
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the constructor of class ActionModule
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-25 07:01:22.893528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_1 = {'args': {'key': 'test'}}
    tmp_1 = None
    task_vars_1 = None
    action_module_1 = ActionModule()
    action_module_1.set_task(task_1)
    action_module_1.set_loader(None)
    action_module_1.set_play_context(None)
    action_module_1.set_variable_manager(None)
    result_1 = action_module_1.run(tmp_1, task_vars_1)
    #assert result_1['add_group'] == 'test'
    #assert result_1['parent_groups'] == ['all']


# Generated at 2022-06-25 07:01:32.307953
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test the action module: action_module_0 on given arguments
    ans_vars = dict()
    ans_vars['ansible_ssh_user'] = 'admin'
    ans_vars['ansible_ssh_pass'] = 'redhat'
    ans_vars['ansible_ssh_port'] = 22
    ans_vars['ansible_sudo_pass'] = 'redhat'
    ans_vars['ansible_connection'] = 'ssh'

    # Test case with default inventory
    inventory = dict()
    inventory['localhost'] = dict()
    inventory['localhost']['hosts'] = dict()
    inventory['_meta'] = dict()
    inventory['_meta']['hostvars'] = dict()

    # Test case without tmp directory
    test_case_1_args = dict()
    test_

# Generated at 2022-06-25 07:01:37.853409
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule(), '__init__'), "Class ActionModule does not have an __init__ member"
    assert type(ActionModule().__init__) == types.FunctionType, "__init__ is not a method"


# Generated at 2022-06-25 07:02:09.307769
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.5
    tuple_0 = ()
    bool_0 = True
    str_0 = '#J\x0c/vK/7q,MlK|b/A5l'
    action_module_0 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_0)
    assert(action_module_0.run())


if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:02:15.921630
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.5
    tuple_0 = ()
    bool_0 = True
    str_0 = '#J\x0c/vK/7q,MlK|b/A5l'
    action_module_0 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_0)
    action_module_0.run()

# Generated at 2022-06-25 07:02:20.174029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.5
    tuple_0 = ()
    bool_0 = True
    str_0 = '#J\x0c/vK/7q,MlK|b/A5l'
    action_module_0 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_0)
    var_0 = action_run()



# Generated at 2022-06-25 07:02:24.734017
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.5
    tuple_0 = ()
    bool_0 = True
    str_0 = '%n\x1b\x17l\n]B\nf\x1d\x1a\x13\n\x07\x03\x1b\x07\x0c'
    action_module_0 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_0)
    result = action_module_0.run()
    assert result


# Generated at 2022-06-25 07:02:26.426098
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 != None, 'Test failed'


# Generated at 2022-06-25 07:02:28.061954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {'key': 'parents'}
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, tuple_0)
    action_module_0.run()


# Generated at 2022-06-25 07:02:34.798826
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.5
    tuple_0 = ()
    bool_0 = True
    str_0 = '#J\x0c/vK/7q,MlK|b/A5l'
    action_module_0 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_0)
    run()

# Generated at 2022-06-25 07:02:39.485084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.5
    tuple_0 = ()
    bool_0 = True
    str_0 = '#J\x0c/vK/7q,MlK|b/A5l'
    action_module_0 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:02:45.701539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.5
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()


# Generated at 2022-06-25 07:02:47.577181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Remove optional parameters
    result = run(tmp='tmp', task_vars='task_vars')
    assert isinstance(result, ActionRun)


# Generated at 2022-06-25 07:03:54.273937
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.5
    tuple_0 = ()
    bool_0 = True
    str_0 = '#J\x0c/vK/7q,MlK|b/A5l'
    action_module_0 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_0)
    assert hasattr(action_module_0, '_VALID_ARGS')
    assert hasattr(action_module_0, '_task')
    assert action_module_0._VALID_ARGS == frozenset(['key', 'parents'])
    assert action_module_0._task == tuple_0


# Generated at 2022-06-25 07:03:57.978336
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:03:58.719023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_run()


# Generated at 2022-06-25 07:04:05.087704
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.5
    tuple_0 = ()
    bool_0 = True
    str_0 = '#J\x0c/vK/7q,MlK|b/A5l'
    action_module_0 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:04:06.299694
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 07:04:12.590030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 10.0
    tuple_0 = ()
    bool_0 = True
    str_0 = '4@\x14\x05\x13D=\x18\x00\x03\x1e\x05\x01'
    action_module_0 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_0)
    var_0 = action_run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:04:17.552527
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.5
    tuple_0 = ()
    dict_0 = {}
    bool_0 = True
    int_0 = 90
    str_0 = 'nPE*\x0b\\]\'6e'
    str_1 = '!l|f<dH8D"\x06'
    action_module_0 = ActionModule(float_0, tuple_0, dict_0, bool_0, int_0, str_0, str_1)

    assert action_module_0 is not None



# Generated at 2022-06-25 07:04:23.241548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test template type
    test_case = 0
    if test_case == 0:
        test_case_0()
    # Test Args
    # Test return type
    # Test return value
    assert isinstance(ret, dict)

# Generated at 2022-06-25 07:04:27.120557
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.5
    tuple_0 = ()
    bool_0 = True
    str_0 = '#J\x0c/vK/7q,MlK|b/A5l'
    action_module_0 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_0)


# Generated at 2022-06-25 07:04:34.307562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = getattr(var_0, 'group_by')
    assert var_1 in var_0
    assert type(var_1) is property
    assert var_1.fset.__doc__ is None
    assert var_1.get.__doc__ is None


# Generated at 2022-06-25 07:06:45.282521
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize with parameters
    float_1 = 0.25
    tuple_1 = ()
    float_2 = 0.9
    bool_1 = False
    str_1 = 'q\x16\x00\x17\x07\x1b\x1a\x05\x07\x0b'
    str_2 = '^\x1c\x1e\x07\x0c\x03\x1c\x0f\x07\x1c'
    action_module_1 = ActionModule(float_1, tuple_1, float_2, bool_1, str_1, str_2)
    var_1 = action_module_1.ActionModule()


# Generated at 2022-06-25 07:06:49.368229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_1 = 0.8780874750509343
    tuple_0 = ()
    bool_0 = True
    str_0 = 'oG:pf.Vm'
    action_module_0 = ActionModule(float_1, tuple_0, float_1, bool_0, str_0, str_0)
    var_0 = test_case_0()



# Generated at 2022-06-25 07:06:56.401701
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.5
    tuple_0 = ()
    bool_0 = True
    str_0 = '#J\x0c/vK/7q,MlK|b/A5l'
    action_module_0 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_0)
    test_case_0()


# Generated at 2022-06-25 07:07:02.371922
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.5
    tuple_0 = ()
    bool_0 = True
    str_0 = '~I\x1d|\r>7H*\x0e\x04\x17\x0b'
    action_module_0 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_0)
    var_0 = action_run()
    var_0.assertEqual('msg', 'the key param is required when using group_by')

# Generated at 2022-06-25 07:07:06.252798
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule('foo' == 'foo', 'foo' != 'foo', 'foo' == 'foo', 'foo' != 'foo', 'foo' == 'foo', 'foo' != 'foo')
    var_0 = action_run()

# Generated at 2022-06-25 07:07:12.940872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.5
    tuple_0 = ()
    bool_0 = True
    str_0 = '0wQ,|)S{7K\x0e-V7'
    action_module_0 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:07:18.109435
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test case 0
    float_0 = 0.5
    tuple_0 = ()
    bool_0 = True
    str_0 = '#J\x0c/vK/7q,MlK|b/A5l'
    action_module_0 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_0)
    var_0 = action_run()
# END TESTS

# Generated at 2022-06-25 07:07:24.283935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.5
    tuple_0 = ()
    bool_0 = True
    str_0 = '#J\x0c/vK/7q,MlK|b/A5l'
    action_module_0 = ActionModule(float_0, tuple_0, float_0, bool_0, str_0, str_0)
