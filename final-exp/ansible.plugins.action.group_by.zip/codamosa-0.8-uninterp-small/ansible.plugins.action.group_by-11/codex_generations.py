

# Generated at 2022-06-25 06:57:38.815662
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\nDataclasses for creating JUnit XML files.\nSee: https://github.com/junit-team/junit5/blob/main/platform-tests/src/test/resources/jenkins-junit.xsd\n'
    bytes_0 = b'E,\x1a~x\x01\x19\xa0\xb8-\x97p\xb5.'
    list_0 = []
    int_0 = 5256
    action_module_0 = ActionModule(str_0, str_0, bytes_0, list_0, bytes_0, int_0)
    assert(action_module_0._name == str_0)
    assert(action_module_0._supports_check_mode == False)

# Generated at 2022-06-25 06:57:46.304864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ''
    str_1 = ''
    bytes_0 = b'6\n'
    list_0 = []
    bytes_1 = b'6\n'
    int_0 = 7133
    action_module_0 = ActionModule(str_0, str_1, bytes_0, list_0, bytes_1, int_0)
    assert isinstance(action_module_0, ActionModule) == True


# Generated at 2022-06-25 06:57:57.568158
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'npn'
    str_1 = 'vdx'
    bytes_0 = b'\xd7\x1a\x83\x1f$\xf4\xee\xb6q\x9a'
    list_0 = [0, 0, -1, 0, '\x0c7', 0.389256208848472, '\rh', 0, 0, 0, -1]
    bytes_1 = b'\x03\xae\x8b\xb0\xec\xe1\xfe\x82\x82\x9d\xaf\xa9\x9e\x07\xa1\x00\x14\x0c\xae\xdc\x82'
    int_0 = -1

# Generated at 2022-06-25 06:58:03.984160
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\nDataclasses for creating JUnit XML files.\nSee: https://github.com/junit-team/junit5/blob/main/platform-tests/src/test/resources/jenkins-junit.xsd\n'
    bytes_0 = b'E,\x1a~x\x01\x19\xa0\xb8-\x97p\xb5.'
    list_0 = []
    int_0 = 5256
    action_module_0 = ActionModule(str_0, str_0, bytes_0, list_0, bytes_0, int_0)


# Generated at 2022-06-25 06:58:11.117687
# Unit test for constructor of class ActionModule
def test_ActionModule():
  str_0 = '\nDataclasses for creating JUnit XML files.\nSee: https://github.com/junit-team/junit5/blob/main/platform-tests/src/test/resources/jenkins-junit.xsd\n'
  bytes_0 = b'E,\x1a~x\x01\x19\xa0\xb8-\x97p\xb5.'
  list_0 = []
  int_0 = 5256
  action_module_0 = ActionModule(str_0, str_0, bytes_0, list_0, bytes_0, int_0)


# Generated at 2022-06-25 06:58:13.331785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        assert callable(ActionModule)
    except:
        print("Constructor Not callable")


# Generated at 2022-06-25 06:58:21.433892
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\nDataclasses for creating JUnit XML files.\nSee: https://github.com/junit-team/junit5/blob/main/platform-tests/src/test/resources/jenkins-junit.xsd\n'
    bytes_0 = b'E,\x1a~x\x01\x19\xa0\xb8-\x97p\xb5.'
    list_0 = []
    int_0 = 5256
    action_module_0 = ActionModule(str_0, str_0, bytes_0, list_0, bytes_0, int_0)
    tmp_0 = None
    task_vars_0 = {}
    
    tmp_1 = action_module_0.run(tmp_0, task_vars_0)
    assert isinstance

# Generated at 2022-06-25 06:58:30.258314
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\nDataclasses for creating JUnit XML files.\nSee: https://github.com/junit-team/junit5/blob/main/platform-tests/src/test/resources/jenkins-junit.xsd\n'
    bytes_0 = b'E,\x1a~x\x01\x19\xa0\xb8-\x97p\xb5.'
    list_0 = []
    int_0 = 5256
    action_module_0 = ActionModule(str_0, str_0, bytes_0, list_0, bytes_0, int_0)
    assert action_module_0._VALID_ARGS == frozenset(('key', 'parents'))
    assert action_module_0.VERBOSITY == 0
    assert action_module_0

# Generated at 2022-06-25 06:58:41.719995
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:58:52.959962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\nDataclasses for creating JUnit XML files.\nSee: https://github.com/junit-team/junit5/blob/main/platform-tests/src/test/resources/jenkins-junit.xsd\n'
    bytes_0 = b'E,\x1a~x\x01\x19\xa0\xb8-\x97p\xb5.'
    list_0 = []
    int_0 = 5256
    action_module_0 = ActionModule(str_0, str_0, bytes_0, list_0, bytes_0, int_0)
    test_task_vars = dict()
    # Test AnsibleModule._load_params()
    assert type(action_module_0._load_params()) == type(test_task_vars)


# Generated at 2022-06-25 06:58:58.529710
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert 0 == len(ActionModule._VALID_ARGS)


# Generated at 2022-06-25 06:59:06.397951
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\nDataclasses for creating JUnit XML files.\nSee: https://github.com/junit-team/junit5/blob/main/platform-tests/src/test/resources/jenkins-junit.xsd\n'
    bytes_0 = b'J+X\xc0\xa8\x02\xf6i\x95\xb4C\xf3\xecH\xda\xa7'
    int_0 = 5256
    action_module_0 = ActionModule(str_0, str_0, bytes_0, int_0, bytes_0, int_0)
    str_1 = ''
    str_2 = ''

# Generated at 2022-06-25 06:59:17.191555
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = '\nDataclasses for creating JUnit XML files.\nSee: https://github.com/junit-team/junit5/blob/main/platform-tests/src/test/resources/jenkins-junit.xsd\n'
    bytes_1 = b'J+X\xc0\xa8\x02\xf6i\x95\xb4C\xf3\xecH\xda\xa7'
    int_1 = 5256
    action_module_1 = ActionModule(str_1, str_1, bytes_1, int_1, bytes_1, int_1)

# Example use

# Generated at 2022-06-25 06:59:20.472124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 06:59:30.137500
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\nDataclasses for creating JUnit XML files.\nSee: https://github.com/junit-team/junit5/blob/main/platform-tests/src/test/resources/jenkins-junit.xsd\n'
    str_1 = 'https://github.com/junit-team/junit5/blob/main/platform-tests/src/test/resources/jenkins-junit.xsd'
    bytes_0 = b'J+X\xc0\xa8\x02\xf6i\x95\xb4C\xf3\xecH\xda\xa7'
    int_0 = 5256
    int_1 = 0

# Generated at 2022-06-25 06:59:36.109240
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Run the method.
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.six import string_types
    result = ActionModule.run('string', ['string'])
    assert result['changed'] == False
    assert result['parent_groups'] == ['all'] and isinstance(result['parent_groups'], list)
    assert result['add_group'] == 'string' and isinstance(result['add_group'], string_types)

# Generated at 2022-06-25 06:59:43.348763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\nDataclasses for creating JUnit XML files.\nSee: https://github.com/junit-team/junit5/blob/main/platform-tests/src/test/resources/jenkins-junit.xsd\n'
    bytes_0 = b'J+X\xc0\xa8\x02\xf6i\x95\xb4C\xf3\xecH\xda\xa7'
    int_0 = 5256
    action_module_0 = ActionModule(str_0, str_0, bytes_0, int_0, bytes_0, int_0)

# Generated at 2022-06-25 06:59:44.466344
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:59:53.394519
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    global str_0
    global bytes_0
    global int_0
    global action_module_0

    # Arguments
    tmp = 'n6a$kW;1+S'
    task_vars = {'Pi': str_0, 'Unexamined': str_0, 'Rearward': bytes_0,
                 'mellowing': int_0, 'luminescence': bytes_0, 'furls': int_0}

    # Function
    result = action_module_0.run(tmp, task_vars)

    # Assertion

# Generated at 2022-06-25 06:59:55.271564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:00:05.185371
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    str_0 = 'V7F%HS'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    dict_0 = {complex_0: complex_0}
    tuple_0 = None
    bool_0 = False
    action_module_2 = ActionModule(dict_0, tuple_0, dict_0, dict_0, bool_0, bool_0)
    str_2 = 'nhw-082><r'
    var_0 = action_module_2.run(str_2)

# Generated at 2022-06-25 07:00:15.080866
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = 'dz'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    dict_0 = {complex_0: complex_0}
    tuple_0 = None
    bool_0 = False
    action_module_2 = ActionModule(dict_0, tuple_0, dict_0, dict_0, bool_0, bool_0)
    str_2 = 'QJ(9$M'
    str_3 = 'IR^)8D*'
    str_4 = '$qvW-V7J'
    str

# Generated at 2022-06-25 07:00:23.957073
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = 'zbe#|Qd'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    complex_1 = None
    dict_0 = {complex_0: complex_0}
    tuple_0 = None
    bool_0 = True
    action_module_2 = ActionModule(dict_0, tuple_0, dict_0, dict_0, bool_0, bool_0)
    str_2 = '1.0.0'
    str_3 = action_module_2.run(str_2)
    str_

# Generated at 2022-06-25 07:00:27.565758
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule(None, None, None, None, None, None)
        print('class ActionModule worked!')
    except AssertionError:
        print('class ActionModule failed!')


# Generated at 2022-06-25 07:00:36.802589
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = 'bk8-%>'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    dict_0 = {complex_0: complex_0}
    tuple_0 = None
    bool_0 = False
    action_module_2 = ActionModule(dict_0, tuple_0, dict_0, dict_0, bool_0, bool_0)
    str_2 = 'N!Dj=0'

# Generated at 2022-06-25 07:00:46.735617
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = 'V7F%HS'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    dict_0 = {complex_0: complex_0}
    tuple_0 = None
    bool_0 = False
    action_module_2 = ActionModule(dict_0, tuple_0, dict_0, dict_0, bool_0, bool_0)
    assert action_module_2 != action_module_0



# Generated at 2022-06-25 07:00:51.784697
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO:
    # 1. Define expected values
    # 2. Instantiate the class with the default arguments
    # 3. Invoke the method
    # 4. Check the result
    assert True # TODO: implement your test here


# Generated at 2022-06-25 07:00:57.685682
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = 'V7F%HS'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    str_2 = 'nhw-082><r'
    var_0 = action_module_1.run(str_2)


# Generated at 2022-06-25 07:01:08.407345
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = 'V7F%HS'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    assert isinstance(action_module_1, ActionModule)
    
    dict_0 = {complex_0: complex_0}
    tuple_0 = None
    bool_0 = False
    action_module_2 = ActionModule(dict_0, tuple_0, dict_0, dict_0, bool_0, bool_0)
    assert isinstance(action_module_2, ActionModule)


# Generated at 2022-06-25 07:01:18.336080
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = 'V7F%HS'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    dict_0 = {complex_0: complex_0}
    tuple_0 = None
    bool_0 = False
    action_module_2 = ActionModule(dict_0, tuple_0, dict_0, dict_0, bool_0, bool_0)

    # test case 0
    str_2 = 'nhw-082><r'
    string_0 = var_0.run(str_2)

# Generated at 2022-06-25 07:01:27.003334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == None
    
    

# Generated at 2022-06-25 07:01:32.221502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule()
    except:
        # We expect this to be an assertion error in the constructor
        pass
    else:
        raise Exception("AssertionError was not raised in constructor of class ActionModule!")


# Generated at 2022-06-25 07:01:39.172206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    str_0 = 'm^X9H%%'
    str_1 = 'gU0F'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    dict_0 = {complex_0: complex_0}
    tuple_0 = None
    bool_0 = False
    action_module_2 = ActionModule(dict_0, tuple_0, dict_0, dict_0, bool_0, bool_0)
    str_2 = '1.0.0'
    dict_1 = action_module_2.run(str_2)


# Generated at 2022-06-25 07:01:44.169528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = 'V7F%HS'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    dict_0 = {complex_0: complex_0}
    tuple_0 = None
    bool_0 = False
    action_module_2 = ActionModule(dict_0, tuple_0, dict_0, dict_0, bool_0, bool_0)
    str_2 = 'nhw-082><r'
    var_0 = action_module_2.run(str_2)


# Generated at 2022-06-25 07:01:51.880818
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = 'N!bRr"B'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    dict_0 = {complex_0: complex_0}
    tuple_0 = None
    bool_0 = False
    action_module_2 = ActionModule(dict_0, tuple_0, dict_0, dict_0, bool_0, bool_0)

# Generated at 2022-06-25 07:02:02.299443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    str_0 = 'V7F%HS'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    dict_0 = {complex_0: complex_0}
    tuple_0 = None
    bool_0 = False
    action_module_2 = ActionModule(dict_0, tuple_0, dict_0, dict_0, bool_0, bool_0)
    str_2 = 'nhw-082><r'
    var_0 = action_module_2.run(str_2)
    # Test negative case
    
   

# Generated at 2022-06-25 07:02:12.647848
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_2 = 3j
    str_0 = 'V7F%HS'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    assert action_module_1.run() == None
    assert isinstance(action_module_1, ActionModule) == True
    assert action_module_1 != None
    assert action_module_1._VALID_ARGS == frozenset({'key', 'parents'})
    assert action_module_1._display.display == None
    assert action_module_1.TRANSFERS_FILES == False
    assert action_module_1

# Generated at 2022-06-25 07:02:14.140958
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Test query_inventory method

# Generated at 2022-06-25 07:02:21.820780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    str_0 = 'V7F%HS'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    dict_0 = {complex_0: complex_0}
    tuple_0 = None
    bool_0 = False
    action_module_2 = ActionModule(dict_0, tuple_0, dict_0, dict_0, bool_0, bool_0)
    str_2 = 'nhw-082><r'
    var_0 = action_module_2.run(str_2)

# Generated at 2022-06-25 07:02:22.799714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  assert 1 == 0


# Generated at 2022-06-25 07:02:47.369837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = 'V7F%HS'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    assert action_module_1 != None

    dict_0 = {complex_0: complex_0}
    tuple_0 = None
    bool_0 = False
    action_module_2 = ActionModule(dict_0, tuple_0, dict_0, dict_0, bool_0, bool_0)
    assert action_module_2 != None



# Generated at 2022-06-25 07:02:53.381635
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = '<S'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    complex_1 = None
    dict_0 = {complex_1: complex_0}
    tuple_0 = None
    bool_0 = False
    action_module_2 = ActionModule(dict_0, tuple_0, dict_0, dict_0, bool_0, bool_0)
    str_2 = 'nhw-082><r'
    var_0 = action_module_2.run(str_2)


# Generated at 2022-06-25 07:02:57.237389
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '<%&2F7$'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    assert action_module_1.run() is not None


# Generated at 2022-06-25 07:03:07.875747
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    str_0 = 'CP'
    str_1 = '1.0.0'
    list_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, action_module_0)
    str_2 = 'H'
    str_3 = '1.0.0'
    list_1 = None
    action_module_1 = ActionModule(str_2, str_3, str_3, list_1, action_module_0, action_module_0)
    str_4 = 'nhw-082><r'
    str_5 = '1.0.0'
    list_2 = None

# Generated at 2022-06-25 07:03:13.506555
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = 'V7F%HS'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)


# Generated at 2022-06-25 07:03:21.011181
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = 'V7F%HS'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    str_2 = 'nhw-082><r'
    var_0 = action_module_1.run(str_2)

# Generated at 2022-06-25 07:03:30.011009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    str_0 = 'aCw-L4H^'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    dict_0 = {complex_0: complex_0}
    tuple_0 = None
    bool_0 = False
    action_module_2 = ActionModule(dict_0, tuple_0, dict_0, dict_0, bool_0, bool_0)
    str_2 = '8>-k2O%-T'
    dict_1 = action_module_2.run(str_2)
    assert dict_1

# Generated at 2022-06-25 07:03:36.764133
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = '=5vP5d'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    dict_0 = {complex_0: complex_0}
    tuple_0 = None
    bool_0 = False
    action_module_2 = ActionModule(dict_0, tuple_0, dict_0, dict_0, bool_0, bool_0)


# Generated at 2022-06-25 07:03:44.896428
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = 'V7F%HS'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    dict_0 = {complex_0: complex_0}
    tuple_0 = None
    bool_0 = False
    action_module_2 = ActionModule(dict_0, tuple_0, dict_0, dict_0, bool_0, bool_0)

# Generated at 2022-06-25 07:03:53.824142
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = '2h*>F&a'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    complex_0 = None
    str_2 = '2h*>F&a'
    str_3 = '1.0.0'
    list_1 = None
    action_module_2 = None
    bytes_1 = None
    action_module_3 = ActionModule(str_2, str_3, str_3, list_1, action_module_2, bytes_1)
    int_0 = 88

# Generated at 2022-06-25 07:04:34.578374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Argument spec values
    tmp = None
    task_vars = {'test1': 'test1string', 'test2': 'test2string', 'test3': 'test3string'}

    # Class instantiation
    action_module_0 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)

    # Method execution
    var_0 = action_module_0.run(tmp, task_vars)
    assert isinstance(var_0, dict) == True
    assert var_0['changed'] == False
    assert var_0['add_group'] == 'nhw-082><r'
    assert var_0['parent_groups'] == ['all']


# Generated at 2022-06-25 07:04:40.018497
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Prepare data
    tmp = None
    task_vars = None
    # Perform the actual call
    result = ActionModule.run(
        tmp,
        task_vars,
        **{'key': 'key_value', 'parents': 'parents_value'}
    )
    # Verify the results
    assert(result['changed'] == False)
    assert(result['add_group'] == 'key_value')
    assert(result['parent_groups'] == ['parents_value'])


# Generated at 2022-06-25 07:04:46.397541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    str_0 = 'V7F%HS'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    dict_0 = {complex_0: complex_0}
    tuple_0 = None
    bool_0 = False
    action_module_2 = ActionModule(dict_0, tuple_0, dict_0, dict_0, bool_0, bool_0)
    str_2 = 'nhw-082><r'
    var_0 = action_module_2.run(str_2)


# Generated at 2022-06-25 07:04:56.190632
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    action_module_0 = ActionModule(None, None, None, None, None, None)
    tuple_0 = None
    list_0 = None
    dict_0 = {tuple_0: list_0}
    action_module_1 = ActionModule(dict_0, tuple_0, dict_0, dict_0, complex_0, complex_0)
    str_0 = '*#,i$U6'
    bool_0 = True
    action_module_2 = ActionModule(str_0, str_0, str_0, bool_0, bool_0, bool_0)
    str_1 = 'xgNRD'
    var_0 = action_module_2.run(str_1)

# Generated at 2022-06-25 07:05:04.687015
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = 'V7F%HS'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    #Testing the constructor of class ActionModule with default args
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    #Testing the constructor of class ActionModule with custom args
    dict_0 = {complex_0: complex_0}
    tuple_0 = None
    bool_0 = False
    action_module_2 = ActionModule(dict_0, tuple_0, dict_0, dict_0, bool_0, bool_0)


# Generated at 2022-06-25 07:05:07.772725
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_3 = ActionModule("test", "test", "test", "test", "test", "test")


# Generated at 2022-06-25 07:05:11.769040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:05:16.690247
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(dict(), dict(), dict(), dict(), dict(), dict())
    bool_0 = False
    action_module_2 = ActionModule(dict(), dict(), dict(), dict(), bool_0, bool_0)
    str_0 = 'V7F%HS'
    str_1 = '1.0.0'
    action_module_3 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    assert issubclass(ActionModule, object)


# Generated at 2022-06-25 07:05:23.819164
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = 'S-E-P-G>\\'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    result = action_module_1._plugin_name()
    result = action_module_1.get_option('str_0')
    result = action_module_1.copy()
    result = action_module_1.validate('str_0')
    result = action_module_1.expand_action('str_0', 'str_1')
    result = action_module_1.get_action_args(result)

# Generated at 2022-06-25 07:05:33.190520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # set up testing
    complex_0 = None
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    str_0 = 'V7F%HS'
    str_1 = '1.0.0'

    # start testing
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    assert type(action_module_1) == ActionModule
    assert action_module_1._task !=  None
    assert action_module_1._connection !=  None
    assert action_module_1._play_context !=  None
    assert action_module_1._loader !=  None
    assert action_module_1._templar !=  None
    assert action_module_1._shared_loader_

# Generated at 2022-06-25 07:07:09.653280
# Unit test for constructor of class ActionModule
def test_ActionModule():
  complex_0 = None
  str_0 = 'V7F%HS'
  str_1 = '1.0.0'
  list_0 = None
  action_module_0 = None
  bytes_0 = None
  action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
  dict_0 = {complex_0: complex_0}
  tuple_0 = None
  bool_0 = False
  action_module_2 = ActionModule(dict_0, tuple_0, dict_0, dict_0, bool_0, bool_0)
  assert action_module_1 is not None


# Generated at 2022-06-25 07:07:11.106507
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:07:14.345879
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:07:19.889568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = 'V7F%HS'
    str_1 = '1.0.0'
    list_0 = None
    action_module_0 = None
    bytes_0 = None
    action_module_1 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    str_2 = str_1
    assert str_2 == str_1
    str_3 = str_0
    assert str_3 == str_0
    str_4 = 'ActionModule'
    assert str_4 == 'ActionModule'


# Generated at 2022-06-25 07:07:26.367988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    str_3 = '.'
    str_2 = 'nhw-082><r'
    dict_0 = {'a': None}
    dict_1 = {'a': dict_0}
    var_0 = ActionModule(str_0, str_1, str_1, list_0, action_module_0, bytes_0)
    var_0.run(str_2, dict_1)
