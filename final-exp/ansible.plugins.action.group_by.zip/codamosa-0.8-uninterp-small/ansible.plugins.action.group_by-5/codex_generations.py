

# Generated at 2022-06-25 06:57:36.925593
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -659.99
    bytes_0 = b'\x08\x06\xf8\x15\xb2\xb5 '
    bytes_1 = b'R\xe1'
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, bytes_0, float_0, bytes_0, bytes_1, tuple_0)


# Generated at 2022-06-25 06:57:41.968810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -659.99
    bytes_0 = b'\x08\x06\xf8\x15\xb2\xb5 '
    bytes_1 = b'R\xe1'
    tuple_0 = ()

    # Create an instance of the class under test
    action_module_0 = ActionModule(float_0, bytes_0, float_0, bytes_0, bytes_1, tuple_0)

    # Invoke the method under test
    result = action_module_0.run(tmp=None, task_vars=None)
    assert result['changed'] == False

# Generated at 2022-06-25 06:57:47.683991
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(bytes_0, float_0, bytes_0, bytes_1, tuple_0, float_0)
    tmp_0 = None
    task_vars_0 = None
    result_0 = action_module_0.run(tmp_0, task_vars_0)
    result_1 = action_module_0.run(tmp_0, task_vars_0)
    assert result_1 == result_0


# Generated at 2022-06-25 06:57:59.208698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -659.99
    bytes_0 = b'\x08\x06\xf8\x15\xb2\xb5 '
    float_1 = -659.99
    bytes_1 = b'\x08\x06\xf8\x15\xb2\xb5 '
    bytes_2 = b'R\xe1'
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, bytes_0, float_1, bytes_1, bytes_2, tuple_0)
    assert action_module_0.run() == {'msg': "the 'key' param is required when using group_by", 'failed': True, 'changed': False}

    bytes_0 = b'\x08\x06\xf8\x15\xb2\xb5 '
    float_

# Generated at 2022-06-25 06:58:07.130335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -659.99
    bytes_0 = b'\x08\x06\xf8\x15\xb2\xb5 '
    bytes_1 = b'R\xe1'
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, bytes_0, float_0, bytes_0, bytes_1, tuple_0)
    # assert that the action module run method constructs the expected test case
    assert action_module_0.run() == {'add_group': '-659.99', 'changed': False, 'parent_groups': ['all']}

# Generated at 2022-06-25 06:58:08.877127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    action_module_0 = ActionModule(tuple_0)


# Generated at 2022-06-25 06:58:14.400391
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -659.99
    bytes_0 = b'\x08\x06\xf8\x15\xb2\xb5 '
    bytes_1 = b'R\xe1'
    tuple_0 = ()
    action_module_0 = ActionModule(float_0, bytes_0, float_0, bytes_0, bytes_1, tuple_0)
    bool_0 = action_module_0._execute_module(action_module_0.run, None, None)
    assert bool_0 == True
    action_module_0.run()

# Generated at 2022-06-25 06:58:19.847778
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {
    'hostvars': {'host1': {'ansible_hostname': 'host1'}},
    'groups': {
        'group1': {
            'hosts': ['host1']
        }
    },
    'inventory_hostname': 'host1'
    }
    action_module_0 = ActionModule(1, 1, 1, 1, 1, 1)
    assert type(action_module_0.run(1, task_vars)) == dict

# Generated at 2022-06-25 06:58:22.536932
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_1 = -828.02
    bytes_2 = b'9]\xc4'
    bytes_3 = b'\xf4'
    action_module_1 = ActionModule(float_1, bytes_2, float_1, bytes_2, bytes_3)


# Generated at 2022-06-25 06:58:27.467926
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -659.99
    bytes_0 = b'\x08\x06\xf8\x15\xb2\xb5 '
    bytes_1 = b'R\xe1'
    tuple_0 = ()
    # Test ActionModule.__init__()
    action_module_0 = ActionModule(float_0, bytes_0, float_0, bytes_0, bytes_1, tuple_0)

# Generated at 2022-06-25 06:58:36.258141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    task_vars['result'] = {'failed': False}
    action_module_0 = ActionModule(dict({'key': 'key_0', 'parents': '<code>'}))
    result = action_module_0.run(None, task_vars)
    assert result['failed'] == False
    assert result['parent_groups'] == ['<code>']


# Generated at 2022-06-25 06:58:40.852708
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ()
    var_1 = ('key',)
    action_module_2 = ActionModule(var_0)
    var_3 = action_module_2.run(var_1)
    assert var_3 == None

# Generated at 2022-06-25 06:58:46.757034
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = () 
    action_module_0 = ActionModule(var_0)
    assert action_module_0._task.args.get('key') == '{{ item }}' 
    assert action_module_0._task.args.get('parents') == None 
    assert action_module_0.task_vars == {'inventory_hostname': 'localhost', 'inventory_hostname_short': 'localhost'} 
    assert action_module_0.tmpdir == 'localhost' 
    assert action_module_0.create_dir == 'localhost' 
    assert action_module_0.remote_user == 'root' 
    assert action_module_0.remote_tmp == '/tmp' 
    assert action_module_0.module_name == 'command' 
    assert action_module_0.module_args

# Generated at 2022-06-25 06:58:48.173781
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME: test this function
    pass


# Generated at 2022-06-25 06:58:51.040714
# Unit test for constructor of class ActionModule
def test_ActionModule():
  var__VALID_ARGS = ()
  var_self = ()
  # No exception should be thrown.
  action_module_0 = ActionModule(var__VALID_ARGS, var_self)


# Generated at 2022-06-25 06:58:51.943876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule() is not None


# Generated at 2022-06-25 06:58:53.559272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ()
    action_module_0 = ActionModule(var_0)


# Generated at 2022-06-25 06:58:54.568264
# Unit test for constructor of class ActionModule
def test_ActionModule():

    print(ActionModule)


# Generated at 2022-06-25 06:59:00.808766
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ()
    action_module_0 = ActionModule(var_0)
    assert type(action_module_0) == ActionModule
    assert action_module_0 is not None
    assert action_module_0.run is not None

# Generated at 2022-06-25 06:59:04.832392
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(None)
    assert action_module_0._task.args == {}


# Generated at 2022-06-25 06:59:08.494758
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    
    

# Generated at 2022-06-25 06:59:09.349127
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Unit test
    pass

# Generated at 2022-06-25 06:59:19.472661
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    str_1 = 'P\x83\xd2'
    str_2 = '9'
    set_0 = {str_2, str_2, str_2, str_2}
    bytes_0 = b'\x87\x11'
    float_0 = 2.0
    bool_0 = True
    int_0 = -1776
    action_module_0 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)
    action_module_0.action_loader = str_0
    action_module_0.action_name = str_1
    str_3 = '\x8a\x835\x15\xf1\x0f'
    int_1 = 1

# Generated at 2022-06-25 06:59:21.770026
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    str_0 = None
    var_0 = action_module_0.run(str_0)
    assert var_0['changed'] == False
    assert var_0['add_group'] == '_'
    assert var_0['parent_groups'] == ['all']


# Generated at 2022-06-25 06:59:24.998840
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module_0 = ActionModule()
    assert (action_module_0.__setattr__ is not None)
    assert (action_module_0.run is not None)
    assert (action_module_0.__init__ is not None)


# Generated at 2022-06-25 06:59:30.364795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Created on 2020-06-02 21:27:00
    """
    print("Testing constructor of class ActionModule")
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation
    # Test object creation


# Generated at 2022-06-25 06:59:36.133183
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run(tmp=None, task_vars=None)
    return var_0

# Generated at 2022-06-25 06:59:42.087363
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = {'f', 'n', 'I', 'I'}
    set_1 = {'S\x90\xb6\x05\x99', 'S\x90\xb6\x05\x99', 'S\x90\xb6\x05\x99', 'S\x90\xb6\x05\x99'}
    bytes_0 = b'\xf7\xfc\x9e\x93\xe9\x9f\xdf\x1f\r'
    float_0 = 0.0
    bool_0 = False
    int_0 = -1713
    action_module_0 = ActionModule(set_0, set_1, bytes_0, float_0, bool_0, int_0)

# Generated at 2022-06-25 06:59:51.072368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = None
    str_1 = '\n0\x17z'
    set_0 = {str_1, str_1, str_1, str_1}
    bytes_0 = b'\xda\\\xf8\xa6\xb9F'
    float_0 = 2.0
    bool_0 = True
    int_0 = -1320
    action_module_0 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)
    var_0 = action_run(str_0)

# Generated at 2022-06-25 07:00:01.470586
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = None
    str_1 = '(Qy{\\+w+{)#\nE'
    set_0 = {str_1, str_1, str_1, str_1}
    bytes_0 = b'\xda\\\xf8\xa6\xb9F'
    float_0 = 2.0
    bool_0 = True
    int_0 = -1320
    action_module_0 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)
    var_1 = None
    var_2 = test_case_0(var_1)


# Generated at 2022-06-25 07:00:13.880286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = {'(Qy{\\+w+{)#\nE', '(Qy{\\+w+{)#\nE', '(Qy{\\+w+{)#\nE', '(Qy{\\+w+{)#\nE'}
    bytes_0 = b'\xda\\\xf8\xa6\xb9F'
    float_0 = 2.0
    bool_0 = True
    int_0 = -1320
    action_module_0 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)


# Generated at 2022-06-25 07:00:21.689108
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    str_1 = '\xce'
    set_0 = {str_0, str_0, str_0, str_0}
    set_1 = {str_1, str_0, str_0, str_1}
    bytes_0 = b"\xfc\x01\xf4"
    float_0 = -10.0
    bool_0 = True
    int_0 = 1628
    action_module_0 = ActionModule(set_0, set_1, bytes_0, float_0, bool_0, int_0)
    var_0 = action_module_0.run(str_0)


# Generated at 2022-06-25 07:00:31.308157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = None
    str_1 = 'c;(j[2<'
    set_0 = {str_1, str_1, str_1, str_1}
    bytes_0 = b'M\x90\xb2\x13'
    float_0 = 2.0
    bool_0 = True
    int_0 = -1320
    action_module_0 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)
    str_2 = None
    action_module_0.run(str_2)

# Generated at 2022-06-25 07:00:33.421896
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        return not (test_case_0())
    except:
        return True

test_ActionModule()

# Generated at 2022-06-25 07:00:43.029922
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    str_1 = '(Qy{\\+w+{)#\nE'
    set_0 = {str_1, str_1, str_1, str_1}
    bytes_0 = b'\xda\\\xf8\xa6\xb9F'
    float_0 = 2.0
    bool_0 = True
    int_0 = -1320
    action_module_0 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)
    assert(action_module_0.run(set_0, set_0) == None)

# Generated at 2022-06-25 07:00:51.688852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    str_1 = '<lvwfZj}|vD'
    set_0 = {str_1, str_1, str_1, str_1}
    bytes_0 = b"\xa9'\xce"
    float_0 = 4.5650636
    bool_0 = True
    int_0 = -1735
    action_module_0 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)


# Generated at 2022-06-25 07:01:01.175114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    str_0 = None
    str_1 = 'group_by'
    str_2 = 'parents'
    str_3 = 'all'
    set_0 = {str_3, str_3, str_3, str_3}
    bytes_0 = b'\x99\xbe-\x1a\xb1/\xa5\x98'
    float_0 = -2.0
    bool_0 = True
    int_0 = 0
    action_module_0 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)
    var_0 = action_play_context(str_0) # [ FAILED  ] 2/2 subtests

# Generated at 2022-06-25 07:01:02.771606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, ActionBase)

# Generated at 2022-06-25 07:01:03.915265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    true_1 = False
    while true_1:
        float_1 = -8.717272181040657
        float_1 = float_1


# Generated at 2022-06-25 07:01:12.366337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(' ')
    print('TESTING ACTIONMODULE.RUN')
    print(' ')
    # First input parameter:  tmp
    # Second input parameter:  task_vars
    print('TESTING ACTIONMODULE.RUN:  PARAM TEST')
    print(' ')
    str_0 = None
    float_0 = 2.0
    int_0 = -1320
    bytes_0 = b'\xda\\\xf8\xa6\xb9F'
    # action_run(arg0, arg1)
    str_1 = '(Qy{\\+w+{)#\nE'
    set_0 = {str_1, str_1, str_1, str_1}
    bool_0 = True

# Generated at 2022-06-25 07:01:29.060461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a new ActionModule
    action_module_0 = ActionModule()

    # Create a new ActionModule
    # AssertionError: expected false but saw true
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:01:36.569831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = None
    str_0 = None
    set_0 = {str_0, str_0, str_1, str_1, str_0}
    bytes_2 = b'9\xb3\xc3<'
    float_0 = 1.0
    bool_0 = True
    int_0 = -965
    action_module_0 = ActionModule(set_0, set_0, bytes_2, float_0, bool_0, int_0)
    var_0 = action_run(str_0)


# Generated at 2022-06-25 07:01:42.659631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, str_0)
    except Exception as e:
        print(e)
        test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:01:50.643100
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    str_1 = '(Qy{\\+w+{)#\nE'
    set_0 = {str_1, str_1, str_1, str_1}
    bytes_0 = b'\xda\\\xf8\xa6\xb9F'
    float_0 = 2.0
    bool_0 = True
    int_0 = -1320
    test_case(set_0, set_0, bytes_0, float_0, bool_0, int_0)


# Generated at 2022-06-25 07:01:57.800992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = {'>;.\x98?', 'I\x88\x89\xc1\xb3\x15', 'S\x907\xe6\xa8\xe8', '0\x1f\x80\x8f\xfb\xce\x03', '6\x04\xdd\xa7\xe6\xe5'}
    dict_0 = dict()
    dict_1 = dict()
    str_0 = None
    str_1 = 'Y\x83Wi\xbd\x9a'
    set_1 = {str_1, str_0, str_1, 'P\x8c\xcc\x92\x9b\xe3\xfa', str_1}

# Generated at 2022-06-25 07:02:07.212465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    str_1 = '9\xab\x04\xba\xd8}iQ\xac\x10\x17>\x08\xe45\x9b\x00\x1d\xed\x88\x0e\x11c\xaa\xd8'
    set_0 = {str_1, str_1, str_1, str_1}
    bytes_0 = b'\xda\\\xf8\xa6\xb9F'
    float_0 = 2.0
    bool_0 = True
    int_0 = -1320
    action_module_0 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)
    instance = ActionModule()


# Generated at 2022-06-25 07:02:16.166683
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    str_1 = '(Qy{\\+w+{)#\nE'
    set_0 = {str_1, str_1, str_1, str_1}
    bytes_0 = b'\xda\\\xf8\xa6\xb9F'
    float_0 = 2.0
    bool_0 = True
    int_0 = -1320
    test_case_0()
    assert action_module_0.action_results == {}, "the action_results was not empty"
    assert action_module_0.action == str_0, "the action was not empty"
    assert action_module_0.task_vars == set_0, "the task_vars was not equal to '{str_1, str_1, str_1, str_1}'"

# Generated at 2022-06-25 07:02:20.708200
# Unit test for constructor of class ActionModule
def test_ActionModule():
  str_0 = None
  str_1 = '(Qy{\\+w+{)#\nE'
  set_0 = {str_1, str_1, str_1, str_1}
  bytes_0 = b'\xda\\\xf8\xa6\xb9F'
  float_0 = 2.0
  bool_0 = True
  int_0 = -1320
  action_module_0 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)
  # Verify attributes
  assert isinstance(action_module_0._task, Task)
  assert isinstance(action_module_0._connection, Connection)
  assert isinstance(action_module_0._play_context, PlayContext)

# Generated at 2022-06-25 07:02:26.064451
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    str_1 = '(Qy{\\+w+{)#\nE'
    set_0 = {str_1, str_1, str_1, str_1}
    bytes_0 = b'\xda\\\xf8\xa6\xb9F'
    float_0 = 2.0
    bool_0 = True
    int_0 = -1320
    action_module_0 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)


if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:02:35.509148
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    str_1 = '(Qy{\\+w+{)#\nE'
    set_0 = {str_1, str_1, str_1, str_1}
    bytes_0 = b'\xda\\\xf8\xa6\xb9F'
    float_0 = 2.0
    bool_0 = True
    int_0 = -1320
    action_module_0 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)
    var_0 = action_run(str_0)



# Generated at 2022-06-25 07:03:05.488628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp, task_vars = 'tmp', 'task_vars'
    var_0 = action_module_0.run(tmp=tmp, task_vars=task_vars)
    assert var_0 == NotImplementedError

# Generated at 2022-06-25 07:03:06.328029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:03:07.977006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # FIXME: setup test fixtures if needed
  #assert True # TODO: implement your test here
  pass


# Generated at 2022-06-25 07:03:13.525668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = None
    str_1 = '(Qy{\\+w+{)#\nE'
    set_0 = {str_1, str_1, str_1, str_1}
    bytes_0 = b'\xda\\\xf8\xa6\xb9F'
    float_0 = 2.0
    bool_0 = True
    int_0 = -1320
    action_module_4 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)
    var_0 = action_run(str_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:03:23.770075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = None
    str_1 = 'FQ \x1a'
    str_2 = 'o\x85\xca\xe3\x0c\xacb\x03\xa9\x8cR\xcf\x83\xbc'
    set_0 = {str_2, str_2, str_2, str_2}
    bytes_0 = b'^\xda\xae\xc5\x92A\xe7\xcd\xaa5\x99\xb0\x01'
    float_0 = 1.0
    bool_0 = True
    int_0 = -2266
    action_module_0 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)
    var_0 = action_

# Generated at 2022-06-25 07:03:32.546575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    str_1 = '@!>w\x12\xcd\x02\x8d\xdd\x9a\x13\x0b\x1b\xcc'
    set_0 = {str_1, str_1, str_1, str_1}
    bytes_0 = b'p\xb1\xbdh\xbe\x9e\x9f'
    float_0 = 1.0
    bool_0 = True
    int_0 = -2087
    action_module_0 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)


# Generated at 2022-06-25 07:03:33.835133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None)
    assert isinstance(action_run(None), dict) == True

# Generated at 2022-06-25 07:03:37.826329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(str(str_0))
    print(str(str_1))
    print(str(set_0))
    print(str(bytes_0))
    print(str(float_0))
    print(str(bool_0))
    print(str(int_0))
    print(str(action_module_0))
    print(str(var_0))



# Generated at 2022-06-25 07:03:48.215890
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    str_1 = '\x00\xff\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    bytes_0 = b'\xd5\xcc\x1a\x8c\x81\xaa\x14\xa4\xdc\xc7\xd2\xaa\x13\xb0'
    float_0 = -1.0
    bool

# Generated at 2022-06-25 07:03:58.396533
# Unit test for constructor of class ActionModule
def test_ActionModule():
  set_0 = frozenset()
  set_1 = frozenset()
  bytes_0 = b'\xda\\\xf8\xa6\xb9F'
  float_0 = 2.0
  bool_0 = True
  int_0 = -1320
  action_module_0 = ActionModule(set_0, set_1, bytes_0, float_0, bool_0, int_0)
  assert isinstance(action_module_0._task, AnsibleTask)
  assert action_module_0._task.args['_ansible_version'] == (2, 4, 2, 0)
  assert action_module_0._task.action == 'meta'

# Generated at 2022-06-25 07:04:51.720480
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    str_1 = '5Q{d}0<'
    set_0 = {str_1, str_1, str_0}
    bytes_0 = b't\xe4,e\x94\xb4\xaf'
    float_0 = 4.4
    bool_0 = True
    int_0 = 193
    action_module_0 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)

# Generated at 2022-06-25 07:04:55.555248
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    str_1 = '(Qy{\\+w+{)#\nE'
    set_0 = {str_1, str_1, str_1, str_1}
    bytes_0 = b'\xda\\\xf8\xa6\xb9F'
    float_0 = 2.0
    bool_0 = True
    int_0 = -1320
    action_module_0 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)
    return True


# Generated at 2022-06-25 07:05:04.847510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    str_1 = '(Qy{\\+w+{)#\nE'
    set_0 = {str_1, str_1, str_1, str_1}
    bytes_0 = b'\xda\\\xf8\xa6\xb9F'
    float_0 = 2.0
    bool_0 = True
    int_0 = -1320
    action_module_0 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)
    assert action_module_0.run(str_0) == -1320
    stream_0 = None
    action_module_0.run(str_0)
    action_module_0.run(str_0)

# Generated at 2022-06-25 07:05:14.100403
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = {}
    action_module_0 = ActionModule(tmp, task_vars)
    tmp = None
    task_vars = {}
    action_module_1 = ActionModule(tmp, task_vars)
    tmp = None
    task_vars = {}
    action_module_2 = ActionModule(tmp, task_vars)
    tmp = None
    task_vars = {}
    action_module_3 = ActionModule(tmp, task_vars)
    tmp = None
    task_vars = {}
    action_module_4 = ActionModule(tmp, task_vars)
    tmp = None
    task_vars = {}
    action_module_5 = ActionModule(tmp, task_vars)
    tmp = None
    task_vars = {}


# Generated at 2022-06-25 07:05:22.785109
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    set_0 = {str_0, str_0, str_0, str_0}

# Generated at 2022-06-25 07:05:32.637384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # type: () -> None
    str_0 = None
    str_1 = '(Qy{\\+w+{)#\nE'
    set_0 = {str_1, str_1, str_1, str_1}
    bytes_0 = b'\xda\\\xf8\xa6\xb9F'
    float_0 = 2.0
    bool_0 = True
    int_0 = -1320
    action_module_0 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)
    var_0 = action_module_0.run(str_0)
    str_2 = None
    str_3 = 'Zu#<\x1dV.\x1b'
    dict_0 = dict()
    dict

# Generated at 2022-06-25 07:05:42.059904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = {'\x9c\x82u\\\xfa', '\x9c\x82u\\\xfa', '\x9c\x82u\\\xfa', '\x9c\x82u\\\xfa'}
    set_1 = set()
    bytes_0 = b'\x8b\xa6\xc1\xab'
    float_0 = 0.0
    bool_0 = False
    int_0 = -1327
    action_module_0 = ActionModule(set_0, set_1, bytes_0, float_0, bool_0, int_0)
    action_module_0.run()
    assert len(set_0) == 4
    assert len(set_1) == 0

# Generated at 2022-06-25 07:05:48.650573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    str_1 = '(Qy{\\+w+{)#\nE'
    set_0 = {str_1, str_1, str_1, str_1}
    bytes_0 = b'\xda\\\xf8\xa6\xb9F'
    float_0 = 2.0
    bool_0 = True
    int_0 = -1320
    action_module_0 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)
    assert True



# Generated at 2022-06-25 07:05:53.705349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = None
    str_1 = '}h'
    bytes_0 = b'\xa0\x8f\\\x1f'
    set_0 = {str_0, str_1, str_1}
    float_0 = 1.0
    bool_0 = True
    int_0 = -1320
    action_module_0 = ActionModule(set_0, set_0, bytes_0, float_0, bool_0, int_0)
    action_module_0.action_loader = ActionLoader()
    action_module_0.task_loader = TaskLoader()
    str_2 = 'J('
    str_3 = 'NoNe'
    dict_0 = {str_2:str_3}
    str_4 = 'x!S'

# Generated at 2022-06-25 07:06:02.535730
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    str_1 = '\xce\xeb\t'
    dict_0 = dict()
    str_2 = 'z\xc3\x1b\xe1\xca\xc0\xd2\xabx\xd0\xb6\xbc\xee\xf7\xcb\xb0\xcb\x10'
    dict_0[str_0] = (dict_0[str_0])
    dict_0[str_1] = (dict_0[str_1])
    dict_0[str_2] = dict_0
    str_3 = '\xd3\x1f\x98L\x1e\xdb\x16\x91'
    dict_0[str_3] = dict_0
    dict_1 = dict()
   