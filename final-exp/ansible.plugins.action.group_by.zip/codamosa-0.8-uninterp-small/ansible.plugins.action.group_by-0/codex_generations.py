

# Generated at 2022-06-25 06:57:40.877841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if 'k_' in test_ActionModule_run.__dict__:
        del test_ActionModule_run.k_

    if 'task_vars_' in test_ActionModule_run.__dict__:
        del test_ActionModule_run.task_vars_

    def tmp_():
        nonlocal tmp_
        if not 'tmp_' in tmp_.__dict__:
            tmp_.tmp_ = None
        return tmp_.tmp_

    def task_vars_():
        nonlocal task_vars_
        if not 'task_vars_' in task_vars_.__dict__:
            task_vars_.task_vars_ = None
        return task_vars_.task_vars_

    k_ = '-\t|(Jq&p9Xs'


# Generated at 2022-06-25 06:57:42.294420
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:57:47.805812
# Unit test for constructor of class ActionModule
def test_ActionModule():
    parent_groups = ['eM{', '9u-7Vd2S.', 'w', 'z"AWg9\t[[HPUa']
    assert test_case_0() == {'changed': False, 'add_group': 'z"AWg9\t[[HPUa', 'parent_groups': ['eM{', '9u-7Vd2S.', 'w', 'z"AWg9\t[[HPUa']}


# Generated at 2022-06-25 06:57:59.350529
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = None
    test_case = [tmp_0, task_vars_0]

    # The params below are defined in ansible.plugins.action.__init__
    with pytest.raises(AttributeError):
        action_module_0.run(tmp_0, task_vars_0)

    bool_0 = False
    int_0 = -2792
    float_0 = 880.6473
    bytes_0 = None
    str_0 = 'z"AWg9\t[[HPUa'
    action_module_0 = ActionModule(bool_0, int_0, float_0, bytes_0, str_0, str_0)
    action_module_0.run(tmp_0, task_vars_0)

# Unit

# Generated at 2022-06-25 06:58:09.237438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 6857
    float_0 = 2.5
    bytes_0 = b'\x1e\x19\xe4\xce\x81\x1b\x91\xee\x90\xfd\xe8\xdc\x11\xfdq\xf1\x9a/'
    str_0 = '=c%N\\L2@Tb'
    action_module_0 = ActionModule(bool_0, int_0, float_0, bytes_0, str_0, str_0)

    bool_1 = False
    int_1 = 2239
    float_1 = -0.088

# Generated at 2022-06-25 06:58:11.288550
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  action_module_0 = ActionModule(None, None, None, None, None, None)
  # No exception should be raised
  action_module_0.run()

# Generated at 2022-06-25 06:58:12.378751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:58:20.206187
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = -7.84886356786e-28
    float_0 = 0.115
    bytes_0 = b'^[k-iY#/\x1f/n\nM\\\\\r'
    str_0 = '^\t@!s)s,c%g\x0b\x06\x1f\x14~"\x12\x0f\x1e\x12'
    action_module_0 = ActionModule(bool_0, int_0, float_0, bytes_0, str_0, str_0)
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:58:29.361977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = 4331
    float_0 = 7135.098
    bytes_0 = 'Tqszdvu#1I&A'
    str_0 = 'K"F_q3%c\\s=m'
    str_1 = '4k^C1mKx1`tC'
    test_case(True, 4331, 7135.098, 'Tqszdvu#1I&A', 'K"F_q3%c\\s=m', '4k^C1mKx1`tC')
    test_case(False, -2679, 1238.6409, '@D$gBU`8R0H^', '{B9Xx_<0[0Ao', '~I^]c%O}Jnlk')


# Generated at 2022-06-25 06:58:33.254084
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = [None for _ in xrange(4)]
    tmp = None
    task_vars = {}
    action_module_0 = ActionModule()
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:58:40.219590
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name_0 = 'ansible.plugins.action.ActionBase'
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:58:41.368811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule(None, None, None, None)
    obj.run()

# Generated at 2022-06-25 06:58:42.346658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  obj = ActionModule()
  obj.run()


# Generated at 2022-06-25 06:58:45.184683
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Try to create an ActionModule
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:58:54.702178
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        str_0 = 'M5r!o0_e'
    except:
        str_0 = '@'
        str_1 = 'U6C'
    else:
        try:
            str_1 = 'db!\x0b\x3aN\x1f'
        except:
            str_1 = '('
            str_2 = 'W8t'
        else:
            str_2 = 'k-S@,'
        try:
            str_3 = '!o4'
        except:
            str_3 = 'rs'
            str_4 = '%y'
        else:
            str_4 = '\x15'
        str_5 = 'b'

# Generated at 2022-06-25 06:58:58.560569
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:59:02.844449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    tmp = None
    task_vars = None
    expected_result = {'failed': True, 'msg': "the 'key' param is required when using group_by", 'changed': False}
    result = ActionModule.run(ActionModule, tmp, task_vars)
    assert expected_result == result

# Generated at 2022-06-25 06:59:05.409048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ansible.plugins.action.ActionModule()
    assert (action_module.run() == 'test string')


# Generated at 2022-06-25 06:59:07.708025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-25 06:59:10.930967
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # var_0 = {u'parent_groups': [u'all'], u'key': u'hoekx', u'add_group': u'hoekx'}
  # var_1 = {u'add_group': u'all'}
  var_2 = ActionModule()
  print(var_2)


# Generated at 2022-06-25 06:59:17.037695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0() == None, 'Failed example test_case_0'
    assert 1 == 1, 'Test failed'

# Generated at 2022-06-25 06:59:28.491392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    f = ActionModule()
    str_1 = '-\t|(Jq&p9Xs'
    str_2 = '~Vu-96{i_1Vu'

    str_0 = f._task.args.get('key')
    str_1 = f._task.args.get('parents', ['all'])
    str_2 = f._task.args.get('key')
    str_3 = f._task.args.get('key')
    str_4 = f._task.args.get('key')
    str_5 = f._task.args.get('key')
    str_6 = f._task.args.get('key')
    str_7 = f._task.args.get('key')
    str_8 = f._task.args.get('key')

# Generated at 2022-06-25 06:59:29.040944
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 06:59:38.023246
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible_host = 'ansible_host'
    ansible_play_hosts = 'ansible_play_hosts'
    ansible_playbook_python = 'ansible_playbook_python'
    ansible_step = 'ansible_step'
    ansible_user = 'ansible_user'
    ansible_verbosity = 'ansible_verbosity'
    ansible_version = 'ansible_version'
    group_names = 'group_names'
    inventory_hostname = 'inventory_hostname'
    inventory_hostname_short = 'inventory_hostname_short'
    play_hosts = 'play_hosts'

    # Check for required param 'key' for class ActionModule
    check_required_param = True
    if (check_required_param):
        action_module = ActionModule

# Generated at 2022-06-25 06:59:39.687411
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj1 = ActionModule(host, task, connection, play_context, loader, templar, shared_loader_obj)


# Generated at 2022-06-25 06:59:45.602275
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = 'task'
    connection = 'connection'
    play_context = 'play_context'
    loader = 'loader'
    variable_manager = 'variable_manager'

    ansible_object = ActionModule(task, connection, play_context, loader, variable_manager)

    assert(ansible_object._task == task)
    assert(ansible_object._connection == connection)
    assert(ansible_object._play_context == play_context)
    assert(ansible_object._loader == loader)
    assert(ansible_object._templar == loader._templar)
    assert(ansible_object._shared_loader_obj == loader)
    assert(ansible_object._variable_manager == variable_manager)
    assert(ansible_object._result == result)

# Generated at 2022-06-25 06:59:47.341876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg_0 = '~;wS8=F:R'
    obj = ActionModule(arg_0)


# Generated at 2022-06-25 06:59:48.707455
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    obj_0 = ActionModule()


# Generated at 2022-06-25 06:59:55.576772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_0 = 'e!Y'
    host_0 = 'l]^'
    stack_var_0 = [['f_aqd'], [['~']]]
    _VALID_ARGS_0 = {'r5)': 'lWU6i[=C3yL>'}
    tmp_0 = '.p(7VZR#}'
    task_vars_0 = 'O'
    result_0 = [['z$;a!qF_m'], [{'=': 'L)l*[i#'}, ['z$;a!qF_m']]]
    result___class__ = result_0.__class__
    data___class__ = result_0.__class__
    tmp___class__ = result_0.__class__
    task_vars___

# Generated at 2022-06-25 07:00:02.389231
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(load_plugins=False)
    tmp = None
    task_vars = {'group_names': ['foo', 'bar']}
    result = action_module.run(tmp, task_vars)
    assert result['changed'] == False
    assert result['parent_groups'] == ['all']
    assert result['add_group'] == 'foobar'


# Generated at 2022-06-25 07:00:13.791581
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)
    action_module_0.run()



# Generated at 2022-06-25 07:00:22.835572
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:00:31.113834
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:00:36.901830
# Unit test for constructor of class ActionModule
def test_ActionModule():
  tuple_0 = ()
  set_0 = {tuple_0, tuple_0, tuple_0}
  str_0 = 'Iw\\:)tI'
  dict_0 = None
  tuple_1 = (set_0, set_0, str_0, dict_0)
  str_1 = 'u)fDrs8'
  action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)


# Generated at 2022-06-25 07:00:47.337471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
 	dict_0 = {'a': 'b'}
 	str_0 = 'key'
 	int_0 = 1
 	tuple_0 = ()
 	list_0 = None
 	list_1 = [('a', 'b'), dict_0, str_0, int_0]
 	set_0 = {tuple_0, tuple_0, tuple_0}
 	set_1 = {'a', dict_0, list_1, set_0}
 	dict_1 = {'a': 'b', dict_0: list_0, str_0: list_1, set_0: set_1}
 	str_1 = 'd'
 	tuple_1 = (dict_0, list_0, list_0, dict_1)

# Generated at 2022-06-25 07:00:52.086357
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_run(action_module_0)
    var_0 = action_run(action_module_0)


# Generated at 2022-06-25 07:00:58.031368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # Varible "tmp" is not assigned a value
    # Varible "task_vars" is not assigned a value
    # Should raise "NameError"
    # assertRaises(, action_module_0.run)

# Generated at 2022-06-25 07:01:02.226908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule(set_1, set_1, set_0, str_1, set_0, dict_0)
    var_0 = action_module_1.run(None, None)


# Generated at 2022-06-25 07:01:03.548706
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:01:09.906938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)
    # assert action_module_0.TRANSFERS_FILES == False

# Generated at 2022-06-25 07:01:17.957936
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert callable(ActionModule.run)


# Generated at 2022-06-25 07:01:27.066545
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)
    str_2 = 'aN9X'
    dict_1 = {'d_i--': str_2}
    dict_2 = dict_1.copy()
    dict_3 = dict_1.copy()
    dict_1.clear()
    dict_2.clear()
    dict_3.clear()


# Generated at 2022-06-25 07:01:37.310171
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ('m|>x', 'P>oD8LU')
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'vI%&nW'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'Z@`[u'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)
    str_2 = 'o2B!u#1'
    dict_1 = None
    tuple_2 = ({'=n6G'}, {'Hc/'}, str_2, dict_1)

# Generated at 2022-06-25 07:01:42.867134
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    tuple_2 = ()
    dict_1 = None
    action_module_0 = ActionModule(tuple_1, set_0, tuple_2, str_1, tuple_0, dict_1)
    action_module_0._VALID_ARGS.add('e4RNcr')
    assert action_module_0._VALID_ARGS == set_0
    assert action_module_0.server == tuple_1

# Generated at 2022-06-25 07:01:51.484932
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)
    action_module_0.run()
    assert action_module_0.run() == 0


# Generated at 2022-06-25 07:01:56.334033
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)


# Generated at 2022-06-25 07:02:05.957614
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = frozenset()
    var_1 = None
    var_2 = var_1
    var_3 = "u):)t#e"
    var_4 = (var_0, var_0, var_3, var_2)
    var_5 = var_4
    var_6 = 'u):)t#e'
    var_7 = ActionModule(var_4, var_0, var_5, var_6, var_0, var_2)
    var_9 = 'Iw\\:)tI'
    var_10 = 'Iw\\:)tI'
    var_12 = 'Iw\\:)tI'
    var_13 = 'Iw\\:)tI'
    var_14 = 'Iw\\:)tI'

# Generated at 2022-06-25 07:02:09.430774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)



# Generated at 2022-06-25 07:02:12.288037
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return


# Generated at 2022-06-25 07:02:18.104677
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)


# Generated at 2022-06-25 07:02:38.084772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:02:48.265494
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)
    assert (action_module_0._task.name == 'group_by')
    assert (action_module_0._task.args == {'key': '{{env}}'})
    assert (action_module_0.get_name() == 'group_by')

# Generated at 2022-06-25 07:02:52.862160
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)


# Generated at 2022-06-25 07:03:00.496550
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)


# Generated at 2022-06-25 07:03:01.251690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:03:11.611080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    str_2 = 'RC*zmhg'
    dict_1 = dict()
    dict_1['RC*zmhg'] = 'C'
    str_3 = 'k-5r1qw'
    dict_1['k-5r1qw'] = 'P'
    dict_2 = dict()
    dict_2['G'] = dict_1
    dict_2['P'] = dict_1
    action_module_2 = ActionModule(dict_2, dict_1, dict_2, str_3, dict_1, dict_1)
    str_4 = 'lS=l0'
    dict_3 = dict()
    dict_3['lS=l0'] = None
    dict_4 = dict()

# Generated at 2022-06-25 07:03:14.702048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    set_0 = {tuple_0}
    str_0 = 'm;J*'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = '8R%7'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)
    action_module_0.run()


# Generated at 2022-06-25 07:03:22.076414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_1 = ()
    set_0 = {tuple_1, tuple_1, tuple_1}
    str_1 = 'Iw\\:)tI'
    dict_1 = None
    tuple_0 = (set_0, set_0, str_1, dict_1)
    str_0 = 'u)fDrs8'
    action_module_1 = ActionModule(tuple_0, set_0, tuple_0, str_0, tuple_1, dict_1)
    action_module_1.run()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 07:03:27.677097
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)
    var_0 = action_module_0.run()
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 07:03:33.080543
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)
    func_0 = getattr(action_module_0, 'get_name', None)
    func_0()

# Generated at 2022-06-25 07:04:07.503738
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:04:14.096379
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    tuple_1 = (None, None, None)
    dict_0 = {}
    str_0 = '_'
    str_1 = '0/'
    str_2 = '_'
    str_3 = 'E{N'
    str_4 = ',6M'
    set_0 = {str_1, str_3, str_4}
    action_module_0 = ActionModule(tuple_0, set_0, tuple_1, str_0, tuple_0, dict_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:04:20.822556
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)

# Generated at 2022-06-25 07:04:27.119193
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:04:32.164984
# Unit test for constructor of class ActionModule
def test_ActionModule():

    msg = 'class ActionModule is defined'
    assert msg == 'class ActionModule is defined'


# Generated at 2022-06-25 07:04:37.239574
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Q$rv;?_'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'Yp?_P]g'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)
    var_1 = action_module_0.run(None, None)


# Generated at 2022-06-25 07:04:42.526503
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    dict_0 = None
    action_module_0 = ActionModule(set_0, set_0, set_0, set_0, set_0, dict_0)
    return action_module_0


# Generated at 2022-06-25 07:04:47.077383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)

# Generated at 2022-06-25 07:04:55.130286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)
    module = ActionModule()
    return


# Generated at 2022-06-25 07:05:03.199984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    set_0 = set()
    str_0 = 'RJ[7v!8'
    list_0 = ['J<u9Ikw']
    tuple_1 = (set_0, str_0, list_0)
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1)
    var_0 = action_module_0.run()
    assert var_0 == ({'failed': True, 'msg': 'the \'key\' param is required when using group_by'}, {})


# Generated at 2022-06-25 07:06:24.473151
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for constructor without parameters
    try:
        action_module_0 = ActionModule()
    except TypeError:
        print('Failed to create an instance without parameter')
    except Exception as e:
        print('Failed to create an instance without parameter, other Exception: ' + str(e))
    else:
        print('Create an instance without parameter successfully')

    # Test for constructor with parameters

# Generated at 2022-06-25 07:06:28.352217
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Y\\Z1r`'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'wVN`\x7f0'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)


# Generated at 2022-06-25 07:06:29.921830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	pass

# Generated at 2022-06-25 07:06:35.430597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()
    assert var_0._task == None
    assert var_0._connection == None
    assert var_0._play_context == None
    assert var_0._loader == None
    assert var_0._templar == None
    assert var_0._shared_loader_obj == None
    assert var_0._action == None
    assert var_0._force_handlers == None
    assert var_0._task_vars == None
    assert var_0._task_vars_template == None
    assert var_0._task_vars_params == None
    assert var_0._clean_copy == None
    assert var_0._task_tmpdir == None
    assert var_0._executor_internal_port == None
    assert var_0._executor_connector == None

# Generated at 2022-06-25 07:06:40.420454
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    action_module_0 = ActionModule([], {}, {}, "", "", dict_0)
    print(action_module_0)

# Generated at 2022-06-25 07:06:46.330538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)
    assert not (action_module_0.run())



# Generated at 2022-06-25 07:06:53.807272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)
    return action_module_0


# Generated at 2022-06-25 07:06:58.255381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)
    var_0 = action_run()
    return var_0

# Generated at 2022-06-25 07:07:07.764137
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)
    print(action_module_0._task.args.values())

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:07:14.750402
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    str_0 = 'Iw\\:)tI'
    dict_0 = None
    tuple_1 = (set_0, set_0, str_0, dict_0)
    str_1 = 'u)fDrs8'
    action_module_0 = ActionModule(tuple_1, set_0, tuple_1, str_1, tuple_0, dict_0)
