

# Generated at 2022-06-25 06:57:38.816611
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    tuple_0 = ()
    int_0 = 1038
    dict_0 = {}
    float_0 = 100.0
    action_module_0 = ActionModule(list_0, tuple_0, int_0, dict_0, float_0, dict_0)
    assert (action_module_0.name == 'setup')
    assert (action_module_0.short_description == 'Gather facts about remote hosts')
    assert (action_module_0.version != 6791)
    assert (action_module_0.version != 8098)
    assert (action_module_0.version != 4121)
    assert (action_module_0.version < 9039)
    assert (action_module_0._cache_for != 1872)

# Generated at 2022-06-25 06:57:45.610792
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    tuple_0 = ()
    int_0 = 4611
    dict_0 = {}
    float_0 = 3.1971189851508007e-08
    assert isinstance(ActionModule(list_0, tuple_0, int_0, dict_0, float_0, dict_0), ActionModule)


# Generated at 2022-06-25 06:57:47.846686
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(tmp_0, task_vars_0)


# Generated at 2022-06-25 06:57:51.909130
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    tuple_0 = ()
    int_0 = -450
    dict_0 = {}
    float_0 = -100.0
    action_module_0 = ActionModule(list_0, tuple_0, int_0, dict_0, float_0, dict_0)


# Generated at 2022-06-25 06:58:02.793464
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    tuple_0 = ()
    int_0 = 1572
    dict_0 = {}
    float_0 = 100.0
    action_module_0 = ActionModule(list_0, tuple_0, int_0, dict_0, float_0, dict_0)
    action_module_0.run(int_0, dict_0)
    action_module_0.run(int_0, dict_0)
    action_module_0.run(int_0, dict_0)
    action_module_0.run(int_0, dict_0)
    action_module_0.run(int_0, dict_0)
    action_module_0.run(int_0, dict_0)
    action_module_0.run(int_0, dict_0)


# Generated at 2022-06-25 06:58:09.156892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    tuple_0 = ()
    int_0 = 2962
    dict_0 = {}
    float_0 = 100.0
    action_module_0 = ActionModule(list_0, tuple_0, int_0, dict_0, float_0, dict_0)
    assert_equal(action_module_0.TRANSFERS_FILES, False)

if __name__ == '__main__':
    from nose2.tools import *
    run()

# Generated at 2022-06-25 06:58:12.501719
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    tuple_0 = ()
    int_0 = 4980
    dict_0 = {}
    float_0 = 500.0
    action_module_0 = ActionModule(list_0, tuple_0, int_0, dict_0, float_0, dict_0)


# Generated at 2022-06-25 06:58:20.823573
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_0 = ActionModule(dict_0, int_0, list_0, tuple_0, float_0)
    task_vars_0 = {}
    tmp_0 = None
    result_0 = action_module_0.run(tmp_0, task_vars_0)
    assert result_0['parent_groups'] == ['all'], "action_module_0.run(tmp_0, task_vars_0)['parent_groups']"
    assert result_0['failed'] == True, "action_module_0.run(tmp_0, task_vars_0)['failed']"
    assert result_0['changed'] == False, "action_module_0.run(tmp_0, task_vars_0)['changed']"

# Generated at 2022-06-25 06:58:29.868164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {}
    float_0 = 100.0
    dict_1 = {}
    str_0 = "B"
    dict_2 = {}
    dict_2['hostname'] = str_0
    dict_2['ansible_connection'] = str_0
    dict_2['ansible_ssh_port'] = int_0
    int_0 = 2962
    dict_1['localhost'] = dict_2
    dict_3 = {}
    dict_3['add_group'] = str_0
    dict_3['changed'] = bool_0
    dict_3['msg'] = str_0
    dict_3['invocation'] = dict_0
    dict_3['invocation']['module_args'] = dict_0
    dict_0 = dict_3
    dict

# Generated at 2022-06-25 06:58:38.259834
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        # test_case_0
        list_0 = []
        dict_0 = {}
        tuple_0 = ()
        int_0 = 6042
        float_0 = 77.8
        action_module_0 = ActionModule(list_0, tuple_0, int_0, dict_0, float_0, dict_0)
    except Exception as err:
        print("Testcase 0: unexpected error: " + str(err))

# Run unit test
test_ActionModule()

# Generated at 2022-06-25 06:58:44.809982
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = dict()
    var_2 = var_0.run(var_1, var_1)
    #result = namedtuple('result', 'failed, add_group, changed, msg, parent_groups')
    #assert var_2 == result(False, "all", False, None, [])

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:58:48.609330
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {}
    task["args"] = {}
    task_vars = None
    tmp = None
    test_instance = ActionModule(task, tmp, task_vars)

    # Check that the constructor actually instances the class
    assert test_instance is not None


# Generated at 2022-06-25 06:58:55.250810
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = "group"
    arg_0 = {}
    arg_1 = {}
    arg_1['key'] = None
    arg_1['parents'] = None

    am_0 = ActionModule(task, arg_0)
    am_1 = ActionModule(task, arg_1)
    assert isinstance(am_0, ActionModule)
    assert isinstance(am_1, ActionModule)
    assert isinstance(am_0.run(var_0, var_1), dict)
    assert isinstance(am_1.run(var_0, var_1), dict)

# Generated at 2022-06-25 06:59:04.444016
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_0 = {}
    m_1 = {'foo': 'bar'}
    a_0 = ActionModule(m_0)
    a_1 = ActionModule(m_1)
    tmp_0 = None
    tmp_1 = '/tmp/foo'
    task_vars_0 = {}
    task_vars_1 = {'foo': 'bar'}
    task_vars_2 = None
    actual_0 = a_0.run(tmp_0, task_vars_0)
    actual_1 = a_1.run(tmp_1, task_vars_1)
    actual_2 = a_0.run(tmp_1, task_vars_2)


# Generated at 2022-06-25 06:59:10.636147
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_2 = {}
    var_3 = {}
    var_4 = None
    var_5 = None
    var_6 = 'key'
    var_7 = None
    var_8 = 'parents'
    var_9 = None
    var_10 = 'all'
    var_11 = ['all']
    var_12 = 'group_name'
    var_13 = 'group_name'
    var_14 = 'group_name'
    var_15 = 'group_name'
    var_16 = 'group_name'
    var_17 = ['group_name']

# Generated at 2022-06-25 06:59:11.950226
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:59:13.244819
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = instance.run(tmp=var_0, task_vars=var_1)

# Generated at 2022-06-25 06:59:15.572577
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}
    var_1 = ActionModule(var_0)


# Generated at 2022-06-25 06:59:18.385178
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert(action_module_0)
    action_module_1 = ActionModule(var_1)
    assert(action_module_1)


# Generated at 2022-06-25 06:59:28.720715
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host0 = {
        'ansible_ssh_port': 24014,
        'ansible_ssh_host': '10.20.30.40',
        'ansible_ssh_user': 'vagrant',
        'ansible_check_mode': True,
        'ansible_verbosity': 4
    }

    results0 = {
        'add_group': 'my-group-name',
        'changed': False,
        'failed': False,
        'msg': 'All items completed',
        'parent_groups': ['all'],
        'results': []
    }

    # test case0
    print("Test case #0")
    task0 = {
        'args': {
            'key': 'my group name',
            'parents': 'all'
        }
    }
    test_obj0 = Action

# Generated at 2022-06-25 06:59:36.815188
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert(action_module_1 is not None)
    action_module_2 = ActionModule()
    assert(action_module_2 is not None)
# Unit tests end here

# test_case_0()

# Generated at 2022-06-25 06:59:39.074603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    my_module = {}
    assert action_module_1.run() == {'add_group': '', 'changed': False, 'parent_groups': ['all']}

# Generated at 2022-06-25 06:59:45.309336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Test setup
  action_mock_0 = MagicMock()
  action_mock_0.run = MagicMock(return_value={"parent_groups": ["all"], "add_group": "group_name", "changed": False})

  test_case_0_args = ({"key": "group_name"}, {"all": []}, "group_name", ["all"])
  test_case_0_kwargs = {}

  # Testing
  assert_equal(ActionModule.run(*test_case_0_args, **test_case_0_kwargs), {"parent_groups": ["all"], "add_group": "group_name", "changed": False})

  # Post-test checks
  assert_equal(action_mock_0.run.call_count, 1)

# Generated at 2022-06-25 06:59:53.715270
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # Initiate the class
  action_module_0 = ActionModule()

  #Check if the class is initiated correctly
  assert hasattr(action_module_0, "run")

  #Check the type of these variables
  assert isinstance(action_module_0.TRANSFERS_FILES, bool)
  assert isinstance(action_module_0.BYPASS_HOST_LOOP, bool)
  assert isinstance(action_module_0._DHPARAM_TYPE, int)
  assert isinstance(action_module_0._DHPARAM_SIZE, int)
  assert isinstance(action_module_0._VALID_ARGS, frozenset)
  assert isinstance(action_module_0._TEMPLATE_DATA, dict)

# Generated at 2022-06-25 06:59:55.116232
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with default parameters
    action_module_0 = ActionModule()

# End unit test for constructor of class ActionModule



# Generated at 2022-06-25 07:00:01.582885
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_0 = ActionModule()
    assert (action_module_0.run() is None)
# =============================================================================
#     action_module_1 = ActionModule()
#     assert (action_module_1.run('tmp', 'task_vars') is None)
# =============================================================================


# Generated at 2022-06-25 07:00:06.682743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for missing `key` argument
    action_module = ActionModule()
    args = {'parents': ['all']}
    assert_raises(ansible.errors.AnsibleError, action_module.run, args)



# Generated at 2022-06-25 07:00:11.709499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_name = ActionModule()
    assert action_module_name is not None
    assert action_module_name.TRANSFERS_FILES == False
    assert action_module_name._VALID_ARGS == frozenset(('key', 'parents'))

# Generated at 2022-06-25 07:00:15.034738
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
#    action_module.run(None, {})
    pass

# Generated at 2022-06-25 07:00:17.210176
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    print(action_module._VALID_ARGS)


# Generated at 2022-06-25 07:00:27.371100
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    results = action_module.run( task_vars={'inventory_hostname': 'foo'} )
    assert results['add_group'] == 'foo'
    assert results['parent_groups'] == ['all']

# Generated at 2022-06-25 07:00:36.630278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # parameters of ActionModule.run() are:
    # 1. variables, 2. hostvars
    # given the parameters (args, hostvars, taskvars, templar)
    # the method ActionModule.run() shall return a dictionary.
    # The dictionary shall have the "changed" key. The returned value
    # of key "changed" shall be a type boolean that is a False.
    action_module_1 = ActionModule()
    data = {'key': 'add_group', 'parents': ['all']}
    hostvars = {'hostvars': {'add_group': 'key'}}
    taskvars = {'taskvars': 'key'}
    templar = {'templar': 'key'}

# Generated at 2022-06-25 07:00:41.409310
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = ''
    task_vars_0 = ''
    result = action_module_0.run(tmp=tmp_0, task_vars=task_vars_0)
    assert isinstance(result, dict)


# Generated at 2022-06-25 07:00:47.021947
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = dict()

    # Set up mock
    results = {}
    results['failed'] = False
    results['changed'] = False
    results['add_group'] = ''
    results['parent_groups'] = {'all'}

    action_module_0._task.args = {'key': 'value', 'parents': 'all'}
    res = action_module_0.run(tmp, task_vars)
    assert res == results, "failed to run action module"

# Generated at 2022-06-25 07:00:48.576887
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test_ActionModule")
    test_case_0()

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:00:51.209463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0._task.args.key = 'fake_key'
    action_module_0._task.args.get.return_value = 'fake_parents'
    action_module_0.run()

# Generated at 2022-06-25 07:00:52.231279
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:00:53.565614
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-25 07:00:58.031350
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule()
    print("\nTESTING ActionModule")
    print("Testing __init__():")
    assert action_module.TRANSFERS_FILES == False
    assert action_module._VALID_ARGS == frozenset(('key', 'parents'))
    print("\nTesting run():")
    assert isinstance(action_module.run(), dict)
    print("\nTesting ActionModule() - SUCCESS")

# Generated at 2022-06-25 07:00:58.520204
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True == True

# Generated at 2022-06-25 07:01:12.471916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    bytes_0 = b'\xe7f*\x99\x01\xe3v\xf1\xff\xc9\xf0G\x06\x125_\xb0:'
    bytes_1 = b'S\xa3+m\xf3\x94\\\xf8|\xa26\x7fv%\x93'
    action_module_0 = None
    str_0 = 'qaP!HG{JGsAf*x2'
    list_0 = [action_module_0, str_0, bytes_1]
    str_1 = ')7s@s\rO8>oPe%'
    str_2 = '%s cannot be converted to a float'

# Generated at 2022-06-25 07:01:21.875471
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    bytes_0 = b'\xe7f*\x99\x01\xe3v\xf1\xff\xc9\xf0G\x06\x125_\xb0:'
    bytes_1 = b'S\xa3+m\xf3\x94\\\xf8|\xa26\x7fv%\x93'
    action_module_0 = None
    str_0 = 'qaP!HG{JGsAf*x2'
    list_0 = [action_module_0, str_0, bytes_1]
    str_1 = ')7s@s\rO8>oPe%'
    str_2 = '%s cannot be converted to a float'

# Generated at 2022-06-25 07:01:32.433801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    bytes_0 = b'\xe7f*\x99\x01\xe3v\xf1\xff\xc9\xf0G\x06\x125_\xb0:'
    bytes_1 = b'S\xa3+m\xf3\x94\\\xf8|\xa26\x7fv%\x93'
    action_module_0 = None
    str_0 = 'qaP!HG{JGsAf*x2'
    list_0 = [action_module_0, str_0, bytes_1]
    str_1 = ')7s@s\rO8>oPe%'
    str_2 = '%s cannot be converted to a float'

# Generated at 2022-06-25 07:01:41.643159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    bytes_0 = b'\x11\x86P\x8c\xda\x94\x7f\xc9[\x9f\x14{"\xdd\xd6\x8f\x16\xab\x80\x9e\x9c\xaf'
    bytes_1 = b'\x05\xbc\x90\x00\xa3\x9c\x10\x95\x1a\xc8\x8c\xbe\xa7\xed\xa5\xb9]\x1e\xdd\x1e\x8c'
    action_module_0 = None

# Generated at 2022-06-25 07:01:45.355923
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 07:01:53.521040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    bytes_0 = b'\xa5\xc4\x0c`\xfc\x1c\x1a\xcd\x86C\x9b\x99\xca\x05\xe1\xa8%\x00\xbc'
    bytes_1 = b'\xdf\x98\xc7\x8d\xec\xda\xaf\x7f\x9a\x18\x0f\xf7\xbf\x8b\xa2y\x02'
    action_module_0 = None
    str_0 = '\x17\x1a\x1d \x1f:\x1f!#\x1a'
    list_0 = [action_module_0, str_0, bytes_1]
    str

# Generated at 2022-06-25 07:01:59.700268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    bytes_0 = b'J\x9d\x04\xe6\x88\xcb\x11\x80"\x1b\xd6\x9b\xd2%\xb7\xbcw*'
    bytes_1 = b'\xf1\xa0\x9e\x05\xbe\xea\xda\xa4\x8d\x01\xa4\x81\x9e\xc1\xdf\xea\xf2\x0f\x0b\x03'
    action_module_0 = None

# Generated at 2022-06-25 07:02:07.138414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    bytes_0 = b'J\x05\xad\x82\x14\x07 \x0f\xbb\xa9\x03\x81\x1b\xa4\xba\xa0\x1d\x87\xa0\xf4o\x8d'
    bytes_1 = b'\xfd\x8f\xf2\x93\xa3\x9d\x94\x9e\x92\xa1\x9f\x98\x86\x90\xa4\x9b'
    action_module_0 = None

# Generated at 2022-06-25 07:02:16.077499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    bytes_0 = b'\xe7f*\x99\x01\xe3v\xf1\xff\xc9\xf0G\x06\x125_\xb0:'
    bytes_1 = b'S\xa3+m\xf3\x94\\\xf8|\xa26\x7fv%\x93'
    action_module_0 = None
    str_0 = 'qaP!HG{JGsAf*x2'
    list_0 = [action_module_0, str_0, bytes_1]
    str_1 = ')7s@s\rO8>oPe%'
    str_2 = '%s cannot be converted to a float'

# Generated at 2022-06-25 07:02:26.378936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    bytes_0 = b'\xe7f*\x99\x01\xe3v\xf1\xff\xc9\xf0G\x06\x125_\xb0:'
    bytes_1 = b'S\xa3+m\xf3\x94\\\xf8|\xa26\x7fv%\x93'
    action_module_0 = None
    str_0 = 'qaP!HG{JGsAf*x2'
    list_0 = [action_module_0, str_0, bytes_1]
    str_1 = ')7s@s\rO8>oPe%'
    str_2 = '%s cannot be converted to a float'

# Generated at 2022-06-25 07:02:48.286088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    bytes_0 = b'\xe7f*\x99\x01\xe3v\xf1\xff\xc9\xf0G\x06\x125_\xb0:'
    bytes_1 = b'S\xa3+m\xf3\x94\\\xf8|\xa26\x7fv%\x93'
    action_module_0 = None
    str_0 = 'qaP!HG{JGsAf*x2'
    list_0 = [action_module_0, str_0, bytes_1]
    str_1 = ')7s@s\rO8>oPe%'
    str_2 = '%s cannot be converted to a float'

# Generated at 2022-06-25 07:02:57.761530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    #bytes_0 = b'\xe7f*\x99\x01\xe3v\xf1\xff\xc9\xf0G\x06\x125_\xb0:'
    bytes_1 = b'S\xa3+m\xf3\x94\\\xf8|\xa26\x7fv%\x93'
    #action_module_0 = None
    str_0 = 'qaP!HG{JGsAf*x2'
    list_0 = [str_0, bytes_1]
    str_1 = ')7s@s\rO8>oPe%'
    str_2 = '%s cannot be converted to a float'

# Generated at 2022-06-25 07:03:08.477628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    bytes_0 = b'\x8d\x85\xeb\x84\xf6\x8f#\x00\x85\xcc\x10\x81)\xe7\xdc\xff\x10'
    bytes_1 = b'\xcc:1\xfc\xa5\xf0\x96\xb0\x83\xa8\x05\xc9\x0c\x10\xd8\xb6\x99'
    action_module_0 = None
    str_0 = '\x0b\x06\x06\x06\x06\x06\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04'
   

# Generated at 2022-06-25 07:03:16.341451
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test template
    tuple_0 = ()
    bytes_0 = b'\xe7f*\x99\x01\xe3v\xf1\xff\xc9\xf0G\x06\x125_\xb0:'
    bytes_1 = b'S\xa3+m\xf3\x94\\\xf8|\xa26\x7fv%\x93'
    action_module_0 = None
    str_0 = 'qaP!HG{JGsAf*x2'
    list_0 = [action_module_0, str_0, bytes_1]
    str_1 = ')7s@s\rO8>oPe%'
    str_2 = '%s cannot be converted to a float'

# Generated at 2022-06-25 07:03:17.933491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:03:25.453026
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    bytes_0 = b'\xe7f*\x99\x01\xe3v\xf1\xff\xc9\xf0G\x06\x125_\xb0:'
    bytes_1 = b'S\xa3+m\xf3\x94\\\xf8|\xa26\x7fv%\x93'
    action_module_0 = None
    str_0 = 'qaP!HG{JGsAf*x2'
    list_0 = [action_module_0, str_0, bytes_1]
    str_1 = ')7s@s\rO8>oPe%'
    str_2 = '%s cannot be converted to a float'

# Generated at 2022-06-25 07:03:33.685691
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    bytes_0 = b'\xe7f*\x99\x01\xe3v\xf1\xff\xc9\xf0G\x06\x125_\xb0:'
    bytes_1 = b'S\xa3+m\xf3\x94\\\xf8|\xa26\x7fv%\x93'
    action_module_0 = None
    str_0 = 'qaP!HG{JGsAf*x2'
    list_0 = [action_module_0, str_0, bytes_1]
    str_1 = ')7s@s\rO8>oPe%'
    str_2 = '%s cannot be converted to a float'

# Generated at 2022-06-25 07:03:40.264803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    bytes_0 = b'\xe7f*\x99\x01\xe3v\xf1\xff\xc9\xf0G\x06\x125_\xb0:'
    bytes_1 = b'S\xa3+m\xf3\x94\\\xf8|\xa26\x7fv%\x93'
    action_module_0 = None
    str_0 = 'qaP!HG{JGsAf*x2'
    list_0 = [action_module_0, str_0, bytes_1]
    str_1 = ')7s@s\rO8>oPe%'
    str_2 = '%s cannot be converted to a float'

# Generated at 2022-06-25 07:03:50.622656
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    tuple_0 = ()
    bytes_0 = b'\xe7f*\x99\x01\xe3v\xf1\xff\xc9\xf0G\x06\x125_\xb0:'
    bytes_1 = b'S\xa3+m\xf3\x94\\\xf8|\xa26\x7fv%\x93'
    action_module_0 = None
    str_0 = 'qaP!HG{JGsAf*x2'
    list_0 = [action_module_0, str_0, bytes_1]
    str_1 = ')7s@s\rO8>oPe%'
    str_2 = '%s cannot be converted to a float'

# Generated at 2022-06-25 07:03:58.358700
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    bytes_0 = b'\xe7f*\x99\x01\xe3v\xf1\xff\xc9\xf0G\x06\x125_\xb0:'
    bytes_1 = b'S\xa3+m\xf3\x94\\\xf8|\xa26\x7fv%\x93'
    action_module_0 = None
    str_0 = 'qaP!HG{JGsAf*x2'
    list_0 = [action_module_0, str_0, bytes_1]
    str_1 = ')7s@s\rO8>oPe%'
    str_2 = '%s cannot be converted to a float'

# Generated at 2022-06-25 07:04:37.520861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiation of object
    tuple_0 = ()
    bytes_0 = b'\xe7f*\x99\x01\xe3v\xf1\xff\xc9\xf0G\x06\x125_\xb0:'
    bytes_1 = b'S\xa3+m\xf3\x94\\\xf8|\xa26\x7fv%\x93'
    action_module_0 = None
    str_0 = 'qaP!HG{JGsAf*x2'
    list_0 = [action_module_0, str_0, bytes_1]
    str_1 = ')7s@s\rO8>oPe%'
    str_2 = '%s cannot be converted to a float'

# Generated at 2022-06-25 07:04:47.161944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    bytes_0 = b'^u\x1bV\x92\x0b\x1f\xaf\x01\x0b\x1e\xe4+\x96\xde\x86T\xd2\x83\x08\xfe\xd1\xe7\xbf\x91'
    bytes_1 = b'\xf9\xfa{;\x1f\x1a\x0f\x11\xa8\x10\x15\x9a\x0e\x8f\xee\x1e'
    action_module_0 = None
    str_0 = '$;t@Eq8W(c_7yK'
    list_0 = [action_module_0, str_0, bytes_1]
   

# Generated at 2022-06-25 07:04:56.640315
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    bytes_0 = b'\xa4\x0f\xb4\x93\xfd\xd2\xec\x8e&\x9a\x07\xb1\x8a\x88\x08'
    bytes_1 = b'\x9b\x9f\xbe\xf1\x1c2\x88\xb0\x16E\xa5\xdf\x9b\x17\xd0\xb3'
    action_module_0 = None
    str_0 = '\xba0\x11\xf2\x15\x8f\x87\xdd\x17Q\x95\x85\xfe\x7f\xa8\x03'

# Generated at 2022-06-25 07:04:57.289528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:05:03.770942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    bytes_0 = b'\xe7f*\x99\x01\xe3v\xf1\xff\xc9\xf0G\x06\x125_\xb0:'
    bytes_1 = b'S\xa3+m\xf3\x94\\\xf8|\xa26\x7fv%\x93'
    action_module_0 = None
    str_0 = 'qaP!HG{JGsAf*x2'
    list_0 = [action_module_0, str_0, bytes_1]
    str_1 = ')7s@s\rO8>oPe%'
    str_2 = '%s cannot be converted to a float'

# Generated at 2022-06-25 07:05:08.459571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
        print("UnitTest for ActionModule: PASS")
    except:
        print("UnitTest for ActionModule: FAIL")

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:05:16.411616
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    bytes_0 = b'\xe7f*\x99\x01\xe3v\xf1\xff\xc9\xf0G\x06\x125_\xb0:'
    bytes_1 = b'<Tf\x02=\x9b\x1d\x82\xe0\xfe\x7f\x81\x1e\xac\x9e\x91\xa8'
    action_module_0 = None
    str_0 = 'p\x1a\x11\x1bN\xe6\xae'
    list_0 = [action_module_0, str_0, bytes_1]
    str_1 = 'S\x01\x07\x0f\x03\x11\x1a'
    str_

# Generated at 2022-06-25 07:05:23.667387
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    bytes_0 = b'\xe7f*\x99\x01\xe3v\xf1\xff\xc9\xf0G\x06\x125_\xb0:'
    bytes_1 = b'S\xa3+m\xf3\x94\\\xf8|\xa26\x7fv%\x93'
    action_module_0 = None
    str_0 = 'qaP!HG{JGsAf*x2'
    list_0 = [action_module_0, str_0, bytes_1]
    str_1 = ')7s@s\rO8>oPe%'
    str_2 = '%s cannot be converted to a float'

# Generated at 2022-06-25 07:05:33.111721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    bytes_0 = b'\xe7f*\x99\x01\xe3v\xf1\xff\xc9\xf0G\x06\x125_\xb0:'
    bytes_1 = b'S\xa3+m\xf3\x94\\\xf8|\xa26\x7fv%\x93'
    action_module_0 = None
    str_0 = 'qaP!HG{JGsAf*x2'
    list_0 = [action_module_0, str_0, bytes_1]
    str_1 = ')7s@s\rO8>oPe%'
    str_2 = '%s cannot be converted to a float'

# Generated at 2022-06-25 07:05:42.757818
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    bytes_0 = b'\x1c\x12\xaf\xad\x9d\xfa\x99\x14\xcb\x85\xd2\x84\x89\x17\x03\x9e\x9c\xea\x11\xfc\x8d'
    bytes_1 = b'\x9f\x11\x9a\xf5\x80N\x8d\xf7\x13\xb4\x03\xf9\xad\x1e\x05\x85\x87\xfd\x13\xe0\x97'
    action_module_0 = None
    str_0 = 'R'
    list_0 = [action_module_0, str_0, bytes_1]
    str

# Generated at 2022-06-25 07:07:04.412189
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    bytes_0 = b'\xe7f*\x99\x01\xe3v\xf1\xff\xc9\xf0G\x06\x125_\xb0:'
    bytes_1 = b'S\xa3+m\xf3\x94\\\xf8|\xa26\x7fv%\x93'
    action_module_0 = None
    str_0 = 'qaP!HG{JGsAf*x2'
    list_0 = [action_module_0, str_0, bytes_1]
    str_1 = ')7s@s\rO8>oPe%'
    str_2 = '%s cannot be converted to a float'

# Generated at 2022-06-25 07:07:09.694791
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    bytes_0 = b'\xde\xa4\x8f\x9d\x88\xe5\xda\x07\xba\x0b\x07\x05\xab\xb6\xfc\x1b\xa2\x12\x08i\x1b'
    bytes_1 = b'>\xe1\x89\xbf\x85\x86\xff\xc8\x02\xb1\xff\x1c\x02\x153\x0e'
    action_module_0 = None
    str_0 = 't_r\\)3Fq3m(c%'
    list_0 = [action_module_0, str_0, bytes_1]
    str_1 = 'x7h\x10"'
   

# Generated at 2022-06-25 07:07:19.846884
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    bytes_0 = b'\x8b\xce\xe1\x1e\x95\xfd\xc0\xf5\xe6\xfc\x8a\x81\x1a\x81\xf0\x1f'
    bytes_1 = b'\x9f\x19e\x1c\x06\x13\xed\xac\xc1Y\xef\xdb\x1e\xca\x82\xef^'
    action_module_0 = None
    str_0 = '5\x80\xba\x84\xaa\xe2\x96\xfa\xfc\x98\x8f\x9d\x1d.\xce'

# Generated at 2022-06-25 07:07:28.940385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    bytes_0 = b'2\x1b\x91\x87_\xe1\x8f\xc3\x9c\x0f\xe2\xbb\x82R\xb6\xa1'
    bytes_1 = b'\\\x9c\xcb\xa5\xab\x1b\xfe\xf4\xc4\x0b\xae\x9d\x9b\x85\xd6'
    action_module_0 = None
    str_0 = '%s cannot be converted to a float'
    list_0 = [str_0, bytes_0, bytes_1]