

# Generated at 2022-06-11 11:52:42.663866
# Unit test for constructor of class ActionModule
def test_ActionModule():
    n = ActionModule()
    assert n != None


# Generated at 2022-06-11 11:52:46.881868
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  action_module = ActionModule()
  action_module._task = Mock()
  action_module._task.args = {'key': 'test_1'}

  result = action_module.run()
  assert result['changed'] == False
  assert result['add_group'] == 'test_1'
  assert result['parent_groups'] == ['all']


# Generated at 2022-06-11 11:52:47.800937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule('task').run()

# Generated at 2022-06-11 11:52:50.758216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(task= {'args': {}}, connection=None, play_context=None, loader=None, templar=None)
    assert hasattr(obj, 'run')
    assert hasattr(obj, '_execute_module')
    assert hasattr(obj, '_loader')
    assert hasattr(obj, '_task')

# Generated at 2022-06-11 11:52:51.254218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:52:51.724889
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:53:00.985361
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def test_method_run(self):
        self._loader.load_from_file = MagicMock(return_value=dict())
        assert not self._connection.run.called, 'Command connection.run should not be called when no key is specified'
        self._task.args = { 'key': 'ip' }
        result = self._execute_module()
        assert not self._connection.run.called, 'Command connection.run should not be called when key is only specified'
        assert not result['failed'], 'The method should return success when key is only specified'
        assert result['changed'], 'The result should contain changed when key is only specified'
        assert result['add_group'] == 'ip', 'The result should contain add_group when key is only specified'

# Generated at 2022-06-11 11:53:10.954135
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock.patch is used to replace "ansible.plugins.action.ActionBase" with "test_ansible_module_action.FakeActionBase"
    # Create an instance of class ActionModule with args of function run
    with mock.patch('ansible.plugins.action.ActionBase', autospec=True) as mock_ActionBase:
        mock_ActionBase_instance       = mock.Mock()
        mock_ActionBase.return_value   = mock_ActionBase_instance
        action_module_instance         = ActionModule(task=dict(), connection=None, play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    # Create a mock object for tmp and task_vars
    tmp = mock.Mock()
    task_vars = mock.Mock()
    # Set the parameters for calling function

# Generated at 2022-06-11 11:53:21.183149
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # pylint: disable=protected-access
    # pylint: disable=too-many-boolean-expressions

    from ansible.plugins.action import ActionModule

    test_action = ActionModule(
        {}, {}, {}, {}, 'test_action', 'test_play', 'test_play_index', 'test_play_line', {'key': 'value'}, 'test_play_hosts',
        'test_play_include_role'
    )
    result = test_action._execute_module(task_vars=dict())
    assert result['failed'] == False
    assert result['changed'] == False
    assert result['add_group'] == 'value'
    assert result['parent_groups'] == ['all']


# Generated at 2022-06-11 11:53:24.321948
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''check if the ActionModule() class can be instantiated'''
    action_mod = ActionModule(None, None, None, None)
    assert action_mod is not None

# Generated at 2022-06-11 11:53:28.975145
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('a', 'b', 'c')

# Generated at 2022-06-11 11:53:40.377967
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test ActionModule class
    """
    args = dict()
    args['key'] = 'null'
    args['parents'] = ['all']

    #test1 
    with pytest.raises(Exception):
        ansible_task = {}
        ansible_action = {}
        ansible_task['name'] = 'test'
        ansible_task['action'] = ansible_action
        ansible_action['module'] = 'group_by'
        ansible_action['args'] = args
        aActionModule = ActionModule(ansible_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
        result = aActionModule.run(tmp=None, task_vars=None)


# Generated at 2022-06-11 11:53:45.498673
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule({'delegate_to': 'test_host', 'key': 'test_group'}, {})
    result = module.run({}, {})
    assert isinstance(result, dict)
    assert 'failed' not in result
    assert result['changed'] is False
    assert result['add_group'] == 'test_group'
    assert result['parent_groups'] == ['all']

# Generated at 2022-06-11 11:53:57.366162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''
    # Create a task with action module group_by
    # and set required parameter 'key'
    task = {'action': {'__ansible_module__': 'group_by',
                       '__ansible_arguments__': {'key':'ansible_distribution'}},
            'imports': [],
            'parameters': {'free_form': '', 'key': 'ansible_distribution', 'parents': 'all'},
            'vars': {'ansible_distribution': 'Fedora'}}
    # Initialize the class with the task and a tmp directory
    tar = ActionModule(task=task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Create a temporary

# Generated at 2022-06-11 11:54:08.963952
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    import json

    # Create the object that runs plays
    loader, inventory, variable_manager = \
            PlaybookExecutor._load_playbook_from_file(
                    '../../tests/test_action_group_by.yml',
                    vault_password='dummy')
    tqm = TaskQueueManager(
            loader=loader,
            inventory=inventory,
            variable_manager=variable_manager,
            passwords={})



# Generated at 2022-06-11 11:54:15.488650
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 11:54:25.964494
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule('test', {}, {}, {'inventory_hostname': 'test'})
    result = module.run()
    assert result.get('failed') is not None
    result = module.run({}, {'group_by': 'test'})
    assert result.get('failed') is not None
    result = module.run({}, {'group_by': 'test'}, {'key': 'test'})
    assert result.get('add_group') == 'test'
    assert result.get('parent_groups') == ['all']
    assert result.get('invocation').get('module_args') == {'key': 'test', 'parents': ['all']}
    assert result.get('changed') is False

# Generated at 2022-06-11 11:54:34.892255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_args = {
        'group_by': True,
        'register': 'add_group',
        'key': 'frontend',
        'parent': 'all',
        'value': 'webservers'
    }
    action = ActionModule(load_fixture('fake_task'), task_args, load_fixture('fake_play'))
    result = action.run(task_vars={'inventory_hostname': 'foobarbaz'})
    assert result['changed'] == False
    assert result['add_group'] == 'frontend'
    assert result['parent_groups'] == ['all']

# Generated at 2022-06-11 11:54:36.237770
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #TODO: Mock class and test
    assert(False)

# Generated at 2022-06-11 11:54:44.715192
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    class ModuleTest(ActionModule):
        def run(self, tmp=None, task_vars=None):
            task_vars['ansible_facts'] = {
                'eth0': {
                    'ipv4': {'address': '192.168.1.1'},
                    'ipv6': [
                        {'address': 'fe80::5054:ff:fe12:3456'},
                        {'address': '2001:db8::1'},
                    ],
                }
            }
            return super(ModuleTest, self).run(tmp, task_vars)


# Generated at 2022-06-11 11:55:00.771960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test the basic group_by case
    task = dict(
        action=dict(
            module='group_by',
            key='os',
        )
    )
    action = ActionModule(task, dict())
    result = action.run(task_vars=dict(
        ansible_distribution=u'CentOS',
        ansible_distribution_major_version=u'7',
    ))
    assert result['failed'] == False
    assert result['add_group'] == 'CentOS'
    assert result['parent_groups'] == ['all']

    # test a group_by with a custom group name
    task = dict(
        action=dict(
            module='group_by',
            key='os',
            parents=['parent_group'],
        )
    )

# Generated at 2022-06-11 11:55:04.239247
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=dict(args=dict(key='foo', parents=['bar', 'baz'])))

    assert action_module._task.args['key'] == 'foo'
    assert action_module._task.args['parents'] == ['bar', 'baz']
    assert action_module._task.args['key'] == 'foo'

# Generated at 2022-06-11 11:55:10.578142
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # In this case, we need a valid 'key'.
    args = {'key': 'foo'}
    # task_vars is not required.
    task_vars = {'1': 'a'}
    res = ActionModule(args, task_vars)
    assert res.run() == {'failed': True, 'msg': "the 'key' param is required when using group_by"}

# Generated at 2022-06-11 11:55:15.487101
# Unit test for constructor of class ActionModule
def test_ActionModule():
    values = {'action': {'module': 'actionmodule1'}, '_ansible_no_log': False, '_ansible_verbosity': 0}
    m = ActionModule({}, values, 'test', [])
    assert m.__class__.__name__ == ActionModule.__name__

# Generated at 2022-06-11 11:55:16.175089
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 11:55:26.887053
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY2
    if PY2:
        import __builtin__ as builtins
    else:
        import builtins

    # out = StringIO()
    # sys.stdout = out
    # print("hello")
    # print(type(out))

    am = ActionModule(None, None)
    am._task = {"args": {"key": "group_name", "parents": ["parent_group1", "parent_group2"]}}
    result = am.run(None, None)
    assert result["changed"] == False
    assert result["add_group"] == "group_name"
    assert result["parent_groups"] == ["parent_group1", "parent_group2"]


# Generated at 2022-06-11 11:55:37.868958
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager

    # Create a new Class with no dependencies to Ansible inventory file.
    # Create a Task belonging to this Class
    test_class = ActionModule( {}, {}, [], Play())
    task = Task()
    task._role = test_class
    test_class._tasks = [ task ]

    # Create a Host object - We dont need to read hosts file
    # as we are testing this class in isolation
    test_host = Host(name='localhost')

    # Create Inventory and pass host object to it
    test_inventory = Inventory(host_list=[test_host])

    # Create Variable manager and pass inventory to

# Generated at 2022-06-11 11:55:40.346570
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(None, None, None, None, None)
    assert actionModule

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 11:55:51.111787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostname = 'example_hostname'
    tmp_dir = '/var/tmp/ansible'
    remote_user = 'example_user'
    destination = 'example_destination'
    source = '/source'
    module_name = 'git'
    module_args = 'repo=git://foosball.example.org/path/to/repo.git dest=/srv/foo version=release-1.0'
    forks = 10
    become = False
    become_method = 'sudo'
    become_user = 'root'
    verbosity = 5
    extra_vars = dict(ansible_ssh_user='example_ssh_user')
    play_context = dict()
    host_list = ['host1', 'host2']
    task_uuid = 'uuid'
    loader = None
   

# Generated at 2022-06-11 11:55:58.331714
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 11:56:17.946445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_args = {
        'key': 'some_key',
        'parents': ['other_group', 'parent_group']
    }
    task_vars = { 'variable_that_contains_key': 'some_key' }
    result = ActionModule(dict(), task_vars, module_args).run()

    assert result['changed'] == False
    assert result['add_group'] == 'some_key'
    assert result['parent_groups'] == ['other_group', 'parent_group']


# Generated at 2022-06-11 11:56:20.145847
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six import PY2
    import pytest
    ActionModule()

#Unit Test for run() function of class ActionModule

# Generated at 2022-06-11 11:56:22.210594
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 11:56:25.397592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Test constructor of class ActionModule '''
    action_module = ActionModule(None, None, None, None)
    print(action_module._VALID_ARGS)

# Generated at 2022-06-11 11:56:26.182448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:56:31.008426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit test for method run of class ActionModule. '''
    action_module = ActionModule()
    args = {'key': 'key', 'parents': ['parents']}
    assert action_module.run(None, None, args) == {'add_group': 'key', 'changed': False, 'parent_groups': ['parents']}


# Generated at 2022-06-11 11:56:33.981146
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('key', 'parents'))



# Generated at 2022-06-11 11:56:38.621918
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module._VALID_ARGS == frozenset(('key', 'parents'))
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-11 11:56:41.696476
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m_self = ActionModule()
    assert m_self._VALID_ARGS == frozenset(('key', 'parents'))
    assert m_self.TRANSFERS_FILES == False, 'ActionModule transfer files'

# Generated at 2022-06-11 11:56:46.767986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Dummy class for tests only.
    class DummyTask(object):
        def __init__(self, args):
            self.args = args

    task = DummyTask({'key':'test_key'})

    module = ActionModule(task=task, connection=None,
            play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module
    assert repr(module)

# Generated at 2022-06-11 11:57:10.339202
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (ActionModule)



# Generated at 2022-06-11 11:57:10.929772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:57:13.220368
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(dict(task=dict(args=dict(key='key', parents='parents'))))
    assert action.runner == None
    assert action.transport == None

# Generated at 2022-06-11 11:57:14.589163
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Simple test to verify
    assert group_by_change == 'change'

# Generated at 2022-06-11 11:57:15.812833
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod.run(None, {})

# Generated at 2022-06-11 11:57:18.468354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(action='group_by',
                  args=dict(key='some_key')),
        connection=None,
        new_stdin=None
    )
    print(action)

# Generated at 2022-06-11 11:57:23.946085
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.group_by as mod

    action_mod = mod.ActionModule(task=dict(args=dict(key='test')))
    assert action_mod.run()['changed'] == False
    assert action_mod.run()['add_group'] == 'test'
    assert action_mod.run()['parent_groups'] == ['all']

test_ActionModule_run()

# Generated at 2022-06-11 11:57:33.337558
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {'hostvars': {}}
    host_vars = task_vars['hostvars']['host1'] = {}
    host_vars['foo'] = 'bar'
    host_vars['ninja'] = True
    host_vars['toad'] = False
    host_vars['number'] = 42
    host_vars['ls'] = [1, 2, 3, 4]
    host_vars['dict'] = {'a': 1, 'b': 2, 'c': 3}

    task = {
        'args': {'key': 'foo', 'parents': 'all'}
    }
    action = ActionModule(task, {}, {}, {'foo': 'bar', 'f': 'b'})

# Generated at 2022-06-11 11:57:35.024271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule('constructor')
    print(actionModule)

# Generated at 2022-06-11 11:57:40.782847
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 11:58:51.600525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    group_name = "test_group"
    parent_groups = ["parent1", "parent2"]

    # First test the constructor
    # action_module = ActionModule()
    assert 1 == 1

# Generated at 2022-06-11 11:59:02.090578
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Incomplete stuff. TODO
    import io
    from ansible.plugins.action import ActionBase

    class FakeTask(object):
        def __init__(self):
            self.args = {'key':'key-value', 'parents': 'parent1, parent2'}

    action_base = ActionBase(FakeTask(), '/home/travis/ansible/ansible/bin/ansible', None, None, None, None, None)
    action_module = ActionModule(FakeTask(), '/home/travis/ansible/ansible/bin/ansible', None, None, None, None, None)

    # Check dict comparison, including dict in list
    expected_result = {'changed': False, 'parent_groups': ['parent1', 'parent2'], 'add_group': 'key-value'}

# Generated at 2022-06-11 11:59:10.631601
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(dict(
        module_name='test_ActionModule',
        module_args=dict(
            key='foo bar',
            parents='all',
        ),
    ),  # No ansible_play_batch here
       ansible_play=dict(
           name='test',
           connection='local',
           hosts='all',
           gather_facts='no',
       )
    )
    assert action._task.args['key'] == 'foo bar'
    assert action._task.args['parents'] == 'all'
    assert action._task.name == 'test_ActionModule'
    assert action._play_name == 'test'

# Generated at 2022-06-11 11:59:12.843941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module1 = ActionModule()
    assert module1 is not None

# Unit Test for run() method of class ActionModule

# Generated at 2022-06-11 11:59:23.693723
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Test 'run' method of class ActionModule
    mock_loader = Mock()
    mock_play_context = Mock(PlayContext)
    mock_play_context.check_mode = False
    mock_play_context.network_os = None
    mock_play_context.remote_addr = None
    mock_play_context.port = None
    mock_play_context.remote_user = None
    mock_itqm = Mock(TaskQueueManager)
    print(mock_itqm)
    print(mock_play_context)
    mock_task = Mock(Task)

# Generated at 2022-06-11 11:59:25.543548
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule(None, 'ansible/test.yml')
    assert act != None

# Generated at 2022-06-11 11:59:33.913174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Check if method run of class ActionModule works well

    # Create instance
    obj = ActionModule()

    # Create object tmp as a object of class StringIO
    class StringIO:
        def __init__ (self):
            pass
    tmp = StringIO()

    # Create object TaskVars as a object of class Object
    class Object:
        def __init__ (self):
            pass
    TaskVars = Object()
    TaskVars.update({'key': 'group_name', 'parents': ['all', 'child_group']})

    # Construct object
    obj._task.args = TaskVars

    # Check if method run of class ActionModule works well
    result = obj.run(tmp, task_vars = TaskVars)

# Generated at 2022-06-11 11:59:43.376444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(dict(name='test', action='group_by'), dict(playbook_dir='/home/jhoekx/ansible/playbooks'))
    result = action.run(task_vars=dict(hostvars=dict(host1=dict(environment='dev'))))
    assert result['failed'] == False
    assert result['msg'] == 'All items completed'
    assert result['changed'] == False
    assert result['add_group'] == 'dev'
    assert result['parent_groups'] == ['all']
    assert result['ansible_facts']['groups']['all']['children'] == ['dev']
    assert result['ansible_facts']['groups']['dev']['hosts'] == ['host1']

# Generated at 2022-06-11 11:59:53.097976
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest

    # Declare test modules to import
    modules = {
        'os': 'ansible.module_utils.basic',
        'sys': 'ansible.module_utils.basic',
        'ansible': 'ansible.module_utils.basic',
        'ansible.module_utils.basic': 'ansible.module_utils.basic',
        'ansible.module_utils.urls': 'ansible.module_utils.basic',
        'ansible.plugins.action': 'ansible.module_utils.basic',
    }
    exec_dict = {}

    # Initialize modules
    for module_name in modules:
        exec("from %s import *" % modules[module_name], exec_dict)
        module = sys.modules[module_name] = exec_dict[module_name]

       

# Generated at 2022-06-11 11:59:54.280841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    assert action.run(None, dict())

# Generated at 2022-06-11 12:02:16.967111
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule()
  assert am is not None

# Generated at 2022-06-11 12:02:20.626853
# Unit test for constructor of class ActionModule
def test_ActionModule():
	# Create a ActionModule
	test = ActionModule()
	
	# Test whether function 'run' is callable
	assert( callable(test.run) )
	
	# Test whether function 'run' is a method
	assert( isinstance(test.run, types.MethodType) )
	

# Generated at 2022-06-11 12:02:21.656734
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor
    assert type(ActionModule()) is ActionModule

# Generated at 2022-06-11 12:02:23.708959
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = object()
    task = object()
    conn = object()
    action = ActionModule(task, conn, play_context=object())



# Generated at 2022-06-11 12:02:31.798092
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:02:33.445495
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with parameters
    ActionModule('group_by', {'key': 'value'})


# Generated at 2022-06-11 12:02:40.390222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Test with just group_name in args
  task = {'args': {'key': 'testgroup'}}
  am = ActionModule(task, None)
  res = am.run({}, None)
  # Check that result contains the expected values
  assert(res['changed'] == False)
  assert(res['add_group'] == 'testgroup')
  assert(res['parent_groups'] == ['all'])
  # Test with group_name and parents in args
  task = {'args': {'key': 'testgroup', 'parents': 'parent'}}
  am = ActionModule(task, None)
  res = am.run({}, None)
  # Check that result contains the expected values
  assert(res['changed'] == False)
  assert(res['add_group'] == 'testgroup')