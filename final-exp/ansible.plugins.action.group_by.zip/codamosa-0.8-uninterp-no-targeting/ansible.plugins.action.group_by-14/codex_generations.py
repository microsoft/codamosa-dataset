

# Generated at 2022-06-21 02:16:18.695720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    variable_manager = VariableManager()
    inventory = Inventory(variable_manager, 'ansible/tests/inventory/files/hosts')
    variable_manager.set_inventory(inventory)

    am = ActionModule(dict(key='key1', parents='parent1'),
                      variable_manager=variable_manager,
                      loader=None,
                      templar=None,
                      shared_loader_obj=None)

    result = am.run(None, None)
    assert result.get('changed') == False
    assert result.get('add_group') == 'key1'
    assert result.get('parent_groups') == ['parent1']

# Generated at 2022-06-21 02:16:25.638955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
    t = dict()
    c = dict()
    pc = dict()
    l = dict()
    temp = dict()
    slo = dict()

    am = ActionModule(t, c, pc, l, temp, slo)
    assert isinstance(am, ActionModule)


# Generated at 2022-06-21 02:16:31.296687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(None, dict())
    ans_ret = am.run(None, {'some_var': 'value'})
    assert ans_ret['parent_groups'] == am._task.args.get('parents', ['all'])

# Generated at 2022-06-21 02:16:31.949244
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()

# Generated at 2022-06-21 02:16:38.077555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' test run method of class ActionModule '''

    m = ActionModule(dict(), dict())
    result = m.run(None, {'inventory_hostname': 'foo'})

    assert result['add_group'] == 'foo'
    assert result['parent_groups'] == ['all']

    result = m.run(None, {'inventory_hostname': 'foo'}, key='cache', parents=['all', 'cache'])

    assert result['add_group'] == 'cache'
    assert result['parent_groups'] == ['all', 'cache']

# Generated at 2022-06-21 02:16:40.235926
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    assert ActionModule is not None

# Generated at 2022-06-21 02:16:48.062004
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests.mock import Mock

    # Unit test: no key in task.args
    mock_task = Mock()
    mock_task.args = {}
    action_module = ActionModule(task=mock_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(task_vars={})
    assert not result['changed']
    assert result['failed']
    assert result['msg'].startswith('the')
    assert result['msg'].endswith('when using group_by')

    # Unit test: key exists in task.args
    mock_task = Mock()

# Generated at 2022-06-21 02:16:50.678352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Unit test for constructor of class ActionModule
    # Test with valid params
    a = ActionModule()
    assert a is not None
    assert a.name is not None
    # Test with no params
    b = ActionModule()
    assert b is not None
    assert b.name is not None

# Generated at 2022-06-21 02:16:52.693069
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule('test',{'key':'test'}, None, None, None, None)
    assert action._task.args['key'] == 'test'


# Generated at 2022-06-21 02:16:55.054021
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(dict(foo='bar'))
    assert isinstance(action, ActionModule)

# Generated at 2022-06-21 02:17:00.389459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    print(a)

# Generated at 2022-06-21 02:17:02.392295
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('TEST: test_ActionModule')


# Generated at 2022-06-21 02:17:08.125577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Test method run of class ActionModule '''
    # Initialize a mock module
    module = ActionModule(ActionBase, dict(_task = dict(args = dict(key = 'automated'))))
    
    # Call the method run
    result = module.run()

    # Asserts for your method run
    assert result['changed']  == False
    assert result['parent_groups']  == ['all']

# Generated at 2022-06-21 02:17:18.349386
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(
            action=dict(
                module_name='group_by',
                args=dict(
                    key='[1, 2, 3]',
                    parents=['foo bar', 'bar', 'baz'],
                    ),
                ),
            ),
        )
    result = action.run(task_vars=dict())
    assert result['add_group'] == '[1, 2, 3]'.replace(' ', '-')
    assert result['parent_groups'] == ['foo-bar', 'bar', 'baz']

# Generated at 2022-06-21 02:17:22.567240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    m._task = object()
    m._task.args = {'key': 'value'}
    m.run()


# Generated at 2022-06-21 02:17:31.642238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.group_by import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.six import string_types
    from ansible.compat.tests import unittest

    # ActionModule class requires AnsibleModule class
    # which requires three arguments

# Generated at 2022-06-21 02:17:37.345082
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock objects
    task_vars = {}
    # instantiate mock objects
    module_args = {'key': 'webservers'}
    action_mod = ActionModule(task_vars, module_args)

    # execute method under test
    result = action_mod.run(task_vars, task_vars)

    # assert results
    expected = {'add_group': 'webservers', 'parent_groups': ['all'], 'changed': False}
    assert result == expected

# Generated at 2022-06-21 02:17:46.829399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    tqm = TaskQueueManager(loader=loader)
    task = Task()
    role = Role()
    block = Block()
    host = '127.0.0.1'

# Generated at 2022-06-21 02:17:58.777059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
        #Arrange
            #self._task.args returns a dict() since that is what gets passed through ansible to the plugin.
        task_args = {
            'key': 'testGroup',
            'parents': ['all', 'testParentGroup']
        }

        task_vars = dict()

        test_group = dict(
            all = dict(
                hosts = dict()
            ),
            testParentGroup = dict(
                hosts = dict()
            )
        )

        test_hosts = dict()

        am = ActionModule(task=task_args, variable_manager=test_group, loader=test_hosts, play_context=None, shared_loader_obj=None)
        #Act
        result = am.run(task_vars=task_vars)
        #Assert

# Generated at 2022-06-21 02:18:03.879394
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # arrange
    test_args = {'key': 'test_group_name', 'parents': ['all']}
    action_module = ActionModule(ActionBase(), test_args)

    # assert
    assert action_module is not None


# Generated at 2022-06-21 02:18:20.776259
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing ActionModule")
    print("====================")
    action_module = ActionModule(name='test_action_module',
                                 task=dict(vars=dict()),
                                 shared_loader_obj=list())
    action_module.task = dict(action=dict(args=dict(key='key')))
    print("Should run without a problem")
    print(action_module.run())
    print()

    print("Should fail without any parameters")
    action_module.task = dict(action=dict(args=dict()))
    print(action_module.run())
    print()

    print("Should have the right parent groups")
    action_module.task = dict(action=dict(args=dict(key='key',
                                                    parents=['group1', 'group2'])))

# Generated at 2022-06-21 02:18:24.942708
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod.TRANSFERS_FILES == False
    assert mod._VALID_ARGS == frozenset(('key', 'parents'))

# Generated at 2022-06-21 02:18:33.749479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.group import Group
    from ansible.inventory.init import BaseInventoryPlugin
    from ansible.plugins.loader import action_loader

    class TestInventoryPlugin(BaseInventoryPlugin):
        def verify_file(self, path):
            return path

# Generated at 2022-06-21 02:18:38.069208
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module_result = action_module.run(tmp=None, task_vars=None)
    # Checks result of action_module to check if the expected key is present
    assert action_module_result['add_group'] == 'key'
    # Checks if the returned result 'add_groups' has a value of expected length
    assert len(action_module_result['parent_groups']) == 1

# Generated at 2022-06-21 02:18:49.279844
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Check the constructor of ActionModule class
    """
    action = ActionModule(
        task={
            'args':{
                'key': 'foo',
                'parents': ['bar'],
            }
        },
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert isinstance(action, ActionBase), action
    assert isinstance(action._task, dict), action._task
    assert action._task.get('args') == {
        'key': 'foo',
        'parents': ['bar'],
    }
    assert action.TRANSFERS_FILES is False, action.TRANSFERS_FILES
    assert isinstance(action._VALID_ARGS, frozenset), action._VAL

# Generated at 2022-06-21 02:18:51.846119
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, dict())
    assert type(action) == ActionModule

# Generated at 2022-06-21 02:18:59.711230
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_group_name = "mock_group_name"
    mock_parent_groups = "mock_parent_group1"
    mock_args = {'key': mock_group_name, 'parents': mock_parent_groups}
    mock_task = type('', (object,), {'args': mock_args})()
    action_module = ActionModule(mock_task, None)

    assert action_module
    assert action_module.run() == {
        'changed': False,
        'add_group': mock_group_name.replace(' ', '-'),
        'parent_groups': [mock_parent_groups.replace(' ', '-')]
    }

# Generated at 2022-06-21 02:19:00.685843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule('test', 'a', 'b', 'c')
    assert action is not None

# Generated at 2022-06-21 02:19:08.417042
# Unit test for constructor of class ActionModule
def test_ActionModule():
    source = dict(
        key='test-key',
        parents=['test-parent']
    )
    task = dict(
        action=dict(
            module='group_by',
            args=source
        )
    )
    am = ActionModule(task, dict())
    assert am._task == task
    assert am._task.args == source
    assert am.args == source
    assert am.run() == dict(
        changed=False,
        add_group='test-key',
        parent_groups=['test-parent']
    )

# Generated at 2022-06-21 02:19:12.351544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(None, None, None, None)
    print(actionModule)


if __name__ == '__main__':

    test_ActionModule()

# Generated at 2022-06-21 02:19:27.319549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    c = ansible.plugins.action.ActionModule('test', dict(key='test'), False, 'all', 'group_by', dict())
    assert c != None
    assert c.name == 'test'

# Generated at 2022-06-21 02:19:29.182009
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)

# Generated at 2022-06-21 02:19:38.628807
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # arguments to test with
    arguments = {
        'key' : 'Test',
        'parents': ['parent1']
    }

    # create test object
    am = ActionModule()

    # run test of method
    result = am.run(None, None, arguments)

    # Check we get a result
    assert result

    # check the run results
    assert not result['failed']
    assert result['changed']
    assert result['add_group'] == 'Test'
    assert result['parent_groups'] == ['parent1']


# Generated at 2022-06-21 02:19:43.511817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class FakeModule:
        def __init__(self):
            self.args = {'key': 'arg1', 'parents': 'arg2'}

    am = ActionModule()
    am._task = FakeModule()
    am.run()

# Generated at 2022-06-21 02:19:47.083893
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(dict(
        action=dict(
            key='val'
        )
    ), None, None, None)
    assert obj._task.args['key'] == 'val'

# Generated at 2022-06-21 02:19:58.461553
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = "localhost"
    task_vars = { 
        'ansible_' + host: { 
            'hostvars': { 
                host: { 'ansible_host': host, 'ansible_port': 22, 'ansible_user': 'root' }
            }
        }    
    }
    action_mod = ActionModule(
        { 'name': 'test',
          'args': { 'key': 'test-key' },
          'delegate_to': host
        },
        task_vars=task_vars
    )
    action_mod._add_host_to_composed_group = lambda g, h: None
    action_mod.async_val = lambda: (0, None)
    result = action_mod.run(None, task_vars=task_vars)

# Generated at 2022-06-21 02:20:10.544008
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action = ActionModule()
    action._task = mock.Mock()
    action._task.args = {'key': 'value'}
    result = action.run()
    assert result['changed'] == False
    assert result['add_group'] == 'value'
    assert result['parent_groups'] == ['all']

    action = ActionModule()
    action._task = mock.Mock()
    action._task.args = {'key': 'group name'}
    result = action.run()
    assert result['changed'] == False
    assert result['add_group'] == 'group-name'
    assert result['parent_groups'] == ['all']

    action = ActionModule()
    action._task = mock.Mock()

# Generated at 2022-06-21 02:20:19.078506
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # GIVEN some variables and a task with group_by
    connection = {'name': 'local'}
    hostvars = {'hostvars': {}}
    play_context = {'name': 'test', 'private_key_file': 'file.key'}
    new_stdin = '{\n"args": {"key": "key-123", "parents": ["parent1", "parent2"]}\n}'

# Generated at 2022-06-21 02:20:19.491617
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:20:26.224493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def fail_run(mocker, result, tmp=None, task_vars=None):
        mocker.patch('ansible.plugins.action.ActionBase.run', return_value=result)

    def run_module(mocker, tmp=None, task_vars=None):
        mocker.patch('ansible.plugins.action.ActionBase.run', return_value={'key':'value'})

    # Test 1 - 'key' is not specified in args
    def test_1(mocker):
        result = {'failed': True, 'msg': 'the \'key\' param is required when using group_by'}
        mocker.patch('ansible.plugins.action.ActionBase._task', args={'args':{}})
        fail_run(mocker, result)

        action_module = ActionModule()
       

# Generated at 2022-06-21 02:20:58.582463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule('task', 'hostname')
    action.module_name = 'setup'

    result = action.run(task_vars={})
    assert result['failed']
    assert result['msg'] == "the 'key' param is required when using group_by"

    result = action.run(task_vars={}, tmp='tmp', key='')
    assert result['failed']
    assert result['msg'] == "the 'key' param is required when using group_by"

    result = action.run(task_vars={}, tmp='tmp', key='foo')
    assert not result['failed']
    assert result['changed'] == False
    assert result['add_group'] == 'foo'
    assert result['parent_groups'] == ['all']


# Generated at 2022-06-21 02:21:07.844244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.action.group_by import ActionModule
    import mock

    # Build a mock inventory manager
    inventory_manager = mock.Mock(spec_set=InventoryManager)
    inventory_manager.get_groups.return_value = [Group('all')]

    # Build a mock Ansible options
    options = mock.Mock(spec_set=Options)

    # Build a mock inventory
    inventory = mock.Mock(spec_set=Inventory)
    inventory.get_hosts.return_value = [Host('localhost')]
    inventory.get_

# Generated at 2022-06-21 02:21:17.625088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.inventory.host import Host

    host = Host(name="foobar.example.org")
    host.vars = dict(group1="foo", group2=["bar", "qux"])

    inven = dict()
    inven['all'] = [host]

    t = dict(
        hosts = host,
        inven = inven,
    )

    a = dict(
        key = "group1",
        parents = "parent_group",
    )

    am = ActionModule(task=t, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    res = am.run(a)

    assert 'changed' in res
    assert res['changed'] == False

    assert 'add_group' in res

# Generated at 2022-06-21 02:21:20.181917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert obj._VALID_ARGS == frozenset(('key', 'parents'))

# Generated at 2022-06-21 02:21:28.142785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import mock
    import sys
    import inspect
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.six import string_types
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.module_utils._text import to_bytes
    from ansible.utils.vars import combine_vars

    inventory_file = 'inventory_ansible_group_by'

# Generated at 2022-06-21 02:21:38.064414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    host_vars = {'hostvars': {}}
    task_vars = {'hostvars': {'hostvars': host_vars}}

    actionmod = ActionModule(dict(DEFAULT_HOST_TOKEN='host', DEFAULT_HOST_TOKEN_VALUE='host', DEFAULT_HOST_TOKEN_VALUE='host'), 'task', 'mytask', 'mytask', dict(key='mykey', parents='myparents'), 'myres')
    # Exercise
    result = actionmod.run(task_vars=task_vars)
    # Verify
    assert(result['changed'] == False)
    assert(result['add_group'] == 'mykey')
    assert(result['parent_groups'] == ['myparents'])

# Generated at 2022-06-21 02:21:45.724127
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = type('MockTask', (), {'args': {'key': 'some-key', 'parents': ['some-parent-group']}})()
    mock_self = type('MockSelf', (), {
        'run': ActionModule.run,
        '_task': mock_task
    })()
    result = mock_self.run()
    assert result['changed'] == False
    assert result['add_group'] == 'some-key'
    assert result['parent_groups'] == ['some-parent-group']


# Generated at 2022-06-21 02:21:47.676905
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    print(module)


# Generated at 2022-06-21 02:21:57.875873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import Playbook
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext(variable_manager=variable_manager)
    play_context.network_os = 'ios'

# Generated at 2022-06-21 02:21:59.805216
# Unit test for constructor of class ActionModule
def test_ActionModule():
	print("Test ActionModule constructor:")
	instance = ActionModule()
	print(instance)
	print("")

if __name__ == '__main__':
	test_ActionModule()

# Generated at 2022-06-21 02:23:06.293721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    mod._task = dict(
        args = dict(key = 'foo')
    )
    assert mod.run() == dict(changed = False,
                             add_group = 'foo',
                             parent_groups = ['all'])

# Generated at 2022-06-21 02:23:13.172125
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    key = 'key'
    result = {}
    equal = 'equal'
    tmp = 'tmp'
    group_name = 'group_name'
    parent_groups = 'parent_groups'
    all = 'all'
    changed = 'changed'
    add_group = 'add_group'
    parent_groups = 'parent_groups'
    name = 'name'
    replace = 'replace'
    parents = 'parents'
    task_vars = 'task_vars'
    module_args = {key: 'ansible_os_family',
                   parents: ['all', 'system']}
    args = dict(module_args=module_args)
    task = dict(args=args)
    action_module = ActionModule()
    action_module._task = task
    action_module.run()
    assert action

# Generated at 2022-06-21 02:23:17.933756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert ActionModule._VALID_ARGS == frozenset(('key', 'parents'))
    assert not ActionModule.TRANSFERS_FILES

# Generated at 2022-06-21 02:23:19.306591
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()


# Generated at 2022-06-21 02:23:23.360258
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_ActionModule = ActionModule(
        task=dict(action=dict(module_name='debug', args=dict(msg='foo'))),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None)

    assert test_ActionModule._task['action']['args']['msg'] == 'foo'
    assert test_ActionModule._task['action']['module_name'] == 'debug'


# Generated at 2022-06-21 02:23:34.318419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Unit test for class ActionModule '''
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    host = Host(name="localhost")
    group = Host(name="all")
    group.add_child(host)
    inventory =  VariableManager(loader=loader)
    inventory.add_group(group)

    task = dict(action=dict(module='group_by', key='test'))
    task_vars = None
    am = ActionModule(task, inventory, loader=loader, connection=None)
    assert am.run(task_vars)  ==  {'add_group': 'test', 'parent_groups': ['all'], 'changed': False}

# Generated at 2022-06-21 02:23:40.363316
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule('foo', dict(x=1), task_vars=dict(console=dict(port=99)))
    assert str(mod.transfer) == 'ANSIBLE_TRANSFER_METHOD'
    assert str(mod.remote_tmp) == 'ANSIBLE_REMOTE_TEMP'

# Generated at 2022-06-21 02:23:52.702819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    info = { 'ANSIBLE_MODULE_ARGS' : {
        'key' : 'test',
        'group_vars' : {
            'test1' : 'test2'
        },
        'host_vars' : {
            'test1' : 'test',
            'test2' : 'test'
        }
    } }
    am = ActionModule(None, info, False, None)
    assert isinstance(am, ActionModule)

    assert am._task.args.get('group_vars')[0] == 'test1'
    assert am._task.args.get('group_vars')[1] == 'test2'
    assert am._task.args.get('host_vars')[0] == 'test1'

# Generated at 2022-06-21 02:23:55.039589
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:23:58.546995
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test empty constructor    
    aModule = ActionModule(None, None, None, None)
    assert aModule != None

