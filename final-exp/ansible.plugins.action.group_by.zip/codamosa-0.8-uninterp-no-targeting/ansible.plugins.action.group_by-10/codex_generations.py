

# Generated at 2022-06-21 02:16:28.166893
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Try a simple instantiation
    try:
        am = ActionModule(
            dict(a=1,b=2),
            dict(action='group_by',
                 task_vars=dict(ansible_facts=dict(a='aa', b='bb')),
                 args=dict(
                     key='mygroup',
                     parents=['all']
                 ))
        )
    # Fail on unexpected exception
    except:
        assert False

    # Fail if we didn't get an ActionModule instance
    assert isinstance(am, ActionModule)

    # Fail if we didn't get the group_by object as expected
    assert am._task.args.get('key') == 'mygroup'
    assert am._task.args.get('parents') == ['all']
    assert am._task.args.get('a') is None

# Generated at 2022-06-21 02:16:39.759355
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    class hosts_run(unittest.TestCase):
        def test_base_case(self):
            import ansible.parsing.dataloader
            import ansible.vars
            import ansible.inventory
            import ansible.playbook
            import ansible.plugins.loader
            import ansible.plugins.action

            host_vars = {}
            group_vars = {}
            inventory = ansible.inventory.Inventory()
            loader = ansible.parsing.dataloader.DataLoader()
            variable_manager = ansible.vars.VariableManager()
            variable_manager.set_inventory(inventory)
            loader.set_basedir('.')

# Generated at 2022-06-21 02:16:50.288770
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task = dict(
            args = dict(
                key =  'key',
                parents = ['group-one', 'group-two']
            )
        )
    )
    result = module.run()
    assert result.get('changed') is False
    assert result.get('add_group') == 'key'
    assert result.get('parent_groups') == ['group-one', 'group-two']

    module = ActionModule(
        task = dict(
            args = dict(
                key =  'key',
                parents = 'group'
            )
        )
    )
    result = module.run()
    assert result.get('changed') is False
    assert result.get('add_group') == 'key'
    assert result.get('parent_groups') == ['group']

   

# Generated at 2022-06-21 02:16:53.376987
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.TRANSFERS_FILES == False
    assert ActionModule._VALID_ARGS == frozenset({'key', 'parents'})

# Generated at 2022-06-21 02:17:01.832838
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    assert mod.run(task_vars={'all': {
        'hosts': ['example1', 'example2'],
        'children': [],
        'vars': {},
    }}) == {
        'parent_groups': ['all'],
        'add_group': 'group-name',
        'changed': False,
    }
    assert mod.run(task_vars={'all': {
        'hosts': ['example1', 'example2'],
        'children': [],
        'vars': {},
    }}, args={'key': 'group name', 'parents': 'all'}) == {
        'parent_groups': ['all'],
        'add_group': 'group-name',
        'changed': False,
    }

# Generated at 2022-06-21 02:17:05.945950
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(dict(), dict())
    assert am._VALID_ARGS == frozenset(['key', 'parents'])
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-21 02:17:06.887699
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    return a

# Generated at 2022-06-21 02:17:19.537579
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook import play
    from ansible.playbook.play_context import PlayContext

    my_play = Play().load({
        'name': "myplay",
        'hosts': ["myhost"],
        'gather_facts': True,
        'any_errors_fatal': False,
        'tasks': [],
        'vars': {},
        'post_tasks': [],
        'handlers': [],
    }, variable_manager=play.VariableManager(), loader=play.loader)


# Generated at 2022-06-21 02:17:30.721950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import nose
    from ansible.plugins.action import ActionModule

    action = ActionModule(dict(name="test"), "playbook", "", "", "", dict())
    result = action.run(dict(), dict())
    nose.tools.assert_equal(result.get("failed"), None)

    # No key, test failed.
    action = ActionModule(dict(name="test"), "playbook", "", "", "", dict(key="hosts"))
    result = action.run(dict(), dict())
    nose.tools.assert_equal(result.get("failed"), None)
    nose.tools.assert_equal(result.get("add_group"), None)

    # Pass the required 'key' argument
    action = ActionModule(dict(name="test"), "playbook", "", "", "", dict(key="hosts"))

# Generated at 2022-06-21 02:17:40.347031
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We need to make an instance with a valid task, host and other parameters
    # So we make a fake task object with required fields defined.
    class FakeTask(object):
        def __init__(self):
            self.args = dict()
            # self.environment = None
            # self.basedir = None
            # self.module_vars = None
            # self.module_name = None
            # self.no_log = False
            # self.async_val = None
            # self.delegate_to = None
            # self.delegate_facts = None
            # self.run_once = None
            # self.notify = None
            # self.become = None
            # self.become_method = None
            # self.become_user = None
            # self.become_flags = None

# Generated at 2022-06-21 02:17:48.545906
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  print('')
  a=ActionModule()
  a.task_vars = dict()
  a._task = dict()
  a._task.args = dict()
  # a._task.args['key'] = "a"
  # a._task.args['parents'] = "b"
  result = a.run()
  print(result)
  assert result['msg'] == "the 'key' param is required when using group_by"


# Generated at 2022-06-21 02:17:53.334185
# Unit test for constructor of class ActionModule
def test_ActionModule():

     # Construct the test object
     action = ActionModule()

     # Test the correct return of the member variable
     assert(action._VALID_ARGS == frozenset(['key', 'parents']))

# Generated at 2022-06-21 02:17:59.442743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule(None, None, None, None, None)

    # Assert we have an object of type ActionModule
    assert isinstance(actionmodule, ActionModule)
    # Assert that we have a valid dict
    assert isinstance(actionmodule._VALID_ARGS, dict)
    # Assert we have a non-zero dict
    assert len(actionmodule._VALID_ARGS) > 0
    # Assert that we've frozen our dict
    assert not isinstance(actionmodule._VALID_ARGS, dict)


# Generated at 2022-06-21 02:18:10.178291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(action=dict(module='group_by',
                            args=dict(key='key1', parents=['all', 'group1'])))

    task_vars = dict()

    action_plugin = ActionModule(task, task_vars)
    result = action_plugin.run(None, task_vars)
    assert result['changed'] is False
    assert result['add_group'] == 'key1'
    assert 'parent_groups' in result
    assert result['parent_groups'] == ['all', 'group1']

    task = dict(action=dict(module='group_by',
                            args=dict(key='key1', parents=['all', 'group1'])))

    task_vars = dict()

    action_plugin = ActionModule(task, task_vars)
    result = action_plugin

# Generated at 2022-06-21 02:18:11.216835
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = AnsibleModule({})
    action = ActionModule(module, {})
    print(action.run())

# Generated at 2022-06-21 02:18:11.602420
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 02:18:21.436757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # run for ActionModule test
    # you can add specific tests for ActionModule
    # that will be run only for testing ActionModule
    # (and not for other classes from this plugin)

    from ansible.plugins.loader import connection_loader

    mock_task = MockTask()
    mock_task.action = 'group_by'
    mock_task.args = dict(key='asdf')
    mock_task.args.pop('name')
    mock_task.args.pop('_uses_shell')

    mock_self = Mock()
    mock_self.connection = connection_loader.get('local',  mock_task, play_context=Mock())
    mock_self._task = mock_task

    action_module = ActionModule.load_action_plugin(mock_self._task)
    action_module.connection = mock_

# Generated at 2022-06-21 02:18:32.061909
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test correct run
    test_module = ActionModule()

    test_module._task = MockTask(dict(args=dict(key='foo', parents=['bar'])))
    assert test_module.run() == {'changed': False, 'add_group': 'foo', 'msg': '', 'parent_groups': ['bar'], 'failed': False}

    test_module._task = MockTask(dict(args=dict(key='foo')))
    assert test_module.run() == {'changed': False, 'add_group': 'foo', 'msg': '', 'parent_groups': ['all'], 'failed': False}

    # Test error conditions
    def run_with_wrong_args(args):
        test_module = ActionModule()
        test_module._task = MockTask(dict(args=args))
        return test_

# Generated at 2022-06-21 02:18:38.069395
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('START test__ActionModule__run')

    def _get_action(args, variables=None):
        from ansible.playbook.task import Task

        action = ActionModule('module', args, targs=dict(name=None), task_vars=variables)
        task = Task()
        task._role = None
        action._task = task
        action._templar = None

        return action

    def _to_list(string):
        return string.split(',') if string else []

    action = _get_action(dict(
        key='{{ hostvars[inventory_hostname]["ansible_distribution"] }}',
        parents='{{ hostvars[inventory_hostname]["ansible_distribution_release"] }}'))
    result = action.run()
    assert result['add_group']

# Generated at 2022-06-21 02:18:49.279793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # No arguments passed in
    assert ActionModule.run(ActionModule(), task_vars={}) == { 'changed': False, 'parent_groups': [ 'all' ], 'add_group': 'all' }

    # Test with key and with parents
    assert ActionModule.run(ActionModule(), task_vars={ 'key': 'test' }) == { 'changed': False, 'parent_groups': [ 'all' ], 'add_group': 'test' }
    assert ActionModule.run(ActionModule(), task_vars={ 'key': 'test', 'parents': 'all' }) == { 'changed': False, 'parent_groups': [ 'all' ], 'add_group': 'test' }

# Generated at 2022-06-21 02:18:58.200819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(load_config_file=False, config=dict(), play_context=dict(), loader=dict(), variable_manager=dict())
    module.set_options(module_args=dict(key=True, parents=True))
    assert module is not None


# Generated at 2022-06-21 02:19:09.433206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    hostvars = {'key1': 'value1', 'key2': 2, 'key3': [3, 4, 5]}
    taskvars = {'hostvars': {'host1': hostvars, 'host2': {}}}
    result = {'failed': False, 'add_group': 'group-name', 'parent_groups': ['all', 'parent-group']}

    # default args, group_name and parents set
    task = {}
    task['args'] = {'key': AnsibleUnicode('group-name'), 'parents': AnsibleSequence([AnsibleUnicode('all'), AnsibleUnicode('parent-group')])}


# Generated at 2022-06-21 02:19:09.840019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:19:19.721711
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible import inventory
    import io
    import sys
    import ansible.constants as C

    class mygroup(inventory.Group):
        def __init__(self, hostname):
            self.hostname = hostname
            self.name = hostname

        def get_variable(self, var):
            return None

    class myhost(inventory.Host):
        def __init__(self, hostname):
            self.vars = dict()
            self.name = hostname

        def get_variable(self, var):
            return None


# Generated at 2022-06-21 02:19:27.813900
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    args = {
        'key': 'test_key',
        'parents': 'test_parents'
    }
    import ansible.plugins.action.group_by as group_by
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    import ansible.constants as C
    import ansible.inventory.manager
    task = Task()
    task._role = None
    task._block = None
    task._loader = None
    task._dependent_role = None
    task._parent_role = None
    task._unsatisfied_dependencies = None
    task._loop = 'test_loop'

# Generated at 2022-06-21 02:19:30.391273
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert ActionModule("ansible/test/test_action.py")

# Generated at 2022-06-21 02:19:31.245484
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-21 02:19:35.077117
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args_dict = {'key': None, 'parents': None}
    ActionModule(succeed=True, fail=True, ansible_args=args_dict)

# Generated at 2022-06-21 02:19:43.225490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Create an instance of class ActionModule
    obj = ActionModule(
            {
                'args':{
                    'key':'webserver',
                    'parents':'all'
                }
            },
            'group-by-test',
            'group-by-test')
            
    assert isinstance(obj, object)
    assert isinstance(obj._task, object)
    assert obj._task.args.get('key') == 'webserver'
    assert obj._task.args.get('parents') == 'all'
    assert obj._task.action == 'group-by-test'
    assert obj._task.name == 'group-by-test'

# Generated at 2022-06-21 02:19:53.444818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up objects
    mock_task_vars = {}
    mock_tmp = None
    action = ActionModule(mock_tmp, mock_task_vars)

    # Set up expected result
    expected_result = {'changed': False,
                       'add_group': 'group-name',
                       'parent_groups': ['all'],
                       'invocation': {'module_args': {'key': 'group name', 'parents': 'all'}},
                       '_ansible_verbose_always': False}

    # Call method run
    result = action.run(mock_tmp, mock_task_vars)

    # Test result
    assert expected_result == result

# Generated at 2022-06-21 02:20:05.958539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(ActionModule) == type

# Generated at 2022-06-21 02:20:08.322491
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.group_by
    assert ansible.plugins.action.group_by.ActionModule is not None

# Generated at 2022-06-21 02:20:13.617181
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(DictObj(), DictObj(), load_options=False, variable_manager=VariableManager())
    assert 'all' == action_module.run(tmp=None, task_vars=DictObj())['parent_groups'][0]

# Generated at 2022-06-21 02:20:18.420348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = dict()
    tmp = None
    task_vars = dict()
    action_module = ActionModule()
    
    # TODO: check result and tmp
    #result, tmp = action_module.run(tmp, task_vars)

    # TODO: check result and tmp
    #action_module.run(tmp, task_vars)

    # currently not possible to test arguments
    #transfers_files = action_module.TRANSFERS_FILES
    #valid_args = action_module._VALID_ARGS

# Generated at 2022-06-21 02:20:27.285425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inmemory import InventoryMemory

    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib

    from ansible.plugins.strategy import StrategyBase
    from ansible.plugins.action import ActionBase
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager


# Generated at 2022-06-21 02:20:37.051381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.group_by
    import ansible.plugins.loader
    import ansible.inventory
    import ansible.constants

    host = ansible.plugins.loader.Host(name='test_host')
    host.set_variable('foo', 'bar')
    host.set_variable('baz', 'boo')
    host.set_variable('test_host', 'bar')
    host.set_variable('group_names', ['foo', 'baz'])

    variable_manager = ansible.plugins.loader.VariableManager()
    variable_manager.set_inventory(ansible.inventory.Inventory(host_list=[host]))
    variable_manager.extra_vars = dict()


# Generated at 2022-06-21 02:20:47.642537
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    class TestActionModule(ActionModule):
        pass

    setup_loader()


# Generated at 2022-06-21 02:20:53.455569
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_dict = {'key': 'test_key', 'parents': 'test_parents'}
    _task = DummyTask(my_dict)
    my_action = ActionModule(_task)

    assert(my_action.run())

# Generated at 2022-06-21 02:21:05.150142
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test1 = {'hosts': ['host1', 'host2'], 'vars': {'foo': 'bar'}, 'name': 'testgroup'}
    group1 = ActionModule(test1, 'playbooks/test.yml', 'test1')
    assert group1._task.args == {'key': 'testgroup', 'parents': ['all']}
    
    test2 = {'hosts': ['host1', 'host2'], 'vars': {'foo': 'bar'}, 'name': 'testgroup', 'parents': 'common'}
    group2 = ActionModule(test2, 'playbooks/test.yml', 'test2')
    assert group2._task.args == {'key': 'testgroup', 'parents': ['common']}


# Generated at 2022-06-21 02:21:16.568405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class TestModule(object):
        def __init__(self, *args, **kwargs):
            self.args = kwargs
        def get_bin_path(self, *args, **kwargs):
            return 'test.sh'

    # Create TaskQueueManager
    loader = DataLoader()
    variable_manager = TaskQueueManager._variable_manager_class()
    inventory = InventoryManager(loader=loader, sources=None)

# Generated at 2022-06-21 02:21:40.350473
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule({})
    assert module is not None

# Generated at 2022-06-21 02:21:41.775453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True
    assert ActionModule

# Generated at 2022-06-21 02:21:42.634804
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:21:55.320919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test 1
    action = ActionModule(dict(key = 'key_test'))
    result = action.run()
    assert result == dict(changed = False, add_group = 'key_test', parent_groups = ['all']), "test 1 failed"

    # Test 2
    action = ActionModule(dict(key = 'key_test2'))
    result = action.run(dict(), dict())
    assert result == dict(changed = False, add_group = 'key_test2', parent_groups = ['all']), "test 2 failed"

    # Test 3
    action = ActionModule(dict(key = 'key test 3'))
    result = action.run(dict(), dict())

# Generated at 2022-06-21 02:21:55.933065
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:22:06.037553
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.group_by import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()

# Generated at 2022-06-21 02:22:14.189728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ActionModule():
        def __init__(self, task_vars=None):
            if task_vars is None:
                task_vars = dict()
            self._task = dict()
            self._task['args'] = dict()
            self._task['args']['key'] = 'systemd'
            self._task['args']['parents'] = ['all', 'linux']
            self.tmp = None
            self.task_vars = task_vars

    module = ActionModule()
    result = module.run()
    assert result['changed'] == False
    assert result['add_group'] == 'systemd'
    assert result['parent_groups'] == ['all', 'linux']


# Generated at 2022-06-21 02:22:22.727946
# Unit test for constructor of class ActionModule
def test_ActionModule():
  module = ActionModule('stuff', 'stuff1', 'stuff2')
  assert(module.run('foo', 'bar') == {'parent_groups': ['all'], 'failed': False, 'changed': False, 'msg': '', 'add_group': 'stuff'})
  module = ActionModule({'key': 'stuff', 'parents': ['stuff1', 'stuff2']}, 'stuff1', 'stuff2')
  assert(module.run('foo', 'bar') == {'parent_groups': ['stuff1', 'stuff2'], 'failed': False, 'changed': False, 'msg': '', 'add_group': 'stuff'})

# Generated at 2022-06-21 02:22:33.286762
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants as C
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    data_loader = DataLoader()

    inventory = InventoryManager(data_loader)
    variable_manager = VariableManager(loader=data_loader)

    play_source = dict(
        name="group_by",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='group_by', key='group_name')),
        ]
    )


# Generated at 2022-06-21 02:22:44.176991
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils._text import to_bytes

    class CallbackModule:
        def v2_runner_on_ok(self, result, **kwargs):
            print('ok: {0}'.format(result._host.name))


# Generated at 2022-06-21 02:23:40.603760
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate object with default arguments
    action_module = ActionModule(task={"args": {}})
    assert action_module._task.args == {}
    assert action_module.transfers_files is False
    assert action_module.valid_args == frozenset(('key', 'parents'))
    assert action_module.action_loader_name == 'standard'

# test function of class ActionModule

# Generated at 2022-06-21 02:23:48.584764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(None, dict())
    action._task.action = 'group_by'
    action._task.args = dict(key='{{ inventory_hostname|upper }}')
    action._shared_loader_obj = object()
    tmp = None
    task_vars = dict()
    result = action.run(tmp, task_vars)
    assert result['changed'] is False


# Generated at 2022-06-21 02:23:56.656990
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Imports
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.six import string_types

    #Test Object - Static Variables
    #_VALID_ARGS = frozenset(('key', 'parents'))

    #Test Object - Instance Variables
    am_key = "doof"
    am_parents = ['bah']

    #Test Object - Instance Variables - AnsibleModule Parameters
    am_ansible_modul_params = dict(
        key=am_key,
        parents=am_parents
    )

    #Test Object - Instance Variables - Task Arguments
    am_task_args = am_ansible_modul_params

    #Test Object - Instance Variables - Task
    am_task = dict(args=am_task_args)

    #

# Generated at 2022-06-21 02:24:02.470302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    config = { 'ANSIBLE_STDOUT_CALLBACK': 'dummy' }
    m = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert m.run(tmp=None, task_vars={'vars':{'ansible_hostname': 'host1', 'group_names': []}})

# Generated at 2022-06-21 02:24:06.116713
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict()
    task['args'] = dict()
    action_module = ActionModule(None, task, None, None)
    assert(action_module is not None)

# Generated at 2022-06-21 02:24:08.522896
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict()) is not None

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:24:11.113317
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    action = ActionModule()
    assert action is not None
    assert isinstance(action, ActionModule)

# Generated at 2022-06-21 02:24:22.285428
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_args = {'key':'blue', 'parents':'all'}
    my_action = ActionModule(None, my_args, False, None)
    result = my_action.run(None, None)
    assert result['changed'] == False
    assert result['add_group'] == 'blue'
    assert result['parent_groups'] == ['all']
    my_args = {'key':'green', 'parents':'blue'}
    my_action = ActionModule(None, my_args, False, None)
    result = my_action.run(None, None)
    assert result['changed'] == False
    assert result['add_group'] == 'green'
    assert result['parent_groups'] == ['blue']

# Generated at 2022-06-21 02:24:26.451325
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module._VALID_ARGS == frozenset(('key', 'parents'))
    assert module.TRANSFERS_FILES == False

# Generated at 2022-06-21 02:24:31.787453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task={'action': 'group_by',
                                'args': {'key': 'value', 'parents': ['one', 'two']}},
                          connection={},
                          play_context={})
    result = module.run(task_vars={})

    assert result['failed'] == False
    assert result['changed'] == False
    assert result['add_group'] == 'value'
    assert result['parent_groups'] == ['one', 'two']