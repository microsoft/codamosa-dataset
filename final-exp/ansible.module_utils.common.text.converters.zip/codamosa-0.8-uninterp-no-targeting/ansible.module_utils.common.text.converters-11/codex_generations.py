

# Generated at 2022-06-20 16:15:28.174904
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({u'hello': u'world'}) == {b'hello': b'world'}
    assert container_to_bytes({u'hello': u'world', u'bye': [3, u'three']}) == {b'hello': b'world', b'bye': [3, b'three']}



# Generated at 2022-06-20 16:15:36.325322
# Unit test for function container_to_text
def test_container_to_text():
    a = {u'a': [b'asd', b'\xee\xff']}
    b = {u'a': [b'asd', b'\xff\xee']}

    assert container_to_text(container_to_bytes(a, 'utf-8', 'surrogate_or_strict'), 'utf-8', 'surrogate_or_strict') == {u'a': [u'asd', u'\ufffd', u'\ufffd']}
    assert container_to_text(container_to_bytes(b, 'utf-8', 'surrogate_or_strict'), 'utf-16', 'surrogate_or_strict') == {u'a': [u'asd', u'\ufffd']}


# Python 2's os.walk does not return unicode

# Generated at 2022-06-20 16:15:40.967972
# Unit test for function to_bytes
def test_to_bytes():
    # This tests that we get different encodings when we
    # encode as ascii, latin-1 and utf-8
    # Result is sort of a roundabout way to get the bytes
    # representation of the encoded objects.
    assert True == b'\xc3\x89' in (
        sorted(to_bytes(to_text(u'\u00e9'), encoding)
               for encoding in ('utf-8', 'ascii', 'latin-1', 'iso-8859-15'))
    )

# Generated at 2022-06-20 16:15:52.483357
# Unit test for function to_native
def test_to_native():
    assert 'ascii str' == to_native('ascii str')
    assert u'unicode str' == to_native(u'unicode str')

    if PY3:
        assert 'ascii str' == to_native(b'ascii str')
        assert 'non-ascii ünicöde str' == to_native(b'non-ascii \xc3\xbcnic\xc3\xb6de str')
        assert 'non-ascii non-utf8\ufffd' == to_native(b'non-ascii non-utf8\xfc')
    else:
        assert b'ascii str' == to_native(b'ascii str')

# Generated at 2022-06-20 16:16:02.691320
# Unit test for function container_to_text
def test_container_to_text():
    """ Test data_to_text"""
    # Test lists
    test_list = [b'abc', b'def']
    assert [u'abc', u'def'] == container_to_text(test_list)

    # Test tuples
    test_tuple = (b'abc', b'def')
    assert (u'abc', u'def') == container_to_text(test_tuple)

    # Test dictionaries
    test_dict = {b'abc':b'def', b'ghi':b'jkl'}
    assert {u'abc':u'def', u'ghi':u'jkl'} == container_to_text(test_dict)

# Generated at 2022-06-20 16:16:15.121256
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text

    assert jsonify == json.dumps
    assert jsonify(None) == 'null'
    assert jsonify(True) == 'true'
    assert jsonify(1) == '1'
    assert jsonify('foo') == '"foo"'
    assert jsonify(u'foo') == '"foo"'
    assert jsonify(to_text(u"foo", "utf-16-le")) == '"foo"'
    assert jsonify(to_bytes("foo", "utf-16-le", errors='surrogateescape')) == '"foo"'
    assert jsonify({'foo': 1}) == '{"foo": 1}'

# Generated at 2022-06-20 16:16:26.095930
# Unit test for function jsonify
def test_jsonify():
    """
    Run a couple unit tests to make sure jsonify is working properly
    """
    # test a basic python object that json can handle
    test_dict = dict(a=1, b=2, c=3)
    assert jsonify(test_dict) == '{"a": 1, "c": 3, "b": 2}'

    # test a set
    test_set = Set()
    test_set.add('a')
    test_set.add('b')
    test_set.add('c')
    assert jsonify(test_set) == '["c", "a", "b"]'

    # test a datetime
    test_time = datetime.datetime(2012, 6, 29, 14, 37, 43, 599739)

# Generated at 2022-06-20 16:16:37.545729
# Unit test for function container_to_text

# Generated at 2022-06-20 16:16:48.918252
# Unit test for function container_to_text
def test_container_to_text():
    test_dict = { 'a': {'b': ['c', [{'d': 'e'}]]}}
    new_dict = container_to_text(test_dict)
    assert new_dict == { 'a': {'b': ['c', [{'d': 'e'}]]}}
    test_dict = { 'a': {'b': ['c', [{'d': b'\x80\x81'}]]}}
    assert test_dict != { 'a': {'b': ['c', [{'d': b'\xc3\x80\xc3\x81'}]]}}
    new_dict = container_to_text(test_dict)

# Generated at 2022-06-20 16:16:59.779672
# Unit test for function jsonify
def test_jsonify():
    import os
    import sys
    import tempfile
    from ansible.module_utils._text import to_bytes
    # Write a unicode filename
    filename = u"filename\u6709\u52b9.txt"
    (fd, filename) = tempfile.mkstemp(prefix=filename, suffix='.txt', dir='.')
    # Ensure the file has a unicode filename
    assert isinstance(filename, text_type)
    # Also ensure the file has a unicode name
    assert isinstance(os.path.basename(filename), text_type)
    os.close(fd)
    json.dumps({filename: 'foo'})
    # Now remove the file
    os.remove(filename)


# Generated at 2022-06-20 16:17:15.969980
# Unit test for function container_to_text
def test_container_to_text():
    expected_result = u'This is a text'
    from_unicode = container_to_text(expected_result)
    from_bytes = container_to_text(expected_result.encode('utf-8'))
    assert from_unicode == expected_result
    assert from_bytes == expected_result

    expected_result = {u'foo': u'bar', b'baz': b'qux'}
    from_unicode = container_to_text(expected_result)
    from_bytes = container_to_text(dict((k.encode('utf-8'), v.encode('utf-8')) for k, v in iteritems(expected_result)))
    assert from_unicode == expected_result
    assert from_bytes == expected_result


# Generated at 2022-06-20 16:17:27.435262
# Unit test for function to_native
def test_to_native():
    """Report whether the function is returning the expected output
    """

    # Generate a test case for test_to_native
    def test_to_native_case(input_str, encoding='utf-8', errors='surrogate_then_replace', nonstring='simplerepr'):
        """Generate a case for the test
        """

        # First deal with the inputs
        try:
            str_orig = to_text(input_str, encoding=encoding, errors=errors, nonstring=nonstring)
        except TypeError:
            # If the input was invalid, skip the test case
            return None

        # Next deal with the errors
        try:
            errors = to_native(errors, nonstring='passthru')
        except TypeError:
            # If the errors was invalid, skip the test case
            return None

        #

# Generated at 2022-06-20 16:17:35.539429
# Unit test for function jsonify
def test_jsonify():

    def test_encode(data, expect):
        actual = jsonify(data)
        if expect != actual:
            raise AssertionError("Expected %s, but got %s" % (expect, actual))

    if PY3:
        test_encode({"foo": u"\u2713"}, '{"foo": "\\u2713"}')
    else:
        test_encode({"foo": u"\u2713"}, '{"foo": "\\u2713"}')
        test_encode({"foo": u"\xe9"}, '{"foo": "\\u00e9"}')
        test_encode({"foo": "hello"}, '{"foo": "hello"}')



# Generated at 2022-06-20 16:17:43.925879
# Unit test for function container_to_text
def test_container_to_text():
    # Create a mock unicode string
    mock_unistring = unichr(40960) + u'abcd' + unichr(1972)

    # This list, when encoded to utf-8, will include multi-byte characters.
    # The point is to try and trip up byte-to-string conversions.
    multi_byte_char_list = [unichr(x) for x in range(0, 500)]
    multi_byte_char_string = "".join(multi_byte_char_list)

    # The following dictionaries should all convert without error

# Generated at 2022-06-20 16:17:54.489944
# Unit test for function to_bytes
def test_to_bytes():
    import sys

    # Test old behavior of to_bytes
    assert to_bytes('hello') == b'hello'
    assert to_bytes(b'hello') == b'hello'
    assert to_bytes('hellø', errors='surrogate_or_strict') == b'hell\xfffd'
    assert to_bytes('hellø', encoding='ascii', errors='surrogate_or_strict') == b'hell?'
    assert to_bytes(b'hell\xfffd', encoding='utf-8', errors='surrogate_or_strict') == b'hell\xfffd'
    assert to_bytes('hellø', encoding='utf-8', errors='surrogate_or_replace') == b'hell\xfffd'
    assert to_bytes('hello', nonstring='strict') == b'hello'
   

# Generated at 2022-06-20 16:18:02.039199
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes('foo') == b'foo'
    assert container_to_bytes('foo') != 'foo'
    assert container_to_bytes(u'foo') == b'foo'
    assert container_to_bytes(u'foo') != 'foo'
    assert container_to_bytes(['foo', u'bar']) == [b'foo', b'bar']
    assert container_to_bytes([u'foo', u'bar']) == [b'foo', b'bar']
    assert container_to_bytes({'foo': 'bar'}) == {b'foo': b'bar'}
    assert container_to_bytes({u'foo': u'bar'}) == {b'foo': b'bar'}

# Generated at 2022-06-20 16:18:14.106343
# Unit test for function to_native
def test_to_native():
    a = {u'composed': u'\u00E9', u'composed2': u'\u0301', u'case': u'\u00E9', 'decomposed': '\u0065\u0301', 'case2': '\u0065\u0301', 'surrogate': 'x\xed\xb0\x80y'}
    b = to_bytes(a)
    c = to_native(b)

    assert c == {u'case': u'\u00E9', u'composed': u'\u00E9', u'composed2': u'\u0301', 'decomposed': u'\u00E9', 'case2': u'\u00E9', u'surrogate': u'x\udc80y'}

# Generated at 2022-06-20 16:18:23.268100
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == 'foo'
    assert to_native('foo') == 'foo'

    #assert to_native(u'\u4321') == '\xE4\xB8\x81'
    #assert to_native('\xE4\xB8\x81') == '\xE4\xB8\x81'
    print(to_native(u'\u4321'))
    print(to_native('\xE4\xB8\x81'))
    assert to_native(1) == '1'
    #assert to_native(u'\u4321') == '\xE4\xB8\x81'
    #assert to_native('\xE4\xB8\x81') == '\xE4\xB8

# Generated at 2022-06-20 16:18:29.569563
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'b\xe9b\xe9') == b'b\xc3\xa9b\xc3\xa9'
    assert to_bytes(b'b\xc3\xa9b\xc3\xa9') == b'b\xc3\xa9b\xc3\xa9'
    assert to_bytes(b'b\xc3\xa9b\xc3\xa9', errors='surrogateescape') == b'b\xc3\xa9b\xc3\xa9'
    assert to_bytes(u'b\uFFFDb\uFFFD', errors='surrogateescape') == b'b\xed\xb3\x9db\xed\xb3\x9d'

# Generated at 2022-06-20 16:18:39.196374
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('test', 'latin-1') == b'test'
    assert to_bytes(b'test', 'latin-1') == b'test'
    assert to_bytes(u'test', 'latin-1') == b'test'
    assert to_bytes(b'test', 'utf-8') == b'test'
    assert to_bytes(u'test', 'utf-8') == b'test'

    # These cases rely on surrogateescape being registered
    assert to_bytes(b'test\xff', 'latin-1', errors='surrogate_or_replace') == b'test\xff'
    assert to_bytes(b'test\xff', 'latin-1', errors='surrogate_or_strict') == b'test\xff'

# Generated at 2022-06-20 16:18:54.459471
# Unit test for function to_native
def test_to_native():
    """This is from #28687, the original version of test_to_native. When we
    can determine the original author, this will be replaced with a proper
    attribution"""
    # Tests are rough, need some fixing
    assert to_native(b"\xe9\x99\xa2") == u"\u99a2"
    assert to_native(b"\xc3", errors='surrogate_then_replace') == u"\ufffd"
    assert to_native(b"\xe9\xc3", errors='surrogate_then_replace') == u"\u99fffd"
    assert to_native(b"\xe9\x99\xc3", errors='surrogate_then_replace') == u"\u99a2fffd"

# Generated at 2022-06-20 16:19:03.640311
# Unit test for function to_native
def test_to_native():
    """Ensure encoded byte strings return the correct values."""
    # test with ascii text
    test_text = 'some string'
    assert to_native(test_text) == test_text

    # test with utf-8 text
    test_text = '\u043c\u0430\u043c\u0430'
    assert to_native(test_text) == test_text

    # test with ascii encoded bytes
    test_text = 'some string'
    test_bytes = test_text.encode(encoding='ascii')
    assert to_native(test_bytes) == test_text

    # test with utf-8 encoded bytes
    test_text = '\u043c\u0430\u043c\u0430'

# Generated at 2022-06-20 16:19:09.359421
# Unit test for function container_to_text
def test_container_to_text():

    # test dict
    d1 = {"b":"a"}
    assert container_to_text(d1) == {"b":"a"}  # text
    assert container_to_text(container_to_bytes(d1)) == {"b":"a"} # bytes to text
    d2 = {"a":b"b"}
    assert container_to_text(d2) == {"a":"b"}
    d3 = {"b":"a", b"a":"b"}
    assert container_to_text(d3) == {"b":"a", "a":"b"}

    # test list
    l1 = ["b","a"]
    assert container_to_text(l1) == ["b","a"] # text
    assert container_to_text(container_to_bytes(l1)) == ["b","a"] # bytes to text
    l2

# Generated at 2022-06-20 16:19:20.701957
# Unit test for function container_to_bytes
def test_container_to_bytes():
    input1 = {u'a': u'a', u'b': [u'a', u'b', u'c'], u'c': {u'd': u'e', u'f': u'g'}}
    input2 = u'a'
    input3 = [u'a', u'b', u'c']
    input4 = (u'a', u'b', u'c')

# Generated at 2022-06-20 16:19:29.384037
# Unit test for function container_to_text
def test_container_to_text():
    str1 = u'\u043f\u0440\u0438\u0432\u0435\u0442 \u043c\u0438\u0440'
    str2 = b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82 \xd0\xbc\xd0\xb8\xd1\x80'
    d1 = {str1:str1}
    d2 = {str2:str2}
    d11 = container_to_text(d1)
    d12 = container_to_text(d1, errors='surrogate_then_replace')
    d2 = container_to_text(d2, errors='surrogate_then_replace')
    return



# Generated at 2022-06-20 16:19:36.102201
# Unit test for function to_native
def test_to_native():
    assert to_native(1) == 1
    assert to_native("1") == "1"
    assert to_native("1".encode('utf-8')) == "1"
    assert to_native("1", errors='surrogate_or_strict') == "1"
    assert to_native(u"1") == u"1"
    assert to_native(u"1", errors='surrogate_or_strict') == u"1"
    assert to_native("1".encode('utf-16')) == u"1"
    assert to_native("1".encode('utf-16'), errors='surrogate_or_strict') == u"1"
    assert to_native(u"1".encode('utf-8')) == u"1"

# Generated at 2022-06-20 16:19:41.539328
# Unit test for function jsonify
def test_jsonify():
    #Test value is Unicode
    inputString = u'unicode test string'
    #This is needed to pass the isinstance check
    outputString = inputString.encode('utf-8')
    jsonData = jsonify(inputString)
    assert(json.loads(jsonData) == outputString)

    #Test value is bytestring
    inputString = u'bytestring test string'.encode('utf-8')
    #This is needed to pass the isinstance check
    outputString = inputString.decode('utf-8')
    jsonData = jsonify(inputString)
    assert(json.loads(jsonData) == outputString)

    #Test value is integer
    inputInt = 4
    #This is needed to pass the isinstance check
    outputInt = str(inputInt)
    jsonData = jsonify(inputInt)

# Generated at 2022-06-20 16:19:52.992668
# Unit test for function to_native

# Generated at 2022-06-20 16:19:54.699792
# Unit test for function to_native
def test_to_native():
    """
    :return:
    """
    to_native(u'\u0999\u0999')



# Generated at 2022-06-20 16:19:58.373472
# Unit test for function jsonify
def test_jsonify():
    d = {"test_key":u'\xac\xb1\xac\xb1'}
    json_data = jsonify(d)
    assert json_data == '{"test_key": "\\ud30c\\ud2b8"}'


# Generated at 2022-06-20 16:20:15.616867
# Unit test for function to_bytes
def test_to_bytes():
    # Bytes and text types
    assert to_bytes(u'é') == u'é'.encode('utf-8')
    assert to_bytes(u'é'.encode('utf-8')) == u'é'.encode('utf-8')
    # Surrogates will fail
    try:
        to_bytes(u'\ud83d\uabc7')
    except UnicodeEncodeError:
        pass
    else:
        assert False, "to_bytes should have thrown an exception"
    # but surrogate_or_replace will ignore them
    assert to_bytes(u'\ud83d\uabc7', errors='surrogate_or_replace') == b''
    # and surrogate_or_strict will complain

# Generated at 2022-06-20 16:20:26.447704
# Unit test for function to_bytes
def test_to_bytes():
    # Different representations of Σ (sigma)
    # There is no sigma in latin1 so we can use the byte string as the expected value
    sigma_latin1_raw = b'\xc3\x83\xc2\x83\xc3\x82\xc2\x83\xc3\x83\xc2\x82\xc3\x83\xc2\x83'
    sigma_latin1_escaped = b'\\xc3\\x83\\xc2\\x83\\xc3\\x82\\xc2\\x83\\xc3\\x83\\xc2\\x82\\xc3\\x83\\xc2\\x83'
    sigma_utf8 = b'\xce\x93'

    if PY3:
        surrogateescape_error_handler = 'surrogateescape'


# Generated at 2022-06-20 16:20:30.500678
# Unit test for function to_bytes
def test_to_bytes():
    assert(type(to_bytes('foo')) == bytes)
    assert(type(to_bytes(u'foo')) == bytes)
    assert(type(to_bytes(1)) == bytes)
    assert(type(to_bytes(u'\u044f')) == bytes)



# Generated at 2022-06-20 16:20:40.787209
# Unit test for function container_to_text
def test_container_to_text():
    class Test(object):
        def __init__(self, name):
            self.name = name
        def __repr__(self):
            return self.name
        if PY3:
            __str__ = __repr__
        else:
            def __str__(self):
                return self.name.encode('utf-8')

    # test_dict

# Generated at 2022-06-20 16:20:51.793053
# Unit test for function to_bytes
def test_to_bytes():
    class TestObj():
        def __str__(self):
            return 'str: %s' % to_text(self.__class__.__name__, errors='surrogate_or_strict')

        def __repr__(self):
            return 'repr: %s' % to_text(self.__class__.__name__, errors='surrogate_or_strict')

    obj = TestObj()
    assert to_bytes(obj) == b'str: TestObj'
    assert to_bytes(obj, nonstring='strict') == b'str: TestObj'
    assert to_bytes(obj, nonstring='empty') == b''
    assert to_bytes(obj, nonstring='passthru') is obj

# Generated at 2022-06-20 16:20:59.645550
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"foo": text_type("\xe4", "latin-1")}) == '{"foo": "\\\\u00e4"}'
    assert jsonify({"foo": [text_type("\xe4", "latin-1"), None]}) == '{"foo": ["\\\\u00e4", null]}'
    assert jsonify({"foo": [text_type("\xe4", "latin-1"), b"\xe4"]}) == '{"foo": ["\\\\u00e4", "\\\\u00e4"]}'
    assert jsonify({"foo": [text_type("\xe4", "latin-1"), 1]}) == '{"foo": ["\\\\u00e4", 1]}'

# Generated at 2022-06-20 16:21:06.287617
# Unit test for function container_to_text
def test_container_to_text():
    # Type conversion
    dict_obj = dict(a=2, b=5.0, c=-1, d=-1.5)
    assert container_to_text(dict_obj) == dict(a=u'2', b=u'5.0', c=u'-1', d=u'-1.5')
    # Bytes strings
    dict_obj = dict(a=u'\u00e9')
    assert container_to_text(dict_obj) == dict(a=u'\ufffd')
    dict_obj = dict(a=u'\u00e9'.encode('utf-8'))
    assert container_to_text(dict_obj) == dict(a=u'\u00e9')

# Generated at 2022-06-20 16:21:12.687042
# Unit test for function to_bytes
def test_to_bytes():
    # PY3 doesn't need to be tested because on PY3 to_bytes meaning is the same as to_text
    if PY3:
        return

    # If the passed object is a string, just return the object
    assert to_bytes('hello') == b'hello'
    assert to_bytes(b'hello') == b'hello'
    # If the object is not a string, then we get the str of the object
    assert to_bytes(u'\xaf') == b'\xc3\xaf'
    assert to_bytes([]) == b'[]'
    assert to_bytes(bytearray(b'hello')) == b'hello'

    # A nonstring object is allowed to have surrogates when encoding to bytes

# Generated at 2022-06-20 16:21:21.789259
# Unit test for function jsonify
def test_jsonify():
    # We can't use the ansible.module_utils.basic.AnsibleModule as our test function
    # because it causes the ansible.module_utils.basic module to be imported,
    # and that imports this module (ansible.module_utils._text) which then causes
    # the `except UnicodeDecodeError` above to be triggered (see #26812).

    # First pass - test list/dict
    expected_data = json.loads(r'''
        {
            "list": [
                "string 1",
                "string 2",
                "string 3",
                "string 4"
            ],
            "dict": {
                "key 1": "value1",
                "key 2": "value2"
            }
        }
    ''')

# Generated at 2022-06-20 16:21:27.088234
# Unit test for function container_to_text
def test_container_to_text():
    e = u'\u20ac'

# Generated at 2022-06-20 16:21:40.295806
# Unit test for function to_bytes
def test_to_bytes():

    class UnicodeSurrogateException(Exception):
        pass

    class NonString(object):
        def __str__(self):
            raise UnicodeSurrogateException('Oops')

        def __repr__(self):
            raise UnicodeSurrogateException('Oops')

    class NotUnicode(object):
        def __str__(self):
            return '£'

        def __repr__(self):
            return '£'

    assert to_bytes(u'string') == b'string'
    assert to_bytes(b'bytes') == b'bytes'

    assert to_bytes(u'\uFFFD', errors='surrogate_then_replace') == b'?'
    assert to_bytes(u'\uFFFD', errors='surrogate_or_replace') == b'?'
    assert to

# Generated at 2022-06-20 16:21:45.905316
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8')) == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'



# Generated at 2022-06-20 16:21:53.718711
# Unit test for function jsonify
def test_jsonify():
    if PY3:
        assert jsonify(u'\x85') == u'"\\u0085"'
    else:
        assert jsonify(u'\x85') == u'"\x85"'
    assert jsonify({"a": 1, "b": set([1,2,3])}) == u'{"a": 1, "b": [1, 2, 3]}'



# Generated at 2022-06-20 16:22:01.312643
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert b'123' == container_to_bytes('123')
    assert {b'k1': b'v1', b'k2': b'v2'} == container_to_bytes({'k1': 'v1', 'k2': 'v2'})
    assert [b'l1', b'l2'] == container_to_bytes(['l1', 'l2'])
    assert (b't1', b't2') == container_to_bytes(('t1', 't2'))
    assert {b'k1': b'v1', b'k2': b'v2'} == container_to_bytes(OrderedDict([('k1', 'v1'), ('k2', 'v2')]))

# Generated at 2022-06-20 16:22:05.072045
# Unit test for function jsonify

# Generated at 2022-06-20 16:22:14.112025
# Unit test for function container_to_bytes
def test_container_to_bytes():
    import six

    input = { u"foo" : u"bar" }
    output = { "foo" : "bar" }
    assert container_to_bytes(input) == output

    class Foo(object):
        def __str__(self):
            return u"bar"

    input = { u"foo" : Foo() }
    output = { "foo" : "bar" }
    assert container_to_bytes(input) == output

    input = { u"foo": {u"bar": [u"baz", u"qux"]} }
    output = { "foo": {"bar": ["baz", "qux"]} }
    assert container_to_bytes(input) == output

    class Foo(object):
        def __str__(self):
            return u"bar"


# Generated at 2022-06-20 16:22:27.286315
# Unit test for function jsonify
def test_jsonify():
    # first test case for list
    test_data = [1, 2, 3]
    expected_result = '[1, 2, 3]'
    assert json.dumps(test_data, default=_json_encode_fallback) == expected_result
    assert jsonify(test_data) == expected_result
    # second test case for list of list
    test_data = [[1, 2, 3], [4, 5, 6]]
    expected_result = '[[1, 2, 3], [4, 5, 6]]'
    assert json.dumps(test_data, default=_json_encode_fallback) == expected_result
    assert jsonify(test_data) == expected_result
    # third test case for list of list of list

# Generated at 2022-06-20 16:22:39.036008
# Unit test for function container_to_text
def test_container_to_text():
    # test case: a, b, c and d should all be unicode
    a = {u'a': u'12345\u6162', u'b': u'abcd'}
    b = [u'12345\u6162', u'abcd']
    c = (u'12345\u6162', u'abcd')
    d = u'12345\u6162'
    res = container_to_text(a)
    assert (type(res[u'a']) == unicode) and (type(res[u'b']) == unicode)
    assert (type(res) == dict)
    res = container_to_text(b)
    assert (type(res[0]) == unicode) and (type(res[1]) == unicode)

# Generated at 2022-06-20 16:22:41.775009
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a":1, 2:"b"}) == '{"a": 1, "2": "b"}'
    raise AssertionError(jsonify({"a":1, 2:"b"}))



# Generated at 2022-06-20 16:22:51.334612
# Unit test for function to_bytes
def test_to_bytes():
    class Bunch(object):
        pass

    b = Bunch()
    b.a = 1
    b.b = 'asdf'

    assert to_bytes('asdf') == b'asdf'
    assert to_bytes(b'asdf') == b'asdf'
    assert to_bytes(b) == b"{'a': 1, 'b': 'asdf'}"

    assert to_bytes('\xe9') == b'\xc3\xa9'

    assert to_bytes('\xe9', nonstring='empty') == b''
    assert to_bytes('\xe9', nonstring='passthru') == u'\xe9'

# Generated at 2022-06-20 16:23:05.151037
# Unit test for function jsonify
def test_jsonify():
    decoded = u"{u'bytes': u'\\u20ac'}"

    result = jsonify({u'bytes':u'\u20ac'})
    print(type(result))
    print(result)

    assert(result == decoded)

test_jsonify()


# Generated at 2022-06-20 16:23:15.370755
# Unit test for function container_to_bytes
def test_container_to_bytes():
    data = dict(a=(1, 2), b=[3, 4], c=u'test', d=dict(e=5, f=u'räksmörgås'))
    data_bytes = dict(a=(b'1', b'2'), b=[b'3', b'4'], c=b'test', d=dict(e=b'5', f=b'r\xc3\xa4ksm\xc3\xb6rg\xc3\xa5s'))
    assert container_to_bytes(data) == data_bytes
    assert container_to_bytes(data, encoding='latin-1') == data_bytes


# Generated at 2022-06-20 16:23:24.107442
# Unit test for function to_bytes
def test_to_bytes():
    # Make sure we can take byte strings and return them unchanged.
    assert to_bytes(b'foo') == b'foo'
    # Make sure we can take text strings and encode them correctly
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'Björk Guðmundsdóttir') == b'Bj\xc3\xb6rk Gu\xc3\xb0mundsd\xc3\xb3ttir'
    # Make sure we can handle surrogates properly
    assert to_bytes(u'\U0001F4A9') == b'\xf0\x9f\x92\xa9'
    # Make sure we can take surrogates that are not valid and replace them properly

# Generated at 2022-06-20 16:23:30.240820
# Unit test for function jsonify
def test_jsonify():
    # Test to make sure that a byte string is jsonify as normal
    test_str = '{"json": "data"}'
    assert jsonify(test_str) == '{"json": "data"}'
    # Test to make sure a set will be jsonified properly
    test_set = set(["a", "b"])
    assert jsonify(test_set) == '["a", "b"]'
    # Test to make sure a datetime object will be jsonified properly
    test_datetime = datetime.datetime.now()
    assert jsonify(test_datetime) == test_datetime.isoformat()


# Generated at 2022-06-20 16:23:34.710370
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text([u'\u2019']) == [u'\u2019']
    assert container_to_text([u'\u2019'], encoding='binary') == [b'\xe2\x80\x99']
    assert container_to_text([u'\u2019'], encoding='binary', errors='strict') == [b'\xe2\x80\x99']
    assert container_to_text([u'\u2019'], encoding='binary', errors='ignore') == [b'']
    assert container_to_text([u'\u2019'], encoding='binary', errors='replace') == [b'?']
    assert container_to_text([u'\u2019'], encoding='illformed_encoding_name', errors='strict') == [u'\udcc3']
    assert container

# Generated at 2022-06-20 16:23:46.997032
# Unit test for function container_to_text
def test_container_to_text():
    # Non-container values do not change
    assert container_to_text(None) is None
    assert container_to_text(1) == 1
    assert container_to_text('a') == 'a'
    assert container_to_text(u'a') == u'a'
    assert container_to_text(to_bytes('a')) == 'a'
    assert container_to_text(to_bytes(u'a')) == u'a'

    # Lists of non-containers do not change
    assert container_to_text([]) == []
    assert container_to_text([1, 2, 3]) == [1, 2, 3]
    assert container_to_text([u'a', u'b', u'c']) == [u'a', u'b', u'c']
    assert container_

# Generated at 2022-06-20 16:23:52.118855
# Unit test for function container_to_text
def test_container_to_text():
    a = dict(key1 = 'value1', key2 = 'value2')
    b = dict(key3 = ['value3', 'value4', 'value5'])
    c = dict(key4 = ( 1, 2, 3 ), key5 = a, key6 = b)
    d = dict(key7 = c)
    assert container_to_text(d) == dict(key7 = dict(key4 = ( 1, 2, 3 ), key5 = dict(key1 = u'value1', key2 = u'value2'), key6 = dict(key3 = [u'value3', u'value4', u'value5'])))


# Generated at 2022-06-20 16:23:59.485910
# Unit test for function to_bytes
def test_to_bytes():
    # Note: This test is rather limited because we can't test the various
    # error handlers in our unit test.  We assume that python itself is
    # working properly and reproduce how to_bytes uses the error handlers in
    # an integration test.

    assert to_bytes('foo', nonstring='simplerepr') == b'foo'
    assert to_bytes(b'foo', nonstring='simplerepr') == b'foo'
    assert to_bytes(u'foo', nonstring='simplerepr') == b'foo'
    assert to_bytes(u'\ufffd', nonstring='simplerepr') == b'\ufffd'

    assert to_bytes('foo', nonstring='empty') == b''
    assert to_bytes(b'foo', nonstring='empty') == b''

# Generated at 2022-06-20 16:24:03.520036
# Unit test for function to_bytes
def test_to_bytes():
    # to_bytes is not tested with these tests because the tests use to_text to ensure python 2 and python 3 compatibility.
    pass


# Generated at 2022-06-20 16:24:15.267695
# Unit test for function container_to_text
def test_container_to_text():
    """ Simple unit test for function container_to_text

        Can serve as an example of how to use it.
    """
    dict_value = {u'a': u'a val', u'b': {u'a': u'a val'}, u'c': [u'a', u'b']}
    list_value = [u'a', u'b', {u'a': u'a'}]
    tuple_value = (u'a', u'b', {u'a': u'a'})
    # Explicit pass example
    assert (dict_value == container_to_text(dict_value))
    assert (list_value == container_to_text(list_value))
    assert (tuple_value == container_to_text(tuple_value))
    # ISO-8859-1 example

# Generated at 2022-06-20 16:24:32.465799
# Unit test for function to_native
def test_to_native():
    import os
    # this one is tricky because we want bytes to stay bytes
    # but we want to transform text to bytes
    orig = 'hello world'
    text_type = to_bytes(orig)
    assert type(text_type) is bytes
    orig = b'hello world'
    text_type = to_native(orig)
    assert type(text_type) is bytes



# Generated at 2022-06-20 16:24:41.455132
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' Test container_to_bytes before DataLoader will load
    '''
    if PY3:
        return

    raw_data = {
        u"name": u"\u041f\u0440\u0438\u0432\u0435\u0442",
        u"list": [u"\u041f\u0440\u0438\u0432\u0435\u0442"],
        u"dict": {u"key": u"\u041f\u0440\u0438\u0432\u0435\u0442"},
        u"tuple": tuple([u"\u041f\u0440\u0438\u0432\u0435\u0442"]),
    }

# Generated at 2022-06-20 16:24:47.507006
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes('foo') == b'foo'
    assert container_to_bytes(u'foo') == b'foo'
    assert container_to_bytes({u'a': u'b'}) == {b'a': b'b'}
    assert container_to_bytes({u'a': u'b\u2713'}) == {b'a': b'b\xe2\x9c\x93'}



# Generated at 2022-06-20 16:24:56.787853
# Unit test for function container_to_text

# Generated at 2022-06-20 16:25:01.360197
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes('a') == b'a'
    assert container_to_bytes(u'a') == b'a'
    assert container_to_bytes({"a":1}) == {b"a": 1}
    assert container_to_bytes([u"a", u"b"]) == [b"a", b"b"]
    assert container_to_bytes((u"a", u"b")) == (b"a", b"b")



# Generated at 2022-06-20 16:25:13.673130
# Unit test for function container_to_text
def test_container_to_text():
    from ansible.compat.tests import unittest
    from ansible.compat.tests import mock

    class TestCase(unittest.TestCase):
        def test_container_to_text(self):
            to_text_mock = mock.Mock()
            to_text_mock.return_value = u'unicode'