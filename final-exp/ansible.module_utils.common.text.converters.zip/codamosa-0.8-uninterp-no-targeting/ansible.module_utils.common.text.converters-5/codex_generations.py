

# Generated at 2022-06-20 16:15:33.508655
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert isinstance(container_to_bytes(u'foo'), binary_type)
    assert isinstance(container_to_bytes(u'foo'.encode('utf-8')), binary_type)
    assert isinstance(container_to_bytes({u'foo': u'bar'}), dict)
    assert isinstance(container_to_bytes({u'foo': u'bar'})[b'foo'], binary_type)
    assert isinstance(container_to_bytes({u'foo': u'bar'.encode('utf-8')})[b'foo'], binary_type)
    assert isinstance(container_to_bytes([1, 2, 3]), list)
    assert isinstance(container_to_bytes([u'foo', u'bar']), list)

# Generated at 2022-06-20 16:15:45.417693
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test different container types
    assert container_to_bytes({'a': u'b', u'c': 'd'}) == {'a': b'b', 'c': b'd'}, 'should only encode unicode keys and values'
    assert container_to_bytes([u'\xb5']) == [to_bytes(u'\xb5')], 'should handle list of unicode'
    assert container_to_bytes((u'\xb5',)) == (to_bytes(u'\xb5'),), 'should handle tuple of unicode'
    assert container_to_bytes(u'\xb5') == to_bytes(u'\xb5'), 'should handle simple unicode'
    assert container_to_bytes('\xb5') == b'\xb5', 'should leave the str type alone'
    assert container_to_bytes

# Generated at 2022-06-20 16:15:50.310753
# Unit test for function container_to_text
def test_container_to_text():
    """Test for container_to_text function.
    """

    def dump_and_load(data, encoding='utf-8', errors='surrogate_or_strict'):
        """Dump and then load json data

        This is a test helper function.
        """
        dumped = jsonify(data)
        loaded = json.loads(dumped)
        converted = container_to_text(loaded, encoding, errors)
        return converted

    # Test a case where non-container values are given
    non_container_values = [
        b"Some bytes", u"Some unicode",
        42, 42.0
    ]
    for val in non_container_values:
        assert container_to_text(val) == val


# Generated at 2022-06-20 16:16:02.528653
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(None, nonstring='simplerepr') == b'None'
    assert to_bytes(u'\u20ac', nonstring='simplerepr') == u'\u20ac'.encode('utf-8')
    assert to_bytes('\xd6\xa4\xce\xbb\xcf\x89\xce\xbd\xce\xb9', encoding='cp437') == b'\xd6\xa4\xce\xbb\xcf\x89\xce\xbd\xce\xb9'



# Generated at 2022-06-20 16:16:14.924616
# Unit test for function container_to_text
def test_container_to_text():
    assert(container_to_text(u"{'a': [1, 2, 'fo']}") == u"{'a': [1, 2, 'fo']}")
    assert(container_to_text(u"{'a': [1, 2, b'fo']}") == u"{'a': [1, 2, u'fo']}")
    assert(container_to_text({'a': [1, 2, b'fo']}) == {'a': [1, 2, u'fo']})
    assert(container_to_text({'a': [1, 2, u'fo']}) == {'a': [1, 2, u'fo']})
    assert(container_to_text({u"a": [b"p"]}) == {u"a": [u"p"]})

# Generated at 2022-06-20 16:16:21.357928
# Unit test for function container_to_text
def test_container_to_text():
    unit_test_dictionary ={'\\x83_': '\\x83_', '\\x83_x': {'\\x83_x': '\\x83_x'}}
    result_dict = container_to_text(unit_test_dictionary, encoding='utf-8', errors='surrogate_or_strict')
    assert result_dict['\x83_'] == '\x83_', result_dict['\x83_']
    assert result_dict['\x83_x']['\x83_x'] == '\x83_x', result_dict['\x83_x']['\x83_x']


# Generated at 2022-06-20 16:16:30.859551
# Unit test for function container_to_text
def test_container_to_text():
    # Tests that are specific to Python3.
    if PY3:
        test_data = {'data': [{b'a_byte_key': b'\xe1', 'a_text_key': u'\xe1', 'another_text_key': b'\xe1'}]}
        result = container_to_text(test_data, encoding='latin-1', errors='surrogate_or_replace')
        assert result['data'][0][b'a_byte_key'] == u'\xe1'
        assert result['data'][0]['a_text_key'] == u'\xe1'
        assert result['data'][0]['another_text_key'] == u'\xe1'


# this is for backwards compat until modules are updated to use jsonify
# when we no longer need to

# Generated at 2022-06-20 16:16:41.400745
# Unit test for function container_to_text
def test_container_to_text():
    def check( val ):
        assert isinstance( val, unicode )
    # Byte strings (errors can happen)
    check( container_to_text( u'spam' ) )
    check( container_to_text( b'eggs' ) )
    check( container_to_text( [ u'spam', b'eggs' ] ) )
    check( container_to_text( ( u'spam', b'eggs' ) ) )
    check( container_to_text( dict(spam=u'eggs', eggs=b'spam' ) ) )
    # Unicode strings are unchanged
    check( container_to_text( u'unicode' ) )
    check( container_to_text( [ u'spam', u'eggs' ] ) )

# Generated at 2022-06-20 16:16:51.687081
# Unit test for function to_native

# Generated at 2022-06-20 16:16:58.492570
# Unit test for function jsonify
def test_jsonify():
    a = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': {
            'key31': u'value 31',
            'key32': u'value 32',
            'key33': [
                u'value 331',
                u'value 332'
            ]
        }
    }

    print(jsonify(a, indent=4))


# Generated at 2022-06-20 16:17:20.421127
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(dict(foo=u'\xf6')) == dict(foo=u'\xf6')
    assert container_to_text([u'\xf6']) == [u'\xf6']
    assert container_to_text((u'\xf6',)) == (u'\xf6',)

    assert container_to_text(dict(foo=b'\xc3\xb6'.decode('utf-8'))) == dict(foo=u'\xf6')
    assert container_to_text([b'\xc3\xb6'.decode('utf-8')]) == [u'\xf6']
    assert container_to_text((b'\xc3\xb6'.decode('utf-8'),)) == (u'\xf6',)

# end unit test

# Generated at 2022-06-20 16:17:32.156010
# Unit test for function container_to_text
def test_container_to_text():
    b_string = b'$ANSIBLE_VAULT;1.1;AES256\n'
    b_key = b'66393333613662346163636233373466393764353265613161373961316563356466386464346234\n'
    b_string += b_key
    b_string += b'64633165383964366630633266633366386638656537366439333638343634316265373336366666\n'
    b_string += b'62343332396661623739653039636261393131636264383462356564313864663339646637386438\n'

# Generated at 2022-06-20 16:17:42.254737
# Unit test for function jsonify
def test_jsonify():

    # Test jsonify with simple string (text type)
    data = b"AM\xc3\x89RIQUE"
    expect = u'{"a": "AM\xC3\x89RIQUE"}'
    result = jsonify({"a": data}, ensure_ascii=False)
    assert result == expect

    # Test jsonify with special characters
    data = u"\u00A0\u20AC\u20AC"
    expect = b'{"a": "\\u00a0\\u20ac\\u20ac"}'
    result = jsonify({"a": data}, ensure_ascii=True)
    assert result == expect

    # Test jsonify with special characters
    data = u"\u00A0\u20AC\u20AC"

# Generated at 2022-06-20 16:17:53.436357
# Unit test for function to_native
def test_to_native():
    # Test str to_native conversion
    assert to_native(u'foo') == u'foo'

    # Test bytes to_native conversion
    if PY3:
        assert to_native(b'foo') == u'foo'
    else:
        assert to_native(b'foo') == b'foo'

    # Test native conversion of value with surrogates
    # On Python3, surrogate escaping shouldn't happen on roundtrip but it does
    # for some reason.
    assert to_native(to_bytes(u'foo\udcff' + u'bar')) == u'foo\\udcffbar'

    # Test native conversion of value with invalid utf-8 values
    assert to_native(b'\x80') == u'\\u0080'
    assert to_native(b'\x80\x81')

# Generated at 2022-06-20 16:18:03.082495
# Unit test for function container_to_text
def test_container_to_text():
    # Make a dict with some unicode that can be jsonified
    unicode_dict = dict(
        key1=u'Testing the \xe9to_text function',
        key2=u'\u2603',
        key3=[u'a', u'b', u'c', 1, 2, 3, dict(key4=u'\u2603')],
        key4=1,
        key5=2,
        key6=3,
    )

    # Also make a dict with string keys (but unicode values)
    # that cannot be jsonified

# Generated at 2022-06-20 16:18:15.865399
# Unit test for function to_native
def test_to_native():
    # Note: We import here so that the unit tests don't have a dependency on
    # the enum module. Only this test module needs enum
    from enum import IntEnum
    class TestEnum(IntEnum):
        val = 5
    assert to_text("just a text") == u"just a text"
    assert to_text("just a text", nonstring="passthru") == "just a text"
    assert to_text("just a text", nonstring="empty") == u""
    assert to_text("just a text", nonstring="strict") == u"just a text"
    assert to_text("just a text", nonstring="simplerepr") == u"just a text"
    assert to_text(u"just a text") == u"just a text"

# Generated at 2022-06-20 16:18:24.266844
# Unit test for function container_to_text
def test_container_to_text():
    # Issue 5967
    assert {u'hello': u'world'} == container_to_text({b'hello': b'world'}, errors='surrogateescape')
    # Issue 5967
    assert u'hello world' == container_to_text(b'hello world', errors='surrogateescape')
    # Issue 5967
    assert u'hello world' == container_to_text(b'hello world')
    # Issue 5962
    assert {u'hello': u'world'} == container_to_text({b'hello': b'world'}, errors='surrogate_or_strict')
    # Issue 6021

# Generated at 2022-06-20 16:18:25.830734
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == b'foo'
# End unit test



# Generated at 2022-06-20 16:18:35.897483
# Unit test for function jsonify
def test_jsonify():
    """ jsonify: return json representation of data """
    data = dict(
        one=dict(
            two=[u'abc', u'café', 'déf', 'ghi', dict(three=u'what?'), dict(three=[u'what?', u'what!', 'what.'])],
            four=u'spam and eggs',
            five=datetime.datetime.now(),
        )
    )
    jsonified_data = jsonify(data)
    decoded_data = json.loads(jsonified_data)
    assert data == decoded_data



# Generated at 2022-06-20 16:18:47.540057
# Unit test for function container_to_bytes
def test_container_to_bytes():
    h = {u'foo': [1, 2, {u'bar':(u'baz', None, 1.0, 2)}]}
    hh = container_to_bytes(h)

    assert isinstance(hh[b'foo'], list)
    assert isinstance(hh[b'foo'][0], int)
    assert isinstance(hh[b'foo'][1], int)
    assert isinstance(hh[b'foo'][2], dict)
    assert isinstance(hh[b'foo'][2][b'bar'], tuple)
    assert isinstance(hh[b'foo'][2][b'bar'][0], binary_type)
    assert hh[b'foo'][2][b'bar'][0] == b'baz'

# Generated at 2022-06-20 16:19:09.265546
# Unit test for function jsonify
def test_jsonify():
    """ Validate that jsonify acts as a proper wrapper for json.dumps """

    # Build a dict with an encoding of utf-8, no errors
    unicode_dict = {u'foo': u'föö'}
    assert isinstance(jsonify(unicode_dict), str)

    # Build a dict with an encoding of utf-8, errors='ignore'
    unicode_dict = {u'foo': u'föö'}
    assert isinstance(jsonify(unicode_dict, errors='ignore'), str)

    # Build a dict with an encoding of utf-8, errors='surrogateescape'
    unicode_dict = {u'foo': u'föö'}
    assert isinstance(jsonify(unicode_dict, errors='surrogateescape'), str)

    # Build a dict with

# Generated at 2022-06-20 16:19:20.569686
# Unit test for function container_to_bytes
def test_container_to_bytes():
    if PY3:
        # if we are here, it is because we are supporting python2.
        # We are not interested in testing python3
        return

    assert(container_to_bytes({'a': 1, 'b': 2}) == {'a': 1, 'b': 2})
    assert(container_to_bytes((1,)) == (1,))
    assert(container_to_bytes([1]) == [1])
    assert(container_to_bytes('foo') == b'foo')
    assert(container_to_bytes(b'foo') == b'foo')
    assert(container_to_bytes(u'bar') == b'bar')


# Generated at 2022-06-20 16:19:24.990510
# Unit test for function container_to_bytes
def test_container_to_bytes():
    u1 = u'\u263a'
    d1 = {u1: u1, "k2": "v2"}
    data = container_to_bytes(d1)
    assert b'\xe2\x98\xba' in data
    assert isinstance(data, dict)
    assert isinstance(data.keys()[0], binary_type)


# Generated at 2022-06-20 16:19:33.623676
# Unit test for function container_to_bytes
def test_container_to_bytes():
    print('Test container_to_bytes')
    assert container_to_bytes({u'aaa': u'bbb'}) == {b'aaa': b'bbb'}
    assert container_to_bytes({u'aa\xe3a': u'bbb'}) == {b'aaa': b'bbb'}
    assert container_to_bytes(u'aa\xe3a') == b'aaa'
    assert container_to_bytes((u'aa\xe3a', u'bb\xe3b')) == (b'aaa', b'bbb')
    assert container_to_bytes([u'aa\xe3a', u'bb\xe3b']) == [b'aaa', b'bbb']

    # Error handling

# Generated at 2022-06-20 16:19:41.013463
# Unit test for function jsonify
def test_jsonify():
    """Test for dict, list, int, str, unicode, datetime object"""
    data_dict = {'test': 'data'}
    data_list = ['test', u'data']
    data_int = 10
    data_str = 'test'
    data_unicode = u'test'
    data_datetime = datetime.datetime.now()
    data_dict_json = json.dumps(data_dict)
    data_list_json = json.dumps(data_list)
    data_int_json = json.dumps(data_int)
    data_str_json = json.dumps(data_str)
    data_unicode_json = json.dumps(data_unicode)
    data_datetime_json = json.dumps(data_datetime.isoformat())

   

# Generated at 2022-06-20 16:19:52.682653
# Unit test for function to_bytes
def test_to_bytes():
    # These strings are all ascii so they'll be the same type going in and out
    text_strings = [u'foo', u'bar', u'baz1']
    for text_string in text_strings:
        assert to_bytes(text_string) == text_string
        assert type(to_bytes(text_string)) == binary_type

    assert to_bytes(u'123', errors='strict') == b'123'
    assert to_bytes(u"'123'", errors='strict') == b"'123'"

    assert to_bytes(b'123') == b'123'
    assert to_bytes(b"'123'") == b"'123'"


# Generated at 2022-06-20 16:20:01.528640
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {six.u('1'): six.u('foo'), six.u('2'): six.u('bar')}
    res = container_to_bytes(d)
    assert isinstance(res, dict)
    assert isinstance(res['1'], binary_type)
    assert isinstance(res['2'], binary_type)
    d_utf16 = {six.u('1'): six.u('foo'), six.u('2'): six.u('b\xe1r')}
    res = container_to_bytes(d_utf16)
    assert isinstance(res, dict)
    assert isinstance(res['1'], binary_type)
    assert isinstance(res['2'], binary_type)

# Generated at 2022-06-20 16:20:03.228089
# Unit test for function to_bytes
def test_to_bytes():
    # We really only care that the return value is a byte string
    assert isinstance(to_bytes(u'foobar'), binary_type)



# Generated at 2022-06-20 16:20:05.326152
# Unit test for function jsonify
def test_jsonify():
    # We are going to test jsonify
    data = dict(foo="bar", bam=[1, 2, 3])
    assert jsonify(data) == json.dumps(data)



# Generated at 2022-06-20 16:20:16.880861
# Unit test for function container_to_text
def test_container_to_text():
    if not PY3:
        # This needs to be run with python 2.X to test
        # Valid utf-8 input
        i = {u'a': 1, u'b': [1, 2, 3], u'c': {u'd': u'e'}}
        o = container_to_text(i)
        assert isinstance(o[b'a'], text_type)
        assert isinstance(o[b'b'], list)
        assert isinstance(o[b'c'], dict)
        assert isinstance(o[b'c'][b'd'], text_type)

        # Invalid utf-8
        i = {b'a\xed': 1, b'b': [1, 2, 3], b'c': {b'd\xed': b'e'}}

# Generated at 2022-06-20 16:20:39.564442
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' test container_to_bytes'''
    data_dict = dict(
        dict1 = dict(
            dict1_key1 = 'dict1_value1',
            dict1_key2 = 'dict1_value2',
        ),
        dict2 = dict(
            dict2_key1 = 'dict2_value1',
            dict2_key2 = 'dict2_value2',
        ),
    )
    # Encode unicode characters to byte strings
    data_dict_byte = container_to_bytes(data_dict)
    # data_dict_byte should be a dict of bytes
    assert(isinstance(data_dict_byte, dict))

    # data_dict_byte's keys should be byte strings
    for key in data_dict_byte:
        assert(isinstance(key, binary_type))


# Generated at 2022-06-20 16:20:50.633239
# Unit test for function to_native

# Generated at 2022-06-20 16:20:55.580950
# Unit test for function jsonify
def test_jsonify():
    assert jsonify("Hello World") == '"Hello World"'
    assert jsonify("Hello World".encode("latin-1")) == '"Hello World"'
    assert jsonify("Hello\xFFWorld") == '"Hello\\ufffdWorld"'
    assert jsonify("Hello\xFFWorld".encode("latin-1")) == '"Hello\\ufffdWorld"'



# Generated at 2022-06-20 16:21:01.382049
# Unit test for function container_to_text
def test_container_to_text():
    import six

    mylist = [u'bytes', 'bytes', u'unicode', six.binary_type('bytes'), None]
    newlist = container_to_text(mylist)

    assert isinstance(newlist[0], six.text_type)
    assert isinstance(newlist[1], six.text_type)
    assert isinstance(newlist[2], six.text_type)
    assert isinstance(newlist[3], six.text_type)


# Generated at 2022-06-20 16:21:12.376411
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' Test container_to_bytes() function '''
    # dict values
    assert container_to_bytes({u'ünicöde': u'ünicöde'}) == {b'\xc3\xbcnic\xc3\xb6de': b'\xc3\xbcnic\xc3\xb6de'}
    # dict keys
    assert container_to_bytes({u'ünicöde': 'ascii'}) == {b'\xc3\xbcnic\xc3\xb6de': b'ascii'}
    # list value
    assert container_to_bytes([u'ünicöde']) == [b'\xc3\xbcnic\xc3\xb6de']
    # tuple value

# Generated at 2022-06-20 16:21:21.644079
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes('hello') == b'hello'
    assert to_bytes(b'hello') == b'hello'
    assert to_bytes(b'\xe5\xe4\xf6') == b'\xe5\xe4\xf6'

    assert to_bytes(u'\xe5\xe4\xf6') == b'\xc3\xa5\xc3\xa4\xc3\xb6'
    assert to_bytes(u'\xe5\xe4\xf6', nonstring='simplerepr') == b'\xc3\xa5\xc3\xa4\xc3\xb6'

    # Non-default encoding
    assert to_bytes(u'\xe5\xe4\xf6', encoding='latin-1')

# Generated at 2022-06-20 16:21:25.116521
# Unit test for function to_native
def test_to_native():
    b = to_bytes('\xe4\xf6\xfc', encoding='latin-1')
    assert to_native(b) == u'äöü'



# Generated at 2022-06-20 16:21:36.284998
# Unit test for function to_bytes
def test_to_bytes():
    b = to_bytes(b'ascii')
    assert isinstance(b, binary_type)
    assert b == b'ascii'

    b = to_bytes('b\xc3\xa1n')
    assert isinstance(b, binary_type)
    assert b == b'b\xc3\xa1n'

    b = to_bytes('b\xe1n'.encode('latin-1'), encoding='latin-1')
    assert isinstance(b, binary_type)
    assert b == b'b\xe1n'

    b = to_bytes('b\xe1n'.encode('latin-1'), encoding='utf-8', errors='surrogateescape')
    assert isinstance(b, binary_type)
    assert b == b'b\xe1n'


# Generated at 2022-06-20 16:21:47.388021
# Unit test for function to_native
def test_to_native():
    assert to_native(1) == "1"
    assert to_native(u'\u1234') == u'\u1234'
    assert to_native(b"\x80") == u"\uFFFD"
    assert to_native(bytearray(b"\x80")) == u"\uFFFD"
    assert to_native(1, nonstring='passthru') == 1
    assert to_native(b"\x80", nonstring='passthru') == b"\x80"
    assert to_native(b"\xc2\x80", nonstring='passthru') == b"\xc2\x80"
    assert to_native(b"\xc2\x80", nonstring='strict') == u"\uFFFD"

# Generated at 2022-06-20 16:21:55.661170
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(u'hellì') == b'hell\xc3\xac'
    assert container_to_bytes(u'hellì', encoding='ascii', errors='replace') == u'hell?'.encode('ascii')
    assert container_to_bytes({u'hello': u'hellì', u'world': u'wórld'}, encoding='ascii') == {b'hello': b'hell\xc3\xac', b'world': b'w\xc3\xb3rld'}
    assert container_to_bytes([u'hellì', u'wórld'], encoding='ascii') == [b'hell\xc3\xac', b'w\xc3\xb3rld']

# Generated at 2022-06-20 16:22:14.984823
# Unit test for function to_native
def test_to_native():
    # Tests are run in the C locale, so surrogateescape is fine.
    # Note: This test also verifies to_bytes, because to_native calls that.
    # Unfortunately we are stuck with doctests until pytest fixes their unicode
    # handling issues so we will just duplicate the tests here.

    # This is not a doctest because we have to ensure the encoding is right
    # before calling a doctest.
    # This must be done before the import
    # (pylama: ignore=W0611)
    from ansible.module_utils._text import to_native

    # (pylama: ignore=W0612,D100)
    from ansible.module_utils._text import to_bytes, to_text

    # unicode
    assert u'\u00e9' == to_native(u'\u00e9')

# Generated at 2022-06-20 16:22:19.751030
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text('123' ) == '123'
    assert container_to_text('123'.encode('utf-8') ) == '123'
    assert container_to_text(u'123' ) == '123'
    assert container_to_text({'a':'1'}) == {'a':'1'}
    assert container_to_text({'a':'1'.encode('utf-8')}) == {'a':'1'}
    assert container_to_text({'a':u'1'}) == {'a':'1'}
    assert container_to_text(['123']) == ['123']
    assert container_to_text(['123'.encode('utf-8')]) == ['123']
    assert container_to_text([u'123']) == ['123']


# Generated at 2022-06-20 16:22:23.364629
# Unit test for function jsonify
def test_jsonify():
    data = {u'a': '123', u'b': u'\u2019'}
    new_data = jsonify(data)
    assert new_data == '{"a": "123", "b": "\\u2019"}'



# Generated at 2022-06-20 16:22:31.980311
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('This is a text string') == b'This is a text string'
    assert to_bytes(u'This is a text string') == b'This is a text string'
    assert to_bytes(b'This is a text string') == b'This is a text string'

    assert to_bytes('1') == b'1'
    assert to_bytes(u'1') == b'1'
    assert to_bytes(1) == b'1'
    assert to_bytes(1.0) == b'1.0'
    assert to_bytes(datetime.datetime.now()) == b'2017-05-11 18:38:32.262437'

    assert to_bytes(Set([1, 2])) == b"Set([1, 2])"

# Generated at 2022-06-20 16:22:36.759363
# Unit test for function jsonify
def test_jsonify():
    data = {u'key': [{u'key1': u'value1'}, {u'key2': u'value2'}]}
    assert jsonify(data) == '{\"key\": [{\"key1\": \"value1\"}, {\"key2\": \"value2\"}]}'


# Generated at 2022-06-20 16:22:47.649614
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.common.collections import is_collection
    from ansible.module_utils._text import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    import datetime
    import sys

    unicode_data = dict(a=u'a', á=u'á')
    byte_data = dict(a=b'a', á=b'\xc3\xa1')
    mixed_data = dict(a=u'a', á=b'\xc3\xa1')

    unicode_data_result = jsonify(unicode_data)
    byte_data_result = jsonify(byte_data)
    mixed_data_result = jsonify(mixed_data)


# Generated at 2022-06-20 16:22:59.814101
# Unit test for function container_to_text
def test_container_to_text():
    # Test that we can handle lists of lists
    # because that is how the return value of json.loads is
    assert container_to_text([[b'bytes', u'unicode'], [b'bytes2', u'unicode2']]) == [[b'bytes', u'unicode'], [b'bytes2', u'unicode2']]

    # Test that we can handle lists of lists of lists
    # because that is how the return value of json.loads is

# Generated at 2022-06-20 16:23:05.344265
# Unit test for function container_to_bytes
def test_container_to_bytes():
    u_data = {u'k1': u'v1', u'k2': u'v2', u'k3': u'v3'}
    b_data = container_to_bytes(u_data)
    for k, v in iteritems(u_data):
        assert to_bytes(k) in b_data
        assert to_bytes(v) == b_data[to_bytes(k)]


# Generated at 2022-06-20 16:23:09.773652
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(['foo',{'bar':'baz'},('qux',)]) == ['foo',{'bar':u'baz'},(u'qux',)]



# Generated at 2022-06-20 16:23:19.665710
# Unit test for function to_native

# Generated at 2022-06-20 16:23:34.099166
# Unit test for function to_native
def test_to_native():
    assert to_text(b'foo') == u'foo'
    assert to_text(b'foo', encoding='ascii') == u'foo'
    assert to_text(b'foo', errors='surrogate_or_strict') == u'foo'
    assert to_text(b'foo\xff', errors='surrogate_then_replace') == u'foo\ufffd'
    assert to_text(b'foo\xff', errors='surrogate_or_replace') == u'foo\ufffd'
    assert to_text(b'foo\xff', errors='surrogate_or_strict') == u'foo\ufffd'
    assert to_text(b'foo\xff', nonstring='passthru') == b'foo\xff'

# Generated at 2022-06-20 16:23:46.228694
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(u'ni\xf1o') == u'ni\xf1o'
    assert container_to_text(b'ni\xc3\xb1o') == u'ni\xf1o'

    assert container_to_text([b'ni\xc3\xb1o', u'ni\xf1o']) == [u'ni\xf1o', u'ni\xf1o']
    assert container_to_text((b'ni\xc3\xb1o', u'ni\xf1o')) == (u'ni\xf1o', u'ni\xf1o')


# Generated at 2022-06-20 16:23:52.744953
# Unit test for function container_to_text
def test_container_to_text():
    class TestObject(object):
        def __unicode__(self):
            return u'foo'

        def __str__(self):
            return 'bar'

    assert isinstance(container_to_text({'foo': b'bar'}), dict)
    assert isinstance(container_to_text({'foo': 'bar'}), dict)
    assert isinstance(container_to_text(['foo', b'bar']), list)
    assert isinstance(container_to_text(('foo', b'bar')), tuple)

    # Test that it handles the various forms of __str__, __unicode__
    # inheritance, __str__ returning text or bytes, and unicode vs text
    # versions
    #
    # No __str__/__unicode__
    o = {}

# Generated at 2022-06-20 16:24:02.687685
# Unit test for function to_bytes
def test_to_bytes():
    import sys
    if PY3:
        # PY3K: We'll never raise a UnicodeError or UnicodeEncodeError so we use
        # the error handler to cause an exception.  We cannot use nonencodable
        # unicode chars in PY3K as Python will always encode them as bytes.
        assert to_bytes(u'\udcff') == u'\udcff'.encode('utf-8')
        assert to_bytes(b'\xff', errors='strict') == u'\xff'.encode('utf-8')
        # We can't cause an error handler to raise in PY3K so we can't test
        # surrogate_or_replace or surrogate_or_strict


# Generated at 2022-06-20 16:24:12.779441
# Unit test for function to_bytes
def test_to_bytes():
    """ Test function to_bytes
    """

    assert to_bytes('abc') == b'abc'
    assert to_bytes(u'abc') == b'abc'
    assert to_bytes(u'\u3042') == b'\xe3\x81\x82'
    assert to_bytes(u'\udc80') == b'\xed\xb2\x80'
    assert to_bytes(b'\xc2') == b'\xc2'
    assert to_bytes(b'\xc2', 'latin-1') == b'\xc2'
    assert to_bytes(b'\xc2\xa2', 'latin-1') == b'\xc2\xa2'

# Generated at 2022-06-20 16:24:25.377171
# Unit test for function to_bytes
def test_to_bytes():
    def _test(obj, encoding='utf-8', errors=None, nonstring='simplerepr', expected=None):
        result = to_bytes(obj, encoding=encoding, errors=errors, nonstring=nonstring)
        assert isinstance(result, binary_type)
        assert result == expected

    # Test text strings
    _test(u'simple', expected=b'simple')
    # Test codecs error handler is used
    _test(u'©', encoding='ascii', errors='ignore', expected=b'')

    if PY3:
        # Test surrogate_or_strict, surrogate_or_replace
        _test(u'\ud800', errors='replace', expected=b'?')
        # surrogate_or_strict not tested, it will always traceback in python3 because
        # surrogateescape is

# Generated at 2022-06-20 16:24:33.228317
# Unit test for function jsonify
def test_jsonify():
    data = {u'foo': u'bar'}
    assert jsonify(data) == '{"foo": "bar"}'
    data = {u'foo': {u'bar': u'baz'}}
    assert jsonify(data) == '{"foo": {"bar": "baz"}}'
    data = {u'foo': [u'bar', u'baz']}
    assert jsonify(data) == '{"foo": ["bar", "baz"]}'


# Generated at 2022-06-20 16:24:41.672409
# Unit test for function jsonify
def test_jsonify():
    import ansible.module_utils.basic as _basic
    data = {
        'encoding': 'utf-8',
        'result': u'\U0001f600',
        'Set': set([u'\U0001f600', '\xa9', '\xae'])
    }
    assert _basic.jsonify(data) == json.dumps({'encoding': 'utf-8', 'result': u'\U0001f600', 'Set': [u'\U0001f600', '\xa9', '\xae']}, encoding='utf-8', default=_json_encode_fallback)


# Make sure these are the same to make it easier to just use a
# to_bytes or to_text converter throughout the codebase
to_str = to_native



# Generated at 2022-06-20 16:24:51.821950
# Unit test for function container_to_bytes
def test_container_to_bytes():
    from ansible.compat.tests import unittest
    class TestContainerToBytes(unittest.TestCase):
        def assertBytesEqual(self, d, c):
            '''
                assert that two data structures are the same,
                but make sure the data structure values are bytes strings.
            '''
            d = container_to_bytes(d)
            c = container_to_bytes(c)
            self.assertEqual(d, c)

        def test_unicode_string(self):
            d = u'\u00c3'
            c = '\xc3\x83'
            self.assertBytesEqual(d, c)

        def test_list_strings(self):
            d = [u'\u00c3']
            c = [b'\xc3\x83']
           

# Generated at 2022-06-20 16:25:00.298193
# Unit test for function to_native
def test_to_native():
    from distutils.version import LooseVersion

    if LooseVersion(json.__version__) >= LooseVersion('2.6'):
        assert to_native(1) == 1

    # Strange encoding
    # Fails if python has surrogateescape error handler
    if HAS_SURROGATEESCAPE and PY3:
        printable = ''.join(map(chr, range(32, 128))) + '\x80\x81\u0400\ufffd\u0100\ufffd\ufffd\u03ff\u0400\u07ff'

# Generated at 2022-06-20 16:25:19.972715
# Unit test for function container_to_text
def test_container_to_text():
    """Test for function container_to_text"""
    assert container_to_text(u'unicode_text') == u'unicode_text'
    assert container_to_text('raw_text') == u'raw_text'
    assert container_to_text(u'm\xe9me', 'utf-8') == u'm\xe9me'
    assert container_to_text(u'm\xe9me', errors='surrogate_or_strict') == u'm\xe9me'
    assert container_to_text('m\xc3\xa9me', 'utf-8') == u'm\xe9me'
    assert container_to_text('m\xc3\xa9me', 'ascii') == u'm\ufffd\ufffdme'