

# Generated at 2022-06-20 16:15:36.302648
# Unit test for function container_to_text
def test_container_to_text():
    a = [ b"test", b"test2", [ b"test3" ] ]
    b = container_to_text(a)
    assert b[0] == u"test"
    assert b[1] == u"test2"
    assert b[2][0] == u"test3"

    a = [ b"test", b"test2", ( b"test3" ) ]
    b = container_to_text(a)
    assert b[0] == u"test"
    assert b[1] == u"test2"
    assert b[2][0] == u"test3"

    a = [ b"test", b"test2", { b"test3" : b"test4" } ]
    b = container_to_text(a)
    assert b[0] == u"test"

# Generated at 2022-06-20 16:15:47.827225
# Unit test for function to_native
def test_to_native():
    assert isinstance(to_native(u'hümbug'), text_type)
    assert isinstance(to_native('hümbug'), text_type)

# Generated at 2022-06-20 16:15:55.509915
# Unit test for function container_to_text
def test_container_to_text():
    # Test 1
    original = {
        'foo': u'z\xc3\xbcr',
        'bar': [u'aaa', u'bbb', u'\xe1\xbc\xa0c'],
        'baz': {
            'aaa': u'\xe1\xbc\xa0\xe1\xbc\xa0\xe1\xbc\xa0',
            'encoded': '\xe1\xbc\xa0\xe1\xbc\xa0\xe1\xbc\xa0'.encode('utf-8'),
        }
    }
    
    # Test 2
    #original = {
    #    'foo': 'ascii',
    #    'bar': ['ascii', '\xe1\xbc\xa0'],
    #    'baz

# Generated at 2022-06-20 16:15:58.942762
# Unit test for function jsonify
def test_jsonify():
    datadict = dict(a='a', b=2)
    new_data = jsonify(datadict)
    if not isinstance(new_data, str):
        raise Exception('jsonify() did not pass for TEXT unicode strings')


# Generated at 2022-06-20 16:16:04.869280
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert {b'a': 1, b'b': 2} == container_to_bytes({u'a': 1, u'b': 2})
    assert [1, 2, 3] == container_to_bytes([1, 2, 3])
    assert (1, 2, 3) == container_to_bytes((1, 2, 3))
    assert 1 == container_to_bytes(1)
    assert b'1' == container_to_bytes(u'1')



# Generated at 2022-06-20 16:16:16.818694
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(dict(foo=u'bar')) == {u'foo': u'bar'}
    assert container_to_text(dict(foo=42)) == {'foo': 42}
    assert container_to_text(u'foo') == u'foo'
    assert container_to_text(42) == 42
    assert container_to_text(u'\u1234') == u'\u1234'
    assert container_to_text('\xe2\x98\x83') == u'\u2603'  # snowman

    with pytest.raises(UnicodeDecodeError):
        container_to_text('\xc3\xb1')  # latin1 n with tilde


# Generated at 2022-06-20 16:16:25.866852
# Unit test for function jsonify
def test_jsonify():
    try:
        import simplejson as json
    except ImportError:
        pass
    my_list = [to_bytes('{"name": "Bob", "age": 42}', "utf-8")]
    result = jsonify(my_list)
    assert result == '["{\\"name\\": \\"Bob\\", \\"age\\": 42}"]'
    assert type(result) == text_type
    my_dict = { "Hello world": "Hell\xf6 W\xf6rld" }
    result = jsonify(my_dict)
    assert result == '{"Hello world": "Hell\\xf6 W\\xf6rld"}'
    assert type(result) == text_type



# JSON serializer for entities to make sure all strings are unicode

# Generated at 2022-06-20 16:16:37.772313
# Unit test for function container_to_text
def test_container_to_text():
    """Unit test for function container_to_text"""
    # test_dict_utf8_bytes
    d = {u'k\u2222':u'v\u2222'}
    assert type(d) == dict
    assert type(d[u'k\u2222']) == text_type
    d_bytes = container_to_bytes(d)
    assert type(d_bytes) == dict
    assert type(d_bytes[u'k\u2222']) == binary_type
    assert d_bytes == {b'k\xca\xa2':b'v\xca\xa2'}
    d_text = container_to_text(d_bytes)
    assert type(d_text) == dict
    assert type(d_text[u'k\u2222']) == text_type

# Generated at 2022-06-20 16:16:46.984328
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(b'foo') == u'foo'
    assert container_to_text({b'foo': b'bar'}) == {u'foo': u'bar'}
    assert container_to_text([b'foo', b'bar']) == [u'foo', u'bar']
    assert container_to_text((b'foo', b'bar')) == (u'foo', u'bar')
    assert container_to_text('foo') == u'foo'
    assert container_to_text({'foo': 'bar'}) == {'foo': 'bar'}
    assert container_to_text(['foo', 'bar']) == ['foo', 'bar']
    assert container_to_text(('foo', 'bar')) == ('foo', 'bar')



# Generated at 2022-06-20 16:16:54.666574
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test data to be jsonified
    rd1 = {u'k1': u'abc', u'k2': [1, 2, 3], u'k3': {u'k4': u'def'}, u'k5': True, u'k6': None, u'k7': u'\u4e2d\u6587'}
    assert container_to_bytes(rd1, encoding='utf-8', errors='surrogate_or_strict') == \
           {b'k1': b'abc', b'k2': [1, 2, 3], b'k3': {b'k4': b'def'}, b'k5': True, b'k6': None, b'k7': b'\xe4\xb8\xad\xe6\x96\x87'}
   

# Generated at 2022-06-20 16:17:13.245519
# Unit test for function to_bytes
def test_to_bytes():

    # Testing PY3 behavior
    if PY3:
        assert to_bytes('foo') == b'foo'
        assert to_bytes(b'foo') == b'foo'
        assert to_bytes(u'foo') == b'foo'
        assert to_bytes(u'føø'.encode('utf-8'), errors='surrogateescape') == b'f\xf8\xf8'
        assert to_bytes(u'føø'.encode('utf-8'), errors='surrogate_or_strict') == b'f\xf8\xf8'
        assert to_bytes(u'føø'.encode('utf-8'), errors='surrogate_or_replace') == b'f\xf8\xf8'

# Generated at 2022-06-20 16:17:25.639535
# Unit test for function container_to_text
def test_container_to_text():
    # test 1.
    test_json = {"foo": u"bar"}
    assert test_json == container_to_text(test_json, "utf-8")
    # test 2.
    test_json = {"foo": u"bar", "foo2": u"bar2"}
    assert test_json == container_to_text(test_json, "utf-8")
    # test 3.
    test_json = {"foo": "bar", "foo2": u"bar2"}
    # because 'bar' is already a text string
    assert test_json == container_to_text(test_json, "utf-8")
    # test 4.
    test_json = {"foo": "bar", "foo2": "bar2"}
    # because 'bar' is already a text string
    assert test_json == container_to

# Generated at 2022-06-20 16:17:35.766914
# Unit test for function to_bytes
def test_to_bytes():
    # This test is designed to exercise as many branches as possible in the to_bytes function
    # and to make sure that we're getting byte strings back.

    # Basic functionality
    assert isinstance(to_bytes(b'bytes'), binary_type)
    assert isinstance(to_bytes('unicode'), binary_type)
    assert isinstance(to_bytes(u'unicode'), binary_type)

    # Assert default encoding
    assert to_bytes('foo') == b'foo'

    # Make sure we get a byte string if we use a non-default encoding
    assert to_bytes('foo', 'latin-1') == b'foo'

    # Make sure it works without encoding
    assert to_bytes(b'bytes') == b'bytes'

    # To make sure we've covered all branches, we'll use a non-ascii character

# Generated at 2022-06-20 16:17:44.051540
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes('foobar') == b'foobar'
    assert container_to_bytes(u'foobar') == b'foobar'
    assert container_to_bytes(['foobar']) == [b'foobar']
    assert container_to_bytes([u'foobar']) == [b'foobar']
    assert container_to_bytes([1,2,3]) == [1,2,3]

    d = {
        'foo': 'bar',
        'baz': 1,
        'qux': ['quux', 'quuux'],
        'corge': (1,2,3),
        1: 'one',
    }

    result = container_to_bytes(d)

# Generated at 2022-06-20 16:17:50.167082
# Unit test for function jsonify
def test_jsonify():
    obj = Set([text_type("foo"), text_type("bar")])
    assert "[\"foo\",\"bar\"]" == jsonify(obj)
    obj = datetime.datetime(2016, 6, 20, 10, 53, 32, 348078)
    assert "2016-06-20T10:53:32.348078" == jsonify(obj)


# Generated at 2022-06-20 16:18:00.914886
# Unit test for function to_bytes
def test_to_bytes():
    """
    >>> test_to_bytes()
    """
    import sys
    if PY3:
        invalid_bytes = b'\xff'
        surrogate_bytes = b'\xed\xa0\x80'
        valid_text = 'foo'
        invalid_text = '\ufffd'
    else:
        invalid_bytes = b'\xff'
        surrogate_bytes = b'\xed\xa0\x80'
        valid_text = u'foo'
        invalid_text = u'\ufffd'

    # Test invalid utf-8 bytes
    if PY3:
        assert to_bytes(invalid_bytes) == invalid_bytes
        assert to_bytes(invalid_bytes, surrogate_or_strict='surrogate_or_strict') == invalid_bytes
        assert to_

# Generated at 2022-06-20 16:18:12.124190
# Unit test for function to_native

# Generated at 2022-06-20 16:18:21.698768
# Unit test for function to_bytes
def test_to_bytes():
    # test surrogateescape and surrogate_then_replace
    assert to_bytes("foo bar") == b'foo bar'
    assert to_bytes("foo bar", errors='surrogate_or_replace') == b'foo bar'
    assert to_bytes("foo bar", errors='surrogate_or_strict') == b'foo bar'
    assert to_bytes("foo bar", errors='surrogate_then_replace') == b'foo bar'
    assert to_bytes("правда", encoding='koi8-r', errors='surrogate_or_replace') == b'\xef\xf0\xe0\xe2\xe4\xe0'

# Generated at 2022-06-20 16:18:35.607559
# Unit test for function container_to_text
def test_container_to_text():
    # test for simple dict
    d = {'a': 'b', 'c': 'd'}
    assert container_to_text(d) == d
    # test for dict with list
    d = {'a': ['b', 'c'], 'c': 'd'}
    assert container_to_text(d) == d
    # test for dict with list and sub dict
    d = {'a': ['b', {'c': 'd'}], 'e': 'f'}
    assert container_to_text(d) == d
    # test for dict with list and sub dict
    # use str/bytes/unicode strings to make sure they get converted to text
    d = {b'a': ['b', {'c': 'd'}], u'e': u'f'}
    assert container_to_text

# Generated at 2022-06-20 16:18:42.246885
# Unit test for function to_bytes

# Generated at 2022-06-20 16:19:15.056143
# Unit test for function jsonify
def test_jsonify():
    try:
        import simplejson
    except ImportError:
        try:
            import json as simplejson
        except ImportError:
            try:
                # For Python < 2.6 we can use demjson
                import demjson
            except ImportError:
                # If all else fails, we just skip it
                return None

    data = dict(a=set([1, 2]))
    assert jsonify(data) == '{"a": [1, 2]}'

# Generated at 2022-06-20 16:19:24.349386
# Unit test for function jsonify
def test_jsonify():
    # jsonify() requires that the default encoder is utf-8
    assert json.dumps(u'€') == u'"\\u20ac"'

    # Make sure that it works with simple objects that don't need encoding
    assert jsonify(u'€') == u'"\\u20ac"'
    assert jsonify({u'foo': 42}) == u'{"foo": 42}'

    # Now test objects that should be encoded
    assert jsonify({u'foo': [u'€']}) == u'{"foo": ["\\u20ac"]}'
    assert jsonify({u'foo': [42]}) == u'{"foo": [42]}'
    assert jsonify({u'foo': {u'bar': u'€'}}) == u'{"foo": {"bar": "\\u20ac"}}'

# Generated at 2022-06-20 16:19:34.884010
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # simple test
    assert json.loads(container_to_bytes(json.dumps({"bstr":"bstr", "ustr":"ustr", "int":1, "list": ["bstr", "ustr", 1]}))) ==\
        json.loads(json.dumps({"bstr":b"bstr", "ustr":b"ustr", "int":1, "list": [b"bstr", b"ustr", 1]}))
    # test float
    assert json.loads(container_to_bytes(json.dumps({"float":1.2}))) ==\
        json.loads(json.dumps({"float":1.2}))
    # test complex
    assert json.loads(container_to_bytes(json.dumps({"complex":1 + 2j}))) ==\
        json.loads

# Generated at 2022-06-20 16:19:40.055138
# Unit test for function to_native
def test_to_native():
    """to_native: Convert a given object to native string."""

    # Test standard string, should pass through.
    if PY3:
        assert to_text(u'foo') == u'foo'
    else:
        assert to_text(b'foo') == b'foo'

    # Test byte string conversion
    byte_string_utf8 = b'I \xc3\xa4m \xc3\x84\xc3\xa6 a byte string'
    text_string_utf8 = u'I \xe4m \xc4\xe6 a byte string'
    assert to_text(byte_string_utf8) == text_string_utf8

    # Test unicode string conversion
    unicode_string = u'I \xe4m \xc4\xe6 a unicode string'

# Generated at 2022-06-20 16:19:51.662128
# Unit test for function jsonify
def test_jsonify():
    # encoding=ascii
    data = {'title': 'test', 'test':u'\u200d\u2764'}
    expected = json.dumps({'title': 'test', 'test':'\\u200d\\u2764'})
    assert jsonify(data) == expected

    data = {u'\u200d\u2764': 'test'}
    expected = json.dumps({'\\u200d\\u2764': 'test'})
    assert jsonify(data) == expected

    data = '\u0110\u0111\u0112'
    expected = json.dumps('\\uD0C\\uD0D\\uD0E')
    assert jsonify(data) == expected

    # encoding=latin-1

# Generated at 2022-06-20 16:19:58.368359
# Unit test for function to_native
def test_to_native():
    if IS_PY2:
        # Check we can always use a non-native str type
        assert to_native(u'foo') == u'foo'
        assert to_native(u'foo', nonstring='passthru') == u'foo'
        assert to_native(u'foo', nonstring='simplerepr') == u'foo'
        assert to_native(u'foo', nonstring='empty') == u''

        # Check that we can't use other types
        assert not isinstance(to_native(1), text_type)
        assert to_native(1, nonstring='simplerepr') == u'1'
        assert to_native(1, nonstring='empty') == u''
        assert to_native(1, nonstring='passthru') == 1

# Generated at 2022-06-20 16:20:09.436339
# Unit test for function to_bytes

# Generated at 2022-06-20 16:20:18.588722
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.six import StringIO
    import sys
    import json

    class Unicode(unicode):
        pass

    class UnicodeDict(dict):
        pass

    class UnicodeList(list):
        pass

    class UnicodeAndByteString(unicode):
        def encode(self, encoding):
            return 'byte string'

    unicode_string = Unicode('unicode string')
    unicode_dict = UnicodeDict([(Unicode('key'), Unicode('value'))])
    unicode_list = UnicodeList([Unicode('list')])
    unicode_and_byte_string = UnicodeAndByteString('unicode and byte string')

# Generated at 2022-06-20 16:20:27.730786
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'영어') == b'\xec\x98\x81\xec\x96\xb4'
    assert to_bytes(u'ひらがな', 'euc-jp') == b'\x8b\xa6\x8b\xbb\x8b\x9f'
    assert to_bytes(u'hello', errors='surrogate_or_replace') == b'hello'

    # We don't have surrogates, so surrogateescape doesn't matter
    assert to_bytes(u'ひらがな', 'euc-jp', errors='surrogate_or_strict') == b'\x8b\xa6\x8b\xbb\x8b\x9f'

# Generated at 2022-06-20 16:20:30.943293
# Unit test for function to_native
def test_to_native():
    ansible_native1 = "test"
    ansible_native2 = u"test"
    assert to_native(ansible_native1)== "test"
    assert to_native(ansible_native2)== "test"
# Unit test to_bytes

# Generated at 2022-06-20 16:22:10.399963
# Unit test for function jsonify
def test_jsonify():
    data = {
        'list': [1, 2, 3],
        'string': 'test',
        'unicode': u'\u7a0b',
        'bytes': b'bytestring',
        'set': set(),
        'dict': {'name': 'bar'}
    }

    # old systems using old simplejson module does not support encoding keyword
    if hasattr(json.dumps, '__code__'):
        co_varnames = json.dumps.__code__.co_varnames
        if not hasattr(json.dumps, 'encoding') and 'encoding' not in co_varnames:
            del data['list']

# Generated at 2022-06-20 16:22:19.920588
# Unit test for function to_bytes
def test_to_bytes():
    try:
        codecs.lookup_error('surrogateescape')
    except (NameError, LookupError):
        HAS_SURROGATEESCAPE = False
    else:
        HAS_SURROGATEESCAPE = True

    assert to_bytes(u'å') == b'\xc3\xa5'
    assert type(to_bytes(u'å')) is binary_type
    assert to_bytes(u'å', errors='ignore') == b''
    assert to_bytes(u'å', errors='replace') == b'?'
    assert to_bytes(u'å', errors='surrogate_or_strict') == b'\xc3\xa5'
    assert to_bytes(u'å', errors='surrogate_or_replace') == b'?'

# Generated at 2022-06-20 16:22:28.874841
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # If a string is passed, it should be passed to to_bytes
    text = u'ñ'
    assert container_to_bytes(text) == b'\xc3\xb1'
    # If a dictionary is passed, both keys and values should be passed to
    # container_to_bytes
    d = {u'ñ': '1', '2': [3, 4], 5: {u'6': u'7'}}
    result = container_to_bytes(d)
    assert isinstance(result, dict)
    for k in result:
        assert isinstance(k, binary_type)
    for v in result.values():
        assert isinstance(v, binary_type) or isinstance(v, list) or isinstance(v, dict)
    # If a list is passed, all of its values should be passed to
   

# Generated at 2022-06-20 16:22:33.296925
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    # This function is the same as to_text and behaves the same.
    # Just a sanity test that it's still there
    assert to_native('foo') == 'foo'



# Generated at 2022-06-20 16:22:44.339988
# Unit test for function jsonify

# Generated at 2022-06-20 16:22:52.308604
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes('foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(b'\xff') == b'\xff'

    a = to_bytes(u'\u1eff')
    assert a == b'\xef\xbf\xbf'
    assert to_bytes(u'\ud800') == b'\xef\xbf\xbf'
    assert to_bytes(u'\ud800', errors=None) == b'\xef\xbf\xbf'
    if HAS_SURROGATEESCAPE:
        assert to_bytes(u'\ud800', errors='surrogateescape') == b'\xed\xa0\x80'
       

# Generated at 2022-06-20 16:23:01.818929
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('\x81') == b'\x81'
    assert to_bytes(u'\u20ac') == b'\xe2\x82\xac'
    assert to_bytes(u'\udcc4') == b'\xed\xb3\x84'

    #
    # This only works if surrogateescape is supported
    #
    if HAS_SURROGATEESCAPE:
        assert to_bytes(u'\udcc4', errors='surrogateescape') == b'\xed\xb3\x84'

    assert to_bytes('\x81', errors='replace') == b'?'
    assert to_bytes(u'\udcc4', errors='replace') == b'?'

# Generated at 2022-06-20 16:23:07.484562
# Unit test for function container_to_bytes
def test_container_to_bytes():
    container = dict(key=u'test', value=[u'test', dict(key=u'test')])
    str_container = dict(key=b'test', value=[b'test', dict(key=b'test')])
    result = container_to_bytes(container)
    assert result == str_container
    container = dict(key=u'\u6d4b\u8bd5')
    str_container = dict(key=b'\xe6\xb5\x8b\xe8\xaf\x95')
    result = container_to_bytes(container)
    assert result == str_container


# Generated at 2022-06-20 16:23:17.738135
# Unit test for function to_bytes

# Generated at 2022-06-20 16:23:30.585486
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"foo": "bar"}) == u'{"foo": "bar"}'
    assert jsonify({"foo": "bar"}, sort_keys=True) == u'{"foo": "bar"}'
    assert jsonify({"uΓÇôΓÇô": "bar"}) == u'{"uΓÇôΓÇô": "bar"}'
    assert jsonify({"uΓÇôΓÇô": "bar"}, sort_keys=True) == u'{"uΓÇôΓÇô": "bar"}'
    assert jsonify("ΓÇôfooΓÇô") == u'"ΓÇôfooΓÇô"'

# Generated at 2022-06-20 16:24:22.511424
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' Test container_to_bytes works as expected '''
    data = dict()
    data = {u'foo': 'bar',
            u'data': u'\xf6\xe4\xfc',
            u'list': ['foo', {1: 'bar', 2: 'baz'}]
            }
    data = container_to_bytes(data)
    assert isinstance(data, dict)
    assert isinstance(data['foo'], binary_type)
    assert isinstance(data['data'], binary_type)
    assert isinstance(data['list'], list)
    assert isinstance(data['list'][0], binary_type)
    assert isinstance(data['list'][1], dict)
    assert isinstance(data['list'][1][1], binary_type)

# Generated at 2022-06-20 16:24:25.947208
# Unit test for function to_native
def test_to_native():
    assert to_native('foo') == u'foo'
    assert to_native(u'foo') == u'foo'
    if PY3:
        assert to_native(b'foo') == 'foo'
    else:
        assert to_native(b'foo') == u'foo'



# Generated at 2022-06-20 16:24:29.798576
# Unit test for function container_to_text
def test_container_to_text():
    a = b'{"key": "value"}'
    result = container_to_text(a)
    assert result == u'{"key": "value"}'

# Generated at 2022-06-20 16:24:39.630204
# Unit test for function jsonify
def test_jsonify():
    # Begin test_jsonify
    s = '{"a": "\u20ac"}'

    driver = {
        "name": "Elena",
        "occupation": "Driver",
    }

    driver_json_str = jsonify(driver)

    assert driver_json_str == '{"name": "Elena", "occupation": "Driver"}'

    driver_json_obj = json.loads(driver_json_str)

    assert driver_json_obj == driver

    # Test with python2 and python3

# Generated at 2022-06-20 16:24:44.374185
# Unit test for function container_to_bytes
def test_container_to_bytes():
    data = {
        "key": [
            "value",
            {
                u"unicode_key": u"unicode_value",
                "ascii": "value"
            }
        ]
    }
    expected = {
        b"key": [
            b"value",
            {
                b"unicode_key": b"unicode_value",
                b"ascii": b"value"
            }
        ]
    }
    assert container_to_bytes(data) == expected
    assert container_to_bytes(expected) == expected



# Generated at 2022-06-20 16:24:48.542437
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(['']) == [b'']
    assert container_to_bytes([u'']) == [b'']
    assert container_to_bytes([{u'': ''}]) == [{b'': b''}]
    assert container_to_bytes({'': ''}) == {b'': b''}
    assert container_to_bytes({u'': u''}) == {b'': b''}
    assert container_to_bytes('a') == b'a'
    assert container_to_bytes(u'a') == b'a'



# Generated at 2022-06-20 16:24:57.591194
# Unit test for function container_to_text

# Generated at 2022-06-20 16:25:08.023419
# Unit test for function jsonify
def test_jsonify():

    # Test Set serialization
    assert jsonify(Set()) == "[]"
    assert jsonify(Set([1, 2, 3])) == "[1, 2, 3]"

    # Test datetime serialization
    assert jsonify(datetime.datetime(2014, 1, 1)) == '"2014-01-01T00:00:00"'

    # Test helpers still work
    assert jsonify(dict(foo='bar')) == '{"foo": "bar"}'


if PY3:
    def container_to_text(d, encoding='utf-8'):
        try:
            return dict((k.decode(encoding), v) for k, v in iteritems(d))
        except UnicodeError:
            return dict((k, v) for k, v in iteritems(d))

# Generated at 2022-06-20 16:25:13.030430
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    # to_native should always return unicode on python 2.x
    assert isinstance(to_native('foo'), text_type)



# Generated at 2022-06-20 16:25:21.207096
# Unit test for function to_bytes
def test_to_bytes():
    '''Test the to_bytes function'''

    # It's possible to supply text strings with various encodings as unicode
    # strings in Python2.  This test verifies that we decode strings into
    # unicode before encoding so that the encoding takes place in the right
    # order.
    unicode_text = u'unicode \u83ca\u5730'
    assert to_bytes(unicode_text, 'utf-8') == b'unicode \xe8\x8f\x8a\xe5\x9c\xb0'
    utf8_text = unicode_text.encode('utf-8')
    assert to_bytes(utf8_text, 'utf-8') == b'unicode \xe8\x8f\x8a\xe5\x9c\xb0'

    #