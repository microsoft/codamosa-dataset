

# Generated at 2022-06-20 16:15:33.302039
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(dict(k=u'v')) == {b'k': b'v'}
    assert container_to_bytes(dict(k=dict(k2=u'v2'))) == {b'k': {b'k2': b'v2'}}
    assert container_to_bytes(dict(k=[u'v1', u'v2'])) == {b'k': [b'v1', b'v2']}
    assert container_to_bytes(dict(k=(u'v1', u'v2'))) == {b'k': (b'v1', b'v2')}


# Generated at 2022-06-20 16:15:45.284724
# Unit test for function container_to_text
def test_container_to_text():
    # unicode
    assert container_to_text("héllo") == "héllo"
    assert container_to_text("héllö") == "héllö"
    assert container_to_text("héllø") == "héllø"
    assert container_to_text("héllõ") == "héllõ"
    assert container_to_text("héllõ") == "héllõ"
    assert container_to_text("héllö") == "héllö"
    assert container_to_text("héllõ") == "héllõ"
    assert container_to_text("\u0080") == "\u0080"
    assert container_to_text(u"\u0800") == u"\u0800"

# Generated at 2022-06-20 16:15:54.664485
# Unit test for function jsonify
def test_jsonify():
    import ansible.module_utils.basic
    # Test string
    assert jsonify("foo") == '"foo"'
    # Test list of integers
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'
    # Test list of strings
    assert jsonify(["foo", "bar"]) == '["foo", "bar"]'
    # Test dict
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    # Test dict with list
    assert jsonify({"a": [1,2,3]}) == '{"a": [1, 2, 3]}'
    # Test list of dicts
    assert jsonify([{"a": "b"}, {"c": "d"}]) == '[{"a": "b"}, {"c": "d"}]'

# Generated at 2022-06-20 16:16:04.822824
# Unit test for function to_native

# Generated at 2022-06-20 16:16:16.780293
# Unit test for function container_to_bytes
def test_container_to_bytes():
    '''
        Test container_to_bytes function
    '''
    assert container_to_bytes({'key': 'value'}) == {b'key': b'value'}
    assert container_to_bytes({'key': {'key2': 'value2'}}) == {b'key': {b'key2': b'value2'}}
    assert container_to_bytes({'key': ['value']}) == {b'key': [b'value']}
    assert container_to_bytes({'key': ('value',)}) == {b'key': (b'value',)}
    assert container_to_bytes(['value', 'value2']) == [b'value', b'value2']
    assert container_to_bytes(('value',)) == (b'value',)

# Generated at 2022-06-20 16:16:25.824850
# Unit test for function to_native
def test_to_native():
    assert to_native(1) == 1
    assert to_native(u'a') == u'a'
    assert to_native(u'\u2019') == u'\u2019'
    assert to_native(b'a') == u'a'
    assert to_native(b'\xe2\x80\x99') == u'\u2019'
    assert to_native(b'{"json": "obj"}') == u'{"json": "obj"}'
    assert to_native((1, 2, 3)) == (1, 2, 3)


# Generated at 2022-06-20 16:16:34.471014
# Unit test for function container_to_text
def test_container_to_text():
    dict_test = {'key_one': 'string', 'key_two': u'unicode_string'}
    list_test = [u'string', u'unicode_string']
    tuple_test = (u'string', u'unicode_string')

    try:
        a = container_to_text(dict_test)
        b = container_to_text(list_test)
        c = container_to_text(tuple_test)
    except UnicodeDecodeError:
        pytest.fail('container_to_text fail')


# Generated at 2022-06-20 16:16:46.382806
# Unit test for function container_to_text
def test_container_to_text():

    # the json module always returns the same container types and sometimes
    # has unicode keys and values
    d = dict(
        a=u'\u00e9',
        b=b'\xc3\xa9',
        c=[u'\u00e9', b'\xc3\xa9'],
        d=[u'\u00e9', b'\xc3\xa9'],
        e=u'\u00e9'.encode('utf-8'),
    )

    # We expect it to still be unicode
    container = container_to_text(d)
    assert isinstance(container['a'], text_type)
    assert isinstance(container['b'], text_type)
    assert isinstance(container['c'][0], text_type)

# Generated at 2022-06-20 16:16:51.975504
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_bytes, to_text
    assert to_bytes(jsonify({"string": "äöü"})) == b'{"string": "\\u00e4\\u00f6\\u00fc"}'
    assert to_text(jsonify({"string": "äöü"})) == "{\"string\": \"äöü\"}"


# Generated at 2022-06-20 16:17:02.981411
# Unit test for function container_to_text
def test_container_to_text():
    # Test with dict
    assert container_to_text({1: 2, b'o': b'o'}, encoding='utf-8') == {1: 2, u'o': u'o'}
    # Test with lists
    assert container_to_text([1, 2, b'o'], encoding='utf-8') == [1, 2, u'o']
    # Test with tuples
    assert container_to_text((1, 2, 3, b'o'), encoding='utf-8') == (1, 2, 3, u'o')
    # Test with no container
    assert container_to_text(1, encoding='utf-8') == 1
    assert container_to_text(None, encoding='utf-8') is None
    # Test with valid unicode string

# Generated at 2022-06-20 16:17:17.573063
# Unit test for function container_to_text
def test_container_to_text():
    data = {'test': [u'\u00e9']}
    assert container_to_text(data) == data


# Generated at 2022-06-20 16:17:29.773891
# Unit test for function to_native
def test_to_native():
    # Python 2.x unicode literals
    assert to_native(u"foo") == "foo"
    assert isinstance(to_native(u"\u043f\u0440\u0438\u0432\u0435\u0442"), str)
    # Python 3.x string literals
    assert to_native("foo") == "foo"
    assert isinstance(to_native("\u043f\u0440\u0438\u0432\u0435\u0442"), str)
    # Object that returns a string when coerced to str
    assert to_native(datetime.datetime.now()) == str(datetime.datetime.now())

    # Everything else should raise an exception

# Generated at 2022-06-20 16:17:32.383758
# Unit test for function container_to_text
def test_container_to_text():

    t = {'a': {1: '1', 2: '2', 3: '3'}, 'b': ['a', 'b', 'c']}

    assert(container_to_text(t) == to_text(t))


# Generated at 2022-06-20 16:17:42.555051
# Unit test for function to_native
def test_to_native():
    py2_byte_string = b'ham and eggs'
    py2_unicode_string = u"ham and eggs"
    py3_byte_string = b'ham and eggs'
    py3_unicode_string = u'ham and eggs'

    # test valid parameters
    assert to_native(py2_byte_string, 'utf-8', 'strict') == py3_unicode_string
    assert to_native(py2_byte_string, 'utf-8') == py3_unicode_string
    assert to_native(py2_unicode_string, 'utf-8') == py3_unicode_string

    assert to_native(py3_unicode_string, 'utf-8') == py3_unicode_string

# Generated at 2022-06-20 16:17:53.669544
# Unit test for function to_native
def test_to_native():
# Try two different named encodings for the same thing
    for encoding in ('ascii', 'ANSI_X3.4-1968'):
        assert to_native(u'string', encoding) == u'string'

    # Try a few different encodings
    assert to_native(u'string', 'utf-8') == u'string'
    assert to_native(u'string', 'latin1') == u'string'
    assert to_native(u'string', 'cp1252') == u'string'
    assert to_native(u'Øredev', 'utf-8') == u'Øredev'
    assert to_native(u'Øredev', 'latin1') == u'Øredev'

# Generated at 2022-06-20 16:18:03.229545
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils.basic import to_native
    assert '1' == to_native(1)
    assert '' == to_native(None)
    assert u"x" == to_native(u"x")
    assert u"?x" == to_native(b"x", errors='surrogate_then_replace')


# Updating and porting notes:
#
# In Python3, surrogateescape is available to let you deal with bytes that cannot
# be decoded using the specified encoding.  However, there is no way to specify
# that you want it to fail if there is a decoding error.
#
# When updating, remember to:
# - Update the docstrings for new error handler options
# - Add a new test for the error handler
# - Update the error handler and test it in the to_bytes and to_text functions
#

# Generated at 2022-06-20 16:18:04.205932
# Unit test for function to_native
def test_to_native():
    assert 1==1


# Generated at 2022-06-20 16:18:17.038581
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'some string') == '"some string"'
    assert jsonify(u'some string'.encode('utf-8')) == '"some string"'
    assert jsonify(u'some string'.encode('latin-1')) == '"some string"'
    assert jsonify({u'some string':u'some string'}) == '{"some string": "some string"}'
    assert jsonify({u'some string':u'some string'.encode('utf-8')}) == '{"some string": "some string"}'
    assert jsonify({u'some string':u'some string'.encode('latin-1')}) == '{"some string": "some string"}'

# Generated at 2022-06-20 16:18:21.821438
# Unit test for function jsonify
def test_jsonify():
    d = dict(text=u'This is a text with unicode characters: Кирилица',
             number=42)
    encoded = jsonify(d)
    assert isinstance(encoded, text_type)
    decoded = json.loads(encoded)
    assert decoded[u'text'] == d['text']
    assert decoded[u'number'] == d['number']



# Generated at 2022-06-20 16:18:26.226002
# Unit test for function to_native
def test_to_native():
    s = "This is a test"
    assert to_native(s) == u"This is a test"
    assert to_native(to_bytes(s)) == u"This is a test"

# Generated at 2022-06-20 16:18:44.647239
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    ansiblemodule = AnsibleModule(
        argument_spec={
            'test': {'required': True, 'type': 'list'},
        },
    )
    result = jsonify({"a": "value", "b": "value", "c": "value"})
    ansiblemodule.exit_json(result=result)


# Generated at 2022-06-20 16:18:54.383156
# Unit test for function to_bytes
def test_to_bytes():
    # We can't do a type based test here because on Python 2, unicode strings are valid byte strings
    # So we just have to figure out which type we should return
    string_type = type(u'text')

    def test_case(obj, expected):
        to_bytes_result = type(to_bytes(obj))
        to_bytes_return_value = to_bytes_result == string_type
        return to_bytes_return_value == expected

    assert test_case(b'asdf', True)
    assert test_case(u'asdf', False)
    assert test_case(u'☃', False)
    assert test_case(u'\U0001F4A9', False)
    assert test_case(u'\U0001F4A9'.encode('utf-16'), True)
    assert test

# Generated at 2022-06-20 16:19:03.578990
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_text, to_bytes
    assert to_native(to_bytes('test')) == 'test'
    assert to_native(to_text('test')) == 'test'
    assert to_native(to_bytes(u'é', encoding='latin-1'), errors='surrogate_or_strict') == u'é'
    assert to_native(to_text(b'\xef', encoding='latin-1'), errors='surrogate_or_strict') == u'\ufffd'
    assert to_native(to_bytes(u'é', encoding='latin-1'), errors='surrogate_or_replace') == u'é'

# Generated at 2022-06-20 16:19:09.203088
# Unit test for function container_to_bytes
def test_container_to_bytes():
    '''Unit test for function container_to_bytes'''
    d = {"key1" : 1234, "key2" : [1234,5678], "key3" : ("asdf",1234) }
    r = container_to_bytes(d)
    assert(isinstance(r, dict))
    assert(isinstance(r["key1"], int))
    assert(isinstance(r["key2"], list))
    assert(isinstance(r["key3"], tuple))



# Generated at 2022-06-20 16:19:20.525017
# Unit test for function container_to_text
def test_container_to_text():
    answer = {'foo': 'bar'}
    assert answer == container_to_text({b'foo': b'bar'})
    answer = {'foo': 'bar'}
    assert answer == container_to_text({b'foo': to_bytes('bar')})
    answer = {'foo': 'bar'}
    assert answer == container_to_text({to_bytes('foo'): b'bar'})
    answer = {'foo': 'bar'}
    assert answer == container_to_text({to_bytes('foo'): to_bytes('bar')})
    answer = {'foo': 'bar', 'baz': 'qux'}
    assert answer == container_to_text({'foo': 'bar', to_bytes('baz'): to_bytes('qux')})

# Generated at 2022-06-20 16:19:29.227772
# Unit test for function to_native
def test_to_native():
    # Ensure that common case is fast
    assert to_native(u'test') == 'test'
    assert to_native(bytearray(b'test')) == 'test'

    # Show that we do the right thing with nonstrings
    assert to_native(b'test') == 'test'
    assert to_native(1) == '1'
    assert to_native(dict(a=1, b=2)) == "{\'a\': 1, \'b\': 2}"

    # Show the error conditions
    try:
        to_native(dict(a=1, b=2), nonstring='strict')
        assert False
    except TypeError:
        pass

    # Ensure that we can decode using different errors handler
    # surrogateescape is an error handler new in python3.  If it exists we'll
    # use

# Generated at 2022-06-20 16:19:35.880826
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'', 'ascii') == b''
    assert to_bytes(b'', 'ascii') == b''
    assert to_bytes(u'a', 'ascii') == b'a'
    assert to_bytes(u'a', 'ascii', errors='surrogateescape') == b'a'
    assert to_bytes(u'\xff', 'ascii') == b'?'
    assert to_bytes(u'\xff', 'ascii', errors='surrogateescape') == b'\xff'
    assert to_bytes(u'\xff', 'ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\xed\xa0\xbd', 'utf-8', errors='surrogateescape') == b

# Generated at 2022-06-20 16:19:37.698173
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": [1, 2, 3], "b": {"c": [1, 2]}}) == '{"a": [1, 2, 3], "b": {"c": [1, 2]}}'



# Generated at 2022-06-20 16:19:44.032572
# Unit test for function container_to_bytes
def test_container_to_bytes():
    dct = {
        b'Pt-br': 'Brazil',
        u'Espa\xf1ol': 'Spanish',
        b'Portugu\xc3\xaas': 'Portuguese',
        u'\u65e5\u672c\u8a9e': 'Japanese',
        'Suomi': 'Finnish',
        u'Fran\xe7ais': 'French',
    }
    expected = {
        'Pt-br': 'Brazil',
        'Español': 'Spanish',
        'Portugu\xc3\xaas': 'Portuguese',
        '日本語': 'Japanese',
        'Suomi': 'Finnish',
        'Français': 'French',
    }


# Generated at 2022-06-20 16:19:45.175207
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({u'hello': u'world'}) == '{"hello": "world"}'



# Generated at 2022-06-20 16:20:04.200594
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(None) == None
    assert container_to_bytes(b'bytes_str') == b'bytes_str'
    assert container_to_bytes(u'unicode_str') == b'unicode_str'

    assert container_to_bytes({u'key1': u'value_str', 'raw_key': u'raw_value'}) == {b'key1': b'value_str', b'raw_key': 'raw_value'}

    # Test special characters
    assert container_to_bytes(u'\u0000') == b'\x00'
    assert container_to_bytes(u'\uFFFD') == b'\xef\xbf\xbd'
    assert container_to_bytes(u'\u0141') == b'\xc5\x81'



# Generated at 2022-06-20 16:20:16.180443
# Unit test for function to_native
def test_to_native():
    """Testing to_native function with some cases"""
    import json

    # string
    assert to_bytes('string') == b'string'
    assert to_text('string') == 'string'
    # list
    assert to_bytes([b'list of bytes']) == b'[b\'list of bytes\']'
    assert to_text([b'list of bytes']) == '[b\'list of bytes\']'
    # dict
    assert to_bytes({'key': 'value'}) == b'{\'key\': \'value\'}'
    assert to_text({'key': 'value'}) == '{\'key\': \'value\'}'
    # ascii text
    assert to_bytes('ascii_text') == b'ascii_text'

# Generated at 2022-06-20 16:20:22.893122
# Unit test for function container_to_text
def test_container_to_text():
    data1 = {'a': 1, 'b': {'c': u'\u00ff'}, 'd': [1, 2, 3], 'e': None}
    data2 = {'a': 1, 'b': {'c': '\x99'}, 'd': [1, 2, 3], 'e': None}
    data3 = {'a': 1, 'b': {'c': '\x99'}, 'd': [1, 2, '\x99'], 'e': None}

    # Test 1: data1 is valid utf-8 and should pass through
    assert data1 == container_to_text(data1)
    # Test 2: data2 is not valid utf-8 and should fail
    try:
        container_to_text(data2)
    except UnicodeError:
        pass
   

# Generated at 2022-06-20 16:20:26.000191
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(to_text({'key': 'value'}, errors='surrogate_then_replace')) == '{"key": "value"}'


# Generated at 2022-06-20 16:20:32.910408
# Unit test for function jsonify
def test_jsonify():
    raw_dict = dict(aaa=dict(bbb="text", ccc="binary".encode("ascii")))
    ans_json = jsonify(raw_dict)
    assert(ans_json == '{"aaa": {"bbb": "text", "ccc": "binary"}}')
    raw_list = ["text", "binary".encode("ascii")]
    ans_json = jsonify(raw_list)
    assert(ans_json == '["text", "binary"]')



# Generated at 2022-06-20 16:20:42.914090
# Unit test for function container_to_text
def test_container_to_text():

    # test for a dictionary
    data = {'a': 1, b'b': 2, u'c': 3}
    assert container_to_text(data) == {"a": 1, "b": 2, "c": 3}

    # test for a list
    data = [1, 2, 3, b'4', u'5']
    assert container_to_text(data) == [1, 2, 3, "4", "5"]

    # test for a tuple
    data = (1, 2, 3, [b'2', u'3'], (b'4', u'5'))
    assert container_to_text(data) == (1, 2, 3, ["2", "3"], ("4", "5"))


if PY3:
    container_to_native = container_to_text

# Generated at 2022-06-20 16:20:54.367811
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(True) == True
    assert container_to_text(False) == False
    assert container_to_text('abc') == u'abc'
    assert container_to_text(u'abc') == u'abc'
    assert container_to_text(b'abc') == u'abc'
    assert container_to_text([1, 2, 3]) == [1, 2, 3]
    assert container_to_text([1, 2, 'a']) == [1, 2, u'a']
    assert container_to_text([b'a', b'b']) == [u'a', u'b']
    assert container_to_text([True, False, 1, 2, 3]) == [True, False, 1, 2, 3]

# Generated at 2022-06-20 16:21:04.314399
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\xab\u1234\u20ac\u8000', nonstring='simplerepr') == b'\xab\xe1\x88\xb4\xe2\x82\xac\xE8\x80\x80'
    assert to_bytes(b'abcd') == b'abcd'
    assert to_bytes(1234, nonstring='simplerepr') == b'1234'
    assert to_bytes([1, 2, 3], nonstring='simplerepr') == b'[1, 2, 3]'
    assert to_bytes([1, 2, 3], 'latin-1', nonstring='simplerepr') == b'[1, 2, 3]'

# Generated at 2022-06-20 16:21:14.292926
# Unit test for function to_native
def test_to_native():
    """
    This unit test is for the function to_native (codeutils.py)
    """
    # Create some containers for the function
    _bytes = b'This is a byte string'
    _unicode = u'This is a unicode string'
    _more_bytes = u'This is another unicode string'.encode('utf-8')
    _bad_unicode = u'This is a unicode string with emojis: \U0001F60D, \U0001F44D'

    # Test __new__(cls)
    assert to_text(_bytes) == 'This is a byte string'
    assert to_text(_unicode) == u'This is a unicode string'
    assert to_text(_more_bytes) == u'This is another unicode string'
    assert to_text(_bad_unicode)

# Generated at 2022-06-20 16:21:21.072564
# Unit test for function container_to_text
def test_container_to_text():
    test_dicts = [
      {u'a': u'1', u'b': u'2', u'c': u'3'},
      {u'a': [u'1', u'2'], u'b': u'3'},
      {u'a': {u'1': u'2', u'3': u'4'}, u'b': u'5'}
    ]

    for d in test_dicts:
        orig_d = d
        d = container_to_text(d)
        assert(orig_d == d)


# Generated at 2022-06-20 16:21:49.571523
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'{"foo": "f\xf6\xf6"}') == '{"foo": "f\\u00f6\\u00f6"}'
    assert jsonify(u'{"foo": "f\xf6\xf6"}'.encode('latin-1')) == '{"foo": "f\\u00f6\\u00f6"}'
    assert jsonify(u'{"foo": "f\xf6\xf6"}'.encode('utf-8')) == '{"foo": "f\\u00f6\\u00f6"}'
    assert jsonify(u'{1: "f\xf6\xf6"}') == '{"1": "f\\u00f6\\u00f6"}'

# Generated at 2022-06-20 16:21:59.146843
# Unit test for function container_to_bytes
def test_container_to_bytes():
    good_dict = {u'a': 1, u'b': [1, 2],
                 u'c': {u'd': u'e', u'f': [u'g', u'h']}, u'i': (u'j', u'k')}

    valid_dict = {b'a': 1, b'b': [1, 2],
                  b'c': {b'd': b'e', b'f': [b'g', b'h']}, b'i': (b'j', b'k')}


# Generated at 2022-06-20 16:22:06.592839
# Unit test for function container_to_text
def test_container_to_text():
    test_data = b'\x80'
    assert container_to_text(test_data) == u'\ufffd'

    test_data = {
        1: b'\x80',
        2: b'\x81',
        3: b'\x82',
        4: {
            b'\x83': b'\x84',
            b'\x85': b'\x86',
            'nested list': [
                b'\x87',
                b'\x88',
            ],
        },
        'list': [
            b'\x89',
            b'\x8a',
        ],
    }

# Generated at 2022-06-20 16:22:08.487510
# Unit test for function container_to_bytes
def test_container_to_bytes():

    assert container_to_bytes([u'unicode', b'bytes', {u'a': u'1'}, (u'a', b'b')]) == [b'unicode', b'bytes', {b'a': b'1'}, (b'a', b'b')]



# Generated at 2022-06-20 16:22:14.609461
# Unit test for function to_native
def test_to_native():
    u = u'\u7f51\u6613'
    b = b'\xe7\xbd\x91\xe6\xa0\x87'
    s = u.encode('utf-8')

    assert to_text(u) == u
    assert to_text(b) == u
    assert to_text(s) == u

    assert to_bytes(u) == b
    assert to_bytes(b) == b
    assert to_bytes(s) == b


# Unit tests for function to_text

# Generated at 2022-06-20 16:22:27.507143
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({u'a': u'xxx', u'b': u'\u2345'}, 'utf-8', 'surrogate_or_strict') == \
        {b'a': b'xxx', b'b': b'\xe2\x8d\x85'}
    assert container_to_bytes([u'a', u'x\xfc'], 'utf-8', 'surrogate_or_strict') == \
        [b'a', b'x\xc3\xbc']
    assert container_to_bytes((u'a', u'x\xfc'), 'utf-8', 'surrogate_or_strict') == \
        (b'a', b'x\xc3\xbc')


# Generated at 2022-06-20 16:22:39.213739
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text({'ascii': b'ascii'}) == {'ascii': u'ascii'}
    assert container_to_text({'tracable': b'\x80'}) == {'tracable': u'\ufffd'}
    assert container_to_text(['ascii', b'ascii']) == ['ascii', u'ascii']
    assert container_to_text([u'ascii', b'ascii']) == ['ascii', u'ascii']
    assert container_to_text([u'ascii', b'\x80']) == ['ascii', u'\ufffd']

# Generated at 2022-06-20 16:22:49.681771
# Unit test for function container_to_bytes
def test_container_to_bytes():
    if sys.version_info < (2, 7):
        raise SkipTest("container_to_bytes is only supported in python 2.7 and above")
    # This unit test is based on json data structure
    # https://docs.python.org/2/library/json.html
    data = {'4': 5, '6': 7}
    expected = {b'4': 5, b'6': 7}
    assert container_to_bytes(data) == expected

    data = [1, 2, 3, {'4': 5, '6': 7}]
    expected = [1, 2, 3, {b'4': 5, b'6': 7}]
    assert container_to_bytes(data) == expected


# Generated at 2022-06-20 16:23:01.163330
# Unit test for function container_to_text
def test_container_to_text():
    def run_test(rval, kwargs, expect_exc=None):
        try:
            ret = container_to_text(rval, **kwargs)
            if expect_exc is not None:
                assert False, 'Expected exception: %s' % expect_exc
        except Exception as err:
            if expect_exc is None:
                raise
            if isinstance(err, expect_exc):
                return
            assert False, 'Expected exception %s, got %s' % (expect_exc, err)
        return ret

    assert run_test('abc', {}) == 'abc'
    assert run_test('abc', {'encoding': 'ascii'}) == 'abc'

# Generated at 2022-06-20 16:23:13.009410
# Unit test for function to_native
def test_to_native():
    # type: () -> None
    to_native(None) == 'None'
    to_native(True) == 'True'
    to_native(False) == 'False'
    to_native(1) == '1'
    to_native(1.5) == '1.5'
    to_native(1.5e6) == '1500000.0'
    to_native(u'abc') == 'abc'
    to_native(b'abc') == 'abc'
    to_native([1, 2, 3]) == '[1, 2, 3]'
    to_native({'a': 'b', 'c': 'd'}) == "{'a': 'b', 'c': 'd'}"

# Generated at 2022-06-20 16:24:00.751931
# Unit test for function to_native
def test_to_native():
    # Only run the tests if we have a way to validate the results
    if HAS_SURROGATEESCAPE:
        # Unit test for function to_native
        def test_to_native():
            raise RuntimeError("Don't test this function.  We should probably remove it.")


# Generated at 2022-06-20 16:24:11.857330
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u2713') == '\u2713'
    assert to_native(b'\xe2\x9c\x93') == '\xe2\x9c\x93'
    assert to_native(b'\xe2\x9c\x93', nonstring='passthru') == b'\xe2\x9c\x93'

    class Foo(object):
        def __repr__(self):
            return 'PASS'
    assert to_native(Foo()) == 'PASS'
    assert to_native(Foo(), nonstring='passthru') == Foo()
    assert to_native(Foo(), nonstring='empty') == ''
    assert to_native(1) == '1'
    assert to_native(1, nonstring='passthru') == 1

# Generated at 2022-06-20 16:24:21.943316
# Unit test for function to_bytes
def test_to_bytes():
    from ansible_test._testutils.pytest.utils import _dummy_codec
    from _pytest.monkeypatch import monkeypatch

    mp = monkeypatch()
    mp.delattr(codecs, 'lookup_error')
    mp.setattr(codecs, 'lookup_error', _dummy_codec)
    mp.setattr(codecs, 'lookup', _dummy_codec)

    def assert_codecs_called(errors):
        assert len(errors) > 0
        if errors == 'surrogate_or_strict':
            assert len(errors) == 2
            assert 'strict' in errors
        elif errors == 'surrogate_or_replace':
            assert len(errors) == 2
            assert 'replace' in errors

# Generated at 2022-06-20 16:24:32.825774
# Unit test for function to_bytes
def test_to_bytes():
    output_str = b'hello world'
    output_unicode = u'hello world'

    output_unicode_bmp = b'\xE7\x9A\x84'
    output_unicode_nonbmp_surrogates = u'\U0001F4A9'
    output_unicode_nonbmp_codepoint = u'\U0001F4A9'

    input_str = output_str
    input_unicode_bmp = output_unicode
    input_unicode_nonbmp_surrogates = output_unicode_nonbmp_surrogates
    input_unicode_nonbmp_codepoint = output_unicode_nonbmp_codepoint

    # python2

# Generated at 2022-06-20 16:24:41.650106
# Unit test for function container_to_bytes
def test_container_to_bytes():
    class TestContainer(object):
        def __init__(self, data):
            self.data = data

        def __iter__(self):
            return iter(self.data)

    if PY3:
        return

    assert container_to_bytes({}) == {}
    assert container_to_bytes('foo') == b'foo'
    assert container_to_bytes(u'foo') == b'foo'
    assert container_to_bytes({'foo': 'bar'}) == {b'foo': b'bar'}
    assert container_to_bytes({'foo': u'bar'}) == {b'foo': b'bar'}
    assert container_to_bytes({u'foo': u'bar'}) == {b'foo': b'bar'}

# Generated at 2022-06-20 16:24:51.777871
# Unit test for function to_native
def test_to_native():
    try:
        u = unicode('')
    except NameError:
        print("SKIP: to_native tests need python2")
        import sys
        sys.exit(0)
    b = ''.encode('utf-8')
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\xe9') == u'\xe9'
    assert to_native(b'\xc3\xa9') == u'\xe9'
    assert to_native(b'\xc3a') == u'\xa9'
    assert to_native(b'\xc3\xa9', nonstring='simplerepr') == "'\xc3\xa9'"

# Generated at 2022-06-20 16:24:55.218708
# Unit test for function to_native
def test_to_native():
    """ This is a unit test for function to_native """
    assert to_native(b'foo', nonstring='passthru') is b'foo'
    assert to_native(b'foo', encoding='ascii', nonstring='passthru') is b'foo'



# Generated at 2022-06-20 16:25:02.428863
# Unit test for function to_bytes
def test_to_bytes():
    # Make sure to_bytes can encode all bytes values
    for i in range(256):
        assert to_bytes(chr(i)) == chr(i)

    # Make sure we can encode unicode that only has ascii characters.  This
    # doesn't require a codec to be passed in
    assert u'abc123' == to_bytes(u'abc123')

    # Make sure ascii-only unicode will be encoded in other character sets
    assert to_bytes(u'abc123', encoding='latin-1') == u'abc123'.encode('latin-1')

    # To make the code coverage gods happy
    assert to_bytes(u'abc123', encoding='latin-1', nonstring='passthru') == u'abc123'

# Generated at 2022-06-20 16:25:14.583033
# Unit test for function jsonify
def test_jsonify():
    u_literal_string = u"I am a unicode string"
    b_literal_string = b"I am a simple bytestring"
    u_string = to_text(b_literal_string, encoding='ascii')
    a_list = [u_literal_string, b_literal_string, u_string]
    a_dict = {"key1": u_literal_string, "key2": b_literal_string, "key3": u_string}
    an_object = ToJSON(u_literal_string, b_literal_string, u_string)
    a_set = set(a_list)

    # u_literal_string is a unicode literal; if we try to jsonify it,
    # we'll get an error.