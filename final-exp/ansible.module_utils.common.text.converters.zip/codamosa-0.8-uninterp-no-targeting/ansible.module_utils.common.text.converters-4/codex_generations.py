

# Generated at 2022-06-20 16:15:48.198668
# Unit test for function to_native

# Generated at 2022-06-20 16:15:59.205990
# Unit test for function container_to_bytes

# Generated at 2022-06-20 16:16:03.513445
# Unit test for function to_native
def test_to_native():
    if PY3:
        assert to_native(u'foo') == u'foo'
        assert to_native(b'foo') == u'foo'
    else:
        assert to_native(u'foo') == u'foo'
        assert to_native(b'foo') == b'foo'


# Generated at 2022-06-20 16:16:09.889326
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # test with non unicode str
    assert container_to_bytes('abc') == b'abc'
    # test with unicode str
    assert container_to_bytes('\u5341') == b'\xe5\x90\x88'
    # test with int
    assert container_to_bytes(123) == 123
    # test with list
    assert container_to_bytes([1,2]) == [1,2]
    # test with tuple
    assert container_to_bytes((1,2)) == (1,2)
    # test with tuple
    assert container_to_bytes({1:2}) == {1:2}
    # test with tuple
    assert container_to_bytes({'a':'b'}) == {b'a':b'b'}
    # test with tuple
    assert container_to_

# Generated at 2022-06-20 16:16:19.964271
# Unit test for function jsonify
def test_jsonify():
    d1 = dict(a=u'\u1234', b=u'\u5678')
    assert jsonify(d1) == '{"a": "\\u1234", "b": "\\u5678"}'
    assert jsonify(d1, ensure_ascii=False) == '{"a": "\\u1234", "b": "\\u5678"}'
    assert jsonify(u'\u1234') == '"\\u1234"'
    assert jsonify(u'\u1234', ensure_ascii=False) == '"\\u1234"'

    # test with non-ascii encodable value
    d2 = dict(a=u'\u1234', b=u'\u5678', c=u'\u9101\u9102\u9103')


# Generated at 2022-06-20 16:16:29.882641
# Unit test for function to_bytes
def test_to_bytes():
    # try to fix this test to pass in a utf-8 environment
    try:
        u'\u2603'.encode('utf-8')
        utf8_chars = [u'ab\u2603cd']
    except (UnicodeEncodeError, UnicodeDecodeError):
        utf8_chars = []
    for text_string, utf8_char in zip(utf8_chars, utf8_chars):
        assert to_bytes(text_string) == text_string.encode('utf-8')
        assert to_bytes(utf8_char) == utf8_char.encode('utf-8')

    assert to_bytes('') == b''
    assert not isinstance(to_bytes(''), text_type)


# Generated at 2022-06-20 16:16:34.091160
# Unit test for function jsonify
def test_jsonify():
    test_data = {0: 'ansible', 1: 'rocks'}
    result = jsonify(test_data)
    if result != '{"0": "ansible", "1": "rocks"}':
        raise AssertionError('jsonify result is not correct')



# Generated at 2022-06-20 16:16:46.082848
# Unit test for function to_native

# Generated at 2022-06-20 16:16:58.136160
# Unit test for function to_native
def test_to_native():
    def do_test(obj, expected, **kwargs):
        # Can't use assertEqual here because of Unicode in py2.  Comparing
        # the reprs of the two objects.
        real = json.loads(to_bytes(to_native(obj, **kwargs)))
        expected = json.loads(to_bytes(expected))
        assert real == expected, 'Expected %s(%s) but got %s(%s)' % (type(expected), expected, type(real), real)

    # Make sure that no new types are added
    assert set(to_native.STRINGIFIERS.keys()) == set([type(None), bool, int, float, list, dict, text_type, tuple,
                                                      binary_type, datetime.datetime, Set])

    do_test('foo', 'foo')
   

# Generated at 2022-06-20 16:17:05.533600
# Unit test for function to_native
def test_to_native():
    assert to_text(u'test') == u'test'
    assert to_text(u'test'.encode('utf-8')) == u'test'
    assert to_text(u'\u00E9') == u'\u00E9'
    assert to_text(u'\u00E9'.encode('utf-8')) == u'\u00E9'
    assert to_text(u'\u00E9'.encode('latin-1')) == u'\u00E9'
    assert to_text(u'\u00E9'.encode('latin-1'), errors='surrogate_or_strict') == u'\u00E9'

# Generated at 2022-06-20 16:17:31.219692
# Unit test for function to_bytes
def test_to_bytes():
    # This function is complicated enough that we have a unit test for it
    import unittest
    import sys

    class TestToBytes(unittest.TestCase):
        def test_nonstring(self):
            self.assertEqual(b"1", to_bytes(1, nonstring='simplerepr'))
            self.assertEqual(b"1", to_bytes(1, nonstring='strict'))
            self.assertEqual(b"", to_bytes(1, nonstring='empty'))
            self.assertEqual(1, to_bytes(1, nonstring='passthru'))
            with self.assertRaises(TypeError):
                to_bytes(1, nonstring='notvalid')


# Generated at 2022-06-20 16:17:40.557371
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test data used in this test
    TestData = [
        {"key1" : 0, "key2" : "value2"},
        "TestString"]
    # Running the function to generate output
    Output = container_to_bytes(TestData)
    # Check if output is of type list
    assert type(Output) is list
    for index, value in enumerate(Output):
        # Check if output is of type dict
        if type(value) is dict:
            for item in iteritems(value):
                # Check if key is of type bytes
                assert type(item[0]) is bytes
                # Check if value is of type bytes
                assert type(item[1]) is bytes
        # Check if output is of type bytes
        elif type(value) is bytes:
            assert type(value) is bytes


# Generated at 2022-06-20 16:17:43.193345
# Unit test for function to_native
def test_to_native():
    assert to_native(b'test') == u'test'
    assert to_native(u'test') == u'test'



# Generated at 2022-06-20 16:17:53.946937
# Unit test for function container_to_text
def test_container_to_text():
    txt = 'test'
    txt2 = u'test'
    txt3 = 'étest'
    txt4 = b'test'
    txt5 = b'\xc3\xa9test'
    arr = [txt, txt2, txt3, txt4, txt5]
    arr2 = (txt, txt2, txt3, txt4, txt5)
    d = {'a': txt, 'b': txt2, 'c': txt3, 'd': txt4, 'e': txt5, 'f': arr, 'g': arr2}

# Generated at 2022-06-20 16:18:03.442387
# Unit test for function to_bytes
def test_to_bytes():
    import sys

    if PY3:
        ustr = 'O«À'
        bstr = b'O\xc2\xab\xc3\x80'
        ustr_invalid_utf8 = b'O\xc2\xab\xc3\xc0'.decode('utf-8', errors='surrogateescape')
        ustr_invalid_utf8_encoded = str('O\xab').encode('utf-8', 'surrogateescape')
        bstr_invalid_utf8 = b'O\xab\xc3\x80'
        bstr_invalid_utf8_encoded = str('O\xab').encode('utf-8', 'replace')
    else:
        ustr = u'O«À'

# Generated at 2022-06-20 16:18:16.241781
# Unit test for function to_bytes
def test_to_bytes():
    if not PY3:
        # We can't use surrogateescape on Python2 unless we have a backport
        # so just test that it's using the fallback error handler
        assert to_bytes(u"\uDC80") == b"?"
    else:
        # python3.3 does not have surrogateescape so only test it on 3.4+
        import sys
        if sys.version_info[:2] >= (3, 4):
            assert to_bytes(u"\uD800") == b"\xed\xa0\x80"
            assert (to_bytes(
                u"\uDC80\uD800hello",
                errors='surrogate_then_replace', nonstring='simplerepr'
            ) == b'\xef\xbf\xbd\xed\xa0\x80hello')

# Generated at 2022-06-20 16:18:24.037589
# Unit test for function to_native
def test_to_native():
    b_ = to_bytes
    u_ = to_text
    assert u_('foo') == u_('foo')
    assert u_('foo') == b_('foo')
    assert b_('foo') == u_('foo')
    assert u_('foo') == 'foo'
    assert b_('foo') == b_('foo')
    assert b_('foo') != u_('foo')
    assert b_('foo') != 'foo'

    # TODO: Either fix the above problem or add a comment.
    # Why does this work locally but fails on the build machine?
    # assert u_('foo') != b_('foo')
    assert u_('foo') != 'foo'


# Unit tests for function to_text

# Generated at 2022-06-20 16:18:36.553748
# Unit test for function jsonify
def test_jsonify():
    def check_jsonify(obj):
        assert jsonify(obj) == json.dumps(obj)


# Generated at 2022-06-20 16:18:47.937281
# Unit test for function container_to_text
def test_container_to_text():
    '''Unit test for function container_to_text'''
    utf8_string = u'☃ - \U0001F638'
    utf8_byte_string = b'\xe2\x98\x83 - \xf0\x9f\x98\xb8'
    utf8_byte_string_wrong_type = u'\xe2\x98\x83 - \xf0\x9f\x98\xb8'
    latin1_byte_string = b'\u2603 - \ud83d\ude38'
    utf8_dict = {utf8_string: utf8_string}
    mixed_dict = {utf8_byte_string: utf8_string}

# Generated at 2022-06-20 16:18:55.397975
# Unit test for function container_to_text
def test_container_to_text():
    my_dict = {'foo': u'\u5341', 'bar': ['baz', {'foofoo': u'\u5341\u5341'}]}
    assert container_to_text(my_dict) == {'foo': u'\u5341', 'bar': [u'baz', {'foofoo': u'\u5341\u5341'}]}
    assert container_to_text(container_to_bytes(my_dict)) == {'foo': u'\u5341', 'bar': [u'baz', {'foofoo': u'\u5341\u5341'}]}



# Generated at 2022-06-20 16:19:23.803821
# Unit test for function to_native
def test_to_native():
    assert to_native(None) is None
    assert to_native(1) == 1
    assert to_native(to_text('abc')) == 'abc'
    assert to_native(to_bytes('abc')) == b'abc'
    assert to_native(dict(a=to_text('abc'))) == dict(a='abc')
    assert to_native(dict(a=to_bytes('abc'))) == dict(a=b'abc')
    assert to_native(to_bytes('\u2603')) == b'\xe2\x98\x83'
    if not PY3:
        assert to_native(u'abc') == 'abc'

# Generated at 2022-06-20 16:19:30.703639
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text('foo', 'utf-8') == u'foo'
    assert container_to_text(u'foo', 'utf-8') == u'foo'
    assert container_to_text('foo', 'utf-16') == u'foo'
    assert container_to_text(u'foo', 'utf-16') == u'foo'

    assert container_to_text(b'foo', 'utf-16') == u'foo'
    assert container_to_text(b'foo', 'utf-8') == u'foo'

    assert container_to_text(['a', u'b', b'c', 1], 'utf-8') == [u'a', u'b', u'c', 1]

# Generated at 2022-06-20 16:19:39.024680
# Unit test for function container_to_bytes
def test_container_to_bytes():
    result = container_to_bytes(dict(a='foo', b='bar'))
    assert(result == dict(a=b'foo', b=b'bar'))
    result = container_to_bytes(dict(a='föö', b='b$r'))
    assert(result == dict(a=b'f\xc3\xb6\xc3\xb6', b=b'b$r'))
    list_of_dict = [dict(a='föö', b='b$r'), dict(a='fôo', b='bár')]
    result = container_to_bytes(list_of_dict)

# Generated at 2022-06-20 16:19:44.307290
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_data = {
        'ascii_bytes': b'ascii_bytes',
        'unicode_str': u'unicode_str'
    }
    assert container_to_bytes(test_data) == {
        'ascii_bytes': b'ascii_bytes',
        'unicode_str': b'unicode_str'
    }

    # for python 2, surrogateescape does not work with json.dumps
    if PY2:
        target_encoding = 'latin-1'
        target_errors = 'surrogatepass'
    else:
        target_encoding = 'utf-8'
        target_errors = 'surrogateescape'

    # Handle mixed dict

# Generated at 2022-06-20 16:19:54.995117
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.compat.tests import unittest

    class TestToBytes(unittest.TestCase):
        def test_to_bytes_passthru(self):
            self.assertEqual(to_bytes(1, nonstring='passthru'), 1)
            self.assertEqual(to_bytes(1j, nonstring='passthru'), 1j)
            self.assertEqual(to_bytes(None, nonstring='passthru'), None)

        def test_to_bytes_strict(self):
            self.assertRaises(TypeError, to_bytes, set(), nonstring='strict')
            self.assertRaises(TypeError, to_bytes, [], nonstring='strict')
            self.assertRaises(TypeError, to_bytes, {}, nonstring='strict')
            self

# Generated at 2022-06-20 16:19:57.159203
# Unit test for function to_bytes
def test_to_bytes():
    ''' a function to run unit tests on the to_bytes function'''
    pass



# Generated at 2022-06-20 16:20:05.131578
# Unit test for function container_to_text
def test_container_to_text():
    # Test dict
    dict_to_text = {
        u'key1': u'value1',
        b'key2': b'value2',
        u'key3': [u'item1', b'item2', 3],
        b'key4': [u'item1', b'item2', 3],
        u'key5': (u'item1', b'item2', 3),
        b'key6': (u'item1', b'item2', 3),
        u'key7': {u'key1': u'value1', b'key2': b'value2'},
        b'key8': {u'key1': u'value1', b'key2': b'value2'}
    }

# Generated at 2022-06-20 16:20:16.696377
# Unit test for function container_to_text
def test_container_to_text():
    assert to_text(container_to_text([{'bytes':1}], errors='surrogate_then_replace')) == '[{"bytes": 1}]'
    assert to_text(container_to_text({'bytes':b'a\xed'}, errors='surrogate_then_replace')) == '{"bytes": "a\uFFFD"}'
    assert to_text(container_to_text([[b'a\xed'], [b'a\xed']], errors='surrogate_then_replace')) == '[[\'a\uFFFD\'], [\'a\uFFFD\']]'

# Generated at 2022-06-20 16:20:23.228155
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.six import binary_type, text_type
    try:
        from datetime import datetime
    except ImportError:
        datetime = None

    assert jsonify([1, 2]) == '[1, 2]'
    assert jsonify({"blah": "foo"}) == '{"blah": "foo"}'
    assert jsonify({"blah": {'baz': 'foo'}}) == '{"blah": {"baz": "foo"}}'
    assert jsonify({"blah": ['foo']}) == '{"blah": ["foo"]}'
    assert jsonify({"blah": [1]}) == '{"blah": [1]}'
    assert jsonify({"blah": []}) == '{"blah": []}'

# Generated at 2022-06-20 16:20:33.792625
# Unit test for function to_native
def test_to_native():
    class Foo(object):
        def __repr__(self):
            return 'foo'


# Generated at 2022-06-20 16:20:51.794566
# Unit test for function container_to_text
def test_container_to_text():
    data = []
    assert container_to_text(data) == data
    assert container_to_text(data, encoding='utf-8', errors='surrogate_or_strict') == data
    assert container_to_text(data, encoding='utf-8', errors='surrogate_or_replace') == data
    assert container_to_text(data, encoding='utf-8', errors='surrogate_then_replace') == data

    data = {}
    assert container_to_text(data) == data
    assert container_to_text(data, encoding='utf-8', errors='surrogate_or_strict') == data
    assert container_to_text(data, encoding='utf-8', errors='surrogate_or_replace') == data

# Generated at 2022-06-20 16:20:59.657802
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    # test int type
    assert to_native(1) == 1
    # test long type
    assert to_native(long(1)) == 1
    # test bool type
    assert to_native(True)
    assert not to_native(False)
    # test list type
    assert to_native([1, 2]) == [1, 2]
    # test dict type
    assert to_native({'key': 1}) == {'key': 1}
    # test scalar types
    assert to_native("string") == "string"
    # test datetime type
    if PY3:
        from datetime import datetime

# Generated at 2022-06-20 16:21:02.863753
# Unit test for function jsonify
def test_jsonify():
    data_dict = {'a': {'b': 'aaa'}, 'c': 'bbb'}
    assert jsonify(data_dict) == '{"a": {"b": "aaa"}, "c": "bbb"}'

# Generated at 2022-06-20 16:21:13.271047
# Unit test for function to_native
def test_to_native():
    assert( b'foo' == to_bytes(u'foo'))
    assert(to_bytes(b'foo') == b'foo')
    assert(to_bytes('foo') == b'foo')

    assert(u'foo' == to_text(u'foo'))
    assert(to_text(b'foo') == u'foo')
    assert(to_text('foo') == u'foo')

    assert(u'foo' == to_native(u'foo'))
    assert(to_native(b'foo') == u'foo')
    assert(to_native('foo') == u'foo')

    assert(b'foo' == to_bytes(u'foo', nonstring='passthru'))
    assert(to_bytes(b'foo', nonstring='passthru') == b'foo')


# Generated at 2022-06-20 16:21:16.148624
# Unit test for function to_native
def test_to_native():
    """
    Like to_text, but returns the native string type of the system.
    """
    if PY3:
        return to_text
    else:
        return to_bytes


# Generated at 2022-06-20 16:21:22.378238
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {
        u'aa': 1,
        u'bb': [True, False],
        u'cc': [1, 2, 3],
        u'dd': [4, 5, 6],
        u'ee': {u'foo': u'bar'}
    }
    assert container_to_bytes(d, encoding='utf-8') == {b'aa': 1, b'bb': [True, False], b'cc': [1, 2, 3], b'dd': [4, 5, 6], b'ee': {b'foo': b'bar'}}



# Generated at 2022-06-20 16:21:32.881265
# Unit test for function jsonify
def test_jsonify():
    data = {
        u'a': u'\u00e9',
        u'b': {u'c': {u'd':u'\u00e9'}},
        u'list': [1, 2, 3, {u'c': {u'd':u'\u00e9'}}],
        u'list_raw': [1, 2, 3, {'c': {'d':'\u00e9'}}],
        u'dict': {'a': 1, 'b': {'c': '\u00e9'}, 'c': [1, 2, '\u00e9', {'c': '\u00e9'}]},
    }
    for k, v in iteritems(data):
        assert v == json.loads(jsonify(v))

# Generated at 2022-06-20 16:21:40.410652
# Unit test for function jsonify
def test_jsonify():
    value1 = {to_bytes('v1', encoding='utf-8'): to_bytes('v2', encoding='utf-8')}
    value2 = {to_bytes('v1', encoding='latin-1'): to_bytes('v2', encoding='latin-1')}
    assert jsonify(value1) == '{"v1": "v2"}'
    assert jsonify(value2) == '{"v1": "v2"}'
    value1 = {to_text('v1', encoding='utf-8'): to_text('v2', encoding='utf-8')}
    value2 = {to_text('v1', encoding='latin-1'): to_text('v2', encoding='latin-1')}
    assert jsonify(value1) == '{"v1": "v2"}'

# Generated at 2022-06-20 16:21:49.971700
# Unit test for function to_native
def test_to_native():

    assert to_native("foo") == "foo"

    assert to_native(u"foo") == "foo"
    assert to_native(u"foo".encode("utf-8")) == "foo"
    assert to_native(u"foo".encode("latin-1")) == u"foo".encode("latin-1")

    assert to_native(123) == '123'
    assert to_native(123, nonstring='strict') == '123'
    assert to_native([1,2,3]) == '[1, 2, 3]'
    assert to_native([1,2,3], nonstring='strict') == '[1, 2, 3]'
    assert to_native(['a', 'b', 'c']) == "['a', 'b', 'c']"

# Generated at 2022-06-20 16:21:53.531404
# Unit test for function jsonify
def test_jsonify():
    source = {u'unicode_key': u'unicode_value'}
    result = jsonify(source)
    expected = u'{"unicode_key": "unicode_value"}'
    assert result == expected, 'should be a string with same content'
    assert isinstance(result, text_type), 'always return a unicode object (str on Python3)'



# Generated at 2022-06-20 16:22:15.860710
# Unit test for function to_native

# Generated at 2022-06-20 16:22:24.779266
# Unit test for function container_to_text
def test_container_to_text():
    j = {
        'a': {
            'b': {
                'c': 'foo'
            }
        },
        'd': 'bar',
        'f': {
            'g': [
                'foo',
                u'b\xe4r',
                'baz',
                {"caf\xe9": "qux"}
            ]
        },
        'h': 'baz',
    }
    j_utf8 = copy.deepcopy(j)
    j_utf8['f']['g'][1] = 'b\xc3\xa4r'
    j_utf8['f']['g'][3]['caf\xc3\xa9'] = 'qux'

# Generated at 2022-06-20 16:22:35.572316
# Unit test for function to_native
def test_to_native():
    from itertools import product

    def check_to_native(value, expected):
        result = to_native(value)
        if result != expected:
            print(('Error: %r should be %r is %r' % (value, expected, result)))

    def check_to_native_raises(value, exception):
        try:
            result = to_native(value)
        except exception:
            pass
        else:
            print(('Error: %r should have raised %r and gave %r' % (value, exception, result)))

    origin_platform = sys.platform

# Generated at 2022-06-20 16:22:46.628154
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we return bytes of the proper encoding
    assert b'123' == to_bytes(u'123')
    assert b'123' == to_bytes(u'123', encoding='ascii')
    assert b'123' == to_bytes(u'123', encoding='latin1')
    assert b'123' == to_bytes(u'123', encoding='utf-8')
    assert b'123' == to_bytes(u'123', encoding='utf-8', errors='surrogate_or_replace')
    assert b'123' == to_bytes(u'123', encoding='utf-8', errors='surrogate_or_strict')

    # Test that we return bytes of the proper encoding even if they are non-ascii

# Generated at 2022-06-20 16:22:52.888007
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.six import PY2
    from collections import OrderedDict

    print("Default to_bytes")
    assert to_bytes('jose') == b'jose'
    assert to_bytes('Jose') == b'Jose'
    assert to_bytes(b'jose') == b'jose'

    assert to_bytes(u'Йóśé') == b'\xd0\x99\xc3\xb3\xc5\x9b\xc3\xa9'
    assert to_bytes(u'\u05c1\u05b8\u05b5\u05b9\u05b1') == b'\xd7\x81\xd7\xb8\xd7\xb5\xd7\xb9\xd7\xb1'
    assert to_

# Generated at 2022-06-20 16:23:02.241056
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({}) == {}
    assert container_to_bytes([]) == []
    assert container_to_bytes(()) == ()
    assert container_to_bytes(['a', u'b', 'c']) == [b'a', b'b', b'c']
    assert container_to_bytes({'a': u'b', 'c': 'd', 'e': [u'f', 'g']}) == {b'a': b'b', b'c': b'd', b'e': [b'f', b'g']}

# Generated at 2022-06-20 16:23:08.537113
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'foo',
            'b': b'bar',
            'c': u'b\u00e4z',
            'd': [1, 2, 3],
            'e': {'ein': [1, 2, 3],
                  'zwei': {1: 2},
                  'drei': b'bar'},
            'f': {u'b\u00e4r': 'baz',
                  'bar': u'b\u00e4z',
                  b'baz': {u'b\u00e4r': b'baz'}}}
    assert jsonify(data) == json.dumps(data, default=_json_encode_fallback)


# Generated at 2022-06-20 16:23:13.934662
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(dict(hello=b'world')) == dict(hello=u'world')
    assert container_to_text([b'hello', b'world']) == [u'hello', u'world']
    assert container_to_text((b'hello', b'world')) == (u'hello', u'world')


# Generated at 2022-06-20 16:23:24.739356
# Unit test for function to_bytes
def test_to_bytes():
    # Make sure that it turns a unicode string containing unicode chars into a
    # UTF-8 encoded bytestring, but that it skips over non-unicode strings
    def check_to_bytes(value, expected_output, encoding='utf-8', errors='strict', nonstring='simplerepr'):
        # pylint: disable=redefined-outer-name
        """Helper function to execute the test"""
        assert isinstance(value, str)
        assert isinstance(expected_output, binary_type)

        outvalue = to_bytes(value, encoding=encoding, errors=errors, nonstring=nonstring)
        assert isinstance(outvalue, binary_type)
        assert outvalue == expected_output

    # Test each nonstring setting

    # SimpleRepr works like str()

# Generated at 2022-06-20 16:23:35.270491
# Unit test for function to_bytes
def test_to_bytes():
    import sys
    import unittest

    # unicode strings with surrogates are only available in Python 2
    if PY3:
        uni_string = u'hi there'
    else:
        uni_string = u'hi there \U0001f4a9'

    def surrogate_error_handler(errors):
        def surr_handler(exception):
            b = u''.join(map(unichr, range(0xD800, 0xE000))).encode('utf-8', errors)
            return b, exception.end
        return surr_handler

    class ToBytesTest(unittest.TestCase):
        '''
        Tests for code in to_bytes
        '''


# Generated at 2022-06-20 16:23:49.183556
# Unit test for function jsonify
def test_jsonify():
    jsonify(dict(key=set([1, 2, 3])))
    jsonify(dict(key=set(['a', 'b', 'c'])))
    jsonify(dict(key=set([u'abc', 'def', 'ghi'])))
    jsonify(dict(key_d=datetime.datetime(2017, 1, 1, 10, 10)))



# Generated at 2022-06-20 16:24:00.717861
# Unit test for function container_to_text
def test_container_to_text():
    # Setup test data
    test_dict_1 = {b'key': b'value'}
    test_dict_2 = {u'key': u'value', b'key2': b'value'}
    test_list_1 = [b'value']
    test_list_2 = [u'value', b'value']
    test_tuple_1 = (b'value',)
    test_tuple_2 = (u'value', b'value')

    # Test Test 1: Single level dict
    # Expected Result: Dict with all values converted to unicode
    assert container_to_text(test_dict_1) == {u'key': u'value'}

    # Test Test 2: Single level dict whith unicode type
    # Expected Result: Dict with all values converted to unicode

# Generated at 2022-06-20 16:24:11.817134
# Unit test for function to_native
def test_to_native():
#    print(to_native('\xe2\x80\x99s the way to go'))
    print(15*'=')
    print(u'\u2122'.encode('utf-8'))
    print(to_bytes(u'\u2122'))

# Generated at 2022-06-20 16:24:21.944776
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' container_to_bytes unit test'''

    # Test conversion of dict
    # Test an all text dict and an all bytes dict, a dict of dicts, and a
    # dict of lists
    test_dict = {'a': u'b'}
    result_dict = container_to_bytes(test_dict)
    assert isinstance(result_dict, dict)
    for k in result_dict.keys():
        assert isinstance(k, binary_type)
        assert isinstance(result_dict[k], binary_type)

    test_dict = {b'a': b'b'}
    result_dict = container_to_bytes(test_dict)
    assert isinstance(result_dict, dict)
    for k in result_dict.keys():
        assert isinstance(k, binary_type)

# Generated at 2022-06-20 16:24:24.502293
# Unit test for function to_native
def test_to_native():
	str1 = to_native('str')
	str2 = to_native('str','utf-8','strict')
	assert isinstance(str1,str)
	assert isinstance(str2,str)
	assert str1 == 'str'
	assert str2 == 'str'

# Generated at 2022-06-20 16:24:31.576378
# Unit test for function container_to_bytes
def test_container_to_bytes():
    data = {'foo': 'bar'}
    assert container_to_bytes(data) == {b'foo': b'bar'}
    data = {'foo': ['bar', 'baz']}
    assert container_to_bytes(data) == {b'foo': [b'bar', b'baz']}



# Generated at 2022-06-20 16:24:40.939698
# Unit test for function jsonify
def test_jsonify():
    from ansible.compat.tests import mock
    from ansible.compat.tests.mock import patch
    import datetime

    true_values = [True, 'true', 'True', 'yes', '1']
    for t in true_values:
        with patch.object(json, 'dumps') as mock_dumps:
            jsonify(t)
            mock_dumps.assert_called_with(True, encoding='utf-8', default=_json_encode_fallback)

    false_values = [False, 'false', 'False', 'no', '0']
    for f in false_values:
        with patch.object(json, 'dumps') as mock_dumps:
            jsonify(f)

# Generated at 2022-06-20 16:24:51.335849
# Unit test for function jsonify
def test_jsonify():
    new_data = {
        'a': 'hello',
        'b': [
            'world',
            'ansible'
        ],
        'c': {
            'new': 'test'
        }
    }
    # unicode string, should not raise any exception
    jsonify(new_data)
    new_data['a'] = u'\u20ac'
    # unicode string, should not raise any exception
    jsonify(new_data)
    new_data['a'] = '\xe2\x82\xac'
    # latin-1 encoded string, should not raise any exception
    jsonify(new_data)
    new_data['a'] = '\xe2\x82\xac'.decode('utf-8')
    # utf-8 encoded string, should not raise any exception


# Generated at 2022-06-20 16:24:59.928163
# Unit test for function to_bytes
def test_to_bytes():
    b = to_bytes
    # Idiomatic use
    assert b('foo') == b('foo')
    assert b('foo', errors='surrogate_or_replace') == b('foo')
    assert b('foo', errors='surrogate_then_replace') == b('foo')
    assert b(b'foo') == b'foo'

    # Some use examples from the docstring
    assert b(b'foo', encoding='ascii') == b'foo'
    assert b(b'foo', encoding='ascii', errors='ignore') == b'foo'
    assert b(u'foo', encoding='ascii', errors='surrogate_or_replace') == b'foo'
    assert b(u'foo', encoding='ascii', errors='surrogate_then_replace') == b'foo'
   

# Generated at 2022-06-20 16:25:12.040354
# Unit test for function container_to_text
def test_container_to_text():
    my_dict = {u"list": [u"item 1", u"item 2"],
               u"string": u"some text",
               u"float": 4.5,
               u"integer": 3}
    my_dict_encoded = container_to_text(my_dict)
    # Test if values are converted
    assert my_dict_encoded['list'][0] == "item 1"
    assert my_dict_encoded['list'][1] == "item 2"
    assert my_dict_encoded['string'] == "some text"
    assert my_dict_encoded['float'] == 4.5
    assert my_dict_encoded['integer'] == 3
    # Test if values are converted in the original dict
    assert isinstance(my_dict['list'][0], text_type)