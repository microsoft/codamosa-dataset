

# Generated at 2022-06-20 16:15:45.359615
# Unit test for function to_native
def test_to_native():

    def _test_to_native_string(obj, result):
        assert to_native(obj) == result
        assert to_native(obj, errors='surrogate_or_strict') == result
        assert to_native(obj, errors='surrogate_or_replace') == result
        assert to_native(obj, errors='surrogate_then_replace') == result
        assert to_native(obj, errors='surrogateescape') == result
        assert to_native(obj, encoding='ascii') == result
        assert to_native(obj, encoding='ascii', errors='surrogate_or_strict') == result
        assert to_native(obj, encoding='ascii', errors='surrogate_or_replace') == result

# Generated at 2022-06-20 16:15:54.664695
# Unit test for function to_bytes
def test_to_bytes():
    import pytest
    from ansible.module_utils.six import text_type


    unicode_value = u'\u00fc'
    utf8_value = b'\xc3\xbc'
    latin1_value = b'\xfc'

    assert to_bytes(utf8_value) == to_bytes(utf8_value, errors='surrogate_or_strict')
    assert to_bytes(utf8_value) == to_bytes(utf8_value, errors='surrogate_or_replace')
    assert to_bytes(utf8_value) == to_bytes(utf8_value, errors='surrogate_then_replace')
    assert to_bytes(utf8_value) == to_bytes(utf8_value, errors=None)

# Generated at 2022-06-20 16:16:03.801270
# Unit test for function to_native
def test_to_native():
    assert to_native(u'spam') == u'spam'
    assert to_native(b'spam') == u'spam'
    assert to_native('spam') == u'spam'
    assert to_native(u"¥") == u"¥"
    assert to_native(u"\u5bae\u6708") == u"\u5bae\u6708"
    assert to_native(b"\xe5\xae\xb4\xe6\x97\xa5") == u"\u5bae\u65e5"
    assert to_native(b"\xc2\xa3", encoding='utf-8') == u"£"
    assert to_native(b"\xa3", encoding='latin1') == u"£"

    # Ignore explicitly

# Generated at 2022-06-20 16:16:10.003999
# Unit test for function to_bytes
def test_to_bytes():
    # Test that a byte string is returned unmodified
    assert b'hello' == to_bytes(b'hello')
    assert b'hello' == to_bytes(b'hello', 'ascii', 'surrogate_or_strict')
    assert b'hello' == to_bytes(b'hello', 'ascii', 'surrogate_or_replace')
    assert b'hello' == to_bytes(b'hello', 'ascii', 'surrogate_then_replace')

    assert b'hello' == to_bytes(b'hello', nonstring='passthru')

    # Ensure a utf-8 encoded string is returned as a byte string
    assert b'hello' == to_bytes('hello')
    assert b'\xc3\xa1' == to_bytes('\xe1')

# Generated at 2022-06-20 16:16:18.865952
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(b'foo') == b'foo'
    assert container_to_bytes(bytearray(b'foo')) == b'foo'
    assert container_to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    assert container_to_bytes(u'\xac', encoding='latin-1') == b'\xac'
    assert container_to_bytes(u'\xac', encoding='ascii', errors='replace') == b'?'
    assert container_to_bytes(u'\u0394') == b'?'
    assert container

# Generated at 2022-06-20 16:16:22.964634
# Unit test for function jsonify
def test_jsonify():
    test = "test"
    assert test == json.loads(jsonify(test))

    test2 = [1, 2, 3, 4, 5]
    assert test2 == json.loads(jsonify(test2))

    test3 = {'a': 1, 'b': 2}
    assert test3 == json.loads(jsonify(test3))

    test4 = Set(['a', 'b', 'c'])
    assert test4 == json.loads(jsonify(test4))



# Generated at 2022-06-20 16:16:32.094381
# Unit test for function to_native
def test_to_native():
    for test_input, test_output in _to_native_outputs:
        yield check_output, test_input, test_output



# Generated at 2022-06-20 16:16:43.955496
# Unit test for function container_to_text
def test_container_to_text():
    # Test for text_type
    input = 'string'
    output = container_to_text(input)
    assert isinstance(output, text_type)
    # Test for default param
    input = u'红色'
    output = container_to_text(input)
    assert isinstance(output, text_type)
    # Test for list
    input = [u'红色', u'黑色']
    output = container_to_text(input)
    assert isinstance(output, list)
    assert isinstance(output[0], text_type)
    # Test for tuple
    input = (u'红色', u'黑色')
    output = container_to_text(input)
    assert isinstance(output, tuple)


# Generated at 2022-06-20 16:16:52.496959
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text("hello world") == "hello world"
    assert container_to_text("hello world".encode("ascii")) == "hello world"
    assert container_to_text({'a': 'b'}) == {'a': 'b'}
    assert container_to_text({'a': 'b'.encode("ascii")}) == {'a': 'b'}
    assert container_to_text([1,2,3]) == [1,2,3]
    assert container_to_text([1,2,3]),[1,2,3]
    assert container_to_text((1,2,3)) == (1,2,3)
    assert container_to_text((1,2,3),[1,2,3])


# Generated at 2022-06-20 16:16:58.705466
# Unit test for function container_to_bytes
def test_container_to_bytes():
    class myunicode(unicode):
        pass

    assert isinstance(container_to_bytes(u'unicode'), bytes)
    assert isinstance(container_to_bytes(myunicode('unicode')), bytes)
    assert container_to_bytes(u'unicode') == 'unicode'
    assert container_to_bytes(myunicode('unicode')) == 'unicode'
    assert container_to_bytes({u'unicode': u'unicode'}) == {'unicode': 'unicode'}
    assert container_to_bytes({myunicode('unicode'): myunicode('unicode')}) == {'unicode': 'unicode'}

# Generated at 2022-06-20 16:17:19.362935
# Unit test for function to_bytes
def test_to_bytes():
    from nose.tools import assert_equal, assert_raises
    assert_equal(b'', to_bytes(None))
    assert_equal(b'', to_bytes(None, 'latin-1'))
    assert_equal(b'', to_bytes(None, 'latin-1', 'surrogateescape'))
    assert_equal(b'', to_bytes(None, 'latin-1', 'surrogate_or_replace'))
    assert_equal(b'', to_bytes(None, 'latin-1', 'surrogate_or_strict'))
    assert_equal(b'', to_bytes(None, 'latin-1', 'surrogate_then_replace'))

    assert_equal(b'', to_bytes(''))

# Generated at 2022-06-20 16:17:31.308815
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Create a dict that is encoded in utf-8 and has a unicode dict key in it
    # Since dict keys are used to index the dict we can just use the same
    # code to iterate the dict keys and values.
    enc_string1 = u"\u00E9"
    enc_string2 = u"\u00E9"
    enc_dict_key = u"\u00E9"
    enc_dict_value = u"\u00E9"
    test_dict = {}
    test_dict[enc_dict_key] = enc_dict_value
    byte_dict = container_to_bytes(test_dict)
    for key,value in iteritems(byte_dict):
        # Check that the dict key and value are byte strings and are encoded
        # in utf-8
        assert isinstance

# Generated at 2022-06-20 16:17:41.097489
# Unit test for function to_native
def test_to_native():
    check_convert(42, '42')
    check_convert('42', '42')
    check_convert(b'42', '42')
    check_convert(None, 'None')
    check_convert(u'\u1234', '\\u1234')
    check_convert('\u1234', '\u1234')
    check_convert(b'\x80abc', '\\x80abc')
    check_convert(b'\xc3\x80abc', 'Àabc')
    check_convert(b'\xc3\x80abc'.decode('utf8'), 'Àabc')
    check_convert(b'\xc3\x80abc', 'Àabc')

# Generated at 2022-06-20 16:17:52.487795
# Unit test for function container_to_bytes
def test_container_to_bytes():

    # Test strings
    test_string_unicode = u'\u5317\u4EB0'
    test_string_bytes = b'\xe5\x8c\x97\xe4\xba\xb0'
    test_string_wrong_bytes = b'\xac\xe5\x8c\x97\xe4\xba\xb0'

    # Test string in list
    test_list = [test_string_unicode]
    assert test_list == container_to_bytes(test_list)
    assert [test_string_bytes] == container_to_bytes(test_list, encoding='utf-8')
    assert [test_string_wrong_bytes] == container_to_bytes(test_list, encoding='utf-8', errors='ignore')

    # Test string in tuple
    test_

# Generated at 2022-06-20 16:17:57.637766
# Unit test for function container_to_bytes
def test_container_to_bytes():
    b = container_to_bytes({u'test': u'foo', u'bar': [1, 2, 3], u'baz': {u'x': 1, u'y': 2, u'z': 3}})
    assert isinstance(b, dict)
    for key in b:
        assert isinstance(key, binary_type)
        assert isinstance(b[key], (binary_type, int))



# Generated at 2022-06-20 16:18:07.663716
# Unit test for function to_bytes

# Generated at 2022-06-20 16:18:18.012766
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert (container_to_bytes("\xe9") == b"\xc3\xa9")
    assert (container_to_bytes(["\xe9"]) == [b"\xc3\xa9"])
    assert (container_to_bytes(("\xe9",)) == (b"\xc3\xa9",))
    assert (container_to_bytes({b"a": "\xe9"}) == {b"a": b"\xc3\xa9"})
    assert (container_to_bytes({u"a": b"\xc3\xa9"}) == {b"a": b"\xc3\xa9"})
    assert (container_to_bytes({u"a": "\xe9"}) == {b"a": b"\xc3\xa9"})

# Generated at 2022-06-20 16:18:27.944578
# Unit test for function to_bytes
def test_to_bytes():
    assert b'foo' == to_bytes('foo')
    assert b'foo' == to_bytes(u'foo')
    assert b'\xff' == to_bytes(b'\xff')
    assert b'foo' == to_bytes(b'foo')
    assert b'foo' == to_bytes(b'foo', 'ascii')
    assert to_bytes('\xe9') == b'\xc3\xa9'
    assert to_bytes(u'\xe9', errors='replace') == b'?'
    assert to_bytes(u'\xe9', errors='surrogateescape') == b'\xe9'
    assert to_bytes(u'\udcff') == b'\xed\xb3\xbf'

# Generated at 2022-06-20 16:18:33.604921
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes([
        {'list': [1, 2],
         'dict': {u'foo': 'bar'}},
        u'unicode string'
    ]) == [{b'list': [1, 2],
            b'dict': {b'foo': b'bar'}}, b'unicode string']



# Generated at 2022-06-20 16:18:41.318555
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {'a': '\xe6\x96\x87\xe6\x9c\xac'}
    assert container_to_bytes(d) == {b'a': b'\xe6\x96\x87\xe6\x9c\xac'}
    assert container_to_bytes(d, encoding='ascii') == {b'a': b'??'}
    assert container_to_bytes(d, errors='replace') == {b'a': b'????'}
    d = ['\xe6\x96\x87\xe6\x9c\xac']
    assert container_to_bytes(d) == [b'\xe6\x96\x87\xe6\x9c\xac']

# Generated at 2022-06-20 16:18:59.969503
# Unit test for function to_bytes
def test_to_bytes():
    """
    Test the function to_bytes
    """
    # Test surrogate_or_replace and surrogate_or_strict
    from ansible.module_utils.six import u

# Generated at 2022-06-20 16:19:09.359992
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(1) == '1'
    assert to_native([1, u'2']) == '[1, 2]'
    assert to_native({1: {u'2': [u'3', u'4']}}) == '{1: {2: [3, 4]}}'
    assert to_native(datetime.datetime(2016, 2, 20, 19, 31, 33, 123456)) == '2016-02-20 19:31:33.123456'



# Generated at 2022-06-20 16:19:17.751219
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native('\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    #assert to_native(u'嗨') == u'嗨'
    #assert to_native('嗨') == u'嗨'
    #assert to_native(b'\xe5\x97\xa8') == u'嗨'
    

# Generated at 2022-06-20 16:19:23.071430
# Unit test for function jsonify
def test_jsonify():
    data = {"a":to_text('\xe5', 'latin-1')}
    x = jsonify(data)
    res = json.loads(x)
    assert res == data
    data = to_text('\xe5', 'latin-1')
    assert jsonify(data) == to_text(data)
    assert jsonify(to_text(data, 'unicode_escape')) == data



# Generated at 2022-06-20 16:19:30.929363
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import _json_encode_default
    data = {'x': "hi\u20ac there"}
    encoded_json = jsonify(data)
    assert json.loads(encoded_json) == {"x": "hi\u20ac there"}
    assert _json_encode_default(data) == {"x": "hi\u20ac there"}

    data = {'x': "hi\xa3 there"}
    encoded_json = jsonify(data)
    assert json.loads(encoded_json) == {"x": "hi\xa3 there"}
    assert _json_encode_default(data) == {"x": "hi\xa3 there"}



# Generated at 2022-06-20 16:19:38.870928
# Unit test for function to_native
def test_to_native():
    """
    Return native string
    type from bytes or unicode on both Py2 and Py3.
    Usage:
        "unicode".encode('utf-8') => b'unicode'
        b'bytes'.decode('utf-8')  => u'bytes'
        u'unicode'                => u'unicode'
        b'bytes'                  => b'bytes'
    """
    def utf8(s):
        return s if isinstance(s, binary_type) else s.encode('utf-8')
    def u(s):
        return s if isinstance(s, text_type) else s.decode('utf-8')
    assert u('unicode') == to_native(u('unicode'))
    assert b'bytes' == to_native(b'bytes')

# Generated at 2022-06-20 16:19:43.263346
# Unit test for function jsonify
def test_jsonify():
    data = {"one": 1, "two": u'\u2020', "three": [{"spam": 1}, {"eggs": None}, {"foo": "bar"}]}
    # u'\u2020' is a non-ascii character, which ressembles a double dagger. This charater is not in the encoding latin-1
    encoded_json = '{"one": 1, "two": "\\u2020", "three": [{"spam": 1}, {"eggs": null}, {"foo": "bar"}]}'
    # jsonify function should json encode all unicode characters in data
    assert jsonify(data) == encoded_json


# Generated at 2022-06-20 16:19:48.946009
# Unit test for function to_native
def test_to_native():
    class Foo(object):
        def __init__(self, val):
            self.val = val
        def __str__(self):
            return self.val
        def __repr__(self):
            return self.val
        def __eq__(self, other):
            return self.val == other

    class Bar(object):
        foo = Foo('str')

        def __str__(self):
            return self.foo.val
        def __repr__(self):
            return self.foo.val

    class FooUnicode(object):
        def __init__(self, val):
            self.val = val
        def __unicode__(self):
            return self.val
        def __repr__(self):
            return self.val
        def __eq__(self, other):
            return self

# Generated at 2022-06-20 16:19:53.944309
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(u'foo') == u'foo'
    assert container_to_text('foo') == u'foo'
    assert container_to_text(['foo']) == [u'foo']
    assert container_to_text(('foo',)) == (u'foo',)
    assert container_to_text({'foo': 'bar'}) == {u'foo': u'bar'}
    assert container_to_text({'foo': ['bar']}) == {u'foo': [u'bar']}
    assert container_to_text({'foo': ('bar',)}) == {u'foo': (u'bar',)}
    assert container_to_text({'foo': {'bar': 'baz'}}) == {u'foo': {u'bar': u'baz'}}



# Generated at 2022-06-20 16:20:02.183612
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=u'\u1234')) == '{"a": "\u1234"}'
    assert jsonify(dict(a=u'\u1234'), ensure_ascii=False) == '{"a": "\\u1234"}'
    assert jsonify(dict(a=u'\u1234'), ensure_ascii=False, encoding=None) == '{"a": "\\u1234"}'
    assert jsonify(dict(a=dict(b=u'\u1234'))) == '{"a": {"b": "\u1234"}}'
    assert jsonify(dict(a=dict(b=dict(c=u'\u1234')))) == '{"a": {"b": {"c": "\u1234"}}}'


# Generated at 2022-06-20 16:20:25.610139
# Unit test for function to_native
def test_to_native():
    # Make a string that has high bit characters
    original_text = u'café'

    # Encode it using the utf-8 codec
    encoded = original_text.encode('utf-8')

    # Encode it using the latin1 codec
    ords = [ord(x) for x in original_text]
    ords_latin1 = [x if x < 256 else 32 for x in ords]   # Replace anything >255 with space
    encoded_latin1 = bytes(bytearray(ords_latin1))

    assert encoded == b'caf\xc3\xa9'
    assert encoded_latin1 == b'caf\xe9'

    decoded_native = to_text(encoded_latin1, encoding='utf-8', errors='surrogate_or_strict')

# Generated at 2022-06-20 16:20:36.331276
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test dict
    d = {to_bytes('key1'): to_bytes('value1'),
         to_bytes('key2'): to_bytes('value2')}
    assert isinstance(d, dict)
    assert isinstance(list(iterkeys(d))[0], binary_type)
    assert isinstance(list(itervalues(d))[0], binary_type)
    d = {"key1": "value1", "key2": "value2"}
    assert isinstance(d, dict)
    assert isinstance(list(iterkeys(d))[0], text_type)
    assert isinstance(list(itervalues(d))[0], text_type)
    assert isinstance(container_to_bytes(d), dict)

# Generated at 2022-06-20 16:20:41.590438
# Unit test for function container_to_text
def test_container_to_text():
    print(container_to_text('1'))
    print(container_to_text(1))
    print(container_to_text(['1']))
    print(container_to_text({'a':'1'}))
    print(container_to_text(['1',{'a':'1'}]))
    print(container_to_text(('1',{'a':'1'})))

# Generated at 2022-06-20 16:20:53.300573
# Unit test for function container_to_text
def test_container_to_text():
    test_dict = {
        'dict': {'key1': 'value1', 'key2': 'value2'},
        'list': ['value3', 'value4'],
        'tuple': ('value5', 'value6'),
        'unicode': u'这是中文',
        'byte_utf8': '\xc0\x80',
        'byte_latin1': '\x80',
        'null': None,
        'integer': 1
    }

# Generated at 2022-06-20 16:21:02.863968
# Unit test for function container_to_text
def test_container_to_text():
    d = {b'key1': b'value1',
         b'key2': b'value2'}

    d = container_to_text(d)
    assert isinstance(d[u'key1'], text_type)
    assert isinstance(d[u'key2'], text_type)

    d = [{b'key1': b'value1'},
         {b'key2': b'value2'}]

    d = container_to_text(d)
    assert isinstance(d[0][u'key1'], text_type)
    assert isinstance(d[1][u'key2'], text_type)

    d = (b'value',)
    d = container_to_text(d)
    assert isinstance(d[0], text_type)



# Generated at 2022-06-20 16:21:11.495237
# Unit test for function container_to_bytes
def test_container_to_bytes():
    data = [dict(a=dict(b="foo"))]
    try:
        container_to_bytes(data)
    except UnicodeEncodeError:
        pass
    else:
        raise AssertionError('Expected UnicodeError')
    container_to_bytes(data, encoding='latin-1')
    data = dict(second={'a': ['b']})
    container_to_bytes(data)
    data = [1,2,3]
    container_to_bytes(data)
    data = (1,2,3)
    container_to_bytes(data)
    data = "test"
    container_to_bytes(data)



# Generated at 2022-06-20 16:21:20.758348
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(u"test") == u"test".encode('utf-8')
    assert container_to_bytes({u"key": u"value"}) == {b"key": u"value".encode('utf-8')}
    assert container_to_bytes([u"test", {u"key": u"value"}]) == [u"test".encode('utf-8'), {b"key": u"value".encode('utf-8')}]
    assert container_to_bytes((u"a", u"b", {u"key": u"value"})) == (u"a".encode('utf-8'), u"b".encode('utf-8'), {b"key": u"value".encode('utf-8')})

# Generated at 2022-06-20 16:21:32.394312
# Unit test for function to_bytes
def test_to_bytes():
    # Make sure byte strings are unchanged
    assert to_bytes(b'foo') == b'foo'

    # Simple strings should encode properly into byte strings
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'föo') == b'f\xc3\xb6o'

    # Nothing but strict should raise an exception on surrogate strings
    assert to_bytes(u'f\udce2o') == b'f\xed\xb3\xa2o'
    assert to_bytes(u'f\udce2o', errors='surrogate_or_strict') == b'f\xed\xb3\xa2o'

# Generated at 2022-06-20 16:21:40.085643
# Unit test for function jsonify
def test_jsonify():
    '''Tests for the jsonify function'''
    from ansible.module_utils._text import jsonify

    assert jsonify({'Hello': 'World'}) == '{\"Hello\": \"World\"}'
    assert jsonify(['Hello', 'World']) == '["Hello", "World"]'
    assert jsonify(123) == '123'
    assert jsonify("Hello World") == '"Hello World"'
    assert jsonify("Hello' World") == '"Hello\' World"'
    assert jsonify("Hello\nWorld\n") == '"Hello\\nWorld\\n"'
    assert jsonify("Hello\u1234World\u4321") == '"Hello\\u1234World\\u4321"'

    foo = Set(['test', 'bar'])

# Generated at 2022-06-20 16:21:49.797174
# Unit test for function to_bytes
def test_to_bytes():
    # The main thing we're testing for here is that the function works when
    # called from multiple threads.
    #
    # Yes, this is a silly way of doing that and a real test should fork and
    # use multiprocessing and do things properly.  But, to get the code coverage
    # to a useful level we need to call the function from multiple threads.

    # The test only works properly when the functions are imported so do the
    # import here where it can be tested.
    from ansible.module_utils.basic import to_bytes, to_text
    import ansible.module_utils.common.threading

    def _to_bytes_thread(obj, encoding, errors, nonstring):
        '''Helper function to call to_bytes from a thread'''
        return to_bytes(obj, encoding, errors, nonstring)

    #

# Generated at 2022-06-20 16:22:36.899065
# Unit test for function to_native
def test_to_native():
    assert to_native(b'ascii') == 'ascii'
    assert to_native(b'still ascii') == 'still ascii'
    utf8 = '{0} {1}'.format(codecs.decode('\xc5\x92', 'latin-1'), codecs.decode('\xc4\x9b', 'latin-1'))
    assert to_native(utf8.encode('utf-8')) == utf8
    assert to_native(b'\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e') == '\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e'

# Generated at 2022-06-20 16:22:47.763249
# Unit test for function container_to_bytes
def test_container_to_bytes():
    b_string = '{"foo": "bar", "baz": {"bat": ["bam", "bam", "bam", "bam"]}}'
    u_string = to_text(b_string)
    utf8_string = u_string.encode('utf-8')
    u_list = [u_string, [utf8_string]]
    u_dict = {u_string: {"foo": u_list}}
    assert container_to_bytes(u_dict) == json.loads(b_string)
    assert container_to_bytes(u_dict, encoding='utf-8') == json.loads(b_string)
    assert container_to_bytes(u_dict, encoding='utf-8', errors='replace') == json.loads(b_string)

# Generated at 2022-06-20 16:22:55.743763
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(
        foo='bar',
        baz=Set(['one', 'two', 'three']),
        qux=datetime.datetime(2015, 3, 9, 17, 30, 0)
    )) == """{"foo": "bar", "baz": ["one", "two", "three"], "qux": "2015-03-09T17:30:00"}"""


# Generated at 2022-06-20 16:23:04.334886
# Unit test for function container_to_text
def test_container_to_text():
    test_string = 'test'
    test_dict = {'test': 'test'}
    test_list = ['test']
    test_tuple = ('test',)
    test_utf = u'\xe4\xf6\xfc'

    assert container_to_text(test_string) == 'test'

    # Dicts are tricky to test because python will not necessarily order them
    # the same way that we input them.  We'll just assert that the return
    # contains the only two items that we put in
    returned_dict = container_to_text(test_dict)
    assert len(returned_dict) == 1
    assert 'test' in returned_dict
    assert returned_dict['test'] == u'test'

    # Same deal with lists

# Generated at 2022-06-20 16:23:10.370977
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo') != u'foo'
    if PY3:
        assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    else:
        assert to_bytes(u'\u1234') == '\xe1\x88\xb4'
        assert to_bytes(u'\u1234', errors='') == '\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_

# Generated at 2022-06-20 16:23:19.351912
# Unit test for function to_native
def test_to_native():
    assert to_native(b'test') == u'test'
    assert to_native(u'test') == u'test'
    assert to_native(b'test', errors='surrogate_or_strict') == u'test'
    assert to_native(u'test', errors='surrogate_or_strict') == u'test'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_or_strict') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_or_replace') == u'?'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_then_replace') == u'?'

# Generated at 2022-06-20 16:23:32.949933
# Unit test for function jsonify
def test_jsonify():
    # Test data in utf-8 format
    data = u'key1:value1,key2:value2,key3:value3,key4:value4,key5:value5'
    data = dict(x.split(':') for x in data.split(','))
    ret = jsonify(data)
    assert type(ret) is text_type
    assert ret == '{"key1": "value1", "key2": "value2", "key3": "value3", "key4": "value4", "key5": "value5"}'

    # Test data in latin-1 format
    data = u'key1:value1,key2:value2,key3:value3,key4:value4,key5:value5'.encode('latin-1')

# Generated at 2022-06-20 16:23:39.256975
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('abc') == b'abc'
    assert to_bytes(b'abc') == b'abc'
    assert to_bytes(u'abc') == b'abc'
    assert to_bytes(u'©') == b'\xc2\xa9'
    assert to_bytes(u'©', encoding='ascii') == b'\xe2\x80\xa8'
    assert to_bytes(u'©', errors='surrogate_or_strict') == b'\xe2\x80\xa8'
    assert to_bytes(u'©', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'©\xFF', errors='surrogate_then_replace') == b'?'
    assert to_bytes(u'©', errors='ignore')

# Generated at 2022-06-20 16:23:49.815621
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {u'a': u'a', u'b': [1, 2, 3], u'c': {u'd': u'e'}}
    e = {b'a': u'a', b'b': [1, 2, 3], b'c': {b'd': u'e'}}
    assert container_to_bytes(d) == e
    assert container_to_bytes(d, errors='surrogate_or_replace') == e
    assert container_to_bytes(d, errors='surrogate_or_strict') == e
    assert container_to_bytes(d, errors='surrogate_then_replace') == e
    assert container_to_bytes(d, errors='ignore') == e
    assert container_to_bytes(d, errors='replace') == e

# Generated at 2022-06-20 16:24:00.818293
# Unit test for function to_bytes
def test_to_bytes():
    try:
        # Ensure that surrogateescape is *not* registered on Python2
        codecs.lookup_error('surrogateescape')
    except LookupError:
        pass

    assert to_bytes('foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(1) == b'1'
    assert to_bytes(None) == b''
    assert to_bytes(u'foø') == b'fo\xc3\xb8'
    assert to_bytes(u'foø', 'latin-1') == b'fo\xf8'
    assert to_bytes(u'foø', 'latin-1', 'surrogate_or_replace') == b'fo\xf8'

# Generated at 2022-06-20 16:24:27.886176
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.six import BytesIO
    f = BytesIO()
    jsonify(f,ensure_ascii=False)

if PY3:
    def container_to_bytes(value):
        if isinstance(value, dict):
            return dict((k, to_bytes(v)) for k, v in iteritems(value))

        if isinstance(value, list):
            return [to_bytes(v) for v in value]

        if isinstance(value, tuple):
            return tuple(to_bytes(v) for v in value)

        return value
else:
    container_to_bytes = container_to_text = lambda x: x



# Generated at 2022-06-20 16:24:34.051753
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({u"\u738b\u82f1": "fu"}) == '{"\xe7\x8e\x8b\xe8\x8b\xb1": "fu"}'
    assert jsonify({u"\u738b\u82f1": "fu"}) == u'{"\u738b\u82f1": "fu"}'


# Generated at 2022-06-20 16:24:42.735268
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=u"\u1337")) == '{"a": "\\\\u1337"}'
    assert jsonify(dict(a=to_native("\xe9"))) == '{"a": "\\\\xe9"}'
    assert jsonify(dict(a=to_native("\xe9")), ensure_ascii=False) == u'{"a": "\\xe9"}'
    assert jsonify(dict(a=[u"\u1337"])) == '{"a": ["\\\\u1337"]}'
    assert jsonify(dict(a=Set([u"\u1337"]))) == '{"a": ["\\\\u1337"]}'

# Generated at 2022-06-20 16:24:47.782677
# Unit test for function container_to_text
def test_container_to_text():
    # dict
    assert container_to_text({'a': 1, 'b': b'2'}) == {'a': 1, 'b': u'2'}
    # list
    assert container_to_text([b'a']) == [u'a']
    # tuple
    assert container_to_text((b'a',)) == (u'a',)

# Generated at 2022-06-20 16:24:57.026037
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes([to_bytes(u'a')]) == [to_bytes(u'a')]
    assert container_to_bytes([to_bytes(u'a'), to_bytes(u'b'), to_bytes(u'c')]) == [to_bytes(u'a'), to_bytes(u'b'), to_bytes(u'c')]
    assert container_to_bytes({"c": to_bytes(u'a'), "a": to_bytes(u'b')}) == {"c": to_bytes(u'a'), "a": to_bytes(u'b')}

# Generated at 2022-06-20 16:25:03.435339
# Unit test for function to_bytes
def test_to_bytes():
    # Test non-string values with various nonstring values
    for nonstring in ('simplerepr', 'empty', 'passthru'):
        for value in (1, None):
            assert to_bytes(value, nonstring=nonstring)
            assert isinstance(to_bytes(value, nonstring=nonstring), binary_type)

        assert to_bytes(1, errors='surrogate_or_replace', nonstring=nonstring)
        assert isinstance(to_bytes(1, errors='surrogate_or_replace', nonstring=nonstring), binary_type)

        assert to_bytes(1, errors='surrogate_or_strict', nonstring=nonstring)
        assert isinstance(to_bytes(1, errors='surrogate_or_strict', nonstring=nonstring), binary_type)

    # Test

# Generated at 2022-06-20 16:25:15.996713
# Unit test for function container_to_bytes
def test_container_to_bytes():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock

    # We need the module for the jsonify, so
    # we need to get it in sys.modules
    if 'ansible.module_utils.json_utils' not in sys.modules:
        json_mod = __import__('ansible.module_utils.json_utils')
        sys.modules['ansible.module_utils.json_utils'] = json_mod

    class TestContainerToBytes(unittest.TestCase):
        @patch('ansible.module_utils._text.jsonify')
        def test_container_to_bytes(self, mock_jsonify):
            mock_jsonify.return_value = u'{"a": "b"}'
            # If a string is passed in it should