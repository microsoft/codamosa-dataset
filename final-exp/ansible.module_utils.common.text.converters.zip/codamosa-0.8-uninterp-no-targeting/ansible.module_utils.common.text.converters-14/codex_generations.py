

# Generated at 2022-06-20 16:15:37.961897
# Unit test for function to_native
def test_to_native():
    import sys
    s = u'Μικρό μπάνιο\u3000微小浴廁\n'
    assert to_bytes(s, nonstring='simplerepr') == b"u'\\u03bc\\u03b9\\u03ba\\u03c1\\u03cc \\u03bc\\u03c0\\u03ac\\u03bd\\u03b9\\u03bf\\u3000\\u5fae\\u5c0f\\u6d85'\n"

# Generated at 2022-06-20 16:15:50.128072
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_data = {
        u'key1': [u'list', u'of', u'strings'],
        u'key2': {u'subkey': 42},
        u'key3': u'unicode string',
        42: u'another unicode string',
        u'bad_key\xe9': u'bad_key\xe9value'
    }

    test_result = {
        'key1': [b'list', b'of', b'strings'],
        'key2': {'subkey': 42},
        'key3': b'unicode string',
        42: b'another unicode string',
        b'bad_key\xc3\xa9': b'bad_key\xc3\xa9value'
    }


# Generated at 2022-06-20 16:15:56.738540
# Unit test for function container_to_text
def test_container_to_text():
    r_str = u"test_str"
    r_bytes = to_bytes(r_str)
    r_list = [r_str, r_str, r_str]
    r_list_bytes = [to_bytes(s) for s in r_list]
    r_list_tuple = [tuple(r_list)]
    r_dict = {u"list": r_list, u"tuple": tuple(r_list), u"str": r_str, u"bytes": r_bytes}
    r_dict_bytes = {to_bytes(k): to_bytes(v) for k, v in iteritems(r_dict)}
    r_dict_tuple = {r_str: r_list_tuple, r_bytes: r_list_tuple}

# Generated at 2022-06-20 16:16:00.579881
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo', errors='surrogate_or_strict') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == 'foo'
    assert to_native(b'foo', errors='surrogate_then_replace') == 'foo'

# Generated at 2022-06-20 16:16:02.317695
# Unit test for function jsonify
def test_jsonify():
    # Test if function can encode unicode
    jsonify(u'\u2713')



# Generated at 2022-06-20 16:16:14.625401
# Unit test for function to_bytes
def test_to_bytes():
    import codecs
    _old_codecs_error = None
    try:
        _old_codecs_error = codecs.lookup_error('surrogateescape')
    except LookupError:
        pass

    string1 = u'abc'
    string2 = u'a\u1234'
    string3 = u'\u1234'
    string4 = u'\u00a9'

    # Test utf-8 with surrogates allowed
    assert to_bytes(string1, 'utf-8', errors='surrogate_or_replace') == b'abc'
    assert to_bytes(string2, 'utf-8', errors='surrogate_or_replace') == b'a\xe1\x88\xb4'

# Generated at 2022-06-20 16:16:22.282025
# Unit test for function to_bytes
def test_to_bytes():
    import unittest
    import sys
    class TestToBytes(unittest.TestCase):
        '''
        Test the to_bytes method
        '''

        def test_basics(self):
            self.assertEqual(to_bytes('ascii_bytes', encoding='ascii'), 'ascii_bytes')
            self.assertEqual(to_bytes(u'unicode_str', encoding='ascii'), 'unicode_str')
            self.assertEqual(to_bytes(u'unicode_str', encoding='utf-8'), 'unicode_str')
            self.assertEqual(to_bytes(u'unicode_str', nonstring='passthru'), u'unicode_str')

# Generated at 2022-06-20 16:16:31.609877
# Unit test for function to_bytes
def test_to_bytes():
    u = u'\u043f\u0440\u0438\u0432\u0435\u0442'
    b = u.encode('utf8')
    assert to_bytes(u) == b
    assert to_bytes(u, encoding='utf8') == b
    assert to_bytes(b, encoding='utf8') == b

    # Invalid encoding
    if PY3:
        import locale
        locale.setlocale(locale.LC_ALL, 'C')
        assert to_bytes(u, encoding='ascii', errors='surrogate_then_replace')

        # Make sure surrogate_then_replace transforms strings to bytes
        try:
            u.encode('ascii', 'surrogateescape')
        except UnicodeEncodeError:
            pass
        else:
            raise Assert

# Generated at 2022-06-20 16:16:42.646422
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # No problem with normal conversion
    assert(container_to_bytes({u'foo': u'bar', u'faz': u'baz'})) == {b'foo': b'bar', b'faz': b'baz'}
    # Nested dict should still be converted
    assert(container_to_bytes({u'foo': u'bar', u'faz': {u'foo': u'bar'}})) == {b'foo': b'bar', b'faz': {b'foo': b'bar'}}
    # Non-ascii chars
    assert(container_to_bytes({u'foo': u'bar', u'faz': u'\u1234'})) == {b'foo': b'bar', b'faz': b'\xe1\x88\xb4'}
    #

# Generated at 2022-06-20 16:16:52.168588
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.six import assertRegex, text_type, binary_type
    import platform

    # Test byte strings
    byte_str = b'\x80\x81\x82'
    assert to_bytes(byte_str) == byte_str
    assert to_bytes(byte_str, nonstring='passthru') == byte_str
    assert to_bytes(byte_str, nonstring='empty') == b''
    if PY3:
        assertRegex(to_bytes(byte_str, nonstring='simplerepr'), r'^b"\\x80\\x81\\x82"$')

# Generated at 2022-06-20 16:17:05.278661
# Unit test for function to_bytes
def test_to_bytes():
    r'''
    We use a triple-quoted string here so that we can test a string with
    a single quote in it.  The string is made up of:
    - A utf8-encoded character that's valid in utf8 and latin1 (2 bytes)
    - A utf8-encoded character that's not valid in latin1 (3 bytes)
    - An ascii-only single quoted string (6 bytes)
    - A utf8-encoded character that's valid in utf8 and latin1 (2 bytes)
    The string with utf8 characters is a total of 13 bytes
    The string with replaced utf8 characters is a total of 18 bytes
    The string with latin1 characters is a total of 11 bytes
    '''

# Generated at 2022-06-20 16:17:15.580466
# Unit test for function container_to_bytes
def test_container_to_bytes():
    foo = {u'unicode_str': u'bar', u'byte_str': b'baz', u'int': 123}
    foo_bytes = {b'unicode_str': b'bar', b'byte_str': b'baz', b'int': 123}
    assert container_to_bytes(foo) == foo_bytes
    assert container_to_bytes(foo, errors='surrogate_then_replace') == foo_bytes
    assert container_to_bytes(foo, errors='replace') == foo_bytes
    assert container_to_bytes(foo, errors='surrogate_or_strict') == foo_bytes
    assert container_to_bytes(foo, errors='surrogate_or_replace') == foo_bytes


# Generated at 2022-06-20 16:17:22.844246
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({'foo': b'bar'}) == {'foo': b'bar'}
    assert container_to_bytes({'foo': b'bar'}) == {'foo': b'bar'}
    assert container_to_bytes({u'foo': b'bar'}) == {b'foo': b'bar'}
    assert container_to_bytes({'foo': [u'bar', u'baz']}) == {'foo': [b'bar', b'baz']}
    assert container_to_bytes({'foo': 'bar'}) == {'foo': b'bar'}
    assert container_to_bytes(['foo', 'bar', [u'bar', u'baz']]) == [b'foo', b'bar', [b'bar', b'baz']]
    assert container

# Generated at 2022-06-20 16:17:28.656880
# Unit test for function jsonify
def test_jsonify():
    class test_dict(dict):
        pass

    mydict = test_dict()
    mydict['test_key'] = 'test_value'
    mydict.test_attr = 'test_attribute'

    assert jsonify(mydict) == '{"test_key": "test_value"}'

    class test_list(list):
        def __init__(self, iterable):
            self.iterable = iterable

        def __iter__(self):
            return iter(self.iterable)

        def __getitem__(self, index):
            return self.iterable[index]

        def __len__(self):
            return len(self.iterable)

    mylist = test_list([1,2,3])
    assert jsonify(mylist) == '[1, 2, 3]'



# Generated at 2022-06-20 16:17:32.318760
# Unit test for function to_native
def test_to_native():
    pass


# Generated at 2022-06-20 16:17:38.036379
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' Unit test for function container_to_bytes'''
    mydict = {u'key1': u'value1', u'key2': {u'key3': u'value2'}}
    bdict = container_to_bytes(mydict)
    assert u'value1'.encode() in bdict['key1']
    assert u'value2'.encode() in bdict['key2']['key3']

# Generated at 2022-06-20 16:17:49.600550
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory
    from ansible.module_utils.facts.system.distribution import LinuxDistribution2
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactory2
    from ansible.module_utils._text import to_bytes, to_text
    distro = DistributionFactCollector()
    distro.distribution = None

    distro_data = {u'name': u'RedHatEnterpriseServer', u'version': u'8.0'}

# Generated at 2022-06-20 16:18:00.463150
# Unit test for function to_native
def test_to_native():
    from packaging.version import parse as Version

    try:
        from packaging.version import parse
    except ImportError:
        from distutils.version import LooseVersion as parse


# Generated at 2022-06-20 16:18:04.759188
# Unit test for function to_native
def test_to_native():
    assert to_native('string') == 'string'

# Generated at 2022-06-20 16:18:17.081931
# Unit test for function container_to_bytes

# Generated at 2022-06-20 16:18:37.252532
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    class Dummy(object):
        def __str__(self):
            return b'foobar'
    class DummyUnicode(object):
        def __str__(self):
            return u'foobar'
    class DummyUnicodeError(object):
        def __str__(self):
            return b'\xff'
    class DummyUnicodeErrorUnicode(object):
        def __str__(self):
            return u'\xff'

    if PY3:
        assert to_native(b'foo') == 'foo'
        assert to_native(u'foo') == 'foo'
        assert to_native(Dummy()) == 'foobar'
        assert to_native(DummyUnicode()) == 'foobar'


# Generated at 2022-06-20 16:18:49.019400
# Unit test for function container_to_text
def test_container_to_text():
    """
    Tests for function container_to_text
    assertEqual:Adds the standard assertEqual method to the TestCase class
    assertIsInstance:Adds the standard assertIsInstance method to the TestCase class
    """

    def _test_container_to_text_(container_type, pytype, value):
        """
           Recursive function to test container_to_text
        """
        if pytype == dict:
            # Ensure it is a dict of dicts and not flat
            value = {'key': value}
        obj = container_type(value)
        kwargs = dict(
            encoding='utf-8',
            errors='surrogate_or_strict',
        )
        result = container_to_text(obj, **kwargs)
        assert isinstance(result, container_type)

# Generated at 2022-06-20 16:18:49.598650
# Unit test for function to_bytes
def test_to_bytes():
    pass



# Generated at 2022-06-20 16:18:54.677246
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({u'foo': {u'bar': u'baz'}}) == {b'foo': {b'bar': b'baz'}}
    assert container_to_bytes([u'foo', {u'bar': u'baz'}]) == [b'foo', {b'bar': b'baz'}]



# Generated at 2022-06-20 16:19:03.819099
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test encoding a unicode string
    test_string = u"\u6c49\u5b57"
    assert container_to_bytes(test_string) == b"\xe6\xb1\x89\xe5\xad\x97"

    # Test encoding a non-unicode string
    test_string = "\u6c49\u5b57"
    assert container_to_bytes(test_string) == b"\xe6\xb1\x89\xe5\xad\x97"

    # Test encoding a dictionary with unicode key and value
    test_dict = {u"key":u"\u6c49\u5b57"}

# Generated at 2022-06-20 16:19:07.191448
# Unit test for function jsonify
def test_jsonify():
    # sample data
    data1 = {
        "name": u"王尼玛",
        "age": 20
    }

    # expected result
    result_data = {
        "name": u"王尼玛",
        "age": 20
    }
    # the json result
    json_result = jsonify(data1,ensure_ascii=False)

    # decode the json result to make the test easy
    result_data = json.loads(json_result)

    assert data1 == result_data


# Generated at 2022-06-20 16:19:17.914044
# Unit test for function to_bytes
def test_to_bytes():
    test_string = u'\u043F\u0440\u0438\u0432\u0435\u0442 \u043C\u0438\u0440'
    assert to_bytes(test_string, errors='surrogate_or_strict') == test_string.encode('utf-8')
    assert to_bytes(test_string, errors='surrogate_or_replace') == test_string.encode('utf-8')
    assert to_bytes(test_string, errors='surrogate_then_replace') == test_string.encode('utf-8')
    assert to_bytes(test_string, encoding='ascii', errors=None) == test_string.encode('ascii', 'surrogateescape')

# Generated at 2022-06-20 16:19:25.714615
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {b"key1": b"value1", b"key2": b"value2"}
    r = container_to_bytes(d)
    assert r == d

    d = {u"key1": u"value1", u"key2": u"value2"}
    r = container_to_bytes(d)
    assert r == {b"key1": b"value1", b"key2": b"value2"}

    d = [b"str1", b"str2"]
    r = container_to_bytes(d)
    assert r == d

    d = [u"str1", u"str2"]
    r = container_to_bytes(d)
    assert r == [b"str1", b"str2"]

    d = ("str1", "str2")
    r = container_

# Generated at 2022-06-20 16:19:30.422725
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Prepare data
    d = {
        u'k1': [1, 2, 3, 4],
        u'k2': {
            u'k3': u'v3',
            u'k4': [u'v4', u'v5', u'v6']
        }
    }
    # Call function
    new_d = container_to_bytes(d)
    # Check result
    assert to_bytes('v3') in new_d['k2'].values()
    assert to_bytes('v4') in new_d['k2']['k4']
    assert to_bytes('v6') in new_d['k2']['k4']


# Generated at 2022-06-20 16:19:34.111700
# Unit test for function to_native
def test_to_native():
    assert to_native(b'text') == u'text'
    assert to_native(u'text') == u'text'
    assert to_native('text') == u'text'
    # Test nonstrings
    assert to_native(1) == '1'
    assert to_native(1.2) == '1.2'
    assert to_native([1, 2, 3]) == '[1, 2, 3]'



# Generated at 2022-06-20 16:19:50.136612
# Unit test for function container_to_text

# Generated at 2022-06-20 16:19:57.700920
# Unit test for function to_native
def test_to_native():
    # True/False are instances of int, so ensure we properly handle converting them to native strings
    assert to_native(True) == "True"
    assert to_native(False) == "False"

try:
    unicode
except NameError:
    unicode = None

# Common return values
# (We don't have good exception handling yet)
RETURN_OK = 'OK'
RETURN_ERROR = 'ERROR'
RETURN_FAILED = 'FAILED'


# Note this is not a literal JSON encoding of {}.  Instead we follow the
# convention of returning a string that looks like the literal.  This ensures
# that we don't change the type of string returned based on the Python version
# (We always return text in Python3, but in Python2 we return bytes if the
# literal is ASCII and unicode otherwise)
EMPTY

# Generated at 2022-06-20 16:20:09.007758
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('hello') == b'hello'
    assert to_bytes(b'hello') == b'hello'
    try:
        to_bytes(5)
        # Because of the try block, reach here if the test fails
        # No exception -> Test failed
        assert False
    except TypeError:
        pass
    try:
        to_bytes(5, nonstring='strict')
        # Because of the try block, reach here if the test fails
        # No exception -> Test failed
        assert False
    except TypeError:
        pass
    assert to_bytes(5, nonstring='passthru') == 5
    assert to_bytes(5, nonstring='empty') == b''
    assert to_bytes(5, nonstring='simplerepr') == b'5'

# Generated at 2022-06-20 16:20:18.302261
# Unit test for function to_bytes
def test_to_bytes():
    # Make sure it works for ascii
    assert to_bytes('Hello') == b'Hello'

    # Make sure it works for utf8 (the default)
    assert to_bytes('Διάλεκτος') == b'\xce\x94\xce\xb9\xce\xac\xce\xbb\xce\xb5\xce\xba\xcf\x84\xce\xbf\xcf\x82'
    # Make sure it works for latin-1

# Generated at 2022-06-20 16:20:24.463467
# Unit test for function container_to_text
def test_container_to_text():
    # TypeError for non-container type
    # Note: can't test for scalar, since those are passed through
    assert_raises(TypeError, container_to_text, None)

    # non-encoded bytes (surrogate escapes)
    # Note: can't test for bytes, since those are passed through
    assert_raises(UnicodeDecodeError, container_to_text, b'\xed\xa0\x80')

    # invalid bytes (not surrogates)
    assert_raises(UnicodeDecodeError,
        container_to_text, {b'text': b'\xed\xa0\x80'}, errors='strict')

# Generated at 2022-06-20 16:20:30.055130
# Unit test for function jsonify
def test_jsonify():
    assert '{"a": "b", "c": "d"}' == jsonify({b"a": b"b", "c": "d"})
    assert ("[\"ascii\", \"\\u00e9\", [[\"a\", \"b\"]]]" ==
            jsonify(["ascii", u"\u00e9", [["a", "b"]]]))



# Generated at 2022-06-20 16:20:35.513685
# Unit test for function to_bytes
def test_to_bytes():
    # TODO: This tests that this function has the same behavior as
    # legacy_to_bytes.  When legacy_to_bytes is removed we can move the tests
    # to test_common_util.py
    import warnings
    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")

        def assert_unicodestr_result(result, original, encoding, errors, nonstring, expected_warning):
            if expected_warning:
                assert len(w) == 1
                warning = to_bytes(w[0].message)
                # Assert that the default encoding contains some surrogates
                assert b'utf-8' in warning
            else:
                assert len(w) == 0

            assert isinstance(result, binary_type)


# Generated at 2022-06-20 16:20:43.963856
# Unit test for function jsonify
def test_jsonify():
    data = {b"a": "b"}
    # If encoding is not specified, by default it is assumed the data is in utf-8 and fails to encode
    assert jsonify(data).decode("utf-8") == '{"a": "b"}'
    data = {b"a": "B"}
    # If encoding is specified, it works
    assert jsonify(data, encoding="latin-1").decode("utf-8") == '{"a": "B"}'
    # Passing non ascii string
    data = {b"a": "à".decode("utf-8")}
    # If encoding is specified, it works
    assert jsonify(data, encoding="latin-1").decode("utf-8") == '{"a": "à"}'



# Generated at 2022-06-20 16:20:54.793992
# Unit test for function to_native
def test_to_native():
    '''
    Test to_native function
    '''
    from ansible.module_utils.basic import to_native
    assert to_native(b'foo') == u'foo'
    assert to_native(u'foo') == u'foo'
    assert to_native(1234) == 1234
    assert to_native(u'☃') == u'☃'
    assert to_native(b'\xE2\x98\x83') == u'☃'
    assert to_native(b'\xE2\x98') == u'�'
    assert to_native(b'\xE2\x98', errors='strict') == u'�'


# Generated at 2022-06-20 16:21:04.835970
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' test_container_to_bytes() - Unit test function to test function container_to_bytes
    '''

    # Try a simple dict in
    assert container_to_bytes({u'foo': u'bar'}) == {b'foo': b'bar'}

    # Try a simple list in
    assert container_to_bytes([u'foo', u'bar']) == [b'foo', b'bar']

    # Try a simple tuple in
    assert container_to_bytes((u'foo', u'bar')) == (b'foo', b'bar')

    # Try a dict with a dict in it
    assert container_to_bytes({u'foo': {u'bar': u'baz'}}) == {b'foo': {b'bar': b'baz'}}

    # Try a dict with a list in

# Generated at 2022-06-20 16:21:22.999340
# Unit test for function to_bytes
def test_to_bytes():
    # Test with nonstring = 'simplerepr'
    assert to_bytes(u'foobar') == b'foobar'
    assert to_bytes('foobar') == b'foobar'
    assert to_bytes(b'foobar') == b'foobar'
    # Test with nonstring = 'passthru'
    assert to_bytes(u'foobar', nonstring='passthru') == u'foobar'
    assert to_bytes('foobar', nonstring='passthru') == 'foobar'
    assert to_bytes(b'foobar', nonstring='passthru') == b'foobar'
    # Test with nonstring = 'empty'
    assert to_bytes(1, nonstring='empty') == b''
    # Test with nonstring = 'strict'

# Generated at 2022-06-20 16:21:31.252114
# Unit test for function to_bytes
def test_to_bytes():
    s = to_bytes(u'Hi')
    assert isinstance(s, binary_type), \
        "Did not create byte string: %r" % (s,)
    assert s == b'Hi', "Did not correctly convert text to bytes: %r" % (s,)

    s = to_bytes('Hi')
    assert isinstance(s, binary_type), \
        "Did not create byte string: %r" % (s,)
    assert s == b'Hi', "Did not correctly convert text to bytes: %r" % (s,)

    s = to_bytes(b'Hi')
    assert isinstance(s, binary_type), \
        "Did not create byte string: %r" % (s,)
    assert s == b'Hi', "Did not correctly convert text to bytes: %r" % (s,)


# Generated at 2022-06-20 16:21:43.333329
# Unit test for function to_bytes
def test_to_bytes():
    """
    Test to_bytes
    """
    def _assert_no_error_when_encoding(input_string, encoding='utf-8',
                                       errors=None):
        try:
            return_value = to_bytes(input_string, encoding=encoding,
                                    errors=errors)
        except UnicodeError:
            assert False, (
                'Encoding %r with %r error handler raised UnicodeError with '
                'input %r' % (encoding, errors, input_string)
            )
        if isinstance(input_string, six.text_type):
            assert isinstance(return_value, six.binary_type), (
                'Input %r did not return a binary type.  Type returned was '
                '%s' % (input_string, type(return_value))
            )


# Generated at 2022-06-20 16:21:46.932945
# Unit test for function to_native
def test_to_native():
  assert to_native('八咫') == '八咫'
  assert to_native(b'\xe5\x85\xab\xe5\x92\xab') == '八咫'

# Generated at 2022-06-20 16:21:58.171391
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'hi') == b'hi'
    assert to_bytes(u'é', encoding='latin-1') == b'\xc3\xa9'
    assert to_bytes(u'\u1234', encoding='ascii') == b'?'
    try:
        to_bytes(u'\u1234', encoding='ascii', errors='strict')
    except UnicodeEncodeError:
        pass
    else:
        assert False, 'UnicodeEncodeError should have failed'
    if HAS_SURROGATEESCAPE:
        assert to_bytes(u'\u1234', encoding='ascii', errors='surrogateescape') == b'\xed\xa0\xb4'

    assert to_bytes(b'hi') == b'hi'
    assert to

# Generated at 2022-06-20 16:21:58.575796
# Unit test for function to_bytes
def test_to_bytes():
    pass

# Generated at 2022-06-20 16:22:06.074344
# Unit test for function to_bytes
def test_to_bytes():
    if PY3:
        return
    else:
        # check if surrogateescape registered with _surrogateescape backport
        import codecs
        codecs.lookup_error('surrogateescape')

        # Some examples that work in python3 and should work in python2
        assert to_bytes(b'foo') == b'foo'
        assert to_bytes(b'foo', nonstring='empty') == b''

        assert to_bytes(u'foo') == u'foo'.encode('utf-8')
        assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'.encode('utf-8')

# Generated at 2022-06-20 16:22:14.984612
# Unit test for function to_native
def test_to_native():
    assert to_native('abc') == 'abc'
    assert to_native(b'abc') == 'abc'
    assert to_native(u'abc') == 'abc'
    assert to_native(b'\xff') == '\xff'
    assert to_native(u'\u0410') == '\u0410'
    assert to_native('\xe1\x88\xb4') == '\u1234'
    assert to_native(u'\u1234') == '\u1234'
    assert to_native('\xe1\x88\xb4', nonstring='empty') == ''
    assert to_native(u'\u1234', nonstring='empty') == ''
    assert to_native(b'\xe1\x88\xb4', nonstring='empty') == ''

# Generated at 2022-06-20 16:22:28.084228
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.common._collections_compat import OrderedDict

    # Normal usage: a string that isn't unicode
    assert isinstance(to_bytes(b'foo'), binary_type)
    assert to_bytes(b'foo') == b'foo'

    # This is a string that doesn't have surrogates but isn't a unicode string
    assert isinstance(to_bytes(u'foo'), binary_type)
    assert to_bytes(u'foo') == b'foo'

    # This is a string that has surrogates and can be represented as utf-8
    assert isinstance(to_bytes(u'\U0001f639'), binary_type)
    assert to_bytes(u'\U0001f639') == b'\xf0\x9f\x98\xb9'



# Generated at 2022-06-20 16:22:39.306542
# Unit test for function container_to_text
def test_container_to_text():
    # byte string as key, byte strinng as value
    dict_byte_as_key_byte_as_value = {b"byte_key": b"byte_value"}
    # byte string as key, text string as value
    dict_byte_as_key_text_as_value = {b"byte_key": u"text_value"}
    # text string as key, byte string as value
    dict_text_as_key_byte_as_value = {u"text_key": b"byte_value"}
    # text string as key, text string as value
    dict_text_as_key_text_as_value = {u"text_key": u"text_value"}
    # list of byte string
    list_of_byte = [b"byte_value"]
    # list of text string
    list_of

# Generated at 2022-06-20 16:22:59.983573
# Unit test for function container_to_text
def test_container_to_text():
    b = {b'k1': b'v1', b'k2': b'v2', b'k3': b'\xf1'}
    t = container_to_text(b, encoding='utf-8', errors='strict')
    assert t == {u'k1': u'v1', u'k2': u'v2', u'k3': u'\xf1'}


# Python's json module expects unicode input, not bytes.
# It also expects unicode dict keys, not str/int/etc.
# This only handles, lists, tuples, and dict container types (the containers
# that the json module returns)
# This method is used by modules running on python2.

# Generated at 2022-06-20 16:23:11.350972
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test that text_type values are turned into byte strings
    # This implicitly tests the leaf node code
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0456\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82'

    # Test that lists are recursed into

# Generated at 2022-06-20 16:23:19.208532
# Unit test for function to_bytes
def test_to_bytes():
    import sys

    orig_stdout = sys.stdout
    sys.stdout = open('/dev/null', 'wb')

    # Verify that a non-string is transformed correctly
    assert u'[1, 2]' == to_bytes({1:2}, nonstring='simplerepr')
    assert b'[1, 2]' == to_bytes(to_bytes({1:2}, nonstring='simplerepr'))
    assert b'[1, 2]' == to_bytes(to_bytes(u'[1, 2]'))

    # Verify that conversion to text don't fail with unicode values
    assert to_text(u'\u2713')

    sys.stdout = orig_stdout



# Generated at 2022-06-20 16:23:32.158595
# Unit test for function to_native
def test_to_native():

    class TestClass(object):
        def __str__(self):
            return 'Simple String'
        def __repr__(self):
            return '<Complex String>'

    def testcases_normal():
        a_str = 'a'
        a_unicode = u'a'
        a_bytes = b'a'

        unicode_unsafe_str = '\x00'
        unicode_unsafe_unicode = u'\x00'
        unicode_unsafe_bytes = b'\x00'

        if PY3:
            unicode_only_str = '\u2713'
            unicode_only_unicode = u'\u2713'
            unicode_only_bytes = b'\xe2\x9c\x93'
        else:
            unicode_

# Generated at 2022-06-20 16:23:40.979557
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'unicode_str') == b'unicode_str'
    assert to_bytes(u'I am a \U0001f60a unicode string!') == b'I am a \xf0\x9f\x98\x8a unicode string!'
    assert to_bytes(u'unicode_str', 'ascii') == b'unicode_str'
    try:
        to_bytes(u'I am a \U0001f60a unicode string!', 'ascii')
        assert False
    except UnicodeEncodeError:
        assert True
    assert to_bytes(u'I am a \U0001f60a unicode string!', 'ascii', 'surrogate_or_replace') == b'I am a ? unicode string!'

# Generated at 2022-06-20 16:23:49.402220
# Unit test for function to_native
def test_to_native():
    # Check various text types
    assert to_native(u'text') == u'text'
    assert to_native(b'text') == u'text'

    # Check various non-text types
    assert to_native(b'\x80') == u'\uFFFD'
    assert to_native(u'\x80') == u'\x80'
    assert to_native(1) == u'1'
    assert to_native(None) == u'None'
    assert to_native([u'a']) == u"[u'a']"



# Generated at 2022-06-20 16:24:00.752823
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({u'foo': u'bar'}) == {b'foo': b'bar'}
    assert container_to_bytes(
        {u'foo': u'bar', 'baz': {u'zab': [2, 3, 4]}}, encoding='utf-16', errors='surrogate_or_replace') == {
            b'foo\x00': b'bar\x00',
            b'baz\x00': {
                b'zab\x00': [2, 3, 4]}}
    assert container_to_bytes([u'foo', u'bar']) == [b'foo', b'bar']

# Generated at 2022-06-20 16:24:11.892493
# Unit test for function jsonify
def test_jsonify():
    #Testing with arg=dict and kwarg=None
    data = {'hello': 1, 'world': [2, 3], 'foo': {'bar': [4, 5, 6]}}
    assert jsonify(data) == json.dumps(data, encoding=u'utf-8', default=_json_encode_fallback)
    #Testing with arg=list and kwarg=None
    data = [1, 2, 3, 4, 5, 6]
    assert jsonify(data) == json.dumps(data, encoding=u'utf-8', default=_json_encode_fallback)
    #Testing with arg=dict and kwargs={'sort_keys':True}

# Generated at 2022-06-20 16:24:19.122523
# Unit test for function to_native
def test_to_native():
    # function to_native should return a native string
    if PY3:
        assert(isinstance(to_native(u'test'), str))
        assert(isinstance(to_native(b'test'), str))
    else:
        assert(isinstance(to_native(u'test'), str))
        assert(isinstance(to_native(b'test'), str))
    assert(to_native(u'test') == 'test')
    assert(to_native(b'test') == 'test')



# Generated at 2022-06-20 16:24:25.613489
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": u"\u00ff"}) == '{"a": "\\u00ff"}'
    assert jsonify({"a": u"\u00ff"}, indent=2) == '{\n  "a": "\\u00ff"\n}'
    assert jsonify({"a": u"\u00ff"}, separators=(',', ':')) == '{"a":"\\u00ff"}'
    assert jsonify({"a": u"\u00ff"}, sort_keys=True) == '{"a": "\\u00ff"}'



# Generated at 2022-06-20 16:24:43.450826
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test the dict branch
    d = {u'foo':u'bar', u'a':u'1'}
    expected = {'foo':b'bar', 'a':b'1'}
    result = container_to_bytes(d)
    assert result == expected

    # Test the list branch
    d = [u'foo', u'bar']
    expected = [b'foo', b'bar']
    result = container_to_bytes(d)
    assert result == expected

    # Test the tuple branch
    d = (u'foo', u'bar')
    expected = (b'foo', b'bar')
    result = container_to_bytes(d)
    assert result == expected

    # Test the unicode branch
    d = u'foo'
    expected = b'foo'
    result = container_to

# Generated at 2022-06-20 16:24:49.098846
# Unit test for function to_native
def test_to_native():
    # Note: to_native is a thin wrapper around to_text for now so this is
    # basically testing to_text too.
    assert to_native(u'\u263a', nonstring='simplerepr') == u'\u263a'
    assert to_native(b'\xe2\x98\xba', nonstring='simplerepr') == u'\u263a'
    assert to_native('\u263a', nonstring='simplerepr') == u'\u263a'
    assert to_native(u'\u263a', nonstring='passthru') == u'\u263a'
    assert to_native(b'\xe2\x98\xba', nonstring='passthru') == b'\xe2\x98\xba'

# Generated at 2022-06-20 16:24:51.555967
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    
    assert to_native(3, nonstring='passthru') == 3
    
    

# Generated at 2022-06-20 16:25:00.104737
# Unit test for function to_bytes
def test_to_bytes():
    '''Test various ways of getting to a byte string'''
    import sys
    import tempfile
    import shutil
    import os.path
    import os

    # Test byte string passthru
    byte_string = b'The quick brown fox'
    assert byte_string == to_bytes(byte_string)

    # Test unicode string
    uni_string = u'The quick brown fox'
    assert byte_string == to_bytes(uni_string)
    # Test unicode string with surrogates
    uni_string = u'The quick brown fox \ud83d\udc4d'
    # Test happy path surrogateescape

# Generated at 2022-06-20 16:25:12.244124
# Unit test for function container_to_text
def test_container_to_text():
    """Check container_to_text works correctly."""
    d = {b'foo': b'bar', 'baz': b'qux'}
    e = {b'foo': b'bar', 'baz': b'qux'}
    assert container_to_text(d) == e
    assert container_to_text(d, encoding='ascii') == e
    d = {'foo': {b'bar': b'qux'}}
    e = {'foo': {'bar': 'qux'}}
    assert container_to_text(d) == e
    assert container_to_text(d, encoding='ascii') == e
    # check that error handler is being used
    d = {b'foo': b'bar\xff'}