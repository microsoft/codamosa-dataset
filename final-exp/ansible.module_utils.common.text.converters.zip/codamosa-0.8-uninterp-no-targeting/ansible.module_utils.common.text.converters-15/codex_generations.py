

# Generated at 2022-06-20 16:15:26.390002
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    assert to_native(b'foo') == 'foo'
    assert to_native('foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(1.0) == '1.0'


if PY3:
    to_native = to_text
else:
    to_native = to_bytes


# Generated at 2022-06-20 16:15:31.431584
# Unit test for function container_to_bytes
def test_container_to_bytes():
    data = {u'name': u'会員登録', u'url': u'/register-member'}
    assert container_to_bytes(data, encoding='utf-8') == {b'name': b'\xe4\xbc\x9a\xe5\x93\xa1\xe7\x99\xbb\xe9\x8c\xb2', b'url': b'/register-member'}

# Generated at 2022-06-20 16:15:36.498201
# Unit test for function jsonify
def test_jsonify():
    data = {'1': 'latin-1', u'2': u'utf-8'}
    jsonify(data)
    assert data[u'1'] == 'latin-1'.decode('utf-8')
    assert data[u'2'] == u'utf-8'


# Generated at 2022-06-20 16:15:48.754950
# Unit test for function container_to_text
def test_container_to_text():
    a_dict = {u'key': u'value', 'binary':'\x00\x01\x02\x03'.decode('latin-1')}
    assert a_dict == container_to_text(a_dict)
    assert container_to_text(a_dict) == container_to_text(container_to_text(a_dict))
    assert container_to_bytes(a_dict) == container_to_bytes(container_to_bytes(a_dict))
    assert container_to_bytes(a_dict) == container_to_bytes(container_to_text(a_dict))
    assert container_to_text(a_dict) == container_to_text(container_to_bytes(a_dict))

    # For now, just test the data types jsonify returns

# Generated at 2022-06-20 16:16:00.204439
# Unit test for function jsonify
def test_jsonify():
    data = {
        'byte_string': 'byte_string',
        u'unicode_string': u'unicode_string',
        'dict': {
            'byte_string': 'byte_string',
            u'unicode_string': u'unicode_string',
            'list': [
                'byte_string',
                u'unicode_string',
                'dict',
                3,
                # datetime.datetime
                datetime.datetime(2016, 1, 1, 0, 0, 0),
                # ansible.utils.unicode.unicode
                SafeText(u'unicode')
            ]
        }
    }

# Generated at 2022-06-20 16:16:04.556451
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": u"\u2603"}) == '{"a": "\\u2603"}'



# Generated at 2022-06-20 16:16:16.566351
# Unit test for function to_bytes
def test_to_bytes():
    def check(input_val, encoding, errors, nonstring, expected_val):
        actual_val = to_bytes(input_val, encoding=encoding, errors=errors, nonstring=nonstring)
        assert actual_val == expected_val

    if PY3:
        check('abcd', 'utf-8', 'surrogate_or_replace', 'simplerepr', b'abcd')
        check('abcd', 'ascii', 'surrogate_or_replace', 'simplerepr', b'abcd')
        check('abcd', 'ascii', 'surrogate_or_strict', 'simplerepr', b'abcd')
        check('abcd', 'ascii', 'surrogate_then_replace', 'simplerepr', b'abcd')

# Generated at 2022-06-20 16:16:24.535896
# Unit test for function jsonify
def test_jsonify():
    module_utils = sys.modules[__name__]
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import binary_type, text_type
    from ansible.compat.tests import unittest

    class TestJSON(unittest.TestCase):
        def setUp(self):
            # pick an encoding we don't expect to see in the text
            self.encoding = 'iso-2022-jp'
            self.u_contents = u"\u0641"
            self.b_contents = to_bytes(self.u_contents, encoding=self.encoding)

        def test_to_bytes_json(self):
            '''jsonify with to_bytes'''

# Generated at 2022-06-20 16:16:32.841994
# Unit test for function to_bytes
def test_to_bytes():
    '''Test Python2 and Python3 byte conversions'''
    # pylint: disable=no-member
    # We can't test this in Python2
    if PY3:
        # Python3 bytes
        assert to_bytes(b'hello') == b'hello'
        assert to_bytes(b'hell\x00o') == b'hell\x00o'
        assert to_bytes(b'\x80') == b'\x80'

    # Non-ASCII text
    assert to_bytes(u'ü') == b'\xC3\xBC'
    assert to_bytes(u'ü', encoding='ascii') == b'?'
    assert to_bytes(u'ü', encoding='latin-1') == b'\xFC'

# Generated at 2022-06-20 16:16:44.848774
# Unit test for function container_to_bytes
def test_container_to_bytes():
    for encoding in ("utf-8", "latin-1"):
        d = {'foô': 'bâr1', u'foô': 'bâr2', b'fo\xc3\xb4': 'bâr3', 1: 2}
        e = container_to_bytes(d, encoding=encoding)
        assert(isinstance(e, dict))
        assert(len(e) == 2)
        assert(isinstance(list(e.keys())[0], binary_type))
        assert(isinstance(list(e.values())[0], binary_type))
        assert(e[b'fo\xc3\xb4'] == b'b\xc3\xa2r3')

# Generated at 2022-06-20 16:17:04.355911
# Unit test for function container_to_text
def test_container_to_text():
    from nose.plugins.skip import SkipTest
    import json

    if PY3:
        raise SkipTest()
    # unicode literals are only allowed in python-3.x
    # pylint: disable=unicode-format-string
    text = u'\u043f\u0440\u0438\u0432\u0456\u0442'
    expected = text
    data = {u'a': text, u'b': [text, text], u'c': (text, text)}
    assert expected == container_to_text(data)
    assert expected == container_to_text(json.loads(json.dumps(data)))
    try:
        container_to_text(to_bytes(data))
    except Exception as e:
        assert False, e

# Generated at 2022-06-20 16:17:14.942158
# Unit test for function jsonify
def test_jsonify():
    test_data = {
        'not_string': None,
        'string': 'string',
        'bytestring': b'bytestring',
        'unicode_string': u'unicode_string',
        'set': set(('foo', u'bar')),
        'datetime': datetime.datetime(1979, 1, 31, 12, 30, 00),
        'dict': {
            'not_string': None,
            'string': 'string',
            'bytestring': b'bytestring',
            'unicode_string': u'unicode_string',
            'set': set(('foo', u'bar')),
            'datetime': datetime.datetime(1979, 1, 31, 12, 30, 00),
        }
    }
    encoded = jsonify(test_data)

   

# Generated at 2022-06-20 16:17:22.357942
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_list = ['ascii', u'unicode']
    test_dict = dict(a=1, b=u'unicode')
    result = container_to_bytes(test_list)
    assert isinstance(result[0], text_type)
    assert isinstance(result[1], text_type)
    result = container_to_bytes(test_dict)
    assert isinstance(result['a'], int)
    assert isinstance(result['b'], text_type)


# Generated at 2022-06-20 16:17:33.621522
# Unit test for function to_bytes
def test_to_bytes():
    import sys

    # Nonstring handling
    assert to_bytes(42, nonstring='simplerepr') == b'42'
    assert to_bytes(None, nonstring='simplerepr') == b'None'
    assert to_bytes([1, 2, 3], nonstring='simplerepr') == b'[1, 2, 3]'
    assert to_bytes(Set([1, 2, 3]), nonstring='simplerepr') == b'Set([1, 2, 3])'

    class MyClass(object):
        def __str__(self):
            return u'unicode string'

        def __repr__(self):
            return u'unicode repr'

    class MyClass2(object):
        def __str__(self):
            return u'\U0001f4a9 unicode string'


# Generated at 2022-06-20 16:17:42.944152
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(['a', 'bb', u'\u1234']) == '["a", "bb", "\\u1234"]'
    assert jsonify([[u'a', u'bb', u'\u1234']]) == '[[["a", "bb", "\\u1234"]]]'
    assert jsonify(dict(((u'a', 'bb'), ('c', u'\u1234')))) == '{"a": "bb", "c": "\\u1234"}'
    assert jsonify(dict(((u'a', [u'bb', u'\u1234']), ('c', u'\u1234')))) == '{"a": ["bb", "\\u1234"], "c": "\\u1234"}'

# Generated at 2022-06-20 16:17:50.210008
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == b'foo'
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes('foo', encoding='latin-1') == b'foo'
    assert to_bytes(u'foo', encoding='latin-1') == b'foo'
    # TODO: Add more tests


# Generated at 2022-06-20 16:17:54.822302
# Unit test for function to_native
def test_to_native():
    a1 = '网络'
    a2 = '\xe7\xbd\x91\xe7\xbb\x9c'
    assert to_native(a1) == a1
    assert to_native(a2) == a1



# Generated at 2022-06-20 16:18:03.909109
# Unit test for function to_native
def test_to_native():
    class Foo(object):
        def __str__(self):
            return u'\u5b54\u5b50'

        def __repr__(self):
            return u'\u5b54\u5b50'

    # Test str and repr of non-string object
    assert to_native(Foo()) == u'\u5b54\u5b50'
    assert to_native(Foo(), nonstring='passthru') == Foo()
    assert to_native(Foo(), nonstring='empty') == u''
    assert to_native(Foo(), nonstring='strict') is None  # None is a placeholder as function should raise TypeError

    # Test text string
    assert to_native(u'\u5b54\u5b50') == '啔啐'

# Generated at 2022-06-20 16:18:16.724839
# Unit test for function to_bytes
def test_to_bytes():
    # Run these through to_text and back to make sure we don't have mojibake

    # Test bytes that are valid utf8
    assert to_bytes(to_text(u'abc123', encoding='utf-8', errors='surrogate_or_strict'),
                    encoding='utf-8', errors='surrogate_or_strict') == u'abc123'.encode('utf-8')
    assert to_bytes(to_text(u'\U0001f638', encoding='utf-8', errors='surrogate_or_strict'),
                    encoding='utf-8', errors='surrogate_or_strict') == u'\U0001f638'.encode('utf-8')

    # Test bytes that are not valid utf8

# Generated at 2022-06-20 16:18:24.771963
# Unit test for function to_native
def test_to_native():
    ''' test to_native function '''
    from ansible.module_utils._text import to_native
    assert to_native('foo', encoding='utf-8') == u'foo'
    assert to_native(b'foo', encoding='utf-8') == u'foo'
    assert isinstance(to_native(b'foo', encoding='utf-8'), text_type)
    assert to_native(b'foo', errors='surrogate_or_replace', encoding='utf-8') == u'foo'
    assert isinstance(to_native(b'foo', errors='surrogate_or_replace', encoding='utf-8'), text_type)
    assert to_native(b'\x80', errors='surrogate_or_replace', encoding='utf-8') == u'\ufffd'

# Generated at 2022-06-20 16:18:55.642740
# Unit test for function jsonify
def test_jsonify():
  import datetime
  test_data = dict(
    string=u"my dog has fleas",
    int=4,
    float=6.1,
    list_of_things=[u"one", 1, 1.0, u"iñtërnâtiônàlizætiøn"],
    dict_of_things=dict(
      list_in_a_dict=[u"tacos", "burritos", 42, dict()],
      string_in_a_dict=u"Iñtërnâtiônàlizætiøn",
      int_in_a_dict=42,
      float_in_a_dict=2.5,
      iso_format=datetime.datetime.now(),
    ),
    null=None,
  )
  json_data = json

# Generated at 2022-06-20 16:19:01.086174
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text({'a': b'a', 'b': b'\xe2\x98'}) == {'a': 'a', 'b': u'\uFFFD'}
    assert container_to_text([b'\xe2\x98', b'\xe2\x98']) == [u'\uFFFD', u'\uFFFD']



# Generated at 2022-06-20 16:19:07.098418
# Unit test for function container_to_bytes
def test_container_to_bytes():
    data = {'foo': 'bar', b'baz': u'qux'}
    assert container_to_bytes(data) == {b'foo': b'bar', b'baz': b'qux'}
    data = [b'foo', u'bar']
    assert container_to_bytes(data) == [b'foo', b'bar']
    data = ('foo', u'bar')
    assert container_to_bytes(data) == (b'foo', b'bar')



# Generated at 2022-06-20 16:19:17.862006
# Unit test for function jsonify
def test_jsonify():
    data = {b"a":{u"b":u"c"}}
    assert data == ast.literal_eval(jsonify(data, encoding=None))

    data = {u"a":{u"b":u"c"}}
    assert data == ast.literal_eval(jsonify(data, encoding=None))

    data = {u"a":u"\u2603"}
    assert data == ast.literal_eval(jsonify(data, encoding=None))

    data = {u"a":u"\u2603"}
    assert data == ast.literal_eval(jsonify(data))

    data = {u"set":set([u"a"])}
    assert data == ast.literal_eval(jsonify(data))
    data = {u"set":Set([u"a"])}


# Generated at 2022-06-20 16:19:25.690708
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils._text import to_bytes, to_text
    import sys

    assert b'abc' == to_bytes('abc')
    assert to_bytes('abc', nonstring='simplerepr') == b"'abc'"
    assert to_bytes(u'abc') == b'abc'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\udcc3') == b'\xed\xb3\x83'
    assert u'\udcc3'.encode('utf-8', 'surrogateescape') == b'\xed\xb3\x83'

# Generated at 2022-06-20 16:19:30.963892
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import integer_types

    assert jsonify({}) == '{}'
    assert jsonify([]) == '[]'
    assert jsonify('') == '""'
    assert jsonify(None) == 'null'
    assert jsonify(1) == '1'

    # Ensure that text types are encoded to utf-8 before being converted to JSON
    assert jsonify(to_text('\xe9')) == '"\xc3\xa9"'
    assert jsonify([to_text('\xe9')]) == '["\xc3\xa9"]'

# Generated at 2022-06-20 16:19:39.025014
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert isinstance(container_to_bytes('string'), string_types)

    assert isinstance(container_to_bytes('string'.encode('ascii')), string_types)

    assert isinstance(container_to_bytes({u'unicode_key': u'unicode_value'}), dict)
    assert isinstance(container_to_bytes({u'unicode_key': u'unicode_value'}).keys()[0], string_types)
    assert isinstance(container_to_bytes({u'unicode_key': u'unicode_value'}).values()[0], string_types)

    assert isinstance(container_to_bytes((u'unicode_value',)), tuple)
    assert isinstance(container_to_bytes((u'unicode_value',))[0], string_types)

# Generated at 2022-06-20 16:19:49.596876
# Unit test for function to_bytes
def test_to_bytes():
    def _try_encode(obj, encoding, errors=None, nonstring='simplerepr'):
        try:
            return to_bytes(obj, encoding, errors, nonstring)
        except UnicodeError:
            return None

    try:
        codecs.lookup_error('surrogateescape')
    except LookupError:
        surrogateescape = False
    else:
        surrogateescape = True

    # Test unicode string
    assert _try_encode(u'\u1234', 'ascii', 'strict') == None
    assert _try_encode(u'\u1234', 'ascii', 'surrogate_or_strict') == None
    assert _try_encode(u'\u1234', 'ascii', 'surrogate_or_replace') == b'?'
   

# Generated at 2022-06-20 16:19:58.754906
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == 'foo'
    assert to_native('foo') == 'foo'

    class Foo(object):
        def __repr__(self):
            return 'not unicode'
        def __str__(self):
            return 'not unicode'
    foo = Foo()
    # repr always works
    assert to_native(foo) == 'not unicode'

    if PY3:
        # __unicode__ unavailable in PY3
        class Foo(object):
            def __unicode__(self):
                return u'aa'
            def __str__(self):
                return 'aa'
        foo = Foo()
        assert to_native(foo) == 'aa'

        # str should work by default

# Generated at 2022-06-20 16:20:10.423837
# Unit test for function container_to_text
def test_container_to_text():
    f = container_to_text
    # This should not trace back
    assert f({'a': b'foo'}) == {u'a': u'foo'}
    # This will trace back (from the json module) because of the bad surrogate
    assert f({'a': b'\xff'}) == {u'a': u'\ufffd'}
    assert f({'a': u'foo'}) == {u'a': u'foo'}
    assert f([b'foo']) == [u'foo']
    assert f(['foo']) == [u'foo']
    assert f(b'foo') == u'foo'
    assert f('foo') == u'foo'

    # Unicode
    assert f(u'\u1234') == u'\u1234'

    # From the json module doc (

# Generated at 2022-06-20 16:20:41.021496
# Unit test for function container_to_text
def test_container_to_text():
    from six import unichr
    # Test a non-container argument
    assert container_to_text(10) == 10

    # Test bytestrings
    assert container_to_text(b'\xe2\x80\xa8') == unichr(8232)
    assert container_to_text(b'\xe2\x80\xa9') == unichr(8233)

    # Test a regular dictionary
    data = {
        b'a': b'foo',
        b'b': b'bar',
        unichr(8232): b'baz',
        unichr(8233): b'qux',
    }

# Generated at 2022-06-20 16:20:52.107059
# Unit test for function to_native
def test_to_native():
    from six import u
    from nose.tools import assert_equal

    assert_equal(u("he\N{LATIN SMALL LETTER E WITH ACUTE}llo"), to_native(u("he\N{LATIN SMALL LETTER E WITH ACUTE}llo")))
    assert_equal(u("he\N{LATIN SMALL LETTER E WITH ACUTE}llo"), to_native("he\N{LATIN SMALL LETTER E WITH ACUTE}llo"))
    assert_equal(u("he\N{LATIN SMALL LETTER E WITH ACUTE}llo"), to_native("he\xc3\xa9llo"))
    assert_equal(u("he\N{LATIN SMALL LETTER E WITH ACUTE}llo"), to_native("he\xe9llo"))

# Generated at 2022-06-20 16:20:55.174256
# Unit test for function container_to_text
def test_container_to_text():
    ''' function to test container_to_text for ansiballz '''
    pass


# This import should be at the bottom of the module to avoid circular imports.
from ansible.module_utils.six.moves import shlex_quote

# Generated at 2022-06-20 16:21:03.757586
# Unit test for function to_bytes
def test_to_bytes():
    if PY3:
        def surrogate_or_strict(unistr):
            return to_bytes(unistr, errors='surrogate_or_strict')

        def surrogate_or_replace(unistr):
            return to_bytes(unistr, errors='surrogate_or_replace')

        def surrogate_then_replace(unistr):
            return to_bytes(unistr, errors='surrogate_then_replace')

        # Have to be careful with the encode/decode here because we're
        # decoding/encoding to latin-1 which loses data
        # \uFFFC is a replacement character
        latin1_bomb = '\uFFFD'
        # \uFFFD is a replacement character
        latin1_replacement = '\uFFFD'
        latin1_

# Generated at 2022-06-20 16:21:09.820364
# Unit test for function container_to_text
def test_container_to_text():
    #dict
    d = {u"key1": u"value1", "key2": "value2"}
    assert container_to_text(d) == {u"key1": u"value1", u"key2": u"value2"}
    d = {"key1": "value1", b"key2": b"value2"}
    assert container_to_text(d) == {u"key1": u"value1", u"key2": u"value2"}
    d = {u"key1": u"value1", b"key2": b"value2"}
    assert container_to_text(d) == {u"key1": u"value1", u"key2": u"value2"}
    #list
    d = [u"value1", "value2"]

# Generated at 2022-06-20 16:21:13.137773
# Unit test for function jsonify
def test_jsonify():
    string = '{"test": "value"}'
    string = json.loads(string)
    json_string = jsonify(string)
    assert isinstance(json_string, str)



# Generated at 2022-06-20 16:21:22.282343
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' Unit test for module function container_to_bytes '''
    assert isinstance(container_to_bytes({'key': 'value', 'key2': 'value2'}, 'utf-8'), dict)
    assert isinstance(container_to_bytes({'key': 'value', 'key2': 'value2'}, 'utf-8'), dict)
    assert isinstance(container_to_bytes(['value', 'value2'], 'utf-8'), list)

    my_obj = {'key1': 'value', 'key2': ['value2', 'value3'], 'key3': ('value2', 'value3'),
              'key4': {'key5': 'value5'}, 'key6': '中文'}
    # my_obj_utf8 = {'key1': b'value', 'key2': [

# Generated at 2022-06-20 16:21:30.672487
# Unit test for function to_bytes

# Generated at 2022-06-20 16:21:42.390057
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\xc5.\xe5') == u'\xc5.\xe5'
    assert to_native('\xc5.\xe5') == u'\xc5.\xe5'
    assert to_native(b'\xc5.\xe5', errors='surrogate_or_strict') == u'\xc5.\xe5'
    assert to_native(b'\xc5.\xe5', errors='surrogate_or_replace') == u'\xc5.\xe5'
    assert to_native(b'\xc5.\xe5', errors='replace') == u'\ufffd.\ufffd'
    if PY3:
        assert to_native(b'\xc5.\xe5', errors='surrogate_or_strict') == u

# Generated at 2022-06-20 16:21:50.658951
# Unit test for function container_to_bytes
def test_container_to_bytes():
    result_dict = container_to_bytes(dict(a=b'a', b='b'))
    expected_dict = dict(a=b'a', b=b'b')
    assert result_dict == expected_dict

    result_list = container_to_bytes([dict(a=b'a', b='b'), dict(c='c', d=b'd')])
    expected_list = [dict(a=b'a', b=b'b'), dict(c=b'c', d=b'd')]
    assert result_list == expected_list

    result_tuple = container_to_bytes((dict(a=b'a', b='b'), dict(c='c', d=b'd')))

# Generated at 2022-06-20 16:22:17.513652
# Unit test for function to_bytes
def test_to_bytes():
    for u in [u'abc', u'\xac\u1234\u20ac\U00008000', u'\ue000', u'\ue001\uefff', u'\ue000\u20ac', u'\ue000a', u'\ue000\u20aca']:
        for e in (None, 'latin-1', 'utf-8', 'utf-16', 'utf-32'):
            for n in ('strict', 'empty', 'simplerepr', 'passthru'):
                if e not in ('utf-16', 'utf-32') or not HAS_SURROGATEESCAPE or n in ('strict', 'empty'):
                    try:
                        x = to_bytes(u, e, n)
                    except UnicodeEncodeError:
                        x = None
                    assert x is None



# Generated at 2022-06-20 16:22:24.893492
# Unit test for function container_to_text
def test_container_to_text():
    test_data = {
        u'test_bytes': b'data',
        u'test_unicode': u'data',
        u'test_nested': {
            b'byte_key': b'byte_value',
            u'unicode_key': u'unicode_value',
            b'nested_dict': {
                b'byte_key': b'byte_value',
                u'unicode_key': u'unicode_value',
            },
        },
    }

    result = container_to_text(test_data)
    assert isinstance(result, dict)
    assert 'test_bytes' in result
    assert isinstance(result['test_bytes'], text_type)

    assert 'test_unicode' in result

# Generated at 2022-06-20 16:22:35.849048
# Unit test for function container_to_text
def test_container_to_text():
    ## Valid UTF-8
    # Lists
    assert container_to_text([1]) == [1]
    assert container_to_text([u'\u7B49']) == [u'\u7B49']
    # Tuples
    assert container_to_text((1,)) == (1,)
    assert container_to_text((u'\u7B49',)) == (u'\u7B49',)
    # Dicts
    assert container_to_text(dict(a=1)) == dict(a=1)
    assert container_to_text(dict(a=u'\u7B49')) == dict(a=u'\u7B49')

    ## Invalid UTF-8
    # Lists
    assert container_to_text([1]) == [1]
    assert container_to_text

# Generated at 2022-06-20 16:22:46.940647
# Unit test for function to_native
def test_to_native():
    assert to_native(dict(a=1, b=2)) == dict(a=1, b=2)
    assert to_native(dict(a='some', b='some')) == dict(a=b'some', b=b'some')
    assert to_native(dict(a=1, b='some')) == dict(a=1, b=b'some')
    assert to_native(dict(a='some', b=dict(c='foo'))) == dict(a=b'some', b=dict(c=b'foo'))
    assert to_native(dict(a=dict(b='some'))) == dict(a=dict(b=b'some'))

# Generated at 2022-06-20 16:22:59.533440
# Unit test for function jsonify
def test_jsonify():
    class MyObj:
        pass
    data = {
        'from_unicode': u'Ivan Krsti\u0107',
        'from_str': 'Ivan Krstić',
        'from_bytes': 'Ivan Krstić'.encode('utf-8'),
        'from_obj': MyObj(),
        'from_set': set(['Ivan Krstić', 'Ivan Krstić']),
        'from_list': [u'Ivan Krsti\u0107'],
    }

# Generated at 2022-06-20 16:23:09.826776
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": str(b"\xc3\x80")}) == '{"a": "\\u00c3\\u0080"}'
    assert jsonify({"a": str(b"\xc3\x80".decode("latin-1"))}) == '{"a": "\\u00c0"}'
    assert jsonify({"a": str(b"\xc3\x80".decode("utf-8"))}) == '{"a": "\\u00c3\\u0080"}'
    assert jsonify({"a": str(b"\xc3\x80".decode("utf-8")).encode("latin-1")}) == '{"a": "\\u00c3\\u0080"}'



# Generated at 2022-06-20 16:23:19.740208
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(b'foo') == 'foo'
    assert container_to_text(u'foo') == u'foo'
    assert container_to_text([1, 2, 3]) == [1, 2, 3]
    assert container_to_text((1, 2, 3)) == (1, 2, 3)
    assert container_to_text({b'foo': b'bar', u'baz': u'qux'}) == {u'foo': u'bar', u'baz': u'qux'}
    assert container_to_text((b'foo', u'bar')) == (u'foo', u'bar')
    assert container_to_text([b'foo', u'bar']) == [u'foo', u'bar']

# Generated at 2022-06-20 16:23:30.593259
# Unit test for function container_to_text
def test_container_to_text():
    # byte -> byte does nothing
    assert container_to_text(b'hello') == b'hello'
    # byte -> text decodes
    assert container_to_text(b'\251\255') == u'\ufffd\ufffd'
    # text -> text does nothing
    assert container_to_text(u'\u2265') == u'\u2265'
    # test some container types
    assert container_to_text({b'test': b'\251\255'}) == {u'test': u'\ufffd\ufffd'}
    assert container_to_text([b'\251\255']) == [u'\ufffd\ufffd']
    assert container_to_text((b'\251\255',)) == (u'\ufffd\ufffd',)
    # mixed encoding
   

# Generated at 2022-06-20 16:23:38.767555
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test a normal byte string
    assert container_to_bytes(u'test') == u'test'
    # Test a normal unicode string
    assert container_to_bytes(u'\u263a') == u'\u263a'
    # Test a list that contains a normal unicode string
    assert container_to_bytes([u'\u263a']) == [u'\u263a']
    # Test a dict that contains a unicode string
    assert container_to_bytes({'a': '\u263a'}) == {'a': '\u263a'}
    # Test a dict that contains a list that contains a unicode string
    assert container_to_bytes({'a': [u'\u263a']}) == {'a': [u'\u263a']}
    # Test a list that contains

# Generated at 2022-06-20 16:23:49.585326
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' Test for container_to_bytes '''
    assert b'a' == container_to_bytes(u'a')
    assert b'a' == container_to_bytes(b'a')
    assert b'a' == container_to_bytes('a')
    assert b'a' == container_to_bytes(u'a', errors='surrogate_or_strict')
    assert b'a' == container_to_bytes(b'a', errors='surrogate_or_strict')
    assert b'a' == container_to_bytes('a', errors='surrogate_or_strict')

    # Test a dictionary
    test_dict = container_to_bytes({u'foo': u'bar', 'baz': 'qux'})
    assert isinstance(test_dict, dict)

# Generated at 2022-06-20 16:24:17.414644
# Unit test for function container_to_text
def test_container_to_text():
    d= {'key1':1, 'key2':2, 'key3':3, 'key4':4}
    e= {'key1':'1', 'key2':'2', 'key3':'3', 'key4':'4'}

    if PY3:
        assert(container_to_text(d) == e)
        f = {to_bytes(x):y for (x,y) in iteritems(d)}
        assert(f != d)
        assert(container_to_text(f) == e)
    else:
        assert(container_to_text(d) == d)
        f = {to_bytes(x):y for (x,y) in iteritems(d)}
        assert(f != d)

# Generated at 2022-06-20 16:24:17.984280
# Unit test for function to_bytes
def test_to_bytes():
    pass

# Generated at 2022-06-20 16:24:26.218913
# Unit test for function to_native
def test_to_native():
    # Parameter Types
    assert to_native(None) == None
    assert to_native(text_type('')) == u''
    assert to_native('/foo/bar') == 'foo/bar'
    assert to_native({u'foo': 'bar'}) == {'foo': 'bar'}
    assert to_native({u'foo': u'bar'}) == {'foo': 'bar'}
    assert to_native({u'foo': {u'bar': u'baz'}}) == {'foo': {'bar': 'baz'}}

# Generated at 2022-06-20 16:24:37.461511
# Unit test for function to_native
def test_to_native():
    # tests for to_native which should be identical to type(obj)==unicode
    # on py2 and type(obj)==str on py3
    assert to_native(u'foo') == u'foo'  # unicode string on py2, str on py3
    assert to_native(b'foo') == u'foo'  # assume utf-8, should convert py2/py3
    # only works on python 3.x, because there are no non-ascii chars
    # check if it's ok for unicode() to return native strings
    # also, assume utf-8 when converting bytes to text/unicode
    assert to_native(b'\xc3\x86\xc3\xa6\xc3\x98') == u'ÆæØ'
    # also ok to pass in a native string,

# Generated at 2022-06-20 16:24:49.435378
# Unit test for function container_to_text
def test_container_to_text():
    # test for simple dict and list in text type
    test_dict_text = {'test': 'success'}
    test_list_text = [1, 2, 3, 4]
    assert container_to_text(test_dict_text) == test_dict_text
    assert container_to_text(test_list_text) == test_list_text
    # test for simple dict and list in byte type
    test_dict_byte = {b'test': b'success'}
    test_list_byte = [b'1', b'2', b'3', b'4']
    assert container_to_text(test_dict_byte) == test_dict_text
    assert container_to_text(test_list_byte) == test_list_text
    # test for nest type
    test_nest_dict

# Generated at 2022-06-20 16:24:51.160373
# Unit test for function jsonify
def test_jsonify():
    if 'b' in __name__:
        assert True
    else:
        assert False


# Generated at 2022-06-20 16:24:59.781895
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.utils.unicode import to_bytes, to_text
    if PY3:
        # Python 2 already accepts binary in json output
        class BinStr(bytes):
            def __repr__(self):
                return to_text(super(BinStr, self).__repr__(), 'ascii')

            def __str__(self):
                return to_text(super(BinStr, self).__str__(), 'ascii')

        class UnicodeBinStr(str):
            def __repr__(self):
                return to_text(super(UnicodeBinStr, self).__repr__(), 'ascii')

            def __str__(self):
                return to_text(super(UnicodeBinStr, self).__str__(), 'ascii')

        assert json

# Generated at 2022-06-20 16:25:11.833929
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(dict(a=1, b=2)) == dict(a=1, b=2)
    assert container_to_text(dict(a=1, b=2), encoding='utf-8') == dict(a=1, b=2)
    assert container_to_text(dict(a=1, b=2), errors='ignore') == dict(a=1, b=2)
    assert container_to_text(dict(a=1, b=2), nonstring='passthru') == dict(a=1, b=2)
    assert container_to_text(list(range(10))) == list(range(10))
    assert container_to_text(list(range(10)), encoding='utf-8') == list(range(10))