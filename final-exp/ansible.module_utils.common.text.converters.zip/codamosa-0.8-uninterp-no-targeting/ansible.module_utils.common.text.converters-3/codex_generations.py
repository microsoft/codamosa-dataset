

# Generated at 2022-06-20 16:15:29.778721
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2713') == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16'), ensure_ascii=False) == '"\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16be')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16le')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-32')) == '"\\u2713"'

# Generated at 2022-06-20 16:15:40.928202
# Unit test for function to_native
def test_to_native():
    for test_value in [
        b'Hello World',
        u'Hello World!',
        1,
        u'😀',
        [u'😀', b'Hello World'],
        dict(((u'😀', b'Hello World'),)),
        set((u'😀', b'Hello World')),
        frozenset((u'😀', b'Hello World')),
        (i for i in range(2)),
        True,
    ]:
        expected = str(test_value)
        got = to_native(test_value)
        assert expected == got, "Expected %s, got %s from %s" % (expected, got, test_value)


# Generated at 2022-06-20 16:15:49.544225
# Unit test for function to_native
def test_to_native():
    assert to_native('string') == 'string'
    assert to_native(b'bytes') == 'bytes'
    assert to_native(u'unicode') == u'unicode'
    assert to_native(None) == None
    class Foo(object):
        pass
    assert to_native(Foo) == repr(Foo)
    class Bar(object):
        def __repr__(self):
            raise UnicodeError()
    assert to_native(Bar()) == str(Bar())



# Generated at 2022-06-20 16:16:01.363387
# Unit test for function to_bytes
def test_to_bytes():
    # pylint: disable=invalid-name

    def _test_encoding(text_string, encoding='utf-8', errors='surrogate_then_replace'):
        # This is a helper function to test the 'surrogate_then_replace' encoding
        # when surrogateescape is available, it should use surrogateescape followed
        # by replace.
        # When surrogateescape is not available, it should use replace

        # Convert text to bytes
        bytes_string = to_bytes(text_string, encoding, errors=errors)

        # Convert bytes back to text
        # If surrogateescape, this should be the same
        # If replace, this should have replaced non-encodable data
        recovered_text = to_text(bytes_string, encoding, errors='replace')

        # Check that the bytes form is the same as the text form if using surrogate

# Generated at 2022-06-20 16:16:13.502076
# Unit test for function container_to_bytes
def test_container_to_bytes():
    sample_data = {
        u'foo': u'bar',
        u'spam': [u'ham', u'egss'],
        u'empty': [],
        u'numbers': [1, 2, 3],
        u'nested': {
            u'a': u'b',
            u'c': u'd',
        },
        u'none': None,
    }

    c2b_utf8 = container_to_bytes(sample_data)
    assert c2b_utf8['foo'] == b'bar'
    assert isinstance(c2b_utf8['foo'], binary_type)
    assert isinstance(c2b_utf8['spam'], list)
    assert c2b_utf8['spam'][0] == b'ham'
    assert c2b

# Generated at 2022-06-20 16:16:21.773086
# Unit test for function to_native
def test_to_native():
    from collections import OrderedDict
    from datetime import datetime
    from datetime import date
    from datetime import time

    assert to_native(u'text') == u'text'
    assert to_native(b'text') == u'text'

    assert to_native(u'\xe9') == u'\xe9'
    assert to_native(b'\xe9') == u'\xe9'

    assert to_native(u'\xe9'.encode('cp1252')) == u'\xe9'
    assert to_native(b'\xe9'.decode('cp1252')) == u'\xe9'

    assert to_native(u'\u2013') == u'\u2013'
    assert to_native(b'\xe2\x80\x93') == u

# Generated at 2022-06-20 16:16:27.860304
# Unit test for function jsonify
def test_jsonify():
    cache_dir = '/tmp'
    data_dir = '/tmp'
    data = dict(cache_dir=cache_dir, data_dir=data_dir, ansible_facts=dict(key1='val1'))
    json_data = jsonify(data)
    assert json_data == '{"cache_dir": "/tmp", "data_dir": "/tmp", "ansible_facts": {"key1": "val1"}}'



# Generated at 2022-06-20 16:16:40.335590
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(['b\xe9b\xe9', 'b\xe9b\xe9']) == [u'b\xe9b\xe9', u'b\xe9b\xe9']
    assert container_to_text({'b\xe9b\xe9': 'blah'}) == {u'b\xe9b\xe9': u'blah'}
    assert container_to_text(('b\xe9b\xe9', 'blah')) == (u'b\xe9b\xe9', u'blah')

# Generated at 2022-06-20 16:16:51.029806
# Unit test for function to_bytes
def test_to_bytes():
    #Test normal functionality
    assert b'123' == to_bytes(123)
    assert b'foo' == to_bytes('foo')
    assert b"foo" == to_bytes(u"foo")
    assert b'foo' == to_bytes(u'foo', errors='strict')
    assert b'foo' == to_bytes('foo', errors='strict')
    assert b'foo' == to_bytes('foo', errors='surrogate_or_strict')
    assert b'foo' == to_bytes(u'foo', errors='surrogate_or_strict')
    assert b'foo' == to_bytes('foo', errors='surrogate_or_replace')
    assert b'foo' == to_bytes(u'foo', errors='surrogate_or_replace')

# Generated at 2022-06-20 16:16:57.477044
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Build the test data
    test_string = u'\u00f6l' # unicode o-umlaut

    test_list_of_dict = [
        {u'name': u'Ansible', u'key': u'value'},
        {u'name': test_string, u'key': u'value'},
    ]

    test_dict = {
        u'a_string': test_string,
        u'a_list': test_list_of_dict,
        u'a_tuple': tuple(test_list_of_dict),
    }

    test_list = [
        u'a_string',
        test_dict,
        test_list_of_dict,
    ]


# Generated at 2022-06-20 16:17:17.946987
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.six import text_type
    data = {'foo': [1, 2, 3, {'bar': 'baz', 'quux': True}]}
    assert jsonify(data) == '{"foo": [1, 2, 3, {"bar": "baz", "quux": true}]}'
    data = {'foo': [1, 2, 3, {'bar': 'baz', 'quux': True}]}
    assert (jsonify(data, separators=(',', ':')) ==
            '{"foo":[1,2,3,{"bar":"baz","quux":true}]}')
    data = {'foo': [1, 2, 3, {'bar': 'baz', 'quux': True}]}

# Generated at 2022-06-20 16:17:21.167865
# Unit test for function to_native
def test_to_native():
  data = {1: "Hello", 2: "World", 3: "123456"}
  assert to_native(data) == {1: "Hello", 2: "World", 3: "123456"}

# Generated at 2022-06-20 16:17:32.759296
# Unit test for function to_bytes
def test_to_bytes():
    # Test text string encoded as utf-8 and ascii
    utf8_string = "Iñtërnâtiônàlizætiøn"
    ascii_string = utf8_string.encode('ascii', 'ignore').decode('ascii')
    try:
        codecs.lookup('surrogateescape')
        surrogateescape = True
    except LookupError:
        surrogateescape = False

    for string in (utf8_string, ascii_string):
        for encoding in ('utf-8', 'ascii', 'latin-1'):
            for errors in ('strict', 'replace', 'ignore'):
                assert to_bytes(string, encoding, errors) == string.encode(encoding, errors)

    # Test surrogateescape
    # surrogateescape doesn

# Generated at 2022-06-20 16:17:42.487252
# Unit test for function to_native
def test_to_native():
    import sys
    if sys.version_info[0] == 2 and sys.version_info[1] == 7:
        import  importlib
        importlib.reload(sys)
        sys.setdefaultencoding('utf-8')
    assert to_native(u'\xe4\xbd\xa0\xe5\xa5\xbd', 'utf-8') == u'\xe4\xbd\xa0\xe5\xa5\xbd'.encode('utf-8')
    assert to_native(u'\xe4\xbd\xa0\xe5\xa5\xbd', 'utf-8', 'surrogate_then_replace') == u'\xe4\xbd\xa0\xe5\xa5\xbd'.encode('utf-8')

# Generated at 2022-06-20 16:17:53.637645
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # test bad type
    assert container_to_bytes(1) == 1
    assert container_to_bytes("a") == b'a'
    assert container_to_bytes("a".encode("utf-8")) == b'a'
    assert container_to_bytes("Invalid unicode character " + chr(0xf8) + " will raise a UnicodeDecodeError") == \
        b'Invalid unicode character \xc3\xb8 will raise a UnicodeDecodeError'
    assert container_to_bytes("Invalid unicode character " + chr(0xf8) + " will be replaced if errors is surrogate_or_replace",
                              errors='surrogate_or_replace') == b'Invalid unicode character \xef\xbf\xbd will be replaced if errors is surrogate_or_replace'

# Generated at 2022-06-20 16:18:03.229499
# Unit test for function container_to_bytes

# Generated at 2022-06-20 16:18:16.046438
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import b
    assert to_bytes('asdf\xe2\x99') == b('asdf\xe2\x99')
    # Testing surrogateescape
    if HAS_SURROGATEESCAPE:
        # This will encode with surrogateescape and then decode back to the original string
        assert to_bytes(u'\xd83c\xdf75') == b('\xf0\x9f\x8f\xb5')
        assert to_bytes(b('\xf0\x9f\x8f\xb5').decode('utf-8', 'surrogateescape'), 'latin-1') == b('\xf0\x9f\x8f\xb5')
        assert to_

# Generated at 2022-06-20 16:18:23.030487
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2713') == u'"\u2713"'
    assert jsonify({u'\u2713': True}) == u'{"\\u2713": true}'
    assert jsonify({u'\u2713': u'\u2713'}) == u'{"\\u2713": "\\u2713"}'
    assert jsonify(['\u2713']) == u'["\\u2713"]'
    assert jsonify(u'\u2713\u2713') == u'"\\u2713\\u2713"'



# Generated at 2022-06-20 16:18:35.851786
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_dict = dict(
        test_list=[dict(ansible='awesome'), 4],
        test_tuple=(dict(python='looks good'), u'unicode', 'byte_string'),
        test_dict=dict(unicode=u'unicode', byte_string='byte_string')
    )
    # Convert dict to byte_string
    new_dict = container_to_bytes(test_dict)
    # Check if all elements were converted to byte_string
    for k, v in iteritems(new_dict):
        assert(isinstance(k, binary_type))
        assert(isinstance(v, binary_type))
        if isinstance(v, dict):
            for inner_k, inner_v in iteritems(v):
                assert(isinstance(inner_k, binary_type))

# Generated at 2022-06-20 16:18:44.698773
# Unit test for function jsonify
def test_jsonify():
    data = {"foo": u"bar", u"baz": "qux"}
    assert jsonify(data)
    data = {"foo": u"bar", u"baz": u"\xFF"}
    assert "Invalid" not in jsonify(data)
    data = {"foo": u"bar", u"baz": u"\xFF"}
    assert "Invalid" not in jsonify(data)
    data = {"foo": u"bar", u"baz": u"\xFF"}
    assert "Invalid" not in jsonify(data)



# Generated at 2022-06-20 16:19:01.046272
# Unit test for function to_native
def test_to_native():
    """
    Basic unit test to make sure we have a to_native function that
    is working.
    """
    assert isinstance(to_native(u'foobar'), text_type)
    assert isinstance(to_native(b'foobar'), text_type)
    assert to_native(u'foobar') == u'foobar'
    assert to_native(b'foobar') == u'foobar'



# Generated at 2022-06-20 16:19:10.567329
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('abc') == b'abc'
    assert to_bytes('abc', nonstring='empty') == b''
    assert to_bytes(u'\N{SNOWMAN}') == b'\xe2\x98\x83'
    assert to_bytes(5, nonstring='passthru') == 5
    assert to_bytes(u'\N{SNOWMAN}', encoding='latin-1') == b'?\xe2\x98\x83'
    assert to_bytes(u'abcdef\ud800') == b'abcdef\ud800'
    assert to_bytes(u'abcdef\ud800', errors='surrogate_or_replace',
        encoding='ascii') == b'abcdef?'

# Generated at 2022-06-20 16:19:21.944025
# Unit test for function to_native
def test_to_native():
    class Foo(object):
        def __str__(self):
            return b'this is a str'

        def __repr__(self):
            return b'this is a repr'

    assert to_native(Foo()) == 'this is a str'

    assert to_native(b'this is a text string') == 'this is a text string'
    assert to_native(b'this is a text string'.decode('ascii')) == 'this is a text string'
    assert to_native(u'this is a text string') == 'this is a text string'

    class Foo2(object):
        def __unicode__(self):
            return u'unicode method'

        def __str__(self):
            return b'bytes method'


# Generated at 2022-06-20 16:19:30.816886
# Unit test for function jsonify
def test_jsonify():
    jdata = jsonify({'a': 'a'})
    assert isinstance(jdata, text_type)
    jdata = jsonify({'a': 'a'.encode('utf-8')})
    assert isinstance(jdata, text_type)
    jdata = jsonify({'a': 'a'.encode('latin1')})
    assert isinstance(jdata, text_type)
    jdata = jsonify({'a': 'a'.encode('latin-1')})
    assert isinstance(jdata, text_type)
    jdata = jsonify({'a': b'a'})
    assert isinstance(jdata, text_type)
    jdata = jsonify({'a': b'a'.decode('utf-8')})
    assert isinstance(jdata, text_type)


# Generated at 2022-06-20 16:19:38.762327
# Unit test for function to_bytes
def test_to_bytes():

    # If a byte string is passed in, it is returned unchanged
    assert to_bytes(b'\x41\x42\x43\xe9', nonstring='simplerepr') is b'\x41\x42\x43\xe9'

    # If a text string is passed in it is encoded correctly
    assert to_bytes('\u043a\u0438\u0440\u0438\u043b\u043b\u0438\u0446\u0430', nonstring='simplerepr') == b'\xd0\xba\xd0\xb8\xd1\x80\xd0\xb8\xd0\xbb\xd0\xbb\xd0\xb8\xd1\x86\xd0\xb0'

    # If an int is passed in it is converted to a text string and

# Generated at 2022-06-20 16:19:44.082163
# Unit test for function to_native
def test_to_native():
    """ Unit test for function to_native """
    def _test_helper(test_value, test_encoding, test_errors,
                     test_nonstring, test_expect):
        """ Helper function for function test_to_native """
        test_result = to_native(test_value,
                                encoding=test_encoding,
                                errors=test_errors,
                                nonstring=test_nonstring)
        assert test_result == test_expect

    test_encoding = 'utf-8'
    test_errors = None
    test_nonstring = 'simplerepr'
    # test_value consist of bytes, text, and non-string data types
    # test_expect consist of matching string data types
    # text same as orig, bytes same as text
    test_value = "This is a test"

# Generated at 2022-06-20 16:19:49.754520
# Unit test for function container_to_text
def test_container_to_text():
    # Recursively convert text and bytes in dict, list and tuple to string
    # Use json.loads to convert dict to dict, list to list and tuple to tuple
    # Origin dict
    d = {'name': [u'zhang', 'san', b'\xe5\x8f\xa3\xe7\xbd\xa9'],
         'age': ('30', '40')}
    # Convert dict to dict
    assert container_to_text(json.loads(json.dumps(d))) == d
    # Convert list to list
    l = [u'zhang', 'san', b'\xe5\x8f\xa3\xe7\xbd\xa9']
    assert container_to_text(json.loads(json.dumps(l))) == l
    # Convert tuple to tuple

# Generated at 2022-06-20 16:19:57.547786
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({"foo": [1, "bar"]}) == {"foo": [1, "bar"]}
    assert isinstance(container_to_bytes({"foo": [1, "bar"]})['foo'][1], binary_type)
    assert container_to_bytes({"foo": [1, "bar"]}, errors='surrogate_or_replace') == {"foo": [1, "bar"]}
    assert isinstance(container_to_bytes({"foo": [1, "bar"]}, errors='surrogate_or_replace')['foo'][1], binary_type)
    assert container_to_bytes({"foo": [1, "bar"]}, errors='strict') == {"foo": [1, "bar"]}

# Generated at 2022-06-20 16:20:05.286810
# Unit test for function container_to_bytes
def test_container_to_bytes():
    def deep_compare(d1, d2):
        if isinstance(d1, dict):
            assert isinstance(d2, dict)
            for key, value in iteritems(d1):
                if key not in d2:
                    return False
                if not deep_compare(value, d2[key]):
                    return False
            return True
        elif isinstance(d1, (list, tuple)):
            assert isinstance(d2, (list, tuple))
            return all(deep_compare(c1, c2) for c1, c2 in zip(d1, d2))
        elif isinstance(d1, binary_type):
            assert isinstance(d2, binary_type)
            return d1 == d2
        else:
            return d1 == d2

# Generated at 2022-06-20 16:20:10.238017
# Unit test for function container_to_text
def test_container_to_text():
    # We test with repr to avoid issues with the u prefix on Python2
    input_dict = {b'key1': b'value1',
           b'key2': b'value2',
           b'key3': [b'valu\xe9'],
           b'key4': {b'key5': b'valu\xe9'},
           b'key6': [b'valu\xe9', {b'key7': [b'valu\xe9']}]}

# Generated at 2022-06-20 16:20:33.519861
# Unit test for function container_to_bytes

# Generated at 2022-06-20 16:20:43.336115
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.common._collections_compat import StringIO
    import random
    import sys

    bytes_type = type(b'')
    text_type = type(u'')
    unicode_type = type(u'')

    # Try an empty byte string
    assert to_bytes(b'') == b''

    # Try an empty text string
    assert to_bytes(u'') == b''

    # Try a normal byte string
    assert to_bytes(b'ascii') == b'ascii'

    # Try a single character that is encodable ascii
    assert to_bytes(u'a') == b'a'

    # Try a single character that is not encodable in ascii

# Generated at 2022-06-20 16:20:48.506183
# Unit test for function jsonify
def test_jsonify():
    json.dump = []
    json.loads = []
    json_data = {'key1': 'value1'}
    result = jsonify(json_data)
    assert result == json.dumps(json_data, default=_json_encode_fallback, encoding = 'utf-8')


# Generated at 2022-06-20 16:20:57.429733
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(b'test') == b'"test"'
    assert jsonify(u'test') == b'"test"'
    assert jsonify(u'\xe9') == b'"\xc3\xa9"'
    assert jsonify({b'test': b'test'}) == b'{"test": "test"}'
    assert jsonify({u'test': u'test'}) == b'{"test": "test"}'
    assert jsonify({u'test': [u'test', u'\xe9']}) == b'{"test": ["test", "\xc3\xa9"]}'

    # Make sure we can serialize Set() containers
    assert jsonify(set(['test', 1])) == b'["test", 1]'

    # Make sure we can serialize datetime objects

# Generated at 2022-06-20 16:21:00.352989
# Unit test for function jsonify
def test_jsonify():
    data = {u'a': u'中文', 'b': 123}
    json_data = jsonify(data)
    assert json_data == '{"a": "\\u4e2d\\u6587", "b": 123}'



# Generated at 2022-06-20 16:21:11.017302
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(list()) == []
    assert container_to_bytes(dict()) == {}
    assert container_to_bytes(tuple()) == ()
    assert container_to_bytes(['a']) == [b'a']
    assert container_to_bytes((b'a',)) == (b'a',)
    assert container_to_bytes({'a': 'a'}) == {b'a': b'a'}
    assert container_to_bytes({'a': {'b': {'c': 'd'}}}) == {b'a': {b'b': {b'c': b'd'}}}

# Generated at 2022-06-20 16:21:20.793055
# Unit test for function container_to_text
def test_container_to_text():
    container_dict = {"a":"\xe2\x98\x83", "b": "\xe2\x98\x83".encode("utf-8"), "c":"test"}
    result = container_to_text(container_dict)
    assert(isinstance(result, dict))
    assert(result["a"] == "\xe2\x98\x83")
    assert(isinstance(result["b"], unicode))
    assert(result["c"] == "test")

    container_list = [container_dict, "\xe2\x98\x83", "\xe2\x98\x83".encode("utf-8"), "test"]
    result = container_to_text(container_list)
    assert(isinstance(result, list))


# Generated at 2022-06-20 16:21:30.155620
# Unit test for function jsonify
def test_jsonify():
    # Test data which contains unicode and binary strings
    data = {
        u'key1': b'value1',
        u'key2': u'value2',
        b'key3': u'value3',
        b'key4': b'value4'
    }
    assert jsonify(data) == '{"key1": "value1", "key2": "value2", "key3": "value3", "key4": "value4"}'
    # Test data which contains Set type
    data = {
        u'key1': Set([u'value1', b'value2']),
        u'key2': u'value3',
        b'key3': b'value4',
    }

# Generated at 2022-06-20 16:21:41.400570
# Unit test for function to_bytes

# Generated at 2022-06-20 16:21:50.446281
# Unit test for function container_to_bytes
def test_container_to_bytes():
    bytes_out = container_to_bytes({'a':u'test_nl\n', 'b':[u'test_nl\n', u'test_nl\n']})
    assert(bytes_out == {b'a':b'test_nl\n', b'b':[b'test_nl\n', b'test_nl\n']})
    bytes_out = container_to_bytes({u'test_nl\n':u'test_nl\n'})
    assert(bytes_out == {b'test_nl\n':b'test_nl\n'})
    bytes_out = container_to_bytes(u'test_nl\n')
    assert(bytes_out == b'test_nl\n')
    bytes_out = container_to_bytes(['test_nl\n'])
   

# Generated at 2022-06-20 16:22:35.482321
# Unit test for function container_to_text
def test_container_to_text():
    '''
    This function is used for unit test for function container_to_text.
    '''

    # object is instance of dict and contains some text, binary data
    data1 = {b'Test': u'\uFEE0',
             u'\uFEE1': b'Test',
             u'\uFEE2': u'\uFEE2'}
    # object is instance of list and contains some text, binary data
    data2 = [u'\uFEE0', b'Test', u'\uFEE0']
    # object is instance of tuple and contains some text, binary data
    data3 = (u'\uFEE0', b'Test', u'\uFEE0')
    # object is instance of binary data
    data4 = b'Test'
    # object is instance of text


# Generated at 2022-06-20 16:22:46.583864
# Unit test for function container_to_text
def test_container_to_text():
    test_dict = {'var1': 'bar', 'var2': {'var3': 'baz'}}
    assert container_to_text(test_dict) == {u'var1': u'bar', u'var2': {u'var3': u'baz'}}
    assert container_to_text(u'foo') == u'foo'
    assert container_to_text(b'foo') == u'foo'
    assert container_to_text(b'\xe6\x96\x87\xe5\xad\x97\xe7\xac\xa6\xe5\x8f\xb7') == u'\u6587\u5b57\u7b26\u53f7'

# Generated at 2022-06-20 16:22:55.851504
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes('foo', 'ascii') == b'foo'
    assert to_bytes(b'foo', 'ascii') == b'foo'
    assert to_bytes('foo', 'utf-8') == b'foo'
    assert to_bytes(b'foo', 'utf-8') == b'foo'
    assert to_bytes(u'foo', 'utf-8') == b'foo'
    assert to_bytes(u'foo', 'latin-1') == b'foo'
    assert to_bytes(b'foo\x80', 'utf-8', 'surrogateescape') == b'foo\x80'

# Generated at 2022-06-20 16:23:05.235271
# Unit test for function to_bytes
def test_to_bytes():
    def b(value):
        """This function makes it easier to specify byte string literals"""
        return to_bytes(value)

    def u(value):
        """This function makes it easier to specify text string literals"""
        return to_bytes(value, errors='surrogate_or_strict')

    assert u('\u263a') == b('\xe2\x98\xba')
    assert u('\ucafe') == b('\xed\xb2\x9e')
    assert u('\U00010203') == b('\xf0\x90\x8c\x83')
    assert u('\U00010000') == b('\xf0\x90\x80\x80')

    # Test surrogate pairs

# Generated at 2022-06-20 16:23:16.848588
# Unit test for function to_native
def test_to_native():
    """
    Test function to_native.
    """
    # py2.7 and py3.4 work a little differently here
    if PY3:
        native1 = u'abcabcabcabc'
        native2 = u'123123123123'
    else:
        native1 = 'abcabcabcabc'
        native2 = '123123123123'
    string = 'abc123'

    assert to_native(string) == native1, \
        'to_native() with a str failed, returned %s instead of %s' % (to_native(string), native1)

# Generated at 2022-06-20 16:23:29.497820
# Unit test for function container_to_text
def test_container_to_text():
    # Check a simple byte string.  This should return the unicode version of
    # the byte string
    d = container_to_text(b'abcdef\xe4\xe4')
    assert isinstance(d, text_type)
    assert d == u'abcdef\xe4\xe4'

    # Check a simple byte string wrapped in tuple.  This should return the
    # unicode version of the byte string wrapped in a tuple
    d = container_to_text((b'abcdef\xe4\xe4',))
    assert isinstance(d, tuple)
    assert len(d) == 1
    assert isinstance(d[0], text_type)
    assert d[0] == u'abcdef\xe4\xe4'

    # When we have a dict with an invalid value, we get an exception
    d = dict

# Generated at 2022-06-20 16:23:33.033969
# Unit test for function jsonify
def test_jsonify():
    import datetime
    data = {
        'x': 'ascii',
        'y': u'unicode \u1234',
        'z': datetime.datetime.utcnow()
    }
    encoded_data = to_bytes(jsonify(data))
    assert isinstance(encoded_data, binary_type)
    assert isinstance(json.loads(encoded_data), dict)
    assert json.loads(encoded_data) == container_to_bytes(data)



# Generated at 2022-06-20 16:23:39.015123
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils.common._collections_compat import Sequence
    for obj in (1, 1.1, set([1, 2, 1])):
        assert isinstance(to_native(obj), text_type)
    for obj in (None, NotImplemented, (1, 2), [1, 2], {'k': 'v'}):
        assert isinstance(to_native(obj), text_type)
        assert not isinstance(to_native(obj), binary_type)
    # The next 2 tests should pass in python3 only
    if PY3:
        assert isinstance(to_native(u'unicode'), binary_type)
        assert isinstance(to_native(b'bytes'), binary_type)



# Generated at 2022-06-20 16:23:49.703856
# Unit test for function container_to_text
def test_container_to_text():
    # simple case
    obj1 = {u'unicode': u'unicode string', 'string': 'byte string', u'uniencode': 'byte uniencode'}
    obj2 = {'unicode': 'unicode string', 'string': 'byte string', 'uniencode': 'byte uniencode'}
    assert (container_to_text(obj1, encoding='utf-8') == obj2)

    # list in dict
    obj1 = {'a': [u'unicode string', 1, 2.0]}
    obj2 = {'a': ['unicode string', 1, 2.0]}
    assert (container_to_text(obj1, encoding='utf-8') == obj2)

    # tuple in dict
    obj1 = {'a': (u'unicode string', 1, 2.0)}
   

# Generated at 2022-06-20 16:24:00.817406
# Unit test for function container_to_text
def test_container_to_text():
    ''' Unit test for function container_to_text '''

    # utf-8 encoded byte string
    utf8_encoded_byte_string = b'\xC3\xA9cole \xC3\xA9lectrique'
    # unicode string
    utf8_unicode_string = '\u00e9cole \u00e9lectrique'
    # iso-8859-1 encoded byte string
    iso_8859_1_encoded_byte_string = b'\xe9cole \xe9lectrique'
    # list, tuple and dict data structure containing text types
    utf8_list = [utf8_unicode_string, b'\xC3\xA9cole \xC3\xA9lectrique']

# Generated at 2022-06-20 16:24:52.607403
# Unit test for function to_native
def test_to_native():
    import json
    import os

    assert isinstance(to_native(u'foo'), text_type)
    assert isinstance(to_native('foo'), text_type)
    assert isinstance(to_native(u'\xe9'), text_type)
    assert isinstance(to_native(b'foo'), text_type)
    assert isinstance(to_native(b'\xc3\xa9'), text_type)

    assert u'\xe9' == to_native(u'\xe9')
    assert b'\xc3\xa9' == to_native(b'\xc3\xa9')

    # do you really want should you actually want to do this?
    assert b'\xc3\xa9' == to_native('\xe9')

# Generated at 2022-06-20 16:24:56.909812
# Unit test for function jsonify
def test_jsonify():
    json_data = jsonify({"a": "b"})
    print (json_data)
    print (type(json_data))
    assert json_data == '{"a": "b"}'
    assert isinstance(json_data, text_type)



# Generated at 2022-06-20 16:25:01.845316
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'abc': '中国'}) == '{"abc": "\\u4e2d\\u56fd"}'
    assert jsonify({'abc': '中国'}, ensure_ascii=False) == '{"abc": "中国"}'
    assert jsonify({'abc': [1, 2, 3], '中国': 'def'}, ensure_ascii=False) == '{"abc": [1, 2, 3], "\\u4e2d\\u56fd": "def"}'


# Generated at 2022-06-20 16:25:04.494028
# Unit test for function jsonify
def test_jsonify():
    data = {"a": "test", "b": "ansible"}
    assert jsonify(data) == '{"a": "test", "b": "ansible"}'



# Generated at 2022-06-20 16:25:16.069488
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1}) == "{\"a\": 1}"
    assert jsonify({'a': 1}, sort_keys=True) == "{\"a\": 1}"
    assert jsonify({'a': 1}, sort_keys=True, indent=4) == "{\n    \"a\": 1\n}"

    assert jsonify({"a": Set([1,2,3])}) == '{"a": [1, 2, 3]}'
    assert jsonify({"a": datetime.datetime(2012, 1, 14, 10, 45)}) == '{"a": "2012-01-14T10:45:00"}'
    assert jsonify({"a": {b"b": 1}}) == '{"a": {"b": 1}}'

