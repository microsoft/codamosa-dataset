

# Generated at 2022-06-20 16:15:28.525586
# Unit test for function to_native
def test_to_native():
    """Basic unit test to verify the to_native function
    """
    # Test to_native
    assert to_native(None) is None
    assert to_native(1) == 1
    assert to_native(u'bytes') == u'bytes'
    assert to_native('bytes') == u'bytes'
    assert to_native(b'bytes') == u'bytes'
    assert to_native(set()) == set()
    assert to_native(['item']) == ['item']
    assert to_native(u'föö') == u'föö'
    assert to_native('föö', encoding=None) == u'föö'
    assert to_native(b'f\xc3\xb6\xc3\xb6', encoding='utf-8') == u'föö'
    assert to

# Generated at 2022-06-20 16:15:39.658448
# Unit test for function to_bytes
def test_to_bytes():
    import sys

    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'fóo') == b'f\xc3\xb3o'
    assert to_bytes(u'fóo', encoding='ascii') == b'f\xc3\xb3o'
    assert to_bytes(u'fóo', errors='ignore') == b'fo'
    assert to_bytes(u'fóo', errors='replace') == b'f?o'
    assert to_bytes(u'fóo', errors='surrogateescape') == b'f\xf3o'
    assert to_bytes(u'fóo', encoding='ascii', errors='surrogateescape') == b'f\xf3o'

# Generated at 2022-06-20 16:15:51.615225
# Unit test for function container_to_text
def test_container_to_text():
    import unittest

    # Surrogate escape tests
    class TestSurrogateEscape(unittest.TestCase):
        def test_dict(self):
            d = container_to_text({'a': b'\xf1'})
            # surrogateescape will leave surrogate char in string
            self.assertEqual(d['a'], u'\udc31')
            self.assertIsInstance(d['a'], text_type)

        def test_list(self):
            l = container_to_text([1, b'\xf1'])
            # surrogateescape will leave surrogate char in string
            self.assertEqual(l[1], u'\udc31')
            self.assertIsInstance(l[1], text_type)

        def test_tuple(self):
            t = container_to_

# Generated at 2022-06-20 16:16:03.821461
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test encoding of string, list, tuple and dict
    test_str = u"G\u0283"
    test_str_bytes = to_bytes(test_str, encoding='utf-16')
    assert test_str_bytes == b"\xff\xfeG\x02\x83"

    test_list = [test_str, (0, 1, 2), [3, 4, 5]]
    test_list_bytes = container_to_bytes(test_list, encoding='utf-16')
    assert test_list_bytes == [test_str_bytes, (0, 1, 2), [3, 4, 5]]


# Generated at 2022-06-20 16:16:04.914553
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes("ascii") == "ascii"



# Generated at 2022-06-20 16:16:16.871725
# Unit test for function to_bytes
def test_to_bytes():
    assert (isinstance(to_bytes(u'string'), binary_type))
    assert (isinstance(to_bytes(b'string'), binary_type))
    assert (isinstance(to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442'), binary_type))
    assert (isinstance(to_bytes(u'\xe5\xae\x89\xe5\x85\xa8'), binary_type))
    assert (isinstance(to_bytes(('a', 'b')), binary_type))
    assert (isinstance(to_bytes(42), binary_type))
    assert (isinstance(to_bytes(True), binary_type))
    assert (isinstance(to_bytes(None), binary_type))

# Generated at 2022-06-20 16:16:28.321635
# Unit test for function container_to_text
def test_container_to_text():
    """
    Function to test container_to_text
    """

    # Test case 1
    test_dict_1 = {
        'test': 'foo'
    }
    # This should not return anything
    assert container_to_text(test_dict_1) == test_dict_1
    # This should not return anything
    assert container_to_text(test_dict_1, encoding='utf-8') == test_dict_1
    # This should not return anything
    assert container_to_text(test_dict_1, errors='surrogate_or_strict') == test_dict_1
    # This should return text type
    assert isinstance(container_to_text(test_dict_1, encoding='utf-8', errors='surrogate_or_strict'), dict)

    # Test case 2
    test

# Generated at 2022-06-20 16:16:40.811506
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'hello world') == b'hello world'
    assert to_bytes(u'hello world') == b'hello world'
    assert to_bytes(u'hello\xA0world') == b'hello\xc2\xa0world'
    assert to_bytes(u'hello\u1234world') == b'hello\xe1\x88\xb4world'
    # RFC 3492 says that punycode should %-encode non-ASCII chars. However
    # the Python IDNA codec doesn't actually do that.  Instead it lets the
    # unicode string through which we can't encode in ASCII
    assert to_bytes(u'hello\u1234world', encoding='ascii') == b'hello\u1234world'

    # We can force it to work by bypassing the codecs and hard

# Generated at 2022-06-20 16:16:47.284969
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {"key1": text_type("αβγ")}
    assert isinstance(to_bytes(d), binary_type)
    assert isinstance(d["key1"], text_type)
    d_bytes = container_to_bytes(d, encoding=u'utf-8')
    assert isinstance(d_bytes, dict)
    assert isinstance(d_bytes["key1"], binary_type)



# Generated at 2022-06-20 16:16:52.923069
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a='a')) == '{"a": "a"}'
    assert jsonify('\u4e2d\u6587') == '"\\u4e2d\\u6587"'
    assert jsonify(to_bytes('\u4e2d\u6587')) == '"\\u4e2d\\u6587"'



# Generated at 2022-06-20 16:17:05.789304
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test to_bytes for all possible types of inputs.
    assert container_to_bytes(u'abc') == 'abc'
    assert container_to_bytes('abc') == 'abc'
    assert container_to_bytes({u'def': u'ghi'}) == {'def': 'ghi'}
    assert container_to_bytes({'def': 'ghi'}) == {'def': 'ghi'}
    assert container_to_bytes([u'abc', u'def']) == ['abc', 'def']
    assert container_to_bytes(['abc', 'def']) == ['abc', 'def']
    assert container_to_bytes((u'abc', u'def')) == ('abc', 'def')
    assert container_to_bytes(('abc', 'def')) == ('abc', 'def')

   

# Generated at 2022-06-20 16:17:16.013156
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(u'unicode') == u'unicode'
    assert container_to_text('str') == 'str'
    assert container_to_text(1) == 1

    def _check(o):
        assert isinstance(o, dict)
        assert isinstance(o['k1'], text_type)
        assert isinstance(o['k2'], text_type)
        assert isinstance(o['k3'], text_type)
        assert isinstance(o['k4'], text_type)
        assert isinstance(o['k5'], text_type)

        assert o['k1'] == u'unicode'
        assert o['k2'] == u'str'
        assert o['k3'] == u'unicode'

# Generated at 2022-06-20 16:17:27.487987
# Unit test for function to_bytes
def test_to_bytes():
    # No string
    assert to_bytes(None) == b''
    assert to_bytes(10) == b'10'

    # Input is a byte string
    assert to_bytes(b'\x80\x80') == b'\x80\x80'

    # Input is a text string
    assert to_bytes(u'\xa9') == b'\xc2\xa9'

    # Input is a text string with an invalid utf8 character
    assert to_bytes(u'\u0100', errors='surrogateescape') == b'\xed\x80\x80'
    assert to_bytes(u'\u0100', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u0100', errors='surrogate_or_strict') == b'?'


# Generated at 2022-06-20 16:17:39.192908
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'hello', 'ascii') == b'hello'
    assert to_bytes(b'hello', 'ascii') == b'hello'
    assert to_bytes(u'\u1234', 'ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', 'ascii', 'surrogate_or_replace') == b'?'

    assert to_bytes(u'\u1234', 'ascii', 'surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', 'ascii', 'surrogate_then_replace') == b'?'


# Generated at 2022-06-20 16:17:50.659990
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(b'abc') == 'abc'
    assert container_to_text(b'\xcc\x81') == '\u0301'
    assert container_to_text(b'\xcc\x81'.decode('utf8', 'surrogateescape').encode('utf-8')) == '\xcc\x81'
    assert container_to_text(b'\xcc\x81'.decode('utf8', 'surrogateescape').encode('utf-8'), errors='surrogate_or_strict') == '\u0301'
# End of unit test for function container_to_text

if PY3:
    container_to_native = container_to_text
else:
    container_to_native = container_to_bytes


# Generated at 2022-06-20 16:18:01.308158
# Unit test for function container_to_text
def test_container_to_text():
    for teststring in [u'\u2211', u'\u2211']:
        for encoding in (b'utf-8', b'latin-1'):
            for byte_string in (True, False):
                for errors in ('surrogate_or_strict', 'surrogate_or_replace', 'surrogate_then_replace'):
                    if byte_string:
                        bytestring = to_bytes(teststring, encoding, errors)
                        obj = {'a': bytestring,
                               'b': [bytestring],
                               'c': (bytestring, bytestring),
                               'd': {bytestring: bytestring}}
                    else:
                        unistring = to_text(teststring, encoding, errors)

# Generated at 2022-06-20 16:18:09.230279
# Unit test for function jsonify
def test_jsonify():
    data = {u'bytes': "\xc3\xa9"}

    # old system with old simplejson module.
    json.dumps = lambda d, encoding=None, default=None: d

    assert jsonify(data) == {'bytes': "\xc3\xa9"}

    # data contains invalid unicode.
    data = {u'bytes': "\xc3\xe9"}
    try:
        jsonify(data)
    except UnicodeError:
        pass



# Generated at 2022-06-20 16:18:10.832489
# Unit test for function jsonify
def test_jsonify():
    json_str = jsonify({'a': 'a', 'b': 'b'})
    assert isinstance(json_str, str)


# Generated at 2022-06-20 16:18:20.463375
# Unit test for function container_to_text
def test_container_to_text():
    d_str = dict(a=1, b='foo', c=u'bar')
    d_unicode = dict(a=1, b='føø', c=u'bår')
    d_bytes = {'a':1, 'b':'føø'.encode('latin-1'), 'c':u'bår'.encode('latin-1')}
    l_unicode = [u'føø', u'bår', u'føø'.encode('latin-1'), u'bår'.encode('latin-1')]

# Generated at 2022-06-20 16:18:26.683491
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test data with text and byte str, unicode surrogates, and nonstring types
    data = {
        'test': 123,
        'byte': b'test',
        'unicode': u'\ud83d\udc2d',
        'text': 'test',
        'dict': {'text': 'test', 'unicode': u'\ud83d\udc2d', 'byte': b'test'},
        'list': [u'\ud83d\udc2d', 'test', b'test'],
        'tuple': (b'test', u'\ud83d\udc2d', 'test')
    }
    new_data = container_to_bytes(data)
    assert new_data['test'] == 123
    assert isinstance(new_data['test'], int)
   

# Generated at 2022-06-20 16:18:38.160062
# Unit test for function jsonify
def test_jsonify():
    data = {u'foo': u'bar'}
    assert jsonify(data) == u'{"foo": "bar"}'
    data = {u'foo': [u'bar']}
    assert jsonify(data) == u'{"foo": ["bar"]}'
    data = {u'foo': {u'bar': u'baz'}}
    assert jsonify(data) == u'{"foo": {"bar": "baz"}}'



# Generated at 2022-06-20 16:18:41.263409
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {'a': '1', 'b': [2, {'c': 3}]}
    print(container_to_bytes(d, 'utf-8'))
    print(container_to_bytes(d))


# Generated at 2022-06-20 16:18:52.422267
# Unit test for function to_bytes
def test_to_bytes():
    '''to_bytes'''
    # to_bytes can be called directly (it's defined in
    # ansible.module_utils.basic)
    if PY3:
        # When we can't decode the utf-8 string with surrogates then we get
        # a surrogateescape error
        assert to_bytes(b'f\xf0\x9f\x98\x81o', errors='surrogate_or_strict') == b'f\xf0\x9f\x98\x81o'
        assert to_bytes(b'f\xf0\x9f\x98\x81o', errors='surrogate_or_replace') == b'f\xf0\x9f\x98\x81o'

# Generated at 2022-06-20 16:19:04.689439
# Unit test for function container_to_bytes
def test_container_to_bytes():

    # Test for a variety of encodings
    for encoding in ('utf-8', 'utf-16', 'utf-32', 'latin-1'):

        # Create a text string that is sure to have non-latin characters and
        # create one that uses a different encoding as well
        non_latin_text = u'\xc8ab'
        other_encoding_text = non_latin_text.encode('utf-16').decode('utf-16')

        # Test to make sure that the to_bytes function works correctly
        assert to_bytes(other_encoding_text, encoding=encoding) == non_latin_text.encode(encoding)
        list_val = [u'abc', non_latin_text]

# Generated at 2022-06-20 16:19:12.670937
# Unit test for function jsonify
def test_jsonify():
    data = { "obj": { "name": u"测试" } }

    # set default encoding to utf-8
    test_jsonify.encoding = "utf-8"

    # Convert obj to byte string using default encoding
    def byteify(obj, **kwargs):
        # obj is a text string, return as byte string
        if isinstance(obj, text_type):
            return to_bytes(obj, encoding=test_jsonify.encoding)
        # obj is a container, recursively convert obj to byte string
        if isinstance(obj, list):
            return [byteify(element, **kwargs) for element in obj]
        if isinstance(obj, dict):
            return {byteify(key, **kwargs): byteify(value, **kwargs) for key, value in iteritems(obj)}

# Generated at 2022-06-20 16:19:23.242629
# Unit test for function to_native
def test_to_native():
    """Test to_native function
    """

    # Test for string
    for value in (u'a', u'a', b'a', b'a'):
        assert to_native(value) == u'a'

    # Test for dict
    data = dict(a=1, b=2)
    for value in (data, data, data, data):
        assert to_native(value) == data

    # Test for list
    data = [1, 2]
    for value in (data, data, data, data):
        assert to_native(value) == data

    # test for tuple
    data = (1, 2)
    for value in (data, data, data, data):
        assert to_native(value) == data

    # test for units.Quantity
    data = units.Quantity(1)

# Generated at 2022-06-20 16:19:28.866838
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = { 'abc': {},
          'def': [],
          'ghi': 123,
          u'jkl': (1,2,3),
          u'mno': {u'pqr':'stu'},
          u'vwx': [u'yz0']}
    dd = container_to_bytes(d)
    assert all(isinstance(x, str) for x in dd.keys())
    assert all(isinstance(x, str) for x in dd)
    assert all(isinstance(x, str) for x in dd.values())
    assert all(isinstance(x, int) for x in dd['ghi'])
    assert all(isinstance(x, int) for x in dd['jkl'])
    dd['mno']['pqr'] == 'stu'
   

# Generated at 2022-06-20 16:19:36.796542
# Unit test for function to_native
def test_to_native():
    """
    Test the to_native function.
    """
    # This should just return the value unchanged
    assert to_native(u'test') == u'test'
    assert to_native(b'test') == b'test'
    assert to_native(5) == 5
    # Surrogates should decode to their unicode code point
    assert to_native(b'\xff\xfe\x41\x01\x00') == u'\udc01A'
    # Other difficult characters should decode
    assert to_native(b'\x80\xc2\x80') == u'\u0080\u0080'
    assert to_native(b'\x80\xe0\x82\x80') == u'\u0800'



# Generated at 2022-06-20 16:19:43.031499
# Unit test for function to_bytes
def test_to_bytes():
    # Check common case
    utf8_string = u'\u2713'
    if PY3:
        assert isinstance(utf8_string, str)
        assert not isinstance(utf8_string, bytes)
    else:
        assert isinstance(utf8_string, unicode)  # noqa: F821
        assert not isinstance(utf8_string, str)
    assert b'\xe2\x9c\x93' == to_bytes(utf8_string)

    # Check errors
    if PY3:
        assert not isinstance(u'\udc80', str)
        assert isinstance(u'\udc80'.encode('utf-8', 'surrogateescape'), bytes)
    else:
        assert not isinstance(u'\udc80', unicode)  #

# Generated at 2022-06-20 16:19:49.511448
# Unit test for function container_to_bytes
def test_container_to_bytes():
    x = dict(ex1 = dict(x = "abc", y = [1, 2, 3]), ex2 = "def")
    y = container_to_bytes(x)
    x_str = to_bytes(x, encoding='utf8')
    y_str = to_bytes(y, encoding='utf8')
    assert x_str == y_str

# Generated at 2022-06-20 16:20:10.099923
# Unit test for function container_to_text
def test_container_to_text():
    # test string
    s = b'\x80\x81\x82\x83'
    try:
        to_text(s)
        assert False, "UnicodeDecodeError should be raised"
    except UnicodeDecodeError:
        to_text(s, errors='ignore')
        to_text(s, errors='replace')
        to_text(s, errors='surrogate_or_replace')
        to_text(s, errors='surrogate_or_strict')

    # test list
    l = [b'\x80\x81\x82\x83']
    try:
        container_to_text(l)
        assert False, "UnicodeDecodeError should be raised"
    except UnicodeDecodeError:
        container_to_text(l, errors='ignore')
       

# Generated at 2022-06-20 16:20:18.648049
# Unit test for function container_to_text
def test_container_to_text():
    d = {u'i\u1234': 'i\udcc4', 'i\udcc4': u'i\u1234', 'foo': 'bar'}
    # Convert to json
    e = jsonify(d)
    # Convert back to native strings
    f = container_to_text(json.loads(e))

    assert isinstance(f, dict)
    assert isinstance(f[u'i\u1234'], text_type)
    assert isinstance(f['i\udcc4'], text_type)
    assert isinstance(f['foo'], text_type)
    assert f[u'i\u1234'] == u'i\udcc4'
    assert f['i\udcc4'] == u'i\u1234'
    assert f['foo'] == 'bar'

# Generated at 2022-06-20 16:20:24.718886
# Unit test for function jsonify
def test_jsonify():
    # String examples
    unicode_fun = b'\xe2\x98\x83'.decode('utf-8')
    unicode_snowman = b'\xe2\x98\x83'.decode('utf-8')
    # unicode_fun is a smiley face
    assert unicode_fun == b'\xe2\x98\x83'.decode('utf-8')
    # unicode_snowman is a snowman
    assert unicode_snowman == b'\xe2\x98\x83'.decode('utf-8')
    # unicode string example
    unicode_string = unicode_fun
    # unicode string example

# Generated at 2022-06-20 16:20:31.470579
# Unit test for function jsonify
def test_jsonify():
    data = dict(
        ansible=1,
        ansible_facts=dict(
            os=dict(
                distribution=dict(
                    id='Debian',
                    version_id='7',
                    version='7'
                )
            )
        )
    )
    assert jsonify(data) == '{"ansible": 1, "ansible_facts": {"os": {"distribution": {"id": "Debian", "version": "7", "version_id": "7"}}}}'



# Generated at 2022-06-20 16:20:36.330929
# Unit test for function to_native
def test_to_native():

    def _assert_native_type(s):
        """Return True if the object has a native string type"""
        return isinstance(s, native_string_type)

    assert _assert_native_type(to_native(u'foo'))
    assert _assert_native_type(to_native('foo'))



# Generated at 2022-06-20 16:20:44.575615
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo', nonstring='simplerepr') == b'foo'
    assert to_bytes(u'foo', nonstring='passthru') == u'foo'
    assert to_bytes(u'foo', nonstring='empty') == b''
    try:
        to_bytes(u'foo', nonstring='strict')
        assert False, 'Expected to fail'
    except TypeError:
        pass
    try:
        to_bytes(u'foo', nonstring='invalid')
        assert False, 'Expected to fail'
    except TypeError:
        pass
    try:
        to_bytes(u'\u2028')
        assert False, 'Expected to fail'
    except UnicodeEncodeError:
        pass
    # Python2 doesn't have surrogate pairs

# Generated at 2022-06-20 16:20:52.105484
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.module_utils import jsonify
    jdata = jsonify({"a": u"b"})
    assert to_text(jdata) == u'{"a": "b"}'
    jdata = jsonify({"a": u"ч"})
    assert to_bytes(jdata) == b'{"a": "\\u0447"}'
    assert to_text(jdata) == u'{"a": "ч"}'



# Generated at 2022-06-20 16:20:59.794046
# Unit test for function container_to_bytes
def test_container_to_bytes():
    input_dict = {u'a': u'\xf6', 'b': {u'x': [1, 2, 3]}}
    assert container_to_bytes(input_dict) == {b'a': b'\xc3\xb6', b'b': {b'x': [1, 2, 3]}}
    assert container_to_bytes(input_dict, errors='surrogate_or_replace') == {b'a': b'\xc3\xb6', b'b': {b'x': [1, 2, 3]}}
    assert container_to_bytes(input_dict, errors='surrogate_or_strict') == {b'a': b'\xc3\xb6', b'b': {b'x': [1, 2, 3]}}

# Generated at 2022-06-20 16:21:07.601225
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('Hello', nonstring='simplerepr') == b'Hello'
    assert to_bytes(u'Hello', nonstring='simplerepr') == b'Hello'
    # We don't expect to get non ascii bytes in anywhere but if we did, this
    #  should be safe
    assert to_bytes(u'caf\xe9', nonstring='empty') == b'caf\xc3\xa9'
    assert to_bytes(u'\U0001f4a9', nonstring='empty') == b'\xf0\x9f\x92\xa9'
    assert to_bytes('caf\xe9', nonstring='empty') == b'caf\xc3\xa9'

# Generated at 2022-06-20 16:21:17.487221
# Unit test for function to_native
def test_to_native():
    if PY3:
        text_class = str
        binary_class = bytes
    else:
        text_class = unicode  # noqa
        binary_class = str

    assert to_native(None) is None
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(1) == 1
    assert to_native(1.1) == 1.1
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == '\u043f\u0440\u0438\u0432\u0435\u0442'
    # TODO: assert to_native(u'\u043f\u0440\u0438\u04

# Generated at 2022-06-20 16:21:37.599156
# Unit test for function jsonify
def test_jsonify():
    import json

# Generated at 2022-06-20 16:21:41.001674
# Unit test for function jsonify
def test_jsonify():
    for encoding in ("utf-8", "latin-1"):
        try:
            jsonify(encoding)
        except TypeError:
            continue
        except UnicodeDecodeError:
            continue

# Generated at 2022-06-20 16:21:50.222593
# Unit test for function container_to_bytes
def test_container_to_bytes():
    value = "test Unicode €"
    d1 = dict(string1=value, string2=to_bytes(value, encoding="latin-1"),
              dict1=dict(string1=value), list1=[1, 2, value],
              tuple1=(value, value))
    d2 = dict(string1=to_bytes(value, encoding="latin-1"), string2=to_bytes(value, encoding="latin-1"),
              dict1=dict(string1=to_bytes(value, encoding="latin-1")),
              list1=[1, 2, to_bytes(value, encoding="latin-1")],
              tuple1=(to_bytes(value, encoding="latin-1"), to_bytes(value, encoding="latin-1")))

# Generated at 2022-06-20 16:21:59.503337
# Unit test for function to_bytes
def test_to_bytes():
    from pytest_ansible.plugin import TestAnsibleModule
    test_module = TestAnsibleModule()
    sample_args = {'_ansible_module_name': 'to_bytes_test',
                   '_ansible_module_args': dict(encoding='utf-8')}
    test_module.init(sample_args)

    # Check for strict type assertion
    with test_module.assert_raises(TypeError):
        to_bytes(obj=1, nonstring='strict')

    # Check for empty byte string return
    empty_bytes_string = to_bytes(obj=1, nonstring='empty')
    test_module.assertEqual(empty_bytes_string, b'')

    # Check for passthru

# Generated at 2022-06-20 16:22:05.821421
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # to_bytes
    assert container_to_bytes(u'foo') == b'foo'
    # dicts
    assert container_to_bytes({u'a':1, u'b':2}) == {b'a':1, b'b':2}
    # lists
    assert container_to_bytes([u'a', u'b']) == [b'a', b'b']
    # tuples
    assert container_to_bytes((u'a', u'b')) == (b'a', b'b')
    # anything else
    assert container_to_bytes(u'foo') == b'foo'


# Generated at 2022-06-20 16:22:14.761203
# Unit test for function jsonify
def test_jsonify():
    test_data = dict(a=1, b=u'unicode_str')
    result = jsonify(test_data)
    assert isinstance(result, text_type)
    assert json.loads(result) == test_data

    test_data[u'c'] = u'unicode_str_2'
    result = jsonify(test_data)
    assert isinstance(result, text_type)
    assert json.loads(result) == test_data

    test_data[u'd'] = u'\u8fd9\u662f\u4e2d\u6587'
    result = jsonify(test_data)
    assert isinstance(result, text_type)
    assert json.loads(result) == test_data


# Generated at 2022-06-20 16:22:27.876888
# Unit test for function to_bytes
def test_to_bytes():
  from ansible.module_utils.six import b
  from sys import version_info

  assert to_bytes(b('test')) == b('test')
  assert to_bytes(b('test'), nonstring='passthru') == b('test')
  assert to_bytes(u'test') == b('test')
  assert to_bytes('test') == b('test')
  assert to_bytes(u'test', errors='strict') == b('test')
  assert to_bytes('test', errors='strict') == b('test')
  assert to_bytes(u'\U00010348') == b('\xf0\x90\x8d\x88')

# Generated at 2022-06-20 16:22:39.263539
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test strings
    assert to_bytes('abc') == b'abc'
    assert to_bytes(b'abc') == b'abc'
    assert to_bytes(u'abc') == b'abc'

# Generated at 2022-06-20 16:22:49.717284
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {
        1: u'foo',
        u'bar': [u'a', u'b'],
        u'baz': (u'a', u'b'),
        u'qux': {u'a': u'b'},
        2: b'foo',
        b'bar': [b'a', b'b'],
        b'baz': (b'a', b'b'),
        b'qux': {b'a': b'b'},
        3: {u'x': b'y'},
    }

    for enc in (1, 2, 3):
        d_encoded = container_to_bytes(d, encoding=encoding[enc])
        assert isinstance(d_encoded, dict)
        for x in d_encoded.values():
            assert isinstance

# Generated at 2022-06-20 16:22:56.023504
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text([u'foo', u'bar', u'baz']) == [u'foo', u'bar', u'baz']
    assert container_to_text(u'foo') == u'foo'
    assert container_to_text({u'foo': u'bar', 'foo': u'baz'}) == {u'foo': u'bar', u'foo': u'baz'}
    assert container_to_text({u'foo': u'bar', 'foo': u'baz', 'baz': {u'foo': 'bar'}}) == {u'foo': u'bar', u'foo': u'baz', 'baz': {u'foo': u'bar'}}

# Generated at 2022-06-20 16:23:16.810898
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils import basic

    got_exception = False
    try:
        to_bytes('hi')
    except Exception as e:
        got_exception = True
    basic.fail_if(not got_exception, msg="Expected 'to_bytes' to throw an exception when the object was a text string")

    basic.fail_if(to_bytes('hi', 'ascii') != b'hi', msg="Expected 'hi' to convert to ascii 'hi'")
    basic.fail_if(to_bytes(b'hi') != b'hi', msg="Expected 'hi' to not be converted")

    basic.fail_if(to_bytes(b'hi', 'ascii') != b'hi', msg="Expected 'hi' to not be converted")


# Generated at 2022-06-20 16:23:24.722467
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes('aoeu') == b'aoeu'
    # Test dict literals
    d = {u'key': u'value'}
    returned = container_to_bytes(d)
    assert isinstance(returned, dict)
    assert isinstance(returned.get(u'key'), bytes)
    # Test dict()
    d = dict(a=u'aoeu')
    returned = container_to_bytes(d)
    assert isinstance(returned, dict)
    assert isinstance(returned.get(u'a'), bytes)
    # Test OrderedDict()
    d = OrderedDict(a=u'aoeu')
    returned = container_to_bytes(d)
    assert isinstance(returned, OrderedDict)

# Generated at 2022-06-20 16:23:28.172812
# Unit test for function container_to_bytes
def test_container_to_bytes():
    '''
    [Unit Test for container_to_bytes]
    Test for container_to_bytes
    '''
    test_data = {
        b'foo': {
            'bar': [
                u'a',
                u'b',
                u'c',
            ]
        }
    }
    result_data = container_to_bytes(test_data)
    assert result_data == {
        b'foo': {
            b'bar': [
                b'a',
                b'b',
                b'c',
            ]
        }
    }



# Generated at 2022-06-20 16:23:33.357366
# Unit test for function container_to_bytes

# Generated at 2022-06-20 16:23:39.284409
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(u'foo') == b'foo'
    assert container_to_bytes({u'foo': u'bar'}) == {b'foo': b'bar'}
    assert container_to_bytes([u'foo', u'bar']) == [b'foo', b'bar']
    assert container_to_bytes((u'foo', u'bar')) == (b'foo', b'bar')



# Generated at 2022-06-20 16:23:46.515438
# Unit test for function jsonify
def test_jsonify():
    # Test common case
    assert jsonify(dict(a=1, b="b")) == '{"a": 1, "b": "b"}'
    # Test case for invalid unicode encoding encountered
    try:
        jsonify(dict(a=1, b=b'\xff')) == '{"a": 1, "b": "b"}'
    except UnicodeError:
        pass
    else:
        assert False



# Generated at 2022-06-20 16:23:52.720766
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({'yup': 'yup'}) == {b'yup': b'yup'}
    assert container_to_bytes(['yup']) == [b'yup']
    assert container_to_bytes(('yup',)) == (b'yup',)
    # Ensure that it doesn't break things that shouldn't be converted
    # This is an int before and after
    assert container_to_bytes(1) == 1
    # This is a string before and after
    assert container_to_bytes('yup') == b'yup'
    # Use an encoding that will fail
    assert container_to_bytes('é', encoding='us-ascii', errors='strict') == b'\xc3\xa9'


# Generated at 2022-06-20 16:24:02.688414
# Unit test for function to_native
def test_to_native():
    # Tests that use to_native
    import pytest
    from ansible.module_utils.six import text_type, integer_types
    from ansible.module_utils._text import to_native

    bytes_obj = b'examplestring'
    text_obj = u'examplestring'
    int_obj = 1

    for obj in bytes_obj, text_obj, int_obj:
        assert(isinstance(to_native(obj, "utf-8"), text_type))
        assert(isinstance(to_native(obj, "utf-8", "surrogate_or_strict"), text_type))
        assert(isinstance(to_native(obj, "utf-8", "surrogate_or_replace"), text_type))

# Generated at 2022-06-20 16:24:13.848936
# Unit test for function container_to_text
def test_container_to_text():
    # Non-dictionary types
    data = [12,34,56]
    assert container_to_text(data) == data
    # Dictionaries
    data = {b'x':b'y', 'a':'b'}
    assert container_to_text(data) == {u'x':u'y', u'a':u'b'}
    # Nested dictionaries
    data = {b'a':b'b', b'c':{b'd': b'e'}}
    assert container_to_text(data) == {u'c': {u'd': u'e'}, u'a': u'b'}
    # Python 2.6-2.7, keys are not converted to text but rather unicode
    # So we need to make sure we're not using byte strings anywhere.
    assert not any

# Generated at 2022-06-20 16:24:22.572750
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo', encoding='ascii') == 'foo'
    assert to_native('foo', encoding='ascii') == 'foo'
    assert to_native(u'\u00c9t\u00e9', errors='surrogate_then_replace') == '\udcc9t\udce9'
    assert to_native(b'\xc3\x89t\xc3\xa9', encoding='latin-1', errors='surrogate_then_replace') == u'\u00c9t\u00e9'

    if PY3:
        assert to_native(u'\u00c9t\u00e9') == '\udcc9t\udce9'

# Generated at 2022-06-20 16:24:42.998565
# Unit test for function to_native
def test_to_native():
    import doctest
    doctest.testmod()



# Generated at 2022-06-20 16:24:52.964712
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # no list or dict
    assert container_to_bytes(True) == True
    assert container_to_bytes(42) == 42
    assert container_to_bytes('some string') == b'some string'
    assert container_to_bytes(u'unicode string') == b'unicode string'
    assert container_to_bytes(b'bytes string') == b'bytes string'
    assert container_to_bytes({}) == {}
    assert container_to_bytes([]) == []
    # dict
    assert container_to_bytes({'k':'v', 'k2':'v2'}) == {b'k': b'v', b'k2': b'v2'}

# Generated at 2022-06-20 16:25:00.607094
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {u'bytes': b'foo', u'text': u'bar', u'int': 1}
    expected = {b'bytes': b'foo', b'text': b'bar', b'int': 1}
    assert container_to_bytes(d) == expected
    
    d = [b'foo', u'bar', 1]
    expected = [b'foo', b'bar', 1]
    assert container_to_bytes(d) == expected
    
    d = ([b'foo', u'bar', 1], b'foo', u'bar', 1)
    expected = ([b'foo', b'bar', 1], b'foo', b'bar', 1)
    assert container_to_bytes(d) == expected


# Generated at 2022-06-20 16:25:05.555233
# Unit test for function container_to_bytes
def test_container_to_bytes():
    import json
    # assuming file is utf-8 encoded
    with open(__file__, 'r') as f:
        data = json.load(f)
    # the test should pass for utf-8 encoded data
    data = container_to_bytes(data)
    data = json.dumps(data)
    assert isinstance(data, string_types)



# Generated at 2022-06-20 16:25:16.470882
# Unit test for function container_to_text
def test_container_to_text():

    # Test unicode
    assert container_to_text(u"ภาษาไทย") == u"ภาษาไทย"

    # Test dict
    dict = {"a": 1, "b": 2, "c": 3}
    assert container_to_text(dict) == {"a": 1, "b": 2, "c": 3}

    # Test list
    list = [1, 2, 3]
    assert container_to_text(list) == [1, 2, 3]

    # Test tuple
    tuple = (1, 2, 3)
    assert container_to_text(tuple) == (1, 2, 3)