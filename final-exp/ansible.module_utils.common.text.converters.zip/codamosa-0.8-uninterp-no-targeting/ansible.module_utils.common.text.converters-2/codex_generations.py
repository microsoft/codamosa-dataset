

# Generated at 2022-06-20 16:15:39.532968
# Unit test for function to_native
def test_to_native():
    assert to_native('a') == 'a'
    assert to_native(b'a') == 'a'
    assert to_native(u'a') == 'a'
    assert to_native(1) == 1
    # assert to_native(None, nonstring='strict') == ''



# Generated at 2022-06-20 16:15:51.194236
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u00dcnic\u00f6de') == u'"\\u00dcnic\\u00f6de"'
    assert jsonify(u'\xc4n\xe4\xdf\xf8de') == '"\\u00c4n\\u00e4\\u00df\\u00f8de"'
    assert jsonify({u'\u00dcnic\u00f6de': [u'\u00dcnic\u00f6de', u'\n', u'\u00dcnic\u00f6de']}) == '{"\\u00dcnic\\u00f6de": ["\\u00dcnic\\u00f6de", "\\n", "\\u00dcnic\\u00f6de"]}'



# Generated at 2022-06-20 16:16:02.897753
# Unit test for function to_native
def test_to_native():
    # Test for Bytes
    bytes_no_decode = to_native(b'foo')
    assert isinstance(bytes_no_decode, binary_type)
    assert bytes_no_decode == b'foo'
    bytes_decode = to_native(b'foo', errors='strict')
    assert isinstance(bytes_decode, binary_type)
    assert bytes_decode == b'foo'
    # Test for Unicode
    unicode_no_decode = to_native(u'foo')
    assert isinstance(unicode_no_decode, text_type)
    assert unicode_no_decode == u'foo'
    unicode_decode = to_native(u'foo', errors='strict')
    assert isinstance(unicode_decode, text_type)
    assert unic

# Generated at 2022-06-20 16:16:15.166708
# Unit test for function container_to_bytes
def test_container_to_bytes():
    '''Unit tests for function container_to_bytes'''
    # Test text_type input
    assert isinstance(container_to_bytes(u"test123"), binary_type)

    # Test dict input
    test_dict = {u"test123": u"test123", "test456": "test456"}
    assert isinstance(container_to_bytes(test_dict), dict)
    assert isinstance(container_to_bytes(test_dict).keys()[0], binary_type)
    assert isinstance(container_to_bytes(test_dict).values()[0], binary_type)

    # Test list input
    test_list = [u"test123", "test456", {"test789": u"test789"}]
    assert isinstance(container_to_bytes(test_list), list)

# Generated at 2022-06-20 16:16:22.563372
# Unit test for function to_bytes
def test_to_bytes():
    class Foo(object):
        def __str__(self):
            return 'str'

    import sys
    if PY3:
        for obj, encoding, errors in (
                (b' ', None, None),
                (b' ', 'latin-1', None),
                (b' ', None, 'surrogateescape'),
                (b' ', None, 'strict'),
                (b' ', None, 'surrogate_then_replace'),
                (b'\ufffd', None, None),
                (b'\ufffd', None, 'surrogateescape'),
                (b'\ufffd', None, 'surrogate_or_strict'),
                (b'\u1234', 'utf-16', None),
            ):
            assert to_bytes(obj, encoding, errors) == obj

# Generated at 2022-06-20 16:16:31.738725
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils._text import to_bytes
    import sys

    # Python3
    if sys.version_info[0] >= 3:
        assert to_bytes(u'foobar') == b'foobar'
        assert to_bytes(b'foobar') == b'foobar'
        try:
            to_bytes(object())
            assert False
        except TypeError:
            pass
        assert to_bytes(object(), errors='strict') == ''
        assert to_bytes(object(), errors='surrogate_or_replace') == ''
        assert to_bytes(object(), errors='surrogate_or_strict') == ''
        assert to_bytes(object(), errors='surrogate_then_replace') == ''
        assert to_bytes(object(), nonstring='empty') == b''
        assert to

# Generated at 2022-06-20 16:16:34.738757
# Unit test for function jsonify
def test_jsonify():
    test_list = [1, 2, {"a": 1, "b": 2}]
    assert jsonify(test_list) == '[1, 2, {"a": 1, "b": 2}]'



# Generated at 2022-06-20 16:16:46.551793
# Unit test for function to_bytes
def test_to_bytes():
    def _test_value(value, encoding='utf-8', errors=None, nonstring='simplerepr'):
        return_value = to_bytes(value, encoding, errors, nonstring)
        if isinstance(value, text_type):
            assert isinstance(return_value, binary_type)
            assert value.encode(encoding, errors) == return_value
        elif isinstance(value, binary_type):
            assert isinstance(return_value, binary_type)
            assert value == return_value
        elif nonstring == 'passthru':
            assert isinstance(return_value, type(value))
            assert return_value is value
        elif nonstring == 'empty':
            assert isinstance(return_value, binary_type)
            assert return_value == b''

# Generated at 2022-06-20 16:16:58.645835
# Unit test for function jsonify
def test_jsonify():
    test_dict = dict(str='str', unicode=u'unicode', byte='byte')
    test_dict['dict'] = test_dict

# Generated at 2022-06-20 16:17:05.847134
# Unit test for function container_to_text
def test_container_to_text():
    test_dict = {u'foo': u'bar'}
    test_list = [u'foo', u'bar']
    test_tuple = (u'foo', u'bar')
    test_str = u'foo'

    assert test_dict == container_to_text(test_dict)
    assert test_list == container_to_text(test_list)
    assert test_tuple == container_to_text(test_tuple)
    assert test_str == container_to_text(test_str)

    test_bytes_dict = {b'foo': b'bar'}
    test_bytes_list = [b'foo', b'bar']
    test_bytes_tuple = (b'foo', b'bar')
    test_bytes_str = b'foo'

    assert test_dict == container

# Generated at 2022-06-20 16:17:19.421451
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_dict = {
        "unicode_key": "unicode_value",
        "byte_key": b"byte_value",
        "dict_key": {
            "unicode_key": "unicode_value",
            "byte_key": b"byte_value"
        },
        "list_key": [
            "unicode_value",
            b"byte_value",
            {
                "unicode_key": "unicode_value",
                "byte_key": b"byte_value"
            }
        ]
    }


# Generated at 2022-06-20 16:17:25.661650
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(u'') == b''
    assert container_to_bytes(u'hello') == b'hello'
    assert container_to_bytes(b'\x00') == b'\x00'
    assert container_to_bytes({}) == {}
    assert container_to_bytes([]) == []
    assert container_to_bytes(()) == ()
    assert container_to_bytes(u'hello') == b'hello'
    assert container_to_bytes({u'key': u'value', u'key2': u'value2'}) == {b'key': b'value', b'key2': b'value2'}

# Generated at 2022-06-20 16:17:35.759043
# Unit test for function container_to_text
def test_container_to_text():
    """
    Test container_to_text()
    """
    data1 = {
        "a": "1",
        "b": "2",
        "c": "3",
        "d": "4"
    }
    data2 = [
        [
            "1",
            "2",
            "3",
            "4"
        ],
        [
            "a",
            "b",
            "c",
            "d"
        ]
    ]
    data3 = [
        ["1", "2", "3", "4"],
        ["a", "b", "c", "d"]
    ]
    data4 = {"nested": {"data": "value"}}
    data5 = ["normal", "data", {"nested": {"data": "value"}}]

    # Test case to test

# Generated at 2022-06-20 16:17:39.700949
# Unit test for function container_to_bytes
def test_container_to_bytes():
    container = {'k1': 'v1', 'k2': 'v2', 'k3': [1,2,3]}
    container_new = {b'k1': b'v1', b'k2': b'v2', b'k3': [1,2,3]}
    assert container_to_bytes(container) == container_new



# Generated at 2022-06-20 16:17:51.538640
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('some text', errors='surrogateescape') == b'some text'
    assert to_bytes('some text', errors='surrogate_or_strict') == b'some text'
    #assert to_bytes(u'\U0001F4A9') == u'\uFFFD'.encode('utf-8')
    #assert to_bytes(u'\U0001F4A9', 'ascii', 'surrogate_or_strict') == '\uFFFD'.encode('utf-8')
    #assert to_bytes(u'\U0001F4A9', 'ascii', 'surrogate_or_replace') == '?'.encode('ascii')
    #assert to_bytes(u'\udc80x\udc80'.encode('utf-8'),

# Generated at 2022-06-20 16:18:01.863283
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'abc') == b'abc'
    assert to_bytes('abc') == b'abc'
    assert to_bytes(u'abc') == b'abc'
    assert to_bytes(u'привет') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    assert to_bytes(123) == b'123'
    assert to_bytes(True) == b'True'
    assert to_bytes(b'\xe4', encoding='latin1') == b'\xe4'
    assert to_bytes(u'\xe4', encoding='latin1', errors='strict') is None

# Generated at 2022-06-20 16:18:13.836526
# Unit test for function to_native
def test_to_native():
    '''
    Test to_native function
    '''
    from ansible.module_utils._text import to_native

    assert to_native() == u''
    assert to_native(None) == u''
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'\xf6') == u'ö'
    assert to_native(u'\xf6') == u'ö'
    assert to_native(b'\xc2\xb5') == u'µ'
    assert to_native(u'\xf6') == u'ö'
    assert to_native(b'\xc2\xb5') == u'µ'
    assert to

# Generated at 2022-06-20 16:18:23.045700
# Unit test for function to_bytes
def test_to_bytes():
    # byte string stays the same
    assert to_bytes(b'foo') == b'foo'

    # Nonstrings are run through str and the str is encoded
    from ansible.module_utils.six import binary_type
    if PY3:
        expected = b'<class \'int\'>'
    else:
        expected = b'<type \'int\'>'
    assert to_bytes(1, nonstring='simplerepr') == expected

    # Non-utf8 encodings
    assert to_bytes(u'\u2661', encoding='latin-1') == b'\xe2\x99\xa1'

    # Errors
    assert to_bytes(u'\u2661', encoding='ascii', errors='strict') == b'?'

# Generated at 2022-06-20 16:18:25.148356
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({u'a': u'b'}) == '{"a": "b"}'



# Generated at 2022-06-20 16:18:37.412269
# Unit test for function container_to_text
def test_container_to_text():
    from ansible.module_utils._text import to_text
    msg = b"\xce\xbd\xce\xb9\xce\xba\xce\xb1"
    cmsg = b"\xf0\x9d\x84\x9e"

    # test simple case
    input = {b'test': b'input'}
    expected_output = {u'test': u'input'}
    output = container_to_text(input)
    assert output == expected_output

    # test nested dict
    input = {b'test': b'input', b'nested': {b'nested': b'test'}}
    expected_output = {u'test': u'input', u'nested': {u'nested': u'test'}}

# Generated at 2022-06-20 16:19:05.601902
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils import basic

    assert jsonify(['test_utf8_\xc3\xa9']) == '["test_utf8_\\u00e9"]'
    assert jsonify('test_utf8_\xc3\xa9') == '"test_utf8_\\u00e9"'
    assert jsonify(u'test_utf8_\xc3\xa9') == '"test_utf8_\\u00e9"'
    assert jsonify(Set(['test_utf8_\xc3\xa9'])) == '["test_utf8_\\u00e9"]'
    assert jsonify(datetime.datetime(2012, 12, 25, 13, 13)) == '"2012-12-25T13:13:00"'


# Generated at 2022-06-20 16:19:11.386605
# Unit test for function to_native
def test_to_native():
    for native_type, text_type, byte_type, text_string, byte_string in NATIVE_TYPES:
        assert to_native(text_string) == native_type(text_string)
        assert to_native(byte_string) == native_type(text_string)
        assert to_native(text_type(text_string)) == native_type(text_string)
        assert to_native(byte_type(text_string)) == native_type(text_string)
        # Not sure what to do about other types
        assert to_native(None) == text_type('')
        # Strings aren't types in Py3.
        # 'str' is just the name we've given to the native string type.
        # pylint: disable=E0602

# Generated at 2022-06-20 16:19:18.061566
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a='test')) == '{"a": "test"}'
    assert jsonify(dict(a='test'.encode('utf-16'))) == '{"a": "test"}'
    assert jsonify(dict(a=list('test'.encode('utf-16')))) == '{"a": [84, 0, 101, 0, 115, 0, 116, 0]}'



# Generated at 2022-06-20 16:19:22.676275
# Unit test for function jsonify
def test_jsonify():
    result = jsonify({u"blah": u"bl\u00e4h"})
    assert isinstance(result, text_type)
    assert isinstance(json.loads(result), dict)


# jsonify wrapper that can be used directly with json.dumps

# Generated at 2022-06-20 16:19:31.513117
# Unit test for function container_to_text
def test_container_to_text():
    s = container_to_text('what is this')
    assert isinstance(s, text_type)
    s = container_to_text(b'what is this')
    assert isinstance(s, text_type)
    s = container_to_text(b'\xff\xff')
    assert isinstance(s, text_type)
    s = container_to_text({'key1': 'value1', 'key2': b'value2'})
    s['key2'] == u'value2'
    assert isinstance(s, dict)
    s = container_to_text({'key1': 'value1', 'key2': b'value2'}, errors='strict')
    assert isinstance(s, dict)

# Generated at 2022-06-20 16:19:39.410649
# Unit test for function container_to_text
def test_container_to_text():
    d = {'a': 'hello', 'b': 'world'}
    result = container_to_text(d)
    assert isinstance(result, dict)
    assert isinstance(result['a'],text_type)
    assert result['a'] == 'hello'
    assert isinstance(result['b'],text_type)
    assert result['b'] == 'world'
    assert isinstance(d, dict)
    assert isinstance(d['a'],text_type)
    assert d['a'] == 'hello'
    assert isinstance(d['b'],text_type)
    assert d['b'] == 'world'

    d = { 'a': b'hello', 'b': b'world' }
    result = container_to_text(d)
    assert isinstance(result, dict)

# Generated at 2022-06-20 16:19:50.217742
# Unit test for function container_to_bytes
def test_container_to_bytes():

    # dict
    data = dict(
        str_key=u"unicode str value",
        str_key2=u"unicode str value",
        unicode_key=u"unicode str value",
        int_key=1,
        dict_key=dict(
            a=1,
            b=2,
            c=u"unicode str value",
            d=[1, 2, 3, u"unicode str value"],
            e=(1, 2, 3, u"unicode str value")
        ),
        list_key=[1, 2, 3, u"unicode str value"],
        tuple_key=(1, 2, 3, u"unicode str value"),
        set_key=set([1, 2, 3, u"unicode str value"])
    )

# Generated at 2022-06-20 16:20:04.343456
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.six.moves import StringIO
    from collections import OrderedDict

    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo', errors='surrogate_then_replace') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_then_replace') == b'foo'

    # Test surrogates
    assert to_bytes(u'\udc80foo', errors='surrogate_then_replace') == u'\udc80foo'.encode('ascii', 'replace')
    assert to_bytes(u'\udc80foo', errors='surrogate_then_replace') == b'\xef\xbf\xbdfoo'



# Generated at 2022-06-20 16:20:08.445566
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo': 6}) == '{"foo": 6}'
    assert jsonify({'foo': 6}, sort_key=True) == '{"foo": 6}'
    assert jsonify({'foo': 6}, indent=4) == '{\n    "foo": 6\n}'
    assert jsonify({'foo': 6}) == '{"foo": 6}'
    assert jsonify({'foo': [1, 2]}) == '{"foo": [1, 2]}'
    assert jsonify({'foo': [1, 2, "six"]}) == '{"foo": [1, 2, "six"]}'
    assert jsonify([{'foo': 1}, {'bar': 2}]) == '[{"foo": 1}, {"bar": 2}]'

# Generated at 2022-06-20 16:20:15.875553
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({'foo': 'bar'}) == {b'foo': b'bar'}
    assert container_to_bytes({'foo': {'bar': 'baz'}}) == {b'foo': {b'bar': b'baz'}}
    assert container_to_bytes('foo') == b'foo'
    assert container_to_bytes([1, 2, 3, {'foo': 'bar'}]) == [1, 2, 3, {b'foo': b'bar'}]
    assert container_to_bytes({'foo': [1, 2, {'bar': 'baz'}]}) == {b'foo': [1, 2, {b'bar': b'baz'}]}
    assert container_to_bytes((1, 2, 3, {'foo': 'bar'}))

# Generated at 2022-06-20 16:20:43.601608
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(u'foo') == b"foo"
    assert container_to_bytes(['a', 'b', 'c', 'd']) == [b'a', b'b', b'c', b'd']
    assert container_to_bytes(('a', 'b', 'c', 'd')) == (b'a', b'b', b'c', b'd')
    # Unit test for function container_to_bytes with dictionary
    assert container_to_bytes({'foo': 'bar'}) == {b'foo': b'bar'}
    assert container_to_bytes({'bar': [u'foo', u'foo'], 'foo': u'bar'}) == {b'bar': [b'foo', b'foo'], b'foo': b'bar'}



# Generated at 2022-06-20 16:20:54.496483
# Unit test for function to_bytes
def test_to_bytes():
    # valid combinations of args and kwargs
    assert to_bytes(u'\U0001f604') == b'\xf0\x9f\x98\x84'
    assert to_bytes('\xc3\xbc') == b'\xc3\xbc'
    assert to_bytes(b'\xc3\xbc') == b'\xc3\xbc'
    assert to_bytes(bytearray(b'\xc3\xbc')) == b'\xc3\xbc'
    assert to_bytes(b'\xc3\xbc', 'iso-8859-1') == b'\xfc'
    assert to_bytes(u'\N{LATIN SMALL LETTER U WITH DIAERESIS}', 'iso-8859-1') == b'\xfc'


# Generated at 2022-06-20 16:21:04.556881
# Unit test for function container_to_bytes
def test_container_to_bytes():
    unicode_string = u"\u041b\u0435\u043d\u0438\u043d\u0430"
    byte_string = b"\xd0\x9b\xd0\xb5\xd0\xbd\xd0\xb8\xd0\xbd\xd0\xb0"
    in_list = [unicode_string, byte_string]
    in_dict = {unicode_string: unicode_string, byte_string: byte_string}
    in_tuple = (unicode_string, byte_string)
    b_dict = container_to_bytes(in_dict, encoding='utf-8')
    b_list = container_to_bytes(in_list, encoding='utf-8')

# Generated at 2022-06-20 16:21:14.554077
# Unit test for function to_native

# Generated at 2022-06-20 16:21:23.054173
# Unit test for function to_bytes
def test_to_bytes():
    # Basic sanity checks
    assert to_bytes(1, nonstring='simplerepr').isdigit()
    assert to_bytes(to_bytes(b'test', 'latin-1')) == b'test'
    assert to_bytes(to_text(b'test', 'latin-1')) == b'test'
    assert to_bytes(to_text(b'test', 'latin-1'), encoding='latin-1') == b'test'
    assert to_text(to_bytes(1, nonstring='simplerepr')) == '1'

    # Multiple nonstrings
    assert to_bytes(None, nonstring='simplerepr') == b'None'
    assert to_bytes(None, nonstring='empty') == b''
    assert to_bytes(None, nonstring='passthru') is None

# Generated at 2022-06-20 16:21:24.910860
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # this should not throw an exception
    container_to_bytes(["Bytes", None, 1])


# Generated at 2022-06-20 16:21:33.080777
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({'foo': {'bar': ['baz', 'bam', 'bam']}}) == {b'foo': {b'bar': [b'baz', b'bam', b'bam']}}
    assert container_to_bytes({u'foo': u'bar'}) == {b'foo': b'bar'}
    assert container_to_bytes({u'foo': u'bar', u'bam': [u'baz', u'bam', u'bam']}) == {b'foo': b'bar', b'bam': [b'baz', b'bam', b'bam']}



# Generated at 2022-06-20 16:21:37.637693
# Unit test for function jsonify
def test_jsonify():
    data = dict(key1=u"value1", key2=u"value2")
    json_data = jsonify(data)
    assert b'"key1": "value1"' in json_data
    assert b'"key2": "value2"' in json_data



# Generated at 2022-06-20 16:21:47.196128
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(['hi']) == to_bytes(['hi'])
    assert container_to_bytes({'hi': 'there'}) == to_bytes({'hi': 'there'})
    assert container_to_bytes(('hi', 'there')) == to_bytes(('hi', 'there'))
    assert container_to_bytes(set(['hi'])) == to_bytes(set(['hi']))
    assert container_to_bytes(set([1])) == set([1])
    assert container_to_bytes(u'hi') == to_bytes(u'hi')
    assert container_to_bytes(2) == 2



# Generated at 2022-06-20 16:21:55.522857
# Unit test for function to_native
def test_to_native():
    '''Test to_native method'''
    # Test with valid latin-1 data
    test = u'This is latin-1 text'
    byte_test = test.encode('latin-1')
    assert to_bytes(test, encoding='latin-1') == byte_test

    # Test with valid utf-8 data
    test = u'This is utf-8 text'
    byte_test = test.encode('utf-8')
    assert to_bytes(test, encoding='utf-8') == byte_test

    # Test with bytes that aren't valid in the specified encoding.
    test = u'\u0278'
    assert to_bytes(test, encoding='ascii', errors='surrogate_or_replace') == b'?'

# Generated at 2022-06-20 16:22:26.455850
# Unit test for function jsonify

# Generated at 2022-06-20 16:22:38.431937
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({u'foo': u'bar'}) == {b'foo': b'bar'}
    assert container_to_bytes({u'foo': u'bar', u'a': [{u'b': u'c'}]}) == {b'foo': b'bar', b'a': [{b'b': b'c'}]}
    assert container_to_bytes({u'foo': u'bar', u'a': [{u'b': u'c'}]}) == {b'foo': b'bar', b'a': [{b'b': b'c'}]}
    assert container_to_bytes([{u'a': {u'b': u'c'}}]) == [{b'a': {b'b': b'c'}}]
    assert container_to_bytes

# Generated at 2022-06-20 16:22:40.516370
# Unit test for function jsonify
def test_jsonify():
    class Foo(object):
        pass

    assert jsonify(Foo()) == '"{}"'.format(Foo())


# Generated at 2022-06-20 16:22:50.564413
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_dict = {'a': '1', 'b': ['a', 'b', 'c']}
    test_dict.update({ text_type('e'): '5'})
    test_dict.update({ text_type('f'): [ text_type('x'), text_type('y'), text_type('z')]})
    from_dict = container_to_bytes(test_dict)
    assert(from_dict == {'a': '1', 'b': ['a', 'b', 'c'], 'e': '5', 'f': ['x', 'y', 'z']})
    test_dict.update({ u'a': u'1'})
    test_dict.update({ u'b': [u'a', u'b', u'c']})

# Generated at 2022-06-20 16:23:00.931882
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.six import BytesIO
    data = {"foo": "bar", "baz": 2, "qux": True}
    assert jsonify(data) == '{"qux": true, "baz": 2, "foo": "bar"}'

    data = {"a": 123, "b": "abc", "c": text_type("def", "latin-1")}
    assert jsonify(data) == '{"a": 123, "c": "def", "b": "abc"}'
    assert len(jsonify(data)) == len(text_type(BytesIO(jsonify(data)), "utf-8"))

    assert jsonify(data, indent=4) == '{\n    "a": 123, \n    "c": "def", \n    "b": "abc"\n}'



# Generated at 2022-06-20 16:23:13.007102
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # container_to_bytes only converts strings and containers, so there needs
    # to be a string in the data to be converted.
    jsondata = '{"foo": "bar", "unicode": "f\xf6\xf6", "dict": {"foo": "bar", "unicode": "b\xe4r"}, "list": ["foo", "bar", "baz", 42, "f\xf6\xf6", {"foo": "bar"}], "tuple": ["foo", "bar", "baz", 42, "f\xf6\xf6", {"foo": "bar"}]}'
    j = json.loads(jsondata)

    # If the test is run on a machine with the locale set to a latin-1 locale
    # then the default encoding will be latin-1 and the tests will fail.
    # Force the default

# Generated at 2022-06-20 16:23:18.470246
# Unit test for function jsonify
def test_jsonify():
    class Foo(object):
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return '<Foo(%r)>' % self.value

        def __json__(self):
            return {'value': self.value}

    my_json = jsonify(data=Foo('bar'))
    assert my_json == '{"value": "bar"}', ("unexpected JSON output: " + to_native(my_json))



# Generated at 2022-06-20 16:23:31.408888
# Unit test for function to_bytes

# Generated at 2022-06-20 16:23:39.015121
# Unit test for function to_bytes
def test_to_bytes():
    import pytest
    from ansible.module_utils._text import to_bytes

    # Test with different types of strings
    for string_type in ('ascii', 'utf8', 'utf8_surrogate'):
        if string_type == 'ascii':
            test_string = b'Hello World'
            test_unicode = test_string.decode('ascii')
        elif string_type == 'utf8':
            test_unicode = u'Hello World \u20ac'
            test_string = test_unicode.encode('utf8')
        elif string_type == 'utf8_surrogate':
            test_unicode = u'Hello World \udcff'
            test_string = test_unicode.encode('utf8', errors='surrogateescape')

        # Test

# Generated at 2022-06-20 16:23:49.705573
# Unit test for function container_to_bytes
def test_container_to_bytes():
    try:
        int(u'1')
    except TypeError:
        has_unicode_int = False
    else:
        has_unicode_int = True

    for container in (dict, list, tuple):
        if container is dict:
            args = ({'foo': u'bar'}, {u'bar': 'foo'})
            # For dicts, we expect a new dict with byte strings
            excepted = {b'foo': b'bar', b'bar': b'foo'}
        else:
            args = ([u'foo'], ['foo'])
            # For lists and tuples, we expect the same, with byte strings
            excepted = [b'foo', b'foo']
        for arg in args:
            res = container_to_bytes(arg)
            assert isinstance(res, container)


# Generated at 2022-06-20 16:24:38.129369
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    handle, path = tempfile.mkstemp()
    os.close(handle)
    testdict = {'spam': 'eggs'}
    teststr = to_bytes(json.dumps(testdict, indent=4, ensure_ascii=False))
    with open(path, 'wb') as f:
        f.write(teststr)
    testmodule = AnsibleModule(argument_spec={})
    with open(path, 'rb') as f:
        teststr = f.read()
    assert isinstance(teststr, binary_type)
    teststr = to_bytes(teststr, nonstring='passthru')
    assert isinstance(teststr, binary_type)
   

# Generated at 2022-06-20 16:24:50.648600
# Unit test for function jsonify
def test_jsonify():
    cdict = dict(list(zip(list(map(chr, range(ord('a'), ord('z')+1))),
                         list(range(ord('a'), ord('z')+1))))) # a:97 ... z:122
    jsonified = jsonify(cdict)
    assert jsonified == json.dumps(cdict, default=_json_encode_fallback)
    # test container_to_text
    assert container_to_text(cdict) == container_to_text(cdict, 'utf-8') == cdict

# Generated at 2022-06-20 16:24:59.367299
# Unit test for function jsonify
def test_jsonify():

    assert jsonify({"a": "123"}) == '{"a": "123"}'

    # old simplejson via ansible1.x path
    old_dumps = json.dumps
    json.dumps = None
    try:
        assert jsonify({"a": "123"}) == '{"a": "123"}'
    finally:
        json.dumps = old_dumps

    # force encoding failure path
    def fake_dumps(obj):
        raise TypeError

    old_dumps = json.dumps
    json.dumps = fake_dumps
    try:
        assert jsonify({"a": "123"}) == '{"a": "123"}'
    finally:
        json.dumps = old_dumps

    # force UnicodeDecodeError path
    # TODO: this is broken for python

# Generated at 2022-06-20 16:25:11.405017
# Unit test for function container_to_bytes

# Generated at 2022-06-20 16:25:20.539518
# Unit test for function container_to_text
def test_container_to_text():
    # check string
    assert 'abc' == container_to_text('abc')
    assert 'abc' != container_to_text(b'abc')
    assert 'abc' == container_to_text(b'abc', encoding='utf-8', errors='surrogate_or_strict')
    assert '\uFFFD' == container_to_text(b'\x80', encoding='utf-8', errors='replace')
    assert '\uFFFD' == container_to_text(b'\x80', encoding='utf-8', errors='surrogate_or_replace')
    assert '\uFFFD' == container_to_text(b'\x80', encoding='utf-8', errors='surrogate_or_strict')
    # check list
    assert ['a', 'b', 'c'] == container_