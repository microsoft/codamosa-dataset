

# Generated at 2022-06-20 16:15:32.200046
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.six import PY2, PY3

    # Note: This can't use the normal testing framework because we're testing
    # function arguments so we use assert_equal here
    def assert_equal(value, other):
        assert value == other, "%r != %r" % (value, other)

    bdata = b'\xd1\x82\xd0\xb5\xd1\x81\xd1\x82'
    udata = bdata.decode('utf-8')

    assert_equal(to_bytes(None), b'None')
    assert_equal(to_bytes(None, nonstring='strict'), b'None')
    assert_equal(to_bytes(None, nonstring='empty'), b'')

# Generated at 2022-06-20 16:15:39.148797
# Unit test for function jsonify
def test_jsonify():
    test_dict = dict(a=u'\xe8\xb1\x86', b=u'\xe6\x9c\xaa', c='c', d=datetime.datetime.now())
    assert jsonify(test_dict) == "{\"a\": \"\\u8c46\", \"c\": \"c\", \"b\": \"\\u672a\", \"d\": \"" + test_dict['d'].isoformat() + "\"}"



# Generated at 2022-06-20 16:15:51.155983
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes([1, 2, 3]) == [1, 2, 3]
    assert container_to_bytes([to_bytes(u'1'), to_bytes(u'2'), to_bytes(u'3')]) == [to_bytes(u'1'), to_bytes(u'2'), to_bytes(u'3')]
    assert container_to_bytes((1, 2, 3)) == (1, 2, 3)
    assert container_to_bytes({ 'a': 1, 'b': 2 }) == {to_bytes(u'a'): 1, to_bytes(u'b'): 2}

# Generated at 2022-06-20 16:16:02.902835
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils.basic import AnsibleModule
    ddt = AnsibleModule(argument_spec=dict(input=dict()),
                        supports_check_mode=True)

    # module=ansible_module_create()
    # set_default_check_output(module)
    #
    # # check to_native with text native strings
    #
    # assert to_native('foo') == 'foo'
    # assert to_native(to_bytes('foo')) == 'foo'
    # assert to_native(b'foo') == 'foo'
    # assert to_native(to_bytes(b'foo')) == 'foo'
    #
    # # check to_native with binary string, was bytes in py2, str in py3
    # assert to_native(to_bytes('\xc3\x

# Generated at 2022-06-20 16:16:07.635388
# Unit test for function container_to_text
def test_container_to_text():
    print('Testing container_to_text function')
    # Test for text string
    assert container_to_text(u'abc') == u'abc'
    # Test for text string in list, tuple and dict
    assert container_to_text(u'abc', 'utf-8', 'replace') == u'abc'
    # Test for binary string
    assert container_to_text(b'abc') == u'abc'
    # Test for binary string in list, tuple and dict
    assert container_to_text([b'abc'], 'utf-8', 'replace') == [u'abc']
    assert container_to_text((b'abc',), 'utf-8', 'replace') == (u'abc',)

# Generated at 2022-06-20 16:16:16.475916
# Unit test for function jsonify
def test_jsonify():
    # Test jsonify with default encoding
    data = {u'foo': [u'bar']}
    assert jsonify(data) == u'{"foo": ["bar"]}'
    # Test jsonify with forced encoding
    data = {u'foo': [u'bar']}
    assert jsonify(data, encoding="utf-8") == u'{"foo": ["bar"]}'
    # Test jsonify with forced encoding
    data = {u'foo': [u'bar']}
    assert jsonify(data, encoding="latin-1") == u'{"foo": ["bar"]}'



# Generated at 2022-06-20 16:16:26.131756
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.common.text.converters import to_bytes
    import unittest

    class TestToBytes(unittest.TestCase):
        def setUp(self):
            pass
        def tearDown(self):
            pass
        def test_nonstring(self):
            self.assertEqual(to_bytes(dict()), b"{'tests': [{'test': 'value'}], 'arr': ['1', '2']}")
            self.assertEqual(to_bytes(dict()), b"{'tests': [{'test': 'value'}], 'arr': ['1', '2']}")
            self.assertEqual(to_bytes(dict()), b"{'tests': [{'test': 'value'}], 'arr': ['1', '2']}")



# Generated at 2022-06-20 16:16:32.787571
# Unit test for function container_to_bytes
def test_container_to_bytes():
    input_data = {b'foo': {u'bar': [u'f\xe3o', 'baz']}, 'fie': b'b\xe4r'}
    expected = {'foo': {'bar': ['f\xc3\xa3o', 'baz']}, 'fie': 'b\xc3\xa4r'}
    assert container_to_bytes(input_data) == expected


# Generated at 2022-06-20 16:16:44.744701
# Unit test for function to_bytes

# Generated at 2022-06-20 16:16:53.104442
# Unit test for function container_to_bytes
def test_container_to_bytes():
    import sys
    import functools
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    @functools.wraps(unittest.TestCase.assertEqual)
    def assertEqual(*args, **kwargs):
        if sys.version_info < (2, 7):
            # Python 2.6 is missing the assertMultiLineEqual method
            kwargs.pop('delta', None)
            kwargs.pop('sorted', None)
        return unittest.TestCase.assertEqual(*args, **kwargs)


# Generated at 2022-06-20 16:17:13.745190
# Unit test for function to_native
def test_to_native():
    assert '\x00' not in to_native(b'\x00', errors='strict')
    assert to_native(b'\x00', errors='strict') == u'\uFFFD'
    assert to_native(b'\x00', errors='surrogate_or_strict') == u'\uFFFD'
    assert to_native(b'\x00', errors='surrogate_or_replace') == u'\uFFFD'
    assert to_native(b'\x00', errors='surrogate_then_replace') == u'\uFFFD'
    assert to_native(b'\x00', errors='ignore') == u''
    assert to_native(b'\x00', errors='replace') == u'\uFFFD'

# Generated at 2022-06-20 16:17:26.144793
# Unit test for function to_bytes
def test_to_bytes():
    # We should be able to encode 8-bit ascii
    # We should not try to decode an object that is not a string
    assert to_bytes(u'\x00') == b'\x00'
    assert to_bytes(b'\x00') == b'\x00'
    assert to_bytes(1) == b'1'
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='empty') == b''
    assert to_bytes(None) == b'None'

    # Exercising all of the different error handlers
    assert not HAS_SURROGATEESCAPE or u'\udc00'.encode('utf-8', 'surrogateescape') == b'\xed\xb0\x80'

# Generated at 2022-06-20 16:17:35.888935
# Unit test for function jsonify
def test_jsonify():
    class A(object):
        def __init__(self, value):
            self.value = value
        def __str__(self):
            return self.value
        def __repr__(self):
            return self.value
        def __iter__(self):
            for i in self.value:
                yield i
        def __getitem__(self, i):
            return self.value[i]
    class A_encoder(json.JSONEncoder):
        def default(self, obj):
            if isinstance(obj, A):
                return obj.value
            return json.JSONEncoder.default(self, obj)

# Generated at 2022-06-20 16:17:47.350246
# Unit test for function to_native
def test_to_native():
    # This test is a bit contrived since to_native is a wrapper around
    # to_text.  However, we want to make sure that the automatic encoding
    # works.
    class MyBinary(object):
        def __str__(self):
            return '\xf1\xf2\xf3\xf4\xf5\xf6'

    class MyText(object):
        def __str__(self):
            return u'\uff10\uff11\uff12\uff13\uff14\uff15'

    class MyTextUnicode(object):
        def __unicode__(self):
            return u'\uff10\uff11\uff12\uff13\uff14\uff15'


# Generated at 2022-06-20 16:18:00.061900
# Unit test for function to_bytes

# Generated at 2022-06-20 16:18:02.021611
# Unit test for function container_to_bytes
def test_container_to_bytes():
    a = { 'hello': 'world', 'goodbye': 'world' }
    rval = container_to_bytes(a)
    assert(isinstance(rval['hello'], bytes))



# Generated at 2022-06-20 16:18:08.062666
# Unit test for function to_bytes
def test_to_bytes():
    assert b'foo' == to_bytes(u'foo')
    assert b'foo' == to_bytes(b'foo')
    assert b'foo' == to_bytes('foo')

    assert b'foo' == to_bytes(u'foo', encoding='ascii')
    assert b'foo' == to_bytes(b'foo', encoding='ascii')
    assert b'foo' == to_bytes('foo', encoding='ascii')

    assert b'f\xc3\xbf\xc3\xbf' == to_bytes(u'f\xfc\xfc')
    assert b'f\xc3\xbf\xc3\xbf' == to_bytes(b'f\xc3\xbf\xc3\xbf')

# Generated at 2022-06-20 16:18:18.360458
# Unit test for function container_to_text
def test_container_to_text():
    # Encoding from utf-8
    # Valid utf-8 bytes
    b_dict = {b'key': [b'byte', b'\xc3\xa9']}
    assert container_to_text(b_dict, 'latin-1') == {'key': ['byte', '?']}
    assert container_to_text(b_dict) == {'key': ['byte', u'\xe9']}
    # Invalid utf-8 bytes
    b_dict = {b'key': [b'byte', b'\xff']}
    assert container_to_text(b_dict, 'latin-1') == {'key': ['byte', '?']}
    assert container_to_text(b_dict) == {'key': [u'byte', u'\ufffd']}
    # Encoding from

# Generated at 2022-06-20 16:18:25.665327
# Unit test for function to_native
def test_to_native():
    """
    Unit tests for `to_native` function in module_utils._text
    """
    from ansible.module_utils._text import to_native

    # ... when no encoding is specified, should return unicode text input characters
    assert to_native(u'some text') == u'some text'
    assert to_native(b'some text') == u'some text'
    assert to_native(u'\xe0 text') == u'\xe0 text'
    assert to_native(b'\xc3\xa0 text') == u'\xe0 text'

    # ... when encoding is specified, should return correct bytestring representation
    assert to_native(u'some text', 'utf-8') == b'some text'
    assert to_native(b'some text', 'utf-8') == b'some text'

# Generated at 2022-06-20 16:18:37.768508
# Unit test for function to_native
def test_to_native():
    string_types = (text_type, binary_type)
    str_types = string_types if PY3 else string_types + (int, float)

# Generated at 2022-06-20 16:18:53.922285
# Unit test for function to_native
def test_to_native():
    """
    Test function
    """


# Generated at 2022-06-20 16:19:03.201576
# Unit test for function container_to_text
def test_container_to_text():
    TESTDICT = {'simple': 'key1', 'unicode': u'\u2713', 'tuple': ('tuple', 'tuple'),
                'list': [1, 2, 3], 'dict': {'one': 1, 'two': 2}}

    # Test a valid utf-8 byte string input
    json_data = jsonify(TESTDICT)
    assert container_to_text(json.loads(json_data)) == TESTDICT

    json_data = jsonify(TESTDICT)
    assert container_to_text(json.loads(json_data.encode('utf-8'))) == TESTDICT

    # Test an invalid utf-8 byte string
    json_data = jsonify(TESTDICT)

# Generated at 2022-06-20 16:19:10.907372
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo', 'ascii') == b'foo'
    assert to_bytes(u'foo', 'ascii') == b'foo'
    assert to_bytes(b'foo', 'ascii') == b'foo'
    assert to_bytes(r'foo', 'ascii') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', 'ascii', 'strict') == b''
    assert to_bytes(u'\u1234', 'ascii', 'surrogate_or_strict') == b''
    assert to_bytes(u'\u1234', 'ascii', 'surrogate_or_replace') == b'?'


# Generated at 2022-06-20 16:19:22.141471
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test dictionary
    test_dict = {u"key1": u"value1",
                 u"key2": u"value2",
                 u"key3": [u"value3", u"value4", u"value5"],
                 u"key4": (u"value6", u"value7"),
                 u"key5": {u"key6": u"value9",
                           u"key7": u"value10"}}

    # Test list

# Generated at 2022-06-20 16:19:28.832930
# Unit test for function container_to_text
def test_container_to_text():
  assert container_to_text({"a":1, "b":2, "c":[3,4,5]}) == {"a":1, "b":2, "c":[3,4,5]}
  assert container_to_text({"a":1, "b":2, "c":(3,4)}) == {"a":1, "b":2, "c":(3,4)}
  assert container_to_text({"a":1, "b":2, "c":[3, 'b', 5]}) == {"a":1, "b":2, "c":[3, u'b', 5]}

# Generated at 2022-06-20 16:19:34.945742
# Unit test for function to_bytes
def test_to_bytes():
    # Note that this test is not as thorough as the json_dict_unicode_to_bytes
    # used to test the json module as that does not take the edge cases that
    # json_dict_unicode_to_bytes needs to.
    # to_bytes is called by our json wrapper and that does have those tests.
    # https://github.com/ansible/ansible/pull/15106

    # to_bytes(text_type)
    assert to_bytes("abcdefg") == b"abcdefg"
    assert to_bytes("abc😞😞defg") == b"abc\xf0\x9f\x98\x9edefg"

# Generated at 2022-06-20 16:19:40.168311
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {b'key1': b'value1', b'key2': b'value2'}
    assert container_to_bytes(d) == d

    d = {b'key1': b'value1', 'key2': 'value2'}
    assert container_to_bytes(d) == d
    d2 = container_to_bytes(d, encoding='latin-1')

    e = {b'key1': b'value1', b'key2': b'value2'}
    assert d2 == e

    d = {b'key1': b'value1', 'key2': 'value2'}
    f = {b'key1': b'value1', b'key2': b'value2'}
    assert container_to_bytes(d, encoding='latin-1') == f



# Generated at 2022-06-20 16:19:50.335507
# Unit test for function jsonify
def test_jsonify():
    data = {u"a": u"b"}
    json_out = jsonify(data)
    assert (json_out == '{"a": "b"}')
    data = {u"a": {u"b": u"c"}}
    json_out = jsonify(data)
    assert (json_out == '{"a": {"b": "c"}}')
    # Test for non ASCII Unicode
    data = {u"a": {u"b": u"\u6c49\u5b57"}}
    json_out = jsonify(data)
    assert (json_out == '{"a": {"b": "\\u6c49\\u5b57"}}')



# Generated at 2022-06-20 16:19:59.480145
# Unit test for function container_to_text
def test_container_to_text():
    container = {
        'dict': {'key1': 'value1', 'key2': 'value2'},
        'list': ['item1', 'item2'],
        'tuple': (1, 2),
        'float': 0.1,
        'bool': True,
        'int': 1,
        'str': "string",
    }


# Generated at 2022-06-20 16:20:06.632851
# Unit test for function to_native
def test_to_native():
    # empty string
    assert to_native('') == ''

    # bytes
    assert to_native(b'foo') == 'foo'
    assert to_native(b'\xc3\xb6\xc3\xa4\xc3\xbc') == 'öäü'
    assert to_native(b'\xe2\x92\xa9') == '⒩'

    # unicode
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\xf6\xe4\xfc') == 'öäü'
    assert to_native(u'\u24e9') == 'ⓩ'

    # be careful what you wish for ...
    assert to_native(u'foo') == 'foo'

# Generated at 2022-06-20 16:20:24.106441
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(1) == 1
    assert container_to_bytes(u'a') == b'a'
    assert container_to_bytes(b'a') == b'a'
    assert container_to_bytes([1,2,3]) == [1,2,3]
    assert container_to_bytes({1:'a',2:'b',3:'c'}) == {1:b'a',2:b'b',3:b'c'}
    assert container_to_bytes((1,2,3)) == (1,2,3)
    assert container_to_bytes([u'a', u'b', u'c']) == [b'a', b'b', b'c']

# Generated at 2022-06-20 16:20:27.462356
# Unit test for function container_to_text
def test_container_to_text():
    s = {"key": ["1", 2, {"key2": u"value"}]}
    t = container_to_text(s)
    if isinstance(next(iter(t)), text):
        assert True
    else:
        assert False

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-20 16:20:39.434261
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' Unit test for the container_to_bytes function'''
    b_str = b'abc'
    u_str = u'abc'
    u_str_unicode = u'\xe9'
    b_str_unicode = u'\xe9'.encode('utf-8')
    example = {b_str: [b_str, b_str_unicode, u_str_unicode, u_str],
               u_str: [b_str, b_str_unicode, u_str_unicode, u_str],
               (1, 2): {b_str: [b_str, b_str_unicode, u_str_unicode, u_str]}}

    # Test on dict
    example_result = container_to_bytes(example)

# Generated at 2022-06-20 16:20:50.453616
# Unit test for function to_bytes
def test_to_bytes():
    # Can't use codecs.lookup_error('surrogateescape') as that would trigger
    # the slow path on python3
    def surrogateescape(exc):
        if isinstance(exc, UnicodeEncodeError):
            return (u"\udcff", exc.end)
        elif isinstance(exc, UnicodeDecodeError):
            return (u"\udcff", exc.start + 1)
        else:
            raise TypeError("don't know how to handle %r" % exc)
    codecs.register_error('surrogateescape', surrogateescape)
    bstr = to_bytes(' foo bar ')

    assert isinstance(bstr, binary_type)
    assert bstr == b' foo bar '

    bstr = to_bytes(u' foo bar ')


# Generated at 2022-06-20 16:20:58.774178
# Unit test for function to_bytes
def test_to_bytes():
    # Note: The following are tests that used to be in the Ansible core test
    # harness.  We can't run them there because we have no way to change what
    # codec error handlers are available.

    # The first group of tests check whether surrogateescape is available and
    # if it is we test that it's used.

    null_byte = b'\x00'
    valid_bytes = b'01234 !"#$%^&\'()*+,-./:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~'
    garbled_bytes = b'\xff\xfe'
    mixed_bytes = garbled_bytes + valid_bytes + garbled_bytes

# Generated at 2022-06-20 16:21:05.686774
# Unit test for function container_to_text
def test_container_to_text():
    # Test with strings
    assert container_to_text(b'a') == u'a'
    assert container_to_text(b'a') == u'a'
    # Test with numbers
    assert container_to_text(1) == 1
    assert container_to_text(1.1) == 1.1
    assert container_to_text(1 + 2j) == 1 + 2j
    # Test with a list
    assert container_to_text([b'a']) == [u'a']
    assert container_to_text([b'a', [b'b', b'c']]) == [u'a', [u'b', u'c']]
    # Test with a tuple
    assert container_to_text((b'a',)) == (u'a',)
    assert container_to_text

# Generated at 2022-06-20 16:21:13.981607
# Unit test for function container_to_text
def test_container_to_text():
    b = dict(a=dict(b='\x80\x81'))
    assert (container_to_text(b, 'utf-8') == dict(a=dict(b=u'\ufffd\ufffd')))
    assert (container_to_text(b, 'utf-8', 'surrogate_then_replace') == dict(a=dict(b=u'\ufffd\ufffd')))
    assert (container_to_text(b, 'utf-8', 'surrogate_or_replace') == dict(a=dict(b=u'\ufffd\ufffd')))


# TODO: needs some error handling

# Generated at 2022-06-20 16:21:22.721666
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(2) == 2
    assert container_to_text(u'foo') == u'foo'
    assert container_to_text(u_('foo')) == u'foo'
    assert container_to_text(2, encoding='utf-8', errors='surrogate_then_replace') == 2
    assert container_to_text(u'foo', encoding='utf-8', errors='surrogate_then_replace') == u'foo'
    assert container_to_text(u_('foo'), encoding='utf-8', errors='surrogate_then_replace') == u'foo'

# Generated at 2022-06-20 16:21:30.897635
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text({'a': '1'}) == {u'a': u'1'}
    assert container_to_text({'a': 1}) == {u'a': 1}
    assert container_to_text({'a': 1.0}) == {u'a': 1.0}
    assert container_to_text({'a': [1, 2]}) == {u'a': [1, 2]}
    assert container_to_text({'a': (1, 2)}) == {u'a': (1, 2)}
    assert container_to_text({'a': '1'}, encoding='latin-1') == {u'a': u'1'}

# Generated at 2022-06-20 16:21:37.978834
# Unit test for function to_bytes
def test_to_bytes():
    # This covers the corner case where surrogateescape is set to
    # surrogate_then_replace to cover for the fact that surrogateescape is not
    # in the default codecs. It should never be possible to reach this in
    # practice.
    if hasattr(codecs, 'register_error'):
        codecs.register_error('surrogateescape',
                              lambda exc: (u'\uFFFD', exc.start + 1))
    with pytest.raises(KeyError):
        to_bytes('foo', errors='surrogate_then_replace')


# Generated at 2022-06-20 16:21:58.323198
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(1) == 1
    assert container_to_text([1]) == [1]
    assert container_to_text((1,)) == (1,)
    assert container_to_text({'a': 1}) == {'a': 1}

    assert container_to_text([u'foo']) == [u'foo']
    assert container_to_text({u'a': u'b'}) == {u'a': u'b'}
    assert container_to_text({'a': u'b'}) == {u'a': u'b'}

    assert container_to_text({b'a': b'b'}) == {u'a': u'b'}
    assert container_to_text({'a': b'b'}) == {u'a': u'b'}



# Generated at 2022-06-20 16:22:05.820988
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils._text import to_bytes
    string_bytes = b'foo'
    string_unicode = u'Ω'

    # Test to_bytes(text_string, encoding='ascii', errors='strict') == b'foo'
    assert to_bytes(string_unicode, encoding='ascii', errors='strict') == b'\xce\xa9'
    assert to_bytes(string_unicode, encoding='ascii', errors='surrogate_or_strict') == b'\xce\xa9'
    assert to_bytes(string_unicode, encoding='ascii', errors='surrogate_or_replace') == b'?'

    # Test to_bytes(bytes_string, encoding='ascii', errors='strict') == b'foo'
   

# Generated at 2022-06-20 16:22:14.723268
# Unit test for function to_bytes
def test_to_bytes():
    import sys
    assert sys.version_info >= (2, 6)

    assert isinstance(to_bytes(u'Wänter'), binary_type)
    assert isinstance(to_bytes(b'Wnter'), binary_type)
    assert isinstance(to_bytes(b'\xFF', errors='surrogate_or_replace'), binary_type)
    assert u'Wänter'.encode('utf-8') == to_bytes(u'Wänter')
    assert b'Wnter' == to_bytes(b'Wnter')
    assert to_bytes(12345) == b'12345'
    assert to_bytes(1 + 2j) == b'(1+2j)'
    assert to_bytes(b'\xFF', errors='surrogate_or_replace') == b

# Generated at 2022-06-20 16:22:27.876215
# Unit test for function container_to_bytes
def test_container_to_bytes():
    t = 'å'.encode('utf-8')
    d = {'1': 'å'.encode('utf-8')}
    assert to_bytes(d) == container_to_bytes(d)
    d = {'1': [t]}
    assert to_bytes(d) == container_to_bytes(d)
    d = {'1': {'2': t}}
    assert to_bytes(d) == container_to_bytes(d)
    d = {'1': {'2': t, '3': d}}
    assert to_bytes(d) == container_to_bytes(d)
    d = {'1': (t, d)}
    assert to_bytes(d) == container_to_bytes(d)
    d = (t, d)
    assert to_bytes(d) == container

# Generated at 2022-06-20 16:22:39.265505
# Unit test for function to_native
def test_to_native():
    ''' test_to_native '''
    # using sample data from stdlib test

# Generated at 2022-06-20 16:22:43.331606
# Unit test for function jsonify
def test_jsonify():
    pass
    # assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    #
    # value = {'foo': 'bar', 'baz': {'fob': 'oar'}}
    #
    # assert jsonify(value) == '{"foo": "bar", "baz": {"fob": "oar"}}'
    #
    # value = {'foo': 'bar', 'baz': ('fob', 'oar')}
    #
    # assert jsonify(value) == '{"foo": "bar", "baz": ["fob", "oar"]}'



# Generated at 2022-06-20 16:22:51.437666
# Unit test for function to_bytes
def test_to_bytes():
    data = {
        u'to_bytes': {
            u'empty': b'',
            u'simplerepr': b'True',
            u'strict': b'',
        },
        u'test_obj': True,
    }

    assert to_bytes(data['test_obj'], nonstring='empty') == data['to_bytes']['empty']
    assert to_bytes(data['test_obj'], nonstring='simplerepr') == data['to_bytes']['simplerepr']
    assert to_bytes(data['test_obj']) == data['to_bytes']['simplerepr']
    assert to_bytes(data['test_obj'], nonstring='strict') == data['to_bytes']['strict']



# Generated at 2022-06-20 16:23:01.290886
# Unit test for function container_to_text
def test_container_to_text():
    # Test for text_type
    text = "ä"
    check_text = container_to_text(text)
    assert(check_text == text)

    # Test for binary_type
    binary = b"\xc3\xa4"
    check_binary = container_to_text(binary)
    assert(check_binary == text)

    # Test for other(int, complex, float)
    other = 1
    check_other = container_to_text(other)
    assert(check_other == other)

    # Test for tuple
    tup = (1, "ä", binary)
    check_tup = container_to_text(tup)
    assert(check_tup == tuple([1, text, text]))

    # Test for list
    lst = [1, "ä", binary]
   

# Generated at 2022-06-20 16:23:13.195778
# Unit test for function to_bytes
def test_to_bytes():
    # Make sure we can encode a string
    assert to_bytes(u'abcd') == b'abcd'
    assert to_bytes('abcd') == b'abcd'

    # Make sure we don't encode non-strings
    assert to_bytes(1) == b'1'
    assert to_bytes({}) == b'{}'

    # Make sure we encode unicode properly
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'

    # Make sure surrogate_or_strict works

# Generated at 2022-06-20 16:23:24.029910
# Unit test for function to_bytes
def test_to_bytes():
  import sys
  import unittest
  class TestStringMethods(unittest.TestCase):
    def setUp(self):
      pass
    def tearDown(self):
      pass
    def test_to_bytes(self):
      self.assertEqual(
          to_bytes(to_bytes('test_to_bytes', encoding='utf-8', errors=None, nonstring='simplerepr')),
          to_bytes('test_to_bytes', encoding='utf-8', errors=None, nonstring='simplerepr'))
      self.assertEqual(
          to_bytes(to_bytes('test_to_bytes', encoding='utf-8', errors=None, nonstring='empty')),
          to_bytes('test_to_bytes', encoding='utf-8', errors=None, nonstring='empty'))
      self

# Generated at 2022-06-20 16:23:45.138702
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo', encoding='utf-8') == b'foo'
    assert to_bytes(u'foo', encoding='utf-8') == b'foo'
    assert to_bytes('\xc3\xa9', encoding='utf-8') == b'\xc3\xa9'
    assert to_bytes(u'\u00e9', encoding='utf-8') == b'\xc3\xa9'
    assert to_bytes('\xc3\xa9\xc3\xa9\xc3\xa9', encoding='utf-8') == b'\xc3\xa9\xc3\xa9\xc3\xa9'

# Generated at 2022-06-20 16:23:55.626633
# Unit test for function jsonify
def test_jsonify():
    '''Test the jsonify function'''

    # simple example
    expected_result = json.dumps('test')
    actual_result = jsonify('test')
    assert actual_result == expected_result

    # example with encoding
    expected_result = json.dumps(u'abcd\xac', encoding='latin-1')
    actual_result = jsonify(u'abcd\xac')
    assert actual_result == expected_result

    # check for exception in case of encoding error
    try:
        jsonify(u'abcd\xacx', encoding='ascii')
    except UnicodeError:
        pass
    except Exception as e:
        raise AssertionError("Unexpected exception caught in jsonify(): %s" % jsonify(e))

# Generated at 2022-06-20 16:24:04.022581
# Unit test for function to_bytes
def test_to_bytes():
    # Test with a few different encodings
    valid_unicode = u'\u2713'
    utf8_encoded = valid_unicode.encode('utf-8')
    latin1_encoded = valid_unicode.encode('latin-1')

    # Test that unicode strings are properly encoded
    assert to_bytes(valid_unicode) == utf8_encoded
    assert to_bytes(valid_unicode, 'utf-8') == utf8_encoded
    assert to_bytes(valid_unicode, 'latin-1') == latin1_encoded

    # Test that byte strings are left alone
    assert to_bytes(utf8_encoded) == utf8_encoded
    assert to_bytes(utf8_encoded, 'utf-8') == utf8_

# Generated at 2022-06-20 16:24:06.865658
# Unit test for function to_native
def test_to_native():
    assert to_native("moo") == "moo", "to_native returned incorrect data"


# Generated at 2022-06-20 16:24:13.244631
# Unit test for function jsonify
def test_jsonify():
    a = dict(a=1)
    assert jsonify(a) == '{"a": 1}'
    a = dict(a=1, b=u'abc')
    assert jsonify(a) == '{"a": 1, "b": "abc"}'
    a = dict(a=1, b=u'\u2028\u2029')
    assert jsonify(a) == '{"a": 1, "b": "\\u2028\\u2029"}'


# Generated at 2022-06-20 16:24:22.544393
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # dict
    input_dict = {"a": u"\u2019"}
    input_dict_bytes = {"a": b"'" }
    assert container_to_bytes(input_dict) == input_dict_bytes
    # list
    input_list = [u"\u2019"]
    input_list_bytes = [b"'" ]
    assert container_to_bytes(input_list) == input_list_bytes
    # tuple
    input_tuple = (u"\u2019", )
    input_tuple_bytes = (b"'" , )
    assert container_to_bytes(input_tuple) == input_tuple_bytes
    # string
    input_string = u"\u2019"
    input_string_bytes = b"'"
    assert container_to_bytes(input_string) == input_

# Generated at 2022-06-20 16:24:33.628656
# Unit test for function to_bytes

# Generated at 2022-06-20 16:24:42.542416
# Unit test for function to_native
def test_to_native():
    output = to_native("Iñtërnâtiônàlizætiøn", nonstring="passthru")
    assert output == "Iñtërnâtiônàlizætiøn"

    output = to_native("Iñtërnâtiônàlizætiøn", nonstring="simplerepr", errors="surrogate_or_replace")
    assert output == "Iñtërnâtiônàlizætiøn"

    output = to_native("Iñtërnâtiônàlizætiøn", nonstring="simplerepr", errors="surrogate_or_strict")
    assert output == "Iñtërnâtiônàlizætiøn"


# Generated at 2022-06-20 16:24:52.606472
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test Case 1 : For string input
    inp = u'\u00e9'
    result = container_to_bytes(inp)
    assert isinstance(result, bytes)

    # Test Case 2 : For dictionary input
    inp = {u'key': u'\u00e9'}
    result = container_to_bytes(inp)
    assert isinstance(result, dict)
    assert isinstance(list(result.keys())[0], bytes)
    assert isinstance(list(result.values())[0], bytes)

    # Test Case 3 : For list input
    inp = [u'\u00e9']
    result = container_to_bytes(inp)
    assert isinstance(result, list)
    assert isinstance(result[0], bytes)

    # Test Case 4 : For tuple

# Generated at 2022-06-20 16:25:00.813811
# Unit test for function to_native
def test_to_native():
    '''Tests to_native function
    '''
    s = 'this is a unicode string'
    b = b'this is a byte string'

    if PY3:
        assert to_native(s) is s
        assert to_native(b) is b
    else:
        assert to_native(s) == s
        assert to_native(b) == s


if PY3:
    def to_native(obj, *args, **kwargs):
        return obj
else:
    def to_native(obj, encoding='utf-8', errors=None, nonstring='simplerepr'):
        if isinstance(obj, binary_type):
            return text_type(obj, encoding, errors)

# Generated at 2022-06-20 16:25:19.998706
# Unit test for function container_to_bytes
def test_container_to_bytes():
    empty_dict = {}
    empty_list = []
    empty_tuple = ()
    unicode_text = u'\u1885'
    unicode_key = u'\u1885'
    unicode_text_list = [u'\u1885']
    unicode_text_tuple = (u'\u1885',)
    unicode_text_tuple_list = [(u'\u1885',)]
    unicode_text_dict = {u'\u1885': u'\u1885'}
    unicode_text_dict_list = [{u'\u1885': u'\u1885'}]
    unicode_text_dict_tuple_list = [{u'\u1885': (u'\u1885',)}]
    unicode_text