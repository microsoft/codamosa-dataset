

# Generated at 2022-06-20 16:15:35.221528
# Unit test for function jsonify
def test_jsonify():
    test_input = {
        u"json_arr": [u"first", unicode( "second", "latin-1" ), u"\u2295"],
        u"json_obj": [{ u"inner_field": u"\u2295" }],
        u"json_str": u"\u2295",
        u"json_int": 1,
        u"json_dec": 3.14,
        u"json_arr_mixed": [{ u"inner_field": u"\u2295" }, u"\u2295", 1, 3.14],
    }


# Generated at 2022-06-20 16:15:47.014757
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(b'foo', nonstring='passthru') == b'foo'

    assert to_bytes('foo') == b'foo'
    # If there are no surrogates, surrogates are not special
    assert to_bytes('foo', errors='surrogate_or_replace') == b'foo'
    assert to_bytes('foo', errors='surrogate_or_strict') == b'foo'
    assert to_bytes('foo', errors='surrogate_then_replace') == b'foo'
    # if there are surrogates, we want them to be stripped
    assert to_bytes(u"\udce3", errors='surrogate_or_replace') == b'\udce3'

# Generated at 2022-06-20 16:15:55.024202
# Unit test for function to_bytes
def test_to_bytes():
    s = u'\u00c6neid'
    assert len(s) == 6
    assert len(to_bytes(s)) == 6
    s = u'\u00c6neid'.encode('utf-8', 'surrogateescape')
    assert len(to_bytes(s)) == 6
    with pytest.raises(UnicodeEncodeError):
        # On Python2 this will fail because there's no surrogateescape error handler
        to_bytes(s, errors='surrogate_or_replace')
    with pytest.raises(UnicodeEncodeError):
        # On Python2 this will fail because there's no surrogateescape error handler
        to_bytes(s, errors='surrogate_or_strict')

# Generated at 2022-06-20 16:16:05.017536
# Unit test for function to_bytes
def test_to_bytes():
    def assert_bytes_equal(expected, *args, **kwargs):
        extracted = to_bytes(*args, **kwargs)
        try:
            assert expected == extracted
        except AssertionError:
            # This is so that on failure we'll get the differ output instead
            # of simply "assert False"
            assert expected == extracted

    assert_bytes_equal(b'abc', 'abc')
    assert_bytes_equal(b'abc', u'abc')
    assert_bytes_equal(b'abc', to_text(u'abc'))
    assert_bytes_equal(b'abc', b'abc')
    assert_bytes_equal(b'abc', to_bytes(b'abc'))
    assert_bytes_equal(b'abc', u'abc'.encode('utf-8'), errors='surrogateescape')

# Generated at 2022-06-20 16:16:12.600477
# Unit test for function jsonify
def test_jsonify():
    after_json_data = '{"a": {"b": ["b1", "b2"], "c": "c", "d": "d"}, "e": "e"}'
    data = {
        'a': {
            'b': ['b1', 'b2'],
            'c': u'c',
            'd': b'd'
        },
        'e': b'e'
    }
    assert jsonify(data) == after_json_data


# Generated at 2022-06-20 16:16:21.481729
# Unit test for function to_bytes
def test_to_bytes():
    assert b'\xc3\xa9' == to_bytes('\xe9')
    if not PY3:
        if HAS_SURROGATEESCAPE:
            assert b'\xff\xff' == to_bytes('\udcff')
        else:
            assert b'?' == to_bytes('\udcff', errors='surrogate_or_strict')
            assert b'?' == to_bytes('\udcff', errors='surrogate_or_replace')
            try:
                to_bytes('\udcff')
                raise AssertionError('to_bytes should have raised an error')
            except UnicodeEncodeError:
                pass
    assert b'\xe9' == to_bytes('\xe9', errors='surrogate_then_replace')

# Generated at 2022-06-20 16:16:26.911938
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'bob': '\x80abc'}, encoding='latin-1') == u'{"bob": "\\u0080abc"}'
    assert jsonify({'bob': '\x80abc'}, encoding='utf-8') == u'{"bob": "\\u0080abc"}'


# This is used by the templar module

# Generated at 2022-06-20 16:16:39.022656
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert isinstance(container_to_bytes(u'foo'), binary_type)
    assert isinstance(container_to_bytes({u'foo': u'bar'}), dict)
    assert isinstance(container_to_bytes({u'foo': u'bar'})[b'foo'], binary_type)
    assert isinstance(container_to_bytes([u'foo', u'bar']), list)
    assert isinstance(container_to_bytes([u'foo', u'bar'])[0], binary_type)
    assert isinstance(container_to_bytes((u'foo', u'bar')), tuple)
    assert isinstance(container_to_bytes((u'foo', u'bar'))[0], binary_type)

# Generated at 2022-06-20 16:16:49.827982
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text("foo") == u"foo"
    assert container_to_text("foo".encode()) == u"foo"
    assert container_to_text(u"foo") == u"foo"
    assert container_to_text({"a": 1}) == {"a": 1}
    assert container_to_text({"a": 1, "b": "foo".encode()}) == {"a": 1, "b": u"foo"}
    assert container_to_text(["foo", 1]) == [u"foo", 1]
    assert container_to_text(("foo", 1)) == (u"foo", 1)
    assert container_to_text([("foo", 1), (b"bar", 2)]) == [(u"foo", 1), (u"bar", 2)]

# Generated at 2022-06-20 16:17:01.481236
# Unit test for function to_bytes
def test_to_bytes():

    def helper_test_to_bytes(value, expected, encoding='ascii', errors=None, nonstring='simplerepr'):
        # Test the to_bytes function
        assert to_bytes(value, encoding, errors, nonstring) == expected

        # Make sure that the object we get back is the same type as what we
        # passed in
        if isinstance(value, binary_type):
            assert isinstance(to_bytes(value, encoding, errors, nonstring),
                              binary_type)
        else:
            assert isinstance(to_bytes(value, encoding, errors, nonstring),
                              text_type)

    helper_test_to_bytes('hello', b'hello')
    helper_test_to_bytes(u'Ö', b'\xc3\x96', encoding='latin-1')
   

# Generated at 2022-06-20 16:17:20.333275
# Unit test for function to_bytes
def test_to_bytes():
    # Tests with no errors
    assert to_bytes(u'\u00C0') == b'\xc3\x80'
    assert to_bytes(u'\u00C0', errors='surrogate_or_strict') == b'\xc3\x80'
    assert to_bytes(u'\u00C0', errors='surrogate_or_replace') == b'\xc3\x80'
    assert to_bytes(u'\u00C0', errors='surrogate_then_replace') == b'\xc3\x80'
    # Tests with errors
    assert to_bytes(u'\u00C0', encoding='latin-1') == b'\xc3\x80'

# Generated at 2022-06-20 16:17:32.076959
# Unit test for function container_to_text
def test_container_to_text():

    #Test dict
    d_dict = dict([(u'key1', u'value1'), (u'key2', u'value2'),
                   (u'key3', u'value3')])
    d_dict_result = container_to_text(d_dict)
    assert d_dict_result == d_dict

    d_dict = dict([(b'key1', b'value1'), (b'key2', b'value2'),
                   (b'key3', b'value3')])
    d_dict_result = container_to_text(d_dict)
    assert d_dict_result == dict([('key1', 'value1'), ('key2', 'value2'),
                   ('key3', 'value3')])


# Generated at 2022-06-20 16:17:41.447779
# Unit test for function jsonify
def test_jsonify():
    """
    test case for function jsonify in lib/ansible/module_utils/_text.py
    """
    from ansible.module_utils.six import StringIO

    # test case for json serialization
    test_data = StringIO()
    test_data.write(u'\u4e2d\u6587')
    origin_str = test_data.getvalue()

    new_str = jsonify(origin_str)
    assert new_str

    # test case for error string
    test_data = StringIO()
    test_data.write(u'\u4e2d\u6587')
    test_data.seek(0)
    result = jsonify(test_data)
    assert result



# Generated at 2022-06-20 16:17:52.775288
# Unit test for function to_bytes
def test_to_bytes():
    # to_bytes(obj, encoding='utf-8', errors=None, nonstring='simplerepr')
    # to_bytes(obj)
    assert isinstance(to_bytes(''), binary_type)
    assert isinstance(to_bytes('foo'), binary_type)

    # to_bytes(obj, encoding='utf-8')
    assert isinstance(to_bytes('', encoding='utf-8'), binary_type)
    assert isinstance(to_bytes('foo', encoding='utf-8'), binary_type)

    # to_bytes(obj, errors=None, nonstring='simplerepr')
    # to_bytes(obj, errors='replace')
    assert isinstance(to_bytes('', errors='replace'), binary_type)
    assert isinstance(to_bytes('foo', errors='replace'), binary_type)

    #

# Generated at 2022-06-20 16:18:02.473980
# Unit test for function jsonify
def test_jsonify():
    if PY3:
        # PY3 code path is not exercised by this test
        return
    try:
        from simplejson import JSONDecodeError
    except ImportError:
        from json import JSONDecodeError
    from ansible.module_utils import basic
    import json_test_pkg
    try:
        import wlenc
    except ImportError:
        wlenc = None

    if wlenc:
        wlenc.set_encoding()

    # Code path exercised by this test
    basic._ANSIBLE_ARGS = None
    # json_test_pkg.json_obj() returns unicode str which is decoded by json.loads
    # if the system encoding (user locale) is utf-8.
    if wlenc:
        wlenc.set_encoding('utf-8')
    result

# Generated at 2022-06-20 16:18:14.853554
# Unit test for function to_bytes
def test_to_bytes():
    if PY3:
        # PY3: Need to monkeypatch so we can test the surrogate_then_replace codepath
        ansible_module_utils_common_collections_compat_Set = Set
        Set = None

# Generated at 2022-06-20 16:18:23.761835
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(u"\u6c49\u5b57") == b"\xe6\xb1\x89\xe5\xad\x97"
    assert container_to_bytes({}) == {}
    assert container_to_bytes({u"a": u"\u6c49\u5b57"}) == {b"a":b"\xe6\xb1\x89\xe5\xad\x97"}
    assert container_to_bytes({"a": {}}) == {b"a":{}}
    assert container_to_bytes({"a": {u"b": u"\u6c49\u5b57"}}) == {b"a":{b"b":b"\xe6\xb1\x89\xe5\xad\x97"}}
   

# Generated at 2022-06-20 16:18:36.335751
# Unit test for function container_to_text
def test_container_to_text():
    def assert_identical_items(items1, items2):
        items1 = sorted(items1)
        items2 = sorted(items2)
        assert [type(item) for item in items1] == [type(item) for item in items2]
        assert len(items1) == len(items2)
        for item1, item2 in zip(items1, items2):
            if isinstance(item1, dict):
                assert_identical_items(item1.items(), item2.items())
            elif isinstance(item1, (list, tuple)):
                assert_identical_items(item1, item2)
            else:
                assert item1 == item2


# Generated at 2022-06-20 16:18:38.871007
# Unit test for function jsonify
def test_jsonify():
    a_dict = {"foo": u"bar"}
    assert jsonify(a_dict)



# Generated at 2022-06-20 16:18:50.000713
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == 'foo'
    assert to_native(1) == 1
    assert to_native(b'foo') == 'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

    if PY3:
        assert type(to_native('foo')) == str
        assert type(to_native(1)) == int
        assert type(to_native(b'foo')) == str

# Generated at 2022-06-20 16:19:10.975369
# Unit test for function container_to_text
def test_container_to_text():
    data = u"中文"
    assert data == container_to_text(data)

    data = ["中文"]
    assert data == container_to_text(data)

    data = {"中文": "中文"}
    assert data == container_to_text(data)

    data = {"中文": ["中文"]}
    assert data == container_to_text(data)

    data = data = {"中文": [u"中文", "中文"]}
    assert data == container_to_text(data)

    data = {"中文": {"中文": "中文"}}
    assert data == container_to_text(data)

    data = b"\xe4\xb8\xad\xe6\x96\x87"

# Generated at 2022-06-20 16:19:18.882066
# Unit test for function container_to_text
def test_container_to_text():
    """
    Test container_to_text function
    """
    input = {u'x': [u'\N{GREEK SMALL LETTER ALPHA}\N{GREEK SMALL LETTER BETA}'.encode('utf-16')]}
    output = {'x': [u'\N{GREEK SMALL LETTER ALPHA}\N{GREEK SMALL LETTER BETA}']}
    assert container_to_text(input, encoding='utf-16') == output

# Generated at 2022-06-20 16:19:22.097476
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    expected = b'{"a": "b", "c": "d"}'
    result = jsonify(data)
    assert result == expected



# Generated at 2022-06-20 16:19:30.929368
# Unit test for function to_bytes
def test_to_bytes():
    # Make up an arbitrary misencoded utf-8 string
    text_value = u'This is a string \U0001f37a'
    # We'll encode to utf-8 to get the byte string
    text_encoded = text_value.encode('utf-8')
    # but we'll mangle the byte string to be invalid utf-8
    start_pos = text_encoded.index(b'\xed')
    end_pos = text_encoded.index(b'\xa2', start_pos) + 1
    text_encoded = text_encoded[:start_pos] + b'\x00' + text_encoded[end_pos:]

    assert to_bytes(text_value) == text_encoded, \
        "to_bytes did not return the expected value when passed a text string"

# Generated at 2022-06-20 16:19:37.316979
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {'a': 1, u'b': u'hello', 'c': [1, 2, [u'x', u'y', u'z']]}
    out = container_to_bytes(d)
    assert isinstance(out, dict)
    assert isinstance(out['a'], int)
    assert isinstance(out['b'], binary_type)
    assert isinstance(out['c'], list)
    assert out['c'] == [1, 2, [b'x', b'y', b'z']]
    assert isinstance(out['c'][2][0], binary_type)


# Generated at 2022-06-20 16:19:43.828461
# Unit test for function jsonify
def test_jsonify():
    # unicode
    assert (jsonify(u'{"foo": "bar"}') == '{"foo": "bar"}')
    # bytes
    if PY3:
        assert (jsonify(b'{"foo": "bar"}') == '"{\\"foo\\": \\"bar\\"}"')
    else:
        assert (jsonify(b'{"foo": "bar"}') == '{"foo": "bar"}')
    # dict
    assert (jsonify({"foo": b"bar"}) == '{"foo": "bar"}')
    # list
    assert (jsonify([{"foo": b"bar"}]) == '[{"foo": "bar"}]')
    # tuple
    assert (jsonify(({"foo": b"bar"},)) == '[{"foo": "bar"}]')
    # set

# Generated at 2022-06-20 16:19:49.561600
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes('\xe9') == to_bytes('\xe9')
    assert container_to_bytes([1, 2], errors='surrogate_or_strict') == [1, 2]
    assert container_to_bytes([1, u'\xe9']) == [1, to_bytes('\xe9')]
    assert container_to_bytes((1, u'\xe9')) == (1, to_bytes('\xe9'))
    assert container_to_bytes({u'\xe9': 1}) == {to_bytes('\xe9'): 1}
    assert container_to_bytes({}) == {}
    assert container_to_bytes([]) == []
    assert container_to_bytes(()) == ()

# Generated at 2022-06-20 16:19:57.467773
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' Function to test container_to_bytes'''
    assert container_to_bytes(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert container_to_bytes(('a', 'b', 'c')) == ('a', 'b', 'c')
    assert container_to_bytes({'a': 'b', 'c': 'd'}) == {b'a': b'b', b'c': b'd'}
    assert container_to_bytes({'a': 'b', 'c': 'd'}, encoding='latin-1') == {b'a': b'b', b'c': b'd'}

# Generated at 2022-06-20 16:20:05.219243
# Unit test for function jsonify
def test_jsonify():

    test_input = dict(a=1, b='2', c=3, d=None, e=[1, 2], f=(1, 2, 3), g={'a': 1},
                      h=set([1, 2, 3]))

    if PY3:
        test_input['i'] = b'bytes'
    else:
        test_input['i'] = bytearray(b'bytearray')

    expected_output = '''{"a": 1, "b": "2", "c": 3, "d": null, "e": [1, 2], \
"f": [1, 2, 3], "g": {"a": 1}, "h": [1, 2, 3], "i": "bytes"}'''

    expected_output = expected_output.replace(' ', '')

# Generated at 2022-06-20 16:20:09.580236
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test a list
    test_list = [u'foo', u'bar']
    result = container_to_bytes(test_list)
    assert isinstance(result[0], text_type)

    # Test a tuple
    test_tuple = [u'foo', u'bar']
    result = container_to_bytes(test_list)
    assert isinstance(result[0], text_type)

    # Test a dict
    test_dict = {u'foo':u'bar'}
    result = container_to_bytes(test_dict, errors='surrogate_or_replace')
    assert isinstance(result[b'foo'], text_type)


# Generated at 2022-06-20 16:20:36.297876
# Unit test for function jsonify
def test_jsonify():
    data = {'foo': b'ABCD'}
    if PY3:
        assert jsonify(data) == '{"foo": "ABCD"}'
    else:
        assert jsonify(data) == '{"foo": "ABCD"}'

# Generated at 2022-06-20 16:20:44.575617
# Unit test for function jsonify
def test_jsonify():

    data = {
        'a': u'\ue77c',
        'b': 'c',
        'd': {
            'e': 'f'
        }
    }

    ret = jsonify(data)
    assert isinstance(ret, text_type)
    assert ret == '{"a": "\\ue77c", "b": "c", "d": {"e": "f"}}'

    class Foo:
        def __init__(self, x):
            self.x = x

        def __repr__(self):
            return 'Foo(%s)' % self.x

    data = [u'\ue77c', Foo('bar')]
    ret = jsonify(data)
    assert isinstance(ret, text_type)

# Generated at 2022-06-20 16:20:55.358113
# Unit test for function to_native
def test_to_native():
    assert to_native(1, errors='surrogate_or_strict') == u'1'
    assert to_native(1, errors='surrogate_or_replace') == u'1'
    assert to_native(1, errors='surrogate_then_replace') == u'1'
    assert to_native(1.2, errors='surrogate_or_strict') == u'1.2'
    assert to_native(1.2, errors='surrogate_or_replace') == u'1.2'
    assert to_native(1.2, errors='surrogate_then_replace') == u'1.2'
    assert to_native(u'a', errors='surrogate_or_strict') == u'a'

# Generated at 2022-06-20 16:21:00.700219
# Unit test for function container_to_text
def test_container_to_text():
    binary_sample = {
        b'key': b'value'
    }
    text_sample = {
        u'key': u'value'
    }
    assert container_to_text(text_sample) == {
        u'key': u'value'
    }

    assert container_to_text(binary_sample) == {
        u'key': u'value'
    }



# Generated at 2022-06-20 16:21:05.696953
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({u'foo': u'bar'}) == {b'foo': b'bar'}
    assert container_to_bytes([u'bar']) == [b'bar']
    assert container_to_bytes((u'bar',)) == (b'bar',)



# Generated at 2022-06-20 16:21:15.919575
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('hello world') == b'hello world'
    assert to_bytes(b'hello world') == b'hello world'
    assert to_bytes('Привет мир') == b'\xd0\x9f\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82 \xd0\xbc\xd0\xb8\xd1\x80'

# Generated at 2022-06-20 16:21:17.377282
# Unit test for function jsonify
def test_jsonify():
    test_data = {
        'test1': {
            'test2': to_bytes('test3\u00be', encoding='latin-1')
        }
    }
    print(jsonify(data=test_data))


# Generated at 2022-06-20 16:21:24.509893
# Unit test for function container_to_text
def test_container_to_text():
    oth=container_to_text({"a":1,"b":2})
    assert oth=={"a":1,"b":2}
    oth=container_to_text([1,2,3,4,'a'])
    assert oth==[1,2,3,4,'a']
    oth=container_to_text(["a",1,2,(3,4)])
    assert oth==["a",1,2,(3,4)]
    oth=container_to_text((1,2,3,4,'a'))
    assert oth==(1,2,3,4,'a')
    oth=container_to_text((["a",1,2,(3,4)]))
    assert oth==(["a",1,2,(3,4)])



# Generated at 2022-06-20 16:21:35.618907
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native

    class TestModule(object):
        def __init__(self, argspec):
            self.params = dict()
            for key in argspec:
                self.params[key] = None

    m = TestModule({'a': 'a', 'b': False, 'c': 1, 'd': 3.14, 'e': [1, 2, 3], 'f': [], 'g': (1, 2, 3), 'h': set([1, 2, 3]), 'i': {'a': 1, 'b': 2}, 'j': None, 'k': datetime.datetime(1997, 8, 29, 12, 0, 0)})
    assert to_native(m, 'a') == 'a'


# Generated at 2022-06-20 16:21:46.879935
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('ascii: foo') == b'ascii: foo'
    assert to_bytes(u'non-ascii: \u2713') == b'non-ascii: \xe2\x9c\x93'
    assert to_bytes(u'non-ascii: \u2713', encoding='ascii') == b'non-ascii: ?'
    assert to_bytes(u'non-ascii: \u2713', encoding='ascii', errors='ignore') == b'non-ascii: '

    # The following tests are only valid on utf-8 supporting systems
    # Note: we don't check to see that codecs.lookup('surrogateescape') is a
    # valid handler because surrogateescape may have been registered already
    # via backports in

# Generated at 2022-06-20 16:22:15.375545
# Unit test for function to_native
def test_to_native():

    assert to_native(u"størstepartens") == u"størstepartens"
    assert to_native(b"st\xc3\xb8rstepartens") == u"størstepartens"
    assert to_native(b"\xc3\x85") == u"\xe5"
    assert to_native(b"\xc3") == u"\xc3"
    assert to_native(b"\xc3\x85") == u"\xe5"
    assert to_native(b"\xc3\x85", errors='surrogate_or_replace') == u"\ufffd"
    assert to_native(b"\xc3\x85", errors='surrogate_or_strict') == u"\xe5"

# Generated at 2022-06-20 16:22:23.656564
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {u'test': [1, u'abc'], u'foo': u'bar'}
    d_out = container_to_bytes(d)
    assert isinstance(d_out['test'][1], bytes)
    assert isinstance(d_out['foo'], bytes)
    assert d_out['test'][1] == b'abc'
    assert d_out['foo'] == b'bar'


# We have to pass encoding through a lot of the json calls, so we have a
# wrapper that picks an encoding (currently hard-coded to latin-1) and calls
# with the correct encoding


# Generated at 2022-06-20 16:22:32.915681
# Unit test for function to_bytes
def test_to_bytes():
    # We can't just pass in unicode types for this because we want to check
    # that the function really does work on Python2
    text1 = 'fäb'.decode('utf-8')
    text2 = 'fäb'.decode('latin-1')
    text3 = 'f\xfc\xf6'.decode('latin-1')
    text4 = u'\u1234\u5678'
    text5 = u'\u1234\udcec\u5678'
    text6 = u'\U00012345'
    text7 = u'\udcfe'

    # Test with no errors
    assert to_bytes(text1) == b'f\xc3\xa4b'
    assert to_bytes(text1, 'latin-1') == 'fäb'

# Generated at 2022-06-20 16:22:43.943435
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', encoding='utf-8') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', encoding='utf-8', errors='surrogateescape') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

# Generated at 2022-06-20 16:22:51.914031
# Unit test for function container_to_text
def test_container_to_text():
    """Test the function container_to_text"""
    assert container_to_text('foo') == u'foo'
    assert container_to_text(u'foo') == u'foo'
    assert container_to_text(b'foo') == u'foo'
    assert container_to_text(u'\u2019') == u'\u2019'
    assert container_to_text(b'\xe2\x80\x99') == u'\u2019'
    assert container_to_text([b'foo', b'\xe2\x80\x99']) == [u'foo', u'\u2019']
    assert container_to_text([u'foo', u'\u2019']) == [u'foo', u'\u2019']

# Generated at 2022-06-20 16:23:01.984805
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_text

    assert to_text(u'foobar') == u'foobar'
    assert to_text(b'foobar') == u'foobar'
    assert to_text(object()) == u'<object object at 0x%x>' % id(object())
    assert to_text(object(), nonstring='empty') == u''
    assert repr(to_text(object(), nonstring='passthru')) == repr(object())
    assert to_text(u'foobar', errors='surrogate_or_replace') == u'foobar'
    assert to_text(b'foobar', errors='surrogate_or_replace') == u'foobar'
    assert to_text(u'foobar', errors='surrogate_or_strict') == u

# Generated at 2022-06-20 16:23:08.824208
# Unit test for function container_to_bytes
def test_container_to_bytes():
    def assert_conversion(input_obj, expected_output):
        output = container_to_bytes(input_obj)
        assert output == expected_output, \
            'Expected %s (%s), got %s (%s)' % (expected_output, type(expected_output), output, type(output))

    assert_conversion([], [])
    assert_conversion({"a": 1}, {"a": 1})
    assert_conversion(("a", {"b": 1}), ("a", {"b": 1}))

    # Test recursiveness
    assert_conversion([1, [2, [3, [4, [5]]]]], [1, [2, [3, [4, [5]]]]])

# Generated at 2022-06-20 16:23:18.501574
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text({'k': 'v'}) == {'k': 'v'}
    assert container_to_text({'k': 1}) == {'k': 1}
    assert container_to_text({'k1': u'v1', 'k2': u'v2'}) == {'k1': 'v1', 'k2': 'v2'}
    # list
    assert container_to_text(['v']) == ['v']
    assert container_to_text([1]) == [1]
    assert container_to_text([u'v1', u'v2']) == ['v1', 'v2']
    # tuple
    assert container_to_text(('v',)) == ('v',)
    assert container_to_text((1,)) == (1,)
    assert container

# Generated at 2022-06-20 16:23:31.449247
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(u'foo') == u'foo'
    assert container_to_text('foo') == u'foo'
    # Setting encoding to latin-1 to test surrogate_or_strict
    assert container_to_text('foo', encoding='latin-1') == u'foo'
    assert container_to_text('\x80') == u'\ufffd'
    assert container_to_text('\x80', encoding='latin-1') == u'\ufffd'
    assert container_to_text('\x80', errors='strict') == u'\ufffd'

    assert container_to_text({'a': 'b'}) == {u'a': u'b'}

# Generated at 2022-06-20 16:23:39.973236
# Unit test for function to_native
def test_to_native():
    from collections import namedtuple
    from ansible.utils.unicode import to_unicode

    d = {
        'foo': u'bar',
        'baz': 1,
        'qux': None,
    }

    Foo = namedtuple('Foo', 'bar')

    class Bar(object):
        pass

    # Test conversion to native strings
    assert to_native(u'foo\u2713') == u'foo\u2713'
    # Test that non string types are unaffected
    assert to_native(1) == 1

    # Test that objects that can't be serialized are unaffected
    assert to_native(Bar()) == Bar()
    # Test that non string types are unaffected
    assert to_native(Foo(u'foo\u2713')) == Foo(u'foo\u2713')



# Generated at 2022-06-20 16:24:26.910307
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\xe9') == '\xe9'
    assert to_native(b'\xe9') == '\xe9'
    assert to_native('foo') == 'foo'

    assert to_native(1) == '1'
    assert to_native(1.1) == '1.1'
    assert to_native(None) == 'None'
    assert to_native(Set()) == 'set()'

    # str() and repr() should not raise UnicodeErrors
    class UnicodeRaisingStr(object):
        def __str__(self):
            return '\xe9'.decode('latin-1')

        def __repr__(self):
            return '\xe9'.decode('latin-1')


# Generated at 2022-06-20 16:24:34.893701
# Unit test for function container_to_text
def test_container_to_text():
    """Unit test for function container_to_text"""
    import ansible.module_utils.basic

    assert container_to_text(text_type(u'bytes')) == text_type(u'bytes')
    assert container_to_text(binary_type(b'bytes')) == text_type(u'bytes')
    assert container_to_text(text_type(u'dict'), b'bytes', u'dict-key') == {
        text_type(u'bytes'): text_type(u'dict-key')
    }
    assert container_to_text(binary_type(b'dict'), b'bytes', u'dict-key') == {
        text_type(u'bytes'): text_type(u'dict-key')
    }


# Generated at 2022-06-20 16:24:43.389477
# Unit test for function jsonify
def test_jsonify():
    # Test with input being a string
    input_string = u"开始"
    output_bytes = jsonify(input_string)
    assert(isinstance(output_bytes, binary_type))
    assert(output_bytes == b'\"\\u5f00\\u59cb\"')

    # Test with input being a dictionary which may contain a unicode string
    input_dictionary = {
        "a": "b",
        "c": u"开始"
    }
    output_bytes = jsonify(input_dictionary)
    assert(isinstance(output_bytes, binary_type))
    assert(output_bytes == b'{"a": "b", "c": "\\u5f00\\u59cb"}')

    # Test with input being a list which may contain a unicode string
    input_list

# Generated at 2022-06-20 16:24:50.512014
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' A function to test container_to_bytes '''
    assert container_to_bytes({'a': 'b'}) == {b'a': b'b'}
    assert container_to_bytes(['a', 'b']) == [b'a', b'b']
    assert container_to_bytes(('a', 'b')) == (b'a', b'b')
    assert container_to_bytes(1) == 1
    assert container_to_bytes(Set([1, 2])) == [1, 2]



# Generated at 2022-06-20 16:24:56.399179
# Unit test for function jsonify
def test_jsonify():
    # test valid utf-8
    test_data = u'A unicode string with \xd7\xa9 characters'
    test_json = b'{"a": "A unicode string with \\u05e9 characters"}'
    assert jsonify({"a": test_data}) == test_json
    # test invalid utf-8
    test_data = 'A unicode string with \xe7\x8a characters'
    assert jsonify({"a": test_data}) == test_json



# Generated at 2022-06-20 16:25:06.339078
# Unit test for function container_to_text
def test_container_to_text():
    d1 = b'hi'
    d2 = {b"a": b"b"}
    d3 = {b"a": {b"b": b"c"}}
    d4 = [b"a", b"b"]
    d5 = [b"a", [b"b", b"c"]]
    d6 = [b"a", {b"b": b"c"}]
    d7 = [b"a", [b"b", {b"c": b"d"}]]
    d8 = {b"a": [b"b", b"c"]}
    d9 = {b"a": [b"b", {b"c": b"d"}]}

    assert isinstance(container_to_text(d1), text_type)

# Generated at 2022-06-20 16:25:12.881739
# Unit test for function to_native
def test_to_native():
    import sys
    os = sys.platform
    if os == "darwin" or os == "linux" or os == "linux2" or os == "win32":
        assert(to_native("Hello World")) == "Hello World"
    else:
        assert(to_native("Hello World")) == "Hello World"