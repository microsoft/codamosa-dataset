

# Generated at 2022-06-20 16:15:34.443175
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo\xFF') == b'foo\xFF'
    assert to_bytes(b'foo\xFF') == b'foo\xFF'
    # Supposed to have surrogate_then_replace as the default error handler, but
    # for some reason we end up with surrogateescape as the default on py34
    assert to_bytes(u'foo\uFFFD') == b'foo\xEF\xBF\xBD'
    assert to_bytes(u'foo\uFFFD', nonstring='simplerepr') == b"foo\xEF\xBF\xBD"
    assert to_bytes(u'foo\uFFFD', nonstring='passthru') == u'foo\uFFFD'

# Generated at 2022-06-20 16:15:46.234002
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == u"null"
    assert jsonify({}) == u"{}"
    assert jsonify([]) == u"[]"
    assert jsonify(True) == u"true"
    assert jsonify(False) == u"false"
    assert jsonify(u'ok') == u'"ok"'
    assert jsonify(u'\u0420\u0443\u0441') == u'"\u0420\u0443\u0441"'
    assert jsonify({"a": "b"}) == u'{"a": "b"}'
    assert jsonify({"a": "b", "c": "d"}) == u'{"a": "b", "c": "d"}'

# Generated at 2022-06-20 16:15:54.796023
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import jsonify
    in_str = u'est\xf3n'
    if PY3:
       in_type = str
    else:
       in_type = unicode
    out_type = str
    assert isinstance(in_str, in_type)
    assert not isinstance(in_str, out_type)
    out_str = jsonify(in_str)
    assert isinstance(out_str, out_type)
    assert not isinstance(out_str, in_type)

# Generated at 2022-06-20 16:16:05.535445
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test dict with bytes keys, bytes values, and unicode values
    in_dict = {b'bytes1': 'unicode1', u'unicode2': b'bytes2', 'unicode3': u'unicode3'}
    assert b'unicode1' in container_to_bytes(in_dict)
    assert b'bytes1' in container_to_bytes(in_dict)
    assert b'bytes2' in container_to_bytes(in_dict)
    assert b'unicode3' in container_to_bytes(in_dict)
    # Test dict with bytes keys and values, and a list as one of the values
    in_dict = {b'bytes1': [u'unicode1', 'unicode2'], b'bytes2': b'bytes2', 'unicode': u'unicode'}
   

# Generated at 2022-06-20 16:16:17.336848
# Unit test for function jsonify
def test_jsonify():
    import pytest
    assert jsonify({"a":"b"}) == '{"a": "b"}'
    assert jsonify(Set([1,2])) == '[1, 2]'
    assert jsonify({"a":Set([1,2])}) == '{"a": [1, 2]}'
    assert jsonify({"a":Set([1,2,u"\u20ac"])}) == '{"a": [1, 2, "\\u20ac"]}'
    assert jsonify(u'\u20ac') == '"\\u20ac"'
    assert jsonify(['\xe2\x82\xac']) == '["\\u20ac"]'
    assert jsonify(u'\xc3\xa9') == '"\\u00e9"'

# Generated at 2022-06-20 16:16:28.816289
# Unit test for function to_bytes
def test_to_bytes():
    def check_bytes(obj, errors, encoding='utf-8', nonstring='simplerepr'):
        return to_bytes(obj, encoding, errors=errors, nonstring=nonstring)

    def check_string(obj, errors, encoding='utf-8', nonstring='simplerepr'):
        # This is a check that the input can be everything but a binary string
        return to_bytes(obj, encoding, errors=errors, nonstring=nonstring)

    input_bytes = b'\xff\xfe\x41\x00\x02\x00'
    utf16_string = u'A\u0002'
    unencodable_string = u'\u0002\u0041'
    surrogate_string = u'\udc80'

    assert check_bytes(input_bytes, 'strict') == input_

# Generated at 2022-06-20 16:16:40.899213
# Unit test for function to_bytes

# Generated at 2022-06-20 16:16:51.349959
# Unit test for function to_native
def test_to_native():

    # Python 2.7
    assert to_native(b'a string') == 'a string'
    assert to_native('a string') == 'a string'
    assert to_native(1) == '1'
    assert to_native(u'\u8349') == '\xe8\x8a\x99'
    assert to_native(b'\xe8\x8a\x99') == '\xe8\x8a\x99'
    assert to_native(b'\xe8\x8a\x99', errors='surrogateescape') == u'\u8349'
    assert to_native(b'\xe8\x8a\x99', errors='surrogate_or_replace') == u'\ufffd'

    # Python 3.5

# Generated at 2022-06-20 16:16:57.722737
# Unit test for function container_to_bytes
def test_container_to_bytes():
    '''Test function container_to_bytes'''
    d_str = {"key1": "this is a test",
             "key2": ['test1', 'test2'],
             "key3": {'test1': 1, 'test2': 'two', 'test3': [1, 2],
                      'test4': (1, 2)},
             "key4": ("test1", "test2")}
    d_bytes = {"key1": b"this is a test",
               "key2": [b"test1", b"test2"],
               "key3": {b"test1": 1, b"test2": b"two", b"test3": [1, 2],
                        b"test4": (1, 2)},
               "key4": (b"test1", b"test2")}
   

# Generated at 2022-06-20 16:17:05.087734
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({'a': ['a', 'b']}) == {'a': ['a', 'b']}
    assert container_to_bytes({u'a': ['a', 'b']}) == {'a': ['a', 'b']}
    assert container_to_bytes({u'a': [u'a', 'b']}) == {'a': ['a', 'b']}
    assert container_to_bytes({u'a': [u'a', u'b']}) == {'a': ['a', 'b']}
    assert container_to_bytes({u'a': [u'a', u'b', {'a': 'b'}]}) == {'a': ['a', 'b', {'a': 'b'}]}

# Generated at 2022-06-20 16:17:19.161008
# Unit test for function to_native
def test_to_native():

    try:
        assert to_native(u'\u2713') == u'\u2713'
    except AssertionError:
        pass
    else:
        assert False, "to_native(u'\u2713') == u'\u2713'"

    try:
        assert to_native('\xe2\x9c\x93') == u'\u2713'
    except AssertionError:
        pass
    else:
        assert False, "to_native('\xe2\x9c\x93') == u'\u2713'"

    try:
        assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    except AssertionError:
        pass

# Generated at 2022-06-20 16:17:30.172830
# Unit test for function to_native
def test_to_native():
    # Tests that the right thing happens for each possible input format
    class Foo(object):
        pass

    foo = Foo()
    bar = u'bar'
    baz = b'baz'

    tests = (
        (Foo, '<class \'ansible.module_utils._text.Foo\'>'),
        (foo, '<ansible.module_utils._text.Foo object at 0x%x>' % id(foo)),
        (bar, 'bar'),
        (baz, 'baz'),
        (1, '1'),
        (1.0, '1.0'),
    )

    for inp, out in tests:
        assert to_native(inp) == out



# Generated at 2022-06-20 16:17:39.432173
# Unit test for function to_bytes
def test_to_bytes():
    # for all the error handlers that don't have a surrogate passed in do the comparison
    for errors in ('strict', 'replace', 'surrogate_or_strict', 'surrogate_or_replace'):
        result = to_bytes(u'short string', errors=errors)
        if result != b'short string':
            raise AssertionError('to_bytes fails with errors=%s' % (errors,))

    result = to_bytes(u'\uFFFD')
    # Should be the utf-8 representation of the replacement character
    if result != b'\xef\xbf\xbd':
        raise AssertionError('to_bytes did not default to utf-8 when encoding a unicode string')

    result = to_bytes(u'\uFFFD', 'latin-1')

# Generated at 2022-06-20 16:17:51.339530
# Unit test for function container_to_text
def test_container_to_text():
    # test string
    raw = b"\xe4\xb8\xad\xe6\x96\x87"
    expect = u"\u4e2d\u6587"
    # test UnicodeEncodeError
    try:
        a = to_text(raw, encoding='ascii')
        failed = False
    except UnicodeEncodeError:
        failed = True
    assert failed
    # test UnicodeDecodeError
    try:
        a = to_text(raw, encoding='ascii', errors='replace')
        failed = False
    except UnicodeDecodeError:
        failed = True
    assert not failed
    assert a == "???????"
    # test UnicodeDecodeError with surrogateescape

# Generated at 2022-06-20 16:18:01.821328
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_str1 = '\u5b5f\u5bb6' # 3 unicode bytes
    test_str2 = '\u30ef' # 2 unicode bytes
    test_str3 = '\u862d' # 1 unicode bytes
    test_str4 = '\U0001f637' # 4 unicode bytes

    test_list1 = [test_str1, test_str2, test_str3, test_str4] # [\xe5\xad\x97, \xe3\x83\xaf, \xe8\x98\xad, \xf0\x9f\x98\xb7]
    test_tuple1 = tuple(test_list1)

    test_dict1 = {}
    test_dict1[test_str1] = test_str2
    test_

# Generated at 2022-06-20 16:18:13.792820
# Unit test for function to_native
def test_to_native():
    assert b'test' == to_bytes(b'test')
    assert u'test' == to_text(b'test')
    assert b'test' == to_bytes(u'test')
    assert u'test' == to_text(u'test')
    assert b'test' == to_bytes(b'test', errors='surrogate_or_strict')
    assert u'test' == to_text(b'test', errors='surrogate_or_strict')
    assert b'test' == to_bytes(u'test', errors='surrogate_or_strict')
    assert u'test' == to_text(u'test', errors='surrogate_or_strict')
    assert b'test' == to_bytes(b'test', errors='surrogate_or_replace')
   

# Generated at 2022-06-20 16:18:23.010181
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(u'foo') == to_bytes(u'foo')
    assert container_to_bytes(u'f\xf6\xf6') == to_bytes(u'f\xf6\xf6')
    assert container_to_bytes(u'f\xf6\xf6', errors='surrogate_or_replace') == to_bytes(u'f\xf6\xf6', errors='surrogate_or_replace')
    assert container_to_bytes(u'f\xf6\xf6', errors='surrogate_or_strict') == to_bytes(u'f\xf6\xf6', errors='surrogate_or_strict')

# Generated at 2022-06-20 16:18:35.851218
# Unit test for function container_to_text
def test_container_to_text():
    assert "foo" == to_native(container_to_text(b'foo'))
    assert {"foo": "bar"} == to_native(container_to_text({b'foo': b'bar'}))
    assert ["foo", "bar"] == to_native(container_to_text([b'foo', b'bar']))
    assert ("foo", "bar") == to_native(container_to_text((b'foo', b'bar')))
    assert "foo" == to_native(container_to_text(u'foo'))
    assert {"foo": "bar"} == to_native(container_to_text({u'foo': u'bar'}))
    assert ["foo", "bar"] == to_native(container_to_text([u'foo', u'bar']))
    assert ("foo", "bar")

# Generated at 2022-06-20 16:18:47.450785
# Unit test for function to_bytes
def test_to_bytes():
    # pylint: disable=missing-docstring
    assert isinstance(to_bytes(b'string'), binary_type)
    assert isinstance(to_bytes('string'), binary_type)
    assert isinstance(to_bytes('string', errors='surrogate_then_replace'), binary_type)
    assert isinstance(to_bytes('string', errors='surrogate_or_replace'), binary_type)
    assert isinstance(to_bytes('string', errors='surrogate_or_strict'), binary_type)
    assert isinstance(to_bytes('string', errors='ignore'), binary_type)

    assert isinstance(to_bytes(u'\u1234'), binary_type)
    assert isinstance(to_bytes(u'\u1234', errors='replace'), binary_type)

# Generated at 2022-06-20 16:18:59.228759
# Unit test for function container_to_text
def test_container_to_text():
    """Unit test for function container_to_text"""
    # check dict
    dict_a = {'a': u'text', 1: 'number', 'c': [u's', 1, 'numbers']}
    dict_a_str = {'a': u'text', '1': 'number', 'c': [u's', '1', 'numbers']}
    assert (container_to_text(dict_a)) == (dict_a_str)

    # check list
    list_a = [u'text', 1, 'number', [u's', 1, 'numbers']]
    list_a_str = [u'text', '1', 'number', [u's', '1', 'numbers']]
    assert (container_to_text(list_a)) == (list_a_str)

    # check tuple

# Generated at 2022-06-20 16:19:21.176793
# Unit test for function container_to_text
def test_container_to_text():

    # Test if all string are converted to text type
    d = {1: [b"a", b"b"], 2: b"c"}
    d = container_to_text(d)
    for v in d.values():
        assert isinstance(v, text_type)

    # Test if non-string is not converted
    d = {1: [b"a", b"b"], 2: "c"}
    d = container_to_text(d)
    assert not isinstance(d[2], text_type)

    # Test if non-string is not converted
    d = {1: [b"a", b"b"], 2: 2}
    d = container_to_text(d)
    assert not isinstance(d[2], text_type)

    # Test if all string are converted to text type

# Generated at 2022-06-20 16:19:29.806915
# Unit test for function container_to_bytes

# Generated at 2022-06-20 16:19:36.312002
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' Test with Python 2 and Python 3 strings '''
    d = {
        u'key1': [u'value1'],
        u'key2': u'value2',
        u'key3': {
            u'key4': u'value4'
        }
    }
    d = container_to_bytes(d)
    assert isinstance(d, dict)
    for key in d:
        assert isinstance(key, binary_type)
        if isinstance(d[key], list):
            for item in d[key]:
                assert isinstance(item, binary_type)
        elif isinstance(d[key], dict):
            for subkey in d[key]:
                assert isinstance(subkey, binary_type)
                assert isinstance(d[key][subkey], binary_type)
       

# Generated at 2022-06-20 16:19:42.689922
# Unit test for function container_to_text
def test_container_to_text():
    # Container types
    data = {u'a': 1, u'b': u'c'}
    assert isinstance(container_to_text(data), dict)
    assert (isinstance(container_to_text(data)['a'], text_type))
    assert (isinstance(container_to_text(data)['b'], text_type))

    data = [u'a', u'b', u'c']
    assert isinstance(container_to_text(data), list)
    for elem in container_to_text(data):
        assert (isinstance(elem, text_type))

    data = (u'a', u'b', u'c')
    assert isinstance(container_to_text(data), tuple)

# Generated at 2022-06-20 16:19:53.475591
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes('foo') == b'foo'
    assert container_to_bytes('foo', encoding='latin-1') == b'foo'
    assert container_to_bytes(u'\xe9', encoding='latin-1') == u'\xe9'.encode('latin-1')
    assert container_to_bytes(u'\u30c6\u30b9\u30c8', encoding='utf-8') == u'\u30c6\u30b9\u30c8'.encode('utf-8')
    assert container_to_bytes(u'\u30c6\u30b9\u30c8', encoding='latin-1') == u'\ufffd\ufffd\ufffd'.encode('latin-1')

# Generated at 2022-06-20 16:20:02.418155
# Unit test for function to_native
def test_to_native():
    # Test empty input
    assert to_native(None) == ""
    assert to_native("") == ""
    assert to_native(b"") == ""
    # Test for expected string conversion
    assert to_native("Test") == "Test"
    assert to_native(b"Test") == "Test"
    assert to_native(123) == "123"
    assert to_native(123.1) == "123.1"
    # Test for expected unicode string conversion
    assert to_native(u"Test") == "Test"
    try:
        unicode
    except NameError:
        pass
    else:
        assert to_native(unicode("Test")) == "Test"
    # Test exception handling
    class BadStr(object):
        def __str__(self):
            raise Exception("Failed")
   

# Generated at 2022-06-20 16:20:03.972447
# Unit test for function container_to_bytes
def test_container_to_bytes():
    data = {u'bo\xc3\xb6te': u'test'}
    converted_data = {'bo\xcc\x83te': 'test'}
    assert container_to_bytes(data) == converted_data



# Generated at 2022-06-20 16:20:15.956604
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo\u1234') == b'foo\xe1\x88\xb4'

    # Test surrogateescape
    try:
        codecs.lookup_error('surrogateescape')
    except LookupError:
        pass
    else:
        # Test that surrogateescape is the default
        assert to_bytes(u'foo\udc80') == b'foo\x80'
        assert to_bytes(u'foo\udc80', errors='surrogate_or_replace') == b'foo\x80'
        assert to_bytes(u'foo\udc80', errors='surrogate_or_strict') == b'foo\x80'

    # Test surrogate_then_replace

# Generated at 2022-06-20 16:20:26.681679
# Unit test for function to_bytes
def test_to_bytes():
    if PY3:
        class Foo(object):
            def __str__(self):
                return 'foo'
        foo = Foo()
        bar = Foo()
        bar.__str__ = lambda s: 'b\xe1r'
        baz = Foo()
        baz.__str__ = lambda s: 'bzz'.encode('latin-1')

        assert to_bytes(foo) == b'foo'
        assert to_bytes(foo, nonstring='strict') == b'foo'
        assert to_bytes(foo, nonstring='passthru') is foo
        assert to_bytes(foo, nonstring='empty') == b''
        assert to_bytes(bar) == 'b\xe1r'.encode('utf-8')

# Generated at 2022-06-20 16:20:39.373903
# Unit test for function jsonify
def test_jsonify():
    data = {
        u"test": [u"\uff22", "test"],
        b"testb": [u"\uff22", "test"],
        u"test2": [u"\U0001d11e", "test"],
        b"test2b": [u"\U0001d11e", "test"],
        u"test3": [u"\ud834\udd1e", "test"],
        b"test3b": [u"\ud834\udd1e", "test"],
    }
    result = jsonify(data)
    assert isinstance(result, text_type)
    assert json.loads(result) == data
    result = jsonify(None)
    assert isinstance(result, text_type)
    assert json.loads(result) == None



# Generated at 2022-06-20 16:20:54.436526
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'x': u'\xe9'}) == '{"x": "\\u00e9"}'



# Generated at 2022-06-20 16:21:04.476580
# Unit test for function jsonify
def test_jsonify():
    """Return a json string of the dict given in argument."""
    utf8_string = "\xe2\x82\xac"
    latin1_string = utf8_string.encode('latin-1')
    assert jsonify(latin1_string) == '"\u20ac"'
    assert jsonify(utf8_string) == '"\u20ac"'

    # dict
    data = {'a': utf8_string}
    assert jsonify(data) == '{"a": "\u20ac"}'
    data = {'a': latin1_string}
    assert jsonify(data) == '{"a": "\u20ac"}'

    # list
    data = [utf8_string]
    assert jsonify(data) == '["\u20ac"]'

# Generated at 2022-06-20 16:21:10.813375
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text({"a": b"a"}) == {"a": u"a"}
    assert container_to_text({"a": u"a"}) == {"a": u"a"}
    assert container_to_text({"a": b"\x00\x01\x02"}) == {"a": u"\u0000\u0001\u0002"}
    assert container_to_text([b"\x00\x01\x02"]) == [u"\u0000\u0001\u0002"]

# Generated at 2022-06-20 16:21:20.593598
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # dict
    d = dict(foo='FOO', bar='BAR')
    assert container_to_bytes(d) == dict(foo=b'FOO', bar=b'BAR')

    # nested dict
    nd = dict(foo=dict(foo1='FOO1', foo2='FOO2'), bar='BAR')
    assert container_to_bytes(nd) == dict(foo=dict(foo1=b'FOO1', foo2=b'FOO2'), bar=b'BAR')

    # list
    l = ['FOO', 'BAR']
    assert container_to_bytes(l) == [b'FOO', b'BAR']

    # nested list
    nl = [['FOO1', 'FOO2'], 'BAR']

# Generated at 2022-06-20 16:21:29.921396
# Unit test for function container_to_text
def test_container_to_text():
    test_dict = {}
    test_dict['k1'] = 'root_string'
    test_dict['k2'] = 'root_string'.encode('utf-8')
    sub_dict = {}
    sub_dict['sk1'] = 'sub_string'
    sub_dict['sk2'] = 'sub_string'.encode('utf-8')
    sub_dict['sk3'] = {}
    sub_dict['sk3']['ssk1'] = 'sub_sub_string'
    sub_dict['sk3']['ssk2'] = 'sub_sub_string'.encode('utf-8')
    test_dict['k3'] = sub_dict

    assert container_to_text(test_dict) == test_dict


# Generated at 2022-06-20 16:21:37.391433
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text({'a': u'a'}) == {u'a': u'a'}
    assert container_to_text({b'a': u'a'}) == {u'a': u'a'}
    assert container_to_text({b'a':  u'\xe4'}) == {u'a': u'\xe4'}
    assert container_to_text({u'a': 'a'}) == {u'a': u'a'}
    assert container_to_text({u'a': b'a'}) == {u'a': u'a'}


# Generated at 2022-06-20 16:21:41.524433
# Unit test for function container_to_text
def test_container_to_text():
    encoding = 'utf-8'
    errors = 'surrogate_or_strict'
    result = container_to_text({"foo": "\xe9", "bar": [1, 2, 3]})
    assert result == {"foo": u"\xe9", "bar": [1, 2, 3]}
    result = container_to_text({"foo": "\xe9", "bar": [1, 2, 3]}, encoding=encoding, errors=errors)
    assert result == {"foo": u"\xe9", "bar": [1, 2, 3]}



# Generated at 2022-06-20 16:21:51.206840
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(
        {u'a': u'1', u'b': u'2'}
    ) == {u'a': u'1', u'b': u'2'}
    assert container_to_text(
        {'a': '1', 'b': '2'}
    ) == {u'a': u'1', u'b': u'2'}
    assert container_to_text(
        ['1', '2', {'a': '1'}]
    ) == [u'1', u'2', {u'a': u'1'}]
    assert container_to_text(
        ('1', '2', {'a': '1'})
    ) == (u'1', u'2', {u'a': u'1'})


# Generated at 2022-06-20 16:22:00.199004
# Unit test for function container_to_text
def test_container_to_text():
    # Test dict
    #   input dict contains ascii, unicode and non-ascii characters
    #   expected result is the same as the input dict
    in_dict = {"ascii": "value",
               "unicode": u"\u00e4\u00f6",
               "non-ascii": b"\xc3\xa4\xc3\xb6"}
    re_dict = container_to_text(in_dict)
    for k, v in iteritems(re_dict):
        expected_value = in_dict[k]
        assert expected_value == re_dict[k]

    # Test list
    #   input list contains string, unicode and non-ascii bytes
    #   expected result is a text list

# Generated at 2022-06-20 16:22:06.986511
# Unit test for function to_native
def test_to_native():
    """
    A basic unit test for the to_native function
    """

    class Obj:
        def __str__(self):
            return "str"

        def __repr__(self):
            return "repr"

    string = 'Text String'
    native = to_native(string)
    assert type(native) == str, "String wasn't converted to a native string"
    assert native == string, "Native version of string is not correct"

    obj = Obj()
    native = to_native(obj)
    assert type(native) == str, "Object wasn't converted to a native string"
    assert native == obj.__repr__(), "Native version of object is not correct"

    json_obj = to_json(obj)
    json_native = to_native(json_obj)

# Generated at 2022-06-20 16:22:21.905408
# Unit test for function container_to_bytes
def test_container_to_bytes():
    foo = dict(a=dict(b=['asdf', 'jkl;'], bar=dict(baz='qwerty')))
    container_to_bytes(foo)

# Generated at 2022-06-20 16:22:28.650572
# Unit test for function container_to_bytes
def test_container_to_bytes():
    data = {
        u'username': u'admin',
        u'password': u'foobarbaz',
        u'extra': ['extra_stuff'],
        u'port': 22
    }
    result = container_to_bytes(data)
    assert isinstance(result['username'], binary_type)
    assert isinstance(result['password'], binary_type)
    assert isinstance(result['port'], binary_type)
    assert isinstance(result['extra'][0], binary_type)
    assert isinstance(result, dict)
    assert isinstance(result['extra'], list)



# Generated at 2022-06-20 16:22:35.983334
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_dict = dict(a=(1,2), b={1:2, 3:'abc'}, c=[1,2,3,u"你好"])
    test_bytes = dict(a=(1,2), b={1:2, 3:b'abc'}, c=[1,2,3,b'\xe4\xbd\xa0\xe5\xa5\xbd'])
    assert container_to_bytes(test_dict) == test_bytes



# Generated at 2022-06-20 16:22:47.053464
# Unit test for function container_to_text
def test_container_to_text():
    d_str = {'a':1,'b':2}
    assert container_to_text(d_str) == d_str
    d_bytes = {b'a':1,b'b':2}
    assert container_to_text(d_bytes) == {'a':1,'b':2}
    d_mixed = {b'a':1,'b':2}
    assert container_to_text(d_mixed) == {'a':1,'b':2}
    d_nested = {'a':1,'b':[{'x':b'y'}]}
    assert container_to_text(d_nested) == {'a':1,'b':[{'x':'y'}]}

# Generated at 2022-06-20 16:22:55.636748
# Unit test for function container_to_bytes
def test_container_to_bytes():
    res = container_to_bytes([{u'high': u'\xe4\xf6\xfc'}, [u'\xe4\xf6\xfc']])
    assert isinstance(res, list)
    assert isinstance(res[0], dict)
    assert isinstance(res[0][b'high'], bytes)
    assert isinstance(res[1], list)
    assert isinstance(res[1][0], bytes)



# Generated at 2022-06-20 16:23:04.263572
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    import json
    import copy


# Generated at 2022-06-20 16:23:16.168597
# Unit test for function to_native
def test_to_native():

    print('***Test for to_native***')
    a = to_native(b'f\xc3\xb1\xc3\xb2', errors='surrogate_or_strict')
    print(a)
    print('-'*50)
    b = to_native(b'f\xc3\xb1\xc3\xb2', errors='surrogate_or_replace')
    print(b)
    print('-'*50)
    c = to_native(b'f\xc3\xb1\xc3\xb2', errors='surrogate_then_replace')
    print(c)
    print('-'*50)
    d = to_native('f\xf1\xf2', errors='surrogate_or_strict')
    print(d)
    print('-'*50)
   

# Generated at 2022-06-20 16:23:24.437832
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test list
    result = container_to_bytes([1, 2, u'a'])
    assert result == [1, 2, b'a']
    # Test dictionary
    result = container_to_bytes({1: 2, u'a': u'b'})
    assert result == {1: 2, b'a': b'b'}
    # Test text
    result = container_to_bytes(u'hello')
    assert result == b'hello'
    # Test mixed list
    result = container_to_bytes([1, 2, u'a', {u'hello': u'goodbye', 1: u'2'}])
    assert result == [1, 2, b'a', {b'hello': b'goodbye', 1: b'2'}]
    # Test mixed dictionary
    result = container_to

# Generated at 2022-06-20 16:23:35.056174
# Unit test for function to_native

# Generated at 2022-06-20 16:23:47.383059
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.common._collections_compat import Set
    from ansible.module_utils.six import text_type, binary_type
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils import six
    from ansible.module_utils.six.moves import zip

    data = {
        "some-text": u"Text with unicode: \u2018",
        "set": Set(["a", "b", "a"]),
        "float": 3.1415,
        "int": 42,
        "bool": True,
        "none": None,
    }
    dthandler = lambda obj: obj.isoformat() if isinstance(obj, datetime.datetime) else None

# Generated at 2022-06-20 16:24:15.707081
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes("abc") == b"abc"
    assert to_bytes(u"abc") == b"abc"
    assert to_bytes(u'\u2018') == u'\u2018'.encode('utf-8')
    assert to_bytes(u'\udce2') == u'\udce2'.encode('surrogateescape')
    assert to_bytes(u'\udce2', errors='replace') == u'\ufffd'.encode('utf-8')
    # test that we can use surrogate_escape if it exists
    try:
        codecs.lookup_error('surrogateescape')
        has_surrogateescape = True
    except LookupError:
        has_surrogateescape = False

# Generated at 2022-06-20 16:24:25.654140
# Unit test for function container_to_text
def test_container_to_text():
    # Test encoding/decoding a dict
    s = {'a': b'bytes_value', 'b': u'unicode_value'}
    u = container_to_text(s)
    assert type(u['a']) == text_type
    assert type(u['b']) == text_type

    # Test encoding/decoding a list
    s = [b'bytes_value', u'unicode_value']
    u = container_to_text(s)
    assert type(u[0]) == text_type
    assert type(u[1]) == text_type

    # Test encoding/decoding a tuple
    s = (b'bytes_value', u'unicode_value')
    u = container_to_text(s)
    assert type(u[0]) == text_type

# Generated at 2022-06-20 16:24:31.374864
# Unit test for function jsonify
def test_jsonify():
    def assert_equal(expected, data, **kwargs):
        assert jsonify(data, **kwargs) == expected

    assert_equal('"foo"', u'foo')
    assert_equal('"foo"', b'foo')
    assert_equal('"foo"', u"foo")
    assert_equal('"foo"', b"foo")

    assert_equal(r'"\xe2\x98\x83"', u"\u2603")
    assert_equal(r'"\xe2\x98\x83"', b"\xe2\x98\x83")
    assert_equal(r'"\xc3\xa2\xc2\x98\xc2\x83"', u"\u2603")

# Generated at 2022-06-20 16:24:40.880992
# Unit test for function to_native
def test_to_native():
    # Ansible requires all strings to be native so that modules can just
    # operate on them and don't need to care about unicode/bytes handling
    # One exception is the special value None which can be passed through
    # when a module doesn't want to return anything.

    assert to_native(u'spam', errors='strict') == 'spam'
    assert to_native(u'\u1234') == '\u1234'
    # byte strings are decoded
    assert to_native(b'\xc3\xa9') == '\xe9'
    if PY3:
        # Non-UTF-8-byte-strings are not decoded.  Instead they're encoded
        # using surrogateescape on Python3
        assert to_native(b'\xe9', encoding='ascii') == '\udce9'


# Generated at 2022-06-20 16:24:47.044955
# Unit test for function to_bytes
def test_to_bytes():
    # pylint: disable=redefined-outer-name
    # pylint: disable=too-many-branches,too-many-statements,too-many-locals,too-many-nested-blocks
    def check(obj, encoding='utf-8', errors=None, nonstring='simplerepr', expected=None):
        actual = to_bytes(obj, encoding=encoding, errors=errors, nonstring=nonstring)
        if actual != expected:
            print('to_bytes(%s, encoding=%s, errors=%s, nonstring=%s)' % (obj, encoding, errors, nonstring))
            raise AssertionError('Expected %s, got %s' % (expected, actual))

    # Non-ascii, non-utf8 safe bytes

# Generated at 2022-06-20 16:24:56.395327
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'abc') == b'abc'
    assert to_bytes(b'abc', 'utf-8', errors='surrogate_or_replace') == b'abc'
    assert to_bytes(u'abc') == b'abc'
    assert to_bytes(u'abc', 'utf-8', errors='surrogate_or_replace') == b'abc'
    assert to_bytes(u'\uFFFD') == b'?'
    assert to_bytes(u'\uFFFD', 'utf-8', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\udc80') == b'\x80'

# Generated at 2022-06-20 16:25:02.556320
# Unit test for function container_to_text
def test_container_to_text():
    input_list = [
        {
            u'list1': [u'list1-1', u'list1-2', 'list1-3'],
            u'list2': [u'list2-1', u'list2-2', 'list2-3']
        }
    ]

    output_list = [
        {
            u'list1': [u'list1-1', u'list1-2', u'list1-3'],
            u'list2': [u'list2-1', u'list2-2', u'list2-3']
        }
    ]
    assert container_to_text(input_list) == output_list

# Generated at 2022-06-20 16:25:14.663062
# Unit test for function to_bytes
def test_to_bytes():
    # Test with a byte string
    assert to_bytes('a') == b'a'
    assert to_bytes(b'a') == b'a'
    assert to_bytes(b'\xe9') == b'\xe9'

    # Test with a text string
    assert to_bytes('\xe9') == b'\xc3\xa9'
    assert to_bytes('\xe9', encoding='latin-1') == b'\xe9'
    assert to_bytes(u'\u304a') == b'\xe3\x81\x8a'
    assert to_bytes(u'\u304a', encoding='euc-jp') == b'\xa4\xa2'

    # Test with nonstring objects
    # Note: that the results are different for py3 and py2 because of how
   