

# Generated at 2022-06-20 16:15:31.318022
# Unit test for function to_native

# Generated at 2022-06-20 16:15:36.186133
# Unit test for function container_to_text
def test_container_to_text():
    data = {'a': [b"\xe9", b'\xf1'], 'b': b'\xe9\xf1'}
    data_expected = {'a': [u"\xe9", u'\xf1'], 'b': u'\xe9\xf1'}
    assert container_to_text(data, encoding='utf-8', errors='surrogate_or_strict') == data_expected

# vim: set expandtab ts=4 sw=4 ai :

# Generated at 2022-06-20 16:15:48.400350
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u"foo") == "foo"
    if PY3:
        assert to_bytes('foo') == 'foo'
    else:
        assert to_bytes('foo') == 'foo'

    assert to_bytes(u'foo\u2222bar') == 'foo\xE2\x88\xA2bar'
    assert to_bytes(u'foo\u2222bar', 'latin-1') == 'foo?bar'
    assert to_bytes(u'foo\u2222bar', 'latin-1', 'strict') == 'foo?bar'
    assert to_bytes(u'foo\u2222bar', 'ascii', 'strict') == b'foo\xe2\x88\xa2bar'  # PY3

# Generated at 2022-06-20 16:15:59.685366
# Unit test for function container_to_text
def test_container_to_text():
    def assertEqual(a, b):
        if a != b:
            print("Not Equal")
    str1 = b"\xE6\xB5\x8B\xE8\xAF\x95"
    str1_to_unicode = u"\u6d4b\u8bd5"
    assertEqual(container_to_text(str1), str1_to_unicode)

    d1 = {b"\xE6\xB5\x8B": 1, b"\xE8\xAF\x95": 2}
    d1_unicode = {"\u6d4b": 1, "\u8bd5": 2}
    assertEqual(container_to_text(d1), d1_unicode)


# Generated at 2022-06-20 16:16:08.921153
# Unit test for function container_to_text
def test_container_to_text():
    # Test data
    data_list = [u'\xe8\xaf\x91'.encode('utf-8'), u'\xe8\xaf\x91'.encode('utf-8')]
    data_dict = {'b': u'\xe8\xaf\x91'.encode('utf-8'), 'a': {u'\xe8\xaf\x91'.encode('utf-8'): u'\xe8\xaf\x91'.encode('utf-8')}}  # noqa

    # Test list
    assert isinstance(container_to_text(data_list), list)
    for i in container_to_text(data_list):
        assert isinstance(i, text_type)

    # Test dict

# Generated at 2022-06-20 16:16:19.255345
# Unit test for function to_bytes
def test_to_bytes():
    _test_to_bytes(text_type, '')
    _test_to_bytes(text_type, '䔠䔡䔢䔣䔤䔥䔦䔧䔨䔩䔪')
    _test_to_bytes(text_type, b'\xe4\x94\xa0\xe4\x94\xa1\xe4\x94\xa2\xe4\x94\xa3\xe4\x94\xa4\xe4\x94\xa5\xe4\x94\xa6\xe4\x94\xa7\xe4\x94\xa8\xe4\x94\xa9\xe4\x94\xaa')

# Generated at 2022-06-20 16:16:29.813647
# Unit test for function jsonify
def test_jsonify():
    b_str = b'\xe9'
    u_str = u'\u20ac'
    text_str = u_str.encode('utf-8')
    latin1_str = u_str.encode('latin-1')


# Generated at 2022-06-20 16:16:37.279318
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # test if output is byte string
    assert isinstance(container_to_bytes({'foo': 'bar'}), dict)
    # test if values are converted to bytes
    assert isinstance(container_to_bytes({'foo': 'bar'})['foo'], binary_type)
    # test if 'latin-1' encoding works and not just 'utf-8'
    assert isinstance(container_to_bytes({u'Æ': 'bar'}, encoding='latin-1')[u'Æ'], binary_type)



# Generated at 2022-06-20 16:16:48.694012
# Unit test for function to_native
def test_to_native():
    assert to_native(b'\x80') == u'\uFFFD'
    assert to_native(b'\x80', errors='surrogate_or_strict') == u'\x80'
    assert to_native(b'\x80', errors='surrogate_or_replace') == u'\ufffd'
    def test_to_bytes():
        # Test a pure ascii string
        assert to_bytes('Foo') == b'Foo'
        # Test a pure unicode string
        assert to_bytes(u'\u0141u\u0107') == b'\xc5\x81u\xc4\x87'
        # Test a unicode string with surrogates in it

# Generated at 2022-06-20 16:17:00.657017
# Unit test for function to_bytes
def test_to_bytes():
    # Tests borrowed from test_to_native()
    ustr = u'\u043f\u0440\u0438\u0432\u0435\u0442'
    bstr = ustr.encode('utf-8')

    assert to_bytes(ustr) == bstr
    assert to_bytes(ustr, nonstring='simplerepr') == bstr
    assert to_bytes(ustr, nonstring='empty') == b''
    assert to_bytes(bstr, nonstring='passthru') == bstr
    assert to_bytes(bstr, nonstring='empty') == b''
    assert to_bytes(bstr) == bstr
    assert to_bytes(bstr, nonstring='simplerepr') == bstr
    assert to_bytes(bstr, nonstring='passthru') == b

# Generated at 2022-06-20 16:17:16.713061
# Unit test for function jsonify
def test_jsonify():
    class AClass(object):
        def __init__(self, my_text):
            self.my_text = my_text
        def __str__(self):
            return self.my_text


# Generated at 2022-06-20 16:17:23.657195
# Unit test for function container_to_text
def test_container_to_text():
    struct = {
        'key1': b'value\x80',
        'key2': [b'value1\x80', b'value2\x80'],
        'key3': {
            'key4': [b'value1\x80'],
            'key5': b'value\x80',
        },
        'key6': (b'value1\x80', b'value2\x80'),
    }

    # When converting to text type, bytes would be converted to a suitable
    # unicode surrogate character. As we don't want to validate the
    # conversion to text, we just make sure that the type of the
    # converted structure is the same as struct type and ensure the
    # structure is converted to text.
    struct_converted = container_to_text(struct)

# Generated at 2022-06-20 16:17:34.635833
# Unit test for function container_to_text
def test_container_to_text():
    def check(input, expected_output):
        encoded_input = container_to_bytes(input)
        assert encoded_input == expected_output
        assert container_to_text(encoded_input) == input

    check('foo', b'foo')
    check(['foo', 'bar'], [b'foo', b'bar'])
    check((u'foo', u'bar'), (b'foo', b'bar'))
    check({'foo': 'bar'}, {b'foo': b'bar'})
    check({'foo': u'bar'}, {b'foo': b'bar'})
    check({'foo': {'bar': 'baz'}}, {b'foo': {b'bar': b'baz'}})

# Generated at 2022-06-20 16:17:38.900920
# Unit test for function jsonify
def test_jsonify():
    data = dict(a=dict(b=u'\xe9'), c=u'\xe9', d=u'\u2603')
    new_data = jsonify(data)
    assert isinstance(new_data, text_type)
    assert data == json.loads(new_data)


# Generated at 2022-06-20 16:17:50.386657
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_text

    # Unique representation to check if the container has been changed or not.
    unique_repr = 'ansiballz-container'

    def unique_container(data):
        return data

    unique_container.__repr__ = lambda x: unique_repr


# Generated at 2022-06-20 16:18:01.092249
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(b'foo\xc3\xa9') == u'fooé'
    assert to_native(b'foo\xc3\xa9'.decode('utf-8')) == u'fooé'
    assert to_native(b'foo\xc3\xa9'.decode('latin-1')) == u'fooÃ©'
    assert to_native(1) == '1'
    assert to_native(None) == 'None'
    assert to_native(Exception('foo')) == 'Exception: foo'
    assert to_native(Exception('foo\xc3\xa9')) == u'Exception: fooé'

# Generated at 2022-06-20 16:18:12.589676
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(dict(a=b('0'))) == {u'a': u'0'}
    assert container_to_text(dict(a=[b('0'), b('1')])) == {u'a': [u'0', u'1']}
    assert container_to_text(dict(a=[dict(b=b('0'))])) == {u'a': [{u'b': u'0'}]}
    assert container_to_text(tuple([b('0'), b('1')])) == (u'0', u'1')
    assert container_to_text([b('0'), b('1')]) == [u'0', u'1']
    assert container_to_text(b('0')) == u'0'

# Generated at 2022-06-20 16:18:22.173955
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(b'foo') == b'foo'
    assert container_to_bytes(u'foo') == b'foo'
    assert container_to_bytes({u'foo': u'bar', 'spam': b'eggs'}) == {b'foo': b'bar', b'spam': b'eggs'}
    assert container_to_bytes([u'foo', b'bar', {u'foo': u'bar', 'spam': b'eggs', }]) == [b'foo', b'bar', {b'foo': b'bar', b'spam': b'eggs'}]

# Generated at 2022-06-20 16:18:35.651238
# Unit test for function jsonify
def test_jsonify():
    def test():
        mydata = {
            "key": "string",
            "list": [{"key1": 1}, {"key2": 2}],
            "dict": {"key1": 1, "key2": 2},
            "set": set([1, 2, 3]),
            "datetime": datetime.datetime.utcnow(),
        }
        myjson = jsonify(mydata)
        mydata2 = json.loads(myjson)
        assert mydata == mydata2
        assert type(mydata['set']) is set
        assert type(mydata2['set']) is list
        assert type(mydata['datetime']) is datetime.datetime
        assert type(mydata2['datetime']) is unicode
        print("test_jsonify OK")
    test()



# Generated at 2022-06-20 16:18:40.298718
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_list = ['abcd', '123']
    test_dict = dict(a={'a_b': 'xyz', 'a_c': '123', 'a_d': '123'})
    result_dict = dict(a=dict(a_b='xyz',a_c='123',a_d='123'))
    assert result_dict == container_to_bytes(test_dict)
    assert test_list == container_to_bytes(test_list)


# Generated at 2022-06-20 16:18:55.445963
# Unit test for function to_bytes
def test_to_bytes():
    def check_to_bytes(obj, *args, **kwargs):
        if PY3 and isinstance(obj, binary_type):
            return obj
        else:
            return to_bytes(obj, *args, **kwargs)
    assert not isinstance(check_to_bytes('hi'), binary_type)  # Not using Python3

    # Simple string
    assert check_to_bytes('hi\xe9') == b'hi\xc3\xa9'
    assert check_to_bytes('hi\xe9', errors='replace') == b'hi?'
    assert check_to_bytes('hi\xe9', errors='strict') == b'hi\xc3\xa9'
    assert check_to_bytes('hi\xe9', encoding='latin-1') == b'hi\xe9'
    assert check_

# Generated at 2022-06-20 16:19:04.174042
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert isinstance(container_to_bytes({'key1':'value1'}), dict)
    assert isinstance(container_to_bytes({'key1':'value1'})['key1'], bytes)
    assert container_to_bytes({'key1':'value1'}) == {b'key1':b'value1'}
    assert isinstance(container_to_bytes(['value1','value2']), list)
    assert container_to_bytes(['value1','value2']) == [b'value1', b'value2']
    assert isinstance(container_to_bytes(('value1','value2')), tuple)
    assert container_to_bytes(('value1','value2')) == (b'value1', b'value2')


# Generated at 2022-06-20 16:19:11.328221
# Unit test for function container_to_text
def test_container_to_text():
    """Function ``container_to_text`` is tested by executing the following code. """
    d = {b'key1': b'value1',
         b'key2': 1,
         b'key3': {b'key3.1': b'value3.1',
                   b'key3.2': b'value3.2',
                   b'key3.3': 3},
         b'key4': [b'value4.1',
                   b'value4.2',
                   b'value4.3',
                   4],
         b'key5': (b'value5.1',
                   b'value5.2',
                   b'value5.3',
                   5),
         b'key6': bytes(range(10))}

# Generated at 2022-06-20 16:19:22.484923
# Unit test for function container_to_bytes
def test_container_to_bytes():
    from ansible.compat.tests import unittest


# Generated at 2022-06-20 16:19:31.283942
# Unit test for function to_native
def test_to_native():
    #
    # to_bytes
    #
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(1) == b'1'

    try:
        to_bytes(object(), strict=True)
    except TypeError as e:
        assert u'obj must be a string type' in to_text(e)
    else:
        raise AssertionError('to_bytes(object()) did not raise TypeError')

    assert to_bytes(object()) == b'<object object at 0x%x>' % id(object())
    assert to_bytes(u'føø') == b'f\xc3\xb8\xc3\xb8'

    # non-ascii text with no encoding specified

# Generated at 2022-06-20 16:19:39.185936
# Unit test for function to_native
def test_to_native():
    import os
    import sys
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_native, to_text, to_bytes

    def check(obj, expect):
        native = to_native(obj)
        text = to_text(obj)
        _bytes = to_bytes(obj)
        if not isinstance(expect, binary_type):
            expect_text = to_text(expect)
            assert text == expect_text, ("%r != %r" % (text, expect_text))
        # TODO: trying to figure out how to write a test for this
        # if not isinstance(expect, text_type):
        #     expect_

# Generated at 2022-06-20 16:19:41.578105
# Unit test for function to_native
def test_to_native():
    '''
    Test that to_native() always converts a string to Unicode in PY2
    '''
    assert isinstance(to_native('foo'), text_type)
    assert isinstance(to_native(u'foo'), text_type)
    assert isinstance(to_native(1), text_type)



# Generated at 2022-06-20 16:19:52.991578
# Unit test for function to_bytes
def test_to_bytes():
    """
Tests for function ``to_bytes``
    """
    assert to_bytes('', 'ascii') == b''
    assert to_bytes(u'фыва', 'utf-8') == b'\xd1\x84\xd1\x8b\xd0\xb2\xd0\xb0'
    assert to_bytes('\xFF', 'ascii') == b'\xFF'
    assert to_bytes(1) == b'1'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='ignore') == b''

# Generated at 2022-06-20 16:20:01.957874
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(dict(a=1,b=2,c=3)) == {'a': 1, 'b': 2, 'c': 3}
    assert container_to_text(dict(a=1,b=2,c=3), encoding='latin-1') == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-20 16:20:14.467983
# Unit test for function to_bytes

# Generated at 2022-06-20 16:20:25.212641
# Unit test for function to_native
def test_to_native():
    '''
    Make sure we can convert to native strings
    '''
    assert isinstance(to_native(u'hello'), text_type)  # unicode -> unicode
    assert isinstance(to_native('hello'), text_type)  # str -> unicode
    assert isinstance(to_native(b'hello'), text_type)  # byte -> unicode



# Generated at 2022-06-20 16:20:35.827350
# Unit test for function container_to_bytes
def test_container_to_bytes():
    data = {
        'foo': 'bar',
        'boo': True,
        'integer': 1,
        'floater': 1.1,
        'bytestr': b'bytes',
        'unicodestr': u'unicode',
        'list': [u'unicode', b'bytes'],
        'dict': {u'unicode': u'unicode', b'bytes': b'bytes'},
        'tuple': (u'unicode', b'bytes'),
        'set': set([u'unicode', b'bytes']),
        'badset': set([1,2,3]),
    }

# Generated at 2022-06-20 16:20:44.355331
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {
        'a': ['Ä', 'Ã', 'Å'],
        'c': {
            'd': '☺'
        }
    }
    b = container_to_bytes(d)
    assert isinstance(b, dict)
    assert isinstance(b['a'], list)
    assert isinstance(b['a'][0], binary_type)
    assert isinstance(b['a'][1], binary_type)
    assert isinstance(b['a'][2], binary_type)
    assert isinstance(b['c'], dict)
    assert isinstance(b['c']['d'], binary_type)


# Generated at 2022-06-20 16:20:55.203499
# Unit test for function container_to_text
def test_container_to_text():
    # container_to_text checks for text_type, but does not check for basestring
    # so this is an invalid call
    with pytest.raises(UnicodeError):
        container_to_text(b'bytes')

    # text items are left unchanged
    assert u'unicode' == container_to_text(u'unicode')

    # ints are returned unchanged
    assert 1 == container_to_text(1)

    # non-containers are returned unchanged
    assert object() == container_to_text(object())

    # change text encoded in utf-8 to unicode
    utf8_str = u'\u2713'.encode('utf-8')
    assert u'\u2713' == container_to_text(utf8_str)

    # change text encoded in utf-8 to

# Generated at 2022-06-20 16:21:03.785985
# Unit test for function to_bytes
def test_to_bytes():
    # Make sure that a unicode string becomes a str/bytes under both py2 and py3
    test = 'hi there'
    assert isinstance(to_bytes(test), bytes)

    # Bytes should get returned back
    test = b'hi there'
    assert isinstance(to_bytes(test), bytes)
    assert to_bytes(test) == test

    # Unicode surrogate pairs should get encoded properly
    # The first pair is ud800 which should get encoded to \ud800 when
    # surrogate_then_replace is the error handler
    assert to_bytes(u'\ud800\udc00', errors='surrogate_then_replace') == b'\xed\xa0\x80\xed\xb0\x80'
    # The second pair is ud800 udc01 which should get encoded to \udc01 when

# Generated at 2022-06-20 16:21:07.733576
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == b'{"a": 1, "b": 2}'
    assert jsonify(dict(a=text_type('\N{SNOWMAN}'))) == b'{"a": "\u2603"}'
    assert jsonify(dict(a=text_type('\N{SNOWMAN}'), b=1)) == b'{"a": "\u2603", "b": 1}'
    assert jsonify(dict(a=text_type('\N{SNOWMAN}'), b=1, c=text_type('\N{SNOWMAN}'))) == b'{"a": "\u2603", "b": 1, "c": "\u2603"}'



# Generated at 2022-06-20 16:21:17.664249
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_dict = {u'a': u'a', [u'b']: u'b'}
    ansible_dict = container_to_bytes(test_dict)
    assert isinstance(ansible_dict, dict)
    assert isinstance(ansible_dict[u'a'], binary_type)
    assert isinstance(ansible_dict[[u'b']], binary_type)

    test_list_of_dicts = [{u'a': u'a'}, {u'b': u'b'}]
    ansible_list_of_dicts = container_to_bytes(test_list_of_dicts)
    assert isinstance(ansible_list_of_dicts, list)
    assert isinstance(ansible_list_of_dicts[0], dict)

# Generated at 2022-06-20 16:21:24.612662
# Unit test for function to_bytes
def test_to_bytes():
    import sys
    if sys.version_info < (3,):
        # Python2 doesn't have an explicit byte string type so we
        # use the same type for both byte and text strings
        assert isinstance(to_bytes(u'foo'), str)
        assert isinstance(to_bytes(b'foo'), str)
        assert isinstance(to_bytes(u'foo', nonstring='passthru'), unicode)
        assert isinstance(to_bytes('foo', nonstring='passthru'), str)
        assert to_bytes(u'\xc3\xbc', encoding='latin-1', errors='surrogate_or_replace') == '\xfc'

# Generated at 2022-06-20 16:21:35.721381
# Unit test for function to_bytes

# Generated at 2022-06-20 16:21:43.287019
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # 1st test, just a string
    my_dict = {u'foo': u'bar'}
    my_dict_bytes = container_to_bytes(my_dict, encoding='utf-8', errors='surrogate_or_strict')
    assert isinstance(my_dict_bytes, dict)
    for value in iteritems(my_dict_bytes):
        assert isinstance(value, tuple)
        for v in value:
            assert isinstance(v, binary_type)
    return True

# Generated at 2022-06-20 16:22:01.526532
# Unit test for function container_to_text
def test_container_to_text():
    dict_1 = {'a': 'a', 'b': 'b', 'c': 'c'}
    dict_2 = {b'a': b'a', b'b': b'b', b'c': b'c'}
    dict_3 = {u'\xa3': u'\xa3', u'\xb3': u'\xb3', u'\xc3': u'\xc3'}
    dict_4 = {b'\xa3': b'\xa3', b'\xb3': b'\xb3', b'\xc3': b'\xc3'}
    assert isinstance(container_to_text(dict_1, encoding='utf-8', errors='surrogate_or_strict'), dict)

# Generated at 2022-06-20 16:22:07.638619
# Unit test for function to_bytes
def test_to_bytes():
    """
    to_bytes() should convert to byte string correctly.
    """
    from ansible.module_utils.six import text_type

    # If we pass a byte string, it should come back unchanged (no decoding)
    assert to_bytes(b'foo') == b'foo'
    # If we pass a text string, it should come back as a byte string
    assert to_bytes(u'foo') == b'foo'
    # If we pass a non-string that has a __bytes__ method, that should be called
    class Foo(object):
        def __bytes__(self):
            return b'foo'
    assert to_bytes(Foo()) == b'foo'
    # If we pass a non-string with no __bytes__ method, this should
    # return the text string equivalent (using __str__ if it exists)


# Generated at 2022-06-20 16:22:16.078718
# Unit test for function to_bytes

# Generated at 2022-06-20 16:22:24.893772
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(u"foo") == u"foo"
    assert container_to_text(b"foo") == u"foo"
    assert container_to_text([u"foo"]) == [u"foo"]
    assert container_to_text([b"foo"]) == [u"foo"]
    assert container_to_text({u"foo": u"bar"}) == {u"foo": u"bar"}
    assert container_to_text({u"foo": b"bar"}) == {u"foo": u"bar"}
    assert container_to_text({b"foo": b"bar"}) == {u"foo": u"bar"}
    assert container_to_text((u"foo", b"bar")) == (u"foo", u"bar")

# Generated at 2022-06-20 16:22:35.803861
# Unit test for function to_native
def test_to_native():
    assert to_native(text_type(u'\u00F6'), errors='surrogate_or_strict') == u'\u00F6'
    # python2 and python3 different when decoding bytes with non-ascii characters.
    if PY3:
        assert to_native(b'\xc3\xb6') == u'\u00F6'
    else:
        assert to_native(b'\xc3\xb6') == u'\xc3\xb6'
    assert to_native(text_type(u'\u00F6')) == u'\u00F6'
    assert to_native(text_type(u'foo')) == u'foo'
    # test conversion of byte string to text string

# Generated at 2022-06-20 16:22:46.888909
# Unit test for function to_native
def test_to_native():
    class NonStr(object):
        pass

    assert to_bytes(None) == b'None'
    assert to_bytes(NonStr()) == b'<ansible.module_utils._text.NonStr object at '

    assert to_bytes(123) == b'123'
    assert to_bytes(u'hi') == b'hi'
    assert to_bytes(u'¡hola!') == b'\xc2\xa1hola!'
    assert to_bytes(b'\xc2\xa1hola!') == b'\xc2\xa1hola!'
    assert to_bytes(b'\xc2\xa1hola!', errors='surrogate_or_strict') == b'\xc2\xa1hola!'

# Generated at 2022-06-20 16:22:55.851407
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text([b'1', b'2']) == [u'1', u'2']
    assert container_to_text([1, 2]) == [1, 2]
    assert container_to_text({b'a': b'1', b'b': b'2'}) == {u'a': u'1', u'b': u'2'}
    assert container_to_text({'a': 1, 'b': 2}) == {u'a': 1, u'b': 2}
    assert container_to_text((b'1', b'2')) == (u'1', u'2')
    assert container_to_text((1, 2)) == (1, 2)

    assert container_to_text([1, 2], encoding='latin-1') == [1, 2]



# Generated at 2022-06-20 16:23:05.234441
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(MY_TEXT_LIST) == MY_BYTE_LIST
    assert container_to_bytes(MY_TEXT_LIST, errors='surrogate_or_strict') == MY_BYTE_LIST

    try:
        container_to_bytes(MY_TEXT_LIST, errors='surrogate_then_replace')
    except UnicodeError:
        pass
    else:
        pytest.fail("surrogate_then_replace error handler should raise exception with surrogates")

    assert container_to_bytes(MY_TEXT_TUPLE) == MY_BYTE_TUPLE
    assert container_to_bytes(MY_TEXT_TUPLE[:1]) == MY_BYTE_TUPLE[:1]
    assert container_to_bytes(MY_TEXT_DICT) == MY_BYTE_

# Generated at 2022-06-20 16:23:16.889356
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test dict with only bytes
    d = dict(one=1, two=2)
    assert container_to_bytes(d) == d

    # Test dict with only text_type
    d = dict(one=u'a', two=u'b')
    assert container_to_bytes(d) == dict(one='a', two='b')
    assert container_to_bytes(d, nonstring='empty') == dict(one=b'', two=b'')

    # Test dict with mixed types
    d = dict(one=1, two=u'b')
    assert container_to_bytes(d) == dict(one=1, two='b')
    assert container_to_bytes(d, nonstring='empty') == dict(one=b'', two=b'')

    # Test nested dict (with unicode)

# Generated at 2022-06-20 16:23:29.542314
# Unit test for function to_bytes
def test_to_bytes():
    utf8_with_surrogates = codecs.decode(b'\xf0\x9d\x84\x9e', 'utf-16-be')

    # No surrogates -> encode with utf-8 -> no decoding
    assert to_bytes(u'h\xe9llo') == b'h\xc3\xa9llo'
    assert to_bytes(u'€') == b'\xe2\x82\xac'

    # No surrogates -> encode with other encoding -> traceback
    if PY3:
        assert to_bytes(u'€', encoding='latin-1') == b'\x80'
    else:
        try:
            to_bytes(u'€', encoding='latin-1')
        except UnicodeEncodeError:
            pass

# Generated at 2022-06-20 16:24:02.313506
# Unit test for function container_to_bytes
def test_container_to_bytes():
    input_data = {"key": u"value"}
    expected_data = {"key": b"value"}
    output_data = container_to_bytes(input_data)
    assert(expected_data == output_data)

    input_data = [u"value1", u"value2"]
    expected_data = [b"value1", b"value2"]
    output_data = container_to_bytes(input_data)
    assert(expected_data == output_data)

    input_data = (u"value1", u"value2")
    expected_data = (b"value1", b"value2")
    output_data = container_to_bytes(input_data)
    assert(expected_data == output_data)


# Generated at 2022-06-20 16:24:09.147285
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(None) == None
    assert container_to_bytes(1) == 1
    assert container_to_bytes(['a']) == ['a']
    assert container_to_bytes((b'a',)) == (b'a',)
    assert container_to_bytes('abc') == b'abc'
    assert container_to_bytes({'a': u'b'}) == {b'a': b'b'}


# Generated at 2022-06-20 16:24:16.881518
# Unit test for function to_native
def test_to_native():
    '''
    Basic test cases for to_native
    '''
    assert to_native(u'foo') == u'foo'
    assert to_native(u'é') == u'é'
    assert to_native(u'\udcaa') == u'\udcaa'
    assert to_native(u'\uDCAA') == u'\udcaa'
    assert to_native(u'\x00') == u'\x00'
    assert to_native(u'\udcaa\udcaa') == u'\udcaa\udcaa'
    assert to_native(u'\udcaa\x00') == u'\udcaa\x00'
    assert to_native(b'foo') == u'foo'

# Generated at 2022-06-20 16:24:21.892551
# Unit test for function jsonify
def test_jsonify():
    input = '{"a": "foo", "b": "bar"}'
    blob = eval(input)
    expected = json.dumps(blob, default=_json_encode_fallback)
    assert jsonify(blob) == expected
    blob = eval(input.decode('utf-8'))
    assert jsonify(blob) == expected



# Generated at 2022-06-20 16:24:23.751522
# Unit test for function jsonify
def test_jsonify():
    # import json
    data = [{"a":1},{"b":2}]
    print(json.dumps(data))
    print(jsonify(data))
# test_jsonify()


# Generated at 2022-06-20 16:24:35.486885
# Unit test for function container_to_text
def test_container_to_text():
  a_string = u'\u2019'
  a_dict = {u'a': 1, a_string: 2}
  a_list = [1, a_string]
  a_tuple = (a_string,)
  a_set = set([a_string])
  # {u'a': 1, u'\u2019': 2}
  assert container_to_text(a_dict) == {'a': 1, '\u2019': 2}
  # [1, u'\u2019']
  assert container_to_text(a_list) == [1, '\u2019']
  # (u'\u2019',)
  assert container_to_text(a_tuple) == ('\u2019',)
  # TypeError: set([u'\u2019']) is not JSON serializable


# Generated at 2022-06-20 16:24:42.861478
# Unit test for function container_to_text
def test_container_to_text():
    """Unit test for function container_to_text"""
    print("Testing function container_to_text")
    data = {
        "str": u"str",
        "str_bytes": b"str_bytes",
        "str_unicode_escape": u"str_unicode_escape\u2603",
        "str_bytes_unicode_escape": b"str_bytes_unicode_escape\xe2\x98\x83"
        }

    data_result_utf8 = {
        "str": u"str",
        "str_bytes": u"str_bytes",
        "str_unicode_escape": u"str_unicode_escape\u2603",
        "str_bytes_unicode_escape": u"str_bytes_unicode_escape\u2603"
        }
    data_result

# Generated at 2022-06-20 16:24:52.836352
# Unit test for function jsonify
def test_jsonify():
    my_data = dict(
        name="foobar",
        nums=[1, 2, 3],
        dict=dict(a='b', c='d'),
        set=set(['foo', 'bar']),
        utf8='\u2713',  # CHECK MARK
        bytes=b'\xe2\x9c\x93',  # CHECK MARK in utf-8
    )
    my_json = jsonify(my_data)
    assert my_json == '{"bytes": "\\u2713", "dict": {"a": "b", "c": "d"}, "name": "foobar", "nums": [1, 2, 3], "set": ["bar", "foo"], "utf8": "\\u2713"}'


# Generated at 2022-06-20 16:25:02.905063
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(u'foo\u2026', errors='surrogate_then_replace') == u'foo\ufffd'
    assert to_native(b'foo\xe2\x80\xa6\xc3\xbf', errors='surrogate_then_replace') == u'foo\ufffd\ufffd'
    assert to_native(b'\xc3\xbf', errors='surrogate_then_replace') == u'\ufffd'
    assert to_native(b'foo\xc3\xbf', errors='surrogate_then_replace') == u'foo\ufffd'


# Generated at 2022-06-20 16:25:15.317969
# Unit test for function to_native
def test_to_native():
    """
    Tests to_native() converts a text string to the native string.

    When native string is byte-string (Python 2; PY2)
        input_string: unicode string
        output_string: byte string

    When native string is text-string (Python 3; PY3)
        input_string: unicode string
        output_string: unicode string

    :return:
        Nothing, just assert result
    """
    str_unicode = to_unicode(u'\u6c49\u5b57')
    str_ascii = to_unicode('ASCII')

    assert isinstance(to_native(str_unicode), native_string_types)
    assert isinstance(to_native(str_ascii), native_string_types)
