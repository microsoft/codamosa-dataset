

# Generated at 2022-06-20 16:15:38.687163
# Unit test for function jsonify
def test_jsonify():
    try:
        foo = jsonify({u'first_name': u'吴', u'last_name': u'晟'}, ensure_ascii=True)
        assert foo == '{"first_name": "\\u5434", "last_name": "\\u644a"}'
        foo = jsonify({u'first_name': u'吴', u'last_name': u'晟'}, ensure_ascii=False)
        assert foo == '{"first_name": "吴", "last_name": "晟"}'
    except:
        pass


# Generated at 2022-06-20 16:15:50.830311
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes('string') == 'string'
    assert container_to_bytes({'test': 'string'}) == {'test': 'string'}
    assert container_to_bytes(['string']) == ['string']
    assert container_to_bytes(('string',)) == ('string',)

    assert container_to_bytes(u'test') == b'test'
    assert container_to_bytes({u'test': u'string'}) == {b'test': b'string'}
    assert container_to_bytes([u'string']) == [b'string']
    assert container_to_bytes((u'string',)) == (b'string',)


# Generated at 2022-06-20 16:16:02.566261
# Unit test for function to_native
def test_to_native():
    assert 'Hello World!' == to_text(u'Hello World!', 'utf-8')
    assert u'Hello World!' == to_text(u'Hello World!')
    try:
        to_text(u'Hello World!', 'ascii')
        assert False, 'Expected UnicodeDecodeError'
    except UnicodeDecodeError:
        pass
    assert u'Hello World!' == to_text(u'Hello World!', 'ascii', 'surrogateescape')

    if PY3:
        assert u'\uFFFD' == to_text(b'\xff', 'ascii', 'surrogateescape')
    else:
        assert u'\udcff' == to_text(b'\xff', 'ascii', 'surrogateescape')

    assert 'Hello World!' == to_

# Generated at 2022-06-20 16:16:05.892370
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils import basic
    assert jsonify(dict(a=1, b=basic.unicode_wrap(u'foo'))) == '{"a": 1, "b": "foo"}'



# Generated at 2022-06-20 16:16:17.573222
# Unit test for function jsonify
def test_jsonify():
    import json
    """
    Function to test the function jsonify.
    Unfortunately, the function jsonify does not exist in Python 2.6, so this
    function is only used for testing.
    """
    # Test 1:
    # Test with a simple dictionary.
    d = {'a': 'b', 'c': ['d', 'e']}
    assert jsonify(d) == json.dumps(d)

    # Test 2:
    # Test with an object in the dictionary
    class JsonTest:
        a = ''
        b = ''

        def __init__(self, a, b):
            self.a = a
            self.b = b


# Generated at 2022-06-20 16:16:27.249555
# Unit test for function to_native
def test_to_native():
    assert to_native(1) == 1
    assert to_native(TextIOWrapper(BytesIO(b'test'))) == 'test'
    assert to_native(None) is None
    assert to_native(b'test') == 'test'
    assert to_native(u'test') == u'test'
    assert to_native(u'\xa3', 'ascii', 'strict') == u'\xa3'
    assert to_native({'a': 1}) == {'a': 1}
    assert to_native([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-20 16:16:39.583381
# Unit test for function container_to_text
def test_container_to_text():
    d1 = {u'abc': [{u'def': u'xxx'}, {u'xyz': u'more'}] }
    assert container_to_text(d1) == {u'abc': [{u'def': u'xxx'}, {u'xyz': u'more'}] }

    d2 = {'abc': [{'def': 'xxx'}, {'xyz': 'more'}] }
    assert container_to_text(d2) == {u'abc': [{u'def': u'xxx'}, {u'xyz': u'more'}] }

    d3 = {'abc': [{u'def': 'xxx'}, {u'xyz': 'more'}] }

# Generated at 2022-06-20 16:16:50.030725
# Unit test for function to_native
def test_to_native():
    import sys

    # Test basics (bytes vs text)
    assert to_native(u"test test") == u"test test"
    assert to_native("test test") == u"test test"
    assert to_native(1) == "1"

    # Test sys.stdout/err value (assume we're running on a TTY.  If it's not, then this
    # test case is skipped)
    if hasattr(sys.stdout, 'fileno'):
        sys.stdout.fileno()
        assert to_native("test test", errors='surrogate_or_strict') == u"test test"
    else:
        assert to_native("test test", errors='surrogate_or_strict') == u

# Generated at 2022-06-20 16:16:55.492820
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({u'foo': u'\u2713'}) == {b'foo': '\xe2\x9c\x93'}
    assert container_to_bytes([u'foo', {u'foo': u'\u2713'}]) == [b'foo', {b'foo': '\xe2\x9c\x93'}]
    assert container_to_bytes((u'foo', {u'foo': u'\u2713'})) == [b'foo', {b'foo': '\xe2\x9c\x93'}]


# Generated at 2022-06-20 16:17:04.631916
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({u'foo': u'bar'}) == u'{"foo": "bar"}'
    assert jsonify({u'foo': [u'bar', u'baz']}) == u'{"foo": ["bar", "baz"]}'
    assert jsonify({u'foo': {u'bar': u'baz'}}) == u'{"foo": {"bar": "baz"}}'
    assert jsonify({u'foo': u'\xe9'}) == u'{"foo": "\xc3\xa9"}'
    assert jsonify({u'foo': u'\u2603'}) == u'{"foo": "\xe2\x98\x83"}'
    assert jsonify({u'foo': u'\ud800'}) == u'{"foo": "\ud800"}'

# Generated at 2022-06-20 16:17:15.882174
# Unit test for function jsonify
def test_jsonify():
    data = {
        'name': 'TestName',
        'set': set(['a', 'b']),
        'now': datetime.datetime.now(),
    }
    # ensure that we have no unicode data
    json_data = jsonify(data)
    loaded_data = json.loads(json_data)

    assert loaded_data['name'] == 'TestName'
    assert isinstance(loaded_data['set'], list)
    assert isinstance(loaded_data['now'], str)



# Generated at 2022-06-20 16:17:27.337578
# Unit test for function to_bytes
def test_to_bytes():
    '''
    Test function to_bytes
    '''
    # 'test_string', b'', b'strings', b'^\x03\x04', b'\xff\xfe\xfd\xfc', b'\x00\x01\xff\xfe\xfd\xfc'
    string_values = [to_bytes('test_string'), to_bytes(''), to_bytes('strings'), to_bytes('^\x03\x04'),
                    to_bytes('\xff\xfe\xfd\xfc'), to_bytes('\x00\x01\xff\xfe\xfd\xfc')]
    # b'strings', [u'test_string', u'strings'], (u'string1', u'string2'), {u'string1': 1, u's

# Generated at 2022-06-20 16:17:36.120603
# Unit test for function to_native
def test_to_native():
    # Strings
    assert to_native(b'foo') == 'foo'
    assert to_native('foo') == 'foo'

    # None
    assert to_native(None) is None

    # Integers
    assert to_native(0) == 0
    assert to_native(100) == 100

    # List
    assert to_native([]) == []
    assert to_native([1, 2, 3]) == [1, 2, 3]
    assert to_native([b"a", 2, 3]) == ["a", 2, 3]

    # Dictionary
    assert to_native({}) == {}
    assert to_native({1: 2}) == {1: 2}
    assert to_native({1: 2, b"3": 4}) == {1: 2, "3": 4}


# Generated at 2022-06-20 16:17:47.583706
# Unit test for function container_to_bytes
def test_container_to_bytes():
    #Create a dict with unicode value
    unidict = {'a':1, u'b': u'unicode'}
    #Create a dict within dict with unicode value
    unidict2 = {'a':1, u'b': u'unicode', 'c': {u'd': u'unicode2'}}
    #Create a list of dict
    listdict = [unidict, unidict2]
    #Create a tuple of dict
    tupledict = (unidict, unidict2)

    #Test the function, then test the result with isinstance
    utf8test = container_to_bytes(unidict)
    assert isinstance(utf8test['b'],binary_type)
    utf8test = container_to_bytes(unidict2)

# Generated at 2022-06-20 16:18:00.062054
# Unit test for function jsonify
def test_jsonify():
    data_dict1 = {'ansible': {'version': '2.7.0'}, 'x': u'a\xf1'}
    assert jsonify(data_dict1) == '{"ansible": {"version": "2.7.0"}, "x": "a\\u00f1"}'

    data_dict2 = {'ansible': {'version': '2.7.0'}, 'x': 'a\xe9'}
    assert jsonify(data_dict2) == '{"ansible": {"version": "2.7.0"}, "x": "a\\u00e9"}'

    data_dict3 = {'ansible': {'version': '2.7.0'}, 'x': 'a\xe9'}

# Generated at 2022-06-20 16:18:11.146713
# Unit test for function container_to_bytes

# Generated at 2022-06-20 16:18:15.770368
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"key 1": ["value 1", "value 2"]}) == '{"key 1": ["value 1", "value 2"]}'
    assert jsonify({"key 1": "value 1"}) == '{"key 1": "value 1"}'
    assert jsonify({"key 1": 1}) == '{"key 1": 1}'



# Generated at 2022-06-20 16:18:24.213094
# Unit test for function to_bytes
def test_to_bytes():
    # This is the lower order test.  We're testing that to_bytes is calling
    # functions correctly
    utf8_b = u'\u1234'.encode('utf-8')
    utf8_t = u'\u1234'
    latin1_b = utf8_b.decode('utf-8').encode('latin-1')
    try:
        utf8_b.decode('latin-1')
    except UnicodeDecodeError:
        latin1_t = u'\ufffd'
    else:
        latin1_t = u'\u1234'.decode('utf-8')

    # We're going to call a lot of functions that will throw UnicodeEncodeErrors
    # Catch them so that we know when this function throws so we can test that

# Generated at 2022-06-20 16:18:36.679961
# Unit test for function container_to_bytes
def test_container_to_bytes():
    class Foo(object):
        def __init__(self, value):
            self.value = value
        def __repr__(self):
            return "Foo(%d)" % self.value

    foo = Foo(42)
    encoded = container_to_bytes(foo)
    assert isinstance(encoded, Foo)

    weird_dict = {foo: foo, 'foo': [foo]}
    encoded = container_to_bytes(weird_dict)
    assert encoded['foo'][0] is encoded[encoded['foo'][0]]

    weird_tuple = (foo, 'foo', [1, 2, foo])
    encoded = container_to_bytes(weird_tuple)
    assert encoded[2][2] is encoded[0]


# Generated at 2022-06-20 16:18:47.951150
# Unit test for function container_to_text
def test_container_to_text():
    test_dict = {'a': 1, 'b': 2, 'c': u'hmm', 'd': [1, 2, 3],
                 'e': [u'hmm', u'hmm'], u'不要': u'不要'}
    assert test_dict == container_to_text(test_dict)
    test_dict = {'a': 1, 'b': 2, 'c': u'hmm', 'd': [1, 2, 3],
                 'e': [u'hmm', u'hmm'], u'不要': u'不要'}
    assert test_dict == container_to_text(test_dict)

# Generated at 2022-06-20 16:19:01.678142
# Unit test for function to_bytes
def test_to_bytes():
    # We have enough of a test in to_text.  If to_text works, to_bytes should
    # also work
    pass
# end unit test



# Generated at 2022-06-20 16:19:09.866696
# Unit test for function jsonify
def test_jsonify():
    ndata = {'a': 'a', 'b': 'b'}
    assert json.loads(jsonify(ndata)) == ndata

    try:
        # Python 2.6 does not support ensure_ascii
        ndata = {'a': 'a\u0024', 'b': 'b'}
        assert jsonify(ndata, ensure_ascii=False) == '{"a": "a\\u0024", "b": "b"}'
    except TypeError:
        pass

    ndata = {'a': 'a', 'b': 'b'}
    assert json.loads(jsonify(ndata, sort_keys=True)) == ndata

    class C(object):
        pass

    ndata = {'a': 'a', 'b': C()}

# Generated at 2022-06-20 16:19:17.630454
# Unit test for function container_to_text
def test_container_to_text():
    b = b"Hello"
    d = {"key1": b, "key2": [b, {"key3": b}, [b, [b]]], "key4": (b, b)}
    assert (container_to_text(d, encoding='utf-8', errors='surrogate_or_strict') ==
            {"key1": "Hello", "key2": ["Hello", {"key3": "Hello"}, ["Hello", ["Hello"]]], "key4": ("Hello", "Hello")})


# Generated at 2022-06-20 16:19:25.561164
# Unit test for function container_to_bytes
def test_container_to_bytes():
    given = {
        u'bytes': b'string',
        u'string': u'unicode',
        u'unicode': u'\u1111',
        u'surrogates': u'\udcff\udc00',
        u'nested': {
            u'string': u'unicode',
            u'unicode': u'\u1111',
            u'bytes': b'bytes',
            u'nested': {
                u'string': u'unicode',
                u'bytes': b'bytes',
            }
        },
        u'list': [
            u'unicode',
            b'bytes',
        ],
        u'tuple': (
            u'unicode',
            b'bytes',
        ),
    }


# Generated at 2022-06-20 16:19:34.121380
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({u"\u8fd9\u662f\u4e00\u4e2a\u4e2d\u6587": u"\u8fd9\u662f\u6e05\u695a\u7684\u6d4b\u8bd5"}) == '{"\u8fd9\u662f\u4e00\u4e2a\u4e2d\u6587": "\u8fd9\u662f\u6e05\u695a\u7684\u6d4b\u8bd5"}'
    assert jsonify({"this is an ascii": "this is a clear test"}) == '{"this is an ascii": "this is a clear test"}'

# Generated at 2022-06-20 16:19:41.339216
# Unit test for function to_bytes
def test_to_bytes():
    b_obj = to_bytes(b'foo')
    utf8_obj = to_bytes(u'foo')
    utf16_obj = to_bytes(u'foo', encoding='utf-16')

    assert b_obj == b'foo'
    assert utf8_obj == b'foo'
    assert utf16_obj.startswith(b'\xff\xfe')

    surrogate_obj = to_bytes(u'\U0010FFFF')
    assert surrogate_obj == b'\xed\xbf\xbf'

    surrogate_obj_surrogateescape = to_bytes(u'\U0010FFFF', errors='surrogateescape')
    assert surrogate_obj_surrogateescape == b'\xed\xbf\xbf'


# Generated at 2022-06-20 16:19:52.992683
# Unit test for function jsonify
def test_jsonify():
    # jsonify(...) converts all text objects to unicode.
    # On python2, the returned string is encoded in utf-8.
    # On python3, the return value is a unicode string.
    assert isinstance(jsonify(), text_type)
    # jsonify(...) converts all text objects in the data to unicode.
    # On python2, the returned string is encoded in utf-8.
    # On python3, the return value is a unicode string.
    assert isinstance(jsonify({'a': 'a'}), text_type)
    # jsonify(...) converts all text objects in the data to unicode.
    # On python2, the returned string is encoded in utf-8.
    # On python3, the return value is a unicode string.

# Generated at 2022-06-20 16:20:01.962204
# Unit test for function container_to_bytes
def test_container_to_bytes():
    from collections import OrderedDict

    class Struct:
        def __init__(self, **entries):
            self.__dict__.update(entries)

    # In this unit test, we will test with Narrow Python build.
    # So we don't need to test for surrogates.
    # The surrogates are tested in test_to_bytes.
    # Also we will test only with utf-8 and latin-1
    # So that the unit test doesn't take too long.
    # For more detailed test, check test_to_bytes.

    # Input

# Generated at 2022-06-20 16:20:03.685996
# Unit test for function jsonify
def test_jsonify():
    # test for json.dumps problem with py27
    mydict = {"test_jsonify": "test_jsonify_value"}
    res = jsonify(mydict, sort_keys=True)
    res = json.loads(res)
    assert res == mydict



# Generated at 2022-06-20 16:20:08.008750
# Unit test for function to_native
def test_to_native():
    b = b'bytes'
    assert to_native(b) == b
    assert isinstance(to_native(b), str)
    if PY3:
        # Python3 already has a text type
        assert to_native('text') == 'text'
        assert isinstance(to_native('text'), str)
    else:
        # Only Python2 doesn't already have a text type
        assert to_native(u'text') == 'text'
        assert isinstance(to_native(u'text'), str)

    # If a nonstring input is given, use the default str() conversion
    assert to_native(10) == '10'
    assert isinstance(to_native(10), str)
    assert to_native(b'bytes') == 'bytes'
    assert isinstance(to_native(b'bytes'), str)

# Generated at 2022-06-20 16:20:20.294277
# Unit test for function jsonify
def test_jsonify():
    assert jsonify([1, 2, 3, 4, 5]) == '''[1, 2, 3, 4, 5]'''
    assert jsonify({'a': 1, 'b': 2, 'c': 3}) == '''{"a": 1, "c": 3, "b": 2}'''



# Generated at 2022-06-20 16:20:25.607075
# Unit test for function container_to_text
def test_container_to_text():
    d = dict(a=dict(a=1, b=[u'a', dict(a=u'\u2019', b=[u'a'])]))
    d2 = container_to_text(d)
    assert isinstance(d2[u'a'][u'a'], int)
    assert isinstance(d2[u'a'][u'b'][0], text_type)
    assert isinstance(d2[u'a'][u'b'][1][u'a'], text_type)
    assert isinstance(d2[u'a'][u'b'][1][u'b'][0], text_type)
    d3 = container_to_text(d, encoding='latin-1')

# Generated at 2022-06-20 16:20:35.547390
# Unit test for function jsonify
def test_jsonify():
    # Check if function correctly encode to json
    # data with latin-1 encoding
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify([{'a': 'b'}]) == '[{"a": "b"}]'
    assert jsonify({'a': ['b']}) == '{"a": ["b"]}'
    # Check if function correctly encode to json data with utf-8 encoding
    assert jsonify({'a': u'b'}) == '{"a": "b"}'
    assert jsonify([{'a': u'b'}]) == '[{"a": "b"}]'
    assert jsonify({'a': [u'b']}) == '{"a": ["b"]}'



# Generated at 2022-06-20 16:20:44.199782
# Unit test for function container_to_text
def test_container_to_text():
    assert True is container_to_text(True)
    assert u'test' == container_to_text(to_bytes(u'test'))
    assert [u'test', u'test2'] == container_to_text([u'test', to_bytes(u'test2')])
    assert (u'test', u'test2') == container_to_text((u'test', to_bytes(u'test2')))
    assert {u'test': u'test2'} == container_to_text({u'test': to_bytes(u'test2')})
    assert {u'test': (u'test2', u'test3')} == container_to_text({u'test': (to_bytes(u'test2'), u'test3')})

# Generated at 2022-06-20 16:20:55.084879
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {
        'first': 'ascii',
        'second': ['ascii', 'utf-8:漢', 'utf-8:Κόσμε'],
        'third': ('ascii', 'utf-8:漢', ('utf-8:漢', 'utf-8:Κόσμε')),
        'fourth': {'key': ['ascii', 'utf-8:漢', 'utf-8:Κόσμε']}
    }

# Generated at 2022-06-20 16:21:03.704810
# Unit test for function to_bytes
def test_to_bytes():
    # This test needs to test that we can go from a ascii and unicode string
    # and get a utf8 byte string out.  It also needs to test that we can give
    # it a nonstring and get a utf8 byte string out (or an error)
    #
    # It also needs to test the different error handlers
    assert to_bytes('hello') == b'hello'
    assert to_bytes(b'hello') == b'hello'
    assert to_bytes(u'\xe2\x9c\x93') == b'\xe2\x9c\x93'
    assert to_bytes(b'\xe2\x9c\x93') == b'\xe2\x9c\x93'

    assert to_bytes('h\xe2\x9c\x93llo') == b

# Generated at 2022-06-20 16:21:09.749871
# Unit test for function to_bytes

# Generated at 2022-06-20 16:21:14.160245
# Unit test for function container_to_text
def test_container_to_text():
    b_string = u"\xff".encode('latin-1')
    assert container_to_text(b_string, errors='surrogate_or_strict') == "?"
    assert container_to_text(b_string, errors='surrogate_then_replace') == u"\ufffd"



# Generated at 2022-06-20 16:21:22.106259
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    assert(to_native('string') == 'string')
    if PY3:
        assert(to_native(b'bytes') == 'bytes')
    else:
        assert(to_native(b'bytes') == b'bytes')
        assert(to_native(u'unicode') == u'unicode')


if PY3:
    # in python3, json only takes text which is unicode in python3
    def to_json(obj):
        return json.dumps(obj, ensure_ascii=False)
else:
    def to_json(obj):
        return json.dumps(obj)



# Generated at 2022-06-20 16:21:32.658670
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'

    assert to_native(b'foo') == u'foo'
    # FIXME
    #assert to_native(u'\xf6') == u'\xf6'
    #assert to_native(b'\xc3\xb6') == u'\xf6'

    #assert to_native(None) == u'None'
    #assert to_native(3) == u'3'
    #assert to_native(2.5) == u'2.5'

    #assert to_native(dict(a=1, b=2)) == u"{'a': 1, 'b': 2}"
    #assert to_native(Set([1, 2, 3])) == u'[1, 2, 3]'
    #assert to_native(tuple

# Generated at 2022-06-20 16:21:49.396060
# Unit test for function to_native
def test_to_native():
    assert to_native('a') == 'a'
    assert to_native(1) == 1
    assert to_native(1.1) == 1.1
    assert to_native(True) == True
    assert to_native(b'a') == u'a'
    assert to_native(bytearray(b'a')) == 'a'
    assert to_native(u'a') == 'a'
    assert to_native({'a':1}) == {'a':1}
    assert to_native(['a',1]) == ['a',1]



# Generated at 2022-06-20 16:21:59.045235
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Dictionaries
    assert(container_to_bytes({'foo': u'bar'}) == {b'foo': b'bar'})
    assert(container_to_bytes({u'foo': 'bar'}) == {b'foo': b'bar'})
    assert(container_to_bytes({u'foo': 'bar', 'baz': u'qux'}) == {b'foo': b'bar', b'baz': b'qux'})

    assert(container_to_bytes({u'foo': {'bar': u'baz'}}) == {b'foo': {b'bar': b'baz'}})

# Generated at 2022-06-20 16:22:06.519320
# Unit test for function container_to_bytes
def test_container_to_bytes():
    a = "this is a string"
    b = {1: a, 2: a, 3: a}
    c = [b, b, b]
    d = tuple(c)

    # test byte str
    assert isinstance(container_to_bytes(a), bytes)
    assert isinstance(container_to_bytes(b), dict)
    assert isinstance(container_to_bytes(c), list)
    assert isinstance(container_to_bytes(d), tuple)

    a = u"this is a string"
    b = {1: a, 2: a, 3: a}
    c = [b, b, b]
    d = tuple(c)

    # test native str
    assert isinstance(container_to_bytes(a), bytes)

# Generated at 2022-06-20 16:22:15.344522
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('\u1234') == '"\\u1234"'
    assert jsonify('\ufffd') == '"\\ufffd"'
    assert jsonify('\u1234', ensure_ascii=True) == '"\\u1234"'
    assert jsonify('\ufffd', ensure_ascii=True) == '"\\ufffd"'
    assert jsonify('\u1234\ufffd') == '"\\u1234\\ufffd"'
    assert jsonify('\u1234\ufffd', ensure_ascii=True) == '"\\u1234\\ufffd"'
    assert jsonify('\xe4\xb8\xad\xe6\x96\x87') == '"\\u4e2d\\u6587"'

# Generated at 2022-06-20 16:22:28.444469
# Unit test for function to_native
def test_to_native():
    # simple test
    assert module.to_native(u'abcd') == 'abcd'
    assert module.to_native(b'abcd') == 'abcd'
    assert module.to_native(u'\u5065') == '\xe5\x81\xa5'
    assert module.to_native(b'\xe5\x81\xa5') == '\xe5\x81\xa5'
    assert module.to_native(b'\xe6\xac\xa1') == '\xe6\xac\xa1'
    assert module.to_native(b'\xe5\x81\xa5\xe6\xac\xa1') == '\xe5\x81\xa5\xe6\xac\xa1'

# Generated at 2022-06-20 16:22:39.522322
# Unit test for function to_native
def test_to_native():
    assert to_native(u"unicode") == "unicode"
    assert to_native("ascii") == "ascii"
    assert to_native(u"unicode".encode("utf-8"), errors='surrogate_or_strict') == "unicode"
    assert to_native("ascii".encode("utf-8"), errors='surrogate_or_strict') == "ascii"
    assert to_native(u"unicode".encode("utf-8", errors="replace"), errors='surrogate_or_strict') == "unicode"
    assert to_native("ascii".encode("utf-8", errors="replace"), errors='surrogate_or_strict') == "ascii"
    assert to_native(b"bytes") == b"bytes"
   

# Generated at 2022-06-20 16:22:49.884423
# Unit test for function to_native
def test_to_native():
    result = to_native(b'bytes_string')
    assert isinstance(result, text_type)
    assert result == 'bytes_string'
    result = to_native(u'unicode_string')
    assert isinstance(result, text_type)
    assert result == 'unicode_string'
    assert to_native(b'bytes_string', encoding='ascii') == 'bytes_string'
    assert to_native(u'unicode_string', nonstring='empty') == u''
    assert to_native(1, nonstring='simplerepr') == '1'

    class NonStr(object):
        def __str__(self):
            return 'non_str'


# Generated at 2022-06-20 16:23:00.829749
# Unit test for function container_to_text

# Generated at 2022-06-20 16:23:13.006515
# Unit test for function container_to_text
def test_container_to_text():
    """
    Unit test for function container_to_text
    """

    def assert_container_equal(data, result):
        """Assert that container_to_text(data) == result"""
        assert container_to_text(data) == result
        assert container_to_bytes(data) == result
        assert container_to_bytes(data, encoding='ascii') == result

    assert_container_equal(u'abc', u'abc')
    assert_container_equal('abc', 'abc')
    assert_container_equal(1, 1)
    assert_container_equal(u'\xe9', u'\xe9')

    assert_container_equal('\xc3\xa9', u'\xe9')

# Generated at 2022-06-20 16:23:23.929644
# Unit test for function container_to_text
def test_container_to_text():
    class Foo(object):
        bar = 'baz'

    assert container_to_text(Foo()) == Foo()

    assert container_to_text([1, 2, 3]) == [1, 2, 3]
    assert container_to_text((1, 2, 3)) == (1, 2, 3)

    assert container_to_text({'foo': 'bar'}) == {'foo': 'bar'}
    assert container_to_text({'foo': b'bar'}) == {'foo': 'bar'}
    assert container_to_text({b'foo': 'bar'}) == {'foo': 'bar'}
    assert container_to_text({b'foo': b'bar'}) == {'foo': 'bar'}


# Generated at 2022-06-20 16:23:51.545462
# Unit test for function to_bytes
def test_to_bytes():
    def test_string(obj, expected, encoding, errors, nonstring):
        result = to_bytes(obj, encoding, errors, nonstring)
        assert result == expected, (
            "Error testing string: %r, encoding: %r, errors: %r, nonstring: %r"
            ", expected: %r, got: %r" % (obj, encoding, errors, nonstring, expected,
                                         result))

    def test_surrogates(obj, expected, encoding=None, errors=None, nonstring=None):
        if encoding is None:
            encoding = 'utf-8'
        if errors is None:
            errors = 'surrogate_then_replace'
        if nonstring is None:
            nonstring = 'simplerepr'


# Generated at 2022-06-20 16:23:59.308950
# Unit test for function to_bytes
def test_to_bytes():
    # Run this under both python2 and python3
    for py2 in (False, True):
        # Some python2/3 differences
        if py2:
            from io import BytesIO
            from StringIO import StringIO
            unicode_type = unicode
            byte_type = str
        else:
            from io import BytesIO, StringIO
            unicode_type = str
            byte_type = bytes
        # To assert against the function, we run it and make sure that the
        # results are what we expect
        assert(to_bytes(b'123') == b'123')
        assert(to_bytes(b'123', nonstring='passthru') == b'123')
        assert(to_bytes(b'123', nonstring='empty') == b'')

# Generated at 2022-06-20 16:24:11.596851
# Unit test for function to_native
def test_to_native():
    type_error_nonstring = 'Invalid value %s for to_native\'s nonstring parameter'
    assert to_native(None) == b'None'
    assert to_native(123, nonstring='simplerepr') == b'123'
    assert to_native(123, nonstring='empty') == b''
    assert to_native(123, nonstring='passthru') == 123
    try:
        to_native(123, nonstring='strict')
    except TypeError as e:
        assert str(e) == type_error_nonstring % 'strict'
    else:
        assert False, "to_native with strict nonstring did not raise TypeError"
    assert to_native(u'\u2019') == b'\xe2\x80\x99'

# Generated at 2022-06-20 16:24:17.947394
# Unit test for function to_native
def test_to_native():
    unicode_val = u'foo'
    unicode_val_escaped = u'foo'
    utf8_val = b'foo'
    latin1_val = b'foo'
    int_val = 1
    dict_val = dict(a=1, b=2, c=3)
    list_val = [1, 2, 3]
    set_val = set([1, 2, 3])
    tuple_val = (1, 2, 3)

    assert to_native(unicode_val) == unicode_val_escaped
    assert to_native(utf8_val) == unicode_val_escaped
    assert to_native(latin1_val) == unicode_val_escaped
    assert to_native(int_val) == str(int_val)
    assert to_

# Generated at 2022-06-20 16:24:26.848585
# Unit test for function to_native
def test_to_native():
    input = (u'test', u'\u043f\u0440\u0438\u0432\u0435\u0442', True, False, None, 8)
    expected = ('test', 'привет', 'true', 'false', 'null', 8)
    if not PY3:
        input += (long(8),)
        expected += ('8',)
    try:
        import decimal
        input += (decimal.Decimal('8.8'),)
        expected += ('8.8',)
    except ImportError:
        pass

    assert expected == to_native(input)
    assert 'null' == to_native(None)
    assert 'true' == to_native(True)
    assert 'false' == to_native(False)
    assert '8.8' == to

# Generated at 2022-06-20 16:24:38.105313
# Unit test for function container_to_bytes
def test_container_to_bytes():
    bad_dict = {u'interface': u'Ethernet1/1', u'null_value': None, u'extra_config': u'\n    description test\n    '}
    fixed_dict = {b'interface': b'Ethernet1/1', b'null_value': None, b'extra_config': b'\n    description test\n    '}
    assert container_to_bytes(bad_dict) == fixed_dict

    bad_dict = {u'interface': u'Ethernet1/1', u'null_value': None, u'extra_config': u'\n    description test\n    ',
                u'unicode_str': u'\x19'}
    assert_raises(UnicodeDecodeError, container_to_bytes, bad_dict, errors='strict')


# Generated at 2022-06-20 16:24:50.468380
# Unit test for function to_native
def test_to_native():
    assert isinstance(to_native(1, errors='surrogate_or_replace'), str)
    assert isinstance(to_native('1', errors='surrogate_or_replace'), str)
    assert isinstance(to_native(b'1', errors='surrogate_or_replace'), str)

    # Python 2
    if PY2:
        # unicode and surrogateescape is strictly for python3
        assert isinstance(to_native(u'1', errors='surrogate_or_replace'), str)

    # surrogate_or_strict is always a surrogateescape error handler
    assert isinstance(to_native(b'\xe9'.decode('latin1'), errors='surrogate_or_strict'), str)

    # surrogate_or_replace is always a surrogateescape error handler

# Generated at 2022-06-20 16:24:59.213583
# Unit test for function to_native
def test_to_native():
    assert to_native(1) == 1
    assert to_native(u'\u1234') == u'\u1234'

    # Need valid surrogate pair
    assert to_native(u'\ud800\udc00') == u'\U00010000'

    valid_surrogates = []

    # NOTE: cannot use range here because ucs-2 python doesn't like this
    for i in range(0x10000, 0x110000):
        # need to skip the invalid surrogates
        if 0xD800 <= i < 0xE000:
            continue
        try:
            valid_surrogates.append(to_native(i))
        except TypeError:
            # The unichr() function can't handle values outside the UCS-2 range on UCS-2 Pythons
            pass

    assert valid_surrogates



# Generated at 2022-06-20 16:25:02.412932
# Unit test for function jsonify
def test_jsonify():
    test_str = u'你好'
    expected = '"\\u4f60\\u597d"'
    test = jsonify(test_str)
    assert test == expected
    assert type(test) == str



# Generated at 2022-06-20 16:25:14.542266
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'El Niño') == b'El Ni\xc3\xb1o'
    assert to_bytes(u'El Niño', encoding='utf-16') == b'\xff\xfee\x00 \x00N\x00i\x00\xf1\x00o\x00'
    assert to_bytes(b'\xf1\x00', encoding='utf-16') == b'\xf1\x00'
    assert to_bytes(b'\xf1\x00', encoding='utf-16', errors='surrogate_or_replace') == b'?'
