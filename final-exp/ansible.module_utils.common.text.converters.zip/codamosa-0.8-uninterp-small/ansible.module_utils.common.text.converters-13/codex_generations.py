

# Generated at 2022-06-24 20:56:33.080957
# Unit test for function to_native

# Generated at 2022-06-24 20:56:38.414190
# Unit test for function to_native
def test_to_native():
    if not isinstance(to_native('foo'), str):
        raise AssertionError
    if not isinstance(to_native(u'foo'), str):
        raise AssertionError
    if not isinstance(to_native(u'foo'.encode('utf-8')), str):
        raise AssertionError
    if not isinstance(to_native(u'foo'.encode('utf-8'), errors='surrogate_or_strict'), str):
        raise AssertionError
    if not isinstance(to_native(u'foo'.encode('utf-8'), errors='surrogate_or_replace'), str):
        raise AssertionError


# Generated at 2022-06-24 20:56:40.697280
# Unit test for function to_bytes
def test_to_bytes():
    test_str = 'str'
    print(to_bytes(test_str))



# Generated at 2022-06-24 20:56:42.664066
# Unit test for function to_native
def test_to_native():
    new_str = to_native('test')
    assert isinstance(new_str, str)


# Generated at 2022-06-24 20:56:45.398899
# Unit test for function to_native
def test_to_native():
    str_0 = 'in local.exec_command()'
    var_0 = to_native(str_0)
    assert var_0 == 'in local.exec_command()'


# Generated at 2022-06-24 20:56:55.458270
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('in local.exec_command()') == '"in local.exec_command()"'
    assert jsonify(u'in local.exec_command()') == '"in local.exec_command()"'
    assert jsonify([u'in local.exec_command()']) == '["in local.exec_command()"]'
    assert jsonify([u'in local.exec_command()']) == '["in local.exec_command()"]'
    assert jsonify([u'in local.exec_command()']) == '["in local.exec_command()"]'
    assert jsonify([u'in local.exec_command()']) == '["in local.exec_command()"]'
    assert jsonify([u'in local.exec_command()']) == '["in local.exec_command()"]'

# Generated at 2022-06-24 20:56:58.700149
# Unit test for function to_native
def test_to_native():
    assert to_native('str_0') == 'str_0'


# Generated at 2022-06-24 20:57:00.994938
# Unit test for function jsonify
def test_jsonify():
    try:
        test_case_0()
    except Exception:
        logging.exception('Caught exception')
        raise


# Generated at 2022-06-24 20:57:02.606820
# Unit test for function to_native
def test_to_native():
    """to_native is tested in test_utils and test_module_utils_basic"""
    pass


# Generated at 2022-06-24 20:57:08.712533
# Unit test for function to_bytes
def test_to_bytes():
    assert isinstance(to_bytes('a'), binary_type)
    assert isinstance(to_bytes(u'a'), binary_type)
    assert isinstance(to_bytes(b'a'), binary_type)
    assert to_bytes('a') == b'a'
    assert to_bytes(u'a') == b'a'
    assert to_bytes(b'a') == b'a'

    assert isinstance(to_bytes(u'\u2019'), binary_type)
    assert isinstance(to_bytes(u'\u2019', errors='surrogateescape'), binary_type)
    if HAS_SURROGATEESCAPE:
        assert to_bytes(u'\u2019', errors='surrogateescape') == b'\x81\x99'

# Generated at 2022-06-24 20:57:18.209691
# Unit test for function jsonify
def test_jsonify():
    var_0 = jsonify("\u0016\u0017")
    print(var_0)


# Generated at 2022-06-24 20:57:25.162048
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u20ac') == b'\xe2\x82\xac'
    assert to_bytes(u'\u20ac', encoding='cp1252') == b'\x80'
    assert to_bytes(u'\u20ac', encoding='cp1252', errors='replace') == b'?'
    assert to_bytes(u'\u20ac', errors='replace') == b'?'
    assert to_bytes(u'\u20ac', errors='surrogate_then_replace') == b'?'
    assert to_bytes(1) == b'1'
    assert to_bytes(1, nonstring='passthru') == 1
    assert to

# Generated at 2022-06-24 20:57:29.716793
# Unit test for function to_native
def test_to_native():
    assert to_native("\xE2\x9C\x9F") == "\xE2\x9C\x9F"
    assert to_native("\xE2\x9C\x9F", errors="surrogate_or_strict") == "\xE2\x9C\x9F"
    assert to_native("\xE2\x9C\x9F".encode("utf-8"), errors="surrogate_or_strict") == "\xE2\x9C\x9F"


# Generated at 2022-06-24 20:57:40.951734
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foobar') == b'foobar'
    assert to_bytes(b'foobar') == b'foobar'

    # Test with various nonstrings
    assert to_bytes(0) == b'0'
    assert to_bytes([]) == b'[]'
    assert to_bytes({}) == b'{}'
    assert to_bytes(()) == b'()'

    # Test with various nonstrings with various nonstring values
    assert to_bytes(0, nonstring='simplerepr') == b'0'
    assert to_bytes(0, nonstring='passthru') == 0
    assert to_bytes(0, nonstring='empty') == b''
    assert to_bytes(0, nonstring='strict')
    # assert to_bytes(0, nonstring='foo')

    #

# Generated at 2022-06-24 20:57:51.743894
# Unit test for function jsonify
def test_jsonify():
    # Checking the internal references
    data = dict(
        a=[u"h\xedll\u2603", u"\ud83d\udc9b", u"\ud83d\udc9c\ud83d\udc99"],
        b=[u"h\xedll\u2603", u"\ud83d\udc9b", u"\ud83d\udc9c\ud83d\udc99", 2, 5, 2.15, 2.15e75, False, True, None]
    )
    text_str = jsonify(data)
    json.loads(text_str)

    assert to_text(text_str) == to_text(jsonify(container_to_text(data)))

# Generated at 2022-06-24 20:57:56.971023
# Unit test for function to_native
def test_to_native():
    assert(to_native('abc') == 'abc')
    assert(to_native(b'abc') == 'abc')
    assert(to_native(1) == 1)
    assert(to_native(dict(a=0)) == dict(a=0))
    assert(to_native(None) is None)
    # datetime.datetime objects are not serializable by the JSON module, so
    # they should be transformed to an ISO8601 string
    assert(to_native(datetime.datetime(2017, 8, 14, 14, 45, 20, 814866)) == '2017-08-14T14:45:20.00814866')
    assert(to_native(Set((1, 2, 3))) == [1, 2, 3])


# Generated at 2022-06-24 20:57:58.939274
# Unit test for function to_bytes
def test_to_bytes():
    int_0 = -832
    var_0 = to_bytes(int_0)


# Generated at 2022-06-24 20:58:00.730772
# Unit test for function to_native
def test_to_native():
    """ Test to_native with various inputs """
    print('Test to_native - start')

    int_0 = -832
    var_0 = to_bytes(int_0)
    print('Test to_native - end')


# Generated at 2022-06-24 20:58:13.247683
# Unit test for function to_bytes
def test_to_bytes():
    int_0 = -832
    value_0 = to_bytes(int_0)
    assert(value_0 == b'-832')
    string_0 = 'h1Xs{PTzt0y'
    value_1 = to_bytes(string_0)
    assert(value_1 == string_0)
    list_0 = ['u', 'v', 'm']
    value_2 = to_bytes(list_0)
    assert(value_2 == b"['u', 'v', 'm']")
    int_1 = -7098
    value_3 = to_bytes(int_1)
    assert(value_3 == b'-7098')
    int_2 = -7275
    value_4 = to_bytes(int_2)

# Generated at 2022-06-24 20:58:23.813189
# Unit test for function jsonify
def test_jsonify():
    str_0 = 'jF8/'
    str_1 = 'qeU$'
    str_2 = '-'
    int_0 = -0
    var_0 = to_bytes(str_0)
    var_1 = jsonify(var_0)

    str_0 = 'gX5)'
    str_1 = 'Bv\xd2'
    str_2 = '-'
    int_0 = -1
    var_0 = to_bytes(str_0)
    var_1 = jsonify(var_0)

    str_0 = '\x11\xa8]\xe1'
    str_1 = 'c\xdc\x0e\xb0'
    str_2 = '-'
    int_0 = -2

# Generated at 2022-06-24 20:58:38.703959
# Unit test for function to_native
def test_to_native():
    test_values = [
        (u'\u2713', None, True, b'\xe2\x9c\x93'),
        (b'\xe2\x9c\x93', None, True, b'\xe2\x9c\x93'),
        (u'\u2713', 'ascii', True, b'?'),
        (b'\xe2\x9c\x93', 'ascii', True, b'?'),
        # Test when the surrogateescape error handler is available
        (u'\u2713', 'ascii', False, b'\xe2\x9c\x93')
    ]


# Generated at 2022-06-24 20:58:49.406026
# Unit test for function to_bytes
def test_to_bytes():
    assert callable(to_bytes)
    assert isinstance(to_bytes('foo'), bytes)
    assert isinstance(to_bytes(b'foo'), bytes)
    assert isinstance(to_bytes(1), bytes)

    assert to_bytes(1) == b'1'
    assert to_bytes('1') == b'1'
    assert to_bytes(b'1') == b'1'

    assert to_bytes(1, encoding='ascii') == b'1'
    assert to_bytes('1', encoding='ascii') == b'1'
    assert to_bytes(b'1', encoding='ascii') == b'1'

    assert to_bytes(1, encoding='utf8') == b'1'
    assert to_bytes('1', encoding='utf8') == b'1'
   

# Generated at 2022-06-24 20:58:56.042508
# Unit test for function jsonify
def test_jsonify():
    # This test is not appropriate since jsonify(data, **kwargs) encodes the data into utf-8
    # or latin-1 depending on the data.
    # We need to create a simple test case like the one above and check that the tw
    # functions produce the same results.
    # assert(jsonify("test") == "test")
    #
    pass


# Generated at 2022-06-24 20:58:59.747362
# Unit test for function to_bytes
def test_to_bytes():
    try:
        int_1 = -832
        var_0 = to_bytes(int_1)
    except Exception as exception:
        print("Failed to call the function to_bytes")
        print(exception)
        return

if __name__ == "__main__":
    test_to_bytes()

# Generated at 2022-06-24 20:59:10.958477
# Unit test for function to_bytes
def test_to_bytes():
    # Test case to_bytes(obj)
    int_0 = -832
    var_0 = to_bytes(int_0)
    assert isinstance(var_0, bytes)
    assert var_0 == '-832'
    # Test case to_bytes(obj)
    str_0 = '~[p]D['
    var_0 = to_bytes(str_0)
    assert isinstance(var_0, bytes)
    # Test case to_bytes(obj)
    str_0 = '&QQ*'
    var_0 = to_bytes(str_0)
    assert isinstance(var_0, bytes)
    # Test case to_bytes(obj)
    str_0 = '&('
    var_0 = to_bytes(str_0)

# Generated at 2022-06-24 20:59:20.757837
# Unit test for function to_bytes
def test_to_bytes():
    assert(to_bytes('hello') == b'hello')
    assert(to_bytes('hello', 'utf-8') == b'hello')
    assert(to_bytes(u'hello') == b'hello')
    assert(to_bytes(u'hello', 'utf-8') == b'hello')
    assert(to_bytes(b'hello') == b'hello')
    assert(to_bytes(b'hello', 'utf-8') == b'hello')
    assert(to_bytes(u'\u1234') == b'\xe1\x88\xb4')
    assert(to_bytes(u'\u1234', 'utf-16') == b'\xff\xfe4\x12')
    assert(to_bytes(u'\u1234', 'ascii') == b'?')


# Generated at 2022-06-24 20:59:25.365989
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(0) == b'0'
    assert to_bytes(0, nonstring='passthru') == 0
    assert to_bytes(0, nonstring='empty') == b''
    assert to_bytes(0, nonstring='strict')


# Generated at 2022-06-24 20:59:27.232297
# Unit test for function jsonify
def test_jsonify():
    result = jsonify({"a": 1})
    assert result == '{"a": 1}'


# Generated at 2022-06-24 20:59:36.233891
# Unit test for function jsonify
def test_jsonify():
    class MyClass(object):
        def __init__(self, some_text):
            self.some_text = some_text

        def __str__(self):
            return self.some_text

        def __repr__(self):
            return u'some_text=%s' % self.some_text

    data = dict(
        a=to_bytes('foo'),
        b=MyClass('bar'),
        c=dict(
            x=to_bytes('abc'),
            y=0
        ),
        d=None,
    )
    output1 = jsonify(data)
    output2 = jsonify(data, sort_keys=True)

    print((output1))
    print((output2))


# Generated at 2022-06-24 20:59:38.857926
# Unit test for function jsonify
def test_jsonify():
    try:
        # Test case 0
        test_case_0()
    except Exception as ex:
        print('Exception %s while testing function jsonify' % ex)

# Global Variables

# Generated at 2022-06-24 20:59:47.342087
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b'}
    var_0 = jsonify(data, sort_keys=True, indent=4)
    print (var_0)


# Generated at 2022-06-24 20:59:54.560824
# Unit test for function to_native
def test_to_native():
    from ansible.utils import to_native

    assert to_native('foo') == u'foo'
    assert to_native(b'foo') == u'foo'

    # Test all values
    class intobj(int):
        def __str__(self):
            raise RuntimeError('foo')

    class strobj(str):
        def __str__(self):
            raise RuntimeError('foo')

    class bytobj(bytes):
        def __str__(self):
            raise RuntimeError('foo')

    class uniobj(unicode):
        def __str__(self):
            raise RuntimeError('foo')

    class dictobj(dict):
        def __str__(self):
            raise RuntimeError('foo')

    class listobj(list):
        def __str__(self):
            raise RuntimeError('foo')

# Generated at 2022-06-24 21:00:06.258325
# Unit test for function jsonify

# Generated at 2022-06-24 21:00:10.851409
# Unit test for function to_native
def test_to_native():
    # assert to_native(unicode_0) == str_0
    assert to_text(str_0) == str_0
    assert to_text(int_0) == str_0


# Generated at 2022-06-24 21:00:13.541271
# Unit test for function jsonify
def test_jsonify():
    int_0 = -3216
    str_0 = jsonify(int_0)
    str_1 = '-3216'
    assert str_0 == str_1


# Generated at 2022-06-24 21:00:23.164362
# Unit test for function to_native
def test_to_native():
    var_1 = to_bytes(True)
    var_3 = to_bytes(False)
    var_4 = to_bytes(datetime.datetime(2014, 12, 30, 13, 23, 13, 132000))
    var_6 = to_bytes(3.141592653589793)
    var_7 = to_bytes(u'This is a string')
    var_8 = to_bytes((b'This is a byte string', u'This is a mixed string', None))
    var_10 = to_bytes(set([u'A', u'B', u'C']))
    var_12 = to_bytes(dict(A=1, B=2, C=3))



# Generated at 2022-06-24 21:00:23.949830
# Unit test for function jsonify
def test_jsonify():
    assert True == True



# Generated at 2022-06-24 21:00:29.136533
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(0) == '0'
    assert to_bytes(1) == '1'
    assert to_bytes(-1) == '-1'
    assert to_bytes(0.0) == '0.0'
    assert to_bytes(-1.0) == '-1.0'
    assert to_bytes(0.1) == '0.1'
    assert to_bytes(-0.1) == '-0.1'
    assert to_bytes(0.123456789) == '0.123456789'
    assert to_bytes(-0.123456789) == '-0.123456789'

# Make sure that we can convert invalid bytes

# Generated at 2022-06-24 21:00:34.545949
# Unit test for function to_bytes
def test_to_bytes():
    # Define the test strings
    int_0 = -832
    int_1 = 452
    int_2 = -391
    int_3 = -315
    int_4 = 804
    int_5 = -798
    int_6 = -827
    int_7 = -333
    int_8 = -730
    int_9 = -267
    int_10 = -707
    int_11 = 872
    int_12 = -632
    int_13 = 653
    int_14 = -839
    int_15 = -55
    int_16 = 652
    int_17 = -973
    int_18 = -772
    int_19 = -727
    int_20 = -932
    int_21 = -769
    int_22 = -568


# Generated at 2022-06-24 21:00:39.206415
# Unit test for function jsonify
def test_jsonify():
    int_0 = -832
    var_0 = jsonify(int_0)
    var_1 = jsonify(int_0)
    assert var_0 == var_1


# Generated at 2022-06-24 21:00:53.372213
# Unit test for function to_native
def test_to_native():
    try:
        str = unicode("str", "utf-8")
    except NameError:
        str = "str"
    try:
        byte_str = b"byte str"
    except NameError:
        byte_str = bytes("byte str", "utf-8")
    assert to_native(str) == "str"
    assert to_native(byte_str) == "byte str"
    assert to_native(["list"]) == ["list"]
    assert to_native(("tuple",)) == ("tuple",)
    assert to_native({"key": "val"}) == {"key": "val"}
    assert to_native(1) == 1
    assert to_native(33.3) == 33.3
    assert to_native(datetime.datetime.now()) == datetime.datetime.now

# Generated at 2022-06-24 21:01:05.175825
# Unit test for function jsonify
def test_jsonify():
    input_var_1 = {
        u'var_2': {
            u'var_3': u'val_1',
            u'var_4': u'val_2',
            u'var_5': u'val_3',
            u'var_6': u'val_4',
        },
        u'var_7': u'val_5',
        u'var_8': u'val_6',
    }
    output = b'{"var_2": {"var_3": "val_1", "var_4": "val_2", "var_5": "val_3", "var_6": "val_4"}, "var_7": "val_5", "var_8": "val_6"}'
    assert jsonify(input_var_1) == output



# Generated at 2022-06-24 21:01:11.385971
# Unit test for function to_native
def test_to_native():
    # Method to_native() from class Text

    str_0 = 'This is a test of the to_native method.'
    var_0 = to_native(str_0)
    print(' var_0:', var_0)

    var_1 = to_native(var_0)
    print(' var_1:', var_1)

    assert var_0 == var_1


# Generated at 2022-06-24 21:01:18.449477
# Unit test for function jsonify
def test_jsonify():
    container_0 = dict()
    container_0[to_bytes(0)] = {'key_0': -832, 'key_1': 'value_0'}
    var_0 = jsonify(container_0)
    assert to_native(var_0) == to_native(to_bytes('{"0": {"key_0": -832, "key_1": "value_0"}}'))


# Generated at 2022-06-24 21:01:21.561198
# Unit test for function jsonify
def test_jsonify():
    hash_0 = dict(b = [], c = [], a = [])
    var_0 = jsonify(hash_0)

# Generated at 2022-06-24 21:01:26.988071
# Unit test for function jsonify
def test_jsonify():
    print("Testing jsonify")
    print("TODO: Assert statements")

    # Test with a dictionary as input
    test_dict = {'name': 'Brian', 'surname': 'Curtin', 'age': '40'}
    test_json = jsonify(test_dict)
    print(test_json)

    # Test with a list of dictionaries as input
    test_list_of_dicts = [
        {'name': 'Brian', 'surname': 'Curtin', 'age': '40'},
        {'name': 'Barry', 'surname': 'Curtin', 'age': '48'}
    ]
    test_json = jsonify(test_list_of_dicts)
    print(test_json)

# Main routine. This should call the test cases.


# Generated at 2022-06-24 21:01:29.549078
# Unit test for function jsonify
def test_jsonify():
    data = {'key': 'value'}
    actual = jsonify(data)
    expected = json.dumps(data)
    assert actual == expected


# Generated at 2022-06-24 21:01:37.551712
# Unit test for function jsonify
def test_jsonify():
    # bool
    assert jsonify(True) == 'true'
    assert jsonify(False) == 'false'
    # str
    assert jsonify('aaa') == '"aaa"' # to be json'ed as a string
    # unicode
    assert jsonify(u'aaa') == '"aaa"' 
    # int
    assert jsonify(-832) == '-832'
    # float
    assert jsonify(832.23) == '832.23'
    # list
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'
    # tuple
    assert jsonify((1, 2, 3)) == '[1, 2, 3]'
    # dictionary

# Generated at 2022-06-24 21:01:44.030638
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('test_text', 'utf-8', 'strict', 'empty') == b''
    assert to_bytes(99999999999999, 'utf-8', 'surrogate_or_replace', 'passthru') == 99999999999999
    assert to_bytes(repr(to_bytes), 'gbk', 'surrogate_or_strict', 'passthru') == repr(to_bytes)
    assert to_bytes(set(), 'utf-8', 'surrogate_then_replace') == b'set()'
    assert to_bytes(print, 'utf-8', 'surrogate_then_replace') == b'<built-in function print>'

# Generated at 2022-06-24 21:01:50.842604
# Unit test for function to_bytes
def test_to_bytes():
    # In Python3 it returns bytes, in python2 it returns str.
    # So just check that it returns a string.
    assert isinstance(to_bytes(''), binary_type)

    assert to_bytes('abc123') == b'abc123'
    assert to_bytes(u'abc123') == b'abc123'
    assert to_bytes(123) == b'123'
    assert to_bytes(text_type('abc123')) == b'abc123'

    # Surrogates
    long_unicode = u'\U00032d4e'
    assert isinstance(long_unicode, text_type)
    # long_unicode is a string with characters that cannot be encoded in utf8
    # so using the default of surrogate_or_replace will encode them as the replacement character

# Generated at 2022-06-24 21:01:58.373231
# Unit test for function to_bytes
def test_to_bytes():
    test_case_0()

test_to_bytes()

# Generated at 2022-06-24 21:02:04.960033
# Unit test for function jsonify
def test_jsonify():
    data_0 = {'k1': 'v1', 'k2': 'v2', 'k3': 'v3'}
    for encoding in ("utf-8", "latin-1"):
        try:
            var_0 = jsonify(data_0, encoding=encoding)
        except TypeError:
            new_data = container_to_text(data_0, encoding=encoding)
            var_0 = jsonify(new_data)
        except UnicodeDecodeError:
            continue
        break
    print(var_0)



# Generated at 2022-06-24 21:02:12.750248
# Unit test for function to_native
def test_to_native():
    int_0 = 1
    bool_0 = False
    list_0 = ['from_file']
    str_0 = 'from_file'
    str_1 = 'from_file'
    dict_0 = {'from_file': 'from_file', 'from_file': 'from_file'}
    int_1, bool_1, list_1, str_2, str_3, dict_1 = to_native(int_0, bool_0, list_0, str_0, str_1, dict_0)
    assert int_1 == 1
    assert bool_1 == False
    assert list_1 == ['from_file']
    assert str_2 == 'from_file'
    assert str_3 == 'from_file'

# Generated at 2022-06-24 21:02:18.277231
# Unit test for function to_native
def test_to_native():
    var_1 = to_native(-0.0)
    var_2 = to_native(set())
    var_3 = to_native(bytearray())
    var_4 = to_native(0.0)
    var_5 = to_native(0)
    var_6 = to_native("")
    var_7 = to_native([])
    var_8 = to_native({})


# Generated at 2022-06-24 21:02:20.989652
# Unit test for function jsonify
def test_jsonify():
    data = {'test': u'hello', u'test2': 'world'}

    try:
        assert(jsonify(data) == b'{"test": "hello", "test2": "world"}')
    except AssertionError:
        return False
    except Exception:
        import traceback
        traceback.print_exc()
        return False
    return True



# Generated at 2022-06-24 21:02:26.907077
# Unit test for function to_native
def test_to_native():
  # Input parameters
  #   arg1:

  # Output parameters
  #   arg1:

  # Test to_native()
  to_native('str_0')
 

# Generated at 2022-06-24 21:02:32.920479
# Unit test for function to_native
def test_to_native():
    #Testing the function to_native
    import ansible_module_utils._text
    from ansible_module_utils._text import to_native
    string_0 = u' \U0001f638 '
    string_0_utf8 = b' \xf0\x9f\x98\xb8 '
    string_1 = ' \xf0\x9f\x98\xb8 '
    string_1_utf8 = b' \xf0\x9f\x98\xb8 '
    bytes_0 = b' \xf0\x9f\x98\xb8 '
    ansible_module_utils._text.HAS_SURROGATEESCAPE = False
    to_native(string_1, 'strict')
    to_native(bytes_0, 'strict')

# Generated at 2022-06-24 21:02:39.029955
# Unit test for function jsonify
def test_jsonify():
    data = {u'a': 1, u'c': {u'b': u'prwtvadnkagrgn'}, u'b': [1, 2]}
    assert jsonify(data) == '{"a": 1, "c": {"b": "prwtvadnkagrgn"}, "b": [1, 2]}'


# Generated at 2022-06-24 21:02:42.234691
# Unit test for function jsonify
def test_jsonify():
    # Will not test all branches, as the function is simply a wrapper
    # around json.dumps and container_to_text
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'


# Generated at 2022-06-24 21:02:46.931195
# Unit test for function jsonify
def test_jsonify():
    var_0 = {
        'data': [
            {
                'value': 678,
                'id': 'item id'
            },
            {
                'value': 678,
                'id': 'item id'
            }
        ]
    }
    json_str = jsonify(var_0)



# Generated at 2022-06-24 21:02:58.967704
# Unit test for function jsonify
def test_jsonify():
    print("Test jsonify")
    print("Expect default to be utf-8")
    print(jsonify([u"\u4e2d\u6587"]))

    print("Expect latin-1")
    print(jsonify([u"\u4e2d\u6587"], encoding="latin-1"))

    print("Expect Invalid Unicode encoding error")
    jsonify([u"\u4e2d\u6587"], encoding="latin-1", ensure_ascii=True)

    print("Expect set to be converted to list")
    print(jsonify({1, 2, 3}))

    print("Expect datetime to be converted to isoformat")
    print(jsonify(datetime.datetime.now()))

    print("Expect error")

# Generated at 2022-06-24 21:03:07.171722
# Unit test for function to_native
def test_to_native():
    # string_0
    string_0 = str("moz-chunked-arraybuffer")
    assert to_native(string_0) == "moz-chunked-arraybuffer"

    # string_1
    string_1 = str("gzip")
    assert to_native(string_1) == "gzip"

    # int_0
    int_0 = -832
    assert to_native(int_0) == -832

    # dict_0
    dict_0 = dict()
    dict_0[str("moz-chunked-arraybuffer")] = 6839.375
    dict_0[str("gzip")] = 8509.4568
    dict_0[str("deflate")] = 989.858
    dict_0[str("br")] = 751.01

# Generated at 2022-06-24 21:03:17.909814
# Unit test for function jsonify
def test_jsonify():
    dict_0 = dict()
    dict_0['element_0'] = -178
    dict_0['element_1'] = to_bytes(340)
    dict_0['element_2'] = 'element_2'
    dict_0['element_3'] = 'element_3'
    dict_0['element_4'] = 'element_4'
    dict_0['element_5'] = 'element_5'
    dict_0['element_6'] = 'element_6'
    dict_0['element_7'] = 'element_7'
    dict_0['element_8'] = 'element_8'
    dict_0['element_9'] = 'element_9'
    dict_0['element_10'] = 'element_10'
    dict_0['element_11'] = 'element_11'
   

# Generated at 2022-06-24 21:03:27.769388
# Unit test for function to_bytes
def test_to_bytes():
    int_0 = -32
    var_0 = to_bytes(int_0)
    var_1 = to_bytes(var_0)
    var_2 = to_bytes(int_0, encoding='utf-8')
    var_3 = to_bytes(var_2)
    var_4 = to_bytes(int_0, encoding='utf-8', errors='surrogate_or_strict')
    var_5 = to_bytes(var_4)
    var_6 = to_bytes(int_0, encoding='utf-8', errors='surrogate_or_replace')
    var_7 = to_bytes(var_6)
    var_8 = to_bytes(int_0, encoding='utf-8', errors='surrogate_then_replace')

# Generated at 2022-06-24 21:03:29.967738
# Unit test for function to_bytes
def test_to_bytes():
    print(to_bytes(100))
    print(to_bytes((1, 2, 3)))
    print(to_bytes('张三'))
    print(to_bytes(u'张三'))



# Generated at 2022-06-24 21:03:31.348286
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == 'null', 'Incorrect value returned'


# Generated at 2022-06-24 21:03:43.205845
# Unit test for function to_bytes
def test_to_bytes():
    print("TEST: to_bytes")
    # Check that we can take a text string and get back a byte string
    assert(to_bytes('hello') == b'hello')

    # Check that we can take a byte string and get back a byte string
    assert(to_bytes(b'hello') == b'hello')

    # Check that we can take an integer and get back a byte string
    assert(to_bytes(-832) == b'-832')

    # Check that we can take a float and get back a byte string
    assert(to_bytes(-832.0) == b'-832.0')

    # Check that we can take a list and get back a byte string
    assert(to_bytes([1, 2, 3]) == b'[1, 2, 3]')

    # Check that we can take a set and get

# Generated at 2022-06-24 21:03:50.355317
# Unit test for function to_bytes
def test_to_bytes():
    int_0 = -832
    var_0 = to_bytes(int_0)
    int_1 = 900
    var_1 = to_bytes(int_1)
    int_2 = -40
    var_2 = to_bytes(int_2)
    int_3 = -660
    var_3 = to_bytes(int_3)
    int_4 = -664
    var_4 = to_bytes(int_4)
    int_5 = 961
    var_5 = to_bytes(int_5)
    int_6 = 532
    var_6 = to_bytes(int_6)
    int_7 = -921
    var_7 = to_bytes(int_7)
    int_8 = -958

# Generated at 2022-06-24 21:03:59.380561
# Unit test for function to_bytes
def test_to_bytes():
    int_0 = -832
    var_0 = to_bytes(int_0)
    var_1 = to_bytes(int_0, errors='surrogate_or_replace')
    var_2 = to_bytes(int_0, nonstring='strict')
    var_3 = to_bytes(int_0, nonstring='simplerepr', encoding='ascii')
    var_4 = to_bytes(int_0, errors='surrogate_then_replace')
    var_5 = to_bytes(int_0, errors='surrogate_or_strict')
    var_6 = to_bytes(int_0, encoding='ascii')


# Generated at 2022-06-24 21:04:01.374709
# Unit test for function to_bytes
def test_to_bytes():
    int_1 = 0
    str_1 = "a"
    test_case_0()


if __name__ == '__main__':
    # Unit test
    test_to_bytes()

# Generated at 2022-06-24 21:04:15.888803
# Unit test for function jsonify

# Generated at 2022-06-24 21:04:26.555172
# Unit test for function jsonify
def test_jsonify():
    list1 = [1, 2, 3]

    expected_result1 = json.dumps(list1)
    actual_result1 = jsonify(list1)
    assert actual_result1 == expected_result1

    list2 = [1, 2, 'x']

    expected_result2 = json.dumps(list2, encoding="latin-1")
    actual_result2 = jsonify(list2)
    assert actual_result2 == expected_result2

    list3 = [1, 2, 'ζ']

    expected_result3 = json.dumps(list3, encoding="utf-8")
    actual_result3 = jsonify(list3)
    assert actual_result3 == expected_result3


# Generated at 2022-06-24 21:04:33.621181
# Unit test for function jsonify
def test_jsonify():
    dict_0 = dict()
    dict_0['d'] = 'ccfc9ef3'
    dict_0['m'] = 'none'
    dict_0['p'] = 'This is the message'
    dict_0['l'] = 'CRITICAL'
    dict_0['t'] = '2016-08-31T16:12:43.353043+00:00'
    var_0 = jsonify(dict_0)


# Generated at 2022-06-24 21:04:44.207605
# Unit test for function jsonify
def test_jsonify():
    int_1 = 369
    bool_0 = False
    var_2 = to_text(int_1)
    var_3 = jsonify(var_2)
    var_3 = jsonify(var_2)
    var_3 = jsonify(var_2)
    var_3 = jsonify(var_2)
    var_3 = jsonify(var_2)
    var_3 = jsonify(var_2)
    var_3 = jsonify(var_2, sort_keys=bool_0)
    var_3 = jsonify(var_2)
    int_2 = 9656
    var_4 = to_bytes(int_2)
    int_4 = -3832
    int_5 = -4988
    float_0 = 3.69
    dict_0 = dict()
    dict

# Generated at 2022-06-24 21:04:53.175541
# Unit test for function jsonify
def test_jsonify():
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_list = [1, 2, 3]
    test_str = "test string"
    test_unicode = u"ascii"
    test_bytearray = bytearray("test byte array", "utf-8")
    test_int = 33
    test_float = 0.66
    test_set1 = set([1, 2, 3])
    test_set2 = set(["a", "b", "c"])
    test_set3 = set([u"one", u"two", u"three"])
    test_date_obj = datetime.datetime(2017, 9, 25, 15, 55, 20, 0)
    test_set1.add(test_date_obj)
    test_

# Generated at 2022-06-24 21:04:59.061733
# Unit test for function to_bytes
def test_to_bytes():
    # Uncomment to start this test
    # var_0 = -832
    # assert to_bytes(var_0) == b"-832"
    pass


# Generated at 2022-06-24 21:05:05.905018
# Unit test for function to_native
def test_to_native():
    # for the following test case, we have to use the following command to pass the test
    # python -m pytest tests/unit/module_utils/test_text.py -v -k to_native
    int_0 = -832
    var_0 = to_bytes(int_0)


# Generated at 2022-06-24 21:05:14.401023
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes("a") == b'a'
    assert to_bytes(b'a') == b'a'
    assert to_bytes(u'a') == b'a'
    assert to_bytes(u'abc') == b'abc'
    assert to_bytes(u'abc', nonstring='empty') == b''
    assert to_bytes(u'abc', nonstring='passthru') == u'abc'

    var_0 = 1
    test_case_0()

if __name__ == '__main__':
    
    test_to_bytes()

# Generated at 2022-06-24 21:05:17.083616
# Unit test for function jsonify
def test_jsonify():
    expected = u'{"key_0": "value_0"}'
    actual = jsonify({u'key_0': u'value_0'})
    assert actual == expected


# Generated at 2022-06-24 21:05:23.772111
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'abc') == b'abc'
    assert to_bytes(u'abc') == b'abc'
    assert to_bytes(u'\u00ff') == b'\xff'
    assert to_bytes(u'\udcff') == b'\xed\xb3\xbf'
    assert to_bytes(u'\udcff', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\udcff', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\udcff', errors='ignore') == b''
    assert to_bytes(u'\udcff', errors='surrogate_then_replace') == b'?'

# Generated at 2022-06-24 21:05:38.809099
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'abc\u20ac', errors='surrogate_or_replace') == b'abc\xe2\x82\xac'
    assert to_bytes(u'abc\u20ac', errors='surrogate_or_ignore') == b'abc'
    assert to_bytes(u'abc\u20ac', errors='surrogate_or_strict') == b'abc\xe2\x82\xac'
    assert to_bytes(u'abc\xff', errors='surrogate_or_replace') == b'abc\xff'
    assert to_bytes(u'abc\xff', errors='surrogate_or_ignore') == b'abc'

# Generated at 2022-06-24 21:05:47.260465
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils import basic
    import requests

    basic._ANSIBLE_ARGS = None
    data_0 = {'headers': {'Accept': 'application/json', 'Content-Type': 'application/json;charset=UTF-8'}, 'cookies': {}, 'params': {'address': '12883 Sugarberry Ct S, Jacksonville, FL', 'key': 'AIzaSyD--QP7V-m5o5CZj5W5rzFhB9SLY-3qybY'}, 'data': '', 'json': None, 'files': None, 'method': 'GET', 'verify': True, 'url': 'https://maps.googleapis.com/maps/api/geocode/json'}

# Generated at 2022-06-24 21:05:48.375057
# Unit test for function jsonify
def test_jsonify():
    assert(jsonify(int) == '"int"')



# Generated at 2022-06-24 21:05:50.238656
# Unit test for function to_native
def test_to_native():
    string = to_native('test')
    print(string)


# Generated at 2022-06-24 21:05:58.267340
# Unit test for function to_bytes
def test_to_bytes():

    # Call function and test for expected results
    assert to_bytes(42) == b'42'

    # Call function and test for expected results
    assert to_bytes('foo') == b'foo'

    # Call function and test for expected results
    assert to_bytes(u'é') == b'\xc3\xa9'

    # Call function and test for expected results
    assert to_bytes(u'é', encoding='latin-1') == b'\xe9'

    # Call function and test for expected results
    try:
        to_bytes(u'é', encoding='ascii')
    except UnicodeError:
        pass

    # Call function and test for expected results
    assert to_bytes(u'é', encoding='ascii', errors='surrogate_or_strict') == b'?'

    # Call function

# Generated at 2022-06-24 21:06:10.083407
# Unit test for function jsonify
def test_jsonify():
    test_data = {u'date': u'2013-04-01', u'name': u'Jill', u'amount': -42, u'transactions': [{u'date': u'2013-04-01', u'name': u'Jill', u'amount': -42}, {u'date': u'2013-04-10', u'name': u'Lillian', u'amount': 1000}, {u'date': u'2013-04-15', u'name': u'Jack', u'amount': -100}]}
    encode = json.dumps(test_data, encoding='utf-8')
    encode_ansible = jsonify(test_data, encoding='utf-8')
    encode_json_ansible_str = jsonify(test_data)

# Generated at 2022-06-24 21:06:13.875314
# Unit test for function to_native
def test_to_native():
    assert to_native(1) == 1
    assert to_native("1") == "1"
