

# Generated at 2022-06-24 20:56:23.433207
# Unit test for function to_bytes
def test_to_bytes():
    pass


# Generated at 2022-06-24 20:56:24.312235
# Unit test for function jsonify
def test_jsonify():
    assert True == True

test_jsonify()

# Generated at 2022-06-24 20:56:30.942132
# Unit test for function jsonify
def test_jsonify():
    bytes_0 = b'm\x86\x80\xaf}\xf2\x85.C\xea8\xa4t7u\x16\x90\xdf\xe2\x8f'
    var_0 = jsonify(bytes_0)


bytes_1 = b'\x0e\x9b\x9bV\x84\x96\x8emp\x0f\x0e\xab\x9a\x11\x07\x87\xef\x01\xe6\x85\xe3\x06\x0b\x07\xbb\xbd\xb4'

# Generated at 2022-06-24 20:56:41.509559
# Unit test for function jsonify
def test_jsonify():
    import os
    import json
    import pprint

# Generated at 2022-06-24 20:56:50.601511
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(False) == b'False'
    assert to_bytes(True) == b'True'

    # Test normal text -> bytes
    assert to_bytes('fob') == b'fob'
    assert to_bytes(u'fob') == b'fob'
    assert to_bytes(u'f\xf6\xe4\xfc'.encode('utf-8'), 'latin-1') == u'f\xf6\xe4\xfc'.encode('latin-1')
    assert to_bytes(u'f\xf6\xe4\xfc'.encode('latin-1'), 'utf-8', errors='surrogate_or_replace') == u'f\xf6\xe4\xfc'.encode('utf-8')

# Generated at 2022-06-24 20:57:02.654794
# Unit test for function to_bytes
def test_to_bytes():
    # Test with valid input
    bytes_0 = b'm\x86\x80\xaf}\xf2\x85.C\xea8\xa4t7u\x16\x90\xdf\xe2\x8f'
    encoding_0 = 'bzip2_codec'
    errors_0 = 'url'
    nonstring_0 = 'simplerepr'

# Generated at 2022-06-24 20:57:06.843009
# Unit test for function to_bytes
def test_to_bytes():
    test0 = to_bytes('中国', 'iso-8859-1')
    #print(type(test0), test0)
    assert test0 == b'\xae\xb6\xa8\xa1'



# Generated at 2022-06-24 20:57:17.110359
# Unit test for function to_bytes
def test_to_bytes():
    # Note: It is important that we make sure we're testing a non-ASCII string
    # here otherwise the surrogateescape codec doesn't get tested in this test
    # case.
    bytes_0 = b'm\x86\x80\xaf}\xf2\x85.C\xea8\xa4t7u\x16\x90\xdf\xe2\x8f'
    str_0 = codecs.decode(bytes_0, 'utf-16-be', 'surrogateescape')
    var_0 = to_bytes(str_0)
    var_1 = to_bytes(str_0, 'utf-16-be')
    var_2 = to_bytes(str_0, 'utf-16-be', 'surrogateescape')

# Generated at 2022-06-24 20:57:24.643608
# Unit test for function to_native
def test_to_native():
    orig_str = "\u092f\u0939\u0932\u094b\u0917\u0939\u0940\u0928"
    orig = to_text(orig_str)
    assert orig == orig_str
    assert orig == u'यहलोगहीन'

    result = to_native(orig, errors='surrogate_or_strict')
    if PY3:
        assert result == orig_str and isinstance(result, str)
    else:
        assert result == orig_str.encode('utf-8').decode('utf-8', 'surrogateescape') and isinstance(result, text_type)

    result = to_native(orig_str, errors='surrogate_or_strict')

# Generated at 2022-06-24 20:57:32.220293
# Unit test for function jsonify
def test_jsonify():
    # Populate params
    data = b'm\x86\x80\xaf}\xf2\x85.C\xea8\xa4t7u\x16\x90\xdf\xe2\x8f'

    # Perform the operation
    result = jsonify(data)

    assert '"m\\x86\\x80\\xaf}\\xf2\\x85.C\\xea8\\xa4t7u\\x16\\x90\\xdf\\xe2\\x8f"' == result


# Generated at 2022-06-24 20:57:41.632155
# Unit test for function jsonify
def test_jsonify():
    data = '{"k0":"v0","k1":"v1"}'
    assert jsonify(data) == str_0


# Generated at 2022-06-24 20:57:45.073093
# Unit test for function to_native
def test_to_native():
    assert isinstance(to_native(u"\u2713", errors='surrogate_or_replace'), str)
    assert isinstance(to_native("\xe2\x9c\x93", errors='surrogate_or_replace'), str)


# Generated at 2022-06-24 20:57:54.906092
# Unit test for function jsonify

# Generated at 2022-06-24 20:57:55.655860
# Unit test for function to_bytes
def test_to_bytes():
    test_case_0()


# Generated at 2022-06-24 20:57:57.828466
# Unit test for function to_native
def test_to_native():
    # Test when object is string
    test_str = b"Rishikesh Agrawani"
    assert True == isinstance(test_str, str)
    assert True == isinstance(to_native(test_str), str)


# Generated at 2022-06-24 20:58:04.155819
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = '\x7f\x1a'
    var_0 = to_bytes(str_0, str_0)
    str_1 = '1I\'\x1d'
    var_1 = to_bytes(str_1, 'utf-8')
    str_2 = '\x14D'
    var_2 = to_bytes(str_2, str_0)
    str_3 = 'K\x1a'
    var_3 = to_bytes(str_3, str_2)
    str_4 = '\x1a\x1d\x13\x1d'
    var_4 = to_bytes(str_4)
    str_5 = '\x09\x19\x1d'

# Generated at 2022-06-24 20:58:07.010480
# Unit test for function to_native
def test_to_native():
    str_0 = '\x9c%_,\x1e\xa2A'
    var_0 = to_bytes(str_0, str_0)


# Generated at 2022-06-24 20:58:09.969934
# Unit test for function to_native
def test_to_native():
    assert to_native('foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'


# Generated at 2022-06-24 20:58:19.063689
# Unit test for function jsonify
def test_jsonify():
    b_0 = b'e\x96\x84\xa6\xbd\xc7\xfa\xc1\xb3\xfd\x9e\xaa\xcd'

# Generated at 2022-06-24 20:58:22.720185
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'vR\x0cak0'
    var_0 = to_bytes(str_0, str_0)
    if (var_0 != '\x03\x00\x00\x00'):
        raise RuntimeError('str_0 == "%s"' % var_0)
    pass


# Generated at 2022-06-24 20:58:34.219614
# Unit test for function jsonify
def test_jsonify():
    text_1 = to_bytes('vR\x0cak0')
    text_2 = to_text('vR\x0cak0')
    assert jsonify(text_1) == '"vR\\u000ck0"'
    assert jsonify(text_2) == '"vR\\u000ck0"'

if __name__ == "__main__":
    # Unit test case 1:
    # Function to_bytes(obj, encoding, errors)
    test_case_0()
    # Unit test case 2:
    # Function jsonify(data, **kwargs)
    test_jsonify()

# Generated at 2022-06-24 20:58:37.292875
# Unit test for function jsonify
def test_jsonify():
    test_data = {
        u'foo': u'1',
        u'bar': 2
    }
    test_encode = u'{"bar": 2, "foo": "1"}'
    assert(test_encode == jsonify(test_data))


# Generated at 2022-06-24 20:58:39.081797
# Unit test for function jsonify
def test_jsonify():
    print(jsonify({"a":5}))

if __name__ == "__main__":
    main()

# Generated at 2022-06-24 20:58:47.477175
# Unit test for function to_native
def test_to_native():
    str_0 = b'\xd2\x95\xe2\x80\x95\xd2\x94\xd2\x96\xd2\x80\xd2\x94\xe2\x80\x95\xd2\x94\xd2\x96\xd2\x80\xd2\x94\xd2\x96 \xd2\x94\xd2\x96\x1d'
    var_0 = to_native(str_0, str_0)


# Generated at 2022-06-24 20:58:57.322831
# Unit test for function jsonify
def test_jsonify():
    data = dict(
        a=1,
        b=u'foo',
        c=(u'a', 'b'),
        d=datetime.datetime(2014, 10, 22, 14, 0, 0),
        e=Set([1,2,3]),
        )
    jsoned = jsonify(data)
    exp = '{"a": 1, "c": ["a", "b"], "b": "foo", "e": [1, 2, 3], "d": "2014-10-22T14:00:00"}'
    if jsoned != exp:
        raise ValueError(
            'jsonify(%r) != %r (%r)' % (data, exp, jsoned)
        )



# Generated at 2022-06-24 20:59:07.460927
# Unit test for function jsonify
def test_jsonify():
    # The following examples will be used for testing.
    # jsonify(A)
    print(jsonify({"id": 12345, "name": "Sam", "likes": ["cake", "gaming"]}))
    print(jsonify({"id": 54321, "name": "Tom", "likes": ["cookies", "Python"]}))
    print(jsonify({"id": 12345, "name": "Sam", "likes": ["cake", "gaming"]}, indent=8))
    print(jsonify({"id": 54321, "name": "Tom", "likes": ["cookies", "Python"]}, sort_keys=True))
    print(jsonify({"id": 12345, "name": "Sam", "likes": ["cake", "gaming"]}, indent=8, sort_keys=True))

# Generated at 2022-06-24 20:59:15.253902
# Unit test for function to_bytes
def test_to_bytes():
    # Check we can fit in a single byte
    assert to_bytes('\xff', 'latin-1') == b'\xff'

    # Check we can fit in two bytes
    assert to_bytes('\u0100', 'utf-16') == b'\x00\x01'

    # Check we can fit in three bytes
    assert to_bytes('\u0800', 'utf-8') == b'\xe0\xa0\x80'

    # Check we can't fit in three bytes
    try:
        to_bytes('\U00010000', 'utf-8')
    except UnicodeEncodeError:
        pass
    else:
        assert False, 'Expected UnicodeEncodeError'

    # Check that we can surrogateescape out the nonencodable characters and
    # get back the original string

# Generated at 2022-06-24 20:59:16.551282
# Unit test for function to_bytes
def test_to_bytes():
    func_name = 'to_bytes'
    test_case_0()

# Generated at 2022-06-24 20:59:23.917230
# Unit test for function jsonify
def test_jsonify():
    data = {}
    data["a"] = "a"
    data["b"] = 1234
    data["c"] = 3.14
    data["d"] = [ "this", "that", "the other" ]
    data["e"] = { "name": "Smith", "age": 100, "children": [ "John", "Jane", "Jill" ] }

    # Assert that the json conversion succeeds
    jsonify(data)

    # Assert that the json conversion succeeds when unicode data are present
    data[u"a"] = u"\u0410\u0411\u0412"
    jsonify(data)

    # Assert that the json conversion succeeds when unicode data are present in the inner dictionary

# Generated at 2022-06-24 20:59:26.549767
# Unit test for function to_native
def test_to_native():
    var = 'string'
    str_0 = to_native(var)
    assert str_0 == b'string'


# Generated at 2022-06-24 20:59:39.091581
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == b'foo'
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == u'foo'
    # Python3
    assert to_native(1) == u'1'
    assert to_native(1.02) == u'1.02'
    assert (to_native(datetime.datetime.now()) ==
            unicode(datetime.datetime.now()))
    assert to_native([u'foo', u'bar']) == u"['foo', 'bar']"


# Generated at 2022-06-24 20:59:43.497190
# Unit test for function to_native
def test_to_native():
    byte_value = b'f\x9c'
    unicode_value = u'\ufffd'
    str_value = ' '.encode('UTF-8').decode('UTF-8')

    assert to_native(byte_value) == 'f\x9c'
    assert to_native(unicode_value) == u'\ufffd'
    assert to_native(str_value) == str_value


# Generated at 2022-06-24 20:59:49.233091
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = '\x00'
    str_1 = '\x08'
    str_2 = '\x87'
    str_3 = '\x96'
    str_4 = ''
    str_5 = 'u'
    str_6 = '\x16'
    str_7 = '\x19'
    str_8 = '\x1c'
    str_9 = '\x12'

    var_0 = to_bytes(str_0, str_5 + str_5 + '\xfc' + str_5 + str_5 + str_5 + str_5 + str_5 + str_5)

# Generated at 2022-06-24 20:59:58.749187
# Unit test for function to_native
def test_to_native():
    str_0 = 'vR\x0cak0'
    var_0 = to_bytes(str_0, str_0)
    str_1 = 'vR\x0cak0'
    str_2 = 'vR\x0cak0'
    var_1 = to_bytes(str_1, str_2)
    str_3 = 'vR\x0cak0'
    list_0 = ['vR\x0cak0', 'vR\x0cak0', 'vR\x0cak0', 'vR\x0cak0', 'vR\x0cak0']
    dict_0 = dict(zip(list_0, list_0))
    str_4 = 'vR\x0cak0'

# Generated at 2022-06-24 21:00:07.000961
# Unit test for function jsonify

# Generated at 2022-06-24 21:00:10.723532
# Unit test for function jsonify
def test_jsonify():

    # var = jsonify(data)
    assert True


# Generated at 2022-06-24 21:00:14.676183
# Unit test for function to_native
def test_to_native():
    test_list = [(u'test', u'test'), ('test', 'test'), (1, '1'), (1.1, '1.1'), ({"key": "val"}, {"key": "val"})]
    for item in test_list:
        assert to_native(item[0]) == item[1]
    

# Generated at 2022-06-24 21:00:20.713267
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes("test") == b'test'
    # test_bytes = b'\xfe\xff\x00t\x00e\x00s\x00t\x00'
    # assert to_bytes("test", encoding='utf-16be') == test_bytes
    # assert to_bytes("test".encode("utf-16be")) == test_bytes
    # assert to_bytes("test".encode("utf-16be"), encoding='utf-16be') == test_bytes
    # assert to_bytes("test", encoding='utf-16be', errors='replace') == test_bytes.replace(b't', b'?')
    # assert to_bytes("test", encoding='utf-16be', errors='strict') == test_bytes
    # assert to_bytes("test".encode("utf-16be"), encoding

# Generated at 2022-06-24 21:00:27.408622
# Unit test for function to_native
def test_to_native():
    assert to_native('abc') == 'abc'
    assert to_native(to_text('abc')) == 'abc'
    assert to_native(b'abc') == 'abc'
    assert to_native(to_bytes('abc'), errors='surrogate_or_strict') == 'abc'


# Generated at 2022-06-24 21:00:32.570592
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('vR\x0cak0', 'utf-8') == b'vR\x0cak0'
    assert to_bytes('\x1d') == b'\x1d'
    assert to_bytes('o\x01y,\x1bv') == b'o\x01y,\x1bv'
    assert to_bytes('\x1d') == b'\x1d'
    assert to_bytes(b'\x16', encoding='utf-8') == b'\x16'
    assert to_bytes('\x07\x13vv', 'utf-8') == b'\x07\x13vv'

# Generated at 2022-06-24 21:00:40.438814
# Unit test for function jsonify
def test_jsonify():
    # Test Exception(s)
    try:
        test_case_0()
    except:
        raise Exception("Test Failed!")




# Generated at 2022-06-24 21:00:42.215528
# Unit test for function jsonify
def test_jsonify():

    # Verify that jsonify() returns bytes
    assert isinstance(jsonify([]) , str)


# Generated at 2022-06-24 21:00:46.043402
# Unit test for function jsonify
def test_jsonify():
    str_0 = 'vR\x0cak0'
    var_0 = jsonify(str_0)

# Generated at 2022-06-24 21:00:52.545827
# Unit test for function to_bytes
def test_to_bytes():
    assert isinstance(to_bytes('\u2019'), binary_type)
    assert isinstance(to_bytes(u'\u2019'), binary_type)
    assert isinstance(to_bytes(b'\xe2\x80\x99'), binary_type)
    assert isinstance(to_bytes(1), binary_type)
    assert isinstance(to_bytes(1.0), binary_type)
    assert isinstance(to_bytes({}), binary_type)
    assert isinstance(to_bytes([]), binary_type)
    assert isinstance(to_bytes(()), binary_type)


# Generated at 2022-06-24 21:01:04.539627
# Unit test for function jsonify
def test_jsonify():
    import json
    import jsonschema

    # Test with positional args only
    expected = '{"a": 1, "b": 2}'
    ret = jsonify({u"a": u"1", u"b": u"2"})
    assert(ret == expected)
    # Test with named args
    expected = '[{"a": 1, "b": 2, "c": 3}, {"d": 4, "e": 5, "f": 6}, {"g": 7, "h": 8, "i": 9}, {"j": 10, "k": 11, "l": 12}]'

# Generated at 2022-06-24 21:01:09.482171
# Unit test for function jsonify
def test_jsonify():
    s = u'{"foo": "bar"}'

    assert jsonify(json.loads(s)) == s

    s = u'{"foo": null}'

    assert jsonify(json.loads(s)) == s


# Generated at 2022-06-24 21:01:14.087234
# Unit test for function jsonify
def test_jsonify():
    input_0 = {'a': 'a', 'b': 'b'}
    expected_0 = '{"a": "a", "b": "b"}'
    assert jsonify(input_0) == expected_0

if __name__ == "__main__":
    for i in range(0):
        test_case_0()
    test_jsonify()

# Generated at 2022-06-24 21:01:17.101626
# Unit test for function jsonify
def test_jsonify():
    data_0 = {'ak0': 'vR\x0cak0'}
    result_0 = jsonify(data_0, separators=(',', ':'))
    assert result_0 == '{"ak0": "vR\nak0"}'


# Generated at 2022-06-24 21:01:22.481172
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'PvH'
    var_1 = to_bytes(str_0, str_0)


# Generated at 2022-06-24 21:01:25.688587
# Unit test for function to_native
def test_to_native():

    # Test 1:  Passing no argument
    # Defect:  The function crashes with a TypeError
    # Workaround:  Pass an argument to the function
    to_native("")


# Generated at 2022-06-24 21:01:37.868447
# Unit test for function jsonify
def test_jsonify():
    var_1 = {}
    var_2 = jsonify(var_1)
    assert var_2 == '{}'
    var_3 = {'key_1': 'val_1'}
    var_4 = jsonify(var_3)
    assert var_4 == '{"key_1": "val_1"}'
    var_5 = {'\x00': b'val_1'}
    var_6 = jsonify(var_5)
    assert var_6 == '{"\\u0000": "dmlhXzE="}'
    var_7 = {'\x00': u'val_1'}
    var_8 = jsonify(var_7)
    assert var_8 == '{"\\u0000": "val_1"}'

# Generated at 2022-06-24 21:01:41.836440
# Unit test for function to_native
def test_to_native():
    str_0 = 'y5TP\xe5M\xf5\x02\xd5\x7f\x03\x0f'
    var_0 = to_bytes(str_0, 'ASCII')


# Generated at 2022-06-24 21:01:51.485688
# Unit test for function jsonify
def test_jsonify():
    print('Testing jsonify()')
    data = {
        'a': 'a',
        'b': b'b',
        'c': 1,
        'd': [1, 2, 3],
        'e': [b'a', b'b', b'c', b'd'],
        'f': {
            'f1': 'a',
            'f2': b'b',
            'f3': 1,
            'f4': [b'a', b'b', b'c', b'd'],
        }
    }
    json_str = jsonify(data)
    print(json_str)
    assert json_str == json.dumps(data, default=_json_encode_fallback)


# Generated at 2022-06-24 21:02:01.579400
# Unit test for function to_bytes
def test_to_bytes():
    out = to_bytes('\u043f\u0440\u0438\u0432\u0435\u0442', 'utf-8')
    # Note that we're not testing what the correct output is.  Just that it
    # runs without error
    assert isinstance(out, binary_type)

    # No error handler specified
    out = to_bytes('\u043f\u0440\u0438\u0432\u0435\u0442', 'ascii')
    assert isinstance(out, binary_type)
    # Note that we're not testing what the correct output is.  Just that it
    # runs without error

    # Default error handler

# Generated at 2022-06-24 21:02:08.015604
# Unit test for function jsonify
def test_jsonify():
    data = dict(complex_list=[u'\u0141\u0104\u017c'], complex_dict=dict(complex_key=u'\u0141\u0104\u017c'))
    assert jsonify(data) == '{"complex_dict": {"complex_key": "\\u0141\\u0104\\u017c"}, "complex_list": ["\\u0141\\u0104\\u017c"]}'


# Generated at 2022-06-24 21:02:10.078457
# Unit test for function jsonify
def test_jsonify():
    data = {"test":"test"}
    # Should raise no error
    jsonify(data)


# Generated at 2022-06-24 21:02:16.089070
# Unit test for function to_native
def test_to_native():
    """Test function to_native
    Test text and binary string convertion functions
    """
    str_0 = "abcde"
    str_1 = "abcde"
    assert to_native(str_0, "utf-8") == "abcde"
    assert to_native(str_1, "utf-8") == "abcde"



# Generated at 2022-06-24 21:02:17.037132
# Unit test for function jsonify
def test_jsonify():
    jsonify('vR\x0cak0')

# Generated at 2022-06-24 21:02:22.946950
# Unit test for function jsonify
def test_jsonify():
    n = 'name'
    v = 'value'
    str_0 = '='.join((n, v))
    var_0 = to_bytes(str_0, str_0)
    foo = {n: v}
    bar = json.dumps(dict(foo, encoding=str_0, default=_json_encode_fallback), default=_json_encode_fallback)
    assert bar == jsonify(foo)


# Generated at 2022-06-24 21:02:32.703552
# Unit test for function to_bytes
def test_to_bytes():
    print('Testing function to_bytes...')
    # check to_bytes with multiple code paths
    # str with surrogates that can be re-encoded
    str_0 = 'vR\x0cak0'
    var_0 = to_bytes(str_0, str_0)
    assert var_0 == b'vR\x0cak0'
    # bytes with surrogates that can be re-encoded
    bytes_0 = bytearray(3)
    bytes_0[0] = 122
    bytes_0[1] = 82
    bytes_0[2] = 30
    var_1 = to_bytes(bytes_0, str_0)
    assert var_1 == b'vR\x0cak0'
    # bytes with surrogate that cannot be re-encoded

# Generated at 2022-06-24 21:02:47.792808
# Unit test for function to_bytes
def test_to_bytes():
    check_for_surrogates = False
    nonstring = 'simplerepr'
    encoding = 'utf-8'
    errors = 'surrogate_or_replace'

    # Simple string and unicode representations
    # Numeric types
    assert to_bytes(0) == b'0'
    assert to_bytes(0.0) == b'0.0'
    assert to_bytes(1.0 + 2.0j) == b'(1+2j)'
    assert to_bytes(float('inf')) == b'inf'
    assert to_bytes(float('-inf')) == b'-inf'
    assert to_bytes(float('nan')) == b'nan'

    # Collections
    assert to_bytes([1, 2, 3]) == b'[1, 2, 3]'
    assert to_bytes

# Generated at 2022-06-24 21:02:56.782510
# Unit test for function to_native
def test_to_native():
    assert to_native(True) == 'True'
    assert to_native(False) == 'False'
    assert to_native('foo') == 'foo'
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'\u1234') == u'\u1234'
    assert to_native(u'\u1234'.encode('utf-8')) == u'\u1234'
    assert to_native(u'\u1234'.encode('utf-16-le')) == u'\u1234'
    assert to_native(u'\u1234'.encode('iso-8859-1')) == '?'

# Generated at 2022-06-24 21:03:05.202405
# Unit test for function to_native
def test_to_native():
    # Generate some data for test
    import string
    import random
    str_data = ''.join(random.choice(string.ascii_lowercase) for _ in range(16))
    print('Generated string to convert: "{0}"'.format(str_data))
    if PY3:
        str_unicode = str_data
        str_bytes = bytes(str_data, 'utf-8')
    else:
        str_unicode = unicode(str_data, 'utf-8')
        str_bytes = str_data
    print('Generated unicode to convert: "{0}"'.format(str_unicode))
    print('Generated bytes to convert: "{0}"'.format(str_bytes))
    # Create the object to test

# Generated at 2022-06-24 21:03:10.714770
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'N\x1e\xc8\xd7\xda'  # 'N\x1e\xc8\xd7\xda'
    var_0 = to_bytes(str_0, str_0)
    str_1 = 'ss\xa9\x93'  # 'ss\xa9\x93'
    var_1 = to_bytes(str_1, str_1)
    str_2 = '1t\xd3\xdd\xca\xe7\x8a'  # '1t\xd3\xdd\xca\xe7\x8a'
    var_2 = to_bytes(str_2, str_2)
    str_3 = '6\xec\xe7\xbf'  # '6\xec\xe7\xbf'

# Generated at 2022-06-24 21:03:18.572140
# Unit test for function to_native
def test_to_native():
    arg_0 = '\x1f\x80\x00\x0c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-24 21:03:25.579161
# Unit test for function jsonify
def test_jsonify():
    str_0 = '\x98\xcd'
    set_0 = {str_0}
    dict_0 = {to_text('\x00\x92\x9c\xac\xb7\x01\x98\xcd'): set_0}
    data = dict_0
    assert jsonify(data) == '{"\\udc00\\udc92\\udc9c\\udcac\\udcb7\\x01\\x98\\xcd": ["\\x98\\xcd"]}'



# Generated at 2022-06-24 21:03:32.811081
# Unit test for function to_native
def test_to_native():
    assert to_native('test') == 'test'
    assert isinstance(to_native('test'), text_type)

    assert to_native(b'test') == 'test'
    assert isinstance(to_native(b'test'), text_type)

    assert to_native(u'test') == 'test'
    assert isinstance(to_native(u'test'), text_type)

    assert to_native(b'bytes\xff') == 'bytes\xff'
    assert isinstance(to_native(b'bytes\xff'), text_type)

    assert to_native(u'unicode\u1234') == 'unicode\u1234'
    assert isinstance(to_native(u'unicode\u1234'), text_type)


# Generated at 2022-06-24 21:03:37.793782
# Unit test for function to_native
def test_to_native():
    str_0 = 'vR\x0cak0'
    var_0 = to_bytes(str_0, str_0)
    var_1 =to_bytes(str_0, str_0)


# Generated at 2022-06-24 21:03:47.244258
# Unit test for function jsonify

# Generated at 2022-06-24 21:03:50.660814
# Unit test for function to_bytes
def test_to_bytes():
    print('Testing to_bytes...')
    test_case_0()
    print('to_bytes passed all tests')

if __name__ == '__main__':
    test_to_bytes()

# Generated at 2022-06-24 21:04:12.554495
# Unit test for function to_bytes
def test_to_bytes():
    var_0 = to_bytes()
    str_0 = 'vR\x0cak0'
    var_1 = to_bytes(str_0, str_0)
    var_2 = to_bytes()
    str_1 = '0'
    var_3 = to_bytes(str_1, str_1)
    var_4 = to_bytes()
    str_2 = 'eic\t'
    var_5 = to_bytes(str_2, str_2)
    var_6 = to_bytes()
    str_3 = '!'
    var_7 = to_bytes(str_3, str_3)
    var_8 = to_bytes()
    str_4 = '0'
    var_9 = to_bytes(str_4, str_4)

# Generated at 2022-06-24 21:04:15.636303
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'vR\x0cak0'
    var_0 = to_bytes(str_0, str_0)

if __name__ == "__main__":
    test_case_0()
    test_to_bytes()

# Generated at 2022-06-24 21:04:20.062946
# Unit test for function jsonify
def test_jsonify():
    var_0 = jsonify(to_bytes('\x0c', '\x0c'))
    assert var_0 == '"\u000c"'


# Generated at 2022-06-24 21:04:22.223161
# Unit test for function to_native
def test_to_native():
    result = to_native('int')
    assert result == 'int'
    assert isinstance(result, str)


# Generated at 2022-06-24 21:04:26.006964
# Unit test for function to_native
def test_to_native():
    assert to_native(b'abc') == b'abc'
    assert to_native('abc') == 'abc'
    if PY3:
        assert to_native(u'abc') == 'abc'
    else:
        assert to_native(u'abc') == u'abc'


# Generated at 2022-06-24 21:04:33.820795
# Unit test for function to_native
def test_to_native():

    print('to_native')
    # Test with no arguments
    var_0 = to_native()
    assert var_0 == str()
    assert isinstance(var_0, str)

    # Test with an argument
    t = ('a', 'b', 'c', 'd', 'e')
    var_1 = to_native(t)
    for value in t:
        assert value in var_1
    assert isinstance(var_1, str)



# Generated at 2022-06-24 21:04:42.680927
# Unit test for function jsonify
def test_jsonify():
    data = {
        'unicode_str': to_text(u'\u2713', errors='surrogate_or_strict'),
        'bytestr': to_bytes(u'Hello\xc2\xb5', errors='surrogate_or_strict'),
        'int': 42,
        'float': 4.2,
        'list': [1, 2, 3],
        'dict': {'A': 1, 'B': 2}
    }

    assert jsonify(data).encode('utf-8') == b'{"dict": {"A": 1, "B": 2}, "float": 4.2, "bytestr": "Hello\\u00b5", "int": 42, "list": [1, 2, 3], "unicode_str": "\\u2713"}'

    # The data we receive

# Generated at 2022-06-24 21:04:43.266910
# Unit test for function to_native
def test_to_native():
    pass


# Generated at 2022-06-24 21:04:52.794490
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'F\x8e\x9f\xf4n\x8d\x8d\xa4\xbc\xd2\xb4\xf8\x9a\xce\xfa\x8d\x02\x81/\xef\xb6\xeb\x9bl\xc9\xee'
    var_0 = to_bytes(str_0, str_0)
    assert var_0 == b'F\x8e\x9f\xf4n\x8d\x8d\xa4\xbc\xd2\xb4\xf8\x9a\xce\xfa\x8d\x02\x81/\xef\xb6\xeb\x9bl\xc9\xee', 'to_bytes did not return the expected value'



# Generated at 2022-06-24 21:05:02.245747
# Unit test for function jsonify
def test_jsonify():
    assert to_bytes(u'hello') == b'hello'
    assert to_text(b'hello') == 'hello'
    assert to_text(b'\x80\x80') == '\ufffd\ufffd'
    assert to_text(1) == '1'
    assert to_bytes(1) == b'1'
    assert to_bytes(None, 'utf-8', 'surrogateescape') == b''
    assert to_bytes(None, 'utf-8', 'surrogate_or_strict') == b''
    assert to_bytes(None, 'utf-8', 'surrogate_then_replace') == b''
    assert to_bytes(None, 'utf-8', 'surrogate_or_replace') == b''

# Generated at 2022-06-24 21:05:30.316414
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'V8I0\x0b\x07\x0c\x0b'
    str_1 = '\x0b\x07\x0b\x0b\x0c'

# Generated at 2022-06-24 21:05:35.552679
# Unit test for function to_native
def test_to_native():
    data = {'a': 1, 'b': 'two', 'c': [3, 3.0, 'four'], 'd': {'five': 5}}
    text_data = '{"a": 1, "b": "two", "c": [3, 3.0, "four"], "d": {"five": 5}}'
    binary_data = b'{"a": 1, "b": "two", "c": [3, 3.0, "four"], "d": {"five": 5}}'
    text_data_utf16 = '{\xa1: 1, \xa1: "two", \xa1: [3, 3.0, "four"], \xa1: {\xa1: 5}}'

# Generated at 2022-06-24 21:05:38.567294
# Unit test for function to_native
def test_to_native():
    # Test #0
    try:
        test_case_0()
    except Exception as e:
        print('Error:', e)


# Functions to test serialization.

# Generated at 2022-06-24 21:05:47.029918
# Unit test for function to_native
def test_to_native():
    # Need to mock the sys.stdin object, which is used in to_native.
    # Since there's no way to patch a module imported in the global module,
    # we're going to create a mock stdin object and pass it as parameter.
    # This is also done in order to not change the global state of sys.stdin.
    class MockStdin(object):
        def __init__(self, encoding):
            self.encoding = encoding

        def isatty(self):
            return True

    class TestToNative(object):
        def __init__(self, stdin_encoding=None, encoding=None):
            self.stdin_encoding = stdin_encoding
            self.encoding = encoding

    test = TestToNative()

    # Create the object and return it
    mock_stdin = MockStdin

# Generated at 2022-06-24 21:05:54.071134
# Unit test for function jsonify
def test_jsonify():
    data = {
        "data":{
                "account":"eosio",
                "name":"transfer",
                "authorization":[{"actor":"pmsc.vip","permission":"active"}],"data":"60a681da5937501000000000004454f5300000000d744f6e6c79206973207461626c65"},
        "hex_data":"60a681155937501000000000004454f5300000000d744f6e6c79206973207461626c65"
        }
    print(jsonify(data))

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:06:01.200795
# Unit test for function to_native
def test_to_native():
    assert to_native(b'\xe1\x88\xb4') == '\u1234'
    assert to_native(u'\u1234') == '\u1234'
    assert to_native(b'\xc3\xa1\x88\xb4') == '\u1234'
    assert to_native(u'\u1234', encoding='ascii', errors='surrogateescape') == '\udcc4'
    assert to_native(b'\xe1\x88\xb4', encoding='ascii', errors='surrogateescape') == '\udcc4'
    assert to_native(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == '\udcc4'

# Generated at 2022-06-24 21:06:08.888368
# Unit test for function jsonify
def test_jsonify():
    test_data = {
        'string': 'string',
        'unicode': u'unicode',
        'datetime': datetime.datetime.utcnow()
    }
    test_json = jsonify(test_data)
    test_dict = json.loads(test_json)
    assert test_dict['unicode'] == test_dict['string']
    assert test_dict['datetime'] == test_data['datetime'].isoformat()


# Generated at 2022-06-24 21:06:15.415096
# Unit test for function jsonify
def test_jsonify():
    dict_0 = dict(key_0='value_0')
    # Verify jsonify returns a bytes type
    assert isinstance(jsonify(dict_0), bytes)
