

# Generated at 2022-06-24 20:56:33.081256
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u043f\u044b\u0442\u0430\u043d\u0438\u044f', 'utf-8') == b'\xd0\xbf\xd1\x8b\xd1\x82\xd0\xb0\xd0\xbd\xd0\xb8\xd1\x8f'
    assert to_bytes(u'\u043f\u044b\u0442\u0430\u043d\u0438\u044f', 'utf-8', 'surrogateescape') == b'\xd0\xbf\xd1\x8b\xd1\x82\xd0\xb0\xd0\xbd\xd0\xb8\xd1\x8f'

# Generated at 2022-06-24 20:56:35.163072
# Unit test for function jsonify
def test_jsonify():
    var_0 = jsonify('\u16a0\u3055\u4e00\u76ee\u9ed2\u3055\u307f')
    print(var_0)



# Generated at 2022-06-24 20:56:39.691109
# Unit test for function jsonify
def test_jsonify():
    # type: () -> None
    """Test module with pytest."""
    # Arrange
    bytes_0 = b'\xfa/qj\xef\x8fM\x9ek\xffelFV\xd5\xf3'
    # Act
    var_1 = jsonify(bytes_0)
    # Assert
    if var_1 != '"\\udcfa\\udf2fqj\\ud8ef\\udc8fM\\udc9ek\\uddffelFV\\udd5\\udd3"':
        raise Exception('Test Failed')



# Generated at 2022-06-24 20:56:43.668810
# Unit test for function to_bytes
def test_to_bytes():
    g_0 = '\xfa/qj\xef\x8fM\x9ek\xffelFV\xd5\xf3'
    var_0 = to_bytes(g_0)
    print(var_0)


# Generated at 2022-06-24 20:56:45.284126
# Unit test for function jsonify
def test_jsonify():
    test_case_0()


# Unit test: Generate the input args, call the function and check whether the expected result is achieved

# Generated at 2022-06-24 20:56:51.004552
# Unit test for function jsonify
def test_jsonify():
    bytes_0 = b'\xfa/qj\xef\x8fM\x9ek\xffelFV\xd5\xf3'
    var_0 = jsonify(bytes_0)
    print(var_0)

# Unit test runner

# Generated at 2022-06-24 20:57:03.131266
# Unit test for function to_bytes
def test_to_bytes():
    # Test with correct data
    bytes_0 = b'\xfa/qj\xef\x8fM\x9ek\xffelFV\xd5\xf3'
    result_0 = to_bytes(bytes_0, 'utf-8', 'strict')
    # Should be True
    assert(result_0 == bytes_0)

    bytes_1 = b'\xfa/qj\xef\x8fM\x9ek\xffelFV\xd5\xf3'
    result_1 = to_bytes(bytes_1, 'utf-8', 'strict')
    # Should be True
    assert(result_1 == bytes_1)


# Generated at 2022-06-24 20:57:14.402375
# Unit test for function to_bytes
def test_to_bytes():
    # Expected values
    bytes_0 = b'\xfa/qj\xef\x8fM\x9ek\xffelFV\xd5\xf3'
    bytes_1 = b''
    bytes_2 = b'\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF'
    bytes_3 = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    bytes_4 = b'\x1D\xCD\xB3\x7C\xF7\xD2\x08\xE1'
    bytes_5 = b'\x1D\x02\xDD\x7C\xF7\xD2\x08\xE1'
    bytes_6

# Generated at 2022-06-24 20:57:18.213489
# Unit test for function to_bytes
def test_to_bytes():
    result = to_bytes(u'\xfa/qj\xef\x8fM\x9ek\xffelFV\xd5\xf3', 'ASCII', 'surrogate_or_replace')
    assert result == b'?'

test_to_bytes()

# Generated at 2022-06-24 20:57:22.764451
# Unit test for function to_native
def test_to_native():
    bytes_0 = b'\xfa/qj\xef\x8fM\x9ek\xffelFV\xd5\xf3'
    text_0 = u'MA-F0\udb10K\U000f6ef5'
    int_0 = 1337
    float_0 = 13.37
    bool_0 = True

    var_0 = to_native(bytes_0, 'utf-8')
    var_1 = to_native(text_0, 'utf-8')
    var_2 = to_native(int_0, 'utf-8')
    var_3 = to_native(float_0, 'utf-8')
    var_4 = to_native(bool_0, 'utf-8')

# Generated at 2022-06-24 20:57:40.357220
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'hello world'
    expected = b'hello world'
    result = to_bytes(str_0)
    result_1 = to_bytes(result)
    assert(expected == result and result_1 == result)

try:
    unicode_0 = unicode
except NameError:
    pass
else:
    str_1 = unicode_0('hello world')
    expected = b'hello world'
    result = to_bytes(str_1)
    result_1 = to_bytes(result)
    assert(expected == result and result_1 == result)

try:
    unicode_0 = unicode
except NameError:
    pass
else:
    str_2 = unicode_0('hello world')
    expected = b'hello world'

# Generated at 2022-06-24 20:57:44.711471
# Unit test for function jsonify
def test_jsonify():
    data = b'\xfa/qj\xef\x8fM\x9ek\xffelFV\xd5\xf3'
    expected = '"\\u00fa\\/qj\\u00ef\\u008fM\\u009ek\\ufffelFV\\ud5f3"'
    result = jsonify(data)
    assert result == expected


# Generated at 2022-06-24 20:57:54.931427
# Unit test for function to_native
def test_to_native():
    # More python3 tests
    assert to_native(text_type(u'foo')) == u'foo'
    assert to_native(binary_type(b'foo')) == b'foo'
    assert to_native(0) == 0
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'привет'.encode('utf-8')) == u'привет'
    assert to_native(u'안녕'.encode('utf-8')) == u'안녕'

# Generated at 2022-06-24 20:57:59.138687
# Unit test for function to_native
def test_to_native():

    def _test_native(obj, encoding='utf-8'):

        _test_to_native_dict(obj, encoding)
        _test_to_native_list(obj, encoding)
        _test_to_native_tuple(obj, encoding)
        _test_to_native_set(obj, encoding)
    
    def _test_to_native_dict(obj, encoding):
        test_dict = {}
        test_dict[u'unicode_b_key'] = u'unicode\u20ac'
        test_dict[u'unicode_a_key'] = u'unicode\u20ad'
        test_dict[b'bytes_a_key'] = b'bytes \xc2\xa2'

# Generated at 2022-06-24 20:58:04.870412
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(True) == 'true'
    assert jsonify(False) == 'false'
    assert jsonify(None) == 'null'
    assert jsonify(1) == '1'
    assert jsonify(0) == '0'
    assert jsonify(-1) == '-1'
    assert jsonify(1.0) == '1.0'
    assert jsonify(0.0) == '0.0'
    assert jsonify(-1.0) == '-1.0'
    assert jsonify('') == '""'
    assert jsonify('foo') == '"foo"'
    assert jsonify('f\"oo') == '"foo"'
    assert jsonify(u'') == '""'
    assert jsonify(u'foo') == '"foo"'

# Generated at 2022-06-24 20:58:13.063781
# Unit test for function jsonify
def test_jsonify():
    for encoding in ("utf-8", "latin-1"):
        try:
            return json.dumps(data, encoding=encoding, default=_json_encode_fallback, **kwargs)
        # Old systems using old simplejson module does not support encoding keyword.
        except TypeError:
            try:
                new_data = container_to_text(data, encoding=encoding)
            except UnicodeDecodeError:
                continue
            return json.dumps(new_data, default=_json_encode_fallback, **kwargs)
        except UnicodeDecodeError:
            continue
    raise UnicodeError('Invalid unicode encoding encountered')


# Generated at 2022-06-24 20:58:17.548388
# Unit test for function to_native
def test_to_native():
    python_2_data = [
        (u'foo', 'foo'),
        (b'foo', 'foo'),
        (1, 1),
    ]
    python_3_data = [
        ('foo', 'foo'),
        (b'foo', 'foo'),
        (1, 1),
    ]

    for i, (in_, exp) in enumerate(python_3_data if PY3 else python_2_data):
        assert to_native(in_) == exp


# Generated at 2022-06-24 20:58:22.603913
# Unit test for function to_bytes
def test_to_bytes():
    assert ['o7\xcc\x9c\x9d\xf6Y\xf6\x15\xb7'] == to_bytes("\x04J\x1b\xbf\x0b\x96\xde\x01\xd4\xb4\xfa\x1f\x04\x0f\xcf\x1c\x1d\x0f\xfb\x11\x08\xb0#\x15\t")

# Generated at 2022-06-24 20:58:30.947678
# Unit test for function to_native
def test_to_native():
    assert to_native('test') == 'test'
    assert to_native(b'test') == 'test'
    #test_case_0()
    assert to_native(['test']) == ['test']
    assert to_native(('test',)) == ('test',)
    assert to_native({'test': 'test'}) == {'test': 'test'}
    assert to_native(True) == True
    assert to_native(False) == False
    assert to_native(0) == 0
    assert to_native(1) == 1
    assert to_native(1.0) == 1.0
    assert to_native(int('1')) == 1
    assert to_native(float('1')) == 1.0
    assert to_native(str) == str
    assert to_native(bytes)

# Generated at 2022-06-24 20:58:38.796527
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils import _json_compat as json_compat
    ansible_json_dump = json_compat.dump
    json_compat.dump = test_case_0

# Generated at 2022-06-24 20:58:55.574727
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'ú/qjï\x8fM\x9ekÿelFVÕó'
    var_0 = to_bytes(str_0, str_0, str_0)

test_case_0()
test_to_bytes()

# Generated at 2022-06-24 20:58:57.698283
# Unit test for function to_native
def test_to_native():
    var_str = 'hello'
    assert to_native(var_str) == var_str


# Generated at 2022-06-24 20:58:59.610921
# Unit test for function to_native
def test_to_native():
    assert to_native(u'oh hello') == 'oh hello'
    assert to_native('oh hello') == 'oh hello'


# Generated at 2022-06-24 20:59:10.913881
# Unit test for function jsonify
def test_jsonify():
    str_10 = '\x1f\x1b3\x1b\x17X\x1cM\x19\x1b\x1e8\v\x1d\x1e\x02\x14\x12\x1e\x1b\x03.÷\x03\x07\x1a\x1a\x1bÌ\x1c¿\x01\x1b\x02\x18\x07\x01\x1e\x1d\x1c\x01\x03\x1b\x14\x1f\x1b\x1b\x1e\x1d\x02\x01\x07\x1d\x1a'

# Generated at 2022-06-24 20:59:20.790081
# Unit test for function jsonify
def test_jsonify():
    for nonstring in ('simplerepr', 'passthru', 'empty', 'strict'):
        for obj in (u'abc', b'abc'):
            # Verify identity (to_text only)
            assert jsonify(obj, nonstring=nonstring) == obj
        for obj in (2, 3.5, object()):
            # Verify surrogateescape is used if available and object is passed in
            if HAS_SURROGATEESCAPE and nonstring == 'simplerepr':
                assert isinstance(jsonify(obj, nonstring=nonstring), binary_type)
            elif nonstring == 'passthru':
                assert jsonify(obj, nonstring=nonstring) is obj
            elif nonstring == 'empty':
                assert jsonify(obj, nonstring=nonstring) == ''

# Generated at 2022-06-24 20:59:30.183991
# Unit test for function jsonify
def test_jsonify():
    data = {'foo': ['bar', {'baz': 'qux'}],
            'meep': 'moop',
            'list': ['foo', {'bar': ['baz', None, 1.0, 2]}],
            'empty_list': [],
            'empty_dict': {},
            'int': 42,
            'float': 3.14159265,
            'bool': False,
            'none': None,
            'set():3': set([3]),
            'set():1,2,3': set([1, 2, 3])}
    data_str = jsonify(data)
    data2 = json.loads(data_str)
    assert data == data2


# Generated at 2022-06-24 20:59:31.452866
# Unit test for function to_bytes
def test_to_bytes():

    # assert str_0 == var_0
    test_case_0()



# Generated at 2022-06-24 20:59:33.380382
# Unit test for function to_native
def test_to_native():
    assert to_native(str_0, str_0, str_0) == str_0


# Generated at 2022-06-24 20:59:34.997021
# Unit test for function to_native
def test_to_native():
    assert to_native('abc') == 'abc'


# Generated at 2022-06-24 20:59:39.968554
# Unit test for function to_native
def test_to_native():
    str_1 = 'ú/qjïÏMÖküelFVÕó'
    var_1 = to_native(str_1)
    var_2 = to_native(var_1, str_1, str_1)
    var_3 = to_native(var_2, None, str_1)
    var_4 = to_native(var_3, str_1, None)
    

# Generated at 2022-06-24 20:59:58.361204
# Unit test for function to_bytes
def test_to_bytes():
    var_1 = to_bytes('some string')
    if isinstance(var_1, text_type):
        print('Failed to encode string to bytes')
        return
    try:
        var_2 = to_bytes(b'some bytes', nonstring='passthru')
        if isinstance(var_2, text_type):
            print('Failed to passthru bytes')
            return
    except TypeError:
        print('Failed to passthru bytes')
        return
    var_3 = to_bytes(b'some bytes', nonstring='simplerepr')
    if isinstance(var_3, text_type):
        print('Failed to encode bytes to bytes using simplerepr')
        return

# Generated at 2022-06-24 21:00:06.850850
# Unit test for function jsonify
def test_jsonify():
    # Test with simple_repr
    data = {'hello': 'world', 'number': 42, 'bool': True}
    assert jsonify(data) == '{"hello": "world", "number": 42, "bool": true}'

    # Test with collection
    data = {'hello': 'world', 'number': 42, 'bool': True, 'set': set({'a', 'b', 'c'})}
    assert jsonify(data) == '{"hello": "world", "number": 42, "bool": true, "set": ["a", "c", "b"]}'

    # Test with datetime
    data = {'hello': 'world', 'number': 42, 'bool': True, 'datetime': datetime.datetime.fromtimestamp(1500382145)}

# Generated at 2022-06-24 21:00:09.076467
# Unit test for function to_native
def test_to_native():
    assert to_native(1.4) == 1.4
    assert to_native("ansible") == "ansible"


# Generated at 2022-06-24 21:00:17.286540
# Unit test for function jsonify
def test_jsonify():
    test_data_0 = {'foo': 'áÁéÉíÍóÓúÚ', 'bar': 1, 'empty': '', 'none': None, 'inf': float('inf'), 'nan': float('nan')}
    expected_0 = r'{"bar": 1, "foo": "áÁéÉíÍóÓúÚ", "empty": "", "none": null, "inf": 1.7976931348623157e+308, "nan": 1.7976931348623157e+308}'
    try:
        assert jsonify(test_data_0) == expected_0
    except:
        pass

# Generated at 2022-06-24 21:00:23.907054
# Unit test for function jsonify
def test_jsonify():
    data = {'name': u'fså\x84\x9f\x8d\x90\x0f\xcf\xae\x8f\x97\x9f9\x9d\x8c'}
    from ansible.module_utils import json
    assert jsonify(data) == json.dumps(data) == '{"name": "fs\\u00e5\\udcb4\\udcb7\\udcb0\\u000f\\udcc6\\u00ae\\udcb7\\udcbf39\\udcbd\\udcb6"}'


# Generated at 2022-06-24 21:00:30.105990
# Unit test for function to_native
def test_to_native():
    roundtrip = (
        'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
        '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~ \t\n\r')
    for i in range(0, 256):
        b = chr(i)
        if PY3:
            b = bytes([i])
        assert to_native(b) == b
        assert to_text(b) == to_text(b, errors='surrogate_or_strict')
        if i < 0x80:
            assert to_native(b, nonstring='passthru') == b

# Generated at 2022-06-24 21:00:40.961083
# Unit test for function to_native
def test_to_native():
    var_1 = u'zìñá'
    var_2 = to_text(var_1)
    var_3 = u'\udcc7\udffe\ude33\udfe2'

    # Test 1: unicode string
    assert var_2 == u'\u007a\u00ec\u00f1\u00e1', 'string'

    # Test 2: surrogate pairs encoded in unicode
    assert var_3 == u'\udcc7\udffe\ude33\udfe2', 'decodable using utf8'

    # Test 3: surrogate pairs encoded in latin1
    var_4 = b'\xed\xb3\xa7\xed\xbf\xbe\xed\xb8\xb3\xed\xbf\xa2'

# Generated at 2022-06-24 21:00:43.498750
# Unit test for function jsonify
def test_jsonify():
    json_str = jsonify(str_0)
    assert json_str is not None



# Generated at 2022-06-24 21:00:47.939583
# Unit test for function to_native
def test_to_native():
    assert to_native(u'test string') == u'test string'
    assert to_native(u'test string'.encode('utf-8')) == u'test string'
    assert to_native(b'test string') == b'test string'


# Generated at 2022-06-24 21:00:52.425878
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('patate') == '"patate"'
    assert jsonify("patate") == '"patate"'
    assert jsonify("patate") == '"patate"'
    assert jsonify("patate") == '"patate"'
    assert jsonify("patate") == '"patate"'
    assert jsonify("patate") == '"patate"'


# Generated at 2022-06-24 21:01:15.303760
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'123') == b'123'
    assert to_bytes(u'123') == b'123'
    assert to_bytes('123') == b'123'

    # test nonstring
    assert to_bytes(123) == b'123'
    assert to_bytes(123.1) == b'123.1'
    assert to_bytes(u'123') == b'123'

    # Test surrogate_then_replace
    if PY3:
        # Test surrogate_then_replace with surrogate pairs
        assert to_bytes(u'\U0001f4a9') == b'\xf0\x9f\x92\xa9'
        assert to_bytes(u'\ud83d\udc69') == b'\xf0\x9f\x91\xa9'

# Generated at 2022-06-24 21:01:16.722572
# Unit test for function to_bytes
def test_to_bytes():
    print('Testing test_to_bytes')
    test_case_0()


# Generated at 2022-06-24 21:01:28.074123
# Unit test for function to_bytes
def test_to_bytes():
    # No-op on a binary string
    assert to_bytes(b'hello') == b'hello'
    # No-op on a text string
    assert to_bytes(u'hello', 'utf-8') == b'hello'
    # utf-8 to utf-8
    # UTF8_STRING = u'\N{SNOWMAN}'
    UTF8_STRING = '\xe2\x98\x83'
    assert to_bytes(UTF8_STRING, 'utf-8') == UTF8_STRING.encode('utf-8')
    # latin-1 to utf-8
    LATIN1_STRING = '\x83'
    assert to_bytes(LATIN1_STRING, 'utf-8') == b'\xc3\x83'
    # surrogateescape

# Generated at 2022-06-24 21:01:30.323060
# Unit test for function to_bytes
def test_to_bytes():
    # Create an instance of our unit test class and run test case 0
    obj = Unit_Test_to_bytes()
    obj.test_case_0()


# Generated at 2022-06-24 21:01:31.165630
# Unit test for function jsonify
def test_jsonify():
    test_jsonify_body()


# Generated at 2022-06-24 21:01:42.070101
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.module_utils.common.collections import is_sequence, is_set, is_dict

    # AnsibleModule argument_spec must be converted to text before passing to utils.jsonify.
    # It's not just argument_spec. It's also a dict without keys as strings.
    dict_0 = {'value_0': 'value_1'}
    ret_0 = jsonify(dict_0)
    assert isinstance(ret_0, str)

    # Check that the return value is JSON serializable.
    # The code below is a copy of the assert_type_str in the original test_jsonify,
    # modified to handle bytes instead of str.
    ret_1 = json.loads(ret_0)
    assert is_sequence

# Generated at 2022-06-24 21:01:52.202088
# Unit test for function jsonify
def test_jsonify():
    arg_0 = dict()
    arg_0[u'ÓÚäê'] = u'ìw\x84\xa5'
    arg_0[u'Ôÿ\x96\x8d\x8b¥¤ß\x8b'] = u'ûRÝûQ=ÿúÖÝ·'
    arg_0[u'ØÙ\xa3B'] = [arg_0, arg_0, arg_0, arg_0, arg_0, arg_0, arg_0, arg_0, arg_0, arg_0, arg_0, arg_0, arg_0, arg_0, arg_0, arg_0, arg_0]

# Generated at 2022-06-24 21:01:55.854907
# Unit test for function jsonify
def test_jsonify():
    true_value = '{"a": "\\u20ac"}'
    test_value = jsonify({'a': u'\u20ac'})
    assert true_value == test_value


# Generated at 2022-06-24 21:02:04.401740
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == '{}'
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify(['a', 'b']) == '["a", "b"]'
    assert jsonify(container_to_text({'a': 'b'}, 'utf-8'), ensure_ascii=False) == '{"a": "b"}'
    assert jsonify(container_to_text({u'a': u'b\u0107'}, 'utf-8'), ensure_ascii=False) == '{"a": "b\\u0107"}'
    assert jsonify(container_to_text({'a': u'b\u0107'}, 'utf-8'), ensure_ascii=False) == '{"a": "b\\u0107"}'
   

# Generated at 2022-06-24 21:02:07.524424
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 1, 'b': 2, 'c': 3}
    jsonified_data = jsonify(data)
    assert isinstance(jsonified_data, str)
    assert jsonified_data == '{"a": 1, "b": 2, "c": 3}'



# Generated at 2022-06-24 21:02:19.462170
# Unit test for function to_native
def test_to_native():
    print('to_native() is not implemented')


# Generated at 2022-06-24 21:02:26.792942
# Unit test for function jsonify
def test_jsonify():
    if not PY3:
        # On Python2, in order to use surrogateescape, it must be registered
        # on Python2 (See note in to_bytes and to_text on how to do this.)
        # So this test is fundamentally broken on Python2.  Specifically,
        # it will succeed if the test is run with a surrogateescape registered
        # or fail with standard library.
        assert u'\udead\ubeef'.encode('utf-8', 'surrogate_then_replace').decode('utf-8', 'surrogateescape') == u'\udead\ubeef'
    data = {u'a': 42, u'b': u'\udead\ubeef'}
    result = jsonify(data)
    assert json.loads(result) == data
    # test surrogateescape

# Generated at 2022-06-24 21:02:35.485257
# Unit test for function to_native
def test_to_native():
    str_0 = 'áz\x11®ÊD+\x1cõj'
    to_native(str_0, None)
    str_1 = 'Lê7Û\x0c\x1dH\x02TÙ'
    to_native(str_1, str_1)
    str_2 = '\x1b\x17ÌÇ\x02í\x00\x17\x00\x1cI'
    to_native(str_2, str_2)
    str_3 = '\x0bÆÝ\x02\x0c\x1b¤¡\x07\x1dÊ'
    to_native(str_3, str_3)

# Generated at 2022-06-24 21:02:41.119992
# Unit test for function to_native
def test_to_native():

    # Call function to_native
    str_2 = 'F'
    assert str_2 == to_native(str_2)



# Generated at 2022-06-24 21:02:42.587567
# Unit test for function to_bytes
def test_to_bytes():
    assert isinstance(to_bytes('hello'), binary_type)


# Generated at 2022-06-24 21:02:45.292970
# Unit test for function to_native
def test_to_native():
    assert to_native(None) == None
    assert to_native('str') == 'str'
    assert to_native(b'bytes') == b'bytes'


# Generated at 2022-06-24 21:02:55.205938
# Unit test for function to_native
def test_to_native():
    # Make sure str->str, bytes->bytes and nonstring->str all work
    assert to_native(b'test', 'latin-1') == b'test'
    assert to_native(u'test') == u'test'
    assert to_native(2.14159) == u'2.14159'

    if PY3:
        # Make sure bytes->str and str->bytes are decoded/encoded
        assert to_native(b'test', 'latin-1') == u'test'
        assert to_native(u'test', 'latin-1') == b'test'
    else:
        # Make sure bytes->str and str->bytes are decoded/encoded
        assert to_native(b'test', 'latin-1') == u'test'

# Generated at 2022-06-24 21:03:04.015727
# Unit test for function jsonify

# Generated at 2022-06-24 21:03:15.890997
# Unit test for function jsonify
def test_jsonify():
    data = 'fjáÚ/qjï\x8fM\x9ekÿelFVÕó'

    # Should not be able to serialize Set
    with pytest.raises(TypeError):
        json.dumps(Set(data), default=_json_encode_fallback)

    # Should be able to serialize datetime.datetime
    json.dumps(datetime.datetime(2016, 4, 1, 14, 4, 0), default=_json_encode_fallback)

    # Should return a string with JSON representation of data, encoding it first.
    assert isinstance(jsonify([u'value']), str)

    # Should return a unicode string with JSON representation of data on PY2

# Generated at 2022-06-24 21:03:19.268400
# Unit test for function to_native
def test_to_native():
    str_1 = 'ú/qjï\x8fM\x9ekÿelFVÕó'
    var_1 = to_text(str_1, str_1, str_1)


# Generated at 2022-06-24 21:03:40.461678
# Unit test for function jsonify

# Generated at 2022-06-24 21:03:42.572752
# Unit test for function to_bytes
def test_to_bytes():
    # Negative tests: string, string, string
    # assert_raises()
    pass

# Generated at 2022-06-24 21:03:50.355579
# Unit test for function jsonify
def test_jsonify():
    # We should call jsonify with a valid argument set
    result = jsonify(func_0, func_0, func_0, func_0, func_0, func_0, func_0)
    # We should call jsonify with a valid argument set
    result = jsonify(func_0, func_0, func_0, func_0, func_0, func_0, func_0)
    # We should call jsonify with a valid argument set
    result = jsonify(func_1, func_1, func_1, func_1, func_1, func_1, func_1)
    # We should call jsonify with a valid argument set
    result = jsonify(func_1, func_1, func_1, func_1, func_1, func_1, func_1)
    # We should call jsonify

# Generated at 2022-06-24 21:03:59.980993
# Unit test for function to_native
def test_to_native():
    func_0 = to_native
    func_1 = func_0
    var_0 = to_bytes('', '', '', 'passthru')
    var_1 = func_0('', str(var_0), '')
    var_2 = to_bytes('12345')
    var_3 = to_bytes(b'12345')
    var_4 = func_1('12345', '', var_2)
    var_5 = to_text('12345')
    var_6 = to_text(b'12345')
    var_7 = func_1(u'12345', '', '12345')
    var_8 = to_bytes(str(var_0), var_2, var_2)
    var_9 = to_bytes('12345', var_3, var_3)
   

# Generated at 2022-06-24 21:04:11.688673
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(None, nonstring='passthru') is None
    assert not isinstance(to_bytes(None), text_type)
    assert to_bytes(123, nonstring='passthru') == 123
    assert not isinstance(to_bytes(123), text_type)

    assert isinstance(to_bytes(123), binary_type)
    assert to_bytes(None, nonstring='strict') is None
    assert to_bytes('hello', errors='surrogate_or_strict') == b'hello'
    assert to_bytes(b'hello') == b'hello'
    assert to_bytes(b'hello', errors='surrogate_or_strict') == b'hello'
    assert to_bytes(b'\xF1') == b'\xF1'

# Generated at 2022-06-24 21:04:20.381274
# Unit test for function to_native
def test_to_native():
    str_0 = 'ú/qjï\x8fM\x9ekÿelFVÕó'
    var_0 = to_native(str_0)
    var_0 = to_native(str_0)
    var_0 = to_native(str_0)
    var_0 = to_native(str_0)
    var_0 = to_native(str_0)
    var_0 = to_native(str_0)
    var_0 = to_native(str_0)
    var_0 = to_native(str_0)
    var_0 = to_native(str_0)
    var_0 = to_native(str_0)
    var_0 = to_native(str_0)
    var_0 = to_native(str_0)
   

# Generated at 2022-06-24 21:04:25.456912
# Unit test for function to_bytes
def test_to_bytes():
    test_cases = [
        # Test cases for function to_bytes
        # [ input, output ]
        [ u'ú/qjï\x8fM\x9ekÿelFVÕó', b'\xc3\xba/qj\xc3\xaf\x8fM\x9ek\xc3\xbfelFV\xc3\x95\xc3\xb3' ],
    ]

    for test_case in test_cases:
        if len(test_case) < 2:
            continue

        var_0 = test_case[0]
        var_1 = test_case[1]
        var_2 = to_bytes(var_0)
        print(str(var_2))
        assert(var_1 == var_2)

# Generated at 2022-06-24 21:04:31.920216
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = '¿p+\x1c\x9b|Ú³ÔoÉrÍ\x06á\x1f.\x81¸\x99YÜ\x9a;'
    var_0 = to_bytes(str_0, str_0, str_0)


# Generated at 2022-06-24 21:04:42.399042
# Unit test for function to_native
def test_to_native():
    # No exception
    assert to_native(None) is None
    assert to_native(True) is True
    assert to_native(False) is False
    assert to_native(1) == 1
    assert to_native("test") == "test"
    assert to_native(b"test") == "test"
    assert to_native(u"test") == u"test"
    assert to_native("test", encoding='utf-8') == "test"
    assert to_native("test", encoding='utf-8', errors='surrogate_or_strict') == "test"
    assert to_native("test", encoding='utf-8', errors='surrogate_then_replace') == "test"
    assert to_native("test", encoding='utf-8', errors='surrogate_or_replace') == "test"

# Generated at 2022-06-24 21:04:46.741511
# Unit test for function jsonify
def test_jsonify():
    hello = {'a': 'hello', 'b': 'world'}
    json_hello = jsonify(hello)
    try:
        result = json.loads(json_hello)
    except ValueError:
        raise
    if hello != result:
        raise Exception("Error")


# Generated at 2022-06-24 21:05:07.086939
# Unit test for function to_bytes
def test_to_bytes():
    # Test for to_bytes with just a single str argument
    str_0 = 'ú/qjï\x8fM\x9ekÿelFVÕó'
    var_0 = to_bytes(str_0)
    assert(var_0 == b'\xc3\xba/qj\xc3\xaf\x8fM\x9ek\xc3\xbfelFV\xc3\x95\xc3\xb3')
    # Test for to_bytes with just a single bytes argument
    str_0 = 'ú/qjï\x8fM\x9ekÿelFVÕó'

# Generated at 2022-06-24 21:05:15.307082
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('abc', 'utf-8', 'replace') == b'abc'
    assert to_bytes('abc', 'latin-1', 'replace') == b'abc'
    assert to_bytes(u'abc', 'utf-8', 'replace') == b'abc'
    assert to_bytes(u'abc', 'latin-1', 'replace') == b'abc'
    assert to_bytes('\xe9', 'utf-8', 'replace') == b'\xc3\xa9'
    assert to_bytes('\xe9', 'latin-1', 'replace') == b'\xe9'
    assert to_bytes(u'\xe9', 'utf-8', 'replace') == b'\xc3\xa9'

# Generated at 2022-06-24 21:05:22.541610
# Unit test for function to_bytes
def test_to_bytes():

    cls_0 = to_bytes('FÕó', 'latin-1', 'strict')
    assert (cls_0 is not None), '''to_bytes returned None'''
    assert (cls_0 == b'F\xd3\xf3'), '''to_bytes returned "%s", expected "%s"''' % (cls_0, b'F\xd3\xf3', )
    cls_1 = to_bytes('Õó', 'latin-1', 'strict')
    assert (cls_1 is not None), '''to_bytes returned None'''
    assert (cls_1 == b'\xd3\xf3'), '''to_bytes returned "%s", expected "%s"''' % (cls_1, b'\xd3\xf3', )
    cls_

# Generated at 2022-06-24 21:05:28.149882
# Unit test for function jsonify
def test_jsonify():
    input_data = {u'a': u'\u13a0', u'b': u'\u00e3\u00e3\u00e3'}
    expected_output = '{"a": "\\u13a0", "b": "\\u00e3\\u00e3\\u00e3"}'

    output_data = jsonify(input_data)

    assert output_data == expected_output


# Generated at 2022-06-24 21:05:35.876863
# Unit test for function to_native
def test_to_native():
    assert to_native("string") == "string"
    assert to_native(b"string") == "string"
    assert to_native(u"string") == "string"
    assert to_native(1) == 1
    assert to_native(1.1) == 1.1
    assert to_native(complex(1,1)) == complex(1,1)
    assert to_native(1) == 1
    assert to_native(frozenset([1,2,3,4])) == set([1,2,3,4])
    assert to_native(datetime.datetime(2018, 1, 1, 1, 1, 1, 1)) == "2018-01-01T01:01:01.000001"

# Generated at 2022-06-24 21:05:39.718589
# Unit test for function to_native
def test_to_native():
    input_str = u'\u6c49\u5b57\u6f22\u5b57'
    assert to_native(input_str) == u'\u6c49\u5b57\u6f22\u5b57'


# Generated at 2022-06-24 21:05:41.247794
# Unit test for function jsonify
def test_jsonify():
    data = {}
    result = jsonify(data)
    assert isinstance(result, str)


# Generated at 2022-06-24 21:05:49.051287
# Unit test for function jsonify
def test_jsonify():
    test_data = {}
    test_data['user'] = 'user'
    test_data['password'] = 'password'
    test_data['port'] = 22
    test_data['hosts'] = ['192.168.0.1', '192.168.0.2']
    test_data['vars'] = {'ansible_become': True, 'ansible_become_method': 'sudo'}
    expected_result = b'{"user": "user", "password": "password", "port": 22, "hosts": ["192.168.0.1", "192.168.0.2"], "vars": {"ansible_become": true, "ansible_become_method": "sudo"}}'
    json_data = jsonify(test_data)
    assert json_data == expected_result


# Generated at 2022-06-24 21:05:50.441696
# Unit test for function jsonify
def test_jsonify():
    pass


# Generated at 2022-06-24 21:05:58.446726
# Unit test for function to_native
def test_to_native():
    str_0 = 'ú/qjï\x8fM\x9ekÿelFVÕó'
    var_0 = to_bytes(str_0, str_0, str_0)
    var_1 = to_text(str_0, str_0, str_0)
    str_1 = '*1GÖxb°ñé\x81íN\x80Î~\x8d\x98\x91_\x90\x8f\x8c'
    var_2 = to_bytes(str_1, str_1, str_1)
    str_2 = '\x99\x83ËMMÀÍÝÓó\x9b\x9d'


# Generated at 2022-06-24 21:06:15.482058
# Unit test for function to_bytes