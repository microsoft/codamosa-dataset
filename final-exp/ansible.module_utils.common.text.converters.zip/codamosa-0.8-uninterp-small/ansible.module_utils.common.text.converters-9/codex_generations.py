

# Generated at 2022-06-24 20:56:40.162069
# Unit test for function to_native
def test_to_native():
    assert to_native(None, nonstring='passthru') is None
    assert to_native('8\r:$shT8h!Swo\tPt1:[g') == '8\r:$shT8h!Swo\tPt1:[g'
    assert to_native(8) == '8'
    assert to_native(['f', None, '', 'p']) == ['f', None, '', 'p']
    assert to_native({'t': 'b', 4: 8}) == {'t': 'b', '4': 8}
    assert to_native(datetime.datetime(2018, 8, 14, 16, 7, 42)) == '2018-08-14T16:07:42'
    assert to_native(Set([1, 2])) == [1, 2]
   

# Generated at 2022-06-24 20:56:49.250993
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('a') == b'a'
    assert to_bytes(b'a') == b'a'
    assert to_bytes(b'\xde\xad\xbe\xef') == b'\xde\xad\xbe\xef'
    assert to_bytes(u'8\r:$shT8h!Swo\tPt1:[g') == b'8\r:$shT8h!Swo\tPt1:[g'
    assert to_bytes(u'\u6c34') == b'\xe6\xb0\xb4'
    assert to_bytes(u'\U0001f34c') == b'\xf0\x9f\x8d\x8c'

# Generated at 2022-06-24 20:56:50.671123
# Unit test for function to_native
def test_to_native():
    str_1 = '_S'
    var_1 = to_native(str_1)


# Generated at 2022-06-24 20:56:52.787467
# Unit test for function jsonify
def test_jsonify():
    try:
        test_case_0()
    except Exception as e:
        print(e)

# Run unit tests
test_jsonify()

# Generated at 2022-06-24 20:56:59.418446
# Unit test for function jsonify
def test_jsonify():
    str_0 = '8\r:$shT8h!Swo\tPt1:[g'
    var_0 = jsonify(str_0)
    assert var_0 == "\"8\\r:$shT8h!Swo\tPt1:[g\""



# Generated at 2022-06-24 20:57:11.087436
# Unit test for function to_bytes
def test_to_bytes():
    # Test passing in a str
    str_0 = 'phantom menace'
    bytes_0 = to_bytes(str_0)
    if not bytes_0 == b'phantom menace':
        raise AssertionError()

    # Test passing in a unicode text
    unicode_0 = text_type('R2-D2')
    bytes_1 = to_bytes(unicode_0)
    if not bytes_1 == b'R2-D2':
        raise AssertionError()

    # Test passing in a non-string object
    str_1 = 'Yoda'
    nonstring_0 = object()
    nonstring_1 = to_bytes(nonstring_0, nonstring='simplerepr')
    nonstring_2 = to_bytes(nonstring_0, nonstring='empty')
    nonstring_

# Generated at 2022-06-24 20:57:15.213178
# Unit test for function jsonify
def test_jsonify():
    json_0 = '"8\\r:$shT8h!Swo\\tPt1:[g"' # str - json
    var_0 = jsonify(str_0)
    if (var_0 != json_0): print('Expected: %s' % json_0); print('Got: %s' % var_0)


# Generated at 2022-06-24 20:57:23.540200
# Unit test for function to_bytes
def test_to_bytes():
    text = u"\u00E6"
    result = codecs.encode(text, "latin-1", 'replace')
    assert result != text
    result = to_bytes(text, errors='ignore')
    assert isinstance(result, binary_type)
    assert result == b''
    result = to_bytes(text, errors='replace')
    assert isinstance(result, binary_type)
    assert result == b'?'
    result = to_bytes(text)
    assert isinstance(result, binary_type)
    assert result == u"\u00E6".encode("utf-8")
    result = to_bytes(1)
    assert isinstance(result, binary_type)
    assert result == b"1"
    assert to_bytes('foo') == b'foo'

# Generated at 2022-06-24 20:57:27.137778
# Unit test for function to_bytes
def test_to_bytes():
    # result = to_bytes(obj, encoding='utf-8', errors=None, nonstring='simplerepr')
    try:
        assert str(to_bytes((1, 2, 3))) == b"(1, 2, 3)"
    except:
        print("Error: test_to_bytes")



# Generated at 2022-06-24 20:57:35.006918
# Unit test for function to_bytes
def test_to_bytes():
    value = 'hello world'
    bytes_value = to_bytes(value, encoding='ascii')
    if not isinstance(bytes_value, binary_type):
        print('FAIL to_bytes() returned text type: {0}'.format(type(bytes_value)))
    elif bytes_value != b'hello world':
        print('FAIL to_bytes() returned incorrect bytes: {0}'.format(bytes_value))
    else:
        print('PASS')


# Generated at 2022-06-24 20:57:43.424298
# Unit test for function to_native
def test_to_native():
    str_0 = '8\r:$shT8h!Swo\tPt1:[g'
    var_0 = to_native(str_0)
    if var_0 != str_0:
        print(var_0)


# Generated at 2022-06-24 20:57:51.759015
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = '8\r:$shT8h!Swo\tPt1:[g'
    var_0 = jsonify(str_0)

    # Test with a simple text string
    str_1 = '8\r:$shT8h!Swo\tPt1:[g'
    str_2 = '8\r:$shT8h!Swo\tPt1:[g'
    var_1 = to_bytes(str_1)
    assert (var_1 == var_0)
    str_3 = '8\r:$shT8h!Swo\tPt1:[g'
    str_4 = '8\r:$shT8h!Swo\tPt1:[g'
    var_2 = to_bytes(str_3)

# Generated at 2022-06-24 20:57:52.554367
# Unit test for function jsonify
def test_jsonify():
    test_case_0()



# Generated at 2022-06-24 20:57:53.840568
# Unit test for function jsonify
def test_jsonify():
    # Setup
    data = 'Hello world'

    # Test execution
    assert jsonify(data) == '"Hello world"'

# Generated at 2022-06-24 20:57:58.447583
# Unit test for function to_native
def test_to_native():
    assert to_native("True") == True
    assert to_native("False") == False
    assert to_native("None") == None


# Generated at 2022-06-24 20:58:04.384517
# Unit test for function to_bytes
def test_to_bytes():
    # Assert that the function raises a TypeError when the passed
    # object is invalid
    from ansible.module_utils.common._collections_compat import Set
    try:
        to_bytes(Set())
    except TypeError:
        pass
    else:
        assert False, 'Expected TypeError not thrown'
    # Assert that the function raises a TypeError when the passed
    # object is invalid
    try:
        to_bytes(set())
    except TypeError:
        pass
    else:
        assert False, 'Expected TypeError not thrown'
    # Assert that the function raises a TypeError when the passed
    # object is invalid
    try:
        to_bytes(dict())
    except TypeError:
        pass
    else:
        assert False, 'Expected TypeError not thrown'
    # Ass

# Generated at 2022-06-24 20:58:05.442700
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Generated at 2022-06-24 20:58:14.609763
# Unit test for function to_bytes
def test_to_bytes():
    assert repr(to_bytes('hello world')) == "b'hello world'"
    assert repr(to_bytes(b'hello world')) == "b'hello world'"
    assert repr(to_bytes(bytearray(b'hello world'))) == "b'hello world'"
    assert repr(to_bytes(u'\u00fcml\xe4ut')) == "b'\\xc3\\xbcml\\xc3\\xa4ut'"
    assert repr(to_bytes(u'\u00fcml\xe4ut', encoding='iso-8859-1')) == "b'\\xfcml\\xe4ut'"

# Generated at 2022-06-24 20:58:20.680368
# Unit test for function to_bytes
def test_to_bytes():
    """Unit tests for function to_bytes"""

    assert to_bytes(u'test') == b'test'
    assert to_bytes(u"\xc0") == b'\xc3\x80'
    assert to_bytes(u"\xc0", encoding='latin-1') == b'\xc0'
    assert to_bytes(None, nonstring='empty') == b''
    assert to_bytes(12345, nonstring='passthru') == 12345



# Generated at 2022-06-24 20:58:21.548816
# Unit test for function to_bytes
def test_to_bytes():
    test_case_0()


# Generated at 2022-06-24 20:58:38.534320
# Unit test for function to_bytes
def test_to_bytes():
    """Test function to_bytes()."""
    if PY3:
        value = to_bytes(u'abc')
        assert isinstance(value, bytes), 'Incorrect return value for {1}, returned {2}'.format(u'abc', type(value))

        value = to_bytes(b'abc')
        assert isinstance(value, bytes), 'Incorrect return value for {1}, returned {2}'.format(b'abc', type(value))

        value = to_bytes(u'\u2019')
        assert isinstance(value, bytes), 'Incorrect return value for {1}, returned {2}'.format(u'\u2019', type(value))

        value = to_bytes(b'\xe2\x80\x9c')

# Generated at 2022-06-24 20:58:49.292200
# Unit test for function to_native
def test_to_native():
    assert jsonify('\u043f\u0440\u0438\u0432\u0435\u0442') == u'привет'
    assert isinstance(jsonify('\u043f\u0440\u0438\u0432\u0435\u0442'), text_type)
    assert jsonify(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'привет'
    assert isinstance(jsonify(u'\u043f\u0440\u0438\u0432\u0435\u0442'), text_type)
    assert jsonify('caf\u00e9') == u'café'

# Generated at 2022-06-24 20:58:50.318485
# Unit test for function to_native
def test_to_native():
    data = 'Hello'
    str_1 = json.dumps(data)
    assert to_native(data) == str_1


# Generated at 2022-06-24 20:58:59.960301
# Unit test for function to_bytes

# Generated at 2022-06-24 20:59:11.192790
# Unit test for function jsonify
def test_jsonify():
    # Test mixed data types
    data = {
        'string': "I'm a robot",
        'number': 42,
        'dict': {
            'key': 'value',
        },
        'list': [
            'a',
            'b',
        ],
        'set': Set([1, 2, 3]),
        'datetime': datetime.datetime.now(),
    }
    expected_json = """{"datetime": "%s", "dict": {"key": "value"}, "list": ["a", "b"], "number": 42, "set": [1, 2, 3], "string": "I'm a robot"}""" % data['datetime'].isoformat()
    assert jsonify(data) == expected_json, "jsonify should serialize mixed data types successfully"


# Generated at 2022-06-24 20:59:19.347473
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('\u00e9') == b'\xc3\xa9'
    assert to_bytes('\u00e9', errors='surrogateescape') == b'\xc3\xa9'
    assert to_bytes('\u00e9', errors='surrogate_or_replace') == b'\xc3\xa9'
    assert to_bytes('\u00e9', errors='surrogate_or_strict') == b'\xc3\xa9'
    assert to_bytes('\u00e9', errors='surrogate_then_replace') == b'\xc3\xa9'



# Generated at 2022-06-24 20:59:29.801893
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(b'foo'.decode('utf-8')) == b'foo'
    assert to_bytes('fóo') == b'f\xc3\xb3o'
    assert to_bytes('fóo'.encode('latin-1'), encoding='latin-1') == b'f\xf3o'
    assert to_bytes('fóo'.encode('latin-1', 'replace'), encoding='latin-1') == b'f?o'
    try:
        to_bytes('fóo'.encode('ascii'), encoding='latin-1')
    except UnicodeEncodeError:
        pass

# Generated at 2022-06-24 20:59:32.701767
# Unit test for function to_native
def test_to_native():
    str_0 = 'J4Gn9'
    var_0 = to_native(str_0)

    print('to_native: ' + str(var_0))


# Generated at 2022-06-24 20:59:37.182898
# Unit test for function jsonify
def test_jsonify():
    try:
        str_0 = '8\r:$shT8h!Swo\tPt1:[g'
        var_0 = jsonify(str_0)
        assert var_0 == '"8\\r:$shT8h!Swo\\tPt1:[g"'
    except Exception:
        assert False



# Generated at 2022-06-24 20:59:44.900918
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes("foo") == b"foo"
    assert to_bytes(u"foo") == b"foo"
    assert to_bytes(b"foo") == b"foo"
    assert to_bytes("foo", nonstring="empty") == b""
    assert to_bytes("foo", nonstring="passthru") == "foo"
    try:
        to_bytes("foo", nonstring="strict")
    except TypeError as e:
        assert str(e) == "obj must be a string type"

    if PY3:
        assert to_bytes("foo", errors='surrogate_or_strict') == b"foo"
        assert to_bytes("foo", errors='surrogate_or_replace') == b"foo"
        assert to_bytes("foo", errors='surrogate_then_replace')

# Generated at 2022-06-24 21:00:02.579185
# Unit test for function jsonify
def test_jsonify():
    # Source:
    # https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/_text.py
    # These test cases are taken from the Ansible test files
    str_0 = to_bytes('8\r:$shT8h!Swo\tPt1:[g')
    var_0 = jsonify(str_0)
    assert var_0 == '"8\\r:$shT8h!Swo\\tPt1:[g"'
    var_0 = jsonify('8\r:$shT8h!Swo\tPt1:[g')
    assert var_0 == '"8\\r:$shT8h!Swo\\tPt1:[g"'

# Generated at 2022-06-24 21:00:13.383151
# Unit test for function to_bytes
def test_to_bytes():
    """
    Unit test for function to_bytes
    """
    var_0 = '\x10\x05\x07\x13\x1c\x11\x0c\x04\x15\x11\x07\x08\x1a\x1d\x0b\x12'
    str_0 = '\x10\x05\x07\x13\x1c\x11\x0c\x04\x15\x11\x07\x08\x1a\x1d\x0b\x12'

    assert to_bytes(var_0) == str_0


# Generated at 2022-06-24 21:00:20.175998
# Unit test for function jsonify
def test_jsonify():
    data = {
            "key1": "value",
            "key2": "value2",
            "key3": "value3",
            "key4": [ 1, 2, 3, 4 ],
            "key5": {"key6": "value6"},
            "key7": {"key8": {"key9": "value9"}}
            }

    # Expected JSON string for the above data
    expected_JSON_string = '{"key1": "value", "key2": "value2", "key3": "value3", "key4": [1, 2, 3, 4], "key5": {"key6": "value6"}, "key7": {"key8": {"key9": "value9"}}}'

    # Test 1: Print the JSON string by passing the Python data to the funtion
    #jsonify(data)

   

# Generated at 2022-06-24 21:00:28.416590
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('2020') == '2020'
    assert to_bytes(20) == '20'
    assert to_bytes('20') == '20'
    assert to_bytes(2020.20) == '2020.2'
    assert to_bytes(20.20) == '20.2'
    assert to_bytes(2020.2020) == '2020.202'
    assert to_bytes(20.2020) == '20.202'


# Generated at 2022-06-24 21:00:31.005317
# Unit test for function jsonify
def test_jsonify():
    str_0 = 'hx}CWkM2e'
    var_0 = jsonify(str_0)
    assert var_0 == '"hx}CWkM2e"'

# Generated at 2022-06-24 21:00:41.449075
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('hello world') == b'hello world'
    assert to_bytes(b'hello world') == b'hello world'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(5) == b'5'
    assert to_bytes(5, nonstring='passthru') == 5
    assert to_bytes(5, nonstring='empty') == b''
    assert to_bytes(5, nonstring='strict') == b'5'
    assert to_bytes(datetime.datetime.now(), nonstring='passthru') == datetime.datetime.now()

    if PY3:
        assert to_bytes(u'\udcff') == b'\xed\xb3\xbf'
        assert to_

# Generated at 2022-06-24 21:00:47.684452
# Unit test for function jsonify
def test_jsonify():
    str_0 = '8\r:$shT8h!Swo\tPt1:[g'
    var_0 = jsonify(str_0)
    if '8\r:$shT8h!Swo\tPt1:[g' != var_0:
        raise Exception("Json serialization error. Expected: {}, actual:{}".format('8\r:$shT8h!Swo\tPt1:[g', var_0))
    print("Unit test for function jsonify is passed")

if __name__ == "__main__":
    test_jsonify()

# Generated at 2022-06-24 21:00:51.868447
# Unit test for function to_native
def test_to_native():
    if PY3:
        assert to_native(b'foo') == b'foo'
        assert to_native(u'\u2713') == '\u2713'
    else:
        assert to_native(b'foo') == 'foo'
        assert to_native(u'\u2713') == u'\u2713'


# Generated at 2022-06-24 21:01:03.024925
# Unit test for function to_native
def test_to_native():
    assert to_native(u'Hello') == 'Hello'
    assert to_native('some_string') == 'some_string'
    assert to_native(5) == 5
    assert to_native(5.5) == 5.5
    assert to_native(True) == True
    assert to_native(['list', 'of', 'strings']) == ['list', 'of', 'strings']
    assert to_native(['list', 'of', 'strings']) == ['list', 'of', 'strings']
    assert to_native({'str1': 'str2', 'str3': 'str4'}) == {'str1': 'str2', 'str3': 'str4'}
    assert to_native(None) == None


# Generated at 2022-06-24 21:01:15.045407
# Unit test for function to_bytes
def test_to_bytes():

    # Test cases
    assert to_bytes('toto.txt') == b'toto.txt'
    assert to_bytes('toto.txt', errors='strict') == b'toto.txt'
    assert to_bytes('toto.txt', encoding='ascii', errors='surrogate_or_strict') == b'toto.txt'
    assert to_bytes('toto.txt', errors='surrogate_or_strict') == b'toto.txt'
    assert to_bytes('toto.txt', errors='surrogate_or_strict', nonstring='') == b'toto.txt'
    assert to_bytes('toto.txt', errors='surrogate_or_strict', nonstring='simplerepr') == b'toto.txt'

# Generated at 2022-06-24 21:01:30.083538
# Unit test for function to_native
def test_to_native():
    # Test decoding from bytes to text
    assert to_native(b'bytes') == 'bytes'

    # Test decoding from bytes to text, when errors='replace'
    assert to_native(b'\x80') == '\ufffd'

    # Test decoding from bytes to text, when errors='ignore'
    assert to_native(b'\x80') == '\ufffd'

    # Test decoding from bytes to text, when errors='backslashreplace'
    assert to_native(b'bytes') == 'bytes'

    # Test decoding from bytes to text, when errors='xmlcharrefreplace'
    assert to_native(b'bytes') == 'bytes'



# Generated at 2022-06-24 21:01:35.460303
# Unit test for function jsonify
def test_jsonify():
    var_0 = jsonify(dict(a=1, b=2, c=3))
    assert type(var_0) == str
    assert var_0 == '{"a": 1, "b": 2, "c": 3}'
    var_1 = jsonify(list([1, 2, 3]))
    assert type(var_1) == str
    assert var_1 == '[1, 2, 3]'
    print('[+] test_jsonify done')

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-24 21:01:38.995856
# Unit test for function to_native
def test_to_native():
    dict_0 = dict()
    dict_0['a'] = 'a'
    dict_0['b'] = 'b'
    var_0 = to_native(dict_0)
    var_1 = to_native(var_0)
    dict_1 = dict()
    dict_1['a'] = 'c'
    dict_1['b'] = 'd'
    var_2 = to_native(dict_1, strict=False)


# Generated at 2022-06-24 21:01:45.959370
# Unit test for function jsonify
def test_jsonify():
    str_0_0 = ')cL=N~2K$B0Q7Y`@%+#o0B>Xl'
    str_0_1 = 'V7_0g5>33;|M5e^P:!5D!O52'
    str_0_2 = 'Q7<a8)TsW_Dq3/&JH2"*~8R@W)'
    str_0_3 = '^y+a"p"@wG*fMbJ7Z`8zy[^2k'
    str_0_4 = '\\oG%C;-\\@l:1*A0h9"0=aQ~1}'

# Generated at 2022-06-24 21:01:51.716145
# Unit test for function to_bytes
def test_to_bytes():
    assert isinstance(to_bytes(u'bob'), str)
    assert to_bytes(u'bob') == b'bob'
    assert to_bytes('bob') == b'bob'

    # to_bytes can only convert unicode to bytes, so b'bob' just gets passed
    # back out
    assert to_bytes(b'bob') == b'bob'

    # error handler to use surrogates on python3 and replace on python2
    # TODO: change this test in Ansible-2.3 to default_errors=None
    assert to_bytes(u'\uDC80') == b'\xed\xb0\x80'

    # error handler to use surrogates on python3 and strict on python2

# Generated at 2022-06-24 21:01:53.336801
# Unit test for function jsonify
def test_jsonify():
    print("This is the jsonify test function")
    test_case_0()


# Generated at 2022-06-24 21:01:55.381659
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Unit test that is used to launch the unit test

# Generated at 2022-06-24 21:02:00.507518
# Unit test for function jsonify
def test_jsonify():
    str_0 = '8\r:$shT8h!Swo\tPt1:[g'
    var_1 = jsonify(str_0)
    assert var_1 is not None


# Generated at 2022-06-24 21:02:08.423425
# Unit test for function to_native
def test_to_native():
    native_str = to_native(b'foo')
    print(native_str)
    print('-' * 40)
    native_str = to_native(u'foo')
    print(native_str)
    print('-' * 40)
    native_str = to_native('foo')
    print(native_str)
    print('-' * 40)
    native_str = to_native(['a', 'b', 'c'])
    print(native_str)
    print('-' * 40)
    native_str = to_native({'key1': 'value1'})
    print(native_str)


# Generated at 2022-06-24 21:02:19.565803
# Unit test for function to_native
def test_to_native():
    # Example:
    #     to_native("utf8\u20ac foo", nonstring='passthru')
    # Result:
    #     u'utf8\u20ac foo'

    try:
        test_0_input = '\xfd'
        test_0_actual = to_text(test_0_input)
    except Exception as e:
        # Note: We deliberately do not use assert_equals here as we want to
        #       know the type of exception on failure
        print("Test 0 failed:")
        print("    Input:      ", repr(test_0_input))
        print("    Exception:  ", repr(e))
        return False

    if test_0_actual is None:
        print("Test 0 failed:")
        print("    Input:      ", repr(test_0_input))


# Generated at 2022-06-24 21:02:31.912027
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(4) == '4'
    assert to_bytes('4') == '4'
    assert to_bytes(u'\u1234') == '\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == '?'
    assert to_bytes(u'\u1234', nonstring='passthru') == u'\u1234'



# Generated at 2022-06-24 21:02:37.385882
# Unit test for function to_native
def test_to_native():
    str_0 = '#T\r\t$:vuz8\tW'
    var_0 = to_native(str_0)
    str_1 = '_\r\t$:vuz8\tW'
    var_1 = to_native(str_1)
    assert var_0 == var_1


# Generated at 2022-06-24 21:02:43.265742
# Unit test for function to_native
def test_to_native():
    str_0 = '\x08\r:$shT8h!Swo\tPt1:[g'
    var_0 = jsonify(str_0)

    if isinstance(var_0, binary_type):
        var_0 = var_0.decode('utf-8')
    assert var_0 == '8\r:$shT8h!Swo\tPt1:[g'


# Generated at 2022-06-24 21:02:51.186852
# Unit test for function to_bytes
def test_to_bytes():
    # Test with a string
    test_string = 'testing'
    assert isinstance(to_bytes(test_string), text_type)

    test_string = u'testing'
    assert isinstance(to_bytes(test_string), text_type)

    # Test with an array
    test_array = [u'testing', b'testing']
    assert isinstance(to_bytes(test_array), list)

    # Test with a dict
    test_dict = {u'testing': b'testing'}
    assert isinstance(to_bytes(test_dict), dict)

# Generated at 2022-06-24 21:02:54.870599
# Unit test for function to_native
def test_to_native():
    """ Test the to_native function
    """
    str_0 = 'this is a string'
    if str_0 != to_native(str_0):
        raise ValueError
    str_1 = 'this is a string'
    if str_1 != to_native(str_1):
        raise ValueError


# Generated at 2022-06-24 21:02:59.243558
# Unit test for function to_bytes
def test_to_bytes():
    data = 'hello world'
    assert data.encode() == to_bytes(data)


# Generated at 2022-06-24 21:03:00.163489
# Unit test for function jsonify
def test_jsonify():
    test_case_0()


# Generated at 2022-06-24 21:03:03.480982
# Unit test for function to_native
def test_to_native():
    var_0 = "TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT"
    var_0 = to_native(var_0)


# Generated at 2022-06-24 21:03:05.202147
# Unit test for function jsonify
def test_jsonify():
    assert test_case_0() == '"8\\r:$shT8h!Swo\\tPt1:[g"'


# Generated at 2022-06-24 21:03:06.468799
# Unit test for function jsonify
def test_jsonify():
    for i in range(100):
        test_case_0()

#-----------------------------------------------------------------------

# Generated at 2022-06-24 21:03:14.426410
# Unit test for function jsonify
def test_jsonify():
    str_0 = '8\r:$shT8h!Swo\tPt1:[g'
    assert jsonify(str_0) == '"8\\r:$shT8h!Swo\\tPt1:[g"'


# Generated at 2022-06-24 21:03:17.296172
# Unit test for function jsonify
def test_jsonify():

    # Call function jsonify with arguments:
    # '8\r:$shT8h!Swo\tPt1:[g'
    test_case_0()


# Generated at 2022-06-24 21:03:19.766164
# Unit test for function jsonify
def test_jsonify():
    var_0 = jsonify(str_0)
    print(var_0)

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-24 21:03:25.539462
# Unit test for function to_native
def test_to_native():
    assert(to_native(b'12345') == '12345')
    assert(to_native(u'12345') == u'12345')
    # If you pass in a non-string something else is going on.
    # Just return the original object.
    class Foo:
        def __str__(self):
            return 'foo'
    obj = Foo()
    assert(to_native(obj) == obj)


# Generated at 2022-06-24 21:03:32.783945
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'\xe2\x98\x83') == b'\xe2\x98\x83'
    assert to_bytes('\xe2\x98\x83') == b'\xe2\x98\x83'
    assert to_bytes(u'\u2603') == b'\xe2\x98\x83'
    # Surrogates in a text string
    assert to_bytes(u'u\ud800\udc00u') == b'uuuu'
    # Surrogates in a text string with a non-utf8 encoding
    assert to_bytes(u'u\ud800\udc00u', encoding='iso-8859-1') == b'uuuu'
    # Surrogates in a byte string

# Generated at 2022-06-24 21:03:38.105491
# Unit test for function to_native
def test_to_native():
    result = to_native(b'\x80\x00\x80\x00\x80')
    result_binary = to_bytes(b'\x80\x00\x80\x00\x80')
    assert result_binary == result


# Generated at 2022-06-24 21:03:40.506087
# Unit test for function jsonify
def test_jsonify():
    try:
        test_case_0()
    except Exception as err:
        print("Caught exception: %s" % err)

# Run test cases
test_jsonify()

# Generated at 2022-06-24 21:03:49.529919
# Unit test for function to_bytes
def test_to_bytes():
    # test default to_bytes
    assert to_bytes('x') == b'x'
    assert to_bytes(b'x') == b'x'
    assert to_bytes(1) == b'1'
    assert isinstance(to_bytes(1), binary_type)

    # test encoding
    assert to_bytes('x', encoding='ascii') == b'x'
    assert to_bytes('x', encoding='ascii') == b'x'
    assert to_bytes('€', encoding='iso-8859-15') == b'\xa4'
    assert to_bytes('€', encoding='ascii') == b''

    # test nonstring
    assert to_bytes(1, nonstring='empty') == b''
    assert to_bytes(1, nonstring='passthru') == 1

# Generated at 2022-06-24 21:03:54.043430
# Unit test for function jsonify
def test_jsonify():
    str_0 = '8\r:$shT8h!Swo\tPt1:[g'
    var_0 = jsonify(str_0)
    assert var_0 != str_0
    assert var_0 == '"8\\r:$shT8h!Swo\\tPt1:[g"'



# Generated at 2022-06-24 21:04:00.157551
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = '8\r:$shT8h!Swo\tPt1:[g'
    bin_0 = to_bytes(str_0, errors='surrogate_or_replace')
    assert isinstance(bin_0, bytes)
    assert '8\r:$shT8h!Swo\tPt1:[g' == bin_0.decode()


# Generated at 2022-06-24 21:04:15.553713
# Unit test for function to_native
def test_to_native():
    assert to_native('12345') == '12345'
    assert to_native(u'12345') == '12345'
    assert to_native(b'12345') == b'12345'
    assert to_native(bytearray(b'12345')) == b'12345'
    assert to_native(12345) == 12345
    assert to_native(None) is None
    assert to_native([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert to_native({1:2, 3:4}) == {1:2, 3:4}
    assert to_native(True) is True
    assert to_native(False) is False
    if PY3:
        text_type = 'str'
        binary_type = 'bytes'

# Generated at 2022-06-24 21:04:18.180735
# Unit test for function jsonify
def test_jsonify():
    test_case_0()



# Generated at 2022-06-24 21:04:26.978010
# Unit test for function to_bytes
def test_to_bytes():
    int_0 = 0
    int_1 = 0
    # the obj will be True or False, depending on whether the
    # isinstance() test succeeded
    var_0 = isinstance(int_0, binary_type)
    # We may want to print the value of var_0 (and other variables) during
    # development. Use '# print' with parentheses around the variable(s) you
    # want to see.
    print(var_0)
    # # print(var_1)
    # # print(var_2)
    # # print(var_3)
    # # print(var_4)
    # # print(var_5)
    # # print(var_6)
    # # print(var_7)
    # # print(var_8)
    # # print(var_9)
   

# Generated at 2022-06-24 21:04:28.899300
# Unit test for function to_native
def test_to_native():
    assert to_native({}) == "{}"

if __name__ == '__main__':
    test_to_native()

# Generated at 2022-06-24 21:04:35.963125
# Unit test for function to_native
def test_to_native():
    assert to_native('8\r:$shT8h!Swo\tPt1:[g') == '8\r:$shT8h!Swo\tPt1:[g'
    assert to_native(u'8\r:$shT8h!Swo\tPt1:[g') == u'8\r:$shT8h!Swo\tPt1:[g'


# Generated at 2022-06-24 21:04:46.518694
# Unit test for function jsonify
def test_jsonify():
    print(jsonify('8\r:$shT8h!Swo\tPt1:[g'))
    print(jsonify('8\r:$shT8h!Swo\tPt1:[g'))
    print(jsonify('8\r:$shT8h!Swo\tPt1:[g'))
    print(jsonify('8\r:$shT8h!Swo\tPt1:[g'))
    print(jsonify('8\r:$shT8h!Swo\tPt1:[g'))
    print(jsonify('8\r:$shT8h!Swo\tPt1:[g'))
    print(jsonify('8\r:$shT8h!Swo\tPt1:[g'))

# Generated at 2022-06-24 21:04:49.895890
# Unit test for function jsonify
def test_jsonify():
    assert json.loads('8\\r:$shT8h!Swo\\tPt1:[g') == json.loads(jsonify('8\r:$shT8h!Swo\tPt1:[g'))


# Generated at 2022-06-24 21:04:57.582161
# Unit test for function to_native
def test_to_native():
    assert to_native('ascii') == u'ascii'
    assert to_native(u'unicode') == u'unicode'
    assert to_native(b'binary') == u'binary'
    assert to_native(b'foo\xc3\xa7'.decode('utf-8'), errors='surrogate_then_replace') == u'foo\ufffd\ufffd'
    assert to_native(b'foo\xc3\xa7') == u'foo\xfffd'


# Generated at 2022-06-24 21:05:07.861608
# Unit test for function to_bytes
def test_to_bytes():
    print('Testing function to_bytes')

    # Test with no parameters
    print('Test #1')
    print('to_bytes()', to_bytes())
    assert to_bytes() == b''

    # Test with one parameter
    print('Test #2')
    print('to_bytes(\'hello world\')', to_bytes('hello world'))
    assert to_bytes('hello world') == b'hello world'

    # Test with two parameters
    print('Test #3')
    print('to_bytes(\'hello world\', \'latin-1\')', to_bytes(
        'hello world', 'latin-1'))
    assert to_bytes('hello world', 'latin-1') == b'hello world'

    # Test with three parameters
    print('Test #4')

# Generated at 2022-06-24 21:05:08.920098
# Unit test for function to_native
def test_to_native():
    pass


# Generated at 2022-06-24 21:05:17.860435
# Unit test for function jsonify
def test_jsonify():
    json_str = text_type('{"ok":true,"test":[{"test1":"test1","test2":"test2"}]}')
    json_str_in = json.loads(json_str)
    ret = jsonify(json_str_in)
    return ret


# Generated at 2022-06-24 21:05:20.020881
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = '\n    Unit test for function to_bytes\n    '
    var_0 = to_bytes(str_0)
    assert var_0 == to_bytes(str_0)



# Generated at 2022-06-24 21:05:26.323901
# Unit test for function jsonify
def test_jsonify():
    data = {'name': u'中文'}
    jsonify(data)
    data = {'name': 'foo'}
    jsonify(data)
    data = {u'name': 'foo'}
    jsonify(data)
    data = {u'name': u'中文'}
    jsonify(data)

test_jsonify()

# Generated at 2022-06-24 21:05:31.033187
# Unit test for function jsonify
def test_jsonify():
    data = {u'\u57fa\u672c': [u'\u57fa\u672c', u'\u57fa\u672c'], 'basic': ['basic', 'basic']}
    assert jsonify(data) == '{"basic": ["basic", "basic"], "\\u57fa\\u672c": ["\\u57fa\\u672c", "\\u57fa\\u672c"]}'


# Generated at 2022-06-24 21:05:32.992450
# Unit test for function to_native
def test_to_native():
    # Call function with args
    # Call function with default args
    try:
        to_native()
    except TypeError:
        pass
    else:
        assert False, "Expected exception"


# Generated at 2022-06-24 21:05:37.361213
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = '\n    Unit test for function to_bytes\n    '
    var_0 = to_bytes(str_0)


# Generated at 2022-06-24 21:05:41.737304
# Unit test for function jsonify
def test_jsonify():
    jsonify(data={'a': 'b'})


# Generated at 2022-06-24 21:05:49.390585
# Unit test for function to_native
def test_to_native():
    # From https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/_text.py#L332
    native_dict = dict()
    dict_0 = dict()
    dict_0['a'] = 1
    dict_0['b'] = 2
    dict_0['c'] = 3
    dict_0['d'] = dict()
    dict_1 = dict()
    dict_1['a'] = 1
    dict_1['b'] = 2
    dict_1['c'] = 3
    dict_1['d'] = dict()
    list_0 = list()
    list_0.append(dict_0)
    list_0.append(dict_1)
    native_dict['list'] = list_0
    set_0 = Set()
    set_0

# Generated at 2022-06-24 21:05:51.061229
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'abcde') == b'abcde'


# Generated at 2022-06-24 21:05:52.769301
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = '\n    Unit test for function to_bytes\n    '
    var_0 = to_bytes(str_0)


# Generated at 2022-06-24 21:06:00.981445
# Unit test for function jsonify
def test_jsonify():
    print('\n    Unit test for function jsonify\n    ')
    var_0 = jsonify({'a':'b'})


# Generated at 2022-06-24 21:06:08.038112
# Unit test for function to_native
def test_to_native():
    var_5 = '{"a": 1}'
    if PY3:
        var_5 = var_5.encode('utf-8')
    var_0 = to_native(var_5)
    assert isinstance(var_0, text_type)
    assert var_0 == u'{"a": 1}'
    assert isinstance(var_0, text_type)
    assert var_0 == '{"a": 1}'


# Generated at 2022-06-24 21:06:15.252615
# Unit test for function jsonify
def test_jsonify():
    dict_0 = {'v6': '2a02:a448:ddb0::1', 'v4': '4.4.4.4'}
    dict_1 = dict_0
    dict_1['v4'] = '4.4.4.4'
    var_0 = jsonify(dict_1)
    assert var_0 == '{"v6": "2a02:a448:ddb0::1", "v4": "4.4.4.4"}'
    dict_1['v4'] = '4.4.4.4'
    var_1 = jsonify(dict_1)
    assert var_1 == '{"v6": "2a02:a448:ddb0::1", "v4": "4.4.4.4"}'