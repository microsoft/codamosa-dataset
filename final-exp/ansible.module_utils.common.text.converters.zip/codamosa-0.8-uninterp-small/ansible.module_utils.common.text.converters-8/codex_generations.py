

# Generated at 2022-06-24 20:56:39.323074
# Unit test for function to_native
def test_to_native():
    for d in (u"foo", b"foo", dict(key=u"value"), dict(key=b"value")):
        for e in ('utf8', 'latin1'):
            for f in ('surrogate_or_replace', 'surrogate_or_strict', 'strict'):
                try:
                    to_native(d, encoding=e, errors=f)
                except Exception as err:
                    print("Unable to execute function 'to_native'")
                    raise(err)


# Generated at 2022-06-24 20:56:49.217290
# Unit test for function to_bytes
def test_to_bytes():
    # Check that to_bytes returns a bytes object (Note: this is a redundant
    # check since the implementation guarantees this but it's here for
    # illustrative purposes)
    if not isinstance(to_bytes(''), binary_type):
        fail_json('to_bytes(string) failed internal test #1')

    # If a byte string is passed in, to_bytes should return that byte string
    # unchanged
    test_string = u'test_string'
    utf8_string = to_bytes(test_string)
    if to_bytes(utf8_string) != utf8_string:
        fail_json('to_bytes(to_bytes(string)) failed internal test #2')

    # If Unicode with no surrogates is passed in, to_bytes should return a utf8
    # encoded byte string

# Generated at 2022-06-24 20:56:52.465648
# Unit test for function to_native
def test_to_native():
    assert to_native(text_type('hello')) == 'hello'
    assert to_native(u'café') == u'café'
    assert to_native(b'caf\xc3\xa9') == u'café'
    assert to_native(1) == 1
    assert to_native(u'\u1234') == u'\u1234'


# Generated at 2022-06-24 20:57:04.338466
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text

    def utf8_text_and_binary(s):
        u = to_text(s, 'utf-8')
        b = to_bytes(s)
        return u, b


# Generated at 2022-06-24 20:57:15.096181
# Unit test for function to_native

# Generated at 2022-06-24 20:57:17.628552
# Unit test for function to_bytes
def test_to_bytes():
    list_0 = [1,2,3]
    dict_0 = {
        'id' : list_0,
        'text' : '<script>alert(1);</script>'
    }
    var_0 = container_to_bytes(dict_0)
    # may raise exception TypeError
    #     may raise exception UnicodeEncodeError
    #     may raise exception UnicodeEncodeError


# Generated at 2022-06-24 20:57:20.175877
# Unit test for function jsonify
def test_jsonify():
    data = { "prop0": "val0", "prop1": {"sub0": "sub0", "sub1": [1, 2, 3]}}
    assert jsonify(data) == "{\"prop0\": \"val0\", \"prop1\": {\"sub0\": \"sub0\", \"sub1\": [1, 2, 3]}}"


# Generated at 2022-06-24 20:57:22.008350
# Unit test for function to_native
def test_to_native():
    dict_0 = {}
    var_0 = to_native(dict_0)
    assert var_0 == dict_0


# Generated at 2022-06-24 20:57:32.792092
# Unit test for function to_native
def test_to_native():
    native_1 = to_native(None)
    assert(native_1 == '')
    assert(type(native_1) == str)
    native_2 = to_native('ansible')
    assert(native_2 == 'ansible')
    assert(type(native_2) == str)
    native_3 = to_native(u'ansible')
    assert(native_3 == 'ansible')
    assert(type(native_3) == str)
    native_4 = to_native(2)
    assert(native_4 == 2)
    assert(type(native_4) == int)
    native_5 = to_native(set())
    assert(native_5 == set())
    assert(type(native_5) == set)
    native_6 = to_native((1, 2))

# Generated at 2022-06-24 20:57:34.532000
# Unit test for function to_native
def test_to_native():
    from sys import version_info
    if version_info.major >= 3:
        assert isinstance(to_native(b'foo'), str)
    else:
        assert isinstance(to_native(b'foo'), unicode)



# Generated at 2022-06-24 20:57:41.969734
# Unit test for function to_bytes
def test_to_bytes():
    result = to_bytes(str)
    assert result == '<class \'str\'>'


# Generated at 2022-06-24 20:57:44.545357
# Unit test for function jsonify
def test_jsonify():
    my_dict = { "key": "value"}
    print("JSONDumps: ")
    print(jsonify(my_dict))
    #print(jsonify("test"))

test_jsonify()

# Generated at 2022-06-24 20:57:54.882442
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    # Disabled for now until we can figure out what idiom to use for this
    #assert to_bytes(u'\u2603') == b'\xe2\x98\x83'
    #assert to_bytes('\xfc') == b'\xc3\xbc'
    #assert to_bytes(u'\xfc', encoding='latin-1') == b'\xfc'
    #assert to_bytes('\xfc', errors='surrogateescape') == b'\xfc'
    #assert to_bytes(u'\xfc', encoding='latin-1', errors='surrogateescape') == b'\xfc'
    #assert to_bytes(u'\xfc

# Generated at 2022-06-24 20:57:55.873646
# Unit test for function to_native
def test_to_native():
    assert to_text(1) == u"1"


# Generated at 2022-06-24 20:57:59.942646
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(to_text('123')) == '123'
    assert to_bytes(to_text('123'), errors='surrogate_or_replace') == '123'
    assert to_bytes(to_text('123'), errors='surrogate_or_strict') == '123'


# Generated at 2022-06-24 20:58:13.177766
# Unit test for function to_bytes
def test_to_bytes():
    # Test type
    assert type(to_bytes('foo')) == str
    # Test a basic string case
    assert to_bytes('foo bar') == b'foo bar'
    # Test a string that contains a unicode character
    assert to_bytes('foo bar 💩') == b'foo bar \xf0\x9f\x92\xa9'
    # Test a binary string case
    assert to_bytes(b'foo bar') == b'foo bar'
    # Test simplerepr
    assert to_bytes(b'foo bar', nonstring='simplerepr') == b'foo bar'
    # Test an integer with simplerepr
    assert to_bytes(0, nonstring='simplerepr') == b'0'
    # Test passthru

# Generated at 2022-06-24 20:58:15.179556
# Unit test for function jsonify
def test_jsonify():
    try:
        assert jsonify('', 'pretty') == '""'
    except AssertionError as e:
        print(e)
        raise


# Generated at 2022-06-24 20:58:24.538062
# Unit test for function to_native
def test_to_native():
    import datetime
    from ansible.module_utils._text import to_native

    assert to_native('hello') == 'hello'
    assert to_native(u'hello') == 'hello'
    assert to_native(b'hello') == 'hello'

    assert to_native('hello', nonstring='passthru') == 'hello'
    assert to_native(u'hello', nonstring='passthru') == u'hello'
    assert to_native(b'hello', nonstring='passthru') == b'hello'

    assert to_native(True) == 'True'
    assert to_native(False) == 'False'
    assert to_native(None) == 'None'
    assert to_native(1.23) == '1.23'

# Generated at 2022-06-24 20:58:33.247694
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u"123") == b"123"
    assert isinstance(to_bytes(u"123"), binary_type)
    if PY3:
        assert to_bytes(b"123") == b"123"
    else:
        assert to_bytes(b"123") == "123"
    assert to_bytes(u"\xff") == b"\xff"
    assert to_bytes(b"\xff") == b"\xff"
    assert to_bytes(u"") == b""
    assert to_bytes(b"") == b""
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(u"\x80", errors='strict') == b"\xc3\x80"

# Generated at 2022-06-24 20:58:40.693580
# Unit test for function to_bytes

# Generated at 2022-06-24 20:58:53.063540
# Unit test for function to_bytes
def test_to_bytes():
    var_1 = to_bytes(str_0)
    assert var_1 is not None,\
        "test_to_bytes: to_bytes should return a value"
    assert isinstance(var_1, (str, bytes)),\
        "test_to_bytes: to_bytes should return a string"

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 20:59:02.456752
# Unit test for function to_bytes
def test_to_bytes():
    # mock obj
    mock_obj = Mock()
    mock_obj.__str__ = Mock(return_value='mock')
    mock_obj.__repr__ = Mock(return_value='mock')

    # mock str
    mock_str = Mock()

    # mock str with surrogateescape
    mock_str_surrogateescape = Mock()
    mock_str_surrogateescape.encode = Mock(return_value='foo')
    mock_str_surrogateescape.decode = Mock(return_value='bar')

    from ansible.module_utils._text import to_bytes as f
    import sys

    # Pass a byte string and ensure it is unchanged
    param = 'foo'
    expected_result = b'foo'
    result = f(param)
    assert result == expected_result

    # Pass

# Generated at 2022-06-24 20:59:04.159242
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(data={'foo':'bar'}) == '{"foo": "bar"}'



# Generated at 2022-06-24 20:59:14.064124
# Unit test for function to_native
def test_to_native():
    str_0 = 'foo'
    var_0 = to_native(str_0)
    str_1 = 'c6e3b6a9b6e3b6e3'
    var_1 = to_native(str_1, errors='surrogate_or_strict')
    str_2 = 'foo'
    var_2 = to_native(str_2, encoding='utf8', errors='surrogate_or_replace', nonstring='passthru')
    str_3 = 'foo'
    var_3 = to_native(str_3, encoding='utf8', errors='surrogate_or_strict')
    str_4 = 'foo'
    var_4 = to_native(str_4, encoding='utf8', errors='surrogate_then_replace', nonstring='empty')


# Generated at 2022-06-24 20:59:16.272495
# Unit test for function to_native
def test_to_native():
    str_0 = 'foo'
    var_0 = to_native(str_0)
    assert var_0 == 'foo'


# Generated at 2022-06-24 20:59:23.747379
# Unit test for function jsonify
def test_jsonify():
    data = {'foo': to_native(u'bar')}
    # TypeError is raised if the data is not json serializable.
    # TypeError: Object of type 'dict_values' is not JSON serializable
    print(jsonify(data))

    data = {to_native(u'foo'): to_native(u'bar')}
    # TypeError is raised if the data is not json serializable.
    # TypeError: Object of type 'dict_keys' is not JSON serializable
    print(jsonify(data))

    data = {to_native(u'foo'): to_native(u'bar')}
    # TypeError is raised if the data is not json serializable.
    # TypeError: Object of type 'dict_keys' is not JSON serializable
    print(jsonify(data))


# Generated at 2022-06-24 20:59:25.915763
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'foo'
    var_0 = to_bytes(str_0)



# Generated at 2022-06-24 20:59:31.315905
# Unit test for function jsonify
def test_jsonify():
    assert json.dumps({"b": 2, "c": 3, "a": 1}, sort_keys=True) == jsonify({"a": 1, "b": 2, "c": 3})



# Generated at 2022-06-24 20:59:40.724886
# Unit test for function jsonify
def test_jsonify():
    print('Testing function jsonify...')

    data = dict(key='value')

    ref_data_1 = jsonify(data)

    assert '"key": "value"' in ref_data_1

    data = {'key': ('value',)}

    ref_data_1 = jsonify(data)

    assert '"key": ["value"]' in ref_data_1

    data = dict(foo=set([1,2,3]))

    ref_data_1 = jsonify(data)

    assert '"foo": [1, 2, 3]' in ref_data_1

    data = dict(foo=set([1,2,3]), bar='baz')

    ref_data_1 = jsonify(data)

    assert '"foo": [1, 2, 3]' in ref_data_1

# Generated at 2022-06-24 20:59:45.857015
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'foo'
    var_0 = to_bytes(str_0)
    assert isinstance(var_0, binary_type)
    assert var_0 == b'foo'

    str_1 = 'bar'
    var_1 = to_bytes(str_1, encoding='ascii')
    assert isinstance(var_1, binary_type)
    assert var_1 == b'bar'

    str_2 = u'\u2019'  # right single quote
    var_2 = to_bytes(str_2)
    assert isinstance(var_2, binary_type)
    assert var_2 == b'\xe2\x80\x99'

    str_3 = u'\u2019'  # right single quote

# Generated at 2022-06-24 20:59:55.457772
# Unit test for function to_bytes
def test_to_bytes():
    assert str(to_bytes('foo', 'ascii')) == b"b'foo'"
    assert str(to_bytes('foo', nonstring='simplerepr')) == b"b'foo'"
    assert str(to_bytes(None, nonstring='simplerepr')) == "b'None'"


# Generated at 2022-06-24 21:00:06.506031
# Unit test for function to_bytes
def test_to_bytes():
    assert(to_bytes('abc') == b'abc')
    assert(to_bytes(to_bytes('abc')) == b'abc')
    assert(to_bytes(u'abc') == b'abc')
    assert(to_bytes(None) == b'')
    assert(to_bytes(u'\ubcf4') == b'\xed\xa0\xbf')

    # non-ascii unicode escapes (e.g., '\u00e9') are not valid in python3
    if PY3:
        assert(to_bytes(u'\u00e9') == b'\xc3\xa9')
    else:
        assert(to_bytes(u'\u00e9') == b'\xe9')

    # If a str can't be encoded, it will be replaced by the

# Generated at 2022-06-24 21:00:09.486980
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'foo'
    var_0 = to_bytes(str_0)

    assert(type(var_0) == bytes)
    assert(var_0 == b'foo')


# Generated at 2022-06-24 21:00:17.558739
# Unit test for function to_native

# Generated at 2022-06-24 21:00:20.753333
# Unit test for function jsonify
def test_jsonify():
	#assert 'foo' == jsonify('foo')
	foo = 'foo'
	assert foo == jsonify(foo)


# Generated at 2022-06-24 21:00:29.223782
# Unit test for function to_native
def test_to_native():

    # Set test requirements
    #from .ansible_mitogen import ansible_mitogen_bool
    from .ansible_mitogen import ansible_mitogen_string


    # Test function to_native with non-unicode strings and bytes
    str_0 = 'foo' # type: str
    bytes_0 = b'bar' # type: bytes
    var_0 = to_native(str_0)
    var_1 = to_native(bytes_0)



# Generated at 2022-06-24 21:00:35.371431
# Unit test for function jsonify
def test_jsonify():
    # Run test 1
    data = {
        u'a': u'foo',
        u'b': u'bar',
        u'c': {
            u'c1': u'baz',
            u'c2': u'qux',
            u'c3': [1, 2, 3],
            u'c4': {
                u'c41': u'quux',
                u'c42': u'corge',
            },
        },
        u'd': [4, 5, 6],
    }

# Generated at 2022-06-24 21:00:46.457645
# Unit test for function to_bytes
def test_to_bytes():
    str0 = 'foo'
    var0 = to_bytes(str0)
    print(repr(var0))
    str1 = 'foo'
    var1 = to_bytes(str1)
    print(repr(var1))
    str2 = 'foo'
    var2 = to_bytes(str2)
    print(repr(var2))
    str3 = 'foo'
    var3 = to_bytes(str3)
    print(repr(var3))
    str4 = 'foo'
    var4 = to_bytes(str4)
    print(repr(var4))
    str5 = 'foo'
    var5 = to_bytes(str5)
    print(repr(var5))
    str6 = 'foo'
    var6 = to_bytes(str6)

# Generated at 2022-06-24 21:00:54.394100
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes('\u1234') == b'\xe1\x88\xb4'
    assert to_bytes('\u1234', encoding='latin-1') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\xe1\x88\xb4'

    if PY3:
        assert to_bytes('\u1234', errors='surrogateescape') == b'\xed\xa0\x88\xed\xb4\xb4'

# Generated at 2022-06-24 21:00:59.581173
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_text

    data = {'foo': True, 'bar': False}
    assert len(list(iteritems(data))) == 2
    assert jsonify(data) == '{"bar": false, "foo": true}'



# Generated at 2022-06-24 21:01:15.515291
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(text_type('foo')) == binary_type('foo')
    assert to_bytes(text_type('foo'), encoding='ascii') == binary_type('foo')
    assert to_bytes(text_type('\u00f6'), errors='surrogate_or_replace') == binary_type('\ufffd')
    assert to_bytes(text_type('\u00f6'), encoding='ascii', errors='surrogate_or_replace') == binary_type('\ufffd')
    assert to_bytes(binary_type('foo')) == binary_type('foo')
    assert to_bytes(binary_type('foo'), encoding='ascii') == binary_type('foo')
    assert to_bytes(5) == binary_type('5')

# Generated at 2022-06-24 21:01:18.094595
# Unit test for function jsonify
def test_jsonify():
    str_0 = 'string'
    dict_0 = dict()
    dict_0['key_0'] = str_0
    json_0 = jsonify(dict_0)
    assert json_0 == json_0


# Generated at 2022-06-24 21:01:23.694757
# Unit test for function jsonify
def test_jsonify():
    import json

    # Test with a dictionary
    data = {'a': 'b', 'c': 'd'}
    data_json = jsonify(data)
    if not data_json == '{"a": "b", "c": "d"}':
        raise AssertionError('Expected {"a": "b", "c": "d"}, but got %s' % data_json)
    # Test with a nested dictionary
    data = {'a': 'b', 'c': 'd', 'nests': {'a': 'b', 'c': 'd'}}
    data_json = jsonify(data)

# Generated at 2022-06-24 21:01:31.012389
# Unit test for function jsonify
def test_jsonify():
    data = {"foo": ["bar", u"baz"]}
    # str_1 is a string encoded in latin-1
    str_1 = bytes(b'fo\xf6')
    data[str_1] = "qux"

    str_5 = jsonify(data)

    assert(str_5)



# Generated at 2022-06-24 21:01:32.493571
# Unit test for function jsonify
def test_jsonify():
    data = dict(type=None)

# Generated at 2022-06-24 21:01:39.237650
# Unit test for function to_native
def test_to_native():
    str_0 = 'foo'
    var_0 = to_native(str_0)
    str_1 = 'foo'
    var_1 = to_native(str_1)
    str_2 = 'foo'
    var_2 = to_native(str_2)


# Generated at 2022-06-24 21:01:45.460390
# Unit test for function to_bytes
def test_to_bytes():
    # Testing if the function returns a bytes
    str_0 = 'foo'
    var_0 = to_bytes(str_0)
    assert isinstance(var_0, bytes) == True

    # Test #1 - Testing the default encoding(utf-8)
    str_1 = 'foo'
    var_1 = to_bytes(str_1)
    expected = 'foo'
    actual = var_1
    assert actual == expected

    # Test #2 - Testing other encoding(latin-1)
    str_2 = 'foo'
    var_2 = to_bytes(str_2, encoding='latin-1')
    expected = 'foo'
    actual = var_2
    assert actual == expected

    # Test #3 - Testing other encoding(latin-1) and other errors(strict)
    str_3

# Generated at 2022-06-24 21:01:47.744457
# Unit test for function jsonify
def test_jsonify():
    data = {u'foo': u'bar', u'baz': u'blah'}
    for k,v in iteritems(data):
        assert type(jsonify(data)) == str



# Generated at 2022-06-24 21:01:57.563970
# Unit test for function to_bytes
def test_to_bytes():
    # Testing a text string with a simple error handler
    str_0 = 'foo'
    var_0 = to_bytes(str_0)
    assert isinstance(var_0, binary_type)

    # Testing a text string with an error handler that uses surrogateescape
    # Note: surrogateescape is only available in python3
    # str_1 = u'\udce5foo'
    # var_1 = to_bytes(str_1, errors='surrogate_or_replace')
    # assert isinstance(var_1, binary_type)

    # Testing a text string with a replace error handler
    str_2 = u'\udce5foo'
    var_2 = to_bytes(str_2, errors='replace')
    assert isinstance(var_2, binary_type)

    # Testing a text string with a strict

# Generated at 2022-06-24 21:02:00.913892
# Unit test for function jsonify
def test_jsonify():
    str_0 = jsonify([1,2,3,4])


# Generated at 2022-06-24 21:02:10.582890
# Unit test for function to_bytes
def test_to_bytes():
    pass



# Generated at 2022-06-24 21:02:15.519429
# Unit test for function jsonify
def test_jsonify():
    # Parameters:
    data = dict(name='John Doe')
    expected = '{"name": "John Doe"}'
    # Actual:
    actual = jsonify(data, sort_keys=True)
    # Assert:
    assert expected == actual


# Generated at 2022-06-24 21:02:18.910640
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'foo'
    var_0 = to_bytes(str_0)


# Generated at 2022-06-24 21:02:22.828630
# Unit test for function jsonify
def test_jsonify():

    assert jsonify({u'key-0': u'value-0'}) == u'{"key-0": "value-0"}'
    assert jsonify({}) == u'{}'
    assert jsonify(u'string') == u'"string"'



# Generated at 2022-06-24 21:02:29.700399
# Unit test for function jsonify
def test_jsonify():

    data = dict(
        foo=to_bytes('bar'),
        bar=set((1, 2, 3)),
        bam=datetime.datetime(2017, 1, 2, 3, 4, 5, 6)
    )
    test = jsonify(data)
    assert to_text(test) == u'''{"foo": "\x62ar", "bam": "2017-01-02T03:04:05.000006", "bar": [1, 2, 3]}'''



# Generated at 2022-06-24 21:02:37.108788
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'foo'
    var_0 = to_bytes(str_0)
    assert var_0 == 'foo'
    str_0 = 'АБВГД'
    var_0 = to_bytes(str_0)
    assert var_0 == 'АБВГД'
    str_0 = '福'
    var_0 = to_bytes(str_0)
    assert var_0 == '福'
    str_0 = '‹›'
    var_0 = to_bytes(str_0)
    assert var_0 == '‹›'
    str_0 = 'Š'
    var_0 = to_bytes(str_0)
    assert var_0 == 'Š'
    str_0

# Generated at 2022-06-24 21:02:39.071919
# Unit test for function jsonify
def test_jsonify():
  assert jsonify(dict(a=1)) == json.dumps(dict(a=1))


# Generated at 2022-06-24 21:02:41.506546
# Unit test for function jsonify
def test_jsonify():
    test_data = {
        'a_string': 'toolong' * 1000,
        'a_set': set([1, 2]),
        'a_datetime': datetime.datetime(2018, 1, 1)
        }
    jsonify(test_data)

# Generated at 2022-06-24 21:02:42.813385
# Unit test for function to_native
def test_to_native():
    x = 'foo'
    expected = 'foo'
    res = to_native(x)
    assert res == expected


# Generated at 2022-06-24 21:02:46.332776
# Unit test for function to_native
def test_to_native():
    assert to_native(b'n\xc3\xa3o') == u'não'
    assert to_native(b'n\xc3\xa3o', encoding=None) == u'n\xc3\xa3o'


# Generated at 2022-06-24 21:02:58.993272
# Unit test for function to_native
def test_to_native():
    #
    # Test a dict.
    #

    dict_0 = dict(key_1=123, key_2=u'456')

    assert to_native(dict_0) == {'key_1': 123, 'key_2': '456'}

    #
    # Test a number.
    #

    assert to_native(123) == 123

    #
    # Test a string.
    #

    assert to_native(u'foo') == 'foo'

    #
    # Test a list.
    #

    list_0 = [123, u'456']

    assert to_native(list_0) == [123, '456']

    #
    # Test a set.
    #

    set_0 = Set()
    set_0.add(123)

# Generated at 2022-06-24 21:03:01.591361
# Unit test for function jsonify
def test_jsonify():
    #my_list = [1, 2, "text"]
    my_list = ["foo", "bar"]
    print(jsonify(my_list))


# Generated at 2022-06-24 21:03:05.100663
# Unit test for function to_native
def test_to_native():
    assert to_bytes('foo') == b'foo'
    assert to_text(b'foo') == 'foo'
    #assert to_bytes(b'foo') == b'foo'
    #assert to_text('foo') == 'foo'

    #test_case_0()

test_to_native()

# Generated at 2022-06-24 21:03:07.616031
# Unit test for function to_native
def test_to_native():
    result = to_native(None)
    # assert result == 'None'
    result = to_native(['Hello'])
    # assert result == "['Hello']"
    result = to_native(["Hello"])
    # assert result == "['Hello']"


# Generated at 2022-06-24 21:03:18.254450
# Unit test for function to_native
def test_to_native():
    utf8_b = b'\xc3\xbc'
    utf8_u = u'\xfc'
    latin1_b = b'\xfc'
    latin1_u = u'\xfc'
    # both byte strings are the same byte string
    assert to_bytes(utf8_b, 'utf-8') == to_bytes(latin1_b, 'latin1')
    # validate that we get the same byte string when converting from the
    # different unicode strings
    assert to_bytes(utf8_u, 'utf-8') == to_bytes(latin1_u, 'latin1')
    # validate that we get the same byte string when converting from the
    # different unicode strings with different encodings

# Generated at 2022-06-24 21:03:20.062706
# Unit test for function jsonify
def test_jsonify():
    assert 'jsonify' is jsonify  # Check that we are using the correct method
    assert True is True


# Generated at 2022-06-24 21:03:22.581636
# Unit test for function jsonify
def test_jsonify():
    str_0 = 'foo'
    var_0 = jsonify(str_0)


# Generated at 2022-06-24 21:03:33.134015
# Unit test for function to_native
def test_to_native():
    str_0 = to_native('foo')
    assert str_0 == 'foo'

    str_1 = to_native('foo\nbar')
    assert str_1 == b'foo\nbar'

    str_2 = to_native('foo\nbar', resolve_nonstring='passthru')
    assert str_2 == 'foo\nbar'

    str_3 = to_native('foo\nbar', resolve_nonstring='strict')
    assert str_3 == 'foo\nbar'

    str_4 = to_native('foo\nbar', resolve_nonstring='empty')
    assert str_4 == 'foo\nbar'

    str_5 = to_native('foo\nbar', resolve_nonstring='simplerepr')
    assert str_5 == 'foo\nbar'

# Unit

# Generated at 2022-06-24 21:03:44.904102
# Unit test for function jsonify
def test_jsonify():
    # NOTE: this jsonify function is only used by the ansible cli tool, so
    # we'll modify it as needed in order to make it easy to test
    data = {'unicode': u'this \u00e9\u2122', 'byte_str': b'foo \xe2\x82', 'list': [u'this \u00e9\u2122', b'bar']}
    data_text = jsonify(data)
    data_native_str = jsonify(data, ensure_ascii=False)

    if not PY3:
        assert isinstance(data_native_str, str)
        assert isinstance(data_text, str)
        assert isinstance(data_text, str)

    # ensure utf-8 is not in the text version
    assert data['unicode'].encode

# Generated at 2022-06-24 21:03:47.748189
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'foo'
    var_0 = to_bytes(str_0)


# Generated at 2022-06-24 21:03:59.981490
# Unit test for function jsonify
def test_jsonify():
    # test for a valid string value that is an "u" followed by any ASCII letters
    str_0 = 'u1'
    data_0 = jsonify(str_0)
    assert type(data_0) is str
    # test if the string value is a valid unicode string
    str_1 = u'testing unicode string'
    data_1 = jsonify(str_1)
    assert data_1 == str_1


# Generated at 2022-06-24 21:04:10.800836
# Unit test for function jsonify
def test_jsonify():
    # Test function input types
    data = {'foo': 'bar'}
    assert jsonify(data) == jsonify(data)
    assert jsonify(data, separators=",") == jsonify(data, separators=",")
    assert jsonify(data, separators=(",", ":")) == jsonify(data, separators=(",", ":"))
    assert jsonify(data, sort_keys=True) == jsonify(data, sort_keys=True)
    assert jsonify(data, indent=4) == jsonify(data, indent=4)
    assert jsonify(data, sort_keys=True, indent=4) == jsonify(data, sort_keys=True, indent=4)


# Generated at 2022-06-24 21:04:13.493123
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'foo'
    expected = u'foo'
    actual = to_bytes(str_0)
    assert actual == expected, 'Expected %s but got %s' % (expected, actual)



# Generated at 2022-06-24 21:04:20.493339
# Unit test for function jsonify
def test_jsonify():
    import os
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text

    module = basic.AnsibleModule(argument_spec={'one': {'type': 'dict'}})

    try:
        os.unlink('/tmp/test.txt')
    except OSError:
        pass

    data = {'one': {'two': 'three', 'four': [5, 6, 7]}}

    # Make sure our encode handler is called
    data['one']['five'] = Set([8, 9, 10])

    # Make sure time objects are json encodable
    data['one']['six'] = datetime.datetime.now()

    # Make sure binary data that doesn't encode properly with utf-8 is properly handled

# Generated at 2022-06-24 21:04:29.083792
# Unit test for function to_native
def test_to_native():
    str_1 = 'foo'
    bytes_1 = to_bytes(str_1)
    assert bytes_1 == b'foo'
    str_2 = to_text(bytes_1)
    assert str_2 == 'foo'
    # from ansible.utils.unicode import to_str
    # str_3 = to_str(str_1)
    # assert str_3 == 'foo'
    # str_4 = to_str(bytes_1)
    # assert str_4 == 'foo'
    # str_5 = to_str(str_1, encoding='ascii', nonstring='passthru')
    # assert str_5 == 'foo'
    # str_6 = to_str(bytes_1, encoding='ascii', nonstring='passthru')
    # assert str_6 ==

# Generated at 2022-06-24 21:04:33.662737
# Unit test for function to_native
def test_to_native():
    var_3 = ''
    var_2 = to_native(var_3, nonstring='remove')
    var_1 = to_native(var_2, nonstring='remove')
    assert var_1 == ''


# Generated at 2022-06-24 21:04:34.709365
# Unit test for function to_native
def test_to_native():
    ret = to_native('str')
    assert ret == 'str'


# Generated at 2022-06-24 21:04:44.966738
# Unit test for function jsonify
def test_jsonify():
    import json
    # Test with a text string as input
    input_str = u"this is a test"
    try:
        test_result = jsonify(input_str)
    except Exception as e:
        raise AssertionError("Call to function 'jsonify' raised the following exception:\n%s" % e)

    expected_result = u'"this is a test"'
    assert(expected_result == test_result)
    # Test with a unicode string as input
    input_str = u"this is a test \u1f42a"
    try:
        test_result = jsonify(input_str)
    except Exception as e:
        raise AssertionError("Call to function 'jsonify' raised the following exception:\n%s" % e)


# Generated at 2022-06-24 21:04:46.616226
# Unit test for function jsonify
def test_jsonify():
    str_0 = 'foo'
    assert 'foo' == jsonify(str_0)

# Generated at 2022-06-24 21:04:47.949214
# Unit test for function to_bytes
def test_to_bytes():
    assert isinstance(to_bytes(to_bytes("123")), bytes)


# Generated at 2022-06-24 21:04:58.131368
# Unit test for function jsonify
def test_jsonify():
    for encoding in ("utf-8", "latin-1"):
        try:
            return json.dumps(data, encoding=encoding, default=_json_encode_fallback, **kwargs)
        # Old systems using old simplejson module does not support encoding keyword.
        except TypeError:
            try:
                new_data = container_to_text(data, encoding=encoding)
            except UnicodeDecodeError:
                continue
            return json.dumps(new_data, default=_json_encode_fallback, **kwargs)
        except UnicodeDecodeError:
            continue
    raise UnicodeError('Invalid unicode encoding encountered')

# Generated at 2022-06-24 21:05:05.769650
# Unit test for function to_bytes
def test_to_bytes():
    # Use the following command to run the test.
    # python -m pytest tests/.
    # nosetests tests/test_to_bytes.py

    # For now we only test that the function doesn't traceback.
    # TODO: Add more tests
    test_case_0()



# Generated at 2022-06-24 21:05:09.609612
# Unit test for function jsonify
def test_jsonify():
    test_data_0 = {'foo': [1, 2, 3, 4], 'bar': (('a', 'b', 'c'),)}
    var_0 = jsonify(test_data_0)
    print(var_0)


# Generated at 2022-06-24 21:05:19.304515
# Unit test for function to_native
def test_to_native():
    # json.dumps() only encodes unicode strings in Python 2.
    # This is used to check that everything is a unicode string.
    json.dumps(to_text(b'foo'), ensure_ascii=False).encode('utf-8')

    # json.dumps() encodes bytes-like in Python 3.
    # This is used to check that anything not unicode is bytes-like.
    json.dumps(to_bytes(b'foo'), ensure_ascii=False).encode('utf-8')

    # These are in base64-encoded form to avoid having to deal with
    # non-utf8 bytes-like objects in Python 3.
    str_1 = 'SGkgdGhlcmUh'  # 'Hi there!'
    str_2 = 'V0lUSCB5b3Uh'

# Generated at 2022-06-24 21:05:29.856366
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'foo'
    var_0 = to_bytes(str_0)
    print(var_0.__class__.__name__)
    print(var_0)
    print(var_0.__class__.__name__)
    print(var_0)
    print(var_0.__class__.__name__)
    print(var_0)

# Python 3 does not support reloading a module that's been imported from a
#   package so we use this trick to make sure we always reload the module from
#   the package when running tests.

if __package__ == '':
    from os import sys, path
    parent = path.dirname(path.dirname(path.abspath(__file__)))
    sys.path.insert(1, parent)
    del sys, path


# Generated at 2022-06-24 21:05:35.177654
# Unit test for function jsonify
def test_jsonify():
    str_0 = '''
    {
        "age": 25,
        "name": "John"
    }
    '''
    str_1 = jsonify(str_0)
    print(str_1)


# Generated at 2022-06-24 21:05:38.446986
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'abc'

    ret = str_0.encode('utf-8')

    assert ret == to_bytes(str_0)



# Generated at 2022-06-24 21:05:46.930446
# Unit test for function to_native
def test_to_native():
    assert to_native('foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native('foo') == to_native(u'foo')
    assert to_native('foo') == to_native(b'foo')
    assert to_native(u'foo') == to_native(b'foo')

# Generated at 2022-06-24 21:05:53.714230
# Unit test for function to_bytes
def test_to_bytes():
    
    str_0 = 'foo'
    var_0 = to_bytes(str_0)
    assert var_0 == b'foo'
    assert type(var_0) == bytes
    
    str_1 = 'Îñţérñåţîöñåļîžåţîờñ'
    var_1 = to_bytes(str_1)

# Generated at 2022-06-24 21:06:00.951758
# Unit test for function to_bytes
def test_to_bytes():
    text_string = u'Hello World'
    encoded_string = b'Hello World'
    assert to_bytes(text_string) == encoded_string
    assert to_bytes(encoded_string) == encoded_string
    assert to_bytes(text_string, 'latin-1') == to_bytes(encoded_string, 'latin-1')
    assert to_bytes(text_string, 'latin-1', 'ignore') != to_bytes(encoded_string, 'latin-1', 'ignore')
    assert to_bytes(text_string, 'latin-1', 'ignore') == to_bytes(encoded_string, 'latin-1', 'ignore')
    assert to_bytes(text_string) == to_bytes(encoded_string)

# Generated at 2022-06-24 21:06:16.743764
# Unit test for function to_bytes
def test_to_bytes():
    # Create a dict of arguments which will be passed to the module
    # The model has to be deepcopy otherwise model values will be
    # overwritten with test values on each iteration
    # The test when test_value_type is 'complex' has to specifically
    # generate bad string arguments to test error handling
    #
    # Each item in the dict is a argument in the function.
    # Key is the argument name and value is the value of the argument
    from copy import deepcopy