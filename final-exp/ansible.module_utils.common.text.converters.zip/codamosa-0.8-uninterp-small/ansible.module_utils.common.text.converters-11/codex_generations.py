

# Generated at 2022-06-24 20:56:35.353433
# Unit test for function to_bytes
def test_to_bytes():
    # These should all be the same
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', 'utf-8') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', 'utf-8', 'strict') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

# Generated at 2022-06-24 20:56:41.524601
# Unit test for function to_bytes
def test_to_bytes():
    float_0 = 2014.995
    set_0 = {float_0, float_0}
    var_0 = to_bytes(float_0, set_0)
    float_1 = 2014.995
    set_1 = {float_1, float_1}
    var_1 = to_bytes(float_1, set_1)
    float_2 = 2014.995
    set_2 = {float_2, float_2}
    var_2 = to_bytes(float_2, set_2)
    float_3 = 2014.995
    set_3 = {float_3, float_3}
    var_3 = to_bytes(float_3, set_3)
    float_4 = 2014.995
    set_4 = {float_4, float_4}
    var_4 = to_

# Generated at 2022-06-24 20:56:42.921256
# Unit test for function jsonify
def test_jsonify():
    float_1 = 2014.995
    set_1 = {float_1, float_1}
    var_1 = jsonify(set_1)



# Generated at 2022-06-24 20:56:52.593644
# Unit test for function jsonify
def test_jsonify():
    data = {
        "name": "value",
        "binary": b"bytes",
        "binary_set": {b"bytes"},
        "text": u"text",
        "text_set": {u"text"},
        "datetime": datetime.datetime.utcnow(),
        "datetime_set": {datetime.datetime.utcnow()},
        "none": None
    }

    expected_data = {
        "name": "value",
        "binary": "bytes",
        "binary_set": ["bytes"],
        "text": "text",
        "text_set": ["text"],
        "datetime": data["datetime"].isoformat(),
        "datetime_set": [data["datetime_set"].pop().isoformat()],
        "none": None
    }

   

# Generated at 2022-06-24 20:56:57.538619
# Unit test for function to_native
def test_to_native():
    float_0 = 2014.995
    set_0 = {float_0, float_0}
    var_0 = to_native(float_0, set_0)


# Generated at 2022-06-24 20:57:06.836531
# Unit test for function jsonify
def test_jsonify():
    var_1 = {'a': 'b'}
    var_2 = jsonify(var_1)
    var_3 = {'c': 'd'}
    var_4 = jsonify(var_3)
    var_5 = {'e': 'f'}
    var_6 = jsonify(var_5)
    var_7 = {'g': 'h'}
    var_8 = jsonify(var_7)
    var_9 = {'i': 'j'}
    var_10 = jsonify(var_9)
    var_11 = {'k': 'l'}
    var_12 = jsonify(var_11)
    var_13 = {'m': 'n'}
    var_14 = jsonify(var_13)

# Generated at 2022-06-24 20:57:17.109251
# Unit test for function jsonify
def test_jsonify():
    # Prepare mock
    class _MockModule:
        name      = 'setup'
        args      = {}
        params    = {}
        return_val = None
        return_msg = 'setup succeeded'

    mock = _MockModule()

    # Try to change a real module's arguments
    for k, v in iteritems(mock.args):
        mock.args[k] = jsonify(v)
        assert(type(mock.args[k]) == type(v))

    # Try to change a real module's params
    for k, v in iteritems(mock.params):
        mock.params[k] = jsonify(v)
        assert(type(mock.params[k]) == type(v))

    # Try to change a real module's return_val

# Generated at 2022-06-24 20:57:25.383807
# Unit test for function to_bytes
def test_to_bytes():
    var_1 = 2014.995
    var_2 = {var_1, var_1}

    # Test #0 for function to_bytes
    var_3 = to_bytes(var_1, var_2)
    if(len(var_3) >= 1):
        print('function to_bytes executed successfully')
    else:
        print('function to_bytes failed')

    # Test #1 for function to_bytes
    try:
        int_0 = -19
        var_1 = var_1 / int_0
        var_3 = to_bytes(var_1, var_2)
    except ValueError as exception:
        print(exception)

    # Test #2 for function to_bytes
    var_3 = to_bytes(var_1, var_2)

    # Test #3 for function to_bytes

# Generated at 2022-06-24 20:57:26.909719
# Unit test for function to_bytes
def test_to_bytes():
    print('Testing to_bytes')
    test_case_0()
    print('to_bytes test complete')



# Generated at 2022-06-24 20:57:37.971161
# Unit test for function to_bytes
def test_to_bytes():
    assert 'ab' == to_bytes('ab')
    assert 'ab' == to_bytes(u'ab')
    assert b'ab' == to_bytes(b'ab')
    assert b'ab' == to_bytes(u'ab'.encode('utf-8'))
    assert b'ab' == to_bytes(u'ab', encoding='utf-8')
    assert b'ab' == to_bytes(u'ab'.encode('utf-8'), encoding='utf-8')
    assert b'ab' == to_bytes(u'ab'.encode('utf-8'), encoding='utf-16')
    assert b'\xff' == to_bytes(u'\ufffd')  # Replacement character
    assert b'\xff' == to_bytes(u'\udcff')  # Unencodable surrogate
   

# Generated at 2022-06-24 20:57:50.896686
# Unit test for function to_bytes
def test_to_bytes():
    import collections
    assert to_bytes(u"foobar") == b"foobar"
    assert to_bytes(u"foobar".encode('utf-16')) == u"foobar".encode('utf-16')
    assert to_bytes(u"foobar".encode('utf-16'), errors='surrogateescape') == u"foobar".encode('utf-16')
    x = u'\udcec\udced\udcee\udcef\udcf0\udcf1\udcf2\udcf3'
    y = x.encode('utf-16')
    assert to_bytes(y, errors='surrogateescape') == y


# Generated at 2022-06-24 20:57:55.906116
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'abc') == b'abc'
    assert to_bytes(text_type('abc')), b'abc'
    assert to_bytes(text_type('abc'), errors='surrogate_or_strict') == b'abc'
    assert to_bytes('abc', nonstring='simplerepr') == b'abc'
    assert to_bytes('abc', nonstring='empty') == b''
    assert to_bytes('abc', nonstring='strict') is TypeError
    assert to_bytes(None, nonstring='passthru') is None


# Generated at 2022-06-24 20:58:03.494363
# Unit test for function to_native
def test_to_native():
    # simple string test
    test_str = to_bytes('hello world')
    test_ret = to_native(test_str)
    assert isinstance(test_ret, str)

    # simple object test
    test_d = {'test': 'hello world'}
    test_ret = to_native(test_d)
    assert isinstance(test_ret, dict)
    assert isinstance(test_d['test'], str)

    # bytes with encoding
    test_str = 'hello world'
    test_ret = to_native(test_str, 'utf-8')
    assert isinstance(test_ret, str)

    # object with encoding
    test_d = {'test': 'hello world'}
    test_ret = to_native(test_d, 'utf-8')

# Generated at 2022-06-24 20:58:13.556131
# Unit test for function to_native
def test_to_native():
    # If a string is unicode, passthru, otherwise encode it as utf-8.
    assert to_native('abc', 'utf-8') == 'abc'
    assert to_native(b'abc', 'utf-8') == 'abc'

    # If a list/tuple is unicode, passthru, otherwise encode it as utf-8.
    assert to_native(['a', 'b', 'c'], 'utf-8') == ['a', 'b', 'c']
    assert to_native([b'a', b'b', b'c'], 'utf-8') == ['a', 'b', 'c']

    # If a dict is unicode, passthru, otherwise encode it as utf-8.

# Generated at 2022-06-24 20:58:23.574851
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'hello', 'ascii') == b'hello'
    assert to_bytes(u'foo', 'ascii') == b'foo'
    assert to_bytes(u'føo', 'utf-8') == b'f\xc3\xb8o'
    assert to_bytes(u'\udce4\udc00', 'utf-8') == b'\xf0\xb0\x90\x80'
    assert to_bytes(u'\u00e4', 'latin-1') == b'\xe4'

# Generated at 2022-06-24 20:58:26.624195
# Unit test for function to_native
def test_to_native():
    jstr = u'{"Hello": "world"}'
    test_obj = json.loads(jstr)
    res = to_native(test_obj)

    if not isinstance(res, dict):
        raise AssertionError('Test to_native() failed.')



# Generated at 2022-06-24 20:58:34.456437
# Unit test for function to_bytes
def test_to_bytes():
    # Add your own unit tests here
    assert to_bytes('unicode') == b'unicode', "Unicode string should stay Unicode"
    assert to_bytes(u'unicode') == b'unicode', "Unicode string should stay Unicode"
    assert to_bytes(b'byte str') == b'byte str', "Byte string should stay byte string"
    assert to_bytes('いちに') == b'\xe3\x81\x84\xe3\x81\xa1\xe3\x81\xab', "multi-byte unicode string should not be mangled"
    assert to_bytes('\xed\xa0\x80') == b'\xed\xa0\x80', "3 byte unicode character (high surrogate) should not be mangled"

# Generated at 2022-06-24 20:58:44.817051
# Unit test for function to_native
def test_to_native():
    ansible_0 = u'\u041f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(ansible_0, 'utf-8', 'strict') == b'\xd0\x9f\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    assert to_native(ansible_0, 'utf-8', 'surrogate_or_strict') == b'\xd0\x9f\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

# Generated at 2022-06-24 20:58:56.025115
# Unit test for function to_bytes
def test_to_bytes():
    text_0 = 'Github is the best place to share code with friends, co-workers, classmates, and complete strangers. Over three million people use GitHub to build amazing things together.'
    # A text string
    test_value = text_0
    assert isinstance(test_value, text_type)
    # Basic API test
    result = to_bytes(test_value)
    assert isinstance(result, binary_type)
    assert to_bytes(to_bytes(test_value)) == result

    # Test different encodings
    chars = u"é"
    codecs = ['ascii', 'latin-1', 'utf-8']
    for encoding in codecs:
        encoded_chars = chars.encode(encoding)
        assert encoded_chars == to_bytes(chars, encoding=encoding)

        #

# Generated at 2022-06-24 20:58:58.687668
# Unit test for function to_bytes
def test_to_bytes():

    # Call function with arguments and keyword argument.
    float_0 = 2014.995
    var_0 = to_bytes(float_0, float_0)



# Generated at 2022-06-24 20:59:18.288240
# Unit test for function to_native
def test_to_native():
    assert to_native(None) is None
    assert to_native(1) == 1
    assert to_native(1.0) == 1.0
    assert to_native('1') == '1'
    assert to_native(datetime.datetime(2014, 4, 1)) == '2014-04-01 00:00:00'
    assert to_native(b'1') == '1'
    assert to_native(u'1') == '1'
    assert to_native({}) == {}
    assert to_native([]) == []
    assert to_native(set()) == set()


# Generated at 2022-06-24 20:59:23.185726
# Unit test for function jsonify
def test_jsonify():
    data = "Test string"
    try:
        data = b"Test string"
    except UnicodeDecodeError:
        return data



# Generated at 2022-06-24 20:59:33.427222
# Unit test for function to_bytes
def test_to_bytes():

    # Test for bytes
    base_0 = '\xf5\xdb\xbd\x8c\xc2\xac\x1f\xb8\xee\x97\x9b\\\x18\xb8\\\x17\x0f\x1b\x8a\xee`\x10F\x0e\x8c\x0f\xc5N\x08\xb4\x03\x02\x94\xbc\xb5S\x8e\xfb\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-24 20:59:35.399837
# Unit test for function jsonify
def test_jsonify():
    float_0 = 2014.995
    var_0 = jsonify(float_0)



# Generated at 2022-06-24 20:59:38.533949
# Unit test for function jsonify
def test_jsonify():
    str_0 = 'ten'
    int_0 = 2
    list_0 = [str_0, int_0]
    var_0 = jsonify(list_0)
    assert var_0 == '["ten", 2]'


# Generated at 2022-06-24 20:59:45.799768
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('Toshio') == b'Toshio'
    assert to_bytes(u'Toshio Kuratomi') == b'Toshio Kuratomi'
    assert to_bytes('\xc4\x88io') == b'\xc4\x88io'
    assert to_bytes(u'\u0108io') == b'\xc4\x88io'

    # try some surrogates
    assert to_bytes(u'\U0001D7F6') == b'\xf0\x9d\x9f\xb6'
    assert to_bytes(u'\U0001D7F6', errors='surrogate_or_strict') == b'\xf0\x9d\x9f\xb6'

# Generated at 2022-06-24 20:59:50.415938
# Unit test for function jsonify
def test_jsonify():
    test_var_0 = {"A": "b", "C": "d"}
    assert jsonify(**test_var_0)
    test_var_1 = {"A": "b", "C": "d"}
    assert jsonify(**test_var_1)
    test_var_2 = {"A": "b", "C": "d"}
    assert jsonify(**test_var_2)



# Generated at 2022-06-24 21:00:00.741653
# Unit test for function to_bytes
def test_to_bytes():
    text_0 = 'A'
    bytes_0 = to_bytes(text_0, 'utf-8')
    text_1 = 'B'
    bytes_1 = to_bytes(text_1)
    text_2 = 'C'
    bytes_2 = to_bytes(text_2)
    text_3 = 'D'
    bytes_3 = to_bytes(text_3, 'utf-8')
    text_4 = 'E'
    bytes_4 = to_bytes(text_4)
    text_5 = 'f'
    bytes_5 = to_bytes(text_5)
    text_6 = 'g'
    bytes_6 = to_bytes(text_6)
    text_7 = 'h'
    bytes_7 = to_bytes(text_7, 'utf-8')


# Generated at 2022-06-24 21:00:11.830629
# Unit test for function jsonify
def test_jsonify():
    # Scenario to test
    # Assert that function jsonify, when given a dict, list, string or other types, returns a json serialized value
    # That the generated json, when loaded, returns an equivalent object to the one passed in
    # That the generated json, when loaded, is not equivalent to the one passed in

    float_0 = 2014.995
    dict_0 = {}
    dict_0[(2014.995)] = float_0
    dict_0['Nxj'] = float_0
    var_0 = jsonify(dict_0)
    dict_1 = dict(var_0)
    dict_2 = dict_0
    list_0 = [var_0]
    var_1 = jsonify(list_0)
    list_1 = list(var_1)
    list_2 = list_0
   

# Generated at 2022-06-24 21:00:12.779095
# Unit test for function to_native
def test_to_native():
    var_0 = to_text(str, str)


# Generated at 2022-06-24 21:00:20.563841
# Unit test for function jsonify
def test_jsonify():
    data_0 = {'hello': 'world'}
    ret_0 = jsonify(data_0)
    assert(ret_0 == '{"hello": "world"}')

# Generated at 2022-06-24 21:00:30.911882
# Unit test for function to_bytes
def test_to_bytes():
    # Test the passing of parameters

    # Test cases
    test_cases = []

    # Case 0
    # Create the arguments
    str_0 = 'õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'
    str_1 = 'õÛ½'
    str_2 = 'Â¬'
    str_3 = '¸î'

# Generated at 2022-06-24 21:00:41.461324
# Unit test for function to_bytes
def test_to_bytes():
    # Test for nonstring equals 'passthru'
    str_0 = 'õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'
    str_1 = to_bytes(str_0, encoding='utf-8', nonstring='passthru')

# Generated at 2022-06-24 21:00:52.369831
# Unit test for function to_native
def test_to_native():
    str_arg = str_0
    bytes_arg = bytes.fromhex('c3b5c3dbc39cc38c6a2c2ac1fb6ac3a5c3979bc3805cc3818c3805c3cf5cc3cb5cc3cb5cb5bcc3afc3bac3bc5c8c2bbc2bdd39cc38ec39bc300c301c300c300c300c300c300c300c300c300')

# Generated at 2022-06-24 21:00:56.245348
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(data=test_case_0()) == b'\x00\x02\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-24 21:01:06.781036
# Unit test for function to_native
def test_to_native():
    i_str = ''
    i_bytes = b''
    i_int = 0
    i_bool = False
    i_float = 0.0
    i_list = []
    i_dict = {}
    i_set = set()
    i_datetime = datetime.datetime.now()
    i_none = None
    i_object = object()

# Generated at 2022-06-24 21:01:12.684821
# Unit test for function to_native
def test_to_native():
    
    try:
        from __main__ import to_text
    except ImportError:
        from ansible.module_utils._text import to_text

    if PY3:
        str_0 = 'õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-24 21:01:13.647168
# Unit test for function jsonify
def test_jsonify():
    with pytest.raises(TypeError):
        jsonify(str_0, encoding='utf-8')


# Generated at 2022-06-24 21:01:22.299079
# Unit test for function to_bytes
def test_to_bytes():
    # Make sure that a string is a byte string

    str_0 = 'õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-24 21:01:31.786006
# Unit test for function to_bytes
def test_to_bytes():

    # Call function
    result = to_bytes(str_0)

    # Check result
    assert( isinstance(result, str) )

# Generated at 2022-06-24 21:01:44.326670
# Unit test for function to_bytes
def test_to_bytes():
    rv = to_bytes('õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00', 'utf-8', 'surrogate_then_replace')
    assert rv == str_0


# Generated at 2022-06-24 21:01:49.622606
# Unit test for function to_bytes
def test_to_bytes():
  assert to_bytes(str_0) == 'õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-24 21:01:58.380928
# Unit test for function to_native
def test_to_native():
    assert to_native(str_0) == str_0
    assert to_native(str_0) == str_0
    assert to_native(str_0) == 'õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-24 21:02:09.532900
# Unit test for function to_bytes
def test_to_bytes():
  assert (to_bytes(str_0) == 'õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00')
  # pytest.raises()
  # AssertionError: Expected 'õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\

# Generated at 2022-06-24 21:02:21.008838
# Unit test for function jsonify

# Generated at 2022-06-24 21:02:30.217701
# Unit test for function to_native
def test_to_native():
    assert to_native(str_0) == 'õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-24 21:02:35.838382
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 1, 'b': 2}
    assert jsonify(data) == '{"a": 1, "b": 2}'
    assert jsonify(data, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(data, sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(data, sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'


# Generated at 2022-06-24 21:02:46.252717
# Unit test for function to_native
def test_to_native():
    wrapped_inst = codecs.getencoder('ascii') (str_0)

# Generated at 2022-06-24 21:02:50.808173
# Unit test for function to_bytes
def test_to_bytes():
    obj = str_0
    encoding = 'utf-8'
    errors = 'surrogate_then_replace'
    nonstring = 'simplerepr'
    val = to_bytes(obj, encoding=encoding, errors=errors, nonstring=nonstring)

    assert val is not None


# Generated at 2022-06-24 21:02:52.130401
# Unit test for function to_native
def test_to_native():
    assert to_native('test') == 'test'


# Generated at 2022-06-24 21:03:05.547079
# Unit test for function to_native
def test_to_native():
    str_1 = u'\u00e5\u00db\u00bd'
    str_2 = u'\u0094\u00a8\u00ac\u001f'
    str_3 = u'\u00b8\u00ee\u0097'

    # Call function
    # No error
    str_0 = to_native(str_1)
    str_0 = to_native(str_2)
    str_0 = to_native(str_3)
    # With error
    # Type error


# Generated at 2022-06-24 21:03:15.990500
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-24 21:03:25.086229
# Unit test for function jsonify
def test_jsonify():
    f_0__ =  jsonify(str_0)
    if isinstance(f_0__, dict):
        for k_0_,v_0_ in iteritems(f_0__):
            v_0_ = __utils__['_text.to_text'](v_0_)
    return f_0__

# Importing a method from another module.
# To be consistent with other python modules, the method is not imported
# in the module's namespace
try:
    import __builtin__ as builtins
except ImportError:
    import builtins
__utils__['_text.to_text'] = to_text
__utils__['_text.to_bytes'] = to_bytes
__utils__['_text.to_native'] = to_native

# Generated at 2022-06-24 21:03:30.837479
# Unit test for function to_native
def test_to_native():
    assert to_native(str_0) == 'õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-24 21:03:42.754220
# Unit test for function to_native
def test_to_native():
    my_test_case = (to_text(b'test'), 'test')
    my_test_case_1 = (to_text(b'test', errors='surrogateescape'), 'test')
    my_test_case_2 = (to_text('test', encoding='latin-1'), 'test')
    my_test_case_3 = (to_text('test', encoding='latin-1', errors='surrogateescape'), 'test')
    my_test_case_4 = (to_text(123), '123')
    my_test_case_5 = (to_text(123, errors='surrogateescape'), '123')
    my_test_case_6 = (to_text(123, nonstring='passthru'), 123)

# Generated at 2022-06-24 21:03:50.460800
# Unit test for function jsonify
def test_jsonify():
    #
    # Tests for function 'jsonify'
    #

    # Testing for function 'jsonify'
    #
    # Test #0:
    #
    # Test using simple test case
    #
    #
    res = jsonify({'an_int': 1, 'a_string': 'foo', 'a_bool': False, 'a_float': 3.14, 'a_list': ['a', 'b', 'c'], 'a_dict': {'a': 'a', 'b': 'b', 'c': 'c', 'd': {'deep1': 'deep1', 'deep2': 'deep2'}}})
    #print(str(res))
    assert res == str_1

    # Test #1:
    #
    # Test using simple test case
    #
    #

# Generated at 2022-06-24 21:03:58.903109
# Unit test for function jsonify
def test_jsonify():
  assert jsonify(str_0) == '"õÛ½\udcc2\u00ac\u001f¸î\u0097\u009b\\\\\u0018¸\\\\\u0017\u000f\u001b\u008aî`\u0010F\u000e\udccc\u000fÅN\u0008´\u0003\u0002\u0094¼µS\udceeû\u0000\u0001\u0000\u0000\u0000\u0000\u0000\u0000\u0000\u0000"'


# Generated at 2022-06-24 21:04:01.847300
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(str_0) == to_bytes(str_0)

if __name__ == "__main__":
    import sys

    print(sys.version)
    print(sys.version_info)
    for i, v in enumerate(vars(sys)):
        print(i, '->', v, '=', getattr(sys, v))

# Generated at 2022-06-24 21:04:13.532029
# Unit test for function to_bytes
def test_to_bytes():
    str_1 = ''
    str_2 = 'õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'

    assert str_2 == to_bytes(str_1)
    assert str_2 == to_bytes(str_2)
    return 'OK'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:04:15.036416
# Unit test for function jsonify
def test_jsonify():
    test_case_0()


if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-24 21:04:27.536927
# Unit test for function jsonify
def test_jsonify():
    str_0 = 'õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'

    # Call function
    result = jsonify(str_0)



# Generated at 2022-06-24 21:04:37.133469
# Unit test for function jsonify
def test_jsonify():
    # Using the string "õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00".
    data = str_0
    # result = jsonify(data)
    # assert result == str_1
    pass

# Generated at 2022-06-24 21:04:45.739002
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'
    arg = str_0
    ret = to_bytes(arg)
    assert len(ret) > 0


# Generated at 2022-06-24 21:04:54.759031
# Unit test for function to_native
def test_to_native():
    str_0 = 'õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-24 21:05:02.474821
# Unit test for function to_native
def test_to_native():
    str_0 = 'õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'

    # Call function
    to_native(str_0)


# Generated at 2022-06-24 21:05:07.695952
# Unit test for function to_native
def test_to_native():
    str = 'õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'
    str_1 = to_text(str)

# Generated at 2022-06-24 21:05:15.973433
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(str_0) == 'õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'

# Function to use in tests below

# Generated at 2022-06-24 21:05:25.868204
# Unit test for function to_bytes
def test_to_bytes():
    # Strings
    str_0 = 'õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'
    ret_0 = to_bytes(str_0)

# Generated at 2022-06-24 21:05:27.543888
# Unit test for function jsonify
def test_jsonify():
    b'this is a test'
    assert jsonify('this is a test') == '"this is a test"'


# Generated at 2022-06-24 21:05:35.294205
# Unit test for function to_bytes
def test_to_bytes():
    obj = str_0
    test_to_bytes_result = to_bytes(obj, 'utf-8', None, 'simplerepr')


# Generated at 2022-06-24 21:05:48.281169
# Unit test for function jsonify
def test_jsonify():
    data = 'õÛ½\x8cÂ¬\x1f¸î\x97\x9b\\\x18¸\\\x17\x0f\x1b\x8aî`\x10F\x0e\x8c\x0fÅN\x08´\x03\x02\x94¼µS\x8eû\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'
    try:
        result = jsonify(data, encoding='utf-8', ensure_ascii=False)
    except Exception as e:
        print(e)
        raise


# Generated at 2022-06-24 21:05:51.709258
# Unit test for function jsonify
def test_jsonify():
    data = {('a' * 256): 'b' * 256, 1: 2,
            u'foo': u'\xe9',
            'unicode': u'\xe9',
            'latin-1': b'\xe9'
            }
    assert whether_test_pass(jsonify(data)) == True, " function jsonify error !"


# Generated at 2022-06-24 21:05:58.659472
# Unit test for function jsonify
def test_jsonify():
    assert (jsonify(str_0) == '"\\ud3f5\\u0f7c\\u4c0c\\xa4c\\x1f\\xb8\\u00ee\\x97\\u009b\\\\\\x18\\xb8\\\\\\x17\\x0f\\x1b\\x8a\\u00ee`\\x10F\\x0e\\x8c\\x0f\\xc5N\\x08\\xb4\\x03\\x02\\u0094\\u00bc\\u00b5S\\x8e\\u00fb\\x00\\x01\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00"')


# Generated at 2022-06-24 21:06:10.444790
# Unit test for function to_bytes

# Generated at 2022-06-24 21:06:21.444389
# Unit test for function jsonify