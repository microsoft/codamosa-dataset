

# Generated at 2022-06-24 20:56:34.698785
# Unit test for function to_native
def test_to_native():
    test_string_1 = 'hello'
    assert isinstance(to_native(test_string_1), str)
    test_string_2 = u'hello'
    assert isinstance(to_native(test_string_2), str)
    test_int = 10
    assert isinstance(to_native(test_int), int)
    test_bool = False
    assert isinstance(to_native(test_bool), bool)
    test_dict = {'a': 1, 'b': '2'}
    assert isinstance(to_native(test_dict), dict)
    test_list = [1, '2', '3']
    assert isinstance(to_native(test_list), list)
    test_tuple = (1, '2', '3')

# Generated at 2022-06-24 20:56:40.141412
# Unit test for function to_bytes
def test_to_bytes():
    # Testing the type and length of return value
    # str -> bytes
    assert isinstance(to_bytes('ansible'), binary_type)
    assert len(to_bytes('ansible')) == 7
    # float -> bytes
    assert isinstance(to_bytes(1), binary_type)
    assert len(to_bytes(1)) == 3
    # int -> bytes
    assert isinstance(to_bytes(1), binary_type)
    assert len(to_bytes(1)) == 3
    # list -> bytes
    assert isinstance(to_bytes(['ansible', 1, [], {}]), binary_type)
    assert len(to_bytes(['ansible', 1, [], {}])) == 69



# Generated at 2022-06-24 20:56:49.585519
# Unit test for function to_bytes
def test_to_bytes():
    # As unit testing gets set up this will become a more proper unit test.
    # Currently it just makes sure we don't crash when encoding various values
    # with various args
    to_bytes(u'\u1234')
    to_bytes(b'a')
    to_bytes(1)
    to_bytes(1, nonstring='passthru')
    to_bytes(1, nonstring='empty')
    to_bytes(1, nonstring='simplerepr')
    to_bytes(u'\u1234', errors='surrogate_or_replace')
    to_bytes(u'\u1234', errors='surrogate_or_strict')
    to_bytes(u'\u1234', errors='surrogate_then_replace')


# Generated at 2022-06-24 20:56:58.709906
# Unit test for function to_native
def test_to_native():
    # Return the native string representation of the object.  For Python 2
    # this is the same as :func:`unicode` (:class:`str` in Python 3)
    # For Python 3 this is the same as :func:`str` (:class:`bytes` in Python 2)
    #
    # This is used by :mod:`json` functions and :func:`shlex.split` to ensure
    # that they can be passed non-text string types.
    in_str = 'str_0'
    out_str = to_native(in_str)


# Generated at 2022-06-24 20:57:10.729800
# Unit test for function to_native
def test_to_native():
    enc = "utf-8"
    res = to_native(u'foo', encoding=enc)
    assert res == u'foo'
    assert isinstance(res, text_type)
    res = to_native('foo', encoding=enc)
    assert res == u'foo'
    assert isinstance(res, text_type)
    res = to_native(u'fóo', encoding=enc)
    assert res == u'fóo'
    assert isinstance(res, text_type)
    res = to_native('fóo', encoding=enc)
    assert res == u'fóo'
    assert isinstance(res, text_type)

# Generated at 2022-06-24 20:57:12.755097
# Unit test for function to_native
def test_to_native():
    list_0 = []
    list_1 = [list_0, list_0]
    var_0 = to_native(list_1)


# Generated at 2022-06-24 20:57:15.959616
# Unit test for function to_bytes
def test_to_bytes():
    try:
        var_0 = str('파이썬')
        var_1 = to_bytes(var_0)
        print(var_1)
    except Exception as var_2:
        print(var_2)


# Generated at 2022-06-24 20:57:17.235860
# Unit test for function jsonify
def test_jsonify():
    pass


# Generated at 2022-06-24 20:57:22.781616
# Unit test for function to_native
def test_to_native():
    assert to_native(text_type('abc')) == 'abc'
    assert to_native(binary_type('abc')) == 'abc'
    # -*- coding: utf-8 -*-
    assert to_native(text_type('\xc3\xa9')) == '\xc3\xa9'
    assert to_native(binary_type('\xc3\xa9')) == '\xc3\xa9'
    assert to_native(1) == 1
    assert to_native(True) == True



# Generated at 2022-06-24 20:57:27.931944
# Unit test for function to_native
def test_to_native():
    t_string = to_native(u'foo')
    assert isinstance(t_string, str) == True

    t_int = to_native(1)
    assert isinstance(t_int, int) == True

    t_int = to_native(1.0)
    assert isinstance(t_int, float) == True

    t_dict = to_native({u'test': u'foo'})
    assert isinstance(t_dict, dict) == True

    t_list = to_native([u'test'])
    assert isinstance(t_list, list) == True

    t_dict = to_native({u'foo': [u'bar', u'baz']})
    assert isinstance(t_dict, dict) == True


# Generated at 2022-06-24 20:57:40.450498
# Unit test for function to_native
def test_to_native():
    test_str = 'some string'
    assert test_str == to_native(test_str)
    assert test_str == to_native(to_bytes(test_str))
    assert test_str == to_native(to_bytes(test_str), nonstring='passthru')
    assert test_str == to_native(to_bytes(test_str), errors='surrogate_or_strict')
    assert test_str == to_native(to_bytes(test_str), errors='surrogate_or_replace')


# Generated at 2022-06-24 20:57:44.292667
# Unit test for function to_bytes
def test_to_bytes():
    bytes_0 = b'\xd6\xf7\xbb\xcdz\xbfL\x85\xcb\xe8A\x1e`5'
    var_0 = to_text(bytes_0)
    assert var_0 == '\u43f3\u5f25'


# Generated at 2022-06-24 20:57:52.453492
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('Hello') == b'Hello'
    assert to_bytes('\xe2\x98\x83', encoding='utf-8') == b'\xe2\x98\x83'
    assert to_bytes('w\xe2\x98\x83rld', encoding='utf-8') == b'w\xe2\x98\x83rld'
    assert to_bytes('\xe2\x98\x83', encoding='ascii') == b'?rld'
    assert to_bytes('w\xe2\x98\x83rld', encoding='ascii') == b'wrld'
    assert to_bytes(b'\xe2\x98\x83', encoding='ascii') == b'\xe2\x98\x83'

# Generated at 2022-06-24 20:57:58.679674
# Unit test for function to_native
def test_to_native():
    assert to_native(1) == 1
    assert to_native(1.0) == 1
    assert to_native(1.0) == 1
    assert to_native('foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native('\xff') == 'ÿ'
    assert to_native(u'\uffff') == '￿'
    assert to_native(b'\xff') == 'ÿ'
    assert to_native(b'\xff'.decode('latin-1')) == 'ÿ'
    assert to_native(b'\xff', errors='surrogate_or_replace') == '�'

# Generated at 2022-06-24 20:58:02.943248
# Unit test for function to_native
def test_to_native():
    assert to_native(1) == 1
    if PY3:
        assert to_native('string') == 'string'
        assert to_native(str('string')) == 'string'
        assert to_native(b'bytes') == 'bytes'
    else:
        assert to_native('string') == u'string'
        assert to_native(str('string')) == u'string'
        assert to_native(b'bytes') == u'bytes'


# Generated at 2022-06-24 20:58:13.398421
# Unit test for function jsonify
def test_jsonify():
    # Check if this is a string type (text_type) and not bytes
    try:
        # This should not raise any exception
        assert(isinstance(jsonify({'a': 'ansible', 'b': True, 'c': [1, 2, 3], 'd': {'e': 'f'}, 'g': {1: 2}}), text_type))
    except AssertionError:
        print("Test 1 Failed!")

    # Check if the json output is same as the expected output

# Generated at 2022-06-24 20:58:20.703111
# Unit test for function to_bytes
def test_to_bytes():
    try:
        assert to_bytes('\xd6\xf7\xbb\xcdz\xbfL\x85\xcb\xe8A\x1e`5') == b'\xd6\xf7\xbb\xcdz\xbfL\x85\xcb\xe8A\x1e`5'
    except AssertionError as e:
        print('AssertionError: %s' % e)



# Generated at 2022-06-24 20:58:25.698892
# Unit test for function jsonify
def test_jsonify():
    expected_result = '{"key1": "value1", "key2": "value2", "key3": "value3"}'
    test_str = '{"key1":"value1","key2":"value2","key3":"value3"}'
    assert jsonify(test_str) == expected_result


# Generated at 2022-06-24 20:58:26.497341
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(0) == '0'



# Generated at 2022-06-24 20:58:32.634799
# Unit test for function jsonify
def test_jsonify():
    string = "this is a test"
    my_dict = {'a': bytes(string, 'utf-8')}
    json.dumps(my_dict)
    assert(jsonify(my_dict) == u'{"a": "this is a test"}')
    my_dict = {'a': {b'c': b'd'}}
    assert(jsonify(my_dict) == u'{"a": {"c": "d"}}')
    my_dict = {'a': [b'c', b'd']}
    assert(jsonify(my_dict) == u'{"a": ["c", "d"]}')


# Generated at 2022-06-24 20:58:47.112208
# Unit test for function to_native
def test_to_native():
    try:
        assert to_native('foo') == 'foo'
        assert to_native(u'foo') == 'foo'
        assert to_native(u'Ö÷»Íz¿L') == 'Ö÷»Íz¿L'
        assert to_native(u'Ö÷»Íz¿L', errors='surrogate_then_replace') == 'Ö÷»Íz¿L'
    except AssertionError:
        raise AssertionError('AssertionError: ' + 'Assertion failed')


# Generated at 2022-06-24 20:58:57.956964
# Unit test for function to_native
def test_to_native():
    assert to_native('Ö÷»Íz¿L\x85ËèA\x1e`5') == 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    assert to_native('Ö÷»Íz¿L\x85ËèA\x1e`5') == u'Ö÷»Íz¿L\x85ËèA\x1e`5'
    assert to_native("Ö÷»Íz¿L\x85ËèA\x1e`5") == b"\x93g\xc2\xbaw\xc2\xbfL\x85\xc3\x8b\xc3\xa8A\x1e`5"

# Generated at 2022-06-24 20:58:59.556348
# Unit test for function jsonify
def test_jsonify():
    data = {"a": "Ö÷»Íz¿L"}
    ret = jsonify(data)


# Generated at 2022-06-24 20:59:10.816403
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.common._collections_compat import Binary
    from ansible.module_utils.common.text.converters import to_bytes
    input_str = u"\u00E5"
    expected_str = b"\xC3\xA5"
    produced_str = to_bytes(input_str)
    assert produced_str == expected_str
    assert type(produced_str) == Binary
    produced_str = to_bytes(input_str, nonstring='strict')
    assert type(produced_str) == Binary
    input_str = u"\u00E5"
    expected_str = b"\xE5"
    produced_str = to_bytes(input_str, errors='surrogateescape')
    assert produced_str == expected_str

# Generated at 2022-06-24 20:59:20.620925
# Unit test for function to_native
def test_to_native():
    str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    var_0 = to_native(str_0)
    str_1 = 'Ö÷»Íz¿LËèA`5'
    var_1 = to_native(str_1)
    str_2 = 'Ä\x83ö\x97¦®\x8e\x93\x88\x85'
    var_2 = to_native(str_2)
    str_3 = 'Äö¦®'
    var_3 = to_native(str_3)
    str_4 = '\x9bÁ\x93\x88\x85'
    var_4 = to_native(str_4)
    str_5

# Generated at 2022-06-24 20:59:26.789118
# Unit test for function to_native
def test_to_native():
    returned_value_0 = to_native(obj, encoding='utf-8', nonstring='simplerepr', errors=None)
    assert returned_value_0 is None
    obj_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    returned_value_0 = to_native(obj_0)
    assert returned_value_0 is None

# Generated at 2022-06-24 20:59:29.897862
# Unit test for function jsonify
def test_jsonify():
    str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    var_0 = jsonify(str_0)
    print(var_0)



# Generated at 2022-06-24 20:59:39.393726
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    var_0 = to_bytes(str_0)
    assert var_0 == b'\xd6\xf7\xbb\xcdz\xbfL\x85\xcb\xe8A\x1e`5'
    str_1 = 'uni: \u03c0 \u03d1 \u03d5'
    var_1 = to_bytes(str_1)
    assert var_1 == b'uni: \xcf\x80 \xcf\x91 \xcf\x95'
    str_2 = '\U0001d120'
    var_2 = to_bytes(str_2)

# Generated at 2022-06-24 20:59:41.736521
# Unit test for function jsonify
def test_jsonify():
    assert True


# Generated at 2022-06-24 20:59:44.115190
# Unit test for function to_native
def test_to_native():
    assert to_native(u'Ö÷»Íz¿LÅ…ËèA“`5') == u'Ö÷»Íz¿LÅ…ËèA“`5'


# Generated at 2022-06-24 20:59:59.777245
# Unit test for function jsonify
def test_jsonify():
    test_data = {'boolean': True, 'list': [1, 2, 3], 'none': None, 'string': 'foo'}
    json_string = jsonify(test_data)
    assert json_string == '{"list": [1, 2, 3], "string": "foo", "none": null, "boolean": true}'



# Generated at 2022-06-24 21:00:02.227066
# Unit test for function jsonify
def test_jsonify():
    data_0 = {
        u'utf8': u'bob',
        u'ascii': u'bob',
    }
    json_0 = jsonify(data_0)


# Generated at 2022-06-24 21:00:13.056984
# Unit test for function to_bytes

# Generated at 2022-06-24 21:00:17.621034
# Unit test for function jsonify
def test_jsonify():
    data = {}
    kwargs = {}
    expected_result = '{}'
    result = jsonify(data, **kwargs)
    assert result == expected_result

    data = {"key": "value", "list": [1, 2, 3]}
    kwargs = {"sort_keys": True}
    expected_result = '{"key": "value", "list": [1, 2, 3]}'
    result = jsonify(data, **kwargs)
    assert result == expected_result


# Generated at 2022-06-24 21:00:23.162838
# Unit test for function jsonify
def test_jsonify():
    # data with unicode and bytestring
    data = {
        u'foo': u'bar',
        'boo': 'baz',
    }

    # Expected output:
    # {"boo": "baz", "foo": "bar"}
    result = jsonify(data)

    # Example output (for reference)
    # '{"boo": "baz", "foo": "bar"}'

    assert result == '{"boo": "baz", "foo": "bar"}'


# Generated at 2022-06-24 21:00:32.959107
# Unit test for function to_native
def test_to_native():
    try:
        working_encoding = codecs.lookup(locale.getpreferredencoding()).name
    except Exception:
        working_encoding = 'ascii'
    encodings = ('ascii', 'utf-8', 'latin-1')

    class Foo:
        def __str__(self):
            return "foo"

    class FooStr(str):
        pass

    class FooBin(bytes):
        pass

    class FooBinStr(FooBin, str):
        pass

    class FooBinUni(FooBin, unicode):
        pass

    class FooUni(unicode):
        pass

    class FooUniStr(FooUni, str):
        pass

    class FooUniBin(FooUni, bytes):
        pass

   

# Generated at 2022-06-24 21:00:44.869306
# Unit test for function to_bytes
def test_to_bytes():
    print()
    # Define arguments and expected default return values
    kwargs = {
        "errors" : 'surrogate_or_replace',
        "encoding" : 'utf-8',
        "nonstring" : 'simplerepr',
        "obj" : 'Ö÷»Íz¿L\x85ËèA\x1e`5',
    }

    # Return value
    ret = b'\xc3\x96\xc3\xb7\xe2\x80\xa2\xc3\x8dz\xc2\xbfL\xc2\x85\xc3\x8b\xc3\xa8A\xc2\x1e`5'

    #  Call to_bytes with correct arguments
    ret = to_bytes(**kwargs)
    ## test equality

# Generated at 2022-06-24 21:00:46.278320
# Unit test for function to_bytes
def test_to_bytes():

    # Assert
    str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    var_0 = to_bytes(str_0)


# Generated at 2022-06-24 21:00:49.824484
# Unit test for function to_native
def test_to_native():
    found = False
    for key, value in iteritems(globals()):
        if to_native(key) == 'test_to_native':
            found = True
    assert found


# Generated at 2022-06-24 21:00:53.561977
# Unit test for function jsonify

# Generated at 2022-06-24 21:01:00.583552
# Unit test for function to_native
def test_to_native():
    try:
        str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
        var_0 = to_native(str_0)
    except:
        assert False


# Generated at 2022-06-24 21:01:06.717131
# Unit test for function jsonify
def test_jsonify():
    data = {
        "byte_string": b"f\xf6\xf6",
        "native_string": "f\xf6\xf6",
        "set": set(["a", "b", "c"]),
    }

    assert isinstance(jsonify(data), str)
    assert jsonify(data) == '{"byte_string": "f\\xf6\\xf6", "native_string": "f\\u00f6\\u00f6", "set": ["a", "b", "c"]}'



# Generated at 2022-06-24 21:01:11.213607
# Unit test for function jsonify
def test_jsonify():
    data_0 = dict()
    # Test for KeyError
    for key in data_0: del data_0[key]
    # Test for TypeError
    data_1 = jsonify(data_0)
    with open('test_file_v2.json', 'w') as f:
        f.write(data_1)


# Generated at 2022-06-24 21:01:19.363927
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    var_0 = to_bytes(str_0)
    assert var_0 == b'\xd6\xf7\xbb\xcdz\xbfL\x85\xcb\xe8A\x1e`5'



# Generated at 2022-06-24 21:01:24.458451
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    var_0 = to_bytes(str_0)
    print(var_0)

test_to_bytes()

# Generated at 2022-06-24 21:01:35.186022
# Unit test for function to_bytes
def test_to_bytes():
    # Make sure we can call it from a python2.4 system
    try:
        to_bytes('Ö÷»Íz¿LËèA\x1e`5', encoding='utf-8')
    except NameError:
        pass

    # Test if it works with non-ASCII unicode strings
    str_1 = u'Ö÷»Íz¿LËèA\x1e`5'
    var_1 = to_bytes(str_1, encoding='utf-8')

    # Test if it works with ASCII unicode strings
    str_2 = u'ASCII STRING'
    var_2 = to_bytes(str_2, encoding='utf-8')

    # Test if it works with non-ASCII text strings

# Generated at 2022-06-24 21:01:37.560264
# Unit test for function to_native
def test_to_native():
    var_1 = to_native(str_0)

# Generated at 2022-06-24 21:01:38.410990
# Unit test for function to_native
def test_to_native():
    assert True


# Generated at 2022-06-24 21:01:44.726567
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native

    # Inferring nonstring type
    # we don't care about the nonstring value for this unit test, so we're just going
    # to test that it works with all possible values
    for nonstring in ('simplerepr', 'passthru', 'empty', 'strict'):
        assert to_native(None, 'utf-8', nonstring=nonstring) is None
        assert to_native(123, 'utf-8', nonstring=nonstring) == 123
        assert to_native([], 'utf-8', nonstring=nonstring) == []

    # Encoding and decoding values
    # we don't care about the error handler for this unit test, so we're going to just test
    # that all possible values for nonstring work

# Generated at 2022-06-24 21:01:53.061971
# Unit test for function jsonify
def test_jsonify():
    data = {
        'test': u'\xe7\x9a\x84\xe6\x98\xaf\xe4\xb8\x80\xe6\xac\xa1\xe9\x9c\x80\xe8\xa6\x81'
    }
    assert jsonify(data) == '{"test": "\\u7684\\u662f\\u4e00\\u6b21\\u9700\\u8981"}'



# Generated at 2022-06-24 21:02:09.058091
# Unit test for function jsonify
def test_jsonify():
    str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    var_0 = jsonify(str_0)
    str_1 = 'utf-8'
    var_1 = jsonify(str_0, encoding=str_1)
    str_2 = 'ensure_ascii=False'
    var_2 = jsonify(str_0, ensure_ascii=False)
    str_3 = 'utf-8'
    str_4 = 'ensure_ascii=False'
    var_3 = jsonify(str_0, encoding=str_3, ensure_ascii=False)


# Generated at 2022-06-24 21:02:13.428855
# Unit test for function jsonify
def test_jsonify():
    test_dict = dict(tuple(u'Ö÷»Íz¿L\x85ËèA\x1e`5' for i in xrange(2)))
    jsonify(test_dict)

test_case_0()

# Generated at 2022-06-24 21:02:15.019217
# Unit test for function to_native
def test_to_native():
    assert to_native('hello') == 'hello'



# Generated at 2022-06-24 21:02:24.400939
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    var_0 = to_bytes(str_0)
    assert var_0== b'\xd6\xf7\xbb\xcdz\xbfL\x85\xcb\xe8A\x1e`5' 

    str_0 = '∩╗┐'
    var_0 = to_bytes(str_0)
    assert var_0 == b'\xe2\x88\xa9\xe2\x95\x97\xe2\x94\x90' 

    str_0 = 'Ş¥'
    var_0 = to_bytes(str_0)

# Generated at 2022-06-24 21:02:33.889534
# Unit test for function jsonify

# Generated at 2022-06-24 21:02:44.930350
# Unit test for function to_native
def test_to_native():
    assert to_native(b'\xe9') == 'é'
    assert to_native(b'\xe9', errors='') == u'\xe9'
    assert to_native(b'\xe9', errors='strict') == u'\xe9'
    assert to_native(b'\xe9', errors='surrogateescape') == 'é'
    assert to_native(b'\xe9', errors='surrogate_or_replace') == 'é'
    assert to_native(b'\xe9', errors='surrogate_or_strict') == 'é'
    assert to_native(b'\xe9', errors='surrogate_then_replace') == 'é'
    assert to_native(b'caf\xe9') == 'café'

# Generated at 2022-06-24 21:02:51.543961
# Unit test for function jsonify
def test_jsonify():

    # function call
    test_data = {"a": 1,
                 u"õ": 2,
                 "b": 3}
    test_data = jsonify(test_data)
    if PY3:
        assert test_data == '{"a": 1, "õ": 2, "b": 3}'
    else:
        assert test_data == '{"a": 1, "\\xf5": 2, "b": 3}'


# Generated at 2022-06-24 21:02:55.440152
# Unit test for function to_native
def test_to_native():
    str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    var_0 = to_native(str_0)
    assert var_0 == 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    

# Generated at 2022-06-24 21:03:04.242599
# Unit test for function to_bytes
def test_to_bytes():
    """ Test function to_bytes """
    inputs_bytes = [b'', b'Foo', b'Foo\x00Bar', b'\xff\xfe']
    inputs_unicode = [u'', u'Foo', u'Foo\x00Bar', u'\xff\xfe']

    # Validate that an error is raised if we do not have surrogateescape
    if HAS_SURROGATEESCAPE:
        # This will raise a lookup error if Python was compiled without unicode support
        try:
            codecs.lookup_error(u'surrogateescape')
        except LookupError:
            raise AssertionError('Cannot run tests for to_bytes if Python was compiled without unicode support')


# Generated at 2022-06-24 21:03:06.964792
# Unit test for function jsonify
def test_jsonify():
    result = jsonify("Ö÷»Íz¿LËèA`5")
    assert result == '"\\xc3\\x96\\xc3\\xb7\\xc2\\xbb\\xc3\\x8dz\\xc2\\xbfL\xc3\\x8b\\xc3\\xa8A`5"'



# Generated at 2022-06-24 21:03:19.808709
# Unit test for function jsonify
def test_jsonify():
    from test.support import captured_stdout

    data = {
        "some": "content",
        "some_list": [
            "content",
            "content",
            "content"
        ]
    }

    with captured_stdout() as stdout:
        jsonify(data)

    assert stdout.getvalue() == ('{\n    "some": "content", \n'
                                 '    "some_list": [\n        "content", \n'
                                 '        "content", \n        "content"\n    ]\n}\n')



# Generated at 2022-06-24 21:03:23.262976
# Unit test for function to_native
def test_to_native():
    str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    var_0 = to_native(str_0)
    pass


# Generated at 2022-06-24 21:03:31.210926
# Unit test for function jsonify
def test_jsonify():
    data = dict(a=dict(b=2, c='foo'))
    rval = jsonify(data)
    assert rval.startswith('{')
    assert '"a": {' in rval
    assert ('"b": 2' in rval) or ('"b" : 2' in rval)
    assert ('"c": "foo"' in rval) or ('"c" : "foo"' in rval)

    data = dict(a=dict(b=2, c=u'Ö÷»Íz¿L\x85ËèA\x1e`5'))
    rval = jsonify(data)
    assert rval.startswith('{')
    assert '"a": {' in rval

# Generated at 2022-06-24 21:03:33.145227
# Unit test for function to_bytes
def test_to_bytes():
    assert not to_bytes('abc')
    assert not to_bytes(b'abc')



# Generated at 2022-06-24 21:03:38.534304
# Unit test for function jsonify
def test_jsonify():
    data = {"a": "1", u'中文': u'中文'}
    dumped = jsonify(data)
    assert json.loads(dumped) == json.loads(u'{"a": "1", "中文": "中文"}')



# Generated at 2022-06-24 21:03:42.483434
# Unit test for function jsonify
def test_jsonify():
    data = {u"foo": u"bar", u"baz": u"bam"}
    result = jsonify(data)
    if result:
        print(result)
    else:
        print('Please implement your test')


# Generated at 2022-06-24 21:03:50.199306
# Unit test for function jsonify
def test_jsonify():
    test_data = {"str_0": to_native("Ö÷»Íz¿LÅËèA`5"), "str_1": to_native("Ö÷»Íz¿LÅËèA`5"), "str_2": to_native("Ö÷»Íz¿LÅËèA`5"), "str_3": to_native("Ö÷»Íz¿LÅËèA`5")}
    assert(jsonify(test_data) == json.dumps(test_data, default=_json_encode_fallback))


# Generated at 2022-06-24 21:03:55.082225
# Unit test for function to_native
def test_to_native():
    str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    print(to_native(str_0))
    print(to_native(str_0, 'ascii'))
if __name__ == '__main__':
    test_to_native()

# Generated at 2022-06-24 21:04:00.517155
# Unit test for function to_native
def test_to_native():
    str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    var_0 = to_native(str_0)

    str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    var_0 = to_native(str_0)


# Generated at 2022-06-24 21:04:12.188404
# Unit test for function to_bytes
def test_to_bytes():
    # No exception raised
    var_0 = to_bytes('Ö÷»Íz¿LËèA`5', 'utf-8')
    assert var_0 == b'\xc3\x96\xc3\xb7\xc2\xbb\xc3\x8dz\xc2\xbfL\xc3\x8b\xc3\xa8A`5'
    # No exception raised
    var_1 = to_bytes('ä äää\tä\tööööö', 'utf-8')

# Generated at 2022-06-24 21:04:27.544313
# Unit test for function jsonify
def test_jsonify():
    """ Test jsonify """
    # Test case 0
    str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    var_0 = to_bytes(str_0)
    jsonify(1)
    jsonify(1)
    jsonify(1)
    jsonify(1)
    jsonify(1)
    jsonify(1)
    jsonify(1)
    jsonify(1)
    jsonify(1)
    jsonify(1)
    jsonify(1)
    jsonify(1)
    jsonify(1)
    jsonify(1)
    jsonify(1)
    jsonify(1)
    jsonify(1)
    jsonify(1)
    jsonify(1)
    jsonify(1)
   

# Generated at 2022-06-24 21:04:29.640410
# Unit test for function to_native
def test_to_native():
    str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    var_0 = to_native(str_0)


# Generated at 2022-06-24 21:04:34.250437
# Unit test for function jsonify
def test_jsonify():
  try:
    # raise errors.AnsibleError("AnsibleError")
    jsonify(None, ensure_ascii=True)
  except (Exception) as e:
    print(to_native(e))



# Generated at 2022-06-24 21:04:44.647263
# Unit test for function jsonify
def test_jsonify():
    # Assert if unicode string has been json serialized.
    str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    assert jsonify(str_0) == '"Ö÷»Íz¿L\\xc85ËèA\\x1e`5"'
    # Assert if unicode string has been json serialized.
    str_1 = 'Ê¾¸ûåïµ¤ÐµÐ·Ñ¡\x1f¬yÌõ×¢µÄÏêÏ¸Ð­Òé'

# Generated at 2022-06-24 21:04:46.306009
# Unit test for function to_bytes
def test_to_bytes():
    # Test mode 0 (str -> str)
    test_case_0()



# Generated at 2022-06-24 21:04:48.637764
# Unit test for function to_native
def test_to_native():
    str_1 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    var_1 = to_text(str_1)

# Generated at 2022-06-24 21:04:50.520188
# Unit test for function jsonify
def test_jsonify():
    assert False



# Generated at 2022-06-24 21:04:55.082254
# Unit test for function jsonify
def test_jsonify():
    str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    var_0 = jsonify(str_0)
    var_1 = json.dumps(str_0)

    if var_0 != var_1:
        print('var_0 is :')
        print(var_0)
        print('var_1 is :')
        print(var_1)
        io.StringIO()
    else: 
        print("jsonify success!!!")





# Generated at 2022-06-24 21:05:03.601555
# Unit test for function to_native
def test_to_native():
    true_val1 = True
    true_val2 = 'true'
    false_val1 = False
    false_val2 = 'false'
    none_val1 = None
    none_val2 = 'null'

    assert to_native(true_val1) == true_val1
    assert to_native(true_val2) == true_val1
    assert to_native(false_val1) == false_val1
    assert to_native(false_val2) == false_val1
    assert to_native(none_val1) == none_val1
    assert to_native(none_val2) == none_val1

    # unit test_case_1
    str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    var_

# Generated at 2022-06-24 21:05:14.361589
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('./flask/app.py') == '"./flask/app.py"'
    assert jsonify('D:/app.py') == '"D:/app.py"'
    assert jsonify('\\app.py') == '"\\\\app.py"'
    assert jsonify('/app.py') == '"/app.py"'
    assert jsonify('.\\flask\\app.py') == '".\\\\flask\\\\app.py"'
    assert jsonify('D:\\app.py') == '"D:\\\\app.py"'
    assert jsonify('\\app.py') == '"\\\\app.py"'
    assert jsonify('/app.py') == '"/app.py"'
    assert jsonify('.\\flask\\app.py') == '".\\\\flask\\\\app.py"'
   

# Generated at 2022-06-24 21:05:35.170881
# Unit test for function to_bytes

# Generated at 2022-06-24 21:05:40.937655
# Unit test for function jsonify
def test_jsonify():
    # Testing if the json.dumps result is a str object
    #assert isinstance(jsonify(None), str)
    # Testing if the json.dumps result is a str object
    #assert isinstance(jsonify(None), str)
    # Testing if the json.dumps result is a str object
    assert isinstance(jsonify(None), str)
    # Testing if the json.dumps result is a str object
    #assert isinstance(jsonify(None), str)
    # Testing if the json.dumps result is a str object
    #assert isinstance(jsonify(None), str)
    # Testing if the json.dumps result is a str object
    #assert isinstance(jsonify(None), str)
    # Testing if the json.dumps result is a str object
    #assert isinstance(jsonify(None),

# Generated at 2022-06-24 21:05:48.821977
# Unit test for function to_native
def test_to_native():
    assert to_native('{:s}') == b'{:s}'
    assert to_native(b'{:s}', errors='surrogate_then_replace') == u'{:s}'
    assert to_native('{:s}', nonstring='empty') == u''
    assert to_native(b'{:s}', nonstring='empty') == b''
    assert to_native('{:s}', nonstring='strict') == u'{:s}'
    assert to_native(b'{:s}', nonstring='strict') == b'{:s}'
    assert to_native('{:s}', nonstring='passthru') == u'{:s}'

# Generated at 2022-06-24 21:05:53.398771
# Unit test for function to_native
def test_to_native():
    assert to_native(u'test') == 'test'
    assert to_native('test') == 'test'
    assert to_native(b'test') == u'test'
    assert to_native(123) == 123
    assert to_native(True) is True
    assert to_native(datetime.datetime(1, 1, 1, 1, 1, 1)) == '0001-01-01T01:01:01'
    assert to_native(set([1, 2, 3])) == Set([1, 2, 3])


# Generated at 2022-06-24 21:05:54.703713
# Unit test for function jsonify
def test_jsonify():
    data = {u"test": u"test"}
    result = jsonify(data)
    assert(result == '{"test": "test"}')



# Generated at 2022-06-24 21:05:58.804848
# Unit test for function jsonify
def test_jsonify():
    data = {'ansible_facts': {'ansible_all_ipv4_addresses': ['127.0.0.1', '172.30.241.236']}, 'warnings': [], 'changed': False, 'msg': ''}
    json_str = jsonify(data)
    assert True



# Generated at 2022-06-24 21:06:10.554041
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'
    var_0 = to_bytes(str_0)
    bytes_0 = b'\xc3\x96\xc3\xb7\xc2\xbb\xc3\x8dz\xc2\xbfL\xc2\x85\xc3\x8b\xc3\xa8A\x1e`5'
    assert var_0 == bytes_0
    str_1 = 'hi'
    var_1 = to_bytes(str_1)
    bytes_1 = b'hi'
    assert var_1 == bytes_1
    str_2 = 'Öh÷i'
    var_2 = to_bytes(str_2)

# Generated at 2022-06-24 21:06:11.584323
# Unit test for function jsonify
def test_jsonify():
    var_0 = jsonify(5)


# Generated at 2022-06-24 21:06:21.482237
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'  # This is a byte string in utf-8
    var_0 = to_bytes(str_0)
    assert isinstance(var_0, binary_type)

    str_1 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'  # This is a text string
    var_1 = to_bytes(str_1, encoding='latin-1')
    assert isinstance(var_1, binary_type)

    str_2 = 'Ö÷»Íz¿L\x85ËèA\x1e`5'  # This is a text string