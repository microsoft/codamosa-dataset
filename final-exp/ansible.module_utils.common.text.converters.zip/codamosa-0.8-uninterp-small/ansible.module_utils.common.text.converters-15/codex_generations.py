

# Generated at 2022-06-24 20:56:34.786820
# Unit test for function jsonify
def test_jsonify():
  list_0 = []
  str_0 = 'modified files in the working repository will be discarded'
  bytes_0 = b'modified files in the working repository will be discarded'
  list_0.append(str_0)
  var_0 = container_to_bytes(list_0)
  result = jsonify(var_0)
  assert result == '["modified files in the working repository will be discarded"]'


# Generated at 2022-06-24 20:56:38.175209
# Unit test for function to_bytes
def test_to_bytes():
    try:
        str_0 = 'modified files in the working repository will be discarded'
        list_0 = [str_0]
        var_0 = container_to_bytes(list_0)
    except TypeError as e:
        assert 'obj must be a string type' in str(e)

    value = to_bytes(u'hi')
    assert isinstance(value, binary_type)


# Generated at 2022-06-24 20:56:43.750656
# Unit test for function to_bytes
def test_to_bytes():
    # str
    val_0 = 'modified files in the working repository will be discarded'
    assert to_bytes(val_0, 'utf-8', None, 'simplerepr') == b'modified files in the working repository will be discarded', "transformed value of 'modified files in the working repository will be discarded' is incorrect"
    print('Test passed!')



# Generated at 2022-06-24 20:56:53.151129
# Unit test for function jsonify
def test_jsonify():
    # jsonify(data, **kwargs)
    # Test if the function raises the proper exception for wrong type parameter
    # data
    data = 99
    with pytest.raises(TypeError) as excinfo:
        jsonify(data)
    # Test if the function raises the proper exception for wrong type parameter
    # data
    data = '99'
    with pytest.raises(TypeError) as excinfo:
        jsonify(data)
    # Test if the function raises the proper exception for wrong type parameter
    # data
    data = _json_encode_fallback
    with pytest.raises(TypeError) as excinfo:
        jsonify(data)
    # Test if the function raises the proper exception for wrong type parameter
    # data
    data = Set(['aafc'])

# Generated at 2022-06-24 20:56:59.005764
# Unit test for function jsonify
def test_jsonify():
    try:
        res = jsonify(list_0)
        assert isinstance(res, unicode)
    except UnicodeDecodeError as e:
        print(e)
    except TypeError as e:
        print(e)


# Generated at 2022-06-24 20:57:01.935331
# Unit test for function to_native
def test_to_native():
    # Provide a mock object for the function test_to_native
    try:
        to_native(var_0)
    except Exception:
        pass


# Generated at 2022-06-24 20:57:05.189192
# Unit test for function to_bytes
def test_to_bytes():
    arg_0 = 'modified files in the working repository will be discarded'
    var_0 = to_bytes(arg_0)
    assert type(var_0) == bytes


# Generated at 2022-06-24 20:57:07.343917
# Unit test for function jsonify
def test_jsonify():
    list_0 = [1,2,3,4,5]
    var_0 = jsonify(list_0)


# Generated at 2022-06-24 20:57:12.385367
# Unit test for function to_bytes
def test_to_bytes():
        from ansible.module_utils.common.text.converters.to_bytes import to_bytes
        list_0 = [u'modified files in the working repository will be discarded']
        var_0 = to_bytes(list_0)
        assert(var_0 == '[b\'modified files in the working repository will be discarded\']')

# Generated at 2022-06-24 20:57:21.591448
# Unit test for function jsonify
def test_jsonify():
    obj = {'a': text_type, 'b': 2}
    assert jsonify(obj) == "{\"a\": \"type 'unicode'\", \"b\": 2}"
    obj = {'a': text_type, 'b': 2}
    assert jsonify(obj, ensure_ascii=False) == u"{\"a\": \"type 'unicode'\", \"b\": 2}"
    obj = {'a': text_type, 'b': 2}
    assert jsonify(obj, ensure_ascii=False, encoding='latin-1') == u"{\"a\": \"type 'unicode'\", \"b\": 2}"
    obj = {'a': text_type, 'b': 2}

# Generated at 2022-06-24 20:57:39.386267
# Unit test for function jsonify
def test_jsonify():
    # Jsonify empty dict
    from ansible.module_utils import _text
    dict_0 = {}
    var_0 = _text.jsonify(dict_0)
    assert var_0 == "{}"

    # Jsonify empty list
    list_0 = []
    var_1 = _text.jsonify(list_0)
    assert var_1 == "[]"

    # Jsonify list with one string
    list_2 = ["a"]
    var_2 = _text.jsonify(list_2)
    assert var_2 == '["a"]'

    # Jsonify list with one integer
    list_3 = [1]
    var_3 = _text.jsonify(list_3)
    assert var_3 == "[1]"

    # Jsonify dict with one key value pair
    dict_

# Generated at 2022-06-24 20:57:48.232624
# Unit test for function to_bytes
def test_to_bytes():
    assert isinstance(to_bytes(b'foo'), binary_type)
    assert isinstance(to_bytes('foo'), binary_type)
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes('foo') == b'foo'

    assert to_bytes('\xf3') == b'\xc3\xb3'
    assert to_bytes('\u03b3') == b'\xce\xb3'
    assert to_bytes(u'\ufffd') == b'\xef\xbf\xbd'

    if HAS_SURROGATEESCAPE:
        assert to_bytes('\udce2\udcbb', errors='surrogate_or_replace') == b'\xed\xb3\xab'

# Generated at 2022-06-24 20:57:55.693651
# Unit test for function to_bytes
def test_to_bytes():

    # Try it for a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', encoding='utf-8') == '\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Try it for a binary string
    assert to_bytes('Hi') == 'Hi'
    binary_string = u'\u043f\u0440\u0438\u0432\u0435\u0442'.encode('utf-16')
    assert to_bytes(binary_string, encoding='utf-16') == binary_string

    # Make sure we don't do an unnecessary encode

# Generated at 2022-06-24 20:57:58.566015
# Unit test for function jsonify
def test_jsonify():
    dict_0 = {}
    # var_0 = jsonify(dict_0)
    # print var_0
    # assert var_0 == '{}', 'Expected different value than "{}" for var_0'


if __name__ == '__main__':
    test_jsonify()
    # test_case_0()

# Generated at 2022-06-24 20:58:00.281030
# Unit test for function jsonify
def test_jsonify():
    test_cases = [0, 1]
    for case in test_cases:
        if case == 0:
            test_case_0()
        if case == 1:
            test_case_1()



# Generated at 2022-06-24 20:58:13.214712
# Unit test for function to_native
def test_to_native():
    string_0 = '  asdfgh  '
    string_1 = '  erqwerq  '
    string_2 = '  fasdfdsa  '
    string_3 = '  asd:asd  '
    string_4 = '  a:s:d:f  '

    # This could be a problem.
    string_5 = 'to_native'

    # This could be a problem.
    string_6 = 'to_native'

    string_7 = 'to_native'

    string_8 = 'to_native'

    string_9 = 'to_native'

    string_10 = '  bvdf  '

    string_11 = '  asdfgh  '
    string_12 = '  erqwerq  '

# Generated at 2022-06-24 20:58:18.662101
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": [1, 2, 3], "b": [4, 5, 6]}) == '{"a": [1, 2, 3], "b": [4, 5, 6]}'


# Generated at 2022-06-24 20:58:27.474831
# Unit test for function to_native
def test_to_native():
    # maybe do a byte string?
    assert to_native(1) == 1
    assert to_native('foo') == 'foo'
    assert to_native(None) == None

    # check if non-ascii characters are transformed to unicode
    assert to_native(b'foo\xc3\xa9') == 'fooé'

    # check for invalid utf-8 characters
    assert to_native(b'foo\xff') == 'foo\ufffd'

    # check for surrogate char in utf-16
    assert to_native(u'foo\udcff') == 'foo\ufffd'

    # check for non-utf8, non-utf16 with surrogate char
    assert to_native(b'foo\xff'+u'\udcff') == 'foo\ufffd\ufffd'

    # check for

# Generated at 2022-06-24 20:58:30.057637
# Unit test for function jsonify
def test_jsonify():
    dict_0 = {}
    dict_0["key_0"] = "value_0"

    var_0 = jsonify(dict_0)
    assert var_0 == '{"key_0": "value_0"}'


# Generated at 2022-06-24 20:58:30.761440
# Unit test for function jsonify
def test_jsonify():
    test_case_0()



# Generated at 2022-06-24 20:58:47.039585
# Unit test for function to_native
def test_to_native():
    test_case = {
        'to_native':[
            {
                'input': (
                    '{\n'
                    '    "changed": false, \n'
                    '    "ping": "pong"\n'
                    '}\n'
                ),
                'want': {
                    'changed': False,
                    'ping': 'pong',
                }
            },
            {
                'input': {
                    'ping': 'pong'
                },
                'want': {
                    'ping': 'pong'
                },
            },
            {
                'input': json.dumps({
                    'ping': 'pong'
                }),
                'want': {
                    'ping': 'pong'
                },
            }
        ]
    }

# Generated at 2022-06-24 20:58:50.885313
# Unit test for function to_native
def test_to_native():
    teststr = to_text('teststring')
    assert teststr == 'teststring'

    teststr = to_native('teststring')
    assert teststr == 'teststring'


# Generated at 2022-06-24 20:58:59.478412
# Unit test for function jsonify
def test_jsonify():
    import copy
    from ansible.module_utils import basic 
    from collections import Set
    testcase = basic.AnsibleModule(
        argument_spec = dict(
            data = dict(),
        ),
        supports_check_mode=False,
    )
    testcase.params = dict(
        data='my test',
    )
    test_0_jsonify = jsonify(testcase.params['data'])
    expected_0_jsonify = '"my test"'

    # Tests
    assert test_0_jsonify == expected_0_jsonify, "Expected {0}, got {1}".format(expected_0_jsonify, test_0_jsonify)


# Generated at 2022-06-24 20:59:01.073140
# Unit test for function to_native
def test_to_native():
    var_0 = {}
    var_0 = to_native(var_0)


# Generated at 2022-06-24 20:59:02.946000
# Unit test for function jsonify
def test_jsonify():
    # Test case 0
    var_0 = {}
    assert jsonify(var_0) == '{}'


# Generated at 2022-06-24 20:59:13.364058
# Unit test for function to_native
def test_to_native():
    print("test_case_0")
    result = to_native({})
    assert result == {}, "'{}' != '{}'".format(result, {})
    print("test_case_1")
    result = to_native({"a": "b"})
    assert result == {"a": "b"}, "'{}' != '{}'".format(result, {"a": "b"})
    print("test_case_2")
    result = to_native({"a": "b", "c": "d"})
    assert result == {"a": "b", "c": "d"}, "'{}' != '{}'".format(result, {"a": "b", "c": "d"})
    print("test_case_3")
    result = to_native(["a", "b"])


# Generated at 2022-06-24 20:59:15.416050
# Unit test for function to_native
def test_to_native():
    var_1 = {}
    var_1['python_ver'] = 3


# Generated at 2022-06-24 20:59:23.595529
# Unit test for function to_bytes
def test_to_bytes():
    if PY3:
        assert to_bytes(b'foo') == b'foo'
        assert to_bytes(u'foo') == b'foo'
        assert to_bytes(u'fóo') == b'f\xcc\x83oo'
        with pytest.raises(UnicodeEncodeError):
            to_bytes(u'fóo', 'ascii')

# Generated at 2022-06-24 20:59:24.434314
# Unit test for function jsonify
def test_jsonify():
    data = {}
    assert jsonify(data) == '{}'


# Generated at 2022-06-24 20:59:26.667120
# Unit test for function to_bytes
def test_to_bytes():
    var_0 = test_case_0()
    assert isinstance(var_0, Set)



# Generated at 2022-06-24 20:59:38.192566
# Unit test for function jsonify
def test_jsonify():
    # Create a JSON string
    test_data = json.dumps({"foo": "bar"})
    # Convert an ASCII string
    assert jsonify(test_data) == test_data
    # Convert a unicode string
    assert jsonify(test_data.decode("utf-8")) == test_data
    # Convert a complex data structure
    assert jsonify({"foo": ["bar", "baz"]}) == '{"foo": ["bar", "baz"]}'



# Generated at 2022-06-24 20:59:40.488838
# Unit test for function to_native
def test_to_native():
    var1 = None
    var2 = {}
    # Test that the function returns expected results

    assert to_native(var1, var2) is None


# Generated at 2022-06-24 20:59:51.897406
# Unit test for function jsonify
def test_jsonify():
    obj = {}
    assert jsonify(obj) == '{}'
    obj = {"a": 1, "b": [1, 2], "c": "abc"}
    assert jsonify(obj) == '{"a": 1, "c": "abc", "b": [1, 2]}'
    obj = {"a": 1, "b": [1, 2], "c": None}
    assert jsonify(obj) == '{"a": 1, "c": null, "b": [1, 2]}'
    obj = [None, 1, False, "abc", [1, 2], {"a": 1}]
    assert jsonify(obj) == '[null, 1, false, "abc", [1, 2], {"a": 1}]'


# Generated at 2022-06-24 20:59:55.177469
# Unit test for function jsonify
def test_jsonify():
    var_0 = {}
    ansible_0 = jsonify(var_0)
    if not( isinstance(ansible_0, str)):
        raise AssertionError("value {} is not an instance of {}".format(ansible_0, str))


# Generated at 2022-06-24 21:00:00.861276
# Unit test for function jsonify
def test_jsonify():
    # Create data
    data = {}

    res = jsonify(data)
    assert res == '{}'

    res = jsonify(data, sort_keys=True)
    assert res == '{}'


# Generated at 2022-06-24 21:00:08.133440
# Unit test for function to_bytes
def test_to_bytes():
    src = 'test,test3'
    if isinstance(src, text_type):
        src = to_bytes(src, errors='surrogate_or_strict')
    # print(src)
    src = src.split(b',')
    # print(src)
    # print(src[0])
    # print(src[1])
    # print(src)
    # print(src[1].split(b':'))

# Generated at 2022-06-24 21:00:16.657404
# Unit test for function to_native
def test_to_native():

    # From Ansible 2.3 onwards, the default is surrogate_then_replace.
    ret = to_text(u"\u0394", errors='surrogate_or_replace')
    assert isinstance(ret, text_type)
    assert ret == u"\ufffd"
    assert to_text(to_bytes(u"\u0394", errors='surrogate_or_replace')) == u"\ufffd"
    assert to_text(to_bytes(u"\u0394", errors='surrogate_then_replace')) == u"\ufffd"

    ret = to_text(u"\u0394", errors='surrogate_then_replace')
    assert isinstance(ret, text_type)
    assert ret == u"\ufffd"

# Generated at 2022-06-24 21:00:20.204209
# Unit test for function to_native
def test_to_native():
    ret = to_native(var_0)
    assert ret == expected_0

# Generated at 2022-06-24 21:00:21.528286
# Unit test for function to_native
def test_to_native():
    var_0 = to_bytes(var_0)


# Generated at 2022-06-24 21:00:26.311739
# Unit test for function to_native
def test_to_native():
    var_0 = to_bytes(var_0)


# Generated at 2022-06-24 21:00:37.788794
# Unit test for function to_native
def test_to_native():
    var_0 = {}
    var_1 = {}
    var_0 = (var_1 == var_0)
    var_0 = {}
    var_1 = {}
    var_0 = (var_1 != var_0)
    var_0 = {}
    var_1 = {}
    var_0 = (var_1 in var_0)

# Generated at 2022-06-24 21:00:39.116492
# Unit test for function to_bytes
def test_to_bytes():
    var_1 = {}


# Generated at 2022-06-24 21:00:42.078767
# Unit test for function to_bytes
def test_to_bytes():
    try:
        var_0 = {}
        var_1 = to_bytes(var_0)
        var_2 = to_bytes(var_0)
    except Exception as e:
        raise e


# Generated at 2022-06-24 21:00:46.875808
# Unit test for function to_native
def test_to_native():
    result = to_native({})
    if not isinstance(result, dict):
        raise RuntimeError("Return value should be a dict")
    if result:
        raise RuntimeError("Dictionary should be empty")


# Generated at 2022-06-24 21:00:48.771697
# Unit test for function jsonify
def test_jsonify():
    var_0 = {}
    var_1 = jsonify(var_0)
    assert var_1 == '{}'


# Generated at 2022-06-24 21:00:53.545712
# Unit test for function jsonify
def test_jsonify():
    # Python 2
    if PY2:
        # Populate the arguments
        var_0 = {}

        # Call the function
        result = jsonify(var_0)
        assert result == '{}'

        # Python 3
    else:
        # Populate the arguments
        var_0 = {}

        # Call the function
        result = jsonify(var_0)
        assert result == '{}'



# Generated at 2022-06-24 21:00:54.520911
# Unit test for function jsonify
def test_jsonify():
    assert var_0 == {}



# Generated at 2022-06-24 21:01:01.061160
# Unit test for function jsonify
def test_jsonify():
    try:
        var_0 = {}
        var_0 = jsonify(var_0)

        assert var_0 == "{}", var_0
    except AssertionError as ae:
        fail(ae.message)
    except Exception as e:
        fail(str(e))
    else:
        pass



# Generated at 2022-06-24 21:01:09.117145
# Unit test for function to_native
def test_to_native():
    # This function is not meant to be used to serialize
    # complex data structures, the full serializer
    # should be used instead.  This function is basically a
    # python2 to python3 shim around native types

    # Most of these tests come from the tests/unit/utils/test_jsonify.py
    # tests

    # this test primarily ensure that to_native does not change the behavior
    # for dicts with non-string keys
    var_1 = {}
    var_2 = {'foo': 'bar'}
    var_3 = {u'foo': u'bar'}
    var_4 = {u'123': u'bar'}
    var_5 = {u'True': u'bar'}
    var_6 = {u'False': u'bar'}

# Generated at 2022-06-24 21:01:10.819294
# Unit test for function jsonify
def test_jsonify():
    print("Test jsonify")
    var_0 = {}

    print(jsonify(var_0))


# Generated at 2022-06-24 21:01:19.636917
# Unit test for function jsonify
def test_jsonify():
    # No arguments
    res = jsonify()
    # Verify the outputs
    assert (res == "{}")
    # One argument
    res = jsonify(5)
    # Verify the outputs
    assert (res == "5")
    # Two arguments
    res = jsonify(5,5)
    # Verify the outputs
    assert (res == "{}")


# Generated at 2022-06-24 21:01:22.292798
# Unit test for function jsonify
def test_jsonify():
    assert jsonify([1,2,3]) == '[1, 2, 3]'


# Generated at 2022-06-24 21:01:23.724487
# Unit test for function to_native
def test_to_native():
    str_0 = 'test,test3'
    var_0 = to_native(str_0, str_0, str_0)

# Generated at 2022-06-24 21:01:29.438444
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'test,test3'
    var_0 = to_bytes(str_0, str_0)
    return var_0

to_native = to_bytes



# Generated at 2022-06-24 21:01:36.966120
# Unit test for function to_native
def test_to_native():
    assert to_native('\x80abc') == u'\x80abc'
    assert to_native(u'\x80abc') == u'\x80abc'
    assert to_native(b'\x80abc') == u'\x80abc'

    assert to_native('\x80abc', None, 'surrogate_then_replace') == u'\x80abc'
    assert to_native(u'\x80abc', None, 'surrogate_then_replace') == u'\x80abc'
    assert to_native(b'\x80abc', None, 'surrogate_then_replace') == u'\x80abc'

    assert to_native('\x80abc', None, 'surrogate_or_replace') == u'\x80abc'

# Generated at 2022-06-24 21:01:38.306627
# Unit test for function to_native
def test_to_native():
    x = to_native('/foo/bar')
    assert x == '/foo/bar'


# Generated at 2022-06-24 21:01:40.240823
# Unit test for function to_native
def test_to_native():
    assert to_native(b'\x80') == '\uFFFD'

# Generated at 2022-06-24 21:01:43.207968
# Unit test for function to_native
def test_to_native():
    assert to_native('hello') == 'hello'
    assert to_native(b'hello') == 'hello'
    if PY3:
        assert to_native(u'hello') == 'hello'
    else:
        assert to_native(u'hello') == u'hello'
    assert to_native(5) == 5



# Generated at 2022-06-24 21:01:44.689159
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == 'foo'
    assert to_native('foo') == 'foo'
    assert to_native(1) == '1'



# Generated at 2022-06-24 21:01:51.143086
# Unit test for function jsonify
def test_jsonify():
    # jsonify should return str type
    assert isinstance(jsonify({'test': 'test'}), str)
    assert isinstance(jsonify({'test': 'test'}, ensure_ascii=False), str)
    assert isinstance(jsonify({'test': 'test'}, ensure_ascii=True), str)
    assert isinstance(jsonify({'test': 'test'}, ensure_ascii=False, sort_keys=False), str)
    assert isinstance(jsonify({'test': 'test'}, ensure_ascii=False, sort_keys=True), str)
    assert isinstance(jsonify({'test': 'test'}, ensure_ascii=True, sort_keys=False), str)

# Generated at 2022-06-24 21:02:07.277517
# Unit test for function jsonify
def test_jsonify():
    if 'str_0' not in globals():
        str_0 = 'test,test3'
    assert (jsonify(str_0) == json.dumps("test,test3", default=_json_encode_fallback))
    assert (jsonify(str_0) == json.dumps("test,test3", default=_json_encode_fallback))
    assert (jsonify(str_0) == json.dumps("test,test3", default=_json_encode_fallback))
    assert (jsonify(str_0) == json.dumps("test,test3", default=_json_encode_fallback))
    assert (jsonify(str_0) == json.dumps("test,test3", default=_json_encode_fallback))

# Generated at 2022-06-24 21:02:11.180278
# Unit test for function jsonify
def test_jsonify():
  data = {'a': {'b': {'c': 'd,e'}, 'f': 'g,h'}}
  str_0 = jsonify(data)
  var_0 = None
  if (('{"a": {"b": {"c": "d,e"}, "f": "g,h"}}') == str_0):
    var_0 = 1
  assert var_0
  return 0


# Generated at 2022-06-24 21:02:16.439096
# Unit test for function to_bytes
def test_to_bytes():
    expected_return = '''default_bytes'''
    str_0 = 'default_text'
    var_0 = to_bytes(str_0, str_0)
    # assert var_0 == expected_return, 'Expected {}, but got {}'.format(expected_return, var_0)
    print(var_0)


# Generated at 2022-06-24 21:02:18.045887
# Unit test for function jsonify
def test_jsonify():
    data_0 = {'sam': 'sam', 'james': 'james'}
    str_0 = jsonify(data_0)


# Generated at 2022-06-24 21:02:26.258955
# Unit test for function to_bytes
def test_to_bytes():
    # Testing if TypeError raised when required arg not specified
    try:
        to_bytes()
    except TypeError as e:
        assert e.args[0] == "to_bytes() takes at least 1 argument (0 given)"
    # Testing if TypeError raised when arg number is less than the required number
    try:
        to_bytes(obj=None)
    except TypeError as e:
        assert e.args[0] == "to_bytes() takes at least 1 argument (1 given)"
    # Testing if TypeError raised when invalid type passed for 'encoding'
    try:
        to_bytes(obj=None, encoding=None)
    except TypeError as e:
        assert e.args[0] == "to_bytes() argument 2 must be str, not NoneType"
    # Testing if TypeError raised when invalid type passed for '

# Generated at 2022-06-24 21:02:29.741664
# Unit test for function jsonify
def test_jsonify():
    obj = {u'test': u'test2', u'test3': u'test4'}
    try:
        json.dumps(obj)
    except UnicodeDecodeError:
        assert(1==1)


# Generated at 2022-06-24 21:02:41.101482
# Unit test for function jsonify
def test_jsonify():

    # Test #0
    # Simple test with the sample data
    old_data = {
        "string": b"\xc2\xa92019 All Rights Reserved",
        "unicode": u"\xa92019 All Rights Reserved",
    }
    new_data = {
        "string": "©2019 All Rights Reserved",
        "unicode": "©2019 All Rights Reserved",
    }

    # Test #1
    # Simple test with the sample data
    new_data = {
        "string": "©2019 All Rights Reserved",
        "unicode": "©2019 All Rights Reserved",
    }


# Generated at 2022-06-24 21:02:51.633357
# Unit test for function to_native
def test_to_native():
    # Python 2.6 doesn't have the `nonlocal` keyword
    # pylint: disable=unused-variable

    # Nonstring inputs
    # No defaults
    assert to_native(None, None, None) is None
    assert to_native(42, None, None) == 42
    # Default everything to ascii
    assert to_native(None, 'ascii', 'strict') is None
    assert to_native(42, 'ascii', 'strict') == 42
    # Default errors to strict
    assert to_native(None, 'ascii', None) is None
    assert to_native(42, 'ascii', None) == 42
    # Default encoding to utf-8
    assert to_native(None, None, 'strict') is None

# Generated at 2022-06-24 21:02:53.336792
# Unit test for function to_native
def test_to_native():
    str_0 = 'test3'
    ret_0 = to_native(str_0)


# Generated at 2022-06-24 21:02:57.215870
# Unit test for function to_native
def test_to_native():
    str_0 = 'test,test3'
    str_1 = 'test,test3'
    var_0 = to_native(str_0, str_1)
    assert var_0 == 'test,test3'


# Generated at 2022-06-24 21:03:18.503151
# Unit test for function to_native
def test_to_native():
    assert to_native('foo', 'ascii') == b'foo'
    assert to_native(b'bar', 'ascii') == 'bar'
    assert to_native(b'b\xe1\x88\xb4r', 'utf-8') == 'b\u1234r'
    if PY3:
        assert to_native('b\xe1\x88\xb4r', 'utf-8', 'surrogate_or_strict') == 'b\u1234r'
    else:
        assert to_native('b\xe1\x88\xb4r', 'utf-8', 'surrogate_or_strict') == b'b\xe1\x88\xb4r'

# Generated at 2022-06-24 21:03:22.909545
# Unit test for function to_bytes
def test_to_bytes():
    try:
        test_case_0()
        test_outcome = True
    except Exception:
        test_outcome = False

    assert test_outcome == True

# Unit test execution
if __name__ == '__main__':
    test_to_bytes()

# Generated at 2022-06-24 21:03:26.689727
# Unit test for function to_bytes
def test_to_bytes():
    """
    Unit test for function to_bytes
    """
    try:
        test_case_0()
    except Exception as ex:
        if str(ex) != "could not convert string to float: 'test,test3'":
            raise


_BYTES_UNCHANGED = (int, binary_type, type(None))



# Generated at 2022-06-24 21:03:33.515934
# Unit test for function jsonify
def test_jsonify():
    '''
    Test if to_bytes works
    '''

    foo = {1: {2: [3, 4, 5, 'a', 'b', 'c']},
           4: {'a': {'b': {'c': {'d': [1, 2, 3, 'a', 'b', 'c']}}},
               'd': {'e': {'f': 1, 'g': 2}}},
           7: 8,
           u'test': u'test'}
    ans = jsonify(foo)
    print(ans)
    #assert ans == json.dumps(foo)
    #assert ans == '{"options": {"foo": "bar", "spam": "eggs"}}'

if __name__ == "__main__":
    test_case_0()
    test_jsonify()

# Generated at 2022-06-24 21:03:38.151199
# Unit test for function jsonify
def test_jsonify():
    print("Test josnify")
    str_0 = "test string"
    dict_0 = dict()
    dict_0['key'] = str_0
    jsonify(dict_0)


# Generated at 2022-06-24 21:03:47.483537
# Unit test for function to_native
def test_to_native():
    assert to_native(True) is True
    assert to_native(False) is False
    assert to_native(None) is None
    assert to_native(1) == 1
    assert to_native(1.0) == 1.0
    assert to_native(u'foo') == 'foo'
    if PY3:
        assert to_native(b'bar') == b'bar'
    else:
        assert to_native(b'bar') == 'bar'
    assert to_native((u'key', u'value')) == ('key', 'value')
    assert to_native([u'key', u'value']) == ['key', 'value']
    assert to_native({u'key': u'value'}) == {'key': 'value'}

# Generated at 2022-06-24 21:03:51.923955
# Unit test for function to_native
def test_to_native():
    assert 'foo' == to_native(to_text('foo'))
    assert u'foo' == to_native(to_bytes(u'foo'))
    assert 'foo' == to_native(u'foo')
    assert u'foo' == to_native('foo')


# Generated at 2022-06-24 21:03:59.056298
# Unit test for function to_native
def test_to_native():
    """Test the behavior of the to_native function
    in the ansible to_native module.
    """
    # Add input string
    str_0 = 'Hello, world!'
    str_1 = 'Hello, world!'
    # Add expected output string
    str_2 = 'Hello, world!'
    # Call function to test
    # str_3 = to_native(str_0, str_1)
    # assert str_3 == str_2


# Generated at 2022-06-24 21:04:05.373991
# Unit test for function to_bytes
def test_to_bytes():
    """
    to_bytes() returns a byte string from it's input object. For a text string or a
    raw string, it's the same as doing .encode(encoding, errors). For a non-string
    type, it will return str(obj).encode(encoding, errors).
    """
    assert to_bytes('') == b''
    assert to_bytes('abc', errors='replace') == b'abc'
    assert to_bytes('abc', errors='strict') == b'abc'
    assert to_bytes('abc', nonstring='empty') == b''
    assert to_bytes('abc', nonstring='passthru') == 'abc'
    assert to_bytes(b'abc', encoding='utf-8') == b'abc'

# Generated at 2022-06-24 21:04:11.339143
# Unit test for function jsonify
def test_jsonify():
    # json.dumps({1:2})
    str_0 = '{"1": 2}'
    data_1 = json.loads(str_0)
    str_2 = jsonify(data_1)
    # print("jsonify(1) expect: {}".format(str_0))
    print("jsonify(1) got: {}".format(str_2))
    assert (str_2 == str_0)


# Generated at 2022-06-24 21:04:40.048548
# Unit test for function to_native
def test_to_native():
    assert to_native(u'text') == u'text'
    assert to_native('text') == 'text'
    assert to_native(b'text') == 'text'
    assert to_native(1) == 1
    assert to_native(1.0) == 1.0
    assert to_native([1,2,3]) == [1,2,3]



# Generated at 2022-06-24 21:04:50.288114
# Unit test for function jsonify
def test_jsonify():
    # Test with a simple list
    test_list_1 = ["one", 2, {"three": "four"}]
    assert json.loads(jsonify(test_list_1)) == test_list_1

    # Test a list with unicode characters
    test_list_2 = ["one", 2, {"three": "föur"}]
    assert json.loads(jsonify(test_list_2)) == test_list_2

    # Test a list with ansible internal types
    test_list_3 = ["one", 2, Set(["three"])]
    assert json.loads(jsonify(test_list_3)) == ["one", 2, ["three"]]

    # Test a dictionary with unicode characters
    test_dict_1 = {"one": 2, "three": {"four": "föur"}}

# Generated at 2022-06-24 21:04:51.943455
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'test,test3'
    var_0 = to_bytes(str_0, str_0)


# Generated at 2022-06-24 21:04:57.466189
# Unit test for function to_bytes
def test_to_bytes():
    # Setup test variables
    str_0 = 'test,test3'
    # Call function to_bytes with arguments
    result = to_bytes(str_0, str_0)
    assert isinstance(result, str)


# Generated at 2022-06-24 21:04:58.969385
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'test,test3'
    var_0 = to_bytes( str_0, str_0 )



# Generated at 2022-06-24 21:05:08.840915
# Unit test for function to_native
def test_to_native():
    assert isinstance(to_native(u"test"), text_type)
    assert isinstance(to_native("test"), text_type)
    assert isinstance(to_native(u"test", errors='surrogate_or_strict'), text_type)
    assert isinstance(to_native("test", errors='surrogate_or_strict'), text_type)
    assert isinstance(to_native(u"test", errors='surrogate_or_replace'), text_type)
    assert isinstance(to_native("test", errors='surrogate_or_replace'), text_type)
    assert isinstance(to_native(u"test", errors='surrogate_then_replace'), text_type)
    assert isinstance(to_native("test", errors='surrogate_then_replace'), text_type)
   

# Generated at 2022-06-24 21:05:17.502503
# Unit test for function to_native
def test_to_native():
    str_0 = 'test,test3'
    str_0 = to_native(str_0, str_0)
    str_1 = 'test"test2'
    str_1 = to_native(str_1, str_1)
    str_2 = 'test"test3'
    str_2 = to_native(str_2, str_2)
    str_3 = 'test,test2'
    str_3 = to_native(str_3, str_3)
    str_4 = 'test, test4'
    str_4 = to_native(str_1, str_2, str_3, str_4)


# Generated at 2022-06-24 21:05:28.485818
# Unit test for function to_bytes
def test_to_bytes():
    import os
    import sys
    import platform
    import shutil
    import tempfile
    import filecmp

    temp_dir = tempfile.mkdtemp()

    example_dir = os.path.join(temp_dir, 'example')

    os.makedirs(example_dir)

    example_0_path = os.path.join(example_dir, 'example_0.txt')

    with open(example_0_path, 'w') as example_0_filedesc:
        example_0_filedesc.write('Hello World')

    example_1_path = os.path.join(example_dir, 'example_1.txt')

    with open(example_1_path, 'w') as example_1_filedesc:
        example_1_filedesc.write('New')

    example_

# Generated at 2022-06-24 21:05:36.492044
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'test,test3'
    var_0 = to_bytes(str_0, str_0)
    if 'test,test3' not in str_0:
        raise Exception("Test failed for function to_bytes")

if __name__ == '__main__':
    print("Running Unit Test for function to_bytes")
    test_to_bytes()

# Generated at 2022-06-24 21:05:42.540620
# Unit test for function to_native
def test_to_native():
    assert to_native(u'spam', 'ascii') == u'spam'
    assert to_native(b'spam', 'ascii') == u'spam'

