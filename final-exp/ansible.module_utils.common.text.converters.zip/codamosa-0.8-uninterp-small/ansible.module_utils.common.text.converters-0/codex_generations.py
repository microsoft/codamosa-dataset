

# Generated at 2022-06-24 20:56:39.447588
# Unit test for function jsonify
def test_jsonify():
    print("[+] TESTING 'ansible.module_utils.basic.jsonify'" + "-"*50)

    print("[.] Case 0: Default Case:", end='')
    test_case_0()
    print("\t\t\t[Pass]")

    print("[+] ALL 'ansible.module_utils.basic.jsonify' TEST PASSED." + "-"*50)



# Generated at 2022-06-24 20:56:42.235248
# Unit test for function jsonify
def test_jsonify():
    data = {
            u'test_key': 'test_value',
            u'': u'',
            u'\u2713': u'\u2713',
            }

    assert jsonify(data) == to_text(u'{"\u2713": "\u2713", "": "", "test_key": "test_value"}')



# Generated at 2022-06-24 20:56:49.370371
# Unit test for function to_native
def test_to_native():
    assert to_native(True) == True
    assert to_native(1) == 1
    assert to_native(None) is None
    assert to_native('foo') == 'foo'
    assert to_native(to_bytes('foo')) == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native('🤔') == '🤔'
    assert to_native(to_bytes('🤔')) == '🤔'
    assert to_native(b'\xf0\x9f\xa4\x94') == '🤔'


# Generated at 2022-06-24 20:56:55.165793
# Unit test for function to_bytes
def test_to_bytes():
    # Test decoding of unicode surrogate pairs that can't be represented in cp1252
    # Should raise UnicodeDecodeError
    try:
        codecs.decode(binary_type(b'\xed\x95\x9c'), 'cp1252')
        assert False, "Expected a UnicodeDecodeError"
    except UnicodeDecodeError:
        pass
    # Decode to Unicode
    unicode_0 = codecs.decode(binary_type(b'\xed\x95\x9c\xea\xb5\xad'), 'utf-8')
    # Encode to cp1252 and raise UnicodeEncodeError
    try:
        codecs.encode(unicode_0, 'cp1252')
        assert False, "Expected a UnicodeEncodeError"
    except UnicodeEncodeError:
        pass

# Generated at 2022-06-24 20:56:57.329856
# Unit test for function jsonify
def test_jsonify():
    var_0 = test_case_0()
    return var_0


# Generated at 2022-06-24 20:57:05.947044
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(None) == b'None'
    assert to_bytes(5) == b'5'
    assert to_bytes({'a': 'b'}) == b"{'a': 'b'}"
    assert to_bytes('foo bar') == b'foo bar'
    assert to_bytes(u'foo bar') == b'foo bar'
    assert to_bytes('foo bar', encoding='utf-8') == b'foo bar'
    assert to_bytes(u'\xfc') == b'\xc3\xbc'
    assert to_bytes(u'\xfc', encoding='ascii') == b'?\xfc'
    assert to_bytes(u'\xfc', errors='surrogate_or_strict') == b'\xfc'

# Generated at 2022-06-24 20:57:08.036655
# Unit test for function jsonify
def test_jsonify():
    int_0 = -407
    var_0 = jsonify(int_0)
    assert var_0 == "-407"


# Generated at 2022-06-24 20:57:11.619716
# Unit test for function jsonify
def test_jsonify():
    try:
        test_case_0()
        print("Test case 0:")
        print("jsonify() works without error")
    except:
        print("jsonify() error")


# Generated at 2022-06-24 20:57:14.053615
# Unit test for function jsonify
def test_jsonify():
    print('Testing function jsonify')

    test_case_0()

# Entry point for stand-alone testing
if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-24 20:57:15.335690
# Unit test for function jsonify
def test_jsonify():
    # *** Run test case 0 ***
    test_case_0()
    
    

# Generated at 2022-06-24 20:57:29.246039
# Unit test for function to_native
def test_to_native():
    func_0 = to_native(str)
    int_0 = -407
    var_0 = func_0(int_0)
    func_0 = to_native(str)
    str_0 = 'Hi'
    var_0 = func_0(str_0)
    func_0 = to_native(str)
    bytes_0 = b'Hi'
    var_0 = func_0(bytes_0)
    func_1 = to_native(int)
    int_0 = -407
    var_0 = func_1(int_0)
    func_1 = to_native(int)
    str_0 = '0'
    var_0 = func_1(str_0)
    func_1 = to_native(float)
    int_0 = -407

# Generated at 2022-06-24 20:57:37.782162
# Unit test for function jsonify
def test_jsonify():
    result = jsonify(123)
    assert type(result) == str
    assert result == '123'
    result = jsonify("abc")
    assert type(result) == str
    assert result == '"abc"'
    result = jsonify("12")
    assert type(result) == str
    assert result == '"12"'
    result = jsonify('12')
    assert type(result) == str
    assert result == '"12"'
    result = jsonify(int_0)
    assert type(result) == str
    assert result == '-407'


# Generated at 2022-06-24 20:57:46.477825
# Unit test for function to_native
def test_to_native():
    if PY3:
        assert to_native("abc") == "abc"
        assert to_native(b"abc") == "abc"
        assert to_native("abc".encode("utf-8")) == "abc"
        assert to_native("abc".encode("utf-16")) == "abc"
    else:
        assert to_native("abc") == u"abc"
        assert to_native(b"abc") == "abc"
        assert to_native("abc".encode("utf-8")) == u"abc"
        assert to_native("abc".encode("utf-16")) == u"abc"


# Generated at 2022-06-24 20:57:54.347942
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('Hi there') == b'Hi there'
    assert to_bytes(u'Hi there') == b'Hi there'
    assert to_bytes(u'Hi there', 'utf-16') == b'\xff\xfel\x00H\x00i\x00 \x00t\x00h\x00e\x00r\x00e\x00'
    assert to_bytes(b'Hi there') == b'Hi there'
    assert to_bytes(1) == b'1'
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='empty') == b''
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

# Generated at 2022-06-24 20:58:03.402389
# Unit test for function to_bytes
def test_to_bytes():
    if not HAS_SURROGATEESCAPE:
        raise Exception("Tests cannot be run because Python does not support the surrogateescape codec")


# Generated at 2022-06-24 20:58:04.951515
# Unit test for function to_bytes
def test_to_bytes():
    assert True


# Generated at 2022-06-24 20:58:07.507282
# Unit test for function jsonify
def test_jsonify():
    print("----------------------")
    print("Testing function jsonify")
    test_case_0()
    print("----------------------")


# Generated at 2022-06-24 20:58:18.622533
# Unit test for function to_native
def test_to_native():

    str_0 = u''
    # Checking for errors
    # if "module_utils._text" == "module_utils._text":
    #     raise Exception("Failed to convert to native")

    str_1 = u''
    # Checking for errors
    # if "module_utils._text" == "module_utils._text":
    #     raise Exception("Failed to convert to native")

    str_2 = u''
    # Checking for errors
    # if "module_utils._text" == "module_utils._text":
    #     raise Exception("Failed to convert to native")

    str_3 = u''
    # Checking for errors
    # if "module_utils._text" == "module_utils._text":
    #     raise Exception("Failed to convert to native")

    str_4 = u''
    # Checking

# Generated at 2022-06-24 20:58:21.598811
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(1) == "1"
    assert jsonify(1, indent=4) == "1"
    assert jsonify({'foo': 1}) == '{"foo": 1}'
    assert jsonify({'foo': 1}, indent=4) == '{\n    "foo": 1\n}'


# Generated at 2022-06-24 20:58:24.669413
# Unit test for function jsonify
def test_jsonify():
    # Testing function jsonify
    test_case_0()
    
    

# Generated at 2022-06-24 20:58:36.195310
# Unit test for function jsonify
def test_jsonify():

    # type: () -> None
    """
    test for jsonify
    https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/_text.py#L363
    """
    var_0 = jsonify({})



# Generated at 2022-06-24 20:58:47.204183
# Unit test for function jsonify
def test_jsonify():
    # Test the function to make sure it returns a json
    list_0 = [1,2,3]
    dict_0 = {}
    dict_0['cisco'] = list_0
    dict_0['arista'] = list_0
    dict_0['juniper'] = list_0
    json_0 = jsonify(dict_0)
    assert(isinstance(json_0,text_type))
    assert(json_0 == '{"arista": [1, 2, 3], "cisco": [1, 2, 3], "juniper": [1, 2, 3]}')
    dict_0 = {}
    dict_0['key_0'] = 'value_0'
    dict_0['key_1'] = ['value_1']
    dict_0['key_2'] = ['value_2']
   

# Generated at 2022-06-24 20:58:50.361179
# Unit test for function jsonify
def test_jsonify():
    dict_0 = {}
    var_0 = jsonify(dict_0)

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-24 20:59:00.012092
# Unit test for function jsonify
def test_jsonify():
    simple_map = {'key': 'value'}
    simple_list = ['value0', 'value1']

    def assertEqualJSON(actual, expected, encoding='utf-8'):
        assert jsonify(actual, encoding=encoding) == expected
        assert jsonify(container_to_text(actual, encoding=encoding)) == expected

    assert jsonify(None) == u'null'
    assert jsonify(True) == u'true'
    assert jsonify(42) == u'42'
    assert jsonify(3.1415) == u'3.1415'
    assert jsonify(3.1415e+55) == u'3.1415e+55'

# Generated at 2022-06-24 20:59:02.072031
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict_0) == b'{}'
    print('Success: test_jsonify')



# Generated at 2022-06-24 20:59:12.230010
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(None) == b'None'
    assert to_bytes(True) == b'True'
    assert to_bytes(False) == b'False'
    assert to_bytes(33) == b'33'
    assert to_bytes(33.0) == b'33.0'
    assert to_bytes('foo') == b'foo'
    assert to_bytes('føø') == b'f\xc3\xb8\xc3\xb8'
    assert to_bytes('f\u00f8\u00f8') == b'f\xc3\xb8\xc3\xb8'
    assert to_bytes('f\ufffd\ufffd') == b'f\ufffd\ufffd'

# Generated at 2022-06-24 20:59:21.355426
# Unit test for function to_native
def test_to_native():
    dict_1 = {u'hey': u'man'}
    var_1 = to_native(dict_1)
    assert isinstance(var_1, dict)


# Generated at 2022-06-24 20:59:24.689222
# Unit test for function jsonify
def test_jsonify():
    data = {"a": "b", "c": Set([3, 4])}
    ret = jsonify(data)
    assert ret == '{"a": "b", "c": [3, 4]}'


# Generated at 2022-06-24 20:59:34.991187
# Unit test for function jsonify
def test_jsonify():
    class OrgException(Exception):
        pass
    class NewException(Exception):
        pass
    try:
        raise OrgException("Original Exception")
    except OrgException:
        import traceback
        try:
            raise NewException(to_bytes(traceback.format_exc()))
        except NewException as e_s:
            stack_trace = jsonify(to_text(e_s))
            print(type(stack_trace))
            print(stack_trace)
            print(type(stack_trace))
            print(stack_trace)
            print(to_bytes(stack_trace))
            print(to_text(stack_trace))


# Generated at 2022-06-24 20:59:38.691807
# Unit test for function jsonify
def test_jsonify():
    try:
        import json
    except ImportError:
        print('Skipping test_jsonify')
        return
    assert jsonify({"a": {"b": u"value"}}) == b'{"a": {"b": "value"}}'



# Generated at 2022-06-24 20:59:58.708303
# Unit test for function to_bytes
def test_to_bytes():
    # The generated code is not yet able to infer types for dictionary
    # literal. For now, we will skip the test for dictionary.
    for i in range(2):
        if i == 0:
            dict_0 = {}
            var_0 = to_bytes(dict_0)
        else:
            dict_0 = {}
            var_0 = to_bytes(dict_0, encoding='utf-8')
        assert isinstance(var_0, bytes)
        assert var_0 == b'{}'
    for i in range(2):
        if i == 0:
            dict_0 = {}
            var_0 = to_bytes(dict_0, nonstring='empty')
        else:
            dict_0 = {}

# Generated at 2022-06-24 21:00:04.844641
# Unit test for function to_native
def test_to_native():
    # There are no inputs
    # Case 0
    # assert that to_native returns the value of default when called with the args (dict, '', 'strict')
    # assert that to_native returns the type of bytes when called with the args (dict, '', 'strict')
    dict_0 = {}
    try:
        var_0 = to_native(dict_0, '', 'strict')
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-24 21:00:14.345315
# Unit test for function to_native
def test_to_native():
    assert to_bytes(b'\xe2\x86\x95') == b'\xe2\x86\x95', 'to_bytes of b\'\\xe2\\x86\\x95\' is b\'\\xe2\\x86\\x95\''
    assert to_text(u'\u2192') == u'\u2192', 'to_text(u\'\\u2192\') == u\'\\u2192\''
    assert to_text(b'\xe2\x86\x95') == u'\u2192', 'to_text(b\'\\xe2\\x86\\x95\') == u\'\\u2192\''

# Generated at 2022-06-24 21:00:24.057284
# Unit test for function to_bytes
def test_to_bytes():
    # Test with no options
    dict_1 = {"abcd": "abcd"}
    dict_2 = {"key": "a=b", "key1": {}}
    dict_3 = {"key": "a=b", "key1": {"key": "a=b"}}
    dict_4 = {"key": "a=b", "key1": {"key": "a=b", "key1": {"key": "a=b", "key1": "a=b"}}}
    dict_5 = {"key": "a=b", "key1": {"key": "a=b", "key1": {"key": "a=b", "key1": {"key": "a=b", "key1": "a=b"}}}}

    ref_1 = b'{"abcd": "abcd"}'

# Generated at 2022-06-24 21:00:29.893050
# Unit test for function to_native
def test_to_native():
  obj = 123
  obj = to_native(obj)
  assert(obj == 123)
  dict_0 = {'key_0':'value_0'}
  dict_0 = to_native(dict_0)
  assert(dict_0 == {'key_0':'value_0'})
  obj = None
  obj = to_native(obj)
  assert(obj == None)
  obj = 0.1
  obj = to_native(obj)
  assert(obj == 0.1)
  obj = "Hello"
  obj = to_native(obj)
  assert(obj == "Hello")
  obj = 'TestCase'
  obj = to_native(obj)
  assert(obj == 'TestCase')
  obj = [1,2,"Hello",['a','b','c']]
 

# Generated at 2022-06-24 21:00:40.134244
# Unit test for function jsonify
def test_jsonify():
    # Input
    dict_0 = {}
    dict_1 = {
        "k1": "v1",
        "k2": "v2",
    }
    dict_2 = {
        "k1": 1,
        "k2": 2,
    }
    dict_3 = {
        "k1": {
            "k11": "v11",
            "k12": "v12",
        },
        "k2": "v2",
    }
    dict_4 = {
        "k1": [
            "v11",
            "v12",
        ],
        "k2": "v2",
    }

    # Output
    json_0 = '{}'
    json_1 = '{"k1": "v1", "k2": "v2"}'
    json

# Generated at 2022-06-24 21:00:45.212753
# Unit test for function jsonify
def test_jsonify():
    dict_0 = {'1':1,'2':2,'3':3,'4':4}
    var_0 = jsonify(dict_0)
    assert var_0 == json.dumps(dict_0,default=_json_encode_fallback)



# Generated at 2022-06-24 21:00:51.388690
# Unit test for function to_native
def test_to_native():
    data = {'a': 1, 'b': 'string', 'c': b'byte\x00string', 'd': 1.1, 'e': {'a': 1, 'b': u'unicode', 'c': b'byte\x00string'}}
    assert to_native(data) == {'a': 1, 'b': 'string', 'c': 'byte\x00string', 'd': 1.1, 'e': {'a': 1, 'b': 'unicode', 'c': 'byte\x00string'}}


# Generated at 2022-06-24 21:00:59.580073
# Unit test for function to_bytes
def test_to_bytes():
    # Creation of the values
    dict_0 = {'key_1': 'value_1', 'key_2': 'value_2', 'key_3': 'value_3', 'key_4': 'value_4', 'key_5': 'value_5', 'key_6': 'value_6', 'key_7': 'value_7', 'key_8': 'value_8', 'key_9': 'value_9', 'key_10': 'value_10'}
    var_0 = to_bytes(dict_0)



# Generated at 2022-06-24 21:01:03.476941
# Unit test for function jsonify
def test_jsonify():
    '''
    Unit test for function jsonify
    '''
    for data_dict in (
        {"foo": "bar"},
        {"baz": "qux"},
    ):
        jsonify(data_dict)



# Generated at 2022-06-24 21:01:12.558403
# Unit test for function jsonify
def test_jsonify():
    data_0 = {}
    var_0 = jsonify(data_0)
    print("var_0: {}".format(var_0))
    assert var_0 == '{}'


# Generated at 2022-06-24 21:01:20.002171
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo\xe2\x98\xba') == u'foo\u263A'
    assert to_native(b'foo\xc3\xba\xc2\xb0') == u'foo\xf9\xb0'
    assert to_native(b'foo\xe2\x98\xba') == u'foo\u263A'
    assert to_native(b'foo\xe2\x98') == u'foos'
    assert to_native(b'foo\xe2\x98', errors='strict') == u'foo\udce2\x98'
    assert to_native(b'foo\xe2\x98', errors='surrogate_or_strict') == u'foo\udce2\x98'

# Generated at 2022-06-24 21:01:21.390720
# Unit test for function jsonify
def test_jsonify():
    pass

# Generated at 2022-06-24 21:01:31.238945
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(to_text('abcd')) == 'abcd', "Unicode data is not converted properly to Byte"
    assert to_bytes(to_text('abcd'), encoding='utf-8') == 'abcd', "Unicode data is not converted properly to Byte"
    assert to_bytes(to_text('\u00f1'), encoding='utf-8', errors='surrogateescape') == '\ufffd', "Unicode data is not converted properly to Byte"
    assert to_bytes(to_text('\u00f1'), encoding='utf-8', errors='surrogate_or_strict') == '\ufffd', "Unicode data is not converted properly to Byte"

# Generated at 2022-06-24 21:01:35.805817
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 'b'}) == '{"a": "b"}'


# Generated at 2022-06-24 21:01:41.503180
# Unit test for function to_native
def test_to_native():
    # Try to native a byte string
    # Try to native a unicode string
    # Try to native a set
    # Try to native a list
    # Try to native a tuple
    # Try to native a dictionary
    # Try to native a float
    # Try to native an int
    # Try to native None
    # Try to native False
    # Try to native True
    native_string = 'This is a test string'
    native_byte_string = 'This is a byte string'
    native_unicode = u'This is a unicode string'
    native_float = 123.45
    native_int = 123
    native_tuple = (1,2)
    native_list = [3,4]
    native_bool_true = True
    native_bool_false = False

# Generated at 2022-06-24 21:01:42.844910
# Unit test for function to_native
def test_to_native():

    # Case 0
    test_case_0()

 
if __name__ == "__main__":
    test_to_native()

# Generated at 2022-06-24 21:01:45.278719
# Unit test for function jsonify
def test_jsonify():
    test_obj = Set([1,2,3])
    print(jsonify(test_obj))


# Generated at 2022-06-24 21:01:45.829778
# Unit test for function jsonify
def test_jsonify():
    pass



# Generated at 2022-06-24 21:01:52.509177
# Unit test for function to_bytes
def test_to_bytes():
    import pickle
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import cStringIO, cPickle
    from ansible.module_utils.pycompat24 import encode_bytes
    # Create the IO object to get around the handler mismatch in Python2.7
    fd = StringIO()
    # Save the dict object to stream
    cPickle.dump(dict_0, fd, -1)
    # Reset stream for reading
    fd.seek(0)
    # load the dict object
    fd = cStringIO(encode_bytes(fd.read()))
    dict_0 = cPickle.load(fd)
    var_1 = to_bytes(dict_0)

# Generated at 2022-06-24 21:01:59.291403
# Unit test for function jsonify
def test_jsonify():
    assert '{}' == jsonify({})


# Generated at 2022-06-24 21:02:04.930924
# Unit test for function jsonify
def test_jsonify():
    data = {"a": 1, "b": 2, "c": ["d", "e", "f"]}
    data_json = jsonify(data)
    assert data_json == '{"a": 1, "c": ["d", "e", "f"], "b": 2}'
    assert isinstance(data_json, str)



# Generated at 2022-06-24 21:02:08.293663
# Unit test for function to_bytes
def test_to_bytes():
    # Test case 0
    test_case_0()
    # Test case 1
    # test_case_1()


if __name__ == '__main__':
    test_to_bytes()

# Generated at 2022-06-24 21:02:15.019718
# Unit test for function jsonify
def test_jsonify():
    data = {"a": 1, "b": [1, 2, 3], "c": {"a": "b"}}
    json_data = jsonify(data)

    assert(json_data == '{"a": 1, "b": [1, 2, 3], "c": {"a": "b"}}')

if __name__ == '__main__':
    test_jsonify()
    test_case_0()

# Generated at 2022-06-24 21:02:16.875911
# Unit test for function to_bytes
def test_to_bytes():
    d = {'[' + (to_bytes('')) + ']': 'test'}
    var_0 = to_bytes(d)


# Generated at 2022-06-24 21:02:18.190359
# Unit test for function to_native
def test_to_native():
    dict_0 = {}
    print(to_bytes(dict_0))


# Generated at 2022-06-24 21:02:20.636363
# Unit test for function to_bytes
def test_to_bytes():
    dict_0 = {}
    var_0 = to_bytes(dict_0)


# Generated at 2022-06-24 21:02:23.211479
# Unit test for function to_bytes
def test_to_bytes():
    dict_0 = {}
    assert isinstance(dict_0, dict)
    var_0 = to_bytes(dict_0)
    assert isinstance(var_0, binary_type)


# Generated at 2022-06-24 21:02:24.896691
# Unit test for function jsonify
def test_jsonify():
    res = jsonify("a")
    # assert(res == '"a"')


# Generated at 2022-06-24 21:02:28.341127
# Unit test for function jsonify
def test_jsonify():
    dict_0 = {}
    dict_0['test'] = 'test'
    dict_0['test_0'] = 'test_0'
    var_0 = jsonify(dict_0)
    return None


# Generated at 2022-06-24 21:02:34.071504
# Unit test for function jsonify
def test_jsonify():
    dict_0 = {}
    jsonify(dict_0)



# Generated at 2022-06-24 21:02:45.158067
# Unit test for function jsonify
def test_jsonify():
    data = {"b": u"unicode", "a": "ascii"}
    assert jsonify(data) == '{"a": "ascii", "b": "unicode"}'

    data = {"a": {"a": {"a": "ascii"}, "b": u"unicode"}}
    assert jsonify(data) == '{"a": {"a": {"a": "ascii"}, "b": "unicode"}}'

    data = [{"a": {"a": {"a": "ascii"}, "b": u"unicode"}}]
    assert jsonify(data) == '[{"a": {"a": {"a": "ascii"}, "b": "unicode"}}]'

    data = {"b": u"\u2713", "a": "ascii"}

# Generated at 2022-06-24 21:02:55.100696
# Unit test for function to_bytes
def test_to_bytes():
    """Check that the to_bytes() function works as expected"""
    assert to_bytes('foo', nonstring='empty') == b'foo'
    assert to_bytes(b'foo', nonstring='empty') == b'foo'
    assert to_bytes(u'foo', nonstring='empty') == b'foo'

    assert to_bytes('foo', nonstring='simplerepr') == b"'foo'"
    assert to_bytes(b'foo', nonstring='simplerepr') == b"'foo'"
    assert to_bytes(u'foo', nonstring='simplerepr') == b"'foo'"

    assert to_bytes('foo', nonstring='passthru') == 'foo'
    assert to_bytes(b'foo', nonstring='passthru') == b'foo'

# Generated at 2022-06-24 21:02:57.708899
# Unit test for function jsonify
def test_jsonify():
    dict_0 = {}
    dict_0['a'] = 'test'
    dict_0['b'] = 'test'
    var_0 = jsonify(dict_0)


# Generated at 2022-06-24 21:03:01.710190
# Unit test for function jsonify
def test_jsonify():
    # Locate the data file and read in the JSON data
    data_file = 'data/input/jsonify.json'
    with open(data_file, 'r') as fp:
        data = json.load(fp)['data']

    result = jsonify(data)
    assert(isinstance(result, str))


# Generated at 2022-06-24 21:03:03.711383
# Unit test for function to_native
def test_to_native():
    assert to_bytes('foo', 'utf8') == b"foo"
    assert to_bytes(123, 'utf8') == b"123"


# Generated at 2022-06-24 21:03:05.101444
# Unit test for function to_bytes
def test_to_bytes():
    obj = {}
    assert isinstance(to_bytes(obj), binary_type)


# Generated at 2022-06-24 21:03:12.996885
# Unit test for function to_native
def test_to_native():
    dict_0 = {}
    var_0 = bool(to_bytes(dict_0))
    var_1 = bool(to_bytes(dict_0, errors="replace"))
    var_2 = bool(to_bytes(dict_0, errors="surrogate_or_strict"))
    var_3 = bool(to_bytes(dict_0, errors="surrogate_or_replace"))
    var_4 = bool(to_bytes(dict_0, errors="surrogate_then_replace"))



# Generated at 2022-06-24 21:03:17.049781
# Unit test for function to_bytes
def test_to_bytes():
    try:
        if HAS_SURROGATEESCAPE:
            print ('Surrogate Escape error handler is available. ')
    except LookupError as err:
        print ('Surrogate Escape error handler is not available. ')
        #assert False # we should never reach this
        test_case_0()

if __name__ == "__main__":
    test_to_bytes()

# Generated at 2022-06-24 21:03:26.568513
# Unit test for function to_native
def test_to_native():
    str_0 = to_native(None, 'utf-8')
    str_1 = to_native(None, 'utf-8', errors='replace')
    str_2 = to_native(None, 'utf-8', errors='ignore')
    str_3 = to_native(None, 'utf-8', errors='strict')
    str_4 = to_native(None, 'utf-8', errors='surrogate_then_replace')
    str_5 = to_native(None, 'utf-8', errors='surrogate_or_strict')
    str_6 = to_native(None, 'utf-8', errors='surrogate_or_replace')
    str_7 = to_native(None, 'utf-8', nonstring='simplerepr')

# Generated at 2022-06-24 21:03:43.244391
# Unit test for function to_bytes
def test_to_bytes():
    if PY3:
        assert to_bytes(u'text', 'ascii') == b'text'
        assert to_bytes(u'text', 'utf8') == b'text'
        assert to_bytes(u'text') == b'text'
        assert to_bytes(u'test\u1234') == b'test\xe1\x88\xb4'
        assert to_bytes(u'test\u1234', 'utf8', 'surrogateescape') == b'test\xed\xa0\x81\xed\xb4\xb4'
        assert to_bytes(b'bytes') == b'bytes'
        assert to_bytes(b'bytes', nonstring='passthru') == b'bytes'
        assert to_bytes(b'bytes', nonstring='simplerepr') == b

# Generated at 2022-06-24 21:03:47.729867
# Unit test for function jsonify
def test_jsonify():
    assert True


# Generated at 2022-06-24 21:03:59.093545
# Unit test for function jsonify
def test_jsonify():

    class Foo(object):
        def __init__(self, bar):
            self.bar = bar

        def __repr__(self):
            return "Foo(%r)" % self.bar

    # Expected values
    exp_result_0 = '{}'
    exp_result_1 = '{"a": "b"}'
    exp_result_2 = '{"a": 1}'
    exp_result_3 = '{"a": [1, 2, 3]}'
    exp_result_4 = '{"a": {"b": "c"}}'
    exp_result_5 = '["test", 123]'
    exp_result_6 = '[{"a": "b"}, 1]'
    exp_result_7 = '[{"a": "b", "c": "d"}, 1]'

# Generated at 2022-06-24 21:04:00.747930
# Unit test for function jsonify
def test_jsonify():
    dict_0 = {}
    _json_encode_fallback(dict_0)
    jsonify(dict_0)



# Generated at 2022-06-24 21:04:03.066180
# Unit test for function to_native
def test_to_native():
    obj = {}
    assert to_native(obj) == '{}', 'Test failed for to_native(obj) = {}'


# Generated at 2022-06-24 21:04:07.007606
# Unit test for function jsonify
def test_jsonify():
    dict_0 = {}
    var_0 = jsonify(dict_0)
    assert var_0 == dict_0


# Generated at 2022-06-24 21:04:16.167157
# Unit test for function to_native
def test_to_native():
    # Test cases for function "to_native"
    dict_0 = {}
    var_0 = to_bytes(dict_0)
    dict_1 = dict()
    var_1 = to_bytes(dict_1)
    dict_2 = {'a' : 2, 'b' : 'ttt'}
    var_2 = to_bytes(dict_2)
    dict_3 = {'a' : 2, 'b' : 12}
    var_3 = to_bytes(dict_3)
    dict_4 = {'a' : [1, 2, 3], 'b' : {'a' : '1', 'b' : '2'}}
    var_4 = to_bytes(dict_4)

# Generated at 2022-06-24 21:04:21.684365
# Unit test for function to_bytes
def test_to_bytes():
    # replacement for input
    to_bytes(1)


# Generated at 2022-06-24 21:04:29.921202
# Unit test for function to_bytes
def test_to_bytes():
    output = b''
    assert to_bytes(dict()) == output

    output = '{"a": "b"}'
    assert to_bytes(dict({u'a': u'b'})) == output

    output = '{"a": "b"}'
    assert to_bytes(dict({u'a': u'b'})) == output

    output = '{"a": "b"}'
    assert to_bytes(dict({u'a': u'b'})) == output

    output = '{"a": "b"}'
    assert to_bytes(dict({u'a': u'b'})) == output

    output = '{"a": "b"}'
    assert to_bytes(dict({u'a': u'b'})) == output

    # Invalid error parameter, should raise TypeError
    error_raised = False

# Generated at 2022-06-24 21:04:40.212589
# Unit test for function to_native
def test_to_native():
    dict_0 = {'key_0':'value_0', 'key_1':'value_1'}
    dict_1 = {'key_0':'value_0', 'key_1':'value_1', 'key_2':{'key_0':'value_0', 'key_1':'value_1'}}
    var_0 = to_native(dict_0)
    var_1 = to_native(dict_1)
    var_2 = to_text(var_0)
    var_3 = to_text(var_1)
    print(var_2)
    print(var_3)

# test_to_native()
test_case_0()

# Generated at 2022-06-24 21:04:49.853294
# Unit test for function jsonify
def test_jsonify():
    # Input data for function
    data = {u'a': u'\u00f8'}

    # Expected output from function
    expected = u'{"a": "\\u00f8"}'

    # Call the function
    result = jsonify(data)

    # Print output for function
    print("Result for function 'jsonify':")
    print(result)

    # Print expected output for function
    print("Expected result for function 'jsonify':")
    print(expected)

    # Determine if output from function matches expected output
    assert result == expected

if __name__ == "__main__":
    test_jsonify()
    test_case_0()

# Generated at 2022-06-24 21:04:56.776453
# Unit test for function to_native
def test_to_native():
    var_0 = {}
    var_1 = to_native(var_0)
    var_2 = to_native(var_0)
    var_3 = to_native(var_0)
    var_4 = to_native(var_0)
    var_5 = to_native(var_0)
    var_6 = to_native(var_0)


# Generated at 2022-06-24 21:05:07.449334
# Unit test for function to_native
def test_to_native():
    content = b'{ "hello": "world" }'
    parsed = json.loads(content)
    assert(parsed == {'hello': 'world'})

    assert (to_native(b'{ "hello": "world" }') == {'hello': 'world'})
    assert (to_native({'hello': 'world'}) == {'hello': 'world'})
    assert (to_native(b'hello') == 'hello')

    assert(to_native(b'\xff') == u'\ufffd')
    assert(to_native(u'\xff') == u'\ufffd')
    with pytest.raises(TypeError):
        assert(to_native(b'\xff', errors='surrogate_then_replace') == u'\ufffd')

# Generated at 2022-06-24 21:05:17.041849
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    # Test the following calls to function 'to_native'
    var_0 = to_native('kYXf')
    var_1 = to_native('\u0064\u0061\u0074\u0061\u002e\u006a\u0073\u006f\u006e')
    var_2 = to_native({})
    var_3 = to_native(datetime.datetime.utcnow())
    var_4 = to_native(2)
    var_5 = to_native(b'\xe3\x82\xb3\xe3\x83\x96')
    var_6 = to_native('\u30b3\u30d6')
    var_7 = to_native(None)
   

# Generated at 2022-06-24 21:05:18.605487
# Unit test for function to_native
def test_to_native():
    dict_0 = {}
    var_0 = to_native(dict_0)


# Generated at 2022-06-24 21:05:29.405010
# Unit test for function to_bytes
def test_to_bytes():
    # this test is executed only in python3
    if PY3:
        b = to_bytes(u'unicode')
        assert isinstance(b, binary_type)

        b = to_bytes(u'unicode', encoding='latin-1')
        assert isinstance(b, binary_type)

        b = to_bytes(b'bytes')
        assert isinstance(b, binary_type)

        # this does not raise an exception
        b = to_bytes(1)

        b = to_bytes(1, nonstring='passthru')
        assert b == 1

        b = to_bytes(1, nonstring='strict')
        assert False

        b = to_bytes(1, nonstring='empty')
        assert isinstance(b, binary_type) and len(b) == 0

        b = to

# Generated at 2022-06-24 21:05:31.538675
# Unit test for function jsonify
def test_jsonify():
    dict_0 = {'a': 'b'}
    result = jsonify(dict_0)
    assert isinstance(result, to_native(str))



# Generated at 2022-06-24 21:05:35.516546
# Unit test for function to_bytes
def test_to_bytes():
    dict_0 = {}
    dict_0["ssv_0"] = "test"
    dict_0["test1"] = "test2"
    str_0 = to_bytes(dict_0)
    print(str_0)


# Generated at 2022-06-24 21:05:44.948251
# Unit test for function to_native

# Generated at 2022-06-24 21:05:48.855012
# Unit test for function to_native
def test_to_native():
    assert to_native("abc") == "abc"
    if PY3:
        assert to_native(u"abc") == "abc"
        assert to_native("abc".encode("utf-8")) == "abc"
    else:
        assert to_native(u"abc") == u"abc"
        assert to_native("abc".encode("utf-8")) == u"abc"


# Generated at 2022-06-24 21:05:55.754432
# Unit test for function to_native
def test_to_native():
    # Test it with good int/float/dict/list, etc.
    pass


# Generated at 2022-06-24 21:05:59.440095
# Unit test for function jsonify
def test_jsonify():
    dict_0 = {u'a': u'b'}
    assert jsonify(dict_0) == json.dumps({'a': 'b'}, encoding='utf-8', default=_json_encode_fallback)

if __name__ == '__main__':
    # Unit test for function to_bytes
    # test_case_0()

    test_jsonify()

# Generated at 2022-06-24 21:06:01.270169
# Unit test for function to_bytes
def test_to_bytes():
    try:
        to_bytes('')
        assert True
    except:
        assert False



# Generated at 2022-06-24 21:06:12.166131
# Unit test for function to_bytes
def test_to_bytes():
    assert isinstance(to_bytes(""), binary_type)
    assert isinstance(to_bytes("", nonstring="passthru"), text_type)
    assert isinstance(to_bytes("", nonstring='simplerepr'), binary_type)
    assert isinstance(to_bytes("", nonstring='empty'), binary_type)
    assert isinstance(to_bytes("", nonstring='strict'), binary_type)
    try:
        to_bytes("", nonstring='invalid')
        assert False
    except TypeError:
        pass
    assert isinstance(to_bytes("", errors='strict'), binary_type)
    assert isinstance(to_bytes("", errors='replace'), binary_type)
    assert isinstance(to_bytes("", errors='ignore'), binary_type)

# Generated at 2022-06-24 21:06:18.737404
# Unit test for function jsonify
def test_jsonify():
    dict_0 = {
        "msg": "test",
        "status": "done"
    }
    assert jsonify(dict_0, separators=(",", ":")) == '{"msg":"test","status":"done"}'

if __name__ == "__main__":
    # Unit test for function test_case_0
    test_case_0()
    # Unit test for function jsonify
    test_jsonify()