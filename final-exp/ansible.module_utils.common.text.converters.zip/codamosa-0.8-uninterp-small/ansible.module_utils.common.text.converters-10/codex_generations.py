

# Generated at 2022-06-24 20:56:33.422281
# Unit test for function to_bytes
def test_to_bytes():

    str_0 = '  executable location = %s'

    var_0 = to_bytes(str_0)
    assert var_0 == '  executable location = %s'
    assert type(var_0) == str

    str_1 = '  no file matched pattern: %s'
    var_1 = to_bytes(str_1, 'utf-8', 'surrogate_or_replace')
    assert var_1 == '  no file matched pattern: %s'
    assert type(var_1) == str

    str_2 = '  %s did not match %s'
    var_2 = to_bytes(str_2, 'utf-8', 'surrogate_or_replace', 'passthru')
    assert var_2 == '  %s did not match %s'

# Generated at 2022-06-24 20:56:35.862850
# Unit test for function jsonify
def test_jsonify():
    data = dict(a=u'foo', b=u'bar')
    assert jsonify(data) == "'a': 'foo', 'b': 'bar'"
    assert jsonify(data, sort_keys=True) == "'a': 'foo', 'b': 'bar'"



# Generated at 2022-06-24 20:56:37.022391
# Unit test for function to_native
def test_to_native():
    assert isinstance(to_native(u'this is a test'), binary_type)



# Generated at 2022-06-24 20:56:38.679711
# Unit test for function jsonify
def test_jsonify():
    data = {'host': 'foo', 'port': None}
    result = jsonify(data)
    assert result == "{'host': 'foo', 'port': null}"


# Generated at 2022-06-24 20:56:44.221349
# Unit test for function to_native
def test_to_native():
    # Testing a string
    str_0 = '  executable location = %s'
    var_0 = container_to_native(str_0)
    assert type(var_0) == str

    # Testing a list
    list_0 = ['  executable location = %s', None]
    var_1 = container_to_native(list_0)
    assert type(var_1) == list
    assert type(var_1[0]) == str
    assert var_1[1] == None

    # Testing a dict
    dict_0 = {'executable': 'executable location = %s', 'value': None}
    var_2 = container_to_native(dict_0)
    assert type(var_2) == dict
    assert type(var_2['executable']) == str

# Generated at 2022-06-24 20:56:53.448250
# Unit test for function jsonify
def test_jsonify():
    # Pass str_0 as parameter
    data = str_0
    expected = json.dumps(str_0, ensure_ascii=True)
    actual = jsonify(data, ensure_ascii=True)
    if expected != actual:
        raise AssertionError(
            "Expected: %s\nActual: %s" % (expected, actual))
    # Pass var_0 as parameter
    data = var_0
    expected = json.dumps(var_0, ensure_ascii=True)
    actual = jsonify(data, ensure_ascii=True)
    if expected != actual:
        raise AssertionError(
            "Expected: %s\nActual: %s" % (expected, actual))

if __name__ == '__main__':
    import sys
   

# Generated at 2022-06-24 20:57:04.935510
# Unit test for function to_native
def test_to_native():
    # Test with invalid type for 'arg_0' (TypeError)
    with pytest.raises(TypeError):
        to_native(256)
    # Test with invalid type for 'arg_0' (TypeError)
    with pytest.raises(TypeError):
        to_native({})
    # Test with invalid type for 'arg_0' (TypeError)
    with pytest.raises(TypeError):
        to_native((1, 2))
    # Test with invalid type for 'arg_1' (TypeError)
    with pytest.raises(TypeError):
        to_native('str', 256)
    # Test with invalid type for 'arg_1' (TypeError)
    with pytest.raises(TypeError):
        to_native('str', {})
    # Test with invalid type for 'arg

# Generated at 2022-06-24 20:57:06.396339
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == '{}'


# Generated at 2022-06-24 20:57:10.573089
# Unit test for function to_native
def test_to_native():
    param = bytes_to_utf8_string('stream=' + 'CRC32C')
    expected = 'stream=' + 'CRC32C'
    actual = to_native(param)
    assert actual == expected


# Generated at 2022-06-24 20:57:13.287543
# Unit test for function jsonify
def test_jsonify():
    """
    Call function jsonify with valid test data
    """

    data = {
        'foo': 'bar',
        'spam': 'eggs'
    }
    jsonify(data)



# Generated at 2022-06-24 20:57:21.520274
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = '  executable location = %s'
    str_1 = 'test_pipe_txt'
    var_0 = container_to_bytes(str_0)
    var_1 = to_bytes(str_1)

# Generated at 2022-06-24 20:57:32.583881
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = '  executable location = %s'
    var_0 = to_bytes(str_0)
    var_1 = to_bytes(var_0, 'utf-8', 'surrogate_then_replace', 'simplerepr')
    var_2 = to_bytes(var_0, 'utf-8', 'surrogate_then_replace', 'empty')
    var_3 = to_bytes(var_0, 'utf-8', 'surrogate_then_replace', 'passthru')
    var_4 = to_bytes(var_0, 'utf-8', 'surrogate_then_replace', 'strict')
    var_5 = to_bytes(var_0, encoding='utf-8')

# Generated at 2022-06-24 20:57:41.690713
# Unit test for function to_native
def test_to_native():
    str_0 = '  executable location = %s'
    var_1 = to_native(str_0)
    str_1 = '  executable location = {}'
    str_2 = '  executable location = %s'

    # Test for known case 1 when using Python 2.x and the error_handlers parameter
    # is not set.
    str_3 = str_2.decode('utf-8', 'strict')
    if len(set([var_1, str_1, str_2, str_3])) == 1:
        assert var_1 == str_1 or var_1 == str_2 or var_1 == str_3

    # Test for known case 2 when using Python 2.x and the error_handlers parameter
    # is set.

# Generated at 2022-06-24 20:57:50.905704
# Unit test for function to_native
def test_to_native():
    assert to_native('foo') == "foo", 'Failed assert: to_native'
    assert to_native(u'foo') == u"foo", 'Failed assert: to_native'
    assert to_native(b'foo') == b"foo", 'Failed assert: to_native'
    assert to_native(b'foo', errors='surrogate_then_replace') == u"foo", 'Failed assert: to_native'
    assert to_native(u'foo', errors='surrogate_then_replace') == u"foo", 'Failed assert: to_native'


# Generated at 2022-06-24 20:57:57.685825
# Unit test for function to_native
def test_to_native():
    assert to_native(b'f\xc3\xb4\xc3\xb4\xc3\xab') == 'f\xf4\xf4\xeb'
    #assert to_native("fôôé") == "fôôé"
    assert to_native(b'\xc3\x80\xc3\xa9') == '\xc3\x80\xc3\xa9'
    assert to_native("\xc3\x80\xc3\xa9") == "\xc3\x80\xc3\xa9"
    assert to_native(b'\xc3\x80\xc3\xa9', errors='surrogate_or_strict') == '\xc3\x80\xc3\xa9'

# Generated at 2022-06-24 20:57:59.011621
# Unit test for function to_native
def test_to_native():
    assert to_native({'text': 'Hello'}) == {'text': 'Hello'}, 'Failed to_native'



# Generated at 2022-06-24 20:58:02.747542
# Unit test for function to_native
def test_to_native():
    # Try to work with a text string
    str_0 = 'asdf'
    var_0 = container_to_native(str_0)

    # Try to work with a binary string
    bytes_0 = b'asdf'
    var_1 = container_to_native(bytes_0)

    # Try to work with a non string
    arg_0 = {}
    var_2 = container_to_native(arg_0)



# Generated at 2022-06-24 20:58:13.398812
# Unit test for function to_native
def test_to_native():
    # Get the source of the module which we will want to test
    source = get_source(to_native)

    # Compile the source of the module that we are intending to test
    # This will detect errors if the code does not parse.
    code_to_test = compile(source, 'ansible/module_utils/_text', 'exec')

    # Run the code in a namespace.
    # This will validate that it is valid Python code.
    # If the code does not parse, then this will error.
    exec(code_to_test, globals(), locals())

    # Perform the tests
    assert to_native(None) == None
    assert to_native(u'text') == u'text'
    assert to_native(b'bytes') == u'bytes'
    assert to_native(1) == 1
    assert to_

# Generated at 2022-06-24 20:58:19.071271
# Unit test for function jsonify
def test_jsonify():
    data = {'k1': u'abc', 'k2': [u'abc', u'abcd']}
    kwargs = {'ensure_ascii': True}
    ret = jsonify(data, **kwargs)


# Generated at 2022-06-24 20:58:26.559717
# Unit test for function jsonify
def test_jsonify():
    data = {
        "test_array": [1, 2, 3],
        "test_dict": {
            "test_byte_string": b"test_bytes_value",
            "test_unicode": u"test_unicode_value",
            "test_int": 5
        }
    }

    if PY3:
        # On Python 3, JSON encoder only handle unicode.
        # Force convert all values to unicode.
        data = container_to_text(data)

    expected = '{"test_array": [1, 2, 3], "test_dict": {"test_byte_string": "test_bytes_value", "test_unicode": "test_unicode_value", "test_int": 5}}'
    result = jsonify(data)
    # Check if the resulting JSON string is equal to the

# Generated at 2022-06-24 20:58:38.306226
# Unit test for function jsonify
def test_jsonify():
    dict_0 = dict()
    dict_0['c'] = 'e'
    dict_0['b'] = 'd'
    dict_0['a'] = 'c'
    dict_0['d'] = 'f'
    dict_0['e'] = 'g'
    dict_0['f'] = 'h'
    dict_0['g'] = 'i'
    assert jsonify(dict_0) == '{"a": "c", "c": "e", "b": "d", "e": "g", "d": "f", "g": "i", "f": "h"}'



# Generated at 2022-06-24 20:58:39.681216
# Unit test for function jsonify
def test_jsonify():
    data = '{"test": "test"}'
    result = jsonify(data)
    assert result == data



# Generated at 2022-06-24 20:58:48.076309
# Unit test for function to_native
def test_to_native():
    str_1 = 'moved'
    str_2 = 'to'
    str_3 = 'here'

    result = to_native(str_1, str_2, str_3)
    assert(isinstance(result, text_type))

    str_4 = 'changed'
    str_5 = 'from'
    str_6 = 'here'

    result = to_native(str_4, str_5, str_6)
    assert(isinstance(result, text_type))


# Generated at 2022-06-24 20:58:58.728257
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = '  executable location = %s'
    str_1 = '%s = %s'
    str_2 = 'this is a %s %s'
    dict_0 = {u'pip': {u'version': u'10.0.1', u'location': u'c:\\python27\\lib\\site-packages\\pip'}}
    dict_1 = {u'python': {u'version': u'2.7.14', u'location': u'c:\\python27\\python.exe'}}

# Generated at 2022-06-24 20:59:02.468210
# Unit test for function to_native
def test_to_native():
    str_1 = '  executable location = %s'
    str_2 = '  executable location = %s'
    var_1 = to_native(str_1, 'utf-8', 'surrogate_or_strict')
    assert (var_1 == str_2)


# Generated at 2022-06-24 20:59:06.425245
# Unit test for function jsonify
def test_jsonify():
    # FIXME: This test is failing with new version of simple json.  Disabled for now.
    if 'ANSIBLE_TEST_JSONIFY' in os.environ:
        var_0 = dict()
        var_0['foo'] = set()
        var_0['foo'].add(1)
        var_0['foo'].add(2)
        var_0['foo'].add(3)
        var_1 = jsonify(var_0)
        assert var_1 == '{"foo": [1, 2, 3]}'

# Generated at 2022-06-24 20:59:08.492522
# Unit test for function to_native
def test_to_native():
    pass


# Generated at 2022-06-24 20:59:19.658839
# Unit test for function to_bytes
def test_to_bytes():
    var_0 = to_bytes('  %s = %s')
    assert var_0 == b'  %s = %s'

    var_0 = to_bytes('  %s = %s', nonstring='strict')
    assert var_0 == b'  %s = %s'

    var_0 = to_bytes('  %s = %s', nonstring='empty')
    assert var_0 == b''

    var_0 = to_bytes('  %s = %s', nonstring='passthru')
    assert var_0 == '  %s = %s'

    var_0 = to_bytes('  %s = %s', nonstring='simplerepr')
    assert var_0 == b'  %s = %s'


# Generated at 2022-06-24 20:59:30.101593
# Unit test for function to_native
def test_to_native():
    print('Running unit tests for function to_native')
    res = to_native('foo')
    print('Test #1 result: {}'.format(res))
    if res != 'foo':
        raise AssertionError('Test #1 expected: foo, actual: {}'.format(res))

    res = to_native(u'foo')
    print('Test #2 result: {}'.format(res))
    if res != 'foo':
        raise AssertionError('Test #2 expected: foo, actual: {}'.format(res))

    res = to_native(b'foo')
    print('Test #3 result: {}'.format(res))
    if res != u'foo':
        raise AssertionError('Test #3 expected: foo, actual: {}'.format(res))

    res = to_native(u'\xa9')

# Generated at 2022-06-24 20:59:35.888983
# Unit test for function to_bytes
def test_to_bytes():
    # Run an assertion check
    # assert to_bytes('foo') == b'foo'
    print(to_bytes('foo'))
    print(to_bytes(u'\xf1', errors='surrogate_or_strict'))
    print(to_bytes(b'foo'))
    print(to_bytes(1, nonstring='passthru'))
    print(to_bytes(1, nonstring='strict'))

# Generated at 2022-06-24 20:59:46.915869
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"ansible": ["all", "your", "base"]}) == '{"ansible": ["all", "your", "base"]}'



# Generated at 2022-06-24 20:59:54.119777
# Unit test for function to_native
def test_to_native():
    try:
        # Test normal case
        print('Testing normal case...')
        str_1 = 'abc'
        var_1 = to_native(str_1)
        print('Success!')
    except Exception as e:
        print('Failure!')
        print(e)
    try:
        # Test normal case
        print('Testing normal case...')
        str_1 = 'abc'
        var_1 = to_native(str_1, True)
        print('Success!')
    except Exception as e:
        print('Failure!')
        print(e)

# Generated at 2022-06-24 20:59:55.309386
# Unit test for function to_native
def test_to_native():

    pass


# Generated at 2022-06-24 21:00:05.880088
# Unit test for function jsonify

# Generated at 2022-06-24 21:00:15.195285
# Unit test for function jsonify

# Generated at 2022-06-24 21:00:20.701876
# Unit test for function jsonify
def test_jsonify():
    # No paramters
    # No return value

    return


# Generated at 2022-06-24 21:00:25.605048
# Unit test for function to_native
def test_to_native():
    # noqa: F821 pylint:disable=undefined-variable

    str_0 = '  executable location = %s'
    var_0 = to_native(str_0)
    print(var_0)

    var_1 = to_native(var_0)
    print(var_1)

    str_1 = '  executable location = %s'
    var_2 = to_native(str_1)
    print(var_2)

    var_3 = to_native(var_2)
    print(var_3)


# Generated at 2022-06-24 21:00:27.087342
# Unit test for function to_native
def test_to_native():
    assert to_native(b'cafe') == u'cafe'


# Generated at 2022-06-24 21:00:30.875146
# Unit test for function to_native
def test_to_native():
    assert (to_native('foo') == 'foo')
    assert (to_native(b'foo') == 'foo')
    assert (to_native('foo'.encode('utf-8')) == 'foo')
    assert (to_native(u'foo') == 'foo')


# Generated at 2022-06-24 21:00:34.719099
# Unit test for function to_bytes
def test_to_bytes():

    # Test with a byte string
    assert to_bytes(str(b'123')) == b'123'

    # Test with a text string
    assert to_bytes(str(u'123')) == b'123'

    # Test with a non-string
    assert to_bytes(123) == b'123'

# Generated at 2022-06-24 21:00:46.146298
# Unit test for function jsonify
def test_jsonify():
    if PY3:
        a = {1: "some text"}
        json_data = jsonify(a)
        assert isinstance(json_data, str)
        b = json.loads(json_data)
        assert a == b
    else:
        a = {1: "some text"}
        json_data = jsonify(a)
        assert isinstance(json_data, str)
        b = json.loads(json_data)
        assert a == b


# Generated at 2022-06-24 21:00:52.241640
# Unit test for function to_bytes
def test_to_bytes():
    def do_test(str_0):
        # function do_test(str_0 is defined
        #   str_0 is assigned str_0
        var_0 = to_bytes(str_0)
        # var_0 is assigned to_bytes(str_0)
        return var_0
        # return var_0
    # Initialize str_0, var_0
    str_0 = '  executable location = %s'
    var_0 = do_test(str_0)
    return var_0
    # return var_0


# Generated at 2022-06-24 21:00:55.043957
# Unit test for function jsonify
def test_jsonify():
    data = '{"foo": "bar"}'
    assert jsonify(data) == '"{\\"foo\\": \\"bar\\"}"'


# Generated at 2022-06-24 21:00:59.579808
# Unit test for function jsonify
def test_jsonify():
    data = {'key': [u'value1', u'value2', u'value3']}
    assert jsonify(data) == '{"key": ["value1", "value2", "value3"]}'



# Generated at 2022-06-24 21:01:07.107208
# Unit test for function to_native
def test_to_native():
    # set up mock errors
    with mock.patch('sys.platform', 'darwin'):
        mock_platform = sys.platform
    with mock.patch('__builtin__.open', mock.mock_open()) as m:
        handle = m.return_value.__enter__.return_value
        assert handle.read.return_value == '{"json": "string"}'
        assert handle.read.return_value == '{"json": "string"}'
        # run test
        result = to_native(handle.read.return_value)

    # check results
    assert result == '{"json": "string"}'



# Generated at 2022-06-24 21:01:16.114696
# Unit test for function to_bytes
def test_to_bytes():
    data = b'\xc2\xa2'
    expected = b'\xc2\xa2'

    codecs.register_error('strict', codecs.strict_errors)
    codecs.register_error('surrogate_or_strict', lambda e: 'strict' if isinstance(e, UnicodeEncodeError) else 'surrogateescape')
    codecs.register_error('surrogate_or_replace', lambda e: 'replace' if isinstance(e, UnicodeEncodeError) else 'surrogateescape')
    codecs.register_error('surrogate_then_replace', lambda e: 'surrogateescape' if isinstance(e, UnicodeEncodeError) else 'replace')

# Generated at 2022-06-24 21:01:17.914607
# Unit test for function jsonify
def test_jsonify():
    data = {}
    ret = jsonify(data, encoding='utf-8')
    assert ret == '{}'


# Generated at 2022-06-24 21:01:22.293298
# Unit test for function jsonify
def test_jsonify():
    value_0 = jsonify(dict(a=1,b=2,c=3))
    assert value_0 == u'{"a": 1, "b": 2, "c": 3}'



# Generated at 2022-06-24 21:01:23.885580
# Unit test for function to_native
def test_to_native():
    try:
        str_0 = '/usr/bin/doveadm'
        var_0 = to_native(str_0)
    except:
        raise TypeError('to_native call resulted in error')



# Generated at 2022-06-24 21:01:32.962188
# Unit test for function to_native
def test_to_native():

    # We're trying to test the case where to_native is called in a different
    # encoding from the default.  Here we set the default encoding to something
    # other than utf-8 and make sure we get the expected result when calling
    # to_native

    import sys

    # Latin1 was the default encoding for Python 2.
    sys.setdefaultencoding('latin1')

    # If this works, we'll get the utf8-encoded form of Grüß Gott!
    result_0 = to_native(u'Gr\xfc\xdfe Gott!')
    assert result_0 == 'Grüß Gott!'

    sys.setdefaultencoding('ascii')
    # If this works, we'll get the utf8-encoded form of Grüß Gott!

# Generated at 2022-06-24 21:01:41.392106
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = '  executable location = %s'
    str_1 = '  executable location = %s'
    str_2 = '  executable location = %s'
    tuple_0 = (str_2,)

    var_0 = to_bytes(str_2)



# Generated at 2022-06-24 21:01:42.131315
# Unit test for function jsonify
def test_jsonify():
    jsonify(TEST_DATA)


# Generated at 2022-06-24 21:01:42.604522
# Unit test for function to_bytes
def test_to_bytes():
    pass


# Generated at 2022-06-24 21:01:45.232293
# Unit test for function to_native
def test_to_native():
    assert to_native('test') == u'test'
    assert to_native(1) == 1


# Generated at 2022-06-24 21:01:47.278205
# Unit test for function to_native
def test_to_native():
    arg0 = 'This is a string'
    # native_str = 'This is a string'
    # assert to_native(arg0) == native_str


# Generated at 2022-06-24 21:01:55.350235
# Unit test for function to_bytes
def test_to_bytes():
    unicode_text = u"\u043f\u0440\u0438\u0432\u0435\u0442"
    byte_string = b"\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82"

    assert to_bytes(unicode_text) == byte_string
    assert to_bytes(unicode_text, nonstring='strict') == byte_string
    assert to_bytes(byte_string) == byte_string
    assert to_bytes(byte_string, nonstring='strict') == byte_string

    assert to_bytes(u"") == b""
    assert to_bytes(b"") == b""



# Generated at 2022-06-24 21:01:58.495428
# Unit test for function to_native
def test_to_native():
    assert to_native(to_text("some_string")) == "some_string"
    assert to_native("some_string") == "some_string"


# Generated at 2022-06-24 21:02:09.598032
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u0A5C') == '\xe0\xa5\x9c'
    assert to_native(u'\u0A5C', errors='surrogateescape') == '\u0a5c'
    assert to_native(u'\u0A5C'.encode('utf-16le')) == '\xe0\xa5\x9c'
    assert to_native(u'\u0A5C'.encode('utf-16le'), errors='surrogateescape') == '\u0a5c'
    assert to_native(b'\xe0\xa5\x9c') == '\xe0\xa5\x9c'

# Generated at 2022-06-24 21:02:13.683032
# Unit test for function to_native
def test_to_native():
    assert to_native('foo') == u'foo'
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'



# Generated at 2022-06-24 21:02:20.133276
# Unit test for function to_bytes
def test_to_bytes():
    """
    to_bytes fails with no arguments
    """

    var_0 = b'  executable location = %s'
    var_1 = ('  executable location = %s',)

    # Test with no args
    try:
        to_bytes()
    except:
        pass
    else:
        assert False, 'Expected exception'


# Generated at 2022-06-24 21:02:35.317599
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(None, 'ascii') == b''
    assert to_bytes(b'test', 'ascii') == b'test'
    assert to_bytes('test', 'ascii') == b'test'
    try:
        to_bytes('\u1000', 'ascii')
    except UnicodeEncodeError:
        pass
    else:
        assert False, "Should've excepted"
    assert to_bytes('\u1000', 'unicode-escape') == b'\\u1000'
    assert to_bytes('\u1000', 'utf-8') == b'\xe1\x80\x80'

    try:
        to_bytes('\u1000', 'utf-8', 'surrogate_or_strict')
    except UnicodeEncodeError:
        pass

# Generated at 2022-06-24 21:02:46.192913
# Unit test for function to_native
def test_to_native():
    ansible_module_0 = AnsibleModule(argument_spec=dict())
    ansible_module_0.exit_json(msg=b'0')
    ansible_module_1 = AnsibleModule(argument_spec=dict())
    ansible_module_1.exit_json(msg=b'1')
    ansible_module_2 = AnsibleModule(argument_spec=dict())
    ansible_module_2.exit_json(msg=b'2')
    ansible_module_3 = AnsibleModule(argument_spec=dict())
    ansible_module_3.exit_json(msg=b'3')
    ansible_module_4 = AnsibleModule(argument_spec=dict())
    ansible_module_4.exit_json(msg=b'4')
    ansible_module_5 = Ans

# Generated at 2022-06-24 21:02:54.947550
# Unit test for function to_bytes
def test_to_bytes():

    var_0 = to_bytes('', 'utf-8', None, 'simplerepr')
    assert type(var_0) == bytes
    assert var_0 == b''

    with pytest.raises(Exception):
        var_1 = to_bytes()

    var_2 = to_bytes('', 'utf-8', None, 'simplerepr')
    assert type(var_2) == bytes
    assert var_2 == b''

    var_3 = to_bytes('', 'utf-8', 'surrogate_then_replace', 'simplerepr')
    assert type(var_3) == bytes
    assert var_3 == b''

test_to_bytes()



# Generated at 2022-06-24 21:03:03.558808
# Unit test for function to_native
def test_to_native():
    # /home/build/ansible/test/units/module_utils/_text.py:116
    try:
        var_0 = '  目录位置 = %s'
        var_1 = container_to_text(var_0)
    except:
        pass

    try:
        var_1 = '  executable location = %s'
        var_2 = container_to_text(var_1)
    except UnicodeError:
        traceback.print_exc()
        pass

    var_3 = '  executable location = %s'
    var_4 = container_to_text(var_3)
    var_5 = None
    var_6 = container_to_text(var_5)

    # /home/build/ansible/test/units/module_utils/_text.py

# Generated at 2022-06-24 21:03:09.757855
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = to_bytes('  executable location = %s', 'utf-8', None, 'simplerepr')
    str_1 = to_bytes('  executable location = %s', 'utf-8', None, 'simplerepr')
    str_2 = to_bytes('  executable location = %s', 'utf-8', None, 'simplerepr')
    str_3 = to_bytes('  executable location = %s', 'utf-8', None, 'simplerepr')
    str_4 = to_bytes('  executable location = %s', 'utf-8', None, 'simplerepr')
    str_5 = to_bytes('  executable location = %s', 'utf-8', None, 'simplerepr')

# Generated at 2022-06-24 21:03:18.525348
# Unit test for function to_bytes
def test_to_bytes():
    # AssertionError: '  executable location = /usr/bin/python' != b'  executable location = /usr/bin/python'
    assert to_bytes('  executable location = /usr/bin/python') == b'  executable location = /usr/bin/python'
    # AssertionError: '  executable location = /usr/bin/python' != b'  executable location = /usr/bin/python'
    assert to_bytes('  executable location = /usr/bin/python', errors='strict') == b'  executable location = /usr/bin/python'
    # AssertionError: '  executable location = /usr/bin/python' != b'  executable location = /usr/bin/python'

# Generated at 2022-06-24 21:03:22.283515
# Unit test for function to_bytes
def test_to_bytes():
    print('Testing to_bytes')
    # Unit: default values
    # Case 0
    test_case_0()

if __name__ == '__main__':
    test_to_bytes()

# Generated at 2022-06-24 21:03:30.895388
# Unit test for function jsonify
def test_jsonify():
  statements = '{"changed": false, "invocation": {"module_args": {"group": "foo", "name": "/etc/passwd"}}, "item": "foo", "skip_reason": "Conditional result was False", "skipped": true}'
  statements_dict = json.loads(statements)
  statements_json = jsonify(statements_dict)
  print(statements_json)
  if statements_json != statements:
      raise Exception("test_jsonify failed")

# Generated at 2022-06-24 21:03:31.790525
# Unit test for function to_bytes
def test_to_bytes():
    test_case_0()


# Generated at 2022-06-24 21:03:38.533920
# Unit test for function jsonify
def test_jsonify():
    var_0 = 'this is a string'
    var_1 = []
    var_2 = {}
    var_3 = {"test": "this is a test"}
    # Test case:
    # Test case:
    # Test case:
    # Test case:
    # Test case:
    # Test case:
    # Test case:
    # Test case:
    # Test case:


# Generated at 2022-06-24 21:03:45.793409
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = '  executable location = %s'
    var_0 = to_bytes(str_0)


# Generated at 2022-06-24 21:03:48.260909
# Unit test for function to_bytes
def test_to_bytes():
    print("TEST_1")
    str_0 = '  executable location = %s'
    var_0 = container_to_bytes(str_0)
    print("OK")


if __name__ == '__main__':
    test_to_bytes()

# Generated at 2022-06-24 21:03:53.915836
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'abcd') == b'abcd'
    assert to_bytes(u'abcd') == b'abcd'
    assert to_bytes(u'\xe9', errors='surrogate_or_strict') == b'\xc3\xa9'  #decode(u'\xe9', 'utf8') == u'\u00e9'


# Generated at 2022-06-24 21:03:59.376083
# Unit test for function to_native
def test_to_native():
    str_0 = json.dumps({'a': 'A', 'c': 3.0, 'b': [2, 1]})
    var_0 = to_native(str_0)
    assert var_0 == "b'{\"a\": \"A\", \"b\": [2, 1], \"c\": 3.0}'"


# Generated at 2022-06-24 21:04:05.570254
# Unit test for function to_native
def test_to_native():
    # Test with int
    my_integer = 123
    expected = 123
    print('Expected is %s' % str(expected))
    # Test with string
    my_str = 'Hello World'
    expected = 'Hello World'
    print('Expected is %s' % str(expected))
    # Test with dict
    my_dict = dict(a=1, b=2, c=3)
    expected = { u'a': 1, u'b': 2, u'c': 3 }
    print('Expected is %s' % str(expected))
    # Test with list
    my_list = [1, 2, 3]
    expected = ['1', '2', '3']
    print('Expected is %s' % str(expected))
    # Test with tuple

# Generated at 2022-06-24 21:04:12.718808
# Unit test for function to_bytes
def test_to_bytes():
    executable_location = '/usr/bin/ansible-2.1.0.0'
    str_0 = 'executable location = %s'

    print(str_0 % executable_location)
    print(str_0 % to_bytes(executable_location))
    print(str_0 % to_bytes(to_bytes(executable_location)))
    print(str_0 % to_bytes(to_bytes(to_bytes(executable_location))))
    print(to_bytes('executable location = %s' % executable_location))



# Generated at 2022-06-24 21:04:20.445390
# Unit test for function to_native

# Generated at 2022-06-24 21:04:21.902931
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('mydata') == '"mydata"'
    assert jsonify('mydata', sort_keys=True) == '"mydata"'


# Generated at 2022-06-24 21:04:23.298562
# Unit test for function jsonify
def test_jsonify():
    data_0 = {}
    var_0 = jsonify(data_0)


# Generated at 2022-06-24 21:04:32.069601
# Unit test for function to_native
def test_to_native():
    # Check if function raises the expected exceptions
    try:
        to_native(1.2)
    except TypeError:
        pass
    else:
        raise AssertionError('ExpectedTypeError not raised')

    # Test #1 for function to_native - unicode string
    str_0 = u'ABCDEFGabcdefg12345'
    expected_1 = str_0
    actual_1 = to_native(str_0)
    if actual_1 != expected_1:
        raise AssertionError('Expected: {}, Actual: {}'.format(expected_1, actual_1))

    # Test #2 for function to_native - bytearray
    str_1 = u'ABCDEFGabcdefg12345'
    unicode_0 = str_1.encode('UTF-8')
    expected_

# Generated at 2022-06-24 21:04:39.369223
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == 'foo'
    assert to_native('foo') == 'foo'



# Generated at 2022-06-24 21:04:41.769006
# Unit test for function jsonify
def test_jsonify():
    json_data = jsonify("{'is_clean': True}")
    json_data = jsonify({"data": "{'is_clean': True}"})



# Generated at 2022-06-24 21:04:51.676635
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(True) == to_bytes('True')
    assert to_bytes(1) == to_bytes('1')
    assert to_bytes(datetime.datetime.now()) == to_bytes(datetime.datetime.now().__str__())
    assert to_bytes(Set([1, 2, 3])) == to_bytes(Set([1, 2, 3]).__str__())
    assert to_bytes('に') == b'\xe3\x81\xab'
    assert to_bytes('に', encoding='ascii') == b'\xe3\x81\xab'
    assert to_bytes('a', encoding='ascii') == b'a'

# Generated at 2022-06-24 21:05:01.564496
# Unit test for function jsonify
def test_jsonify():
    try:
        import simplejson as json
    except ImportError:
        import json

    str_0 = 'test_str'
    var_0 = container_to_bytes(str_0)
    str_1 = 'test_str'
    var_1 = container_to_bytes(str_1)
    str_2 = 'test_str'
    var_2 = container_to_bytes(str_2)
    str_3 = 'test_str'
    var_3 = container_to_bytes(str_3)
    str_4 = 'test_str'
    var_4 = container_to_bytes(str_4)
    a = {var_0: var_1, var_2: var_3, var_4: var_1}
    res = jsonify(a)

# Generated at 2022-06-24 21:05:04.767554
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\xe4\xba\xac\xe6\x88\x90', encoding='GBK') == b'\xce\xd2\xba\xce'
    assert to_bytes(u'\xe4\xba\xac\xe6\x88\x90', encoding='GB2312') == b'\xd6\xd0\xce\xc4'


# Generated at 2022-06-24 21:05:15.733488
# Unit test for function to_bytes

# Generated at 2022-06-24 21:05:22.795247
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = '  executable location = %s'
    var_0 = to_bytes(str_0)
    str_1 = '  executable location = %s'
    var_1 = to_bytes(str_1)
    str_2 = '  executable location = %s'
    var_2 = to_bytes(str_2)
    str_3 = '  executable location = %s'
    var_3 = to_bytes(str_3)
    str_4 = '  executable location = %s'
    var_4 = to_bytes(str_4)
    str_5 = '  executable location = %s'
    var_5 = to_bytes(str_5)
    str_6 = '  executable location = %s'
    var_6 = to_bytes(str_6)
    str_

# Generated at 2022-06-24 21:05:32.609538
# Unit test for function to_native

# Generated at 2022-06-24 21:05:33.670640
# Unit test for function jsonify
def test_jsonify():
    ret = jsonify({u'foo': u'bar'})
    assert ret == '{"foo": "bar"}'


# Generated at 2022-06-24 21:05:38.414482
# Unit test for function to_native
def test_to_native():
    # Creating the variables for assert
    str_0 = '  executable location = %s'
    a = assert_is_instance(to_native(str_0), str)
    raise Exception('')


# Generated at 2022-06-24 21:05:45.741536
# Unit test for function to_native
def test_to_native():
    str_0 = '  executable location = %s'
    var_0 = container_to_native(str_0)



# Generated at 2022-06-24 21:05:49.091019
# Unit test for function jsonify
def test_jsonify():
    data_0 = dict(one=datetime.datetime.now(), two=set(range(5)))
    str_0 = '{"two": [0, 1, 2, 3, 4], "one": "2017-02-15T14:40:40.631506"}'
    assert jsonify(data_0) == str_0


# Generated at 2022-06-24 21:05:53.190255
# Unit test for function jsonify
def test_jsonify():
    data = dict()
    data['json_obj'] = dict()
    data['json_obj']['key1'] = 'value1'
    data['json_obj']['key2'] = 'value2'
    data['json_obj']['key3'] = dict()
    data['json_obj']['key3']['key3_1'] = 'value3_1'

    test_jsonify_0 = jsonify(data)


# Generated at 2022-06-24 21:05:59.235742
# Unit test for function jsonify
def test_jsonify():
    # test_jsonify
    data = {
        'data': {
            'a': 1,
            'b': 'data',
            'c': [2, 3, 4],
            'd': {'a': 1, 'b': 2}
        }
    }
    actual_data = jsonify(data)
    expected_data = '{"data": {"a": 1, "b": "data", "c": [2, 3, 4], "d": {"a": 1, "b": 2}}}'
    assert actual_data == expected_data


# Generated at 2022-06-24 21:06:06.271220
# Unit test for function to_bytes
def test_to_bytes():
    if b'\xed\xa0\x88' in to_bytes('\U00010400'):
        raise AssertionError('to_bytes(text, surrogate_then_replace) should not include surrogates')
    if b'\xed\xa0\x88' not in to_bytes('\U00010400', errors='surrogate_or_replace'):
        raise AssertionError('to_bytes(text, surrogate_or_replace) should include surrogates')


# Generated at 2022-06-24 21:06:11.601249
# Unit test for function to_native
def test_to_native():
    assert to_native(1) == 1
    assert isinstance(to_native(1), int)
    assert to_native('1') == '1'
    assert isinstance(to_native('1'), str)
    assert to_native(b'1') == '1'
    assert isinstance(to_native(b'1'), str)


# Generated at 2022-06-24 21:06:19.033493
# Unit test for function to_native
def test_to_native():
    assert to_native('abc', 'utf-8') == 'abc'
    assert to_native('abc', 'ascii') == 'abc'
    assert to_native(b'abc', 'utf-8') == 'abc'
    assert to_native(b'abc', 'ascii') == 'abc'
    assert to_native(u'abc', 'utf-8') == 'abc'
    assert to_native(u'abc', 'ascii') == 'abc'
