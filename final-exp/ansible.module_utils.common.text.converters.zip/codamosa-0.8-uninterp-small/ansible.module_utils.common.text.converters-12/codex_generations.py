

# Generated at 2022-06-24 20:56:27.333689
# Unit test for function jsonify
def test_jsonify():
    # Encoding error should be thrown
    assert jsonify(5002.564)


# Generated at 2022-06-24 20:56:29.951370
# Unit test for function to_native
def test_to_native():
    x = b'\xe4\xe4\xe4'.decode('latin1')
    assert u'test: \xe4\xe4\xe4' == to_native(u'test: %s' % x)



# Generated at 2022-06-24 20:56:37.179899
# Unit test for function to_bytes
def test_to_bytes():
    # Should return unicode string
    string_0 = b'\xb5\xb4\xbao\x10\x9d\xb1l\xda\x1e\xe2\x7f\x14'
    string_1 = to_bytes(string_0, 'utf-8', errors='surrogate_or_replace')

    # Should return unicode string
    string_0 = b'\x87\x90\xa6\xbb\xc1k\xaa\x06\x96\xdb\xbd\x99'
    string_1 = to_bytes(string_0, 'utf-8', errors='surrogate_or_replace')

    # Should return unicode string

# Generated at 2022-06-24 20:56:38.353977
# Unit test for function jsonify
def test_jsonify():
    a = {1:2}
    assert jsonify(a) == '{"1": 2}'


# Generated at 2022-06-24 20:56:43.694779
# Unit test for function jsonify
def test_jsonify():
    # Create a dictionary
    var_0 = 1
    var_1 = 2
    var_2 = 3
    var_3 = "foo"
    var_4 = "bar"
    var_5 = {var_3: var_0, var_4: var_1}
    if PY3:
        assert jsonify(var_5) == json.dumps(var_5, default=_json_encode_fallback)
    else:
        expected_result = json.dumps({var_3.encode("utf-8"): var_0, var_4.encode("utf-8"): var_1}, default=_json_encode_fallback)
        assert jsonify(var_5) == expected_result
    # Create a list

# Generated at 2022-06-24 20:56:52.472562
# Unit test for function to_native
def test_to_native():
    text_0 = to_native('\x81\x07E\x98\x8c?C\xea\xcc\xc9\\.\\r\x1e', None, 'surrogate_or_strict')
    text_1 = to_native(False)
    dict_0 = dict()
    dict_0.update({'key_0': text_0, 'key_1': text_1})
    bytes_0 = b'\x99\x98\x8f\xae\xb0n<\xabP\x8e\xbd\x0e'
    str_0 = to_native(bytes_0, 'ascii', 'surrogate_or_strict', 'passthru')
    list_0 = list()
    list_0.append(dict_0)
   

# Generated at 2022-06-24 20:56:59.842582
# Unit test for function to_native
def test_to_native():
    float_0 = 5002.564
    bytes_0 = b'.\xe3\x8c\xd9\x10\xe5\xc2-g\r'
    var_0 = container_to_text(float_0, bytes_0)
    var_1 = to_native(var_0)
    assert var_1 == var_0


# Generated at 2022-06-24 20:57:07.331430
# Unit test for function jsonify
def test_jsonify():
    # Populate data
    data = {}
    data['a'] = 0
    data['b'] = 'abc'
    data['c'] = [1,2,3,4]
    data['d'] = None
    data['e'] = 'e'
    data['f'] = {'a': 1, 'b': 2}
    # Populate expected
    expected = {}
    expected['a'] = 0
    expected['b'] = 'abc'
    expected['c'] = [1,2,3,4]
    expected['d'] = None
    expected['e'] = 'e'
    expected['f'] = {'a': 1, 'b': 2}
    # Call function
    ret = jsonify(data)
    # Check if equals
    assert(expected == ret)


# Generated at 2022-06-24 20:57:12.055031
# Unit test for function to_native
def test_to_native():
    # test_0
    float_0 = 5002.564
    bytes_0 = b'.\xe3\x8c\xd9\x10\xe5\xc2-g\r'
    var_0 = container_to_text(float_0, bytes_0)


# Generated at 2022-06-24 20:57:15.489348
# Unit test for function to_native
def test_to_native():
    float_0 = 5002.564
    bytes_0 = b'.\xe3\x8c\xd9\x10\xe5\xc2-g\r'
    var_0 = container_to_text(float_0, bytes_0)


# Generated at 2022-06-24 20:57:42.242096
# Unit test for function to_bytes
def test_to_bytes():
    print()
    print("BEGIN TESTS FOR TO_BYTES")
    # Init
    string_0 = "utf-8"
    string_1 = "non-ASCII: é"
    
    # TypeError: surrogates not allowed (only in python2 without a backported unicode literal)
    # Bytes Literal
    bytes_0 = b'\x88\x80\x00\x00'
    bytes_1 = b'\x00\x00\x80\x88'
    bytes_2 = b'\x80\x88\x00\x00'
    bytes_3 = b'\x00\x00\x88\x80'
    bytes_4 = b'\x88\x88\x00\x00'

    # Bytes from utf-16
    bytes_

# Generated at 2022-06-24 20:57:45.849699
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    assert to_native('hello world') == u'hello world'
    assert to_native(u'hello world') == u'hello world'
    assert to_native('hello world'.encode('utf-8')) == u'hello world'


# Generated at 2022-06-24 20:57:50.680741
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Test function for function jsonify
if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-24 20:57:56.026606
# Unit test for function to_bytes
def test_to_bytes():
    try:
        codecs.lookup_error('surrogateescape')
        HAS_SURROGATEESCAPE = True
    except LookupError:
        HAS_SURROGATEESCAPE = False

    # Check that we encode text strings properly
    #
    # Note: We're doing this test with a non-unicode char so that we can check
    # that default encoding is working.  The default encoding is 'ascii' for
    # Python2 and 'utf-8' for Python3
    result = to_bytes(b'\xffhello')
    assert result == b'\xffhello'

    # Check that we can decode text strings with specified encoding
    result = to_bytes(u'\u20ac', encoding='utf-8')
    assert result == b'\xe2\x82\xac'
    result

# Generated at 2022-06-24 20:57:59.753954
# Unit test for function to_bytes
def test_to_bytes():
    # Testcases
    float_0 = 5002.564
    var_0 = jsonify(float_0)
    try:
        # Call the function
        to_bytes(var_0)
        print("Ok")
    except Exception:
        print("Error")


# Generated at 2022-06-24 20:58:01.970958
# Unit test for function jsonify
def test_jsonify():
    assert (jsonify(5002.564)) == '5002.564'
    assert (isinstance(jsonify(5002.564), text_type))

if __name__ == "__main__":
    test_jsonify()

# Generated at 2022-06-24 20:58:13.352552
# Unit test for function to_bytes
def test_to_bytes():
    str_encoded_0 = 'test text'
    str_encoded_1 = 'test text'
    str_encoded_2 = b"test text"
    str_encoded_3 = b"test text"
    str_encoded_4 = 'test text'
    str_encoded_5 = 'test text'
    str_encoded_6 = b"test text"
    str_encoded_7 = b"test text"
    str_encoded_8 = 'test text'
    str_encoded_9 = 'test text'
    str_encoded_10 = b"test text"
    str_encoded_11 = b"test text"
    str_encoded_12 = 'test text'
    str_encoded_13 = 'test text'

# Generated at 2022-06-24 20:58:15.108686
# Unit test for function to_bytes
def test_to_bytes():
    var_0 = 5002.564
    s = str(var_0)
    b = s.encode('utf-8')
    assert to_bytes(var_0) == b

if __name__ == "__main__":
    test_to_bytes()

# Generated at 2022-06-24 20:58:25.220480
# Unit test for function to_bytes
def test_to_bytes():
    int_1 = 5
    str_1 = str(int_1)

    byte_1 = to_bytes(int_1, errors='surrogate_or_replace')
    byte_2 = to_bytes(str_1, errors='surrogate_or_replace')
    byte_3 = to_bytes(str_1, errors='surrogate_or_strict')
    byte_4 = to_bytes(str_1, errors='surrogate_or_strict', encoding='latin-1')
    byte_5 = to_bytes(str_1, errors='surrogate_then_replace', encoding='latin-1')



# Generated at 2022-06-24 20:58:32.783480
# Unit test for function to_bytes
def test_to_bytes():
    """Verify that the to_bytes function returns a bytes object"""
    assert isinstance(to_bytes(u'ascii', errors='surrogateescape'), binary_type)
    assert isinstance(to_bytes(''), binary_type)
    assert to_bytes(u'ascii', errors='surrogateescape') == b'ascii'
    assert to_bytes('', encoding='latin-1') == b''
    assert to_bytes(b'bytes', errors='surrogateescape') == b'bytes'
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(Set([1, 2, 3]), nonstring='passthru') == Set([1, 2, 3])

# Generated at 2022-06-24 20:58:40.702852
# Unit test for function jsonify
def test_jsonify():
    # Test case 0
    float_0 = 5002.564
    var_0 = jsonify(float_0)


# Generated at 2022-06-24 20:58:42.162157
# Unit test for function jsonify
def test_jsonify():
    print("TEST BEGIN FOR jsonify()\n")

    print("Testing with float object")
    test_case_0()

    print("TEST END FOR jsonify()\n")



# Generated at 2022-06-24 20:58:52.347431
# Unit test for function to_native
def test_to_native():
    # Test with float
    float_0 = 5002.564
    expect_0 = "5002.564"
    actual_0 = to_native(float_0)
    assert actual_0 == expect_0,"test_to_native function test failed"
    # Test with None
    obj_0 = None
    expect_1 = None
    actual_1 = to_native(obj_0)
    assert actual_1 == expect_1,"test_to_native function test failed"
    # Test with boolean
    bool_0 = False
    expect_2 = False
    actual_2 = to_native(bool_0)
    assert actual_2 == expect_2,"test_to_native function test failed"
    # Test with int
    int_0 = 112
    expect_3 = 112
    actual_3 = to_

# Generated at 2022-06-24 20:58:57.612368
# Unit test for function jsonify
def test_jsonify():
    output_0 = json.dumps(5002.564, default=_json_encode_fallback)
    print(output_0)
    output_0 = json.dumps(5002.564, default=_json_encode_fallback)
    print(output_0)

if __name__ == '__main__':
    test_case_0()
    test_jsonify()

# Generated at 2022-06-24 20:59:05.642755
# Unit test for function to_bytes
def test_to_bytes():
    # Test the error cases
    try:
        to_bytes(None, nonstring='strict')
        passed = False
    except TypeError:
        passed = True
    assert passed, 'to_bytes did not fail properly when passed a non-string in strict mode'

    assert to_bytes(None, nonstring='empty') == to_bytes(''), 'to_bytes did not return an empty string when asked to'
    assert to_bytes(None, nonstring='passthru') is None, 'to_bytes did not return the passed object when asked to'
    assert to_bytes(None, nonstring='simplerepr') == to_bytes(str(None)), 'to_bytes did not return a string representation when asked to'


# Generated at 2022-06-24 20:59:08.787387
# Unit test for function jsonify
def test_jsonify():
    print("Testing jsonify")
    print("\tCalling jsonify with mandatory values...")
    test_case_0()
    print("\tCalling jsonify with mandatory values and some optional values...")
    print("\tCalling jsonify with optional values...")



# Generated at 2022-06-24 20:59:15.773043
# Unit test for function jsonify
def test_jsonify():
    float_0 = 5002.564
    var_0 = jsonify(float_0)
    assert var_0 == '5002.564'
    float_1 = 312.994
    var_1 = jsonify(float_1)
    assert var_1 == '312.994'
    float_2 = 8902.54
    var_2 = jsonify(float_2)
    assert var_2 == '8902.54'
    float_3 = 5.5
    var_3 = jsonify(float_3)
    assert var_3 == '5.5'
    float_4 = 9200.9142
    var_4 = jsonify(float_4)
    assert var_4 == '9200.9142'
    float_5 = 522.45

# Generated at 2022-06-24 20:59:24.367513
# Unit test for function jsonify
def test_jsonify():
    str_0 = "eyd2"
    list_0 = [1, 4, 5, 6]
    tuple_0 = (1, 6, 9)
    int_0 = 9
    float_0 = 7.2
    bytes_0 = 'a'
    dict_0 = {}
    set_0 = set()
    # Assert that the function works for all parameters
    try:
        for param in [str_0, list_0, tuple_0, int_0, float_0, bytes_0, dict_0, set_0, {"str_1": "str_0"}]:
            jsonify(param)
            assert True
    except AssertionError:
        raise AssertionError('The function "jsonify" does not work for some parameters')
    # Test that the correct types are returned

# Generated at 2022-06-24 20:59:34.606181
# Unit test for function to_native
def test_to_native():
    assert u'' == to_native(b'', encoding='utf-8')
    assert u'' == to_native(b' ', encoding='utf-8')
    assert u'' == to_native(b'\n', encoding='utf-8')
    assert u'' == to_native(u'', encoding='utf-8')
    assert u'' == to_native(u' ', encoding='utf-8')
    assert u'' == to_native(u'\n', encoding='utf-8')
    assert u'foo' == to_native(b'foo', encoding='utf-8')
    assert u'foo' == to_native(u'foo', encoding='utf-8')
    assert u' ' == to_native(b' ', encoding='utf-8')

# Generated at 2022-06-24 20:59:42.987823
# Unit test for function jsonify
def test_jsonify():
    for encoding in ("utf-8", "latin-1"):
        try:
            var_1 = jsonify(float_0, encoding=encoding, default=_json_encode_fallback, **kwargs)
            var_1 = jsonify(float_0, default=_json_encode_fallback, **kwargs)
        # Old systems using old simplejson module does not support encoding keyword.
        except TypeError:
            try:
                new_data = container_to_text(data, encoding=encoding)
            except UnicodeDecodeError:
                continue
            var_1 = jsonify(new_data, default=_json_encode_fallback, **kwargs)
        except UnicodeDecodeError:
            continue
    raise UnicodeError('Invalid unicode encoding encountered')


# Generated at 2022-06-24 20:59:59.021431
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes([]) == b''
    assert to_bytes(Set()) == b''
    assert to_bytes(set()) == b''
    assert to_bytes(frozenset()) == b''
    assert to_bytes(dict()) == b''
    assert to_bytes({}) == b''
    assert to_bytes([1, 2, 3, 4, 5]) == b'[1, 2, 3, 4, 5]'
    assert to_bytes(Set([1, 2, 3, 4, 5])) == b'{1, 2, 3, 4, 5}'
    assert to_bytes(set([1, 2, 3, 4, 5])) == b'{1, 2, 3, 4, 5}'

# Generated at 2022-06-24 21:00:04.317823
# Unit test for function jsonify
def test_jsonify():
    jsonify_double = 5002.564
    jsonify_obj = {
        'x': float_0,
        'y': jsonify_double,
        'z': jsonify_double}
    jsonify_output = json.dumps(jsonify_obj, sort_keys=True)
    print(jsonify_output)
    jsonify_output = json.dumps(jsonify_obj, sort_keys=False)
    print(jsonify_output)

# Generated at 2022-06-24 21:00:11.572892
# Unit test for function to_bytes
def test_to_bytes():
    text_0 = u'test_value'
    byte_0 = to_bytes(text_0, errors='surrogate_or_strict')
    if(PY3):
        assert byte_0 == b'test_value'
    else:
        assert byte_0 == 'test_value'
    text_1 = u'test_value'
    byte_1 = to_bytes(text_1, errors='surrogate_or_strict')
    if(PY3):
        assert byte_1 == b'test_value'
    else:
        assert byte_1 == 'test_value'

# Generated at 2022-06-24 21:00:18.886965
# Unit test for function jsonify
def test_jsonify():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()
    bool_23 = bool()
    bool_24 = bool()

# Generated at 2022-06-24 21:00:19.985450
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(test_case_0) == "5002.564"


# Generated at 2022-06-24 21:00:21.020504
# Unit test for function to_native
def test_to_native():
    assert to_native( float_0 ) == '5002.564'

# Generated at 2022-06-24 21:00:29.137140
# Unit test for function to_native
def test_to_native():
    native_0 = to_native(bytearray(b'\x00\x00'), errors='surrogate_or_strict', nonstring='strict')
    assert native_0 == bytearray(b'\x00\x00')

    native_1 = to_native(float_0, errors='strict')
    assert native_1 == 5002.564

# End unit test from function to_native


# Generated at 2022-06-24 21:00:34.637760
# Unit test for function to_bytes
def test_to_bytes():
  # Test case 0
  float_0 = 5002.564
  result = to_bytes(float_0)
  assert result == 5002.564



# Generated at 2022-06-24 21:00:46.056416
# Unit test for function to_bytes
def test_to_bytes():

    # Test case for function to_bytes.
    float_2 = 4963.7307
    float_3 = 4373.4636
    float_4 = 252.0655
    float_5 = 5183.9898
    float_1 = 3113.69556
    float_0 = 5002.564
    dict_0 = { 'foo': 2, 'bar': 5819, 'baz': False, 'qux': float_2, 'corge': 8, 'grault': 7, 'garply': float_0, 'waldo': float_5, 'fred': True, 'plugh': None, 'xyzzy': False }

# Generated at 2022-06-24 21:00:47.609777
# Unit test for function to_bytes
def test_to_bytes():
    float_0 = 5002.564
    value_0 = to_bytes(float_0)


# Generated at 2022-06-24 21:00:57.251253
# Unit test for function to_bytes
def test_to_bytes():
    bytes_0 = to_bytes(float_0)
    assert bytes_0 == b'5002.564'



# Generated at 2022-06-24 21:01:07.137023
# Unit test for function jsonify
def test_jsonify():
    list_0 = ['1', '0', '3', '5']
    obj_0 = jsonify(list_0)
    obj_1 = jsonify(['1', '0', '3', '5'])
    obj_2 = jsonify(list_0)
    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'c'
    int_0 = 100000
    obj_2 = jsonify(list_0)
    str_1 = 'b'
    obj_0 = jsonify(list_0)
    # Testcases for jsonify
    if obj_0 == obj_1 and str_1 != str_0:
        pass
    else:
        print('FAILED')
    if str_1 == str_2:
        pass

# Generated at 2022-06-24 21:01:11.554357
# Unit test for function jsonify
def test_jsonify():
    float_0 = 5002.564
    int_0 = jsonify(float_0)
    float_1 = 52312.13
    int_1 = jsonify(float_1)
    assert int_0 != int_1
test_case_0()
test_jsonify()

# End Unit test for function jsonify


# Generated at 2022-06-24 21:01:16.722930
# Unit test for function to_bytes
def test_to_bytes():
    """
    Test to check if the function works properly
    """
    # These are global variables
    float_0 = 5002.564

    assert to_bytes(float_0, "utf-8") == "5002.564"
    assert to_bytes(float_0) == "5002.564"
    assert to_bytes(float_0, errors = 'invalid') == "5002.564"

test_case_0()

# Generated at 2022-06-24 21:01:20.138641
# Unit test for function jsonify
def test_jsonify():
    # asserts that the results are equivalent
    result = json.dumps(test_case_0(), default=_json_encode_fallback)
    expected = jsonify(test_case_0())
    assert result == expected



# Generated at 2022-06-24 21:01:30.909462
# Unit test for function jsonify
def test_jsonify():
    float_0 = 5002.564
    string_0 = "double"
    string_1 = 'safe'
    string_2 = 'lat/in'
    string_3 = 'escape'
    string_4 = '\u20ac'
    string_5 = '\\'
    string_6 = '"'
    string_7 = '/'
    string_8 = 'b'
    string_9 = '\b'
    string_10 = 'f'
    string_11 = '\f'
    string_12 = 'n'
    string_13 = '\n'
    string_14 = 'r'
    string_15 = '\r'
    string_16 = 't'
    string_17 = '\t'
    string_18 = '\u2028'

# Generated at 2022-06-24 21:01:37.763154
# Unit test for function jsonify

# Generated at 2022-06-24 21:01:39.948223
# Unit test for function to_native
def test_to_native():
    float_0 = 5002.564
    test_str_0 = to_native(float_0)
    assert test_str_0 == str(float_0)


# Generated at 2022-06-24 21:01:48.872405
# Unit test for function to_native
def test_to_native():
    output = json.dumps({u'text': True, u'state': u'present', u'force': False, u'owner': u'root', u'group': u'root', u'mode': u'0777', u'dest': u'/home/foobar'}, ensure_ascii=True)
    expected = u'{"text": true, "state": "present", "force": false, "owner": "root", "group": "root", "mode": "0777", "dest": "/home/foobar"}'
    assert(output == expected)



# Generated at 2022-06-24 21:01:59.121874
# Unit test for function to_bytes
def test_to_bytes():
    float_0 = 5002.564
    teststr = u"T\xe9st"
    assert to_bytes(teststr) == b"T\xc3\xa9st"
    assert to_bytes(teststr, errors='surrogate_or_strict') == b"T\xc3\xa9st"
    assert to_bytes(teststr, errors='surrogate_or_replace') == b"T\xc3\xa9st"
    assert to_bytes(teststr, errors='surrogate_then_replace') == b"T\xc3\xa9st"
    teststr = u"T\xe9st\udcdc"
    assert to_bytes(teststr) == b"T\xc3\xa9st\xed\xb4\x9c"

# Generated at 2022-06-24 21:02:13.071468
# Unit test for function jsonify
def test_jsonify():
    res = jsonify(float_0)
    return



# Generated at 2022-06-24 21:02:21.014036
# Unit test for function to_bytes
def test_to_bytes():
    # Line coverage: 4 - Default
    # Line coverage: 4 - Default
    # Line coverage: 14 - else, then else
    # Line coverage: 14 - else, then else
    # Line coverage: 13 - else, then else
    # Line coverage: 13 - else, then else
    # Line coverage: 17 - Default
    # Line coverage: 22 - Default
    # Line coverage: 25 - Default
    # Line coverage: 25 - Default
    # Line coverage: 6 - Default
    # Line coverage: 6 - Default
    # Line coverage: 10 - Default
    # Line coverage: 10 - Default
    # Line coverage: 8 - Default
    # Line coverage: 8 - Default
    str_0 = "ASCII"
    # Line coverage: 12 - Default
    # Line coverage: 12 - Default

    ret = to_bytes(str_0)

    str_

# Generated at 2022-06-24 21:02:32.508175
# Unit test for function to_bytes
def test_to_bytes():
    # Coding error test
    # Create a list of inputs
    inputs = []
    # Add a dict entry for each test
    temp_dict = {'obj': to_bytes(text_type(float_0), 'utf-8', 'surrogate_or_replace', 'simplerepr'), 'encoding': 'utf-8', 'errors': 'surrogate_or_replace', 'nonstring': 'simplerepr'}
    inputs.append(temp_dict)
    # Loop over each test and evaluate the function
    for test_inputs in inputs:
        # Get the function inputs
        func_inputs = [test_inputs[x] for x in ['obj', 'encoding', 'errors', 'nonstring']]
        # Evaluate the function
        output = to_bytes(*func_inputs)
        # Compare output to known

# Generated at 2022-06-24 21:02:38.834291
# Unit test for function jsonify
def test_jsonify():
    # make sure that the results of jsonify can be decoded by json.loads
    data = dict((str(num), to_native(num)) for num in range(10))
    new_data = json.loads(jsonify(data))
    assert len(new_data) == 10
    assert isinstance(new_data, dict)
    for num in range(10):
        assert to_native(num) == new_data[to_native(num)]

    new_data = json.loads(jsonify(data, indent=4))
    assert len(new_data) == 10
    assert isinstance(new_data, dict)
    for num in range(10):
        assert to_native(num) == new_data[to_native(num)]


# Generated at 2022-06-24 21:02:44.683381
# Unit test for function jsonify
def test_jsonify():
    name = "str_0"
    str_0 = "'1'"
    int_0 = 77
    bool_0 = True
    bool_1 = False
    none_0 = "None"
    none_1 = None
    none_2 = "None"
    none_3 = "None"
    none_4 = None
    none_5 = "None"
    none_6 = None
    none_7 = None
    none_8 = "None"
    none_9 = None
    none_10 = "None"
    none_11 = "None"
    none_12 = "None"
    none_13 = "None"
    none_14 = None
    none_15 = None
    none_16 = "None"
    none_17 = None
    none_18 = None

# Generated at 2022-06-24 21:02:54.715917
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(1) == b'1'
    assert to_bytes(1.3) == b'1.3'
    assert to_bytes('test') == b'test'
    assert to_bytes(u'test') == b'test'
    assert to_bytes('\xe9') == b'\xc3\xa9'
    assert to_bytes(u'\xe9') == b'\xc3\xa9'

    assert to_bytes(None) == b''
    assert to_bytes(None, nonstring='passthru') is None
    assert to_bytes(None, nonstring='strict') is None

    # Test non-native strings
    assert to_bytes('\xe9'.encode('utf-16'), encoding='utf-16') == b'\xff\xfe\xe9\x00'

# Generated at 2022-06-24 21:03:03.189742
# Unit test for function jsonify

# Generated at 2022-06-24 21:03:13.839911
# Unit test for function to_bytes
def test_to_bytes():
    # Test 'float_0'
    float_0 = 5002.564
    assert to_bytes(float_0) == str(float_0).encode()
    # Test 'float_1'
    float_1 = 916.98
    assert to_bytes(float_1, encoding='utf-8') == str(float_1).encode('utf-8')
    # Test 'test_bytes'

# Generated at 2022-06-24 21:03:16.122436
# Unit test for function to_native
def test_to_native():
    fmt_0 = to_native()
    assert (fmt_0 is not None)


# Generated at 2022-06-24 21:03:19.118714
# Unit test for function jsonify
def test_jsonify():
    print("Testing jsonify")
    assert jsonify('foo') == '"foo"'
    assert jsonify({"foo": "bar"}) == '{"foo": "bar"}'


# Generated at 2022-06-24 21:03:31.138441
# Unit test for function to_native
def test_to_native():
    assert to_native(float_0)=='5002.564'


# Generated at 2022-06-24 21:03:42.989028
# Unit test for function to_bytes
def test_to_bytes():
    # Make sure that to_bytes handles unicode regr test for #5988
    text_0 = to_bytes(u'\u043f\u0440\u0438\u0432', 'utf-8')
    text_1 = to_bytes(u'\u043f\u0440\u0438\u0432\u0441\u0442\u0432\u0435')
    text_2 = to_bytes(u'\u043f\u0440\u0438\u0432\u0441\u0442\u0432\u0435', 'utf-8')
    text_3 = to_bytes(u'\u043f\u0440\u0438\u0432\u0441\u0442\u0432\u0435', 'utf-8')
   

# Generated at 2022-06-24 21:03:48.968726
# Unit test for function to_native
def test_to_native():
    float_0 = 5002.564
    assert to_native(float_0, nonstring='simplerepr') == '5002.564'
    # These are expected to fail because of the nonstring argument type
    #assert to_native(float_0, nonstring='passthru') == float_0
    #assert to_native(float_0, nonstring='empty') == ''
    test_dict = {}
    tmp_36 = 'abc'
    test_dict['a'] = tmp_36
    tmp_37 = 'def'
    test_dict['b'] = tmp_37
    assert to_native(test_dict, nonstring='simplerepr') == "{'a': 'abc', 'b': 'def'}"


# Generated at 2022-06-24 21:04:00.162330
# Unit test for function jsonify
def test_jsonify():
    print("Test 1: jsonify")
    data = {"test": 0}
    assert(jsonify(data) == '{"test": 0}')
    data = {"test": {"test": 0}}
    assert(jsonify(data) == '{"test": {"test": 0}}')
    data = {u"test": 0}
    assert(jsonify(data) == '{"test": 0}')
    data = {u"test": u"test"}
    assert(jsonify(data) == '{"test": "test"}')
    data = {u"test": {u"test": 0}}
    assert(jsonify(data) == '{"test": {"test": 0}}')
    data = {u"test": [0]}
    assert(jsonify(data) == '{"test": [0]}')

# Generated at 2022-06-24 21:04:09.990073
# Unit test for function to_native
def test_to_native():
    # Initialize the string variables
    str_0 = "}Q@F9$HW"
    str_1 = ",?YI"
    str_2 = "`F"
    str_3 = "{n"
    str_4 = "${b+"

    # Check if the function returns an expected result for the provided arguments
    assert to_native(str_0, str_1, str_2) == '\\', "Test_case_0 failed"
    assert to_native(str_3, str_4, str_2) == '{n', "Test_case_1 failed"


# Generated at 2022-06-24 21:04:20.289324
# Unit test for function to_native
def test_to_native():
    dt_now = datetime.datetime.now()
    float_input  = 5002.564
    float_output = float(float_input)
    
    list_input  = [1, 2, 3, 5, 6]
    list_output = list(list_input)
    tuple_input  = (1, 2, 3, 5, 6)
    tuple_output = tuple(tuple_input)
    set_input   = set(list_input)
    set_output  = set(set_input)
    dict_input  = {'a': 1}
    dict_output = dict(dict_input)

    for in_type in (dt_now, float_input, list_input, tuple_input, set_input, dict_input):
        out_type = to_native(in_type)


# Generated at 2022-06-24 21:04:25.619110
# Unit test for function jsonify
def test_jsonify():
    # Tests that a dict containing a datetime object can be jsonified
    dt_obj = datetime.datetime(2000, 1, 1)
    obj = {'a': dt_obj}
    assert jsonify(obj) == '{"a": "2000-01-01T00:00:00"}'
    # Tests that a dict of lists containing datetime objects can be jsonified
    dt_obj = datetime.datetime(2000, 1, 1)
    obj = {'a': [dt_obj, dt_obj]}
    assert jsonify(obj) == '{"a": ["2000-01-01T00:00:00", "2000-01-01T00:00:00"]}'
    # Tests that a dict of lists containing datetime objects can be pretty printed

# Generated at 2022-06-24 21:04:38.055742
# Unit test for function jsonify
def test_jsonify():
    assert (jsonify("Hello") == '"Hello"'), "AssertionError"
    assert (jsonify(to_text("Hello")) == '"Hello"'), "AssertionError"
    assert (jsonify(["Hello", "World"]) == '["Hello", "World"]'), "AssertionError"
    assert (jsonify("JSON") == '"JSON"'), "AssertionError"
    assert (jsonify(to_text("JSON")) == '"JSON"'), "AssertionError"
    assert (jsonify("JSON", ensure_ascii=False) == u'"JSON"'), "AssertionError"
    assert (jsonify(to_text("JSON"), ensure_ascii=False) == u'"JSON"'), "AssertionError"

# Generated at 2022-06-24 21:04:44.960056
# Unit test for function to_native
def test_to_native():
    float_1 = 4.93737
    int_2 = 3
    int_3 = 45
    int_4 = 1
    set_0 = {'val_7', 'val_5', 'val_6', 'val_0', 'val_3', 'val_2', 'val_9', 'val_8', 'val_1', 'val_4'}
    test_case_0()

# Generated at 2022-06-24 21:04:54.722118
# Unit test for function to_native
def test_to_native():
    # get the following error as of Ans 1.9.4
    # assert yaml_dict['boolean_float_string_list'] == [True, False, 1.1, 'foo']
    # AssertionError: Lists differ: [True, False, 1.1, 'foo'] != [True, False, 1.1, u'foo']
    #assert yaml_dict['boolean_float_string_list'] == [True, False, 1.1, 'foo']
    text_str = to_native("foo")
    assert text_str == "foo"

    util_dict = {'boolean_float_string_list': [True, False, 1.1, 'foo'],
                 'null_string': None, 'string': 'foo'}

    # TODO:  better test for null_string
    assert util_

# Generated at 2022-06-24 21:05:25.852223
# Unit test for function to_native
def test_to_native():
    '''
    Test function to_native()
    '''

    assert to_native(1) == 1
    assert to_native('foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(True) is True
    assert to_native(None) is None

    assert to_native({'foo': 'bar'}) == {'foo': 'bar'}
    assert to_native([1, 2, 3]) == [1, 2, 3]
    assert to_native((1, 2, 3)) == (1, 2, 3)

    now = datetime.datetime.now()
    assert to_native(now) == now

    now2 = datetime.datetime.now()
    assert to_native(now) == now2


# Generated at 2022-06-24 21:05:33.700128
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes("foobar") == b"foobar"
    assert to_bytes("foobar", encoding="us-ascii") == b"foobar"
    assert to_bytes("foobar", errors="replace") == b"foobar"
    assert to_bytes("foobar", errors="ignore") == b"foobar"
    assert to_bytes("foo\xffbar", errors="ignore") == b"foobar"
    assert to_bytes("foobar", errors="xmlcharrefreplace") == b"foobar"
    assert to_bytes("foobar", errors="backslashreplace") == b"foobar"
    assert to_bytes("foob\xe8r", errors="replace") == b"foob?r"

# Generated at 2022-06-24 21:05:44.506271
# Unit test for function to_bytes
def test_to_bytes():
    float_0 = 5002.564
    str_0 = 'com.google.protobuf.ServiceException'
    str_1 = 'com.google.protobuf.ServiceException'
    str_2 = 'com.google.protobuf.ServiceException'
    str_3 = 'com.google.protobuf.ServiceException'
    str_4 = 'com.google.protobuf.ServiceException'

    assert to_bytes(str_0, encoding='utf-8', errors=None, nonstring='simplerepr') == 'com.google.protobuf.ServiceException'
    assert to_bytes(str_1, encoding='utf-8', errors=None, nonstring='simplerepr') == 'com.google.protobuf.ServiceException'

# Generated at 2022-06-24 21:05:51.616024
# Unit test for function jsonify
def test_jsonify():
    # Test with float argument
    float_0 = jsonify(5002.564)
    print(float_0)
    print("Testing jsonify")
    # Test with dictionary argument
    dict_0 = jsonify({"x": "a"})
    dict_1 = jsonify({"x": "a"}, ensure_ascii=False, sort_keys=True)
    dict_2 = jsonify({"x": "a"}, separators=(',', ':'), sort_keys=True)
    print(dict_0)
    print(dict_1)
    print(dict_2)
    # Test with Set argument
    set_0 = {1, 2, 3, 4}
    set_1 = jsonify(set_0)
    print(set_1)


# Generated at 2022-06-24 21:05:53.755549
# Unit test for function jsonify
def test_jsonify():
    try:
        test_case_0()
        assert True, "Test case 0 passed"
    except AssertionError as e:
        assert False, str(e)

# Generated at 2022-06-24 21:06:00.980677
# Unit test for function to_bytes
def test_to_bytes():
    # Default args
    # Test case with float
    assert to_bytes(5002.564) == b'5002.564'
    # Test case with integer
    assert to_bytes(58) == b'58'
    # Test case with string
    assert to_bytes('string') == b'string'
    # Test case with boolean True
    assert to_bytes(True) == b'True'
    # Test case with boolean False
    assert to_bytes(False) == b'False'
    # Test case with none
    assert to_bytes(None) == b'None'

    # args
    # Test case with float
    assert to_bytes(5002.564, 'ascii') == b'5002.564'
    # Test case with integer

# Generated at 2022-06-24 21:06:05.205235
# Unit test for function to_native
def test_to_native():
    str_0 = to_native(float_0, errors='surrogate_or_replace')
    str_1 = to_native(str_0, errors='surrogate_or_strict')
    assert str_1 == str_0


# Generated at 2022-06-24 21:06:14.031092
# Unit test for function jsonify
def test_jsonify():
    # Test case for default arguments:
    # data = {'a': True, 'b': 2, 'c': u'hello', 'd': False, 'e': 1, 'f': set([1]), 'g': u'world'}
    data = {}
    data['a'] = True
    data['b'] = 2
    data['c'] = u'hello'
    data['d'] = False
    data['e'] = 1
    data['f'] = set([1])
    data['g'] = u'world'
    result = jsonify(data)
    print(result)
    # Test case for keyword arguments:
    # data = {'a': True, 'b': 2, 'c': u'hello', 'd': False, 'e': 1, 'f': set([1]), 'g': u'world'}


# Generated at 2022-06-24 21:06:22.358919
# Unit test for function to_bytes