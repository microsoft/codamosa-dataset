

# Generated at 2022-06-24 20:56:41.127288
# Unit test for function to_native
def test_to_native():
    bool_0 = False
    var_0 = to_native(bool_0)
    bool_1 = True
    var_1 = to_native(bool_1)
    int_0 = 500
    var_2 = to_native(int_0)
    float_0 = float(3.14)
    var_3 = to_native(float_0)
    unicode_0 = u'acb'
    var_4 = to_native(unicode_0)
    unicode_1 = u"{'a': 'b'}"
    var_5 = to_native(unicode_1)
    list_0 = ['abc', 'abc']
    var_6 = to_native(list_0)
    unicode_2 = u'acb'

# Generated at 2022-06-24 20:56:43.640428
# Unit test for function jsonify
def test_jsonify():
    test_case_0()

# Main program
if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-24 20:56:52.045340
# Unit test for function to_native
def test_to_native():
    value = to_text(1, errors='surrogate_or_strict')
    assert value == u"1"
    value = to_text(1, errors='surrogate_or_replace')
    assert value == u"1"
    value = to_text(1, errors='surrogate_then_replace')
    assert value == u"1"

    # bool
    bool_ = True
    value = to_native(bool_, errors='surrogate_or_strict')
    assert value == True
    value = to_native(bool_, errors='surrogate_or_replace')
    assert value == True
    value = to_native(bool_, errors='surrogate_then_replace')
    assert value == True

    bool_ = False

# Generated at 2022-06-24 20:57:04.041651
# Unit test for function to_bytes
def test_to_bytes():
    bool_0 = False
    obj_0 = bytes()
    var_0 = to_bytes(obj_0)
    obj_1 = bytes([97, 98, 99])
    var_1 = to_bytes(obj_1)
    obj_2 = bytes(97)
    var_2 = to_bytes(obj_2)
    obj_3 = bytes([97, 98, 99, 100, 101, 102, 103])
    var_3 = to_bytes(obj_3)
    obj_4 = bytes([97, 98, 99, 100])
    var_4 = to_bytes(obj_4)

# Generated at 2022-06-24 20:57:06.527800
# Unit test for function jsonify
def test_jsonify():
    bool_0 = False
    var_0 = jsonify(bool_0)


# Generated at 2022-06-24 20:57:16.539554
# Unit test for function to_bytes

# Generated at 2022-06-24 20:57:18.579095
# Unit test for function jsonify
def test_jsonify():
    # Default test case
    test_case_0()
    # Positive test cases
    # Negative test cases


# Generated at 2022-06-24 20:57:22.261894
# Unit test for function jsonify
def test_jsonify():
    bool_0 = False
    var_0 = jsonify(bool_0)
    string_0 = '{}'
    if var_0 != string_0:
        raise Exception("jsonify(bool_0) did not produce correct results. Expected " + string_0 + ", got " + var_0)
    hash_0 = { 1: "hello", 2: "world"}
    var_1 = jsonify(hash_0)
    string_1 = '{"1": "hello", "2": "world"}'
    if var_1 != string_1:
        raise Exception("jsonify(hash_0) did not produce correct results. Expected " + string_1 + ", got " + var_1)


# Generated at 2022-06-24 20:57:26.733686
# Unit test for function jsonify
def test_jsonify():
    try:
        test_case_0()
    except Exception as e:
        print("Failed running tested function: %s" % e)
        return False
    else:
        return True

# Test this file

# Generated at 2022-06-24 20:57:28.851533
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('test') == 'test'
    assert type(to_bytes('test')) == 'str'


# Generated at 2022-06-24 20:57:35.945877
# Unit test for function jsonify
def test_jsonify():
    bool_0 = False
    
    
    test_case_0()

# Generated at 2022-06-24 20:57:40.773874
# Unit test for function to_native
def test_to_native():
    dict_0 = dict({'bool': bool_0})
    dict_1 = dict_0.copy()
    dict_1['i'] = 0
    dict_0 = dict_1.copy()
    dict_1['i2'] = 0
    dict_0 = dict_1.copy()
    dict_1['i2'] = 1
    dict_0 = dict_1.copy()
    dict_1['i2'] = 2
    dict_0 = dict_1.copy()
    dict_1['i2'] = 3
    dict_0 = dict_1.copy()
    dict_1['i3'] = 0
    dict_0 = dict_1.copy()
    dict_1['i3'] = None
    dict_0 = dict_1.copy()
    dict_1['i3'] = 1
   

# Generated at 2022-06-24 20:57:47.065339
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(True) == b'true'
    assert to_bytes(False) == b'false'
    assert to_bytes(1) == b'1'
    assert to_bytes(3.4) == b'3.4'
    assert to_bytes('test', 'ascii') == b'test'
    assert to_bytes(u'test') == b'test'
    assert to_bytes(u'tést', 'ascii', 'surrogate_or_strict') == b't\xffst'
    assert to_bytes(u't\xffst', 'ascii', 'surrogate_or_replace') == b't\xffst'
    assert to_bytes(u't\xffst', 'ascii', 'surrogate_then_replace') == b't?st'
    assert to

# Generated at 2022-06-24 20:57:52.656264
# Unit test for function to_native
def test_to_native():
    temp_0 = False
    temp_1 = True
    arg_0 = to_native(temp_1)
    arg_1 = to_native(temp_0)
    assert arg_0 == temp_1
    assert arg_1 == temp_0
    assert temp_1 != temp_0
    arg_2 = to_native(temp_1)
    arg_3 = to_native(temp_1)
    assert arg_2 == temp_1
    assert arg_3 == temp_1
    assert temp_1 == temp_1


# Generated at 2022-06-24 20:57:53.917160
# Unit test for function to_native
def test_to_native():
    native = "test"
    assert to_native(native) == "test"


# Generated at 2022-06-24 20:58:00.135036
# Unit test for function jsonify
def test_jsonify():
    print(json.dumps(8, encoding='utf-8'))
    print(json.dumps(8))
    print(jsonify(8))
    print(jsonify(to_bytes(8, 'utf-8')))
    print(jsonify(to_text(8, 'utf-8')))
    print(jsonify(to_bytes('a')))
    print(jsonify(to_text('a')))
    print(json.dumps([1, 2, 3], encoding='utf-8'))
    print(json.dumps([1, 2, 3]))
    print(jsonify([1, 2, 3]))
    print(jsonify(to_bytes([1, 2, 3], 'utf-8')))

# Generated at 2022-06-24 20:58:04.899908
# Unit test for function to_bytes
def test_to_bytes():
  assert to_bytes('abc') == b'abc'


# Generated at 2022-06-24 20:58:06.162980
# Unit test for function jsonify
def test_jsonify():
    # Get the test data
    data = {1: 'test'}
    # Check if function returns correct result
    assert jsonify(data) == '{"1": "test"}'



# Generated at 2022-06-24 20:58:17.510481
# Unit test for function to_bytes
def test_to_bytes():
    bool_0 = True

    # TypeError: to_bytes() takes at least 1 argument (0 given)
    #assert bool_0 == bool(to_bytes())

    bool_1 = True

    # TypeError: to_bytes() takes at least 1 argument (0 given)
    #assert bool_1 == bool(to_bytes())

    bool_2 = True

    # TypeError: to_bytes() takes at least 1 argument (0 given)
    #assert bool_2 == bool(to_bytes())

    bool_3 = True

    # TypeError: to_bytes() takes at least 1 argument (0 given)
    #assert bool_3 == bool(to_bytes())

    bool_4 = True

    # TypeError: to_bytes() takes at least 1 argument (0 given)
    #assert bool_4 == bool(to_bytes())

# Generated at 2022-06-24 20:58:26.105182
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u"\u05d0\u05d1\u05d2") == b"\xd7\x90\xd7\x91\xd7\x92"
    if PY3:
        assert to_bytes(u"\u05d0\u05d1\u05d2", errors='surrogate_or_strict') == b"\xd7\x90\xd7\x91\xd7\x92"
        assert to_bytes(u"\u05d0\u05d1\u05d2", errors='surrogate_or_replace') == b"\xd7\x90\xd7\x91\xd7\x92"

# Generated at 2022-06-24 20:58:33.804611
# Unit test for function jsonify
def test_jsonify():
    # Test #0 for function jsonify
    test_case_0()


# Generated at 2022-06-24 20:58:37.481850
# Unit test for function to_native
def test_to_native():
    assert 'foo' == to_native(u'foo')
    assert 'foo' == to_native(b'foo')
    assert 'foo' == to_native('foo')
    assert 123 == to_native(123)
    assert 123.5 == to_native(123.5)
    assert "1/1/1970" == to_native(datetime.datetime(1970, 1, 1))


# Generated at 2022-06-24 20:58:48.342290
# Unit test for function to_bytes
def test_to_bytes():
    bool_0 = True
    string_0 = to_bytes(bool_0)
    bool_1 = False
    string_1 = to_bytes(bool_1)
    string_0 = to_bytes(string_1)
    list_0 = []
    string_0 = to_bytes(list_0)
    dict_0 = {}
    string_0 = to_bytes(dict_0)
    string_0 = to_bytes(dict_0)
    string_0 = to_bytes(dict_0)
    string_1 = to_bytes(dict_0)
    string_0 = to_bytes(string_1)
    string_0 = to_bytes(string_1)
    string_0 = to_bytes(string_1)
    string_1 = to_bytes(bool_0)
    string_

# Generated at 2022-06-24 20:58:53.753301
# Unit test for function to_native
def test_to_native():
    val = 'value'
    assert to_native(val, nonstring='passthru') is val
    assert to_native(val, nonstring='empty') == ''
    assert to_native(val, nonstring='simplerepr') == repr(val)
    #assert to_native(val, nonstring='strict') == str(val)


# Generated at 2022-06-24 20:58:55.091369
# Unit test for function jsonify
def test_jsonify():
    if True:
        test_case_0()


# Generated at 2022-06-24 20:59:02.103894
# Unit test for function to_native
def test_to_native():
    # No exceptions should be thrown
    assert to_native(5) == 5
    assert to_native(True) == True
    assert to_native("string") == "string"
    assert to_native(1.02) == 1.02
    assert to_native(None) == None
    assert to_native({}) == {}

    try:
        to_native(0, nonstring='strict')
    except TypeError:
        pass
    else:
        raise AssertionError("should have raised TypeError")

    assert to_native("string", nonstring='simplerepr') == "string"
    assert to_native("string", nonstring='passthru') == "string"
    assert to_native("string", nonstring='empty') == ""

    assert to_native("string", encoding='latin1') == "string"


# Generated at 2022-06-24 20:59:12.885133
# Unit test for function jsonify
def test_jsonify():
    # simple tests
    assert jsonify("foobar") == "\"foobar\""
    assert jsonify("foobar\u2713") == "\"foobar\\u2713\""
    assert jsonify("foobar\u2713".encode("latin-1")) == "\"foobar\\u2713\""
    assert jsonify("foobar\u2713".encode("latin-1").decode('utf-8')) == "\"foobar\\u2713\""

    # test with sets
    assert jsonify(set([1, 2, 3])) == "[1,2,3]"

    # test with dates
    now = datetime.datetime.now()
    timestamp = now.isoformat()
    assert jsonify(now) == "\"" + timestamp + "\""

    # test with non ascii

# Generated at 2022-06-24 20:59:21.811930
# Unit test for function to_native
def test_to_native():
  assert to_native('foo') == 'foo'
  assert to_native('foo', errors='surrogate_or_replace') == 'foo'
  assert to_native(u'foo') == 'foo'
  assert to_native(u'foo', errors='surrogate_or_replace') == 'foo'
  assert to_native(u'foo'.encode('utf-8')) == 'foo'
  assert to_native(u'foo'.encode('utf-8'), errors='surrogate_or_replace') == 'foo'
  assert to_native('foo'.decode('utf-8'), encoding='utf-8', nonstring='passthru') == 'foo'

# Generated at 2022-06-24 20:59:25.443349
# Unit test for function to_bytes
def test_to_bytes():
    # Input parameters
    obj = ''
    encoding = 'utf-8'
    errors = ''
    nonstring = ''

    ret = to_bytes(obj, encoding, errors, nonstring)



# Generated at 2022-06-24 20:59:27.665412
# Unit test for function jsonify
def test_jsonify():
    a = {
        "a": "This is \u2018 to \u2019."
    }
    print(jsonify(a))



# Generated at 2022-06-24 20:59:53.195376
# Unit test for function jsonify
def test_jsonify():
    data = {
      "key_0": "value_0",
      "key_1": "value_1",
      "key_2": "value_2",
    }
    kwargs = {
      "separators": (",", ":"),
      "sort_keys": True
    }
    # Test with defaults for every argument
    assert jsonify(data, **kwargs) == '{"key_0":"value_0","key_1":"value_1","key_2":"value_2"}'

test_cases = [
    (test_case_0, "Test #0: "),
]


# Generated at 2022-06-24 21:00:05.092990
# Unit test for function jsonify
def test_jsonify():
    if bool_0:
        data = 'Hello'
        result = jsonify(data)
        assert result == '"Hello"'
        print('TEST: jsonify(%s) == %s' % (data, result))

    if bool_0:
        data = 'Hello'
        result = jsonify(data, ensure_ascii=False)
        assert result == '"Hello"'
        print('TEST: jsonify(%s) == %s' % (data, result))

    if bool_0:
        data = 5
        result = jsonify(data)
        assert result == '5'
        print('TEST: jsonify(%s) == %s' % (data, result))

    if bool_0:
        data = '\xc3\xab'
        result = jsonify(data)
       

# Generated at 2022-06-24 21:00:07.289928
# Unit test for function to_bytes
def test_to_bytes():
    try:
        bool_0 = True
    except:
        bool_0 = False
    assert bool_0 == True


# Generated at 2022-06-24 21:00:11.243550
# Unit test for function to_native
def test_to_native():
    assert to_native(b'hello') == 'hello'
    assert to_native(True) is True
    assert to_native(1) == 1
    assert to_native('hello') == 'hello'
    assert to_native(10.1) == 10.1
    assert to_native(None) is None


# Generated at 2022-06-24 21:00:17.988185
# Unit test for function jsonify

# Generated at 2022-06-24 21:00:18.991634
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(True) == "true"


# Generated at 2022-06-24 21:00:25.797769
# Unit test for function to_native
def test_to_native():
    # Set up mock
    to_bytes_mock_0 = mocker.patch('ansible.module_utils._text.to_bytes')
    to_bytes_mock_1 = mocker.patch('ansible.module_utils._text.to_bytes')
    to_bytes_mock_2 = mocker.patch('ansible.module_utils._text.to_bytes')
    native_mock = mocker.patch('ansible.module_utils._text.native')
    to_bytes_mock_3 = mocker.patch('ansible.module_utils._text.to_bytes')
    to_bytes_mock_4 = mocker.patch('ansible.module_utils._text.to_bytes')

# Generated at 2022-06-24 21:00:26.476045
# Unit test for function jsonify
def test_jsonify():
    assert 1 == 1


# Generated at 2022-06-24 21:00:28.360355
# Unit test for function jsonify
def test_jsonify():
    try :
        content_0 = jsonify(True)
        assert isinstance(content_0, str)
    except Exception as e:
        logger.exception(e)
        assert False


# Generated at 2022-06-24 21:00:34.331396
# Unit test for function to_bytes
def test_to_bytes():
    filePath = 'test_'
    filePath = 'test_1_to_bytes'

    # Unit test for function to_bytes
    text_0 = 'Hello World'
    # Done unit testing for function to_bytes
    text_1 = '你好'
    # Test for exceptions
    # Exception: None
    # Exception: Traceback (most recent call last):
    #   File "C:\Users\fengtao\Desktop\test-project\test_1_to_bytes.py", line 3, in <module>
    #     text_0 = 'Hello World'
    # NameError: name 'text_0' is not defined
    # AssertionError: assert (to_bytes(text_0, encoding='utf-8', errors=None, nonstring='simplerepr') == 'Hello World'.encode('utf

# Generated at 2022-06-24 21:00:47.078372
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = '4x\\w'
    var_0 = to_bytes(str_0, 'utf-8', 'surrogateescape')


# Generated at 2022-06-24 21:00:50.916130
# Unit test for function jsonify
def test_jsonify():
    sample_json_dict = {"k1": "v1", "k2": [{"k3": "v3"}]}
    assert jsonify(sample_json_dict) == '{"k1": "v1", "k2": [{"k3": "v3"}]}'


# Generated at 2022-06-24 21:01:01.212604
# Unit test for function to_native
def test_to_native():
    arg_0 = '3x\\w'
    arg_1 = 'utf-8'
    arg_2 = 'surrogateescape'
    arg_3 = 'simplerepr'
    arg_4 = {1, 2}

# Generated at 2022-06-24 21:01:13.932428
# Unit test for function to_native
def test_to_native():
    assert to_native(b'\xc3\xbc') == '\u00fc'
    assert to_native("bob") == "bob"
    assert to_native("bob".encode("utf-8")) == "bob"
    assert to_native(u"bob") == "bob"
    assert to_native("bob", errors="surrogate_or_replace") == "bob"
    assert to_native("\x00", nonstring="strict") == "\x00"
    assert to_native("\x00") == "\x00"
    assert to_native(u"\u0100") == "\u0100"
    assert to_native(u"\u0100", nonstring="strict") == "\u0100"
    assert to_native(u"\u0100", nonstring="empty")

# Generated at 2022-06-24 21:01:20.680120
# Unit test for function to_native
def test_to_native():
    # Execution of function to_native
    rct_0 = to_native(container_0)
    assert(rct_0 == rce_0)

    rct_1 = to_native(container_1)
    assert(rct_1 == rce_1)

    rct_2 = to_native(container_2)
    assert(rct_2 == rce_2)

    rct_3 = to_native(container_3)
    assert(rct_3 == rce_3)


# Generated at 2022-06-24 21:01:24.613551
# Unit test for function to_bytes
def test_to_bytes():
    #return_value = to_bytes(obj, encoding, errors, nonstring)
    #assert return_value == expected
    #assert exception_expected == True
    assert True # TODO: implement your test here


# Generated at 2022-06-24 21:01:33.886565
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('教育') == b'\xe6\x95\x99\xe8\x82\xb2'
    assert to_bytes('教育', encoding='ascii') is None
    assert to_bytes('\U0001F4A9', encoding='ascii') is None
    assert to_bytes(b'\xe6\x95\x99\xe8\x82\xb2', encoding='ascii') == b'\xe6\x95\x99\xe8\x82\xb2'
    assert to_bytes(b'\xe6\x95\x99\xe8\x82\xb2', encoding=None) == b'\xe6\x95\x99\xe8\x82\xb2'

# Generated at 2022-06-24 21:01:37.568396
# Unit test for function to_native
def test_to_native():
    # Get the class name for type of the given object
    class_name = type(var_0).__name__

    # Return the xrange iterator
    if class_name == 'xrange':
        return iter(var_0)
    elif class_name == 'TextIOWrapper':
        return var_0
    elif class_name == 'BufferedReader':
        return var_0


# Generated at 2022-06-24 21:01:38.915960
# Unit test for function to_native
def test_to_native():
    str_0 = '3x\\w'
    var_0 = container_to_native(str_0)
    assert var_0 == '3x\\w'


# Generated at 2022-06-24 21:01:46.528854
# Unit test for function to_bytes
def test_to_bytes():
    str_1 = 'a'
    bs_0 = b'a'
    result_0 = to_bytes(str_1)
    if isinstance(result_0, bytes):
        assert bs_0 == result_0
    else:
        assert False


# Generated at 2022-06-24 21:02:10.275088
# Unit test for function to_native
def test_to_native():
    assert to_native("str") == str("str")
    assert to_native("str", "ascii") == "\x97\x97\x97"

    if PY3:
        assert to_native("str".encode("ascii"), "ascii") == "str"
        if HAS_SURROGATEESCAPE:
            assert to_native(b'\xe9\x9b\xb2\xf0\xa7\xa8\x94\x8c\x8e', "latin-1", 'surrogateescape') == u'é雲ꨔ茌'

# Generated at 2022-06-24 21:02:13.946638
# Unit test for function to_native
def test_to_native():
    print ("testing to_native")
    str_0 = '3x\\w'
    var_0 = container_to_native(str_0)


# Generated at 2022-06-24 21:02:23.759195
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = '3x\\w'
    var_0 = to_bytes(str_0, errors = 'surrogate_or_strict')
    assert var_0 == b'3x\\w'
    str_1 = '$[?_=oo'
    var_1 = to_bytes(str_1, encoding = 'utf-8', nonstring = 'strict')
    assert var_1 == b'$[?_=oo'
    str_2 = 'u>7p'
    var_2 = to_bytes(str_2, nonstring = 'passthru')
    #assert var_2 == b'u>7p'
    str_3 = 'FAA'

# Generated at 2022-06-24 21:02:27.332753
# Unit test for function jsonify
def test_jsonify():
    data = {'a': {'b': 'c', 'd': u'\xaa'}}

    output = json.loads(jsonify(data))

    assert output.get('a').get('d') == "\\u00aa"



# Generated at 2022-06-24 21:02:30.257372
# Unit test for function jsonify
def test_jsonify():
    str_0 = '3x\\w'
    var_0 = container_to_bytes(str_0)
    json_0 = jsonify(var_0)
    print(json_0)


# Generated at 2022-06-24 21:02:39.803813
# Unit test for function jsonify
def test_jsonify():
    str_0 = '3x\\w'
    assert jsonify(str_0) == str_0
    str_0 = '3x\\w'
    assert jsonify(str_0) == str_0
    str_0 = '3x\\w'
    assert jsonify(str_0) == str_0
    str_0 = '3x\\w'
    assert jsonify(str_0) == str_0
    str_0 = '3x\\w'
    assert jsonify(str_0) == str_0
    str_0 = '3x\\w'
    assert jsonify(str_0) == str_0


# Generated at 2022-06-24 21:02:40.704065
# Unit test for function to_native
def test_to_native():
    pass


# Generated at 2022-06-24 21:02:46.102738
# Unit test for function jsonify
def test_jsonify():
    data = {'foo': 42, 'bar': 1.1, 'foobar': 'hello world!'}
    jsonified = jsonify(data)
    assert jsonified == '{"foo": 42, "bar": 1.1, "foobar": "hello world!"}' or \
            jsonified == '{"bar": 1.1, "foo": 42, "foobar": "hello world!"}'


# Generated at 2022-06-24 21:02:55.725234
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(['a', 2, 'c']) == '["a",2,"c"]'
    assert jsonify({'a': 1, 'b': 2}) == '{"a":1,"b":2}'
    assert jsonify(('a', 1)) == '["a",1]'
    assert jsonify(set(['a', 1])) == '[1,"a"]'
    assert jsonify(datetime.datetime(2017, 12, 22, 15, 8, 13, 678920)) == '"2017-12-22T15:08:13.678920"'

# Generated at 2022-06-24 21:02:57.466055
# Unit test for function jsonify
def test_jsonify():
    obj = {u'a': 1}
    res = jsonify(obj)
    return (isinstance(res, str) and res == '{"a": 1}')


# Generated at 2022-06-24 21:03:28.598569
# Unit test for function jsonify
def test_jsonify():
    str_0 = '3x\\w'
    var_0 = container_to_bytes(str_0)
    assert str(json_encode(var_0)) == str(b'3x\\\\w')

    str_0 = '''
    abc
    '''
    var_0 = container_to_bytes(str_0)
    assert str(json_encode(var_0)) == str(b'\\n    abc\\n    ')

    str_0 = '''
    """
    abc
    '''
    var_0 = container_to_bytes(str_0)
    assert str(json_encode(var_0)) == str(b'\\n    \\\\"\\"\\"\\n    abc\\n    ')

    str_0 = '"abc"'
    var

# Generated at 2022-06-24 21:03:38.273631
# Unit test for function jsonify
def test_jsonify():
    global test_str_0
    global test_str_1
    global test_str_2
    global test_str_3
    global test_str_4
    global test_str_5
    global test_str_6
    global test_dict_0
    global test_list_0
    global test_list_1
    test_str_0 = '-'
    test_str_1 = '?'
    test_str_2 = '\\'
    test_str_3 = '\\'
    test_str_4 = '\\'
    test_str_5 = '\\'
    test_str_6 = '\\'

# Generated at 2022-06-24 21:03:46.992444
# Unit test for function to_native
def test_to_native():
    assert to_native("str") == "str"
    assert to_native("str", errors='surrogate_or_strict') == "str"
    assert to_native("str", errors='surrogate_or_replace') == "str"
    assert to_native("str", errors='surrogate_then_replace') == "str"
    assert to_native("nonunicode", encoding=None, errors='surrogate_or_strict') == "nonunicode"
    assert to_native("nonunicode", encoding=None, errors='surrogate_or_replace') == "nonunicode"
    assert to_native("nonunicode", encoding=None, errors='surrogate_then_replace') == "nonunicode"



# Generated at 2022-06-24 21:03:52.455544
# Unit test for function jsonify
def test_jsonify():
    s = u'{"name": "VM오토메이션 프로그램"}'
    result = jsonify(s)
    assert result == '{"name": "VM\\ud648\\ub7f0\\uc2dc\\ub3c4 \\ud504\\ub85c\\uadf8\\ub798\\ud504"}'


# Generated at 2022-06-24 21:03:58.863216
# Unit test for function jsonify
def test_jsonify():
    class TestCase:
        test_string = 'test string'

    data = {'test': TestCase()}

    #Test function to_bytes()

    #Test function to_text()

    #Test function jsonify()

    expected_result = b'{"test": {"test_string": "test string"}}'
    actual_result = jsonify(data)

    assert actual_result == expected_result


# Generated at 2022-06-24 21:04:05.242874
# Unit test for function to_bytes
def test_to_bytes():
    # Test the format of the docstring
    assert to_bytes.__doc__ is not None

    # Make sure that calling with a byte string simply returns that string
    assert to_bytes(b'foo') == b'foo'

    # Test ellipsis encoding
    assert to_bytes(b'\x91...\x94') == b'\xe2\x80\xa6'

    # Test surrogate handling
    if PY3:
        assert to_bytes(u'\udcff') == b'\xef\xbf\xbf'
    elif HAS_SURROGATEESCAPE:
        assert to_bytes(u'\udcff') == b'\xdc\xff'
        assert to_bytes(u'\udcff', errors='surrogateescape') == b'\xdc\xff'


# Generated at 2022-06-24 21:04:12.187859
# Unit test for function jsonify
def test_jsonify():
    # Check that encoding is 'utf-8'
    data = {'a': 'A', 'b': 'B'}
    ret = jsonify(data)
    assert re.match(r'^\{"a":.*"b":.*}$', ret)

    # Check that encoding is 'latin-1'
    data = {'a': 'A', 'b': 'B'}
    ret = jsonify(data)
    assert re.match(r'^\{"a":.*"b":.*}$', ret)



# Generated at 2022-06-24 21:04:19.708477
# Unit test for function to_native

# Generated at 2022-06-24 21:04:28.480925
# Unit test for function jsonify
def test_jsonify():

    str_0 = 'abc'

    var_1 = jsonify(str_0)
    assert var_1 == '"abc"'

    int_0 = 1
    var_1 = jsonify(int_0)
    assert var_1 == '1'

    list_0 = [1, 2, 3]
    var_1 = jsonify(list_0)
    assert var_1 == '[1, 2, 3]'

    dict_0 = dict(a=1, b=2)

    var_1 = jsonify(dict_0)
    assert var_1 == '{"a": 1, "b": 2}'

    dict_0 = dict(a=1, b=2)
    var_1 = jsonify(dict_0, sort_keys=True)

# Generated at 2022-06-24 21:04:40.090442
# Unit test for function jsonify
def test_jsonify():
    for _ in range(50):
        var = str(random.randint(0,50))

# Generated at 2022-06-24 21:05:07.042528
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == b'foo'
    assert to_bytes('fòô') == b'f\xc3\xb2\xc3\xb4'
    assert to_bytes('fòô'.encode('utf-8'), 'ascii', 'surrogate_or_replace') == b'f???'
    assert to_bytes('fòô'.encode('utf-8'), 'ascii', 'surrogate_or_strict') == b''
    assert to_bytes('fôô'.encode('utf-8'), errors='surrogate_then_replace') == b'f???'
    assert to_bytes('fòô'.encode('utf-8'), errors='surrogate_then_replace') == b'f\xc3\xb2\xc3\xb4'



# Generated at 2022-06-24 21:05:08.972388
# Unit test for function jsonify
def test_jsonify():
    str_0 = '3x\\w'
    var_0 = container_to_bytes(str_0)


# Generated at 2022-06-24 21:05:12.776950
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = '3x\\w'
    var_0 = to_bytes(str_0, errors='surrogate_then_replace')
    assert var_0 == b'3x\\w'


# Generated at 2022-06-24 21:05:19.490456
# Unit test for function to_bytes
def test_to_bytes():
    result = to_bytes(3)
    assert result == b'3'
    result = to_bytes(3, 'ascii', errors='surrogateescape')
    assert result == b'3'
    result = to_bytes(3, 'ascii', errors='surrogate_then_replace')
    assert result == b'3'
    result = to_bytes(3, 'ascii', errors='surrogate_or_replace')
    assert result == b'3'
    result = to_bytes(3, 'ascii', errors='surrogate_or_strict')
    assert result == b'3'
    result = to_bytes(u'\ue000')
    assert result == b'\xee\x80\x80'

# Generated at 2022-06-24 21:05:20.553554
# Unit test for function jsonify
def test_jsonify():
    assert True == True


# Generated at 2022-06-24 21:05:25.356745
# Unit test for function jsonify
def test_jsonify():
    data = {'x': u'\u2713'}
    expect = '{"x": "\\u2713"}'
    result = jsonify(data)
    print(result)
    assert result == expect


# Generated at 2022-06-24 21:05:26.668685
# Unit test for function jsonify
def test_jsonify():
    str_0 = '3xo\\w'
    str_1 = jsonify(str_0)


# Generated at 2022-06-24 21:05:34.498836
# Unit test for function to_native
def test_to_native():
    assert to_native(None) is None
    assert to_native(1) == 1
    assert to_native(['a', 1]) == ['a', 1]
    assert to_native([1, ['a', 1]]) == [1, ['a', 1]]
    assert to_native(set(['a'])) == set(['a'])
    assert to_native(dict(a=1)) == dict(a=1)
    assert to_native(u'café') == u'café'
    assert to_native(to_bytes(u'café')) == u'café'

# Generated at 2022-06-24 21:05:38.024749
# Unit test for function jsonify
def test_jsonify():
    result = jsonify(["test4", "test2", "test3", "test1"], sort_keys=True, indent=4)



# Generated at 2022-06-24 21:05:45.639104
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import PY3

    if not PY3:
        assert to_native(u"hello") == "hello"
        assert to_native("hello") == "hello"
    else:
        assert to_native(u"hello") == "hello"
        assert to_native("hello") == "hello"

    assert to_native(b"hello") == "hello"
    assert to_native("hello") == "hello"
    assert to_native(dict(a=1, b=2)) == b"{'a': 1, 'b': 2}".decode("utf-8")

