

# Generated at 2022-06-24 20:56:33.184062
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native

    assert to_native('test') == 'test'
    assert isinstance(to_native(b'test'), text_type)
    assert to_native(b'test', errors='surrogate_or_strict') == u'test'
    assert to_native(b'test', errors='surrogate_or_replace') == u'test'
    assert to_native(b'test', errors='surrogate_then_replace') == u'test'
    assert to_native(u'test') == u'test'


# Generated at 2022-06-24 20:56:38.336041
# Unit test for function to_native
def test_to_native():
    assert to_native('{"a":"1"}') == '{"a":"1"}'
    assert to_native('{"a":"1","b":2}') == '{"a":"1","b":2}'
    assert to_native('{"a":"1","b":2,"c":3,"d":4,"e":5,"f":6,"g":7,"h":8,"i":9,"j":10}') == '{"a":"1","b":2,"c":3,"d":4,"e":5,"f":6,"g":7,"h":8,"i":9,"j":10}'

# Generated at 2022-06-24 20:56:39.252692
# Unit test for function jsonify
def test_jsonify():
    # Test case 0
    test_case_0()


# Generated at 2022-06-24 20:56:49.175246
# Unit test for function to_bytes
def test_to_bytes():
    """
    Assert that the to_bytes() function correctly converts inputs.
    """
    # Check that Unicode text can be encoded properly
    b_obj = to_bytes(u'my string')
    assert isinstance(b_obj, binary_type)
    assert b_obj == b'my string'

    # Check that surrogates are encoded properly
    u_obj = u'\ud83d\ude00'
    b_obj = to_bytes(u_obj)
    assert isinstance(b_obj, binary_type)
    assert b_obj == b'\xf0\x9f\x98\x80'

    # Check that surrogates are encoded properly with a custom encoding
    b_obj = to_bytes(u_obj, 'utf-16-be')
    assert isinstance(b_obj, binary_type)


# Generated at 2022-06-24 20:56:54.236438
# Unit test for function to_native
def test_to_native():
    assert to_native(5) == 5
    assert to_native(5.0) == 5.0
    assert to_native(Set()) == set()
    assert to_native(datetime.datetime(1970, 1, 1)) == 0
    assert to_native(text_type('unicode')) == u'unicode'
    assert to_native(binary_type(b'binary')) == b'binary'

    class Foo(object):
        pass

    obj = Foo()
    obj.bar = 1
    obj.baz = 2

    assert to_native(obj) == {'bar': 1, 'baz': 2}


# Generated at 2022-06-24 20:57:02.971395
# Unit test for function to_native
def test_to_native():

    # Call the to_bytes function w/ default args
    var_0 = to_bytes()

    # Call the to_bytes function w/ default args
    var_1 = to_bytes()

    # Call the to_bytes function w/ default args
    var_2 = to_bytes()

    # Call the to_text function w/ default args
    var_3 = to_text()

    # Call the to_text function w/ default args
    var_4 = to_text()

    # Call the to_text function w/ default args
    var_5 = to_text()


# Generated at 2022-06-24 20:57:08.221249
# Unit test for function jsonify
def test_jsonify():

    set_0 = set()
    var_0 = jsonify(set_0)

    set_1 = set([b'1', b'2'])
    var_1 = jsonify(set_1)

    set_2 = set([1, 2])
    var_2 = jsonify(set_2)

    set_3 = set([1.1, 2.2])
    var_3 = jsonify(set_3)

    set_4 = set([u'string1', u'string2'])
    var_4 = jsonify(set_4)

    set_5 = set([True, False])
    var_5 = jsonify(set_5)


# Generated at 2022-06-24 20:57:13.306066
# Unit test for function jsonify
def test_jsonify():
    # Test with a valid set.
    set_0 = set()
    var_0 = jsonify(set_0)


# Generated at 2022-06-24 20:57:18.499999
# Unit test for function jsonify
def test_jsonify():
    test_cases = [
        (
            {'a': 1, 'b': 2, 'c': [1, 2, 3, 4]},
            '{"a": 1, "b": 2, "c": [1, 2, 3, 4]}'
        )
    ]

    for test_case in test_cases:
        assert jsonify(test_case[0]) == test_case[1]


# Generated at 2022-06-24 20:57:25.208193
# Unit test for function to_bytes
def test_to_bytes():

    # Testing when obj is a Set
    set_obj = set()
    # Calling to_bytes() with argument values
    # obj, encoding='utf-8', errors=None, nonstring='simplerepr'
    bytes_obj = to_bytes(set_obj, encoding='utf-8', errors=None, nonstring='simplerepr')

    # Testing when obj is a binary_type
    binary_obj = b"Python 2.7"
    # Calling to_bytes() with argument values
    # obj, encoding='utf-8', errors=None, nonstring='simplerepr'
    bytes_obj = to_bytes(binary_obj, encoding='utf-8', errors=None, nonstring='simplerepr')

    # Testing when obj is a text_type
    text_obj = "Python 2.7"
    # Calling to_bytes()

# Generated at 2022-06-24 20:57:36.955144
# Unit test for function to_native
def test_to_native():

    res = to_native(5)
    assert res == 5

    res = to_native('5')
    assert res == '5'

    res = to_native(u'5')
    assert res == u'5'



# Generated at 2022-06-24 20:57:41.710718
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foobar') == u'foobar'
    assert to_native(u'foobar') == u'foobar'
    assert to_native(42) == 42
    assert to_native(3.14) == 3.14
    expected_list = u'[42, 3.14]' if PY3 else u'[42, 3.14]'
    assert to_native([42, 3.14]) == expected_list
    expected_set = u'set([42, 3.14])' if PY3 else u'set([42, 3.14])'
    assert to_native(set([42, 3.14])) == expected_set
    expected_dict = u'{42: 3.14}' if PY3 else u'{42: 3.14}'

# Generated at 2022-06-24 20:57:52.625808
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('mensagem') == b'mensagem'
    assert to_bytes(b'dados') == b'dados'

    # Test that we can encode without touching the text
    assert to_bytes('mensagem') == b'mensagem'

    # Ensure we do touch the text if necessary,
    test_string = text_type('España, Français', encoding='utf8')
    assert to_bytes(test_string) != test_string

    # Ensure we take care of non-string types
    assert to_bytes(123, nonstring='empty') == b''
    assert to_bytes(dict(a=1), nonstring='simplerepr') == b"{'a': 1}"
    assert to_bytes(123, nonstring='passthru') == 123

    # Ensure we try to take care of

# Generated at 2022-06-24 20:57:59.069046
# Unit test for function to_native
def test_to_native():
    native_str = 'foo'
    expected = b'foo'
    actual = to_bytes(native_str)
    assert actual == expected, 'Expected: {}, Actual: {}'.format(expected, actual)


# Generated at 2022-06-24 20:58:00.404994
# Unit test for function jsonify
def test_jsonify():
    set_0 = set()
    var_0 = jsonify(set_0)



# Generated at 2022-06-24 20:58:05.347919
# Unit test for function jsonify
def test_jsonify():
    print(str(jsonify(set())))

if __name__ == '__main__':
    test_jsonify()

# Generated at 2022-06-24 20:58:12.457792
# Unit test for function to_native
def test_to_native():
    assert 'unicode' == to_native(u'string')
    assert 'str' == to_native('string')
    assert 'list' == to_native([])
    assert 'set' == to_native(set())
    assert 'dict' == to_native({})
    assert 'True' == to_native(True)
    assert 'False' == to_native(False)
    assert 'None' == to_native(None)
    assert 'int' == to_native(42)
    assert to_native(datetime.datetime.now())


# Generated at 2022-06-24 20:58:23.366912
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == '{}'
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': 'bar', 'baz': 'qux'}) == '{"foo": "bar", "baz": "qux"}'
    assert jsonify({'foo': 1, 'baz': 'qux'}) == '{"foo": 1, "baz": "qux"}'
    assert jsonify({'foo': {'bar': True}}) == '{"foo": {"bar": true}}'
    assert jsonify({'foo': range(5)}) == '{"foo": [0, 1, 2, 3, 4]}'
    foo = set(['foo'])
    bar = set(['bar'])

# Generated at 2022-06-24 20:58:31.680839
# Unit test for function to_bytes
def test_to_bytes():
    try:
        isinstance(to_bytes(1), binary_type)
        assert False
    except TypeError:
        assert True

    try:
        isinstance(to_bytes(1, nonstring='strict'), binary_type)
        assert False
    except TypeError:
        assert True

    assert isinstance(to_bytes(1, nonstring='passthru'), int)
    assert isinstance(to_bytes(1, nonstring='empty'), str)
    assert isinstance(to_bytes(1, nonstring='simplerepr'), str)

    try:
        isinstance(to_bytes(u'a', errors='foobar'), binary_type)
        assert False
    except LookupError:
        assert True


# Generated at 2022-06-24 20:58:38.842840
# Unit test for function to_native
def test_to_native():
    v = to_native({1: 2})
    assert type(v) == dict
    v = to_native(None)
    assert type(v) == str
    v = to_native([None])
    assert type(v) == list
    v = to_native([1, 2, 3])
    assert type(v) == list
    v = to_native("string")
    assert type(v) == str
    v = to_native(10)
    assert type(v) == int
    v = to_native(1.0)
    assert type(v) == float
    v = to_native(set([1, 2, 3]))
    assert type(v) == list
    v = to_native("string", encoding='utf-8')
    assert type(v) == str

# Generated at 2022-06-24 20:58:47.913192
# Unit test for function to_bytes
def test_to_bytes():
    # Getting value from sandboxed function
    var_0 = to_bytes(set())

    # Asserting value from sandboxed function
    print(var_0)


# Generated at 2022-06-24 20:58:49.073751
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('中文') == b'\xe4\xb8\xad\xe6\x96\x87'



# Generated at 2022-06-24 20:58:55.006485
# Unit test for function jsonify
def test_jsonify():
    set_0 = set()
    var_0 = jsonify(set_0)
    assert var_0 == '[]'


# Generated at 2022-06-24 20:58:57.375687
# Unit test for function jsonify
def test_jsonify():
    set_0 = set()
    var_0 = jsonify(set_0)
    assert type(var_0) == str



# Generated at 2022-06-24 20:59:07.502055
# Unit test for function jsonify
def test_jsonify():
    obj = {u'foo': u'bar'}
    # Test with posixly argument
    var_10 = jsonify(obj, **{'posixly': True})
    # Test with skip_key argument
    var_11 = jsonify(obj, **{'skip_key': True})
    # Test with skip_value argument
    var_12 = jsonify(obj, **{'skip_value': True})
    # Test with sort_keys argument
    var_13 = jsonify(obj, **{'sort_keys': True})
    # Test with indent argument
    var_14 = jsonify(obj, **{'indent': '    '})
    # Test with ensure_ascii argument
    var_15 = jsonify(obj, **{'ensure_ascii': True})
    # Test with separators argument

# Generated at 2022-06-24 20:59:18.419007
# Unit test for function to_native
def test_to_native():
    assert to_native('foo') is 'foo'
    assert to_native(u'bar') is 'bar'
    assert to_native(b'baz') is 'baz'
    assert to_native(u'baz') is 'baz'
    assert to_native(b'{"foo":"bar"}') == '{"foo":"bar"}'
    assert to_native(u'{"foo":"bar"}') == '{"foo":"bar"}'
    assert isinstance(to_native(1), int)
    assert isinstance(to_native(1.0), float)
    assert to_native(1.0) == 1.0
    assert isinstance(to_native(None), type(None))
    assert to_native(None) is None
    assert to_native(False) is False
    assert to_native(True)

# Generated at 2022-06-24 20:59:19.470214
# Unit test for function jsonify
def test_jsonify():
    test_case_0()
    

# Generated at 2022-06-24 20:59:22.640854
# Unit test for function jsonify
def test_jsonify():
    data = {"a": "b"}
    assert jsonify(data) == '{"a": "b"}'

if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-24 20:59:24.775702
# Unit test for function to_native
def test_to_native():
    assert to_native(True) == 'True'
    assert to_native(False) == 'False'


# Generated at 2022-06-24 20:59:26.969281
# Unit test for function jsonify
def test_jsonify():
    set_0 = set()
    var_0 = jsonify(set_0)


# Generated at 2022-06-24 20:59:34.995565
# Unit test for function jsonify
def test_jsonify():
    set_0 = set(['test'])
    var_0 = jsonify(set_0)

    assert('["test"]' == var_0)


# Generated at 2022-06-24 20:59:44.703338
# Unit test for function to_native
def test_to_native():
    # example 1
    print("pass-thru of text")
    test_str = "this is a string"
    assert to_native(test_str) == "this is a string"

    # example 2
    print("pass-thru of byte string")
    test_str = b"this is a byte string"
    assert to_native(test_str) == b"this is a byte string"

    # example 3
    print("pass-thru of unicode string")
    test_str = u"this is a unicode string"
    assert to_native(test_str) == u"this is a unicode string"

# Generated at 2022-06-24 20:59:45.636533
# Unit test for function to_native
def test_to_native():
    set_0 = set()
    var_0 = to_native(set_0)


# Generated at 2022-06-24 20:59:52.749156
# Unit test for function jsonify
def test_jsonify():
    set_0 = set()
    var_0 = jsonify(set_0)
    assert var_0 == '[]'

    set_1 = set()
    set_1.add('hello')
    var_1 = jsonify(set_1)
    assert var_1 == '["hello"]'

    set_2 = set()
    set_2.add('\u00e9')
    var_2 = jsonify(set_2)
    assert var_2 == '["é"]'

    set_3 = set()
    set_3.add('\u00e9')
    set_3.add('\u00e9')
    var_3 = jsonify(set_3)
    assert var_3 == '["é"]'


# Generated at 2022-06-24 20:59:54.279386
# Unit test for function jsonify
def test_jsonify():
    test_case_0()


# Generated at 2022-06-24 21:00:00.900953
# Unit test for function to_native
def test_to_native():
    dict_0 = {}
    dict_1 = {'f': 1}
    expect_str = '{}'
    expect_str_1 = '{"f": 1}'
    assert to_native(dict_0) == expect_str
    assert to_native(dict_1) == expect_str_1


# Generated at 2022-06-24 21:00:11.830956
# Unit test for function to_native

# Generated at 2022-06-24 21:00:19.019216
# Unit test for function to_bytes
def test_to_bytes():
    # Assume that the default encoding is utf-8
    # Test encoding in a text string
    assert to_bytes(u'Iñtërnâtiônàlizætiøn') == b'I\xc3\xb1t\xc3\xbbrn\xc3\xa2ti\xc3\xb4n\xc3\xa0liz\xc3\xa6ti\xc3\xb8n'
    # Test ascii strings
    assert to_bytes('ascii') == b'ascii'
    # Test encoding in a text string with an encoding other than utf-8

# Generated at 2022-06-24 21:00:25.824309
# Unit test for function to_bytes
def test_to_bytes():
    assert type(to_bytes('asdf')) is str
    assert type(to_bytes('asdf')) is str
    assert type(to_bytes('asdf')) is str
    assert type(to_bytes('asdf')) is str
    assert type(to_bytes('asdf')) is str
    assert type(to_bytes('asdf')) is str
    assert type(to_bytes('asdf')) is str
    assert type(to_bytes('asdf', encoding='asdf')) is str
    assert type(to_bytes('asdf', encoding='asdf')) is str
    assert type(to_bytes('asdf')) is str
    assert type(to_bytes('asdf', encoding='asdf')) is str
    assert type(to_bytes('asdf')) is str

# Generated at 2022-06-24 21:00:26.959458
# Unit test for function to_bytes
def test_to_bytes():
    test_0 = to_bytes('Test String')
    assert test_0 == b'Test String'


# Generated at 2022-06-24 21:00:33.843961
# Unit test for function jsonify
def test_jsonify():
    set_0 = set()
    var_0 = jsonify(set_0)


# Generated at 2022-06-24 21:00:45.649018
# Unit test for function jsonify
def test_jsonify():
    var_i = 0
    char_arr = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    num_arr = [chr(i) for i in range(0, 0xffff)]
    for char_i in range(0, 0xffff - len(char_arr)):
        char_arr.append(chr(char_i))
    set_0 = set(char_arr)
    set_1 = set(num_arr)
    map_0 = dict(zip(char_arr, num_arr))
    json_str_0 = jsonify(set_0)
    json_str_1 = jsonify(set_1)
   

# Generated at 2022-06-24 21:00:47.567687
# Unit test for function to_native
def test_to_native():
    __doc__ = """Test to_native function"""
    # assert function_call(var_0) == expected_0
    assert True == True



# Generated at 2022-06-24 21:00:50.504506
# Unit test for function jsonify
def test_jsonify():
    set_0 = set()
    var_0 = jsonify(set_0)
    check_variable_type(var_0, 'string')
    check_equal(var_0, '[]')


# Generated at 2022-06-24 21:01:01.193370
# Unit test for function to_native
def test_to_native():
    # Tests for function to_native
    import pytest

    with pytest.raises(TypeError):
        to_native(1, nonstring='badstring')

    with pytest.raises(TypeError):
        to_native(None, nonstring='badstring')

    assert to_native('{ "a": 1, "b": { "c": 2 } }') == {
        'a': 1,
        'b': {'c': 2}
    }
    assert to_native(u'{ "a": 1, "b": { "c": 2 } }') == {
        'a': 1,
        'b': {'c': 2}
    }

# Generated at 2022-06-24 21:01:13.979327
# Unit test for function to_native
def test_to_native():
    assert to_native(datetime.datetime(2017, 1, 31, 16, 53, 7, 873000, tzinfo=datetime.timezone.utc)) == "2017-01-31T16:53:07.873000Z"
    assert to_native(datetime.datetime(2017, 1, 31, 16, 53, 7, 873000)) == "2017-01-31T16:53:07.873000"
    assert to_native(datetime.datetime(2017, 1, 31, 16, 53, 7)) == "2017-01-31T16:53:07"
    assert to_native(datetime.time(16, 53, 7, 873000)) == "16:53:07.873000"

# Generated at 2022-06-24 21:01:15.713663
# Unit test for function to_bytes
def test_to_bytes():
    result = to_bytes('\xed\xb0\x80')
    assert result == b'\xed\xb0\x80'


# Generated at 2022-06-24 21:01:16.688284
# Unit test for function to_native
def test_to_native():
    assert(to_native(b'a') == 'a')


# Generated at 2022-06-24 21:01:26.210433
# Unit test for function jsonify
def test_jsonify():
    print("in test_jsonify")

    # Test case 0
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False


# line 102 "utils_text.py"

ANSIBLE_METADATA = {'metadata_version': '1.0',
                    'status': ['preview'],
                    'supported_by': 'community'}

# Hacky way of having access to object properties for evaluation
AVAILABLE_PROPERTIES = ["",]

# our imports go at the top so we fail fast.
from ansible.module_utils.basic import AnsibleModule



# Generated at 2022-06-24 21:01:27.951767
# Unit test for function to_native
def test_to_native():
    '''
    Docstring for method to_native
    '''
    pass


# Generated at 2022-06-24 21:01:43.004742
# Unit test for function to_native
def test_to_native():
    assert to_native('') == ''
    assert to_native(1) == 1
    assert to_native('ansible') == 'ansible'
    assert to_native(b'ansible', errors='surrogate_or_strict') == 'ansible'
    assert to_native('ansible', errors='surrogate_or_strict') == 'ansible'
    assert to_native('{"a": 1}') == '{"a": 1}'
    assert to_native(b'{"a": 1}', errors='surrogate_or_strict') == '{"a": 1}'
    #assert to_native(b'{"a": 1}', errors='surrogate_or_strict') == '{"a": 1}'

# Generated at 2022-06-24 21:01:43.956357
# Unit test for function jsonify
def test_jsonify():
    #TODO: Write test here
    pass


# Generated at 2022-06-24 21:01:48.841193
# Unit test for function to_bytes
def test_to_bytes():
    # Ensure that the return type is always bytes.
    assert isinstance(to_bytes(str_0), binary_type) == True
    # Ensure that the return type is always bytes
    # str text to utf-8 byte string
    str_1 = '\n        Docstring for method to_bytes\n    '
    assert to_bytes(str_1).decode('utf-8') == str_1
    # Ensure that the return type is always bytes
    # str text to utf-16 byte string
    str_2 = '\n        Docstring for method to_bytes\n    '
    assert (str_2).encode('utf-16') == to_bytes(str_2, encoding='utf-16') == str_2.encode('utf-16')
    # Ensure that the return type is always bytes
    # str text

# Generated at 2022-06-24 21:01:59.122614
# Unit test for function jsonify
def test_jsonify():
    str_0 = jsonify(_set_0)
    assert str_0 == "{\"__ansible_module_generated\": true}"
    str_0 = jsonify(_set_0, indent=2)
    assert str_0 == """{
  "__ansible_module_generated": true
}"""
    str_0 = jsonify(unicode_0)
    # assert str_0 == u'{"unicode_0": "\\u05d0"}'
    str_0 = jsonify(str_0)
    # assert str_0 == u'{"unicode_0": "\\u05d0"}'
    str_0 = jsonify(str_1)
    # assert str_0 == u'{"str_1": "\\u05d0"}'

# Generated at 2022-06-24 21:02:08.915282
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = '\n    Docstring for class type_check\n    '
    dict_2 = dict()
    str_3 = '\n    Docstring for class generic_msg\n    '
    str_4 = '\n    Docstring for function to_text\n    '
    str_5 = '\n    Docstring for class AnsibleFailJson\n    '
    str_6 = '\n    Docstring for class AnsibleTimeoutExceeded\n    '
    str_7 = '\n    Docstring for class AnsibleConnectionFailure\n    '
    str_8 = '\n    Docstring for class AnsibleError\n    '

# Generated at 2022-06-24 21:02:20.236839
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(str_0) == b'\n    Docstring for method to_native\n    '
    assert to_bytes(b'text') == b'text'
    assert to_bytes(u'text') == b'text'
    assert to_bytes(b'text', 'latin-1') == b'text'
    assert to_bytes(u'text', 'latin-1') == b'text'
    assert to_bytes(u'\xFF') == b'\xFF'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u263a') == b'\xe2\x98\xba'

# Generated at 2022-06-24 21:02:21.929448
# Unit test for function to_native
def test_to_native():
    assert test_case_0() == '\n    Docstring for method to_native\n    '



# Generated at 2022-06-24 21:02:31.847180
# Unit test for function to_native
def test_to_native():
    str_0 = '\n    Docstring for method to_native\n    '

# Generated at 2022-06-24 21:02:42.664060
# Unit test for function to_native
def test_to_native():
    str_0 = '\n    Docstring for method to_native\n    '

# Generated at 2022-06-24 21:02:53.170247
# Unit test for function to_native
def test_to_native():
    str_0 = '\n    Docstring for method to_native\n    '
    str_0 = str_0.split('\n')
    str_0 = [x.lstrip() for x in str_0]
    var_0 = {y.split(': ', 1)[0]: y.split(': ', 1)[1] for y in [x for x in str_0 if x.strip()]}
    str_1 = var_0['returns']
    str_1 = str_1.split(', ')
    var_1 = [x.split(' ', 1)[1] for x in str_1]
    str_0 = str(to_native('xyz'))

# Generated at 2022-06-24 21:03:04.751193
# Unit test for function jsonify

# Generated at 2022-06-24 21:03:05.897756
# Unit test for function to_native
def test_to_native():
    # For now, just check that this compiles
    native = to_native('foob', 'utf-8')


# Generated at 2022-06-24 21:03:16.393572
# Unit test for function jsonify
def test_jsonify():
    my_dict = {
        "foo": 1,
        "bar": "hello",
        "baz": [1, 2, 3],
        "quux": {
            "quuz": "quuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuz",
            "grault": "12345687901234567890123456789012345678901234567890",
        },
    }
    encoded = jsonify(my_dict)
    decoded = json.loads(encoded)
    assert isinstance(decoded["quux"], dict)
    assert isinstance(decoded["baz"], list)
    assert isinstance(decoded["bar"], basestring)
    assert isinstance(decoded["foo"], int)
    return True

# Generated at 2022-06-24 21:03:18.204400
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'foob'
    assert to_bytes(str_0) == 'foob'


# Generated at 2022-06-24 21:03:27.997028
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'foob'

    assert(to_bytes(str_0) == b'foob')
    # Testing for overflow exception
    # Issue #4807

# Generated at 2022-06-24 21:03:33.141351
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'foob'
    assert to_bytes(str_0) == b'foob'



# Generated at 2022-06-24 21:03:33.722849
# Unit test for function to_native
def test_to_native():
    pass


# Generated at 2022-06-24 21:03:45.369021
# Unit test for function to_bytes
def test_to_bytes():
    text_inputs = [u'foobar', u'\xe4\xf6\xfc',
        b'ascii',  # Python 2.7 treats this as a text string
        # Python 3 treats this as a binary string
        bytearray(b'binary'),
        b'\xe4\xf6\xfc']

    if not PY3:
        text_inputs.append(b'ascii')
        text_inputs.append(bytearray(b'binary'))

    binary_inputs = [b'ascii', bytearray(b'binary'),
        u'ascii',  # Python 2.7 treats this as a text string
        # Python 3 treats this as a binary string
        u'binary']


# Generated at 2022-06-24 21:03:51.957056
# Unit test for function to_native
def test_to_native():
    var_0 = to_native('hello world')
    assert(var_0 == 'hello world')

    var_1 = to_native(12)
    assert(var_1 == 12)

    var_2 = to_native(set((1, 2, 3, 4)))
    assert(var_2 == set((1, 2, 3, 4)))

    var_3 = to_native(datetime.datetime.now())
    assert(isinstance(var_3, str))

    var_4 = to_native(bytearray(b'\x01\x03'))
    assert(var_4 == '\x01\x03')

    var_5 = to_native('\xc3\xbc')
    assert(var_5 == '\xc3\xbc')


# Generated at 2022-06-24 21:04:01.479712
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'foob'
    var_0 = to_bytes(str_0)
    assert type(var_0) == type(('',))  # ensure it is a byte string

    # Binary string
    assert to_bytes(b'foobar') == b'foobar'

    # Unicode string
    assert to_bytes(u'foobar') == b'foobar'
    assert to_bytes(u'привет') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Unicode with surrogates
    assert to_bytes(u'\udc80\udc01') == b'\xed\xb2\x80\xed\xb3\x81'

    #

# Generated at 2022-06-24 21:04:09.990056
# Unit test for function jsonify
def test_jsonify():
    obj = {1: 2, 3: 4}
    ret = jsonify(obj)


# Generated at 2022-06-24 21:04:15.005773
# Unit test for function jsonify
def test_jsonify():
    try:
        data_arg_0 = [1, 2, 3, {'a': 1, 'b': 2, 'c': 3}, 'a']
        kwargs_0 = {'sort_keys': True}
        jsonify(data_arg_0, **kwargs_0)
    except Exception as e:
        print('Exception:', e)
    else:
        raise Exception('Expected an exception')



# Generated at 2022-06-24 21:04:15.888808
# Unit test for function to_bytes
def test_to_bytes():
    to_bytes(1)



# Generated at 2022-06-24 21:04:19.186208
# Unit test for function jsonify
def test_jsonify():
    pass


# Generated at 2022-06-24 21:04:23.386733
# Unit test for function to_bytes
def test_to_bytes():
    assert(to_bytes('hello') == b'hello')
    assert(to_bytes(b'\xff', errors='surrogateescape') == b'\xff')
    assert(to_bytes(b'\xff'.decode('utf8', 'surrogateescape'), errors='surrogateescape') == b'\xff')


# Generated at 2022-06-24 21:04:23.974880
# Unit test for function to_bytes
def test_to_bytes():
    test_case_0()


# Generated at 2022-06-24 21:04:30.101359
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'foob'
    str_1 = 'utf-8'
    str_2 = 'strict'
    str_3 = 'simplerepr'
    bytes_0 = b'foob'
    bytes_1 = b'utf-8'
    bytes_2 = b'strict'
    bytes_3 = b'simplerepr'
    assert bytes_0 == to_bytes(str_0)
    assert bytes_1 == to_bytes(str_1)
    assert bytes_2 == to_bytes(str_2)
    assert bytes_3 == to_bytes(str_3)


# Generated at 2022-06-24 21:04:36.463264
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'foob'
    var_0 = to_bytes(str_0)



# Generated at 2022-06-24 21:04:38.370861
# Unit test for function to_native
def test_to_native():
    str_0 = 'foob'
    var_0 = to_native(str_0)


# Generated at 2022-06-24 21:04:48.588918
# Unit test for function jsonify

# Generated at 2022-06-24 21:05:01.406857
# Unit test for function to_native
def test_to_native():
    str_0 = 'foob'
    var_0 = to_bytes(str_0)
    assert var_0 == 'foob'
    str_1 = 'foob'
    var_1 = to_bytes(str_1, nonstring='passthru')
    assert var_1 == 'foob'
    str_2 = 'foob'
    var_2 = to_bytes(str_2, nonstring='strict')



# Generated at 2022-06-24 21:05:05.791765
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'foob'
    var_0 = to_bytes(str_0)
    assert var_0 == 'foob'


# Generated at 2022-06-24 21:05:08.037592
# Unit test for function to_native
def test_to_native():
    str_0 = 'foob'
    var_0 = to_native(str_0)



# Generated at 2022-06-24 21:05:18.228757
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common._collections_compat import Set

    not_encodable = Set([u'Bj\xf6rk Gu\xf0mundsd\xf3ttir'])

    # Pass a simple unicode string through
    assert jsonify(u'"\u2713"') == '"\\"\\\\u2713\\""'
    # Pass a complex structure

# Generated at 2022-06-24 21:05:20.668210
# Unit test for function to_bytes
def test_to_bytes():
    # This is just a sample test set, some cases are already covered in other test sets.
    var_0 = b'foob'
    to_bytes(var_0)
    # FIXME: add additional tests


# Generated at 2022-06-24 21:05:24.607136
# Unit test for function jsonify
def test_jsonify():
    data = {"test_key": "test_value"}
    assert jsonify(data) == '{"test_key": "test_value"}'


# Generated at 2022-06-24 21:05:30.727244
# Unit test for function jsonify
def test_jsonify():
    data_0 = {'bad': 'a\x80z'}
    results_0 = jsonify(data_0)
    assert results_0 == '{"bad": "a\\u0080z"}'

    data_1 = {'bad': 'a\x80z'}
    results_1 = jsonify(data_1)
    assert results_1 == '{"bad": "a\\u0080z"}'

    data_2 = {'bad': 'a\x80z'}
    results_2 = jsonify(data_2)
    assert results_2 == '{"bad": "a\\u0080z"}'


# Generated at 2022-06-24 21:05:34.596770
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'foob'
    var_0 = to_bytes(str_0)
    str_1 = 'foob'
    var_1 = to_bytes(str_1)
    str_2 = 'foob'
    var_2 = to_bytes(str_2)
    str_3 = 'foob'
    var_3 = to_bytes(str_3)


# Generated at 2022-06-24 21:05:40.460639
# Unit test for function jsonify
def test_jsonify():
    list_0 = [1, '2']
    dict_0 = {'a': 1, 'b': 2, 'c': 3}
    # Test jsonify()
    msg = 'Expected %s, but got %s' % (to_native(test_dict), to_native(res_json))
    assertEqual(test_json, res_json, msg)


# Generated at 2022-06-24 21:05:43.838367
# Unit test for function jsonify
def test_jsonify():
    run_jsonify_0()
    run_jsonify_1()
    run_jsonify_2()

# ----------------------------------------------------------------------------
# Tests for '_json_encode_fallback'
# ----------------------------------------------------------------------------

# Test for function _json_encode_fallback

# Generated at 2022-06-24 21:05:52.716273
# Unit test for function to_native
def test_to_native():
    """
    to_native is a shim around to_text, ensuring the result is always a unicode string.
    """
    native = to_native(u'\u2019')
    assert type(native) == unicode


# Generated at 2022-06-24 21:05:58.164734
# Unit test for function to_native
def test_to_native():
    var_0 = to_bytes('foob')
    var_1 = to_text('foob')
    var_2 = to_text(1)
    var_3 = to_bytes(datetime.datetime.now())
    var_4 = to_bytes('foob')
    var_5 = to_text('foob')
    var_6 = to_text(1)
    var_7 = to_bytes(datetime.datetime.now())
    var_8 = to_text('foob')
    var_9 = to_bytes('foob')
    var_10 = to_text(1)
    var_11 = to_bytes(datetime.datetime.now())
    var_12 = to_bytes('foob')
    var_13 = to_text('foob')

# Generated at 2022-06-24 21:06:09.940265
# Unit test for function to_native
def test_to_native():
   assert to_native('foo bar') == 'foo bar'
   assert to_native(u'foo bar') == 'foo bar'
   assert to_native('bar', encoding='utf-8') == 'bar'
   assert to_native('bar'.encode('utf-8'), encoding='utf-8') == 'bar'
   assert to_native(None) is None
   assert to_native(42) == 42
   assert to_native([1,2,3]) == [1,2,3]
   assert to_native({'hello': 'world'}) == {'hello': 'world'}
   assert to_native(dict(foo='bar')) == dict(foo='bar')
   assert to_native(Set([1,2,3])) == Set([1,2,3])


# Generated at 2022-06-24 21:06:15.246710
# Unit test for function to_bytes
def test_to_bytes():
    str_0 = 'foob'
    var_0 = to_bytes(str_0)
    assert var_0 == b'foob'