

# Generated at 2022-06-22 22:01:49.507494
# Unit test for function to_bytes
def test_to_bytes():
    def tb_bytes(obj, encoding='utf-8', errors=None, nonstring='simplerepr'):
        return to_bytes(obj, encoding, errors, nonstring)

    assert tb_bytes(u'foo') == b'foo'
    assert tb_bytes(u'foo', encoding='latin-1') == b'foo'
    assert tb_bytes(u'fó') == b'f\xc3\xb3'
    assert tb_bytes(u'fó', encoding='latin-1', errors='ignore') == b'f'
    assert tb_bytes(u'fó') == b'f\xc3\xb3'
    assert tb_bytes(u'fó', encoding='latin-1') == b'f\xf3'

# Generated at 2022-06-22 22:02:01.883010
# Unit test for function to_native
def test_to_native():
    PY3 = sys.version_info[0] == 3
    if PY3:
        string_types = (str,)
    else:
        string_types = (str, unicode)

    nonstring_types = (set, dict, list, int, float, tuple, bool)

    for nonstring in nonstring_types:
        for errors in (None, 'surrogate_or_replace', 'surrogate_then_replace'):
            for test_value in (-1, 1.1, 'foo', nonstring([1, 2]), "\u2222"):
                assert isinstance(to_native(test_value, errors=errors), str)
                # If we're using a custom error handler, we'll get a
                # binary_type.

# Generated at 2022-06-22 22:02:14.884228
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test unicode input
    value = u"je me souviens"
    assert container_to_bytes(value) == to_bytes(value)
    assert container_to_bytes(value, encoding='latin-1') == to_bytes(value, encoding='latin-1')
    assert container_to_bytes(value, errors='replace') == to_bytes(value, errors='replace')

    # Test byte string input, note this should be unchanged
    value = to_bytes(value)
    assert container_to_bytes(value) == to_bytes(value)
    assert container_to_bytes(value, encoding='latin-1') == to_bytes(value, encoding='latin-1')
    assert container_to_bytes(value, errors='replace') == to_bytes(value, errors='replace')

    # Test mixed input

# Generated at 2022-06-22 22:02:18.676217
# Unit test for function to_native
def test_to_native():
    assert u'test' == to_native(u'test')
    if PY3:
        assert 'test' == to_native(b'test')
    else:
        assert u'test' == to_native(b'test')



# Generated at 2022-06-22 22:02:21.449781
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text({u"abc" : 1, u"": u"", u"xyz": u"\udcf9"}) == {u"abc" : 1, u"": u"", u"xyz": u"\udcf9"}
    assert container_to_text({u"abc" : 1, u"": u"", u"xyz": b"\xed\xb3\xa9"}) == {u"abc" : 1, u"": u"", u"xyz": u"\udcf9"}



# Generated at 2022-06-22 22:02:34.136889
# Unit test for function jsonify
def test_jsonify():
    if PY3:
        assert jsonify('foo') == '"foo"'
        assert jsonify('foo'.encode()) == '"foo"'
        assert jsonify(['foo', 'bar']) == '["foo", "bar"]'
        assert jsonify(['foo', 'bar'.encode()]) == '["foo", "bar"]'
        assert jsonify({'foo': 'bar', 'baz': 'qux'}) == '{"foo": "bar", "baz": "qux"}'
        assert jsonify({'foo': 'bar', 'baz': 'qux'.encode()}) == '{"foo": "bar", "baz": "qux"}'
    else:
        assert jsonify('foo') == '"foo"'
        assert jsonify(b'foo') == '"foo"'

# Generated at 2022-06-22 22:02:44.807671
# Unit test for function container_to_bytes
def test_container_to_bytes():
    import json

    text_keys = [to_text(b'key_%03d' % i, 'ascii') for i in range(100)]
    text_values = [to_text(b'value_%03d' % i, 'ascii') for i in range(100)]
    d = dict(zip(text_keys, text_values))
    d_bytes = container_to_bytes(d, errors='surrogate_or_strict')
    d_bytes_str = json.dumps(d_bytes)
    d_str = json.dumps(d)

    assert d_str == d_bytes_str

    d_bytes_surrogateescape = container_to_bytes(d, errors='surrogateescape')

    assert d_bytes_surrogateescape == d_bytes

    non_

# Generated at 2022-06-22 22:02:56.723868
# Unit test for function to_native
def test_to_native():
    # Valid utf-8 byte string
    assert to_native(b'\xc3\x96sterreich') == 'Österreich'
    assert to_native(b'\xc3\x96sterreich', keep_wrappers=True) == b'\xc3\x96sterreich'

    # Invalid utf-8 byte string
    assert to_native(b'\xc3\x96sterrei') == 'Ãsterrei'
    assert to_native(b'\xc3\x96sterrei', keep_wrappers=True) == b'\xc3\x96sterrei'

    # Valid utf-8 byte string with surrogateescape error handler
    assert to_native(b'\xc3\x96sterreich', errors='surrogateescape') == 'Österreich'

# Generated at 2022-06-22 22:03:08.542267
# Unit test for function container_to_bytes
def test_container_to_bytes():
    py2_strings = {u'foo': b'bar', u'baz': u'bar'}
    assert py2_strings == container_to_bytes(py2_strings)

    py2_unicode_strings = {u'foo': u'bar', u'baz': b'bar'}
    assert py2_unicode_strings == container_to_bytes(py2_unicode_strings)

    # to_bytes should encode b'foo' to 'foo'
    assert u'foo' == to_bytes(u'foo')

    # container_to_bytes should encode b'foo' to 'foo'
    py2_bytes = {u'foo': b'bar', u'baz': b'bar'}
    assert py2_bytes == container_to_bytes(py2_bytes)

    # to_bytes

# Generated at 2022-06-22 22:03:18.842261
# Unit test for function container_to_bytes
def test_container_to_bytes():
    dict_in = {u'unicode': u'bytes', u'unicode \u2665': u'bytes \xb5',
               u'unicode bytes': u'bytes bytes'}
    dict_out = {'unicode': 'bytes', 'unicode \xe2\x99\xa5': 'bytes \xb5',
                'unicode bytes': 'bytes bytes'}
    assert container_to_bytes(dict_in) == dict_out
    list_in = [u'unicode', [u'unicode \u2665', u'unicode bytes']]
    list_out = ['unicode', ['unicode \xe2\x99\xa5', 'unicode bytes']]
    assert container_to_bytes(list_in) == list_out

# Generated at 2022-06-22 22:03:29.559631
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # simple test for dict
    d = {'a': 'b', 'c': {'d': 'e'},'f':[1,2]}
    dd = container_to_bytes(d)
    assert(isinstance(dd['a'], binary_type))
    assert(isinstance(dd['c'], dict))
    assert(isinstance(dd['f'], list))

    # simple test for list
    d = ['a', 'b', 'c', {'d': 'e'}]
    dd = container_to_bytes(d)
    assert(isinstance(dd[0], binary_type))
    assert(isinstance(dd[3], dict))

    # simple test for tuple
    d = ('a', 'b', 'c', {'d': 'e'})

# Generated at 2022-06-22 22:03:42.587296
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # The json return function adds an ansible_facts key to the return dict
    # if ansible_facts is specified.  This is a tuple in a dict.
    # This list is made up of dict, list and tuples.
    # This covers the same structure as the json return function
    a = {
        u'test': u'value',
        u'foo': [1, 2, 3],
        u'bar': {
            u'ink': u'blot',
            u'lot': [7, 8, 9]
        },
        u'ansible_facts': {
            u'bob': [u'alice', u'frank']
        },
    }

# Generated at 2022-06-22 22:03:49.395686
# Unit test for function to_native
def test_to_native():
    """
    Basic sanity check that to_native does it's job.
    """
    # Things that should stay the same
    truth_table = (
        (u"hello", u"hello"),
        (b"hello", b"hello"),
        (5, 5),
        ({"a": "b"}, {"a": "b"}),
    )
    # Ensure that the basic table works
    for arg, arg_truth in truth_table:
        arg_return = to_native(arg)
        assert arg_return == arg_truth


# Generated at 2022-06-22 22:03:59.889693
# Unit test for function jsonify
def test_jsonify():
    # Test valid input
    assert jsonify([u'str', u'\u1234', u'\uefef']) == json.dumps(['str', '\u1234', '\uefef'])
    assert jsonify({u'str': u'\u1234'}) == json.dumps({'str': '\u1234'})
    # Test latin-1 input, this will fail with the default UTF-8
    # assert jsonify([b'\xff', b'\xfe']) == json.dumps([u'\u00ff', u'\u00fe'])
    # Test mixed input, encoding gets applied to values, not keys

# Generated at 2022-06-22 22:04:11.867312
# Unit test for function container_to_text
def test_container_to_text():
    # unicode test
    unicode_data = u'\u540d\u5b57'
    assert unicode_data == container_to_text(container_to_bytes(unicode_data))
    # str test
    str_data = '你好'
    assert str_data == container_to_text(container_to_bytes(str_data))
    # list test
    list_data = [u'\u540d\u5b57', '你好', {'你好': '你好'}]
    assert list_data == container_to_text(container_to_bytes(list_data))
    # tuple test

# Generated at 2022-06-22 22:04:23.281746
# Unit test for function to_native
def test_to_native():
    for nonstring in (None, 'simplerepr', 'passthru', 'strict'):
        for obj in (u'foo', b'foo', 42, Exception('boom')):
            if nonstring == 'strict':
                if not isinstance(obj, (text_type, binary_type)):
                    # Strict wants only text or bytes
                    try:
                        to_native(obj, nonstring=nonstring)
                    except TypeError:
                        pass
                    else:
                        raise AssertionError('to_native(%r, nonstring=%r) '
                                             'should have failed' % (obj, nonstring))
                    continue
            value = to_native(obj, nonstring=nonstring)

# Generated at 2022-06-22 22:04:35.026413
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Passing different kind of containers
    assert container_to_bytes('str') == b'str'
    assert container_to_bytes({'foo': 'bar'}) == {b'foo': b'bar'}
    assert container_to_bytes(['foo', 'bar']) == [b'foo', b'bar']
    assert container_to_bytes(('foo', 'bar')) == (b'foo', b'bar')

    # Passing non-container objects
    assert container_to_bytes(1234) == 1234
    assert container_to_bytes(None) is None

    # passing non ASCII data
    class test: pass
    obj = test()
    obj.foo = '\u4321'
    assert container_to_bytes('\u1234') == b'\xe1\x88\xb4'

# Generated at 2022-06-22 22:04:38.761431
# Unit test for function jsonify
def test_jsonify():
    if PY3:
        assert jsonify('føø') == '"føø"'
    else:
        assert jsonify('føø') == u'"føø"'


# Generated at 2022-06-22 22:04:46.241376
# Unit test for function container_to_text
def test_container_to_text():
    data = {
        u'key': [u'value', {u'foo': u'bar'}]
    }
    b_data = container_to_bytes(data)
    assert isinstance(b_data['key'][0], binary_type)
    t_data = container_to_text(b_data)
    assert isinstance(t_data['key'][0], text_type)
    assert t_data == data



# Generated at 2022-06-22 22:04:53.423586
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'\xe9'.encode('utf-8')) == u'\xe9'
    assert to_native(u'\u9433'.encode('utf-16')) == u'\u9433'.encode('utf-16')
    assert to_native(u'foo'.encode('latin-1')) == u'foo'
    assert to_native(u'\xe9'.encode('latin-1')) == u'\xe9'
    assert to_native(u'\u9433'.encode('utf-16')) == u'\u9433'.encode('utf-16')
    assert to

# Generated at 2022-06-22 22:05:02.161732
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert 'foo' == container_to_bytes('foo')
    assert b'foo' == container_to_bytes(b'foo')
    assert 'foo' == container_to_bytes('foo', encoding='latin-1')
    assert b'foo' == container_to_bytes(b'foo', encoding='latin-1')

    # non strings should pass through
    assert 1 == container_to_bytes(1)
    assert 1.1 == container_to_bytes(1.1)

    # Dicts
    assert {b'foo': 'foo'} == container_to_bytes({'foo': 'foo'})
    assert {b'foo': 1} == container_to_bytes({'foo': 1})

    # Lists
    assert [b'foo'] == container_to_bytes(['foo'])
    assert ['foo']

# Generated at 2022-06-22 22:05:08.330809
# Unit test for function to_native
def test_to_native():
    assert to_native('passed') == 'passed'
    assert to_native(u'passed') == 'passed'
    assert to_native(u'\xa2') == u'\xa2'
    try:
        to_native(u'\uffff')
        assert False, 'to_native() correctly handled an out of range unicode string'
    except UnicodeEncodeError:
        pass

# Generated at 2022-06-22 22:05:17.459232
# Unit test for function container_to_text
def test_container_to_text():
    """test module"""
    # pylint: disable=missing-docstring
    def check_container_to_text(data, expected, encoding='utf-8', errors='surrogate_or_strict',
                                nonstring='simplerepr'):
        """test helper"""
        results = container_to_text(data, encoding=encoding, errors=errors, nonstring=nonstring)
        assert result == expected

    def check_container_to_text_fails(data, encoding='utf-8', errors='surrogate_or_strict',
                                      nonstring='simplerepr'):
        """test helper"""
        try:
            result = container_to_text(data, encoding=encoding, errors=errors, nonstring=nonstring)
            assert not result
        except UnicodeDecodeError:
            pass

   

# Generated at 2022-06-22 22:05:28.549571
# Unit test for function to_native
def test_to_native():
    assert to_native('s', encoding='ascii') == b's'
    assert to_native(b'\xe2\x99\xa5') == u'\u2665'
    assert to_native('s') == u's'
    assert to_native(u's') == u's'
    assert to_native(u'\u2665') == u'\u2665'
    # Unicode is the default encoding for Python 3
    if PY3:
        assert to_native(b'\xe2\x99\xa5') == u'\u2665'
    else:
        # Strings in Python 2 are bytestrings by default, we have to tell it to decode
        assert to_native(b'\xe2\x99\xa5', encoding='utf-8') == u'\u2665'


# Generated at 2022-06-22 22:05:39.981596
# Unit test for function container_to_bytes
def test_container_to_bytes():
    class foo(object):
        def __repr__(self):
            return 'Hello World'

    assert container_to_bytes('Hello World') == b'Hello World'
    assert container_to_bytes(u'Hello World') == b'Hello World'
    assert container_to_bytes({u'Hello World': b'Hello World'}) == {b'Hello World': b'Hello World'}
    assert container_to_bytes({u'Hello World': [u'Hello World', b'Hello World']}) == {b'Hello World': [b'Hello World', b'Hello World']}
    assert container_to_bytes([u'Hello World', b'Hello World']) == [b'Hello World', b'Hello World']

# Generated at 2022-06-22 22:05:50.419086
# Unit test for function to_bytes
def test_to_bytes():
    try:
        codecs.lookup_error('surrogateescape')
        HAS_SURROGATEESCAPE = True
    except LookupError:
        HAS_SURROGATEESCAPE = False

    # Test surrogateescape
    if HAS_SURROGATEESCAPE:
        assert to_bytes('{"a": "\udc80"}', 'utf-8', errors='surrogateescape') == b'{"a": "\udc80"}'
        assert to_bytes('{"a": "\udc80"}', 'utf-8', errors='surrogate_or_strict') == b'{"a": "\udc80"}'
        assert to_bytes('{"a": "\udc80"}', 'utf-8', errors='surrogate_or_replace') == b'{"a": "\udc80"}'
       

# Generated at 2022-06-22 22:05:53.529219
# Unit test for function to_native
def test_to_native():
     """
     :return: Pass if True
     """
     res = to_native('{"key": "value"}')
     assert res == json.loads('{"key": "value"}')

# Generated at 2022-06-22 22:06:02.067178
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('{"a": "b"}') == '{"a": "b"}'
    assert jsonify(u'{"a": "b"}') == '{"a": "b"}'
    assert jsonify(u'{"a": "b\u20ac"}') == '{"a": "b\u20ac"}'
    assert jsonify(u'{"a": "b\u20ac"}', ensure_ascii=False) == u'{"a": "b\u20ac"}'
    assert jsonify({"a": "b\u20ac"}) == '{"a": "b\u20ac"}'
    assert jsonify({"a": "b\u20ac"}, ensure_ascii=False) == u'{"a": "b\u20ac"}'

# Generated at 2022-06-22 22:06:10.595795
# Unit test for function to_native
def test_to_native():
    assert to_native(None) is None
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == b'foo'
    assert to_native(u'\xc3\xb1') == u'\xc3\xb1'
    assert to_native(b'\xc3\xb1') == u'\xf1'
    assert to_native(1) == 1
    assert to_native([]) == []
    assert to_native([u'\xc3\xb1', b'\xc3\xb1']) == [u'\xc3\xb1', b'\xc3\xb1']


# Unit tests for function to_text

# Generated at 2022-06-22 22:06:17.276827
# Unit test for function jsonify
def test_jsonify():
    # Test input data that is already safe
    data1 = {b"foo": b"bar", b"baz": b"qux"}
    assert b'{"baz": "qux", "foo": "bar"}' == jsonify(data1)
    data2 = {b"foo": u"bar", b"baz": u"qux"}
    assert b'{"baz": "qux", "foo": "bar"}' == jsonify(data2)

    # Test input data that needs encoding
    data3 = {u"foo": u"bar", u"baz": u"qux"}
    assert b'{"baz": "qux", "foo": "bar"}' == jsonify(data3)
    data4 = {u"foo": b"bar", u"baz": b"qux"}
    assert b

# Generated at 2022-06-22 22:06:28.809756
# Unit test for function to_bytes
def test_to_bytes():
    class Foo(object):
        def __str__(self):
            return u'foo'
        def __repr__(self):
            return u'repr(foo)'

    foo = Foo()

    # Non-string tests
    assert u'foo'.encode('utf-8') == to_bytes(foo)
    assert b'' == to_bytes(foo, nonstring='empty')
    assert foo == to_bytes(foo, nonstring='passthru')
    try:
        to_bytes(foo, nonstring='strict')
    except TypeError:
        pass
    else:
        raise AssertionError('to_bytes(foo, nonstring=\'strict\') did not raise TypeError')

    # Python2-only tests
    # Can't decode utf-16 in python2

# Generated at 2022-06-22 22:06:32.721361
# Unit test for function to_native
def test_to_native():
    assert to_native(to_text('foo')) == to_native(u'foo') == 'foo'
    assert to_native(to_bytes('foo')) == 'foo'
    assert to_native(1) == '1'
    assert to_native(Exception('foo')) == 'foo'



# Generated at 2022-06-22 22:06:35.201359
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1)) == '{"a": 1}'



# Generated at 2022-06-22 22:06:45.423530
# Unit test for function jsonify
def test_jsonify():
    if PY3:
        assert jsonify(u'sp\xe4m') == '"sp\\xe4m"'
    else:
        assert jsonify(u'sp\xe4m') == '"sp\xe4m"'
    assert jsonify({'sp\xe4m': 'eggs'}) == '{"sp\\xe4m": "eggs"}'
    assert jsonify({'sp\xe4m': [1, 2]}) == '{"sp\\xe4m": [1, 2]}'
    assert jsonify(set([1, 2])) == '[1, 2]'
    assert jsonify(datetime.datetime(2014, 5, 10, 16, 22, 23, 12345)) == '"2014-05-10T16:22:23.012345"'

# Generated at 2022-06-22 22:06:51.318172
# Unit test for function jsonify
def test_jsonify():
    dict_ = {
        'fo\xc3\xb6': 'bar',
        'bo\xc3\xb6z': [1, 2, {'three': 'quatro'}],
        'novalue': None,
    }
    data = jsonify(dict_)
    dict2 = json.loads(data)
    assert dict_ == dict2



# Generated at 2022-06-22 22:06:58.626958
# Unit test for function to_native
def test_to_native():
    """
    Ensure that all kinds of input are properly coerced to a native string
    """
    class myunicode(text_type):
        pass

    class mybytes(binary_type):
        pass

    class myint(int):
        pass

    class mycomplex(complex):
        pass

    class mydict(dict):
        pass

    class mylist(list):
        pass

    assert to_native(u'foo') == 'foo'
    assert to_native('foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(1.2) == '1.2'
    assert to_native(True) == 'True'
    assert to_native(myunicode('foo')) == 'foo'
    assert to

# Generated at 2022-06-22 22:07:03.573155
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native

    assert to_native('Test') == 'Test'
    assert to_native(b'Test') == 'Test'
    assert to_native(u'Test') == 'Test'
    assert to_native(2) == u'2'

# Generated at 2022-06-22 22:07:09.433909
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foobar') == u'foobar'
    assert to_native(u'\xf6') == u'\xf6'

    assert to_native('foobar') == u'foobar'
    assert to_native('\xf6') == u'\xf6'
    assert to_native('\xf6', errors='surrogate_or_strict') == u'\udcf6'



# Generated at 2022-06-22 22:07:20.152328
# Unit test for function container_to_bytes
def test_container_to_bytes():

    class Boo:
        def __init__(self, b_string):
            self.b_string = b_string

    assert container_to_bytes(Boo(b'foo')) == Boo(b'foo')
    assert container_to_bytes(Boo(u'foo')) == Boo(b'foo')
    assert container_to_bytes(Boo(b'foo'), nonstring='passthru') == Boo(b'foo')
    assert container_to_bytes(Boo(b'foo'), nonstring='passthru', encoding='ascii') == Boo(b'foo')
    assert container_to_bytes(Boo(u'foo'), nonstring='passthru') == Boo(b'foo')

# Generated at 2022-06-22 22:07:29.033175
# Unit test for function to_bytes
def test_to_bytes():
    # The functions should raise exceptions if we're given incorrect types
    def inner_test_exceptions(bad_type, encoding, errors):
        if bad_type is None:
            with pytest.raises(TypeError):
                to_bytes(None, encoding, errors)
        else:
            with pytest.raises(TypeError):
                to_bytes(bad_type(None), encoding, errors)

    # Test for all permutations of:
    # 1) An encoding to use (default of utf-8, latin-1, and None)
    # 2) An encoding error handler (default of surrogate_then_replace, surrogate_or_replace,
    #    surrogate_or_strict, strict, ignore, and replace)
    # 3) A type to test that is not a string (default of None, int, float, and list)

# Generated at 2022-06-22 22:07:36.166372
# Unit test for function to_native
def test_to_native():
    b_ascii_string = b'foobar'
    ascii_string = u'foobar'
    utf8_string = u'fööbar'
    utf8_b_string = b'f\xc3\xb6\xc3\xb6bar'
    cp1252_b_string = b'f\xf6\xf6bar'
    cp1252_string = u'fööbar'
    # cp1252_surrogate = u'f\udc3cööbar'  # cp1252:f = \udc3c = 타
    # utf8_surrogate = u'f\udc3cööbar'
    # utf8_b_surrogate = b'f\xed\xb0\xbc\xf6\xf

# Generated at 2022-06-22 22:07:47.988807
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_dict = {1:2, 3:4, 5:{'a':6, 'b':7}, 8:9}
    assert container_to_bytes(test_dict) == test_dict
    test_dict_unicode_key = {u'\u9f20':2, 3:4, 5:{'a':6, 'b':7}, 8:9}
    assert container_to_bytes(test_dict_unicode_key) == {b'\xe9\xbc\xa0':2, 3:4, 5:{b'a':6, b'b':7}, 8:9}
    test_dict_unicode_value = {1:u'\u9f20', 3:4, 5:{'a':6, 'b':7}, 8:9}

# Generated at 2022-06-22 22:07:59.479049
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(None) == b'None'
    assert to_bytes(1) == b'1'
    assert to_bytes(u'test') == b'test'
    assert to_bytes(u'\N{SNOWMAN}') == b'\xe2\x98\x83'
    assert to_bytes(u'\N{SNOWMAN}', encoding='latin-1') == b'?'
    assert to_bytes(b'\xe2\x98\x83') == b'\xe2\x98\x83'
    assert to_bytes(b'\xe2\x98\x83', errors='surrogate_or_strict') == b'\xe2\x98\x83'

# Generated at 2022-06-22 22:08:11.021147
# Unit test for function to_native
def test_to_native():
    cur_time = datetime.datetime.utcnow()
    assert to_native(u'some utf8 text \u6709\u52b9', encoding='utf-8') == u'some utf8 text \u6709\u52b9'
    assert to_native(u'some utf8 text \u6709\u52b9', encoding='ascii') == u'some utf8 text \u6709\u52b9'
    assert to_native(b'some ascii text', encoding=None) == b'some ascii text'

# Generated at 2022-06-22 22:08:19.249152
# Unit test for function jsonify
def test_jsonify():
    for py_version in (2, 3):
        if py_version == 2:
            from ansible.module_utils._text import to_bytes
        else:
            from ansible.module_utils._text import to_text as to_bytes
        data = {
            'null': None,
            'integer': 42,
            'float': 3.14159265359,
            'string': '',
            'unicode': u'\u2603',
            'ascii_only': 'ascii_only'.decode('ascii'),
            'list': [1, 2, 3],
            'dict': {to_bytes('key'): to_bytes('value')},
            'set': set([1, 2, 3]),
            'datetime': datetime.datetime.utcnow(),
        }
        new

# Generated at 2022-06-22 22:08:21.456320
# Unit test for function jsonify
def test_jsonify():
    text = '我是中文'
    data = {'test': '我是中文'}
    text2 = jsonify(data)
    print(text2)


# Generated at 2022-06-22 22:08:27.900116
# Unit test for function jsonify
def test_jsonify():
    result = jsonify(dict(
        a=dict(b=u"\xe9"),
        c=u"\xe9",
        d=1)
    )
    assert isinstance(result, text_type)
    # the real test is that it not fail without requiring a UnicodeDecodeError
    # or UnicodeEncodeError



# Generated at 2022-06-22 22:08:40.578791
# Unit test for function container_to_text
def test_container_to_text():
    import json
    import unicodedata
    import codecs
    from ansible.module_utils._text import to_bytes, to_text, to_native
    from ansible.module_utils.urls import open_url, connection_loader

    test_url = 'http://api.openweathermap.org/data/2.5/weather?zip=19343,us'

    myhttp = connection_loader('urllib3')
    resp, info = open_url(myhttp, test_url)

    # data is of type dict
    data = json.loads(to_native(resp.read()))
    data_decode1 = container_to_text(data)
    # data_decode1 is of type dict
    assert isinstance(data_decode1, dict)

# Generated at 2022-06-22 22:08:49.444867
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('foo') == "\"foo\""
    assert jsonify(b'foo') == "\"foo\""
    assert jsonify("f\u1234oo") == "\"f\u1234oo\""
    assert jsonify("\u20ac") == "\"\u20ac\""
    assert jsonify("f\xe4oo") == "\"f\xe4oo\""
    assert jsonify("f\xe4oo", ensure_ascii=False) == "\"f\u00e4oo\""
    assert jsonify("f\xe4oo", ensure_ascii=False, encoding="latin-1") == "\"f\u00e4oo\""


# Generated at 2022-06-22 22:08:56.562692
# Unit test for function container_to_bytes
def test_container_to_bytes():
    a = dict(a=b'foo', b=dict(b1='foo', b2=b'bar'), c=[b'baz', b'qux'])
    b = container_to_bytes(a)
    assert b == dict(a=b'foo', b=dict(b1=b'foo', b2=b'bar'), c=[b'baz', b'qux'])
    assert isinstance(b['a'], binary_type)


# Generated at 2022-06-22 22:09:06.928752
# Unit test for function to_native
def test_to_native():
    assert (to_native(0) == '0') is True
    assert (to_native(True) == 'True') is True
    assert (to_native(False) == 'False') is True
    assert (to_native(None) == 'None') is True
    assert (to_native(b'\xc3\xb1') == u'\xf1') is True
    assert (to_native(u'\xf1') == u'\xf1') is True

    # legacy behavior
    assert (to_native(b'\xc3\xb1') == u'\xc3\xb1') is False
    assert (to_native(u'\xf1') == b'\xc3\xb1') is False

# Generated at 2022-06-22 22:09:13.486828
# Unit test for function container_to_text
def test_container_to_text():
    """Unit test for container_to_text"""

    # test_dict
    d = { 'A': b'A', 'B': {'C': b'C'}}
    d_result = { 'A': u'A', 'B': {'C': u'C'}}
    assert container_to_text(d) == d_result

    # test_list
    l = [b'A', [b'C']]
    l_result = [u'A', [u'C']]
    assert container_to_text(l) == l_result

    # test_tuple
    t = (b'A', (b'C',))
    t_result = (u'A', (u'C',))
    assert container_to_text(t) == t_result

    # test_noncontainer
    n

# Generated at 2022-06-22 22:09:23.016093
# Unit test for function to_native
def test_to_native():
    """to_native should return native strings (text on py3, bytes on py2)
    """

    txt = u'foo'
    bin = b'foo'
    obj = object()

    # in 2.x, this is a string
    if PY3:
        assert isinstance(to_native(txt), str)
    else:
        assert isinstance(to_native(txt), bytes)

    # in 2.x, this is a string
    if PY3:
        assert isinstance(to_native(bin), str)
    else:
        assert isinstance(to_native(bin), bytes)

    # object is always a string
    assert isinstance(to_native(obj), str)


# Generated at 2022-06-22 22:09:30.601460
# Unit test for function to_native
def test_to_native():
    """
    Validate that a variety of datatypes are transformed correctly by
    the to_native function
    """

    assert _to_native(True) == u'true'
    assert _to_native(False) == u'false'
    assert _to_native(1) == u'1'
    assert _to_native(10) == u'10'
    assert _to_native(1.0) == u'1.0'
    assert _to_native(1.0) == u'1.0'
    assert _to_native(u'test') == u'test'
    assert _to_native(u'\u041b\u0430\u0431\u043e') == u'\u041b\u0430\u0431\u043e'

# Generated at 2022-06-22 22:09:40.785615
# Unit test for function container_to_text
def test_container_to_text():
    """
    Run tests against function "container_to_text"
    """
    encoded_string = to_bytes(u'\u0278', encoding='latin-1')
    assert encoded_string == b'\x98'
    # round trip text to bytes to text with valid encoding
    container = {u'\u0278': u'\u0278'}
    converted = container_to_bytes(container, encoding='latin-1')
    assert converted == {b'\x98': b'\x98'}
    assert isinstance(converted, dict)
    assert isinstance(converted.keys()[0], binary_type)
    assert isinstance(converted.values()[0], binary_type)
    assert isinstance(container_to_text(converted, encoding='latin-1'), dict)
   

# Generated at 2022-06-22 22:09:52.445750
# Unit test for function container_to_text
def test_container_to_text():
    text_value = u"\u00E0 peine arriv\u00E9s nous entr\u00E2mes dans sa chambre"
    bytes_value = text_value.encode("utf-8")
    bytes_value_with_null = (text_value + '\x00').encode("utf-8")
    bytes_value_with_invalid_char = (text_value + '\xFF').encode("utf-8")
    text_value_with_null = text_value + u'\x00'
    assert container_to_text(text_value) == text_value
    assert container_to_text(bytes_value) == text_value
    assert container_to_text(bytes_value_with_null) == text_value_with_null
    assert container_to_text

# Generated at 2022-06-22 22:10:03.821059
# Unit test for function to_bytes
def test_to_bytes():
    # setup
    # 1. Try to import the unittest code
    try:
        from unittest import TestCase
        from unittest.mock import patch
        from unittest.mock import MagicMock
    except ImportError:
        from ansible.module_utils.six import unittest
        from ansible.module_utils.six.moves import mock
        from ansible.module_utils.six.moves import builtins

    # 2. If we can't import it, define our own TestCase
    if 'TestCase' not in locals():
        class TestCase(object):
            def assertTrue(self, *args, **kwargs):
                raise NotImplementedError("unittest.TestCase not implemented")

    # 3. Set up the test case we are using

# Generated at 2022-06-22 22:10:15.876833
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # tuple
    from_container = ('h\xe9llo', {'key_with_nonascii': u'value\xe9'})
    expected_string = ("('h\\xe9llo', {'key_with_nonascii': 'value\\xe9'})")

    to_container = container_to_bytes(from_container)
    assert to_native(str(to_container)) == expected_string, \
        'container_to_bytes() on tuples failed'

    # list
    from_container = [
        {'key': 'value'},
        {'key\xe9': 'value\xe9'}
    ]
    expected_string = ("[{'key': 'value'}, {'key\\xe9': 'value\\xe9'}]")

    to_container = container_to_

# Generated at 2022-06-22 22:10:24.660590
# Unit test for function jsonify
def test_jsonify():
    # Valid utf-8 encoding
    data = {"a": "unicode \u2013"}
    jsonify(data)

    # Valid latin-1 encoding
    data = {"a": "ascii", "b": u"unicode \u2013".encode("latin-1")}
    jsonify(data)

    # Invalid encoding raises UnicodeError
    data = {"a": "ascii", "b": u"unicode \u2013".encode("utf-16")}
    try:
        jsonify(data)
    except UnicodeError:
        pass
    else:
        assert False



# Generated at 2022-06-22 22:10:34.552833
# Unit test for function jsonify
def test_jsonify():
    assert jsonify("test") == json.dumps("test")
    assert jsonify("test", indent=4) == json.dumps("test", indent=4)
    assert jsonify("test", sort_keys=True) == json.dumps("test", sort_keys=True)
    assert jsonify("test", skipkeys=True) == json.dumps("test", skipkeys=True)
    assert jsonify("test", ensure_ascii=True) == json.dumps("test", ensure_ascii=True)
    assert jsonify("test", check_circular=True) == json.dumps("test", check_circular=True)
    assert jsonify("test", allow_nan=True) == json.dumps("test", allow_nan=True)

# Generated at 2022-06-22 22:10:39.343317
# Unit test for function to_native
def test_to_native():
    # Byte string
    bstr = binary_type(b'foo')
    assert to_native(bstr) == 'foo'

    # Text string
    tstr = text_type(u'foo')
    assert to_native(tstr) == 'foo'

    # Integer
    assert to_native(5) == '5'

    # Python 2 long
    if PY2:
        assert to_native(long(5)) == '5'

    # Python 3 long
    if PY3:
        assert to_native(5) == '5'

    # Datetime
    assert to_native(datetime.datetime(2000, 1, 1, 0, 0, 0)) == '2000-01-01 00:00:00'

    # Dict
    assert to_native({'foo': {'bar': 5}})

# Generated at 2022-06-22 22:10:50.897457
# Unit test for function to_native
def test_to_native():
    assert to_native(b'hello world') == 'hello world'
    assert to_native(b'sp\xc3\xa4cial') == 'späcial'
    assert to_native('späcial') == 'späcial'
    assert to_native('sp\xc3\xa4cial') == 'späcial'
    assert to_native('sp\xa1cial') == 'sp\xa1cial'
    extra_character = u'\U0001f4a9' * 100
    assert to_native(extra_character.encode('utf-8')) == extra_character
    assert to_native(extra_character) == extra_character
    assert to_native(u'\xf4b4') == u'\xf4b4'

# Generated at 2022-06-22 22:11:01.030926
# Unit test for function container_to_text
def test_container_to_text():

    class FakeDict(dict):
        ''' class to test that container_to_text doesn't try to iterate over
            __dict__
        '''
        def __init__(self, *args):
            d = {}
            for a in args:
                d.update(a)
            super(FakeDict, self).__init__(d)

    d = {b'foo':b'bar',
         b'bar':[b'foo', b'bar'],
         b'foobar':{b'foo':b'bar'},
         b'foofoo':(b'foo', b'bar', b'foobar')
        }


# Generated at 2022-06-22 22:11:13.231496
# Unit test for function container_to_text
def test_container_to_text():
    from ansible.compat.tests.mock import patch
    from ansible.module_utils._text import _get_text_type_error

    def raise_unicode_error(*args, **kwargs):
        raise UnicodeDecodeError('some encoding', b'some bytes', 1, 2, 'some reason')

    # Test that it works with non-strings
    assert container_to_text(u'text') == u'text'

    # Test that it decodes bytestrings
    assert container_to_text(b'bytes') == u'bytes'
    assert container_to_text(b'bytes', errors='ignore') == u''
    assert container_to_text(b'bytes', errors='replace') == u'\ufffd\ufffd\ufffd\ufffd\ufffd'

    # Test that it handles lists

# Generated at 2022-06-22 22:11:23.214544
# Unit test for function container_to_text
def test_container_to_text():
    test_tuple = (1,2,3,b'abc', b'abc', [5,6,7,8], {'a':'b',b'a':b'b'},[b'a',b'b'])
    test_list = [1,2,3,b'abc', b'abc', [5,6,7,8], {'a':'b',b'a':b'b'},[b'a',b'b']]
    test_dict = {'a':'b','c':'d', 6:b'abc', b'abc':6, [5,6,7,8]:{'abc':'abc'}}
    assert isinstance(container_to_text(test_tuple), tuple)
    assert isinstance(container_to_text(test_list), list)

# Generated at 2022-06-22 22:11:35.557517
# Unit test for function container_to_text
def test_container_to_text():
    a = {"b": [1,u"3"]}
    b = container_to_text(a, encoding='utf-8')
    assert b["b"][1] == u"3"
    a = {"b": [1,u"3"]}
    b = container_to_text(a, encoding='utf-16')
    assert b["b"][1] == u"3"
    a = {"b": (1,u"3")}
    b = container_to_text(a, encoding='utf-16')
    assert b["b"][1] == u"3"
    a = {"b": (1,u"3")}
    b = container_to_text(a, errors='replace', encoding='utf-16')
    assert b["b"][1] == u"3"

# Generated at 2022-06-22 22:11:40.967662
# Unit test for function jsonify
def test_jsonify():
    input_json = {"unicode_key": u"value", "ascii_key": "value", "list_key": ["value"]}
    expected_output = u'{"ascii_key": "value", "list_key": ["value"], "unicode_key": "value"}'
    assert jsonify(input_json) == expected_output

