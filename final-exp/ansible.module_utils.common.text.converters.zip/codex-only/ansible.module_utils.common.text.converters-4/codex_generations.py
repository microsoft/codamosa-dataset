

# Generated at 2022-06-22 22:01:48.293520
# Unit test for function jsonify
def test_jsonify():
    # string
    assert jsonify(u'\xe9') == '"\\u00e9"'
    # unicode
    assert jsonify(u'\xe9') == '"\\u00e9"'
    # int
    assert jsonify(1) == '1'
    # float
    assert jsonify(150.0) == '150.0'
    # array
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'
    # dict
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'



# Generated at 2022-06-22 22:01:58.407010
# Unit test for function jsonify
def test_jsonify():
    ''' test for jsonify'''
    # text is unicode and json.dumps can not ensure encoding
    test_data = {'a': 'b'}
    assert '{"a": "b"}' == jsonify(test_data)
    test_data = {'a': 'b'.decode('utf-8')}
    assert '{"a": "b"}' == jsonify(test_data)
    test_data = {'a': 'b'.decode('latin-1')}
    assert '{"a": "b"}' == jsonify(test_data)
    test_data = {'a': 'b'.encode('utf-8')}
    assert '{"a": "b"}' == jsonify(test_data)

# Generated at 2022-06-22 22:02:03.717423
# Unit test for function to_native
def test_to_native():
    from . import to_native
    assert to_native(b'foo', errors='surrogate_or_strict') == 'foo'
    assert to_native(u'\udcff') == u'\udcff'
    # Python 2.7.9+
    if hasattr(u'\udcff', 'encode'):
        assert to_native(u'\udcff', errors='surrogate_or_strict') == u'\udcff'

# Generated at 2022-06-22 22:02:16.557644
# Unit test for function container_to_text
def test_container_to_text():
    args = []
    assert container_to_text(args) == args
    #test list
    args = [["test list"], "test list value"]
    assert container_to_text(args) == args
    #test tuple
    args = (["test tuple"], "test tuple value")
    assert container_to_text(args) == args
    #test dict
    args = [{u"test": u"dict"}]
    assert container_to_text(args) == args
    #test unicode string
    args = [u"test unicode"]
    assert container_to_text(args) == args
    #test byte string
    byte_string = b'byte string'
    assert container_to_text(byte_string) == byte_string.decode('utf-8')
    #test mixed contain, only container will be changed

# Generated at 2022-06-22 22:02:22.843110
# Unit test for function to_bytes
def test_to_bytes():
    '''Test to_bytes'''
    # Import here because of import loop
    import ansible.module_utils.basic

    def test_cases():
        '''returns a generator that yields test cases'''
        from cStringIO import StringIO

        # Tests for simple cases
        yield dict(
            obj='hello',
            encoding='us-ascii',
            nonstring='passthru',
            expected=u'hello',
        )
        yield dict(
            obj=u'hello',
            encoding='us-ascii',
            nonstring='passthru',
            expected=u'hello',
        )
        yield dict(
            obj='\x80hello',
            encoding='us-ascii',
            nonstring='passthru',
            expected=u'\x80hello',
        )
       

# Generated at 2022-06-22 22:02:34.319459
# Unit test for function container_to_bytes
def test_container_to_bytes():

    d = dict(abc=u'abc', num=1, sub=dict(abc=u'abc', num=1),
             lst=[u'abc', 1, dict(abc=u'abc', num=1)])
    expected = dict(abc=b'abc', num=1,
                    sub=dict(abc=b'abc', num=1),
                    lst=[b'abc', 1, dict(abc=b'abc', num=1)])
    actual = container_to_bytes(d)
    assert actual == expected, "Expected %s, got %s" % (expected, actual)

    # Test tuple return

# Generated at 2022-06-22 22:02:42.907111
# Unit test for function to_native
def test_to_native():
    """
    Test function to_native
    """

    #Test with Unicode string
    unicode_string = "Résumé"
    text_string = u"Résumé"
    native_string = "Résumé"
    if PY3:
        assert to_native(unicode_string) == text_string
        assert to_native(text_string) == text_string
    else:
        assert to_native(unicode_string) == native_string
        assert to_native(text_string) == native_string

    #Test with ASCII string
    ascii_string = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    if PY3:
        assert to_native(ascii_string) == ascii_string

# Generated at 2022-06-22 22:02:54.566726
# Unit test for function to_bytes
def test_to_bytes():
    import sys

    # Test the common case:
    result = to_bytes(u'hello')
    assert isinstance(result, binary_type)
    assert u'hello' == result

    # Test bytes are not touched
    if PY3:
        result = to_bytes(b'hello')
        assert isinstance(result, binary_type)
        assert b'hello' == result
    else:
        result = to_bytes(b'hello')
        assert isinstance(result, binary_type)
        assert u'hello' == result

    # Test non-strings
    result = to_bytes(1, nonstring='simplerepr')
    assert isinstance(result, binary_type)
    assert u'1' == result

    result = to_bytes(1, nonstring='empty')

# Generated at 2022-06-22 22:03:06.249245
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u"\u6d4b\u8bd5") == b"\xe6\xb5\x8b\xe8\xaf\x95"
    assert to_bytes(b'\xe6\xb5\x8b\xe8\xaf\x95') == b'\xe6\xb5\x8b\xe8\xaf\x95'
    assert to_bytes(b'\xe6\xb5\x8b\xe8\xaf\x95', errors='strict') == \
           b'\xe6\xb5\x8b\xe8\xaf\x95'

    if PY3:
        assert to_bytes(u"\U00023456", errors='ignore') == b''

# Generated at 2022-06-22 22:03:17.620260
# Unit test for function to_native
def test_to_native():
    # Check with different types of objects
    assert to_native(u'string') == 'string'
    assert to_native('string') == 'string'
    assert to_native(b'string') == 'string'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'.encode('utf-8')

# Generated at 2022-06-22 22:03:28.431899
# Unit test for function to_bytes
def test_to_bytes():
    assert b'abc' == to_bytes('abc')
    assert b'abc' == to_bytes(to_bytes('abc'))
    assert b'abc' == to_bytes(u'abc')
    assert b'abc' == to_bytes(u'abc', encoding='ascii')
    assert b'abc' == to_bytes(u'abc', errors='surrogateescape')
    assert b'abc' == to_bytes(u'abc', errors='surrogate_or_replace')
    assert b'abc' == to_bytes(u'abc', errors='surrogate_then_replace')
    assert b'abc' == to_bytes(u'abc', errors='surrogate_or_strict')
    assert b'abc' == to_bytes(b'abc', errors='surrogate_or_strict')

# Generated at 2022-06-22 22:03:41.493221
# Unit test for function container_to_text

# Generated at 2022-06-22 22:03:51.474930
# Unit test for function container_to_text
def test_container_to_text():
    output = container_to_text({'a': 1, 'b': 2}, encoding='latin-1')
    assert isinstance(output, dict)
    assert output['a'] == 1
    assert output['b'] == 2

    output = container_to_text([1, 2], encoding='latin-1')
    assert isinstance(output, list)
    assert output[0] == 1
    assert output[1] == 2

    output = container_to_text((1, 2), encoding='latin-1')
    assert isinstance(output, tuple)
    assert output[0] == 1
    assert output[1] == 2

    output = container_to_text({"a": 'b'}, encoding='latin-1')
    assert isinstance(output, dict)
    assert output['a'] == 'b'

   

# Generated at 2022-06-22 22:04:01.607690
# Unit test for function container_to_text
def test_container_to_text():
    container = {
        u'key_str': b'value',
        u'key_int': 1,
        u'key_dict': {
            u'key_str': b'value',
            u'key_int': 1
        },
        u'key_list': [
            b'value',
            1
        ]
    }

    new_container = container_to_text(container)

    assert new_container == {
        'key_str': 'value',
        'key_int': 1,
        'key_dict': {
            'key_str': 'value',
            'key_int': 1
        },
        'key_list': [
            'value',
            1
        ]
    }

# Generated at 2022-06-22 22:04:13.161488
# Unit test for function container_to_text
def test_container_to_text():
    """container_to_text function unit test"""
    # Just convert an encrypted password
    data = '{\"password\": \"#some_password_here#\"}'
    new_data = container_to_text(data, encoding='utf-8')
    assert isinstance(new_data, text_type)
    assert new_data == u'{u"password": u"#some_password_here#"}'

    # convert an encrypted password in dictionary
    data = {
        'password': '#some_password_here#'
    }
    new_data = container_to_text(data, encoding='utf-8')
    assert isinstance(new_data, dict)
    assert new_data['password'] == u'#some_password_here#'

    # convert an encrypted password in tuple

# Generated at 2022-06-22 22:04:19.757351
# Unit test for function container_to_text
def test_container_to_text():
    # Lists
    assert container_to_text(['test_str']) == ['test_str']
    assert container_to_text([b'\xe2\x98\x83']) == [u'\u2603']
    assert container_to_text([u'\u2603']) == [u'\u2603']
    # Dict
    assert container_to_text({'key':'test_str'}) == {u"key": u'test_str'}
    assert container_to_text({b'key':b'\xe2\x98\x83'}) == {u"key": u'\u2603'}
    assert container_to_text({b'key':u'\u2603'}) == {u"key":u'\u2603'}
    # Class with __re

# Generated at 2022-06-22 22:04:24.710440
# Unit test for function container_to_bytes
def test_container_to_bytes():
    data = {u'a': u'z'}
    assert isinstance(container_to_bytes(data), dict)
    for key, value in data.items():
        assert isinstance(key, binary_type)
        assert isinstance(value, binary_type)

    data = ['a', 'b', 'c']
    assert isinstance(container_to_bytes(data), list)
    for element in data:
        assert isinstance(element, binary_type)

    data = (u'a', u'b', u'c')
    assert isinstance(container_to_bytes(data), tuple)
    for element in data:
        assert isinstance(element, binary_type)



# Generated at 2022-06-22 22:04:35.149082
# Unit test for function container_to_text
def test_container_to_text():
    data = '\xe8\xaf\xb7\xe8\xbe\x93\xe5\x85\xa5\xe9\x94\x81\xe4\xbb\xb6\xe5\x8c\x85\xe7\xb4\xa2\xe5\xbc\x95\xe5\xad\x97\xe6\xae\xb5'
    encode_result = container_to_text(data)
    assert encode_result == u'\u8bf7\u8f93\u5165\u94a5\u4ee5\u5e93\u7b4a\u5f15\u5b57\u6bb5'



# Generated at 2022-06-22 22:04:47.646396
# Unit test for function container_to_text
def test_container_to_text():
    """ test_container_to_text: Unit test for function container_to_text
    """
    assert container_to_text(u'\u2708') == u'\u2708'
    assert container_to_text('\u2708'.encode('utf-8')) == u'\u2708'
    result = container_to_text({u'\u2708': u'\u2708'})
    assert isinstance(result, dict)
    assert result[u'\u2708'] == u'\u2708'
    result = container_to_text(('\u2708'.encode('utf-8'), '\u2708'.encode('utf-8')))
    assert isinstance(result, tuple)
    assert result[0] == u'\u2708'
    result = container_

# Generated at 2022-06-22 22:04:53.082496
# Unit test for function to_bytes
def test_to_bytes():
    # we don't use assertEqual because it will call to_text on the arguments
    # and py2.7 can't handle that
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes('foo') == b'foo'
    assert to_bytes('foo', errors='replace') == b'foo'
    assert to_bytes(u'foo\ufffd') == to_bytes('foo\ufffd') == b'foo\ufffd'
    assert to_bytes(u'foo\xfffd') == to_bytes('foo\xfffd') == b'foo\xfffd'


# Generated at 2022-06-22 22:05:01.954176
# Unit test for function container_to_bytes
def test_container_to_bytes():
    input = {'a': {'b': [1, [u"\u6e2c\u8a66"]], 'c': u'\u6e2c\u8a66', 'd': ['\u6e2c\u8a66', u'\u6e2c\u8a66']}}
    expected = {b'a': {b'b': [1, [b'\xe6\xb8\xac\xe8\xa8\x88']], b'c': b'\xe6\xb8\xac\xe8\xa8\x88', b'd': [b'\xe6\xb8\xac\xe8\xa8\x88', b'\xe6\xb8\xac\xe8\xa8\x88']}}

# Generated at 2022-06-22 22:05:09.365485
# Unit test for function jsonify
def test_jsonify():
    data = {to_text("a"): to_text("b")}
    assert jsonify(data)
    data.update({to_text("a"): b"b"})
    assert jsonify(data)
    data.update({b"a": to_text("b")})
    assert jsonify(data)


# Used so that we can have a single encode function that handles both text and
# binary data.
_encode_handler = codecs.lookup('utf-8')[3]



# Generated at 2022-06-22 22:05:17.339041
# Unit test for function to_native
def test_to_native():
    """
    to_native(obj, encoding='utf-8', errors='strict') -> string

    This should really be just 'return text_type(obj)' but it's not in Python2.
    """
    assert to_native('happy') == u'happy'
    assert to_native(u'happy') == u'happy'

    # Note: Python2 doesn't have surrogates
    # Note: Python3 doesn't have a b prefix for bytes
    if PY3:
        with pytest.raises(TypeError):
            to_native(b'\x80')
    else:
        assert to_native(b'\x80') == u'\udc80'



# Generated at 2022-06-22 22:05:28.358064
# Unit test for function jsonify
def test_jsonify():
    import ansible.module_utils.basic
    from ansible.module_utils.six import StringIO
    import sys
    import json

    data_in = {u"äöü": "test"}
    data_out = jsonify(data_in)
    data_in_utf8 = {u"äöü".encode("utf-8"): "test"}
    data_out_utf8 = jsonify(data_in_utf8)
    data_in_latin1 = {u"äöü".encode("latin-1"): "test"}
    data_out_latin1 = jsonify(data_in_latin1)


# Generated at 2022-06-22 22:05:39.810908
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({"1": [1, 2, 3]}) == {"1": [1, 2, 3]}
    assert container_to_bytes({"1": [1, 2, {"foo": "bar"}]}) == {"1": [1, 2, {"foo": "bar"}]}
    assert container_to_bytes({"1": [1, 2, {"foo": "bar"}]}) == {"1": [1, 2, {"foo": "bar"}]}
    assert container_to_bytes({"1": [1, 2, {"foo": "bar"}]}) == {"1": [1, 2, {"foo": "bar"}]}
    assert container_to_bytes([1, 2, {"foo": "bar"}]) == [1, 2, {"foo": "bar"}]

# Generated at 2022-06-22 22:05:50.338416
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'name': u'\uc774\ub2c8\uc9c0'}) == '{"name": "\\uc774\\ub2c8\\uc9c0"}'
    assert jsonify({'name': u'\uc774\ub2c8\uc9c0'.encode('utf-8')}) == '{"name": "\\uc774\\ub2c8\\uc9c0"}'
    assert jsonify({'name': u'\uc774\ub2c8\uc9c0'.encode('latin-1')}) == '{"name": "\\uc774\\ub2c8\\uc9c0"}'

# Generated at 2022-06-22 22:05:59.259381
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test for no conversion
    assert container_to_bytes(b'test') == b'test'
    assert container_to_bytes(u'test') == u'test'
    assert container_to_bytes(1) == 1
    assert container_to_bytes(1.0) == 1.0
    assert container_to_bytes(['test', b'test']) == ['test', b'test']
    assert container_to_bytes(('test', b'test')) == ('test', b'test')

    # Test for conversion
    assert container_to_bytes(u'test', encoding='ascii') == b'test'
    assert container_to_bytes(u'\u1234', encoding='ascii') == u'\u1234'.encode('ascii', 'surrogateescape')
    assert container

# Generated at 2022-06-22 22:06:06.343467
# Unit test for function to_native
def test_to_native():
    for datatype in (int, float, complex, binary_type, text_type, set, tuple, list):
        # bytes, str, unicode, set, tuple, list
        # Shouldn't be able to instantiate datetime or bool w/o args
        obj = datatype()
        assert to_native(obj) == obj, 'Failed to_native(%s) on object %r' % (datatype, obj)

    for datatype in (datetime.datetime, datetime.date, datetime.time):
        # datetime.datetime, datetime.date, datetime.time
        obj1 = datatype()
        obj2 = datatype.now()
        obj3 = datatype.fromtimestamp(0)

# Generated at 2022-06-22 22:06:17.322810
# Unit test for function to_native
def test_to_native():

    class Foo(object):
        def __str__(self):
            return "foo"

        def __repr__(self):
            return "foo"

    class FooRaises(object):
        def __str__(self):
            raise UnicodeError()

        def __repr__(self):
            raise UnicodeError()

    class FooRaisesStrOnly(object):
        def __str__(self):
            raise UnicodeError()

        def __repr__(self):
            return "foo"

    class FooRaisesReprOnly(object):
        def __str__(self):
            return "foo"

        def __repr__(self):
            raise UnicodeError()

    class FooRaisesBytes(object):
        def __str__(self):
            return u'\u0CA0_\u0CA0'.en

# Generated at 2022-06-22 22:06:24.400816
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.basic import AnsibleModule
    orig = {u'ö': u'ö'}
    if PY3:
        orig = {u'ö'.encode('utf-8').decode('latin-1'): u'ö'}
    module = AnsibleModule(argument_spec={})
    json_output = jsonify(orig)
    module.exit_json(changed=True, original_message=orig, message=json_output)



# Generated at 2022-06-22 22:06:36.351193
# Unit test for function container_to_bytes
def test_container_to_bytes():
    '''
    This function returns True if the test passes, and returns False if it fails.
    '''
    from ansible.compat.tests import unittest
    data = dict(
        foo=dict(
            bar='baz',
            # Note: nested dicts do not get converted
            bam=dict(
                bing=[u'bang', [u'whiz', u'splat'], u'zoom'],
                blah=('one', 'two', 'three')
            )
        ),
        boof=u'barf'
    )


# Generated at 2022-06-22 22:06:41.227343
# Unit test for function to_native
def test_to_native():
    assert to_native(b'\xe9', errors='surrogate_then_replace') == u'\ufffd'
    assert to_native(b'\xe9', errors='surrogate_or_strict') == u'\xe9'
    assert to_native(b'\xe9', errors='surrogate_or_replace') == u'\ufffd'

    if HAS_SURROGATEESCAPE:
        assert to_native(b'\xe9', errors='surrogateescape') == u'\xe9'

    assert to_native(b'\xe9', errors='strict') == u'\xe9'
    assert to_native(b'\xe9', errors='replace') == u'\ufffd'
    assert to_native(b'\xe9', errors='ignore') == u''

# Generated at 2022-06-22 22:06:53.796603
# Unit test for function container_to_bytes
def test_container_to_bytes():
    '''Validate container_to_bytes'''
    # Try a dict
    expected = {'a': {'b': {'c': '123'}}}
    actual = container_to_bytes(expected, errors='surrogate_or_strict')
    assert actual == expected
    # Try a list
    expected = ['a', 'b', 'c', '123']
    actual = container_to_bytes(expected, errors='surrogate_or_strict')
    assert actual == expected
    # Try a tuple
    expected = ('a', 'b', 'c', '123')
    actual = container_to_bytes(expected, errors='surrogate_or_strict')
    assert actual == expected
    # Try a dict of dicts
    expected = {'a': {'b': {'c': '123'}}}


# Generated at 2022-06-22 22:07:00.398752
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' Unit test for function container_to_bytes'''
    import six
    if six.PY3:
        # this test is only valid on python3
        from io import StringIO
        # Container_to_bytes only handles dicts, tuples, and lists
        test_dict = {u'test':u'working'}
        test_tuple = (u'test1', u'test2')
        test_list = [u'test1', u'test2']
        test_int = 1
        test_bytes = b'test1'
        test_unicode = u'test1'
        # test that the container_to_bytes returns a dict of byte strings
        assert isinstance(container_to_bytes(test_dict), dict)

# Generated at 2022-06-22 22:07:10.804152
# Unit test for function to_native
def test_to_native():
    # to_native with bytes and unicode
    #
    # The decoded bytes and the unicode strings are valid JSON.  Make sure they
    # come out in a way that is still valid JSON.
    #
    # Note: These are only valid in Python3, the 1st parameter to json.loads is
    # different in python2
    assert to_native(b'{"foo":"bar"}') == b'{"foo":"bar"}'
    assert to_native(u'{"foo":"bar"}') == u'{"foo":"bar"}'

    # to_native with other types.
    #
    # Note: These are only valid in Python3, the 1st parameter to json.loads is
    # different in python2
    assert json.loads(to_native(1)) == 1
    assert json.loads(to_native(1.1))

# Generated at 2022-06-22 22:07:21.309942
# Unit test for function to_bytes
def test_to_bytes():
    """Test that to_bytes() works as expected"""
    from ansible.module_utils.common._collections_compat import StringIO
    from ansible.module_utils.pycompat24 import to_native


# Generated at 2022-06-22 22:07:28.404610
# Unit test for function to_native
def test_to_native():
    '''
    Test to_native()
    '''
    from ansible.module_utils._text import to_native
    assert to_native(u'pass') == u'pass'
    assert to_native('pass') == u'pass'
    assert to_native(True) == u'True'
    assert to_native(False) == u'False'
    assert to_native(None) == u'None'
    assert to_native(u'\x80') == u'\x80'
    assert to_native('\x80') == u'\x80'
    assert to_native('\u1234') == u'\u1234'
    assert to_native('\U00010111') == u'\U00010111'
    if PY3:
        assert to_native(b'pass')

# Generated at 2022-06-22 22:07:39.225922
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text([], 'utf-8') == []
    assert container_to_text(["test_text", "another_test_text"], 'utf-8') == ["test_text", "another_test_text"]

    assert container_to_text((), 'utf-8') == ()
    assert container_to_text(("test_text", "another_test_text"), 'utf-8') == ("test_text", "another_test_text")

    assert container_to_text({}, 'utf-8') == {}
    assert container_to_text({'test': 1}, 'utf-8') == {'test': 1}
    assert container_to_text({'test': ['1', '2']}, 'utf-8') == {'test': ['1', '2']}


# Generated at 2022-06-22 22:07:49.897135
# Unit test for function container_to_text
def test_container_to_text():
    d = {'abc': b'123', 'xyz': [b'a', ['b', b'd', 'e'], 'f'], 'pqr': (b'a', 'b', b'd')}
    e = container_to_text(d)
    assert(e['abc'] == '123')
    assert(e['xyz'][0] == 'a')
    assert(e['xyz'][1][0] == 'b')
    assert(e['xyz'][1][1] == 'd')
    assert(e['xyz'][1][2] == 'e')
    assert(e['xyz'][2] == 'f')
    assert(e['pqr'][0] == 'a')
    assert(e['pqr'][1] == 'b')

# Generated at 2022-06-22 22:07:51.433875
# Unit test for function to_native
def test_to_native():

    assert text_type == str
    assert binary_type == bytes



# Generated at 2022-06-22 22:07:56.756655
# Unit test for function container_to_text
def test_container_to_text():
    # Test with a text value
    assert container_to_text("hello world") == u"hello world"

    # Test with a byte string
    assert container_to_text("hello world".encode("utf-8")) == u"hello world"

    # Test with a dict that contains text
    assert container_to_text(dict(a="hello world")) == {u"a": u"hello world"}

    # Test with a dict that contains a byte string
    assert container_to_text(dict(a="hello world".encode("utf-8"))) == {u"a": u"hello world"}

    # Test with a dict that contains a nested dict that contains text
    assert container_to_text(dict(a=dict(b="hello world"))) == {u"a": {u"b": u"hello world"}}

    # Test

# Generated at 2022-06-22 22:08:04.223329
# Unit test for function container_to_bytes
def test_container_to_bytes():
    """
    Test the container_to_bytes function
    """
    # This test is not supposed to raise any exception, if so it will trigger an assert.
    # All tests will have a dict that looks like this.  If the input text string is decodable using
    # encoding than the key will be the decoded string, otherwise the key will be the encoded string
    # using 'surrogateescape'.  The value will always be the raw text string in the correct encoding.

# Generated at 2022-06-22 22:08:09.858155
# Unit test for function jsonify
def test_jsonify():
    data = {'a': u'中文'}
    assert jsonify(data) == '{"a": "\\u4e2d\\u6587"}'
    assert jsonify(container_to_text(data, encoding='utf-8')) == '{"a": "\\u4e2d\\u6587"}'



# Generated at 2022-06-22 22:08:20.311961
# Unit test for function container_to_bytes
def test_container_to_bytes():
    class Foo(object):
        def __init__(self, s):
            self.s = s
        def __str__(self):
            return self.s
        __repr__ = __str__

        def __eq__(self, other):
            return self.s == other.s

    inp = {
        u"bàr": "baz",
        "bāz": u"bàz",
        u"băz": Foo(u"baz"),
        "baz": [
            ("baz", u"bāz"),
            (u"bàz", "baz"),
        ],
        "bâz": {
            "baz": u"bàz"
        },
        "bàz": (u"baz", )
    }
    out = container_to

# Generated at 2022-06-22 22:08:32.163975
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(2) == b'2'
    assert to_bytes(b'f\xbfo') == b'f\xbfo'
    assert to_bytes(u'f\xfco') == b'f\xc3\xbc'
    assert to_bytes(None) == b'None'

    assert to_bytes(u'f\xfco', errors='strict') == b'f\xc3\xbc'
    assert to_bytes(u'f\xfco', errors='surrogate_or_strict') == b'f\xc3\xbc'

# Generated at 2022-06-22 22:08:42.638071
# Unit test for function jsonify
def test_jsonify():
    # Default encoding utf-8
    assert jsonify({"test": "hé"}) == '{"test": "h\\u00e9"}'
    # Override encoding
    assert jsonify({"test": "hé"}, encoding="latin-1") == '{"test": "h\\u00e9"}'
    # Provide a containter which only works for latin-1
    assert jsonify({b"test": b"h\xE9"}, encoding="latin-1") == '{"test": "h\\u00e9"}'
    assert jsonify({b"test": b"h\xE9"}, encoding="utf-8") == '{"test": "h\\u00e9"}'
    # Provide a container which only works for utf-8

# Generated at 2022-06-22 22:08:51.691743
# Unit test for function to_native

# Generated at 2022-06-22 22:09:02.748832
# Unit test for function jsonify
def test_jsonify():
    import json

    data = {u"abc": u"def", "ghi": "jkl"}
    assert json.dumps(data, encoding='utf-8', ensure_ascii=False, sort_keys=True) == jsonify(data)
    data = {u"name": u"中文"}
    assert '{"name": "\\u4e2d\\u6587"}' == jsonify(data)


types = [
    'set',
    'dict',
    'list',
    'frozenset',
    'tuple',
]

if PY3:
    # New in py3 stdlib
    types.extend([
        'UserDict',
        'UserList',
        'UserString',
    ])
else:
    # New in py2.6 stdlib
    types

# Generated at 2022-06-22 22:09:14.516278
# Unit test for function container_to_bytes
def test_container_to_bytes():
    from cStringIO import StringIO
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.module_utils.basic import AnsibleModule

    data = {u'\u0147': {u'a': (1, 2), u'b': [u'\u0147', u'\u0127']}, u'\u0127': {u'c': to_unicode(u'\u0127'), u'd': [u'\u0147', u'\u0127']}}
    mod = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    # Test default, with exceptions
    actual = container_to_bytes(data)

# Generated at 2022-06-22 22:09:15.800122
# Unit test for function to_bytes
def test_to_bytes():
    pass

# Generated at 2022-06-22 22:09:24.722267
# Unit test for function jsonify
def test_jsonify():
    '''{"a": "b\u2014", "b": "a\udcd4"}'''
    data = dict(a=to_text("b\u2014", "latin-1"), b=to_text("a\udcd4", "latin-1"))
    assert jsonify(data) == '{"a": "b\\u2014", "b": "a\\udcd4"}'
    data = dict(a=to_text("b\u2014", "utf-8"), b=to_text("a\udcd4", "latin-1"))
    assert jsonify(data) == '{"a": "b\\u2014", "b": "a\\udcd4"}'



# Generated at 2022-06-22 22:09:36.640299
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {u'a': [1, 2], u'b': u'c'}
    assert container_to_bytes(d) == {'a': [1, 2], 'b': 'c'}
    assert container_to_bytes(d, encoding='latin-1') == {b'a': [1, 2], b'b': b'c'}
    assert container_to_bytes(u'\N{GREEK CAPITAL LETTER DELTA}') == b'\xce\x94'
    assert container_to_bytes(u'\N{GREEK CAPITAL LETTER DELTA}', encoding='latin-1') == b'?'
    assert container_to_bytes(u'\N{GREEK CAPITAL LETTER DELTA}', errors='surrogate_then_replace') \
        == b

# Generated at 2022-06-22 22:09:44.719984
# Unit test for function to_native
def test_to_native():
    assert '\xf0\x9f\x98\x81' == '\ud83d\ude01'
    assert b'\xf0\x9f\x98\x81' == to_text('\ud83d\ude01').encode('utf8')
    assert '\xf0\x9f\x98\x81' == '\ud83d\ude01'.encode('utf8').decode('utf8')
    assert b'\xf0\x9f\x98\x81' == b'\ud83d\ude01'

    assert b'\xf0\x9f\x98\x81' == to_bytes('\ud83d\ude01')

# Generated at 2022-06-22 22:09:55.076890
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    # Ensure to_native always returns unicode or str and never bytes
    assert isinstance(to_native(u'test'), text_type)
    assert isinstance(to_native(b'test'), text_type)
    assert isinstance(to_native(u'test'.encode('utf-8')), text_type)
    assert isinstance(to_native(u'test'.encode('utf-16')), text_type)
    assert isinstance(to_native(True), text_type)
    assert isinstance(to_native(False), text_type)
    assert isinstance(to_native(None), text_type)
    assert isinstance(to_native(b'bytes_value'.decode('utf-8')), text_type)
    assert isinstance

# Generated at 2022-06-22 22:10:00.292591
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo', 'ascii') == 'foo'
    assert to_native(b'foo', 'ascii') == 'foo'
    assert to_native(u'“Hänsel und Gretel”', 'ascii', 'replace') == '"H�nsel und Gretel"'



# Generated at 2022-06-22 22:10:11.386212
# Unit test for function to_native
def test_to_native():
    """
    Test to_native with various inputs
    """
    from ansible.module_utils._text import to_native
    from collections import OrderedDict
    assert to_native(b'\xc3\x9f\xc3\xa5\xc3\xb8\xc3\xa6\xc3\xb8\xc3\xb8') == 'ÿåøæøø'
    assert to_native(u'\u00e6\u0153') == 'æœ'
    assert to_native(u'\u00e6\u0153', errors='surrogate_or_replace') == 'æœ'
    assert to_native(u'\u00e6\u0153', errors='surrogate_or_strict') == 'æœ'

# Generated at 2022-06-22 22:10:22.775365
# Unit test for function container_to_text
def test_container_to_text():
    # Python3
    # test bytes
    if six.PY3:
        assert container_to_text(b'123') == '123'
        assert container_to_text(b'\xe4\xb8\xad\xe6\x96\x87') == '中文'
        assert container_to_text(b'\xff') == '\ufffd'

    # test non-container
    assert container_to_text(1) == 1
    assert container_to_text(1.0) == 1.0
    assert container_to_text(True) is True
    assert container_to_text(False) is False
    assert container_to_text(None) is None

    # test tuple
    assert container_to_text((1, )) == (1, )

# Generated at 2022-06-22 22:10:26.583404
# Unit test for function jsonify
def test_jsonify():
    actual = jsonify(dict(a=1, b=2))
    expect = '{"a": 1, "b": 2}'
    assert actual == expect

# Generated at 2022-06-22 22:10:33.760902
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test bytes (with a surrogate pair in it)
    data = b'I am the \xc2\xad bytestring'
    # Test text (with a surrogate pair in it)
    txt = text_type('I am the \u202ctextstring', 'utf-8')
    # Test unicode (with a surrogate pair in it)
    uni = u'I am the \u202cunicodestring'
    # Test list with text, bytes, and unicode in it
    lst = [data, txt, uni]
    # Dict with all of the above in it
    d = dict(bytes=data, text=txt, unicode=uni, list=lst)
    # Follows the json spec and returns unicode
    dd = jsonify(d)
    # convert it to a dict
    jd

# Generated at 2022-06-22 22:10:44.472502
# Unit test for function to_bytes
def test_to_bytes():
    if not PY3:
        assert to_bytes(u'foo\u1234bar', errors='surrogateescape') == \
            b'foo\xed\xa0\xb4bar'
        assert to_bytes(b'bytes string') == b'bytes string'
        assert to_bytes(b'bytes string', errors='surrogate_or_strict') == \
            b'bytes string'
        assert to_bytes(b'bytes string', errors='surrogate_or_strict',
                        nonstring='strict') == b'bytes string'
        assert to_bytes(b'bytes string', errors='surrogate_or_replace') == \
            b'bytes string'
        assert to_bytes(b'bytes string', errors='surrogate_then_replace') == \
            b'bytes string'
       

# Generated at 2022-06-22 22:10:56.538816
# Unit test for function jsonify
def test_jsonify():
    import json
    import unittest
    from ansible.module_utils._text import to_bytes

    class TestUnicodeDecodeErrorInJsonDumps(unittest.TestCase):

        def test_decode_latin_1(self):
            json_str = jsonify({'ansible_facts': {'test_key': to_bytes('\xf6', 'latin-1')}})
            json_str = json_str.encode('utf-8').decode('latin-1')
            result = json.loads(json_str)
            self.assertEqual(result['ansible_facts']['test_key'], '\xf6')


# Generated at 2022-06-22 22:11:04.489551
# Unit test for function jsonify
def test_jsonify():
    """ test for jsonify, jsonify should be able to handle unicode """
    import sys
    if sys.version_info[0] == 2:
        if sys.version_info < (2, 7):
            from ordereddict import OrderedDict
        else:
            from collections import OrderedDict
    else:
        from collections import OrderedDict

    # example using a list
    data = [u"blah blah blah",u"h\xf9bl\xe9" ]
    result = jsonify(data)
    assert u"blah blah blah" in result
    assert u"h\xf9bl\xe9" in result

    # example using a dict
    data = OrderedDict()
    data[u"key1"] = u"blah blah blah"

# Generated at 2022-06-22 22:11:08.474533
# Unit test for function jsonify
def test_jsonify():

    # no exception raised
    try:
        jsonify(u'¿Cómo estás?')
    except UnicodeDecodeError:
        assert False

    # no exception raised
    try:
        jsonify(u'¿Cómo estás?'.encode('utf-8'))
    except UnicodeDecodeError:
        assert False



# Generated at 2022-06-22 22:11:11.699795
# Unit test for function jsonify
def test_jsonify():
    a = jsonify({u'foo': u'bar'})
    print(a)
    b = jsonify({u'foo': [1, 2, 3, 4, 5]})
    print(b)



# Generated at 2022-06-22 22:11:22.591452
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(dict(x=u'\xe8\xaf\xad', y=dict(u=u'\u7f16\u7801'))) == dict(x='语', y=dict(u='编码'))
    assert container_to_text(dict(x=u'\xe8\xaf\xad', y=dict(u='\xe7\xbc\x96\xe7\xa0\x81'))) == dict(x='语', y=dict(u='编码'))

# Generated at 2022-06-22 22:11:35.177818
# Unit test for function to_bytes

# Generated at 2022-06-22 22:11:44.155328
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({u'foo': u'bar'}) == {'foo': 'bar'}
    assert container_to_bytes(u'foo') == 'foo'
    assert container_to_bytes([u'a', u'b', u'c']) == ['a', 'b', 'c']
    assert container_to_bytes((u'a', u'b', u'c')) == ('a', 'b', 'c')
    assert container_to_bytes([[u'a', u'b'], u'c']) == [['a', 'b'], 'c']
    assert container_to_bytes([u'a', [u'b', u'c']]) == ['a', ['b', 'c']]