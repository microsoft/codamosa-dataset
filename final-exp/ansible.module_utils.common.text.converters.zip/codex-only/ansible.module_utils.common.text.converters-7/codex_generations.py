

# Generated at 2022-06-22 22:01:49.382416
# Unit test for function container_to_bytes
def test_container_to_bytes():
    input_data = {u'bytes': '',
                  u'unicode': u'series of unicode characters\u00CE',
                  u'unicode_dict': {u'dict_unicode': u'unicode string\u00CE'},
                  u'unicode_list': [u'unicode string\u00CE', u'unicode string 2\u00CE']}
    golden_output = {'bytes': '',
                     'unicode': 'series of unicode characters\xc3\x8e',
                     'unicode_dict': {'dict_unicode': 'unicode string\xc3\x8e'},
                     'unicode_list': ['unicode string\xc3\x8e', 'unicode string 2\xc3\x8e']}

# Generated at 2022-06-22 22:01:58.934474
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # ensure container_to_bytes does not alter bytes objects
    x = b'123'
    y = container_to_bytes(x)
    assert x == y
    assert isinstance(y, binary_type)

    x = u'123'
    y = container_to_bytes(x)
    assert x.encode('utf-8') == y
    assert isinstance(y, binary_type)

    x = {u'a': u'123', 'b': u'456'}
    y = container_to_bytes(x)
    assert y[u'a'].encode('utf-8') == b'123'
    assert y['b'].encode('utf-8') == b'456'

    x = [u'123', b'456']
    y = container_to_bytes(x)
   

# Generated at 2022-06-22 22:02:05.136938
# Unit test for function container_to_text
def test_container_to_text():
    input_list = [b'123\x81\x82\x83', {b'test': b'123\x81\x82\x83'}, [b'123\x81\x82\x83']]
    output_list = [u'123\U00010102\U00010103', {u'test': u'123\U00010102\U00010103'}, [u'123\U00010102\U00010103']]
    assert container_to_text(input_list, encoding='big5') == output_list


# Generated at 2022-06-22 22:02:17.426777
# Unit test for function container_to_text
def test_container_to_text():
    # List
    assert container_to_text(["test"]) == ["test"]
    # Dict
    assert container_to_text({"test": "value"}) == {"test": "value"}
    assert container_to_text({"test": b"value"}) == {"test": u"value"}
    # tuple
    assert container_to_text(("test",)) == ("test",)
    # Error Testing:
    # string
    assert container_to_text(b"test", errors='strict') == u"test"
    # Dict:
    with pytest.raises(UnicodeDecodeError):
        container_to_text({b"test": b"value"}, encoding='ascii')
    assert container_to_text({b"test": b"value"}, encoding='ascii', errors='replace')

# Generated at 2022-06-22 22:02:28.741438
# Unit test for function to_native
def test_to_native():
    assert type(to_native(1)) == str
    assert type(to_native(u'1')) == str
    assert type(to_native('1')) == str
    assert type(to_native(1.1)) == str
    assert type(to_native(True)) == str
    assert type(to_native(None)) == str
    assert type(to_native({})) == str
    assert type(to_native({})) == str
    assert type(to_native([])) == str
    assert type(to_native(())) == str
    assert type(to_native(set())) == str
    assert type(to_native(datetime.date.today())) == str
    assert type(to_native(b'1')) == str

# Generated at 2022-06-22 22:02:40.449932
# Unit test for function container_to_bytes
def test_container_to_bytes():
    if not PY3:
        assert container_to_bytes(u'\u2713') == b'\xe2\x9c\x93'
        assert container_to_bytes(u'\u2713', errors='surrogate_or_replace') == b'?'
        # In Python2, surrogateescape is not a valid error handler.  So, this should use replace
        assert container_to_bytes(u'\u2713', errors='surrogate_then_replace') == b'?'
        assert container_to_bytes([u'\u2713', u'\u2713']) == [b'\xe2\x9c\x93', b'\xe2\x9c\x93']

# Generated at 2022-06-22 22:02:46.531877
# Unit test for function to_bytes
def test_to_bytes():
    # Here we test that the surrogateescape error handler is used
    # when it is available and that it is not used when it is not available
    # This is done by toggling global HAS_SURROGATEESCAPE
    # Additionally, we test that surrogate_then_replace results in no traces
    # surrogateescape is needed for this to work
    SURROGATEESCAPE_STRING = '\udc80'
    if PY3:
        try:
            codecs.lookup_error('surrogateescape')
            HAS_SURROGATEESCAPE = True
        except LookupError:
            HAS_SURROGATEESCAPE = False
    else:
        # Python 2.7 doesn't have surrogateescape
        HAS_SURROGATEESCAPE = False


# Generated at 2022-06-22 22:02:56.003500
# Unit test for function container_to_text
def test_container_to_text():
    d = json.loads(b'{"list": ["a", "b"], "tuple": ["a", "b"], "unicode": "\\u00fc", "binary": "\\xe0"}')
    assert container_to_text(d) == {'list': ['a', 'b'], 'tuple': ['a', 'b'], 'unicode': 'ü', 'binary': 'à'}
    assert container_to_text(d, encoding='latin-1') == {'list': ['a', 'b'], 'tuple': ['a', 'b'], 'unicode': 'ü', 'binary': '\xe0'}


# Generated at 2022-06-22 22:03:07.804044
# Unit test for function container_to_text
def test_container_to_text():
    # Sanity check
    # We don't expect this to traceback
    to_text('test')

    # Check conversion
    data = {
        b'a': 'a',
        b'bytes_key': b'value',
        'text_value': u'text_value',
        'unicode_key': b'value',
    }
    result = container_to_text(data)
    assert isinstance(result, dict)
    for k, v in iteritems(result):
        assert isinstance(k, text_type)
        assert isinstance(v, text_type)
        assert v == to_text(v)

    # Check conversion with error handling

# Generated at 2022-06-22 22:03:18.335017
# Unit test for function to_native
def test_to_native():
    """
    Tests to_native on 2.6, 2.7, 3.2, 3.3, and 3.4.
    """
    import sys
    # Python 2.6's native string type is 'str'
    # Python 2.7's native string type is 'unicode'
    # Python 3.2-3.4's native string type is 'str'
    # Python 3.5+'s native string type is 'str'
    if sys.version_info[:3] < (2, 7, 0):
        # Python 2.x
        if IS_PY2:
            assert to_native(b'ascii') == b'ascii'
            assert to_native(u'ascii') == b'ascii'

# Generated at 2022-06-22 22:03:29.092796
# Unit test for function container_to_text
def test_container_to_text():
    d = dict(a=dict(b=b'foobar', c='foobar'))
    d_rev = dict(a=dict(b='foobar', c='foobar'))
    assert container_to_text(d) == d_rev
    d = dict(a=dict(b='foobar', c=b'foobar'))
    assert container_to_text(d) == d
    d = dict(a=[1,2,3], b=[b'baz', b'qux'])
    d_rev = dict(a=[1,2,3], b=['baz', 'qux'])
    assert container_to_text(d) == d_rev

_CHARACTER_TYPES = (binary_type, text_type, int, float)



# Generated at 2022-06-22 22:03:41.960240
# Unit test for function container_to_text
def test_container_to_text():
    # Test Simple unicode string
    string = u'\u3068'
    assert container_to_text(string) == string

    # Test (string, int) tuple
    mixed = (u'\u3068', 42)
    assert container_to_text(mixed) == mixed

    # Test (unicode, byte) tuple
    mixed = (u'\u3068', b'\xe3\x81\xa8')
    assert container_to_text(mixed) == mixed

    # Test [int, unicode, byte] list
    mixed = [42, u'\u3068', b'\xe3\x81\xa8']
    assert container_to_text(mixed) == mixed

    # Test [tuple, unicode, byte] list

# Generated at 2022-06-22 22:03:50.920253
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'text', 'b': b'bytes'}
    assert jsonify(data) == '{"a": "text", "b": "bytes"}'
    assert jsonify(data, ensure_ascii=False) == '{"a": "text", "b": "bytes"}'

    data = {'a': b'bytes'}
    assert jsonify(data) == '{"a": "bytes"}'
    assert jsonify(data, ensure_ascii=False) == '{"a": "bytes"}'
    data = [b'bytes', 'text']
    assert jsonify(data) == '["bytes", "text"]'
    assert jsonify(data, ensure_ascii=False) == '["bytes", "text"]'

# Generated at 2022-06-22 22:04:01.766862
# Unit test for function to_bytes
def test_to_bytes():

    # On PY3, all these will return bytes.  On Py2 they should return str
    # with the same contents

    # On Py2, this is a str
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442 \u043c\u0438\u0440') == '\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82 \xd0\xbc\xd0\xb8\xd1\x80'
    # On Py2, this is a str

# Generated at 2022-06-22 22:04:13.278269
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(u'abc') == 'abc'
    assert container_to_bytes(dict(a=u'abc', b=u'123')) == dict(a='abc', b='123')
    assert container_to_bytes(dict(a=[u'abc', dict(b=u'123')])) == dict(a=['abc', dict(b='123')])
    assert container_to_bytes(tuple(u'abc')) == ('abc',)
    assert container_to_bytes(tuple(u"\u2018\u2019")) == ('\xe2\x80\x98', '\xe2\x80\x99')

# Generated at 2022-06-22 22:04:24.835207
# Unit test for function to_bytes

# Generated at 2022-06-22 22:04:36.441021
# Unit test for function to_bytes
def test_to_bytes():
    class UnknownObject:
        def __str__(self):
            return u'unknown'

        def __repr__(self):
            return u'unknown'

    # Simple bytes
    assert b'foo' == to_bytes(b'foo')
    assert b'foo' == to_bytes(b'foo', 'ascii')

    # Bytes that aren't valid in the specified encoding
    if PY3:
        assert b'foo' == to_bytes(b'foo', 'utf-8')
    else:
        assert b'foo' == to_bytes(b'foo', 'utf-8', nonstring='empty')

    # Non-strings
    assert b'' == to_bytes(None)
    assert b'True' == to_bytes(True)
    assert b'42' == to_bytes(42)
   

# Generated at 2022-06-22 22:04:48.684328
# Unit test for function container_to_text
def test_container_to_text():
    assert "foo" == container_to_text("foo")
    assert ["foo"] == container_to_text(["foo"])
    assert ("foo", ) == container_to_text(("foo", ))
    assert {"foo":"bar"} == container_to_text({"foo":"bar"})
    assert {"foo":{"bar":"baz"}} == container_to_text({"foo":{"bar":"baz"}})
    assert {"foo":{"bar":["baz","qux","quux"]}} == container_to_text({"foo":{"bar":["baz","qux","quux"]}})

    assert {"foo":{"bar":{"qux":b"quux"}}} == container_to_text({"foo":{"bar":{"qux":b"quux"}}}, encoding='latin-1')
    assert {"foo":b"bar"} == container_

# Generated at 2022-06-22 22:04:59.109740
# Unit test for function container_to_text
def test_container_to_text():
    funcs = [text_type, container_to_text, to_text]
    d = {b"a": b"b"}
    d[b"c"]  = d[b"a"]
    d[b"foo"]= {b"bar": b"baz"}
    d[b"foo2"]= [b"bar", b"baz"]
    d[b"foo3"]= (b"bar", b"baz")
    d[b"foo4"]= {(b"bar", b"baz"): (b"bar", b"baz")}
    d[b"foo5"]= {b"bar": [b"baz", b"bar"], b"bar2": [b"baz", b"bar"]}

# Generated at 2022-06-22 22:05:10.424548
# Unit test for function container_to_text
def test_container_to_text():
    """Unit test for function container_to_text.
    """
    # pylint: disable=invalid-name
    # noqa: F841
    data = [
        1, 2, 3,
        ['a', 'b', 'c'],
        ('d', 'e', 'f'),
        {'g': 'h', 'i': 'j'}
    ]
    data_bytes = [
        1, 2, 3,
        [b'a', b'b', b'c'],
        (b'd', b'e', b'f'),
        {b'g': b'h', b'i': b'j'}
    ]
    result = container_to_text(data_bytes)
    assert data == result

# Generated at 2022-06-22 22:05:21.574034
# Unit test for function to_bytes
def test_to_bytes():
    import unittest2

    class TestToBytes(unittest2.TestCase):
        '''Test the to_bytes function'''
        def test_preexisting_bytes(self):
            self.assertEqual(b'some bytes', to_bytes(b'some bytes'))
            self.assertEqual(b'\xe5', to_bytes(b'\xe5'))

        def test_text_objects(self):
            if PY3:
                self.assertEqual(b'\xc3\xa5', to_bytes(u'\u00e5'))
            else:
                self.assertEqual(b'\xc3\xa5', to_bytes(u'\u00e5'.encode('utf8')))

        def test_all_ascii(self):
            self

# Generated at 2022-06-22 22:05:33.031427
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text({'text1': u'hej', 'text2': u'h\xe9j'}) == {'text1': 'hej', 'text2': u'h\xe9j'}
    assert container_to_text({'text1': 'hej', 'text2': u'h\xe9j'}) == {'text1': 'hej', 'text2': u'h\xe9j'}
    assert container_to_text({'text1': 'hej', 'text2': 'h\xe9j'}) == {'text1': 'hej', 'text2': u'h\xe9j'}

# Generated at 2022-06-22 22:05:42.925848
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' Make sure that container_to_bytes works as expected

        This function tests container_to_bytes with several cases that are
        known to have caused problems in the past.  If you fix a bug in
        container_to_bytes, add a new test case to this function.
    '''

# Generated at 2022-06-22 22:05:54.657461
# Unit test for function to_native
def test_to_native():
    assert to_native(b'abc', errors='surrogate_or_strict') == 'abc'
    assert to_native(u'abc', errors='surrogate_or_strict') == u'abc'
    assert to_native(b'\x80') == '\x80'
    assert to_native(b'\x80', errors='strict') == '\x80'
    #assert to_native(b'\x80', errors='surrogate_or_strict') == '\udc80'
    assert to_native(u'\udc80') == u'\udc80'
    assert to_native(u'\udc80', errors='surrogateescape') == u'\udc80'

# Generated at 2022-06-22 22:06:02.880507
# Unit test for function to_native
def test_to_native():
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-statements
    import sys

    # We want to test that the following errors

# Generated at 2022-06-22 22:06:12.351826
# Unit test for function container_to_text
def test_container_to_text():
    a_str = "m\xe9tal"
    test_dict = {'text': to_bytes(a_str, encoding='utf-8'), 'list': [a_str, to_bytes(a_str, encoding='utf-8')], 'tuple': (a_str, to_bytes(a_str, encoding='utf-8'))}
    assert container_to_text(test_dict, encoding='utf-8')['text'] == a_str
    assert container_to_text(test_dict, encoding='utf-8')['list'][0] == a_str
    assert container_to_text(test_dict, encoding='utf-8')['list'][1] == a_str
    assert container_to_text(test_dict, encoding='utf-8')['tuple'][0] == a_str


# Generated at 2022-06-22 22:06:17.891255
# Unit test for function jsonify
def test_jsonify():
    """Ensure we can encode a single unicode character as json."""
    # This is a single unicode character outside of the ascii range.
    data = '\u2713'
    json.dumps(data)
    # This is the same unicode character, but as utf-8 encoded bytes.
    data = b'\xe2\x9c\x93'
    json.dumps(data)



# Generated at 2022-06-22 22:06:29.362871
# Unit test for function container_to_bytes
def test_container_to_bytes():
    input_dict = {'foo': 'bar', 'baz': ['qux', 'quux'], 'corge': 'grault'}
    output = container_to_bytes(input_dict, encoding='latin-1')
    if not (isinstance(list(output.keys())[0], binary_type) and
            isinstance(list(output.values())[0], binary_type) and
            isinstance(list(output.values())[1][0], binary_type)):
        raise AssertionError('container_to_bytes() did not convert all strings to byte strings')
    input_list = ['foo', 'bar', 'baz', 'qux']
    output = container_to_bytes(input_list, encoding='utf-8')

# Generated at 2022-06-22 22:06:41.557877
# Unit test for function to_native
def test_to_native():
    '''
    Test to_native function with various inputs
    '''
    from ansible.module_utils._text import to_native
    # pylint: disable=unused-variable
    # In Python 3 all strings are unicode.  There's no need to encode to bytes
    # to test this function
    if PY3:
        unicode_type = str
    else:
        unicode_type = text_type

    # Bytes encoded in latin-1
    test_string = b'Hello \xd2\x90 world'
    assert isinstance(to_native(test_string), unicode_type)
    assert isinstance(to_native(test_string, nonstring='empty'), unicode_type)
    assert isinstance(to_native(test_string, nonstring='passthru'), binary_type)



# Generated at 2022-06-22 22:06:42.525752
# Unit test for function container_to_bytes
def test_container_to_bytes():
    pass



# Generated at 2022-06-22 22:06:49.535055
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({u'foo': u'bar'}) == {b'foo': b'bar'}
    assert container_to_bytes([u'foo', u'bar']) == [b'foo', b'bar']
    assert container_to_bytes((u'foo', u'bar')) == (b'foo', b'bar')
    assert container_to_bytes(u'foo') == b'foo'



# Generated at 2022-06-22 22:06:57.152235
# Unit test for function to_native
def test_to_native():
    unicode_string = u'\u2019'
    testStrings = [u'Manoj is a good guy', u'\u2019', b'abc', 1, 0, 'abc']
    expectedStrings = ['Manoj is a good guy', unicode_string, 'abc', '1', '0', 'abc']
    for index in range(len(testStrings)):
        val = to_native(testStrings[index])
        assert val == expectedStrings[index]


# Generated at 2022-06-22 22:07:04.814071
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(foo=u'bar', baz=[u'qux', u'quux'])) == '{"baz": ["qux", "quux"], "foo": "bar"}'
    assert jsonify(dict(foo=u'bar', baz={u'qux': u'quux'})) == '{"baz": {"qux": "quux"}, "foo": "bar"}'
    assert jsonify(u'\u1234') == u'"\u1234"'



# Generated at 2022-06-22 22:07:14.696307
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text({'a': b'hello'}) == {'a': 'hello'}
    assert container_to_text([b'hello']) == ['hello']
    assert container_to_text((b'hello',)) == ('hello',)
    for i in range(4):
        for j in range(4):
            if (i, j) == (3, 3):
                continue
            assert container_to_text({'a': b'hello'}, errors=['strict', 'replace', 'surrogateescape', 'surrogate_or_strict'][i], encoding=['utf-8', 'ascii', 'latin-1', 'base64'][j]) == {'a': 'hello'}

# Generated at 2022-06-22 22:07:24.078161
# Unit test for function container_to_bytes
def test_container_to_bytes():
    """Function test_container_to_bytes
    This function tests container_to_bytes with many different data types

    """
    test_data_types = {text_type('string'):b'string',
                       42: 42,
                       int(42): int(42),
                       long(42): long(42),
                       float(42): float(42),
                       1.1: 1.1,
                       complex(42): complex(42),
                       set([1,2,3]): set([1,2,3]),
                       frozenset([1,2,3]): frozenset([1,2,3]),
                       None: None,
                       }
    for k,v in iteritems(test_data_types):
        assert container_to_bytes(k) == v


# Generated at 2022-06-22 22:07:25.970343
# Unit test for function to_native
def test_to_native():
    assert to_text(b'foo') == u'foo'
    assert to_text(u'foo') == u'foo'



# Generated at 2022-06-22 22:07:32.671284
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {
        "name": "a b c",
        "child": {
            "name": "a b c",
            "child": {
                "name": "a b c",
            }
        }
    }
    assert container_to_bytes(d) == {
        "name": b"a b c",
        "child": {
            "name": b"a b c",
            "child": {
                "name": b"a b c",
            }
        }
    }
    assert container_to_bytes(d, encoding='iso-8859-1') == {
        "name": b"a b c",
        "child": {
            "name": b"a b c",
            "child": {
                "name": b"a b c",
            }
        }
    }


# Generated at 2022-06-22 22:07:45.963786
# Unit test for function jsonify
def test_jsonify():
    import json
    from ansible.module_utils._text import jsonify
    from collections import OrderedDict
    from datetime import datetime
    from ansible.module_utils.common._collections_compat import Set
    # jsonify tuples of python primitives
    assert jsonify((1,2,'3')) == json.dumps((1,2,'3'))
    # jsonify python dict
    py_dict = {'int': 1, 'float': 0.1, None: 'nonetype', 'str': "mys\xe8", 'bool': False}
    assert isinstance(jsonify(py_dict), str)
    assert jsonify(py_dict) == json.dumps(py_dict)
    # jsonify python lists

# Generated at 2022-06-22 22:07:57.607268
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.six import u
    from ansible.module_utils.six.moves import StringIO

    assert to_bytes(u('foo')) == b'foo'
    assert to_bytes(u('foo'), encoding='ascii') == b'foo'
    assert to_bytes(u('f\uFFFD'), encoding='ascii') == b'f\xef\xbf\xbd'
    assert to_bytes(u('f\uFFFD'), encoding='latin-1') == b'f\xff'
    assert to_bytes(u('f\uFFFD'), encoding='latin-1', errors='surrogate_or_replace') == b'f?'

    # The surrogate_then_replace handler was added in Ansible 2.4

# Generated at 2022-06-22 22:08:09.334560
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(u'foo') == u'foo'
    assert container_to_text('foo') == u'foo'
    assert container_to_text(u'\xe9') == u'\xe9'
    assert container_to_text('\xe9') == u'\xe9'
    assert container_to_text(b'\xc3\xa9') == u'\xe9'

    # dicts
    assert container_to_text({u'foo': u'bar'}) == {u'foo': u'bar'}
    assert container_to_text({'foo': 'bar'}) == {u'foo': u'bar'}
    assert container_to_text({u'foo': b'bar'}) == {u'foo': u'bar'}

# Generated at 2022-06-22 22:08:12.984285
# Unit test for function to_native
def test_to_native():
    for x in [ integer for integer in range(1000)]:
        to_text(x)
        to_bytes(x)
    #for x in [ integer for integer in range(1000)]:
    #    assert to_native(x) == str(x)


# Generated at 2022-06-22 22:08:22.445614
# Unit test for function to_bytes
def test_to_bytes():
    # Failure cases
    # obj is not a string
    b = to_bytes(None)
    assert b == b''
    b = to_bytes(None, nonstring='passthru')
    assert None == b
    try:
        b = to_bytes(None, nonstring='strict')
    except TypeError:
        pass
    else:
        assert False, "Failed to raise TypeError"

    # Success cases
    # Text strings
    b = to_bytes('foo')
    assert isinstance(b, binary_type)
    assert b == b'foo'
    b = to_bytes('фываж')
    assert isinstance(b, binary_type)

# Generated at 2022-06-22 22:08:34.197300
# Unit test for function container_to_text
def test_container_to_text():
    """Unit test for function container_to_text"""

    # Test data
    data_dict = {'num': 5, 'str': 'str', 'str_of_num': '5', 'list': [5, 'str'], 'tuple': (5, 'str'), 'dict': {'num': 5, 'str': 'str'}}
    data_list = [5, 'str']
    data_tuple = (5, 'str')
    data_str = 'str'
    data_num = 5
    data_byte = b'str'
    data_unicode = u'\u1234\u2345'

    # normal test
    result = container_to_text(data_dict)

# Generated at 2022-06-22 22:08:43.939343
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test dict
    d = dict(a=2, b='string', c='\xe4\xf6\xfc')
    e = container_to_bytes(d)
    assert(e[b'a'] == 2)
    assert(e[b'b'] == b'string')
    assert(e[b'c'] == b'\xc3\xa4\xc3\xb6\xc3\xbc')
    # Test list
    d = [2, 'string', '\xe4\xf6\xfc']
    e = container_to_bytes(d)
    assert(e[0] == 2)
    assert(e[1] == b'string')
    assert(e[2] == b'\xc3\xa4\xc3\xb6\xc3\xbc')
    #

# Generated at 2022-06-22 22:08:52.710228
# Unit test for function to_native
def test_to_native():
    assert to_native(b'hello', errors='surrogate_or_strict') == 'hello'
    assert to_native(b'hello', errors='surrogate_then_replace') == 'hello'
    assert to_native(u'hello', errors='surrogate_or_strict') == u'hello'
    assert to_native(u'hello', errors='surrogate_then_replace') == u'hello'
    assert to_native(b'\xff', errors='surrogate_or_strict') == u'\ufffd'
    assert to_native(b'\xff', errors='surrogate_then_replace') == u'\ufffd'
    assert to_native(u'\U0001d11e', errors='surrogate_or_strict') == u'\U0001d11e'

# Generated at 2022-06-22 22:08:54.391730
# Unit test for function to_native
def test_to_native():
    # Test that to_native() is the same as to_text() in Python3
    if PY3:
        assert to_native is to_text



# Generated at 2022-06-22 22:09:02.851259
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(b"foo") == b"foo"
    assert container_to_bytes([b"foo", b"bar"]) == [b"foo", b"bar"]
    assert container_to_bytes((b"foo", b"bar")) == (b"foo", b"bar")
    assert container_to_bytes({b"foo": b"bar"}) == {b"foo": b"bar"}
    assert container_to_bytes({b"foo": b"bar", b"baz": [b"foo", b"bar"]}) == {b"foo": b"bar", b"baz": [b"foo", b"bar"]}

# Generated at 2022-06-22 22:09:14.609902
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text('hi') == u'hi'
    assert container_to_text(u'hi') == u'hi'
    assert container_to_text(b'hi') == u'hi'
    assert container_to_text([b'hi']) == [u'hi']
    assert container_to_text({b'key': b'value'}) == {u'key': u'value'}
    assert container_to_text({u'key': b'value'}) == {u'key': u'value'}
    assert container_to_text({'key': b'value'}) == {u'key': u'value'}
    assert container_to_text({b'key': u'value'}) == {u'key': u'value'}

# Generated at 2022-06-22 22:09:24.797548
# Unit test for function container_to_bytes
def test_container_to_bytes():
    '''
    Tests for container_to_bytes function
    '''
    # no unicode test
    assert container_to_bytes({'a': 'a'}) == {'a': 'a'}

    # a unicode string and a non string test
    assert isinstance(container_to_bytes({'a': u'a'})['a'], bytes_type)
    assert container_to_bytes({'a': 1}) == {'a': 1}

    # nested unicode and non string tests
    assert (container_to_bytes({'a': {'b': u'b', 'c': 2}}) ==
            {'a': {'b': b'b', 'c': 2}})

# Generated at 2022-06-22 22:09:32.267991
# Unit test for function to_bytes
def test_to_bytes():
    uni_string = u'\u043a\u0438\u0440\u0438\u043b\u043b\u0438\u0447\u0435\u0441\u043a\u0438\u0439'
    uni_string_utf16 = u'\u0439\u0446'
    byte_string_utf16 = codecs.BOM_UTF16 + uni_string_utf16.encode('utf-16-le')
    utf8_byte_string = uni_string.encode('utf-8')

# Generated at 2022-06-22 22:09:41.656742
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'abcd') == b'abcd'
    assert to_bytes('abcd') == b'abcd'
    assert to_bytes(u'abcd') == b'abcd'
    assert to_bytes(b'\xff\xfe\xfd') == b'\xff\xfe\xfd'
    assert to_bytes(u'\uffff') == b'\xef\xbf\xbf'
    assert to_bytes(u'\uffff', encoding='latin-1') == b'\xff'
    assert to_bytes(u'\uffff', encoding='ascii', errors='surrogate_or_strict') == b'?'

# Generated at 2022-06-22 22:09:53.426858
# Unit test for function to_native
def test_to_native():

    def _validate_to_native(value, expected):
        result = to_native(value)
        assert result == expected, (result, expected)

    # Invalid nonstrings
    _validate_to_native(None, 'None')
    _validate_to_native(1, u'1')
    _validate_to_native(1.5, u'1.5')
    _validate_to_native([1, 2, 3], u'[1, 2, 3]')
    _validate_to_native({'a': 1}, u"{'a': 1}")
    _validate_to_native(Set([1, 2, 3]), u'[1, 2, 3]')

    # Valid nonstrings

# Generated at 2022-06-22 22:10:04.450426
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(dict(a=1, b=dict(c=3))) == dict(a=1, b=dict(c=3))
    assert container_to_bytes(dict(a=1, b=u'abc')) == dict(a=1, b='abc')
    assert container_to_bytes(dict(a=1, b=u'\xe9')) == dict(a=1, b='\xc3\xa9')
    assert container_to_bytes(dict(a=1, b=u'\xe9'), encoding='latin-1') == dict(a=1, b='\xe9')
    assert container_to_bytes(dict(a=1, b=u'\xe9'), errors='ignore') == dict(a=1, b='')
    assert container_to_bytes

# Generated at 2022-06-22 22:10:16.563905
# Unit test for function container_to_text
def test_container_to_text():
    '''
    This is a unit test to ensure that the container_to_text() function is working correctly.
    '''
    x = '\xe7\xb1\xb3\xe5\xa5\xbd'
    y = '米好'
    test_dict = {'good': y, 'bad': x}
    assert container_to_bytes(test_dict) == test_dict
    test_dict_decoded = container_to_text(test_dict)
    assert isinstance(test_dict_decoded, dict)
    assert test_dict_decoded['good'] == y
    assert test_dict_decoded['bad'] == '?好'
    test_list = [y, x]
    assert container_to_bytes(test_list) == test_list
    test_list_dec

# Generated at 2022-06-22 22:10:28.751576
# Unit test for function jsonify
def test_jsonify():
    dict_key = dict()
    dict_key['a'] = 'a'
    dict_key['b'] = 'b'
    dict_key['c'] = 'c'
    set_key = set()
    set_key.add('a')
    set_key.add('b')
    set_key.add('c')
    arr_key = []
    arr_key.append('a')
    arr_key.append('b')
    arr_key.append('c')
    sample = dict()
    sample['dict_key'] = dict_key
    sample['set_key'] = set_key
    sample['arr_key'] = arr_key
    json_data = jsonify(sample)

# Generated at 2022-06-22 22:10:42.205731
# Unit test for function container_to_text
def test_container_to_text():

    # dict
    if PY3:
        dict_bytes = {"key": b"byte_val", "key2": b"byte_val2"}
        dict_unicode = {"key": "\u00c9", "key2": "\u00c8"}
        dict_complex = {"key": u"val", "key2": [1, 2, 3], "key3": [4, 5, 6],
                        "key4": [{"key": u"val", "key2": [1, 2, 3], "key3": [4, 5, 6], "key4": [7, 8, 9]}]}
    else:
        dict_bytes = {"key": "byte_val", "key2": "byte_val2"}

# Generated at 2022-06-22 22:10:54.876450
# Unit test for function to_native
def test_to_native():
    assert to_bytes(42) == b'42'
    assert to_bytes(42, nonstring='strict') is TypeError
    assert to_bytes(b'42') == b'42'
    assert to_bytes(b'\xff') == b'\xff'
    assert to_bytes('\xff') == b'\xc3\xbf'

    assert to_text(42) == u'42'
    assert to_text(42, nonstring='strict') is TypeError
    assert to_text(u'42') == u'42'
    assert to_text(b'42') == u'42'
    assert to_text(b'\xff') == u'\ufffd'
    assert to_text(u'\xff') == u'\xff'



# Generated at 2022-06-22 22:10:59.349553
# Unit test for function jsonify
def test_jsonify():
    data = {u'foo': u'bar'}
    result = jsonify(data)
    assert result == '{"foo": "bar"}'

# Generated at 2022-06-22 22:11:10.143674
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b"foo") == b"foo"
    assert to_bytes(u"foo") == b"foo"
    assert to_bytes(bytearray(b"foo")) == b"foo"
    assert to_bytes(bytearray(u"foo")) == b"foo"
    assert to_bytes(b"foo".decode("ascii", "surrogateescape")) == b"foo"
    assert to_bytes(u"foo\udcff".encode("ascii", "surrogateescape")) == b"foo\xdc\xff"
    assert to_bytes(b"foo\xdc\xff".decode("ascii", "surrogateescape"),
                    encoding="ascii", errors="surrogate_then_replace") == "foo??"


# Generated at 2022-06-22 22:11:21.328031
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {u"testÜ": u"testЖ"}
    assert (container_to_bytes(d) == {b"test\xc3\x9c": b"test\xd0\x96"})
    assert (container_to_bytes(d, errors="surrogate_or_ignore") == {b"test\xc3\x9c": b"test\xd0\x96"})
    assert (container_to_bytes(d, errors="surrogate_or_replace") == {b"test?": b"test?"})
    assert (container_to_bytes(d, errors="surrogate_then_replace") == {b"test?": b"test?"})
    assert (container_to_bytes(d, errors="ignore") == {b"test": b"test"})

# Generated at 2022-06-22 22:11:29.810156
# Unit test for function jsonify
def test_jsonify():
    first_test = {u"user": u"\u05e9\u05dc\u05dd" }
    second_test = {u"user": "\xe9\xdc\xdd" }
    test_1 = jsonify(first_test)
    test_2 = jsonify(second_test)
    assert test_1 == '{"user":"\u05e9\u05dc\u05dd"}'
    assert test_2 == '{"user":"\\xe9\\xdc\\xdd"}'



# Generated at 2022-06-22 22:11:41.154805
# Unit test for function container_to_text
def test_container_to_text():
    d = {'k1': "ÄÖÜ".encode("iso-8859-1")}
    result = container_to_text(d, "iso-8859-1")
    assert result == {u'k1': u'\xc4\xd6\xdc'}
    d = {'k1': "ÄÖÜ".encode("utf-8")}
    result = container_to_text(d, "iso-8859-1")
    assert result == {u'k1': u'\xc3\x84\xc3\x96\xc3\x9c'}
    d = {'k1': b'\xff'}
    result = container_to_text(d, "iso-8859-1")
    # This is actually correct ; ISO-8859-1