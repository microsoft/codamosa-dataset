

# Generated at 2022-06-22 22:01:47.904554
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(u'string') == u'string'
    assert container_to_text('string') == u'string'
    assert container_to_text(b'string') == u'string'
    assert container_to_text(b'\xff\xff') == u'\ufffd\ufffd'
    assert container_to_text({'a': 'string', 'c': b'string'}) == {'a': u'string', 'c': u'string'}
    assert container_to_text(['a', 'string', 'string']) == [u'a', u'string', u'string']
    assert container_to_text(('a', 'string', 'string')) == (u'a', u'string', u'string')

# Unit

# Generated at 2022-06-22 22:01:58.184363
# Unit test for function to_native
def test_to_native():
    assert to_native(str('\xe2\x80\xaf')) == '\\xe2\\x80\\xaf'
    assert to_native(str('\xe2\x80\xaf'), encoding='latin-1') == '\\xe2\\x80\\xaf'
    assert to_native(str('\xe2\x80\xaf'), encoding='latin-1', errors='surrogate_or_strict') == '\\xe2\\x80\\xaf'
    assert to_native(str('\xe2\x80\xaf'), encoding='latin-1', errors='surrogate_or_replace') == '?'
    assert to_native(str('\xe2\x80\xaf'), errors='surrogate_then_replace') == '?'

# Generated at 2022-06-22 22:02:05.982505
# Unit test for function to_bytes
def test_to_bytes():

    # Test surrogate_then_replace (the default)
    try:
        # This is a case where surrogateescape won't work:
        nonbmp_codepoint = to_text(int('0x10000'))
        this_string_was_not_surrogate_encodable = nonbmp_codepoint.encode('gbk', 'surrogateescape')
    # If surrogateescape is available, we should get a UnicodeEncodeError
    except UnicodeEncodeError:
        pass
    # If it's not available, we don't get the error so we need to skip to avoid a false success
    else:
        this_string_was_not_surrogate_encodable = None
        raise AssertionError('Surrogateescape was not detected')


# Generated at 2022-06-22 22:02:11.353758
# Unit test for function jsonify
def test_jsonify():
    data = dict(invalid_utf8_field=b'\x80abc\xff')
    result = jsonify(data)
    assert result == '{"invalid_utf8_field": "\\u008abc\\ufffd"}'



# Generated at 2022-06-22 22:02:20.419439
# Unit test for function to_native
def test_to_native():
    assert to_native('foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'foo') == u'foo'

    assert to_native(b'\xc3\xa9') == u'\u00e9'
    assert to_native(u'\u00e9') == u'\u00e9'
    assert to_native(u'\u03b1') == u'\u03b1'
    assert to_native(b'\xce\xb1') == u'\u03b1'

    # even if the text has surrogates, we should get back a text object
    fake_surrogates = b'a\xed\xa0\x80b'

# Generated at 2022-06-22 22:02:32.386385
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_str = u'\u7f51\u7edc'
    test_dict = {test_str: test_str}
    test_list = [test_str]
    test_tuple = (test_str,)
    converted_dict = container_to_bytes(test_dict, encoding='utf-8', errors='surrogate_or_replace')
    assert isinstance(converted_dict, dict)
    for k in converted_dict.keys():
        assert isinstance(k, binary_type)
        assert k.decode('utf-8', 'surrogate_or_replace') == test_str
        assert k.decode('utf-8', 'surrogate_or_replace') == converted_dict[k].decode('utf-8', 'surrogate_or_replace')

# Generated at 2022-06-22 22:02:41.388470
# Unit test for function container_to_text
def test_container_to_text():
    ''' Test function container_to_text'''
    # Prepare
    d = {'a':'abc', 'b':b'efg'}
    d2 = {'a':['abc'], 'b':(b'efg',)}
    d3 = {b'a':['abc'], 'b':(b'efg',)}

    # Test
    result = container_to_text(d)
    result = container_to_text(d2)
    result = container_to_text(d3)

    # Verify
    assert result['a'] == 'abc'
    assert isinstance(result['a'], text_type)
    assert result['b'] == 'efg'
    assert isinstance(result['b'], text_type)

    assert result['b'][0] == 'efg'
   

# Generated at 2022-06-22 22:02:54.204398
# Unit test for function to_native
def test_to_native():
    if PY3:
        # native should be text
        assert to_native(u'hello') == 'hello'
        assert to_native('hello') == 'hello'
        assert to_native(b'hello') == 'hello'
        assert str(to_native(False)) == 'False'
        assert str(to_native(10)) == '10'
        f = 10.0
        assert to_native(f) == '10.0'
        assert str(to_native(bytearray(b'hello'))) == "b'hello'"
    else:
        # native should be bytes
        assert to_native(u'hello') == 'hello'
        assert to_native('hello') == 'hello'
        assert to_native(b'hello') == 'hello'

# Generated at 2022-06-22 22:03:05.924979
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Assert for text_type
    assert container_to_bytes(u'i am text') == u'i am text'
    # Assert for dict type
    assert container_to_bytes({'k1': u'v1', u'k2': [u'v2'], u'k3': {u'k4': u'v4'}, u'k5': (u'v5', u'v6')}) == {
        'k1': u'v1', u'k2': [u'v2'], u'k3': {u'k4': u'v4'}, u'k5': (u'v5', u'v6')}
    # Assert for list type

# Generated at 2022-06-22 22:03:11.115382
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.six import b
    from tests.module_utils import _test_params

    wrong_type = object()
    for test_params in _test_params:
        # No encodings specified
        assert to_bytes(test_params.text, 'ascii') == b(test_params.bytes)
        assert to_bytes(b(test_params.bytes), 'ascii') == b(test_params.bytes)
        assert to_bytes(wrong_type, 'ascii', nonstring='passthru') == wrong_type
        assert to_bytes(wrong_type, 'ascii', nonstring='empty') == b('')
        assert to_bytes(wrong_type, 'ascii', nonstring='strict') == b('')

        # Test that if we call with surrogate

# Generated at 2022-06-22 22:03:22.088332
# Unit test for function container_to_text
def test_container_to_text():
    '''Unit test for function container_to_text'''

    assert container_to_text(u"\u3042") == u"\u3042"
    assert container_to_text(u"\u7a7a") != u"\u7a7a"
    assert container_to_text(b"\xe3\x81\x82") == u"\u3042"
    assert container_to_text(b"\xe7\xa9\xba") != u"\u7a7a"
    assert container_to_text({"a": b"\xe3\x81\x82"}) == {"a": u"\u3042"}
    l = [b"\xe3\x81\x82", b"\xe7\xa9\xba"]
    assert container_to_text

# Generated at 2022-06-22 22:03:31.804663
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' Unit tests for function container_to_bytes '''
    # container_to_bytes is called as container_to_bytes(d, 'utf-8', errors='surrogate_or_strict')
    # Set up the input and expected output

# Generated at 2022-06-22 22:03:44.311743
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = dict(
        text='ascii',
        textunicode=u'unicode',
        int=19,
        list=range(3),
        dict=dict(a=1, b=2),
        dictunicode=dict(a=u'1', b=u'2'),
        tuple=('list', 'of', 'strings'),
        tupleunicode=(u'list', u'of', u'strings')
    )


# Generated at 2022-06-22 22:03:53.923129
# Unit test for function jsonify
def test_jsonify():
    # test jsonify()
    data = dict(a=u'中文', b='bbb', c=[1, 2, 3])
    json_data = jsonify(data)
    assert json_data == '{"a": "\\u4e2d\\u6587", "c": [1, 2, 3], "b": "bbb"}'

    # test jsonify() with encoding='latin-1'
    data = dict(a=u'中文', b='bbb', c=[1, 2, 3])
    json_data = jsonify(data, encoding='latin-1')
    assert json_data == '{"a": "\\u4e2d\\u6587", "c": [1, 2, 3], "b": "bbb"}'

    # test jsonify() with encoding='utf-8

# Generated at 2022-06-22 22:04:05.895839
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({u'key': u'value'}) == {b'key': b'value'}
    assert container_to_bytes({u'key': u'value'}, 'ascii', 'replace') == {b'key': b'value'}
    assert container_to_bytes([u'value']) == [b'value']
    assert container_to_bytes([u'value'], 'ascii', 'replace') == [b'value']
    assert container_to_bytes((u'value',)) == (b'value',)
    assert container_to_bytes((u'value',), encoding='ascii', errors='replace') == (b'value',)

# Generated at 2022-06-22 22:04:15.828889
# Unit test for function container_to_text
def test_container_to_text():
    aDict = {
        u'a' : u'b',
        u'c' : u'd'
    }
    aList = [u'a', u'b']
    aTuple = (u'a', u'b')
    aText = u'a'
    aByte = b'a'
    assert(container_to_text(aDict) == aDict)
    assert(container_to_text(aList) == aList)
    assert(container_to_text(aTuple) == aTuple)
    assert(container_to_text(aText) == aText)
    assert(container_to_text(aByte) == aText)
    # test that an exception is raised if a non-string and non-container value is passed in

# Generated at 2022-06-22 22:04:19.330479
# Unit test for function container_to_text
def test_container_to_text():
    dict_ex = {b'host': b'localhost', u'port': u'22', u'username': u'root', u'password': u'#'}
    actual_result = container_to_text(dict_ex)
    expected_result = {u'host': u'localhost', u'port': u'22', u'username': u'root', u'password': u'#'}

    assert expected_result == actual_result

# Generated at 2022-06-22 22:04:24.411046
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(to_bytes('string')) == to_bytes('"string"')
    assert jsonify(to_bytes('{"python":"rocks"}')) == to_bytes('{"python":"rocks"}')
    assert jsonify(to_bytes('string', encoding='latin-1')) == to_bytes('"string"')
    assert jsonify(to_bytes('{"python":"rocks"}', encoding='latin-1')) == to_bytes('{"python":"rocks"}')
    assert jsonify([to_bytes('string', encoding='latin-1'), to_bytes('string', encoding='latin-1')]) == to_bytes('["string","string"]')
    assert jsonify(dict(data=to_bytes('string', encoding='latin-1'))) == to_bytes('{"data":"string"}')

# Generated at 2022-06-22 22:04:35.795166
# Unit test for function jsonify
def test_jsonify():
    if not PY3:
        assert jsonify({'foo': b'bar'}) == '{"foo": "bar"}'
        assert jsonify({'foo': b'\xc3\xa9'}) == '{"foo": "\\u00e9"}'
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': u'\u00e9'}) == '{"foo": "\\u00e9"}'
    if not PY3:
        assert jsonify({'foo': '\xc3\xa9'}) == '{"foo": "\\u00e9"}'
    assert jsonify({'foo': '\u00e9'}) == '{"foo": "\\u00e9"}'



# Generated at 2022-06-22 22:04:47.783705
# Unit test for function container_to_text
def test_container_to_text():
    # This should be text_type
    assert isinstance(container_to_text({"key": b'value'}), text_type)

    # This should be text_type
    assert isinstance(container_to_text({"key": to_bytes("value", 'utf-8', 'surrogate_or_strict')}), text_type)

    # This should be text_type
    assert isinstance(container_to_text({"key": b'\x80'}), text_type)

    # This should be text_type
    assert isinstance(container_to_text({"key": to_bytes('\x80', 'utf-8', 'surrogate_or_strict')}), text_type)

    # This should be text_type

# Generated at 2022-06-22 22:04:56.042865
# Unit test for function jsonify
def test_jsonify():
    data1 = {u'foo': u'bar'}
    assert jsonify(data1, ensure_ascii=False) == '{"foo": "bar"}'
    data2 = {u'foo': [1,2,3]}
    assert jsonify(data2, ensure_ascii=False) == '{"foo": [1, 2, 3]}'
    data3 = {u'foo': {u'bar': u'baz'}}
    assert jsonify(data3, ensure_ascii=False) == '{"foo": {"bar": "baz"}}'



# Generated at 2022-06-22 22:05:03.816179
# Unit test for function container_to_text
def test_container_to_text():
    # dictionary
    d = {'a': 'b', u'a1': u'\u6f22\u5b57', 'c': None, 'd': 3, u'e': u'\u4f60'}
    new_d = container_to_text(d, "utf-8")
    assert isinstance(new_d, dict)
    assert isinstance(new_d['a'], text_type)
    assert new_d['a'] == u'b'
    assert isinstance(new_d['c'], text_type)
    assert new_d['c'] == u'None'

    # list
    l = [d, 1, 3, None]
    new_l = container_to_text(l, "utf-8")
    assert isinstance(new_l, list)

# Generated at 2022-06-22 22:05:15.466746
# Unit test for function to_bytes
def test_to_bytes():
    if PY3:
        ORIGINAL_STRING = u'\udcc3'
        ENCODED_BYTES = b'\xed\xb3\x83'
    else:
        ORIGINAL_STRING = u'\udcc3'.encode('utf-8')
        ENCODED_BYTES = u'\udcc3'.encode('utf-8')

    assert to_bytes(ORIGINAL_STRING, 'utf-8') == ENCODED_BYTES
    assert to_bytes(ORIGINAL_STRING, 'utf-8', 'ignore') == b''
    assert to_bytes(ORIGINAL_STRING, 'utf-8', 'replace') == b'?'
    assert to_bytes(ORIGINAL_STRING, 'utf-8', 'xmlcharrefreplace')

# Generated at 2022-06-22 22:05:19.912857
# Unit test for function jsonify
def test_jsonify():
    assert jsonify([u'\N{CYRILLIC CAPITAL LETTER A}']) == '["\\u0410"]'
    assert jsonify({u'a': u'\N{CYRILLIC CAPITAL LETTER A}'}) == '{"a": "\\u0410"}'


# Generated at 2022-06-22 22:05:30.776935
# Unit test for function container_to_text
def test_container_to_text():
    """Unit test for function container_to_text"""
    assert container_to_text(u'abc') == u'abc'
    assert container_to_text(b'abc') == u'abc'
    assert container_to_text([b'abc', u'abc']) == [u'abc', u'abc']
    assert container_to_text([u'abc', b'abc']) == [u'abc', u'abc']
    assert container_to_text((b'abc', u'abc')) == (u'abc', u'abc')
    assert container_to_text((u'abc', b'abc')) == (u'abc', u'abc')

# Generated at 2022-06-22 22:05:41.265596
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('abcd') == b'abcd'
    assert to_bytes(b'abcd') == b'abcd'
    assert to_bytes(u'abcd') == b'abcd'
    assert to_bytes(u'\u611b') == b'\xe6\x84\x9b'
    assert to_bytes(b'\xc3\xa6') == b'\xc3\xa6'
    assert to_bytes(u'\u611b', nonstring='simplerepr') == b"u'\xe6\x84\x9b'"
    assert to_bytes(u'\u611b', nonstring='empty') == b''

# Generated at 2022-06-22 22:05:48.246673
# Unit test for function jsonify
def test_jsonify():
    data = {'test': u'My name is S\xf8ren'}
    try:
        ret = jsonify(data)
    except UnicodeError:
        # Old systems using old simplejson module.  Should be fixed
        # in Galaxy.
        ret = jsonify(data)
    assert ret == '{"test": "My name is S\\u00f8ren"}'


BINARY_TYPES = set([bytes])



# Generated at 2022-06-22 22:05:56.517759
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_string = {
        u'insensitive': True,
        u'args': [
            1,
            2,
            3,
        ],
        u'kwalist': {
            u'dict': True,
            u'args': (1,2,3),
        },
    }
    assert container_to_bytes({}) == {}
    assert container_to_bytes(test_string) == {
        b'insensitive': True,
        b'args': [
            1,
            2,
            3,
        ],
        b'kwalist': {
            b'dict': True,
            b'args': (1,2,3),
        },
    }

# Generated at 2022-06-22 22:06:07.342411
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_replace') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_strict') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_then_replace') == b'foo'
    assert to_bytes(u'foo', errors='strict') == b'foo'
    assert to_bytes(u'foo', encoding='ascii') == b'foo'
    assert to_bytes(u'fòô', encoding='ascii', errors='replace') == b'f?o?'

# Generated at 2022-06-22 22:06:17.799396
# Unit test for function to_bytes
def test_to_bytes():
    # Test the first use case: byte string in, byte string out
    assert to_bytes(b'hello') == b'hello'
    assert isinstance(to_bytes(b'hello'), binary_type)

    # Test the second use case: unicode in, byte string out
    # Try a normal string
    assert to_bytes(u'hello') == b'hello'
    assert isinstance(to_bytes(u'hello'), binary_type)

    # Try with a non-ascii string
    if PY3:
        assert to_bytes(u'hëllö') == b'h\xc3\xabl\xc3\xb6'
        assert isinstance(to_bytes(u'hëllö'), binary_type)

# Generated at 2022-06-22 22:06:29.287214
# Unit test for function container_to_text
def test_container_to_text():
    assert u'a' == container_to_text(u'b')
    assert isinstance(container_to_text([u'a']), list)
    assert [u'a'] == container_to_text([u'b'])
    assert isinstance(container_to_text(u'a'), text_type)
    assert isinstance(container_to_text([b'a']), list)
    assert [b'a'] == container_to_text([b'b'])
    assert isinstance(container_to_text(b'a'), text_type)
    assert isinstance(container_to_text(b'abc'), text_type)
    assert isinstance(container_to_text({u'a': [u'b']}), dict)
    assert {u'a': [u'b']} == container_to_

# Generated at 2022-06-22 22:06:41.510453
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(u"String with unicode: \u20ac") == u"String with unicode: \u20ac"
    assert container_to_text("String with unicode: \xe2\x82\xac".encode("utf-8")) == u"String with unicode: \u20ac"
    assert container_to_text("String with unicode: \xe2\x82\xac".encode("iso-8859-1")) == u"String with unicode: \u20ac"

# Generated at 2022-06-22 22:06:54.106359
# Unit test for function container_to_text
def test_container_to_text():
    # Test Cases
    # TypeError
    my_var = 1
    try:
        container_to_text(my_var)
    except TypeError as e:
        pass
    except:
        raise

    # ValueError
    my_var = {'key':'value'}
    try:
        container_to_text(my_var, errors='invalid')
    except ValueError as e:
        pass
    except:
        raise

    # UnicodeDecodeError
    my_var = '\x80'
    try:
        container_to_text(my_var, errors='strict')
    except UnicodeDecodeError as e:
        pass
    except:
        raise

    # Success
    # OOM-23
    my_var = '\xe4'

# Generated at 2022-06-22 22:07:00.672642
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test a text_type object
    x = u'This is a text_type string'
    y = container_to_bytes(x, encoding='utf-8', errors='surrogate_or_strict')
    assert isinstance(y, binary_type)

    # Test a dict with text_type key and text_type value
    x = {u'key_1': u'value_1', u'key_2': u'value_2'}
    y = container_to_bytes(x, encoding='utf-8', errors='surrogate_or_strict')
    assert isinstance(y, dict)
    assert isinstance(list(y.keys())[0], binary_type)
    assert isinstance(list(y.values())[0], binary_type)

    # Test a list with text_type element
   

# Generated at 2022-06-22 22:07:11.002017
# Unit test for function to_native
def test_to_native():
  # text_x_y test
  to_native("text_x_y")

  # text_x_y_z test
  to_native("text_x_y_z")

  # text test
  to_native("text")

  # 1234 test
  to_native(1234)

  # 0 test
  to_native(0)

  # text_x_y test
  to_native("text_x_y")

  # text_x_y_z test
  to_native("text_x_y_z")

  # text test
  to_native("text")

  # 1234 test
  to_native(1234)

  # 0 test
  to_native(0)

  # text_x_y test
  to_native("text_x_y")

  # text_

# Generated at 2022-06-22 22:07:21.850241
# Unit test for function container_to_text
def test_container_to_text():
    """Unit test for container_to_text"""
    test_dict = {
        'key1': 'value1',
        'key2': {'key3': 'value3'},
        'key4': [
            {'key5': 'value5'},
            'value6',
            {'key7': 'value7'}
        ],
        'key8': (
            {'key9': 'value9'},
            'value10',
            {'key11': 'value11'}
        )
    }


# Generated at 2022-06-22 22:07:30.242237
# Unit test for function to_bytes
def test_to_bytes():
    # bytes is a noop
    assert to_bytes(b'foo') == b'foo'

    # Test str inputs
    assert to_bytes(u'foo', nonstring='strict') == b'foo'
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test non-string inputs
    assert to_bytes(None, nonstring='simplerepr') == b'None'
    assert to_bytes(True, nonstring='simplerepr') == b'True'
    assert to_bytes(10, nonstring='simplerepr') == b'10'

# Generated at 2022-06-22 22:07:42.784515
# Unit test for function to_native
def test_to_native():
    # test_to_native: no native string
    # with_nonstring
    # expect_passthru
    assert '123' == True
    # test_to_native: no native string
    # with_nonstring
    # expect_repr
    assert '123' == True
    # test_to_native: no native string
    # with_nonstring
    # expect_strict
    assert '123' == True
    # test_to_native: no native string
    # with_nonstring
    # expect_repr
    assert '123' == True
    # test_to_native: no native string
    # with_nonstring
    # expect_repr
    assert '123' == True
    # test_to_native: no native string
    # with_nonstring
    # expect_repr

# Generated at 2022-06-22 22:07:52.006073
# Unit test for function jsonify
def test_jsonify():
    print("test_jsonify")
    x_dict = {u'\u6f22': [1, 2, 3]}
    assert u'{"\u6f22": [1, 2, 3]}' == jsonify(x_dict)
    x_dict = {'\xe4\xb8\xad': [1, 2, 3]}
    assert '{"\xe4\xb8\xad": [1, 2, 3]}' == jsonify(x_dict)
    x_dict = {'str': u'\u6f22'}
    assert '{"str": "\u6f22"}' == jsonify(x_dict)
    x_dict = {u'str': '\xe4\xb8\xad'}
    assert '{"str": "\xe4\xb8\xad"}' == jsonify

# Generated at 2022-06-22 22:08:01.976960
# Unit test for function to_native
def test_to_native():
    class BogoStr(object):
        def __repr__(self):
            raise RuntimeError('Oh noes, a recursion!')

# Generated at 2022-06-22 22:08:06.424014
# Unit test for function jsonify
def test_jsonify():
    data = jsonify(dict(a=u'/\u2713'))
    assert data == '{"a": "/\\u2713"}'
    data = jsonify(u'/\u2713')
    assert data == '"/\\u2713"'



# Generated at 2022-06-22 22:08:16.606067
# Unit test for function to_bytes
def test_to_bytes():
    for original in (b'ascii', b'non-ascii: \xe2\x98\xba'):
        for encoding in (b'ascii', b'utf-8', b'latin-1'):
            for errors in (None, b'replace', b'strict', b'ignore'):
                # When input and output encodings are the same
                # and the errors is None, we should get the same value back out
                if encoding == b'ascii' and errors is None:
                    expected = original
                else:
                    expected = original.decode('ascii', b'ignore').encode(encoding, errors)

                result = to_bytes(original, encoding=encoding, errors=errors)

# Generated at 2022-06-22 22:08:22.447187
# Unit test for function to_bytes
def test_to_bytes():
    # Make sure utf-8 round trips
    utf8_str_1 = u'\u1234'
    utf8_str_2 = u'\N{SNOWMAN}'
    assert to_bytes(to_text(utf8_str_1)) == utf8_str_1.encode('utf-8')
    assert to_bytes(to_text(utf8_str_2)) == utf8_str_2.encode('utf-8')



# Generated at 2022-06-22 22:08:29.977489
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\N{SNOWMAN}') == '"\\u2603"'
    assert jsonify(u'\N{SNOWMAN}'.encode('latin-1')) == '"\\u2603"'
    assert jsonify(u'\N{SNOWMAN}'.encode('latin-1'), ensure_ascii=False) == '"\u2603"'



# Generated at 2022-06-22 22:08:41.171333
# Unit test for function to_bytes
def test_to_bytes():
    # Note: For complete test coverage, see test_unicode_helper.py

    # Test valid inputs
    assert to_bytes(u"", errors='surrogate_then_replace') == b""
    assert to_bytes(u"", errors='surrogate_then_replace', nonstring='empty') == b""

    # Test invalid inputs
    assert to_bytes(u"", errors='surrogate_then_replace', nonstring='nonexistent') == b""

    # Test invalid input text
    assert to_bytes(u"\U000fdd0f", errors='surrogate_then_replace') == b'?'
    assert to_bytes(u"\U000fdd0f", errors='surrogate_then_replace', encoding='latin-1') == b'\xef\xbf\xbd'

   

# Generated at 2022-06-22 22:08:50.597540
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # List of items to check
    items = []
    items.append({u'foo': u'bar', u'baz': [u'baz1', u'baz2', {u'baz3': u'baz3'}]})
    items.append(u'abcd\u1234')
    items.append(12345)
    items.append((u'foo', u'bar', [1, 2, 3]))
    items.append(u'\xe9')
    items.append(u'\u1234') # surrogate character

    # Perform the conversion and check
    for item in items:
        converted = container_to_bytes(item)

        # Check that the conversion worked
        if isinstance(item, dict):
            assert isinstance(converted, dict)

# Generated at 2022-06-22 22:09:00.394155
# Unit test for function to_native
def test_to_native():
    """Test different values for input and output"""
    assert to_native(None) is None
    assert to_native(1) == '1'
    assert isinstance(to_native(1), text_type)
    assert to_native([]) == to_native([])
    assert to_native([1, 2]) == to_native([1, 2])
    assert to_native(True) == 'True'
    assert to_native(datetime.datetime(2014, 1, 1)) != '2014-01-01 00:00:00'
    assert to_native(['1', '2']) == ['1', '2']
    assert to_native({}) == '{}'
    assert to_native({1: 2}) == '{1: 2}'

# Generated at 2022-06-22 22:09:09.439323
# Unit test for function to_bytes
def test_to_bytes():
    """
    Basic test for the :func:`to_bytes` function.
    """
    # ansible-2.3+
    from ansible.module_utils.common._text import to_bytes, HAS_SURROGATEESCAPE
    assert HAS_SURROGATEESCAPE

    # existing behavior
    assert to_bytes('\udcee\udcf0', 'utf-8') == b'\xed\xb3\xae\xed\xb3\xb0'
    assert to_bytes('\udcee\udcf0', 'utf-8', errors='surrogate_or_replace') == b'\xed\xb3\xae\xed\xb3\xb0'

# Generated at 2022-06-22 22:09:20.135514
# Unit test for function jsonify
def test_jsonify():
    assert '"{\\"name\\": \\"Alice\\"}"' == jsonify(container_to_bytes({'name': 'Alice'}))
    assert '"{\\"name\\": \\"Alice\\"}"' == jsonify(container_to_bytes({'name': 'Alice'}), ensure_ascii=False)
    assert '"{\\"name\\": \\"Alice\\"}"' == jsonify(container_to_text({'name': 'Alice'}))
    assert '"{\\"name\\": \\"Alice\\"}"' == jsonify(container_to_text({'name': 'Alice'}))
    assert '"{\\"name\\": \\"Bob\\"}"' == jsonify(container_to_bytes({'name': 'Bob'}))
    assert '"{\\"name\\": \\"Bob\\"}"'

# Generated at 2022-06-22 22:09:28.845027
# Unit test for function to_native
def test_to_native():
    x = {'foo': None, 'bar': 'this is a text', 'baz': u'this is a text'}
    assert to_native(x)
    assert to_native(x, errors='surrogate_or_replace')
    assert to_native(x, errors='surrogate_or_strict')
    assert to_native(x, errors='surrogate_then_replace')
    assert to_native(x, encoding='latin-1')
    assert to_native(x, encoding='latin-1', errors='surrogate_or_replace')
    assert to_native(x, encoding='latin-1', errors='surrogate_or_strict')
    assert to_native(x, encoding='latin-1', errors='surrogate_then_replace')



# Generated at 2022-06-22 22:09:35.221160
# Unit test for function to_native
def test_to_native():
    if PY3:
        assert to_native(b'foo') == 'foo'
        assert to_native(b'foo', errors='surrogate_or_replace') == 'foo'
    else:
        assert to_native(b'foo') == u'foo'
        assert to_native(b"\xff") == u'\ufffd'


# Generated at 2022-06-22 22:09:43.010720
# Unit test for function container_to_text
def test_container_to_text():
    # empty string
    result = container_to_text(b'')
    assert type(result) == text_type
    assert result == u''

    # valid utf8 string
    result = container_to_text(b'valid utf8 string')
    assert type(result) == text_type
    assert result == u'valid utf8 string'

    # valid latin-1 string
    result = container_to_text(b'valid latin-1 string', encoding='latin-1')
    assert type(result) == text_type
    assert result == u'valid latin-1 string'

    # invalid utf8 string
    result = container_to_text(b'invalid utf8 string\xff')
    assert type(result) == text_type

# Generated at 2022-06-22 22:09:54.345436
# Unit test for function to_bytes

# Generated at 2022-06-22 22:10:03.143954
# Unit test for function to_bytes
def test_to_bytes():
    # can't include u'' strings in py2 code by default.
    foo_utf8 = b'\xc4\x85\xc4\x87foo\xc4\x85\xc4\x87'
    foo_latin1 = b'\xd2\u0105foo\xd2\u0105'

    assert isinstance(to_bytes(foo_utf8, errors='surrogate_or_replace'), binary_type)
    assert isinstance(to_bytes(foo_latin1, errors='surrogate_or_replace'), binary_type)
    assert isinstance(to_bytes(foo_latin1, encoding='utf-8', errors='surrogate_or_replace'), binary_type)

# Generated at 2022-06-22 22:10:13.393073
# Unit test for function container_to_text
def test_container_to_text():
    data = {'key1': [b'value\xe2\x98\x83'.decode('utf-8')]}
    new_data = container_to_text(data, encoding='utf-8')
    assert new_data['key1'][0] == b'value\xe2\x98\x83'.decode('utf-8')

    data = {'key1': [b'value\xe2\x98\x83']}
    new_data = container_to_text(data, encoding='utf-8')
    assert new_data['key1'][0] == b'value\xe2\x98\x83'.decode('utf-8')



# Generated at 2022-06-22 22:10:24.161184
# Unit test for function container_to_bytes
def test_container_to_bytes():
    data = [
        u'The quick brown fox jumped over the lazy dogs\u2119',
        {u'foo': 1, u'bar': u'baz\u2119'},
        [u'one', u'two\u2119'],
        (u'one', u'two\u2119')
    ]
    assert container_to_bytes(data) == [
        b'The quick brown fox jumped over the lazy dogs\xe2\x84\x99',
        {b'foo': 1, b'bar': b'baz\xe2\x84\x99'},
        [b'one', b'two\xe2\x84\x99'],
        (b'one', b'two\xe2\x84\x99')
    ]



# Generated at 2022-06-22 22:10:34.238628
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text('test') == 'test'
    assert container_to_text(u'test') == u'test'
    assert container_to_text('test'.encode('utf-8')) == 'test'
    assert container_to_text('test'.encode('ascii')) == 'test'
    assert container_to_text('test'.encode('latin-1')) == 'test'
    assert container_to_text('test'.encode('utf-16')) == u'test'
    assert container_to_text('test'.encode('utf-16le')) == u'test'
    assert container_to_text('test'.encode('utf-16be')) == u'test'


# Generated at 2022-06-22 22:10:44.734084
# Unit test for function to_native
def test_to_native():
    '''
    Test to_native method
    '''
    import sys

# Generated at 2022-06-22 22:10:56.734368
# Unit test for function to_bytes
def test_to_bytes():
    """test to_bytes()"""
    assert to_bytes('ascii') == b'ascii'
    assert to_bytes('ascii', nonstring='passthru') == 'ascii'
    assert to_bytes(u'unicode') == b'unicode'
    assert to_bytes(u'unicode', nonstring='passthru') == u'unicode'
    assert to_bytes(u'unicode', errors='surrogate_or_strict') == b'unicode'
    assert to_bytes(u'unicode', errors='surrogate_or_replace') == b'unicode'
    assert to_bytes(u'unicode', errors='surrogate_then_replace') == b'unicode'

# Generated at 2022-06-22 22:11:03.887223
# Unit test for function jsonify
def test_jsonify():
    ret = jsonify({'foo': b'\xe9\x9a\x8f'})
    if PY3:
        assert ret == u'{"foo": "\\udca9\\udd8f"}'
    else:
        assert isinstance(ret, str)
        assert ret == '{"foo": "\\u9a8f"}'



# Generated at 2022-06-22 22:11:15.535855
# Unit test for function container_to_text
def test_container_to_text():
    test_1 = {"hello": "world"}
    assert container_to_text(test_1) == test_1
    test_2 = {"hello": u"world"}
    assert container_to_text(test_2) == test_2
    test_3 = {"hello": str(b"world")}
    assert container_to_text(test_3) == test_2
    test_4 = [{"hello": b"world"}]
    assert container_to_text(test_4) == [test_2]
    test_5 = ({"hello": b"world"},)
    assert container_to_text(test_5) == (test_2,)
    test_6 = [{"hello": "world"}, [{"hello": u"world"}]]
    assert container_to_text(test_6) == test_6


# Generated at 2022-06-22 22:11:27.075976
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(u'foo') == u'foo'
    assert container_to_text(b'foo') == u'foo'
    assert container_to_text([b'foo']) == [u'foo']
    assert container_to_text([u'foo']) == [u'foo']
    assert container_to_text({'foo': [b'bar', u'baz']}) == {'foo': [u'bar', u'baz']}
    assert container_to_text({'foo': [u'bar', b'baz']}) == {'foo': [u'bar', u'baz']}


# This is a hack to work around some python deficiencies

# Generated at 2022-06-22 22:11:39.474397
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('hello') == 'hello'
    assert to_bytes(u'hello') == 'hello'
    assert to_bytes(u'łóżźć') == b'\xc5\x82\xc3\xb3\xc5\xbc\xc5\xba\xc4\x87'
    assert to_bytes(u'utf8 with surrogates \udce4') == b'utf8 with surrogates \xed\xb3\xa4'
    assert to_bytes(u'utf8 with surrogates \udce4', errors=None) == b'utf8 with surrogates \xed\xb3\xa4'