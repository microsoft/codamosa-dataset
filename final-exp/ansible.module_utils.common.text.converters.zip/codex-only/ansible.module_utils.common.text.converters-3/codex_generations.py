

# Generated at 2022-06-22 22:01:46.056727
# Unit test for function to_native
def test_to_native():
    """Exercise the to_native function.
    """
    res = to_native(str('foo'))
    assert res == 'foo'

    res = to_native(str(u'foo'))
    assert res == 'foo'

    res = to_native(str(5))
    assert res == 5



# Generated at 2022-06-22 22:01:55.108215
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert type(to_native(u'foo')) == type(u'')
    assert type(to_native(u'foo'.encode('utf-8'))) == type(u'')

    assert to_native(b'foo') == u'foo'
    assert type(to_native(b'foo')) == type(u'')

    assert to_native(None) == u'None'
    assert type(to_native(None)) == type(u'')


# Generated at 2022-06-22 22:02:02.234639
# Unit test for function container_to_bytes
def test_container_to_bytes():
    for data in ({u'\u4e2d': u'\u56fd'}, [u'\u4e2d', u'\u56fd'], (u'\u4e2d', u'\u56fd')):
        ansible_data = container_to_bytes(data)
        assert (isinstance(ansible_data, dict) or isinstance(ansible_data, list) or isinstance(ansible_data, tuple))
        assert (isinstance(ansible_data, binary_type))


# Generated at 2022-06-22 22:02:15.276491
# Unit test for function container_to_bytes
def test_container_to_bytes():
    import tempfile
    fd, path = tempfile.mkstemp()

    # Python 2.6 can't use the with statement
    f = os.fdopen(fd, 'w')
    try:
        # when writing a file can't use unicode string
        data = '#!/usr/bin/python\nprint "Hello World!"\n'
        bytes_data = to_bytes(data)
        f.write(bytes_data)
    finally:
        f.close()

    try:
        os.remove(path)
    except:
        pass

    assert to_text(container_to_bytes(u'Hello World!')) == u'Hello World!'
    assert to_text(container_to_bytes({u'foo': u'Hello World!'})) == {u'foo': u'Hello World!'}

# Generated at 2022-06-22 22:02:22.365004
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test a list
    test_list = [u'Just', u'a', u'test']
    expected_list = [b'Just', b'a', b'test']
    assert expected_list == container_to_bytes(test_list)

    # Test a tuple
    test_tuple = (u'Just', u'a', u'test')
    expected_tuple = (b'Just', b'a', b'test')
    assert expected_tuple == container_to_bytes(test_tuple)

    # Test a dict
    test_dict = { u'Just': u'a', u'test': u'Unicode' }
    expected_dict = { b'Just': b'a', b'test': b'Unicode' }

# Generated at 2022-06-22 22:02:26.509239
# Unit test for function jsonify
def test_jsonify():
    test_dict = {"test_key1": "test_val1", "test_key2": "test_val2"}
    test_dict_json = jsonify(test_dict)
    assert isinstance(test_dict_json, str)



# Generated at 2022-06-22 22:02:37.729256
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a':1,'b':2},sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify({'a':1,'b':2},sort_keys=False) == '{"b": 2, "a": 1}'
    assert jsonify(['a',{'a':1,'b':2},3],sort_keys=True) == '["a", {"a": 1, "b": 2}, 3]'
    assert jsonify(['a',{'a':1,'b':2},3],sort_keys=False) == '["a", {"b": 2, "a": 1}, 3]'
    data = {'a':1, 'b':2, 'c':Set([1,2])}

# Generated at 2022-06-22 22:02:44.934716
# Unit test for function to_bytes
def test_to_bytes():
    # bytes
    assert to_bytes('ascii') == b'ascii'
    assert to_bytes(u'\u6d4b\u8bd5') == b'\xe6\xb5\x8b\xe8\xaf\x95'
    assert to_bytes(u'\xfc') == b'\xc3\xbc'
    assert to_bytes(u'\xfc', 'ascii', 'surrogate_or_replace') == b'?'
    b_ = b'\xf0\x90\x80\x80'
    assert to_bytes(b_.decode('utf-8', 'surrogateescape'), 'utf-8', 'surrogateescape') == b_
    if PY3:
        # surrogateescape is only valid for utf-8
        assert to

# Generated at 2022-06-22 22:02:48.824542
# Unit test for function jsonify
def test_jsonify():
    assert jsonify([1,2,3]) == '[1, 2, 3]'
    assert jsonify({'key':'value', 'key2': 'value2'}) == '{"key2": "value2", "key": "value"}'


# Generated at 2022-06-22 22:03:00.823870
# Unit test for function container_to_text
def test_container_to_text():
    def assertEqual(x, y):
        if x != y:
            print(x, y)
        assert(x == y)
    assertEqual({1: 2}, container_to_text({b'1': 2}, 'ascii'))
    assertEqual({1: 2}, container_to_text({'1': b'2'}, 'ascii'))
    assertEqual([1, 2], container_to_text([b'1', b'2'], 'ascii'))
    assertEqual([1, 2], container_to_text([1, b'2'], 'ascii'))
    assertEqual((1, 2), container_to_text((b'1', b'2'), 'ascii'))

# Generated at 2022-06-22 22:03:13.003513
# Unit test for function container_to_text
def test_container_to_text():
    # Dicts
    assert container_to_text({}) == {}

    assert container_to_text({to_bytes('x', 'utf-8'): 1}) == {u'x': 1}

    assert container_to_text({u'x': to_bytes(1, 'utf-8')}) == {u'x': 1}

    assert container_to_text({u'x': to_bytes(1, 'utf-8'), u'y': to_bytes(2, 'utf-8')}) == {u'x': 1, u'y': 2}


# Generated at 2022-06-22 22:03:23.610206
# Unit test for function to_native
def test_to_native():
    """
    Make sure to_native() behaves as expected.
    """
    import sys
    if sys.version_info[0] == 3:
        # Python 3
        assert to_native(b'hello') == 'hello'
        assert to_native('hello') == 'hello'
        assert to_native(u'\xe2\x99\xa5') == '♥'
        assert to_native(b'\xe2\x99\xa5') == '♥'
    else:
        # Python 2
        assert to_native(b'hello') == b'hello'
        assert to_native(u'hello') == b'hello'

# Generated at 2022-06-22 22:03:32.423165
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == u'foo'
    assert to_bytes(u'foo') == u'foo'
    assert to_bytes(u'\u20ac') == u'\xe2\x82\xac'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(123, nonstring='simplerepr') == b'123'
    assert to_bytes(b'foo', nonstring='empty') == b''
    assert to_bytes(b'foo', nonstring='passthru') == b'foo'
    assert to_bytes(u'\u20ac', encoding='ascii', errors='surrogate_or_strict') == b'?'

# Generated at 2022-06-22 22:03:38.092826
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 1}) == u'{"a": 1}'
    assert jsonify(value=2) == u'2'
    assert jsonify([1, 2, 3], separators=(',', ':')) == u'[1,2,3]'


# Generated at 2022-06-22 22:03:46.424787
# Unit test for function jsonify
def test_jsonify():
    test_data = {u'bytes': b'\xc3\xbc', u'ascii': b'abc123', 'list': ['a', 1, b'\xc3\xbc'], u'unicode': u'\xc3\xbc', 'set': set(['a', 1, b'\xc3\xbc'])}
    assert jsonify(test_data) == '{"bytes":"\xc3\xbc","ascii":"abc123","list":["a",1,"\xc3\xbc"],"unicode":"\xc3\xbc","set":["a",1,"\xc3\xbc"]}'


# Generated at 2022-06-22 22:03:55.936725
# Unit test for function container_to_text
def test_container_to_text():
    """
    Unit test function named as per best practice guidance here: https://docs.pytest.org/en/latest/goodpractices.html#test-discovery
    """
    # Defining the valid inputs for a dict in the input params
    test_dict_params = [
        # If one item in the dict is not a str, then the output is not a dict
        {'dict': {'key_1': 'this_is_a_str', 'key_2': 2}},
        # Tests utf-8 and that the output is a dict
        {'dict': {to_bytes('this_is_a_utf8_key', 'utf-8'): 'this_is_a_utf8_value'}}
    ]
    # Defining the valid inputs for a list in the input params

# Generated at 2022-06-22 22:04:08.884462
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' Unit test for function container_to_bytes '''
    assert container_to_bytes(['a', 'b', 'c'], 'ascii') == [b'a', b'b', b'c']
    assert container_to_bytes({'a': 'b', 'c': 'd'}, 'ascii') == {b'a': b'b', b'c': b'd'}
    assert container_to_bytes('a', 'ascii') == b'a'
    assert container_to_bytes(1, 'ascii') == 1

# Generated at 2022-06-22 22:04:17.435163
# Unit test for function jsonify
def test_jsonify():
    def test(x):
        t = type(x)
        assert jsonify(x) == json.dumps(x, encoding='utf-8', default=_json_encode_fallback)
        assert jsonify(x, ensure_ascii=False) == json.dumps(x, ensure_ascii=False, encoding='utf-8', default=_json_encode_fallback)
        assert type(jsonify(x)) is t

    test(False)
    test(True)
    test(None)
    test(0)
    test(3.14)
    test(1<<64)
    test(3.14+1j)
    test('abc')
    test(u'abc')
    test(b'abc')
    test(bytearray(b'abc'))

# Generated at 2022-06-22 22:04:28.125220
# Unit test for function to_bytes
def test_to_bytes():
    import sys
    sys.modules['ansible'] = sys.modules['ansible.module_utils.six']

    try:
        import ansible.module_utils.six as six
    except ImportError:
        from .. import six
    six.moves.builtins.__dict__['unicode'] = six.text_type
    six.moves.builtins.__dict__['basestring'] = (six.binary_type, six.text_type)

    if six.PY2:
        assert b'\xc2' == six.to_bytes(u'\u00c2')
        assert b'\xe2' == six.to_bytes(u'\u00e2', 'latin-1')

# Generated at 2022-06-22 22:04:35.924961
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({'name': 'Žluťoučký kůň'}, 'utf-8') == {b'name': b'\xc5\xbdlu\xc5\xa5ou\xc4\x8dk\xc3\xbd k\xc5\xaf\xc5\x88'}
    assert container_to_bytes({'name': 'Žluťoučký kůň'}, 'utf-8', 'surrogate_then_replace') == {'name': b'?????'}
    assert container_to_bytes({'name': 'Žluťoučký kůň'}, 'ascii') == {'name': '?????? ???'}

# Generated at 2022-06-22 22:04:47.876120
# Unit test for function to_bytes
def test_to_bytes():
    '''Test that to_bytes works correctly'''

    class TestClass(object):
        def __repr__(self):
            return 'repr'
        def __str__(self):
            return 'str'

    obj = TestClass()

    assert b'repr' == to_bytes(None, nonstring='simplerepr')
    assert b'str' == to_bytes(obj, nonstring='simplerepr')
    assert b'' == to_bytes(None, nonstring='empty')
    assert obj is to_bytes(obj, nonstring='passthru')

    try:
        to_bytes(None, nonstring='strict')
        assert False, "Failed to raise error when strict and nonstring is None"
    except TypeError:
        pass


# Generated at 2022-06-22 22:04:54.671917
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # bytes and non-container types, not handled in function
    if not PY3:
        assert b'asdf' == container_to_bytes(b'asdf')
        assert None == container_to_bytes(None)
        assert 5 == container_to_bytes(5)
    assert 'asdf' == container_to_bytes('asdf')

    # Unicode conversion
    assert b'asdf' == container_to_bytes(u'asdf')

    # Recursive conversion
    assert [b'asdf'] == container_to_bytes([u'asdf'])
    assert (b'asdf',) == container_to_bytes((u'asdf',))
    assert {b'asdf': b'asdf'} == container_to_bytes({u'asdf': u'asdf'})



# Generated at 2022-06-22 22:05:02.945843
# Unit test for function container_to_bytes
def test_container_to_bytes():
    from ansible.module_utils.common.collections import isidentical
    testdata = {'ascii': 'foo', 'unicode': u'\u2713', 'dict': dict(foo='bar')}
    testdata_utf8 = {'ascii': b'foo', 'unicode': b'\xe2\x9c\x93', 'dict': dict(foo='bar')}
    testdata_latin1 = {'ascii': b'foo', 'unicode': b'?'}

    assert isidentical(testdata_utf8, container_to_bytes(testdata, encoding='utf-8'))
    assert isidentical(testdata_latin1, container_to_bytes(testdata, encoding='latin-1'))


# We need a custom encoder for OrderedDict to

# Generated at 2022-06-22 22:05:11.993234
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({u'foo': u'bar'}) == {b'foo': b'bar'}
    assert container_to_bytes({u'foo': [u'bar', u'baz']}) == {b'foo': [b'bar', b'baz']}
    assert container_to_bytes({u'foo': (u'bar', u'baz')}) == {b'foo': (b'bar', b'baz')}
    assert container_to_bytes([u'foo', u'bar']) == [b'foo', b'bar']
    assert container_to_bytes((u'foo', u'bar')) == (b'foo', b'bar')



# Generated at 2022-06-22 22:05:22.502424
# Unit test for function to_bytes
def test_to_bytes():
    """
    :avocado: tags: units
    """
    assert to_bytes('foo') == b'foo'
    assert to_bytes('foo') == u'foo'.encode('utf-8')
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'\N{SNOWMAN}') == b'\xe2\x98\x83'
    assert to_bytes(u'\N{PILE OF POO}') == b'\xf0\x9f\x92\xa9'
    assert to_bytes(1) == b'1'
    assert to_bytes(2.0) == b'2.0'
    assert to_bytes(datetime.datetime.utcnow()) == b'2017-04-03 22:12:40.739415'


# Generated at 2022-06-22 22:05:31.290783
# Unit test for function to_native

# Generated at 2022-06-22 22:05:42.263291
# Unit test for function container_to_text
def test_container_to_text():
    test_input = {
        'a': {'b': 'c'},
        'd': [b'foo', u'bar'],
        'e': [1, 2],
        'f': 'g',
        'h': bytearray(b'abc'),
        'i': 1
    }

    test_output = {
        'a': {u'b': u'c'},
        'd': [u'foo', u'bar'],
        'e': [1, 2],
        'f': u'g',
        'h': u'abc',
        'i': 1,
    }


# Generated at 2022-06-22 22:05:53.173977
# Unit test for function jsonify
def test_jsonify():
    data = {
        'a': 'a',
        'b': u'b',
        'c': {
            'd': 'd',
            'e': u'e',
        },
        u'f': u'f'
    }
    if PY3:
        expected = '{"a": "a", "c": {"e": "e", "d": "d"}, "b": "b", "f": "f"}'
    else:
        expected = '{"a": "a", "c": {"d": "d", "e": "e"}, "b": "b", "f": "f"}'
    result = jsonify(data)
    assert result == expected



# Generated at 2022-06-22 22:05:55.637119
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b="2", c=[3, 4])) == '{"c": [3, 4], "b": "2", "a": 1}'



# Generated at 2022-06-22 22:06:03.477112
# Unit test for function to_native
def test_to_native():
    assert to_text(b'hello world', 'ascii') == u'hello world'
    assert to_text(u'hello world', 'ascii') == u'hello world'
    assert to_bytes(b'hello world', 'ascii') == b'hello world'
    assert to_bytes(u'hello world', 'ascii') == b'hello world'

    assert to_text(b'\xe2\x82\xac', 'latin-1') == u'\u20ac'
    assert to_text(u'\u20ac', 'latin-1') == u'\u20ac'
    assert to_bytes(b'\xe2\x82\xac', 'latin-1') == b'\xe2\x82\xac'

# Generated at 2022-06-22 22:06:12.844540
# Unit test for function to_native
def test_to_native():
    # Python 3 is testing with surrogate escape
    if PY3:
        assert to_text(b'\xf1\x80\x80\x80') == '\udc80\udc80\udc80'
        assert to_text(b'\xf1\x80\x80\x80', errors='surrogate_or_strict') == '\udc80\udc80\udc80'
        assert to_text(b'\xf1\x80\x80\x80', errors='surrogate_or_replace') == '\udc80\udc80\udc80'
        assert to_text(b'\xf1\x80\x80\x80', errors='surrogate_then_replace') == '\udc80\udc80\udc80'
        assert to

# Generated at 2022-06-22 22:06:21.765065
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {u'bytes': '\xff',
         u'string': u'\xff'}
    dd = container_to_bytes(d)
    assert isinstance(dd, dict)
    assert isinstance(dd[b'string'], bytes)
    assert isinstance(dd[b'bytes'], bytes)
    assert isinstance(next(iter(dd)), binary_type)

    dd = container_to_bytes([1, 2, 3])
    assert isinstance(dd, list)
    assert not isinstance(dd[0], binary_type)



# Generated at 2022-06-22 22:06:32.744752
# Unit test for function jsonify
def test_jsonify():
    result = jsonify('foo')
    assert result == '"foo"'
    result = jsonify(u'Österreich')
    assert result == '"\\u00d6sterreich"'
    result = jsonify(u'Österreich'.encode('latin-1'))
    assert result == '"\\u00d6sterreich"'
    result = jsonify(u'Österreich'.encode('utf-16'))
    assert result == '"\\u00d6sterreich"'
    result = jsonify([u'Österreich'])
    assert result == '["\\u00d6sterreich"]'
    result = jsonify({'foo': u'Österreich'})
    assert result == '{"foo": "\\u00d6sterreich"}'

# Generated at 2022-06-22 22:06:44.141288
# Unit test for function to_bytes
def test_to_bytes():
    if PY3:
        raise AssertionError("Test must be run in Python2")

    # Ensure we have a surrogateescape error handler for the rest of the test
    # We have to re-import this
    from ansible.module_utils.six import register_unserializable, _native_unserializables
    if 'surrogateescape' not in _native_unserializables and 'surrogateescape' in codecs.lookup_error:
        register_unserializable('surrogateescape')


# Generated at 2022-06-22 22:06:50.924831
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_text
    data = {u'\u00e5\u00e4': u'\u00f6', 'foo': 'bar'}
    expect = to_text('{"foo": "bar", "\\u00e5\\u00e4": "\\u00f6"}')
    actual = jsonify(data, sort_keys=True)
    assert actual == expect


# Generated at 2022-06-22 22:06:57.304913
# Unit test for function jsonify
def test_jsonify():
    assert jsonify([u'\u2713']) == u'["\\u2713"]'
    assert jsonify([u'\u2713'], ensure_ascii=False) == u'["\u2713"]'
    assert jsonify([u'\u2713'], ensure_ascii=False, sort_keys=True) == u'["\u2713"]'



# Generated at 2022-06-22 22:07:02.595634
# Unit test for function jsonify
def test_jsonify():
    data = {
        b"test_bytes": b"test",
        u"test_unicode": u"test",
        "test_int": 1,
    }
    assert jsonify(data) == '{"test_bytes": "test", "test_unicode": "test", "test_int": 1}'



# Generated at 2022-06-22 22:07:12.648886
# Unit test for function to_native
def test_to_native():
    # bytes in sys default encoding to text
    if PY3:
        assert to_native(b'test', errors='surrogate_or_strict') == 'test'
        assert to_native(b'\xe4\xb8\xad\xe6\x96\x87', errors='surrogate_or_strict') == '中文'
        assert to_native(b'\xe4\xb8\xad\xff', errors='surrogate_or_strict') == '中�'
    else:
        assert to_native(b'test', errors='surrogate_or_strict') == u'test'

# Generated at 2022-06-22 22:07:17.736254
# Unit test for function jsonify
def test_jsonify():
    jsonify(dict(foo=u'\xe9'))
    jsonify(dict(foo=u'\xe9'), ensure_ascii=False)
    jsonify(dict(foo=u'\xe9'), ensure_ascii=True)
    jsonify(dict(foo=u'\xfc'))



# Generated at 2022-06-22 22:07:26.285593
# Unit test for function to_native
def test_to_native():
    assert to_native(u'test', errors='strict') == u'test'
    assert to_native(u'test', errors='surrogate_or_strict') == u'test'
    assert to_native(u'test', errors='surrogate_or_replace') == u'test'
    assert to_native(b'test', errors='strict') == u'test'
    assert to_native(u'test', encoding='utf-16') == u'test'
    assert to_native(b'test', encoding='utf-16') == u'test'
    assert to_native(b'\xff') == u'\ufffd'
    assert to_native(u'\ufffd') == u'\ufffd'
    assert to_native(1) == u'1'

# Generated at 2022-06-22 22:07:29.037985
# Unit test for function container_to_text
def test_container_to_text():
    d1 = {b'a':1, b'b':2}
    d2 = container_to_text(d1)
    assert isinstance(d2, dict)
    assert isinstance(d2[u'a'], int)
    assert isinstance(d2[u'b'], int)
    assert d2[u'a'] == 1
    assert d2[u'b'] == 2


# Generated at 2022-06-22 22:07:40.996139
# Unit test for function container_to_text
def test_container_to_text():
    # TypeError("can't concat str to bytes")
    characters = 'abcdefg'
    bytes_bytearray = bytearray('abcdefg', encoding='utf-8')
    bytes_list = ['a','b','c','d','e','f','g']
    bytes_tuple = ('a','b','c','d','e','f','g')
    bytes_dict = {"A":"a","B":"b","C":"c","D":"d","E":"e","F":"f","G":"g"}

    assert characters == container_to_text(bytes_bytearray)
    assert bytes_list == container_to_text(bytes_list)
    assert bytes_tuple == container_to_text(bytes_tuple)
    assert bytes_dict == container_to_text(bytes_dict)



# Generated at 2022-06-22 22:07:50.852013
# Unit test for function container_to_text
def test_container_to_text():
    # Empty dict
    assert container_to_text({}) == {}
    # dict with mixed values, bytes and unicode
    mixed_dict_bytes_unicode = {'unicode_value': u'unicode_text', 'byte_value': 'test_bytes'}
    mixed_dict_unicode_unicode = {'unicode_value': u'unicode_text', 'unicode_value_2': u'unicode_text'}
    # dict with all unicode
    assert container_to_text(mixed_dict_bytes_unicode, encoding='utf-8', errors='surrogate_or_strict') == mixed_dict_unicode_unicode
    # dict with all bytes

# Generated at 2022-06-22 22:07:59.363981
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native

    assert to_native(u'foo') == 'foo'
    assert to_native('foo') == 'foo'
    assert to_native(b'foo') == 'foo'

    value = 5
    if PY3:
        assert to_native(value) == '5'
    else:
        assert to_native(value) == '5'

    assert to_native(datetime.datetime.now()) == str(datetime.datetime.now())
    assert to_native(5, nonstring='passthru') == 5



# Generated at 2022-06-22 22:08:11.013561
# Unit test for function jsonify
def test_jsonify():

    # Test invalid unicode encoding
    try:
        jsonify('\xf4\x8f\xbf\xbf')
        assert False
    except UnicodeError as e:
        assert e.args[0] == 'Invalid unicode encoding encountered'

    # Test latin-1 jsonify
    data = u'\xe9'
    json_data = jsonify(data)
    assert isinstance(json_data, text_type)
    assert json_data == u'"\xe9"'

    # Test utf-8 jsonify
    data = u'\u20ac'
    json_data = jsonify(data)
    assert isinstance(json_data, text_type)
    assert json_data == u'"\u20ac"'

    # Test jsonify with encoding
    data = u'\u20ac'
    json

# Generated at 2022-06-22 22:08:19.249998
# Unit test for function jsonify
def test_jsonify():

    import datetime
    import json
    from ansible.module_utils._text import to_bytes, to_text, to_native
    from ansible.module_utils.common._collections_compat import Set

    # test utf-8 encoding
    # test utf-8 encoding
    test_string_utf8 = u'ni\xf1o'
    assert jsonify(test_string_utf8) == u'ni\xf1o'

    # test latin-1 encoding
    test_string_latin1 = u'ni\xf1o'
    assert jsonify(test_string_latin1) == u'ni\xf1o'

    # test container_to_text with utf-8 encoding
    test_container_utf8 = {u'ni\xf1o':u'ni\xf1o'}

# Generated at 2022-06-22 22:08:25.338073
# Unit test for function to_native
def test_to_native():
    """
    Test to_native function
    """
    # pylint: disable=too-many-branches
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common._collections_compat import UserDict, UserList

    # Check for correct handling of different input types
    assert to_native(None) is None
    assert to_native(True) is True
    assert to_native(False) is False
    assert to_native(0) == 0
    assert to_native(10000) == 10000
    assert to_native(0.001) == 0.001
    assert to_native(12345678901234567890) == 12345678901234567890
    assert to_native(set([1, 2, 3])) == set([1, 2, 3])

# Generated at 2022-06-22 22:08:36.371067
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' Function container_to_bytes unit test

        Based on function container_to_text unittest
        from file lib/ansible/utils/unicode.py
    '''
    assert container_to_bytes(u'foo') == b'foo'
    assert container_to_bytes({u'foo': u'bar'}) == {b'foo': b'bar'}
    assert container_to_bytes({b'foo': u'bar'}) == {b'foo': b'bar'}

# Generated at 2022-06-22 22:08:45.607592
# Unit test for function container_to_text
def test_container_to_text():
    print('Test the function: container_to_text')
    # test for unicode
    s = u'\u00FF'
    d = {u'a': u'\u00FF'}
    l = [u'a', (u'b', u'\u00FF')]
    assert container_to_text(s) == s
    assert container_to_text(d) == d
    assert container_to_text(l) == l

    # test for byte
    s = b'\xFF'
    d = {b'a': b'\xFF'}
    l = [b'a', (b'b', b'\xFF')]
    assert container_to_text(s) == '\u00FF'

# Generated at 2022-06-22 22:08:54.355280
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_text, to_bytes
    assert to_native(b'foo', nonstring='simplerepr') == u'foo'
    assert to_native(u'foo', nonstring='simplerepr') == u'foo'
    assert to_native({u'baz': 1}, nonstring='simplerepr') == " {u'baz': 1}"
    assert to_native((1, 2, 3), nonstring='simplerepr') == '(1, 2, 3)'


# Generated at 2022-06-22 22:08:59.657728
# Unit test for function to_native
def test_to_native():
    for obj in ['hello', u'world', 1, 1.2, datetime.datetime.now(), object()]:
        if PY3:
            assert to_native(obj) == str(obj)
        else:
            assert to_native(obj) == unicode(obj)



# Generated at 2022-06-22 22:09:05.440061
# Unit test for function to_native
def test_to_native():
    unicode_string = u"El Niño"

# Generated at 2022-06-22 22:09:16.303461
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # first a simple string, which should not be converted
    assert container_to_bytes('simple') == 'simple'
    # try a dictionary with a variety of combinations
    input_dict = {u'simple': 'simple', u'unicode': u'Iñtërnâtiônàlizætiøn', 'list': ['one', 'two', u'three'], u'tuple': (1, 2, 3), u'other_dict': {'foo': 'bar'}}

# Generated at 2022-06-22 22:09:26.052380
# Unit test for function container_to_text
def test_container_to_text():
    """
    :return: Whether all the test passed
    """
    # check that it returns the same object for non-basestring objects
    nonbasestring = [
        1,
        1.0,
        {1: 2},
        [1, 2, 3],
        (4, 5, 6),
        u'text'
    ]
    for obj in nonbasestring:
        if container_to_text(obj) != obj:
            raise AssertionError()
    # check that it returns a text object for a bytestring object
    bytestring = b'string'
    if not isinstance(container_to_text(bytestring), text_type):
        raise AssertionError()
    # check that it returns a text object for a unicode object
    unicodestring = u'string'

# Generated at 2022-06-22 22:09:37.269661
# Unit test for function container_to_text
def test_container_to_text():
    import json
    # Check functions in this module are
    # all of the things we are looking for
    # in container_to_text
    def assert_is_text(obj):
        _bytes = to_bytes(obj)
        _text = container_to_text(_bytes)
        assert isinstance(_text, text_type)
        assert obj == _text

        obj = json.dumps(obj)
        _bytes = to_bytes(obj)
        _text = container_to_text(_bytes)
        assert isinstance(_text, text_type)
        assert json.loads(obj) == json.loads(_text)

    # This is a list of all valid JSON types
    # and some things that are not valid JSON types

# Generated at 2022-06-22 22:09:45.038062
# Unit test for function jsonify
def test_jsonify():
    # Create an example string that contains non-ascii (i.e. Chinese) characters

    # Encode Chinese characters to bytes.
    # This example is not running on a computer with a Chinese locale,
    # therefore encoding to latin-1 is necessary.
    chinese_bytes = u'你好'.encode('latin-1')
    chinese_bytes_string = chinese_bytes.decode('latin-1')
    data = {}
    data["name"] = chinese_bytes_string
    data["children"] = [
        {
            "name": chinese_bytes_string,
            "size": None
        }
    ]
    print (jsonify(data))
    # You should see the following string:
    # {"name": "你好", "children": [{"name": "你

# Generated at 2022-06-22 22:09:55.137031
# Unit test for function jsonify
def test_jsonify():

    #json.dumps(data, encoding=encoding, default=_json_encode_fallback, **kwargs)
    data = dict(a='foo', b='bar', c='baz')
    j = jsonify(data)
    assert j == '{"a": "foo", "c": "baz", "b": "bar"}'

    data['d'] = "test"
    j = jsonify(data)
    assert j == '{"a": "foo", "c": "baz", "b": "bar", "d": "test"}'

    data['a'] = '中文'
    j = jsonify(data)
    assert j == '{"a": "中文", "c": "baz", "b": "bar", "d": "test"}'

    # try with the default value of json

# Generated at 2022-06-22 22:10:02.655849
# Unit test for function jsonify
def test_jsonify():
    # Test all types of json-able data
    json_data = jsonify({"a": ["one", "two", "three"], "b": [1, 2, 3], "c": "string", "d": True, "e": None, "f": 1, "g": 2.0})
    assert json_data == '{"a": ["one", "two", "three"], "c": "string", "b": [1, 2, 3], "e": null, "d": true, "g": 2.0, "f": 1}'

    # Test non-json-able objects
    try:
        json_data = jsonify({"a": object()})
        assert False
    except Exception:
        assert True

    # Test non-ascii byte data

# Generated at 2022-06-22 22:10:14.614805
# Unit test for function jsonify
def test_jsonify():

    # Test data with utf-8 encoding

    test_data = {
        u"str": u"\u6d4b\u8bd5",
        "byte": "\xe6\xb5\x8b\xe8\xaf\x95",
        "unicode_list": [u"\u6d4b\u8bd5", "\xe6\xb5\x8b\xe8\xaf\x95"],
        "tuple": (u"\u6d4b\u8bd5", "\xe6\xb5\x8b\xe8\xaf\x95"),
        "dict": {u"1": u"\u6d4b\u8bd5", "2": "\xe6\xb5\x8b\xe8\xaf\x95"}
    }


# Generated at 2022-06-22 22:10:24.589680
# Unit test for function to_native
def test_to_native():
    assert to_native(b'hello') == u'hello'
    assert to_native(b'Tr\xc3\xa4dgr') == u'Tr\xe4dgr'

    assert to_native(u'hello') == u'hello'
    assert to_native(u'Tr\xe4dgr') == u'Tr\xe4dgr'

    assert to_native(u'Tr\xe4dgr'.encode(b'latin-1'), encoding=b'latin-1') == u'Tr\xe4dgr'

    assert to_native(42) == u'42'
    assert to_native(42, nonstring='passthru') == 42
    assert to_native(42, nonstring='strict') == u'42'
    assert to_native(None) == u'None'

   

# Generated at 2022-06-22 22:10:34.519688
# Unit test for function container_to_text
def test_container_to_text():
    test_list = [b'text1', u'text2', b'text3', u'\xe9\x84\x89']
    assert container_to_text(test_list) == [u'text1', u'text2', u'text3', u'\u9089']
    test_tuple = (b'text1', u'text2', b'text3', u'\xe9\x84\x89')
    assert container_to_text(test_tuple) == (u'text1', u'text2', u'text3', u'\u9089')
    test_dict = {b'text1': 1, u'text2': 2, b'text3': 3, u'\xe9\x84\x89': 4}

# Generated at 2022-06-22 22:10:44.880831
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo', 'utf8') == u'foo'
    assert to_native(u'foo') == u'foo'
    # Test non-ascii unicode data
    assert to_native(u'\u043c\u0430\u0437\u0430') == u'\u043c\u0430\u0437\u0430'
    assert to_native(b'\xd0\xbc\xd0\xb0\xd0\xb7\xd0\xb0') == u'\u043c\u0430\u0437\u0430'
    # Test non-ascii bytes that are actually unicode
    assert to_native(b'\xc3\xa8') == u'\u00e8'

# Generated at 2022-06-22 22:10:56.876769
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test the default settings
    result = container_to_bytes(FAKE_STR_UTF8_DICT)
    assert type(result) == dict
    assert len(result) == len(FAKE_STR_UTF8_DICT)
    assert result['key_str'] == FAKE_STR_UTF8
    assert result['key_unicode'] == FAKE_STR_UTF8_UNICODE
    for k in iteritems(result):
        assert k[0] == FAKE_STR_UTF8
        assert k[1] == FAKE_STR_UTF8
    result = container_to_bytes(FAKE_STR_BYTES_UNICODE_DICT)
    assert type(result) == dict
    assert len(result) == len(FAKE_STR_BYTES_UNICODE_DICT)
   

# Generated at 2022-06-22 22:11:02.632803
# Unit test for function to_native
def test_to_native():
    """
    Unit tests for :py:func:`to_native`
    """

# Generated at 2022-06-22 22:11:14.285708
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text([u"s\u0161", u"s\u0161"]) == [u"s\u0161", u"s\u0161"]
    assert container_to_text(['s\xe5', 's\xe5']) == [u"s\u0161", u"s\u0161"]
    assert container_to_text(['s\xe5', 's\xe5'], encoding='ascii', errors='strict') == [u"s\u0161", u"s\u0161"]
    assert container_to_text(['s\xe5', 's\xe5'], errors='strict') == [u"s\xe5", u"s\xe5"]

# Generated at 2022-06-22 22:11:24.188815
# Unit test for function to_native
def test_to_native():
    # Testing Strings
    assert to_native(b'\xc3\xbc') == u'\xfcr'
    assert to_native('\xe4\xbd\xa0\xe5\xa5\xbd') == u'\u4f60\u597d'
    assert to_native(u'\u6d4b\u8bd5') == u'\u6d4b\u8bd5'
    assert to_native('\xc3\xa9 \xe2\x98\x83') == u'\xe9 \u2603'
    assert to_native(b'\xc3\xa9 \xe2\x98\x83') == u'\xe9 \u2603'

# Generated at 2022-06-22 22:11:37.017236
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('something') == '"something"'
    assert jsonify('ρσμφ') == '"\\u03c1\\u03c3\\u03bc\\u03c6"'
    assert jsonify({'Ω': 'ρσμφ'}) == '{"\\u03a9": "\\u03c1\\u03c3\\u03bc\\u03c6"}'
    assert jsonify(['Ω', 'ρσμφ']) == '["\\u03a9", "\\u03c1\\u03c3\\u03bc\\u03c6"]'
    assert jsonify(set(['Ω', 'ρσμφ'])) == '["\\u03a9", "\\u03c1\\u03c3\\u03bc\\u03c6"]'
    #

# Generated at 2022-06-22 22:11:44.729564
# Unit test for function to_native
def test_to_native():
    assert to_native(text_type('foo'), encoding='ascii') == text_type('foo')
    assert to_native(binary_type('foo'),  encoding='ascii') == text_type('foo')
    assert to_native(1, nonstring='empty') == u''
    assert to_native(1, nonstring='passthru') == 1
    assert to_native(1, nonstring='strict') == TypeError
    assert to_native(text_type('foo'), encoding='ascii', errors='surrogateescape') == text_type('foo')
    assert to_native(binary_type('foo'),  encoding='ascii', errors='surrogateescape') == text_type('foo')