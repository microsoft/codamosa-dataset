

# Generated at 2022-06-22 22:01:49.042290
# Unit test for function to_native
def test_to_native():
    assert to_native(b'abc') == 'abc'
    assert to_native(b'abc', errors='surrogate_then_replace') == 'abc'

    assert to_native(u'abc') == 'abc'
    assert to_native(u'abc', errors='surrogate_then_replace') == 'abc'

    assert to_native(10) == '10'
    assert to_native(10, nonstring='empty') == ''
    assert to_native(10, nonstring='passthru') == 10
    assert to_native([1, 2]) == '[1, 2]'
    assert to_native(datetime.datetime(1, 1, 1)) == '0001-01-01 00:00:00'



# Generated at 2022-06-22 22:01:58.729402
# Unit test for function container_to_text
def test_container_to_text():
    data_str = {'str': 'test_string'}
    data_dict = {'str': 'test_string',
                 'dict': {'str': 'test_string'}}
    data_list = {'str': 'test_string',
                 'list': [1, "test"]}
    data_tuple = {'str': 'test_string',
                  'tuple': (1, "test")}
    data_mix = {'str': 'test_string',
                'list': [1, "test"],
                'tuple': (1, "test"),
                'dict': {'str': 'test_string'}}

    def check_container_to_text(data):
        new_data = container_to_text(data, encoding='utf-8')

# Generated at 2022-06-22 22:02:06.255881
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.utils.unicode import to_unicode


# Generated at 2022-06-22 22:02:14.307606
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'1':'\u20ac'}) == '{"1": "\u20ac"}'
    assert jsonify({'1':'\u20ac'}, ensure_ascii=False) == u'{"1": "\u20ac"}'
    assert jsonify({'1':b'\xe2\x82\xac'}, ensure_ascii=False) == u'{"1": "\u20ac"}'



# Generated at 2022-06-22 22:02:25.304756
# Unit test for function to_native
def test_to_native():
    # PY2 - to_native() - unicode
    orig = to_text(u'this is a unicode test \u2713', errors='surrogate_then_replace')
    orig_type = type(orig)
    assert orig_type == text_type, 'to_text() returned %s type instead of unicode' % orig_type
    assert u'this is a unicode test \u2713' == orig, 'Expected unicode string, got %s' % orig

    # PY2 - to_native() - bytes
    orig = to_text(b'this is a bytes test \xe2\x9c\x93', errors='surrogate_then_replace')
    orig_type = type(orig)
    assert orig_type == text_type, 'to_text() returned %s type instead of unicode'

# Generated at 2022-06-22 22:02:29.889180
# Unit test for function container_to_text
def test_container_to_text():
    '''Test for container_to_text'''
    d = {'foo': 'bar'}
    result = container_to_text(d)
    assert result == {u'foo': u'bar'}



# Generated at 2022-06-22 22:02:39.426263
# Unit test for function to_bytes
def test_to_bytes():
    # PY2 doesn't have __debug__
    if not isinstance(__builtins__, dict) and not __builtins__.__debug__:
        raise Exception("We need to be running in with python -O to test to_bytes")

    def test_nonascii_encoding(test_string, encoding):

        bytes_string = test_string.encode(encoding)
        bytes_string_from_to_bytes = to_bytes(test_string)

        if bytes_string != bytes_string_from_to_bytes:
            raise Exception("to_bytes(u'%s') is not %s" % (test_string, bytes_string))


# Generated at 2022-06-22 22:02:51.049517
# Unit test for function container_to_bytes
def test_container_to_bytes():
    unicode_string = u'\u2713'
    ascii_string = b'ascii_string'
    assert container_to_bytes(unicode_string) == unicode_string.encode('utf-8')
    assert container_to_bytes(ascii_string) == ascii_string
    assert container_to_bytes(unicode_string, errors='replace') == unicode_string.encode('utf-8', errors='replace')
    assert container_to_bytes(ascii_string, errors='replace') == ascii_string
    assert container_to_bytes(unicode_string, encoding='latin-1') == unicode_string.encode('latin-1')
    assert container_to_bytes(ascii_string, encoding='latin-1') == ascii_

# Generated at 2022-06-22 22:03:02.812449
# Unit test for function to_bytes
def test_to_bytes():
    if PY3:
        # These things are byte strings in py3
        assert to_bytes(b'abc', errors='surrogate_or_strict') == b'abc', "to_bytes didn't return byte string"
        assert to_bytes(b'abc', nonstring='passthru', errors='surrogate_or_strict') == b'abc', \
            "to_bytes didn't return byte string"
        assert to_bytes(b'abc', errors='surrogate_or_replace') == b'abc', "to_bytes didn't return byte string"
        assert to_bytes(b'abc', nonstring='passthru', errors='surrogate_or_replace') == b'abc', \
            "to_bytes didn't return byte string"

# Generated at 2022-06-22 22:03:09.346443
# Unit test for function jsonify
def test_jsonify():
    data = {
        'key1': u'\u0451',
        'key2': 'value2',
        'key3': {
            'key4': 'value4',
            'key5': b'value5'
        }
    }
    result = jsonify(data)
    if PY3:
        assert isinstance(result, str)
    else:
        assert isinstance(result, str)
    result = jsonify(data, ensure_ascii=False)
    if PY3:
        assert isinstance(result, str)
    else:
        assert isinstance(result, str)

# Generated at 2022-06-22 22:03:19.424640
# Unit test for function to_native
def test_to_native():
    a = 'test'
    b = b'test'
    c = u'test'

    assert a == to_native(a), "str fails"
    assert a == to_native(b), "Byte fails"
    assert a == to_native(c), "unicode fails"

    a = '\xe2\x82\xac'
    b = b'\xe2\x82\xac'
    c = u'\u20ac'

    assert a == to_native(a), "str fails"
    assert a == to_native(b), "Byte fails"
    assert a == to_native(c), "unicode fails"

    a = "i\u039dm"
    b = b"i\xc3\xb6m"

    assert a == to_native(a), "str fails"


# Generated at 2022-06-22 22:03:30.043278
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test string
    assert container_to_bytes(u'ℌ𝔢𝔩𝔩𝔬') == b'\xe2\x84\x8c\xf0\x9d\x94\xa2\xf0\x9d\x94\xa9\xf0\x9d\x94\xa9\xf0\x9d\x94\xac'
    assert container_to_bytes(u'ℌ𝔢𝔩𝔩𝔬', 'ascii') == b'???'
    # Test dict

# Generated at 2022-06-22 22:03:43.093276
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' Ensure container_to_bytes returns the correct data types '''
    assert isinstance(container_to_bytes(b'foo'), binary_type)
    assert isinstance(container_to_bytes(u'foo'), binary_type)
    assert isinstance(container_to_bytes('foo'), binary_type)
    assert isinstance(container_to_bytes(42), integer_types)
    assert isinstance(container_to_bytes(dict(foo='bar')), dict)
    assert isinstance(container_to_bytes(dict(foo=u'bar')), dict)
    assert isinstance(container_to_bytes(dict(foo=b'bar')), dict)
    assert isinstance(container_to_bytes(dict(foo=[u'bar'])), dict)

# Generated at 2022-06-22 22:03:47.307430
# Unit test for function to_native
def test_to_native():
    bytes_ = u'\xe2\x82\xac'
    text = bytes_.encode('utf-8')
    assert bytes == to_native(bytes, encoding='ascii')
    assert bytes == to_native(bytes_, encoding='ascii')
    assert bytes == to_native(text, encoding='ascii')



# Generated at 2022-06-22 22:03:56.169615
# Unit test for function container_to_text
def test_container_to_text():
    # Make sure it accepts str input
    container_to_text('test')
    # Make sure it accepts text input
    container_to_text(u'test')
    # Make sure it accepts list input
    container_to_text([u'test', 'test'])
    container_to_text([u'test', u'test'])
    container_to_text([b'test', b'test'])
    container_to_text([b'test', u'test'])
    # Make sure it accepts dict input
    container_to_text({u'test': 'test', b'test': u'test'})
    container_to_text({u'test': b'test', b'test': u'test'})



# Generated at 2022-06-22 22:04:09.153440
# Unit test for function container_to_text
def test_container_to_text():
    val = {
        'a': 'abcd',
        'b': {'c': 'd'},
        'e': [1, 2, 3, 4],
        'f': ('s', 't', 'u'),
        'g': b'1234'
    }
    new_val = container_to_text(val)
    assert isinstance(new_val['a'], text_type)
    assert isinstance(new_val['g'], text_type)
    assert new_val == {
        'a': u'abcd',
        'b': {'c': u'd'},
        'e': [1, 2, 3, 4],
        'f': (u's', u't', u'u'),
        'g': u'1234'
    }



# Generated at 2022-06-22 22:04:17.548302
# Unit test for function container_to_text
def test_container_to_text():
    unicode_data = {
        u'simple_value': u'aé',
        u'list_value': [u'aé', u'b'],
        u'dict_value': {u'aé': u'aé', u'b': u'b'},
        u'tuple_value': (u'aé', u'b'),
        u'int_value': 1,
        u'float_value': 1.2,
        u'unicode_value': u'aé',
        u'utf8_value': u'aé'.encode('utf-8'),
        u'latin1_value': u'aé'.encode('latin-1')
    }

# Generated at 2022-06-22 22:04:22.755800
# Unit test for function to_bytes
def test_to_bytes():
    # This is used to make tests shorter and more readable
    to_bytes = lambda s, enc, err: to_bytes(s, encoding=enc, errors=err, nonstring='simplerepr')
    assert to_bytes('hello', 'us-ascii', 'surrogate_or_strict') == b'hello'
    try:
        to_bytes('\u1234', 'us-ascii', 'surrogate_or_strict')
        assert False, 'Should have raised a UnicodeEncodeError'
    except UnicodeEncodeError:
        pass
    assert to_bytes('\u1234', 'utf-8', 'surrogate_or_strict') == b'\xe1\x88\xb4'

# Generated at 2022-06-22 22:04:34.561411
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_dict = {u'foo': u'bar', u'abc': [1, 2, 3], u'a': {u'b': u'c'}}
    bytestr_dict = container_to_bytes(test_dict)
    assert isinstance(bytestr_dict, dict)
    assert isinstance(bytestr_dict[b'foo'], binary_type)
    assert isinstance(bytestr_dict[b'abc'], list)
    assert isinstance(bytestr_dict[b'a'], dict)
    assert isinstance(bytestr_dict[b'a'][b'b'], binary_type)

    test_list = [u'foo', u'bar', u'abc']
    bytestr_list = container_to_bytes(test_list)

# Generated at 2022-06-22 22:04:47.085084
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == 'foo'
    assert to_native(b'\xe6\x97\xa5\xd1\x88', encoding='euc_jp') == u'\u65e5\u672c\u8a9e'
    assert to_native(u'\u65e5\u672c') == '日本語'
    assert to_native(b'\xe6\x97\xa5\xd1\x88', encoding='euc_jp', errors='replace') == '???'

# Generated at 2022-06-22 22:04:54.124294
# Unit test for function container_to_text
def test_container_to_text():
    testdict = dict(test_key1=to_bytes('test_value1'), test_key2=to_bytes('test_value2'))
    testlist = [to_bytes('test_item1'), to_bytes('test_item2')]
    testtuple = (to_bytes('test_tuple1'), to_bytes('test_tuple2'))
    testdict_converted = container_to_text(testdict)
    testlist_converted = container_to_text(testlist)
    testtuple_converted = container_to_text(testtuple)
    assert isinstance(testdict_converted, dict)
    assert isinstance(testlist_converted, list)
    assert isinstance(testtuple_converted, tuple)

# Generated at 2022-06-22 22:05:02.627817
# Unit test for function to_bytes
def test_to_bytes():
    # Module import is in a function so that we don't pollute the global
    # namespace for PY2 and PY3
    # pylint: disable=import-error,redefined-outer-name
    import sys

    import ansible.module_utils.common.text as text

    def fail(s, encoding, errors, nonstring):
        try:
            text.to_bytes(s, encoding, errors, nonstring)
        except Exception as e:
            print(e)
        else:
            raise AssertionError('Should have thrown an exception')

    # Make sure our execution environment is set up correctly
    assert text.HAS_SURROGATEESCAPE == (sys.version_info >= (3, 4))

    # Test text types
    assert text.to_bytes(u'foo', 'utf-8') == b

# Generated at 2022-06-22 22:05:12.847017
# Unit test for function to_bytes
def test_to_bytes():
    string = u"This is a test.  Тестируем"
    try:
        codecs.lookup_error('surrogateescape')
        surrogateescape = True
    except LookupError:
        surrogateescape = False
    utf8 = u'This is a test.  \u0422\u0435\u0441\u0442\u0438\u0440\u0443\u0435\u043c'
    latin1 = 'This is a test.  \xc3\x82\xc3\xa5\xc3\x93\xc3\xa5\xc3\xa9'.decode('latin-1')

    assert to_bytes(string, encoding='utf-8') == string.encode('utf-8')

# Generated at 2022-06-22 22:05:22.982729
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_native
    from io import StringIO
    import json
    import sys
    import unittest

    # data with non unicode, non ascii characters

# Generated at 2022-06-22 22:05:27.594843
# Unit test for function to_native
def test_to_native():
    assert to_native('\xc3\xa9\xc3\xab\xc3\xad\xc3\xaf\xc3\xa1', encoding='utf-8') == u'éëíïá'


_native_value_types = (None, bool, int, float, Set)



# Generated at 2022-06-22 22:05:39.135935
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    assert to_native(u'pass') == u'pass'
    assert to_native(u"héllo") == u"héllo"
    assert to_native(b'pass') == u'pass'
    assert to_native(b'\xc3\xa9') == u'\xe9'
    assert to_native(b'\xc3\xa9', encoding='latin1', errors='surrogate_or_strict') == u'\udce9'
    assert to_native(b'\xc3\xa9', encoding='latin1', errors='surrogate_or_replace') == u'\ufffd'

# Generated at 2022-06-22 22:05:46.569897
# Unit test for function to_native
def test_to_native():
    assert to_native('foo') == u'foo'
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'

    assert to_native(1) == 1
    assert to_native(True) is True
    assert to_native([1, 2, 3]) == [1, 2, 3]
    assert to_native(Set()) == set()
    assert to_native((1, 2, 3)) == (1, 2, 3)
    # Unit test for function to_text

# Generated at 2022-06-22 22:05:54.343606
# Unit test for function jsonify
def test_jsonify():
    foo = {b'bar': b'1234'}
    assert json.loads(jsonify(foo)) == foo
    foo = {b'bar': u'1234'}
    assert json.loads(jsonify(foo)) == foo
    foo = {u'bar': u'1234'}
    assert json.loads(jsonify(foo)) == foo
    foo = {u'bar': u'1234'}
    assert json.loads(jsonify(foo, ensure_ascii=False)) == foo
    foo = {u'bar': u'1234'}
    bar = jsonify(foo, ensure_ascii=False)
    assert isinstance(bar, text_type)
    assert json.loads(bar) == foo


# Generated at 2022-06-22 22:06:02.704041
# Unit test for function container_to_text
def test_container_to_text():
    from ansible.compat.tests import unittest
    from ansible.module_utils._text import to_text

    # tests encoding of different types of text
    test_dict = {
        'a': b'plain text',
        'b': to_bytes('with unicode: \xe2\x88\x88'),
    }
    # tests encoding of types not supported by container_to_text
    test_dict2 = {
        'a': u'unicode text: \u6c49',
        'b': 'with unicode: \xe2\x88\x88',
        'c': 1234567
    }


# Generated at 2022-06-22 22:06:08.454813
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native([1, 2]) == '[1, 2]'
    assert to_native({1: 2}) == '{1: 2}'


_BYTESLIKE = Set((binary_type, bytearray))



# Generated at 2022-06-22 22:06:17.864388
# Unit test for function jsonify
def test_jsonify():
    bad_utf8 = b'\x80abc'
    try:
        # Attempt to create a text string (unicode in python2) from bad_utf8
        bad_utf8.decode('utf-8')

        # If we get here, then the python doesn't have PEP 383 support
        # and so the bytes string can't contain invalid utf-8.  Since
        # we can't test jsonify with an invalid utf-8 byte string we're
        # going to raise a SkipTest.
        raise Exception
    except UnicodeDecodeError:
        # NOTE: We catch a specific exception here to avoid masking any
        # other errors
        pass

    # This should not traceback
    assert jsonify(bad_utf8) == to_native(bad_utf8)



# Generated at 2022-06-22 22:06:29.315996
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foô') == b'fo\xc3\xb4'
    assert to_bytes(b'fo\xc3\xb4') == b'fo\xc3\xb4'
    assert to_bytes(u'fo\x80') == b'fo\xef\xbf\xbd'
    assert to_bytes(b'fo\x80') == b'fo\x80'
    assert to_bytes('fo') == b'fo'
    assert to_bytes('fo', nonstring='simplerepr') == b'fo'
    assert to_bytes(u'fo\u0154') == b'fo\xc5\x94'
    assert to_bytes(u'fo\u0154', 'latin-1') == b'fo\x94'

# Generated at 2022-06-22 22:06:36.615346
# Unit test for function jsonify
def test_jsonify():
    import json
    import datetime
    from ansible.module_utils.six import PY3
    # Jsonify primitive data
    data = u"data"
    assert jsonify(data) == "\"data\""

    # Jsonify list, set, datetime
    set_data = set([u"data1", u"data2"])
    if PY3:
        assert jsonify(set_data) == "[\"data1\", \"data2\"]"
        assert jsonify(datetime.datetime.now()) == "\"%s\"" % datetime.datetime.now().isoformat()
    else:
        set_data = [set_data]
        assert jsonify(set_data) == "[[\"data1\", \"data2\"]]"
        datetime_str = datetime.datetime.now().iso

# Generated at 2022-06-22 22:06:41.440235
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.text_utils.text_annotator import annotate_text
    from ansible.module_utils.common.text_utils import to_text

    if PY3:
        # No surrogates
        with annotate_text(text=u'\U0001F4A9'):
            assert to_native(u'\U0001F4A9') == '\U0001F4A9'
            assert to_native(to_bytes(u'\U0001F4A9')) == '\U0001F4A9'

        # Has surrogates
        with annotate_text(text=u'\ud83d\udca9'):
            assert to_native(u'\ud83d\udca9') == u

# Generated at 2022-06-22 22:06:45.593594
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('str') == '"str"'
    assert jsonify(u'ééé') == u'"ééé"'
    assert jsonify(u'\xa3') == '"\\u00a3"'



# Generated at 2022-06-22 22:06:57.597679
# Unit test for function to_bytes
def test_to_bytes():
    # Basic checks for ascii, unicode and byte strings
    assert u'foo' == to_bytes(u'foo')
    assert u'foo'.encode('ascii') == to_bytes(u'foo', 'ascii')
    assert b'foo' == to_bytes(b'foo')
    assert b'foo' == to_bytes(b'foo', nonstring='passthru')
    assert b'' == to_bytes(None)
    assert b'' == to_bytes(None, nonstring='empty')
    assert b'' == to_bytes(False)
    assert b'' == to_bytes(False, nonstring='empty')
    assert b'1' == to_bytes(True)
    assert b'1' == to_bytes(True, nonstring='empty')
    # Note: This is a str in python

# Generated at 2022-06-22 22:07:08.694789
# Unit test for function to_bytes
def test_to_bytes():
    '''
    Unit test for function to_bytes
    '''
    import tempfile
    import os

    def _create_file_with_contents(contents, filename=None):
        '''
        Generic function to create a file on the system with the given contents.  Returns
        the filename of the file.
        '''
        fd, filename = tempfile.mkstemp()
        f = os.fdopen(fd, 'wb')
        f.write(contents)
        f.close()
        return filename

    def _remove_file(filename):
        '''
        Generic function to remove the file passed in.
        '''
        os.unlink(filename)

    # A bunch of utf-8 strings
    non_ascii_utf8 = u'abcdé'
    non_ascii

# Generated at 2022-06-22 22:07:19.595256
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(u'\U0001f638') == b'\xf0\x9f\x98\xb8'
    assert container_to_bytes([u'\U0001f638']) == [b'\xf0\x9f\x98\xb8']
    assert container_to_bytes((u'\U0001f638', u'\U0001f468')) == (b'\xf0\x9f\x98\xb8', b'\xf0\x9f\x91\xa8')

# Generated at 2022-06-22 22:07:27.372454
# Unit test for function to_native
def test_to_native():
    assert to_native(b"hello") == 'hello'
    assert to_native(u'\u7684') == u'\u7684'

    # python2.4 doesn't have b''
    if PY3:
        assert to_native(b'') == ''
    else:
        assert to_native('') == ''

    assert to_native({u'a': u'b'}) == {u'a': u'b'}
    assert to_native({u'a': u'b'}, nonstring='simplerepr') == "{u'a': u'b'}"
    assert to_native({u'a': u'b'}, nonstring='passthru') == {u'a': u'b'}

# Generated at 2022-06-22 22:07:32.334360
# Unit test for function container_to_text
def test_container_to_text():
    dict_data = dict(k1=1, k2='c')
    data = ['a', 'b', dict_data]
    text_data = container_to_text(data, encoding='utf-8', errors='surrogate_or_strict')
    assert isinstance(text_data[0], text_type)
    assert isinstance(text_data[1], text_type)
    for k, v in iteritems(text_data[2]):
        assert isinstance(k, text_type)
        assert isinstance(v, text_type)
    return text_data

# Generated at 2022-06-22 22:07:45.344223
# Unit test for function to_native
def test_to_native():
    # From: https://github.com/ansible/ansible/blob/devel/test/units/utils/test_module_utils_text.py
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u2318') == '\xe2\x8c\x98'
    assert to_native(b'foo') == 'foo'
    assert to_native(b'\xe2\x8c\x98') == '\xe2\x8c\x98'
    assert to_native(b'\xe2\x8c\x98', errors='surrogate_or_replace') == '\xe2\x8c\x98'

# Generated at 2022-06-22 22:07:53.460391
# Unit test for function jsonify
def test_jsonify():
    data = {u"\u6d4b\u8bd5": 123, u"\u6d4b\u8bd5": 456, u"\u6d4b\u8bd5": 789}
    data2 = {
        u'\uc77c\uc790\ub9ac': [u'\uc11c\ub85c\uc778\uc815\uad50\ud65c',
                                u'\uc9c4\uc720\uc5d0\uc775']
    }
    data3 = {
        u'\u4e2d\u6587': [u'\u4e2d\u6587', u'\u4e2d\u6587']
    }

# Generated at 2022-06-22 22:07:57.616172
# Unit test for function jsonify
def test_jsonify():
    assert u"\"\xe9\u20ac\"" == jsonify(u"\xe9\u20ac", ensure_ascii=False)
    assert "\"\\u00e9\\u20ac\"" == jsonify(u"\xe9\u20ac", ensure_ascii=True)
    assert "[1, 2, 3]" == jsonify([1, 2, 3])



# Generated at 2022-06-22 22:08:09.334115
# Unit test for function container_to_text
def test_container_to_text():
    """Unit test for function container_to_text"""
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestText(unittest.TestCase):
        """Unit test class for function container_to_text"""
        def test_normal_run(self):
            """Normal run test case for function container_to_text"""
            self.assertEqual(
                container_to_text(
                    dict(a=1,
                         b=[dict(c=1), dict(c=2)],
                         d=dict(e=dict(f=1)))
                ),
                dict(a=1,
                     b=[dict(c=1), dict(c=2)],
                     d=dict(e=dict(f=1)))
            )

# Generated at 2022-06-22 22:08:18.199757
# Unit test for function to_native
def test_to_native():
    assert to_text(u'ascii') == u'ascii'
    assert to_text('ascii') == u'ascii'
    assert to_text(b'ascii') == u'ascii'
    assert to_text(u'\u5341\u5341\u5341') == u'\u5341\u5341\u5341'
    assert to_text('\xe5\x90\x8d\xe5\x88\xab') == u'\u5341\u5341\u5341'
    assert to_text(b'\xe5\x90\x8d\xe5\x88\xab') == u'\u5341\u5341\u5341'



# Generated at 2022-06-22 22:08:29.357159
# Unit test for function container_to_bytes
def test_container_to_bytes():
    data = {
        u'bytes': u'bytes_value',
        u'unicode': u'\u263a',
        u'list': [u'list_value', u'list_\u263a'],
        u'tuple': (u'tuple_value', u'tuple_\u263a'),
        u'dict': {
            u'unicode': u'dict_unicode_value',
            u'bytes': u'dict_bytes_value',
            u'list': [u'list_value', u'list_\u263a']
        }
    }

# Generated at 2022-06-22 22:08:40.985219
# Unit test for function container_to_text
def test_container_to_text():

    # Test with a dictionary that has utf-8 encoded bytes
    utf8_dict = {
        b'key1': b'value1',
        b'key2': b'\xed\xb3\xac',
    }
    assert container_to_text(utf8_dict) == {
        'key1': 'value1',
        'key2': u'\uac1c',
    }

    # Test with a dictionary that has latin-1 encoded bytes
    latin1_dict = {
        b'key1': b'value1',
        b'key2': b'\xed\xb3\xac',
    }

# Generated at 2022-06-22 22:08:48.163151
# Unit test for function to_bytes
def test_to_bytes():
    assert isinstance(to_bytes('test'), binary_type)
    assert to_bytes('test') == b'test'

    # test byte string
    byte_test = b'test'
    assert to_bytes(byte_test) is byte_test

    # test surrogateescape
    assert to_bytes('\udce5\udcee\udcef') == b'\xff\xff\xff'
    assert to_bytes('\udce5\udcee\udcef', errors='surrogate_or_strict') == b'\xff\xff\xff'
    assert to_bytes('\udce5\udcee\udcef', errors='surrogate_or_replace') == b'\xff\xff\xff'

# Generated at 2022-06-22 22:08:58.857189
# Unit test for function container_to_bytes
def test_container_to_bytes():
    '''Tests for container_to_bytes'''
    data1 = {'ascii_key': 'ascii_value', u'unicode_key': u'unicode_value'}
    res = container_to_bytes(data1)
    assert isinstance(res, dict)
    assert isinstance(res.keys()[0], str)
    assert isinstance(res.values()[0], str)
    assert isinstance(res.keys()[1], str)
    assert isinstance(res.values()[1], str)

    data2 = [u'unicode_value', 'ascii_value']
    res = container_to_bytes(data2)
    assert isinstance(res, list)
    assert isinstance(res[0], str)
    assert isinstance(res[1], str)



# Generated at 2022-06-22 22:09:08.749245
# Unit test for function container_to_text
def test_container_to_text():
    en_text_obj = {'k1': 'hello'}
    assert container_to_text(en_text_obj) == en_text_obj

    utf8_text_obj = {'k1': '你好'}
    assert container_to_text(utf8_text_obj) == utf8_text_obj

    chinese_text_obj = {'k1': b'\xe4\xbd\xa0\xe5\xa5\xbd'}
    assert container_to_text(chinese_text_obj) == utf8_text_obj

    chinese_text_obj = {'k1': b'\xe4\xbd\xa0\xe5\xa5\xbd'}
    assert container_to_text(chinese_text_obj) == utf8

# Generated at 2022-06-22 22:09:19.491254
# Unit test for function to_bytes
def test_to_bytes():  # noqa
    global _COMPOSED_ERROR_HANDLERS_SET
    str_unicode_to_bytes_map = {
        'e9': u'\xE9',
        'eac0': u'\uEAC0',
        '41ac80': u'\U000041ac80',
    }

    for result, unicode_val in iteritems(str_unicode_to_bytes_map):
        assert to_bytes(unicode_val) == codecs.decode(result, 'hex')
        assert to_bytes(unicode_val, errors='surrogate_or_replace') == codecs.decode(result, 'hex')

# Generated at 2022-06-22 22:09:28.354246
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes('a') == b'a'
    assert container_to_bytes('a', nonstring='passthru') == 'a'
    assert container_to_bytes({}) == {}
    assert container_to_bytes({}, nonstring='passthru') == {}
    assert container_to_bytes(['a']) == [b'a']
    assert container_to_bytes([u'a']) == [b'a']
    assert container_to_bytes([b'a']) == [b'a']
    assert container_to_bytes([u'a'], nonstring='passthru') == [u'a']
    assert container_to_bytes((u'a',)) == (b'a',)

# Generated at 2022-06-22 22:09:34.785284
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'\xe2\x98\xa3') == b'\xe2\x98\xa3'
    assert to_bytes('\xe2\x98\xa3') == b'\xe2\x98\xa3'
    assert to_bytes(u'\u2603') == b'\xe2\x98\xa3'
    assert to_bytes('\u2603') == b'\xe2\x98\xa3'
    assert to_bytes(u'☃\u2603') == b'\xe2\x98\x83\xe2\x98\xa3'
    assert to_bytes('☃\u2603') == b'\xe2\x98\x83\xe2\x98\xa3'

# Generated at 2022-06-22 22:09:42.286788
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test that container_to_bytes can handle objects which can be
    # serialized to JSON
    assert container_to_bytes({u'a': u'b', 'c': 'd'}) == {b'a': b'b', b'c': b'd'}
    assert container_to_bytes([u'a', 'b']) == [b'a', b'b']
    assert container_to_bytes((u'a', 'b')) == (b'a', b'b')
    assert container_to_bytes(u'a') == b'a'

# Generated at 2022-06-22 22:09:53.905044
# Unit test for function container_to_text
def test_container_to_text():
    # the list defined in utf-8
    for_utf8 = [
        {u'utf8_str': u'\u6d4b\u8bd5'},
        {u'utf8_list': [u'\u6d4b\u8bd5', u'utf8']},
        u'\u6d4b\u8bd5',
        [u'\u6d4b\u8bd5', u'utf8'],
        (u'\u6d4b\u8bd5', u'utf8'),
        u'\u6d4b\u8bd5'
    ]
    # the list defined in gb2312

# Generated at 2022-06-22 22:09:58.638370
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(["a"]) == ["a"]
    assert container_to_bytes(("a", "b")) == ("a", "b")
    assert container_to_bytes({'a': 'b'}) == {'a': 'b'}



# Generated at 2022-06-22 22:10:07.187836
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text({u'key': 'value'}) == {u'key': u'value'}
    assert container_to_text({b'key': 'value'}) == {u'key': u'value'}
    assert container_to_text({b'veryunlikelyutf8string': b'value'}) == {u'veryunlikelyutf8string': u'value'}

    assert container_to_text('value') == u'value'
    assert container_to_text(b'value') == u'value'
    assert container_to_text(b'veryunlikelyutf8string') == u'veryunlikelyutf8string'

    assert container_to_text([b'value']) == [u'value']
    assert container_to_text((b'value',)) == (u'value',)

   

# Generated at 2022-06-22 22:10:19.499451
# Unit test for function jsonify
def test_jsonify():
  assert jsonify('foo') == '"foo"'
  assert jsonify(u'\u20ac') == u'"\u20ac"'
  assert jsonify(u'\u20ac'.encode('utf-16')) == u'"\u20ac"'
  assert jsonify(u'\u20ac'.encode('latin-1')) == u'"\u20ac"'
  assert jsonify(u'\u20ac'.encode('utf-16'), ensure_ascii=False) == u'"\u20ac"'
  assert jsonify(u'\u20ac'.encode('latin-1'), ensure_ascii=False) == u'"\u20ac"'

# Generated at 2022-06-22 22:10:27.279619
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # container_to_bytes(d, encoding='utf-8', errors='surrogate_or_strict')
    # type(d) == text_type
    assert container_to_bytes(u'string') == b'string'
    # type(d) == dict
    d = {u'a': u'value1', u'b': u'value2'}
    assert container_to_bytes(d) == {b'a': b'value1', b'b': b'value2'}
    # type(d) == list
    l = [u'string1', u'string2']
    assert container_to_bytes(l) == [b'string1', b'string2']
    # type(d) == tuple

# Generated at 2022-06-22 22:10:34.057926
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_dict = {"a": 2, "b": "ä"}
    test_list = [test_dict]
    test_tuple = (test_dict, test_list)

    # Tests for both valid and invalid utf-8 and latin-1
    test_invalid = b"\xef\xbf\xbf"
    test_valid = b"\xc3\xa4"

    assert(container_to_bytes(test_dict, "utf-8") == {"a": 2, "b": test_valid})
    assert(container_to_bytes(test_dict, "latin-1") == {"a": 2, "b": test_valid})
    # test surrogate_or_strict

# Generated at 2022-06-22 22:10:44.402715
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_dict = { u'bytes': u'\xc3\xbc', 'foo': 'bar', 'list': [u'\xc3\xbc'] }
    new_dict = container_to_bytes(test_dict)
    assert isinstance(new_dict[b'bytes'], binary_type)
    assert isinstance(new_dict[b'foo'], binary_type)
    assert isinstance(new_dict[b'list'][0], binary_type)

    # Helps debug errors.
    if new_dict == {b'bytes':b'\xfc', b'foo':b'bar', b'list':[b'\xfc']}:
        return
    else:
        raise AssertionError('container_to_bytes failed unit test')



# Generated at 2022-06-22 22:10:56.490321
# Unit test for function container_to_bytes

# Generated at 2022-06-22 22:11:04.459959
# Unit test for function to_native

# Generated at 2022-06-22 22:11:11.199128
# Unit test for function jsonify
def test_jsonify():
    class Foo(object):
        """Class Foo"""
        def __repr__(self):
            """Foo.__repr__"""
            return u'Foo(%s)' % 'foo'

    obj = Foo()
    assert jsonify(obj) == ('"Foo(%s)"' % 'foo')

    # test object_hook
    obj_dict = {"foo": "bar"}
    assert jsonify(obj_dict, object_hook=lambda d: dict((('test_' + k), v) for k, v in iteritems(d))) == u'{"test_foo": "bar"}'

    # test custom cls
    class MyEncoder(json.JSONEncoder):
        """MyEncoder"""
        def encode(self, o):
            """MyEncoder.encode"""

# Generated at 2022-06-22 22:11:20.328439
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    if PY3:
        assert isinstance(to_native(b"foobar"), str)
        assert to_native(b"foobar") == "foobar"
        assert to_native(u"foobar") == "foobar"
    else:
        assert isinstance(to_native("foobar"), str)
        assert to_native("foobar") == "foobar"
        assert to_native(b"foobar") == "foobar"
        assert to_native(u"foobar") == u"foobar"
# End of unit test for function to_native


# Generated at 2022-06-22 22:11:33.411843
# Unit test for function jsonify
def test_jsonify():
    # Test for function jsonify: with unicode not contain 'ascii'
    test_input = to_text(u'\u8c37\u6b4c', 'utf-8')
    test_output = jsonify(test_input)
    assert test_output == b'"\xe8\xb1\x86\xe7\xae\x80"'

    # Test for function jsonify: with Set
    test_input = Set([1, 2, 3])
    test_output = jsonify(test_input)
    assert test_output == b'[1, 2, 3]'

    # Test for function jsonify: with DateTime
    test_input = datetime.datetime.now()
    test_output = jsonify(test_input)
    assert test_output == '"%s"' % test_input.iso

# Generated at 2022-06-22 22:11:43.164050
# Unit test for function container_to_text
def test_container_to_text():
    test_data = {
        'byte':b'\x00',
        'unicode':'\u0000',
        'dict':{'byte':b'\x00', 'unicode':'\u0000'},
        'list':[b'\x00', '\u0000'],
        'tuple':(b'\x00', '\u0000')
    }
    assert container_to_text(test_data) == {
        'byte':'\x00',
        'unicode':'\u0000',
        'dict':{'byte':'\x00', 'unicode':'\u0000'},
        'list':['\x00', '\u0000'],
        'tuple':('\x00', '\u0000')
    }
