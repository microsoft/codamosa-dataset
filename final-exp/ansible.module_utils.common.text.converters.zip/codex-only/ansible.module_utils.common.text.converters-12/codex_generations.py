

# Generated at 2022-06-22 22:01:49.529223
# Unit test for function to_native
def test_to_native():
    assert to_text(u'\u00e9') == u'\u00e9'
    assert to_text(u'\u00e9'.encode('utf-8')) == u'\u00e9'

    if PY3:
        assert to_native(b'test') == 'test'
        assert to_native('test') == 'test'
        assert to_native(u'\u00e9') == '\u00e9'
        assert to_native(1) == 1
        assert to_native(datetime.datetime.utcnow()) == datetime.datetime.utcnow()
        assert to_native({'a': b'1', u'b': b'2'}) == {'a': '1', 'b': '2'}

# Generated at 2022-06-22 22:02:01.924876
# Unit test for function to_native
def test_to_native():
    assert to_native(u'hello') == u'hello'
    assert to_native(u'こんにちは') == u'こんにちは'
    assert to_native('hello') == u'hello'
    assert to_native('こんにちは') == u'こんにちは'
    assert to_native(u'\xe3\x81\x93\xe3\x82\x93\xe3\x81\xab\xe3\x81\xa1\xe3\x81\xaf') == u'\u3053\u3093\u306b\u3061\u306f'

# Generated at 2022-06-22 22:02:14.976442
# Unit test for function container_to_bytes
def test_container_to_bytes():
    from ansible.compat.tests import unittest

    class TestContainerToBytesUnicode(unittest.TestCase):
        def setUp(self):
            self.string = u'Hi \u2100'
            self.dict   = {u'string': u'Hi \u2100', u'list': [1,2,3], u'tuple': (5,6,7,8)}
            self.list   = [u'Hi \u2100', 1, 'two', [3,4,5], (6,7,8)]
            self.tuple  = (u'Hi \u2100', 1, 'two', [3,4,5], (6,7,8))


# Generated at 2022-06-22 22:02:16.819311
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'


# Generated at 2022-06-22 22:02:28.178997
# Unit test for function to_bytes
def test_to_bytes():
    # Python2's str() of unicode strings is bytestring
    assert isinstance(to_bytes(u'foo'), binary_type)
    assert isinstance(to_bytes('foo'), binary_type)
    if PY3:
        # Python3's str() of unicode strings is text type
        assert isinstance(str(u'foo'), text_type)
        assert isinstance(str('foo'), text_type)

    assert u'foo'.encode('utf-8') == to_bytes(u'foo')
    assert u'føø'.encode('utf-8') == to_bytes(u'føø')

    assert u'føø'.encode('latin1', 'replace') == to_bytes(u'føø', 'latin1')

# Generated at 2022-06-22 22:02:34.825838
# Unit test for function jsonify
def test_jsonify():
    data = {
        "1": "2",
        "2": "3",
        "3": "4",
        "4": {
            "11": "22",
            "22": "33",
            "33": "44"
        },
        "5": {
            "111": "222",
            "222": "333",
            "333": "444"
        }
    }
    ret = jsonify(data)
    print(ret)
    assert isinstance(ret, str)


# Generated at 2022-06-22 22:02:45.370437
# Unit test for function to_bytes
def test_to_bytes():
    try:
        to_bytes("\xff", 'latin-1', 'surrogate_or_strict')
        assert False, 'surrogate_or_strict should not encode latin-1'
    except (UnicodeEncodeError, UnicodeDecodeError):
        pass

    assert to_bytes("ä", 'ascii', 'surrogate_or_strict') == b'?'
    assert to_bytes("ä", 'ascii', 'surrogate_or_replace') == b'?'
    assert to_bytes("ä", 'ascii', 'surrogate_then_replace') == b'?'
    assert to_bytes("\xff", 'latin-1') == b'\xff'

# Generated at 2022-06-22 22:02:57.162296
# Unit test for function to_bytes
def test_to_bytes():
    # make sure we can't import this module pre-2.4
    try:
        from unittest import skipIf
    except ImportError:
        # Note, this should be evaluated at import time so we don't need to
        # do the byte compile checking on Python 3.
        try:
            from unittest2 import skipIf
        except ImportError:
            def skipIf(condition, reason):
                def inner(obj):
                    return obj
                return inner

    PY24 = skipIf(not __import__('sys').version_info < (2, 5), 'Test only applies to python 2.4 or earlier')

    import unittest
    import sys


# Generated at 2022-06-22 22:03:02.864558
# Unit test for function jsonify
def test_jsonify():
    mydict = {'a': 1,
              'b': (1, 2, 3),
              'c': [b'ab', b'cd', b'ef']}
    answer = '{"a": 1, "b": [1, 2, 3], "c": ["ab", "cd", "ef"]}'
    assert jsonify(mydict) == answer



# Generated at 2022-06-22 22:03:09.369388
# Unit test for function jsonify
def test_jsonify():
    # jsonify test using utf-8 encoding
    data = dict(a=2, b='foo', c=None, d=[1, 2, 3], e={'e': 'ee'})
    new_data = jsonify(data)
    assert new_data == '{"a": 2, "c": null, "b": "foo", "e": {"e": "ee"}, "d": [1, 2, 3]}'
    # jsonify test using latin-1 encoding
    data = dict(a=2, b=u'\xe9', c=None, d=[1, 2, 3], e={'e': 'ee'})
    new_data = jsonify(data)

# Generated at 2022-06-22 22:03:18.613625
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u1234') == u'\u1234'
    assert to_native(u'\u1234'.encode('utf-16')) == u'\u1234'
    assert to_native('\xe4\xbd\xa0\xe5\xa5\xbd') == u'你好'
    assert to_native(b'\xe4\xbd\xa0\xe5\xa5\xbd') == u'你好'
    assert to_native(b'\xe4\xbd\xa0\xe5\xa5\xbd'.decode('utf-8')) == u'你好'

# Generated at 2022-06-22 22:03:29.369205
# Unit test for function to_native
def test_to_native():
    # test with py3 bytes
    assert to_native(b'foo') == 'foo'

    # test with py2 bytes
    assert to_native(str('foo')) == 'foo'

    # test with unicode
    assert to_native(u'foo') == u'foo'

    # nonstring
    # simplerepr
    assert to_native(42, nonstring='simplerepr') == '42'
    assert to_native(datetime.datetime(1980, 1, 21, 23, 30, 0, 0), nonstring='simplerepr') == 'datetime.datetime(1980, 1, 21, 23, 30)'

    # passthru
    assert to_native(42, nonstring='passthru') == 42

# Generated at 2022-06-22 22:03:42.201464
# Unit test for function jsonify
def test_jsonify():
    data = dict(a="text1", b=dict(c=1), d=[1, 2, 3])
    assert jsonify(data) == '{"a": "text1", "d": [1, 2, 3], "b": {"c": 1}}'
    assert jsonify(data, sort_keys=True) == '{"a": "text1", "b": {"c": 1}, "d": [1, 2, 3]}'
    assert jsonify(data, indent=2) == '{\n  "a": "text1", \n  "d": [\n    1, \n    2, \n    3\n  ], \n  "b": {\n    "c": 1\n  }\n}'

# Generated at 2022-06-22 22:03:52.027816
# Unit test for function to_bytes
def test_to_bytes():
    """Unit tests for :py:func:`ansible.module_utils.basic.to_bytes`"""

    try:
        codecs.lookup_error('surrogateescape')
        HAS_SURROGATEESCAPE = True
    except LookupError:
        HAS_SURROGATEESCAPE = False

    import os
    import sys

    # Guess how we were invoked to determine PY3
    PY3 = sys.version_info[0] > 2

    #
    # Inputs and expected outputs
    #

    #
    # byte strings
    if PY3:
        byte_string = b'bytes'
    else:
        byte_string = str('bytes')

    byte_string_ansi_c_escape_decoded = str('b\'bytes\'')

    # We expect that to_

# Generated at 2022-06-22 22:04:03.501359
# Unit test for function to_native
def test_to_native():
    # bytes to bytes
    assert to_native(b'abc') == b'abc'
    # text to text
    assert to_native(u'abc') == u'abc'
    # bytes to text
    assert to_native(b'abc', encoding='ascii') == u'abc'
    # text to bytes
    assert to_native(u'abc', nonstring='simplerepr') == b"'abc'"
    # int to text
    assert to_native(7) == u'7'
    # list to text
    assert to_native([u'a', 'b', b'c']) == u"[u'a', 'b', 'c']"
    # tuple to text
    assert to_native((u'a', 'b', b'c')) == u"(u'a', 'b', 'c')"


# Generated at 2022-06-22 22:04:13.589087
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b="string")) == '{"a": 1, "b": "string"}'
    assert jsonify(dict(a=1, b=to_bytes("string"))) == '{"a": 1, "b": "string"}'
    assert jsonify(dict(a=1, b=to_bytes(u"string\u1234"))) == '{"a": 1, "b": "string\u1234"}'
    assert jsonify(dict(a=1, b=to_bytes(u"string\u1234".encode('utf-16')))) == '{"a": 1, "b": "string\\udcc4\\udc00"}'



# Generated at 2022-06-22 22:04:15.029477
# Unit test for function container_to_text
def test_container_to_text():
    ''' Test for function container_to_text '''
# End Unit test for function container_to_text



# Generated at 2022-06-22 22:04:21.006206
# Unit test for function container_to_bytes
def test_container_to_bytes():
    this = {"foo": b"bar",
            "baz": u"qux",
            "bar": [1,2,3],
            "a": {"b": b"c"},
            "utf8string": "utf8\u6162",
            "utf8unicode": u"utf8\u6162",
            }
    more_this = {"foo": b"bar",
                 "baz": u"qux",
                 "bar": [1,2,3],
                 "a": {"b": b"c"},
                 "utf8string": "utf8\u6162",
                 "utf8unicode": u"utf8\u6162",
                 }
    more_this['another'] = this


# Generated at 2022-06-22 22:04:24.733736
# Unit test for function to_native
def test_to_native():
    # We shouldn't trigger an exception
    result = to_native(u'foo')

    # We should get back a text type
    assert isinstance(result, text_type)

    # We should get back the same string
    assert result == u'foo'



# Generated at 2022-06-22 22:04:36.359834
# Unit test for function to_bytes
def test_to_bytes():
    # Python 2 doesn't have `b''` so to_bytes('') gives a slightly different result
    # on Python 2 vs Python 3.  Also since we're hardcoding the lookup of
    # surrogatescape to False we can't test the surrogateescape settings of to_bytes.
    # Python 2 also gives different results when it can't encode utf-8 to ascii.  So
    # we're just going to ignore those tests.

    # Test that bytes works
    assert b'a\xb7\u6c34\U0001f34c' == to_bytes(u'a\xb7\u6c34\U0001f34c')

    # Test surrogate_or_strict

# Generated at 2022-06-22 22:04:44.465688
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes('\xe9') == b'\xc3\xa9'
    assert container_to_bytes(['\xe9']) == [b'\xc3\xa9']
    assert container_to_bytes(('\xe9',)) == (b'\xc3\xa9',)
    assert container_to_bytes({'\xe9': '\xe9'}) == {b'\xc3\xa9': b'\xc3\xa9'}



# Generated at 2022-06-22 22:04:48.831501
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert {b'a': 1, b'b': 2} == container_to_bytes({'a': 1, 'b': 2})
    assert {b'a': 1,
            b'b': 2,
            b'c': [3, 4, {b'd': 5, b'e': 6}]} == container_to_bytes({'a': 1, 'b': 2, 'c': [3, 4, {'d': 5, 'e': 6}]})


# Generated at 2022-06-22 22:04:53.916036
# Unit test for function container_to_text
def test_container_to_text():
    # Dictionary
    assert container_to_text({'happy': 'birth_day', 'to': 'you'}) == {'happy': u'birth_day', 'to': u'you'}
    # List
    assert container_to_text([1, 2, 3]) == [1, 2, 3]
    # Tuple
    assert container_to_text((7, 8, 9, 10)) == (7, 8, 9, 10)
    # String
    assert container_to_text('django') == u'django'

# Unit tests for function to_text

# Generated at 2022-06-22 22:05:02.507110
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert b'foo' == container_to_bytes('foo')
    assert [b'foo', b'bar', b'baz'] == container_to_bytes(['foo', 'bar', 'baz'])
    assert (b'foo', b'bar', b'baz') == container_to_bytes(('foo', 'bar', 'baz'))
    assert {b'foo':b'bar', b'baz': 'baz'} == container_to_bytes({'foo':'bar', 'baz': 'baz'})
    assert {b'foo':b'bar', b'baz': 'baz'} == container_to_bytes({b'foo':'bar', b'baz': 'baz'})
    assert {b'foo':[b'bar', b'baz']} == container_to_

# Generated at 2022-06-22 22:05:08.953080
# Unit test for function container_to_text
def test_container_to_text():
    d = {
        'a': {
            'b': b'c',
            'd': [b'e', 'f', u'\u2713']
        }
    }
    expected = {
        'a': {
            'b': 'c',
            'd': ['e', 'f', '✓']
        }
    }
    assert(container_to_text(d) == expected)


# Generated at 2022-06-22 22:05:20.809371
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.six import text_type
    import datetime
    test_list = [ { 'unicode': u'\u2713', 'int': 1, 'float': 3.14, 'list': ['a', 'b'], 'dict': {'a': 'b'}, 'none': None, 'true': True, 'false': False, 'datetime': datetime.datetime(2012,11,15,1,30) } ]
    expected_result = text_type('[{"dict": {"a": "b"}, "false": false, "none": null, "true": true, "float": 3.14, "int": 1, "list": ["a", "b"], "unicode": "\u2713", "datetime": "2012-11-15T01:30:00"}]')

# Generated at 2022-06-22 22:05:31.604912
# Unit test for function container_to_text
def test_container_to_text():
    tests = {
        u'TO BE ENCODED\U0001f48b': {
            'utf-8': b'TO BE ENCODED\xf0\x9f\x92\x8b',
            'ascii': b'TO BE ENCODED?',
        },
    }

    for text, texts in iteritems(tests):
        print("Testing %s" % repr(text))
        for encoding, expected_bytes in iteritems(texts):
            result = container_to_text(expected_bytes, encoding=encoding)
            print("  %s: %s => %s" % (encoding, repr(expected_bytes), repr(result)))
            assert result == text
            assert isinstance(result, text_type)


# Generated at 2022-06-22 22:05:41.664239
# Unit test for function container_to_text
def test_container_to_text():
    my_list = ['yay value', 'another value']
    my_dict = {
        'key1': 'value1',
        'key2': 'value2'
    }
    my_dict_in_list = ['value1', {'key1': 'value1'}]
    my_list_in_dict = {'key1': ['value1', 'value2']}
    my_dict_in_dict = {'key1': 'value1', 'key2': {'key3': 'value3'}}
    my_tuple = ('yay value', 'another value')
    my_tuple_in_dict = {'key1': 'value1', 'key2': ('value3', 'value4')}

    # Test for my_list

# Generated at 2022-06-22 22:05:53.580808
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {
        u'string': u'value',
        u'integer': 1,
        u'float': 1.1,
        u'unicode': u'latin-1 \xed',
        u'list': [u'a', u'b', 1],
        u'tuple': (u'a', u'b', 1),
        u'dict': {u'a': u'a', u'b': u'b'},
        u'none': None,
        u'bytes': b'5',
    }

# Generated at 2022-06-22 22:05:57.033177
# Unit test for function to_native
def test_to_native():
    assert to_native(1) == 1
    assert to_native('1') == '1'
    assert to_native(b'a') == 'a'
    assert to_native(to_bytes(u'café')) == u'café'

# Generated at 2022-06-22 22:06:04.457891
# Unit test for function to_native
def test_to_native():
    # By default, to_native() should return unicode strings
    assert type(to_native('foo')) == text_type

    # Try a few different byte strings with various encodings and error
    # handlers
    assert to_native(b'm\xc3\xb6p', encoding='ascii') == u'm\xf6p'
    assert to_native(b'm\xc3\xb6p', encoding='ascii', errors='surrogate_or_strict') == u'm\xf6p'
    assert to_native(b'm\xc3\xb6p', encoding='ascii', errors='surrogate_or_replace') == u'm\xfffdp'
    assert to_native(b'm\xc3\xb6p', encoding='ascii', errors='surrogate_then_replace') == u

# Generated at 2022-06-22 22:06:13.562415
# Unit test for function to_bytes
def test_to_bytes():
    utf8_text = u'\u8521'
    cp1252_text = u'\x85'
    latin1_text = u'\x85'
    utf16_text = u'\u8521'
    utf32_text = u'\u8521'
    bytes_utf8 = b'\xe8\x90\xa1'
    bytes_cp1252 = b'\x85'
    bytes_latin1 = b'\x85'
    bytes_utf16 = b'\xff\xfe\x21\x85'
    bytes_utf32 = b'\xff\xfe\x00\x00\x21\x85\x00\x00'

    # when passed a string, to_bytes should decode the string using the requested encoding

# Generated at 2022-06-22 22:06:20.543500
# Unit test for function jsonify
def test_jsonify():
    # test for string
    assert jsonify("hello world") == '"hello world"'
    # test for dict with unicode string, bytes and bool
    assert jsonify(dict(a=u"hello world", b='\xa9', c=True)) == '{"a": "hello world", "c": true, "b": "\\u00a9"}'
    # test for a datetime object
    dt = datetime.datetime(2017, 1, 1, 12, 0, 0)
    assert jsonify(dt) == '"2017-01-01T12:00:00"'
    # test for a set object
    st = set(["a", "b", "c"])
    assert jsonify(st) == '["a", "c", "b"]'


# Generated at 2022-06-22 22:06:31.473429
# Unit test for function container_to_text
def test_container_to_text():
    # Test decoding of a text string
    assert '你好' == container_to_text(u'你好')
    assert '你好' == container_to_text(b'\xe4\xbd\xa0\xe5\xa5\xbd')
    assert '你好' == container_to_text(b'\xe4\xbd\xa0\xe5\xa5\xbd', 'utf-8')
    assert '你好' == container_to_text(b'\xe4\xbd\xa0\xe5\xa5\xbd', 'utf-8', 'surrogateescape')

# Generated at 2022-06-22 22:06:43.267955
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'hello world') == b'hello world'
    assert to_bytes('hello world') == b'hello world'
    assert to_bytes('«ö∑®†πø˚¬', errors='surrogateescape') == b'\xab\xf6\u2211\u00ae\u2020\xf8\u02d9\xac'
    assert to_bytes('«ö∑®†πø˚¬', errors='replace') == b'??\xe2\x88\x91\xc2\xae\xe2\x80\xa0\xc3\xb8\xcb\x9a\xc2\xac'

# Generated at 2022-06-22 22:06:55.621696
# Unit test for function container_to_text
def test_container_to_text():
    """
    test cases for function container_to_text
    """
    str_test = ['中文测试', 'foo']
    str_test_bytes = [to_bytes(i) for i in str_test]
    str_test_dict = dict(a=str_test, b=str_test)
    str_test_bytes_dict = dict(a=str_test_bytes, b=str_test_bytes)
    assert container_to_text(str_test) == str_test
    assert container_to_text(str_test_bytes) == str_test
    assert container_to_text(str_test_dict) == str_test_dict
    assert container_to_text(str_test_bytes_dict) == str_test_dict

# Generated at 2022-06-22 22:07:06.970200
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test that all container types are handled
    o = [1, 2, 3]
    assert container_to_bytes(o) == o
    o = (1, 2, 3)
    assert container_to_bytes(o) == o
    o = {'a': 1, 'b': 'c'}
    assert container_to_bytes(o) == o

    # Test that text types are converted to bytes
    o = 'string_to_convert'
    assert container_to_bytes(o) == b'string_to_convert'
    o = u'unicode_t\N{SNOWMAN}_convert'
    assert container_to_bytes(o) == b'unicode_t\xe2\x98\x83_convert'

# Generated at 2022-06-22 22:07:17.155912
# Unit test for function to_native
def test_to_native():
    def noop(*args, **kwargs):
        return args[0]

    text_type = to_text(noop, 'utf-8')
    for test in u'a', False, 42, 42.0, [u'a'], {u'a': u'b'}, set((u'a', )):
        assert test is to_native(test, kwargs={})

    for test in u'a'.encode('utf-8'), 'a', False, 42, 42.0, [u'a'], {u'a': u'b'}, set((u'a', )):
        assert test is to_native(test, kwargs={'errors': 'surrogate_or_strict'})


# Generated at 2022-06-22 22:07:26.701635
# Unit test for function container_to_text
def test_container_to_text():
    for enc in ('utf-8', 'latin-1'):
        d = json.loads('{"key": "value"}', encoding=enc)
        assert isinstance(d, dict)
        assert isinstance(next(iterkeys(d)), binary_type)
        assert isinstance(next(itervalues(d)), binary_type)

        t_d = container_to_text(d, encoding=enc)
        assert isinstance(t_d, dict)
        assert isinstance(next(iterkeys(t_d)), text_type)
        assert isinstance(next(itervalues(t_d)), text_type)

        d = json.loads('["value1", "value2"]', encoding=enc)
        assert isinstance(d, list)
        assert isinstance(d[0], binary_type)

        t

# Generated at 2022-06-22 22:07:33.448536
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text([1, 'foo', {'bar': True}]) == [1, 'foo', {'bar': True}]
    if PY3:
        data = {'a': b'foo', 'b': 'foo', 'c': [b'foo'], 'd': ('foo', 'bar'), 'e': {'f': b'foo'}}
    else:
        data = {'a': u'foo', 'b': 'foo', 'c': [u'foo'], 'd': ('foo', 'bar'), 'e': {'f': u'foo'}}
    assert container_to_text(data) == data
    if PY3:
        data = {'a': '№'}
    else:
        data = {u'a': '№'}
    assert container_

# Generated at 2022-06-22 22:07:44.136972
# Unit test for function container_to_bytes
def test_container_to_bytes():
    above_ascii = u"hi\u1234"  # <-- 3 bytes in utf-8
    byte_string = b"hi"
    byte_string += b"\xE1\x88\xB4"  # <-- surrogates escape to 3 byte
    assert to_bytes(above_ascii, encoding='utf-8', errors='surrogateescape') == byte_string

    test_dict = {above_ascii: [above_ascii]}
    assert container_to_bytes(test_dict) == {byte_string: [byte_string]}



# Generated at 2022-06-22 22:07:52.825892
# Unit test for function to_bytes
def test_to_bytes():
    from itertools import product
    from ansible.module_utils.six import binary_type as b

    def _test_to_bytes(test_string, encoding, errors, nonstring):
        try:
            expected = to_bytes(test_string, encoding, errors, nonstring)
        except TypeError:
            # If this is a nonstring error, return now.  We're going to test
            # everything against the 'strict' nonstring value
            if nonstring != 'strict':
                return True
            else:
                # If we're supposed to be strict and raise a TypeError, then this
                # is an error
                raise
        except UnicodeDecodeError:
            # If the string has invalid characters and we're told to be strict
            # then that's ok
            if errors == 'strict':
                return True

# Generated at 2022-06-22 22:07:56.000981
# Unit test for function jsonify
def test_jsonify():
    data = {'key': b'\xc2\xa9'}
    result = jsonify(data)
    assert result == u'{"key": "\\u00a9"}'
    assert isinstance(result, text_type)
    assert isinstance(data['key'], binary_type)



# Generated at 2022-06-22 22:08:03.789728
# Unit test for function to_bytes
def test_to_bytes():
    # byte strings are bytes
    assert isinstance(to_bytes(b'string'), bytes)
    assert to_bytes(b'string') == b'string'

    # text strings are bytes
    assert isinstance(to_bytes('string'), bytes)
    assert to_bytes('string') == b'string'
    assert to_bytes(u'string') == b'string'

    # text strings with non-ascii are bytes
    # utf-8 is the default encoding if none is given
    assert isinstance(to_bytes(u'ąćł'), bytes)
    assert to_bytes(u'ąćł') == b'\xc4\x85\xc4\x87\xc5\x82'
    assert to_bytes(u'ąćł', encoding='latin-1')

# Generated at 2022-06-22 22:08:15.134955
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # dict
    assert isinstance(container_to_bytes({'a':1}), dict)
    assert isinstance(container_to_bytes({u'a':1}), dict)
    assert isinstance(container_to_bytes({1:1}), dict)
    assert all(isinstance(i, bytes) for i in container_to_bytes({u'a':1}).keys())
    assert all(isinstance(i, int) for i in container_to_bytes({1:1}).keys())
    # list
    assert isinstance(container_to_bytes([1]), list)
    assert isinstance(container_to_bytes([u'a']), list)
    assert all(isinstance(i, bytes) for i in container_to_bytes([u'a']))
    # tuple

# Generated at 2022-06-22 22:08:21.885905
# Unit test for function container_to_bytes
def test_container_to_bytes():
    import unittest
    import sys
    class TestContainerToBytes(unittest.TestCase):
        class TestClass(object):
            def __repr__(self):
                return "TestClass"

# Generated at 2022-06-22 22:08:33.644599
# Unit test for function jsonify
def test_jsonify():
    # Invalid unicode encoding encountered
    data = {b'test': [b'\x80abc']}
    if PY3:
        data = container_to_text(data, encoding='utf-8', errors='strict')
    try:
        jsonify(data)
        assert False
    except UnicodeError as e:
        assert 'Invalid unicode encoding encountered' in to_native(e)

    # Container which is valid to encode
    data = {'test': [1, 'abc']}
    assert jsonify(data) == '{"test": [1, "abc"]}'

    # Old systems using old simplejson module does not support encoding keyword.
    data = {b'test': [1, b'\x80abc']}

# Generated at 2022-06-22 22:08:39.632307
# Unit test for function to_native
def test_to_native():
    def _check(obj, start_encoding, errors):
        actual_return = to_native(obj, errors=errors)
        raise_exc = False
        if errors == 'surrogate_then_replace':
            expected_text = obj.decode(start_encoding, errors='surrogateescape')
            expected_return = expected_text.decode('utf-8', 'replace')
        elif errors == 'surrogate_or_replace' and not HAS_SURROGATEESCAPE:
            expected_text = obj.decode(start_encoding, errors='replace')
            expected_return = expected_text.decode('utf-8', 'replace')
        elif errors == 'surrogate_or_strict' and not HAS_SURROGATEESCAPE:
            expected_text = obj.decode

# Generated at 2022-06-22 22:08:47.288256
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes('foo\nbar') == b"foo\nbar"
    assert container_to_bytes({'a': 'foo\nbar'}) == {b'a': b"foo\nbar"}
    assert container_to_bytes(['foo\nbar']) == [b"foo\nbar"]
    assert container_to_bytes(('foo\nbar',)) == (b"foo\nbar",)
    assert container_to_bytes(None) is None



# Generated at 2022-06-22 22:08:54.823991
# Unit test for function container_to_text
def test_container_to_text():
    # Test dict key, value types
    d = {to_bytes('key'): to_bytes('value')}

    # Should return unicode
    assert isinstance(container_to_text(d, encoding='utf-8'), dict)
    assert isinstance(container_to_text(d, encoding='utf-8')[u'key'], text_type)

    # Test dict key, dict value types
    d = {to_bytes('key'): {to_bytes('key2'): to_bytes('value')}}

    # Should return unicode
    assert isinstance(container_to_text(d, encoding='utf-8'), dict)
    assert isinstance(container_to_text(d, encoding='utf-8')[u'key'], dict)

# Generated at 2022-06-22 22:09:03.042012
# Unit test for function container_to_bytes
def test_container_to_bytes():
    '''
    Unit test for container_to_bytes.
    '''
    # test container_to_bytes on simple string
    assert container_to_bytes('foo') == b'foo'

    # test container_to_bytes on list of strings
    assert container_to_bytes(['foo', 'bar']) == [b'foo', b'bar']

    # test container_to_bytes on tuple of strings
    assert container_to_bytes(('foo', 'bar')) == (b'foo', b'bar')

    # test container_to_bytes on dict of strings
    assert container_to_bytes({'foo': 'bar'}) == {b'foo': b'bar'}

    # test container_to_bytes on list of dicts

# Generated at 2022-06-22 22:09:14.748820
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Create ASCII test str
    test_str = '{"foo": [1, "bar"], "ansible": {"awesome": "yes"}}'
    # Create Unicode test str
    test_unicode = u'{"unicode": "\u2713"}'
    # Create Unicode from utf8 test str
    test_utf8 = u"{\"utf8\": \"\u2713\"}".encode('utf8')
    # Load unicode str
    unicode_data = json.loads(test_unicode)
    # Load utf8 str
    utf8_data = json.loads(test_utf8)
    # Load ascii str
    ascii_data = json.loads(test_str)
    # Convert ascii str to unicode

# Generated at 2022-06-22 22:09:24.798550
# Unit test for function container_to_text
def test_container_to_text():
    encoding_list = ['utf-8', 'latin-1']
    errors_list = ['strict', 'surrogate_or_strict', 'surrogate_or_replace']
    for encoding in encoding_list:
        for errors in errors_list:
            text_list = [u'中', u'文']
            bytes_list = [to_bytes(text, encoding) for text in text_list]
            # Test container list type
            data_list = bytes_list
            result = container_to_text(data_list, encoding, errors)
            assert result == text_list
            # Test container tuple type
            data_tuple = (data_list[0],)
            result = container_to_text(data_tuple, encoding, errors)
            assert result == text_list[:1]
            #

# Generated at 2022-06-22 22:09:32.322326
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({'foo': 'bar'}) == {b'foo': b'bar'}
    assert container_to_bytes({u'foo': u'bar'}) == {b'foo': b'bar'}

    assert container_to_bytes({'foo': {'baz': 'qux'}}) == {b'foo': {b'baz': b'qux'}}
    assert container_to_bytes({u'foo': {u'baz': u'qux'}}) == {b'foo': {b'baz': b'qux'}}

    assert container_to_bytes([['foo', 'bar'], ['baz', 'qux']]) == [[b'foo', b'bar'], [b'baz', b'qux']]

# Generated at 2022-06-22 22:09:41.714979
# Unit test for function container_to_text
def test_container_to_text():
    """Unit test for function container_to_text"""

    # text_type  to text_type - should return same
    test_value = u"my text value"
    assert test_value == container_to_text(test_value)

    # text_type from unicode to bytes
    test_value = u"my text value"
    assert to_bytes(test_value) == container_to_bytes(test_value)

    # bytes_type from utf-8 to text_type
    test_value = u"my text value".encode('utf-8')
    assert to_text(test_value) == container_to_text(test_value)

    # bytes_type from latin-1 to text_type
    test_value = u"my text value".encode('latin-1')

# Generated at 2022-06-22 22:09:53.586246
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_dict = {'key1': 'value1', 'key2': 'value2'}
    test_list = ['key1', 'value1']
    test_tuple = ('value1', 'value2')
    test_str = 'a string'
    test_int = 123

    assert container_to_bytes(test_dict) == {b'key1': b'value1', b'key2': b'value2'}
    assert container_to_bytes(test_list) == [b'key1', b'value1']
    assert container_to_bytes(test_tuple) == (b'value1', b'value2')
    assert container_to_bytes(test_str) == b'a string'
    assert container_to_bytes(test_int) == 123



# Generated at 2022-06-22 22:10:04.550811
# Unit test for function to_native
def test_to_native():
    assert to_native(1, nonstring='simplerepr') == '1'
    assert to_native(1, nonstring='passthru') == 1
    assert to_native(1, nonstring='empty') == ''
    try:
        to_native(1, nonstring='strict')
    except TypeError:
        pass
    else:
        raise AssertionError('to_native(1, nonstring="strict") did not fail')

    # Test string conversions
    assert to_native('a') == 'a'
    assert to_native(u'a') == 'a'
    assert to_native(b'a') == 'a'
    assert to_native(b'\xe2\x98\x83', encoding='utf-8') == u'\u2603'

# Generated at 2022-06-22 22:10:16.692117
# Unit test for function container_to_bytes
def test_container_to_bytes():
    def make_container_string(container):
        if isinstance(container, (dict, list, tuple)):
            return ''.join(make_container_string(i) for i in container)
        else:
            return to_text(container)

    # If a non-container is passed in, it should be returned unchanged
    string = 'foo'
    assert string == container_to_bytes(string)
    string = 'föö'
    assert string == container_to_bytes(string)

    # If a container is passed in, unicode strings should be converted
    # to bytes
    string = 'föö'
    in_container = ('föö',)
    out_container = ('föö',)
    assert out_container == container_to_bytes(in_container)

    string = 'föö'


# Generated at 2022-06-22 22:10:28.852818
# Unit test for function container_to_text
def test_container_to_text():
    # Convert a list of strings
    assert container_to_text([u"a", b"b", u"c"]) == [u"a", u"b", u"c"]
    # Convert a list of lists of strings
    assert container_to_text([[u"a", b"b"], [u"c", u"d"]]) == [[u"a", u"b"], [u"c", u"d"]]
    # Convert lists with special characters
    assert container_to_text([u"héllo", b"world"]) == [u"héllo", u"world"]
    # Convert a set
    assert container_to_text(set([u"a", b"b", u"c"])) == [u"a", u"b", u"c"]
    # Convert a list of sets
    assert container_to

# Generated at 2022-06-22 22:10:42.249351
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == u'foo'
    # Check for possible encoding errors
    assert to_native(b'foo\xd4') == u'foo\ufffd'
    assert to_native(b'foo\xd4', errors='surrogate_then_replace') == u'foo\ufffd\ufffd'
    assert to_native(b'foo\xd4', errors='surrogate_then_replace') == u'foo\ufffd\ufffd'
    assert to_native(b'foo\xd4', errors='surrogate_or_strict') == u'foo\udcd4'
    assert to_native(b'foo\xd4', errors='surrogate_or_replace') == u'foo\ufffd'
    assert to

# Generated at 2022-06-22 22:10:54.978543
# Unit test for function to_bytes
def test_to_bytes():
    # These tests assume that the utf8 codec is the same between Python 2 and 3.
    # At the time of writing, it is.
    try:
        # Python 2
        codecs.lookup('surrogateescape')
        HAS_SURROGATEESCAPE = True
    except LookupError:
        HAS_SURROGATEESCAPE = False

    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(chr(0x89)) == b'\x89'
    assert to_bytes(u'\xff') == b'\xff'
    if PY3:
        assert to_bytes(u'\udcff') == b'\xff'

# Generated at 2022-06-22 22:11:04.615298
# Unit test for function to_native
def test_to_native():  
    # Python 2
    assert isinstance(to_native('test'), str)
    assert isinstance(to_native(u'test'), str)
    assert isinstance(to_native(to_bytes('test')), str)

    # Python 3
    assert isinstance(to_native('test'), str)
    assert isinstance(to_native(u'test'), str)
    assert isinstance(to_native(to_bytes('test')), str)
    assert isinstance(to_native(bytearray(b'test')), str)

# Generated at 2022-06-22 22:11:11.261442
# Unit test for function to_bytes
def test_to_bytes():
    """
    Test to_bytes()
    """
    # Test when passed a byte string
    assert to_bytes(b'\xff', 'ascii') == b'\xff'
    assert to_bytes(b'\xff', 'ascii', 'surrogate_or_replace') == b'\xff'
    assert to_bytes(b'\xff', 'ascii', errors='surrogate_or_replace') == b'\xff'
    assert to_bytes(b'\xff', 'ascii', nonstring='strict') == b'\xff'
    assert to_bytes(b'\xff', 'ascii', 'surrogate_or_replace', 'strict') == b'\xff'

# Generated at 2022-06-22 22:11:14.123716
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(dict(test=1)) == dict(test=1)



# Generated at 2022-06-22 22:11:24.055034
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.common._text import to_bytes, to_native, to_text
    from ansible.module_utils.six import PY2, PY3
    import sys

    # Basic sanity check that this works
    assert to_bytes('hello', nonstring='simplerepr') == b'hello'
    assert to_bytes(b'hello', nonstring='simplerepr') == b'hello'

    assert to_bytes('привет', encoding='utf-8', nonstring='simplerepr') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

# Generated at 2022-06-22 22:11:29.642477
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(u'foobar') == b'foobar'
    assert container_to_bytes({u'foo': u'bar'}) == {b'foo': b'bar'}
    assert container_to_bytes([u'foo', u'bar']) == [b'foo', b'bar']



# Generated at 2022-06-22 22:11:41.005810
# Unit test for function to_native
def test_to_native():
    assert to_native(1) == 1
    assert to_native('foo') == u('foo')
    assert to_native(u('foo')) == u('foo')
    assert to_native(to_bytes('foo')) == b('foo')
    assert to_native(to_bytes('foo'), encoding='ascii') == u('foo')
    assert to_native(to_bytes('foo'), errors='surrogate_or_replace') == u('foo')
    assert to_native(to_bytes('foo'), errors='surrogate_or_strict') == u('foo')
    assert to_native(to_bytes('foo'), errors='surrogate_then_replace') == u('foo')

# Generated at 2022-06-22 22:11:47.301451
# Unit test for function container_to_bytes