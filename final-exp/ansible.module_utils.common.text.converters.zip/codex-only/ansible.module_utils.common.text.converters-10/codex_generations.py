

# Generated at 2022-06-22 22:01:49.378983
# Unit test for function to_native
def test_to_native():
    assert 'baz' == to_native(b'baz')
    assert 'baz' == to_native(u'baz')

    # Verify encoding errors are replaced by default
    assert 'b\ufffdz' == to_native(b'b\x80z')

    # Verify decoding errors are replaced by default
    assert 'b\ufffdz' == to_native(b'b\x80z'.decode('ascii', 'surrogateescape'))

    # Verify that we can ignore encoding errors
    assert 'baz' == to_native(b'b\x80z', errors='replace')

    # Verify that we can ignore decoding errors
    assert 'baz' == to_native('b\x80z'.decode('ascii', 'surrogateescape'), errors='replace')

# Unit tests for function

# Generated at 2022-06-22 22:01:57.879682
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(u'foo') == b'foo'
    assert container_to_bytes({u'foo': u'bar'}) == {b'foo': b'bar'}
    assert container_to_bytes((u'foo',)) == (b'foo',)
    assert container_to_bytes([u'foo']) == [b'foo']
    assert container_to_bytes(5) == 5
    assert container_to_bytes(None) is None


# Generated at 2022-06-22 22:02:01.741455
# Unit test for function jsonify
def test_jsonify():
    """
    Test for function jsonify
    """
    my_data = dict(
        my_string=to_text(u"simple string"),
        my_unicode=to_text(u"\u2019")
        )
    my_jsonified = jsonify(my_data)
    assert my_jsonified == b'{"my_unicode": "\\u2019", "my_string": "simple string"}'



# Generated at 2022-06-22 22:02:14.696277
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes('string') == b'string'
    assert container_to_bytes({}) == {}
    assert container_to_bytes({'k':'v'}) == {b'k': b'v'}
    assert container_to_bytes({'k':'value'}) == {b'k': b'value'}
    assert container_to_bytes({'k':u'value'}) == {b'k': b'value'}
    assert container_to_bytes({u'k':'value'}) == {b'k': b'value'}
    assert container_to_bytes({'key':{'k':'value'}}) == {b'key': {b'k': b'value'}}
    assert container_to_bytes([]) == []

# Generated at 2022-06-22 22:02:25.351893
# Unit test for function to_bytes
def test_to_bytes():
    # pylint: disable=no-self-use
    utf8_string = to_bytes('é')
    try:
        utf8_string.decode('utf-8')
    except UnicodeDecodeError:
        self.fail('to_bytes failed to encode to UTF-8')
    # Nonprintable utf8
    utf8_bytes = b'\xc3\xbf'
    self.assertEqual(b'\xc3\xbf', to_bytes(utf8_bytes, nonstring='passthru'))
    # Non-string (like a list).  This will always return a string (and is one
    # of those cases where we return a text string on python2 and a byte string
    # on python3)

# Generated at 2022-06-22 22:02:36.531493
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Pass in a text string
    assert container_to_bytes('helloworld') == b'helloworld'
    assert isinstance(container_to_bytes('helloworld'), binary_type)

    # Pass in a tuple with a string
    assert container_to_bytes(('helloworld',)) == (b'helloworld',)
    assert isinstance(container_to_bytes(('helloworld',))[0], binary_type)

    # Pass in a list with a string
    assert container_to_bytes(['helloworld']) == [b'helloworld']
    assert isinstance(container_to_bytes(['helloworld'])[0], binary_type)

    # Pass in a dict with a string

# Generated at 2022-06-22 22:02:45.336569
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(dict(a=1)) == dict(a=1)
    assert container_to_bytes(dict(a=u'Ü')) == dict(a=b'\xc3\x9c')
    assert container_to_bytes(dict(a=[u'Ü'])) == dict(a=[b'\xc3\x9c'])
    assert container_to_bytes(dict(a=set(['Ü']))) == dict(a=[b'\xc3\x9c'])
    assert container_to_bytes(dict(a=(u'Ü',))) == dict(a=(b'\xc3\x9c',))



# Generated at 2022-06-22 22:02:49.521443
# Unit test for function jsonify
def test_jsonify():
    """
    Unit test for function jsonify
    """

    # Simple test
    data = dict(a=dict(b=u'c', d=[1,2,3]))
    data_json = jsonify(data)
    assert json.loads(data_json) == data



# Generated at 2022-06-22 22:03:01.474096
# Unit test for function jsonify
def test_jsonify():
    # jsonify sucessfull
    res = jsonify({
        "a": 1,
        "b": 2
    })
    expected_res = '{"a": 1, "b": 2}'
    assert(res == expected_res)
    # jsonify with utf-8 encoding and no encoding given.
    res = jsonify({
        "a": 1,
        "b": 2,
        "c": u'\xe9'
    })
    expected_res = '{"a": 1, "b": 2, "c": "\xc3\xa9"}'
    assert(res == expected_res)
    # jsonify with latin-1 encoding and no encoding given.
    res = jsonify({
        "a": 1,
        "b": 2,
        "c": u'abc\xe9'
    })

# Generated at 2022-06-22 22:03:13.641854
# Unit test for function jsonify
def test_jsonify():
    # Test for valid encoding 'utf-8'
    json_data = jsonify("unittest", ensure_ascii=False)
    assert(isinstance(json_data, str))

    # Test for valid encoding 'latin-1'
    encoded_data_latin_1 = "unittest".encode("latin-1")
    json_data = jsonify(encoded_data_latin_1, ensure_ascii=False)
    assert(isinstance(json_data, str))

    # Test for invalid encoding
    encoded_data_iso_8859_15 = "unittest".encode("iso-8859-15")

# Generated at 2022-06-22 22:03:16.707359
# Unit test for function container_to_text
def test_container_to_text():
    d = container_to_text(dict(foo=b'bar', bar=(b'foo', b'bar')), encoding=None)
    assert d == dict(foo=u'bar', bar=(u'foo', u'bar'))



# Generated at 2022-06-22 22:03:25.264284
# Unit test for function container_to_text
def test_container_to_text():
    # This function doesn't have a well defined return value with respect to
    # the type of containers it's given.  It's designed to be able to handle
    # any iterable that contains dicts and/or strings.  It tries to handle
    # other non-string iterables but this may not be possible if the container
    # type doesn't support iteration or doesn't support index based access.
    # Because it works differently on Python2 and Python3, the tests are split
    # into Python2 and Python3 test cases.

    # Python2
    if PY2:
        class FauxSet(object):
            def __init__(self, iterable):
                self._iterable = list(iterable)

            def __iter__(self):
                return iter(self._iterable)

        # dict

# Generated at 2022-06-22 22:03:26.891499
# Unit test for function jsonify
def test_jsonify():
    data = dict(a=u'\xe9')
    assert jsonify(data) == '{"a": "\xe9"}'

# Generated at 2022-06-22 22:03:39.920771
# Unit test for function to_native
def test_to_native():
    assert to_native('bob', 'ascii') == 'bob'
    assert to_native('bob') == 'bob'

    assert to_native('\xff') == '\xff'
    assert to_native('\xff'.encode('ascii'), 'ascii') == '\xff'

    assert to_native(b'\xc3\xb1') == '\xf1'
    assert to_native(b'\xc3\xb1'.decode('utf-8'), 'utf-8') == '\xf1'

    # This next case is interesting because surrogateescape only works for
    # unicode.  If the codec is asking for a bytestring, then we don't have
    # surrogates to encode invalid characters with.

# Generated at 2022-06-22 22:03:45.834939
# Unit test for function to_native
def test_to_native():
    expected = binary_type('hi') if PY3 else 'hi'
    assert to_native(b'hi') == expected
    assert to_native(u'hi') == expected
    assert to_native(expected) == expected
    assert to_native(expected, nonstring='passthru') == expected
    assert to_native(1) == '1'
    assert to_native(1, nonstring='passthru') == 1



# Generated at 2022-06-22 22:03:55.340609
# Unit test for function to_native
def test_to_native():
    # Run this in python 3 only
    # Test the correct type is returned and the right error is raised
    if PY3:
        obj_native_string = '\xe2\x99\xa5'
        obj_native_bytes = b'\xe2\x99\xa5'
        obj_native_bytearray = bytearray([226, 153, 165])
        obj_decode_error_bytes = b'\xff'
        obj_decode_error_bytearray = bytearray([255])
        obj_decode_error_text = u'\uffff'

        # Test native strings are returned unchanged
        assert to_native(obj_native_string) == obj_native_string

        # Test native byte strings are transformed into native strings
        # when no encoding is defined
        assert to_native

# Generated at 2022-06-22 22:04:07.625189
# Unit test for function to_bytes
def test_to_bytes():
    # All text strings should be turned into byte strings
    # Even if they are pure ascii, they should be encoded
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'

    # Error handlers should coerce text strings into byte strings
    assert to_bytes(u'fóo', 'utf-8', 'replace') == b'f\xf3o'

    # Coercing non-text strings should work if a nonstring error handler is
    # chosen
    assert to_bytes(1234, errors='strict', nonstring='simplerepr') == b'1234'
    assert to_bytes([1, 2, 3], errors='strict', nonstring='simplerepr') == b'[1, 2, 3]'

# Generated at 2022-06-22 22:04:16.929932
# Unit test for function to_bytes
def test_to_bytes():
    # Test that to_bytes works with byte strings
    assert to_bytes(b'\x80\x81\x82\x83') == b'\x80\x81\x82\x83'
    assert to_bytes(b'\x80\x81\x82\x83', nonstring='empty') == b''
    assert to_bytes(b'\x80\x81\x82\x83', nonstring='passthru') == b'\x80\x81\x82\x83'
    assert to_bytes(b'\x80\x81\x82\x83', nonstring='simplerepr') == b'\x80\x81\x82\x83'

    # Test that to_bytes works with text strings

# Generated at 2022-06-22 22:04:27.706837
# Unit test for function container_to_bytes
def test_container_to_bytes():
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import container_to_bytes


# Generated at 2022-06-22 22:04:35.317385
# Unit test for function jsonify
def test_jsonify():
    string_utf8 = \
        '{\n  "changed": false, \n  "ping": "pong"\n}\n'
    string_latin1 = \
        '{\n  "changed": false, \n  "ping": "pong"\n}\n'.decode(
            'latin-1')
    string_utf8_unicode = \
        u'{\n  "changed": false, \n  "ping": "pong"\n}\n'
    string_latin1_unicode = \
        u'{\n  "changed": false, \n  "ping": "pong"\n}\n'.encode(
            'latin-1').decode('latin-1')
    assert string_utf8 == jsonify(string_utf8_unicode)
    assert string_

# Generated at 2022-06-22 22:04:43.341039
# Unit test for function container_to_text
def test_container_to_text():
    yaml_example = '''
    list:
        - {unicode_key: 'python2'}
        - {binary_key: 'python2'}
    dict:
        unicode_key: 'python2'
        binary_key: 'python2'
    tuple:
        - {unicode_key: 'python2'}
        - {binary_key: 'python2'}
    '''


# Generated at 2022-06-22 22:04:55.211115
# Unit test for function jsonify
def test_jsonify():
    try:
        json.dumps([])
    except TypeError:
        print('Old simplejson module detected, skipping jsonify unit test')
        return
    assert(jsonify({'a': 'b'}) == '{"a": "b"}')
    assert(jsonify({'a': u'b'}) == '{"a": "b"}')
    assert(jsonify({'a': u'\xc3\x84'}) == '{"a": "\\u00c4"}')
    x = Set([3, 1, 2])
    y = {'set': [3, 1, 2]}
    assert(jsonify(x) == jsonify(y))
    x = datetime.datetime(2012, 12, 21, 12, 21)

# Generated at 2022-06-22 22:05:06.756884
# Unit test for function container_to_text
def test_container_to_text():
    data = [(1, to_bytes('b')), (2, 'c')]
    assert container_to_text(data) == [(1, 'b'), (2, 'c')]
    assert container_to_text(data, encoding='latin1') == [(1, 'b'), (2, 'c')]
    assert container_to_text(data, encoding='latin1', errors='surrogate_or_strict') == [(1, 'b'), (2, 'c')]
    assert container_to_text(data, encoding='latin1', errors='surrogate_or_replace') == [(1, 'b'), (2, 'c')]
    assert container_to_text(data, encoding='latin1', errors='strict') == [(1, 'b'), (2, 'c')]

# Generated at 2022-06-22 22:05:16.292260
# Unit test for function container_to_text
def test_container_to_text():
    from ansible.module_utils._text import to_bytes, to_text, to_native
    unicode_str = u'test'

# Generated at 2022-06-22 22:05:25.548816
# Unit test for function to_bytes
def test_to_bytes():
    # Test that to_bytes handles valid args
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin1') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='replace') == b'?'
    assert to_bytes(b'\xe1\x88\xb4', errors='surrogateescape') == b'\xe1\x88\xb4'

    # Missing surrogateescape error handler
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'?'

# Generated at 2022-06-22 22:05:38.075508
# Unit test for function jsonify
def test_jsonify():
    # setup a simpleutf8 structure
    utf8_unicode_string = u'\ubcf4\uace0'
    utf8_dict = {u'unicode_key': utf8_unicode_string}
    utf8_list = [utf8_unicode_string]
    assert jsonify(utf8_dict) == '{"unicode_key": "\\ubcf4\\uace0"}'
    assert jsonify(utf8_list) == '["\\ubcf4\\uace0"]'

    # setup an invalid utf8 structure
    # (Using '\u' prefix for an unknown character with (invalid) unicode code point 999999.)
    # This string should cause the UnicodeDecodeError.
    latin1_unicode_string = u'\ufffd\uace0'
    lat

# Generated at 2022-06-22 22:05:48.644990
# Unit test for function container_to_text
def test_container_to_text():
    class MockObj(object):

        def __unicode__(self):
            return u'unicode'

        def __str__(self):
            return 'str'

        def __repr__(self):
            return 'repr'

    class MockBytes(object):

        def __bytes__(self):
            return b'bytes'

        def __str__(self):
            return 'str'

        def __repr__(self):
            return 'repr'

    class MockStr(object):

        def __str__(self):
            return 'str'

        def __repr__(self):
            return 'repr'

    assert container_to_text('ascii', 'ascii') == u'ascii'

# Generated at 2022-06-22 22:05:58.632106
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text({'a': u'\u1234', 'b': 'abc'}) == {'a': u'\u1234', 'b': u'abc'}
    assert container_to_text({u'\u1234': 'abc', 'b': 'abc'}) == {u'\u1234': u'abc', u'b': u'abc'}
    assert container_to_text([u'\u1234', 'abc']) == [u'\u1234', u'abc']
    assert container_to_text((u'\u1234', 'abc')) == (u'\u1234', u'abc')

    # input shall not be modified
    # dict
    a = {'a': 'abc'}
    container_to_text(a)

# Generated at 2022-06-22 22:06:08.843940
# Unit test for function container_to_text
def test_container_to_text():
    if PY3:
        assert to_text('ascii', 'ascii') == 'ascii'
        assert to_text(b'ascii', 'ascii') == 'ascii'
        assert to_text(b'\xe9', 'ascii', errors='surrogate_or_strict') == '\uFFFD'
        assert to_text(b'\xe9', 'ascii', errors='surrogate_or_replace') == '?'
        assert to_text('\xe9', 'ascii', errors='surrogate_or_strict') == '\uFFFD'
        assert to_text('\xe9', 'ascii', errors='surrogate_or_replace') == '?'

# Generated at 2022-06-22 22:06:16.221397
# Unit test for function to_bytes
def test_to_bytes():
    """This function contains the tests for function :py:func:`to_bytes`."""
    assert to_bytes(b'abcd') == b'abcd'

    assert to_bytes('abcd') == b'abcd'

    # Test a string with surrogates in it
    assert to_bytes('ab\uFFFDcd') == b'ab\xef\xbf\xbdcd'

    # Test that a surrogate that can't be encoded raises an exception
    # Test that a surrogate that can't be encoded raises an exception
    # Test that a surrogate that can't be encoded raises an exception
    try:
        to_bytes('ab\udcffcd', 'latin-1')
        assert False, 'To_bytes did not error out when a surrogate was provided'
    except UnicodeEncodeError:
        pass

    # Test that an

# Generated at 2022-06-22 22:06:28.243926
# Unit test for function container_to_text
def test_container_to_text():
    # A dict with a byte key and unicode value
    d1 = {b'k1': u'v1'}
    # A list with a unicode and byte element
    d2 = [u'v1', b'v2']
    # A tuple with a mix of unicode and byte elements
    d3 = (u'v1', b'v2')
    # A dict with a unicode key, and values with a mix of unicode and byte elements

# Generated at 2022-06-22 22:06:40.573429
# Unit test for function to_native
def test_to_native():
    if PY3:
        value1 = to_bytes(u'foo', encoding='ascii')
        assert value1 == b'foo'

        value1 = to_bytes(u'fóo', encoding='ascii', errors='surrogate_or_strict')
        assert value1 == b'f\xf3o'

        try:
            value1 = to_bytes(u'fóo', encoding='ascii', errors='strict')
            raise AssertionError('unreachable')
        except UnicodeEncodeError as e:
            assert isinstance(e, UnicodeEncodeError)
            assert e.object == u'fóo'
            assert e.encoding == 'ascii'
            assert e.start == 1
            assert e.end == 2

# Generated at 2022-06-22 22:06:52.357914
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Dict
    assert container_to_bytes({'a': 1, u'b': u'2'}) == {b'a': 1, b'b': b'2'}
    assert container_to_bytes({'a': {u'b': u'2'}}) == {b'a': {b'b': b'2'}}

    # List
    assert container_to_bytes([u'1', 2]) == [b'1', 2]
    assert container_to_bytes([u'1', [3, 4]]) == [b'1', [3, 4]]
    assert container_to_bytes([{u'a': u'1'}]) == [{b'a': b'1'}]

# Generated at 2022-06-22 22:06:59.491994
# Unit test for function to_bytes

# Generated at 2022-06-22 22:07:00.260416
# Unit test for function to_native
def test_to_native():
    return True



# Generated at 2022-06-22 22:07:10.722858
# Unit test for function jsonify
def test_jsonify():
    mydict = dict(a=dict(b='foo', c=[1, 2, 3]))
    assert jsonify(mydict) == '{"a": {"c": [1, 2, 3], "b": "foo"}}'
    import datetime
    now = datetime.datetime.now()
    assert jsonify(now) == '"%s"' % now.isoformat()
    assert jsonify(Set(["1","2","3"])) == json.dumps(["1","2","3"])
    # This should error out with a UnicodeDecodeError
    try:
        jsonify(dict(a=dict(b='foo', c=b'\xff')))
        assert False, 'Should throw error'
    except UnicodeDecodeError:
        pass

# Generated at 2022-06-22 22:07:21.268189
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'hello', nonstring='passthru') == b'hello'
    assert to_bytes(u'hello') == b'hello'

    assert to_bytes(u'\u00e9') == b'\xc3\xa9'
    assert to_bytes(u'\u00e9', errors='strict') == b'\xc3\xa9'

    assert to_bytes(u'\u00e9', errors='surrogate_or_replace') == b'\xc3\xa9'
    assert to_bytes(u'\u00e9', errors='surrogate_or_strict') == b'\xc3\xa9'
    assert to_bytes(u'\u00e9', errors='surrogate_then_replace') == b'\xc3\xa9'

# Generated at 2022-06-22 22:07:29.824376
# Unit test for function container_to_text
def test_container_to_text():
    """Unit test for function container_to_text"""
    d = {u'foo':  u'bar'}
    assert container_to_text(d) == {b'foo': b'bar'}
    d = [u'foo', u'bar']
    assert container_to_text(d) == [b'foo', b'bar']
    d = [u'foo', [u'bar', [u'c', u'r']], u'moo']
    assert container_to_text(d) == [b'foo', [b'bar', [b'c', b'r']], b'moo']
    d = (u'foo', u'bar')
    assert container_to_text(d) == (b'foo', b'bar')

# Generated at 2022-06-22 22:07:42.550285
# Unit test for function jsonify
def test_jsonify():
    data = {'a': '中文', 'b': 123, 'c': [123, '中文'], 'd': {'a': '中文'}}
    assert jsonify(data) == r'{"a": "\u4e2d\u6587", "c": [123, "\u4e2d\u6587"], "b": 123, "d": {"a": "\u4e2d\u6587"}}'
    #if you want to use raw data, use kwargs `ensure_ascii=False`
    assert jsonify(data, ensure_ascii=False) == r'{"a": "中文", "c": [123, "中文"], "b": 123, "d": {"a": "中文"}}'

# Generated at 2022-06-22 22:07:52.945181
# Unit test for function to_native
def test_to_native():
    assert to_native(b'abc') == u'abc'
    assert to_native(u'abc') == u'abc'

    assert to_native(1) == u'1'
    assert to_native(1.0) == u'1.0'
    assert to_native(dict(a=1, b=2)) == u"{'a': 1, 'b': 2}"
    assert to_native(Set([1, 2, 3])) == u'{1, 2, 3}'
    assert to_native(None) == u'None'
    assert to_native(False) == u'False'
    assert to_native([1, 2, 3]) == u'[1, 2, 3]'
    assert to_native(u'\x80') == u'\x80'


# Generated at 2022-06-22 22:08:02.233462
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' unit test for container_to_bytes '''
    sample_dict = {'a': 1, 'b': [1, u'foo'], 'c': u'þor', 'd': {'e': {'f': u'þor'}}, 'e': range(10)}
    sample_dict_encoded = {'a': 1, 'b': [1, 'foo'], 'c': 'þor', 'd': {'e': {'f': 'þor'}}, 'e': range(10)}

# Generated at 2022-06-22 22:08:11.787676
# Unit test for function container_to_text
def test_container_to_text():
    b_dict = {b'a': True, b'b': [1,2,3], b'c': {b'd': False}}
    assert container_to_text(b_dict) == {u'a': True, u'b': [1,2,3], u'c': {u'd': False}}
    assert container_to_text([b'a']) == [u'a']
    assert container_to_text((b'a',)) == (u'a',)
    assert container_to_text(b'a') == u'a'
    assert container_to_text(5) == 5
    assert container_to_text(False) == False

# Generated at 2022-06-22 22:08:12.942608
# Unit test for function to_native
def test_to_native():
    assert False


# Generated at 2022-06-22 22:08:17.895633
# Unit test for function container_to_text
def test_container_to_text():
    data = [
        {
            "key1": "val1",
            "key2": "val2",
            "key3": {
                "key4": "val4"
            },
            "key5": [
                "val5"
            ],
            "key6": (
                "val6",
            )
        },
        "mine"
    ]
    display.display(container_to_text(data))

# Generated at 2022-06-22 22:08:26.192498
# Unit test for function to_native
def test_to_native():
    from types import ModuleType

    whitespace_bytes = b' \n\t\v\f\r '
    whitespace_unicode = u' \n\t\v\f\r '
    truthy_bytes = b'true'
    truthy_unicode = u'truthy'
    falsy_bytes = b'false'
    falsy_unicode = u'falsy'
    empty_bytes = b''
    empty_unicode = u''
    empty_list = []
    empty_dict = {}
    empty_set = set()
    module_type_obj = ModuleType('module')

    # Truthy tests
    assert to_native(truthy_bytes, nonstring='simplerepr') == truthy_bytes

# Generated at 2022-06-22 22:08:37.271402
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native

    assert to_native(b'\xe9', encoding='ascii', errors='surrogate_or_replace') == u'\ufffd'
    assert to_native(b'\xe9', encoding='ascii', errors='surrogate_or_strict') == u'\\xe9'
    assert to_native(b'\xe9', encoding='ascii', errors='surrogate_then_replace') == u'\ufffd'

    assert to_native(b'\xff') == u'\ufffd'
    assert to_native(b'\xff', errors='surrogate_or_replace') == u'\ufffd'

# Generated at 2022-06-22 22:08:44.242558
# Unit test for function to_native
def test_to_native():
    """Unit tests for ``to_native``"""
    import io

    for obj in True, False, None, b'True', 1, 1.5, [], {}, (), 'Test':
        # Non-text strings and binary
        assert to_native(obj) == str(obj)

        # Text strings
        if not isinstance(obj, str):
            assert to_native(to_text(obj)) == obj

    # Python3 file descriptors
    if PY3:
        assert to_native(io.StringIO('Test')) == 'Test'



# Generated at 2022-06-22 22:08:52.962919
# Unit test for function container_to_text
def test_container_to_text():
    assert json.loads(jsonify(container_to_text({b'foo': b'\xe9'}, encoding='latin-1', errors='surrogate_or_strict'))) == {u'foo': u'\xe9'}
    assert json.loads(jsonify(container_to_text({b'foo': b'\xff'}, encoding='latin-1', errors='surrogate_or_strict'))) == {u'foo': u'\ufffd'}
    assert json.loads(jsonify(container_to_text({b'foo': b'\xe9'}, encoding='latin-1', errors='surrogate_or_replace'))) == {u'foo': u'\xe9'}

# Generated at 2022-06-22 22:09:04.792976
# Unit test for function jsonify
def test_jsonify():
    data = {u'bytes': b'\xc3\xa9\xc3\xa9', u'ascii': u'ascii'}
    assert jsonify(data) == '{"ascii": "ascii", "bytes": "\\u00c3\\u00a9\\u00c3\\u00a9"}'
    data = {u'bytes': b'\xc3\xa9\xc3\xa9', u'ascii': u'ascii', b'bytes2': b'\xc3\xa9\xc3\xa9'}

# Generated at 2022-06-22 22:09:15.977884
# Unit test for function to_bytes
def test_to_bytes():
    # Test each of the error handlers using a byte string that contains a
    # byte that doesn't encode to utf8.  We'll use the byte string '\xff'
    chars = codecs.charmap_build(dict((i, to_bytes(chr(i), 'utf-8')) for i in range(256)))
    test_data = ((codecs.lookup_error('strict'), '\xff'),
                 (codecs.lookup_error('replace'), '\xef\xbf\xbd'),
                 # Will always be surrogateescape because of the HAS_SURROGATEESCAPE check
                 (codecs.lookup_error('surrogateescape'), '\xff'),
                 (None, '\xff'),
                 )

    # Test each error handler using a surrogate character

# Generated at 2022-06-22 22:09:17.369340
# Unit test for function to_native
def test_to_native():
    pass


# Generated at 2022-06-22 22:09:26.538503
# Unit test for function to_native
def test_to_native():
    # Ensure the function runs without erroring
    i = to_native(1)
    assert isinstance(i, int)
    i = to_native(u'1')
    assert isinstance(i, text_type)
    i = to_native(u'\u2019')
    assert isinstance(i, text_type)
    if PY3:
        i = to_native(b'\x80')
        assert isinstance(i, text_type)
    else:
        i = to_native(b'\x80')
        assert isinstance(i, binary_type)

    # Check the 'ascii' flag
    i = to_native('\u2019', errors='surrogate_then_replace', nonstring='strict', ascii=True)
    assert isinstance(i, text_type)

# Generated at 2022-06-22 22:09:33.627694
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.compat.tests import unittest

    class TestToBytes(unittest.TestCase):
        def test_to_bytes(self):
            self.assertEqual(to_bytes('123', errors='strict'), b'123')
            self.assertEqual(to_bytes(123, errors='surrogate_then_replace', nonstring='passthru'), 123)
            self.assertEqual(to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', errors='strict'), b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82')

# Generated at 2022-06-22 22:09:42.384805
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text([1,2,3]) == [1,2,3]
    assert container_to_text({"a": 1}) == {"a": 1}
    assert container_to_text({1: "a"}) == {1: "a"}
    assert container_to_text((1, "a")) == (1, "a")
    assert container_to_text(123) == 123
    assert container_to_text(u"1234") == u"1234"
    assert container_to_text(b"123") == u"123"
    assert container_to_text({"a": 1, b"b": 2}) == {b"a": 1, b"b": 2}

# Generated at 2022-06-22 22:09:48.905516
# Unit test for function to_native
def test_to_native():
    assert isinstance(to_native(u'a'), text_type)
    assert isinstance(to_native(b'a'), text_type)
    assert isinstance(to_native(1), text_type)
    assert isinstance(to_native(None), text_type)
    assert isinstance(to_native(object), text_type)



# Generated at 2022-06-22 22:09:56.853827
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(['a', 'b', 'c']) == '["a", "b", "c"]'

    assert jsonify(u'\u0400', encoding='utf-8') == '"\\u0400"'

    assert jsonify({'a': 'b'}) == '{"a": "b"}'

    class MyObj(object):
        def __init__(self, key):
            self.key = key

        def __str__(self):
            return "STRING"

    assert jsonify(MyObj('key')) == '"STRING"'

    assert jsonify(Set([1, 2, 3])) == '[1, 2, 3]'

    assert jsonify(datetime.datetime.fromtimestamp(0)) == '"1970-01-01T00:00:00"'


# Generated at 2022-06-22 22:10:06.227566
# Unit test for function jsonify

# Generated at 2022-06-22 22:10:12.891878
# Unit test for function to_bytes
def test_to_bytes():
    # It probably makes sense to just run the tests via to_text's test suite but
    # that can wait until later
    #
    # The basic test suite is the same as to_text's
    def tb_helper(obj, encoding='utf-8', errors=None, nonstring='simplerepr'):
        return to_bytes(obj, encoding, errors, nonstring).decode('utf-8')

    assert tb_helper(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-22 22:10:24.712008
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test with a regular dict
    d = {"a" : "a", u"b" : u"b"}
    k, v = next(iteritems(d))
    assert isinstance(k, str) and isinstance(v, str)
    d2 = container_to_bytes(d)
    k, v = next(iteritems(d2))
    assert isinstance(k, binary_type) and isinstance(v, binary_type)

    # Test with a list
    l = ["a", u"b"]
    assert isinstance(l[0], str) and isinstance(l[1], str)
    l2 = container_to_bytes(l)
    assert isinstance(l2[0], binary_type) and isinstance(l2[1], binary_type)

    # Test with a tuple

# Generated at 2022-06-22 22:10:34.583366
# Unit test for function container_to_text
def test_container_to_text():
    valid_cases = (
        ({}, dict),
        ({'key': 'value'}, dict),
        (['value1', 'value2'], list),
        (('value1', 'value2'), tuple),
    )
    for input, expected_type in valid_cases:
        assert isinstance(container_to_text(input), expected_type)

    invalid_cases = (
        {'key': b'value'},
        [b'value1', 'value2'],
        ('value1', b'value2'),
    )
    for invalid_input in invalid_cases:
        try:
            container_to_text(invalid_input)
        except UnicodeDecodeError:
            pass
        else:
            raise AssertionError("Shouldn't be able to decode %s" % str(invalid_input))

# Generated at 2022-06-22 22:10:44.906102
# Unit test for function container_to_bytes
def test_container_to_bytes():
    p = {'foo': 'bar', 'bar': 'baz', 'baz': 42, 'qux': ['quux', 'corge', 42]}
    p_ascii = {b'foo': b'bar', b'bar': b'baz', b'baz': 42, b'qux': [b'quux', b'corge', 42]}
    p_latin1 = {b'foo': b'bar', b'bar': b'baz', b'baz': 42, b'qux': [b'quux', b'corge', 42]}

    assert container_to_bytes(p) == p_ascii
    assert container_to_bytes(p, encoding='latin-1') == p_latin1

    # simple string

# Generated at 2022-06-22 22:10:51.248290
# Unit test for function container_to_text
def test_container_to_text():
    """Test for container_to_text"""
    result = container_to_text(data1)
    assert isinstance(result, dict)
    assert isinstance(result['result'], list)
    assert isinstance(result['result'][0]['bytes'], text_type)
    assert isinstance(result['result'][0]['size'], text_type)


# Generated at 2022-06-22 22:11:01.255638
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    from sys import version_info
    if version_info[0] == 2 and version_info[1] < 7:
        assert to_native(u'\u043a\u0438\u0440\u0438\u043b\u043b\u0438\u0447\u0435\u0441\u043a\u0438\u0439') == u'\u043a\u0438\u0440\u0438\u043b\u043b\u0438\u0447\u0435\u0441\u043a\u0438\u0439'

# Generated at 2022-06-22 22:11:03.798058
# Unit test for function to_bytes
def test_to_bytes():
    # This will traceback if it is a problem
    to_bytes('\udcc3', errors='surrogateescape')



# Generated at 2022-06-22 22:11:15.418267
# Unit test for function container_to_bytes
def test_container_to_bytes():
    for encoding, errors in (
        ('utf-8', 'surrogate_or_replace'),
        ('utf-8', 'surrogate_or_strict'),
        ('ascii', 'strict'),
        ('utf-8', 'replace'),
        ('utf-8', 'ignore'),
        ('utf-8', 'surrogateescape'),
        ):
        # A good, simple ascii string
        good_ascii_string = 'simple string'
        # A good unicode string

# Generated at 2022-06-22 22:11:24.850411
# Unit test for function jsonify

# Generated at 2022-06-22 22:11:37.557650
# Unit test for function jsonify
def test_jsonify():
    '''
    Set and datetime object cannot be serialized by json, if jsonify returns correct
    encoded string, it works as intended.
    '''
    data = {
        "list": ["foo", "bar"],
        "set": Set(["foo", "bar"]),
        "mapping": {
            "foo": "bar",
            "bar": "baz"
        },
        "datetime": datetime.datetime.now()
    }
    data_correct = {
        "list": ["foo", "bar"],
        "set": list(Set(["foo", "bar"])),
        "mapping": {
            "foo": "bar",
            "bar": "baz"
        },
        "datetime": datetime.datetime.now().isoformat()
    }
    assert jsonify(data)

# Generated at 2022-06-22 22:11:44.999748
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text("blah") == "blah"
    assert container_to_text("blah".encode("utf-8")) == "blah"
    assert container_to_text({'a': 'b'}) == {'a': 'b'}
    assert container_to_text({'a': 'b'.encode("utf-8")}) == {'a': 'b'}
    assert container_to_text(['a', {'b': 'c'}]) == ['a', {'b': 'c'}]
    assert container_to_text(['a', {'b': 'c'.encode("utf-8")}]) == ['a', {'b': 'c'}]