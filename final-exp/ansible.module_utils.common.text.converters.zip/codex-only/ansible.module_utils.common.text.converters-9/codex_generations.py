

# Generated at 2022-06-22 22:01:49.529268
# Unit test for function jsonify
def test_jsonify():
    d = {"a": b"b"}
    assert jsonify(d) == '{"a": "b"}'
    d = {"a": "b"}
    assert jsonify(d) == '{"a": "b"}'
    d = {"a": "b", "c": "d"}
    assert jsonify(d) == '{"a": "b", "c": "d"}'
    d = {"a": Set(["b", "c"]), "c": "d"}
    assert jsonify(d) == '{"a": ["b", "c"], "c": "d"}'
    d = {"a": {"x": "y"}, "c": "d"}
    assert jsonify(d) == '{"a": {"x": "y"}, "c": "d"}'


# Generated at 2022-06-22 22:02:01.963526
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' Unit test for function container_to_bytes'''
    test_dict = {'a': [1, 2, (3, ['4', '5'])],  # List with contents of mixed type
                 'b': b'bytes',
                 'c': u'unicode',
                 'd': {'a': b'bytes', 'b': u'unicode'}}
    ret_dict = container_to_bytes(test_dict)
    assert isinstance(ret_dict['a'][2][1][1], binary_type)
    assert isinstance(ret_dict['b'], binary_type)
    assert isinstance(ret_dict['c'], binary_type)
    assert isinstance(ret_dict['d']['a'], binary_type)

# Generated at 2022-06-22 22:02:14.977139
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Dict conversion
    d = {u'key': u'value'}
    r = container_to_bytes(d)
    assert isinstance(r, dict)
    assert isinstance(r[b'key'], binary_type)
    assert r[b'key'] == b'value'

    # List conversion
    l = [u'value']
    r = container_to_bytes(l)
    assert isinstance(r, list)
    assert isinstance(r[0], binary_type)
    assert r[0] == b'value'

    # Unicode objects should be unchanged
    r = container_to_bytes(u'value')
    assert isinstance(r, text_type)
    assert r == u'value'
    # Non-unicode objects should be unchanged

# Generated at 2022-06-22 22:02:16.349503
# Unit test for function jsonify
def test_jsonify():
    assert '["test_value"]' in jsonify({
        'test_key': 'test_value'
    })



# Generated at 2022-06-22 22:02:22.757691
# Unit test for function to_native
def test_to_native():
    # Test with different type
    string_type = "This is a string"
    assert to_native(string_type) == string_type
    # Convert to native
    n_string_type = to_native(string_type)
    assert isinstance(n_string_type, basestring)
    assert n_string_type == string_type

    # Test with int type
    int_type = 10
    assert to_native(int_type) == int_type
    # Convert to native
    n_int_type = to_native(int_type)
    assert isinstance(n_int_type, int)
    assert n_int_type == int_type

    # Test with dict
    dict_type = {'name':'Test','value':10}
    assert to_native(dict_type) == dict_type


# Generated at 2022-06-22 22:02:34.246525
# Unit test for function container_to_bytes

# Generated at 2022-06-22 22:02:42.875159
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(u'hello') == u'hello'
    assert container_to_text(b'hello') == u'hello'
    assert container_to_text(re.compile(b'hello')) == re.compile(b'hello')
    assert isinstance(container_to_text(re.compile(b'hello')), re._pattern_type)
    assert container_to_text({u'hello': b'world'}) == {u'hello': u'world'}
    assert isinstance(container_to_text({u'hello': b'world'}), dict)
    assert container_to_text([b'hello', u'world']) == [u'hello', u'world']
    assert isinstance(container_to_text([b'hello', u'world']), list)

# Generated at 2022-06-22 22:02:54.566726
# Unit test for function container_to_text
def test_container_to_text():
    a = {u'key1': 10,
         u'key2': [u'a', u'b'],
         u'key3': {u'key4': u'a'},
         u'key5': (u'a', u'b')
        }

    assert a == container_to_text(a, encoding='ascii')

    a = {'key1': 10,
         'key2': ['a', 'b'],
         'key3': {'key4': 'a'},
         'key5': ('a', 'b')
        }
    a = container_to_text(a, encoding='ascii')

    assert type(a['key1']) is text_type
    assert type(a['key2'][0]) is text_type

# Generated at 2022-06-22 22:03:06.249356
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({u'a': 1}) == {b'a': 1}
    assert container_to_bytes({u'a': [1, 2]}) == {b'a': [1, 2]}
    assert container_to_bytes({u'a': {u'b': 1, u'c': [1, 2, 3]}}) == {b'a': {b'b': 1, b'c': [1, 2, 3]}}
    assert container_to_bytes((u'a', {u'b': 1, u'c': [1, 2, 3]}, [u'1', u'2', u'3'])) == (b'a', {b'b': 1, b'c': [1, 2, 3]}, [b'1', b'2', b'3'])
    assert container

# Generated at 2022-06-22 22:03:11.776097
# Unit test for function to_native
def test_to_native():
    assert to_native(u'test') == u'test'
    assert to_native(u'\u2713') == '\xe2\x9c\x93'
    assert to_native('test') == 'test'
    assert to_native('\xe2\x9c\x93') == u'\u2713'


# Generated at 2022-06-22 22:03:23.327855
# Unit test for function container_to_text
def test_container_to_text():
    from yaml.constructor import ConstructorError
    from yaml.error import MarkedYAMLError
    from ddt import ddt, data, unpack


# Generated at 2022-06-22 22:03:32.350521
# Unit test for function to_native
def test_to_native():
    """
    :type obj
    :rtype: str
    """
    def b(value):return value.encode('utf-8')
    def u(value):return value
    def f(value):return float(value)
    def t(value):return datetime.datetime.now()
    def a(value):return [value]
    def s(value):return set([value])
    class Custom(object):
        def __repr__(self):return "Custom"

# Generated at 2022-06-22 22:03:38.836877
# Unit test for function jsonify
def test_jsonify():
    """Test jsonify function by dict data"""
    dict_data = dict(a=1, b=2, c=3, d=4)
    json_data = jsonify(dict_data)
    assert json_data == '{"a": 1, "c": 3, "b": 2, "d": 4}'


# Generated at 2022-06-22 22:03:49.179969
# Unit test for function to_bytes
def test_to_bytes():
    input_str = 'Iñtërnâtiônàlizætiøn'
    assert to_bytes(input_str) == b'I\xc3\xb1t\xc3\xbbrn\xc3\xa2ti\xc3\xb4n\xc3\xa0liz\xc3\xa6ti\xc3\xb8n'
    assert to_bytes(input_str) == input_str.encode('utf-8')

    assert to_bytes(to_bytes(input_str)) == to_bytes(input_str)
    assert to_bytes(to_bytes(input_str, errors='replace')) == to_bytes(input_str, errors='replace')
    assert to_bytes(to_bytes(input_str, errors='surrogate_or_strict')) == to_

# Generated at 2022-06-22 22:03:52.351111
# Unit test for function container_to_bytes
def test_container_to_bytes():
    x = u'abcd汉字'
    y = to_bytes(x)
    z = {u'a': 1, u'b': 2}
    zb = container_to_bytes(z)



# Generated at 2022-06-22 22:03:58.597118
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"foo": "bar"}) == '{"foo": "bar"}'
    assert jsonify({"foo": [b"bar", b"baz"]}) == '{"foo": ["bar", "baz"]}'
    assert jsonify({"foo": [u"bar", u"baz"]}) == '{"foo": ["bar", "baz"]}'



# Generated at 2022-06-22 22:04:03.769482
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # str key, str value
    d = {'a':'b'}
    # bytes key, bytes value
    d2 = container_to_bytes(d)
    assert isinstance(d2, dict)
    assert isinstance(d2.keys()[0], binary_type)
    assert isinstance(d2.values()[0], binary_type)
    # str key, list value
    d = {'a':['b', 'c']}
    # bytes key, list value list with bytes
    d2 = container_to_bytes(d)
    assert isinstance(d2, dict)
    assert isinstance(d2.keys()[0], binary_type)
    assert isinstance(d2.values()[0], list)
    assert isinstance(d2.values()[0][0], binary_type)

# Generated at 2022-06-22 22:04:09.366912
# Unit test for function container_to_bytes
def test_container_to_bytes():
    my_dict = {"ascii": b"ascii_value", u"unicode": u"unic\u00eat_value"}
    # check byte keys become byte str
    assert isinstance(container_to_bytes(my_dict)["ascii"], binary_type)
    # check unicode keys become byte str
    assert isinstance(container_to_bytes(my_dict)[u"unicode"], binary_type)
    # check values that are byte str stay byte str
    assert isinstance(container_to_bytes(my_dict)["ascii"], binary_type)
    # check values that are unicode become byte str
    assert isinstance(container_to_bytes(my_dict)[u"unicode"], binary_type)
    # check the 'value' that got encoded

# Generated at 2022-06-22 22:04:21.883679
# Unit test for function to_native
def test_to_native():
    # Test bytes type
    assert to_native(b"hello") == "hello"

    # Test text type
    assert to_native("hello") == "hello"

    # Test when nonstring='passthru'
    assert to_native("hello", nonstring='passthru') == "hello"

    # Test when nonstring='empty'
    assert to_native("hello", nonstring='empty') == ""

    # Test when PY3 and nonstring='strict'
    if PY3:
        try:
            # This should fail when PY3 and nonstring='strict'
            to_native("hello", nonstring='strict')
        except TypeError:
            pass
        else:
            # The above statement should raise TypeError
            assert False, "Failed to raise TypeError!"

    # Test when PY2 and

# Generated at 2022-06-22 22:04:33.658147
# Unit test for function to_bytes
def test_to_bytes():
    '''Unit test for function to_bytes.'''
    import ansible.module_utils.basic
    assert ansible.module_utils.basic.to_bytes('abc') == b'abc'
    assert ansible.module_utils.basic.to_bytes(u'abc') == b'abc'
    assert ansible.module_utils.basic.to_bytes(b'abc') == b'abc'
    assert ansible.module_utils.basic.to_bytes(b'\xff') == b'\xff'

    assert ansible.module_utils.basic.to_bytes(bytearray(b'abc')) == b'abc'
    assert ansible.module_utils.basic.to_bytes(memoryview(b'abc')) == b'abc'

    import array

# Generated at 2022-06-22 22:04:38.710427
# Unit test for function jsonify
def test_jsonify():
    import key_json_test
    for item in key_json_test.data:
        if 'res' in item:
            assert jsonify(item['data']) == item['res']
        else:
            assert jsonify(item['data']) == json.dumps(item['data'])
# end of test_jsonify



# Generated at 2022-06-22 22:04:51.317439
# Unit test for function to_native
def test_to_native():
    '''
    Test conversion of strings to native
    '''
    assert to_native(u'') == ''
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(b'foo\xe4\xb8\x96bar') == u'foo\u4e16bar'
    assert to_native(b'foo\xc3\xa4\xc2\xb8\xc2\x96bar') == u'foo\xe4\xb8\x96bar'
    assert to_native(u'foo\xe4\xb8\x96bar') == u'foo\xe4\xb8\x96bar'
    assert to_native(u'foo\u4e16bar') == u'foo\u4e16bar'


# Generated at 2022-06-22 22:05:00.647550
# Unit test for function jsonify
def test_jsonify():

    # testing for utf-8 and latin-1 encodings
    assert jsonify('\xc8\xa7') != jsonify('\xc8\xa7'.decode('utf-8'))
    assert jsonify('\xc8\xa7') == jsonify('\xc8\xa7'.decode('latin-1'))

    # testing for dict, list and set
    assert jsonify({'a': '\xc8\xa7'}) == '{"a": "\\u00c8\\u00a7"}'
    assert jsonify(['a', '\xc8\xa7']) == '["a", "\\u00c8\\u00a7"]'
    assert jsonify({'a', '\xc8\xa7'}) == '["\\u00c8\\u00a7", "a"]'

# Generated at 2022-06-22 22:05:11.541241
# Unit test for function container_to_bytes
def test_container_to_bytes():
    '''
    unit test for function container_to_bytes
    '''

# Generated at 2022-06-22 22:05:17.510777
# Unit test for function container_to_bytes
def test_container_to_bytes():
    dict_str = {'abc': 123, 'key': u'\u6c49\u5b57'}
    dict_bytes = {b'abc': b'123', b'key': b'\xe6\xb1\x89\xe5\xad\x97'}
    assert container_to_bytes(dict_str) == dict_bytes


# Generated at 2022-06-22 22:05:28.655373
# Unit test for function container_to_text
def test_container_to_text():
    assert type(container_to_text([1, 2])) == list, 'List should be returned as is'
    assert type(container_to_text((1, 2))) == tuple, 'Tuple should be returned as is'
    assert type(container_to_text({'one': 1, 'two': 2})) == dict, 'Dict should be returned as is'
    assert type(container_to_text("abc")) == unicode, 'String should be converted to unicode'
    assert type(container_to_text(u"abc")) == unicode, 'Unicode string should be returned as is'
    assert type(container_to_text("abc", encoding='latin-1')) == unicode, 'String should be converted to unicode'

# Generated at 2022-06-22 22:05:40.063765
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({u'a': u'a'}) == '{"a": "a"}'
    assert jsonify(u'a') == '"a"'
    assert jsonify(1) == '1'
    assert jsonify(1.1) == '1.1'
    assert jsonify(True) == 'true'
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'
    assert jsonify(set([1, 2, 3])) == '[1, 2, 3]'
    assert jsonify({u'a': u'a', u'c': u'c', u'b': u'b'}) == '{"a": "a", "c": "c", "b": "b"}'
    assert jsonify({}) == '{}'
    assert jsonify(None) == 'null'



# Generated at 2022-06-22 22:05:50.419394
# Unit test for function container_to_text
def test_container_to_text():
    # None
    assert container_to_text(None) == None
    # Boolean
    assert container_to_text(True) == True
    assert container_to_text(False) == False
    # int
    assert container_to_text(123) == 123
    # float
    assert container_to_text(3.4) == 3.4
    # list
    assert container_to_text(['1',2,3]) == [u'1',2,3]
    # dict
    assert container_to_text({'1':'2'}) == {u'1':u'2'}
    # unicode
    assert container_to_text(u'项目') == u'项目'
    # byte

# Generated at 2022-06-22 22:05:59.301379
# Unit test for function to_native
def test_to_native():
    type_tests = [
        ([], u'[]'),
        (['abcd'], u'[u\'abcd\']'),
        ({}, u'{}'),
        #(set(), u'{}'),
        ({'foo': 'bar'}, u"{u'foo': u'bar'}"),
        (u'abcd', u'abcd'),
        (b'abcd', u'abcd'),
        (2, u'2'),
        (2.0, u'2.0'),
        (None, u'None'),
        (float('nan'), u'NaN'),
        (float('inf'), u'inf'),
        (float('-inf'), u'-inf'),
    ]

    for (input_, output) in type_tests:
        res = to_native(input_)
        assert res

# Generated at 2022-06-22 22:06:09.443881
# Unit test for function container_to_text
def test_container_to_text():
    case1 = {'a': 'x', 'b': 'y'}
    case2 = {'a': u'\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e', 'b': 'y'}
    case3 = {'a': 'x', 'b': [u'\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e', '\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e'.decode('utf-8')]}

# Generated at 2022-06-22 22:06:14.513788
# Unit test for function jsonify
def test_jsonify():
    import ansible_collections.ansible.community.plugins.module_utils.jsonify as jsonify_mod

    assert(jsonify_mod.jsonify([1, 2, 3]) == '[1, 2, 3]')
    assert(jsonify_mod.jsonify({'a':[1, 2, 3]}) == '{"a": [1, 2, 3]}')
    assert(jsonify_mod.jsonify({'a': b'foo'}) == '{"a": "foo"}')



# Generated at 2022-06-22 22:06:26.929779
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(b'foo', nonstring='strict') == b'foo'
    assert to_bytes(b'foo', nonstring='empty') == b''
    assert to_bytes(b'foo', nonstring='passthru') == b'foo'
    assert to_bytes(b'foo', nonstring='simplerepr') == b"'foo'"

    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_then_replace') == b'foo'
    assert to_bytes(u'foo', errors='strict') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_strict') == b'foo'


# Generated at 2022-06-22 22:06:38.064979
# Unit test for function jsonify
def test_jsonify():
    # Create a dict with unicode characters
    test_dict = dict()
    test_dict[u"\u2665"] = u"\u2665"
    test_dict['foo'] = 'bar'
    jsonified_dict = jsonify(test_dict)
    assert jsonified_dict == '{"foo": "bar", "\\u2665": "\\u2665"}'
    test_list = list()
    test_list.append(u"\u2665")
    test_list.append(u"\u2665")
    jsonified_list = jsonify(test_list)
    assert jsonified_list == '["\\u2665", "\\u2665"]'


####################################
#  DEPRECATED
####################################


# Generated at 2022-06-22 22:06:47.584632
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils._text import to_bytes

    ascii_val = b'ascii'
    ascii_str = 'ascii'
    unicode_val = b'\xc3\xa1scii'
    unicode_str = '\xe1scii'

    e = 'ascii'
    if PY3:
        e = 'backslashreplace'

    # input is bytestring
    # - ascii should stay ascii
    # - non-ascii should stay non-ascii
    assert to_bytes(ascii_val) == ascii_val
    assert to_bytes(unicode_val) == unicode_val

    # input is unicode text
    # - ascii text should be returned as byte string
    # - non-

# Generated at 2022-06-22 22:06:59.235525
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(1) == 1
    assert container_to_text(u'unicode') == u'unicode'
    assert container_to_text('ascii') == u'ascii'
    assert container_to_text(b'bytes') == u'bytes'
    assert container_to_text([1, b'bytes', u'unicode']) == [1, u'bytes', u'unicode']
    assert container_to_text((1, b'bytes', u'unicode')) == (1, u'bytes', u'unicode')
    assert container_to_text({'key1': 1, 'key2': b'bytes', 'key3': u'unicode'}) == {'key1': 1, 'key2': u'bytes', 'key3': u'unicode'}
   

# Generated at 2022-06-22 22:07:09.869811
# Unit test for function container_to_text
def test_container_to_text():
    test_dict = {"a": "1", "b": [1, 2], "c": ("1", "2", 3), "d": u"台北"}
    dict2 = container_to_text(test_dict)

    assert dict2 == {"a": "1", "b": [1, 2], "c": ("1", "2", 3), "d": u"台北"}

    assert isinstance(dict2["a"], text_type)
    assert isinstance(dict2["b"], list)
    assert isinstance(dict2["c"], tuple)
    assert all((isinstance(x, text_type) for x in dict2["b"]))
    assert all((isinstance(x, text_type) for x in dict2["c"]))



# Generated at 2022-06-22 22:07:20.752394
# Unit test for function container_to_text
def test_container_to_text():

    # to_text() needs encoding to convert a binary type to text type,
    # so here we test with a random encoding
    encoding = 'utf-8'

    # Test when input is a dict
    # 1) keys and values in both binary and text
    dict_with_keys_and_values_in_binary_and_text = {
        b'key1': 'value1',
        b'key2': b'value2',
        'key3': b'value3',
        'key4': 'value4',
        b'key5': {
            'key6': b'value5',
        },
        b'key7': [
            b'value6',
            'value7',
        ],
    }

# Generated at 2022-06-22 22:07:27.149927
# Unit test for function to_native
def test_to_native():
    assert to_native('foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(1) == 1
    assert to_native(['foo']) == ['foo']
    assert to_native({'foo': 'bar'}) == {'foo': 'bar'}
    assert to_native(Set(['foo', 'bar'])) == Set(['foo', 'bar'])

    now = datetime.datetime.now()
    assert to_native({'foo': now}) == {'foo': now}



# Generated at 2022-06-22 22:07:35.591197
# Unit test for function container_to_text
def test_container_to_text():
    r = to_text(container_to_text(dict(key1='value1', key2='value2')))
    assert r['key1'] == 'value1'
    assert r['key2'] == 'value2'
    r = to_text(container_to_text(dict(key1=dict(key2='value2'))))
    assert r['key1']['key2'] == 'value2'
    r = to_text(container_to_text(dict(key1='value1', key2=('value2', 'value3'))))
    assert r['key1'] == 'value1'
    assert r['key2'][0] == 'value2'
    assert r['key2'][1] == 'value3'

# Generated at 2022-06-22 22:07:47.607800
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.six import binary_type, PY3, text_type
    assert isinstance(to_bytes('hello'), binary_type)
    assert isinstance(to_bytes(b'hello'), binary_type)
    assert isinstance(to_bytes(u'\u1234'), binary_type)

    # Python3 str type is unicode
    if PY3:
        assert isinstance(to_bytes('hello', nonstring='passthru'), str)
    else:
        assert isinstance(to_bytes('hello', nonstring='passthru'), text_type)

    assert isinstance(b'hello', binary_type)
    assert isinstance(u'hello', text_type)

    # Python3 bytes type is the same as str

# Generated at 2022-06-22 22:07:52.732096
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({1: 1}) == '{"1": 1}'
    assert jsonify({1: [1, 2, 3]}) == '{"1": [1, 2, 3]}'
    assert jsonify({1: to_bytes(b'\xc3\xb6')}) == '{"1": "\\u00f6"}'
    assert jsonify({1: to_text(b'\xc3\xb6')}) == '{"1": "\\u00f6"}'



# Generated at 2022-06-22 22:08:02.077054
# Unit test for function to_native
def test_to_native():
    # Basic tests
    assert to_native(1) == '1'
    assert to_native(1.1) == '1.1'
    assert to_native(True) == 'True'
    assert to_native(set([1, 2])) == 'set([1, 2])'

    # Tests for str(x)
    assert to_native(u'\u1234') == u'\u1234'
    assert to_native(b'\xe4\xbd\xa0\xe5\xa5\xbd') == '\xe4\xbd\xa0\xe5\xa5\xbd'
    assert to_native(None) == 'None'

    # Tests for unicode(x)
    assert to_native(b'abc') == u'abc'

# Generated at 2022-06-22 22:08:13.178846
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(['foo', [u'bar', 'baz']], encoding='utf-8', errors='surrogateescape') == [b'foo', [u'bar', b'baz']]
    assert container_to_bytes({'foo': 'bar', 'bam': [1, 2, 3]}, encoding='utf-8', errors='surrogateescape') == {b'foo': b'bar', b'bam': [1, 2, 3]}
    assert container_to_bytes(('foo', 'bar'), encoding='utf-8', errors='surrogateescape') == (b'foo', b'bar')
    assert container_to_bytes(u'foo', encoding='utf-8', errors='surrogateescape') == b'foo'

# Generated at 2022-06-22 22:08:22.602006
# Unit test for function to_bytes

# Generated at 2022-06-22 22:08:34.348796
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test unicode -> byte string
    assert container_to_bytes('test') == b'test'
    assert container_to_bytes('string with unicode: \xe9') == b'string with unicode: \xc3\xa9'
    assert container_to_bytes(u'\xe9') == b'\xc3\xa9'
    # Test with list
    assert container_to_bytes([u'\xe9']) == [b'\xc3\xa9']
    assert container_to_bytes([u'\xe9', 'test', [u'test2']]) == [b'\xc3\xa9', b'test', [b'test2']]
    # Test with tuple

# Generated at 2022-06-22 22:08:39.718268
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = dict(a=dict(b='c'))
    result = container_to_bytes(d)
    assert isinstance(result['a']['b'], binary_type)
    result = container_to_bytes(d, encoding='latin-1', errors='surrogate_or_replace')
    assert isinstance(result['a']['b'], binary_type)


# Generated at 2022-06-22 22:08:45.889868
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', u'c': u'd'}
    jsonified_data = jsonify(data)
    assert jsonified_data == b'{"a": "b", "c": "d"}'

    data = {u'c': u'd'}
    jsonified_data = jsonify(data)
    assert jsonified_data == b'{"c": "d"}'

    data = {'a': 'b'}
    jsonified_data = jsonify(data)
    assert jsonified_data == b'{"a": "b"}'



# Generated at 2022-06-22 22:08:50.628184
# Unit test for function jsonify
def test_jsonify():

    test_data = dict(
        a=to_bytes(u'unicode_str'),
        b=dict(b1='test'),
        c=list([u'one', to_bytes(u'two'), 3]),
        d=True,
        e=1,
        f='junk1'
    )

    test_data_encoded = b'{"a": "unicode_str", "b": {"b1": "test"}, "c": ["one", "two", 3], "d": true, "e": 1}'
    assert jsonify(test_data) == test_data_encoded

    test_data_decoded = jsonify(test_data)
    assert isinstance(test_data_decoded, str)



# Generated at 2022-06-22 22:08:56.369333
# Unit test for function container_to_text
def test_container_to_text():
    # Define the following variables for this test
    data_dict = {}
    data_list = []
    data_tuple = ()
    data_dict_unicode = {}
    data_list_unicode = []
    data_tuple_unicode = ()

    # Generate unicode characters for this test
    data_dict_unicode['ascii'] = dict(a=1, b=2, c=3)
    data_dict_unicode['unicode_a'] = dict(a=u'\u039a', b=u'\u0394', c=u'\u03a9')
    data_dict_unicode['unicode_b'] = dict(a=u'\u00e9', b=u'\u00e8', c=u'\u00e0')
    data_

# Generated at 2022-06-22 22:09:07.354954
# Unit test for function container_to_text

# Generated at 2022-06-22 22:09:08.084846
# Unit test for function to_native
def test_to_native():
    pass



# Generated at 2022-06-22 22:09:14.336219
# Unit test for function to_native
def test_to_native():
    # pylint: disable=unused-import,unused-variable,import-error
    from ansible.module_utils import basic

    if PY3:
        # On py3, we want to test all the non-default error handlers, and the default error handler
        # which is surrogate_then_replace
        assert to_bytes(u'\udce5', errors='ignore') == b''
        assert to_bytes(u'\udce5', errors='replace') == b'?'
        assert to_bytes(u'\udce5', errors='surrogate_or_replace') == b'\xed\xb3\xa5'
        assert to_bytes(u'\udce5', errors='surrogate_or_strict') == b'\xed\xb3\xa5'

# Generated at 2022-06-22 22:09:24.711474
# Unit test for function container_to_text
def test_container_to_text():
    # Test the function on all possible container types
    assert container_to_text('ascii') == u'ascii'
    assert container_to_text(b'ascii') == u'ascii'

    assert container_to_text(u'unicode') == u'unicode'
    assert container_to_text(b'unicode') == u'unicode'

    x = b'\xc3\xa9'  # Two byte unicode character
    assert container_to_text(x) == u'\xe9'

    x = '\xe9'  # One byte unicode character
    assert container_to_text(x) == u'\xe9'
    x = b'\xe9'  # One byte unicode character
    assert container_to_text(x) == u'\xe9'

# Generated at 2022-06-22 22:09:29.277143
# Unit test for function to_native
def test_to_native():
    """to_native should return a str in both py2 and py3"""
    assert isinstance(to_native(b'bytes'), str)
    assert isinstance(to_native(u'unicode'), str)


_to_text = to_text
_to_bytes = to_bytes



# Generated at 2022-06-22 22:09:40.407370
# Unit test for function container_to_bytes

# Generated at 2022-06-22 22:09:47.082332
# Unit test for function container_to_text
def test_container_to_text():
    '''Function to test container_to_text function by comparing the expected output
    with expected output of the function and assert accordingly.
    '''
    assert container_to_text({}, encoding='utf-8') == {}
    assert container_to_text({'str': 'text'}, encoding='utf-8') == {'str': 'text'}
    assert container_to_text({'str': 'text', 'bstr': b'btext'}, encoding='utf-8') == {'str': 'text', 'bstr': 'btext'}
    assert container_to_text({'str': 'text', 'bstr': b'btext', 'num': 20, 'bool': True}, encoding='utf-8') == {'str': 'text', 'bstr': 'btext', 'num': 20, 'bool': True}

# Generated at 2022-06-22 22:09:55.719124
# Unit test for function container_to_text
def test_container_to_text():
    from ansible.module_utils._text import to_text
    to_text('foo')
    to_text(u'foo') 

    with pytest.raises(TypeError) as error:
        to_text(42)

    assert str(error.value).startswith("obj must be a string type")

    assert to_text({"foo": "foo"}) == {"foo": u"foo"}
    assert to_text([b"foo", "bar", 42]) == [u"foo", u"bar", u"42"]
    assert to_text((b"foo", "bar", 42)) == (u"foo", u"bar", u"42")


# Generated at 2022-06-22 22:10:04.958996
# Unit test for function to_bytes
def test_to_bytes():
    import sys
    import unittest

    class TestToBytes(unittest.TestCase):
        def test_to_bytes(self):
            if PY3:
                unicode_type = str
                bytes_type = bytes
            else:
                unicode_type = unicode
                bytes_type = str

            self.assertTrue(isinstance(to_bytes(b'ascii'), bytes))
            self.assertTrue(isinstance(to_bytes(u'unicode'), bytes))

            # Nonstring with strategy 'simplerepr'
            self.assertEqual(to_bytes(123, nonstring='simplerepr'), b'123')

            # Nonstring with strategy 'passthru'
            self.assertEqual(to_bytes(123, nonstring='passthru'), 123)

            # Nonstring with strategy '

# Generated at 2022-06-22 22:10:07.339089
# Unit test for function to_bytes
def test_to_bytes():
    # We don't actually test this function since it's just a wrapper for
    # a couple of text_type/binary_type.encode calls.  That's tested in the
    # python stdlib.
    pass



# Generated at 2022-06-22 22:10:19.657444
# Unit test for function container_to_text
def test_container_to_text():
    b = {
        "key": b"\xe8"  # 'è' encoded as latin-1 in byte str
    }
    assert "key" in container_to_text(b)
    assert "\xe8" not in container_to_text(b)
    assert "\xe8" in container_to_text(b).values()[0]

    b = {
        "key": b"\xe8"  # 'è' encoded as latin-1 in byte str
    }
    assert "key" in container_to_text(b)
    assert u'è' in container_to_text(b).values()[0]

    b = [b"\xe8"]  # 'è' encoded as latin-1 in byte str
    assert "\xe8" not in container_to_text(b)

# Generated at 2022-06-22 22:10:27.392220
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes(u'\xe9') == b'\xc3\xa9'
    assert to_bytes(u'\xe9', 'latin-1') == b'\xe9'
    assert to_bytes(u'\udce2\udce8', 'latin-1', 'surrogate_or_replace') == b'?'
    assert to_bytes(u'\udce2\udce8', 'latin-1') == b'\xed\xb3\xa2\xed\xb3\xa8'
    assert to_bytes(u'\udce2\udce8', 'latin-1', 'surrogate_or_strict') == b'?'

# Generated at 2022-06-22 22:10:35.947806
# Unit test for function jsonify
def test_jsonify():
    test_dict = {
        'a': u'\u7f16\u7801',
        'b': [1, 2, 3],
        'c': 3.14,
        'd': "testline",
        'e': {"key1": "value1"},
    }
    test_json = jsonify(test_dict)
    assert isinstance(test_json, string_types)


# Generated at 2022-06-22 22:10:45.431611
# Unit test for function container_to_text
def test_container_to_text():
    r = container_to_text({u'foo' : [u'bar']})
    assert(r[u'foo'][0] == u'bar')

    r = container_to_text({u'foo' : [(u'bar', 'baz')]})
    assert(r[u'foo'][0][0] == u'bar')
    assert(r[u'foo'][0][1] == u'baz')

    r = container_to_text({u'foo' : {'bar' : 'baz'}})
    assert(r[u'foo'][u'bar'] == u'baz')

    r = container_to_text([u'foo' , u'bar'])
    assert(r[0] == u'foo')
    assert(r[1] == u'bar')



# Generated at 2022-06-22 22:10:57.237966
# Unit test for function container_to_text
def test_container_to_text():
    test_dict = {b'key0': 'value0', b'key1': [1, 2, 3], 'key2': ('key0', 'key1'), b'key3': {b'key0': 'val0', 'key1': 'val1'}}
    # Check normal case
    expect = {u'key0': u'value0', u'key1': [1, 2, 3], u'key2': (u'key0', u'key1'), u'key3': {u'key0': u'val0', u'key1': u'val1'}}
    assert container_to_text(test_dict) == expect
    # Check non-utf8 case

# Generated at 2022-06-22 22:11:09.353985
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test basic types: True, False, None, etc.
    assert container_to_bytes(True) is True
    assert container_to_bytes(False) is False
    assert container_to_bytes(None) is None
    assert container_to_bytes(1) == 1

# Generated at 2022-06-22 22:11:20.633031
# Unit test for function jsonify
def test_jsonify():
    data = {
        "text": b'\x80abc',
        "list": [b'\xe6\x88\x91\xe4\xbb\xac'],
        "dict": {
            b'\xe4\xb8\xad\xe6\x96\x87': b'\xe4\xb8\xad\xe6\x96\x87'
        },
        "hostvars": {
            "abc": {
                "text": b'\xe5\x93\x88\xe5\x93\x88'
            }
        }
    }

# Generated at 2022-06-22 22:11:33.684972
# Unit test for function container_to_text
def test_container_to_text():
    test_str = "hello, world"
    test_unicode = "ni hao"
    test_str_encoded = test_str.encode('utf-8').decode('utf-8')
    test_unicode_encoded = test_unicode.encode('utf-8').decode('utf-8')

    # test_list1 = [test_str, test_unicode, test_str_encoded, test_unicode_encoded]
    # test_list1_result = container_to_text(test_list1)
    def _test_list_container(obj, expected_result):
        obj_converted = container_to_text(obj)
        assert len(obj) == len(expected_result)

# Generated at 2022-06-22 22:11:38.672683
# Unit test for function to_bytes
def test_to_bytes():
    class Foo(text_type):
        pass

    class Bar(binary_type):
        pass

    class Baz(Foo, Bar):
        pass

    # Objects that look like strings
    assert to_bytes(Foo('hello')) == b'hello'
    assert to_bytes(Bar(b'hello')) == b'hello'
    assert to_bytes(Baz('world')) == b'world'

    # Non-strings
    assert to_bytes(42) == b'42'
    assert to_bytes(42, nonstring='passthru') == 42
    assert to_bytes(42, nonstring='empty') == b''
    try:
        to_bytes(42, nonstring='strict')
        raise AssertionError('Did not receive a TypeError')
    except TypeError:
        pass

    #

# Generated at 2022-06-22 22:11:43.823021
# Unit test for function to_bytes
def test_to_bytes():
    #print(type(b'\xc3\xb8'.decode('utf-8', 'surrogateescape')))
    #print(type(b'\xc3\xb8'.decode('utf-8', 'surrogateescape').encode('latin-1')))
    print(type(to_bytes(b'\xc3\xb8'.decode('utf-8', 'surrogateescape'), encoding='latin-1', errors='surrogate_then_replace')))

