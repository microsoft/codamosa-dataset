

# Generated at 2022-06-22 22:01:49.552170
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {u'message': u'test \u2665', 'bad_type': None, u'inner': {u'inner_message': u'inner_test \u2665'}}
    d = container_to_bytes(d)
    assert(d == {b'message': b'test \xe2\x99\xa5', 'bad_type': None, b'inner': {b'inner_message': b'inner_test \xe2\x99\xa5'}})
    # Test that a simple string converts too
    assert(container_to_bytes(u'Hi!') == b'Hi!')
    # Test that ints, etc. don't break
    assert(container_to_bytes(1) == 1)
    # Test that an empty container works
    assert(container_to_bytes([]) == [])


# Generated at 2022-06-22 22:02:01.963905
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'this is a byte string') == b'this is a byte string'
    assert to_bytes('this is a unicode string') == b'this is a unicode string'
    import sys
    if sys.version_info < (3, 6):
        # Work around bug in python3.5. See https://github.com/ansible/ansible/issues/63911
        assert to_bytes('this is a\u2713 unicode string', errors='surrogate_then_replace') == b'this is a\xe2\x9c\x93 unicode string'
    assert to_bytes(b'this is an invalid utf-8 byte string', encoding='utf-8', errors='strict') == b'this is an invalid utf-8 byte string'

# Generated at 2022-06-22 22:02:15.017808
# Unit test for function container_to_text
def test_container_to_text():
    # Test text type
    data = 'my text'
    assert data == container_to_text(data)

    # Test dict type and keys
    data = {u('key'): 'value'}
    assert to_text(u('key')) == container_to_text(data).keys()[0]
    assert to_text('value') == container_to_text(data).values()[0]

    # Test list type
    data = [u('item1'), u('item2')]
    assert to_text(u('item1')) == container_to_text(data)[0]
    assert to_text(u('item2')) == container_to_text(data)[1]

    # Test tuple type
    data = (u('item1'), u('item2'))

# Generated at 2022-06-22 22:02:25.498441
# Unit test for function to_bytes
def test_to_bytes():
    """Make sure that to_bytes does the right thing"""
    assert to_bytes('foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes('питон') == b'\xd0\xbf\xd0\xb8\xd1\x82\xd0\xbe\xd0\xbd'  # utf-8
    assert to_bytes('ä') == b'\xc3\xa4'  # utf-8
    assert to_bytes('ä', encoding='latin-1') == b'\xe4'

    assert to_bytes('питон', encoding='ascii', nonstring='passthru') == 'питон'  # NOQA

# Generated at 2022-06-22 22:02:34.557356
# Unit test for function to_bytes
def test_to_bytes():
    assert isinstance(to_bytes(b'foo'), binary_type)
    assert isinstance(to_bytes(b'bar'), binary_type)
    assert isinstance(to_bytes('bar'), binary_type)
    assert isinstance(to_bytes(u'bar'), binary_type)
    assert isinstance(to_bytes(1), binary_type)
    assert isinstance(to_bytes(1, nonstring='passthru'), int)
    assert to_bytes(b'bar') == b'bar'
    assert to_bytes('bar') == b'bar'
    assert to_bytes(u'bar') == b'bar'



# Generated at 2022-06-22 22:02:43.060559
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    assert to_native(u'abc', errors='surrogate_or_strict') == u'abc'
    assert to_native(u'abc') == u'abc'
    assert to_native(b'abc', errors='surrogate_or_strict') == u'abc'
    assert to_native(b'abc') == u'abc'
    assert to_native(b'\x80') == u'\ufffd'
    assert to_native(b'\x80', errors='surrogate_or_strict') == u'\ufffd'
    assert to_native(b'\x80', errors='surrogate_then_replace') == u'\ufffd'

# Generated at 2022-06-22 22:02:54.615766
# Unit test for function to_bytes
def test_to_bytes():
    # Check that a byte string is unchanged
    assert to_bytes(b'\xfc') == b'\xfc'

    # Check that a normal text string is encoded properly
    assert to_bytes('\xfc') == b'\xfc'

    # Check that surrogates are encoded properly
    assert to_bytes('\udce4\udceb') == b'\xfc\xeb'

    # Check that surrogates are encoded with surrogateescape
    assert to_bytes('\udce4\udceb', errors='surrogateescape') == b'\xed\xb3\xa4\xed\xb3\xab'

    # Check that surrogates are encoded with surrogateescape when surrogate_or_strict is the original_errors

# Generated at 2022-06-22 22:03:03.880649
# Unit test for function to_native
def test_to_native():
    result = to_native('this is a string')
    assert result == 'this is a string'
    result = to_native(b'this is a bytestring')
    assert result == 'this is a bytestring'
    result = to_native({'this': 'dict'})
    assert result == "{'this': 'dict'}"
    result = to_native(['this', 'list'])
    assert result == "['this', 'list']"
    result = to_native(('this', 'tuple'))
    assert result == "('this', 'tuple')"



# Generated at 2022-06-22 22:03:09.112721
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_bytes

    assert isinstance(to_native(5), text_type)
    assert isinstance(to_native(5, nonstring='passthru'), int)

    # we allow to native convert bytes-like input
    assert isinstance(to_native(to_bytes(u'string')), text_type)

    # but make sure it's not residual data sticking around
    assert isinstance(to_native(u'string'), text_type)
    assert isinstance(to_bytes(u'string'), binary_type)



# Generated at 2022-06-22 22:03:19.265937
# Unit test for function to_native
def test_to_native():
    codecs.register_error('test', lambda e: (u'', e.start + 1))
    codecs.register_error('test_raise', lambda e: (u'', e.start + 1), True)

    assert to_text(u'foo') == 'foo'
    assert to_text(b'foo') == 'foo'
    assert to_text(123) == '123'

    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(123) == '123'

    assert to_text(b'\xff', errors='test') == '\udcff'
    assert to_text(b'\xff', errors='test_raise') == u'\ufffd'

# Generated at 2022-06-22 22:03:29.937665
# Unit test for function container_to_text
def test_container_to_text():
    from ansible.compat.tests.mock import patch
    from ansible.module_utils import _text as text_utils

    _old_string_types = text_utils.string_types

    # Text types
    text_utils.string_types = (text_type,)

    test_dict = {
        "text": "text",
        "integer": 1,
        "list": [1, 2, 3],
        "dict": { "text": "text" },
        "bytes": b"bytes",
        "unicode": u"unicode",
        "boolean": True,
    }

    # Data will remain recursive dict
    transformed = copy.deepcopy(test_dict)
    text_utils.container_to_text(transformed)
    assert transformed == test_dict

    # Add bytestrings to dict
   

# Generated at 2022-06-22 22:03:42.999328
# Unit test for function container_to_text
def test_container_to_text():
    """
    Test for container_to_text
    """
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    # Invalid utf-8 byte sequence for key
    d = {b'\x80': b'\x80'}
    assert container_to_text(d, errors='strict') == {u'\ufffd': u'\ufffd'}
    # Invalid utf-8 byte sequence for value
    d = {b'key': b'\x80'}
    assert container_to_text(d, errors='strict') == {u'key': u'\ufffd'}
    # List with invalid utf-8 byte sequence for value
    d = [b'\x80']

# Generated at 2022-06-22 22:03:47.931374
# Unit test for function jsonify
def test_jsonify():
    # 1. Test on list and tuple
    test_list = [u'\u2019', u'\u2019']
    assert jsonify(test_list) == '["\u2019", "\u2019"]'
    # 2. Test on dict
    test_dict = {u'\u2019': u'\u2019'}
    assert jsonify(test_dict) == '{"\u2019": "\u2019"}'

# Generated at 2022-06-22 22:03:57.793511
# Unit test for function to_native
def test_to_native():
    assert to_native(b'ascii') == 'ascii'
    assert to_native('de\xe4f') == 'deäf'
    assert to_native(u'de\xe4f') == u'deäf'
    assert to_native(u'de\u20acf'.encode('utf-16')) == u'de\u20acf'
    assert to_native(u'de\xfff'.encode('latin1')) == u'de\ufffd'
    assert to_native(u'de\xfff'.encode('latin1'), errors='strict') == u'de\ufffd'
    assert to_native(u'de\xe4f'.encode('latin1')) == u'de\ufffd'

# Generated at 2022-06-22 22:04:10.694495
# Unit test for function container_to_text
def test_container_to_text():
    good_dict = {u'foo': u'bar', u'test': [u'one', u'two']}
    good_list = [u'foo', u'bar', [u'one', u'two']]
    good_tuple = (u'foo', u'bar', [u'one', u'two'])
    normal_string = u'foo'
    normal_int = 1
    normal_unicode = u'\u2713'

    assert container_to_text(good_dict) == good_dict
    assert container_to_text(good_list) == good_list
    assert container_to_text(good_tuple) == good_tuple
    assert container_to_text(normal_string) == normal_string
    assert container_to_text(normal_unicode) == normal_unicode

# Generated at 2022-06-22 22:04:18.290025
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text({u'a': 'b', u'c': 'd'}) == {u'a': u'b', u'c': u'd'}
    assert container_to_text({'a': 'b', u'c': 'd'}) == {u'a': u'b', u'c': u'd'}
    assert container_to_text({'a': 'b', 'c': 'd'}) == {u'a': u'b', u'c': u'd'}
    assert container_to_text([u'a', 'b', 'c']) == [u'a', u'b', u'c']
    assert container_to_text(('a', 'b', 'c')) == (u'a', u'b', u'c')

# Generated at 2022-06-22 22:04:29.105589
# Unit test for function container_to_bytes
def test_container_to_bytes():

    # The surrogateescape error handler is only in python3, so we can't
    # test that in python2

    # If you don't pass an encoding, it should default to utf-8
    assert container_to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # It should handle unicode input

# Generated at 2022-06-22 22:04:39.345678
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {'a': ['b', u'\xe4', 'c', to_text(b"\x80")],
         'd': {'e': u'\u2603'},
         'f': to_text(b"\x80")}
    new_d = container_to_bytes(d)
    assert isinstance(new_d, dict)
    assert isinstance(new_d['a'], list)
    assert isinstance(new_d['d'], dict)
    assert isinstance(new_d['d']['e'], binary_type)
    for i in new_d['a'][0:3]:
        assert isinstance(i, binary_type)
    assert isinstance(new_d['a'][3], text_type)

# Generated at 2022-06-22 22:04:46.089613
# Unit test for function to_bytes
def test_to_bytes():
    assert(to_bytes('foo') == b'foo')
    assert(to_bytes(b'foo') == b'foo')
    try:
        to_bytes(u'\uFFFE')
    except UnicodeEncodeError:
        assert(False)
    try:
        to_bytes(u'\uFFFE', errors='surrogate_or_replace')
    except UnicodeEncodeError:
        assert(False)
    try:
        to_bytes(u'\uFFFE', errors='surrogate_or_strict')
    except UnicodeEncodeError:
        assert(False)
    assert(to_bytes(u'\uFFFE', errors='surrogate_then_replace') == b'?\ufffd')
    assert(to_bytes(5) == b'5')

# Generated at 2022-06-22 22:04:50.939700
# Unit test for function to_native
def test_to_native():
    assert to_native("b'hello'") == b'b\'hello\''
    assert to_native("u'hello'") == u'hello'
    assert to_native("'hello\u20ac'") == u'hello\u20ac'
    assert to_native(to_bytes("u'hello\u20ac'")) == to_bytes("'hello\u20ac'")
    assert to_native(to_bytes("u'hello'")) == to_bytes("'hello'")



# Generated at 2022-06-22 22:04:58.786433
# Unit test for function container_to_text
def test_container_to_text():
    d = {'a': b'\xc3\xbcnic\xc3\xb8de'}
    t = {'a': u'\xfcnic\xf8de'}
    assert container_to_text(container_to_bytes(d)) == t
    assert container_to_bytes(container_to_text(t)) == d
    d = {'a': u'\xfcnic\xf8de'}
    t = {'a': u'\xfcnic\xf8de'}
    assert container_to_text(d) == t
    assert container_to_bytes(t) == d



# Generated at 2022-06-22 22:05:02.006671
# Unit test for function to_native
def test_to_native():
    obj = u'\u1234'
    assert to_native(obj) == '\xe1\x88\xb4'



# Generated at 2022-06-22 22:05:12.328997
# Unit test for function to_native
def test_to_native():
    import ast
    from datetime import date
    from decimal import Decimal
    from fractions import Fraction
    from textwrap import dedent

    from ansible.module_utils._text import to_native

    raw = u'{"ansible_facts": {"date_time": {"date": "%s", "timezone": "UTC", "time": "13:12:00", "is_dst": false, "epoch": "1520279920.0", "tz": "UTC"}}}' % date.today().strftime("%Y-%m-%d")

    # String conversion tests

    # bytes
    assert to_native(b'hello world') == 'hello world'

# Generated at 2022-06-22 22:05:22.787554
# Unit test for function container_to_bytes
def test_container_to_bytes():
    '''
    test function container_to_bytes
    '''
    foo_dict = {'foo': 'x', 'bar': 'y'}
    foo_dict_bytes = {b'foo': b'x', b'bar': b'y'}
    assert container_to_bytes(foo_dict) == foo_dict_bytes
    foo_list = ['foo', 'x', 'bar', 'y']
    foo_list_bytes = [b'foo', b'x', b'bar', b'y']
    assert container_to_bytes(foo_list) == foo_list_bytes
    foo_tuple = ('foo', 'x', 'bar', 'y')
    foo_tuple_bytes = (b'foo', b'x', b'bar', b'y')

# Generated at 2022-06-22 22:05:31.424304
# Unit test for function to_bytes
def test_to_bytes():
    # non-strings
    assert to_bytes(None) == b'None'
    assert to_bytes(1) == b'1'
    assert to_bytes(1) == to_bytes(1, nonstring='simplerepr')
    assert to_bytes(1, nonstring='empty') == b''
    assert to_bytes(1, nonstring='passthru') == 1
    try:
        to_bytes(1, nonstring='strict')
        assert False
    except TypeError:
        assert True
    try:
        to_bytes(1, nonstring='invalid')
        assert False
    except TypeError:
        assert True

    # text string handling
    assert to_bytes('hi') == b'hi'
    assert to_bytes(u'hi') == b'hi'

# Generated at 2022-06-22 22:05:41.564101
# Unit test for function container_to_text
def test_container_to_text():
    from ansible.module_utils._text import to_bytes, to_text
    # Test with a dict
    d = {to_bytes("key"): to_bytes("value")}
    data1 = container_to_text(d, encoding='utf-8', errors='strict')
    assert isinstance(data1, dict)
    # Test with a list
    data2 = container_to_text([to_bytes("value1"), to_bytes("value2")], encoding='utf-8', errors='strict')
    assert isinstance(data2, list)
    # Test with a tuple
    data3 = container_to_text((to_bytes("value1"), to_bytes("value2")), encoding='utf-8', errors='strict')
    assert isinstance(data3, tuple)



# Generated at 2022-06-22 22:05:53.377350
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'test') == b'test'
    assert to_bytes(u'\u043f\u043e\u0440\u0442') == b'\xd0\xbf\xd0\xbe\xd1\x80\xd1\x82'
    assert to_bytes('\xd0\xbf\xd0\xbe\xd1\x80\xd1\x82') == b'\xd0\xbf\xd0\xbe\xd1\x80\xd1\x82'
    assert to_bytes(u'\u043f\u043e\u0440\u0442', encoding='koi8-r') == b'\xc3\xa0\xc2\xbb\xc2\xae\xc2\xae'

# Generated at 2022-06-22 22:06:03.322145
# Unit test for function to_native
def test_to_native():
    """
    Test function: test_to_native
    Purpose: To test the following functions:
        to_native
        to_text
        to_bytes
    Return: True
    """
    import unittest
    class TestToNative(unittest.TestCase):
        """
        Test class: TestToNative
        Purpose: To test the functions in the module
        Return: True
        """
        def test_to_native(self):
            """
            Test function: test_to_native
            Purpose: test the to_native function in the module
            Return: True
            """
            self.assertEqual(to_native(u'foo'), 'foo')
            self.assertEqual(to_native(b'foo'), 'foo')

# Generated at 2022-06-22 22:06:12.699128
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_data = [
        ("utf-8", "utf-8", b"\xE2\x82\xAC"),
        ("ascii", "utf-8", b'euro = \xE2\x82\xAC'),
        ("ascii", "surrogate_or_replace", b'euro = \xEF\xBF\xBD'),
        ("ascii", "surrogate_then_replace", b'euro = \xEF\xBF\xBD'),
        ("ascii", "surrogate_or_strict", Exception),
    ]

# Generated at 2022-06-22 22:06:24.214247
# Unit test for function to_bytes

# Generated at 2022-06-22 22:06:30.966329
# Unit test for function container_to_text
def test_container_to_text():
    assert(container_to_text([u"a", "b", b"c", 1, [], (u"d", b"e")]) ==
           [u"a", u"b", u"c", 1, [], (u"d", u"e")])
    assert(container_to_text({u"a": "b", "c": b"d"}) ==
           {u"a": u"b", u"c": u"d"})



# Generated at 2022-06-22 22:06:42.903062
# Unit test for function to_native
def test_to_native():
    # Verify proper handling of errors argument
    assert(to_text(to_bytes('123', errors='surrogate_or_strict'), 'utf-8', 'surrogate_or_strict') == '123')
    assert(to_text(to_bytes('123', errors='surrogate_or_replace'), 'utf-8', 'surrogate_or_replace') == '123')

    # Verify that surrogate_then_replace uses surrogateescape when possible,
    # and otherwise is a passthrough to the replace handler
    if HAS_SURROGATEESCAPE:
        assert(to_text(to_bytes('123', errors='surrogate_then_replace'), 'utf-8', 'surrogate_then_replace') == '123')
        # When surrogateescape is available, we should be able to use it to get
       

# Generated at 2022-06-22 22:06:55.184277
# Unit test for function to_bytes
def test_to_bytes():
    safe_text_strings = [
        u'Andr\xe9',
        u'Fran\xe7ois',
        u'\xe4\xf6\xfc',
        u'text',
        u'\xa3',
    ]

    surrogate_strings = [
        u'\U000a7427',
        u'\ud83d\ude00',
        u'\U0001f600',
    ]


# Generated at 2022-06-22 22:06:58.274945
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': '1'}) == '{"a": "1"}'
    assert jsonify({'a': u'\u1234'}) == '{"a": "\\u1234"}'



# Generated at 2022-06-22 22:07:03.688955
# Unit test for function container_to_bytes
def test_container_to_bytes():
    for obj in [
            {u'a': u'1'},
            [u'1'],
            (u'1', ),
            u'1',
            1,
            None,
            b'1'
    ]:
        assert container_to_bytes(obj) == obj


# vim: set fileencoding=utf-8 :

# Generated at 2022-06-22 22:07:13.959143
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.common._collections_compat import Mapping

    assert to_bytes(1, errors='strict', nonstring='strict') != 1

    for nonstring in ('simplerepr', 'passthru', 'empty'):
        assert to_bytes(1, errors='strict', nonstring=nonstring) != 1

    # Ensure that surrogates are escaped
    surrogate_text = u"a\uD800\uDC02b"
    # surrogate_text.encode('utf-8') will raise UnicodeEncodeError, so we
    # substitute the error handler
    assert to_bytes(surrogate_text, errors='ignore') == b'ab'

# Generated at 2022-06-22 22:07:19.639911
# Unit test for function jsonify
def test_jsonify():
    # Make sure utf-8 encoded data can be jsonified
    data = {u'foo': u'bar'}
    assert jsonify(data) == '{"foo": "bar"}'
    # Make sure latin-1 encoded data can be jsonified
    data = {u'foo': u'À'}
    assert jsonify(data) == '{"foo": "\\u00c0"}'



# Generated at 2022-06-22 22:07:27.402926
# Unit test for function to_bytes
def test_to_bytes():

    placeholder = object()

# Generated at 2022-06-22 22:07:35.435930
# Unit test for function to_bytes
def test_to_bytes():
    try:
        codecs.lookup_error('surrogateescape')
        HAS_SURROGATEESCAPE = True
    except LookupError:
        HAS_SURROGATEESCAPE = False

    def _test(obj, encoding, errors, nonstring, expected):
        actual = to_bytes(obj, encoding=encoding, errors=errors, nonstring=nonstring)
        assert expected == actual

    # Test valid input
    _test('This is a string', 'utf-8', None, 'simplerepr', b'This is a string')
    _test('This is a string', 'utf-8', 'surrogate_or_replace', 'simplerepr', b'This is a string')

# Generated at 2022-06-22 22:07:47.507749
# Unit test for function container_to_text
def test_container_to_text():

    assert container_to_text({'foo': 'bar', 'baz': {'faz': 'bus'}}) == \
        {'foo': u'bar', 'baz': {'faz': u'bus'}}

    assert container_to_text({'foo': 'bar', 'baz': {'faz': b'bus'}}) == \
        {'foo': u'bar', 'baz': {'faz': u'bus'}}

    assert container_to_text({'foo': 'bar', 'baz': {'faz': 'bus'}}) == \
        {'foo': u'bar', 'baz': {'faz': u'bus'}}


# Generated at 2022-06-22 22:07:59.000920
# Unit test for function to_native
def test_to_native():
    sample_text_unicode = u'\u043f\u0440\u0438\u0432\u0435\u0442'
    sample_text_utf8 = b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # This sample text is decodable with 'ascii' but not with 'utf-8'
    sample_text_strict_unicode = u'\u043f\u0440\u0438\u0432\u0435\u0442'
    sample_text_strict_utf8 = b'\xcf\x80\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

   

# Generated at 2022-06-22 22:08:10.787574
# Unit test for function container_to_bytes

# Generated at 2022-06-22 22:08:21.238897
# Unit test for function jsonify
def test_jsonify():

    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    json_test = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    json_test_dict = dict(key1='value1', key2='value2', key3='value3')
    json_test_dict_unicode = dict(key1='value1', key2='value2', key3='value3', unicode_key=u"unic\u00F6de")
    json_test_dict_bytes = dict(key1='value1', key2='value2', key3='value3', bytes_key=b"bytes")


# Generated at 2022-06-22 22:08:33.018742
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(['a',u'b']) == [u'a',u'b']
    assert container_to_text([u'a',b'b']) == [u'a', u'b']
    assert container_to_text([b'a',u'b']) == [u'a', u'b']
    assert container_to_text({u'a':'b'}) == {u'a': u'b'}
    assert container_to_text({'a': 'b'}) == {u'a': u'b'}
    assert container_to_text({'a': b'b'}) == {u'a': u'b'}
    assert container_to_text({b'a': u'b'}) == {u'a': u'b'}
    assert container_

# Generated at 2022-06-22 22:08:43.344894
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_replace') == b'?\x88\xb4'
    assert to_bytes(u'\u1234', encoding='utf-8') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\xe1\x88\xb4'
    assert to_bytes(b'\xff') == b'\xff'
   

# Generated at 2022-06-22 22:08:49.430212
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test data:
    # Complex data structure with unicode characters
    data = [
        u'\xe4\xb8\xad\xe6\x96\x87',
        [
            u'\xe4\xb8\xad\xe6\x96\x87',
            {
                u'\xe4\xb8\xad\xe6\x96\x87': u'\xe4\xb8\xad\xe6\x96\x87',
                u'z2': 3
            },
            4
        ],
        {
            u'\xe4\xb8\xad\xe6\x96\x87': u'\xe4\xb8\xad\xe6\x96\x87',
            u'z2': 3
        },
        5
    ]

   

# Generated at 2022-06-22 22:08:56.909832
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Intentionally using non-ascii character to prove that we are encoding
    test_unicode = "abcéf"
    test_dict = {
        test_unicode: test_unicode,
        b"c": b"c",
    }
    expected_dict = {
        test_unicode.encode('utf-8'): test_unicode.encode(),
        b"c": b"c",
    }
    assert container_to_bytes(test_dict) == expected_dict


# Generated at 2022-06-22 22:09:07.741884
# Unit test for function container_to_bytes
def test_container_to_bytes():
    if not PY3:
        raise SkipTest("Test only works on python3")

    assert container_to_bytes(u'foobar') == b'foobar'
    assert container_to_bytes(u'foobar', encoding='ascii') == b'foobar'
    assert container_to_bytes(u'foobar', errors='surrogate_or_replace') == b'foobar'

    try:
        container_to_bytes(u'\udcff')
        assert False
    except UnicodeEncodeError:
        pass
    assert container_to_bytes(u'\udcff', errors='surrogate_or_replace') == b'?'

# Generated at 2022-06-22 22:09:18.488127
# Unit test for function container_to_bytes

# Generated at 2022-06-22 22:09:27.516438
# Unit test for function jsonify
def test_jsonify():
    # Test for container_to_text of function jsonify
    result = jsonify({'a': 1}, ensure_ascii=False)
    assert result == u'{"a": 1}'

    result = jsonify([{'a': '\u5f20'}], ensure_ascii=False)
    assert result == u'[{"a": "\u5f20"}]'

    # Test for json.dumps of function jsonify

# Generated at 2022-06-22 22:09:34.294537
# Unit test for function container_to_bytes
def test_container_to_bytes():
    '''Unit test for function container_to_bytes'''
    data = {
        'foo': 'my string',
        'bar': b'bytes_string',
        'baz': ['list', 'of', 'strings'],
        'dictionary': {'foo': 'bar'},
        'tuple': ('1', '2'),
        'unicode_string': u'\u2713',
        'bytearray': bytearray(b'foo'),
    }
    encoded_data = container_to_bytes(data)
    assert isinstance(encoded_data['foo'], bytes)
    assert isinstance(encoded_data['bar'], bytes)
    assert isinstance(encoded_data['baz'], list)
    assert isinstance(encoded_data['baz'][0], bytes)


# Generated at 2022-06-22 22:09:44.324690
# Unit test for function container_to_text
def test_container_to_text():
    t = {  # test dictionary
        'string': 'this is a test',
        'byte_str_in_str': b'this is a test',
        'str_in_byte_str': 'this is a test'.encode('ascii'),
        'byte_str': b'\x00\x01\x02\x04\xff',
        'list': ['this', 'is', b'\x00\x01\x02\x04\xff', 'a', 'test'],
        'list_in_list': ['this', 'is', ['a', b'test'], 'a', 'test'],
    }

    result = container_to_text(t)
    assert isinstance(result['string'], str), \
        "Failed to convert string value of dictionary"

# Generated at 2022-06-22 22:09:50.309873
# Unit test for function to_bytes
def test_to_bytes():
    to_bytes('abc', 'latin1')

    if PY3:
        # Python 3 has a utf-8 codec that can't decode surrogates.  So we're just
        # making sure it doesn't traceback
        try:
            to_bytes('abc\udce4', 'utf-8', 'surrogateescape')
        except UnicodeEncodeError:
            pass
        else:
            raise AssertionError('surrogate escape error handler did not raise exception on encoding error')

        # Python 3's surrogateescape handler will round-trip back to the original string.
        # We can only test this if we have a non-ascii string to start with
        assert 'abc\udce4' == to_bytes('abc\udce4', 'utf-8', 'surrogate_or_replace')

# Generated at 2022-06-22 22:10:01.282644
# Unit test for function container_to_text
def test_container_to_text():
    fake_data = {
        b'a': b'b',
        'c': u'\xe4',
        'd': [b'e', u'\xe4', b'\xe4'],
        1: 2,
        3: {
            'x': [u'\xe4', b'\xe4'],
            'y': u'\xe4',
            'z': b'\xe4'
            }
    }

# Generated at 2022-06-22 22:10:12.744659
# Unit test for function jsonify
def test_jsonify():
    unicode_string = u"Iñtërnâtiônàlizætiøn☃💩"
    utf8_bytes = unicode_string.encode('utf-8')
    input_data = {
        to_bytes(u'unicode_string'): unicode_string,
        'utf8_bytes': utf8_bytes
    }

# Generated at 2022-06-22 22:10:24.543537
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {u'a': 1, u'b': (2, 3)}
    assert container_to_bytes(d, encoding='utf-8', errors='surrogate_or_strict') == {b'a': 1, b'b': (2, 3)}
    # unicode error
    d = {u'a': 1, u'b': (2, 3), u'c': u'\u001f'}
    assert container_to_bytes(d, encoding='ascii', errors='surrogate_or_replace') == {b'a': 1, b'b': (2, 3), b'c': b'?'}
    # nonstring (simplerepr)
    import datetime

# Generated at 2022-06-22 22:10:34.452060
# Unit test for function to_native
def test_to_native():
    class TestClass:
        def __str__(self):
            return 'class string'
        def __repr__(self):
            return 'class repr'

    fake_now = datetime.datetime.now()
    fake_now2 = datetime.datetime.now()

    def fake_json_dumps(obj, **kwargs):
        return 'json dumps: %s' % (obj)
    def fake_json_dump(obj, fp, **kwargs):
        return fp.write('json dump: %s' % (obj))

    def fake_json_loads(obj, **kwargs):
        return 'json loads: %s' % (obj)

    def fake_json_load(obj, fp, **kwargs):
        return 'json load: %s' % (fp.read())


# Generated at 2022-06-22 22:10:37.374315
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u2713') == '\xe2\x9c\x93'



# Generated at 2022-06-22 22:10:44.985677
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text('123') == '123'
    assert container_to_text(b'123') == '123'
    assert container_to_text({'a': b'123'}) == {u'a': u'123'}
    assert container_to_text({'a': u'123'}) == {u'a': u'123'}
    assert container_to_text({b'a': u'123'}) == {u'a': u'123'}
    assert container_to_text([{b'a': u'123'}]) == [{u'a': u'123'}]


# Generated at 2022-06-22 22:10:49.476261
# Unit test for function to_native
def test_to_native():
    text = u'\u2665'
    binary = to_bytes(text, encoding='ascii', errors='surrogateescape')
    assert text == to_text(binary, encoding='utf-8', errors='surrogateescape')



# Generated at 2022-06-22 22:10:59.983662
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"key": "val", "arr": ["val1", "val2"], "map": {"key": "val"}, "int": 1, "bool": True}) == b'{"int": 1, "key": "val", "map": {"key": "val"}, "arr": ["val1", "val2"], "bool": true}'
    assert jsonify({"key": "val", "arr": ["val1", "val2"], "map": {"key": "val"}, "int": 1, "bool": True}, sort_keys=True) == b'{"arr": ["val1", "val2"], "bool": true, "int": 1, "key": "val", "map": {"key": "val"}}'

# Generated at 2022-06-22 22:11:10.649398
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo'.encode('utf16'), encoding='utf8') == b'foo'
    assert to_bytes(u'foo'.encode('utf16'), encoding='utf8', errors='replace') == b'foo'
    assert to_bytes(u'\udcec\udcba', encoding='ascii', errors='surrogate_or_replace') == b'?\ufffd'

# Generated at 2022-06-22 22:11:19.708860
# Unit test for function to_native
def test_to_native():
    assert isinstance(to_native(u'foo'), text_type)
    assert isinstance(to_native(b'foo'), binary_type)
    assert isinstance(to_native(u'foo'), text_type)
    assert isinstance(to_native(b'foo'), binary_type)
    assert to_native(u'\u2713') == to_native(u'\u2713')
    assert not isinstance(to_native(u'\u2713'), binary_type)
    assert to_native(1) == '1'
    assert to_native(None) is None



# Generated at 2022-06-22 22:11:28.418763
# Unit test for function to_native
def test_to_native():
    # Python 3
    assert to_native(b'abc') == 'abc'
    assert to_native('abc') == 'abc'
    assert to_native(u'abc') == 'abc'
    assert to_native(3) == '3'

    # Python 2
    assert to_native(b'abc') == 'abc'
    assert to_native('abc') == 'abc'
    assert to_native(u'abc') == u'abc'
    assert to_native(3) == '3'



# Generated at 2022-06-22 22:11:40.504611
# Unit test for function to_bytes
def test_to_bytes():
    # Tests all code paths
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\ud800', errors='surrogate_or_strict') == b'\xed\xa0\x80'

# Generated at 2022-06-22 22:11:47.071726
# Unit test for function container_to_text
def test_container_to_text():
    test_list = [b'byte', [b'string'], [[b'inside', [b'list']]]]
    test_tuple = (b'byte', [b'string'], (b'inside', [b'list']))
    test_dict = {b'key': 'value', b'list': [b'inside', [b'dictionary']]}
    test_dict_nested = {b'key': 'value', b'list': [b'inside', {b'nested': [b'list']}]}
    assert container_to_text(test_list) == ['byte', ['string'], [['inside', ['list']]]]
    assert container_to_text(test_tuple) == ('byte', ['string'], ('inside', ['list']))