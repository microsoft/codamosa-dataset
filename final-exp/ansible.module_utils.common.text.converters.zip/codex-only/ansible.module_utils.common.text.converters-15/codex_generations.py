

# Generated at 2022-06-22 22:01:47.981428
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == b'foo'
    assert to_bytes(to_text(b'foo')) == b'foo'
    assert to_bytes('fòô', encoding='latin-1') == b'f\xf2\xf4'
    assert to_bytes('fòô', encoding='utf-8') == b'f\xc3\xb2\xc3\xb4'
    assert to_bytes('fòô', encoding='ascii', errors='surrogate_or_strict') == b'f\xc3\xb2\xc3\xb4'
    assert to_bytes('fòô', encoding='ascii', errors='surrogate_or_replace') == b'f??'
    assert to_bytes('fòô', encoding='ascii') == b

# Generated at 2022-06-22 22:01:56.745934
# Unit test for function jsonify
def test_jsonify():
    # sample data
    data = dict(
        foo='bar',
        baz=dict(
            bla='blub',
            list_of_stuff=[u'lal\xf6', 42, u'l\xf6l\xf6']
        )
    )
    # Get the jsonified data
    json_data = jsonify(data)
    # Should not be a Unicode string
    assert not isinstance(json_data, text_type)
    # Should be a str
    assert isinstance(json_data, str)
    # Should decode to the same data structure we started with
    assert json.loads(json_data) == data


# Generated at 2022-06-22 22:02:04.174219
# Unit test for function to_native
def test_to_native():
    assert to_native('foo') == 'foo'
    assert isinstance(to_native(b'foo'), binary_type)
    assert isinstance(to_native(b'foo', errors='replace'), text_type)
    assert isinstance(to_native(b'foo', nonstring='empty'), text_type)
    assert isinstance(to_native(b'foo', errors='replace'), text_type)
    assert isinstance(to_native(u'foo', encoding='ascii', errors='surrogateescape'), text_type)
    assert isinstance(to_native(u'foo', bytearray_as_bytes=True), binary_type)



# Generated at 2022-06-22 22:02:16.864245
# Unit test for function container_to_text
def test_container_to_text():
    if not PY3:
        return
    data = dict(
        a=1,
        b=b'hello',
        c='goodbye',
        d=b'\xe9',
        e=[
            dict(
                a=b'\xe9',
                b=b'\xe9',
            )
        ],
        f=u'\xe9',
        g=[
            dict(
                a=b'\xe9',
                b=b'\xe9',
            )
        ],
        h=u'\u7684',
        i=[
            dict(
                a=b'\xe9',
                b=b'\xe9',
            )
        ],
        j=[
            b'\xe9'
        ],
    )


# Generated at 2022-06-22 22:02:28.222261
# Unit test for function to_native
def test_to_native():
    assert to_native(None) is None
    assert to_native(True) is True
    assert to_native(False) is False
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'fóo'.encode('utf-8')) == u'fóo'
    assert to_native(u'fóo'.encode('iso-8859-1')) == u'fóo'
    assert to_native(u'fóo'.encode('cp424')) == u'fóo'
    assert to_native(u'foo'.encode('utf-16')) == u'foo'

# Generated at 2022-06-22 22:02:38.205873
# Unit test for function container_to_text
def test_container_to_text():
    # Test simple case
    assert to_text({'test': to_bytes('test')}) == {'test': u'test'}

    # Test that unicode strings are not transformed
    assert to_text({'test': u'test'}) == {'test': u'test'}

    # Test nested case
    data = {'test': {'test': {'test': to_bytes('test')}}}
    assert to_text(data) == {'test': {'test': {'test': u'test'}}}

    # Test list cases
    assert to_text([to_bytes('test')]) == [u'test']
    assert to_text([[to_bytes('test')]]) == [[u'test']]
    assert to_text((to_bytes('test'),)) == (u'test',)
    assert to_

# Generated at 2022-06-22 22:02:48.076832
# Unit test for function container_to_text
def test_container_to_text():
    print("===========test_container_to_text=========")
    str_a = "中文"
    print("before: %s %s %s" % (str_a, type(str_a), sys.getdefaultencoding()))
    str_b = container_to_text(str_a)
    print("after: %s %s" % (str_b, type(str_b)))
    assert(str_a == str_b)

    str_a = "中文".encode("utf-8")
    print("before: %s %s %s" % (str_a, type(str_a), sys.getdefaultencoding()))
    str_b = container_to_text(str_a)

# Generated at 2022-06-22 22:03:00.048021
# Unit test for function to_bytes
def test_to_bytes():
    assert isinstance(to_bytes(u'\u6d4b'), binary_type)
    assert isinstance(to_bytes(u'\u6d4b', nonstring='empty'), binary_type)
    # Can't do this on python 2.4
    #assert isinstance(to_bytes(u'\u6d4b', nonstring='strict'), binary_type)
    if PY3:
        try:
            to_bytes(b'\xff')
            raise AssertionError('Encoding a byte string should fail')
        except TypeError:
            pass

    assert to_bytes(u'\u6d4b\u8bd5') == b'\xe6\xb5\x8b\xe8\xaf\x95'

# Generated at 2022-06-22 22:03:11.515070
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(foo="bar", bam=dict(a=1, b=2))) == '{"foo": "bar", "bam": {"a": 1, "b": 2}}'
    assert jsonify(dict(foo="bar", bam=[1, 2, 3])) == '{"foo": "bar", "bam": [1, 2, 3]}'
    assert jsonify(dict(foo="bar", bam=[1, 'a', 3])) == '{"foo": "bar", "bam": [1, "a", 3]}'
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'
    assert jsonify([1, 2, [3, 4]]) == '[1, 2, [3, 4]]'

# Generated at 2022-06-22 22:03:21.444886
# Unit test for function to_native
def test_to_native():
    from . import _text
    from ansible.module_utils.common._collections_compat import collections_compat_bytes, collections_compat_str
    native_value = 'foo'
    try:
        u = unicode
    except NameError:
        u = str
    assert isinstance(_text.to_native(native_value), collections_compat_str)
    assert isinstance(_text.to_native(u('друг')), collections_compat_str)
    assert isinstance(_text.to_native(u('друг').encode('utf-8')), collections_compat_str)
    assert isinstance(_text.to_native(native_value.encode('utf-8')), collections_compat_str)


# Generated at 2022-06-22 22:03:26.699411
# Unit test for function container_to_text
def test_container_to_text():
    dict_a = dict((u'k1', u'test'), (u'k2', u'123'), (b'k3', b'345'))
    dict_b = dict((u'k1', u'test'), (u'k2', u'123'), (b'k3', b'345'))
    dict_b[u'k4'] = dict_b
    dict_a[b'k4'] = dict_a
    assert container_to_text(dict_b, encoding='latin-1') == dict_a

# Generated at 2022-06-22 22:03:33.691184
# Unit test for function to_bytes
def test_to_bytes():
    print('Testing to_bytes...')
    # Check bytes pass through
    b_test = b'\xe1\x88\xb4'
    assert to_bytes(b_test) == b_test
    assert to_bytes(b_test, 'ascii') == b_test
    assert to_bytes(b_test, 'ascii', 'surrogateescape') == b_test

    # Check str handling
    if PY3:
        assert to_bytes('\u1234') == b'\xe1\x88\xb4'
        assert to_bytes('\u1234', 'ascii', 'surrogateescape') == b'\xed\xa1\x8c\xed\xb4\xb4'

# Generated at 2022-06-22 22:03:45.642132
# Unit test for function container_to_text
def test_container_to_text():
    import unittest
    class TestContainerToText(unittest.TestCase):
        def test_dict(self):
            d = dict(foo='bar', baz='qux', xyzzy='thud')
            d = container_to_text(d, encoding='ascii', errors='strict')
            self.assertTrue(isinstance(d, dict))
            for k, v in d.items():
                self.assertTrue(isinstance(k, text_type))
                self.assertTrue(isinstance(v, text_type))
        def test_list(self):
            original_list = ['foo', 'bar', 'baz']
            new_list = container_to_text(original_list, encoding='ascii', errors='strict')

# Generated at 2022-06-22 22:03:55.170221
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test case : check if the container_to_bytes function decode the all
    #             unicode character correctly.
    # Test step : 1. create a unicode string with chinese and special character
    #             2. convert the unicode to text string using container_to_bytes
    #                function
    #             3. check if the converted text string is the same as the unicode
    #                string
    # Test result: PASS - if the converted string is the same as the unicode string
    #              FAIL - if the converted string is not the same as the unicode string
    unicode_string = u'中文text/简体字'
    byte_string = to_bytes(unicode_string)
    text_string = container_to_bytes(unicode_string)
    assert byte_string == text_string



# Generated at 2022-06-22 22:04:07.475105
# Unit test for function container_to_text
def test_container_to_text():
    class A(object):
        def __str__(self):
            # On Python2, str returns bytes
            return b"\xe1"

        def __repr__(self):
            # On Python2, repr returns bytes
            return b"\xe1"

    da = {b'a': b'a', b'b': b'b'}
    class B(object):
        def __init__(self):
            self.da = da

    db = {u'a': u'a', u'b': u'b'}
    class C(object):
        def __init__(self):
            self.db = db

    dc = {b'a': A(), b'b': A()}
    class D(object):
        def __init__(self):
            self.dc = dc


# Generated at 2022-06-22 22:04:16.863616
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # bytes type
    assert container_to_bytes(b'bytes') == b'bytes'
    # text_type
    assert container_to_bytes('unicode') == 'unicode'
    # dict
    unicode_dict = {'key': 'value'}
    expected_dict = {'key': 'value'}
    assert container_to_bytes(unicode_dict) == expected_dict
    # list
    unicode_list = [b'bytes', 'unicode']
    expected_list = [b'bytes', b'unicode']
    assert container_to_bytes(unicode_list) == expected_list
    # tuple
    unicode_tuple = (b'bytes', 'unicode')
    expected_tuple = (b'bytes', b'unicode')

# Generated at 2022-06-22 22:04:23.584925
# Unit test for function to_native
def test_to_native():
    if PY3:
        assert b'foo' == to_bytes(b'foo')
        assert b'foo' == to_bytes('foo')
        assert 'foo' == to_text(b'foo')
        assert 'foo' == to_text('foo')
    else:
        assert 'foo' == to_bytes(b'foo')
        assert 'foo' == to_bytes('foo')
        assert u'foo' == to_text(b'foo')
        assert u'foo' == to_text('foo')



# Generated at 2022-06-22 22:04:35.269756
# Unit test for function container_to_bytes
def test_container_to_bytes():
    my_dict = dict(my_key = u'Value with unicode: é', my_list = [u'1', u'2', u'3'], my_tuple = (u'1', u'2', u'3'), my_int = 1)
    my_dictb = container_to_bytes(my_dict, encoding='utf-8')
    my_dictl = container_to_bytes(my_dict, encoding='latin-1')

    assert isinstance(my_dictb['my_key'], binary_type)
    assert isinstance(my_dictb['my_list'][0], binary_type)
    assert isinstance(my_dictb['my_tuple'][1], binary_type)
    assert isinstance(my_dictb['my_int'], int)


# Generated at 2022-06-22 22:04:43.316716
# Unit test for function container_to_text
def test_container_to_text():
    """Unit tests for container_to_text"""
    assert container_to_text(u'foo', encoding='utf-8', errors='surrogate_or_strict') == u'foo'

    # dict
    assert container_to_text({u'foo': u'bar'}, encoding='utf-8', errors='surrogate_or_strict') == {u'foo': u'bar'}
    assert container_to_text({'foo': 'bar'}, encoding='utf-8', errors='surrogate_or_strict') == {u'foo': u'bar'}
    assert container_to_text({u'foo': 'bar'}, encoding='utf-8', errors='surrogate_or_strict') == {u'foo': u'bar'}

# Generated at 2022-06-22 22:04:55.163592
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text({"key1":u"value1",
                              "key2":u"value2",
                              "key3":u"value3",
                              "key4":u"value4",
                              "key5":u"value5",
                              "key6":u"value6",
                              }) == {"key1":u"value1",
                                     "key2":u"value2",
                                     "key3":u"value3",
                                     "key4":u"value4",
                                     "key5":u"value5",
                                     "key6":u"value6",
                              }


# Generated at 2022-06-22 22:05:03.255074
# Unit test for function to_bytes
def test_to_bytes():
    if PY3:
        raise Exception('This test is for Python2 only')

    from ansible.utils.unicode import to_bytes
    import sys
    import platform

    # Case 1: Pass a string
    # Case 1.1: Pass ascii
    assert to_bytes('string') == b'string'

    # Case 1.2: Pass unicode
    # Case 1.2.1: Pass unicode that doesn't need to be decoded
    assert to_bytes(u'unicode') == b'unicode'
    # Case 1.2.2: Pass unicode that needs to be decoded
    assert to_bytes(u'\u00e9') == b'\xc3\xa9'

    # Case 2: Pass a non-string
    # Case 2.1: Passthru: to_bytes(42

# Generated at 2022-06-22 22:05:13.245654
# Unit test for function container_to_text
def test_container_to_text():
    input_list = [1,'a']
    input_tuple = ("a", b"b")
    input_dict = {"a":1}
    input_dict2 = {b"a":b"b"}
    input_mix = {"a":[b"a",1]}
    input_mix2 = {b"a":[b"a",1]}
    input_mix4 = {"a":[b"a",1],b"b":b"b"}
    input_mix5 = {b"a":[1,2],b"b":b"b"}



    output_list = container_to_text(input_list)
    assert(isinstance(output_list, list))
    assert(isinstance(output_list[0], text_type))
    assert(isinstance(output_list[1], text_type))

    output

# Generated at 2022-06-22 22:05:20.910638
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({u'a': u'b'}) == {'a': 'b'}
    assert container_to_bytes([u'a', u'b']) == ['a', 'b']
    assert container_to_bytes((u'a', u'b')) == ('a', 'b')

    assert container_to_bytes({u'a': u'b'}, errors='surrogate_then_replace') == {'a': 'b'}
    assert container_to_bytes([u'a', u'b'], errors='surrogate_then_replace') == ['a', 'b']
    assert container_to_bytes((u'a', u'b'), errors='surrogate_then_replace') == ('a', 'b')


# Generated at 2022-06-22 22:05:23.211682
# Unit test for function jsonify
def test_jsonify():
    jsonify(dict(one="string", two=dict(three=[1, 2, u'\u20ac', dict(four=False)], five='string')))



# Generated at 2022-06-22 22:05:29.266927
# Unit test for function container_to_bytes
def test_container_to_bytes():
    for test_string in ['abc', '\x80', '\u20ac']:
        try:
            result = container_to_bytes(test_string)
            assert isinstance(result, binary_type)
        except UnicodeDecodeError:
            if PY3:
                raise Exception('unrecognized character with test_string="{0}"'.format(test_string))
            else:
                pass


# Generated at 2022-06-22 22:05:40.511067
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes("a") == b"a"
    assert container_to_bytes("abcd") == b"abcd"
    assert container_to_bytes(("abc","abc")) == (b"abc", b"abc")
    assert container_to_bytes(("abc","abc")) == (b"abc", b"abc")
    assert container_to_bytes(["abc","abc"]) == [b"abc", b"abc"]
    assert container_to_bytes(dict(A=1)) == {b"A": 1}
    assert container_to_bytes(dict(A="abc")) == {b"A": b"abc"}
    assert container_to_bytes(dict(A=["abc","abc"])) == {b"A": [b"abc", b"abc"]}

# Generated at 2022-06-22 22:05:50.812953
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\xe9\x94\x99\xe6\x80\xa7\xe7\x9a\x84\xe8\xa8\x98\xe6\x9c\x9f') == u'\xe9\x94\x99\xe6\x80\xa7\xe7\x9a\x84\xe8\xa8\x98\xe6\x9c\x9f'
    assert to_native(u'abcde') == u'abcde'

# Generated at 2022-06-22 22:06:00.208960
# Unit test for function to_bytes
def test_to_bytes():
    assert b'hiya' == to_bytes('hiya')
    assert b'hiya' == to_bytes('hiya', encoding='ascii')
    assert b'foob\xe4r' == to_bytes('foob\xe4r'.encode('latin-1'), encoding='ascii', errors='replace')
    assert to_bytes('', nonstring='passthru') == ''
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(to_bytes, nonstring='passthru') == to_bytes
    assert b'1' == to_bytes(1, nonstring='simplerepr')
    assert b'1' == to_bytes(1, nonstring='simplerepr', encoding='ascii')

# Generated at 2022-06-22 22:06:10.129682
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.six import b

    assert to_bytes(u'\u6c38\u9060', encoding='utf-8') == b'\xe6\xb0\xb8\xe9\xac\xa8'
    assert to_bytes(b'\xe6\xb0\xb8\xe9\xac\xa8', encoding='utf-8') == b'\xe6\xb0\xb8\xe9\xac\xa8'

    assert to_bytes(u'\u6c38a\u9060', encoding='utf-8', errors='replace') == b'\xe6\xb0\xb8a\xe9\xac\xa8'

# Generated at 2022-06-22 22:06:18.782612
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Convert byte string keys and values
    d = {b'a': b'b'}
    assert container_to_bytes(d) == {b'a': b'b'}

    # Convert text string keys and values
    d = {u'a': u'b'}
    assert container_to_bytes(d) == {b'a': b'b'}

    # Convert text string keys and values with a surrogate
    d = {u'a': u'\uFFFD'}
    assert container_to_bytes(d) == {b'a': b'\xef\xbf\xbd'}

    # Convert a list
    d = [b'a', u'b']
    assert container_to_bytes(d) == [b'a', b'b']

    # Convert a tuple

# Generated at 2022-06-22 22:06:29.874621
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_dict_unicode = {'1': u'string1', u'2': 'string2',
                         '3': {u'string1': {u'string2': 'string3'}},
                         '4': [1, 2, '3', u'string4'],
                         '5': ([u'string1'], 'string2', 'string3')}
    test_dict_str = {'1': b'string1', b'2': 'string2',
                     '3': {b'string1': {b'string2': 'string3'}},
                     '4': [1, 2, '3', b'string4'],
                     '5': ([b'string1'], 'string2', 'string3')}

    # container_to_bytes with default values
   

# Generated at 2022-06-22 22:06:42.062748
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({u'foo': u'bar'}) == {b'foo': b'bar'}
    assert container_to_bytes({u'foo': u'bar'}, encoding='ascii') == {b'foo': b'bar'}
    assert container_to_bytes([u'foo', u'bar']) == [b'foo', b'bar']
    assert container_to_bytes([u'foo', u'b\xe4r']) == [b'foo', b'b\xc3\xa4r']
    assert container_to_bytes([u'foo', u'b\xe4r'], encoding='latin-1') == [b'foo', b'b\xe4r']
    assert container_to_bytes(u'b\xe4r', encoding='latin-1') == b

# Generated at 2022-06-22 22:06:50.108324
# Unit test for function container_to_bytes
def test_container_to_bytes():
    data = dict(a=1, b=2)
    b = container_to_bytes(data)
    assert isinstance(b.get(to_bytes('a')), int)
    assert isinstance(b.get(to_bytes('b')), int)

    data = dict(a=1, b=dict(c=2, d=3))
    b = container_to_bytes(data)
    assert isinstance(b.get(to_bytes('a')), int)
    b = b.get(to_bytes('b'))
    assert isinstance(b.get(to_bytes('c')), int)
    assert isinstance(b.get(to_bytes('d')), int)

    data = [dict(a=1, b=2), dict(c=3, d=4)]
    b = container

# Generated at 2022-06-22 22:07:02.010921
# Unit test for function to_native
def test_to_native():
    import pytest
    
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    
    class MockUnicode:
        def __init__(self, value):
            self.value = value
    
        def __unicode__(self):
            return self.value
    #to_native() can take two arguments,a string,the optional encoding.
    #If the argument is a byte string,decode it to Unicode using the encoding.
    #If the argument is a Unicode string,return it unchanged.
    #If the argument is something else,convert it to a string using str()

# Generated at 2022-06-22 22:07:11.882906
# Unit test for function jsonify
def test_jsonify():
    data = {'mystring': u'\u1234',
            'myfloat': 3.14,
            'myunicode': u'\u2345',
            'mybool': True}
    assert jsonify(data) == '{"mystring": "\\u1234", "myfloat": 3.14, "myunicode": "\\u2345", "mybool": true}'
    assert jsonify(data, indent=4) == '{\n    "mystring": "\\u1234", \n    "myfloat": 3.14, \n    "myunicode": "\\u2345", \n    "mybool": true\n}'

# Generated at 2022-06-22 22:07:22.172113
# Unit test for function to_bytes
def test_to_bytes():
    # NOTE: This function doesn't test surrogate_then_replace error handler.
    # That's because it's only intended to be used internally.
    # Callers need to handle all errors themselves.

    # Caller passes byte string, returns a byte string
    assert to_bytes(b'foo', nonstring='passthru') == b'foo'
    assert to_bytes(b'\xff', nonstring='passthru') == b'\xff'

    # Caller passes text string, returns a byte string
    assert to_bytes('foo', nonstring='passthru') == b'foo'
    assert to_bytes(u'foo', nonstring='passthru') == b'foo'
    assert to_bytes(u'\N{SNOWMAN}', nonstring='passthru') == b'\xe2\x98\x83'

   

# Generated at 2022-06-22 22:07:30.496593
# Unit test for function to_bytes
def test_to_bytes():
    pass
    # FIXME: Add unit tests
    #assert to_bytes('abc123') == b'abc123'
    #assert to_bytes('\u1234') == b'\xe1\x88\xb4'
    #assert to_bytes('\u1234', encoding='latin-1') == b'\x88\xb4'
    #assert to_bytes('\u1234', encoding='ascii') == b'?'
    #assert to_bytes('\u1234', encoding='latin-1', errors='surrogate_or_strict') == b'?'
    #assert to_bytes('\u1234', encoding='latin-1', errors='surrogate_or_replace') == b'?'
    #assert to_bytes('\u1234', encoding='latin-1', errors='sur

# Generated at 2022-06-22 22:07:43.188315
# Unit test for function to_bytes
def test_to_bytes():
    # testing default values
    assert to_bytes(b'\x80\xff') == b'\x80\xff'

    # testing text
    assert to_bytes(u'\x80\xff') == u'\x80\xff'.encode('utf-8')
    assert to_bytes(u'\x80\xff'.encode('latin-1').decode('utf-8')) == u'\x80\xff'.encode('utf-8')
    assert to_bytes(u'\x80\xff'.encode('latin-1').decode('utf-8'), encoding='latin-1') == u'\x80\xff'.encode('latin-1')
    assert to_bytes(u'\u1234') == u'\u1234'.encode('utf-8')
    assert to

# Generated at 2022-06-22 22:07:52.251059
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('foo') == b'"foo"'
    assert jsonify(u'foo') == b'"foo"'
    assert jsonify(b'foo') == b'"foo"'
    assert jsonify(b'\xc3foo') == b'"\\u00c3foo"'
    assert jsonify(b'\xc3\xf8') == b'"\\u00c3\\u00f8"'
    assert jsonify({b'foo': b'bar'}) == b'{"foo": "bar"}'
    assert jsonify({u'foo': u'bar'}) == b'{"foo": "bar"}'
    assert jsonify({'foo': 'bar'}) == b'{"foo": "bar"}'

# Generated at 2022-06-22 22:08:02.016435
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Note that this doesn't test nonstrings, that is dealt with in
    # to_bytes' test.
    # This also tests that nonstrings are left alone
    encoded_text = u"\xF0\x9F\x92\xA9".encode('utf-8')
    l = [b'ascii', encoded_text, 'unicode_ascii',
         dict(a='b', c=u'\xF0\x9F\x92\xA9', d=[1, 2, 3])
        ]
    l2 = container_to_bytes(l)
    assert isinstance(l2, list)
    for v in l2[:-1]:
        assert isinstance(v, binary_type)

    # The last value is the dict, lets make sure it's properly converted
    d = l

# Generated at 2022-06-22 22:08:11.955245
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert(container_to_bytes('hi') == 'hi')
    mylist = [u'hi', u'how', u'are', u'you']
    assert(container_to_bytes(mylist) == ['hi', 'how', 'are', 'you'])

    mytuple = (u'hi', u'how', u'are', u'you')
    assert(container_to_bytes(mytuple) == ('hi', 'how', 'are', 'you'))

    mydict = {u'a':u'b', u'c':u'd'}
    assert(container_to_bytes(mydict) == {'a': 'b', 'c': 'd'})


# Generated at 2022-06-22 22:08:21.683001
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # This function is complex enough to not test directly, so we're testing
    # that it produces the same thing as calling to_bytes on each item in every
    # container
    data1 = {
        'simple': 'value',
        'list': [1, 2, 3, {'key': 'val'}],
        'tuple': (1, 2, 3, {'key': 'val'}),
        'latin-1': b'something latin-1 \xe9 encoded',
        'utf-8': b'something utf-8 \xc3\xa9 encoded',
    }

    data2 = copy.deepcopy(data1)

    data1['latin-1'] = to_text(data1['latin-1'], encoding='latin-1')

# Generated at 2022-06-22 22:08:26.779354
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b"foo") == b"foo"
    assert to_bytes("foo") == b"foo"
    assert to_bytes("foo".encode("utf-8")) == b"foo"
    assert to_bytes("föö".encode("latin-1"), encoding="latin-1") == b'f\xf6\xf6'
    assert to_bytes("föö".encode("utf-8"), encoding="utf-8", errors="surrogate_or_replace") == b'f\xf6\xf6'
    assert to_bytes("föö".encode("utf-8"), encoding="utf-8", errors="surrogate_or_strict") == b'f\xf6\xf6'

# Generated at 2022-06-22 22:08:37.720180
# Unit test for function container_to_bytes
def test_container_to_bytes():
    a = {'a': 'abc', 'b': ['abc', {'c': 'abc'}, 'def', (1, 2)], 'c': 'def'}
    b = container_to_bytes(a)
    assert isinstance(b['a'], binary_type)
    assert isinstance(b['b'][0], binary_type)
    assert isinstance(b['b'][1]['c'], binary_type)
    assert isinstance(b['c'], binary_type)
    assert isinstance(b['b'][2], binary_type)
    assert isinstance(b['b'][3][0], int)
    assert isinstance(b['b'][3][1], int)


# Generated at 2022-06-22 22:08:46.432560
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test for container_to_bytes for json return
    json_data = {
        'foo': {
            'bar': ['baz', 'qux'],
            'corge': None,
            'grault': 1,
            'garply': 2.0,
            'waldo': True,
            'fred': False,
        },
        'quux': 'hello',
    }
    ansible_data = json.loads(jsonify(json_data))

    if PY3:
        # These should all be the same format
        assert isinstance(ansible_data, dict)
        assert isinstance(ansible_data['foo'], dict)
        assert isinstance(ansible_data['foo']['bar'], list)

# Generated at 2022-06-22 22:08:54.336977
# Unit test for function to_native
def test_to_native():
    b_utf8 = b'\xc3\xa9'
    b_utf8_2 = to_bytes(b_utf8)
    assert isinstance(b_utf8_2, binary_type)
    assert b_utf8 == b_utf8_2
    assert isinstance(b_utf8_2, binary_type)

    t_utf8 = u'\u00e9'
    t_utf8_2 = to_text(t_utf8)
    assert isinstance(t_utf8_2, text_type)
    assert t_utf8 == t_utf8_2
    assert isinstance(t_utf8_2, text_type)

    b_latin1 = b'\xe9'

# Generated at 2022-06-22 22:09:02.807057
# Unit test for function to_native
def test_to_native():
    """Test to_native() function against a variety of inputs and assertions
    """

    from ansible.module_utils._text import to_native
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.unicode import unicode_wrap

    # Test binary strings
    assert u'foo' == to_native(u'foo'.encode("utf-8"))
    assert u'foo' == to_native(u'foo'.encode("utf-16"))
    assert u'foo' == to_native(u'foo'.encode("utf-32"))

    # Test text strings
    assert u'foo' == to_native(u'foo')
    assert u'foo' == to_native(unicode_wrap(u'foo'))

# Generated at 2022-06-22 22:09:14.562939
# Unit test for function to_native
def test_to_native():
    '''
    Test: to_native
    '''
    assert 'baz' == to_native('baz')
    assert 'foo' == to_native(b'foo')
    assert 'foo' == to_native(b'foo'.decode())
    assert 'bar' == to_native(b'bar'.decode(errors='surrogate_or_strict'))
    assert 'foo' == to_native(b'foo'.decode(), errors='surrogate_or_strict')
    assert 'foo' == to_native(u'foo', errors='surrogate_or_strict')

    assert 'bar' == to_native(b'bar'.decode(errors='surrogate_or_replace'))

# Generated at 2022-06-22 22:09:24.516656
# Unit test for function container_to_bytes
def test_container_to_bytes():
    data = {
        'a': 'a',
        'a_string': 'b',
        'a_bytestring': b'byte',
        'a_dict': {
            'a': 'a',
            'a_string': 'b',
            'a_bytestring': b'byte',
            'a_dict': {'a': 'a'}
        },
        'a_list': ['a', 'a', b'byte', {'a': 'a'}],
        'a_tuple': ('a', 'a', b'byte', {'a': 'a'})
    }
    data = container_to_bytes(data)
    assert isinstance(data.get('a'), binary_type)
    assert isinstance(data.get('a_string'), binary_type)

# Generated at 2022-06-22 22:09:32.034177
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert isinstance(container_to_bytes(1), int)
    assert isinstance(container_to_bytes('1'), binary_type)
    assert isinstance(container_to_bytes(u'1'), binary_type)
    assert isinstance(container_to_bytes({'foo': u'bar'}), dict)
    assert isinstance(container_to_bytes({'foo': u'bar'}).get('foo'), binary_type)
    assert isinstance(container_to_bytes([u'foo', u'bar']), list)
    assert isinstance(container_to_bytes([u'foo', u'bar'])[0], binary_type)
    assert isinstance(container_to_bytes((u'foo', u'bar')), tuple)

# Generated at 2022-06-22 22:09:41.537239
# Unit test for function to_native
def test_to_native():
    assert to_native(123, nonstring='passthru') == 123
    assert to_native(u'unicode', nonstring='passthru') == u'unicode'
    assert to_native(u'unicode') == 'unicode'
    assert to_native('unicode') == 'unicode'
    assert to_native(b'bytes') == 'bytes'
    assert to_native(123, errors='surrogate_or_strict') == 123
    assert to_native(u'unicode', errors='surrogate_or_strict') == u'unicode'
    assert to_native(u'unicode', errors='surrogate_or_replace') == u'unicode'
    assert to_native('unicode', errors='surrogate_or_strict') == 'unicode'
    assert to_

# Generated at 2022-06-22 22:09:53.343629
# Unit test for function container_to_text
def test_container_to_text():
    from collections import namedtuple

    assert container_to_text(1) == 1
    assert container_to_text(u'\u1234') == u'\u1234'
    assert container_to_text(b'\xe4\xb8\xad') == u'\u4e2d'
    assert container_to_text({u'\u1234': b'\xe4\xb8\xad', u'\u4321': b'\xe4\xb8\xad'}) == {u'\u1234': u'\u4e2d', u'\u4321': u'\u4e2d'}
    assert container_to_text(['\xc3\xa9']) == [u'\u00e9']

# Generated at 2022-06-22 22:10:04.377489
# Unit test for function container_to_text
def test_container_to_text():
    values = {'a':1, u'hi': 2, 'c': 'hi'}
    encoded_values = container_to_text(values)
    if encoded_values != {'a':1, 'hi': 2, 'c': 'hi'}:
        raise Exception(encoded_values)
    encoded_values = container_to_text(values, errors='surrogate_or_replace')
    if encoded_values != {'a':1, 'hi': 2, 'c': 'hi'}:
        raise Exception(encoded_values)
    encoded_values = container_to_text(values, errors='surrogate_or_strict')
    if encoded_values != {'a':1, 'hi': 2, 'c': 'hi'}:
        raise Exception(encoded_values)
    encoded_values = container_to

# Generated at 2022-06-22 22:10:16.501291
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\xe4\xf6\xfc') == u'"\xe4\xf6\xfc"'
    assert jsonify({u'\xe4\xf6\xfc': u'\xe4\xf6\xfc'}) == '{"\xe4\xf6\xfc": "\xe4\xf6\xfc"}'
    assert jsonify({u'\xe4\xf6\xfc': u'\xe4\xf6\xfc'}) == '{"\xe4\xf6\xfc": "\xe4\xf6\xfc"}'
    data = {"a": u"\xe4\xf6\xfc"}
    assert jsonify(data, sort_keys=True) == '{"a": "\xe4\xf6\xfc"}'

# Generated at 2022-06-22 22:10:28.696976
# Unit test for function container_to_bytes
def test_container_to_bytes():
    list_of_dicts = [
        {"a" : "1", u"b" : u"2"},
        {u"a" : u"3", "b" : "4"},
        {"a" : [1, 2, 3]},
        {u"a" : (1, 2, 3)},
    ]
    byte_dicts = container_to_bytes(list_of_dicts)
    for byte_dict in byte_dicts:
        for key, value in iteritems(byte_dict):
            assert isinstance(key, binary_type)
            # Lists and tuples are not recursively converted
            if isinstance(value, (text_type, list, tuple)):
                continue
            assert isinstance(value, binary_type)


# Generated at 2022-06-22 22:10:42.210890
# Unit test for function container_to_text
def test_container_to_text():
    # Non recursive object
    byte_string = b'ThisIsAByteString'
    text_string = u'ThisIsATextString'
    number = 1
    unicode_string = u'\u2713'

    assert container_to_text(byte_string) == text_string
    assert container_to_text(text_string) == text_string
    assert container_to_text(number) == number
    assert container_to_text(unicode_string) == unicode_string

    # Recursive object
    list_of_strings = [byte_string, text_string, number, unicode_string]
    assert container_to_text(list_of_strings) == [text_string, text_string, number, unicode_string]


# Generated at 2022-06-22 22:10:54.977914
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text("ascii") == u"ascii"
    assert container_to_text("\xe7") == u"\xe7"
    assert container_to_text("\xff") == u"\ufffd"
    assert container_to_text("\xe7\xff") == u"\xe7\ufffd"
    assert container_to_text("\xff\xe7") == u"\ufffd\xe7"
    assert container_to_text("\xe7\xff\xe7") == u"\xe7\ufffd\xe7"
    assert container_to_text("\xe7\xff", 'latin-1') == u"\xe7\x00"
    assert container_to_text("\xe7", 'latin-1') == u"\xe7"

# Generated at 2022-06-22 22:11:03.477734
# Unit test for function to_native
def test_to_native():
    try:
        codecs.lookup_error('surrogateescape')
        surrogate_escape = True
    except LookupError:
        surrogate_escape = False

    # valid utf-8 text.  should be returned as unicode
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native('\xe2\x9c\x93') == u'\u2713'

    # valid latin-1 text.  should be returned as unicode
    assert to_native(u'\xa9') == u'\xa9'
    assert to_native('\xa9') == u'\xa9'

    # invalid utf-8 text with surrogateescape error handler
    if surrogate_escape:
        assert to_native('\xff') == u'\udcff'


# Generated at 2022-06-22 22:11:15.067185
# Unit test for function to_bytes

# Generated at 2022-06-22 22:11:24.671966
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(1) == 1
    assert container_to_text(u"foo") == u"foo"
    assert container_to_text({"foo": "bar"}) == {"foo": "bar"}
    assert container_to_text({"foo": "bar"}) != {"foo": "bad"}
    assert container_to_text({"foo": "bar"})["foo"] == "bar"
    assert container_to_text(["foo", "bar"]) == ["foo", "bar"]
    assert container_to_text(["foo", "bar"]) != ["foo", "bad"]
    assert container_to_text(["foo", "bar"])[1] == "bar"
    assert container_to_text(("foo", "bar")) == ("foo", "bar")

# Generated at 2022-06-22 22:11:28.418347
# Unit test for function jsonify
def test_jsonify():
    data = {'test':'123', u'pi': 3.141592653589793}
    # Show that all values are accepted with utf-8
    for value in data.values():
        jsonify({value:value})


# Generated at 2022-06-22 22:11:40.544925
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'a', 'b': 'b', 'c': {'c1': 'test', 'c2': [1, 2, 3]}, 'd': [4, 5, 6]}
    assert jsonify(data) == json.dumps(data, default=_json_encode_fallback)
    # Test for container_to_text
    data_list = ['a', 'b', 'c']
    assert jsonify(data_list) == json.dumps(data_list, default=_json_encode_fallback)
    data_unicode = {'a': u'\u00e9'}
    assert jsonify(data_unicode) == json.dumps(data_unicode, default=_json_encode_fallback, encoding='utf-8')

