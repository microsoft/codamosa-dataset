

# Generated at 2022-06-22 22:01:49.547937
# Unit test for function container_to_bytes
def test_container_to_bytes():  # pylint: disable=too-many-statements
    ''' Unit test for function container_to_bytes '''

    # Test invalid input
    invalid_inputs = [None, 2]
    for invalid in invalid_inputs:
        try:
            container_to_bytes(invalid)
        except Exception as e:
            assert(isinstance(e, TypeError))
        else:
            assert(0)  # Error expected

    # Test byte string inputs
    byte_inputs = [b'1', b'1\xe2\x99\xa5']
    for byte_in in byte_inputs:
        assert(type(container_to_bytes(byte_in)) == bytes)
        assert(type(container_to_bytes(byte_in, encoding='ascii')) == bytes)

    # Test text string

# Generated at 2022-06-22 22:02:01.930873
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('testing') == b'testing'
    assert to_bytes(u'testing') == b'testing'
    assert to_bytes(u'ünicøde') == b'\xc3\xbcnic\xc3\xb8de'
    assert to_bytes(u'ünicøde', errors='strict') == b'\xc3\xbcnic\xc3\xb8de'
    assert to_bytes(u'ünicøde', errors='surrogate_or_strict') == b'\xc3\xbcnic\xc3\xb8de'
    assert to_bytes(u'ünicøde', errors='surrogate_or_replace') == b'\xc3\xbcnic\xc3\xb8de'

# Generated at 2022-06-22 22:02:14.885828
# Unit test for function to_bytes
def test_to_bytes():
    # Non-strings
    assert to_bytes(5, nonstring='simplerepr') == b'5'
    if PY3:
        assert to_bytes(b'5', nonstring='simplerepr') == b"b'5'"
    else:
        assert to_bytes(b'5', nonstring='simplerepr') == b"'5'"
    assert to_bytes(5, nonstring='passthru') == 5
    assert to_bytes(5, nonstring='empty') == b''
    try:
        to_bytes(5, nonstring='strict')
        assert False, 'to_bytes(5, nonstring=\'strict\') did not raise TypeError as expected.'
    except TypeError:
        pass

    # Basic latin-1 text

# Generated at 2022-06-22 22:02:22.159140
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(b'\xde\xad\xbe\xef') == u'\udeadbeef'
    assert container_to_text(u'\udeadbeef') == u'\udeadbeef'
    assert container_to_text(b'\xde\xad\xbe\xef', errors='surrogate_then_replace') == u'\ufffd\ufffd\ufffd\ufffd'
    assert container_to_text([b'\xde\xad\xbe\xef']) == [u'\udeadbeef']

# Generated at 2022-06-22 22:02:29.324956
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({u'foo': u'bar'}) == {b'foo': b'bar'}
    assert container_to_bytes(u'foo') == b'foo'
    assert container_to_bytes([u'bar', b'foo']) == [b'bar', b'foo']
    assert container_to_bytes((u'bar', b'foo')) == (b'bar', b'foo')



# Generated at 2022-06-22 22:02:39.093788
# Unit test for function to_native
def test_to_native():
    try:
        unicode_string = unicode
    except NameError:
        unicode_string = str

    assert to_native(None) == 'None'
    assert to_native(str(None)) == 'None'
    assert to_native(u'foo') == 'foo'
    assert isinstance(to_native(u'foo'), str)
    assert to_native(u'foo'.encode('utf-8')) == 'foo'
    assert isinstance(to_native(u'foo'.encode('utf-8')), str)
    assert to_native(b'foo') == 'foo'
    assert isinstance(to_native(b'foo'), str)
    assert to_native(b'foo', errors='surrogate_or_strict') == 'foo'

# Generated at 2022-06-22 22:02:48.349527
# Unit test for function to_bytes

# Generated at 2022-06-22 22:03:00.409718
# Unit test for function container_to_text
def test_container_to_text():
    '''Unit test for function container_to_text'''
    test = {'key': [1, 2, 3],
            'other_key': (4, 5, 6),
            'and_another': {'and': 'another'}}
    utf8_encoded_test = {b'key': [1, 2, 3],
                         b'other_key': (4, 5, 6),
                         b'and_another': {b'and': b'another'}}
    latin1_encoded_test = {b'key': [1, 2, 3],
                           b'other_key': (4, 5, 6),
                           b'and_another': {b'and': b'another'}}

    json_test = jsonify(test)

# Generated at 2022-06-22 22:03:11.880242
# Unit test for function container_to_text
def test_container_to_text():
    unicode_str = u'\u00e9'
    unicode_item = (('key1', u'unicode str \u00e9'),
                    ('key2', unicode_str),
                    ('key3', unicode_str.encode('utf-8')))
    unicode_dict = dict(unicode_item)
    unicode_list = [unicode_dict, unicode_dict]
    unicode_tuple = (unicode_dict, unicode_dict)

    # Test unicode string
    if PY3:
        assert unicode_str == container_to_text(unicode_str)
    else:
        assert unicode_str.encode('utf-8') == container_to_text(unicode_str)

    # Test unicode list

# Generated at 2022-06-22 22:03:23.428060
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert isinstance(container_to_bytes(u'asdf'), binary_type)
    assert isinstance(container_to_bytes({u'a': u'b'}), dict)
    assert isinstance(container_to_bytes({u'a': u'b'}).keys()[0], binary_type)
    assert isinstance(container_to_bytes({u'a': u'b'}).values()[0], binary_type)
    assert isinstance(container_to_bytes([u'a', u'b']), list)
    assert isinstance(container_to_bytes([u'a', u'b'])[0], binary_type)
    assert isinstance(container_to_bytes((u'a', u'b')), tuple)

# Generated at 2022-06-22 22:03:26.783478
# Unit test for function jsonify
def test_jsonify():
    def base(data):
        try:
            json.dumps(data)
        except TypeError:
            return False
        return True
    #AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    assert jsonify(module)
    #Set
    assert base(jsonify(Set()))
    #Datetime
    import datetime
    d = datetime.datetime(year=2016, month=8, day=12, hour=0, minute=0, second=0)
    assert base(jsonify(d))
    #End of function test_jsonify



# Generated at 2022-06-22 22:03:34.391926
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(u"foo") == u"foo"
    assert container_to_text(b"\u20ac") == u"€"
    assert container_to_text(b"\xc3\xa9") == u"é"
    assert container_to_text(u"foo", errors='strict') == u"foo"
    assert container_to_text(u"foo\xe9", errors='strict') == u"fooé"

# Generated at 2022-06-22 22:03:46.029432
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text({"key1": u"val1", "key2": 2, "key3": b"val3"}) == {"key1": u"val1", "key2": 2, "key3": u"val3"}
    assert container_to_text([u"val1", b"val2"]) == [u"val1", u"val2"]
    assert container_to_text((u"val1", b"val2")) == (u"val1", u"val2")
    # Test that container_to_text does not change encoding for non-string values
    assert "1" == container_to_text(1)
    assert 1 == container_to_text(1)
    assert 1.1 == container_to_text(1.1)
    assert None == container_to_text(None)


# Generated at 2022-06-22 22:03:55.560328
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_native
    import ansible.module_utils as utils
    # dict
    x = dict(a=8, b='foo')
    assert jsonify(x) == '{"a": 8, "b": "foo"}'

    # list
    x = [1, 2, 3]
    assert jsonify(x) == '[1, 2, 3]'

    # set
    x = set(x)
    assert jsonify(x) == '[1, 2, 3]'

    # frozenset
    x = frozenset(x)
    assert jsonify(x) == '[1, 2, 3]'

    # object with __str__
    class Foo(object):
        def __str__(self):
            return 'bar'

    x = Foo()

# Generated at 2022-06-22 22:04:00.950037
# Unit test for function container_to_text
def test_container_to_text():
    _test_container_to_text_unicode_keys(u'ascii')
    try:
        _test_container_to_text_unicode_keys(u'utf-8')
    except UnicodeDecodeError:
        # ANSIBLE_PY3_NO_BYTES
        pass


# Generated at 2022-06-22 22:04:09.101747
# Unit test for function to_native
def test_to_native():
    for _input, output in (
        # Test binary strings
        (b'hello', 'hello'),
        (b'hello\xe4', 'hello\xe4'),
        # Test text strings
        (u'hello', 'hello'),
        (u'hello\xe4', 'hello\xe4'),
        # Test nonstring conversions
        (1, '1'),
        (1.5, '1.5'),
        (None, 'None'),
    ):
        assert to_native(_input) == output



# Generated at 2022-06-22 22:04:21.838470
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'string') == b'string'
    # b'\xe9' is a valid utf-8 encoding of the latin-1 character with
    # ordinal 0xe9.
    assert to_bytes(b'\xe9') == b'\xe9'
    # b'\xff' is a invalid utf8 encoding
    assert to_bytes(b'\xff') == b'\xff'
    if PY3:
        assert to_bytes('\udcff') == b'\xed\xb3\xbf'
        assert to_bytes('\U0001D4B6') == b'\xf0\x9d\x92\xb6'
    else:
        assert to_bytes(u'\udcff') == b'\xed\xb3\xbf'

# Generated at 2022-06-22 22:04:33.609987
# Unit test for function jsonify
def test_jsonify():
    # Test for string value
    test_data = {"a":"\xe9"}
    result_data = jsonify(test_data)
    assert result_data == "{\"a\": \"\u00e9\"}"
    # Test for list value
    test_data = {"a": ["\xe9", "\xe9"]}
    result_data = jsonify(test_data)
    assert result_data == "{\"a\": [\"\u00e9\", \"\u00e9\"]}"
    # Test for dict value
    test_data = {"a": {"b":"\xe9"}}
    result_data = jsonify(test_data)
    assert result_data == "{\"a\": {\"b\": \"\u00e9\"}}"
    # Test for nested dict value

# Generated at 2022-06-22 22:04:45.716540
# Unit test for function to_bytes
def test_to_bytes():
    # validate that surrogate_then_replace really does what we expect.
    # Note that this isn't a true unit test.  It's more of a regression test
    # to make sure that it doesn't traceback on a non-utf8 encoding

    if HAS_SURROGATEESCAPE:
        non_utf8_encoding = 'ascii'
    else:
        non_utf8_encoding = 'utf-8'

    # No surrogates
    assert to_bytes(u'foo', non_utf8_encoding, errors=None) == u'foo'.encode(non_utf8_encoding)
    assert to_bytes(u'foo', non_utf8_encoding, errors='surrogate_or_replace') == u'foo'.encode(non_utf8_encoding)

# Generated at 2022-06-22 22:04:51.973138
# Unit test for function to_bytes
def test_to_bytes():
    def f(obj, encoding='utf-8', errors='surrogate_then_replace', nonstring='simplerepr'):
        return to_bytes(obj, encoding, errors, nonstring)
    yield f, None, 'None is not a string'
    yield f, u'\U000abcde', 'utf-8', 'surrogate_then_replace', 'simplerepr'



# Generated at 2022-06-22 22:04:54.872844
# Unit test for function jsonify
def test_jsonify():
    jsonify({u'\xe7': u'foo'}, ensure_ascii=False)
    jsonify({u'\xe7': u'foo'})



# Generated at 2022-06-22 22:04:58.701104
# Unit test for function jsonify
def test_jsonify():
    data = dict(a=u'\u2019', b=u'\u0915', c=u'\u093F', d=u'\u0905\u094B', e=u'\u0914', f=u'\u092C')
    assert jsonify(data)



# Generated at 2022-06-22 22:05:10.585322
# Unit test for function to_native
def test_to_native():

    def _t_over_t(obj, encoding='utf-8', errors='surrogate_or_replace'):
        """Runs to_text on the text version of the object and returns it."""
        return to_text(to_text(obj, encoding=encoding, errors=errors), encoding=encoding, errors=errors)

    def _b_over_b(obj, encoding='utf-8', errors='surrogate_or_replace'):
        """Runs to_bytes on the bytes version of an object and returns it"""
        return to_bytes(to_bytes(obj, encoding=encoding, errors=errors), encoding=encoding, errors=errors)


# Generated at 2022-06-22 22:05:21.665622
# Unit test for function container_to_bytes
def test_container_to_bytes():
    data = {'d1': u'\u4e2d\u6587', 'd2': [u'\u4e2d\u6587']}
    rtn = container_to_bytes(data, encoding=u'utf-8', errors=u'surrogate_or_strict')
    assert_equal(rtn, {'d1': '\xe4\xb8\xad\xe6\x96\x87', 'd2': ['\xe4\xb8\xad\xe6\x96\x87']})

    rtn = container_to_bytes(data, encoding=u'ascii', errors=u'surrogate_or_replace')
    assert_equal(rtn, {'d1': '???', 'd2': ['???']})


# Generated at 2022-06-22 22:05:33.087957
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'foo', nonstring='passthru') == u'foo'
    assert to_native(b'foo', nonstring='passthru') == b'foo'
    assert to_native(b'foo', nonstring='strict') == u'foo'
    assert to_native(None, nonstring='strict') == None
    try:
        to_native(42, nonstring='strict')
    except TypeError:
        pass
    else:
        assert False, "to_native with strict nonstring failed to raise TypeError"



# Generated at 2022-06-22 22:05:42.973462
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, jsonify

    # AnsibleModule.fail_json requires a byte string, not a unicode string.
    # Forcing unicode conversion is incorrect.
    def fail_json(obj):
        raise Exception(to_bytes(jsonify(obj)))

    m = AnsibleModule({})
    m.fail_json = fail_json

    try:
        m.fail_json({'a': 'hello', u'b\xc3\xa9': u'world'})
        raise AssertionError('Expected exception not raised')
    except Exception as e:
        assert to_bytes('{"a": "hello", "b\\u00e9": "world"}') in to_bytes(e)

    # See #8

# Generated at 2022-06-22 22:05:54.706275
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils._text import to_bytes

    assert to_bytes('foobar') == b'foobar'
    assert to_bytes('føø') == b'f\xc3\xb8\xc3\xb8'
    assert to_bytes(u'føø') == b'f\xc3\xb8\xc3\xb8'
    assert to_bytes(u'føø', nonstring='passthru') == u'føø'
    assert to_bytes(u'føø', nonstring='empty') == b''
    assert to_bytes(u'føø', nonstring='strict') == b'f\xc3\xb8\xc3\xb8'

# Generated at 2022-06-22 22:05:59.969211
# Unit test for function to_native
def test_to_native():
    """ Test the to_native function with these test cases:
        0. We should be able to handle invalid unicode characters
           passed in.
    """
    # Handle invalid unicode characters
    test_string = '\x80abcd'
    if PY3:
        assert to_native(test_string) == b'\xef\xbf\xbdabcd'
    else:
        assert to_native(test_string) == '\x80abcd'



# Generated at 2022-06-22 22:06:07.651010
# Unit test for function to_bytes
def test_to_bytes():

    # This tests to_bytes with three parameters and
    # these are the only tests explaing the details of
    # the function. The other tests will just exercise the
    # other to_bytes functions.

    # Unicode strings are transformed.
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes(u'привет') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Byte strings are simply returned unchanged
    assert to_bytes(b'hello') == b'hello'
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82')

# Generated at 2022-06-22 22:06:17.927494
# Unit test for function container_to_text
def test_container_to_text():
    import sys
    if sys.version_info < (3, 0):
        b_unicode = b'\xc3\xa9'
        assert to_text(b_unicode) == u'\xe9'
        assert to_text(u'\xe9') == u'\xe9'
        assert to_text(1) == u'1'
        assert jsonify(dict(a=b_unicode)) == b'{"a": "\xc3\xa9"}'
        assert jsonify(dict(a=u'\xe9')) == b'{"a": "\xc3\xa9"}'
        assert jsonify(dict(a=1)) == b'{"a": 1}'
        assert container_to_text(dict(a=b_unicode)) == {u'a': u'\xe9'}


# Generated at 2022-06-22 22:06:23.056752
# Unit test for function container_to_bytes

# Generated at 2022-06-22 22:06:27.464382
# Unit test for function container_to_text
def test_container_to_text():
    # str is returned
    assert "simple plain str" == container_to_text("simple plain str")
    # bytes are converted to str
    assert u"simple plain str" == container_to_text(b"simple plain str")
    # invalid bytes are converted to str with surrogate_or_strict handler
    assert u"simple plain str\udce4" == container_to_text(b"simple plain str\xf4")
    assert "simple plain str\ufffd" == container_to_text(b"simple plain str\xf4", encoding="ascii")

    # list is recursed
    assert [1, 2, 3] == container_to_text([1, 2, 3])
    assert [1, 2, 3] == container_to_text([1, 2, b"3"])

# Generated at 2022-06-22 22:06:39.969186
# Unit test for function container_to_bytes
def test_container_to_bytes():
    some_dict = {u'bytes': b'\xe5\xb8\x82', u'str': u'\u5e02', u'unicode': u'\u5e02'}

    res = container_to_bytes(some_dict, encoding='latin-1', errors='replace')
    assert to_bytes(u'\ufffd') in res['bytes']
    assert to_bytes(u'\u5e02') in res['unicode']

    res = container_to_bytes(some_dict, encoding='latin-1', errors='strict')
    assert to_bytes(u'\u5e02') in res['unicode']

# Generated at 2022-06-22 22:06:52.123810
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.six import text_type, binary_type

    # Note: We define these inner functions so that we can refer to them in the docstring below
    def test_simplerepr(v):
        return to_bytes(v, nonstring='simplerepr')

    def test_passthru(v):
        return to_bytes(v, nonstring='passthru')

    def test_empty(v):
        return to_bytes(v, nonstring='empty')

    def test_strict(v):
        return to_bytes(v, nonstring='strict')

    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(text_type('føø')) == b'f\xc3\xb8\xc3\xb8'

# Generated at 2022-06-22 22:07:03.992337
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Json only handles lists, dicts, tuples
    # Other test cases are covered by to_bytes tests
    # also including ints and None to handle json output
    data = {
        u'test': u'ascii',
        u'\u00fcnic\u00f8de': u'utf-8',
        u'\u00fcnic\u00f8de'.encode('utf-8'): u'utf-8 encoded str',
        u'list': [u'utf-8', 1, True, None],
        u'dict': {u'utf-8': u'utf-8', 1: 1, True: True, None: None},
        u'tuple': (u'utf-8', 1, True, None),
    }


# Generated at 2022-06-22 22:07:14.166907
# Unit test for function to_native
def test_to_native():
    assert to_native(b'asdf', None, None, None) == b'asdf'
    assert to_native(b'asdf', 'utf-8', 'strict', 'simplerepr') == b'asdf'
    assert to_native(b'asdf', 'ascii', 'strict', 'simplerepr') == b'asdf'
    assert to_native(b'asdf', 'utf-8', 'strict', 'simplerepr') == b'asdf'
    assert to_native(b'asdf', 'ascii', 'strict', 'simplerepr') == b'asdf'
    assert to_native(b'asdf', 'utf-8', 'surrogateescape', 'simplerepr') == b'asdf'

# Generated at 2022-06-22 22:07:24.515616
# Unit test for function container_to_text
def test_container_to_text():
    import json
    import os

    # A dict of str to dict
    test = {'dict': {'cat': 'dog'}, 'list': [1, 2, 3],
            'tuple': (True, False)}

    # Test str to text
    #  utf-8
    pass_data = json.dumps(test, encoding='utf-8')
    pass_data = json.loads(pass_data, encoding='utf-8')
    assert_equal(pass_data, container_to_text(pass_data))

    # Test text to str
    pass_data = json.dumps(test, encoding='utf-8')
    pass_data = json.loads(pass_data, encoding='latin-1')
    assert_equal(pass_data, container_to_text(pass_data))

    # Test a

# Generated at 2022-06-22 22:07:25.760848
# Unit test for function jsonify
def test_jsonify():
    assert jsonify("string") == "\"string\""


# Generated at 2022-06-22 22:07:32.556431
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('abc') == b'abc'

    # Test surrogate_or_strict
    if HAS_SURROGATEESCAPE:
        assert to_bytes(u'\uDC80\uDCFF') == b'\x80\xFF'
        assert to_bytes(u'\uDC80\uDCFF', errors='surrogate_or_strict') == b'\x80\xFF'
        assert to_bytes(u'\uDC80\uDCFF', errors='surrogate_then_replace') == b'\x80\xFF'
    else:
        try:
            to_bytes(u'\uDC80\uDCFF', errors='surrogate_or_strict')
        except UnicodeEncodeError:
            pass

# Generated at 2022-06-22 22:07:45.240833
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert '艾伦' == to_text(container_to_bytes([u"艾伦"])[0])
    assert '艾伦' == to_text(container_to_bytes((u"艾伦",))[0])
    assert '艾伦' == to_text(container_to_bytes({"name": u"艾伦"})["name"])
    assert '艾伦' == to_text(container_to_bytes({"name": [u"艾伦"]})["name"][0])
    assert '艾伦' == to_text(container_to_bytes({"name": (u"艾伦",)})["name"][0])



# Generated at 2022-06-22 22:07:53.408304
# Unit test for function jsonify
def test_jsonify():
    obj = {u'key': u'\u4f60\u597d'.encode('utf8')}
    assert jsonify(obj) == '{"key": "\\u4f60\\u597d"}'
    # Test the scenario that obj is a python 2 unicode string which can be utf8 encoded.
    obj = u'\u4f60\u597d'
    assert jsonify(obj) == '"\\u4f60\\u597d"'
    # Test the scenario that obj is a python 2 unicode string which can only be latin-1 encoded.
    obj = u'\xac\xb1\xac\xb1\xac\xb1'

# Generated at 2022-06-22 22:07:57.562240
# Unit test for function jsonify
def test_jsonify():
    dict1 = dict(a=u'\xe3', b=u'\xff', c=u'\xff\xff', d=u'\xff\xff\xff')
    data = """{"a": "\u00e3", "b": "\ufffd", "c": "\ufffd\ufffd", "d": "\ufffd\ufffd\ufffd"}"""
    assert jsonify(dict1) == data

# Generated at 2022-06-22 22:08:09.226468
# Unit test for function jsonify
def test_jsonify():
    my_dict = {"key": u'\xe2'}
    json_str = jsonify(my_dict)
    assert json_str == '{"key": "\xe2"}', "jsonify: jsonify should encode to utf-8 if possible"
    my_dict = {"key": u'\ufffd'}
    json_str = jsonify(my_dict)
    assert json_str == '{"key": "?"}', "jsonify: jsonify shouldn't fail if encoding isn't possible"
    my_dict = {"key": [u'\xe2']}
    json_str = jsonify(my_dict)
    assert json_str == '{"key": ["\xe2"]}', "jsonify: jsonify should encode lists to utf-8 if possible"

# Generated at 2022-06-22 22:08:12.891242
# Unit test for function jsonify
def test_jsonify():
    input_data = {"a_string": "a unicode string",
                  "a_set": Set([1, 2]),
                  "a_datetime": datetime.datetime.utcnow()
                  }
    data = jsonify(input_data)
    print(data)



# Generated at 2022-06-22 22:08:22.362733
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test list
    assert(container_to_bytes(['abc']) == [b'abc'])
    assert(container_to_bytes([u'\u1234']) == [b'\xe1\x88\xb4'])
    assert(container_to_bytes([1, 2, 3]) == [1, 2, 3])
    assert(container_to_bytes([[1, 2, 3]]) == [[1, 2, 3]])
    assert(container_to_bytes([[u'\u1234', 'abc']]) == [[b'\xe1\x88\xb4', b'abc']])
    assert(container_to_bytes([('a', 'b', 'c')]) == [('a', 'b', 'c')])

# Generated at 2022-06-22 22:08:34.160574
# Unit test for function container_to_text
def test_container_to_text():
    container = {'utf-8': 'utf-8'.encode('utf-8'),
                 'latin-1': 'latin-1'.encode('latin-1')}
    container = container_to_text(container, 'utf-8')
    print('container_to_text test case 1: {0}'.format(container))

    container = container_to_text(container, 'latin-1')
    print('container_to_text test case 2: {0}'.format(container))

    container = {'utf-8': 'utf-8'.encode('utf-8'),
                 'latin-1': 'latin-1'.encode('latin-1')}
    container = container_to_text(container, 'utf-8', 'surrogate_or_replace')

# Generated at 2022-06-22 22:08:43.905192
# Unit test for function container_to_text
def test_container_to_text():
    my_dict = {u'key1': 1, u'key2': '2', u'key3': 3.2}
    my_dict1 = {u'key1': 1, u'key2': '2', u'key3': 3.2, b'key4': b'4'}
    my_res = {u'key1': 1, u'key2': u'2', u'key3': 3.2}
    my_res1 = {u'key1': 1, u'key2': u'2', u'key3': 3.2, b'key4': u'4'}
    my_dict_str = {'key1': 1, 'key2': '2', 'key3': 3.2}

# Generated at 2022-06-22 22:08:52.677525
# Unit test for function container_to_text
def test_container_to_text():
    # Test dict
    dict_with_raw_bytes = {b'key1': b'value1', u'key2': u'value2'}
    assert sorted(container_to_text(dict_with_raw_bytes).keys()) == sorted([u'key1', u'key2'])
    dict_with_raw_bytes = {u'key1'.encode('utf-16-be'): b'value1', u'key2': u'value2'}
    assert sorted(container_to_text(dict_with_raw_bytes).keys()) == sorted([u'key1', u'key2'])
    dict_with_raw_bytes = {b'key1'.decode('utf-16-be'): b'value1', u'key2': u'value2'}

# Generated at 2022-06-22 22:09:02.056334
# Unit test for function to_native
def test_to_native():
    # to_native() function should be considered private and is subject to change.
    # This test is here to give a better chance that any changes to to_native
    # will be caught by unit tests.

    # In python3, all of these are native strings
    assert isinstance(to_native(u'123'), str)
    assert isinstance(to_native(b'123'), str)
    assert isinstance(to_native(123), str)
    assert isinstance(to_native(b'\xff'), str)
    assert isinstance(to_native(b'\xff'.decode('latin-1')), str)

    # but not in python2
    assert not isinstance(to_native(u'123'), binary_type)
    assert not isinstance(to_native(b'123'), text_type)

# Generated at 2022-06-22 22:09:14.101515
# Unit test for function to_bytes
def test_to_bytes():
    """
    Test for ansible.module_utils.basic.to_bytes

    This is a fairly basic test that ensures that we get the proper byte
    string back for various inputs.  It does not attempt to validate that the
    byte string is well-formed in the specified encoding.

    Don't write tests for 'surrogateescape' unless you really know what you're doing.
    Probably the only person who knows what they're doing is the same person who
    wrote the os.fsdecode docs.
    """
    # Simple string case
    assert to_bytes('hello') == b'hello'

    # Simple byte string case
    assert to_bytes(b'hello') == b'hello'

    # Note: This is nonsense given how to_bytes is expected to be used but we're
    # writing this test to make sure we do the right thing if it happens.

# Generated at 2022-06-22 22:09:24.233249
# Unit test for function to_native
def test_to_native():
    for value in [
        u'',
        u'hello world',
        u'\u2764',
        u'\u00e9',
        b'',
        u'\u2764'.encode('utf-8'),
        u'\u00e9'.encode('utf-8'),
    ]:
        assert value == to_native(value)
        assert value == to_native(value, errors='surrogate_or_replace')
        assert value == to_native(value, errors='surrogate_or_strict')


# Generated at 2022-06-22 22:09:31.653155
# Unit test for function container_to_bytes
def test_container_to_bytes():
    nested_dict = {
        'str': u'\u1e8a\u0323',
        'list': [
            u'\u1e8a\u0323',
            ('tuple', ('tuple', u'\u1e8a\u0323')),
        ],
        'dict': {
            u'key': 'value',
        },
        'unicode': u'\u1e8a\u0323',
    }
    d = container_to_bytes(nested_dict)
    assert isinstance(d['str'], binary_type)
    assert isinstance(d['list'][0], binary_type)
    assert isinstance(d['list'][1][0], binary_type)
    assert isinstance(d['list'][1][1][1], binary_type)

# Generated at 2022-06-22 22:09:41.318729
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_dict = {
        'key1': 'value1',
        u'key2': u'value2',
        'key3': {
            u'key4': u'value4',
            u'key5': u'value5',
            'key6': {
                u'key7': u'value7',
                u'raw8': u'\u001b[0;32mok\u001b[0m',
                'key9': u'value9'
            },
            'key10': [
                {u'key11': u'value11a'},
                {u'key12': u'\u001b[0;32mok\u001b[0m'}
            ]
        }
    }


# Generated at 2022-06-22 22:09:53.091301
# Unit test for function container_to_bytes
def test_container_to_bytes():
    value = u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert container_to_bytes(value) == to_bytes(value)
    assert container_to_bytes(value, errors='ignore') == to_bytes(value, errors='ignore')
    assert container_to_bytes(value, errors='replace') == to_bytes(value, errors='replace')
    assert container_to_bytes(value, errors='surrogate_then_replace') == to_bytes(value, errors='surrogate_then_replace')

    value = {u'k1': u'val1', 'k2': u'\u043f\u0440\u0438\u0432\u0435\u0442'}

# Generated at 2022-06-22 22:10:04.303489
# Unit test for function to_bytes
def test_to_bytes():
    fail = False

# Generated at 2022-06-22 22:10:16.364508
# Unit test for function to_bytes
def test_to_bytes():
    # Issue 15215 - to_bytes does not call __str__ on non-string objects
    class Anobj:
        def __init__(self, val):
            self.val = val
        def __str__(self):
            return self.val
    assert to_bytes(Anobj('foo')) == b'foo'
    assert to_bytes(Anobj(b'foo')) == b'foo'
    assert to_bytes(Anobj(u'foo')) == b'foo'

    # Issue 15156 - to_bytes may fail with encode errors
    assert to_bytes(u'\uffff', encoding='ascii') == b'?'
    assert to_bytes(u'\uffff', encoding='ascii', errors='surrogate_or_replace') == b'?'

# Generated at 2022-06-22 22:10:28.539031
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({u'foo': u'bar'}) == '{"foo": "bar"}'
    assert jsonify({u'foo': u'bar'}, sort_keys=True) == '{"foo": "bar"}'
    assert jsonify({u'foo': u'bar'}, sort_keys=True, indent=4) == '{\n    "foo": "bar"\n}'
    assert jsonify({u'foo': u'bar'}, sort_keys=True, indent=None) == '{"foo": "bar"}'
    assert jsonify({u'foo': u'bar'}, separators=(',', ':')) == '{"foo":"bar"}'
    assert jsonify({u'foo': u'bar'}, separators=(',', ': ')) == '{"foo": "bar"}'

# Generated at 2022-06-22 22:10:42.205391
# Unit test for function container_to_text
def test_container_to_text():
    invalid_utf8 = b'\xc3\x28'
    utf8 = invalid_utf8.decode('utf-8', errors='replace')
    latin1 = invalid_utf8.decode('latin-1')
    invalid_utf8_dict = dict(key1=invalid_utf8, key2=dict(key3=invalid_utf8))
    invalid_utf8_list = [invalid_utf8, dict(key1=invalid_utf8)]
    invalid_utf8_tuple = (invalid_utf8, dict(key1=invalid_utf8))

    assert to_text(container_to_text(invalid_utf8)) == utf8
    assert to_text(container_to_text(invalid_utf8_dict)) == utf8
    assert to_text

# Generated at 2022-06-22 22:10:54.877175
# Unit test for function to_bytes
def test_to_bytes():
    import sys

    # Python3
    if PY3:
        assert to_bytes(u'\ufffd\u3333\ufffd\u1234\ufffd', nonstring='strict') == b'\xfffd\u3333\xfffd\u1234\xfffd'

        # Invalid encoding
        assert to_bytes(b'\x00\x01', encoding='not a real encoding') == b'\x00\x01'
        assert to_bytes(b'\x00\x01', encoding='latin-1', errors='strict') == b'\x00\x01'

        # Valid encoding
        assert to_bytes(b'\x00\x01', encoding='latin-1') == b'\x00\x01'

# Generated at 2022-06-22 22:11:03.418358
# Unit test for function to_bytes
def test_to_bytes():
    try:
        codecs.lookup_error('surrogateescape')
        HAS_SURROGATEESCAPE = True
    except LookupError:
        HAS_SURROGATEESCAPE = False
    assert isinstance(to_bytes(u'somestring', errors='surrogate_or_strict'), binary_type)
    assert isinstance(to_bytes(u'somestring', errors='surrogate_or_replace'), binary_type)
    assert isinstance(to_bytes(u'somestring', errors='surrogate_then_replace'), binary_type)

    if HAS_SURROGATEESCAPE:
        assert isinstance(to_bytes(u'somestring', errors='surrogateescape'), binary_type)

# Generated at 2022-06-22 22:11:15.015592
# Unit test for function to_native
def test_to_native():
    '''
    Test to_native function

    Test the basic to_native function
    '''
    # Test that it doesn't crash on conversion
    res1 = to_text('test')
    assert res1 == u'test'

    # Test conversion with an encoding
    no_eacute = to_text('Les enfants de Vi\xe8ge', encoding='latin-1')
    assert no_eacute == u'Les enfants de Vi\xe8ge'

    eacute = u'Les enfants de Vi\xe8ge'.encode(u'utf-8').decode(u'latin-1')
    assert no_eacute == eacute

    # Test that an encoding which can't convert is handled correctly

# Generated at 2022-06-22 22:11:24.612538
# Unit test for function container_to_bytes
def test_container_to_bytes():
    if not PY3:
        assert container_to_bytes({u'abc':u'xyz'}) == {'abc': 'xyz'}
        assert container_to_bytes({u'abc':{u'def':u'hijk'}}) == {'abc': {'def': 'hijk'}}
        assert container_to_bytes([u'abc', {u'def':u'hijk'}]) == ['abc', {'def': 'hijk'}]
        assert container_to_bytes([u'abc', [u'def', u'hijk']]) == ['abc', ['def', 'hijk']]

        assert container_to_bytes({u'abc':u'xyz'}, errors='surrogate_then_replace') == {'abc': 'xyz'}

# Generated at 2022-06-22 22:11:37.374165
# Unit test for function to_bytes
def test_to_bytes():
    """A function to test the to_bytes function from module_utils.basic.py

    This function runs a test suite to verify that to_bytes is working as expected
    """
    import sys

    class KeywordModuleMock(object):
        params = {}
        encoding = 'utf-8'
        nonstring = 'simplerepr'

    # Create a Mock module object
    mod = KeywordModuleMock()

    errors = 'surrogate_or_strict'
    # Create test cases and expected results

# Generated at 2022-06-22 22:11:44.887711
# Unit test for function to_native