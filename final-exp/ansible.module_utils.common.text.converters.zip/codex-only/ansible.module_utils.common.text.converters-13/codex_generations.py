

# Generated at 2022-06-22 22:01:48.930416
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=to_bytes(u'\xe9', errors='surrogate_then_replace'))) == '{"a": "\\ufffd"}'
    assert jsonify(dict(a=u'\xe9')) == '{"a": "\\u00e9"}'
    assert jsonify(dict(a=to_bytes(u'\xe9'))) == '{"a": "\\u00e9"}'
    assert jsonify(dict(a=to_text(b'\xe9'))) == '{"a": "\\u00e9"}'
    assert jsonify(dict(a=b'\xe9')) == '{"a": "\\u00e9"}'



# Generated at 2022-06-22 22:01:58.657477
# Unit test for function jsonify
def test_jsonify():
    jsonify_test = lambda : None
    jsonify_test.set = []
    jsonify_test.set.append({"test1": "test1", "testSet": Set(['test1', 'test2'])})
    jsonify_test.set.append({"test2": "test2", "testSet": Set(['test3', 'test4'])})
    jsonify_test.set.append({"test3": "test3", "testSet": Set(['test5', 'test6'])})
    jsonify_test.set.append(["test1", "test2", "test3"])
    jsonify_test.set.append(["test1", "test2", {"test3": "test3"}])

# Generated at 2022-06-22 22:02:06.209373
# Unit test for function to_bytes
def test_to_bytes():
    """
    Run test against to_bytes.
    """
    try:
        from unittest2 import TestCase, SkipTest
    except ImportError:
        from unittest import TestCase, SkipTest
    from ansible.module_utils.common._collections_compat import MutableSequence
    class TesttoBytes(TestCase):
        def setUp(self):
            self.pass_error = 'passthru'
            self.passthru_error = 'strict'
            self.simplerepr_error = 'empty'
            self.empty_error = 'simplerepr'
            self.text_type = str if PY3 else unicode
            self.binary_type = bytes
            self.nonstring_types = (MutableSequence, dict, Set, int, float)

# Generated at 2022-06-22 22:02:18.250532
# Unit test for function to_bytes
def test_to_bytes():
  assert to_bytes('fäb') == b'f\xc3\xa4b'
  assert to_bytes(u'fäb') == b'f\xc3\xa4b'

# Generated at 2022-06-22 22:02:21.815507
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'name': u'\xe4\xb8\xad\xe6\x96\x87'}) == u'{"name": "\u4e2d\u6587"}'
    assert jsonify({'name': u'\xe4\xb8\xad\xe6\x96\x87'}, ensure_ascii=False) == u'{"name": "\\u4e2d\\u6587"}'



# Generated at 2022-06-22 22:02:34.137774
# Unit test for function to_native
def test_to_native():
    assert to_native(b'abc') == 'abc'
    assert to_native('abc') == 'abc'
    assert to_native(dict(key=b'value')) == "{'key': 'value'}"
    assert to_native(dict(key='value')) == "{'key': 'value'}"
    assert to_native(Set([b'value'])) == "set(['value'])"
    assert to_native(Set(['value'])) == "set(['value'])"
    assert to_native(u'abc') == 'abc'
    assert to_native(1) == 1
    assert to_native(3.4) == 3.4
    assert to_native(True) == True
    assert to_native(False) == False
    assert to_native(None) == None

# Generated at 2022-06-22 22:02:44.846583
# Unit test for function jsonify
def test_jsonify():
    from ansible.compat.tests.mock import patch
    from contextlib import contextmanager
    @contextmanager
    def mock_encoding_for_json_dumps(return_value):
        with patch('ansible.module_utils._text.json.dumps') as mock_dumps:
            mock_dumps.return_value = return_value
            yield
    assert jsonify({}, sort_keys=True) == '{}'
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    with mock_encoding_for_json_dumps('[1, 2, 3]'):
        assert jsonify([1, 2, 3]) == '[1, 2, 3]'
    # Test for JSON serializing datetime
    import datetime

# Generated at 2022-06-22 22:02:56.724508
# Unit test for function to_bytes
def test_to_bytes():
    for test_val in b'a text string', u'a unicode text strïng', b'\x80\xff':
        assert to_bytes(test_val) == test_val

    assert to_bytes(i_am_not_a_string) == b"i_am_not_a_string"

    try:
        to_bytes(u'\uffff\x80')
        assert False, "Did not raise a UnicodeEncodeError"
    except UnicodeEncodeError:
        pass

    assert u'\uffff\x80'.encode('surrogateescape') == b'\xff\xff\x80', \
            "surrogateescape encoding is broken"

    b = to_bytes(u'\uffff\x80', errors='surrogate_then_replace')

# Generated at 2022-06-22 22:03:08.544142
# Unit test for function to_bytes
def test_to_bytes():
    # Basic tests of to_bytes
    assert to_bytes(u'foo', errors='surrogate_or_strict') == b'foo'
    assert to_bytes(u'\udce4', errors='surrogate_or_strict') == b'\xed\xb3\xa4'
    assert to_bytes(u'\udce4', encoding='koi8-r', errors='surrogate_or_strict') == b'\x84\xe4'

    # Test that surrogate_or_replace works with a codec that doesn't support surrogates
    assert to_bytes(u'\udce4', encoding='koi8-r', errors='surrogate_or_replace') == b'?'

    # Test that surrogate_or_strict doesn't traceback with a codec that doesn't support surrogates

# Generated at 2022-06-22 22:03:18.879316
# Unit test for function container_to_text
def test_container_to_text():
    assert (container_to_text([123, 456, '789'], 'utf-8', 'surrogate_or_strict') ==
            [123, 456, u'789'])
    assert (container_to_text([123, 456, '789'], 'utf-8', 'surrogate_or_replace') ==
            [123, 456, u'789'])
    assert (container_to_text([123, 456, '789'], 'utf-8', 'surrogate_then_replace') ==
            [123, 456, u'789'])

# Generated at 2022-06-22 22:03:26.696783
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils.six import b, u
    from ansible.module_utils.parsing.convert_bool import boolean
    for s in ['foo', b('foo'), u('foo')]:
        assert s == to_native(s), "to_native() accepted invalid value %r" % s
    for s in [True, False, []]:
        assert repr(s) == to_native(s), "to_native() accepted invalid value %r" % s
    for s in [1, 1.2, 1j, b('foo'), u('foo'), {}, {u('foo'): u('bar')}, object(), object]:
        assert str(s) == to_native(s), "to_native() accepted invalid value %r" % s



# Generated at 2022-06-22 22:03:39.865160
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text({'f': 1,
                              'g': {'h': 'abc'},
                              'l': [1, 'abc', '\xe2']}) == {'f': 1,
                                                            'g': {'h': 'abc'},
                                                            'l': [1, 'abc', '\xe2']}
    assert container_to_text({'f': 1,
                              'g': {'h': 'abc'},
                              'l': [1, 'abc', '\xe2']}, errors='surrogate_then_replace') == {'f': 1,
                                                                                              'g': {'h': 'abc'},
                                                                                              'l': [1, 'abc', '\ufffd']}
    assert container_to_text

# Generated at 2022-06-22 22:03:49.639362
# Unit test for function to_bytes
def test_to_bytes():
    assert b'foobar' == to_bytes('foobar')
    assert b'foobar' == to_bytes(u'foobar')
    assert b'foobar' == to_bytes('foobar', 'ascii')
    assert b'foobar' == to_bytes(u'foobar', 'ascii')
    assert b'foobar' == to_bytes(b'foobar')
    assert b'foobar' == to_bytes(b'foobar', 'ascii')
    assert b'foobar' == to_bytes(b'foobar', 'ascii', 'surrogate_or_strict')
    assert b'foobar' == to_bytes(b'foobar', 'ascii', 'surrogate_or_replace')

# Generated at 2022-06-22 22:04:00.183745
# Unit test for function jsonify
def test_jsonify():
    # Test set serialization
    assert jsonify(Set([1, 2]), sort_keys=True) == '[1, 2]'
    # Test datetime serialization
    assert jsonify(datetime.datetime(1990,1,1), sort_keys=True) == '"1990-01-01T00:00:00"'
    # Test utf-8 decoding
    assert jsonify({u"a": u"\u20ac"}, sort_keys=True) == '{"a": "\\u20ac"}'
    # Test latin-1 decoding
    assert jsonify({u"a": b"\xe2\x82\xac".decode('latin-1')}, sort_keys=True) == '{"a": "\\u20ac"}'
    # Test invalid decoding

# Generated at 2022-06-22 22:04:02.641320
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u"\u7684") == '"\\u7684"'
    assert jsonify("abc") == '"abc"'


# Generated at 2022-06-22 22:04:10.205275
# Unit test for function to_native
def test_to_native():
    # Test all parameters of to_text() and to_bytes()
    for name, data in iteritems(test_data):
        for encoding in encodings:
            for errors in ('strict', 'replace', 'surrogateescape', 'surrogate_or_strict', 'surrogate_or_replace', 'surrogate_then_replace'):
                for nonstring in ('simplerepr', 'empty', 'passthru', 'strict'):
                    _to_text = to_text(data, encoding, errors, nonstring)
                    _to_bytes = to_bytes(data, encoding, errors, nonstring)

                    _to_native = to_native(data, encoding=encoding, errors=errors, nonstring=nonstring)


# Generated at 2022-06-22 22:04:22.474748
# Unit test for function container_to_bytes
def test_container_to_bytes():
    b_val = container_to_bytes(u'foo')
    assert isinstance(b_val, binary_type)
    assert b_val == b'foo'

    test_dict1 = {'k1': u'v1', 'k2': u'v2'}
    test_dict2 = {b'k1': b'v1', b'k2': b'v2'}
    b_val = container_to_bytes(test_dict1)
    assert isinstance(b_val, dict)
    assert isinstance(list(b_val.keys())[0], binary_type)
    assert isinstance(list(b_val.values())[0], binary_type)
    assert b_val == test_dict2


# Generated at 2022-06-22 22:04:26.925236
# Unit test for function container_to_text
def test_container_to_text():
    from ansible.module_utils._text import to_text


# Generated at 2022-06-22 22:04:34.828184
# Unit test for function container_to_bytes
def test_container_to_bytes():
    return_dict = {'asdf': 'qwer', 'zxcv': ['qwer', 'asdf']}
    return_list = ['asdf', {'zxcv': 'qwer'}]
    return_tuple = ('asdf', 'zxcv', {'qwer': 'asdf'})
    assert container_to_bytes(return_dict) == return_dict
    assert container_to_bytes(return_list) == return_list
    assert container_to_bytes(return_tuple) == return_tuple
    assert container_to_bytes({'asdf': 'qwer'}) == {b'asdf': b'qwer'}
    assert container_to_bytes({'asdf': 'qwer'.encode('utf-8')}) == {b'asdf': b'qwer'}


# Generated at 2022-06-22 22:04:47.440667
# Unit test for function to_native
def test_to_native():
    for x in [u'foo', u'fóo', u'fòô', u'fòô'.encode('utf-8')]:
        assert to_native(x) == u'fòô'

    assert to_native(1) == '1'
    assert to_native(1.1) == '1.1'
    assert to_native(u'fòô'.encode('utf-8')) == u'fòô'

# Generated at 2022-06-22 22:04:54.377507
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(['test']) == ['test']
    assert container_to_bytes(('test',)) == ('test',)
    assert container_to_bytes({'key': 'test'}) == {'key': b'test'}
    assert container_to_bytes({'key': ['test']}) == {'key': [b'test']}
    assert container_to_bytes({'key': ('test',)}) == {'key': (b'test',)}
    assert container_to_bytes({'key': ('test' , ['test'])}) == {'key': (b'test' , [b'test'])}

# Generated at 2022-06-22 22:05:02.856460
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_str = _text_type('測試')
    test_dict = {'nonsens': _text_type('測試')}
    test_list = [_text_type('測試'), _text_type('測試')]
    test_tuple = (_text_type('測試'), _text_type('測試'))

    # test simple case utf-8
    ret = container_to_bytes(test_str)
    assert isinstance(ret, binary_type) and ret == b'\xe6\xb8\xac\xe8\xa9\xa6'

    # test simple case latin-1
    ret = container_to_bytes(test_str, encoding='latin-1')
   

# Generated at 2022-06-22 22:05:10.280667
# Unit test for function to_native
def test_to_native():
    for obj in (
        u'', u'foobar', u'\u3068\u3054\u3068',
        ['alpha', 'beta'],
        {'alpha': u'\u3068\u3054\u3068', 'beta': ['gamma', 'delta']},
        {}, Set(),
        datetime.datetime.now(),
        datetime.date.today(),
        datetime.timedelta(days=1),
    ):
        assert to_native(obj) == obj


# Generated at 2022-06-22 22:05:16.189413
# Unit test for function to_bytes
def test_to_bytes():
    #assertEqual(to_bytes('Iñtërnâtiônàlizætiøn'), b'I\xc3\xb1t\xc3\xabrn\xc3\xa2ti\xc3\xb4n\xc3\xa0liz\xc3\xa6ti\xc3\xb8n')
    assert 1 == 1



# Generated at 2022-06-22 22:05:25.473015
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.six.moves.builtins import range

    # Test a bunch of things that are already bytes
    for n in range(256):
        assert to_bytes(chr(n), errors='strict') == chr(n)

    # Test surrogateescape for non-utf8 encodings
    surrogate_chars = u'\udce2\udc80\udc80\udc80'
    assert to_bytes(surrogate_chars, encoding='utf-16', errors='surrogateescape') == u'\udce2\udc00\udc00\udc00'.encode('utf-16')

# Generated at 2022-06-22 22:05:38.075363
# Unit test for function to_bytes
def test_to_bytes():
    # Make sure that we are actually testing the function and not the global
    # function with this name
    import sys
    if 'ansible.module_utils.basic.to_bytes' in sys.modules:
        del sys.modules['ansible.module_utils.basic.to_bytes']
    from ansible.module_utils.basic import to_bytes

    byte_string = b'some bytes'
    text_string = u'some unicode'
    if PY3:
        text_string = text_string.encode('utf-8').decode('utf-8')

    assert to_bytes(byte_string) == byte_string
    assert to_bytes(byte_string, errors='strict') == byte_string

    assert to_bytes(text_string) == text_string.encode('utf-8')
    # Just

# Generated at 2022-06-22 22:05:48.645670
# Unit test for function jsonify
def test_jsonify():
    try:
        import simplejson
    except ImportError:
        # simplejson is not installed, so we can't test jsonify.
        return
    simple = simplejson.dumps
    data = {u"a\u2764\ufe0f": u"b"}
    assert simple(data) == jsonify(data)
    assert b"\"a\xe2\x9d\xa4\xef\xb8\x8f\": \"b\"" in jsonify(data)

    data = {u"a\u2764\ufe0f": u"b\u2764\ufe0f"}
    assert simple(data) == jsonify(data)

# Generated at 2022-06-22 22:05:53.316796
# Unit test for function jsonify
def test_jsonify():
    data_string = '{"test": "test"}'
    data_obj = {'test': 'test'}
    assert jsonify(data_string) == data_string
    assert jsonify(data_obj) == data_string
    assert jsonify(to_bytes(data_string, 'latin-1')) == data_string
    assert jsonify(to_bytes(data_obj, 'latin-1')) == data_string



# Generated at 2022-06-22 22:06:03.275011
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Create a test data
    data1 = {u'name': {u'first': 'foo', u'last': u'bar'}, u'numbers': [1, 2, 3]}
    data2 = [{u'name': {u'first': 'foo', u'last': u'bar'}, u'numbers': [1, 2, 3]}]
    data3 = u'\udca7'
    data4 = {'1': 1, '2': {'3': 3}, '4': [4]}

    # Test function container_to_bytes
    assert container_to_bytes(data1, errors='surrogate_or_strict') == {b'name': {b'first': b'foo', b'last': b'bar'}, b'numbers': [1, 2, 3]}
    assert container_to

# Generated at 2022-06-22 22:06:10.385817
# Unit test for function jsonify
def test_jsonify():
    data = {"hello": u"world", "ansible": u"\u2713"}
    assert jsonify(data) == '{"ansible": "\u2713", "hello": "world"}'
    data = {"hello": "world", "ansible": "\\u2713"}
    assert jsonify(data) == '{"ansible": "\\u2713", "hello": "world"}'
    data = "hello world"
    assert jsonify(data) == '"hello world"'
    data = u"hello world"
    assert jsonify(data) == '"hello world"'


# Generated at 2022-06-22 22:06:18.931560
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ''' dicts, lists, and tuples are all container types, so test all three
    '''
    # Check that non-container type is passed through unchanged
    assert(container_to_bytes(3) == 3)
    assert(container_to_bytes(3.2) == 3.2)
    assert(container_to_bytes(u'foo') == u'foo')

    assert(container_to_bytes([u'foo', u'bar']) == [b'foo', b'bar'])
    assert(container_to_bytes((u'foo', u'bar')) == (b'foo', b'bar'))
    assert(container_to_bytes([u'foo', 3]) == [b'foo', 3])

# Generated at 2022-06-22 22:06:29.965186
# Unit test for function to_bytes
def test_to_bytes():
    for text_str in (u'\u043a\u0438\u0440\u0438\u043b\u043b\u0438\u0447\u0435\u0441\u043a\u0438\u0439',
                     u'\u65e5\u672c\u8a9e'):
        assert to_bytes(text_str) == text_str.encode('utf-8')

    assert to_bytes(u'\U0001F4A9') == b'\xf0\x9f\x92\xa9'

    assert to_bytes(b'\xc3\xa9') == b'\xc3\xa9'

    assert to_bytes(b'\xc3\xa9', errors='strict') == b'\xc3\xa9'

   

# Generated at 2022-06-22 22:06:32.378703
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'test': u'sp\xe4m'}) == "{\"test\": \"sp\\u00e4m\"}"



# Generated at 2022-06-22 22:06:43.837234
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == b'foo'
    assert to_bytes('bar') == b'bar'
    assert to_bytes(b'baz') == b'baz'
    assert to_bytes(u'baz') == b'baz'
    assert to_bytes(u'\u85c9') == b'\xe8\x97\x89'
    assert to_bytes(1) == b'1'
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='empty') == b''
    class Foo(object):
        def __str__(self):
            return u'\u85c9'
    class Bar(object):
        def __repr__(self):
            return u'\u85c9'
    assert to

# Generated at 2022-06-22 22:06:55.215315
# Unit test for function container_to_bytes
def test_container_to_bytes():
    test_data = {
        u'ascii': u'ascii_str',
        u'unicode': u'☃',
        u'list': [1, u'unicode'],
        u'tuple': (1, u'unicode')
    }
    # We need to convert this to bytes to match the return value
    expected_data = {
        b'ascii': b'ascii_str',
        b'unicode': b'\xe2\x98\x83',
        b'list': [1, b'unicode'],
        b'tuple': (1, b'unicode')
    }
    assert container_to_bytes(test_data) == expected_data


# Generated at 2022-06-22 22:07:06.593504
# Unit test for function jsonify
def test_jsonify():
    test_data_dict1 = {'Name': 'Ansible', 'Age': '5.5', 'Language': ['Python', 'Ruby', 'YAML', 'Java', 'C']}
    data_out_expectation = '{"Language": ["Python", "Ruby", "YAML", "Java", "C"], "Name": "Ansible", "Age": "5.5"}'
    expected_json_output = jsonify(test_data_dict1)
    if expected_json_output != data_out_expectation:
        raise AssertionError("expected_json_output %s != data_out_expectation %s" % (expected_json_output, data_out_expectation))
    # Test with ordinal type

# Generated at 2022-06-22 22:07:16.969980
# Unit test for function to_native
def test_to_native():
    """Unit test for function to_native."""
    assert to_native(u'\xe3\x82\xaa') == u'\xe3\x82\xaa'
    assert to_native(b'\xe3\x82\xaa') == u'\xe3\x82\xaa'
    assert to_native(u'\xe3\x82\xaa'.encode('utf-8')) == u'\xe3\x82\xaa'
    assert to_native(u'\xe3\x82\xaa'.encode('utf-16')) == u'\xe3\x82\xaa'
    assert to_native(u'\xe3\x82\xaa'.encode('utf-32')) == u'\xe3\x82\xaa'
    assert to

# Generated at 2022-06-22 22:07:25.954399
# Unit test for function to_native
def test_to_native():
    assert to_text(b'hello') == u'hello'
    assert to_text(b'some bytes with a nul \x00') == u'some bytes with a nul \x00'
    assert to_text(b'bytes with utf8 b\xc3\xa9') == u'bytes with utf8 b\xe9'
    assert to_text(u'unicode string with a nul \x00') == u'unicode string with a nul \x00'
    assert to_text(u'unicode string with utf8 b\xe9') == u'unicode string with utf8 b\xe9'

# Generated at 2022-06-22 22:07:32.690779
# Unit test for function container_to_text
def test_container_to_text():
    # Test dict
    data = dict({"english":"english",
                 "chinese":b'\xe4\xb8\xad\xe6\x96\x87',
                 "arabic":str('\xd8\xa8\xd8\xb1\xd8\xa7\xd9\x85\xd8\xb2\xd9\x8a').encode('utf-8')
                 })

    # Functionality test
    assert container_to_text(data)["english"] == "english"
    assert container_to_text(data)["chinese"] == u"中文"
    assert container_to_text(data)["arabic"] == u"برامزي"
    # Type test
    assert isinstance(container_to_text(data),dict)

# Generated at 2022-06-22 22:07:45.964503
# Unit test for function jsonify
def test_jsonify():
    data = {
        "foo": "bar",
        u"привет": u"мир",
        "list": [u"one", u"two", u"three"],
        123: 456,
        u"numbers": [1, 2, 3],
        "test_set": Set([u"one", u"two", u"three"]),
        "test_datetime_now": datetime.datetime(2015, 1, 1, 5, 23, 22),
        "test_datetime_utc_now": datetime.datetime(2015, 1, 1, 5, 23, 22).replace(tzinfo=datetime.timezone.utc),
    }

    encoded_data = jsonify(data)


# Generated at 2022-06-22 22:07:53.703177
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text({'a': 1}) == {'a': 1}
    assert container_to_text({'a': b'1'}) == {'a': '1'}
    assert container_to_text({b'a': b'1'}) == {'a': '1'}
    assert container_to_text({'a': {'b': 'c'}}) == {'a': {'b': 'c'}}
    assert container_to_text({b'a': {'b': 'c'}}) == {'a': {'b': 'c'}}
    assert container_to_text({b'a': {b'b': 'c'}}) == {'a': {'b': 'c'}}

# Generated at 2022-06-22 22:08:02.671064
# Unit test for function container_to_bytes
def test_container_to_bytes():
    t_dictionary = {
        'foo': b('foovalue'),
        b('bar'): 'barvalue'
    }
    t_dictionary_utf8 = {
        'foo': b('foovalue'),
        'bar': 'barvalue'
    }

    t_dictionary_unicode = {
        'foo': b('foovalue'),
        'bar': u'barvalue'
    }
    t_list = [b('value1'), b('value2')]
    t_list_utf8 = [b('value1'), b('value2')]
    t_list_unicode = [b('value1'), u'value2']

    assert_equal(container_to_bytes(t_dictionary), t_dictionary)

# Generated at 2022-06-22 22:08:14.326713
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test whether container_to_bytes convert dict,list,tuple key,value to byte str
    data = {"key1":'value1',"key2":['value2', 'value3'],"key3":('value4', 'value5')}
    new_data = container_to_bytes(data)
    # Test whether dict key,value are byte str
    assert isinstance(new_data, dict)
    for k,v in iteritems(new_data):
        assert isinstance(k, binary_type)
        assert isinstance(v, binary_type)
        if isinstance(v, binary_type):
            assert v == b'value1'

    # Test whether list elements are byte str
    assert isinstance(new_data['key2'], list)

# Generated at 2022-06-22 22:08:19.066327
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=dict(c=2))).startswith('{"a": 1, "b": {"c": 2}')
    assert jsonify(dict(a=1, b=[dict(c=2), dict(d=3)])).startswith('{"a": 1, "b": [{"c": 2}, {"d": 3}]')



# Generated at 2022-06-22 22:08:26.159911
# Unit test for function jsonify
def test_jsonify():
    # json encode a string
    assert jsonify(u'foo') == u'"foo"'
    # json encode a unicode string
    assert jsonify(b'\xe2\x98\x83') == u'"\u2603"'
    # json encode a set()
    assert jsonify(set([u'foo', u'bar'])) == u'["bar", "foo"]'
    # json encode a datetime()
    assert jsonify(datetime.datetime(2017,1,1)) == u'"2017-01-01T00:00:00"'
    # json encode a dict()
    assert jsonify(dict(a=1, b=2)) == u'{"a": 1, "b": 2}'



# Generated at 2022-06-22 22:08:37.272593
# Unit test for function to_bytes
def test_to_bytes():
    """Sanity check that to_bytes works as expected in various cases."""
    from ansible.module_utils.basic import bytes_lib

    # In python2.6, we don't have assertEqual and friends.  We can't replace
    # this with unittest.TestCase since we want this test to run in both
    # python2 and python3
    def eq(real, expected):
        assert real == expected, '%r != %r' % (real, expected)

    eq(to_bytes('test'), b'test')
    eq(to_bytes('test', encoding='ascii'), b'test')
    eq(to_bytes('test', encoding='ascii', errors='surrogate_or_replace'), b'test')

# Generated at 2022-06-22 22:08:46.607144
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d1 = dict({"zhangsan": "lisi", "wangwu": "zhaoliu", "qianqi": [1,2,3,4]})
    assert isinstance(container_to_bytes(d1), dict)
    assert isinstance(container_to_bytes(d1)["zhangsan"], bytes)
    assert isinstance(container_to_bytes(d1)["qianqi"], list)
    assert container_to_bytes(d1)["wangwu"] == "zhaoliu"
    assert container_to_bytes(d1)["qianqi"] == [1,2,3,4]


# Generated at 2022-06-22 22:08:54.447376
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('this is a test') == b'this is a test'
    assert to_bytes('abc\u2012') == b'abc\xe2\x80\x92'
    assert to_bytes('abc\u2012', encoding='ascii') == b'abc?'
    assert to_bytes(u'\u2012'.encode('UTF-16'), encoding='ascii') == b'?'

    nonstrings = [3, 2.5, object(), Set()]
    for item in nonstrings:
        assert to_bytes(item, nonstring='simplerepr') == b'%s' % item
        assert to_bytes(item, nonstring='passthru') is item
        assert to_bytes(item, nonstring='empty') == b''

# Generated at 2022-06-22 22:08:58.572531
# Unit test for function jsonify
def test_jsonify():
    structure = dict(a=[1, dict(b=2, c=3)])
    assert jsonify(structure) == "{\"a\": [1, {\"c\": 3, \"b\": 2}]}"


# Generated at 2022-06-22 22:09:04.633732
# Unit test for function jsonify
def test_jsonify():
    # setup
    json_data = [{u'a': u'b'}, u"hi"]
    new_json_data = [{u'a': b'b'}, u"hi".encode("utf-8")]

    # run the test
    new_json_string = jsonify(json_data)

    # assert the results
    assert new_json_string == json.dumps(new_json_data)



# Generated at 2022-06-22 22:09:13.949602
# Unit test for function jsonify
def test_jsonify():
    data = {'key': 'value'}
    assert jsonify(data, sort_keys=True) == '{"key": "value"}'
    data = {'key': 'value\u2713'}
    try:
        jsonify(data, sort_keys=True)
        assert False, 'UnicodeDecodeError should have been raised'
    except TypeError:
        # We are on some old version of json module.
        # Check if we get the correct Python2 container
        assert jsonify(data, sort_keys=True) == '{"key": "value\\xe2\\x9c\\x93"}'



# Generated at 2022-06-22 22:09:24.106094
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('{"hello":"world"}') == '"{\\"hello\\":\\"world\\"}"'
    assert jsonify('\xe4\xb8\x89\xe5\x88\x87') == '"\\u4e09\\u5206"'
    assert jsonify({'hello':'world'}) == '{"hello": "world"}'
    assert jsonify({u'hello': u'world'}) == '{"hello": "world"}'
    assert jsonify('\xe4\xb8\x89\xe5\x88\x87') == '"\\u4e09\\u5206"'
    assert jsonify(u'\xe4\xb8\x89\xe5\x88\x87') == '"\\u4e09\\u5206"'

# Generated at 2022-06-22 22:09:31.596887
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text({'b': b'byte', 't': u'text'}) == {'b': u'byte', 't': u'text'}
    assert container_to_text([b'byte', u'text']) == [u'byte', u'text']
    assert container_to_text([b'byte', [u'text']]) == [u'byte', [u'text']]
    assert container_to_text({'b': [b'byte', u'text']}) == {'b': [u'byte', u'text']}
    assert container_to_text((b'byte', u'text')) == (u'byte', u'text')

# Generated at 2022-06-22 22:09:40.447046
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'{"foo":1}') == u'{"foo": 1}'
    assert jsonify(u'{"foo":1}'.encode('utf-8')) == u'{"foo": 1}'
    assert jsonify(u'{"foo":1}'.encode('latin-1')) == u'{"foo": 1}'
    assert jsonify(u'{"ä":"ö"}') == '{"ä": "ö"}'
    assert jsonify(u'{"ä":"ö"}'.encode('utf-8')) == '{"ä": "ö"}'
    assert jsonify(u'{"ä":"ö"}'.encode('latin-1')) == '{"ä": "ö"}'



# Generated at 2022-06-22 22:09:51.949326
# Unit test for function to_bytes
def test_to_bytes():
    try:
        codecs.lookup_error('surrogateescape')
    except LookupError:
        return

    # Verify codecs.decode() like behavior
    for s in [u'\u2603', u'\uD800', u'\U00010400']:
        assert to_bytes(s, errors='surrogate_or_strict') == s.encode('utf-8', 'surrogateescape')
        assert to_bytes(s, errors='surrogate_or_replace') == s.encode('utf-8', 'surrogateescape')
        assert to_bytes(s, errors='surrogate_then_replace') == s.encode('utf-8', 'surrogateescape').decode('utf-8', 'replace').encode('utf-8', 'replace')

    # Verify

# Generated at 2022-06-22 22:10:03.356157
# Unit test for function jsonify
def test_jsonify():
    test_data = {'basic':'test', 'value':123, 
                 'list': [1,2,3], 'empty': [], 
                 'dict':{1:2,3:4}, 'dict2':{'k1':'v1', 'k2':'v2'},
                 'unicode':u'\u2713', 'set':set([1,2,3]),
                 'datetime':datetime.datetime(2019, 6, 12, 10, 11, 54, 123456),
                 'encoded':to_bytes('\u2713')}

# Generated at 2022-06-22 22:10:06.885492
# Unit test for function to_native
def test_to_native():
    '''
    `test_to_native`
    TODO
    '''
    assert to_native(b'abc') == b'abc'
    assert to_native(u'abc') == u'abc'


# Generated at 2022-06-22 22:10:10.811464
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u1234') == u'\u1234'
    assert to_native(b'\xe1\x88\xb4') == u'\u1234'



# Generated at 2022-06-22 22:10:15.205988
# Unit test for function container_to_bytes
def test_container_to_bytes():
    from ansible.compat.tests import unittest
    class TestContainerToBytes(unittest.TestCase):
        def test_dict(self):
            test_dict = {'foo' : 'bar'}
            self.assertEqual(container_to_bytes(test_dict), {b'foo' : b'bar'})
        def test_dict_with_unicode(self):
            test_dict = {'foo' : u'bar\u0099'}
            self.assertEqual(container_to_bytes(test_dict), {b'foo' : b'bar\xc2\x99'})
        def test_dict_with_non_string(self):
            test_dict = {'foo' : [1,2,3]}

# Generated at 2022-06-22 22:10:27.364232
# Unit test for function to_bytes
def test_to_bytes():
    # This is needed to test surrogateescape where surrogateescape exists
    if 'surrogateescape' in codecs.__dict__:
        codecs.register_error('surrogate_or_replace', codecs.surrogateescape)
        codecs.register_error('surrogate_or_strict', codecs.surrogateescape)
        codecs.register_error('surrogate_then_replace', codecs.surrogateescape)

    # Test that surrogateescape is preferred to replace

# Generated at 2022-06-22 22:10:41.405216
# Unit test for function jsonify
def test_jsonify():
    # dict
    data = dict(key1='a', key2=u'\xe9')
    assert jsonify(data) == '{"key1": "a", "key2": "\\u00e9"}'
    # list
    data = [u'a', (1,2), [3, dict(key=u'\xe9')]]
    assert jsonify(data) == '["a", [1, 2], [3, {"key": "\\u00e9"}]]'
    # set
    data = set([u'a', (1,2), [3, dict(key=u'\xe9')]])
    assert jsonify(data) == '["a", [3, {"key": "\\u00e9"}], [1, 2]]'
    # other types

# Generated at 2022-06-22 22:10:53.056933
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text('ASCII_string') == u'ASCII_string'
    assert container_to_text('str\xe5') == u'str\u00e5'
    assert container_to_text({'key': 'value'}) == {u'key': u'value'}
    assert container_to_text({'key': 'value', 'key2': {'val': 'val'}}) == {u'key': u'value', u'key2': {u'val': u'val'}}
    assert container_to_text([['key', 'value']]) == [[u'key', u'value']]

# Generated at 2022-06-22 22:11:05.274987
# Unit test for function to_native

# Generated at 2022-06-22 22:11:17.005834
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Ensure that dict and all direct containers are handled
    test_data = dict(key1='abc\xe4\xb8\xad', key2=u'abc\u4e2d', set1=set([1,2]))
    rval = container_to_bytes(test_data)
    assert isinstance(rval, dict)
    assert isinstance(rval['key1'], binary_type)
    assert isinstance(rval['key2'], binary_type)
    assert isinstance(rval['set1'], set)

    # Ensure that nested dict and all direct containers are handled

# Generated at 2022-06-22 22:11:25.608030
# Unit test for function container_to_text
def test_container_to_text():
    test_list = [b'test1', {b'test2': b'test3'}, b'\xFF', [b'\xFF'], (b'\xFF', b'\xFF')]
    assert container_to_text(test_list, 'ascii') == [u'test1', {u'test2': u'test3'}, u'\xff', [u'\xff'], (u'\xff', u'\xff')]



# Generated at 2022-06-22 22:11:38.273412
# Unit test for function to_native
def test_to_native():
    # Use str instead of bytes so we can compare with an exception's output
    # under Python 2 and 3.
    if PY3:
        byte_type = "bytes"
        str_type = "str"
    else:
        byte_type = "str"
        str_type = "unicode"

    # Test bytes path
    assert to_native("a") == "a"
    assert to_native(b"a") == "a"
    assert to_native(1) == "1"
    assert to_native("\u00fc") == "ü"

    # Test unicode path
    assert to_native(u"a") == "a"
    assert to_native("\xfc") == "ü"

    # Test exceptions

# Generated at 2022-06-22 22:11:45.619835
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(u'\xf6') == u'\xf6'
    assert to_native(b'\xc3\xb6', 'utf-8') == u'\xf6'
    assert to_native(b'\xc3\x96', 'iso-8859-1', 'replace') == u'\ufffd'
    assert to_native(b'\xc3\x96', 'iso-8859-1', errors='surrogateescape') == u'\udcc3\udc96'