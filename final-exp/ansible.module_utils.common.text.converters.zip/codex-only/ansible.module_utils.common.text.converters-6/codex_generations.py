

# Generated at 2022-06-22 22:01:49.552424
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    assert(to_native("Hello") == "Hello")
    assert(to_native("Hello".encode("utf-8")) == "Hello")
    assert(to_native("Hello".encode("cp437")) == u"Hello".encode("cp437").decode("cp437"))
    assert(to_native(u"Hello".encode("cp437")) == u"Hello".encode("cp437").decode("cp437"))
    assert(to_native("Héllö".encode("cp437")) == u"Héllö".encode("cp437").decode("cp437"))
    assert(to_native(u"Héllö".encode("cp437")) == u"Héllö".encode("cp437").decode("cp437"))



# Generated at 2022-06-22 22:02:01.965021
# Unit test for function container_to_text

# Generated at 2022-06-22 22:02:14.929627
# Unit test for function to_bytes
def test_to_bytes():

    #
    # Test encoding/decoding
    #
    text_value = u'\u611b'
    utf8_value = to_bytes(text_value)
    utf8_value_2 = to_bytes(to_bytes(text_value))
    assert utf8_value == utf8_value_2
    utf8_value = to_bytes(text_value, encoding='utf-8', errors='surrogate_then_replace')
    utf8_value_2 = to_bytes(to_bytes(text_value, encoding='utf-8', errors='surrogate_then_replace'), encoding='utf-8', errors='surrogate_then_replace')
    assert utf8_value == utf8_value_2

# Generated at 2022-06-22 22:02:19.858636
# Unit test for function jsonify
def test_jsonify():
    class Foo(object):
        def __init__(self,bar):
            self.bar = bar

        def __repr__(self):
            return to_native(jsonify({u"bar": self.bar}))


    data = {u'foo': Foo(bar="hello")}
    # 以上都是生成例子数据
    output = jsonify(data)
    print(output)



# Generated at 2022-06-22 22:02:28.683727
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Create a dict with unicode key and value
    testDict = {u'unicode': u'unicode'}

    # Convert the dict to a byte-string
    testDictBytes = container_to_bytes(testDict)

    # Test that the dict was converted correctly
    assert testDictBytes.keys()[0].decode('ascii') == 'unicode'
    assert testDictBytes.values()[0].decode('ascii') == 'unicode'



# Generated at 2022-06-22 22:02:38.556398
# Unit test for function to_bytes
def test_to_bytes():
    """Test to_bytes"""
    assert b'a:b:c' == to_bytes(u'a:b:c')
    assert b'a:b:c' == to_bytes(u'a:b:c', 'ascii')
    assert b'a:b:c' == to_bytes(u'a:b:c', encoding='ascii')
    assert b'a:b:c' == to_bytes(u'a:b:c', errors='strict')
    assert b'a:b:c' == to_bytes(b'a:b:c')
    assert b'' == to_bytes(None)
    assert b'' == to_bytes(None, nonstring='empty')
    assert b'None' == to_bytes(None, nonstring='simplerepr')

# Generated at 2022-06-22 22:02:47.810864
# Unit test for function container_to_bytes
def test_container_to_bytes():
    mixed_text_dict = {
        b'bytes_key': u'text_value',
        u'text_key': b'bytes_value',
        u'mixed_key': {u'mixed_sub_key': u'mixed_sub_value'}
    }
    utf8_text_dict = {
        b'bytes_key': u'text_value',
        u'text_key': u'bytes_value',
        u'mixed_key': {u'mixed_sub_key': u'mixed_sub_value'}
    }

# Generated at 2022-06-22 22:02:55.993055
# Unit test for function to_native
def test_to_native():
    test_cases = (
        (12345, '12345'),
        (3.14, '3.14'),
        (b'test', 'test'),
        (u'\u0123', u'\u0123'),
    )

    for test_case, expected_result in test_cases:
        result = to_native(test_case)
        assert result == expected_result, \
        'Expected "%s" but got "%s" - test case "%s"' % (expected_result, result, test_case)


# Generated at 2022-06-22 22:03:07.759553
# Unit test for function to_native
def test_to_native():
    assert to_native(b'hello', 'utf-8') == u'hello'
    assert to_native(u'hello', 'utf-8') == u'hello'
    assert to_native(u'你好', 'utf-8') == u'你好'
    assert to_native(b'1234', 'utf-8') == u'1234'
    assert to_native(b'\x80\x90', 'utf-8') == u'\uFFFD\uFFFD'
    assert to_native(u'\x80\x90', 'utf-8') == u'\uFFFD\uFFFD'
    assert to_native(u'你好', 'ascii') == u'\uFFFD\uFFFD'

# Generated at 2022-06-22 22:03:18.296494
# Unit test for function to_native
def test_to_native():
    # object is a native string
    assert to_text(u'Löwe 老虎 Léopard') == u'Löwe 老虎 Léopard'
    # object is a byte string
    assert to_text(u'Löwe 老虎 Léopard'.encode('utf-8')) == u'Löwe 老虎 Léopard'
    # object is a non-string
    assert to_text(10) == u'10'
    # encoding error is ignored
    assert to_text(u'L\xf6we 老虎 Léopard'.encode('ascii', 'ignore')) == u'Lwe 老虎 Lpard'
    # non-string error is ignored

# Generated at 2022-06-22 22:03:29.054292
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import Sequence

    # dict
    assert(to_native({'a': 'b'}) == {'a': 'b'})
    assert(isinstance(to_native({'a': 'b'}), dict))

    # list
    assert(to_native(['a', 'b']) == ['a', 'b'])
    assert(isinstance(to_native(['a', 'b']), list))

    # tuple
    assert(to_native(('a', 'b')) == ['a', 'b'])
    assert(isinstance(to_native(('a', 'b')), list))

    #

# Generated at 2022-06-22 22:03:33.976649
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(dict(a=1, b=2, c=3)) == dict(a=1, b=2, c=3)
    assert container_to_bytes([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-22 22:03:38.029499
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.six import u

    data = {u("\u1234"): u("\u4321")}
    assert jsonify(data)



# Generated at 2022-06-22 22:03:48.908686
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils.six import BytesIO

    # This test is to ensure that result is always a string
    # (bytes or unicode in Python 2, str in Python 3).

    assert isinstance(to_native(u"foo"), text_type)
    assert isinstance(to_native("foo"), text_type)
    assert isinstance(to_native(1), text_type)
    assert isinstance(to_native(None), text_type)

    class Foo(object):
        def __str__(self):
            raise RuntimeError()

    assert isinstance(to_native(Foo()), text_type)

    # Ensure that all types decode to Unicode without exception
    assert isinstance(to_native(u"foo"), text_type)
    assert isinstance(to_native("foo"), text_type)
   

# Generated at 2022-06-22 22:03:58.987255
# Unit test for function container_to_text
def test_container_to_text():
    data = {
        to_bytes('\xe9', 'latin-1'):
            [to_bytes('\xe9', 'latin-1'), {to_bytes('\xe9', 'latin-1'): to_bytes('\xe9', 'latin-1')}],
        to_bytes('\xe9', 'latin-1'): to_bytes('\xe9', 'latin-1')
    }

    # python2.7 has issues with latin-1 surrogates
    if PY3:
        expect = {u"\xe9": [u"\xe9", {u"\xe9": u"\xe9"}], u"\xe9": u"\xe9"}

# Generated at 2022-06-22 22:04:11.252197
# Unit test for function container_to_text

# Generated at 2022-06-22 22:04:13.764149
# Unit test for function jsonify
def test_jsonify():
    json_obj = jsonify("a")
    assert isinstance(json_obj, str)
    assert json_obj == '"a"'


# Generated at 2022-06-22 22:04:25.703067
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(["1"]) == ["1"]
    assert container_to_bytes([b"1"]) == [b"1"]
    assert container_to_bytes({"key": "1"}) == {"key": "1"}
    assert container_to_bytes({"key": b"1"}) == {"key": b"1"}
    assert container_to_bytes(("1", "2")) == ("1", "2")
    assert container_to_bytes((b"1", b"2")) == (b"1", b"2")
    # Test that a unicode value makes the function raises an exception
    assert_raises(UnicodeEncodeError, container_to_bytes, [u"1"])

# Generated at 2022-06-22 22:04:27.706844
# Unit test for function to_native
def test_to_native():
    try:
        to_native('test')
    except:
        return False
    return True


# Generated at 2022-06-22 22:04:38.482441
# Unit test for function to_bytes
def test_to_bytes():
    assert(to_bytes('abc') == b'abc')
    assert(to_bytes(u'abc') == b'abc')
    assert(to_bytes(u'\U0001f4a9') == b'\xf0\x9f\x92\xa9')
    assert(to_bytes(u'\U0001f4a9', encoding='iso-8859-1', errors='strict') == b'?')
    if HAS_SURROGATEESCAPE:
        assert(to_bytes(u'\U0001f4a9', encoding='iso-8859-1', errors='surrogateescape') == b'\xed\xa0\xbd\xed\xb2\xa9')

# Generated at 2022-06-22 22:04:51.142511
# Unit test for function to_bytes
def test_to_bytes():
    # PY3
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(1) == b'1'

    # Python 2.4 doesn't have b''
    assert to_bytes(u'foo', nonstring='empty') == to_bytes('', nonstring='empty')
    assert to_bytes(b'foo', nonstring='empty') == to_bytes('', nonstring='empty')
    assert to_bytes(1, nonstring='empty') == to_bytes('', nonstring='empty')

    assert to_bytes(u'foo', nonstring='passthru') == u'foo'
    assert to_bytes(b'foo', nonstring='passthru') == b'foo'

# Generated at 2022-06-22 22:04:57.304044
# Unit test for function container_to_text
def test_container_to_text():
    test_dict = {u"foo": b"bar"}
    test_list = [b"foo", b"bar"]
    test_tuple = (b"foo", b"bar")

    assert container_to_text(test_dict) == {u"foo": u"bar"}
    assert container_to_text(test_list) == [u"foo", u"bar"]
    assert container_to_text(test_tuple) == (u"foo", u"bar")



# Generated at 2022-06-22 22:05:10.065811
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text('foo') == u'foo'
    assert container_to_text('foo'.encode('utf-8')) == u'foo'
    assert container_to_text('f\xc3\xbc'.encode('utf-8')) == u'f\xfc'
    assert container_to_text('f\xc3\xbc'.encode('latin-1')) == u'f\ufffd'
    assert container_to_text(u'f\xfc') == u'f\xfc'
    assert container_to_text(u'f\xfc'.encode('utf-8')) == u'f\xfc'
    assert container_to_text(u'f\xfc'.encode('latin-1')) == u'f\ufffd'
    # non

# Generated at 2022-06-22 22:05:18.521805
# Unit test for function jsonify
def test_jsonify():
    data = {
        'aaa': 'bbb',
        'ascii': 'same',
        'latin1': 'á'.encode('latin-1'),
        'utf8': 'á'.encode('utf-8'),
        'set': Set(('a', 'd')),
        'date': datetime.datetime.now()
    }
    json_data = jsonify(data)
    if PY3:
        assert(isinstance(json_data, str))
    else:
        assert(isinstance(json_data, unicode))



# Generated at 2022-06-22 22:05:24.257938
# Unit test for function container_to_text
def test_container_to_text():

         data1 = {'key': 'value'}
         data2 = {'key': 'value','key1':['value1', 'value2']}
         data3 = {'key': 'value','key1':['value1', 'value2','value3']}
         data4 = {'key': 'value','key1':['value1', 'value2','value3'],'key2': [{'key3': 'value3'},{'key4': 'value4'}]}
         data5 = {'key': 'value','key1':['value1', 'value2','value3'],'key2': [{'key3': 'value3'},{'key4': 'value4'}],'key5': (1,2,3)}

# Generated at 2022-06-22 22:05:32.697541
# Unit test for function to_bytes
def test_to_bytes():
    # This is a big file with all sorts of characters in it
    with open(__file__, 'rb') as data_file:
        data_in = data_file.read()
    data_out = to_bytes(data_in, nonstring='passthru')
    assert data_in == data_out
    data_out = to_bytes(data_in, errors='surrogate_or_replace')
    assert data_out == data_in
    data_out = to_bytes(data_in, errors='surrogate_or_strict')
    assert data_out == data_in
    data_out = to_bytes(data_in, errors='surrogate_then_replace')
    assert data_out == data_in
    data_out = to_bytes(data_in, encoding='ascii')
   

# Generated at 2022-06-22 22:05:42.279282
# Unit test for function to_bytes
def test_to_bytes():
    # Note: Don't test with surrogate_or_* error handler because it only works
    # on Python3. And we have to have use b'' instead of bytes literal because
    # we need to support Python2.4 in this module
    assert to_bytes(b'string') == b'string'
    assert to_bytes('string') == b'string'
    assert to_bytes(u'string') == b'string'
    assert to_bytes('a\xf1c') == b'a\xC3\xB1c'
    assert to_bytes('a\xf1c', errors='surrogateescape') == b'a\xC3\xB1c'
    assert to_bytes(u'\U000E0000') == b'?'

# Generated at 2022-06-22 22:05:54.341773
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils.six import PY2, PY3
    if PY2:
        assert to_native(u'\u99ab') == u'\u99ab'
        assert to_native(b'\xe9\xa6\xab') == u'\u99ab'
        assert to_native(u'\u99ab'.encode('utf-8'), errors='surrogate_or_strict') == u'\u99ab'

        assert to_native(u'\udcab') == u'\udcab'
        assert to_native(b'\xed\xb2\xab') == u'\udcab'

# Generated at 2022-06-22 22:06:02.672172
# Unit test for function to_bytes
def test_to_bytes():
    # We don't have a direct test for surrogate_then_replace except for when surrogateescape is present
    # as that is the only time it was a different behaviour.
    if HAS_SURROGATEESCAPE:
        # surrogateescape fails when there are surrogates.  Because our test strings have
        # surrogates we need to use the surrogate_then_replace error handler
        assert to_bytes(u'\ud800', errors='surrogate_then_replace') == u'\ud800'.encode('utf-8', 'replace')

    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes('foo', errors='surrogate_or_replace') == b'foo'

# Generated at 2022-06-22 22:06:03.633861
# Unit test for function to_bytes
def test_to_bytes():
    # Insert string tests here
    pass


# Generated at 2022-06-22 22:06:12.952416
# Unit test for function to_native

# Generated at 2022-06-22 22:06:24.768318
# Unit test for function to_bytes
def test_to_bytes():
    import pytest
    utf8_bom = codecs.BOM_UTF8
    utf16_le_bom = codecs.BOM_UTF16_LE
    utf16_be_bom = codecs.BOM_UTF16_BE
    utf32_le_bom = codecs.BOM_UTF32_LE
    utf32_be_bom = codecs.BOM_UTF32_BE


# Generated at 2022-06-22 22:06:36.724063
# Unit test for function jsonify
def test_jsonify():
    test_dict = dict(aaa=dict(bbb=dict(ccc="ascii", ddd="ascii"), zzz="ascii"), yyy=dict(zzz="ascii"))
    test_dict["aaa"]["bbb"]["ccc"] = to_bytes(test_dict["aaa"]["bbb"]["ccc"])
    test_dict["aaa"]["bbb"]["ddd"] = to_bytes(test_dict["aaa"]["bbb"]["ddd"])
    test_dict["aaa"]["zzz"] = to_bytes(test_dict["aaa"]["zzz"])
    test_dict["yyy"]["zzz"] = to_bytes(test_dict["yyy"]["zzz"])

# Generated at 2022-06-22 22:06:45.267539
# Unit test for function container_to_text
def test_container_to_text():
    # Test for dict
    ascii_str = "test"
    non_ascii_str = u"test \u00f6 \u6709\u52b9"
    non_ascii_bytes = b"test \xc3\xb6 \xe6\x9c\x89\xe5\x8a\xb9"
    non_ascii_dict_ascii_key_bytes_value = {ascii_str: non_ascii_bytes}
    non_ascii_dict_bytes_key_bytes_value = {non_ascii_bytes: non_ascii_bytes}
    non_ascii_dict_non_ascii_key_bytes_value = {non_ascii_str: non_ascii_bytes}

    # Test for list

# Generated at 2022-06-22 22:06:48.049089
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == u'foo'



# Generated at 2022-06-22 22:06:59.756573
# Unit test for function container_to_bytes
def test_container_to_bytes():
    unicode_dict = {u'test_key': u'test_value'}
    unicode_list = [u'test_item', u'test_item']
    unicode_tuple = (u'test_item', u'test_item')
    nonunicode_dict = {'test_key': 'test_value'}
    nonunicode_list = ['test_item', 'test_item']
    nonunicode_tuple = ('test_item', 'test_item')

# Generated at 2022-06-22 22:07:10.389292
# Unit test for function to_native

# Generated at 2022-06-22 22:07:21.205178
# Unit test for function to_bytes
def test_to_bytes():
    # May change in py3.5
    # String with a unencodable character
    text_string = u'\u4f60\u597d\u4e16\u754c \u00a9'
    # Valid utf-8 encoded version of the above string
    valid_bytes = b'\xe4\xbd\xa0\xe5\xa5\xbd\xe4\xb8\x96\xe7\x95\x8c \xc2\xa9'
    # Invalid utf-8 encoded version of the above string.
    invalid_utf8_bytes = b'\xe4\xbd\xa0\xe5\xa5\xbd\xe4\xb8\x96\xe7\x95\x8c \xe2\x29'
    # Invalid latin-1 encoded version of

# Generated at 2022-06-22 22:07:29.754471
# Unit test for function jsonify
def test_jsonify():
    import ansible.module_utils.six as six
    if six.PY3:
        unicode_type = str
    else:
        unicode_type = unicode

    # Evaluate a simple jsonify test
    assert jsonify(dict(a=1, b=2, c=3)) == '{"a": 1, "c": 3, "b": 2}'

    # Evaluate a test with unicode types in the data
    assert jsonify(dict(a=u'foo', b=u'bar', c=u'baz')) == '{"a": "foo", "c": "baz", "b": "bar"}'

    # Evaluate a test with a datetime.datetime object in the data

# Generated at 2022-06-22 22:07:42.550063
# Unit test for function container_to_text
def test_container_to_text():
    data = {
        'unicode_key': u'unicode_value',
        b'bytes_key': b'bytes_value',
        'mixed_list': [u'unicode_value', b'bytes_value', {'another_key': u'another_value'}],
        'mixed_dict': {u'unicode_key': u'unicode_value', b'bytes_key': b'bytes_value'}
    }

# Generated at 2022-06-22 22:07:51.790464
# Unit test for function to_bytes
def test_to_bytes():
    # Test what happens if the text string is already in the specified encoding
    assert to_bytes(u'\u2713', 'utf-8') == b'\xe2\x9c\x93'
    assert to_bytes(u'\u2713', 'utf-8', 'surrogateescape') == b'\xe2\x9c\x93'

    # Test that surrogates in the text string make it out as bytes
    assert to_bytes(u'\ud800\udc00', 'utf-8') == b'\xf0\x90\x80\x80'

    # Test that surrogates in the text string make it out as bytes even if
    # they're not valid in the output encoding

# Generated at 2022-06-22 22:08:01.940859
# Unit test for function container_to_bytes
def test_container_to_bytes():

    a_utf8_string = to_bytes(u"a unicode string")
    non_utf8_bytes = to_bytes("\x90\xa0", encoding='cp1252')
    a_unicode_string = to_text(u"a unicode string")
    utf8_bytes = to_bytes(a_unicode_string)

    for obj in (a_utf8_string, non_utf8_bytes, a_unicode_string, utf8_bytes):
        assert isinstance(container_to_bytes(obj), binary_type)

    assert container_to_bytes({"a": 1, a_unicode_string: 2}) == {b"a": 1, utf8_bytes: 2}

# Generated at 2022-06-22 22:08:13.065424
# Unit test for function to_native
def test_to_native():
    import datetime
    import json
    #
    # to_native(text_type, nonstring='passthru')
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo', nonstring='passthru') == u'foo'
    assert to_native(u'foo', nonstring='strict') == u'foo'
    assert to_native(u'foo', nonstring='simplerepr') == u'foo'
    assert to_native(u'foo', nonstring='empty') == u''
    #
    # to_native(binary_type, nonstring='passthru')
    assert to_native(b'foo') == b'foo'
    assert to_native(b'foo', nonstring='passthru') == b'foo'

# Generated at 2022-06-22 22:08:22.525034
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(None, nonstring='passthru') is None
    assert to_bytes(1, nonstring='passthru') == 1

    # Non-string handling
    assert to_bytes(1) == b'1'
    assert to_bytes(1, nonstring='empty') == b''
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(b'n', nonstring='passthru') == b'n'
    assert to_bytes(u'n', nonstring='passthru') == u'n'

    assert to_bytes(u'n\x8e', errors='surrogate_or_strict') == b'n\x8e'
    assert to_bytes(u'n\x8e', errors='surrogate_or_replace') == b

# Generated at 2022-06-22 22:08:29.097108
# Unit test for function container_to_text
def test_container_to_text():
    a = dict(a=['\xd7\x90', '\xd7\x91', '\xd7\x92'])
    b = dict(a=[u'\u05d0', u'\u05d1', u'\u05d2'])
    c = dict(a=[b'\xd7\x90', b'\xd7\x91', b'\xd7\x92'])
    d = dict(a=[u'\u05d0', b'\xd7\x91', u'\u05d2'])
    assert container_to_text(a) == b
    assert container_to_text(c) == b
    assert container_to_text(d) == b


# A simple example to test the surrogateescape error handler in the to_text()
# and to_bytes

# Generated at 2022-06-22 22:08:36.307328
# Unit test for function jsonify
def test_jsonify():
    for encoding in ("utf-8", "latin-1"):
        try:
            return json.dumps(data, encoding=encoding, default=_json_encode_fallback, **kwargs)
        except TypeError:
            return json.dumps(data, default=_json_encode_fallback, **kwargs)
        except UnicodeDecodeError:
           return
    raise UnicodeError('Invalid unicode encoding encountered')



# Generated at 2022-06-22 22:08:45.574554
# Unit test for function container_to_text
def test_container_to_text():
    import unittest
    import json

    # ASCII 7-bit characters
    data_ascii_string = ('This is a test of the emergency broadcast system using 7-bit ASCII characters.')
    data_ascii_list = ['This', 'is', 'a', 'test', 'of', 'the', 'emergency', 'broadcast', 'system', 'using', '7-bit', 'ASCII', 'characters.']
    data_ascii_tuple = ('This', 'is', 'a', 'test', 'of', 'the', 'emergency', 'broadcast', 'system', 'using', '7-bit', 'ASCII', 'characters.')
    data_ascii_dict = {'key': 'value'}

    # Text combining diacritical characters and euro sign (Unicode C1 8-bit characters)

# Generated at 2022-06-22 22:08:53.814679
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text({b"key": b"value"}) == {u"key": u"value"}
    assert container_to_text({b"key": b"value"}, errors="surrogate_or_replace") == {u"key": u"value"}
    assert container_to_text({b"key": b"value"}, errors="surrogate_or_strict") == {u"key": u"value"}
    assert container_to_text([b"value", b"value2"], errors="surrogate_or_strict") == [u"value", u"value2"]
    assert container_to_text([b"value", b"value2"], errors="surrogate_or_replace") == [u"value", u"value2"]

# Generated at 2022-06-22 22:09:05.024445
# Unit test for function jsonify
def test_jsonify():
    # Ensure container serialization works
    assert jsonify(dict(x=1)) == '{"x": 1}'
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'

    # Ensure container deserialization works
    assert jsonify(dict(x=1), object_pairs_hook=dict) == {'x': 1}
    assert jsonify([1, 2, 3], object_hook=lambda x: [x]) == [[1, 2, 3]]

    # Ensure bytes and unicode strings are coerced to text
    assert jsonify('foo') == '"foo"'
    assert jsonify('foo'.encode('utf-8')) == '"foo"'
    assert jsonify(u'\u20ac') == '"\\u20ac"'

# Generated at 2022-06-22 22:09:12.617959
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(u'\xc2') == b'\xc3\x82'
    assert container_to_bytes({u'\xc2': u'\xc2'}) == {b'\xc3\x82': b'\xc3\x82'}
    assert container_to_bytes([u'\xc2']) == [b'\xc3\x82']
    assert container_to_bytes((u'\xc2',)) == (b'\xc3\x82',)



# Generated at 2022-06-22 22:09:22.602328
# Unit test for function to_native
def test_to_native():
    #Test for non string type
    assert to_native(None) == None
    assert to_native(7) == 7
    assert to_native(True) == True
    assert to_native(0.7) == 0.7
    assert to_native(datetime.datetime.now()) == datetime.datetime.now()
    assert to_native(ascii) == ascii
    assert to_native(Error()) == Error()
    #Test for non ascii string
    assert to_native('Test function to_native') == 'Test function to_native'

# Generated at 2022-06-22 22:09:30.336234
# Unit test for function container_to_text
def test_container_to_text():
    d = {u'key': u'val', 'bkey': b'bval'}
    drecurse = {u'key': [u'vallist'], 'bkey': b'bval'}
    assert (container_to_text(d, encoding='utf-8') == {u'key': u'val', u'bkey': u'bval'})
    assert (container_to_text(drecurse, encoding='utf-8') == {u'key': [u'vallist'], u'bkey': u'bval'})
    assert (container_to_text(d, encoding='latin-1') == {u'key': u'val', u'bkey': u'bval'})

# Generated at 2022-06-22 22:09:40.640619
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({'a': 'abc'}) == {b'a': b'abc'}
    assert container_to_bytes({'a': 'abc', 'b': ['def', 'ghi']}) == {b'a': b'abc', b'b': [b'def', 'ghi']}
    assert container_to_bytes({'a': u'abc', 'b': ['def', 'ghi']}) == {b'a': b'abc', b'b': [b'def', b'ghi']}
    assert container_to_bytes({'a': u'abc', 'b': ['def', u'ghi']}) == {b'a': b'abc', b'b': [b'def', b'ghi']}

# Generated at 2022-06-22 22:09:52.219574
# Unit test for function to_native
def test_to_native():
    class Bencode(object):
        def __init__(self, obj):
            self.obj = obj

        def __str__(self):
            try:
                return str(self.obj)
            except UnicodeError:
                return repr(self.obj)

        def __repr__(self):
            return repr(self.obj)

    from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_bytes

    # Test first with only a simple string
    assert to_native(None) == 'None'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'ø') == 'ø'

# Generated at 2022-06-22 22:10:03.612099
# Unit test for function to_native

# Generated at 2022-06-22 22:10:15.601681
# Unit test for function to_bytes

# Generated at 2022-06-22 22:10:27.890376
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(b'foo') == u'foo'
    assert container_to_text(b'f\xe9') == u'f\xe9'
    assert container_to_text(b'f\xe9', encoding='latin-1') == u'f\xe9'
    assert container_to_text(b'f\xe9', encoding='ascii') == u'f\ufffd'
    assert container_to_text({b'key': b'value', b'key2': b'f\xe9'}, encoding='latin-1') == \
        {u'key': u'value', u'key2': u'f\xe9'}

# Generated at 2022-06-22 22:10:34.283276
# Unit test for function to_bytes
def test_to_bytes():
    text_type('abc').encode('utf-8').decode('utf-8')
    text_type('abc').encode('utf-8').decode('utf-8', 'replace')
    text_type('abc').encode('utf-8').decode('utf-8', 'surrogateescape')
    text_type('abc').encode('utf-8').decode('utf-8', 'surrogate_or_strict')
    text_type('abc').encode('utf-8').decode('utf-8', 'surrogate_or_replace')
    text_type('abc').encode('utf-8').decode('utf-8', 'surrogate_then_replace')

    text_type('abc').encode('utf-8').decode('latin-1')

# Generated at 2022-06-22 22:10:44.763336
# Unit test for function container_to_text
def test_container_to_text():
    dict_test = {'aaa':u'bbb', 'ccc':u'ddd', 'eee':u'fff'}
    list_test = ['aaa',u'bbb','ccc',u'ddd','eee',u'fff']
    tuple_test = ('aaa',u'bbb','ccc',u'ddd','eee',u'fff')
    for item in (dict_test, list_test, tuple_test):
        to_test = container_to_text(item)
        assert True == isinstance(to_test, (dict,list,tuple))
        if isinstance(to_test, dict):
            assert True == all(isinstance(k, text_type) for k in to_test.keys())

# Generated at 2022-06-22 22:10:53.428234
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_bytes
    assert jsonify({"a": "b"}) == b'{"a": "b"}'
    assert jsonify({"a": "b"}, indent=4) == b'{\n    "a": "b"\n}'
    assert jsonify({"a": to_bytes("b")}) == b'{"a": "b"}'
    assert jsonify({"a": to_bytes("\xe9")}) == b'{"a": "\xc3\xa9"}'



# Generated at 2022-06-22 22:11:02.565289
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('hello') == b'hello'
    assert to_bytes(b'hello') == b'hello'
    assert to_bytes(b'\xff') == b'\xff'
    assert to_bytes('\xe2\x82\xac') == b'\xe2\x82\xac'
    assert to_bytes(b'\xe2\x82\xac') == b'\xe2\x82\xac'
    assert to_bytes(b'\xe2\x82\xac', 'latin-1') == b'\xe2\x82\xac'

    # Invalid byte sequences
    assert to_bytes(b'\xff\xfe') == b'\xff\xfe'

# Generated at 2022-06-22 22:11:14.177577
# Unit test for function to_bytes
def test_to_bytes():

    # Test that Py2/3 can be called with unicode, str, and bytes and
    # that it always returns a bytes
    value = u'unicode'
    assert isinstance(to_bytes(value), binary_type)
    value = 'str'
    assert isinstance(to_bytes(value), binary_type)
    value = b'bytes'
    assert isinstance(to_bytes(value), binary_type)
    value = u'\ue000'
    assert isinstance(to_bytes(value), binary_type)
    value = '\udc80'
    assert isinstance(to_bytes(value), binary_type)
    value = b'\xdc\x80'
    assert isinstance(to_bytes(value), binary_type)

    # Test nonstring: passthru, strict, simplerepr,

# Generated at 2022-06-22 22:11:24.088360
# Unit test for function to_bytes

# Generated at 2022-06-22 22:11:36.922043
# Unit test for function container_to_text
def test_container_to_text():
    sample_data = {
        'a': {
            'b': bytes(u'test'),
            'c': [bytes(u'test2'), bytes(u'test3')]
        },
        'd': [
            bytes(u'test4'),
            [bytes(u'test5'), [bytes(u'test6'), bytes(u'test7')]]
        ]
    }
    unit_test = container_to_text(sample_data)
    assert set(unit_test.keys()) == set(['a', 'd'])
    assert set(unit_test['a'].keys()) == set(['b', 'c'])
    assert unit_test['a']['b'] == u'test'
    assert unit_test['a']['c'] == [u'test2', u'test3']


# Generated at 2022-06-22 22:11:41.080247
# Unit test for function to_native
def test_to_native():
    # Test for a text type
    assert to_native(u'foo') == u'foo'
    # Test for a byte type
    assert to_native(b'foo') == u'foo'
    # Test for nonstring type
    assert to_native(1) == u'1'
    assert to_native('foo') == u'foo'

