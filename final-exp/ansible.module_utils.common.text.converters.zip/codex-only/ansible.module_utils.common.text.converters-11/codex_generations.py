

# Generated at 2022-06-22 22:01:49.481324
# Unit test for function jsonify
def test_jsonify():
    assert jsonify("test") == '"test"'
    assert jsonify("test-\xe9") == '"test-\xe9"'
    assert jsonify(["test", "test"]) == '["test", "test"]'
    assert jsonify(["test", "test-\xe9"]) == '["test", "test-\xe9"]'
    assert jsonify({"test": "test"}) == '{"test": "test"}'
    assert jsonify({"test": "test-\xe9"}) == '{"test": "test-\xe9"}'
    assert jsonify({"test": "test", "test2": "test2"}) == '{"test": "test", "test2": "test2"}'

# Generated at 2022-06-22 22:02:01.924418
# Unit test for function container_to_text
def test_container_to_text():
    output_dict = {'a': 'string', 'b': u'unicode-string', 'c': ['a list']}
    result_dict = container_to_text({'a': 'string', 'b': u'unicode-string', 'c': [u'a list']})
    assert(result_dict == output_dict)
    # This assert fails if the default encoding is not utf-8,
    # which is not the default encoding.
    assert(result_dict['b'] == u'unicode-string')
    output_list = [u'string',u'unicode-string',[u'a list']]
    result_list = container_to_text([u'string','unicode-string',[u'a list']])
    assert(result_list == output_list)
    output_tuple

# Generated at 2022-06-22 22:02:14.930055
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(
        {
            'a': 'abc',
            'b': [b'foo', 'b\u1234r'],
            'c': {
                'd': '\xe9',
                'e': {
                    'f': '\u1234',
                }
            },
            'g': Set(('foo', 'bar')),
            'h': datetime.datetime(2017, 6, 23, 20, 43),
        },
    ) == (
        b'{"a": "abc", "b": ["foo", "b\udcc0r"], "c": {"d": "\xc3\xa9", "e": {"f": "\udcc0"}}, "g": ["foo", "bar"], "h": "2017-06-23T20:43:00"}'
    )



# Generated at 2022-06-22 22:02:18.371774
# Unit test for function jsonify
def test_jsonify():
    for obj in [
        dict(a=1, b=2),
        dict(a=1, b=Set([2,3,4])),
        dict(a=2, b={u'a':1}),
    ]:
        assert jsonify(obj)
        for encoding in ("utf-8", "latin-1"):
            assert jsonify(obj, ensure_ascii=False).encode(encoding)


# Generated at 2022-06-22 22:02:30.182320
# Unit test for function to_bytes
def test_to_bytes():
    # Test that passing a byte string returns a byte string
    assert isinstance(to_bytes(b'hi'), binary_type)
    assert isinstance(to_bytes(b'hi', nonstring='empty'), binary_type)
    assert isinstance(to_bytes(b'hi', nonstring='passthru'), binary_type)

    # Test that passing a text string returns a byte string
    assert isinstance(to_bytes(u'hi'), binary_type)
    assert isinstance(to_bytes(u'hi', nonstring='empty'), binary_type)
    assert isinstance(to_bytes(u'hi', nonstring='passthru'), binary_type)

    # Test that passing a nonstring returns a byte string
    assert isinstance(to_bytes(1), binary_type)

# Generated at 2022-06-22 22:02:39.618273
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(set(), nonstring='strict') == b'set([])'
    assert to_bytes(set(), nonstring='simplerepr') == b'set([])'
    assert to_bytes(set(), nonstring='passthru') == set()
    assert to_bytes(set(), nonstring='empty') == b''
    assert to_bytes(b'bytes', errors='strict') == b'bytes'
    assert to_bytes(u'unicode', errors='strict') == b'unicode'
    assert to_bytes(u'no ascii here: \u1234', errors='strict') == b'no ascii here: \xe1\x88\xb4'

# Generated at 2022-06-22 22:02:43.821389
# Unit test for function container_to_text
def test_container_to_text():
    d = {'a' : 1, 'b' : 2, 'c' : 3}
    assert container_to_text(d) == d
    d = {b'a' : 1, b'b' : 2, b'c' : 3}
    assert container_to_text(d, errors='surrogate_or_strict') == {'a' : 1, 'b' : 2, 'c' : 3}


# Generated at 2022-06-22 22:02:55.488759
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test a simple decode that does not need to be encoded.
    a = {u'a': u'b'}
    b = container_to_bytes(a)
    assert isinstance(b, dict)
    for key in b:
        assert isinstance(key, binary_type)
        assert isinstance(b[key], binary_type)
    # Test a string that needs to be encoded.
    a = {u'a': u'\u2603'}
    b = container_to_bytes(a)
    assert isinstance(b, dict)
    for key in b:
        assert isinstance(key, binary_type)
        assert isinstance(b[key], binary_type)
    # Test a different string that needs to be encoded.

# Generated at 2022-06-22 22:03:07.391268
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # empty list
    assert container_to_bytes([]) == []

    # list [1,2,3]
    assert container_to_bytes([1, 2, 3]) == [1, 2, 3]

    # tuple (1,2,3)
    assert container_to_bytes((1, 2, 3)) == (1, 2, 3)

    # list of string ['a', 'b', 'c']
    assert container_to_bytes(['a', 'b', 'c']) == [b'a', b'b', b'c']

    # list of utf-8 ['\u263a', '\u2639']

# Generated at 2022-06-22 22:03:17.361140
# Unit test for function container_to_bytes
def test_container_to_bytes():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    s = u"this is a test"
    assert container_to_bytes(s) == b'this is a test'
    assert container_to_bytes(set(s)) == b'this is a test'
    assert container_to_bytes(list(s)) == b'this is a test'
    assert container_to_bytes(dict.fromkeys(s, 1)) == b'1th1is1 1is1 1a1 1test'
    s = u"foo bar baz"
    assert loader.load(loader.get_real_file(u"/tmp/foobarbaz"), s) == b'foo bar baz'



# Generated at 2022-06-22 22:03:28.177411
# Unit test for function to_bytes
def test_to_bytes():
    # error handlers
    assert to_bytes(binary_type(b'\xff')) == binary_type(b'\xff')
    assert to_bytes(u'\udcec') == binary_type(b'\xed\xb3\x8c')
    assert to_bytes(u'\udcec', errors='ignore') == binary_type(b'')
    assert to_bytes(u'\udcec', errors='replace') == binary_type(b'?')
    assert to_bytes(u'\udcec', errors='strict') == binary_type(b'?')
    assert to_bytes(u'\udcec', errors='surrogate_or_strict') == binary_type(b'?')

# Generated at 2022-06-22 22:03:38.132839
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # mock the nested container to test recursively convert the container
    def_container = {
        'a': ['b', 'c'],
        'd': {
            'e': ['f', {'g': 'h'}]
        }
    }
    exp_container = {
        'a': [b'b', b'c'],
        'd': {
            'e': [b'f', {'g': b'h'}]
        }
    }
    assert exp_container == container_to_bytes(def_container)



# Generated at 2022-06-22 22:03:48.655520
# Unit test for function jsonify
def test_jsonify():
    assert(jsonify('abc') == '"abc"')
    assert(jsonify(dict(a=123, b=789, c='abc')) == '{"a": 123, "c": "abc", "b": 789}')
    assert(jsonify(dict(a=123, b=to_bytes('789', 'utf-8'), c='abc')) == '{"a": 123, "c": "abc", "b": "789"}')
    assert(jsonify(dict(a=123, b=to_bytes('789', 'latin-1'), c='abc')) == '{"a": 123, "c": "abc", "b": "789"}')

# Generated at 2022-06-22 22:03:58.308018
# Unit test for function container_to_text
def test_container_to_text():
    from ansible.compat.tests import mock

    # Text type
    with mock.patch('ansible.module_utils._text.to_text') as mock_to_text:
        container_to_text('abc')
        mock_to_text.assert_called_with('abc')

    # Bytes type
    with mock.patch('ansible.module_utils._text.to_text') as mock_to_text:
        container_to_text(b'abc')
        mock_to_text.assert_called_with(b'abc')

    # List
    with mock.patch('ansible.module_utils._text.to_text') as mock_to_text:
        container_to_text([b'one', b'two', b'three'])
        assert mock_to_text.call_count == 3

# Generated at 2022-06-22 22:04:11.067243
# Unit test for function to_bytes
def test_to_bytes():
    def test(x, y, enc='utf-8', errors=None, nonstring='simplerepr'):
        z = to_bytes(x, enc, errors, nonstring)
        try:
            assert z == y
        except AssertionError:
            print('%s -> %s != %s (%s, %s)' % (x, z, y, enc, errors))
            raise

    # Empty strings
    test(u'', b'')
    test(b'', b'')
    test(b'', b'', 'ascii')
    test(b'', b'', 'ascii', 'strict')
    test(b'', b'', 'ascii', 'ignore')
    test(b'', b'', 'ascii', 'replace')

# Generated at 2022-06-22 22:04:17.860575
# Unit test for function to_native
def test_to_native():
    # We just want to make sure that we're not experiencing
    # 'surrogateescape' with native strings and unicode strings
    test_bytes = b'\xff\xff'
    test_unicode = u'\uffff'
    assert(test_bytes == to_native(test_bytes))
    assert(test_unicode == to_native(test_unicode))



# Generated at 2022-06-22 22:04:28.485682
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.basic import to_bytes
    def test(t, s, e='utf-8', es='strict'):
        assert to_bytes(t, e, es) == s
        assert to_bytes(s, e, es) == s
        assert to_bytes(u'%s' % t, e, es) == s
        assert to_bytes(b'%s' % t, e, es) == s
        for es in ('strict', 'replace', 'surrogateescape', 'surrogate_or_strict', 'surrogate_or_replace', 'surrogate_then_replace'):
            assert to_bytes(t, 'utf-8', es) == s
            assert to_bytes(s, 'utf-8', es) == s

# Generated at 2022-06-22 22:04:36.274535
# Unit test for function jsonify
def test_jsonify():
    # first test using non-ASCII characters
    data = {"key": "val\xe9"}
    new_data = container_to_text(data)
    jdata = jsonify(new_data)
    assert jdata == '{"key": "val\\\\u00e9"}'

    # now test using non-text data
    data = {"key": Set(['val1', 'val2'])}
    jdata = jsonify(data)
    assert jdata == '{"key": ["val1", "val2"]}'


# Generated at 2022-06-22 22:04:48.324512
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({'a': [1, 2]}) == {b'a': [1, 2]}
    assert container_to_bytes({u'a': [1, 2]}) == {b'a': [1, 2]}
    assert container_to_bytes({u'a': [1, 2], b'b': [3, 4]}) == {b'a': [1, 2], b'b': [3, 4]}
    assert container_to_bytes({u'a': [1, 2], b'b': [3, 4], 5: [6, 7]}) == {b'a': [1, 2], b'b': [3, 4], 5: [6, 7]}

# Generated at 2022-06-22 22:04:54.987507
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'abc', '1-byte-encoding') == b'abc'
    assert to_bytes(u'\u263A', '1-byte-encoding', nonstring='strict') == b'\xe2\x98\xba'
    assert to_bytes(u'\u263A', '1-byte-encoding', errors='surrogate_or_strict') == b'\xe2\x98\xba'
    assert to_bytes(u'\u263A', '1-byte-encoding', errors='surrogate_or_replace') == b'\xe2\x98\xba'

# Generated at 2022-06-22 22:05:03.181920
# Unit test for function container_to_text
def test_container_to_text():
    from nose.tools import assert_equals
    _assert_function_call(assert_equals, container_to_text,
                          [{b'b1': b'v1', u'u1': u'v2'}, {b'b2': b'v3', u'u2': u'v4'}],
                          [{b'b1': u'v1', u'u1': u'v2'}, {b'b2': u'v3', u'u2': u'v4'}])

# Generated at 2022-06-22 22:05:13.210610
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # test converting a dict
    d = { b'key' : b'value' }
    assert (container_to_bytes(d) == d )
    d = { u'key' : u'value' }
    assert (container_to_bytes(d, encoding='latin-1') == {'key': 'value'})
    # test converting a list
    l = [b'list1', b'list2']
    assert (container_to_bytes(l) == l )
    l = [u'list1', u'list2']
    assert (container_to_bytes(l, encoding='latin-1') == ['list1', 'list2'])
    # test converting a tuple
    t = (b'tuple1', b'tuple2')
    assert (container_to_bytes(t) == t )
   

# Generated at 2022-06-22 22:05:19.515282
# Unit test for function container_to_bytes
def test_container_to_bytes():
    ansible_vars = {
        u'y': {
            u'x': [u'a', 1, 2, 3, [u'b', u'\ubcf4', u'\ue000']]
        },
        u'z': u'\ubcf4\ue000'
    }
    assert container_to_bytes(ansible_vars) == b'{b"y": {b"x": [b"a", 1, 2, 3, [b"b", b"\\ubcf4", b"\\ue000"]]}, b"z": b"\\ubcf4\\ue000"}'


# Generated at 2022-06-22 22:05:30.136236
# Unit test for function jsonify

# Generated at 2022-06-22 22:05:38.950558
# Unit test for function jsonify
def test_jsonify():
    data = dict(a=set([1,2,3]), b=u(u'\xe4\xf6\xfc'))
    # same as running:
    #   json_data = dict([(k,list(v)) for k,v in data.items()])
    #   json_data['b'] = data['b'].encode('utf-8')
    json_data = dict(a=[1,2,3], b=u(u'\xe4\xf6\xfc').encode('utf-8'))
    assert json_data == json.loads(jsonify(data))


# Generated at 2022-06-22 22:05:43.636828
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'你好') == u'你好'
    assert to_native(u'\xe4\xbd\xa0\xe5\xa5\xbd') == u'你好'


# Generated at 2022-06-22 22:05:55.061568
# Unit test for function to_native

# Generated at 2022-06-22 22:06:03.121657
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('123') == b'123'
    assert to_bytes(u'123') == b'123'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='replace') == b'\xef\xbf\xbd'
    assert to_bytes(u'\udc00') == b'\xed\xb0\x80'
    assert to_bytes(u'\udc00', errors='replace') == b'\xef\xbf\xbd'
    assert to_bytes('') == b''
    assert to_bytes(b'123') == b'123'

# Generated at 2022-06-22 22:06:11.912067
# Unit test for function container_to_bytes
def test_container_to_bytes():
    fixture = {"a": 1, "b": 2, "c": [1, 2, 3]}
    encode_delimiter = u'\u20ac'
    fixture_encoded = {u"a".encode('utf-8') + encode_delimiter: 1, u"b".encode('utf-8') + encode_delimiter: 2, u"c".encode('utf-8') + encode_delimiter: [1, 2, 3]}
    assert container_to_bytes(fixture) == fixture
    assert container_to_bytes(fixture_encoded) == fixture_encoded
    assert container_to_bytes(fixture, encoding='utf-8', errors='surrogate_or_strict') == fixture_encoded


# Generated at 2022-06-22 22:06:19.698259
# Unit test for function to_bytes
def test_to_bytes():
    # type: () -> None
    assert to_bytes('abc') == b'abc'
    assert to_bytes(b'\x80\x81') == b'\x80\x81'
    assert to_bytes('\xe2\x80\xa8') == b'\xe2\x80\xa8'
    assert to_bytes(u'\xe2\x80\xa8') == b'\xe2\x80\xa8'
    assert to_bytes('123', encoding='ascii') == b'123'
    assert to_bytes(u'123', encoding='ascii') == b'123'
    assert to_bytes('123', encoding='ascii', errors='ignore') == b'123'

# Generated at 2022-06-22 22:06:26.354599
# Unit test for function container_to_text
def test_container_to_text():
    data_types = [
        'foo',
        ['foo'],
        {'foo': 'bar'},
        ('foo',),
        ('foo', 'bar')
    ]
    for data_type in data_types:
        try:
            assert data_type == container_to_text(to_bytes(data_type))
        except Exception:
            print('%s is not converted to container_to_text' % data_type)
            raise


# Generated at 2022-06-22 22:06:37.116587
# Unit test for function jsonify
def test_jsonify():
    import ansible.module_utils._text as text

    # Should be able to use the jsonify to convert a dict
    d = { b'byte_str_key' : 'value', u'unicode_str_key' : u'value' }
    json_str = text.jsonify(d)
    assert json_str == u'{"byte_str_key": "value", "unicode_str_key": "value"}'

    # Should be able to use the jsonify to convert a list
    l = [ b'byte_str_key', u'unicode_str_key' ]
    json_str = text.jsonify(l)
    assert json_str == u'["byte_str_key", "unicode_str_key"]'


# Generated at 2022-06-22 22:06:38.804394
# Unit test for function jsonify
def test_jsonify():
    class TestObject:
        def __repr__(self):
            return u"Test"
    assert jsonify({"a": {"b": TestObject()}}) == '{"a": {"b": "Test"}}'



# Generated at 2022-06-22 22:06:47.872384
# Unit test for function container_to_text
def test_container_to_text():
    def recursive_compare(obj1, obj2):
        if isinstance(obj1, dict):
            assert isinstance(obj2, dict)
            for key in obj1.keys():
                assert key in obj2
                recursive_compare(obj1[key], obj2[key])
        elif isinstance(obj1, list):
            assert isinstance(obj2, list)
            assert len(obj1) == len(obj2)
            for e1, e2 in zip(obj1, obj2):
                recursive_compare(e1, e2)
        elif isinstance(obj1, tuple):
            assert isinstance(obj2, tuple)
            assert len(obj1) == len(obj2)

# Generated at 2022-06-22 22:06:59.280802
# Unit test for function to_bytes
def test_to_bytes():
    # These all return byte strings
    assert isinstance(to_bytes(u'foo'), binary_type)
    assert isinstance(to_bytes(b'foo'), binary_type)
    assert isinstance(to_bytes(u'föo'), binary_type)
    assert isinstance(to_bytes(u'föo'.encode('latin-1'), 'cp65001'), binary_type)
    assert isinstance(to_bytes(u'föo'.encode('latin-1'), 'cp65001', 'surrogate_or_strict'), binary_type)
    assert isinstance(to_bytes(u'föo'.encode('latin-1'), 'cp65001', 'surrogate_or_replace'), binary_type)

# Generated at 2022-06-22 22:07:03.886273
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text(['a', ['b', ['c']]]) == ['a', ['b', ['c']]]
    assert container_to_text((b'a', (b'b', (b'c',)))) == ('a', ('b', ('c',)))



# Generated at 2022-06-22 22:07:14.084831
# Unit test for function to_bytes
def test_to_bytes():
    assert 'hello' == to_bytes(u'hello')
    assert 'hello' == to_bytes(u'hello', errors='surrogate_or_replace')
    assert b'hello' is to_bytes(u'hello', errors='surrogate_or_strict')
    assert b'hello' is to_bytes(b'hello')
    assert b'hello' is to_bytes(b'hello', errors='surrogate_or_replace')
    assert repr(b'hello') == to_bytes(b'hello', errors='surrogate_or_strict')

    assert to_bytes(True) == b'True'
    assert to_bytes(False) == b'False'
    assert to_bytes(1) == b'1'

# Generated at 2022-06-22 22:07:23.874441
# Unit test for function jsonify

# Generated at 2022-06-22 22:07:31.467765
# Unit test for function to_bytes
def test_to_bytes():
    def validate(pass_in, expected, encoding='utf-8', errors=None, nonstring='simplerepr'):
        result = to_bytes(pass_in, encoding=encoding, errors=errors, nonstring=nonstring)
        assert isinstance(result, binary_type)
        assert result == expected

    # Try text strings
    validate(u'\u2713', '\xe2\x9c\x93', encoding='utf-8')
    validate(u'\u2713', '\xe2\x9c\x93', encoding='utf-8', errors=None)
    validate(u'\u2713', '\xe2\x9c\x93', encoding='utf-8', errors='surrogateescape')

# Generated at 2022-06-22 22:07:44.389953
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(dict(k1=1,k2='2')) == dict(k1=b'1',k2=b'2')
    assert container_to_bytes(dict(k1=1,k2='2'), encoding='ascii') == dict(k1=b'1',k2=b'2')
    assert container_to_bytes(dict(k1=1,k2='2',k3=u'3é')) == dict(k1=b'1',k2=b'2',k3=b'3\xc3\xa9')

# Generated at 2022-06-22 22:07:53.025090
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils import basic

    def jsonify_obj(obj, **kwargs):
        try:
            return jsonify(obj, **kwargs)
        except UnicodeDecodeError:
            return '<UnicodeDecodeError>'

    # Call jsonify with a unicode type object
    obj = u'test'
    assert jsonify_obj(obj) == u'"test"'

    # Call jsonify with a unicode type string that can cause decode errors
    obj = '\xe2\x28\xa1'
    assert jsonify_obj(obj) == '<UnicodeDecodeError>'

    # Call jsonify with a byte type string
    obj = '\xe2\x28\xa1'

# Generated at 2022-06-22 22:08:00.717331
# Unit test for function jsonify
def test_jsonify():
    """Test for function jsonify"""
    data = {u"a": "A", u"b": "B", u"c": [u"C"], u"d": {"e": "E", "f": {"g": "G", "h": u"\u2665"}, "i": u"I"}, u"j": set([u"J", u"K"]), u"l": u"\u2665", u"m": [1, 2, 3], u"n": {u"o": {"p": u"\u2665"}, u"q": [1, 2, 3]}}
    data = container_to_text(data)
    new_data = jsonify(data)
    print(new_data)



# Generated at 2022-06-22 22:08:11.703330
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.common._text import to_text
    if PY3:
        py2_unichr = None
    else:
        from __builtin__ import unichr as py2_unichr

    def make_str(string):
        if isinstance(string, bytes):
            return to_text(string, 'utf-8', errors='surrogate_then_replace')
        return string

    def make_b(string):
        if isinstance(string, text_type):
            return to_bytes(string, 'utf-8', errors='surrogate_then_replace')
        return string

    def unicodable(string):
        try:
            return make_b(string)
        except UnicodeError:
            return False


# Generated at 2022-06-22 22:08:21.130417
# Unit test for function container_to_text
def test_container_to_text():

    # Test for Dictionary
    d = {"ubuntu" : ["command1", "command2", "command3"]}
    assert container_to_text(d) == {"ubuntu" : ["command1", "command2", "command3"]}
    # Test for List
    data = ["ubuntu", "command1", "command2"]
    assert container_to_text(data) == ["ubuntu", "command1", "command2"]
    # Test for Tuple
    tup = ("ubuntu", "command1", "command2")
    assert container_to_text(tup) == ("ubuntu", "command1", "command2")
    # Test for conversion of bytestring to text string
    b = b'ubuntu'
    assert container_to_text(b) == 'ubuntu'



# Generated at 2022-06-22 22:08:32.893191
# Unit test for function to_native

# Generated at 2022-06-22 22:08:41.431876
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes([{"foo": 'bar'}]) == [{"foo": b'bar'}]
    assert container_to_bytes({"foo": 'bar'}) == {"foo": b'bar'}
    assert container_to_bytes({"foo": 1}) == {"foo": 1}
    assert container_to_bytes(["foo", "bar"]) == [b"foo", b"bar"]
    assert container_to_bytes(("foo", "bar")) == (b"foo", b"bar")



# Generated at 2022-06-22 22:08:42.864645
# Unit test for function to_native
def test_to_native():
    pass

to_native = to_str = to_bytes



# Generated at 2022-06-22 22:08:51.871335
# Unit test for function to_bytes

# Generated at 2022-06-22 22:08:57.724680
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(1) == b'1'
    assert to_bytes(1, nonstring='passthru') == 1
    try:
        to_bytes(1, nonstring='strict')
        assert False
    except TypeError:
        pass
    try:
        to_bytes(1, nonstring='invalid')
        assert False
    except TypeError:
        pass


# Generated at 2022-06-22 22:09:01.628647
# Unit test for function to_native
def test_to_native():
    def test(value, expected):
        actual = to_native(value)
        assert expected == actual
        print("Test ok")
    test('test_value', 'test_value')


# Generated at 2022-06-22 22:09:13.691714
# Unit test for function container_to_text
def test_container_to_text():
    import copy
    x = {u"key1": u"value1"}
    assert x == container_to_text(copy.deepcopy(x))

    x = {u"key1": u"value1".encode('utf-8')}
    assert x == container_to_text(copy.deepcopy(x))
    assert x == container_to_text(copy.deepcopy(x), errors='surrogate_or_strict')
    assert x == container_to_text(copy.deepcopy(x), errors='surrogate_or_replace')
    assert x == container_to_text(copy.deepcopy(x), errors='surrogate_then_replace')

    x = {u"key1": u"value1".encode('utf-8')}
    # This will fail without surrogate_or_replace or surrogate

# Generated at 2022-06-22 22:09:23.896261
# Unit test for function jsonify
def test_jsonify():
    """Unit test for function jsonify"""
    from ansible.module_utils.six import StringIO
    import sys
    import traceback

    # If a user uses the following code,
    # the unittest completes with a traceback.
    # >>> ansible.module_utils.six.moves.StringIO(u'\u3042')
    # >>> ansible.module_utils.jsonify({u'\u3042': u'\u3042'})
    #
    # The unittest below is to judge that the code above does not generate a traceback in this function.

    fh = StringIO(u'\u3042')
    sys.stdin = fh
    json.loads(u'{u"\u3042": u"\u3042"}')

# Generated at 2022-06-22 22:09:31.417288
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test dict
    d = {
        'key': 'value',
        u'key\u2713': u'value\u2713',
        u'key\u2713\u2713': [u'value\u2713\u2713'],
    }
    result = container_to_bytes(d)
    for key in d:
        assert isinstance(key, str)
        assert isinstance(result[key], str)
    assert isinstance(result[b'key\xe2\x9c\x93'], str)
    assert isinstance(result[b'key\xe2\x9c\x93\xe2\x9c\x93'], list)

# Generated at 2022-06-22 22:09:41.159147
# Unit test for function to_bytes
def test_to_bytes():
    '''
    :param obj:
    :return:
    '''
    assert to_bytes('', nonstring='strict') == b''
    assert to_bytes('', nonstring='empty') == b''
    assert to_bytes('', nonstring='passthru') == ''
    assert to_bytes('', nonstring='simplerepr') == b''

    assert to_bytes('Hello') == b'Hello'
    assert to_bytes('Hello', encoding='ascii') == b'Hello'
    assert to_bytes(u'Hello') == b'Hello'
    assert to_bytes(u'Hello', encoding='ascii') == b'Hello'
    assert to_bytes(b'Hello', encoding='ascii') == b'Hello'

# Generated at 2022-06-22 22:09:52.833374
# Unit test for function to_native
def test_to_native():
    text = b'\xd1\x80\xd1\x83\xd1\x81\xd1\x81\xd0\xba\xd0\xb8\xd0\xb9'
    assert to_native(text) == text.decode('utf-8')
    assert to_native(text, 'latin-1') == text.decode('utf-8')
    assert to_native(text, 'ascii') == text.decode('utf-8')

    # This will fail on non-utf8 python, which is fine.
    try:
        assert to_native(text, errors='surrogate_then_replace') == '???????'
    except UnicodeDecodeError:
        # It's fine, we're not testing this codepath right now.
        pass


# Generated at 2022-06-22 22:09:57.945087
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({u'bytes': u'\xe9'}) == {b'bytes': b'\xc3\xa9'}
    assert container_to_bytes([b'\xc3\xa9']) == [b'\xc3\xa9']



# Generated at 2022-06-22 22:10:06.560958
# Unit test for function container_to_text
def test_container_to_text():
    # Strings are passed through unchanged
    assert 'abc' == container_to_text('abc')
    assert u'abc' == container_to_text(u'abc')
    # byte string is decoded to text
    assert u'abc' == container_to_text(b'abc')
    # int should not be touched
    assert 1 == container_to_text(1)
    # container should return a container of the same type
    assert [u'abc', 1] == container_to_text([u'abc', 1])
    assert (u'abc', 1) == container_to_text((u'abc', 1))
    assert {'a': u'abc', 'b': 1} == container_to_text({'a': u'abc', 'b': 1})



# Generated at 2022-06-22 22:10:12.199678
# Unit test for function to_native
def test_to_native():
    assert to_native(b'bytes') == u'bytes'
    assert to_native('unicode') == u'unicode'
    assert to_native(1) == u'1'
    assert to_native(None) == u'None'

    a = object()
    assert to_native(a) == repr(a)



# Generated at 2022-06-22 22:10:23.980554
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {'key': u'val', 'nonstring': 1, 'list': [u'a', u'b', 1]}
    e = container_to_bytes(d)
    assert isinstance(e['key'], binary_type)
    assert isinstance(e['nonstring'], int)
    assert isinstance(e['list'], list)
    for v in e['list']:
        assert isinstance(v, binary_type)
    # test with non-default arguments
    d = {u'key': u'val'}
    e = container_to_bytes(d, encoding="latin-1", errors="replace")
    assert isinstance(e['key'], binary_type)
    assert e['key'] == b'val'
    d = {u'key': b'val'}
    e = container

# Generated at 2022-06-22 22:10:34.129724
# Unit test for function container_to_bytes
def test_container_to_bytes():
    result = container_to_bytes({'a': 1, 'b': 2}, 'ascii')
    assert result['a'] == b'1'
    assert result['b'] == b'2'
    assert isinstance(result, dict)
    assert isinstance(result['a'], binary_type)
    assert isinstance(result['b'], binary_type)

    result = container_to_bytes(['a', 'b'], 'ascii')
    assert result[0] == b'a'
    assert result[1] == b'b'
    assert isinstance(result, list)
    assert isinstance(result[0], binary_type)
    assert isinstance(result[1], binary_type)

    result = container_to_bytes(('a', 'b'), 'ascii')

# Generated at 2022-06-22 22:10:44.700817
# Unit test for function container_to_text
def test_container_to_text():
    mytuple = (u'Ivan Krsti\u0107', 141, u'GitHub', u'San Francisco')
    mydict = {'x': 12, 'y': 23}

    assert container_to_text(mytuple) == mytuple
    assert container_to_text(mydict) == mydict
    assert container_to_text({u'utf8': u'string\u2713'}) == {u'utf8': u'string\u2713'}

    # Test conversion
    mytuple = (b'Ivan Krsti\xc4\x87', 141, b'GitHub', b'San Francisco')
    mydict = {'x': 12, 'y': 23}

    # Test conversion

# Generated at 2022-06-22 22:10:56.734179
# Unit test for function container_to_text
def test_container_to_text():
    """Unit test for function to_text"""
    test_dict = dict(A = dict(a = dict(aa = '', ab = 'aa'), b = ['aa', 'ab']),
                     B = dict(a = dict(aa = '', ab = 'aa'), b = ['aa', 'ab']))
    test_dict_str = dict(A = dict(a = dict(aa = '', ab = 'aa'), b = ['aa', 'ab']),
                         B = dict(a = dict(aa = '', ab = 'aa'), b = ['aa', 'ab']))
    result = container_to_text((), test_dict)
    assert result == tuple()
    result = container_to_text((), test_dict_str)
    assert result == tuple()

# Generated at 2022-06-22 22:11:00.179016
# Unit test for function jsonify
def test_jsonify():
    json_1 = jsonify({u'abc': u'ABC'})
    json_2 = jsonify({b'abc': b'ABC'})
    assert _is_json(json_1) is True
    assert _is_json(json_2) is True


# Generated at 2022-06-22 22:11:10.874873
# Unit test for function to_bytes
def test_to_bytes():
    # Test that it returns a byte string
    assert isinstance(to_bytes('abc'), binary_type)

    if PY3:
        # Test that it converts text strings to bytes
        assert b'abc' == to_bytes('abc')

        # Test that it doesn't error if it's already bytes
        assert b'abc' == to_bytes(b'abc')

        def unicode_error_handler(exc):
            if exc.object[exc.start] == '\udcff':
                return u'', exc.end
            raise exc

        # Test error handler with surrogates
        codecs.register_error('test.unicode_error_handler',
                              unicode_error_handler)

# Generated at 2022-06-22 22:11:20.838568
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes({'a': u'A', 'b': u'B'}) == {b'a': b'A', b'b': b'B'}
    assert container_to_bytes([u'a', u'b']) == [b'a', b'b']
    assert container_to_bytes((u'a', u'b')) == (b'a', b'b')
    assert container_to_bytes({u'a': [u'a']}) == {b'a': [b'a']}
    assert container_to_bytes({u'a': (u'a', u'b')}) == {b'a': (b'a', b'b')}



# Generated at 2022-06-22 22:11:33.734283
# Unit test for function jsonify
def test_jsonify():
    assert jsonify([u'list ünit test', u'list ünit test']) == '["list \\u00fcnit test", "list \\u00fcnit test"]'
    assert jsonify({"key ünit test": "value ünit test"}) == '{"key \\u00fcnit test": "value \\u00fcnit test"}'
    assert jsonify({"key_unit_test": [u'list ünit test', u'list ünit test']}) == '{"key_unit_test": ["list \\u00fcnit test", "list \\u00fcnit test"]}'

# Generated at 2022-06-22 22:11:37.845345
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes('foo') == b'foo'
    assert container_to_bytes(u'\u00e9') == b'\xc3\xa9'
    assert container_to_bytes([u'\u00e9']) == [b'\xc3\xa9']
    assert container_to_bytes([u'\u00e9']) == [b'\xc3\xa9']
    assert container_to_bytes({u'\u00e9': u'\u00e9'}) == {b'\xc3\xa9': b'\xc3\xa9'}



# Generated at 2022-06-22 22:11:45.246825
# Unit test for function to_native
def test_to_native():
    # Test simple conversions
    assert b'A' == to_bytes(u'A')
    assert b'A' == to_bytes(u'A', errors='strict')
    assert b'A' == to_bytes(b'A')
    assert b'A' == to_bytes(b'A', errors='strict')
    assert u'A' == to_text(u'A')
    assert u'A' == to_text(u'A', errors='strict')
    assert u'A' == to_text(b'A')
    assert u'A' == to_text(b'A', errors='strict')

    # Check we can return the same object we were passed