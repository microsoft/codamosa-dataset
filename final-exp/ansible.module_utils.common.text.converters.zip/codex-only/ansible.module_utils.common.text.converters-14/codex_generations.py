

# Generated at 2022-06-22 22:01:47.302701
# Unit test for function container_to_bytes
def test_container_to_bytes():
    t = u'\u00e9'
    d = {u'a':u'a'+t, u'b':[u'b'+t], u'c':(u'c'+t,)}
    e = {b'a':b'a\xc3\xa9', b'b':[b'b\xc3\xa9'], b'c':(b'c\xc3\xa9',)}
    x = container_to_bytes(d)
    assert e == x



# Generated at 2022-06-22 22:01:57.279380
# Unit test for function container_to_bytes
def test_container_to_bytes():
    d = {'k1': ['v1', b'v2', u'v3'], u'k2': {b'k2.1': 'v2.1'},
            123: b'value', 'k3': {u'k4': (b'v4', u'v5', b'v6')}}
    assert (container_to_bytes(d) == {b'k1': [b'v1', b'v2', b'v3'], b'k2': {b'k2.1': b'v2.1'},
                                          123: b'value', b'k3': {b'k4': (b'v4', b'v5', b'v6')}})


# Generated at 2022-06-22 22:02:05.466673
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.six import u

    def do_test(text, ascii_result, utf8_result, latin_1_result):
        assert text == to_text(text, errors='surrogate_or_strict')
        assert text == to_text(to_bytes(text, errors='surrogate_or_strict'))

        # Test with None
        assert ascii_result is None or isinstance(ascii_result, binary_type)
        assert utf8_result is None or isinstance(utf8_result, binary_type)
        assert latin_1_result is None or isinstance(latin_1_result, binary_type)
        assert to_bytes(text, 'ascii', errors='surrogate_or_replace') == ascii_result


# Generated at 2022-06-22 22:02:08.568304
# Unit test for function to_native
def test_to_native():
  tmp_value = to_native(unicode)
  assert tmp_value == str


# Generated at 2022-06-22 22:02:19.097581
# Unit test for function to_native

# Generated at 2022-06-22 22:02:30.825333
# Unit test for function container_to_bytes
def test_container_to_bytes():
    if not PY3:
        assert isinstance(container_to_bytes(u"simple string"), binary_type)
        assert isinstance(container_to_bytes(u"\u3042", errors='surrogate_then_replace'), binary_type)
        assert isinstance(container_to_bytes(u"\u3042", errors='surrogate_or_replace'), binary_type)
        assert isinstance(container_to_bytes(u"\u3042", errors='surrogate_or_strict'), binary_type)
        assert isinstance(container_to_bytes(u"\ud800"), binary_type)
    assert isinstance(container_to_bytes({u"key": u"value"}), dict)
    assert isinstance(container_to_bytes([u"value"]), list)

# Generated at 2022-06-22 22:02:42.953705
# Unit test for function to_bytes
def test_to_bytes():
    # We cannot use ``assert_equal`` here because that prints out the byte
    # strings which has the effect of converting them to text strings.  We don't
    # want that because part of what is being tested is that the byte strings
    # are not converted to text strings.
    #
    # Also note that this will fail if run on an OS that uses a different
    # encoding than UTF-8 as the system default.
    assert to_bytes(u'ሴ') == b'\xe1\x88\xb4'
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'


# Generated at 2022-06-22 22:02:45.118930
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native('foo') == 'foo'



# Generated at 2022-06-22 22:02:57.005072
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text({}) == {}
    assert container_to_text("") == u""
    assert container_to_text("\n") == u"\n"

    # Test unicode strings
    assert container_to_text(u"\xf6") == u"\xf6"

    # Test byte strings
    assert container_to_text("\xc3\xb6") == u"\xf6"

    # Test nested data structures
    assert container_to_text({u"\xf6": u"\xf6"}) == {u"\xf6": u"\xf6"}
    assert container_to_text({u"\xf6": "\xc3\xb6"}) == {u"\xf6": u"\xf6"}

# Generated at 2022-06-22 22:03:08.726605
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'example') == b'example'
    assert to_bytes('example') == b'example'
    assert to_bytes(u'example') == b'example'
    assert to_bytes(u'Þ') == b'\xc3\x9e'

    # Errors
    assert to_bytes(u'\U0001F4A9') == b'\xf0\x9f\x92\xa9'
    assert to_bytes(u'\udcd2') == b'\xed\xb3\x92'
    assert to_bytes(u'\udcd2', errors='surrogate_or_replace') == b'?\xb3\x92'

# Generated at 2022-06-22 22:03:11.092465
# Unit test for function to_native
def test_to_native():
    test = u'你好'
    text = to_native(test)
    print(text)
    # Unit test for function to_text

# Generated at 2022-06-22 22:03:21.098963
# Unit test for function jsonify
def test_jsonify():
    import sys
    if sys.version_info < (2, 7):
        from unittest2 import TestCase
    else:
        from unittest import TestCase
    import json

    class JsonTestCase(TestCase):

        def test_jsonify(self):
            data = "just a string"
            res = jsonify(data)
            self.assertEqual(json.dumps(data), res)

            data = [u"unicode", b"bytestring"]
            res = jsonify(data)
            self.assertEqual(data, json.loads(res))

            data = {u"unicode": u"unicode", b"bytestring": b"bytestring", "mixed": [1, u"unicode", b"bytestring"]}
            res = jsonify(data)
            self

# Generated at 2022-06-22 22:03:29.704605
# Unit test for function container_to_text
def test_container_to_text():
    # See all the possible cases in function container_to_text
    unicode_str = u'\u041b\u0435\u0441\u043d\u043e'
    byte_str = unicode_str.encode('utf-8')
    container = (unicode_str, byte_str, {byte_str: unicode_str}, [unicode_str], (unicode_str,))
    test_result = container_to_text(container)
    assert isinstance(test_result, tuple)
    assert isinstance(test_result[0], text_type)
    assert isinstance(test_result[1], text_type)
    assert isinstance(test_result[2], dict)
    assert isinstance(test_result[3], list)
    assert isinstance(test_result[4], tuple)

# Generated at 2022-06-22 22:03:39.714693
# Unit test for function to_native
def test_to_native():
    # TODO: Add tests for when we have non-UTF-8 characters in the environment
    # and locale
    b_ascii = to_bytes("foo", nonstring='passthru')
    assert isinstance(b_ascii, binary_type)
    assert to_native(b_ascii) == "foo"

    from_unicode = to_text(u'\u6709', nonstring='passthru')
    assert isinstance(from_unicode, text_type)
    assert to_native(from_unicode) == u'\u6709'



# Generated at 2022-06-22 22:03:49.844416
# Unit test for function to_bytes
def test_to_bytes():
    try:
        codecs.lookup_error('surrogateescape')
        HAS_SURROGATEESCAPE = True
    except LookupError:
        HAS_SURROGATEESCAPE = False

    for bstr in (b'Yay for ascii', b'Yay for \xff'):
        assert to_bytes(bstr) == bstr

    if HAS_SURROGATEESCAPE:
        for text in (u'Yay for ascii', u'Yay for \U00012345'):
            assert to_bytes(text) == text.encode('utf-8', 'surrogateescape')
    else:
        for text in (u'Yay for ascii', u'Yay for \U00012345'):
            assert to_bytes(text) == text.encode

# Generated at 2022-06-22 22:03:52.979529
# Unit test for function to_native
def test_to_native():
    "Check that serialization is behaving according to spec"
    # I can't think of a way to test that this isn't importing
    # the native_ module right now but I'll leave the test in
    # for future use
    assert to_native


# Generated at 2022-06-22 22:03:57.170891
# Unit test for function jsonify
def test_jsonify():
    result = jsonify({'key1': 'foo', 'key2': b'\xc3\xb6'})
    print('Json Serialization Result: {}'.format(result))


# Generated at 2022-06-22 22:04:10.195493
# Unit test for function container_to_text
def test_container_to_text():
    # When encoding is utf-8, we should be able to convert a dict containing decoded utf-8 strings.
    test_dict = {'foo': {u'b\xe4r': u'value', u'foo': u'bar'}, 'bar': [u'a', u'bc', u'\xe4']}
    expected_dict = {'foo': {u'b\xe4r': u'value', u'foo': u'bar'}, 'bar': [u'a', u'bc', u'\xe4']}
    res_dict = container_to_text(test_dict, encoding='utf-8')
    assert res_dict == expected_dict, "container_to_text doesn't work when encoding utf-8"

    # When encoding is ascii, we should get a UnicodeEncodeError from a unic

# Generated at 2022-06-22 22:04:18.023632
# Unit test for function to_native
def test_to_native():
    for value in (
            u"ö",
            b'\xc3\xb6',
            bytearray(b'\xc3\xb6'),
            6,
            6.0,
            datetime.date(2000, 1, 1),
            [1],
            (1,),
            {1: 2},
            {"a": "b"},
            u"\u263a",
            b"\xe2\x98\xba",
            bytearray(b"\xe2\x98\xba"),
            datetime.datetime(2001, 12, 12),
    ):
        result = to_native(value, nonstring='simplerepr')
        assert isinstance(result, text_type)
        assert to_text(result) == to_text(value, nonstring='simplerepr')



# Generated at 2022-06-22 22:04:28.887248
# Unit test for function container_to_bytes
def test_container_to_bytes():
    for d in [dict(foo='bar', baz=u'\xe1\xe9\xed\xfa\u6c34\u5e74'),
              [u'\xe1\xe9\xed\xfa\u6c34\u5e74', 1, 2, 3],
              (u'\xe1\xe9\xed\xfa\u6c34\u5e74', 1, 2, 3)]:
        r = container_to_bytes(d, encoding='utf-8', errors='strict')
        # this error is raised if we cannot encode the bytes using strict
        old_ex = UnicodeError('encoding without a replacement character, but no surrogates are allowed')

# Generated at 2022-06-22 22:04:39.187685
# Unit test for function to_bytes
def test_to_bytes():
    # When surrogateescape is available, these should all work on Python2
    test0 = to_bytes(b'\xe9', errors='surrogate_or_replace')
    assert test0 == b'\xc3\xa9'
    test1 = to_bytes(b'\xe9', errors='surrogate_or_strict')
    assert test1 == b'\xc3\xa9'
    test2 = to_bytes(b'\xe9', errors='surrogate_then_replace')
    assert test2 == b'\xc3\xa9'
    test3 = to_bytes(b'\xe9', errors='surrogate_then_replace', encoding='latin-1')
    assert test3 == b'\xe9'
    # The following is only supported in Python 3.6
    # test4 =

# Generated at 2022-06-22 22:04:47.542451
# Unit test for function container_to_text
def test_container_to_text():
    b_dictionary = {'k1': b'v1'}
    b_list = [b'v1']
    b_tuple = (b'v1',)
    f_dictionary = {'k1': 'v1'}

    assert container_to_text(b_dictionary) == f_dictionary
    assert container_to_text(b_list) == ['v1']
    assert container_to_text(b_tuple) == ('v1',)



# Generated at 2022-06-22 22:04:53.018040
# Unit test for function container_to_text
def test_container_to_text():
    j_str = json.dumps({'str': 'str', 'unicode': u'\u043f\u0440\u0438\u0432\u0456\u0442', 'bytestr': b'bytestr'})
    j_str = container_to_text(json.loads(j_str))
    assert j_str['str'] == 'str'
    assert j_str['unicode'] == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert j_str['bytestr'] == 'bytestr'



# Generated at 2022-06-22 22:04:57.654009
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test 1
    in_str = u'[{"a": "b", "c": "d"}]'
    out_str = b'[{"a": "b", "c": "d"}]'
    assert_equal(container_to_bytes(json.loads(in_str)), json.loads(out_str))

    # Test 2
    in_str = u'["a", "b", "c"]'
    out_str = b'["a", "b", "c"]'
    assert_equal(container_to_bytes(json.loads(in_str)), json.loads(out_str))

    # Test 3
    in_str = u'{"a": "b", "c": "d"}'
    out_str = b'{"a": "b", "c": "d"}'

# Generated at 2022-06-22 22:05:10.413043
# Unit test for function to_bytes
def test_to_bytes():
    # Note: When tests are run with pytest on Windows we get
    # UnicodeEncodeError: 'charmap' codec can't encode character '\U0001f4a9'
    # in position 0: character maps to <undefined> so we skip these tests for
    # windows.
    import platform
    if platform.system() == 'Windows':
        return

    unistr = u'text'
    test_str = 'test'

    # Simple test with 'text'
    assert to_bytes(unistr) == b'text'

    # Default encoding is utf-8
    assert to_bytes(unistr.encode('utf-16')) == b'text'
    assert to_bytes(unistr.encode('utf-16'), encoding='utf-16') == b'text'

# Generated at 2022-06-22 22:05:19.317020
# Unit test for function container_to_text
def test_container_to_text():
    d_in = {"unicode": u'\xef', "bytes": b'\xef',
            "list": [u'\xef', b'\xef'], "tuple": (u'\xef', b'\xef')}
    d_in_out = {"unicode": u'\xef', "bytes": u'\xef',
                "list": [u'\xef', u'\xef'], "tuple": (u'\xef', u'\xef')}
    assert_equal(d_in_out, container_to_text(d_in))



# Generated at 2022-06-22 22:05:30.707969
# Unit test for function to_native
def test_to_native():
    # Basic usage and more complex usage
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(True) == True
    assert to_native(False) == False, to_native(False)

    # unicode/non-unicode across python2/3
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert isinstance(to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442'), text_type)

# Generated at 2022-06-22 22:05:41.230601
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # This test needs to be run from the tests directory
    from . import testcase_base
    from . import testlib

    b_data1 = b'{"key1": "val1", "key2": [1, 2, 3], "key3": {"key4": "val2"}}'
    json1 = json.loads(b_data1)
    b_json = container_to_bytes(json1)
    expected = '{\'key1\': \'val1\', \'key2\': [1, 2, 3], \'key3\': {\'key4\': \'val2\'}}'
    testcase_base.TESTCASE = testlib.TestCaseBase()
    testcase_base.TESTCASE.assertEqual(expected, str(b_json))


# Generated at 2022-06-22 22:05:52.915101
# Unit test for function container_to_text
def test_container_to_text():
    assert 'abc' == container_to_text('abc')
    assert 6 == container_to_text(6)
    assert ['a', 'b', 'c'] == container_to_text(['a', 'b', 'c'])
    assert ('a', 'b', 'c') == container_to_text(('a', 'b', 'c'))
    assert {'a': 'a', 'b': 'b', 'c': 'c'} == container_to_text({'a': 'a', 'b': 'b', 'c': 'c'})

    # utf-8
    assert '\xc3\xa9' == container_to_text('\xc3\xa9')
    assert ['\xc3\xa9', '\xc3\xa9', '\xc3\xa9'] == container_to_text

# Generated at 2022-06-22 22:06:01.462644
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(u'Mary had a little lamb') == 'Mary had a little lamb'
    assert container_to_bytes(u'Mary had a little lamb'.encode('utf-16')) == 'Mary had a little lamb'.encode('utf-16')
    assert container_to_bytes({u'foo': u'Mary had a little lamb'}) == {'foo': 'Mary had a little lamb'}
    assert container_to_bytes({u'foo': {u'bar': u'Mary had a little lamb'.encode('utf-16')}}) == \
        {'foo': {'bar': 'Mary had a little lamb'.encode('utf-16')}}



# Generated at 2022-06-22 22:06:07.642649
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(['a', 'b']) == '["a", "b"]'
    assert jsonify(set(['a', 'b'])) == '["a", "b"]'
    assert jsonify(datetime.datetime(2017,8,11,16,57,23,172169)) == '"2017-08-11T16:57:23.172169"'
    assert jsonify(u'\u7684') == u'"\u7684"'



# Generated at 2022-06-22 22:06:17.930300
# Unit test for function jsonify
def test_jsonify():
    assert '{"plain": "okay"}' == jsonify({u'plain': u'okay'})
    assert '{"non-ascii": "\\u0161umava"}' == jsonify({u'non-ascii': u'\u0161umava'})
    assert '{"unicode_as_utf8": "\\u0161umava"}' == jsonify({u'unicode_as_utf8': b'\xc5\xa1umava'})
    assert '{"unicode_as_cp1252": "\\u0161umava"}' == jsonify({u'unicode_as_cp1252': u'\u0161umava'.encode('cp1252')})

# Generated at 2022-06-22 22:06:21.984063
# Unit test for function jsonify
def test_jsonify():
    try:
        import simplejson as json  # support older systems
    except ImportError:
        json = None
    data = {u'byte': b'\x80abc', u'ascii':u'ascii_str', u'unicode':u'\u2713'}
    rval = jsonify(data)
    if json:
        assert isinstance(rval, bytes)
    else:
        assert isinstance(rval, unicode)

# TODO:  replace all of these with text_type()+u'string'

# Generated at 2022-06-22 22:06:32.963512
# Unit test for function to_native
def test_to_native():
    assert to_native(u'abc') == 'abc'
    assert to_native(u'\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e') == u'\u65e5\u672c\u8a9e'
    assert to_native(u'\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e'.encode('utf8')) == u'\u65e5\u672c\u8a9e'
    assert to_native('abc') == 'abc'

# Generated at 2022-06-22 22:06:38.817993
# Unit test for function to_native
def test_to_native():
    assert isinstance(to_native(u'\uc778\ub3c4'), text_type)
    assert isinstance(to_native('\xe1\x84\x8b\xe1\x85\xb5'), text_type)
    assert isinstance(to_native(b'\xf0\x90\x8c\xbc'), text_type)
    assert isinstance(to_native(bytearray(b'\xf0\x90\x8c\xbc')), text_type)
    assert isinstance(to_native(u'\xe1\x84\x8b\xe1\x85\xb5', encoding='ascii'), text_type)
    # bytes_obj, encoding=None, errors='surrogate_or_strict', nonstring='passthru'):

# Generated at 2022-06-22 22:06:50.831133
# Unit test for function container_to_bytes
def test_container_to_bytes():
    # Test for dict type
    data = {b'key1': b'value1', b'key2': b'value2'}
    assert container_to_bytes(data) == data

    data = {u'key1': u'value1', u'key2': u'value2'}
    new_data = container_to_bytes(data)
    assert new_data == {b'key1': b'value1', b'key2': b'value2'}
    assert isinstance(list(new_data.keys())[0], binary_type)
    assert isinstance(list(new_data.values())[0], binary_type)

    data = {u'key1': u'value1', b'key2': b'value2'}
    new_data = container_to_bytes(data)

# Generated at 2022-06-22 22:07:02.715388
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils.six import b
    from ansible.module_utils.six import u
    assert to_native(u(b'\xc3\xbc'), 'latin-1') == u('\xfc')
    assert to_native(u('\xfc'), 'latin-1') == u('\xfc')
    assert to_native(b('\xc3\xbc'), 'latin-1') == u('\xfc')
    assert to_native(u(b'\xf6'), 'latin-1') == u('\xf6')
    assert to_native(b('\xf6'), 'latin-1') == u('\xf6')
    assert to_native(u(b'\xc3\xbc'), 'utf-8') == u('\xfc')
    assert to

# Generated at 2022-06-22 22:07:12.967748
# Unit test for function to_bytes
def test_to_bytes():
    try:
        __import__('surrogateescape')
        HAS_SURROGATEESCAPE = True
    except ImportError:
        HAS_SURROGATEESCAPE = False

    # Test that the surrogateescape handler is correctly checked for.
    if HAS_SURROGATEESCAPE:
        # No handler specified
        assert to_bytes(u'\udce4\udce5', errors=None) == b'\xed\xb3\x84\xed\xb3\x85'
        # surrogate_then_replace
        assert to_bytes(u'\udce4\udce5', errors='surrogate_then_replace') == b'\xed\xb3\x84\xed\xb3\x85'
        # surrogate_or_replace

# Generated at 2022-06-22 22:07:22.929888
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native

# Generated at 2022-06-22 22:07:30.861660
# Unit test for function to_native
def test_to_native():
    # pylint: disable=no-self-use
    # Test that we accept bytes
    assert u'a string' == to_text(b'a string', nonstring='strict')
    # Test that we accept text
    assert u'a string' == to_text(u'a string', nonstring='strict')
    # Test that we accept objects with __unicode__
    class UnicodeObj(object):
        def __unicode__(self):
            return u"unicöde object"
    uobj = UnicodeObj()
    # Test that we accept objects with __str__, __bytes__ and a defined encoding
    class NativeObj(object):
        def __str__(self):
            return b"native object"
    obj = NativeObj()
    assert u'native object' == to_text(obj, nonstring='strict')

# Generated at 2022-06-22 22:07:43.548598
# Unit test for function to_bytes
def test_to_bytes():
    if PY3:
        # Shouldn't raise an exception
        to_bytes('hello')
        # u'\ufffe' is a surrogate in utf-16 which can't be represented in utf-8
        to_bytes(u'\ufffe', encoding='utf-8')
        # u'\ud83d\udc0e' is a surrogate pair that can be represented in utf-8
        to_bytes(u'\ud83d\udc0e', encoding='utf-8', errors='replace')
        to_bytes(u'\ud83d\udc0e', encoding='iso-8859-1', errors='surrogate_or_replace')
        to_bytes(u'\ud83d\udc0e', encoding='iso-8859-1', errors='surrogate_or_strict')

# Generated at 2022-06-22 22:07:52.479860
# Unit test for function container_to_text
def test_container_to_text():
    assert container_to_text({"a": u"a", "b": u"b"}) == {"a": u"a", "b": u"b"}
    assert container_to_text(u"a") == u"a"
    assert container_to_text(["a", "b"]) == [u"a", u"b"]
    assert container_to_text(("a", "b")) == (u"a", u"b")
    text_input = u"a"
    bytes_input = "a".encode('utf-8')
    unicode_output = u"a"
    assert container_to_text(bytes_input) == unicode_output
    assert container_to_text([bytes_input]) == [unicode_output]

# Generated at 2022-06-22 22:07:57.472793
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.six.moves import StringIO
    temp_result = StringIO()
    test_data = [u"test\udce2string", u"test\udce2string", u'\udce2']
    jsonify(test_data, sort_keys=True, indent=2, fp=temp_result)
    expected = '''[
  "test\\udce2string",
  "test\\udce2string",
  "\\udce2"
]'''
    assert temp_result.getvalue() == expected



# Generated at 2022-06-22 22:08:09.059229
# Unit test for function container_to_text
def test_container_to_text():
    from ansible.compat.tests import unittest
    import sys
    import json

    class TestJsonifyText(unittest.TestCase):
        """Test to text conversions of json objects."""

        def test_dict(self):
            d = {b'key': b'value'}
            self.assertEqual(container_to_text(d), {u'key': u'value'})

        def test_list(self):
            d = [b'value']
            self.assertEqual(container_to_text(d), [u'value'])

        def test_tuple(self):
            d = (b'value',)
            self.assertEqual(container_to_text(d), (u'value',))


# Generated at 2022-06-22 22:08:18.020050
# Unit test for function to_bytes
def test_to_bytes():
    """Run tests to confirm that to_bytes() converts to bytes
    """
    # Run tests against the different types of python to test the different
    # error strategies
    for encoding in ('ascii', 'latin-1', 'utf-8'):
        # Valid text types as input:
        # ascii, utf-8, and mixed ascii/utf8 unicode
        assert to_bytes('hello world', encoding=encoding) == b'hello world'
        assert to_bytes(b'hello world', encoding=encoding) == b'hello world'
        assert to_bytes(u'\u1234foobar\u4321', encoding=encoding) == b'\xe1\x88\xb4foobar\xdd\x88\xa1'

        # Empty text strings as input:

# Generated at 2022-06-22 22:08:24.331955
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import text_type, binary_type
    from units.compat import unittest
    import sys, json

    class TestJsonify(unittest.TestCase):

        def test_container_to_text(self):

            if sys.version_info[0] < 3:
                self.assertEqual(container_to_text({'a': 'b'}, encoding='utf-8'),
                                 {'a': to_bytes('b', encoding='utf-8')})
                self.assertEqual(container_to_text(['a', 'b'], encoding='utf-8'),
                                 [to_bytes('a', encoding='utf-8'), to_bytes('b', encoding='utf-8')])

# Generated at 2022-06-22 22:08:33.377084
# Unit test for function jsonify
def test_jsonify():

    # Test 1
    data = dict(
        a = dict(
            b = dict(
                c = dict(
                    d = 'value',
                ),
            ),
        ),
    )
    assert jsonify(data) == '{"a": {"b": {"c": {"d": "value"}}}}'

    # Test 2
    data = dict(
        a = dict(
            b = dict(
                c = dict(
                    d = Set(['value']),
                ),
            ),
        ),
    )
    assert jsonify(data) == '{"a": {"b": {"c": {"d": ["value"]}}}}'



# Generated at 2022-06-22 22:08:43.475496
# Unit test for function container_to_text
def test_container_to_text():
    """ Unit test for function container_to_text
    """
    b = dict(foo='bar')
    assert container_to_text(b) == {u'foo': u'bar'}

    b = dict(foo=b'dog')
    assert container_to_text(b) == {u'foo': u'dog'}

    b = dict(foo=to_bytes('dog', 'utf-16'))
    assert container_to_text(b) == {u'foo': u'dog'}

    b = dict(foo=b'\xc3\xa5')
    assert container_to_text(b) == {u'foo': u'\xe5'}

    b = dict(foo=to_bytes('\xc3\xa5', 'utf-16'))
    assert container_to_text(b)

# Generated at 2022-06-22 22:08:52.315439
# Unit test for function to_native
def test_to_native():
    # Test to_native for default 'surrogate_then_replace' error handler
    # ------------------------------------------------------------------

    # Test surrogate_then_replace with utf8
    # Valid utf8 strings should be unaltered
    res = to_native(u'\u2713', 'utf-8')
    assert isinstance(res, text_type)
    assert res == u'\u2713'
    res = to_native(u'\U0001f608', 'utf-8')
    assert isinstance(res, text_type)
    assert res == u'\U0001f608'

    # utf8 strings with invalid bytes should have invalid bytes replaced
    res = to_native(b'\xc2\xa1', 'utf-8', nonstring='passthru')
    assert isinstance(res, text_type)

# Generated at 2022-06-22 22:08:56.908977
# Unit test for function to_native
def test_to_native():

    assert to_native('hello') == 'hello'
    assert to_native(u'hello') == 'hello'
    assert to_native(b'hello') == 'hello'
    assert to_native(b'\xe5\x85\x83') == u'\u5143'

# Generated at 2022-06-22 22:09:06.928711
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('hello') == b'hello'
    assert to_bytes('ёжик') == b'\xd1\x91\xd0\xb6\xd0\xb8\xd0\xba'
    assert to_bytes(None) == b'None'
    assert to_bytes(None, nonstring='empty') == b''
    assert to_bytes({1: 'one'}) == b"{1: 'one'}"
    assert to_bytes(datetime.datetime.now()) == str(datetime.datetime.now()).encode('utf-8')
    assert to_bytes(datetime.datetime.now(), nonstring='strict')



# Generated at 2022-06-22 22:09:18.067781
# Unit test for function container_to_bytes
def test_container_to_bytes():
    input_dict = {"key": "value"}
    expected_dict = {"key": b"value"}
    actual_dict = container_to_bytes(input_dict)
    assert actual_dict == expected_dict

    input_list = [42, "the answer", ["a", "list", "of", "list", "items"]]
    expected_list = [42, b"the answer", [b"a", b"list", b"of", b"list", b"items"]]
    actual_list = container_to_bytes(input_list)
    assert actual_list == expected_list

    input_tuple = (42, "the answer", ("a", "tuple", "of", "tuple", "items"))

# Generated at 2022-06-22 22:09:26.696712
# Unit test for function to_native
def test_to_native():
    test_str = 'foo'
    test_unicode = u'bar'
    test_int = 1
    test_list = ['dog', u'cat', 1]
    test_dict = {'pet': 'dog', u'animal': 'cat', 'number': 1}

    assert to_native(test_str) == 'foo'
    assert to_native(test_unicode) == u'bar'
    assert to_native(test_int) == 1
    assert to_native(test_list) == ['dog', u'cat', 1]
    assert to_native(test_dict) == {'pet': 'dog', u'animal': 'cat', 'number': 1}


# Generated at 2022-06-22 22:09:33.778507
# Unit test for function jsonify
def test_jsonify():
    # Create data for test
    data = {b'key1': b'value1', b'key2': b'value2'}
    try:
        # Test for call jsonify with no keywords parameters
        output = jsonify(data)
    except:
        assert False, "jsonify function does not work as expected"
    assert output == '{"key2": "value2", "key1": "value1"}', 'jsonify function does not work as expected'

    # Test for call jsonify with sort_keys=False
    output = jsonify(data, sort_keys=False)
    assert output == '{"key1": "value1", "key2": "value2"}', 'jsonify function does not work as expected'

    # Test for call jsonify with indent=4
    output = jsonify(data, indent=4)

# Generated at 2022-06-22 22:09:42.462859
# Unit test for function container_to_text
def test_container_to_text():
    if PY3:
        # python3 can't have bytes in dict keys
        test_dict = {'k': b'v'}
        assert container_to_text(test_dict) == {'k': 'v'}
        assert container_to_text(test_dict, encoding='ascii') == {'k': 'v'}
    else:
        test_dict = {b'k': 'v'}
        assert container_to_text(test_dict) == {u'k': 'v'}
        assert container_to_text(test_dict, encoding='ascii') == {u'k': u'v'}

    test_dict = {'k': 'v'}
    assert container_to_text(test_dict) == {'k': 'v'}
    assert container_to_text

# Generated at 2022-06-22 22:09:53.944312
# Unit test for function container_to_bytes
def test_container_to_bytes():

    # simple string convert
    assert container_to_bytes('simple') == b'simple'
    assert container_to_bytes(u'simple') == b'simple'
    assert container_to_bytes(b'simple') == b'simple'

    assert container_to_bytes(u'þ') == b'\xc3\xbe'
    assert container_to_bytes(u'\xe9') == b'\xc3\xa9'
    assert container_to_bytes(u'\xe9') == u'\xe9'.encode('utf-8')
    assert container_to_bytes(u'\xe9') == u'\xe9'.encode('utf-8', 'surrogateescape')
    assert container_to_bytes(u'\xe9') != u'\xe9'.encode

# Generated at 2022-06-22 22:10:04.804527
# Unit test for function to_native
def test_to_native():
    ###
    # Verify that the values are the same type and if the value is a text
    # string, that it's the same value.
    ###
    # Given a simple text string, it should return a text string
    assert to_native('crab') == u'crab'
    # Given a simple byte string, it should return a text string
    assert to_native(b'crab') == u'crab'
    # Given a byte string with a utf8 character in it, it should return a text
    # string
    assert to_native(b'\xe7\x8a\xac') == u'\u732b'
    # Given a byte string with a character that cannot be decoded, it should
    # return a text string

# Generated at 2022-06-22 22:10:10.810468
# Unit test for function jsonify
def test_jsonify():
    value = dict(
        a=dict(
            b=dict(
                c=["foo", "bar"],
                d={"bar": "foo"},
                e=set(["foo", "bar"])
            )
        )
    )
    round_tripped = json.loads(jsonify(value))
    assert round_tripped == value



# Generated at 2022-06-22 22:10:20.675125
# Unit test for function jsonify
def test_jsonify():
    assert isinstance(jsonify(dict(a="text")), str)
    # assert isinstance(jsonify({ 'a' : to_bytes('text', encoding='latin-1') }), str)
    assert isinstance(jsonify([dict(a="text")]), str)
    assert isinstance(jsonify(dict(a=to_bytes('text', encoding='latin-1'))), str)
    assert isinstance(jsonify([dict(a=to_bytes('text', encoding='latin-1'))]), str)
    assert isinstance(jsonify(dict(a=[to_bytes('text', encoding='latin-1')])), str)



# Generated at 2022-06-22 22:10:29.691297
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes(u'foobar') == b'foobar'
    assert container_to_bytes({u"k1": u"v1", u"k2": u"v2"}) == {b"k1": b"v1", b"k2": b"v2"}
    assert container_to_bytes([u"v1", u"v2"]) == [b"v1", b"v2"]
    assert container_to_bytes((u"v1", u"v2")) == (b"v1", b"v2")



# Generated at 2022-06-22 22:10:42.509273
# Unit test for function container_to_bytes
def test_container_to_bytes():
    assert container_to_bytes([u'test']) == [b'test']
    assert container_to_bytes((u'test',)) == (b'test',)
    assert container_to_bytes([u'\U0001F60A']) == [b'\xf0\x9f\x98\x8a']
    assert container_to_bytes([u'test'], encoding='latin-1') == [b'test']
    assert container_to_bytes(u'test', encoding='latin-1') == b'test'
    assert container_to_bytes(u'\U0001F60A', encoding='latin-1') == b'\xed\xa0\xbd\xed\xb0\x8a'
    assert container_to_bytes(u'test') == b'test'

# Generated at 2022-06-22 22:10:55.072803
# Unit test for function container_to_bytes
def test_container_to_bytes():
    data = dict(
        str = u'test',
        int = 1,
        unicode = u'\u2603',
        utf8 = b'\xe2\x98\x83',
        list = [u'test1', u'test2'],
        subdict = dict(
            subkey = u'test',
            sublist = [u'test1', u'test2'],
        ),
        utf8_mix_dict = {
            'caf\xc3\xa9': u'mocha',
            'unicode\u2603': b'bytestring',
        },
    )


# Generated at 2022-06-22 22:11:08.081223
# Unit test for function jsonify

# Generated at 2022-06-22 22:11:19.398655
# Unit test for function container_to_text
def test_container_to_text():
    # test normal dictionary
    d = dict(a=u'\u00e9', b=10)
    assert container_to_text(d) == d

    # test tuple
    t = ('\xe9', 10, 'test')
    assert container_to_text(t) == (u'\u00e9', 10, u'test')

    # test list
    l = ['\xe9', 10, 'test']
    assert container_to_text(l) == [u'\u00e9', 10, u'test']

    # test set
    s = set(['\xe9', 10, 'test'])
    assert container_to_text(s) == set([u'\u00e9', 10, u'test'])

    # test list with multiple level
    # (Not sure if this is a

# Generated at 2022-06-22 22:11:32.400451
# Unit test for function jsonify
def test_jsonify():
    # Test basic function
    assert jsonify([u'123']) == '[123]'

    # Test encoding errors are handled correctly
    assert jsonify([u'\ubcd1']) == '["\\udc91"]'

    # Test complex data
    from collections import OrderedDict
    from datetime import datetime
    from ansible.module_utils import six

# Generated at 2022-06-22 22:11:36.677690
# Unit test for function container_to_bytes
def test_container_to_bytes():
    b = dict(a=dict(b="hello"))
    assert b == container_to_bytes(b)
    b = dict(a=["hello"])
    assert b == container_to_bytes(b)
    b = dict(a=set(["hello"]))
    assert b == container_to_bytes(b)
    b = dict(a=str(123))
    assert b == container_to_bytes(b)
    b = dict(a=str(123), b=dict(c='test'))
    assert b == container_to_bytes(b)



# Generated at 2022-06-22 22:11:44.567230
# Unit test for function container_to_text
def test_container_to_text():
    # The tests are inside a function to delay the execution until
    # all functions are defined
    import unittest


    class TestContainerToText(unittest.TestCase):
        def test_text_type_doesnt_change(self):
            my_str = u'é'

            result = container_to_text(my_str, encoding='utf-8')
            expected = my_str
            self.assertEqual(result, expected)

        def test_binary_type_converts_without_traceback(self):
            my_str_utf8 = b'\xc3\xa9'
            my_str = u'é'

            result = container_to_text(my_str_utf8, encoding='utf-8')
            expected = my_str
            self.assertEqual(result, expected)
