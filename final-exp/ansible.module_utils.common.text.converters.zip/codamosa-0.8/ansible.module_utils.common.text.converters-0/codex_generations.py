

# Generated at 2022-06-11 01:29:58.329526
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=dict(b=dict(c=["\u00a1Unicode snowman: \u2603"]), d=dict(e=["\u00a1Unicode snowman: \u2603"]), f="\u00a1Unicode snowman: \u2603")))



# Generated at 2022-06-11 01:30:04.954287
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2603') == '"\\u2603"'
    assert jsonify(b'\xe2\x98\x83') == '"\\u2603"'
    from ansible import module_utils
    module_utils.HAS_SURROGATEESCAPE=True
    assert jsonify(b'\xe2\x98\x83') == '"\\u2603"'


# Generated at 2022-06-11 01:30:11.804737
# Unit test for function to_native
def test_to_native():
    assert to_native('value') == "value"
    assert to_native(u'value') == "value"
    assert to_native(b"value") == "value"

    # I'm not sure if we want to keep this or not...
    #assert to_native(b"value".decode('utf-8')) == "value"

    try:
        to_native(object())
        assert False, 'to_native should have thrown an exception'
    except TypeError:
        pass


# Generated at 2022-06-11 01:30:15.316100
# Unit test for function to_native
def test_to_native():
    assert(to_native('Hello World') == 'Hello World')
    assert(to_native(u'Hello World') == 'Hello World')
    assert(to_native(b'Hello World') == 'Hello World')
    assert(to_native(1) == '1')
    assert(to_native(None) == 'None')


# Generated at 2022-06-11 01:30:19.270637
# Unit test for function jsonify
def test_jsonify():
    result = jsonify({u"foo": u"bar"})
    assert type(result) == str


    result = jsonify({u"foo": u"b\xe2r"})
    assert type(result) == str
# End unit test for function jsonify


# Generated at 2022-06-11 01:30:27.768714
# Unit test for function to_bytes
def test_to_bytes():
    # test surrogateescape
    surrogate_str = u'ab\udcf0cd'
    bin_str = b'ab\xed\xb3\xb0cd'
    assert surrogate_str.encode('utf-8', 'surrogateescape') == bin_str
    assert to_bytes(surrogate_str, errors='surrogateescape') == bin_str
    assert to_bytes(surrogate_str, errors='surrogate_then_replace') == bin_str

    # test surrogate_or_strict
    if HAS_SURROGATEESCAPE:
        assert to_bytes(surrogate_str, errors='surrogate_or_strict') == bin_str
        assert to_bytes(surrogate_str, errors='surrogate_or_replace') == bin_str
        assert to_bytes

# Generated at 2022-06-11 01:30:37.716129
# Unit test for function jsonify
def test_jsonify():
    abc = jsonify('abc')
    assert abc == '"abc"'

    abc = jsonify(u'abc')
    assert abc == '"abc"'

    abc = jsonify(b'abc')
    assert abc == '"abc"'

    abc = jsonify(12345)
    assert abc == '12345'

    abc = jsonify([1, 2, 3, 4, 5])
    assert abc == '[1, 2, 3, 4, 5]'

    abc = jsonify({'a': 1, 'b': 2})
    assert abc == '{"a": 1, "b": 2}'

    abc = jsonify(Set([1, 2, 3, 4]))
    assert abc == '[1, 2, 3, 4]'


# Generated at 2022-06-11 01:30:49.956496
# Unit test for function jsonify
def test_jsonify():
    test_data = dict(
        test_str='test',
        test_int=1,
        test_bool=True,
        test_nonascii=to_text(b'\xc3\x28'),
        test_list=['this', 'is', 'a', 'test'],
        test_set=Set(['this', 'is', 'a', 'test']),
        test_dict=dict(this='is', a='test'),
        test_datetime=datetime.datetime(2013, 1, 26, 1, 22, 3),
        test_datetime_tz=datetime.datetime(2013, 1, 26, 1, 22, 3, tzinfo=datetime.timezone(datetime.timedelta(seconds=0)))
    )

    if PY3:
        _json_encode

# Generated at 2022-06-11 01:30:55.220126
# Unit test for function jsonify
def test_jsonify():
    data = {
        'key1': 'value1',
        'key2': b'value2',
        'key3': u'value3'
    }
    data1 = container_to_text(data)
    assert jsonify(data1) == '{"key1": "value1", "key3": "value3", "key2": "value2"}'



# Generated at 2022-06-11 01:31:03.604464
# Unit test for function jsonify
def test_jsonify():
    import sys
    import base64

    from ansible.compat.tests import unittest

    from ansible.module_utils.common._collections_compat import Set

    if sys.version_info[0] > 2:
        unicode_obj = str
    else:
        unicode_obj = unicode

    class TestJsonify(unittest.TestCase):

        def test_json_serializes_set_to_list(self):
            obj = Set(['foo', 'bar'])
            jsonified_obj = jsonify(obj)
            self.assertEqual(jsonified_obj, '["foo", "bar"]')


# Generated at 2022-06-11 01:31:21.247178
# Unit test for function to_native
def test_to_native():
    assert to_native(b'Hello') == 'Hello'
    assert to_native(u'\u2603') == u'\u2603'
    class Foo(object):
        def __repr__(self):
            return b'\x80\x00'
        if PY3:
            def __str__(self):
                return b'\xe9'
        else:
            def __str__(self):
                return u'\u2603'
    assert to_native(Foo()) == '\u2603'
    assert to_native(Foo(), nonstring='empty') == ''
    assert to_native(Foo(), nonstring='passthru') == Foo()

# Generated at 2022-06-11 01:31:26.643655
# Unit test for function jsonify
def test_jsonify():
    assert jsonify([u'd\xe9fault']) == '["d\\u00e9fault"]'
    assert jsonify([u'd\xe9fault'], encoding='ascii') == '["d\\u00e9fault"]'
    assert jsonify([u'd\xe9fault'], encoding='latin-1') == '["défault"]'


# TODO: remove

# Generated at 2022-06-11 01:31:38.580224
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == u'foo'
    assert to_native(u'\xc3\xb1'.encode('utf-8'), errors='surrogateescape') == u'\ufffd\ufffd'
    assert to_native(u'\xc3\xb1'.encode('utf-8'), errors='surrogate_or_strict') == u'\ufffd\ufffd'
    assert to_native(u'\xc3\xb1'.encode('utf-8'), errors='surrogate_or_replace') == u'\ufffd\ufffd'

# Generated at 2022-06-11 01:31:49.981346
# Unit test for function jsonify
def test_jsonify():
    from ansible.compat.tests import unittest

    class TestJsonify(unittest.TestCase):
        def test_no_unicode(self):
            native = {u'foo': u'bar'}
            json_data = {'foo': 'bar'}
            self.assertEqual(jsonify(native), json.dumps(json_data))

        def test_unicode_dict(self):
            native = {u'f\xf8\xf8': u'b\xe6r'}
            json_data = {u'f\xf8\xf8'.encode('utf-8'): u'b\xe6r'.encode('utf-8')}
            self.assertEqual(jsonify(native), json.dumps(json_data))


# Generated at 2022-06-11 01:31:59.690327
# Unit test for function to_native
def test_to_native():
    class MyInspection(object):
        def __str__(self):
            return 'str'

    class MyInspectionUnicode(object):
        def __str__(self):
            return u'str'

    class MyInspectionUnicodeDecodeError(object):
        def __str__(self):
            return b'\xff'

    class MyInspectionUnicodeEncodeError(object):
        def __unicode__(self):
            return b'\xff'

    class MyInspectionUnicodeEncodeError2(object):
        def __unicode__(self):
            return '\u3042'

    class MyInspectionUnicodeEncodeError3(object):
        def __unicode__(self):
            return '\xe3\x81\x82'


# Generated at 2022-06-11 01:32:11.412578
# Unit test for function jsonify
def test_jsonify():
    def test(data):
        data_ = eval(jsonify(data))
        assert data == data_

    class C:
        def __init__(self, a, b):
            self.a = a
            self.b = b

        def __eq__(self, other):
            return self.a == other.a and self.b == other.b

    test(dict(a=1, b=2, c=3))
    test(dict(a=1, b=2, c=[3, 4, 5]))
    test(dict(a=1, b=2, c=[3, dict(d=4, e=5)]))
    test(dict(a=1, b=2, c=dict(d=4, e=5)))

# Generated at 2022-06-11 01:32:21.224263
# Unit test for function jsonify

# Generated at 2022-06-11 01:32:34.013906
# Unit test for function jsonify
def test_jsonify():
    test_data = dict(
        dict1={u"a": 1, u"b": 2},
        dict2={u"a": 1, u"b": 2},
        list1=[1, 2, 3, 4],
        list2=[1, 2, 3, 4],
        set1=set(["a", u"b"]),
        set2=set(["a", u"b"]),
        datetime1=datetime.datetime.now(),
        datetime2=datetime.datetime.now(),
        int1=1,
        int2=1,
        str1=u"str1",
        str2=u"str2"
    )

    json.dumps(test_data, encoding='utf-8', default=_json_encode_fallback)
    jsonify(test_data)

# Generated at 2022-06-11 01:32:41.062626
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_bytes, to_text, to_native
    # Test when data is a native string
    if PY3:
        data = to_text(u"你好")
    else:
        data = u"你好"
    assert isinstance(jsonify(data), str)
    assert "你好" in jsonify(data)

    # Test when data is bytes in different encoding
    data = "你好"
    for encoding in ("utf-8", "latin-1"):
        if PY3:
            data = to_bytes(u"你好", nonstring="passthru", encoding=encoding)
        else:
            data = to_bytes(u"你好", encoding=encoding)

# Generated at 2022-06-11 01:32:51.220249
# Unit test for function to_bytes
def test_to_bytes():
    # Define a few unicode strings for the tests
    bmp_character = text_type('\U0001F604')
    surrogate_character = text_type('\ud800\udc01')
    bmp_and_surrogate = text_type('\U0001F604') + text_type('\ud800\udc01')
    bmp_and_unassigned_character = text_type('\U0001F604') + text_type('\U0007ffff')

    #
    # Test nonstring semantics
    #

    # Task: We have a function that returns strings.  We need to make sure that
    #       string is a byte string.
    def maybe_unicode(obj):
        return str(obj)

    assert not isinstance(maybe_unicode(123), text_type)

    # We don't

# Generated at 2022-06-11 01:33:11.047675
# Unit test for function to_bytes
def test_to_bytes():

    assert to_bytes('foo', 'utf-8') == b'foo'
    assert to_bytes('\u2713', 'utf-8') == b'\xe2\x9c\x93'

    if not PY3:
        assert to_bytes('\u2713', 'utf-8', 'surrogate_or_strict') == b'\xe2\x9c\x93'
        assert to_bytes('\u2713', 'utf-8', 'surrogate_or_strict', nonstring='passthru') == '\u2713'
        assert to_bytes(u'\u2713', 'ascii', 'surrogate_or_strict', nonstring='simplerepr') == b"'\\xe2\\x9c\\x93'"

    # This long string triggers the fastpath

# Generated at 2022-06-11 01:33:20.883810
# Unit test for function to_native
def test_to_native():
    # Python 2 unicode strings
    assert to_native(u'foo') == 'foo'
    assert to_native(u'föo') == 'föo'
    assert to_native(u'f\xe9o') == 'f\xc3\xa9o'
    assert to_native(u'f\xe9o'.encode('utf-8')) == 'f\xc3\xa9o'
    assert to_native(u'f\u0119o'.encode('utf-8')) == 'f\xc4\x99o'
    assert to_native(u'f\u0119o'.encode('utf-8'), encoding='iso-8859-1') == 'f\xebo'

# Generated at 2022-06-11 01:33:31.887376
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'test 123') == b'test 123'
    assert to_bytes(u'\ubcf4\uae30') == b'\xed\xa0\xbd\xed\xb2\xb0'
    assert to_bytes(u'\ubcf4\uae30'.encode('utf-8'), errors='surrogate_or_replace') == b'\xed\xa0\xbd\xed\xb2\xb0'
    assert to_bytes(u'\ubcf4\uae30'.encode('utf-8')) == b'\xed\xa0\xbd\xed\xb2\xb0'

# Generated at 2022-06-11 01:33:42.772513
# Unit test for function to_native
def test_to_native():
    # Make sure this function is working
    u_str = u'привет, мир'
    b_str = u_str.encode('utf-8')
    assert to_text(u_str) == u_str
    assert to_text('\xe2\x98\x83') == u'\u2603'
    assert to_text('\xe2\x98\x83'.decode('utf-8'), 'latin-1') == u'\ufffd\ufffd\ufffd'
    assert to_text(b_str) == u_str
    assert to_bytes(u_str) == b_str
    assert to_bytes('\xe2\x98\x83') == '\xe2\x98\x83'

# Generated at 2022-06-11 01:33:53.486627
# Unit test for function to_bytes

# Generated at 2022-06-11 01:34:04.512975
# Unit test for function jsonify
def test_jsonify():
    data = u"This is a string"
    assert data == json.loads(jsonify(data))

    data = u"This is a string".encode('utf-8')
    assert data == json.loads(jsonify(data))

    data = u"This is a string".encode('latin-1')
    assert data == json.loads(jsonify(data))

    data = u"This is a string".encode('cp1252')
    assert to_text(data, errors='surrogate_or_strict') == json.loads(jsonify(data))

    data = u"This is a string".encode('cp1252')
    assert to_text(data, errors='surrogate_then_replace') == json.loads(jsonify(data))

    # Test new custom json serializer function: _json_en

# Generated at 2022-06-11 01:34:13.413725
# Unit test for function to_native
def test_to_native():

    # Bytes should not be touched
    assert to_native(b'foobar') == b'foobar'
    assert to_native(b'123') == b'123'
    assert to_native(b'123456\xc3\xa9') == b'123456\xc3\xa9'  # binary with non-ascii characters

    # Strings should not be touched
    assert to_native('foobar') == 'foobar'
    assert to_native('123') == '123'
    assert to_native('123456\xc3\xa9') == '123456\xc3\xa9'  # binary with non-ascii characters

    # Numbers should be converted to strings
    assert to_native(1) == '1'
    assert to_native(42) == '42'

# Generated at 2022-06-11 01:34:24.972967
# Unit test for function jsonify
def test_jsonify():
    test_obj = datetime.datetime.strptime("2017-10-01T13:29:13Z", "%Y-%m-%dT%H:%M:%SZ")
    assert jsonify(test_obj) == json.dumps(test_obj.isoformat(), default=_json_encode_fallback)
    assert jsonify({}) == json.dumps({}, default=_json_encode_fallback)
    assert jsonify([u'\xA9', u'\u03A3', u'\u2665', u'\u2603']) == json.dumps([u'\xA9', u'\u03A3', u'\u2665', u'\u2603'], default=_json_encode_fallback)

# Generated at 2022-06-11 01:34:34.456822
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableMapping

    assert jsonify(dict(foo=None)) == '{"foo": null}'
    assert jsonify(dict(foo=1)) == '{"foo": 1}'
    assert jsonify(dict(foo=1.0)) == '{"foo": 1.0}'
    assert jsonify(dict(foo="a")) == '{"foo": "a"}'
    assert jsonify(dict(foo=[1, 2])) == '{"foo": [1, 2]}'

# Generated at 2022-06-11 01:34:46.731018
# Unit test for function to_bytes

# Generated at 2022-06-11 01:35:05.301526
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'ascii text', encoding='ascii') == b'ascii text'
    assert to_bytes('ascii text', encoding='ascii') == b'ascii text'
    assert to_bytes(b'ascii text', encoding='ascii') == b'ascii text'
    assert to_bytes(u'non-ascii text', encoding='ascii') == b'non-ascii text'
    assert to_bytes('non-ascii text', encoding='ascii') == b'non-ascii text'
    assert to_bytes(b'non-ascii text', encoding='ascii') == b'non-ascii text'

# Generated at 2022-06-11 01:35:16.631603
# Unit test for function jsonify
def test_jsonify():
    data = {
        "foo": "bar",
        "baz": [1, 2, 3],
        "whats": {
            "up": "doc"
        },
        "testset": set([1, 2, 3]),
        "testdate": datetime.datetime(2014, 12, 11, 10, 9, 8)
    }

    # Make sure all keys and values are converted to text strings
    result = jsonify(data)
    obj = json.loads(result)

    for k, v in iteritems(obj):
        assert isinstance(k, text_type)
        if isinstance(v, list):
            for i in v:
                assert isinstance(i, text_type)

# Generated at 2022-06-11 01:35:24.015873
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text

    try:
        from unittest import skipIf
    except ImportError:
        from unittest2 import skipIf

    import sys

    # Test string to bytes
    # Test utf-8
    assert b'foobar' == to_bytes(u'foobar')
    assert u'foobar' == to_text(b'foobar')

    assert b'\xc3\x28' == to_bytes(u'\u0028', errors='surrogate_or_replace')
    assert u'\uFFFD' == to_text(b'\xc3\x28', errors='surrogate_or_replace')

    # Test latin-1
    assert b'foobar' == to

# Generated at 2022-06-11 01:35:28.457877
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(True) == b'true'
    assert to_bytes(True, nonstring='empty') == b''
    assert to_bytes(True, nonstring='passthru') is True
    assert to_bytes(True, nonstring='strict')



# Generated at 2022-06-11 01:35:38.767065
# Unit test for function to_bytes
def test_to_bytes():
    result = to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', 'utf-8')
    assert isinstance(result, binary_type)
    assert result == u'\u043f\u0440\u0438\u0432\u0435\u0442'.encode('utf-8')

    result = to_bytes(b'\xe4\xbd\xa0\xe5\xa5\xbd', 'utf-8')
    assert isinstance(result, binary_type)
    assert result == b'\xe4\xbd\xa0\xe5\xa5\xbd'

    result = to_bytes(1, nonstring='passthru')
    assert isinstance(result, int)
    assert result == 1


# Generated at 2022-06-11 01:35:44.725468
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils.basic import AnsibleModule
    am = AnsibleModule(argument_spec=dict(
        s=dict(type='str')
    ))
    s = am.params['s']
    if PY3:
        assert to_text(s) is s
        assert to_bytes(s) is not s
        assert to_bytes(s).decode('utf-8') == s
    else:
        assert to_bytes(s) is s
        assert to_text(s) is not s
        assert to_text(s).encode('utf-8') == s



# Generated at 2022-06-11 01:35:55.555512
# Unit test for function to_bytes
def test_to_bytes():
    import sys
    import unittest

    class TestToBytes(unittest.TestCase):

        def test_unicode_to_bytes(self):
            unicode_str = to_text(b'\xf0\xa4\xad\xa2', 'utf-8', errors='surrogate_or_replace')
            b = to_bytes(unicode_str)
            self.assertEqual(b, b'\xf0\xa4\xad\xa2')
            self.assertTrue(isinstance(b, binary_type))
            self.assertEqual(to_text(b, errors='surrogate_or_replace'), unicode_str)

        def test_identity(self):
            b = to_bytes(b'hi')

# Generated at 2022-06-11 01:36:05.365730
# Unit test for function jsonify
def test_jsonify():
    test_dict = {
        "unicode": u'\u2713',
        "ascii": "yes",
        "non_ascii": u'\u0131',
        "binary": b'\x01',
        "list": [1, 2, 3, u'\u2713'],
        "tuple": (1, 2, 3, u'\u2713'),
        "set": set(["abc", u'\u2713']),
        "dict": {u'\u2713': "unicode", u'\u0131': "non_ascii"},
        }

# Generated at 2022-06-11 01:36:15.382510
# Unit test for function jsonify
def test_jsonify():

    from collections import OrderedDict
    from datetime import datetime

    # simple test
    test_data1 = {u'unicode_key_1': u'unicode_value_1'}
    expected_result1 = '{"unicode_key_1": "unicode_value_1"}'
    assert jsonify(test_data1) == expected_result1

    # test with a null byte within the string
    test_data2 = 'abcd\x00efghi'
    expected_result2 = '"abcd\\u0000efghi"'
    assert jsonify(test_data2) == expected_result2

    # test with a high order unicode character (non-ASCII value)
    test_data3 = u'abcd\xe9fghi'

# Generated at 2022-06-11 01:36:25.348590
# Unit test for function to_native
def test_to_native():
    # Verifying that str is not always a native string
    assert isinstance(to_native(""), text_type)

    if PY3:
        # Verifying that bytes is always a native string
        assert isinstance(to_native(b""), binary_type)
        # Verifying that str is always a native string
        assert isinstance(to_native(""), text_type)
    else:
        # Verifying that str is not always a native string (unicode)
        assert type(to_native("")) != text_type

    # Testing nonstring 'passthru'
    obj = object
    assert id(obj) == id(to_native(obj, nonstring="passthru"))

    # Testing nonstring 'simplerepr'
    obj = object()

# Generated at 2022-06-11 01:36:50.495907
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(b'foo', nonstring='passthru') == b'foo'
    assert to_bytes(u'foo\u1234') == b'foo\xe1\x88\xb4'
    assert to_bytes(b'foo\xe1\x88\xb4') == b'foo\xe1\x88\xb4'
    assert to_bytes(u'foo\u1234', encoding='latin-1') == b'foo\xe1\x88\xb4'
    assert to_bytes(u'foo\u1234', encoding='ascii', errors='ignore') == b'foo'

# Generated at 2022-06-11 01:37:00.016729
# Unit test for function jsonify
def test_jsonify():
    jsonify(dict(a=u'\xe9', b=u'\xfc')) == '{"a": "\\u00e9", "b": "\\u00fc"}'
    jsonify(Set([u'\xe9', u'\xfc'])) == '["\\u00e9", "\\u00fc"]'
    jsonify([u'\xe9', u'\xfc']) == '["\\u00e9", "\\u00fc"]'
    jsonify(Set([u'\xe9', u'\xfc'])) == '["\\u00e9", "\\u00fc"]'
    jsonify({"a": Set([u'\xe9', u'\xfc'])}) == '{"a": ["\\u00e9", "\\u00fc"]}'



# Generated at 2022-06-11 01:37:11.492212
# Unit test for function to_native
def test_to_native():
    # Testing bytes objects with non-ascii characters encoded with different encodings
    for encoding in ['utf-8', 'utf-16', 'utf-32']:
        x = to_native(u'foø'.encode(encoding))
        assert isinstance(x, text_type)
        assert x == u'foø'

    # Testing byte strings in the ascii encoding
    x = to_native(b'foo')
    assert isinstance(x, text_type)
    assert x == u'foo'

    # Testing unicode objects
    x = to_native(u'foo')
    assert isinstance(x, text_type)
    assert x == u'foo'

    # Testing integers
    x = to_native(10)
    assert isinstance(x, int)
    assert x == 10

    #

# Generated at 2022-06-11 01:37:13.351064
# Unit test for function to_native
def test_to_native():
    raise Exception("Not implemented")



# Generated at 2022-06-11 01:37:21.541484
# Unit test for function to_bytes
def test_to_bytes():
    unicode_test_string = u'\u043a\u0438\u0440\u0438\u043b\u043b\u0438\u0447\u0435\u0441\u043a\u0438\u0439'  # Cyrillic "kirillicheskii"
    utf8_bytes = unicode_test_string.encode('utf-8')
    latin1_bytes = unicode_test_string.encode('latin-1')
    latin1_bytes2 = to_bytes(unicode_test_string, 'latin-1')

    assert utf8_bytes == to_bytes(utf8_bytes)
    assert utf8_bytes == to_bytes(utf8_bytes, 'utf-8')
    assert utf8_bytes == to

# Generated at 2022-06-11 01:37:33.352205
# Unit test for function to_bytes
def test_to_bytes():
    # Non-strings,passthru
    assert to_bytes(None, nonstring='passthru') is None
    assert to_bytes(6, nonstring='passthru') == 6
    assert to_bytes(list(range(5)), nonstring='passthru') == [0, 1, 2, 3, 4]

    # Non-strings
    assert to_bytes(None) == b'None'
    assert to_bytes(6) == b'6'
    assert to_bytes(list(range(5))) == b'[0, 1, 2, 3, 4]'

    # Valid utf-8
    # test_bytes
    assert to_bytes(b'asdf') == b'asdf'
    # test_text
    assert to_bytes(u'asdf') == b'asdf'
    # unicode

# Generated at 2022-06-11 01:37:43.820210
# Unit test for function to_native

# Generated at 2022-06-11 01:37:51.804841
# Unit test for function to_native
def test_to_native():
    # Try a few Unicode characters that are outside the ASCII range
    # This also tests the surrogate_or_replace handler
    for char in (u'Ωˆ˜¨¯ß', u'™', u'\xab\u30af\u30ea\u30cb\u30c3\u30af\xbb'):
        # Try single characters
        assert to_native(char) == char.encode('utf-8').decode('ascii', 'surrogate_or_replace')

        # Try multiple times to make sure that we can't accidentally decode more than once
        assert to_native(to_native(char)) == char.encode('utf-8').decode('ascii', 'surrogate_or_replace')

        # Try the surrogate_or_replace error handler

# Generated at 2022-06-11 01:37:55.390426
# Unit test for function jsonify
def test_jsonify():
    data = dict(a=u"\xac\xb1\xdf\x8c",)
    result = jsonify(data)
    assert isinstance(result, basestring)


# Generated at 2022-06-11 01:37:59.332512
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({1: [to_bytes(u"\u0141ba"), to_bytes(u"b\u0107")]}) == '{"1": ["\\u0141ba", "b\\u0107"]}'



# Generated at 2022-06-11 01:38:22.280256
# Unit test for function to_bytes
def test_to_bytes():
    import sys
    import unittest

    class TestToBytes(unittest.TestCase):
        def test_to_bytes(self):
            b = to_bytes('abc123')
            self.assertEqual(b, b'abc123')

            # Test that normal strings are unmodified
            self.assertEqual(b, to_bytes(b))

            # Test different encodings
            self.assertEqual(b'\xe2\x9c\x88', to_bytes('\u2608'))
            self.assertEqual(b'\xe2\x98\x83', to_bytes('\u2603'))

            # Test surrogate handling

# Generated at 2022-06-11 01:38:32.393587
# Unit test for function to_native
def test_to_native():
    """Some basic checks for function to_native."""
    # Simple check for some values
    input_values = [b'test', u'test', 1]
    for value in input_values:
        assert to_native(value) == value

    # In python2, the bytes type actually is the same
    # as the native str type, so let's make sure that
    # to_native handles this case and doesn't just
    # return the same input value (which would be
    # a terrible implementation, but one that would
    # pass these tests!)
    # We'll do this by just checking if an encoded
    # ascii string returns itself with to_native,
    # since the bytes and str representation of ascii
    # are the same
    if not PY3:
        input_value = b'example string'
        assert to_

# Generated at 2022-06-11 01:38:35.403635
# Unit test for function to_native
def test_to_native():
    dict = {'this_is_a_key': 'this_is_a_value'}
    assert False
    return



# Generated at 2022-06-11 01:38:44.069389
# Unit test for function jsonify
def test_jsonify():
    # Not test unicode under Python3
    if PY3:
        return

    data = dict()
    data['regular'] = b'foo'
    data['unicode_str'] = u'\N{SNOWMAN}'
    data['unicode_bytes'] = u'\N{SNOWMAN}'.encode('utf-8')
    data['dict'] = dict()
    data['dict']['regular'] = b'bar'
    data['dict']['unicode_str'] = u'\N{SNOWMAN}'
    data['dict']['unicode_bytes'] = u'\N{SNOWMAN}'.encode('utf-8')

# Generated at 2022-06-11 01:38:53.219592
# Unit test for function to_native
def test_to_native():
    """Test proper conversion of mixed strings using to_native"""
    try:
        x = u'test'
        assert isinstance(x, text_type)
        assert to_native(x) == u'test'
    except NameError:
        # Python3 doesn't have unicode type
        pass

    x = 'test'
    assert isinstance(x, binary_type)
    assert to_native(x) == 'test'

    assert to_native(1) == 1
    assert to_native(None) is None
    assert to_native(['a', 'b']) == ['a', 'b']



# Generated at 2022-06-11 01:39:04.565583
# Unit test for function jsonify
def test_jsonify():
    data = {
        "str": {
            "unicode": u'\u2713',
            "utf-8": u'Ivan Krsti\u0107',
            "latin1": 'abcde\xf1'
        },
        "int": 1,
        "list": [u'\u2713', 'abcde\xf1'],
        "bool": False,
        "set": Set([u'\u2713', 'abcde\xf1']),
        "object": datetime.datetime.now()
    }
    assert jsonify(data) is not None
    # It is impossible to assert anything else as on Travis Python
    # jsonify always return the unchanged data with this test input
    #assert_equals(jsonify(data), json.dumps(data))



# Generated at 2022-06-11 01:39:08.936536
# Unit test for function to_native
def test_to_native():
    # my_obj = mock.MagicMock(return_value='This is a unicode string')
    my_obj = 'This is a unicode string'
    assert isinstance( to_native(my_obj, nonstring='simplerepr'), text_type)
    assert isinstance( to_native(my_obj, nonstring='passthru'), text_type)
    #assert isinstance( to_native(my_obj, nonstring='strict'), text_type)



# Generated at 2022-06-11 01:39:16.885450
# Unit test for function to_native
def test_to_native():
    assert 'foo' == to_native('foo')
    assert u'foo' == to_native(u'foo')

    # Python 2.6 doesn't have b'' notation
    if PY3:
        assert 'foo' == to_native(b'foo')
        assert 'foo' == to_native(bytearray(b'foo'))
    else:
        assert u'foo' == to_native('foo')
        assert u'foo' == to_native(bytearray('foo'))



# Generated at 2022-06-11 01:39:27.383826
# Unit test for function jsonify
def test_jsonify():
    data = {u"test": u"\u2713"}
    assert jsonify(data) == '{"test": "\\u2713"}'
    for encoding in ("utf-8", "latin-1"):
        try:
            assert json.dumps(data, encoding=encoding, default=_json_encode_fallback) == '{"test": "\\u2713"}'
        except TypeError:
            new_data = container_to_text(data, encoding=encoding)
            assert json.dumps(new_data, default=_json_encode_fallback) == '{"test": "\\u2713"}'
    data = {u"test": u"\u2713".encode('ascii')}
    assert jsonify(data) == '{"test": "?"}'

# Generated at 2022-06-11 01:39:31.073861
# Unit test for function jsonify
def test_jsonify():
    data = {'a': {
                'b': 'A'
                }
            }
    print(jsonify(data))
    print(jsonify(data, ensure_ascii=False))

