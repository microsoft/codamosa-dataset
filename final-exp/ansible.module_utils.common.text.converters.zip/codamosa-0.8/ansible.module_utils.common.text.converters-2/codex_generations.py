

# Generated at 2022-06-11 01:30:01.361620
# Unit test for function to_bytes
def test_to_bytes():
    if PY3:
        return
    # Test for issue #24968
    # Test for issue #30757

    a = u'\ud800'
    b = u'\udc00'
    ab = u'\U00010000'
    c = u'\ud800\udc00'
    d = u'\ud800'


# Generated at 2022-06-11 01:30:03.937191
# Unit test for function to_native
def test_to_native():
    assert to_native("foobar") == "foobar"
    assert to_native(b"foobar") == "foobar"

# Generated at 2022-06-11 01:30:06.469462
# Unit test for function to_native
def test_to_native():
    assert to_native(None) is None
    assert to_native("") == ''
    assert to_native("test") == 'test'
    assert to_native(u"") == ''
    assert to_native(u"test") == 'test'
    assert to_native(b"test") == 'test'



# Generated at 2022-06-11 01:30:08.508817
# Unit test for function to_native
def test_to_native():
    # result = to_native(binary_obj)
    assert False, "TODO"



# Generated at 2022-06-11 01:30:16.996220
# Unit test for function to_native
def test_to_native():
    ''' test the to_native function '''
    # pylint: disable=no-self-use
    # No selft use, this is a helper function
    if PY3:
        def assert_type_str(blah):
            assert isinstance(blah, str)
    else:
        def assert_type_str(blah):
            assert isinstance(blah, text_type)

    assert_type_str(to_native('foo'))
    assert_type_str(to_native(u'foo'))
    assert_type_str(to_native(u'État'))
    assert_type_str(to_native(b'foo'))
    assert_type_str(to_native(b'\xc3\x89tat'))


# Generated at 2022-06-11 01:30:26.832269
# Unit test for function to_bytes
def test_to_bytes():
    def check(value, encoding='utf-8', errors='surrogate_then_replace', nonstring='simplerepr'):
        """
        Assert that we can use to_bytes to turn the value into a bytestring, then
        that to_text can turn it into the original type.
        """
        # This should always be a byte string
        new_value = to_bytes(value, encoding=encoding, errors=errors, nonstring=nonstring)
        assert isinstance(new_value, binary_type)

        # In some cases, it's impossible to turn a bytestring back into the original type
        # We can try, but we have to be prepared to catch exceptions

# Generated at 2022-06-11 01:30:37.064653
# Unit test for function jsonify
def test_jsonify():
    d = dict(a=1, b=2)
    res = jsonify(d)
    assert res == '{"a": 1, "b": 2}'
    d = dict(a=1, b=Set([2, 3]))
    res = jsonify(d)
    assert res == '{"a": 1, "b": [2, 3]}'
    if not PY3:
        from ansible.module_utils._text import to_bytes, to_unicode
        d = dict(a=1, b=Set([2, 3, to_unicode(b'\xc3\xa9')]))
        res = jsonify(d)
        assert res == '{"a": 1, "b": [2, 3, "\\u00e9"]}'

# Generated at 2022-06-11 01:30:49.153463
# Unit test for function to_bytes
def test_to_bytes():
    assert b"\xfb" == to_bytes(u'\xfb')
    assert b"\xc3\xab" == to_bytes(u'\xeb')
    assert b"\xc3\xab" == to_bytes(u'\xeb', encoding='latin-1')

    assert b"\xe2\x89\xa0" == to_bytes(u'≠', encoding='latin-1', errors='surrogate_or_replace')
    assert b'\xe2\x89\xb0' == to_bytes(u'≥', encoding='latin-1', errors='surrogate_then_replace')
    assert b'\xe2\x89\xbf' == to_bytes(u'≿', encoding='latin-1', errors='surrogate_or_strict')

# Generated at 2022-06-11 01:30:54.704753
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    assert to_native(u'hello') == text_type('hello')
    assert to_native(b'hello') == text_type('hello')
    assert to_native(123) == text_type('123')
    assert to_native(set([1,2,3])) == text_type('set([1, 2, 3])')

# Generated at 2022-06-11 01:30:56.462234
# Unit test for function jsonify
def test_jsonify():
    json_data = jsonify(dict(sample = dict(a = '1', b = '2')))
    assert json_data == '{"sample": {"a": "1", "b": "2"}}'



# Generated at 2022-06-11 01:31:13.491539
# Unit test for function to_bytes
def test_to_bytes():
    def _check(obj, encoding, errors, nonstring, expected_value, expected_type=binary_type):
        assert isinstance(obj, text_type)
        actual_value = to_bytes(obj, encoding, errors, nonstring)
        assert isinstance(actual_value, expected_type), ("Expected %s but got %s" % (expected_type, type(actual_value)))
        assert actual_value == expected_value

    # Test various encodings
    for encoding in ('utf-8', 'latin-1'):
        # Test ascii string with different error handlers
        for errors in (None, 'surrogate_or_strict', 'surrogate_or_replace', 'surrogate_then_replace'):
            _check('abc', encoding, errors, 'simplerepr', b'abc')
       

# Generated at 2022-06-11 01:31:20.080234
# Unit test for function to_bytes
def test_to_bytes():
    from ansible_collections.tests.unit.compat._text_compat import get_bytes, get_text

    for obj in get_text():
        output = to_bytes(obj)
        assert isinstance(output, binary_type)

    for obj in get_bytes():
        output = to_bytes(obj)
        assert isinstance(output, binary_type)

    for obj in get_text():
        output = to_bytes(obj, nonstring='empty')
        assert isinstance(output, binary_type)

    for obj in get_bytes():
        output = to_bytes(obj, nonstring='empty')
        assert isinstance(output, binary_type)

    for obj in get_text():
        output = to_bytes(obj, nonstring='passthru')
        assert obj is output


# Generated at 2022-06-11 01:31:29.505367
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils import basic

    # Test this on python2.6 where we don't have surrogateescape
    utf8_capable_python26 = False
    if not HAS_SURROGATEESCAPE:
        try:
            codecs.lookup_error('surrogateescape')
            utf8_capable_python26 = True
        except LookupError:
            utf8_capable_python26 = False
    try:
        codecs.lookup_error('surrogate_or_strict')
        surrogate_or_strict = True
    except LookupError:
        surrogate_or_strict = False
    try:
        codecs.lookup_error('surrogate_or_replace')
        surrogate_or_replace = True
    except LookupError:
        surrogate_or

# Generated at 2022-06-11 01:31:42.031200
# Unit test for function to_bytes
def test_to_bytes():
    # Check to ensure that we don't add PY3 bytes tests for python2.4
    assert not isinstance(b'', text_type)
    assert not isinstance(b'', binary_type)
    x = b'foo'
    assert isinstance(x, binary_type)
    assert not isinstance(x, text_type)
    x = 'foo'
    assert isinstance(x, text_type)
    assert not isinstance(x, binary_type)
    x = u'foo'
    assert isinstance(x, text_type)
    assert not isinstance(x, binary_type)

    assert to_bytes(x) == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes('foo', nonstring='passthru') == u'foo'
   

# Generated at 2022-06-11 01:31:48.515765
# Unit test for function jsonify
def test_jsonify():
    data = {'hello': u"\xe7\xbd\x91\xe7\xbb\x9c"}
    result = jsonify(data)
    assert result == '{"hello": "\\u7f51\\u7edc"}'

    data = {'hello': u"\xe7\xbd\x91\xe7\xbb\x9c", 'world': u'\u4e16\u754c'}
    result = jsonify(data)
    assert result == '{"world": "\\u4e16\\u754c", "hello": "\\u7f51\\u7edc"}'

    data = set([u"\xe7\xbd\x91\xe7\xbb\x9c", 'latin-1'])
    result = jsonify(data)
    assert result

# Generated at 2022-06-11 01:31:50.663318
# Unit test for function jsonify
def test_jsonify():
    a = {'a': u'\u20ac', 'b': 'c'}
    print (jsonify(a))


# Generated at 2022-06-11 01:32:00.890437
# Unit test for function to_bytes
def test_to_bytes():
    class Test(object):

        def __str__(self):
            return 'str'

        def __repr__(self):
            return 'repr'

    test_value = Test()

# Generated at 2022-06-11 01:32:12.618267
# Unit test for function to_native
def test_to_native():
    class Struct:
        def __str__(self):
            return 'foo'

    class UnicodeStruct:
        def __str__(self):
            return u'\u0187'

    class ReprStruct:
        def __repr__(self):
            return 'foo'

    class UnicodeReprStruct:
        def __repr__(self):
            return u'\u0187'

        def __str__(self):
            raise UnicodeError('This unicode must not be used')

    class UnicodeStrStruct:
        def __str__(self):
            return u'\u0187'

        def __repr__(self):
            raise UnicodeError('This unicode must not be used')

    class BinaryStrStruct:
        def __str__(self):
            return b'\x00'


# Generated at 2022-06-11 01:32:21.895858
# Unit test for function jsonify
def test_jsonify():
    data = dict(a='root', b=dict(a='foo', b='bar', c=['baz', 'qux']))
    ret = jsonify(data)
    assert(ret == '{"a": "root", "b": {"a": "foo", "b": "bar", "c": ["baz", "qux"]}}')
    data = dict(a='root', b=dict(a='foo', b='bar', c=[u'baz', 'qux']))
    ret = jsonify(data)
    assert(ret == '{"a": "root", "b": {"a": "foo", "b": "bar", "c": ["baz", "qux"]}}')

# Generated at 2022-06-11 01:32:29.179345
# Unit test for function jsonify
def test_jsonify():
    booldata = True
    intdata = 1
    strdata = u"a"
    bundledata = [booldata, intdata, strdata]
    tupledata = (booldata, intdata, strdata)
    dictdata = {strdata: bundledata}
    datas = [booldata, intdata, bundledata, tupledata, dictdata]
    for data in datas:
        assert jsonify(data) is not None


# Generated at 2022-06-11 01:32:37.551685
# Unit test for function to_native
def test_to_native():
    # We make this a function so we can catch import errors in the unit tests
    from ansible.module_utils._text import to_native
    return to_native



# Generated at 2022-06-11 01:32:42.916930
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    assert isinstance(to_native(True), text_type)
    assert isinstance(to_native(1), text_type)
    assert isinstance(to_native(1.0), text_type)


# Generated at 2022-06-11 01:32:52.288941
# Unit test for function jsonify
def test_jsonify():
    # Test string
    data = u'test'
    encoded = jsonify(data)
    assert encoded == '"test"', "jsonify didn't encode the string correctly"

    # Test lists
    data = [u'u1', u'u2', u'u3']
    encoded = jsonify(data)
    assert encoded == '["u1", "u2", "u3"]', "jsonify didn't encode the list correctly"

    # Test dicts
    data = {u'key1': u'val1', u'key2': u'val2', u'key3': u'val3'}
    encoded = jsonify(data)
    assert encoded == '{"key1": "val1", "key2": "val2", "key3": "val3"}', "jsonify didn't encode the dict correctly"

    #

# Generated at 2022-06-11 01:33:05.586477
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'foo') == '"foo"'
    assert jsonify([u'foo', u'bar']) == '["foo", "bar"]'
    assert jsonify({u'foo': u'bar'}) == '{"foo": "bar"}'
    assert jsonify(u'\u3042') == '"\\u3042"'
    assert jsonify({u'1': 123}) == '{"1": 123}'
    assert jsonify([u'\u3042', u'\u3044']) == '["\\u3042", "\\u3044"]'

# Generated at 2022-06-11 01:33:09.685965
# Unit test for function to_native
def test_to_native():
    def test(obj, expected):
        result = to_native(obj, nonstring='simplerepr')
        if result != expected:
            raise AssertionError("to_native(%s) != %s but %s" % (str(obj), result, expected))
        if type(result) is not type(expected):
            raise AssertionError("to_native(%s) returns type %s instead of %s" % (str(obj), type(result), type(expected)))
    test('hi', 'hi')
    test(u'hi', 'hi')
    test('hi'.encode('utf-8'), 'hi')
    class Foo(object):
        def __repr__(self):
            return 'Foo'
    test(Foo(), 'Foo')



# Generated at 2022-06-11 01:33:20.169520
# Unit test for function to_bytes
def test_to_bytes():
    import codecs
    codecs.register_error('strict', codecs.strict_errors)
    assert (u'\n'.encode() == to_bytes(u'\n'))
    assert (u'\n'.encode() == to_bytes(b'\n'))
    assert (u'\u1234'.encode() == to_bytes(u'\u1234'))
    assert (u'\u1234'.encode() == to_bytes(u'\u1234'.encode()))
    assert (u'\n'.encode() == to_bytes('\n'))
    assert (u'\n'.encode() == to_bytes(b'\n', nonstring='passthru'))

# Generated at 2022-06-11 01:33:30.771267
# Unit test for function jsonify
def test_jsonify():
    def eq(a, b):
        assert a == b
    eq(jsonify({"foo": "bar"}), '{"foo": "bar"}')
    eq(jsonify({"foo": to_text("bar")}), '{"foo": "bar"}')
    eq(jsonify({"foo": to_bytes("bar", encoding="utf-8")}), '{"foo": "bar"}')
    eq(jsonify({"foo": to_bytes("bar", encoding="latin-1")}), '{"foo": "bar"}')
    eq(jsonify({"foo": to_bytes("bar", encoding="ascii")}), '{"foo": "bar"}')
    eq(jsonify({"foo": {'baz': 'qux'}}), '{"foo": {"baz": "qux"}}')

# Generated at 2022-06-11 01:33:36.272912
# Unit test for function to_native
def test_to_native():

    # Test to_native with text objects
    assert to_native(u'foo') == u'foo'

    # Test to_native with bytes objects
    assert to_native(b'foo') == u'foo'

    # Test to_native with other objects
    assert to_native(100) == '100'



# Generated at 2022-06-11 01:33:39.154569
# Unit test for function to_native
def test_to_native():
    assert to_native(
        'string',
        encoding=None,
        nonstring=None,
        method='bogus',
    ) == 'string'



# Generated at 2022-06-11 01:33:44.964064
# Unit test for function jsonify
def test_jsonify():
    data = dict(
        a = dict(b = dict(c = dict(d = dict(e = dict(f = [1,2,3], g = [4,5,6]))))),
        h = [8, 9, "a"]
    )
    assert jsonify(data) == '{"a": {"b": {"c": {"d": {"e": {"f": [1, 2, 3], "g": [4, 5, 6]}}}, "h": [8, 9, "a"]}}}'


# Generated at 2022-06-11 01:34:01.963225
# Unit test for function to_bytes
def test_to_bytes():
    #
    # Test that passing in a byte string returns that byte string
    #
    bs = b'Fake byte string'
    result = to_bytes(bs)
    assert isinstance(result, binary_type)
    assert result == bs
    result = to_bytes(bs, 'us-ascii')
    assert isinstance(result, binary_type)
    assert result == bs

    #
    # Test that passing in a text string returns encoded to utf-8 by default
    #
    ts = 'Fake text string'
    result = to_bytes(ts)
    assert isinstance(result, binary_type)
    assert result == ts
    result = to_bytes(ts, 'us-ascii')
    assert isinstance(result, binary_type)
    assert result == ts

# Generated at 2022-06-11 01:34:11.839051
# Unit test for function to_bytes
def test_to_bytes():
    class TestClass(object):
        def __str__(self):
            return u'test_str'

        def __repr__(self):
            return u'test_repr'

    assert to_bytes('b') == b'b'
    assert to_bytes(u'bb') == b'bb'
    assert to_bytes(u'bb', errors='replace') == b'bb'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='replace') == b'?\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'?\xe1\x88\xb4'

# Generated at 2022-06-11 01:34:24.197052
# Unit test for function to_bytes
def test_to_bytes():
    # Simple smoke test to make sure we can encode
    assert to_bytes(u'foo') == b'foo'

    # Try out all the error handlers
    # This tests surrogate_or_strict, surrogate_or_replace, surrogate_then_replace
    assert to_bytes(u'foo\udcba') == b'foo?'

    if HAS_SURROGATEESCAPE:
        # Test surrogateescape
        assert to_bytes(u'foo\udcba', errors='surrogateescape') == b'foo\xdc\xba'
        assert to_bytes(u'foo\udcba', errors='surrogateescape').decode('utf-8', 'surrogateescape') == u'foo\udcba'

        # Test an invalid surrogate

# Generated at 2022-06-11 01:34:33.895348
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import json
    # Make sure that a utf-8 string can be encoded/decoded
    test_string = "føø"
    encoded_string = jsonify(test_string)
    if encoded_string is not None and isinstance(encoded_string, str):
        encoded_string = to_bytes(encoded_string)
    decoded_string = json.loads(encoded_string)
    assert test_string == decoded_string
    basic.AnsibleModule(argument_spec=dict(x=dict(type='str'))).exit_json(**{'x': test_string})
    # Make sure that a latin-1 string can be encoded/decoded

# Generated at 2022-06-11 01:34:37.894293
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_text
    assert jsonify(to_text('\xe5\xb0\x8f\xe5\x9c\xa8')) == r'"\u5c0f\u5728"'


# Generated at 2022-06-11 01:34:50.086860
# Unit test for function to_native

# Generated at 2022-06-11 01:34:59.152654
# Unit test for function to_bytes
def test_to_bytes():
    # Sample text that is ASCII on the surface but has non-ASCII bytes in the
    # UTF-8 encoding
    sample_text = "Sample ASCII text \xe2\x98\x83"

    # This is a UTF-8 string that is non-ASCII
    sample_text_u = u"Sample ASCII text \u2603"

    # This is a UTF-8 string that is invalid.  We should not be able to encode
    # it to UTF-8.
    sample_bad_u = u"Sample ASCII text \uDC80\uDC80"
    sample_bad = u"Sample ASCII text \xdc\x80\xdc\x80".encode('utf-8')

    def compare_bytes(a, b):
        if PY3:
            return a == b

# Generated at 2022-06-11 01:35:02.499265
# Unit test for function jsonify
def test_jsonify():
    test_data = {b'bytes': b'value'}
    new_data = jsonify(test_data)
    data = json.loads(new_data)
    assert data["bytes"] == 'value'



# Generated at 2022-06-11 01:35:09.580111
# Unit test for function jsonify
def test_jsonify():
    data = dict(a="Hello", b="World", c=123, d=456)
    assert jsonify(data) == json.dumps(data, default=_json_encode_fallback)

    data = dict(a={"b": "Hello", "c": 123, "d": None}, x=[1, 2, 3, "Hello"])
    assert jsonify(data) == json.dumps(data, default=_json_encode_fallback)


# Generated at 2022-06-11 01:35:20.047406
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'ascii') == b'ascii'
    assert to_bytes(b'\xe5\xae\x89\xe5\xbf\x83') == b'\xe5\xae\x89\xe5\xbf\x83'
    assert to_bytes(u'\u5b89\u5fc3') == b'\xe5\xae\x89\xe5\xbf\x83'
    assert to_bytes(u'\u5b89\u5fc3', encoding='gbk') == b'\xb0\xa1\xbf\xda'

    # This is a 3 byte unicode character.  It will not fit in latin-1

# Generated at 2022-06-11 01:35:34.995571
# Unit test for function jsonify
def test_jsonify():
    if json.dumps({'foo': u'bar'}) != '{}':
        raise ValueError('jsonify() needs to be fixed')
    if json.dumps({'foo': u'bar'}, ensure_ascii=False) != '{"foo": "bar"}':
        raise ValueError('jsonify() needs to be fixed')



# Generated at 2022-06-11 01:35:43.828539
# Unit test for function jsonify
def test_jsonify():
    # Testing for normal dict
    d = dict({"foo":"bar", "baz":["foobar", "baz", "qux"], "corge": "grault"})
    assert jsonify(d) == '{"baz": ["foobar", "baz", "qux"], "corge": "grault", "foo": "bar"}'
    assert jsonify(d, sort_keys=True) == '{"baz": ["foobar", "baz", "qux"], "corge": "grault", "foo": "bar"}'

# Generated at 2022-06-11 01:35:54.948983
# Unit test for function to_native
def test_to_native():
    b_utf8 = to_bytes(u'\u2713', 'utf-8', 'strict')
    assert to_text(b_utf8, 'utf-8') == u'\u2713'

    b_latin1 = to_bytes(u'\u00e9', 'latin-1', 'strict')
    assert to_text(b_latin1, 'latin-1') == u'\u00e9'

    b_latin1 = to_bytes(u'\u00e9', 'latin-1')
    assert to_text(b_latin1, 'latin-1', 'ignore') == u''

    if HAS_SURROGATEESCAPE:
        b_utf8 = to_bytes(u'\u2713', 'utf-8')

# Generated at 2022-06-11 01:36:04.751832
# Unit test for function to_native
def test_to_native():
    mystr = "mystr"
    mybytes = b"mybytes"
    if PY3:
        assert mystr == to_native(mystr)
        assert mybytes.decode('utf-8') == to_native(mybytes)
        assert mystr == to_native(mystr, method='smart')
        assert mybytes.decode('utf-8') == to_native(mybytes, method='smart')
    else:
        assert mystr == to_native(mystr)
        assert mybytes == to_native(mybytes)
        assert mystr == to_native(mystr, method='smart')
        assert mybytes == to_native(mybytes, method='smart')
    assert mystr == to_native(mystr, method='force')
    assert mybytes == to_native(mybytes, method='force')

# Generated at 2022-06-11 01:36:11.341696
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.six import b as B, u as U, PY3

    # Test nonstrings
    assert to_bytes(42) == B('42')
    assert to_bytes([1, 2, 3]) == B('[1, 2, 3]')
    assert to_bytes(u'ascii') == B('ascii')

    # Test byte string inputs
    assert to_bytes(B('foo'), 'ascii') == B('foo')
    assert to_bytes(B('foo\xe9'), 'ascii') == B('foo\xe9')
    assert to_bytes(B('foo\xe9'), 'utf-8') == B('foo\xc3\xa9')

    # Test text string inputs
    assert to_bytes(U('foo')) == B('foo')

# Generated at 2022-06-11 01:36:21.785061
# Unit test for function jsonify
def test_jsonify():
    import os
    import six
    import json

    if six.PY2:
        unicode_type = unicode
    else:
        unicode_type = str

    # Test set serialization
    test_set = Set([u'foo', u'bar', u'baz'])

    # Test Datetime serialization
    test_datetime = datetime.datetime.utcnow()

    test_data = dict(a=dict(b=unicode_type("c")))
    test_data["set"] = test_set
    test_data["datetime"] = test_datetime

    result = jsonify(test_data)

# Generated at 2022-06-11 01:36:24.093668
# Unit test for function jsonify
def test_jsonify():
    # data = dict(aa=u'中文')
    # assert jsonify(data) is not None
    pass



# Generated at 2022-06-11 01:36:26.978859
# Unit test for function to_native
def test_to_native():
    if False:
        # We don't actually use this but make the syntax checker happy
        # This can't be right because we're not returning a string...
        to_native(u'stringwhat')



# Generated at 2022-06-11 01:36:29.268192
# Unit test for function jsonify
def test_jsonify():
    test_data = {'basic': 'test'}
    assert jsonify(test_data) == '{"basic": "test"}'



# Generated at 2022-06-11 01:36:36.640804
# Unit test for function to_bytes
def test_to_bytes():
    def t(input_obj, expected_output, errors=None, nonstring='simplerepr'):
        assert to_bytes(input_obj, errors=errors, nonstring=nonstring) == expected_output
        if isinstance(expected_output, binary_type):
            assert isinstance(to_bytes(input_obj, errors=errors, nonstring=nonstring), binary_type)

    t(u'\x00\x01\x02\x03', b'\x00\x01\x02\x03')
    t(u'\u0100\u0101\u0102\u0103', b'\xc4\x80\xc4\x81\xc4\x82\xc4\x83')

# Generated at 2022-06-11 01:36:54.153892
# Unit test for function to_native
def test_to_native():
    """
    Test to_native function
    """
    # --------
    # Integer
    # --------
    # data types as integer
    assert to_native(1) == 1
    assert to_native(0) == 0
    # Positive integer
    assert to_native(1) == 1
    assert to_native(+1) == 1
    # Negative integer
    assert to_native(-1) == -1
    # Zero integer
    assert to_native(0) == 0
    # Maximum integer
    assert to_native(2147483647) == 2147483647
    # Minimum integer
    assert to_native(-2147483648) == -2147483648
    # Maximum positive integer
    assert to_native(2147483647) == 2147483647
    # Maximum negative integer
    assert to_

# Generated at 2022-06-11 01:37:01.899747
# Unit test for function jsonify
def test_jsonify():
    from ansible.parsing import vault
    import datetime
    assert jsonify({u'foo': u'bar'}) == '{"foo": "bar"}'
    assert jsonify({u'foo': u'bar', u'a': [1, 2, 3], u'b': (1, 2, 3), u'c': u'foobar'}) == '{"a": [1, 2, 3], "c": "foobar", "b": [1, 2, 3], "foo": "bar"}'
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify(dict(vault.VaultSecret('password'))) == '{"__ansible_vault": "2.0"}'

# Generated at 2022-06-11 01:37:14.568590
# Unit test for function to_bytes
def test_to_bytes():
    string = u'spam'
    string_bytes = b'spam'
    assert(to_bytes(string) == string_bytes)
    assert(to_bytes(string, nonstring='passthru') == string)

    bad_string = u'spam\ufffe'
    assert(to_bytes(bad_string) == b'spam\ufffd')
    assert(to_bytes(bad_string) == b'spam\ufffd')
    assert(to_bytes(bad_string, errors='surrogate_then_replace') == b'spam?')
    assert(to_bytes(bad_string, errors='surrogate_or_replace') == b'spam?')
    assert(to_bytes(bad_string, errors='surrogate_or_strict') == b'spam?')


# Generated at 2022-06-11 01:37:22.093648
# Unit test for function to_bytes

# Generated at 2022-06-11 01:37:31.986035
# Unit test for function jsonify
def test_jsonify():
    data = {
        text_type('test'): set([1, 2, 3]),
        u'test2': datetime.datetime.utcnow(),
    }
    # Test for ansible 2.4 in python 2.7
    assert isinstance(jsonify(data), str)
    # Test for ansible 2.4 in python 3.6
    assert isinstance(jsonify(data), str)
    # Test for ansible 2.5 in python 2.7
    assert isinstance(jsonify(data), str)
    # Test for ansible 2.5 in python 3.6
    assert isinstance(jsonify(data), str)



# Generated at 2022-06-11 01:37:42.394778
# Unit test for function jsonify
def test_jsonify():
    test_input_data = {
        u"name": u"f@\xefoo",
        u"value": Set([1, 2]),
        u"time": datetime.datetime(2013, 12, 25, 11, 14, 25, 875000),
        u"enable": True,
        u"dict": {
            u"name": u"bar",
            u"value": Set([1, 2]),
            u"time": datetime.datetime(2013, 12, 25, 11, 14, 25, 875000),
            u"enable": True
        }
    }

# Generated at 2022-06-11 01:37:50.027690
# Unit test for function jsonify
def test_jsonify():
    data = b'{ "test": [1, 2, 3, { "with": "accent" }] }'
    assert jsonify(data) == u'{ "test": [1, 2, 3, { "with": "accent" }] }'
    assert isinstance(jsonify(data), unicode)
    assert jsonify(data, indent=4) == u'{\n    "test": [\n        1, \n        2, \n        3, \n        {\n            "with": "accent"\n        }\n    ]\n}'
    assert jsonify(data, sort_keys=True) == u'{ "test": [1, 2, 3, { "with": "accent" }] }'

# Generated at 2022-06-11 01:37:57.118492
# Unit test for function jsonify
def test_jsonify():
    data = dict(
        aa=dict(
            bb=dict(
                cc=135,
            ),
        ),
        dd=dict(
            ee='sometext',
        ),
    )
    assert jsonify(data) == '{"aa": {"bb": {"cc": 135}}, "dd": {"ee": "sometext"}}'

    data = Set([1,2,3])
    assert jsonify(data) == '[1, 2, 3]'



# Generated at 2022-06-11 01:38:07.156954
# Unit test for function to_native
def test_to_native():
    assert to_native("string") == "string"
    assert to_native("string", encoding='ascii') == b"string"
    assert to_native("string", errors='surrogate_or_strict') == u"string"
    assert to_native("string", encoding='ascii', errors='surrogate_or_strict') == b"string"
    assert to_native(u"string") == "string"
    assert to_native(u"string", encoding='ascii') == b"string"
    assert to_native(u"string", errors='surrogate_or_strict') == u"string"
    assert to_native(b"string", encoding='ascii') == "string"

# Generated at 2022-06-11 01:38:16.788873
# Unit test for function to_bytes
def test_to_bytes():

    def validate(input_string, **kwargs):
        # Note: We don't use assertRaisesRegexp in 2.6-compatible code because
        # it's not always available in 2.6.
        try:
            result = to_bytes(input_string, **kwargs)
        except TypeError as e:
            if 'must be a string type' in to_native(e):
                return
            raise

        if not isinstance(result, binary_type):
            raise AssertionError('Result (%s) is not a byte string' % result)

    # Test byte string
    validate(b'abc')

    # Test text string
    validate('abc', encoding='latin-1')
    validate('abć')
    validate('ab\udc80')

    # Test non-string

# Generated at 2022-06-11 01:38:25.682112
# Unit test for function jsonify
def test_jsonify():
    data = {u"text": u"ÁÇÊÉ"}
    assert jsonify(data) == '{"text": "\\u00c1\\u00c7\\u00ca\\u00c9"}'



# Generated at 2022-06-11 01:38:32.836798
# Unit test for function jsonify
def test_jsonify():
    '''test_dict = {
        "a": {
            "b": {
                "c": [b"\xc3\xb1"]
            }
        }
    }'''
    test_dict = {
        "a": {
            "b": {
                "c": [b"\xc3\xb1"]
            }
        }
    }  
    print("test_dict: ", test_dict)
    print("jsonify(test_dict): ", jsonify(test_dict))



# Generated at 2022-06-11 01:38:42.758115
# Unit test for function to_bytes
def test_to_bytes():
    def check_equal(obj, encoding='utf-8', errors=None, nonstring='simplerepr', expected=None):
        if expected is None:
            expected = to_bytes(obj, encoding, errors, nonstring)
        result = to_bytes(obj, encoding, errors, nonstring)
        assert result == expected, '''\
Expected to_bytes({obj!r}, {encoding!r}, {errors!r}, {nonstring!r}) to return {expected!r}
but it returned {result!r}'''.format(**locals())

# Generated at 2022-06-11 01:38:54.086122
# Unit test for function to_bytes
def test_to_bytes():
    # The function to_bytes is tested separately from the other codecs because
    # it has a nonstandard error handler.
    from ansible.module_utils.compat import _compat_b_to_s

    # Note: We don't bother testing that to_bytes doesn't return a text string
    # because the re-wrap-to-bytes test will fail in that case

    # No surrogate escapes
    assert to_bytes(u'привет') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

# Generated at 2022-06-11 01:39:05.108531
# Unit test for function jsonify
def test_jsonify():
    test_dict = dict(a=u'\u2713', b=u'\u2714')
    test_string = jsonify(test_dict)
    assert '"a": "\\u2713"' in test_string
    assert '"b": "\\u2714"' in test_string
    test_string = jsonify(test_dict, sort_keys=True)
    assert '"a": "\\u2713"' in test_string
    assert '"b": "\\u2714"' in test_string
    test_list = [ u'\u2713', u'\u2714' ]
    test_string = jsonify(test_list)
    assert '"\\u2713"' in test_string
    assert '"\\u2714"' in test_string

# Generated at 2022-06-11 01:39:16.649286
# Unit test for function jsonify
def test_jsonify():
    data_str = 'ansible'
    data_unicode = u'ansible'
    assert jsonify(data_str) == '"ansible"'
    assert jsonify(data_unicode) == '"ansible"'
    data_list_str = ['ansible', 'is', 'awesome']
    data_list_unicode = [u'ansible', u'is', u'awesome']
    assert jsonify(data_list_unicode) == '["ansible", "is", "awesome"]'
    assert jsonify(data_list_str) == '["ansible", "is", "awesome"]'
    assert jsonify(dict(a="ansible", b="awesome")) == '{"a": "ansible", "b": "awesome"}'

# Generated at 2022-06-11 01:39:27.137348
# Unit test for function to_bytes
def test_to_bytes():
    # No surrogates, no non-ascii characters
    in_string = b'abc123'
    assert(to_bytes(in_string, encoding='ascii') == in_string)
    assert(to_bytes(in_string, encoding='ascii', errors=None) == in_string)
    assert(to_bytes(in_string, encoding='ascii', errors='surrogate_or_strict') == in_string)
    assert(to_bytes(in_string, encoding='ascii', errors='surrogate_or_replace') == in_string)
    assert(to_bytes(in_string, encoding='ascii', errors='surrogate_then_replace') == in_string)

    # Non-ascii characters

# Generated at 2022-06-11 01:39:37.400011
# Unit test for function jsonify
def test_jsonify():
    from collections import OrderedDict

    assert jsonify(u'foo') == '"foo"'
    assert jsonify(u'fóo') == '"fóo"'
    assert jsonify(u'fóo'.encode('latin-1')) == '"fóo"'
    # if we jsonify an object that can't be encoded, it should throw an exception
    # this should also be true if we pass in a dict
    if sys.version_info >= (2, 7):
        assert Raises(TypeError, jsonify, {u'fóo': u'bar'})
        assert Raises(TypeError, jsonify, {u'fóo'.encode('latin-1'): u'bar'})
