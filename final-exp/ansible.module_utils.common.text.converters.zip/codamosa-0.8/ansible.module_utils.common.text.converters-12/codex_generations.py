

# Generated at 2022-06-11 01:29:49.942497
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"key": u"\u2713"}) == '{"key": "\\u2713"}'


# Generated at 2022-06-11 01:29:53.795324
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'foo\\u1234') == b'foo\\u1234'



# Generated at 2022-06-11 01:30:05.554468
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

    assert to_native(u'foo') == u'foo'
    assert isinstance(to_native(u'foo'), text_type)
    assert isinstance(to_native(b'foo'), text_type)
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo\xc3\xaf\xc2\xbb\xc2\xbf') == u'fooï»¿'
    assert isinstance(to_native(u'foo'), text_type)
    assert isinstance(to_native('foo'), text_type)

# Generated at 2022-06-11 01:30:15.218989
# Unit test for function to_bytes
def test_to_bytes():
    """
    These tests vary the encoding, errors, and nonstring parameters to
    to_bytes() to ensure that it properly handles all the cases
    """
    import sys
    from io import BytesIO

    def uc(text):
        # We use this a lot
        return text.decode('utf-8')

    # By default this just returns the string it's passed
    assert b'abc' == to_bytes(b'abc'), 'to_bytes should return a bytes object'

    # Strings with surrogates
    assert b'\xff' == to_bytes(uc('\udcff')), 'Invalid surrogate should be replaced'
    assert b'\xff' == to_bytes(uc('\udcff'), errors='replace'), 'surrogate_or_replace should be replace'

# Generated at 2022-06-11 01:30:25.675416
# Unit test for function to_bytes
def test_to_bytes():
    # to_bytes(obj, <defaults>) -> byte string

    # obj is byte string -> byte string
    assert to_bytes('string') == 'string'
    assert to_bytes(b'string') == b'string'

    # obj is text string -> default encoding in byte string
    assert to_bytes(u'string') == b'string'

    # obj is text string with non-ascii -> default encoding in byte string
    assert to_bytes(u'str\xc3\xadng') == b'str\xc3\xadng'

    # obj is text string with non-ascii and encoding -> encoding in byte string
    assert to_bytes(u'str\xc3\xadng', encoding='latin-1') == b'str\xedng'

    # obj is text string with non

# Generated at 2022-06-11 01:30:34.253479
# Unit test for function to_native
def test_to_native():
    assert to_native('foo') == 'foo'
    assert to_native('foo'.encode('utf-8')) == 'foo'
    assert to_native(1) == '1'
    assert to_native(True) == 'True'
    class Foo(object):
        def __str__(self):
            return 'foo'
        def __repr__(self):
            return 'bar'
    assert to_native(Foo()) == 'foo'
    assert to_native(Set()) == 'set()'
    assert to_native(datetime.datetime.now()) == str(datetime.datetime.now())



# Generated at 2022-06-11 01:30:44.892587
# Unit test for function to_bytes
def test_to_bytes():
    # some very basic tests for the function
    assert to_bytes('ascii') == b'ascii'
    assert to_bytes(u'unicode') == b'unicode'
    assert to_bytes(u'z\u03A3') == b'z\xce\xa3'
    assert to_bytes(u'z\u03A3', errors='surrogate_then_replace') == b'z\xef\xbf\xbd\xce\xa3'
    assert to_bytes(u'\uFFFD') == b'\xef\xbf\xbd'
    assert to_bytes(u'\uFFFD', errors='surrogate_then_replace') == b'\xef\xbf\xbd'

# Generated at 2022-06-11 01:30:51.967760
# Unit test for function to_native
def test_to_native():

    # Test to ensure that to_native works as expected.
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8')) == u'\u2713'



# Generated at 2022-06-11 01:30:54.642398
# Unit test for function to_native
def test_to_native():
    etalon = 'Test text'
    ans = to_text(etalon, 'utf-8', 'surrogate_or_replace')
    assert ans == etalon


# Generated at 2022-06-11 01:31:03.327678
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u2713', errors='strict') == u'\u2713'
    assert to_native(u'\u2713', errors='surrogate_then_replace') == u'\u2713'
    assert to_native(u'\u2713', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(u'\u2713', errors='surrogate_or_replace') == u'\u2713'

    assert to_native(b'\xe2\x9c\x93', errors='strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == u'\u2713'
    assert to_

# Generated at 2022-06-11 01:31:25.381054
# Unit test for function to_bytes
def test_to_bytes():
    assert b'' == to_bytes(to_bytes(''))
    assert b'a' == to_bytes(to_bytes('a'))
    assert b'a' == to_bytes(to_bytes('a', errors='replace', nonstring='strict'))
    assert b'a' == to_bytes(to_bytes('a\xe0', errors='replace', nonstring='strict'))
    assert b'a?' == to_bytes(to_bytes('a\xe0', errors='replace', nonstring='strict'), encoding='latin1')
    assert b'a\xff' == to_bytes(to_bytes(b'a\xff', errors='replace', nonstring='strict'), encoding='latin1')

# Generated at 2022-06-11 01:31:32.076328
# Unit test for function to_native
def test_to_native():
    data = {
        u'test': u'中文',
        b'test': b'\xe4\xb8\xad\xe6\x96\x87',
    }
    if PY3:
        assert data[u'test'] == to_text(data[b'test'], nonstring='passthru')
    else:
        assert data[u'test'] == data[b'test'].decode('utf-8')
        assert data[u'test'] == to_native(data[b'test'], nonstring='passthru')
    assert data[u'test'] == to_native(data[u'test'], nonstring='passthru')



# Generated at 2022-06-11 01:31:44.790995
# Unit test for function jsonify
def test_jsonify():
    import json
    import unittest
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_text
    import ansible.module_utils._text 
    from ansible.module_utils._text import container_to_text, container_to_bytes
    import sys
    import ansible.module_utils.common
    #1. jsonify works to encode a string
    data1 = to_bytes('hello')
    #print "unicode test1: " , jsonify(dict(data=data1))
    assert jsonify(dict(data=data1)) == u'{"data": "hello"}'
    #2. jsonify works to encode an int

# Generated at 2022-06-11 01:31:54.355703
# Unit test for function jsonify
def test_jsonify():
    data = {
        'text': u'\ud83d\ude80',
        'binary': u'\ud83d\ude80'.encode('utf-8'),
        'none': None,
        'simple': 'simple',
        'integer': 42,
        'datetime': datetime.datetime(2018, 12, 10, 10, 11, 12),
        'set': set([u'\ud83d\ude80', 'simple', 42, None])
    }
    json_data = jsonify(data)

# Generated at 2022-06-11 01:32:05.621829
# Unit test for function to_bytes
def test_to_bytes():
    # Error handlers
    for error_handler in ('strict', 'ignore', 'replace', 'xmlcharrefreplace', 'backslashreplace', 'surrogateescape'):
        assert isinstance(to_bytes('\u00e9\u00f1\u00f1\u00a8\u00e1', errors=error_handler), binary_type)

    # Error handler aliases
    if HAS_SURROGATEESCAPE:
        assert isinstance(to_bytes('\udcc3\udc9a\udcc3\udc9b\udcc3\udc98\udcc3\udc9c\udcc3\udc92', errors='surrogate_or_strict'), binary_type)

# Generated at 2022-06-11 01:32:11.853756
# Unit test for function jsonify
def test_jsonify():
    ''' returns a json string from dict data, using the utf-8 encoding by default
        data is a dict
        encoding is the encoding (default utf8)
        keys and values in dict are strings
        json is a string
    '''
    assert jsonify({'a':'b'}) == json.dumps({'a':'b'}, default=_json_encode_fallback)



# Generated at 2022-06-11 01:32:21.443380
# Unit test for function to_bytes
def test_to_bytes():
    # Empty tests
    assert to_bytes(None) == b''
    assert to_bytes(None, 'latin-1') == b''
    assert to_bytes(None, 'utf-8') == b''
    assert to_bytes(None, 'utf-8', 'strict') == b''
    assert to_bytes(None, 'utf-8', 'surrogateescape') == b''
    assert to_bytes(None, 'utf-8', 'surrogate_or_replace') == b''
    assert to_bytes(None, 'utf-8', 'surrogate_or_strict') == b''
    assert to_bytes(None, 'utf-8', 'surrogate_then_replace') == b''

    # Known text strings
    assert to_bytes('test') == b'test'
    assert to_

# Generated at 2022-06-11 01:32:34.109049
# Unit test for function jsonify
def test_jsonify():
    data = dict(
        unicode_key=u"unicode_value",
        binary_key=b"binary\xe5\xad\x97\xe7\xac\xa6",
        dict_key={u"unicode_key": u"unicode_value", b"binary_key": b"binary\xe5\xad\x97\xe7\xac\xa6"},
        list_key=[u"unicode_key", b"binary\xe5\xad\x97\xe7\xac\xa6"],
        set_key=set([{u"unicode_key": u"unicode_value", b"binary_key": b"binary\xe5\xad\x97\xe7\xac\xa6"}])
    )
    assert jsonify(data)

# Generated at 2022-06-11 01:32:46.286620
# Unit test for function to_bytes
def test_to_bytes():
    # Test some basic conversions
    # NOTE: These tests don't use the default error handler.  They are just
    # basic tests to make sure to_bytes is doing the same thing as
    # .encode(encoding, errors)
    assert to_bytes('test', 'latin-1') == b'test'
    assert to_bytes(u'\xff', encoding='ascii', errors='surrogate_then_replace') == b'\xef\xbf\xbd'
    assert to_bytes(u'\xe9', encoding='ascii', errors='ignore') == b''
    assert to_bytes(b'\xe9', encoding='ascii', errors='ignore') == b'\xe9'

# Generated at 2022-06-11 01:32:55.267912
# Unit test for function to_native
def test_to_native():
    # Basic tests
    assert to_native(None) == 'None'
    if PY3:
        assert to_native(True) == 'True'
        assert to_native(False) == 'False'
    assert to_native('test') == 'test'
    assert to_native(b'test') == 'test'
    # Test with datetime
    dt = datetime.datetime(2017, 1, 1, 0, 0, 0)
    assert to_native(dt) == dt.isoformat()
    # Test with dict
    test_dict = dict(
        one=1,
        two='2',
        three=None,
        four=[1, 2, 3],
        five={'a': '1', 'b': '2'},
        six=set([1, 2, 3]),
    )


# Generated at 2022-06-11 01:33:12.898265
# Unit test for function to_native

# Generated at 2022-06-11 01:33:22.175075
# Unit test for function jsonify
def test_jsonify():
    data = {u'\u30aa\u30fc\u30c7\u30a3\u30b7\u30e7\u30f3\u306e\u30c7\u30b6\u30a4\u30ca\u30fc':u'\u5b89\u4e95 \u8cb4\u6587'}
    json_data = jsonify(data)
    assert json_data == u'{"\u30aa\u30fc\u30c7\u30a3\u30b7\u30e7\u30f3\u306e\u30c7\u30b6\u30a4\u30ca\u30fc": "\u5b89\u4e95 \u8cb4\u6587"}'


# Generated at 2022-06-11 01:33:33.968333
# Unit test for function to_native
def test_to_native():

    assert to_native(u'\u1234') == '\u1234'
    assert to_native(b'\xe5\xbc\xa0\xe4\xb8\x89') == '\xe5\xbc\xa0\xe4\xb8\x89'
    assert to_native(5) == '5'
    assert to_native(True) == 'True'
    assert to_native(False) == 'False'
    assert to_native(None) == ''

    # ensure string subclasses are handled correctly
    class MyStr(str):
        pass

    my_string = MyStr('\u1234')
    assert to_native(my_string) == '\u1234'

    class MyUnicode(str):
        pass


# Generated at 2022-06-11 01:33:44.021070
# Unit test for function to_native
def test_to_native():
    assert to_native(b'abc', errors='surrogate_or_strict') == 'abc'
    assert to_native(b'abc', errors='surrogate_or_replace') == 'abc'
    assert to_native(b'abc', errors='surrogate_then_replace') == 'abc'
    assert to_native(b'\xf1\xf2\xf3', encoding='latin-1') == '\xf1\xf2\xf3'
    assert to_native(b'\xf1\xf2\xf3', encoding='ascii', errors='surrogate_or_strict') == '\xf1\xf2\xf3'

# Generated at 2022-06-11 01:33:55.328921
# Unit test for function to_native
def test_to_native():
    for obj in (3, (3, ), {'foo': 'bar'}, datetime.datetime.now()):
        result = to_native(obj)
        assert result == str(obj)

    for obj in (b'a string', b'\xe4\xf6\xfc', u'a string', u'\xe4\xf6\xfc'):
        result = to_native(obj)
        assert result == str(obj)

    # We should not have any errors
    result = to_native(b'\xe4\xf6\xfc', errors='strict')
    assert result == u'\xe4\xf6\xfc'

    result = to_native(b'\xe4\xf6\xfc', errors='ignore')
    assert result == u'\xf6\xfc'

    result

# Generated at 2022-06-11 01:34:06.229168
# Unit test for function to_bytes
def test_to_bytes():
    # Test passing in nonstrings
    # Test with nonstring='simplerepr' and nonstring='passthru'
    assert to_bytes(1) == '1'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(b'foo', nonstring='passthru') == b'foo'
    assert to_bytes(u'foo', nonstring='passthru') == u'foo'
    # Test with nonstring='empty'
    assert to_bytes(1, nonstring='empty') == b''
    assert to_bytes(b'foo', nonstring='empty') == b''

# Generated at 2022-06-11 01:34:09.031292
# Unit test for function to_native
def test_to_native():
  x = {'1': 'a'}
  print(json.dumps(x))
  assert json.dumps(x) == '{"1": "a"}'

test_to_native()

# Generated at 2022-06-11 01:34:12.601080
# Unit test for function jsonify
def test_jsonify():
    data = jsonify(dict(name='foo', value=42))
    assert data == '{"name": "foo", "value": 42}'
    data = jsonify(dict(name='foo', value=Set([1, 2, 3])))
    assert data == '{"name": "foo", "value": [1, 2, 3]}'


# Generated at 2022-06-11 01:34:17.210467
# Unit test for function jsonify
def test_jsonify():
    json_obj = json.loads(jsonify([to_bytes("Iñtërnâtiônàlizætiøn")]))
    assert json_obj == [u'Iñtërnâtiônàlizætiøn']



# Generated at 2022-06-11 01:34:28.318918
# Unit test for function to_native
def test_to_native():
    if PY3:
        assert to_native(u'unicode') == u'unicode'
        assert to_native('bytes') == 'bytes'
        assert to_native(u'bytes'.encode('utf-8')) == 'bytes'
        assert to_native(b'bytes') == 'bytes'
        assert type(to_native(u'unicode')) is str
    else:
        assert to_native(u'unicode') == u'unicode'
        assert to_native('bytes') == b'bytes'
        assert to_native(u'bytes'.encode('utf-8')) == b'bytes'
        assert to_native(b'bytes') == b'bytes'
        assert type(to_native(u'unicode')) is unicode



# Generated at 2022-06-11 01:34:45.514561
# Unit test for function jsonify
def test_jsonify():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import builtins
    from _ast import Call
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_text
    import datetime
    import json
    # Test the case of a utf-8 encoded string
    utf8_encoded_string = 'Ivan Krsti\xc4\x87'
    assert utf8_encoded_string == json.loads(jsonify(utf8_encoded_string))
    # Test the case of an iso

# Generated at 2022-06-11 01:34:55.787489
# Unit test for function to_native
def test_to_native():
    assert to_native('test') == u'test'
    assert to_native(u'test') == u'test'
    assert to_native(b'test') == u'test'
    assert to_native(b'test'.decode('utf-8')) == u'test'
    assert to_native(b'test'.decode('utf-8').encode('utf-8')) == u'test'
    assert to_native(b'\xc3\xbc') == u'\xfc'
    assert to_native(b'\xc3\xbc'.decode('utf-8')) == u'\xfc'
    assert to_native(b'\xc3\xbc'.decode('utf-8').encode('utf-8')) == u'\xfc'

# Generated at 2022-06-11 01:35:06.633825
# Unit test for function to_native
def test_to_native():
    assert to_native(None) is None
    assert to_native(5) == 5
    assert isinstance(to_native(5), int)
    assert to_native('test') == u'test'
    assert isinstance(to_native('test'), text_type)
    assert to_native(u'test') == u'test'
    assert isinstance(to_native(u'test'), text_type)
    assert to_native(b'test') == u'test'
    assert isinstance(to_native(b'test'), text_type)
    assert to_native(b'\xc3\xa9') == u'\xe9'
    assert isinstance(to_native(b'\xc3\xa9'), text_type)

# Generated at 2022-06-11 01:35:11.481253
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.pycompat24 import get_exception
    import sys

    # capture output from jsonify
    saved_stdout = sys.stdout
    saved_stderr = sys.stderr
    sys.stdout = mystdout = StringIO()
    sys.stderr = mystderr = StringIO()
    # Create a data dict

# Generated at 2022-06-11 01:35:21.507807
# Unit test for function to_native
def test_to_native():
    s = 'test'
    assert to_native(s) == s
    assert to_native(1) == '1'
    assert to_native(None) == 'None'
    assert to_native(u'\u0123') == '\u0123'

    assert to_native(s, errors='surrogate_or_strict') == s
    assert to_native(1, errors='surrogate_or_strict') == '1'
    assert to_native(None, errors='surrogate_or_strict') == 'None'
    assert to_native(u'\u0123', errors='surrogate_or_strict') == '\u0123'
    assert to_native(u'\udcba', errors='surrogate_or_strict') == '\udcba'



# Generated at 2022-06-11 01:35:31.490385
# Unit test for function jsonify
def test_jsonify():
    data = {u'a': u'value', u'b': {u'inner': u'value'}}
    assert jsonify(data) == json.dumps(data, default=_json_encode_fallback)

    data = {
        u'a': u'value',
        u'b': u'\xe9',
        u'c': {u'inner': u'\xe9'},
        u'd': [u'\xe9', {u'another': u'\xe9'}]
    }
    assert jsonify(data) == json.dumps(data, default=_json_encode_fallback)



# Generated at 2022-06-11 01:35:36.616604
# Unit test for function jsonify
def test_jsonify():
    import ansible.module_utils
    ansible.module_utils._json_compat = None
    try:
        jsonify(r"\xc3\xbc\xc3\xbc")
    except TypeError as e:
        assert type(e.message) == type('')
    ansible.module_utils._json_compat = None



# Generated at 2022-06-11 01:35:43.919791
# Unit test for function jsonify
def test_jsonify():
    def _check_encoding(obj, encoding_name):
        try:
            obj.encode(encoding_name)
            return True
        except (UnicodeEncodeError):
            return False

    class Foo(object):
        pass

    foo = Foo()
    foo.foo = u'bar'
    foo.bar = b'baz'
    foo.baz = {u'unicode': u'thing', u'bytes': b'other thing'}
    foo.foobar = {u'unicode': {u'unicode': u'thing', u'bytes': b'other thing'}, u'bytes': {u'unicode': u'thing', u'bytes': b'other thing'}}
    foo.foobaz = [u'unicode', b'bytes', Foo()]
    foo.barfoo = u

# Generated at 2022-06-11 01:35:48.101538
# Unit test for function to_bytes
def test_to_bytes():
    # FIXME: Add unit tests for the different errors
    # FIXME: Add unit tests for the nonstring parameter
    pass


# TODO: Replace with an OrderedDict
# OrderedDict is new to 2.7.  We're using 2.6 so can't use it.

# Generated at 2022-06-11 01:35:58.571348
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('a') == b'a'
    assert to_bytes('a', nonstring='strict') == b'a'
    assert to_bytes(b'a') == b'a'
    assert to_bytes(b'\xff', nonstring='strict') == b'\xff'
    assert to_bytes(1, nonstring='simplerepr') == to_bytes('1')
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='empty') == b''
    assert to_bytes(1, nonstring='strict') == to_bytes('1')
    assert to_bytes(2.0, encoding='utf-16', errors='replace') == b'\xff\xfd\x00\x00'

# Generated at 2022-06-11 01:36:11.033090
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo': 'bar', 'baz': [1, 2, 3]}) == '{"baz": [1, 2, 3], "foo": "bar"}'
    assert jsonify({'foo': b'bar', 'baz': [1, 2, 3]}) == '{"baz": [1, 2, 3], "foo": "bar"}'
    assert jsonify({'foo': u'bar', 'baz': [1, 2, 3]}) == '{"baz": [1, 2, 3], "foo": "bar"}'
    assert jsonify({'foo': u'bar', 'baz': [1, 2, 3], u'qux': u'quux'}) == '{"baz": [1, 2, 3], "foo": "bar", "qux": "quux"}'

# Generated at 2022-06-11 01:36:21.518448
# Unit test for function to_native
def test_to_native():
    """
    This function tests when you pass a string object to the to_native function
    and expect it to return a string object.
    """
    assert isinstance(to_native('foo'),str)
    """
    This function tests when you pass an int object to the to_native function
    and expect it to return a int object.
    """
    assert isinstance(to_native(1),int)
    """
    This function tests when you pass an array object to the to_native function
    and expect it to return a array object.
    """
    assert isinstance(to_native(['foo','bar']),list)
    """
    This function tests when you pass an dict object to the to_native function
    and expect it to return a dict object.
    """

# Generated at 2022-06-11 01:36:31.449001
# Unit test for function jsonify
def test_jsonify():
    # Test the errors in the function
    test_string = u'test\u0000'
    # this is deliberately set to a value that will raise a "UnicodeDecodeError" in the function
    # and thereby test the error handling in json.dumps
    try:
        jsonify(test_string)
    except UnicodeDecodeError:
        assert True
    else:
        assert False
    # Set the encoding to utf-8
    orig_encoding = getattr(sys.stdin, 'encoding', None)
    sys.stdin.encoding = 'utf-8'
    test_string = u'test\u0000'
    result = jsonify(test_string)
    # Expected output is test\u0000
    assert result == u'"test\u0000"'
    # Restore the encoding
    sys.stdin

# Generated at 2022-06-11 01:36:40.820138
# Unit test for function jsonify
def test_jsonify():
    '''
    run python -m ansible.module_utils.basic test_jsonify
    :return:
    '''
    from ansible.module_utils.six import PY3
    if PY3:
        from ansible.module_utils.six.moves.urllib.parse import parse_qs
    else:
        from urlparse import parse_qs
    from ansible.module_utils.six.moves.urllib.parse import parse_qsl
    import json
    import random
    import string

    def random_str():
        return ''.join(random.choice(string.ascii_letters) for i in range(random.randint(1, 16)))

    def random_dict(depth):
        if depth == 0:
            if random.choice([True, False]):
                return random_

# Generated at 2022-06-11 01:36:51.652593
# Unit test for function jsonify
def test_jsonify():
    data = {
        'string': u'\u1234',
        'list': [u'\u1234', 123,u'\u1234',u'\u1234'],
        'dict': {'key1': u'\u1234','key2': u'\u1234','key3': u'\u1234'},
        'int': 123
    }
    assert jsonify(data) == '{"list": ["\\u1234", 123, "\\u1234", "\\u1234"], "string": "\\u1234", "int": 123, "dict": {"key3": "\\u1234", "key2": "\\u1234", "key1": "\\u1234"}}'


# Generated at 2022-06-11 01:37:00.658380
# Unit test for function jsonify
def test_jsonify():
    data = {
        u'k1': u'value1',
        u'k2': [u'v2', u'v3']
    }
    assert(jsonify(data) == '{"k1": "value1", "k2": ["v2", "v3"]}')
    data = {
        b'k1': b'value1',
        b'k2': [b'v2', b'v3']
    }
    assert(jsonify(data) == '{"k1": "value1", "k2": ["v2", "v3"]}')
    data = {
        b'k1': u'value1',
        b'k2': [u'v2', u'v3']
    }

# Generated at 2022-06-11 01:37:04.316271
# Unit test for function jsonify
def test_jsonify():
    ansi_color = "\\x1b[0;31;49m" + "foo" + "\\x1b[0m"
    assert ansi_color == container_to_text(ansi_color)



# Generated at 2022-06-11 01:37:07.165643
# Unit test for function jsonify
def test_jsonify():
    for encoding in ("utf-8", "latin-1"):
        assert jsonify({"test": "test_jsonify_data"})



# Generated at 2022-06-11 01:37:14.086162
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == u'foo'
    assert to_native(u'foo') == u'foo'
    assert to_native(dict(foo='bar')) == "{'foo': 'bar'}"
    assert to_native(u'\u4321') == u'\u4321'
    assert to_native(u'\u4321'.encode('utf-16')) == u'\u4321'
    assert to_native(b'\xff') == u'\ufffd'
    assert to_native(b'\xff'.decode('latin-1')) == u'\ufffd'
    assert to_native(b'\xff'.decode('latin-1').encode('utf-16')) == u'\ufffd'
    if PY3:
        assert to

# Generated at 2022-06-11 01:37:20.289936
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'中文') == b'\xe4\xb8\xad\xe6\x96\x87'
    assert to_bytes(b'\xe4\xb8\xad\xe6\x96\x87') == b'\xe4\xb8\xad\xe6\x96\x87'
    assert to_bytes(3) == b'3'
    assert to_bytes(3, nonstring='passthru') == 3
    assert to_bytes(3, nonstring='empty') == b''
    assert to_bytes(3, nonstring='strict') == b'3'



# Generated at 2022-06-11 01:37:41.374115
# Unit test for function to_bytes
def test_to_bytes():
    """Test conversion to a binary string"""

    # Test passing through binary strings
    assert b'foo' == to_bytes(b'foo')
    assert not isinstance(to_bytes(b'foo'), text_type)

    # Test passing through text string with ascii content
    assert b'foo' == to_bytes('foo')
    assert not isinstance(to_bytes('foo'), text_type)

    # Test passing through text string with utf-8 content
    assert b'\xc3\xa9' == to_bytes('\xc3\xa9')
    assert not isinstance(to_bytes('\xc3\xa9'), text_type)

    # Test invalid bytes with a surrogateescape error handler

# Generated at 2022-06-11 01:37:43.643495
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': u'\u2713'}) == '{"a": "\\u2713"}'


# Generated at 2022-06-11 01:37:50.513633
# Unit test for function to_bytes
def test_to_bytes():
    # Check with simple strings
    sample_text = '\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_bytes(sample_text, 'utf-8') == \
            b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82'
    # Check with multibyte characters
    sample_text = '\u062c\u0647\u062a\u0627 \u062c\u0647\u062a\u0627'

# Generated at 2022-06-11 01:38:01.954159
# Unit test for function to_native
def test_to_native():
    # Tests are only needed for Python2 as in Python3 all strings are unicode
    if PY3:
        return
    # Test that it's not already unicode and becomes unicode
    assert isinstance(to_native('ascii'), unicode)
    # Test that it's already unicode and remains unicode
    assert isinstance(to_native(u'ascii'), unicode)
    # Test that bytes get converted to unicode
    assert to_native(b'ascii') == u'ascii'
    # Test that non-strings get converted to unicode
    assert to_native(1) == '1'
    # Test that it does not convert ints to bytes
    assert not isinstance(to_native(1), str)
    # Test that it does not convert ints to bytes

# Generated at 2022-06-11 01:38:10.351474
# Unit test for function jsonify
def test_jsonify():
    # simple test
    old_data = dict(a=u'hello', b=dict(c=[1, 2, 3]))
    new_data = dict(a='hello', b=dict(c=[1, 2, 3]))
    assert jsonify(old_data) == jsonify(new_data)

    # test with unicode aware containers
    from ansible.module_utils.common._collections_compat import Mapping
    old_data = dict(a=u'hello', b=dict(c=Set([u'a', u'b']), d=Mapping({u'a': 1, u'b': 2})))
    new_data = dict(a='hello', b=dict(c=['a', 'b'], d={'a': 1, 'b': 2}))

# Generated at 2022-06-11 01:38:11.737265
# Unit test for function jsonify
def test_jsonify():
    jsonify({1: to_bytes("\xe9")})


# Generated at 2022-06-11 01:38:19.589649
# Unit test for function to_bytes
def test_to_bytes():
    """
    to_bytes unit test

    :returns: bool -- True if all tests for this function pass and False if at
        least one test fails.
    """
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Test if surrogateescapes are allowed
    if not hasattr(codecs, 'lookup_error'):
        # codecs.lookup_error isn't present in Python2
        # so these tests shouldn't be run in Python2
        return True

    try:
        codecs.lookup_error('surrogateescape')
        surrogateescape_is_available = True
    except LookupError:
        surrogateescape_is_available = False

    basic._ANSIBLE_ARGS = None  # pylint: disable=protected-access
    module = basic

# Generated at 2022-06-11 01:38:26.187271
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=u'\uc4d0')) == '{"a": "\\uc4d0"}'
    assert jsonify(dict(a=u'\uc4d0'), ensure_ascii=False) == '{"a": "쓐"}'
    assert jsonify(dict(a=[u'\uc4d0'])) == '{"a": ["\\uc4d0"]}'
    assert jsonify(dict(a=[u'\uc4d0']), ensure_ascii=False) == '{"a": ["쓐"]}'


# Generated at 2022-06-11 01:38:37.631163
# Unit test for function to_native
def test_to_native():
    assert to_native(1, normalize=False) == 1
    assert to_native(1, normalize=True) == "1"
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native('foo') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == u'foo'
    assert to_native(u'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(u'foo', errors='surrogate_or_replace') == u'foo'

# Generated at 2022-06-11 01:38:39.254542
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'



# Generated at 2022-06-11 01:38:52.693901
# Unit test for function jsonify
def test_jsonify():
    my_dict = {'aaa': u'bbb', 'ccc': [u'ddd', u'eee']}
    print(jsonify(my_dict))
test_jsonify()



# Generated at 2022-06-11 01:38:54.238490
# Unit test for function jsonify
def test_jsonify():
    assert 'true' in jsonify({'foo':True})


# Generated at 2022-06-11 01:39:05.285895
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.six import StringIO
    raise_unraisable_exception = False

    class FakeFile(StringIO):
        def close(self):
            if raise_unraisable_exception:
                raise Exception('This exception should never be raised')

    def fake_dump(data, fp, encoding=None, **kwargs):
        assert isinstance(fp, FakeFile)

    # Test non-ascii data
    nonascii = u'\u2013'
    data = {u'key': nonascii}
    assert jsonify(data) == u'{"key": "\u2013"}'
    # Test complex data
    data = {"key": [{"key": nonascii}]}
    assert jsonify(data) == u'{"key": [{"key": "\u2013"}]}'

# Generated at 2022-06-11 01:39:13.917501
# Unit test for function to_native
def test_to_native():

    # Python 2 should return a byte string
    to_native(u'text')

    # Python 2 should return a byte string
    to_native(u'text'.encode('utf-8'))

    # Binaries should return a byte string
    to_native(b'text')

    # Nonstrings should return a byte string
    to_native(5)

    # Lists should return a byte string
    to_native([1, 2])

    # Datetime should return a byte string
    to_native(datetime.date(2014, 1, 15))



# Generated at 2022-06-11 01:39:24.590484
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'{"a": "b"}') == '{"a": "b"}'
    assert jsonify(u'{"a": "b"}'.encode('utf-16')) == '{"a": "b"}'
    assert jsonify(u'{"a": "b"}'.encode('utf-32')) == '{"a": "b"}'
    assert jsonify(u'{"a": "b"}'.encode('latin-1')) == '{"a": "b"}'
    assert jsonify(u'{"a": "b"}'.encode('latin-1').decode('utf-8')) == '{"a": "b"}'

# Generated at 2022-06-11 01:39:33.549254
# Unit test for function to_native
def test_to_native():
    assert to_native(1, 'ascii') == b'1'
    assert to_native(1, 'ascii', nonstring='empty') == b''
    assert to_native(1, 'ascii', nonstring='passthru') == 1
    assert to_native(u'\xe9', 'ascii') == b''
    assert to_native(u'\xe9', 'ascii', errors='surrogate_then_replace') == b''
    assert to_native(b'\xe9', 'ascii', errors='surrogate_then_replace') == b'\xe9'

