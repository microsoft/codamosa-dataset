

# Generated at 2022-06-11 01:29:59.928224
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_text, to_bytes

    if PY3:
        unicode_string = 'ünicödé'
        byte_string = unicode_string.encode('utf-8')
        surrogate_string = '\ud83e\uddf4'
        surrogate_bytes = surrogate_string.encode('utf-8')
        surrogate_nonascii_string = 'ü\ud83e\uddf4dé'
        surrogate_nonascii_bytes = surrogate_nonascii_string.encode('utf-8')

        # In Python3 using str(obj) or repr(obj) and then calling
        # to_native(obj) will not raise a traceback but will return a
        # byte string

# Generated at 2022-06-11 01:30:11.188106
# Unit test for function to_bytes
def test_to_bytes():
    from six import u
    from ansible.module_utils import basic

    string_types = (u(''), u('hello'), u('\u043f\u0440\u0438\u0432\u0435\u0442'))
    for string_type in string_types:
        for encoding in ('utf-8', 'latin-1'):
            for nonstring in ('simplerepr', 'empty', 'strict'):
                for errors in ('strict', 'ignore', 'replace', 'surrogateescape', 'xmlcharrefreplace'):
                    if PY3 and errors == 'surrogateescape':
                        continue
                    if PY3 and errors == 'xmlcharrefreplace':
                        continue

# Generated at 2022-06-11 01:30:13.606326
# Unit test for function jsonify
def test_jsonify():
    json.dumps({'a': '\xe9'})
    json.dumps({'a': '\xe9'.decode("latin-1")})



# Generated at 2022-06-11 01:30:24.049592
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'Κόσμε') == b'\xce\x9a\xe1\xbd\xb9\xcf\x83\xce\xbc\xce\xb5'
    assert to_bytes(u'привет') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    assert to_bytes(u'مرحبا') == b'\xd9\x85\xd8\xb1\xd8\xad\xd8\xa8\xd8\xa7'

# Generated at 2022-06-11 01:30:34.430442
# Unit test for function to_native
def test_to_native():

    # Test basic functions
    assert to_native(None) == u'None'
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'

    # Test non-string conversions
    assert to_native(42) == u'42'
    assert to_native(42.3) == u'42.3'

    # Test non-string parameter
    assert to_native({u'foo': u'bar'}) == u"{u'foo': u'bar'}"



# Generated at 2022-06-11 01:30:45.719945
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.six import u
    import sys
    import types
    import random

    # Python3 and Python2 disagree about surrogates in byte strings
    if PY3:
        surrogates_are_encoded = True
    else:
        surrogates_are_encoded = False

    try:
        u'\udc80'.encode('ascii')
        # If we didn't get an exception, then surrogates are allowed in byte
        # strings which is a violation of Python3's rules.  We can't use the
        # surrogateescape error handler if this is the case.  We'll skip related
        # tests.
        surrogates_allowed = True
    except UnicodeEncodeError:
        surrogates_allowed = False

    assert to_bytes(b'dog') == b'dog'
    assert to_bytes

# Generated at 2022-06-11 01:30:51.025934
# Unit test for function jsonify
def test_jsonify():
    data = {
        'bool': True,
        'int': 12345,
        'float': 12.345,
        'array': [b'abc', 'def', bytearray(b'hgi')],
        'dict': {"key1": "val1", "key2": b"val2", "key3": bytearray(b"val3")},
        'complex': {
            'bool': True,
            'int': 12345,
            'float': 12.345,
            'array': [b'abc', 'def', bytearray(b'hgi')],
            'dict': {
                'key1': "val1",
                'key2': b"val2",
                'key3': bytearray(b"val3")
                }
            }
        }

# Generated at 2022-06-11 01:30:57.894297
# Unit test for function to_native
def test_to_native():
    for u in [
        u'abc',
    ]:
        for encoding in ['utf-8', 'utf-16', 'latin-1']:
            for errors in ['strict', 'replace', 'surrogateescape']:
                try:
                    b = u.encode(encoding, errors)
                except LookupError:
                    # codec not available
                    continue
                assert to_native(u, encoding=encoding, errors=errors) == b.decode(encoding, errors)



# Generated at 2022-06-11 01:31:07.453248
# Unit test for function to_bytes
def test_to_bytes():

    # single string
    assert to_bytes('hi') == b"hi"
    assert to_bytes('hi', encoding='ascii') == b"hi"
    assert to_bytes('hi', encoding='ascii', errors='surrogate_or_replace') == b"hi"
    assert to_bytes(u'hi') == b"hi"
    assert to_bytes(u'hi', encoding='ascii') == b"hi"
    assert to_bytes(u'hi', encoding='ascii', errors='surrogate_or_replace') == b"hi"
    assert to_bytes(b'hi') == b"hi"
    assert to_bytes(b'hi', encoding='ascii') == b"hi"

# Generated at 2022-06-11 01:31:19.275537
# Unit test for function to_native
def test_to_native():
    assert to_native(u'some string', encoding='ascii') == 'some string'
    assert to_native(b'some bytes', encoding='ascii') == 'some bytes'
    assert to_native(u'some string', encoding='ascii', nonstring='simplerepr') == 'some string'
    assert to_native(b'some bytes', encoding='ascii', nonstring='simplerepr') == 'some bytes'

    # We're testing for equivalency, so we may need to compare native strings to unicode strings
    if PY3:
        # Python3 expects strings to be unicode
        assert u'some string' == to_native(u'some string')
        assert u'some bytes' == to_native(b'some bytes')

# Generated at 2022-06-11 01:31:31.155536
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(b'\xe9') == '"\u00e9"'
    assert jsonify(u'\xe9') == '"\u00e9"'



# Generated at 2022-06-11 01:31:33.731468
# Unit test for function jsonify
def test_jsonify():

    class JSONEncoder(json.JSONEncoder):
        def default(self, obj):
            if isinstance(obj, binary_type):
                return 'TEST_VALUE'
    obj = binary_type('test')
    data = jsonify(obj)
    assert obj == json.loads(data, cls=JSONEncoder)


# Generated at 2022-06-11 01:31:45.813141
# Unit test for function jsonify
def test_jsonify():
    a = {'a':u'\xe9', 'b':'\xe9'}
    expected_a = r'{"a": "\u00e9", "b": "\u00e9"}'
    assert jsonify(a) == expected_a

    b = {'b':10, 'a':"\xe9"}
    expected_b = r'{"b": 10, "a": "\u00e9"}'
    assert jsonify(b) == expected_b

    c = {'a': u'\u2282\u0391'}
    expected_c = r'{"a": "\u2282\u0391"}'
    assert jsonify(c) == expected_c

    d = {'a':u'\xe9', 'b':"\xe9"}

# Generated at 2022-06-11 01:31:54.074597
# Unit test for function jsonify
def test_jsonify():
    assert u'"apple"'.encode('utf-8') == jsonify(u"apple")
    assert json.loads(jsonify({"a": u"apple"})) == {"a": "apple"}
    assert json.loads(jsonify({"a": u"\u2713"})) == {"a": "\u2713"}
    assert json.loads(jsonify({"a": u"\xae"})) == {"a": "\xae"}
    assert json.loads(jsonify({"a": to_text(u"\xae")})) == {"a": "\xae"}
    assert json.loads(jsonify({"a": data_dict})) == {"a": data_dict}
    assert True



# Generated at 2022-06-11 01:32:05.273130
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils.basic import bytes_to_native, native_to_bytes
    for test_str in ['test', b'test', u'test', '\xc3\xa9', b'\xc3\xa9', u'\u00e9', True, False, None, 1, {'a': 1}, [1], 1.23]:
        assert test_str == native_to_bytes(bytes_to_native(test_str))

    # Fallback to using repr() if to_text/from_text raises an exception
    assert "1 + 2" == bytes_to_native(1 + 2)
    # nonstring=passthru
    assert 1 == bytes_to_native(1, nonstring='passthru')
    # nonstring=empty

# Generated at 2022-06-11 01:32:12.999731
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('foo') == '"foo"'
    assert jsonify('foo'.encode('utf-16')) == '"foo"'
    assert jsonify(u'foo') == '"foo"'
    assert jsonify(u'\u20ac') == '"\\u20ac"'

    assert jsonify(b'\xe2\x20ac') == '"\\u20ac"'

    assert jsonify(Set([1, 2, 3])) == '[1, 2, 3]'


# Generated at 2022-06-11 01:32:17.902952
# Unit test for function jsonify
def test_jsonify():
    data = {'1': 'a1', '2': u'd\xe9'}
    assert jsonify(data) == '{"1": "a1", "2": "d\\\\u00e9"}'
    assert jsonify(data, ensure_ascii=False) == '{"1": "a1", "2": "dé"}'



# Generated at 2022-06-11 01:32:29.534182
# Unit test for function to_bytes
def test_to_bytes():
    # function to_bytes
    # b"String"
    assert to_bytes('String') == b'String'
    assert to_bytes(b'String') == b'String'
    # b"String"
    assert to_bytes(u'String') == b'String'
    assert to_bytes(u'String'.encode('utf-16'), 'utf-16') == b'String'
    # b'No unicode string in here'
    assert to_bytes(u'No unicode string in here'.encode('utf-16'), 'utf-16') == b'No unicode string in here'
    # b'\xe1\x88\xb4'
    assert to_bytes('ሴ') == b'\xe1\x88\xb4'
    # b'\xe1\x88\xb4'


# Generated at 2022-06-11 01:32:38.965418
# Unit test for function jsonify
def test_jsonify():
    # Test normal jsonify
    result = jsonify({'a': ['b', {'c': 'd'}, [1, 2, 3], True, None]})
    assert result == '{"a": ["b", {"c": "d"}, [1, 2, 3], true, null]}'
    # Test jsonify with encoding=latin-1
    result = jsonify({'a': ['b', {'c': 'd'}, [1, 2, 3], True, None]}, ensure_ascii=False)
    assert result == '{"a": ["b", {"c": "d"}, [1, 2, 3], true, null]}'
    # Test jsonify with unicode
    result = jsonify({u'a': [u'b', {u'c': 'd'}, [1, 2, 3], True, None]})

# Generated at 2022-06-11 01:32:50.132381
# Unit test for function to_native
def test_to_native():
    # Python3 str/bytes
    assert to_native(b'foo') == 'foo'
    assert to_native('foo') == 'foo'

    # Python2 unicode/str
    assert to_native(u'foo') == 'foo'
    assert to_native('foo') == 'foo'

    # Fails without the right encoding
    try:
        to_native(b'\xe9')
        assert False
    except UnicodeDecodeError:
        pass

    # Works with the right encoding
    assert to_native(b'\xe9'.decode('latin1')) == u'\xe9'
    assert to_native(b'\xe9', encoding='latin1') == u'\xe9'

    # Handles surrogate escapes

# Generated at 2022-06-11 01:32:59.988729
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=u'\u2603')) == u'{"a": "\\u2603"}'



# Generated at 2022-06-11 01:33:12.043905
# Unit test for function to_native
def test_to_native():
    b1 = to_bytes(b'hello world')
    assert isinstance(b1, binary_type)
    b2 = to_bytes(u'hello world')
    assert isinstance(b2, binary_type)
    assert b1 == b2

    b1 = to_bytes(b'\n')
    assert isinstance(b1, binary_type)
    b2 = to_bytes(u'\n')
    assert isinstance(b2, binary_type)
    assert b1 == b2


    if PY3:
        b1 = to_bytes(u'\udcff')
        assert isinstance(b1, binary_type)
        # We can't test the contents of the bytestring because the surrogate
        # escape error handler isn't available yet in all python versions.
        # b2 = to

# Generated at 2022-06-11 01:33:21.557145
# Unit test for function jsonify
def test_jsonify():
    value1 = {'a': 'hello',
              'b': u'world',
              'c': [1, 2, 3]}
    value2 = {u'a': 'hello',
              u'b': 'world',
              u'c': [1, 2, 3]}
    value3 = {'a': 'hello',
              'b': 'world',
              'c': [1, 2, 3]}
    value4 = {u'a': u'hello',
              u'b': u'world',
              u'c': [1, 2, 3]}
    value5 = {u'a': 'hello',
              u'b': u'world',
              u'c': [1, 2, 3]}

# Generated at 2022-06-11 01:33:32.964863
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('test') == b'test'
    assert to_bytes(b'test') == b'test'
    assert to_bytes(u'test') == b'test'
    assert to_bytes(u'проверка') == b'\xd0\xbf\xd1\x80\xd0\xbe\xd0\xb2\xd0\xb5\xd1\x80\xd0\xba\xd0\xb0'
    assert to_bytes(u'\uFFFD') == b'?'
    assert to_bytes(u'\uFFFD'.encode('utf-16'), 'utf-16') == b'?'
    assert to_bytes(1) == b'1'
    assert to_bytes(None) == b'None'

# Generated at 2022-06-11 01:33:43.446388
# Unit test for function to_native
def test_to_native():
    import sys
    if PY3:
        assert to_native(b'\xc3\xa9', errors='strict') == 'é'
        assert to_native(b'\x80', errors='surrogateescape') == '\udc80'
        assert to_native(b'\xc3\xa9', errors='surrogateescape') == '\udcfd\udcdd'
        assert to_native(b'\xc3\x80', errors='replace') == '?'
        # this is the opposite of what you might expect: U+FFFD (REPLACEMENT CHARACTER)
        # is encoded as the byte 0xef 0xbf 0xbd in UTF-8, but surrogateescape
        # replaces it with the surrogate \udcff-\udc00-\udcbd, which
        # becomes the

# Generated at 2022-06-11 01:33:54.611043
# Unit test for function to_bytes

# Generated at 2022-06-11 01:34:02.803297
# Unit test for function jsonify
def test_jsonify():
    u1 = u'\u2713'
    u2 = u'\u2714'

    data = {u'unicode': u1, u'bytes': u2.encode("utf-8")}
    assert jsonify(data) == '{"bytes": "\\u2714", "unicode": "\\u2713"}'

    data = {u'unicode': [u1], u'bytes': [u2.encode("utf-8")]}
    assert jsonify(data) == '{"bytes": ["\\u2714"], "unicode": ["\\u2713"]}'


# Generated at 2022-06-11 01:34:12.460742
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    assert to_bytes('【foo】', encoding='utf-8') == b'\xe3\x80\x90foo\xe3\x80\x91'
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', encoding='ASCII') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

# Generated at 2022-06-11 01:34:20.188933
# Unit test for function jsonify
def test_jsonify():
    assert isinstance(jsonify(text_type('foo')), str)
    assert isinstance(jsonify({'foo': u'bar'}), str)
    assert isinstance(jsonify({'foo': [u'bar']}), str)
    assert isinstance(jsonify({'foo': {u'bar': u'baz'}}), str)
    assert isinstance(jsonify({'foo': {u'bar': [u'baz']}}), str)



# Generated at 2022-06-11 01:34:30.990057
# Unit test for function to_native
def test_to_native():

    # test python version
    if PY3:
        assert to_native(u'test') == 'test'
        assert to_native(b'test') == 'test'
        assert to_native('test') == 'test'
        assert to_native(b'test', errors='surrogate_then_replace') == 'test'
        assert to_native(b'test', errors='surrogate_or_replace') == 'test'
        assert to_native(b'test', errors='surrogate_or_strict') == 'test'

        assert to_native(u't\udce4st') == 't\udce4st'
        assert to_native(b't\xed\xb5\xb4st') == 't\udce4st'

# Generated at 2022-06-11 01:34:49.483078
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'foo') == u'foo'

# Generated at 2022-06-11 01:34:58.728781
# Unit test for function to_native
def test_to_native():
    # to_native will return back the same value if it is a text string
    assert isinstance(to_native(u'test text'), text_type)

    assert u'\xe9' == to_native('\xc3\xa9')

    # If the encoding is None, we must be passed a text string.
    # If not, we just preserve the type of the input.
    assert to_native('\xc3\xa9') == '\xc3\xa9'

    if PY3:
        # Python3 native strings are text
        assert to_native('t\xc3\xa9st text') == 'tést text'
    else:
        # Python2 native strings are bytes
        assert to_native('t\xc3\xa9st text') == 't\xc3\xa9st text'

    assert to_

# Generated at 2022-06-11 01:35:10.339676
# Unit test for function to_native
def test_to_native():
    """
    Test for to_native function.
    """
    import os
    import sys
    if sys.version_info[0] >= 3:
        # Python 3.x
        # Testing bytes should return bytes
        assert to_native('\xc3\xa0') == '\xc3\xa0'
        # Testing unicode should return unicode
        assert to_native('\u00e0') == '\u00e0'
        # Testing str should return unicode
        assert to_native('føø') == 'føø'
        # Testing an integer should return the same integer
        assert to_native(1) == 1
        # Testing a float should return the same float
        assert to_native(1.1) == 1.1
        # Testing None should return None
        assert to_native(None) is None


# Generated at 2022-06-11 01:35:20.615547
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.compat.mock import Mock
    from ansible.module_utils.compat import UnsafeBytes, UnsafeText

    # Test encoding to bytes, raw python text
    assert b'raw bytes' == to_native(b'raw bytes')

    # Test decoding as bytes
    assert 'decoded bytes' == to_native(b'decoded bytes'.decode('utf-8'))

    # Test encoding to bytes, unicode object
    assert b'unicode object' == to_native(u'unicode object')

    # Test decoding to unicode object
    assert u'decoded unicode' == to_native(u'decoded unicode'.encode('utf-8'))

    # Test encoding as bytes

# Generated at 2022-06-11 01:35:32.655818
# Unit test for function jsonify
def test_jsonify():
    # Valid:
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, ensure_ascii=False) == '{"a": "b"}'
    assert isinstance(jsonify({'a': 'b'}), text_type)
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, separators=(',', ':')) == '{"a":"b"}'
    assert isinstance(jsonify({'a': 'b'}), text_type)
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'

# Generated at 2022-06-11 01:35:41.929642
# Unit test for function jsonify
def test_jsonify():
    for ansible_version in ('v2.4.0', 'v2.4.1', 'v2.4.2', 'v2.4.3'):
        if not __name__ == '__main__':
            break
        ansible_freezed_modules_path = '/tmp/ansible_%s/lib/ansible/modules' % ansible_version
        if not os.path.isdir(ansible_freezed_modules_path):
            continue
    if not ansible_freezed_modules_path:
        ansible_freezed_modules_path = '/usr/lib/python2.7/site-packages/ansible/modules'
        if not os.path.isdir(ansible_freezed_modules_path):
            raise Exception('Could not detect ansible module path')
    import sys
    sys

# Generated at 2022-06-11 01:35:51.602901
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('') == b''
    assert isinstance(to_bytes(''), binary_type)

    assert to_bytes('foo') == b'foo'
    assert isinstance(to_bytes('foo'), binary_type)

    assert to_bytes(b'foo') == b'foo'
    assert isinstance(to_bytes(b'foo'), binary_type)

    assert to_bytes(u'\u2019') == b'\xe2\x80\x99'
    assert isinstance(to_bytes(u'\u2019'), binary_type)

    assert to_bytes(u'\u2019', nonstring='passthru') == u'\u2019'
    assert isinstance(to_bytes(u'\u2019', nonstring='passthru'), text_type)


# Generated at 2022-06-11 01:36:02.053017
# Unit test for function to_native

# Generated at 2022-06-11 01:36:09.996189
# Unit test for function to_bytes
def test_to_bytes():
    assert '\xf8' == to_bytes(u'\xf8')
    assert to_bytes('\xf8') is '\xf8'  # Noop
    assert '\xf8' == to_bytes(u'\u00f8')
    assert u'\u00f8'.encode('utf-8', 'surrogateescape') == to_bytes(u'\u00f8', 'utf-8', 'surrogate_then_replace')
    assert 'x' == to_bytes(u'\u00f8', 'latin-1')
    assert str(bytearray([0xf8])) == str(to_bytes(bytearray([0xf8])))

    assert '' == to_bytes(None, nonstring='empty')

# Generated at 2022-06-11 01:36:16.293016
# Unit test for function to_native
def test_to_native():
    assert to_native(b"to_native", errors="surrogate_or_strict") == "to_native"


_NATIVE_UNICODE_TYPES = (text_type, type(None))
if PY3:
    _NATIVE_BYTE_TYPES = (bytes, type(None))
else:
    _NATIVE_BYTE_TYPES = (str, type(None))




# Generated at 2022-06-11 01:36:43.727707
# Unit test for function jsonify
def test_jsonify():
    import os, sys, shutil, tempfile, glob
    from os.path import join
    from lib.utils.callback_plugins import get_callback_plugin
    # 1. test with string
    data = {
        "name": "test_jsonify"
    }
    assert jsonify(data, indent=4)
    assert jsonify(data, sort_keys=True)
    assert jsonify(data, separators=(",", ":"))
    # 2. test with unicode
    data = {
        "name": u"测试jsonify"
    }
    assert jsonify(data)
    assert jsonify(data, indent=4)
    assert jsonify(data, sort_keys=True)
    assert jsonify(data, separators=(",", ":"))


# Generated at 2022-06-11 01:36:55.337009
# Unit test for function jsonify
def test_jsonify():
    json_str = jsonify({u'foo': u'bar', u'baz': 42, u'blong': [1, 2, 3, 4]})
    assert json_str == '{"foo": "bar", "blong": [1, 2, 3, 4], "baz": 42}'
    json_str = jsonify({u'foo': u'bar', u'baz': 42, u'blong': [1, 2, 3, 4]})
    assert json_str == '{"foo": "bar", "blong": [1, 2, 3, 4], "baz": 42}'
    json_str = jsonify({u'foo': u'bar', u'baz': 42, u'blong': [1, 2, 3, 4]})

# Generated at 2022-06-11 01:37:04.316793
# Unit test for function to_native
def test_to_native():
    assert to_native(b'test') == 'test'
    assert to_native(b'test', errors='surrogate_or_strict') == 'test'
    assert to_native(b'test', errors='surrogate_or_replace') == 'test'
    assert to_native(b'test', errors='surrogate_then_replace') == 'test'
    assert to_native(u'test') == u'test'
    assert to_native(u'test', errors='surrogate_or_strict') == u'test'
    assert to_native(u'test', errors='surrogate_or_replace') == u'test'
    assert to_native(u'test', errors='surrogate_then_replace') == u'test'
    assert to_native(u'\udcff')

# Generated at 2022-06-11 01:37:11.534504
# Unit test for function jsonify
def test_jsonify():
    data = {'a': '\xe4\xb8\xad\xe6\x96\x87'}
    assert to_native(jsonify(data)) == r'{"a": "\u4e2d\u6587"}'
    data = {'a': u'\u5e73\u621011'}
    assert to_native(jsonify(data)) == r'{"a": "\u5e73\u621011"}'



# Generated at 2022-06-11 01:37:19.951876
# Unit test for function to_native
def test_to_native():
    if PY3:
        assert to_native(b'bytes') == 'bytes'
        assert to_native('text') == 'text'
        assert to_native(u'unicode') == 'unicode'
        assert to_native(b'\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e') == '\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e'
    else:
        assert to_native(b'bytes') == b'bytes'
        assert to_native('text') == b'text'
        assert to_native(u'unicode') == b'unicode'

# Generated at 2022-06-11 01:37:31.565470
# Unit test for function to_bytes
def test_to_bytes():
    # with unicode
    assert to_bytes(text_type('foo'), errors='strict') == b'foo'
    assert to_bytes(text_type('foo')) == b'foo'
    assert to_bytes(text_type('føø'), encoding='ascii', errors='strict') == b'f\xc3\xb8\xc3\xb8'
    assert to_bytes(text_type('føø')) == b'f\xc3\xb8\xc3\xb8'

    # with byte string
    assert to_bytes(binary_type('foo'), errors='strict') == b'foo'
    assert to_bytes(binary_type('foo')) == b'foo'
    assert to_bytes(binary_type('føø'), encoding='ascii', errors='strict') == b

# Generated at 2022-06-11 01:37:41.950308
# Unit test for function to_native
def test_to_native():
    '''
    Unit test that ensures that to_native works
    '''
    from ansible.module_utils._text import to_native

    # Ensure that to_native with a text string returns a text string
    assert isinstance(to_native('foo'), text_type)

    # Ensure that to_native with a byte string returns a text string
    assert isinstance(to_native(b'foo'), text_type)

    # FIXME: This test currently fails in Python3
    # https://github.com/ansible/ansible/issues/26379
    #
    # Ensure that to_native with a nonstring returns a text string
    # assert isinstance(to_native(dict(a=1)), text_type)

    # Ensure that to_native with a nonstring returns a text string when a nonstring type is passed in
    assert to

# Generated at 2022-06-11 01:37:49.783366
# Unit test for function to_bytes
def test_to_bytes():
    # The parameter is a text string and we expect a byte string
    assert isinstance(to_bytes(u'foo'), binary_type)
    assert not isinstance(to_bytes(u'foo'), text_type)

    # We return an empty byte string if we're given one
    assert to_bytes(b'') == b''

    # Return the object if nonstring is passthru
    class Foo(object):
        pass
    assert to_bytes(Foo(), nonstring='passthru') is Foo()

    # Return the empty string if nonstring is empty
    assert to_bytes(Foo(), nonstring='empty') == b''

    # If given an object that is not a string and nonstring is strict, fail
    #TypeError: obj must be a string type

# Generated at 2022-06-11 01:38:01.338084
# Unit test for function jsonify
def test_jsonify():
    import unittest
    import sys
    class JsonifyTestCase(unittest.TestCase):
        def test_jsonify_decode_error(self):
            '''jsonify should work with invalid unicode characters'''
            testData = u"\u6655\u6655\u6655"
            if PY3:
                testData = testData.encode('utf-8')
            else:
                testData = testData.encode('latin-1')
            with self.assertRaises(UnicodeError):
                jsonify(testData)

        def test_jsonify_encode_error(self):
            '''jsonify should work with object which json cannot serialize'''
            testData = set([1,2,3])
            with self.assertRaises(TypeError):
                json

# Generated at 2022-06-11 01:38:09.930391
# Unit test for function to_bytes
def test_to_bytes():
    # pylint: disable=missing-docstring

    # Test with default error handler of surrogate_then_replace
    if PY3:
        # In python 3 this is a no-op but we want to make sure it's not a regression
        # for when we port to python 2
        test_string = to_bytes('hello')
        assert test_string == b'hello'

        test_string = to_bytes('goodbye')
        assert test_string == b'goodbye'
    else:
        test_string = to_bytes('hello', errors='surrogate_or_replace')
        assert test_string == b'hello'

        # This is not valid utf-8
        test_string = to_bytes('goodbye', errors='surrogate_or_replace')
        assert test_string == b'goodbye'

       

# Generated at 2022-06-11 01:38:40.119886
# Unit test for function jsonify
def test_jsonify():
    # Test encoding keyword
    assert jsonify({u'ascii': 'ASCII'}) == '{"ascii": "ASCII"}'
    assert jsonify({u'non_ascii': u'\u2740'}) == u'{"non_ascii": "\u2740"}'
    assert jsonify({u'non_ascii': u'\u2740'}, ensure_ascii=False) == u'{"non_ascii": "\\u2740"}'
    assert jsonify({u'non_ascii': u'\u2740'}, ensure_ascii=True) == '{"non_ascii": "\\u2740"}'
    # Test default fallback handler

# Generated at 2022-06-11 01:38:51.091385
# Unit test for function to_native
def test_to_native():
    # Check that text and binary strings pass through correctly
    assert to_native(b'foo', errors='surrogate_or_strict') == b'foo'
    assert to_native(u'foo', errors='surrogate_or_strict') == u'foo'

    # Check that text and binary strings pass through correctly
    assert to_native(b'foo', errors='surrogate_or_replace') == b'foo'
    assert to_native(u'foo', errors='surrogate_or_replace') == u'foo'

    # to_native should return a unicode string under Python2
    assert isinstance(to_native(b'foo'), text_type)
    assert isinstance(to_native(u'foo'), text_type)

    # Test bytes with non-ascii characters

# Generated at 2022-06-11 01:38:58.902249
# Unit test for function to_bytes
def test_to_bytes():
    in_values = [
        u'abc',
        u'abc\u6d77\u5916',
        u'abc\udc80\udc00',
        u'abc\udcff',
        'abc',
        b'abc']


# Generated at 2022-06-11 01:39:07.270421
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native

    assert to_native(b'abc') == 'abc'
    assert to_native(b'\xe4\xb8\xad\xe6\x96\x87') == '中文'
    assert to_native(b'\xd1\x94') == '\u0414'
    assert to_native(b'\xd1\x94\x00') == '\u0414'
    assert to_native(b'\xd1\x94\x00\xe4\xb8\xad') == '\u0414中'



# Generated at 2022-06-11 01:39:18.974522
# Unit test for function to_native
def test_to_native():
    # Check that all string types are converted to native strings
    unicode_str = to_text('Žluťoučký kůň', 'utf-8')
    assert isinstance(to_native(unicode_str), text_type)
    assert isinstance(to_native(to_bytes(unicode_str)), text_type)
    assert isinstance(to_native(to_bytes(unicode_str, errors='surrogateescape')), text_type)

    # Check that non-string types are returned as-is
    assert to_native(100) is 100
    assert to_native(100.5) is 100.5
    assert to_native(None) is None
    assert to_native(dict()) == dict()
    assert to_native(list()) == list()

    # Check that we can

# Generated at 2022-06-11 01:39:30.080351
# Unit test for function jsonify
def test_jsonify():
    data = {'type': 'basic', 'name': u'foo', 'baz': 'bar'}
    utf8_data = jsonify(data)
    assert utf8_data == json.dumps(data, encoding='utf-8', default=_json_encode_fallback)

    data = {'type': 'basic', 'name': u'\xe4', 'baz': 'bar'}
    utf8_data = jsonify(data)
    assert utf8_data == json.dumps(data, encoding='utf-8', default=_json_encode_fallback)

    data = {'type': 'basic', 'name': u'\xe4', 'baz': 'bar', u'\u2603': u'\u00e4\xe4'}

# Generated at 2022-06-11 01:39:39.070074
# Unit test for function to_bytes
def test_to_bytes():

    # Test encoding a non-unicode string
    assert to_bytes(b'foo') == b'foo'

    # Test encoding a unicode string
    assert to_bytes(u'bar') == b'bar'

    # Test a non-string type
    assert to_bytes(None) == b'None'

    # Test encoding a unicode string with surrogates
    assert to_bytes(u'\udc9d\u0387', encoding='ascii') == b'?\xc3\x87'
    assert to_bytes(b'\x9d\xc7\x87', encoding='ascii') == b'?\xc3\x87'

    # Test encoding a unicode string with surrogates using 'surrogateescape'