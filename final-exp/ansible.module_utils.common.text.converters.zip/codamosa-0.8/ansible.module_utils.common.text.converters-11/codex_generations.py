

# Generated at 2022-06-11 01:30:02.362088
# Unit test for function to_native
def test_to_native():
    '''Unit test to_native()'''

    # input was bytes.  Want to keep it that way
    assert to_native(b'input bytes') == b'input bytes'
    assert type(to_native(b'input bytes')) == binary_type

    assert to_native(b'input str') == b'input str'
    assert type(to_native(b'input str')) == binary_type

    assert to_native(None) is None
    assert to_native(1) == 1
    assert type(to_native(1)) == int

    # input was text.  Want to keep it that way
    assert to_native(u'input unicode') == u'input unicode'
    assert type(to_native(u'input unicode')) == text_type


# Generated at 2022-06-11 01:30:08.192513
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=dict(c=2))) == '{"a": 1, "b": {"c": 2}}'
    assert jsonify(dict(a=1, b=[dict(c=2), dict(d=3)])) == '{"a": 1, "b": [{"c": 2}, {"d": 3}]}'



# Generated at 2022-06-11 01:30:16.844642
# Unit test for function jsonify
def test_jsonify():
    ansible_dict = dict(contacts=Set([u'user1@example.com', u'user2@example.com']))
    assert jsonify(ansible_dict) == '{"contacts": ["user1@example.com", "user2@example.com"]}'

    ansible_dict = dict(contacts=Set([u'user1@example.com', u'user2@example.com']))
    assert jsonify(ansible_dict, sort_keys=True) == '{"contacts": ["user1@example.com", "user2@example.com"]}'

    ansible_dict = dict(contacts=Set([u'user1@example.com', u'user2@example.com']), test=True)

# Generated at 2022-06-11 01:30:26.758150
# Unit test for function to_bytes
def test_to_bytes():
    import os
    import tempfile
    from ansible.module_utils.basic import write_bytes
    from ansible.module_utils.six import StringIO
    # This class is created in the function's local scope but is used in the
    # class's repr so we make it global to avoid a NameError
    class NonString(object):
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return 'NonString(%r)' % self.value
    class Testclass:
        def test_main(self):
            self._test_encoding(['ascii', 'utf-8'])
            self._test_encoding(['ascii', 'latin-1'])
            self._test_encoding(['ascii', 'utf-16'])
           

# Generated at 2022-06-11 01:30:36.999599
# Unit test for function jsonify
def test_jsonify():
    data1 = {"test1": "test1data", "test2": {"test3": "test3data", "test4": "test4data"}}
    print(jsonify(data1))

    data2 = {'key1': ['value1', 'value2'], 'key2': 'value3'}
    print(jsonify(data2))

    data3 = {'key1': {'key2': 'value1'}, 'key3': ['value2', 'value3'], 'key4': 'value4'}
    print(jsonify(data3))

    data4 = []
    print(jsonify(data4))

    data5 = [1, 2, 3]
    print(jsonify(data5))

    data6 = {1:2, 3:4, 5:6}

# Generated at 2022-06-11 01:30:41.964867
# Unit test for function to_native
def test_to_native():
    assert to_native(None) is None
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'føø'.encode('utf-8')) == u'føø'



# Generated at 2022-06-11 01:30:49.303699
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == u'foo'
    # https://github.com/ansible/ansible/issues/24984
    assert to_native(b'foo') == u'foo'
    # https://github.com/ansible/ansible/issues/24993
    assert to_native(b'foo\n') == u'foo\n'


# Generated at 2022-06-11 01:30:59.572455
# Unit test for function jsonify
def test_jsonify():
    import json
    import datetime

    foo = dict(
        answer = 42,
        data = [1,2,3, "føø"],
        now = datetime.datetime.now(),
        set = set([3,4,1,2]),
        u = u'Døllefjelde-Musse Ƿ',
    )

    bar = dict(
        answer = 42,
        data = [1,2,3, "fÃ¸Ã¸"],
        now = foo["now"].isoformat(),
        set = [3,4,1,2],
        u = u'DÃ¸llefjelde-Musse ƿ',
    )


# Generated at 2022-06-11 01:31:09.715471
# Unit test for function to_bytes
def test_to_bytes():

    def _check(obj, expected, encoding, errors, nonstring):
        '''test method for testing to_bytes'''
        assert to_bytes(obj, encoding=encoding, errors=errors,
                        nonstring=nonstring) == expected

    # Test with a plain vanilla utf-8 string
    _check(u'foo', b'foo', 'utf-8', None, 'strict')
    _check('foo', b'foo', 'utf-8', None, 'strict')

    # Error handler should default to surrogate_then_replace
    _check(u'a\udcff', b'a\ufffd', 'utf-16', None, 'strict')
    # But should work with surrogate_or_replace

# Generated at 2022-06-11 01:31:21.106690
# Unit test for function jsonify
def test_jsonify():
    # Test lists
    str_list = [u'a', u'b', u'c']
    bytestr_list = [b'a', b'b', b'c']
    assert jsonify(str_list) == "["u"\"a\", "u"\"b\", "u"\"c\"""]"
    assert jsonify(bytestr_list) == "["u"\"a\", "u"\"b\", "u"\"c\"""]"
    # Test dicts
    str_dict = {u'1': u'a', u'2': u'b', u'3': u'c'}
    bytestr_dict = {b'1': b'a', b'2': b'b', b'3': b'c'}

# Generated at 2022-06-11 01:31:45.053939
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo', nonstring='simplerepr') == u'foo'
    assert to_native('ascii') == u'ascii'
    assert to_native('utf8') == u'utf8'
    assert to_native(b'utf8') == u'utf8'
    assert to_native(u'\u20ac', 'ascii', nonstring='simplerepr') == u'\ufffd'
    assert to_native(u'\u20ac', 'ascii', nonstring='simplerepr') == u'\ufffd'
    assert to_native(u'\u20ac', 'ascii', errors='surrogate_or_replace', nonstring='simplerepr') == u'?'

# Generated at 2022-06-11 01:31:54.488149
# Unit test for function to_bytes
def test_to_bytes():
    to_bytes('hello', encoding='ascii')
    to_bytes('привет', encoding='ascii', nonstring='strict')

    # errors
    try:
        to_bytes('привет', encoding='ascii')
    except UnicodeEncodeError:
        pass
    to_bytes('привет', encoding='ascii', errors='replace')
    to_bytes('привет', encoding='ascii', errors='surrogateescape')
    to_bytes('привет', encoding='ascii', errors='surrogate_or_replace')
    to_bytes('привет', encoding='ascii', errors='surrogate_then_replace')

# Generated at 2022-06-11 01:32:06.056614
# Unit test for function to_bytes
def test_to_bytes():
    result = to_bytes('ascii_only_string')
    assert isinstance(result, str)
    assert result == b'ascii_only_string'

    result = to_bytes(b'bytes_only_string')
    assert isinstance(result, str)
    assert result == b'bytes_only_string'

    result = to_bytes(u'utf8_string_with_bom\uFEFF')
    assert isinstance(result, str)
    assert result == b'utf8_string_with_bom\xef\xbb\xbf'

    # utf8 string with a non-ascii unicode character
    result = to_bytes(u'utf8_string_with_non_ascii_unicode_f\xf6\xf6')

# Generated at 2022-06-11 01:32:07.622066
# Unit test for function jsonify
def test_jsonify():
    assert(jsonify('test') == '"test"')



# Generated at 2022-06-11 01:32:16.437921
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.unicode import to_unicode

    assert jsonify(to_unicode("foo")) == '"foo"'
    assert jsonify("foo") == '"foo"'
    assert jsonify("vår") == '"v\xe5r"'
    assert jsonify("måned") == '"m\xe5ned"'
    assert jsonify("syöte") == '"sy\xf6te"'
    assert jsonify("blåbærsyltetøy") == '"bl\xe5b\xe6rsyltet\xf8y"'



# Generated at 2022-06-11 01:32:26.848845
# Unit test for function to_native
def test_to_native():
    assert to_native(True) == 'True'
    assert to_native(False) == 'False'
    assert to_native(3) == '3'
    assert to_native(3.0) == '3.0'
    assert to_native([3.0, 2.0, 1.0]) == '[3.0, 2.0, 1.0]'
    assert to_native(u'unicode') == u'unicode'
    assert to_native(b'\xa0') == '\xa0'
    assert to_native(None) == 'None'
    assert to_native({'k': [3.0, 2.0, 1.0]}) == "{'k': [3.0, 2.0, 1.0]}"

# Generated at 2022-06-11 01:32:29.482746
# Unit test for function jsonify
def test_jsonify():
    data = {"a": u"\u4500", "b": 1}
    print(jsonify(data))


# Generated at 2022-06-11 01:32:34.012921
# Unit test for function jsonify
def test_jsonify():
    json_raw_string = jsonify('{"a": "\xe5\xb1\x8b\xe5\x8f\xb0"}')
    assert json_raw_string == '{"a": "\\u5c4b\\u53f0"}'



# Generated at 2022-06-11 01:32:46.295114
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo', nonstring='strict') == b'foo'
    assert to_bytes(u'foo', nonstring='passthru') == u'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(2) == b'2'
    assert to_bytes(2, nonstring='strict') == b'2'
    assert to_bytes(2, nonstring='passthru') == 2
    assert to_bytes(u'\U0001f4a9') == b'\xf0\x9f\x92\xa9'
    assert to_bytes(u'\U0001f4a9', encoding='latin-1') == b'?'

# Generated at 2022-06-11 01:32:55.267876
# Unit test for function to_native
def test_to_native():
    StringTest = collections.namedtuple('StringTest',
                                        'string expected_value')
    # When nonstring=simplerepr
    # We can't test all values that str could return.  However, a number
    # of testcases have been added to ensure that the datetime module
    # (Which is potentially a large user of this function) is still
    # properly handled when it's changed to unicode.
    # This is a partial list of datetime objects to test.  If it's not
    # listed here, it is assumed that it either doesn't have a unicode
    # method or that the unicode method is the same as the default str
    # method.

# Generated at 2022-06-11 01:33:19.102668
# Unit test for function to_native
def test_to_native():

    # Define a simple class
    class MyClass(object):
        def __str__(self):
            return 'string representation of MyClass'
        def __repr__(self):
            return 'repr representation of MyClass'

    myobj = MyClass()
    myobj_str = str(myobj)
    myobj_repr = repr(myobj)

    # Make sure we raise an error for invalid nonstrings
    try:
        to_native(myobj, nonstring='invalid')
    except TypeError as e:
        assert 'nonstring parameter' in str(e)
    else:
        raise AssertionError("TypeError should have been raised")

    # Make sure that the default works for a text string
    assert to_native(u'foo') == u'foo'

# Generated at 2022-06-11 01:33:20.577929
# Unit test for function jsonify
def test_jsonify():
    jsonify({"a": "foo", "b": "bar"})



# Generated at 2022-06-11 01:33:27.909956
# Unit test for function to_native
def test_to_native():
    if PY3:
        assert to_native(u'string') == 'string'
        assert to_native('string') == 'string'
        assert to_native(b'string') == 'string'
        assert to_native(1) == '1'
    else:
        assert to_native(u'string') == 'string'
        assert to_native('string') == 'string'
        assert to_native(b'string') == 'string'
        assert to_native(1) == "1"


# Generated at 2022-06-11 01:33:39.438952
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 'b'}, ensure_ascii=False) == '{"a": "b"}'
    assert jsonify(to_bytes({'a': 'b'}, 'latin-1'), ensure_ascii=False) == '{"a": "b"}'
    assert jsonify(to_bytes({'a': 'b'}, 'utf-8'), ensure_ascii=False) == '{"a": "b"}'
    assert jsonify(to_bytes({'a': 'b'}, 'cp1252'), ensure_ascii=False) == '{"a": "b"}'
    assert jsonify({'a': to_bytes('b', 'latin-1')}, ensure_ascii=False) == '{"a": "b"}'

# Generated at 2022-06-11 01:33:46.398377
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2, c=3)) == "{\"a\": 1, \"c\": 3, \"b\": 2}"
    assert jsonify([1,2,3]) == "[1, 2, 3]"
    assert jsonify(dict(a=1, b=2, c=3), sort_keys=True) == "{\"a\": 1, \"b\": 2, \"c\": 3}"
    assert jsonify(dict(a=1, b=2, c=3), sort_keys=True, indent=4) == "{\n    \"a\": 1,\n    \"b\": 2,\n    \"c\": 3\n}"


# Generated at 2022-06-11 01:33:58.058752
# Unit test for function jsonify
def test_jsonify():
    import sys, os
    import six
    # Test python2
    if six.PY2:
        if sys.platform != 'win32':
            os.environ['LANG'] = 'en_US.UTF-8'
        string = 'café'
        assert isinstance(string, six.text_type)
        assert len(string) == 4
        json_string = jsonify(string)
        assert isinstance(json_string, six.binary_type)
        assert len(json_string) == 10
        assert json_string == b'"caf\xc3\xa9"'

    # Test python3
    else:
        string = 'café'
        assert isinstance(string, six.text_type)
        assert len(string) == 4
        json_string = jsonify(string)

# Generated at 2022-06-11 01:34:01.604242
# Unit test for function jsonify
def test_jsonify():
    test_data = { b'foo': b'bar', b'baz': u'qux' }
    assert jsonify(test_data) == '{"foo": "bar", "baz": "qux"}'



# Generated at 2022-06-11 01:34:04.700167
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=u'\u20ac', b='foo')) == '{"a": "\\u20ac", "b": "foo"}'



# Generated at 2022-06-11 01:34:13.540193
# Unit test for function jsonify
def test_jsonify():
    class TestSet(Set):
        pass
    ts = TestSet(['foo', 'bar'])
    d = dict(a=1, b=2, ts=ts, s=set('abc'))
    res = jsonify(d)
    assert isinstance(res, text_type)
    assert res == '{"a": 1, "s": ["a", "b", "c"], "b": 2, "ts": ["foo", "bar"]}'

    # Test unicode error handling
    # Note: This fails on Python3 because the Python3 json module uses
    # surrogateescape.

    # Create a unicode string which cannot be decoded into the encoding 'latin-1'
    if PY3:
        bad_unicode = bytes(range(128, 256)).decode('latin-1', 'surrogateescape')


# Generated at 2022-06-11 01:34:25.063932
# Unit test for function jsonify
def test_jsonify():
    assert b'{"test": "unicode"}' == jsonify({"test": u'unicode'})
    assert b'["has unicode \xc3\xa5\xc3\xa6\xc3\xb8"]' == jsonify(["has unicode \xe5\xe6\xf8"])
    assert b'{"test": "unicode"}' == jsonify({"test": b'unicode'.decode('latin-1')})
    assert b'{"test": "unicode"}' == jsonify({"test": b'unicode'.decode('utf-8')})
    assert b"{'test': 'unicode'}" == jsonify({"test": u'unicode'}, ensure_ascii=True)

# Generated at 2022-06-11 01:34:42.091546
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": u"foo"}) == '{"a": "foo"}'
    assert jsonify({"a": b"foo"}) == '{"a": "foo"}'
    assert jsonify({"a": b"foo".decode('latin-1')}) == '{"a": "foo"}'



# Generated at 2022-06-11 01:34:53.468729
# Unit test for function to_native

# Generated at 2022-06-11 01:35:01.135808
# Unit test for function to_native
def test_to_native():
    result = to_native("Ansible", None)
    assert result == "Ansible"

    result = to_native("Ansible", str)
    assert result == "Ansible"

    result = to_native("Ansible", bytes)
    assert result == b"Ansible"

    result = to_native("Ansible", "ascii")
    assert result == b"Ansible"

    with pytest.raises(UnicodeDecodeError):
        to_native("Ansible", "ascii", "strict")

    if PY3:
        result = to_native("Ansible".encode("ascii"), "ascii", "strict")
        assert result == b"Ansible"

        # We do not allow surrogateescape to appear in non-PY3 tests

# Generated at 2022-06-11 01:35:13.198290
# Unit test for function to_native
def test_to_native():
    import io
    # bytes
    assert(to_native(b'') == '')
    assert(to_native(b'abc\x80\x81') == 'abc\x80\x81')
    assert(to_native(b'{"a": "a", "b": "b"}') == '{"a": "a", "b": "b"}')

    # unicode
    assert(to_native(u'') == '')
    assert(to_native(u'abc\x80\x81') == 'abc\x80\x81')
    assert(to_native(u'{"a": "a", "b": "b"}') == '{"a": "a", "b": "b"}')

    # non-string
    assert(to_native(1) == '1')

# Generated at 2022-06-11 01:35:22.305893
# Unit test for function to_bytes
def test_to_bytes():
    to_bytes('foobar')
    to_bytes(u'foobar', errors='surrogate_or_replace')
    to_bytes(u'foobar', errors='surrogate_or_replace', nonstring='passthru')
    to_bytes(u'foobar', errors='surrogate_or_strict', nonstring='passthru')
    to_bytes(b'foobar', nonstring='passthru')
    to_bytes(None, nonstring='simplerepr')
    to_bytes(None, nonstring='empty')
    to_bytes(None, nonstring='passthru')
    fail_to_bytes = lambda: to_bytes(None, nonstring='strict')
    try:
        fail_to_bytes()
    except TypeError:
        pass

# Generated at 2022-06-11 01:35:33.624803
# Unit test for function to_bytes
def test_to_bytes():
    _test_to_bytes('hello world', six.b('hello world'))
    _test_to_bytes('héllo world', six.b('héllo world'), 'latin-1')
    _test_to_bytes('héllo world', six.b('héllo world'), 'utf-8')
    _test_to_bytes('héllo world', six.b('h\xc3\xa9llo world'), 'ascii')
    _test_to_bytes('héllo world', six.b('h\xc3\xa9llo world'), 'ascii', 'surrogate_or_replace')
    _test_to_bytes('héllo world', six.b('h\xe9llo world'), 'ascii', 'replace')

# Generated at 2022-06-11 01:35:39.475115
# Unit test for function jsonify
def test_jsonify():
    test_in = {u'\xe8\xaf\xad\xe4\xb9\xa6': u'\u4e2d\u6587'}
    test_out = '{"\xe8\xaf\xad\xe4\xb9\xa6": "\u4e2d\u6587"}'
    j = jsonify(test_in)
    assert j == test_out, "%s != %s" % (j, test_out)



# Generated at 2022-06-11 01:35:46.766858
# Unit test for function to_native
def test_to_native():
    assert to_native("a") == "a"
    assert to_native(u"a") == "a"
    assert to_native(u"ä") == "ä"
    assert to_native(u"\u20ac") == "€"
    assert to_native("\xc3\xa4") == "ä"
    assert to_native("\xe2\x82\xac") == "€"
    # surrogate pair
    assert to_native(u"\ud800\udf02") == "\U00010412"
    assert to_native("\xf0\x90\x90\x82") == "\U00010412"
    assert to_native(u"\udc80") == "\udc80"
    # string with invalid byte

# Generated at 2022-06-11 01:35:57.312435
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u1234') == u'\u1234'
    assert to_native(b'\xe1\x88\xb4') == u'\u1234'
    assert to_native(u'\u1234', encoding='ascii') == u'?'
    assert to_native(u'\u1234', nonstring='simplerepr') == u'\u1234'
    assert to_native(True, nonstring='simplerepr') == u'True'
    assert to_native(None, nonstring='simplerepr') == u'None'
    assert to_native(b'\xe1\x88\xb4', nonstring='strict') == TypeError
    assert to_native(1, nonstring='strict') == TypeError



# Generated at 2022-06-11 01:36:03.890789
# Unit test for function jsonify
def test_jsonify():
    data = {u'stat': {u'color': u'yellow', u'number': u'7'}}
    assert jsonify(data) == b'{"stat": {"color": "yellow", "number": "7"}}'
    data = {u'stat': [1, 2, {u'color': u'yellow', u'number': u'7'}]}
    assert jsonify(data) == b'{"stat": [1, 2, {"color": "yellow", "number": "7"}]}'


# Generated at 2022-06-11 01:36:26.781020
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native

    assert to_native("just works") == u"just works"


# Generated at 2022-06-11 01:36:35.421941
# Unit test for function to_native

# Generated at 2022-06-11 01:36:43.018548
# Unit test for function jsonify
def test_jsonify():
    import json
    import datetime

    data = {"key": "value", "key2": [1, 2, 3], "key3": u"ss\u00e9", "key4": {"key5": "value2"}}
    json_data = jsonify(data)
    assert json_data == json.dumps(data, encoding="utf-8")

    now = datetime.datetime.now()
    json_data = jsonify(now)
    assert json_data == json.dumps(now.isoformat(), encoding="utf-8")



# Generated at 2022-06-11 01:36:51.141497
# Unit test for function to_bytes
def test_to_bytes():
    # Test surrogateescape (tested in python3 tests)
    # Test surrogate_or_strict
    # Test surrogate_or_replace
    # Test surrogate_then_replace
    # Test empty (tested in python3 tests)
    # Test strict (tested in python3 tests)
    # Test simplerepr (tested in python3 tests)
    # Test passthru
    non_bytes = object()
    my_bytes = to_bytes(non_bytes, nonstring='passthru')
    assert id(my_bytes) == id(non_bytes)



# Generated at 2022-06-11 01:36:57.513389
# Unit test for function jsonify
def test_jsonify():
    assert '"empty"' == jsonify({})
    assert '["empty"]' == jsonify([{}])
    assert '{"foo": "bar"}' == jsonify({'foo': 'bar'})
    assert '["foo", "bar"]' == jsonify(['foo', 'bar'])
    assert '{"foo": ["bar", "baz"]}' == jsonify({'foo': ['bar', 'baz']})
    assert 'null' == jsonify(None)



# Generated at 2022-06-11 01:37:01.043250
# Unit test for function jsonify
def test_jsonify():
    import json
    data = {'A': {'B': {'C': 'unicode \u2665'}}}
    data = jsonify(data)
    assert json.loads(data)['A']['B']['C'] == 'unicode \u2665'



# Generated at 2022-06-11 01:37:01.609055
# Unit test for function to_native
def test_to_native():
    pass

# Generated at 2022-06-11 01:37:11.616032
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import OrderedDict
    from datetime import datetime

    input_data = OrderedDict([
        ('a', to_text(u'\u00f6 \u00e8 \u00e9', encoding='utf-8')),
        ('c', datetime(2014, 2, 13, 13, 13))
    ])

    serialized = jsonify(input_data)

    assert json.loads(serialized) == {"a": "ö è é", "c": "2014-02-13T13:13:00"}



# Generated at 2022-06-11 01:37:20.030764
# Unit test for function jsonify
def test_jsonify():
    # Test with utf-8 encoded data
    utf8_text = to_text(b'abc\xc3\xb1', 'utf-8')
    assert jsonify(utf8_text) == '"abc\\u00f1"'
    assert jsonify({1: utf8_text}) == "{\"1\": \"abc\\u00f1\"}"

    # Test with utf-8 decodable data with latin-1 encoding
    utf8_decodable_data = to_bytes(utf8_text, 'latin-1')
    assert jsonify(utf8_decodable_data) == '"abc\\u00f1"'
    assert jsonify({1: utf8_decodable_data}) == "{\"1\": \"abc\\u00f1\"}"

    # Test with utf-8 dec

# Generated at 2022-06-11 01:37:31.630869
# Unit test for function to_native
def test_to_native():
    '''Unit test for module_utils._text.to_native'''
    result = to_text('bytes')
    assert isinstance(result, text_type)
    result = to_text(u'text')
    assert isinstance(result, text_type)
    result = to_text(u'text'.encode('utf-8'), errors='surrogate_or_replace')
    assert isinstance(result, text_type)
    result = to_text(u'text'.encode('utf-16'), errors='surrogate_or_replace')
    assert isinstance(result, text_type)
    result = to_text(u'\udcfftext'.encode('utf-8'), errors='surrogate_or_replace')
    assert isinstance(result, text_type)


# Generated at 2022-06-11 01:38:27.726674
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'asdf') == b'asdf'
    assert to_bytes(u'asdf') == b'asdf'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\xe1\x88\xb4'
    assert to_bytes(b'\xff') == b'\xff'
    assert to_bytes(u'\u1234', errors='ignore') == b''
    assert to_bytes(u'\u1234', errors='replace') == b'?'
    assert to_bytes(u'\u1234', errors='surrogateescape') == b'\xed\xa0\x84'
    # Note: surrogateescape only

# Generated at 2022-06-11 01:38:36.183881
# Unit test for function jsonify
def test_jsonify():
    data = set([1,2,3])
    assert json.loads(jsonify(data)) == [1,2,3]
    from datetime import datetime
    date_obj = datetime(year=2012, month=12, day=15)
    assert json.loads(jsonify(date_obj)) == "2012-12-15T00:00:00"
    # Test non-list
    try:
        jsonify(dict(a=1,b=2))
    except TypeError:
        # Expected behaviour
        pass


# Generated at 2022-06-11 01:38:44.518982
# Unit test for function to_bytes
def test_to_bytes():
    """
    :returns: bool -- True if all tests pass, False otherwise
    """
    from ansible.module_utils.six import b

# Generated at 2022-06-11 01:38:49.080473
# Unit test for function to_native
def test_to_native():
    """Test function to_native"""
    assert to_native(u'item', errors='surrogate_then_replace') == u"item"
    assert to_native(b'\xe0\xbf\xbd', errors='surrogate_then_replace') == u"\ufffd"

# Generated at 2022-06-11 01:38:58.122710
# Unit test for function to_native
def test_to_native():
    # --------------
    # try bytes
    # --------------
    # If we pass it bytes, we get back the bytes unchanged
    b_to_native = to_native(b'hello world')
    assert b_to_native == b'hello world'
    assert type(b_to_native) == bytes

    # --------------
    # try text
    # --------------
    # If we pass it text, we get back the text unchanged, except in python2 we
    # get back unicode, not str.
    t_to_native = to_native('hello world')
    if PY3:
        assert t_to_native == 'hello world'
        assert type(t_to_native) == str
    else:
        assert t_to_native == u'hello world'
        assert type(t_to_native) == text

# Generated at 2022-06-11 01:39:07.865118
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(
        a=dict(b='c', f=dict(g='h')),
        e=dict(i='j'),
        k=Set(['l', 'm']),
        n=datetime.datetime(2014, 7, 1, 11),
    ), indent=2, sort_keys=True) == '{\n  "a": {\n    "b": "c", \n    "f": {\n      "g": "h"\n    }\n  }, \n  "e": {\n    "i": "j"\n  }, \n  "k": [\n    "l", \n    "m"\n  ], \n  "n": "2014-07-01T11:00:00"\n}'



# Generated at 2022-06-11 01:39:19.153414
# Unit test for function to_bytes
def test_to_bytes():
    # Test various valid nonstring types
    assert to_bytes(5) == b'5'
    assert to_bytes(5.5) == b'5.5'
    assert to_bytes(True) == b'True'
    assert to_bytes(None) == b'None'
    assert to_bytes((1, 2, 3)) == b'(1, 2, 3)'
    assert to_bytes({'a': 1, 'b': 2}) == b"{'a': 1, 'b': 2}"

    # Test invalid nonstring types
    try:
        to_bytes(5, nonstring='badvalue')
        assert False
    except TypeError:
        assert True
    try:
        to_bytes(5, nonstring=5)
        assert False
    except TypeError:
        assert True

    # Test various valid

# Generated at 2022-06-11 01:39:22.643681
# Unit test for function jsonify
def test_jsonify():
    for encoding in ("utf-8", "latin-1"):
        try:
            test_json = jsonify(encoding)
        except TypeError:
            pass
        except UnicodeDecodeError:
            pass



# Generated at 2022-06-11 01:39:33.719249
# Unit test for function to_bytes
def test_to_bytes():
    # Python2.6 doesn't have b'' notation so use this instead
    b = to_bytes(str(''))
    test_passing_byte = u'pass'
    test_passing_byte_b = to_bytes(test_passing_byte)
    test_unicode_byte = u'\u6211\u7231\u4f60'
    test_unicode_byte_b = to_bytes(test_unicode_byte)
    test_non_ascii_byte = u'\ufffd'
    test_non_ascii_byte_b = to_bytes(test_non_ascii_byte)
    test_surrogate_byte = u'\ud800'
    test_surrogate_byte_b = to_bytes(test_surrogate_byte)

# Generated at 2022-06-11 01:39:41.109654
# Unit test for function jsonify
def test_jsonify():
    """Test to make sure there is no errors during json encoding"""
    # Test to ensure that Set are transformed to lists
    assert jsonify(set([1, 2, 3])) == '{"_ansible_set": [1, 2, 3]}'

    test_date = datetime.datetime(2011, 12, 12, 12, 12, 12)
    assert jsonify(test_date) == '"2011-12-12T12:12:12"'

    # Test that Default function is working.
    assert jsonify([set([1, 2, 3]), test_date]) == '{"_ansible_set": [1, 2, 3], "_ansible_seq": [{"_ansible_set": [1, 2, 3]}, "2011-12-12T12:12:12"]}'

