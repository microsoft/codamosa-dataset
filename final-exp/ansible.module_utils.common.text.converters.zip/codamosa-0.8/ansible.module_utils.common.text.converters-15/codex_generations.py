

# Generated at 2022-06-11 01:30:03.558654
# Unit test for function to_bytes
def test_to_bytes():
    '''
    ansible.module_utils.common.to_bytes - Test Cases

    These test cases can be used to cover the various behaviours when
    converting text and nontext to bytes.  To use them directly::

        python -m ansible.module_utils.common to_bytes

    If you have nose you can use::

        nosetests test/unit/module_utils/common/to_bytes
    '''
    from .argspec import get_argument_spec

    results = []

    # While the following tests could be written in the individual test's
    # docstring, it's best to have them here in the main docstring.  These
    # ways of running the tests will only use the docstring of the function
    # as the test specifications.

# Generated at 2022-06-11 01:30:14.011592
# Unit test for function jsonify
def test_jsonify():
    x = {
        'booleans': [True, False, True, True],
        'none': None,
        'text': u"I'm a string",
        'numbers': [1, 0, -1, 1.2345, 0.0],
        'list': [1, 2, 3, {'item': 'test'}],
        'dict': {'Name': 'John Doe', 'Age': '34', 'Location': 'Wherever'},
        'empty_dict': {},
        'empty_list': [],
    }
    assert jsonify(x)
    # All Python versions can encode utf-8
    assert jsonify(x, encoding="utf-8")
    # Make sure we can encode Latin-1 as well, just in case.
    assert jsonify(x, encoding="latin-1")


# Generated at 2022-06-11 01:30:24.510236
# Unit test for function to_native
def test_to_native():
    for test_string in ['string', u'string']:
        # test str or unicode string
        assert to_native(test_string) == 'string'
        assert to_native(test_string, errors='strict') == 'string'
        assert to_native(test_string, errors='surrogate_or_replace') == 'string'
        assert to_native(test_string, errors='surrogate_or_strict') == 'string'
        # test surrogate_then_replace on a string with no errors
        assert to_native(test_string, errors='surrogate_then_replace') == 'string'

    # Test surrogate_then_replace on surrogates
    assert to_native(b'\x80', errors='surrogate_then_replace') == u'\ufffd'

# Generated at 2022-06-11 01:30:34.795230
# Unit test for function to_native
def test_to_native():
    assert to_native('abc') == 'abc'
    assert to_native(b'abc') == 'abc'
    # Make sure that surrogateescape gets passed through
    # surrogateescape was added in python3, so this is just surrogateescape
    # under the hood.  But, this exercises the code in to_text
    assert to_native(b'\xf1\x80\x80\x80') == b'\xf1\x80\x80\x80'.decode('utf-8', 'surrogateescape')
    # and make sure that surrogateescape gets passed through to to_bytes
    assert to_native(b'\xf1\x80\x80\x80'.decode('utf-8', 'surrogateescape')) == b'\xf1\x80\x80\x80'

# Generated at 2022-06-11 01:30:39.253121
# Unit test for function jsonify
def test_jsonify():
    try:
        jsonify(set())
        assert False
    except TypeError:
        assert True

    try:
        jsonify({1:Set()})
        assert False
    except TypeError:
        assert True

    assert jsonify({1:1}) == '{"1": 1}'

    try:
        jsonify({1: datetime.datetime(2012, 1, 1)})
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-11 01:30:46.805523
# Unit test for function to_native
def test_to_native():
    assert to_native(b'spam') == 'spam'
    assert to_native('eggs') == 'eggs'
    assert to_native('\u00e4\u00f6\u00fc') == '\u00e4\u00f6\u00fc'
    assert to_native(b'\xc3\xa4\xc3\xb6\xc3\xbc') == '\u00e4\u00f6\u00fc'



# Generated at 2022-06-11 01:30:57.528993
# Unit test for function to_bytes
def test_to_bytes():
    import sys
    # Try with a good encoding
    try:
        # In Python3, this should decode to the right thing
        assert b'\xc3\xb1' == to_bytes('\xc3\xb1'.encode('utf-8'), 'utf-8')
        # In Python2, this should encode to the right thing
        assert b'\xc3\xb1' == to_bytes(b'\xc3\xb1'.decode('utf-8'), 'utf-8')
    except AssertionError:
        # In Python3, this should decode to the right thing
        assert b'\xc3\xb1' == to_bytes(b'\xc3\xb1')
        # In Python2, this should encode to the right thing

# Generated at 2022-06-11 01:31:06.777993
# Unit test for function to_native
def test_to_native():
    assert to_native(b'\xc3\xbc', 'utf-16') == u'\xfc'

    # We have no way to test surrogateescape because the hex
    # representation is technically a string of a surrogate pair.
    # In order to generate a surrogate pair in python you have to
    # intentionally use a bad encoding and then decode with
    # surrogateescape.  This would be a unit test of both to_bytes
    # and to_text in one and that's too complex so we don't test
    # it here.

    assert to_native(None) == u''
    assert to_native('\xfc') == u'\xfc'
    assert to_native(b'\xfc') == u'\xfc'


# Generated at 2022-06-11 01:31:11.467154
# Unit test for function to_native
def test_to_native():
    assert to_native(b'hello') == 'hello'
    data = {'hello': 'world'}
    if PY3:
        assert to_native(data) == repr(data)
    else:
        assert to_native(data) == str(data)



# Generated at 2022-06-11 01:31:23.017835
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils import _json_compat as json_compat
    # Convert OrderedDict to dict
    test_data = dict()
    test_data['key1'] = 'value1'
    test_data['key2'] = ['value2', 'value3']
    test_data['key3'] = dict()
    test_data['key3']['key4'] = 'value4'
    test_data['key3']['key5'] = ['value5', 'value6']

    # check the result of jsonify function
    str_data = jsonify(test_data)
    dict_data = json_compat.loads(str_data)

    assert test_data == dict_data

    # check the result of jsonify function with unicode

# Generated at 2022-06-11 01:31:40.769935
# Unit test for function to_bytes
def test_to_bytes():
    '''
    Unit test for ansible.utils.to_bytes

    :kwarg nonstring: Determines what the return value should be for
        nonstrings.  Default: 'simplerepr'
    :kwarg encoding: Value to use for encoding.  Default: 'utf-8'
    :kwarg errors: Value to use for errors.  Default: 'surrogate_or_replace'
    '''
    import sys
    import unittest


# Generated at 2022-06-11 01:31:51.632137
# Unit test for function to_native
def test_to_native():
    #str1=str(str,encoding='utf8')
    str1=b" \xef\xbb\xbfabc"
    str2=b"\x80abc"
    str3=b"\xef\xbf\xbdabc"
    str4=b"\xc3\xa1bc"
    str5=b"\xe4\xbd\xa0\xe5\xa5\xbd"
    str6=b"\xe4\xbd\x9c\xe4\xba\xba\xe8\x80\x81\xe4\xb9\x85\xe5\x8c\x96"
    str7=b"abc"
    print(to_native(str1))
    print(to_native(str2))

# Generated at 2022-06-11 01:32:01.714768
# Unit test for function jsonify
def test_jsonify():
    original_list = [u'\n', u'\xc2\xb7', u'\n']
    original_dict = {u'key1': u'\n', u'key2': u'\xc2\xb7', u'key3': u'\n'}
    original_set = set(original_list)

    assert jsonify(original_list) == u'["\\n", "\\u00b7", "\\n"]'
    assert jsonify(original_dict) == u'{"key1": "\\n", "key3": "\\n", "key2": "\\u00b7"}'
    assert jsonify(original_set) == u'["\\n", "\\u00b7"]'


# Generated at 2022-06-11 01:32:13.294489
# Unit test for function to_native
def test_to_native():
    b_to_native = to_native(b'hello')
    assert isinstance(b_to_native, str), 'Expected string return value, got {0}'.format(type(b_to_native))
    assert b_to_native == 'hello', 'Expected "hello", got {0}'.format(b_to_native)

    u_to_native = to_native(u'hello')
    assert isinstance(u_to_native, str), 'Expected string return value, got {0}'.format(type(u_to_native))
    assert u_to_native == 'hello', 'Expected "hello", got {0}'.format(u_to_native)

    # Test to_native dict
    dict_to_native = to_native({'hello': u'world'})

# Generated at 2022-06-11 01:32:22.234849
# Unit test for function jsonify
def test_jsonify():
    import json
    json_string = b'{"ab": "cd"}'
    assert json.loads(json_string) == json.loads(jsonify(json_string)), "jsonify does not work for pure json string!"
    utf8_json_string = u'{"ab": "cd"}'
    assert json.loads(json_string) == json.loads(jsonify(utf8_json_string)), "jsonify does not work for utf8 json string!"

    test_dict = {u'ab': u'cd'}
    test_string = '{"ab": "cd"}'
    assert json.loads(test_string) == json.loads(jsonify(test_dict)), "jsonify does not work for utf8 dict"
    test_dict = {'ab': 'cd'}

# Generated at 2022-06-11 01:32:34.290890
# Unit test for function to_bytes
def test_to_bytes():
    bogus_str = text_type(str(b'bogus'), 'utf-8', 'surrogateescape')
    unic_str = to_text(u'\u2713')
    byte_str = unic_str.encode('utf-8')
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'foo', errors='strict') == b'foo'
    assert to_bytes(b'foo', errors='strict') == b'foo'
    if PY3:
        assert to_bytes(bogus_str) == b'bogus'
    else:
        assert to_bytes(bogus_str) == b'bogus'

# Generated at 2022-06-11 01:32:46.289807
# Unit test for function to_native
def test_to_native():
    # At the python layer, a text string and a byte string are both native
    assert to_native(u'foo') == 'foo'
    assert to_native('foo') == 'foo'
    assert to_native(b'foo') == 'foo'

    assert to_native(u'\u2019') == '\u2019'
    assert to_native('\u2019') == '\u2019'
    assert to_native(b'\xe2\x80\x99') == '\u2019'

    # Test that this always returns a text string
    # assert to_native(None) == u'None'
    # assert to_native(True) == u'True'

    # test that objects are converted to text
    class Foo(object):
        def __str__(self):
            return 'foo'

# Generated at 2022-06-11 01:32:55.268176
# Unit test for function to_bytes
def test_to_bytes():
    # Note:  This should be updated for every encodings that get
    #      tested.  It is used by find_missing_tests to find encodings
    #      that need to be linked to a test
    encodings = set()

    class dummy_unicode(text_type):
        '''This is a dummy unicode class that will try to decode with
        an undefined codec
        '''

    def make_unencodable():
        '''Create a string that has one undecodable character in
        Latin-1

        :returns: a string that has the first character encoded in
            Latin-1 and the second character will have a value that
            does not decode in Latin-1.
        '''
        return u'\x41%s' % unichr(0xFFFD)

    # First a string that we know

# Generated at 2022-06-11 01:33:07.798350
# Unit test for function to_bytes

# Generated at 2022-06-11 01:33:17.381561
# Unit test for function to_native
def test_to_native():
    '''
    Unit test for function ``to_native``.
    '''
    from ansible.module_utils._text import to_native
    # ``to_native`` called with a text string
    ########################################
    # PY2:
    assert to_native(u"test") == "test"
    # PY3:
    assert to_native(u"test") == "test"
    # ``to_native`` called with a byte string
    ########################################
    # PY2:
    assert to_native(b"test") == "test"
    # PY3:
    assert to_native(b"test") == "test"


# Generated at 2022-06-11 01:33:34.941893
# Unit test for function to_bytes
def test_to_bytes():
    # Basic text and bytes tests
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234'.encode('utf-8')) == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234'.encode('utf-8'), nonstring='passthru') == b'\xe1\x88\xb4'
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

    if HAS_SURROGATEESCAPE:
        # nonstring tests
        assert to_bytes(u'\u1234', nonstring='simplerepr') == b'\xe1\x88\xb4'
        assert to

# Generated at 2022-06-11 01:33:44.781847
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native

    assert u'\U0001f4a9' == to_native(u'\U0001f4a9')
    assert u'\U0001f4a9' == to_native(u'\U0001f4a9'.encode('utf-8'))
    assert u'\U0001f4a9' == to_native(u'\U0001f4a9'.encode('utf-8'), errors='surrogate_or_strict')
    assert u'\U0001f4a9' == to_native(u'\U0001f4a9'.encode('utf-8'), errors='surrogate_or_replace')

# Generated at 2022-06-11 01:33:56.375180
# Unit test for function to_bytes
def test_to_bytes():
    class Foo(object):
        def __init__(self):
            self.bar = 'baz'

    if PY3:
        def tostring(string):
            return string.encode('utf-8')
    else:
        def tostring(string):
            return string

    assert to_bytes(Foo(), errors='strict') == b'<to_bytes.Foo object at '
    assert to_bytes(Foo(), nonstring='simplerepr') == tostring('<to_bytes.Foo object at ')
    assert to_bytes(Foo(), nonstring='passthru') == Foo()
    assert to_bytes(Foo(), nonstring='empty') == tostring('')
    assert to_bytes(Foo(), errors='replace', nonstring='empty') == tostring('')
    assert to_

# Generated at 2022-06-11 01:34:04.465396
# Unit test for function to_native
def test_to_native():
	import os
	file_path = os.path.dirname(os.path.abspath(__file__))
	filename = os.path.join(file_path, 'to_native.json')
	my_file = open(filename, 'r')
	my_list = my_file.readlines()
	for item in range(0, len(my_list)):
		print(u'Sample:', my_list[item])
		result = to_native(my_list[item])
		print('Result:', result)


# Generated at 2022-06-11 01:34:10.960825
# Unit test for function jsonify
def test_jsonify():
    assert '{"a": "b"}' == jsonify({"a": "b"})
    assert '{"a": "b"}' == jsonify(container_to_text({"a": "b"}, encoding='utf-8'))
    assert '{"a": "b"}' == jsonify(container_to_bytes({"a": "b"}, encoding='utf-8'))
    assert '{"a": "b"}' == jsonify(container_to_bytes({"a": "b"}, encoding='latin-1'))



# Generated at 2022-06-11 01:34:19.132066
# Unit test for function jsonify
def test_jsonify():
    data = to_text(u'\u2603', 'utf-8')
    data = {
        'x': to_text(u'\u2603', 'utf-8'),
        'y': [1,2,data]
    }
    s = jsonify(data, indent=2)
    import sys
    if PY3:
        sys.stdout.buffer.write(s)
    else:
        sys.stdout.write(s)
    print()



# Generated at 2022-06-11 01:34:25.571868
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'привет') == u'привет'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'\xe4\xbd\xa0\xe5\xa5\xbd') == u'你好'
    assert to_native(1) == '1'



# Generated at 2022-06-11 01:34:34.838406
# Unit test for function to_native
def test_to_native():
    """
    Validate the to_native function's happy path
    """
    from ansible.module_utils._text import to_native
    # Check for non-strings
    assert to_native(None) is None
    assert to_native(42) == 42
    assert to_native(dict(a=42)) == dict(a=42)
    assert to_native(set([42])) == set([42])
    assert to_native(datetime.datetime(year=2017, month=1, day=1)) == datetime.datetime(year=2017, month=1, day=1)
    # Check for native strings
    assert to_native(u'foo') == 'foo'
    assert to_native('foo') == 'foo'
    # Pass a non-string with nonstring=strict

# Generated at 2022-06-11 01:34:47.152758
# Unit test for function to_bytes
def test_to_bytes():
    try:
        codecs.lookup_error('surrogateescape')
        HAS_SURROGATEESCAPE = True
    except LookupError:
        HAS_SURROGATEESCAPE = False

    assert to_bytes(u'strings must be utf-8') == b'strings must be utf-8'
    assert to_bytes(u'питон', errors='strict') == b'\xd0\xbf\xd0\xb8\xd1\x82\xd0\xbe\xd0\xbd'
    assert to_bytes(b'bytes stay bytes') == b'bytes stay bytes'
    assert to_bytes(b'bytes stay bytes', nonstring='simplerepr') == b'bytes stay bytes'

# Generated at 2022-06-11 01:34:57.092907
# Unit test for function to_native
def test_to_native():
    b_u_value = b'one\u2013two'
    u_value = u'one\u2013two'
    # Test an ascii bytestring
    b_value = b'onetwothree'

    # Test surrogate_or_strict
    assert to_native(b_u_value, errors='surrogate_or_strict') == u_value

    # Test surrogate_or_replace
    assert to_native(b_u_value, errors='surrogate_or_replace') == u'one\uFFFDtwo'

    # Test surrogate_then_replace
    assert to_native(b_u_value, errors='surrogate_then_replace') == u'one\uFFFDtwo'

    # Test ascii bytestring

# Generated at 2022-06-11 01:35:13.003230
# Unit test for function to_bytes

# Generated at 2022-06-11 01:35:22.215972
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": {b"b": u"b"}}) == '{"a": {"b": "b"}}'
    assert jsonify({"a": {b"b": u"b"}}) == '{"a": {"b": "b"}}'
    assert jsonify({"a": {b"b": u"b"}}) == '{"a": {"b": "b"}}'
    assert jsonify({"a": {b"b": u"b"}}) == '{"a": {"b": "b"}}'
    assert jsonify([{b"b": u"b"}]) == '[{"b": "b"}]'
    assert jsonify([{b"b": u"b"}]) == '[{"b": "b"}]'

# Generated at 2022-06-11 01:35:27.530401
# Unit test for function to_native
def test_to_native():
        # to_native should always return native strings
        assert isinstance(to_native(u'some string'), text_type)
        assert isinstance(to_native(b'some string'), binary_type)

if __name__ == "__main__":
    # Unit test for function to_bytes
    test_to_bytes()
    test_to_native()

# Generated at 2022-06-11 01:35:38.092655
# Unit test for function to_bytes
def test_to_bytes():
    # Test autodetection of utf8
    ansible_test = to_bytes(u'\u20ac')
    assert ansible_test == u'\u20ac'.encode('utf-8')
    # Test autodetection of utf8, exceptions
    ansible_test = to_bytes(u'\u20ac', errors='surrogate_or_replace')
    assert ansible_test == u'\u20ac'.encode('utf-8')
    # Test utf8
    ansible_test = to_bytes(u'\u20ac', 'utf-8', 'strict')
    assert ansible_test == u'\u20ac'.encode('utf-8')
    # Test utf8 surrogateescape

# Generated at 2022-06-11 01:35:46.088671
# Unit test for function to_bytes
def test_to_bytes():
    # Verify that we accept text and return bytes
    assert isinstance(to_bytes(u'\u1234'), binary_type)

    # Verify that we accept bytes and return bytes
    assert isinstance(to_bytes(b'\xff'), binary_type)

    # Verify that we don't accept other types
    for nonstring in (42, 1.23, object(), object):
        try:
            to_bytes(nonstring)
            success = False
        except TypeError:
            success = True
        assert success, ("to_bytes accepted a nonstring type of %s when "
                "nonstring was the default value." % (type(nonstring,)))

        success = False
        try:
            to_bytes(nonstring, nonstring='strict')
        except TypeError:
            success = True

# Generated at 2022-06-11 01:35:56.738206
# Unit test for function to_native
def test_to_native():
    '''
    Basic sanity check.
    '''
    plain_text = 'hello'
    plain_bytes = b'hello'
    unicode_string = u'hello'
    complex_tuple = (plain_text, plain_bytes, unicode_string)

    assert isinstance(to_native(plain_text), type(''))
    assert isinstance(to_native(plain_bytes), type(''))
    assert isinstance(to_native(unicode_string), type(''))
    assert isinstance(to_native(complex_tuple), type(()))

    assert to_native(plain_text) == 'hello'

    assert isinstance(to_native(plain_bytes, errors='surrogate_or_replace'), type(''))

# Generated at 2022-06-11 01:36:06.430524
# Unit test for function to_native
def test_to_native():
    """
    Unit tests for function to_native.
    """
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils._text import to_native

    # text string
    assert isinstance(to_native(u'foo'), text_type)
    # nonascii text string
    assert isinstance(to_native(u'føø'), text_type)
    # bytes
    assert isinstance(to_native(b'foo'), text_type)
    # nonascii bytes
    assert isinstance(to_native(b'f\xc3\xb8\xc3\xb8'), text_type)
    # nonascii bytes with unicode_body

# Generated at 2022-06-11 01:36:16.630956
# Unit test for function to_bytes
def test_to_bytes():
    # Non-ascii chars to test unicode handling
    a = u'\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e'
    b = u'\u6d4b\u8bd5'

    utf8_strings = (
        (b'abc123', 'abc123'),
        (u'abc123', 'abc123'),
        (b'\xc3\xa9', u'\xe9'),
        (a, a.encode('utf-8')),
        (b, b.encode('utf-8')),
        (b'\xff', '\xff'),
        (u'\ufffd', '\ufffd'),
    )

    for utf8_string, expected in utf8_strings:
        assert to_

# Generated at 2022-06-11 01:36:26.607529
# Unit test for function to_bytes
def test_to_bytes():
    # pylint: disable=unused-argument
    def make_bytes(obj):
        if hasattr(obj, 'encode'):
            return obj.encode('utf-8')
        return obj
    try:
        codecs.lookup_error(b'surrogateescape')
    except LookupError:
        HAS_SURROGATEESCAPE = False
    else:
        HAS_SURROGATEESCAPE = True

    if PY3:
        # If we're in python3, to_text should return text strings.
        assert isinstance(to_bytes(u'foo'), binary_type)

    # If we're dealing with text strings, we can encode to unicode
    # in simple ways.
    assert to_bytes('foo') == b'foo'

# Generated at 2022-06-11 01:36:35.331371
# Unit test for function to_bytes
def test_to_bytes():
    """
    TODO
    """
    import sys
    from ansible.module_utils.six import PY3
    from ansible.module_utils.pycompat24 import unichr

    if PY3:
        unicode_type = str

        def _u(s):
            return s

        def _b(s):
            return bytes(s, 'ascii')
    else:
        unicode_type = unicode

        def _u(s):
            return unicode(s, 'unicode_escape')

        def _b(s):
            return s

    class TestUnicode(unicode_type):
        def __repr__(self):
            return self.__class__.__name__

        __str__ = __repr__


# Generated at 2022-06-11 01:36:57.272394
# Unit test for function to_native
def test_to_native():

    # Test with non-string object
    obj = dict(a=1, b=2)
    nonstring = 'simplerepr'
    assert to_native(obj, nonstring) == str(obj)
    nonstring = 'passthru'
    assert to_native(obj, nonstring) is obj
    nonstring = 'empty'
    assert to_native(obj, nonstring) == ''
    nonstring = 'strict'
    try:
        to_native(obj, nonstring)
    except TypeError:
        pass
    else:
        raise AssertionError('Strict nonstring test failed')

    # Test unicode
    unistr = u'abc123'
    nonstring = 'simplerepr'
    assert to_native(unistr, nonstring) == str(unistr)
    nonstring

# Generated at 2022-06-11 01:37:07.860883
# Unit test for function to_bytes
def test_to_bytes():
    """
    unit test for to_bytes
    """
    assert to_bytes(u'string') == b'string'
    assert to_bytes(u'цф') == b'\xd1\x86\xd1\x84'
    assert to_bytes(u'string', 'UTF-16') == b'\xff\xfes\x00t\x00r\x00i\x00n\x00g\x00'

    assert to_bytes(b'string') == b'string'
    assert to_bytes(b'\xd1\x86\xd1\x84') == b'\xd1\x86\xd1\x84'

# Generated at 2022-06-11 01:37:18.772307
# Unit test for function to_native
def test_to_native():
    # assert(to_native("foo") == u"foo")
    assert(to_native(u"foo") == u"foo")
    assert(to_native(b"foo") == u"foo")
    assert(to_native(123) == u"123")
    assert(to_native(("foo", u"bar")) == u"('foo', 'bar')")
    assert(to_native(("foo", b"bar")) == u"('foo', 'bar')")
    assert(to_native(["foo", u"bar"]) == u"['foo', 'bar']")
    assert(to_native(["foo", b"bar"]) == u"['foo', 'bar']")
    assert(to_native({"foo": "bar"}) == u"{'foo': 'bar'}")

# Generated at 2022-06-11 01:37:29.183205
# Unit test for function jsonify
def test_jsonify():
    jsonify('{"a": "b"}')
    jsonify('{"a": "\u20ac"}')
    jsonify('{"a": "\u20ac"}', ensure_ascii=False)
    jsonify('{"a": "\u20ac"}', ensure_ascii=True)
    jsonify(u'{"a": "\u20ac"}')
    jsonify(u'{"a": "\u20ac"}', ensure_ascii=False)
    jsonify(u'{"a": "\u20ac"}', ensure_ascii=True)
    jsonify(u'{"a": "\u20ac"}', encoding='utf-8')
    jsonify(u'{"a": "\u20ac"}', encoding='utf-8', ensure_ascii=True)



# Generated at 2022-06-11 01:37:40.367977
# Unit test for function to_bytes
def test_to_bytes():
    for text_string in ('this is text', '中文測試'):
        text_string_as_bytes = to_bytes(text_string, 'utf-8')
        assert isinstance(text_string_as_bytes, binary_type)
        assert text_string_as_bytes == text_string.encode('utf-8')
        assert to_bytes(text_string_as_bytes, 'utf-8') == text_string.encode('utf-8')

        text_string_as_utf8 = to_bytes(text_string, 'utf-8', errors='surrogate_or_strict')
        assert isinstance(text_string_as_utf8, binary_type)
        assert to_bytes(text_string_as_utf8, 'utf-8') == text_string.en

# Generated at 2022-06-11 01:37:48.766900
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'abc') == b'abc'
    assert to_bytes(u'ácc') == b'\xc3\xa1cc'
    assert to_bytes(u'ácc', 'ascii', 'surrogate_or_strict') == b'\xc3\xa1cc'
    assert to_bytes(u'ácc', 'ascii') == b'?cc'
    assert to_bytes(u'ácc', 'ascii', 'surrogate_or_replace') == b'?cc'
    assert to_bytes(u'\udcec', 'ascii', 'surrogate_or_replace') == b'\xed\xb3\x8c'

# Generated at 2022-06-11 01:38:00.144083
# Unit test for function to_bytes
def test_to_bytes():
    assert isinstance(to_bytes(u''), binary_type)
    assert isinstance(to_bytes(b''), binary_type)
    assert isinstance(to_bytes(None), binary_type)
    assert isinstance(to_bytes(1), binary_type)
    assert isinstance(to_bytes(1), binary_type)

    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo', encoding='latin-1') == b'foo'
    assert to_bytes(u'foo', nonstring='simplerepr') == b"'foo'"
    assert to_bytes(u'foo', nonstring='empty') == b''
    assert to_bytes(u'foo', nonstring='passthru') == u'foo'

    assert to_bytes(u'foo\uffff')

# Generated at 2022-06-11 01:38:07.529539
# Unit test for function to_native
def test_to_native():
    assert isinstance(to_native(b'abc'), str)
    assert isinstance(to_native(u'abc'), str)
    assert isinstance(to_native(123), str)
    assert to_native(b'abc') == 'abc'
    assert to_native(u'abc') == 'abc'
    assert to_native(123) == '123'
    assert to_native(b'\xe3\x81\x82') == u'あ'.encode('utf-8')
    assert to_native(u'\u3042') == u'あ'.encode('utf-8')

# Generated at 2022-06-11 01:38:17.181010
# Unit test for function jsonify
def test_jsonify():
    # Test a basic encoding case that contains unicode
    value = to_bytes({'a': 'a'})
    # Test ansible.module_utils.basic.py from v2.5.5:
    #   File "/tmp/ansible_test/ansible/module_utils/basic.py", line 240, in jsonify
    #     return json.dumps(data, encoding=encoding, default=_indent_fallback, **kwargs)
    # TypeError: dumps() got an unexpected keyword argument 'encoding'
    if value == b'{"a": "a"}':
        return
    # Test the encoding with unicode values
    new_data = container_to_text(value)
    # Test ansible.module_utils.basic.py from v2.4.6:
    #   File "/tmp/ansible_

# Generated at 2022-06-11 01:38:26.260858
# Unit test for function to_bytes
def test_to_bytes():
    # Make sure that to_bytes always returns a byte string
    assert isinstance(to_bytes('123'), binary_type)
    assert isinstance(to_bytes(u'123'), binary_type)

    # Make sure that we can encode a text string to bytes
    assert to_bytes(u'this is a text string') == b'this is a text string'

    # Make sure that we can pass a byte string through
    # Note: We do this last because it's unusual
    assert to_bytes(b'this is a text string') == b'this is a text string'

    # Make sure that nonstring == 'passthru' is handled correctly
    assert to_bytes('abc', nonstring='passthru') == u'abc'
    assert to_bytes(u'abc', nonstring='passthru') == u'abc'

# Generated at 2022-06-11 01:38:45.165536
# Unit test for function to_native
def test_to_native():
    class Foo(object):
        def __str__(self):
            return u'foo'

    class Bar(object):
        def __repr__(self):
            return u'\u1234'

    # Note: Verify that non-native strings do not raise an error
    for non_native in (u'not native', u'\u1234'):
        assert to_native(non_native) == non_native

    # Note: Verify that non-native byte strings do not raise an error
    for non_native in (b'not native', b'\x00', b'\xff\xfe\xfd\xfc', b'\x12\x34'):
        assert to_native(non_native) == non_native

    # Note: Verify that native strings do not raise an error
    assert to_native('ok')

# Generated at 2022-06-11 01:38:55.687132
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(1) == b'1'
    assert to_bytes(object()) == b''

# Generated at 2022-06-11 01:38:59.346749
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'б', 'b': 'c'}

    result = jsonify(data)

    assert result == '{"a": "б", "b": "c"}'
    assert isinstance(result, str)


# Generated at 2022-06-11 01:39:08.644845
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foobar') == b'foobar'
    assert to_bytes(b'foobar') == b'foobar'
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='simplerepr') == b'1'
    assert to_bytes(u'\u5b54') == b'\xe5\xad\x94'
    assert to_bytes(b'\xe5\xad\x94') == b'\xe5\xad\x94'
    assert to_bytes(u'\u5b54', 'ascii') == b'\xe5\xad\x94'

# Generated at 2022-06-11 01:39:14.080806
# Unit test for function to_native
def test_to_native():
    assert to_native(None) is None
    assert to_native("something") == "something"
    assert to_native(u"something unicode") == "something unicode"

    class TestClass(object):
        def __str__(self):
            return "something"

    assert to_native(TestClass()) == "something"



# Generated at 2022-06-11 01:39:24.721412
# Unit test for function to_native
def test_to_native():
    # Test that a non-string doesn't raise exceptions
    assert to_native(1) == '1'
    # Test that string objects are not altered, except for surrogate
    # escapes
    assert to_native('foo') == 'foo'
    assert to_native('foo\xff') == u'foo\ufffd'
    assert to_native(u'foo\u0100') == u'foo\u0100'
    # Test that non-unicode string objects get decoded properly
    assert to_native('foo\xc3\xa9') == u'foo\xe9'
    assert to_native('foo\xc3\xa9'.encode('utf-8')) == u'foo\xe9'
    # Test that surrogate_then_replace handles surrogates correctly

# Generated at 2022-06-11 01:39:35.422433
# Unit test for function to_bytes
def test_to_bytes():
    nonstrings = (
        ('simplerepr', lambda x: x, lambda x: x, lambda x: x),
        ('empty', lambda x: '', lambda x: '', lambda x: ''),
        ('passthru', lambda x: x, lambda x: x, lambda x: x),
    )

    class Foo(object):
        def __str__(self):
            return 'str1'

        def __repr__(self):
            return 'repr1'

    class Bar(object):
        def __str__(self):
            return to_bytes('a')

        def __repr__(self):
            return to_bytes('b')

    class FooUnicode(object):
        def __str__(self):
            return to_text('str2')

        def __repr__(self):
            return