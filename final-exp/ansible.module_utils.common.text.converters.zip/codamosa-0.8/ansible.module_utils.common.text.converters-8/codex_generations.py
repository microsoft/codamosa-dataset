

# Generated at 2022-06-11 01:30:01.475274
# Unit test for function to_bytes
def test_to_bytes():
    # Test that it accepts byte strings
    assert to_bytes(b'foo', 'ascii') == b'foo'
    assert to_bytes(b'foo', nonstring='strict') == b'foo'

    # Test with text strings
    assert to_bytes(u'foo', 'ascii') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'ÞÆÝ', 'latin-1') == b'\xde\xc6\xdd'

    # Test that we can decode surrogates
    assert to_bytes(u'\udce2\udc90', 'latin-1', errors='surrogateescape') == b'foo'

    # Test surrogate then replace

# Generated at 2022-06-11 01:30:12.477258
# Unit test for function to_native
def test_to_native():
    """
    Test to_native function
    """
    str_value = unicode('foo')
    res = to_native(str_value)
    assert res == 'foo', 'to_native did not return str value'

    text_value = unicode('foo')
    res = to_native(text_value)
    assert res == 'foo', 'to_native did not return unicode value'

    if PY3:
        byte_value = bytes('foo', 'utf-8')
        res = to_native(byte_value)
        assert res == byte_value, 'to_native did not return byte value'
    else:
        byte_value = bytes('foo')
        res = to_native(byte_value)
        assert res == 'foo', 'to_native did not return str value'

    int_value = 10

# Generated at 2022-06-11 01:30:14.623982
# Unit test for function to_native
def test_to_native():
    class Foo(object):
        pass

    obj = Foo()
    obj.foo = 'bar'
    assert to_native(obj) == 'bar'


# Generated at 2022-06-11 01:30:19.372312
# Unit test for function jsonify
def test_jsonify():
  a = dict()
  a['a'] = 'a'
  a['b'] = 'b'
  a['c'] = 'c'
  # print(jsonify(a))
  # print(jsonify(a, indent=4))
  # print(jsonify(a, sort_keys=True, indent=4))



# Generated at 2022-06-11 01:30:27.822106
# Unit test for function to_bytes
def test_to_bytes():
    # Make sure byte strings and text strings don't change
    try:
        codecs.lookup_error('surrogateescape')
        HAS_SURROGATEESCAPE = True
    except LookupError:
        HAS_SURROGATEESCAPE = False

    assert to_bytes(b'foobar') == b'foobar'
    assert to_bytes(u'foobar') == b'foobar'

    # This is a good format for testing on Python 2.6 and 2.7
    for encoding in ('utf-8', 'utf-16', 'utf-32'):
        for errors in ('replace', 'strict', 'ignore'):
            assert to_bytes(u'foobar', encoding, errors) == b'foobar'

# Generated at 2022-06-11 01:30:37.750040
# Unit test for function to_native
def test_to_native():
    # pylint: disable=missing-docstring
    from ansible.module_utils._text import to_native

    assert to_native(b'\xe4\xbd\xa0\xe5\xa5\xbd') == u'\u4f60\u597d'
    assert to_native(b'123') == u'123'
    assert to_native(u'\xe4\xbd\xa0\xe5\xa5\xbd') == u'\u4f60\u597d'
    assert to_native(123) == u'123'
    # Non-ASCII Unicode fails
    try:
        to_native(u'\xe2\x98\xa0')
    except UnicodeError:
        pass
    else:
        assert False, 'Expected a UnicodeError'
    # encoding

# Generated at 2022-06-11 01:30:43.278571
# Unit test for function to_native
def test_to_native():
    """Test to_native function"""
    import sys

    if sys.version_info[0] == 2:
        expected = '\xe3\x82\xab\xe3\x83\xbc'
        value = u'\u30ab\u30fc'
        assert expected == to_bytes(to_native(value))

# end of unit test


# Generated at 2022-06-11 01:30:55.013575
# Unit test for function to_bytes
def test_to_bytes():
    try:
        codecs.lookup_error('surrogateescape')
        HAS_SURROGATEESCAPE = True
    except LookupError:
        HAS_SURROGATEESCAPE = False

    for text_string in [u'\U0001f4a9', u'abcde']:
        for errors in ['replace', 'ignore', 'surrogate_or_replace', 'surrogate_or_strict']:
            for encoding in ['utf-8', 'latin-1']:
                if encoding == 'utf-8' and HAS_SURROGATEESCAPE and errors == 'surrogate_or_replace':
                    continue
                if PY3 and encoding == 'latin-1' and errors == 'surrogate_or_replace':
                    continue

# Generated at 2022-06-11 01:31:03.578859
# Unit test for function jsonify
def test_jsonify():
    module = {'res': ''}
    data = {'a':'b', 'c':'d'}

# Generated at 2022-06-11 01:31:15.329578
# Unit test for function to_native
def test_to_native():
    """
    The to_native() function returns its argument decoded to
    the native str type (eg: unicode on py2, str on py3)
    """
    from ansible.module_utils import _text
    from ansible.module_utils._text import to_native

    # Dummy class to test for non-string values
    class FooTest(object):
        def __str__(self):
            return "FooTest"

        def __repr__(self):
            return "FooTest"

    # Test str types
    assert isinstance(to_native("Test"), str)
    assert isinstance(to_native("Test", method='strict'), str)
    assert isinstance(to_native("Test", method='simplerepr'), str)

# Generated at 2022-06-11 01:31:30.841878
# Unit test for function to_native
def test_to_native():
    # Test normal case
    r = to_native(u'\u5341\u5b57')
    assert isinstance(r, str)
    assert r == u'\u5341\u5b57'.encode('utf-8')
    # Test bytes case
    r = to_native(u'\u5341\u5b57'.encode('utf-8'))
    assert isinstance(r, str)
    assert r == u'\u5341\u5b57'.encode('utf-8')
    # Test non-string case with default setting
    r = to_native(1j)
    assert isinstance(r, str)
    assert r == str(1j)
    # Test non-string case with 'passthru' setting

# Generated at 2022-06-11 01:31:43.601102
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'123') == b'123'
    assert to_bytes(u'123') == b'123'
    assert to_bytes(u'¿123') == b'?123'
    assert to_bytes(u'¿123', errors='ignore') == b'123'
    assert to_bytes(u'¿123', errors='replace') == b'?123'
    assert to_bytes(u'\u03c0', errors='replace') == b'?'
    assert to_bytes(u'\u03c0', errors='xmlcharrefreplace') == b'&#960;'
    assert to_bytes(u'\u03c0', errors='surrogate_then_replace') == b'?'

# Generated at 2022-06-11 01:31:47.020666
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('abc') == '"abc"'
    assert jsonify(u'abc') == '"abc"'
    assert jsonify(u'\xe5') == '"\xc3\xa5"'



# Generated at 2022-06-11 01:31:48.021353
# Unit test for function to_native
def test_to_native():
    pass


# Unit test to_text function

# Generated at 2022-06-11 01:31:56.115853
# Unit test for function to_native
def test_to_native():

    # Note that we use the non ascii character U+0153 (œ) in these tests because
    # its utf-8 encoding uses multiple bytes.
    expected_unicode = u'\u0153\u0153'
    expected_str = b'\xc5\x93\xc5\x93'
    expected_str_utf8 = b'\xc5\x93\xc5\x93'
    expected_str_ascii = b'oeoe'

    # Test text strings with surrogates
    obj = u'\udcc3\udc93\udcc3\udc93'
    assert to_native(obj, encoding='ascii') == expected_str_ascii
    assert to_native(obj, encoding='ascii', nonstring='empty') == expected_str_ascii


# Generated at 2022-06-11 01:32:07.976508
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'string') == b'string'
    assert to_bytes(b'\xc3\x9f', 'utf-8') == b'\xc3\x9f'
    assert to_bytes(b'\xc3\xbf', 'latin-1') == b'\xc3\xbf'
    assert to_bytes(b'\xc3\x9f', 'latin-1', 'replace') == b'?'
    assert to_bytes(b'\xc3\x9f', 'latin-1', 'surrogate_or_replace') == b'?'
    assert to_bytes(to_text(b'\xc3\x9f', 'utf-8'), 'latin-1') == b'?'

# Generated at 2022-06-11 01:32:18.958060
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(False) == b'False'
    assert to_bytes(u'\u8d85\u7d21\u5f0f') == b'\xe8\xb6\x85\xe7\xb8\xa1\xe5\xbc\x8f'
    assert to_bytes(u'\u8d85\u7d21\u5f0f', encoding='latin-1') == b'\xe8\xb6\x85\xe7\xb8\xa1\xe5\xbc\x8f'
    assert to_bytes(u'\u8d85\u7d21\u5f0f', encoding='latin-1', errors='replace') == b'?\xe7?\x8f'

# Generated at 2022-06-11 01:32:26.491016
# Unit test for function jsonify
def test_jsonify():
    data = dict(
        key1="hello",
        key2=u"\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e"
    )
    myjson = jsonify(data)
    assert u"\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e" in myjson
    assert "key1" in myjson
    assert "hello" in myjson


# Generated at 2022-06-11 01:32:37.271017
# Unit test for function to_bytes
def test_to_bytes():
    # Tests that a string is returned
    assert isinstance(to_bytes('test string'), binary_type)

    # Tests that the correct value is returned and that the function is idempotent
    tests = {
        u'test string': 'test string',
        u'\U0001f4a9': u'\U0001f4a9'.encode('utf-8'),
        u'\u263a': u'\u263a'.encode('utf-8'),
        u'\uFEFF': u'\uFEFF'.encode('utf-8'),
    }

    for test, expected in iteritems(tests):
        assert to_bytes(test) == expected
        assert to_bytes(test) == to_bytes(to_bytes(test))

    # Tests that the latin-1 roundtrip gives back the same thing


# Generated at 2022-06-11 01:32:49.098787
# Unit test for function to_bytes
def test_to_bytes():
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    """Test to_bytes function"""
    # pylint: disable=too-many-locals
    from ansible.module_utils.common.unicode import to_bytes
    from ansible.module_utils.common.unicode import to_text

    if PY3:
        str_obj = str
        int_type = int
        long_type = int
    else:
        str_obj = unicode  # pylint: disable=undefined-variable
        int_type = int
        long_type = long

    # The following tests are taken from the stdlib's test_codecs.py

    # Testing byte input
    assert b'hello' == to_bytes(b'hello')
   

# Generated at 2022-06-11 01:33:10.056663
# Unit test for function to_bytes
def test_to_bytes():
    def to_bytes_helper(obj, encoding, errors, nonstring):
        if isinstance(obj, binary_type):
            # We often get bytes back for this as we ask for utf8 or ascii to encode data that
            # python already knows can be encoded in those.
            return obj
        else:
            return to_bytes(obj, encoding=encoding, errors=errors, nonstring=nonstring)

    # Default args
    # None
    assert to_bytes_helper(None, None, None, None) == b''

    # bytes
    assert to_bytes_helper(b'', None, None, None) == b''
    assert to_bytes_helper(b'a', None, None, None) == b'a'

# Generated at 2022-06-11 01:33:20.450575
# Unit test for function to_bytes
def test_to_bytes():
    import codecs
    codecs.register(lambda name: codecs.lookup('ascii') if name == 'cp65001' else None)
    # Test bytes, nonstring, simplerepr
    assert to_bytes(u'\xb5') == '\xc2\xb5'
    assert to_bytes(u'\xb5', nonstring='passthru') is u'\xb5'
    assert to_bytes(to_bytes('bytes'), nonstring='simplerepr') == 'bytes'
    # Test text, nonstring, simplerepr
    assert to_bytes(u'\u03bc') == '\xce\xbc'
    assert to_bytes(u'\u03bc', nonstring='passthru') is u'\u03bc'

# Generated at 2022-06-11 01:33:20.986124
# Unit test for function to_native
def test_to_native():
    pass



# Generated at 2022-06-11 01:33:32.035893
# Unit test for function to_native
def test_to_native():
    a = to_text(u'\xa9', errors='surrogate_or_strict')
    assert a == u'\ufffd'
    b = to_text(u'\xa9')
    assert b == u'\xa9'
    c = to_bytes(u'\ufffd')
    assert c == b'\ufffd'
    assert isinstance(c, binary_type)
    d = to_bytes(u'\xa9')
    assert d == b'\xc2\xa9'
    assert isinstance(d, binary_type)
    e = to_bytes(b'\xc2\xa9')
    assert e == b'\xc2\xa9'
    assert isinstance(e, binary_type)

# Generated at 2022-06-11 01:33:42.902000
# Unit test for function to_bytes
def test_to_bytes():
    """Unit test function to_bytes"""
    # These tests should be replaced with more exhaustive tests and moved to a
    # dedicated unit test module
    assert to_bytes(b'This is a byte string') == b'This is a byte string'
    assert to_bytes(b'This is a \xff byte string', errors='surrogate_then_replace') == b'This is a \ufffd byte string'
    assert to_bytes(b'This is a \xff byte string', errors='surrogate_or_replace') == b'This is a \ufffd byte string'
    assert to_bytes(b'This is a \xff byte string', errors='surrogate_or_strict') == b'This is a \ufffd byte string'
    #assert to_bytes(b'This is a \xff byte string') == b'This is a \

# Generated at 2022-06-11 01:33:53.752637
# Unit test for function to_native
def test_to_native():
    # Test that we can go from text to native, bytes to native, and have a
    # default fallback
    # Test both unicode and text strings
    for text in (u'€', '€'):
        assert to_native(text) == text
        # b'euro sign'
        assert to_native(b'\xe2\x82\xac') == text
    # Test that we can go from ints to text
    assert to_native(2) == '2'
    assert to_native(2, nonstring='strict') == '2'
    try:
        to_native(2, nonstring='empty')
    except TypeError as e:
        assert 'obj must be a string type' in to_text(e)
    # Test that we can go from str to bytes w/o surrogates and w/ surrogates

# Generated at 2022-06-11 01:34:04.700269
# Unit test for function to_native
def test_to_native():
    type_fail = TypeError
    import pytest
    # Python 2
    if PY3:
        type_fail = ValueError
    assert to_native(b'foo') == 'foo'
    assert to_native(b'foo', nonstring='passthru') == b'foo'
    assert to_native(b'foo', nonstring='empty') == ''
    assert to_native(b'foo', nonstring='strict') == TypeError
    assert to_native(b'foo', nonstring='simplerepr') == "'foo'"
    assert to_native(u'foo') == 'foo'
    assert to_native(u'foo', nonstring='passthru') == u'foo'
    assert to_native(u'foo', nonstring='empty') == ''

# Generated at 2022-06-11 01:34:13.541592
# Unit test for function to_bytes
def test_to_bytes():
    if PY3:
        # See if surrogate escapes work
        assert to_bytes(u'\udcff') == b'\xed\xb3\xbf'
        # Make sure surrogate or strict doesn't traceback for invalid strings
        assert to_bytes(u'\udcff', errors='surrogate_or_strict') == b'\xed\xb3\xbf'
        assert to_bytes(u'\udcff', errors='surrogate_or_replace') == b'\x3f'
        assert to_bytes(u'\udcff\udcff', errors='surrogate_then_replace') == b'??'

# Generated at 2022-06-11 01:34:25.063728
# Unit test for function jsonify
def test_jsonify():
    # Dictionary with valid unicode strings for JSON serialization.
    data = {"key": "value"}
    assert jsonify(data) == "{\"key\": \"value\"}"

    # Dictionary with non-ASCII char for JSON serialization.
    data = {"key": to_bytes("\xc3\xa1")}
    assert jsonify(data) == "{\"key\": \"\xc3\xa1\"}"

    # Dictionary with non-ASCII char for JSON serialization.
    data = {"key": to_bytes("\xc3\xa1")}
    assert jsonify(data) == "{\"key\": \"\xc3\xa1\"}"

    # Dictionary with mixed unicode strings for JSON serialization.

# Generated at 2022-06-11 01:34:34.532590
# Unit test for function to_bytes
def test_to_bytes():
    text_string = 'testing \N{SNOWMAN}'
    text_string_with_bad_char = u'testing \xff'
    bad_char = '\xff'
    utf8_string = text_string.encode('utf-8')
    utf8_string_with_bad_char = text_string_with_bad_char.encode('utf-8')
    utf8_string_with_gd_char = text_string_with_bad_char.encode('utf-8', 'replace')
    utf8_string_with_gd_char_2 = text_string_with_bad_char.encode('utf-8', 'surrogate_then_replace')
    latin1_string = text_string.encode('latin-1')
    latin1_string_with_

# Generated at 2022-06-11 01:34:45.410961
# Unit test for function to_native
def test_to_native():
    assert to_native(None) == 'None'
    assert to_native([]) == '[]'
    assert to_native({}) == '{}'
    assert to_native('a') == 'a'
    assert to_native(b'a') == 'a'



# Generated at 2022-06-11 01:34:55.700197
# Unit test for function to_bytes
def test_to_bytes():
    # Note: Python-2.4 doesn't have b''
    assert to_bytes('\xc3\xb1', 'utf-8') == b'\xc3\xb1'
    assert to_bytes(u'\xc3\xb1', 'utf-8') == to_bytes('\xc3\xb1')
    assert to_bytes('\xc3\xb1') == b'\xc3\xb1'
    assert to_bytes(u'\xc3\xb1') == b'\xc3\xb1'
    assert to_bytes(b'\xc3\xb1') == b'\xc3\xb1'

    assert to_bytes('\xc3\xb1', 'latin-1') == b'\xc3\xb1'

# Generated at 2022-06-11 01:35:00.821052
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'hi') == b'hi'
    assert to_bytes('hi') == b'hi'
    assert to_bytes(b'hi') == b'hi'
    assert to_bytes(123) == b'123'
    assert to_bytes(datetime.datetime.now()) == str(datetime.datetime.now()).encode('utf-8')



# Generated at 2022-06-11 01:35:12.945449
# Unit test for function jsonify
def test_jsonify():
    # Test different types of text string
    assert jsonify('str') == '"str"'
    assert jsonify(u'unicode') == '"unicode"'
    assert jsonify(u'\u2191') == u'"\u2191"'
    assert jsonify(b'bytes\xe2\x91') == '"bytes\\u2191"'
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'
    assert jsonify(None) == 'null'
    assert jsonify(True) == 'true'
    assert jsonify(False) == 'false'
    assert jsonify(dict(a=1)) == '{"a": 1}'
    assert jsonify(Set([1, 2, 3])) == '[1, 2, 3]'

# Generated at 2022-06-11 01:35:22.195437
# Unit test for function jsonify
def test_jsonify():
    # Test for different datatypes
    data = dict()
    data["string"] = "blah"
    data["integer"] = 3
    data["float"] = 3.14
    data["dict"] = dict()
    data["list"] = list()
    data["none"] = None
    
    result = jsonify(data)
    assert result == '{"string": "blah", "integer": 3, "float": 3.14, "dict": {}, "list": [], "none": null}'
    
    # Test for unicode
    data = u'\u2713' 
    result = jsonify(data)
    assert result == '"\u2713"'
    
    # Test for unicode inside a string
    data = "blah \u2713 blah"
    result = jsonify(data)
   

# Generated at 2022-06-11 01:35:29.165788
# Unit test for function jsonify
def test_jsonify():
    data = {
        u'foo': u'\u2713',
        u'bar': [u'baz', dict(quux=u'qux')],
        u'set': set([1, 2, 3]),
        u'datetime': datetime.datetime(2014, 1, 20, 18, 31, 0)
    }
    encoded = jsonify(data)
    decoded = json.loads(encoded)
    assert data == decoded



# Generated at 2022-06-11 01:35:33.281310
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_text
    '''Return native string'''
    value = to_text(b'{"example": 1}', errors='surrogate_or_strict')
    assert value == u'{"example": 1}'
    

# Generated at 2022-06-11 01:35:42.429936
# Unit test for function to_native
def test_to_native():
    assert 'éà' == to_native('\xc3\xa9\xc3\xa0'.decode('utf-8'))
    assert 'éà' == to_native('\xc3\xa9\xc3\xa0')
    assert 'éà' == to_native(u'éà')
    assert 'éà' == to_native(u'\xc3\xa9\xc3\xa0'.encode('utf-8'))
    assert 'None' == to_native(None)
    assert '1' == to_native(1)
    assert '1' == to_native(int(1))
    assert '1.1' == to_native(int(1.1))

# Generated at 2022-06-11 01:35:52.656007
# Unit test for function jsonify
def test_jsonify():
    assert(jsonify({'a': 'b', 'c': [1,2,3]}, sort_keys=True) == '{"a": "b", "c": [1, 2, 3]}')
    assert(jsonify({'a': 'b', 'c': [1,2,3]}, sort_keys=True, indent=4) == '{\n    "a": "b", \n    "c": [\n        1, \n        2, \n        3\n    ]\n}')
    assert(jsonify({'a': 'b', 'c': [1,2,3]}, sort_keys=True, separators=('',':')) == '{"a":"b","c":[1,2,3]}')

# Generated at 2022-06-11 01:36:02.912784
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('hello', 'ascii') == b'hello'
    assert to_bytes('hell\xe9', 'ascii') == b'hello'
    assert to_bytes('hell\xe9', 'ascii', 'strict') == b'hello'

    assert to_bytes('hello', 'utf-8') == b'hello'
    assert to_bytes(b'hello', 'utf-8') == b'hello'

    try:
        to_bytes('hello')
    except TypeError:
        assert PY3
    else:
        # Py2 u'hello' implicitly decodes to ascii before trying to encode to utf-8
        assert to_bytes('hello') == b'hello'


# Generated at 2022-06-11 01:36:18.347247
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.six import b, u
    from ansible.module_utils.six import PY2

    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'Ünicode', 'latin-1') == b'\xc3\x9cnicode'
    assert to_bytes(123, nonstring='passthru') == 123
    assert to_bytes(123, nonstring='empty') == b''
    assert to_bytes({'foo': u'bar'}, nonstring='simplerepr') == b'{\'foo\': \'bar\'}'

# Generated at 2022-06-11 01:36:28.448993
# Unit test for function jsonify
def test_jsonify():
    assert jsonify("test") == "\"test\""
    assert jsonify(u"test") == "\"test\""
    assert jsonify("test", sort_keys=True) == "\"test\""
    assert jsonify(u"test", sort_keys=True) == "\"test\""
    assert jsonify("test", sort_keys=False) == "\"test\""
    assert jsonify(u"test", sort_keys=False) == "\"test\""
    assert jsonify("test", sort_keys=False, indent=1) == "\"test\""
    assert jsonify(u"test", sort_keys=False, indent=1) == "\"test\""
    assert jsonify({"test":1}) == "{\"test\": 1}"

# Generated at 2022-06-11 01:36:36.352949
# Unit test for function to_native
def test_to_native():

    obj = 'str'
    assert to_native(obj) == obj

    obj = u'unicode str'
    assert to_native(obj) == obj

    obj = [1, 2, 3]
    assert to_native(obj) == obj

    obj = (1, 2, 3)
    assert to_native(obj) == obj

    obj = {'a': 1, 'b': 2}
    assert to_native(obj) == obj

    obj = {'a': 1, 'b': 2, 'c': 3}
    assert to_native(obj) == obj

    obj = {u'unicode_key': u'unicode_value'}
    assert to_native(obj) == obj


# Generated at 2022-06-11 01:36:47.119429
# Unit test for function jsonify
def test_jsonify():
    my_dict = {u'hey': u'I am a unic\u00f8de value'}
    my_list = [u'I am a unic\u00f8de value', 'this is a byte string']
    my_set = set(my_list)

    result = jsonify(my_dict)
    assert result == u'{"hey": "I am a unic\u00f8de value"}'

    result = jsonify(my_list)
    assert result == u'["I am a unic\u00f8de value", "this is a byte string"]'

    result = jsonify(my_set)
    assert json.loads(result) == [u'I am a unic\u00f8de value', 'this is a byte string']



# Generated at 2022-06-11 01:36:57.860575
# Unit test for function jsonify

# Generated at 2022-06-11 01:37:01.537617
# Unit test for function jsonify
def test_jsonify():
    ut_data = {u'a': 1, u'b': 1.23, u'c': u'\u2026', u'd': datetime.datetime(2014, 9, 22)}
    assert jsonify(ut_data) == '{"a": 1, "c": "...", "b": 1.23, "d": "2014-09-22T00:00:00"}'



# Generated at 2022-06-11 01:37:14.082052
# Unit test for function jsonify
def test_jsonify():
    import json
    data_utf8 = {
        u'あ'.encode(u'utf-8'): {u'い'.encode(u'utf-8'): u'う'.encode(u'utf-8')}
    }
    data_latin1 = {
        u'あ'.encode(u'latin-1'): {u'い'.encode(u'latin-1'): u'う'.encode(u'latin-1')}
    }
    data_base64 = {
        b'\xe3\x81\x82'.decode(u'base64'): {b'\xe3\x81\x84'.decode(u'base64'): b'\xe3\x81\x86'.decode(u'base64')}
    }
    data

# Generated at 2022-06-11 01:37:21.880879
# Unit test for function to_bytes

# Generated at 2022-06-11 01:37:33.710559
# Unit test for function jsonify

# Generated at 2022-06-11 01:37:44.079973
# Unit test for function to_native
def test_to_native():
    things = [
        b'foo',
        u'foo',
        3,
        dict(foo=u'bar'),
        u'\u10000',
        {b'foo': 'bar'},
    ]
    if PY3:
        expected = [
            'foo',
            'foo',
            3,
            {'foo': 'bar'},
            '\U00010000',
            {'foo': 'bar'},
        ]
    else:
        expected = [
            u'foo',
            u'foo',
            3,
            {u'foo': u'bar'},
            u'\u10000',
            {'foo': u'bar'},
        ]

    for thing, result in zip(things, expected):
        assert to_text(thing) == result



# Generated at 2022-06-11 01:38:04.283162
# Unit test for function jsonify
def test_jsonify():
    # test the function with basic data structures
    assert jsonify({}) == '{}'
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify([1, 2, 3]) == '[1, 2, 3]'

    # test that the function will attempt to encode a string with
    # a different encoding and try again if it fails.
    data = '\u039a\u0391\u03a3\u03a3\u0395'
    # data.decode('utf-8') will raise UnicodeDecodeError
    assert jsonify(data, encoding='latin-1') == '"\u039a\u0391\u03a3\u03a3\u0395"'

    # test that the function will attempt to JSONify a container with
    # a different

# Generated at 2022-06-11 01:38:11.618845
# Unit test for function to_native
def test_to_native():
    # Test a regular text string
    assert to_native('\xe5\x86\x87') == '冇'

    # Test a regular byte string
    assert to_native(b'\xe5\x86\x87') == '冇'

    # Test with an invalid encoding
    try:
        result = to_native('\xe5\x86\x87', 'ascii')
        raise AssertionError('to_native did not raise exception when given invalid encoding')
    except UnicodeDecodeError:
        pass

    # Test with an invalid encoding but a fallback error handler
    assert to_native('\xe5\x86\x87', 'ascii', 'replace') == '?'

    # Test a text string that has a surrogate pair

# Generated at 2022-06-11 01:38:19.552211
# Unit test for function to_native

# Generated at 2022-06-11 01:38:27.600506
# Unit test for function to_native
def test_to_native():
    assert to_native(1) == 1
    assert to_native(1, nonstring='passthru') == 1
    assert to_native('foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    if PY3:
        assert to_native(b'foo') == 'foo'
    else:
        assert to_native(b'foo') == b'foo'
    assert to_native('foo', nonstring='passthru') == 'foo'
    assert to_native(u'foo', nonstring='passthru') == u'foo'
    assert to_native(b'foo', nonstring='passthru') == b'foo'
    assert to_native(1, nonstring='strict') == 1

# Generated at 2022-06-11 01:38:39.048306
# Unit test for function to_bytes
def test_to_bytes():
    from py.test import raises

    assert to_bytes('foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes('foo', errors=None) == b'foo'
    assert to_bytes(u'foo', errors='replace') == b'foo'

    if PY3:
        # Python 3 doesn't have surrogates
        assert to_bytes(u'\udc00', errors='surrogateescape') == b'\x00'
        # On python 3, surrogateescape is always valid
        assert to_bytes(u'\udc00', errors='surrogate_or_strict') == b'\x00'

# Generated at 2022-06-11 01:38:39.591284
# Unit test for function to_native
def test_to_native():
    pass



# Generated at 2022-06-11 01:38:50.788974
# Unit test for function to_bytes
def test_to_bytes():
    b_str = u'בדיקה'
    # If we have surrogateescape support, use it
    if HAS_SURROGATEESCAPE:
        expected_bytes = b_str.encode('utf-8', 'surrogateescape')  # binary string
        assert to_bytes(expected_bytes, encoding='utf-8', errors='surrogate_or_strict') == expected_bytes
        assert to_bytes(expected_bytes, encoding='utf-8', errors='surrogate_or_replace') == expected_bytes
        assert to_bytes(expected_bytes, encoding='utf-8', errors='surrogate_then_replace') == expected_bytes
        assert to_bytes(expected_bytes, 'cp1256', errors='surrogate_then_replace') == expected_bytes

# Generated at 2022-06-11 01:38:58.772465
# Unit test for function to_native
def test_to_native():
    assert to_native(u'hello') == u'hello'
    assert to_native(u'ü') == u'ü'
    assert to_native(b'hello') == u'hello'
    assert to_native(b'\xc3\xbc') == u'ü'
    if PY3:
        assert to_native(u'\u1234') == u'\u1234'
        assert to_native(b'\xe1\x88\xb4') == u'\u1234'
    #dates
    assert to_native(datetime.datetime(2016, 10, 10, 20, 59, 46, 252689)) == '2016-10-10 20:59:46.252689'

# Generated at 2022-06-11 01:39:08.417771
# Unit test for function to_native
def test_to_native():
    # Note that in python3, native strings are text and are unicode.  When
    # testing against python2, we have to explicitly say python3 will use
    # unicode for its strings.
    if PY3:
        unicode_type = str
    else:
        unicode_type = unicode

    # Confirm that we can take ascii text, utf-8 bytes, and unicode text and return
    # native strings.  We test unicode in python2 because we may have already
    # had to convert to unicode to get here
    assert to_native(b'ascii') == 'ascii'
    assert isinstance(to_native(b'ascii'), str)
    assert to_native(u'ascii') == 'ascii'

# Generated at 2022-06-11 01:39:19.689122
# Unit test for function jsonify
def test_jsonify():
    if PY3:
        b_data = dict(a=1, b='ascii', c=b'bytes', d=u'unicode')
    else:
        b_data = dict(a=1, b='ascii', c=b'bytes', d='unicode')
    return_data = jsonify(b_data)
    assert isinstance(return_data, text_type)
    assert return_data == '{"a": 1, "b": "ascii", "c": "bytes", "d": "unicode"}'
    test_list = [set([1, 2, 3]), set([4, 5, 6])]
    return_list = jsonify(test_list)
    assert isinstance(return_list, text_type)

# Generated at 2022-06-11 01:39:37.004834
# Unit test for function to_native
def test_to_native():
    """
    This test makes sure that when we decode an encoded string that
    it gives us the original string back
    """
    utf8_string = u'\u2713'
    utf8_bytes = b'\xe2\x9c\x93'

    if PY3:
        assert to_native(utf8_bytes) == utf8_string
        assert to_native(utf8_string) == utf8_string
    else:
        assert to_native(utf8_bytes) == utf8_bytes
        assert to_native(utf8_string) == utf8_bytes

