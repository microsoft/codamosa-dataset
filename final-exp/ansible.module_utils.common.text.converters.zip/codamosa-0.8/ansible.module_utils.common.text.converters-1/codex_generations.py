

# Generated at 2022-06-11 01:29:58.129031
# Unit test for function to_bytes
def test_to_bytes():
    import datetime
    import os

    # Test strings that are valid in utf-8
    # Test ascii
    assert to_bytes('hi there') == b'hi there'
    # Test single byte utf-8 characters
    assert to_bytes('my quote is " to escape') == b'my quote is " to escape'
    # Test multibyte utf-8 characters
    assert to_bytes('\u2588\u2588\u2588') == b'\xe2\x96\x88\xe2\x96\x88\xe2\x96\x88'
    # Test that surrogates pass through

# Generated at 2022-06-11 01:30:03.010883
# Unit test for function to_native
def test_to_native():
    assert to_native(b'abc') == 'abc'
    assert to_native(u'abc') == 'abc'

    assert to_native(b'\xc3\xa4') == u'ä'
    assert to_native(u'\xe4') == u'ä'


# Generated at 2022-06-11 01:30:11.140520
# Unit test for function jsonify
def test_jsonify():
    import unittest
    import datetime
    class TestJsonify(unittest.TestCase):
        def test_encode_set(self):
            s = Set([1, 2, 3, 4])
            self.assertEqual(jsonify(s), '[1, 2, 3, 4]')

        def test_encode_datetime(self):
            now = datetime.datetime.utcnow()
            self.assertEqual(jsonify(now), to_native(now.isoformat()))
    unittest.main()



# Generated at 2022-06-11 01:30:18.397844
# Unit test for function jsonify
def test_jsonify():
    """
    Test jsonify
    """
    import datetime
    t = "2013-06-04T18:46:10.907279"

# Generated at 2022-06-11 01:30:27.452442
# Unit test for function to_bytes
def test_to_bytes():
    """This is a separate function so that doctest can test it"""
    # Test with various input encodings
    assert to_bytes('Hello', 'ascii') == b'Hello'
    assert to_bytes('Привет', 'utf-8') == b'\xd0\x9f\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    assert to_bytes(u'\u1234', 'utf-16') == b'\xff\xfe4\x12'

    # Test byte strings
    assert to_bytes(b'Hello', 'ascii') == b'Hello'
    assert to_bytes(b'\xd0\x9f', 'ascii') == b'\xd0\x9f'
   

# Generated at 2022-06-11 01:30:34.153082
# Unit test for function jsonify
def test_jsonify():
    obj = {u'foo': u'bar'}
    assert jsonify(obj) == '{"foo": "bar"}'

    # This will fail with a json.dumps TypeError, not with a UnicodeEncodeError
    # like the old code would have done
    obj = {u'foo': b'bar'}
    assert jsonify(obj) == '{"foo": "bar"}'


# The conversion of entities to text is a common idiom in our code

# Generated at 2022-06-11 01:30:44.799341
# Unit test for function jsonify
def test_jsonify():
    # test exception
    try:
        jsonify('bad_data')
        assert False, "failed to raise exception on bad data"
    except UnicodeError:
        pass

    # test data
    assert '"bad_data"' == jsonify(u'bad_data')
    assert '3.1415' == jsonify(3.1415)

    # test data with datetime
    testdata = { 'now': datetime.datetime.now()}
    jsonstr = jsonify(testdata)
    newdata = json.loads(jsonstr)
    assert testdata['now'].isoformat() == newdata['now']

    # test data with set
    testdata = { 'set': set(['a', 'b'])}
    jsonstr = jsonify(testdata)
    newdata = json.loads(jsonstr)


# Generated at 2022-06-11 01:30:50.026433
# Unit test for function to_bytes
def test_to_bytes():
    import sys
    from multiprocessing import Value, Array

    # Test with a byte string
    assert to_bytes('hello') == b'hello'

    # Test with a text string
    assert to_bytes(u'hello') == b'hello'

    # Test with surrogates.  This is the big one because we should never traceback
    # We should never traceback and we always encode the replacement character
    assert to_bytes(u'\udcc3') == b'?'

    # Test with an invalid encoding
    try:
        to_bytes(u'\udcc3', encoding='cp424')
    except UnicodeEncodeError:
        pass
    else:
        assert False, 'Expected to_bytes to traceback'

    # Test with a nonstring object
    assert to_bytes(42) == b'42'

    #

# Generated at 2022-06-11 01:30:54.569036
# Unit test for function to_bytes
def test_to_bytes():
    def _test_to_bytes(obj, expected, valid_encodings=None, valid_errors=None):
        valid_encodings = valid_encodings or ('utf-8', 'latin-1', 'cp037')
        valid_errors = valid_errors or ('strict', 'replace', 'ignore')

        for encoding in valid_encodings:
            for errors in valid_errors:
                result = to_bytes(obj, encoding, errors)
                assert isinstance(result, binary_type), \
                    'result of to_bytes not bytes.  Got %s when encoding with %s and errors=%s' % (
                        type(result), encoding, errors)

# Generated at 2022-06-11 01:31:02.139105
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    data = {"a": "b"}
    data2 = container_to_text(data)
    assert jsonify(data2) == '{"a": "b"}'
    assert jsonify(data.items()) == '[[["a", "b"]]]'
    assert jsonify(data.items(), sort_keys=True) == '[[["a", "b"]]]'
    data = Set(["a", "b"])
    assert jsonify(data) == '["a", "b"]'
    assert jsonify(data, sort_keys=True) == '["a", "b"]'

# Generated at 2022-06-11 01:31:19.802131
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foobar') == u'foobar'
    assert to_native(b'foobar') == u'foobar'
    assert to_native(1) == u'1'
    assert to_native(open(__file__)) == u'<open file \'%s\', mode \'r\' at %s>' % (__file__, hex(id(open(__file__))))
    assert to_native(Exception('foobar')) == u'foobar'
    assert to_native(Exception(u'foobar')) == u'foobar'
    assert to_native(Exception(b'foobar')) == u'foobar'
    assert to_native((1, 2, 3)) == u'(1, 2, 3)'

# Generated at 2022-06-11 01:31:29.267079
# Unit test for function to_bytes
def test_to_bytes():
    for string in [u"unicode", b"byte"]:
        assert to_bytes(string) == string.encode('utf-8')
    assert to_bytes(u"\u00a9", encoding='latin-1') == u"\u00a9".encode('latin-1')
    assert to_bytes(u"\u00a9", encoding='ascii') == u"\u00a9".encode('utf-8', 'replace')
    assert to_bytes(u"\u00a9", encoding='ascii', errors='ignore') == b''

    try:
        to_bytes(u"\u00a9", encoding='ascii')
    except UnicodeEncodeError:
        pass

# Generated at 2022-06-11 01:31:41.717869
# Unit test for function to_bytes
def test_to_bytes():
    # bytes should be passed through as-is
    assert to_bytes(b'foo') == b'foo'

    # unicode should be encoded as utf-8
    assert to_bytes(u'foo') == b'foo'

    # obj should be coerced to a unicode string, then encoded
    assert to_bytes(42, nonstring='simplerepr') == b'42'

    # We detect surrogates in unicode strings and don't traceback when
    # encoding them under Python3
    assert to_bytes(u'\udce4'.encode('utf-8').decode('utf-8'), errors='surrogate_or_replace', nonstring='strict') == u'\udce4'.encode('utf-8')

    # We can handle surrogates with an arbitrary encoding under Python3

# Generated at 2022-06-11 01:31:52.095700
# Unit test for function to_native

# Generated at 2022-06-11 01:32:03.135712
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.common._collections_compat import BytesIO, StringIO

    # Plain objects
    assert to_bytes(1) == b'1'
    assert to_bytes(True) == b'True'
    assert to_bytes(1.1) == b'1.1'

    # Iterables
    assert to_bytes([1, 2, 3]) == b'[1, 2, 3]'
    assert to_bytes((1, 2, 3)) == b'[1, 2, 3]'
    assert to_bytes(set([1, 2, 3])) == b'[1, 2, 3]'
    assert to_bytes(frozenset([1, 2, 3])) == b'[1, 2, 3]'

    # Mappings

# Generated at 2022-06-11 01:32:14.712856
# Unit test for function to_bytes
def test_to_bytes():
    # Testing PY3 behavior
    on_py3 = True

    # to_bytes() accepts unicode and returns bytes
    assert isinstance(to_bytes('foo\u1234'), binary_type)
    assert to_bytes('foo\u1234') == 'foo\xe1\x88\xb4'
    assert to_bytes('foo\u1234'.encode('utf-8')) == 'foo\xe1\x88\xb4'

    # to_bytes() accepts bytes and returns bytes
    assert to_bytes('foo') == 'foo'
    assert to_bytes(u'foo') == 'foo'
    assert to_bytes(b'foo') == b'foo'

    # to_bytes() uses the requested encoding
    assert to_bytes('foo\u1234', 'ascii') == 'foo?'
   

# Generated at 2022-06-11 01:32:21.087460
# Unit test for function jsonify
def test_jsonify():
    test_dict = {"key1": "value1",
                 "key2": "value2",
                 "key3": u"value3\xa5\u1234\u20ac\u200b",
                 }
    results = jsonify(test_dict)
    assert isinstance(results, text_type)
    assert results == u'{"key1": "value1", "key2": "value2", "key3": "value3\\u00a5\\u1234\\u20ac\\u200b"}'



# Generated at 2022-06-11 01:32:33.921521
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.basic import AnsibleModule
    source = set((u'four', u'áéíóú', u's', u'\U0001f4a9', b'four', b'\xe1\xe9\xed\xf3\xfa', b's', b'\xf0\x9f\x92\xa9'))
    from_source = set((b'four', b'\xc3\xa1\xc3\xa9\xc3\xad\xc3\xb3\xc3\xba', b's', b'\xf0\x9f\x92\xa9', u'four', u'\xe1\xe9\xed\xf3\xfa', u's', u'\U0001f4a9'))

# Generated at 2022-06-11 01:32:46.189584
# Unit test for function to_bytes
def test_to_bytes():

    assert to_bytes(u'foobaz') == b'foobaz'
    assert to_bytes(u'foobaz', errors='ignore') == b'foobaz'
    assert to_bytes(u'foobaz', encoding='latin-1', errors='surrogate_or_replace') == b'foobaz'
    assert to_bytes(b'foobaz') == b'foobaz'
    assert to_bytes(b'foobaz', errors='ignore') == b'foobaz'
    assert to_bytes(b'foobaz', encoding='latin-1', errors='surrogate_or_replace') == b'foobaz'


# Generated at 2022-06-11 01:32:52.219338
# Unit test for function to_native
def test_to_native():
    if PY3:
        # On Python3, the native string type is unicode
        assert to_native('Hello') == 'Hello'
        assert to_native(u'Hello') == 'Hello'
        assert to_native(b'Hello') == 'Hello'
    else:
        # On Python2, the native string type is bytes
        assert to_native('Hello') == 'Hello'
        assert to_native(u'Hello') == 'Hello'
        assert to_native(b'Hello') == b'Hello'



# Generated at 2022-06-11 01:33:04.161365
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native

# Generated at 2022-06-11 01:33:16.129024
# Unit test for function to_native
def test_to_native():
    def n(obj, encoding='utf-8', errors='surrogate_then_replace'):
        return to_native(obj, encoding=encoding, errors=errors)

    assert n('abc') == 'abc'
    assert n(u'abc') == 'abc'
    assert n(b'abc') == 'abc'
    assert n('\xe9') == '\xe9'
    assert n(u'\xe9') == '\xe9'
    assert n(b'\xe9') == '\xe9'
    assert n(b'\xff') == '\ufffd'
    assert n(b'\xff', errors='ignore') == ''
    assert n(b'\xff', errors='replace') == '\ufffd'

# Generated at 2022-06-11 01:33:23.326817
# Unit test for function to_bytes
def test_to_bytes():
    # The to_text function is fully tested in test_common_unicode.py
    # This is just a test to verify the basics of the to_bytes function.
    # We do need to test byte strings, text strings, and nonstrings
    assert to_bytes(u'test') == b'test'
    assert to_bytes(u'\u00a3') == b'\xc2\xa3'
    assert to_bytes(b'test') == b'test'
    assert to_bytes(b'\xc2\xa3') == b'\xc2\xa3'
    class TestClass(object):
        pass

    assert to_bytes(TestClass()) == b"<class 'ansible.module_utils.common.TestClass'>"



# Generated at 2022-06-11 01:33:34.988021
# Unit test for function to_native
def test_to_native():
    # When using PY3, we should have a text type, otherwise
    # we will have a byte type
    # On PY2, the basic string doesn't have a decode method,
    # but the unicode string does, so this helps us pick between
    # the two
    if hasattr(u'str', 'decode'):
        text_type = unicode
    else:
        text_type = str

    # Test on a number of different types
    ntext_types = (text_type, bytes)
    ntext_none_types = (text_type, bytes, type(None))

    # Confirm that we always get back an object with the same type

# Generated at 2022-06-11 01:33:39.605731
# Unit test for function to_native
def test_to_native():
    some_undecodable_string=b'\xc3\x28'
    utf8_string=to_text(some_undecodable_string, errors='surrogate_or_replace', nonstring='empty')
    assert utf8_string == u'\ufffd\ufffd('



# Generated at 2022-06-11 01:33:43.444158
# Unit test for function jsonify
def test_jsonify():
    data={'a': 1, 'b': 2, 'c': 3}
    print('data:', data)
    print('jsonify:', jsonify(data))
    data = '中文'
    print('data:', data)
    print('jsonify:', jsonify(data))



# Generated at 2022-06-11 01:33:49.038585
# Unit test for function to_bytes
def test_to_bytes():
    '''
    Test the to_bytes function.
    '''
    # For coverage, test all code paths
    def _test_decoding(obj, encoding, errors, nonstring):
        '''
        Test one combination of inputs.
        '''
        try:
            returned_bytes = to_bytes(obj, encoding, errors, nonstring)
        except TypeError:
            if nonstring == 'strict':
                pass
            else:
                raise

        if isinstance(returned_bytes, binary_type):
            returned_bytes.decode(encoding, errors)


# Generated at 2022-06-11 01:34:00.483525
# Unit test for function jsonify
def test_jsonify():
    # Test data
    valid_utf8_data = u"{ \"foo\": \"\u2603\" }"
    invalid_utf8_data = u"{ \"foo\": \"\ud83d\udca9\" }".encode("utf-8")
    invalid_latin1_data = u"{ \"foo\": \"\ud83d\udca9\" }".encode("latin-1")

    def _test(data):
        jsonified = jsonify(data)
        assert isinstance(jsonified, text_type)
        # If this test is failing and you're on a Python version that supports
        # surrogateescape (Python 3.3+) you can try this to see where it's going
        # wrong:
        #
        #     print("\nInput:")
        #     print(data)
        #     print("

# Generated at 2022-06-11 01:34:10.639271
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes('hello', errors='replace') == b'hello'
    assert to_bytes(u'\u2297', errors='replace') == b'?'
    assert to_bytes(u'\u2297', errors='surrogate_or_strict') == u'\u2297'.encode('utf-8', 'surrogateescape')
    assert to_bytes(u'\u2297', errors='strict') == u'\u2297'.encode('utf-8', 'strict')
    assert to_bytes(b'hello') == b'hello'
    assert to_bytes(1) == b'1'

# Generated at 2022-06-11 01:34:22.322413
# Unit test for function to_native
def test_to_native():
    '''to_native() should convert a byte string to utf-8 on Python 3 and do nothing
    on Python 2'''

    # If this is Python 3, then we expect to convert a byte string to utf-8.
    # If this is Python 2, then we expect unicode to be returned.
    expected_output = 'Test' if PY3 else u'Test'
    actual_output = to_native('Test')
    assert actual_output == expected_output, 'to_native() failed to convert b"Test" to utf-8 on Python 3 and to unicode on Python 2'

    # If we get unicode on Python 3, we expect it to be returned unchanged.
    # If we get unicode on Python 2, we expect it to be returned unchanged.
    expected_output = u'Test'
    actual_output = to_native

# Generated at 2022-06-11 01:34:42.694394
# Unit test for function to_bytes
def test_to_bytes():
    # Note: PY3 implicitly tests surrogateescape error handler
    # because surrogateescape is set as the default error handler for
    # all non-ascii encodings.
    #
    # TODO: Add some explicit tests for surrogateescape

    # PY3: Non-unicode objects
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(42) == b'42'
    assert to_bytes(42, nonstring='strict') is TypeError

    # PY3: Unicode strings
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'A\u1234') == b'A\xe1\x88\xb4'

# Generated at 2022-06-11 01:34:54.017208
# Unit test for function jsonify
def test_jsonify():
    try:
        from __main__ import display
    except ImportError:
        display = None

    def print_test(test_name, data):
        if display:
            display.display("%s: %s" % (test_name, data), color='blue')
        else:
            print('%s: %s' % (test_name, data))


# Generated at 2022-06-11 01:35:01.503506
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a="b")) == """{"a": "b"}"""
    assert jsonify(dict(a=dict(foo="bar"))) == """{"a": {"foo": "bar"}}"""
    assert jsonify(dict(a=dict(foo="bar"), b=set([1, 2]))) == """{"a": {"foo": "bar"}, "b": [1, 2]}"""
    test_datetime = datetime.datetime(2012, 12, 12, 12, 12, 12, 12)
    assert jsonify(dict(a=test_datetime)) == """{"a": "2012-12-12T12:12:12.000012"}"""

# Generated at 2022-06-11 01:35:13.603973
# Unit test for function to_bytes

# Generated at 2022-06-11 01:35:22.570651
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a":1, "test": "success"}) == '{"a": 1, "test": "success"}'
    assert jsonify([1,2,3]) == '[1, 2, 3]'
    assert jsonify(u'\u1234') == '"\\u1234"'
    assert jsonify(u"\u2713") == '"\\u2713"'
    assert jsonify({"a":1, "test": "success"}, sort_keys=True) == '{"a": 1, "test": "success"}'
    assert jsonify([1,2,3], sort_keys=True) == '[1, 2, 3]'
    assert jsonify(u'\u1234', sort_keys=True) == '"\\u1234"'

# Generated at 2022-06-11 01:35:33.852699
# Unit test for function jsonify
def test_jsonify():
    data = {u'key': u'\u2713', u'key2': b'\xe2\x9c\x93', u'list': [2], u'set': set((1, 2, 3))}
    assert jsonify(data, sort_keys=True) == json.dumps({'key': u'\u2713', 'key2': u'\u2713', 'list': [2], 'set': [1, 2, 3]}, sort_keys=True, encoding="utf-8", default=_json_encode_fallback)

# Generated at 2022-06-11 01:35:42.917768
# Unit test for function to_bytes

# Generated at 2022-06-11 01:35:53.197828
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    # surrogateescape
    if HAS_SURROGATEESCAPE:
        assert to_bytes('\udc80') == b'\x80'
        assert to_bytes('\udc80', errors='surrogate_or_strict') == b'\x80'

# Generated at 2022-06-11 01:36:03.480840
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foobar') == b'foobar'
    assert to_bytes('foobar') == b'foobar'
    assert to_bytes(b'foobar') == b'foobar'

    assert to_bytes(u'\u20ac') == b'\xe2\x82\xac'

    assert to_bytes(u'\u20ac'.encode('utf-8'), errors='surrogate_or_strict') == b'\xe2\x82\xac'
    assert to_bytes(u'\u20ac'.encode('utf-8'), errors='surrogate_or_replace') == b'\xe2\x82\xac'
    assert to_bytes(u'\u20ac', encoding='ascii', errors='surrogate_or_replace') == b

# Generated at 2022-06-11 01:36:10.779762
# Unit test for function to_native
def test_to_native():
    if PY3:
        assert to_native(b'\x80\xFF', method='replace', errors='surrogate_or_replace') == '\udc80\udcff'
        assert to_native(b'\x80\xFF', method='replace', errors='surrogate_or_strict') == '\udc80\udcff'
        assert to_native(b'\x80\xFF', method='replace', errors='surrogate_then_replace') == '\udc80\udcff'
        assert to_native(b'\x80\xFF', method='replace', errors='surrogateescape') == '\udc80\udcff'

# Generated at 2022-06-11 01:36:30.172540
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('{ "key": "value" }') == '"{ \\"key\\": \\"value\\" }"'
    assert jsonify('{ "key": "value" }', ensure_ascii=False) == '"{ \"key\": \"value\" }"'
    assert jsonify('{ "key": "value" }') == '"{ \\"key\\": \\"value\\" }"'
    assert jsonify('{ "key": "value" }', ensure_ascii=False) == '"{ \"key\": \"value\" }"'
    assert jsonify({ "key": "value" }) == '{"key": "value"}'
    assert jsonify({ "key": "value" }, ensure_ascii=False) == '{"key": "value"}'



# Generated at 2022-06-11 01:36:35.401447
# Unit test for function jsonify
def test_jsonify():
    # Create a dictionary with non utf-8 string as a value
    d = {b7('key'): b('a') + bchr(255) + b('c')}

    try:
        json.dumps(d)
    except UnicodeDecodeError:
        pass
    else:
        raise AssertionError("Expected a UnicodeDecodeError to be raised")

    # Test jsonify
    assert jsonify(d) == u('{"key": "a\\ufffdc"}')



# Generated at 2022-06-11 01:36:46.241845
# Unit test for function to_native
def test_to_native():
    assert(to_native("unicode_val") == "unicode_val")
    assert(to_native("unicode_val", errors='surrogate_or_strict') == "unicode_val")
    assert(to_native("unicode_val", errors='surrogate_or_replace') == "unicode_val")
    assert(to_native("unicode_val", errors='surrogate_then_replace') == "unicode_val")
    # if surrogateescape error handler is not supported, then default to surrogate_then_replace
    assert(to_native("unicode_val", errors=None) == "unicode_val")
    assert(to_native("unicode_val", errors='hi_there') == "unicode_val")


# Generated at 2022-06-11 01:36:51.600410
# Unit test for function jsonify
def test_jsonify():
    """
        verify that function jsonify
        returns a string properly
    """
    test_data = {'unicode': u"\u5f20 -- zhang"}
    result = jsonify(test_data)

    expected_results = '{"unicode": "\\u5f20 -- zhang"}'
    assert result == expected_results


# Generated at 2022-06-11 01:37:00.627291
# Unit test for function to_native
def test_to_native():
    # Some of the functionality below requires the u'' prefix for the
    # string to be unicode in python2.  That's because in python2 the
    # various string types do not inherit from a common base class
    # (to_text() below does that for us).
    # pylint: disable=undefined-variable
    # We want to be able to test a single error handler without having
    # to type the _or_replace every time.  So we'll have a local copy
    # of surrogate_or_replace.
    surrogate_or_replace = 'surrogate_or_replace'

    # Test bytes to native
    if PY3:
        # if we're in python3, bytes should come out as bytes and
        # strings as str objects
        native = to_native(b'\x80')

# Generated at 2022-06-11 01:37:12.749325
# Unit test for function to_bytes
def test_to_bytes():
    # text strings get encoded as utf-8
    assert to_bytes('\N{SNOWMAN}') == b'\xe2\x98\x83'

    # text strings with surrogates get encoded as utf-8
    assert to_bytes(chr(0xD83D) + chr(0xDE0A)) == b'\xf0\x9f\x98\x8a'

    # byte strings pass through
    assert to_bytes(b'\xe2\x98\x83') == b'\xe2\x98\x83'

    # nonstrings are represented as utf-8
    class Snowman(object):
        def __repr__(self):
            return '\N{SNOWMAN}'

# Generated at 2022-06-11 01:37:21.270291
# Unit test for function to_native
def test_to_native():
    # Test Unicode input
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'foo'.encode('latin-1')) == u'foo'
    assert to_native(u'foo'.encode('ascii', 'replace')) == u'foo'
    assert to_native(u'foo\xff') == u'foo\ufffd'
    assert to_native(u'foo\u1234') == u'foo\u1234'
    assert to_native(u'foo\u1234'.encode('ascii', 'replace')) == u'foo?'

# Generated at 2022-06-11 01:37:33.082621
# Unit test for function to_native
def test_to_native():
    """
    Test to_native
    """
    if PY3:
        input_types = [
            1,
            True,
            datetime.datetime(2020, 1, 1, 0, 0, 0, 0),
            (1, "two", 3.0),
            {"one": 1, "two": 2},
        ]
    else:
        input_types = [
            1,
            True,
            unicode("/bin/foo"),
            datetime.datetime(2020, 1, 1, 0, 0, 0, 0),
            (1, "two", 3.0),
            {"one": 1, "two": 2},
            Set(),
        ]

    for test_input in input_types:
        assert isinstance(to_native(test_input), text_type)

    # This should return

# Generated at 2022-06-11 01:37:35.017554
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=dict(b=1))) == '{"a": {"b": 1}}'



# Generated at 2022-06-11 01:37:45.164623
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('hello') == b'hello'
    assert to_bytes(b'hello') == b'hello'
    assert to_bytes(b'\xc3\xbc') == b'\xc3\xbc'
    assert to_bytes(u'\xfc', encoding='latin-1') == b'\xfc'
    assert to_bytes(u'\xfc', encoding='ascii') == b'?'
    assert to_bytes(u'\xfc', encoding='ascii', errors='ignore') == b''
    assert to_bytes(u'\xfc', encoding='ascii', errors='replace') == b'?'
    assert to_bytes(u'\xfc', encoding='ascii', errors='surrogateescape') == b'?'

# Generated at 2022-06-11 01:38:11.448866
# Unit test for function jsonify

# Generated at 2022-06-11 01:38:19.482238
# Unit test for function to_native
def test_to_native():
    # Check that bytes are handled properly
    result = to_native(b'\xc3\xbc')
    assert isinstance(result, text_type)
    assert result == u'\xfc'

    # Check that text is handled properly
    result = to_native(u'\xfc')
    assert isinstance(result, text_type)
    assert result == u'\xfc'

    if PY3:
        # Check that lots of types are handled properly
        result = to_native(u'\xfc', None, None, 'simplerepr')
        assert isinstance(result, text_type)
        assert result == u'\xfc'

        result = to_native(1, None, None, 'simplerepr')
        assert isinstance(result, text_type)
        assert result == u'1'



# Generated at 2022-06-11 01:38:27.576614
# Unit test for function to_native
def test_to_native():
    # NOTE: This is a duplicate of the test_to_text test suite
    # It only exists here because it's easier to keep the tests in sync
    # if they're all in the same test suite.  This means we can easily make
    # sure that changes to one are reflected in the other.
    # We should really consider moving all the to_text tests here instead
    # of keeping them in the to_text test suite.

    # Check unicode defaults to utf-8
    tt = to_text(u'\u043f\u044b\u0442\u0430\u0442\u044c\u0441\u044f')
    assert tt == u'\u043f\u044b\u0442\u0430\u0442\u044c\u0441\u044f'

# Generated at 2022-06-11 01:38:39.049705
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo': u'bar'}) == '{"foo": "bar"}'
    assert jsonify([]) == '[]'
    assert jsonify(['foo', u'bar']) == '["foo", "bar"]'
    assert jsonify({"k1": {"k2": u"value"}}) == '{"k1": {"k2": "value"}}'
    assert jsonify({"k1": {'k2': u"value"}}) == '{"k1": {"k2": "value"}}'
    assert jsonify([{"k1": {u"k2": u"value"}}]) == '[{"k1": {"k2": "value"}}]'

# Generated at 2022-06-11 01:38:46.306902
# Unit test for function to_native
def test_to_native():
    # Now try to turn a text string in ascii into a unicode string
    try:
        codecs.lookup_error('surrogateescape')
        HAS_SURROGATEESCAPE = True
    except LookupError:
        HAS_SURROGATEESCAPE = False

    if HAS_SURROGATEESCAPE and PY3:
        assert to_native(b'\xe2\x98\x83') == b'\xe2\x98\x83'.decode('utf-8', 'surrogateescape')
    else:
        assert to_native(b'\xe2\x98\x83') == b'\xe2\x98\x83'.decode('utf-8', 'replace')

    # Now try to turn a text string in ascii into a string
    assert to

# Generated at 2022-06-11 01:38:56.517103
# Unit test for function to_native
def test_to_native():
    def test_equivalent_to(expected, obj, encoding, errors, nonstring):
        to_bytes_out = to_bytes(obj, encoding=encoding, errors=errors, nonstring=nonstring)
        to_text_out = to_text(obj, encoding=encoding, errors=errors, nonstring=nonstring)
        to_native_out = to_native(obj, encoding=encoding, errors=errors, nonstring=nonstring)
        assert to_bytes_out == expected
        assert to_text_out == expected
        assert to_native_out == expected

    test_equivalent_to('á', u'á', 'ascii', 'strict', 'simplerepr')

# Generated at 2022-06-11 01:39:05.921217
# Unit test for function jsonify
def test_jsonify():
    # Invalid data
    data = {'k1': to_bytes('\u6c49', 'utf-8')}
    try:
        jsonify(data)
    except UnicodeError:
        pass
    else:
        assert False

    # Valid data
    data2 = {'k1': to_bytes('\xe5\x90\x8d', 'utf-8')}
    if sys.version_info >= (2, 7):
        jsonify(data2)

# Generated at 2022-06-11 01:39:11.032879
# Unit test for function jsonify
def test_jsonify():
    import json
    import datetime
    data = {'time': datetime.datetime(2015, 6, 14, 2, 35, 35, 954000)}
    assert jsonify(data) == '{"time": "2015-06-14T02:35:35.954000"}'


# Generated at 2022-06-11 01:39:15.840579
# Unit test for function to_native
def test_to_native():
    ustr = u"hello world"
    if PY3:
        assert to_native(ustr) == ustr
    else:
        assert to_native(ustr) == b"hello world"

    if not PY3:
        assert to_native(b"hello world") == b"hello world"



# Generated at 2022-06-11 01:39:26.479039
# Unit test for function to_native
def test_to_native():
    inp = b'{"json":"obj"}'
    outp = to_native(inp)
    assert type(outp) == text_type
    assert json.loads(outp) == json.loads(to_text(inp))
    assert type(json.loads(outp)) == dict
    inp = u'{"json":"obj"}'
    outp = to_native(inp)
    assert type(outp) == text_type
    assert json.loads(outp) == json.loads(to_text(inp))
    assert type(json.loads(outp)) == dict
    inp = [1, 2, 3]
    outp = to_native(inp)
    assert type(outp) == list
    # Python3 has native strings, so using repr here
    assert repr(outp) == repr