

# Generated at 2022-06-11 01:30:00.639957
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.common._collections_compat import Set
    from ansible.module_utils.six import unichr
    from datetime import datetime


# Generated at 2022-06-11 01:30:11.851752
# Unit test for function to_bytes
def test_to_bytes():
    assert b'abc' == to_bytes(b'abc')
    assert b'abc' == to_bytes(u'abc')
    assert b'abc' == to_bytes('abc')

    assert b'\xc3\xa9' == to_bytes(u'\xe9')
    assert b'\xc3\xa9' == to_bytes('\xe9')
    assert b'\xc3\xa9' == to_bytes(b'\xc3\xa9')
    assert b'\xc3\xa9' == to_bytes(b'\xc3\xa9', errors='strict')
    assert b'\xc3\xa9' == to_bytes(b'\xc3\xa9', encoding='ascii', errors='strict')


# Generated at 2022-06-11 01:30:21.556467
# Unit test for function to_bytes
def test_to_bytes():

    class TestObj(object):
        def __str__(self):
            return 'string'

        def __repr__(self):
            return 'repr'

    class TestUnicodeObj(object):
        def __str__(self):
            return u'string'

        def __repr__(self):
            return u'repr'

    class TestUnicodeUnencodableObj(object):
        def __str__(self):
            return u'\xa1'

        def __repr__(self):
            return u'\xa1'

    class TestUnicodeUnencodableObjRepr(object):
        def __str__(self):
            return 'string'

        def __repr__(self):
            return u'\xa1'


# Generated at 2022-06-11 01:30:28.532467
# Unit test for function to_bytes
def test_to_bytes():
    if PY3:
        def b(x):
            return x.encode('latin-1')
    else:
        import codecs
        codecs.register_error('strict', codecs.strict_errors)
        b = str

    assert b('') == to_bytes('')
    assert b('') == to_bytes('', encoding='ascii')
    assert b('') == to_bytes(b(''), encoding='ascii')

    assert b('hello') == to_bytes('hello')
    assert b('hello') == to_bytes('hello', encoding='ascii')
    assert b('hello') == to_bytes(b('hello'), encoding='ascii')

# Generated at 2022-06-11 01:30:38.224779
# Unit test for function to_native
def test_to_native():
    test_dict = dict(a=1, b=2, c=dict(foo='bar', baz='baz'))
    test_str = 'test'
    test_u_str = u'test'
    test_list = [1, 2, 3]
    test_bytes = b'test'
    test_set = set(['foo', 'bar', 'baz'])
    test_tuple = ('foo', 'bar')
    test_datetime = datetime.datetime.utcnow()
    test_date = datetime.date.today()

    assert to_native(test_dict) == test_dict
    assert to_native(test_str) == test_str
    assert to_native(test_u_str) == test_str
    assert to_native(test_list) == test_list


# Generated at 2022-06-11 01:30:50.405736
# Unit test for function jsonify
def test_jsonify():
    '''
    Test some of the edge cases of encoding unicode data.
    '''

    # Make sure that the jsonify function doesn't raise any exceptions for
    # non-unicode data.
    jsonify('foo')
    jsonify([1, 2, 3])
    jsonify({'foo': 1})

    # Make sure that the jsonify function properly encodes unicode data.
    res = jsonify(to_bytes('\u7231\u60c5'))
    assert res == '"\\u7231\\u60c5"'
    assert isinstance(res, str)

    res = jsonify(['\u7231\u60c5'])
    assert res == '["\\u7231\\u60c5"]'
    assert isinstance(res, str)


# Generated at 2022-06-11 01:30:53.950158
# Unit test for function jsonify
def test_jsonify():
    data = {
            "data": "test",
            "data2": [{"test": "data"}]
    }
    encoded_data = jsonify(data)
    assert json.loads(encoded_data) == data


# Generated at 2022-06-11 01:31:02.990910
# Unit test for function jsonify
def test_jsonify():
    class MyClass(object):
        def __repr__(self):
            return u"\u00a5"
    assert(jsonify(MyClass()) == '"\\\\uffe5"')
    assert(jsonify({"a": [1, u'\u2603']}) == '{"a": [1, "\\\\u2603"]}')
    assert(jsonify({"a": [1, u"\u2603"]}, indent=4) == '{\n    "a": [\n        1, \n        "\\\\u2603"\n    ]\n}')


# View items is not a public api in Python2
# For python2 it is a normal view of items
# In python3 it is a view of key-value pairs

# Generated at 2022-06-11 01:31:14.669985
# Unit test for function to_native

# Generated at 2022-06-11 01:31:25.468315
# Unit test for function to_native
def test_to_native():
    """
    Make sure that a thing is a native thing
    """

# Generated at 2022-06-11 01:31:36.371601
# Unit test for function jsonify
def test_jsonify():
    test_str = b'{"foo": "bar"}'
    test_dict = dict(foo="bar")
    assert jsonify(test_dict) == test_str

    test_str = b'{"foo": "bar", "baz": [{"test": "blah"}], "test": "blah"}'
    test_dict = dict(foo="bar", baz=[dict(test="blah")], test="blah")
    assert jsonify(test_dict) == test_str


# Generated at 2022-06-11 01:31:48.020713
# Unit test for function jsonify
def test_jsonify():
    """Tests for `ansible.module_utils.basic._json_encode_fallback` function."""

    from ansible.module_utils import basic
    import datetime
    import sys

    str_types = (str, basic.to_native)
    if sys.version_info[0] >= 3:
        from ansible.module_utils._text import to_text, to_bytes
        str_types = (str, to_text, to_bytes)

    data = {"a": "b"}
    assert jsonify(data) == '{"a": "b"}'

    data = {"a": "b\xc2\x85"}
    assert jsonify(data) == '{"a": "b\u0085"}'

    data = {"a": "b\xc2\xa0"}
    assert jsonify(data)

# Generated at 2022-06-11 01:31:56.176461
# Unit test for function to_bytes
def test_to_bytes():
    assert b'abc' == to_bytes('abc')
    assert b'123' == to_bytes(123)
    assert u'ą'.encode('utf-8') == to_bytes(u'ą')
    # TODO: Consider using a different error handler for the nonstring tests
    #     This could be done with a separate decorator and test function
    assert b'123' == to_bytes(123, errors='strict')
    assert b'123' == to_bytes(123, errors='replace')
    assert u'ą'.encode('utf-8') == to_bytes(u'ą', errors='strict')
    assert u'ą'.encode('utf-8') == to_bytes(u'ą', errors='replace')

# Generated at 2022-06-11 01:32:01.824600
# Unit test for function jsonify
def test_jsonify():
    class TestClass(object):
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return 'TestClass(%s)' % self.value

    assert jsonify({"test": TestClass(123)}) == '{"test": "TestClass(123)"}'



# Generated at 2022-06-11 01:32:13.440163
# Unit test for function to_bytes
def test_to_bytes():
    """
    Unit tests for to_bytes.
    """
    assert to_bytes('test') == b'test'
    assert to_bytes(b'test') == b'test'
    assert to_bytes(u'test') == b'test'
    assert to_bytes(u'test', errors='surrogate_or_replace') == b'test'
    assert to_bytes(u'test', errors='surrogate_or_strict') == b'test'
    assert to_bytes(u'test', errors='surrogate_then_replace') == b'test'
    options = {'errors': 'surrogate_then_replace'}

# Generated at 2022-06-11 01:32:22.289340
# Unit test for function to_native
def test_to_native():
    """
    Test to_native().
    """
    # Test bytes to unicode
    assert to_native(b"abc") == u"abc"
    assert to_native(b"\xe9") == u"\xe9"
    assert to_native(u"abc") == u"abc"
    assert to_native(u"\xe9") == u"\xe9"
    # Test bytes/unicode to utf-8
    assert to_native(u"\xe9", encoding='utf-8') == u"\xe9".encode('utf-8')
    assert to_native(u"abc", encoding='utf-8') == u"abc".encode('utf-8')
    assert to_native(b"abc", encoding='utf-8') == b"abc"

# Generated at 2022-06-11 01:32:25.140361
# Unit test for function to_native
def test_to_native():
    obj = to_native({u'one': 'two'})
    assert (obj == {u'one': 'two'}) # but this one is true



# Generated at 2022-06-11 01:32:33.298523
# Unit test for function to_native
def test_to_native():
    # Test bytes are passed through unchanged
    assert to_native(b'foo') == b'foo'
    # Test unicode is encoded to the default
    assert to_native(u'\xe9') == b'\xc3\xa9'
    # Test nonstrings are turned into text strings
    assert to_native(u'\xe9') == b'\xc3\xa9'
    # Test other types are treated as nonstrings
    assert to_native(25) == b'25'


# Generated at 2022-06-11 01:32:40.714473
# Unit test for function to_bytes
def test_to_bytes():
    # pylint: disable=too-many-locals
    # Old tests
    assert to_bytes('foo') == b'foo'
    assert to_bytes('fóo') == b'f\xc3\xb3o'
    assert to_bytes('\xe0') == b'\xc3\xa0'
    assert to_bytes('\U00102030') == b'\xf0\x90\x88\xb0'
    assert to_bytes(u'\ud800') == b'\xed\xa0\x80'
    assert to_bytes(u'\udc00') == b'\xed\xb0\x80'
    assert to_bytes(u'\ud800\udc00') == b'\xf0\x90\x80\x80'

# Generated at 2022-06-11 01:32:50.995119
# Unit test for function to_bytes
def test_to_bytes():
    import sys

    # Simple tests
    assert isinstance(to_bytes(u'foo'), binary_type), 'to_bytes should return the same obj if it is already a byte string'
    assert isinstance(to_bytes('foo'), binary_type), 'to_bytes should return byte string when passed a text string'
    assert isinstance(to_bytes(u'foo', nonstring='strict'), binary_type), 'to_bytes should return byte string when passed a nonstring and strict'

    # Test to_bytes produces the same results as to_text if using the same encoding
    # TODO: This should be expanded to cover the error handlers and charsets in
    # a more thorough way

# Generated at 2022-06-11 01:33:08.068931
# Unit test for function jsonify
def test_jsonify():
    # Encode data containing unicode
    data = {
        u'bytes': b'\xc3\xa9',
        u'unicode': u'\xc3\xa9',
    }
    assert jsonify(data) == u'{"unicode": "é", "bytes": "é"}'

    # Encode non-serializable object
    data = {
        u'set': set([1, 2, 3]),
    }
    assert jsonify(data) == u'{"set": [1, 2, 3]}'

    # Fail with invalid unicode
    try:
        jsonify({'unicode': u'\xa0'})
        assert False, "Invalid unicode did not generate error"
    except UnicodeError:
        pass



# Generated at 2022-06-11 01:33:19.061676
# Unit test for function to_bytes

# Generated at 2022-06-11 01:33:29.737627
# Unit test for function to_bytes
def test_to_bytes():
    class Unicode_subclass(text_type):
        pass

    class Bytes_subclass(binary_type):
        pass

    class Nonstring_subclass(object):
        def __str__(self):
            return 'simplerepr'

        def __repr__(self):
            return 'surrogaterepr'

    _NONSTRINGS = [0, 0.0, u'unicode_subclass: \ufffe', Unicode_subclass(u'\ufffe'),
                   'bytes_subclass: \xff', Bytes_subclass(b'\xff'), Nonstring_subclass()]

    #
    # Test a text string using various error handlers
    #
    assert to_bytes(u'hello', errors='surrogate_then_replace') == b'hello'

# Generated at 2022-06-11 01:33:39.154576
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_bytes

    if PY3:
        test_text = to_text(b"Test")
    else:
        test_text = to_bytes("Test")
    test_dict = dict(a=1, b=2, c=test_text)
    res = jsonify(data=test_dict)
    assert res == json.dumps(data=test_dict, default=_json_encode_fallback)
# end of test



# Generated at 2022-06-11 01:33:47.091108
# Unit test for function to_native
def test_to_native():
    assert to_native("") == ""
    assert to_native("hello") == "hello"
    assert to_native("hello\u00a2") == "hello\xc2\xa2"
    assert to_native("hello\u00a2".encode("latin-1")) == "hello\xc2\xa2"
    assert to_native("hello\u00a2".encode("ascii", "surrogateescape")) == "hello?"
    assert to_native(u"hello\u00a2") == u"hello\ua0a2"
    assert to_native(u"hello\u00a2", encoding="latin-1") == u"hello\ua0a2"
    assert to_native(u"hello\u00a2".encode("latin-1"), encoding="latin-1")

# Generated at 2022-06-11 01:33:58.515995
# Unit test for function to_bytes
def test_to_bytes():  # noqa: D103
    from ansible_collections.ansible.community.tests.unit.compat import unittest

    class TestToBytes(unittest.TestCase):
        def test_to_bytes_nonstring_simplerepr(self):
            self.assertEqual(to_bytes(None), b'None')
            self.assertEqual(to_bytes(42), b'42')

        def test_to_bytes_nonstring_passthru(self):
            self.assertEqual(to_bytes(None, nonstring='passthru'), None)
            self.assertEqual(to_bytes(42, nonstring='passthru'), 42)


# Generated at 2022-06-11 01:34:09.104257
# Unit test for function to_native
def test_to_native():
    class Foo:
        def __str__(self):
            return 'foo'

    class FooRepr:
        def __str__(self):
            raise UnicodeError()

        def __repr__(self):
            return 'bar'

    class FooNoRepr:
        def __str__(self):
            raise UnicodeError()

    # Test that to_native works with the following types:
    #  * text string
    #  * byte string
    #  * integer
    #  * float
    #  * list
    #  * dictionary
    #  * tuple
    #  * boolean
    #  * datetime
    #  * None
    #  * object (an instance of Object)
    #  * object (an instance of ObjectRepr)
    #  * object (an instance of ObjectNoRepr)


# Generated at 2022-06-11 01:34:19.715712
# Unit test for function jsonify
def test_jsonify():
    assert jsonify('foo') == u'"foo"'
    assert jsonify(u'foo') == u'"foo"'
    assert jsonify(u'\u1234') == u'"\u1234"'
    assert jsonify({'foo': 'foo'}) == u"{\"foo\": \"foo\"}"
    assert jsonify({'foo': u'foo'}) == u"{\"foo\": \"foo\"}"
    assert jsonify(['foo', 'bar']) == u"[\"foo\", \"bar\"]"
    assert jsonify((u'foo', u'bar')) == u"[\"foo\", \"bar\"]"
    assert jsonify({'foo': 'foo', 'bar': 'bar'}) == u"{\"foo\": \"foo\", \"bar\": \"bar\"}"

# Generated at 2022-06-11 01:34:29.014010
# Unit test for function to_native
def test_to_native():
    data = [
        (b"I'm a byte string", "I'm a byte string"),
        (u"I'm a unicode string", u"I'm a unicode string"),
        (b"192.0.2.1", "192.0.2.1"),
        (u"192.0.2.1", u"192.0.2.1"),
        (u'\u4f60\u597d', 'hello')
    ]
    for before, after in data:
        assert to_native(before) == after
        assert to_native(before, errors='surrogateescape') == after
        # Ensure we didn't change the input
        assert before == after



# Generated at 2022-06-11 01:34:30.777274
# Unit test for function to_bytes
def test_to_bytes():
    """This is a documented unit test.

    :rtype: int
    """
    return 1


# Generated at 2022-06-11 01:34:48.207887
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'string') == b'string'
    assert to_bytes(u'string') == b'string'
    assert to_bytes(u'\uF15A') == b'\xef\x85\x9a'
    assert to_bytes('\uF15A') == b'\xef\x85\x9a'

    try:
        to_bytes(b'\x81')
    except UnicodeDecodeError:
        pass
    else:
        raise AssertionError('to_bytes didn\'t error when given a byte string with invalid utf-8')

    assert to_bytes(b'\x81', errors='surrogateescape') == b'\x81'

    assert to_bytes(b'\x81', errors='replace') == b'?'

   

# Generated at 2022-06-11 01:34:52.240387
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native

    assert to_native('foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(b'foo'.decode('ascii')) == 'foo'



# Generated at 2022-06-11 01:35:00.459576
# Unit test for function to_bytes
def test_to_bytes():
    class Foo(object):
        def __repr__(self):
            return '\xe4'

    try:
        u'\xe4'.encode('latin-1', 'surrogateescape')
    except LookupError:
        has_surrogateescape = False
    else:
        has_surrogateescape = True

    # Single byte character strings
    assert to_bytes('a') == b'a'
    assert to_bytes(b'a') == b'a'

    # Strings with multi byte characters
    assert to_bytes('\xe4') == b'\xc3\xa4'
    assert to_bytes(b'\xc3\xa4') == b'\xc3\xa4'

    # When surrogateescape is available, we should be able to encode anything
    # that can be str'ed

# Generated at 2022-06-11 01:35:04.116593
# Unit test for function jsonify
def test_jsonify():
    input_data = {
        "key": 3,
        "key2": "value"
    }
    output_data = jsonify(input_data)
    print(output_data)



# Generated at 2022-06-11 01:35:15.669978
# Unit test for function jsonify
def test_jsonify():
    data = {
        "key": u"value",
        "list": [1, 2, 3, "a", u"b", {"c": "d"}],
        "set": set([1, 2, 3]),
        "dict": {"a": 1, "b": 2, "c": "3"},
        u"utf8": u"utf8_string",
        "now": datetime.datetime.now(),
        "date": datetime.date.today(),
        "time": datetime.datetime.now().time(),
        "complex": 1 + 2j,
        "unicode_key": u"value",
    }
    json_str = jsonify(data)

# Generated at 2022-06-11 01:35:23.562723
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    from collections import OrderedDict

    assert isinstance(to_native(b'foo'), text_type)
    assert isinstance(to_native(u'foo'), text_type)
    assert isinstance(to_native(1), text_type)
    assert isinstance(to_native(1.0), text_type)
    assert isinstance(to_native([]), text_type)
    assert isinstance(to_native({}), text_type)
    assert isinstance(to_native(OrderedDict()), text_type)
    assert isinstance(to_native(set()), text_type)
    assert isinstance(to_native(frozenset()), text_type)

# Generated at 2022-06-11 01:35:32.518731
# Unit test for function to_native
def test_to_native():
    assert to_native("none") == "none"
    assert to_native("bytes") == "bytes"
    assert to_native("str") == "str"
    assert to_native("all") == "all"
    assert to_native("surrogate_or_strict") == "surrogate_or_strict"
    assert to_native("") == ""

import os
import sys
import errno
import shlex
import shutil
import subprocess

import six
from six.moves import shlex_quote

from ansible.compat.six import ensure_text



# Generated at 2022-06-11 01:35:38.211949
# Unit test for function jsonify
def test_jsonify():
    data = dict(
        a=1,
        b=u"\xe9"
    )
    assert isinstance(jsonify(data), str)
    assert u"\xe9" in jsonify(data)
    # json can not encode datetime
    dt = datetime.datetime(2018, 6, 7)
    assert "2018-06-07T00:00:00" in jsonify({"dt": dt})



# Generated at 2022-06-11 01:35:46.216407
# Unit test for function to_native
def test_to_native():
    utf8_bom = codecs.BOM_UTF8
    utf16_le_bom = codecs.BOM_UTF16_LE
    utf16_be_bom = codecs.BOM_UTF16_BE
    utf32_le_bom = codecs.BOM_UTF32_LE
    utf32_be_bom = codecs.BOM_UTF32_BE

    # Ensure we can convert to unicode, no matter what the input string type
    assert to_native(b'spam') == u'spam'
    assert to_native(u'spam') == u'spam'
    assert to_native('spam') == u'spam'

    # Ensure that the BOMs are stripped
    assert to_native(utf8_bom + b'spam')

# Generated at 2022-06-11 01:35:56.825946
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foobar') == b'foobar'
    assert to_bytes('fööbär') == b'f\xc3\xb6\xc3\xb6b\xc3\xa4r'
    assert to_bytes('fööbär', encoding='latin1') == b'f\xf6\xf6b\xe4r'
    assert to_bytes('fööbär', errors='surrogate_or_replace') == b'foobar'
    assert to_bytes('fööbär', errors='surrogate_or_strict') == b'foobar'
    assert to_bytes('fööbär', errors='surrogate_then_replace') == b'foobar'

# Generated at 2022-06-11 01:36:09.967011
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils.six import PY3
    assert to_native("foo") == "foo"
    assert to_native(u"foo") == "foo"
    if PY3:
        assert to_native(b"foo") == "foo"
    assert to_native("foo\xc3\xa9") == "foo\xc3\xa9"
    assert to_native(u"foo\xe9") == "foo\xe9"
    assert to_native(b"foo\xc3\xa9") == "foo\xc3\xa9"
    if PY3:
        assert to_native("foo\u1fff") == "\ud83f\udfff"
        assert to_native(b"foo\x1f\xff") == "\ud83f\udfff"

# Generated at 2022-06-11 01:36:15.535390
# Unit test for function jsonify
def test_jsonify():
    data = {"foo": u"bar"}
    assert jsonify(data) == '{"foo": "bar"}'
    data = {u"foo": "bar"}
    assert jsonify(data) == '{"foo": "bar"}'
    data = {u"foo": to_text("bar")}
    assert jsonify(data) == '{"foo": "bar"}'



# Generated at 2022-06-11 01:36:20.054907
# Unit test for function jsonify
def test_jsonify():
    data = {'test': u'\u2019'}
    try:
        json.dumps(data)
    except UnicodeDecodeError:
        pass
    else:
        raise AssertionError('Test data must fail with UnicodeDecodeError')

    assert jsonify(data) == u'{"test": "\u2019"}'



# Generated at 2022-06-11 01:36:30.127950
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('abc', 'ascii') == b'abc'
    assert to_bytes(u'abc', 'ascii') == b'abc'
    assert to_bytes(u'ффф', 'ascii') == b'\xd1\x84\xd1\x84\xd1\x84'
    assert to_bytes(u'ффф', 'ascii', 'strict') == b'\xd1\x84\xd1\x84\xd1\x84'
    assert to_bytes(u'abc') == b'abc'
    assert to_bytes(u'ффф') == b'\xd1\x84\xd1\x84\xd1\x84'

# Generated at 2022-06-11 01:36:38.573631
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_text
    from datetime import datetime

    test_data = {
        'a_key': 'a_value',
        'another': ['a_string',
                    None,
                    True,
                    False,
                    0,
                    1,
                    set(['a', 'b']),
                    datetime(2017, 1, 1),
                   ],
    }

    encoded = jsonify(test_data)
    assert isinstance(encoded, text_type)
    assert '"a_key": "a_value"' in encoded
    assert '"another": ["a_string", null, true, false, 0, 1, ["a", "b"], "2017-01-01T00:00:00"]' in encoded

# Generated at 2022-06-11 01:36:50.237318
# Unit test for function jsonify
def test_jsonify():
    test_obj = Set(['a', 'b', 'c'])
    result = jsonify(test_obj)
    assert result == '["a", "b", "c"]'
    test_dict = {'a': 1, 'b': 2, 'c': test_obj}
    result = jsonify(test_dict)
    assert result == '{"a": 1, "b": 2, "c": ["a", "b", "c"]}'
    utf8_str = u'\u2713'
    latin_str = utf8_str.encode('latin-1')
    result = jsonify({'a': 1, 'b': 2, 'c': latin_str})
    assert result == '{"a": 1, "b": 2, "c": "\\u2713"}'
    ut

# Generated at 2022-06-11 01:36:52.225890
# Unit test for function jsonify
def test_jsonify():
    data = jsonify('{ "a": "b"}')
    assert isinstance(data, text_type)



# Generated at 2022-06-11 01:36:56.341552
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'key': u'\u2713'}) == '{"key": "\\u2713"}'
    assert jsonify({u'\u2713': u'\u2713'}) == '{"\\u2713": "\\u2713"}'



# Generated at 2022-06-11 01:37:06.633022
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.common.text.converters._unicode_helper import (
        HAS_SURROGATEESCAPE,
    )

    SURROGATE_OR_STRICT = (None, 'surrogate_or_strict')
    SURROGATE_OR_REPLACE = ('surrogate_or_replace',)
    SURROGATE_THEN_REPLACE = ('surrogate_then_replace',)


# Generated at 2022-06-11 01:37:13.032620
# Unit test for function to_native

# Generated at 2022-06-11 01:37:28.116740
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    import sys
    if sys.version_info >= (3, 0):
        assert to_native(u'hello') == 'hello'
        assert to_native(b'hello') == 'hello'
        assert to_native(bytearray('hello', 'utf-8')) == u'hello'
        assert to_native(u'\u1234') == '\u1234'
        assert to_native(b'\u1234') == '\u1234'
        assert to_native(bytearray('\u1234','utf-8')) == u'\u1234'
    else:
        assert to_native(u'hello') == 'hello'
        assert to_native(b'hello') == 'hello'
        assert to_native

# Generated at 2022-06-11 01:37:39.169528
# Unit test for function jsonify
def test_jsonify():
    import copy
    import sys
    # jsonify(data) should raise UnicodeDecodeError if data contains any
    # non-ascii characters and cannot be decoded from 'utf-8',
    # per Python documentation.
    data = '{ \u0394: 1 }'
    try:
        jsonify(data)
    except UnicodeDecodeError:
        pass
    else:
        raise AssertionError('jsonify() did not raise UnicodeDecodeError for non-ascii characters.')
    # jsonify(data) should return json.dumps(data) if data contains only valid
    # ascii characters, since all Python versions support utf-8 encoding.
    # This is covered by the test_json.py in unit tests, but we add it here
    # as a sanity check.

# Generated at 2022-06-11 01:37:43.776950
# Unit test for function jsonify
def test_jsonify():
    utf8_input = jsonify({'a': '\xc3\xa2'})
    assert utf8_input == b'{"a": "\\u00e2"}'
    latin1_input = jsonify({'a': '\xe2'})
    assert latin1_input == b'{"a": "\xe2"}'



# Generated at 2022-06-11 01:37:45.968835
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(3) == '3'

# Generated at 2022-06-11 01:37:47.653505
# Unit test for function to_bytes
def test_to_bytes():
    # We test this in unit tests by importing it there...
    pass



# Generated at 2022-06-11 01:37:58.951522
# Unit test for function to_bytes
def test_to_bytes():
    # Non-strings are turned into text before encoding

    # simplerepr
    assert to_bytes(None) == b'None'
    assert to_bytes(True) == b'True'
    assert to_bytes(10) == b'10'
    assert to_bytes(10.5) == b'10.5'
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes([u'hello', u'goodbye']) == b"[u'hello', u'goodbye']"
    assert to_bytes({u'hello': u'goodbye'}) == b"{u'hello': u'goodbye'}"
    assert to_bytes({'hello': u'goodbye'}) == b"{'hello': u'goodbye'}"

    # passthru

# Generated at 2022-06-11 01:38:08.558833
# Unit test for function jsonify
def test_jsonify():
    '''Unit test for function jsonify'''
    param1 = dict(a=1, b=2, c=[6, 7, 8], d={'e': 6, 'f': 7})
    assert jsonify(param1) == '{"a": 1, "c": [6, 7, 8], "b": 2, "d": {"e": 6, "f": 7}}'
    param2 = [1, 2, 3, 4, 5]
    assert jsonify(param2) == '[1, 2, 3, 4, 5]'
    param3 = set(['a', 'b', 'c'])
    assert jsonify(param3) == '["a", "c", "b"]'
    param4 = datetime.datetime(2016, 12, 19, 1, 2, 3, 4)

# Generated at 2022-06-11 01:38:18.003002
# Unit test for function to_bytes
def test_to_bytes():
    try:
        codecs.lookup_error('surrogateescape')
        surrogateescape = True
    except LookupError:
        surrogateescape = False

    # Test nonstring handling
    assert to_bytes(1, nonstring='') == b''
    assert to_bytes(1, nonstring='passthru') == 1
    try:
        to_bytes(1, nonstring='strict')
        assert False, 'to_bytes should fail with strict'
    except TypeError:
        pass

    # Test surrogateescape error handler
    if surrogateescape:
        assert to_bytes(u'\uff19', errors='surrogate_or_replace') == b'\xef\xbf\x99'

# Generated at 2022-06-11 01:38:26.851162
# Unit test for function to_bytes
def test_to_bytes():
    """
    >>> test_to_bytes()
    True
    """
    import sys
    import json
    import time

    # Simple tests on each documented use of to_bytes
    assert to_bytes('foo') == b'foo'
    assert to_bytes('föö') == b'f\xc3\xb6\xc3\xb6'
    assert to_bytes('föö', 'utf-16') == b'\xff\xfef\x00\x00\xf6\x00\x00\xf6\x00'
    assert to_bytes('föö'.encode('latin-1'), 'utf-8', 'surrogate_or_strict') == b'f\xc3\xb6\xc3\xb6'

# Generated at 2022-06-11 01:38:31.668103
# Unit test for function jsonify
def test_jsonify():
    test_dict = dict(a=1, b=2, c=3, d=u'123', e=u'你好')
    test_str = jsonify(test_dict)
    assert test_str == json.dumps(test_dict, default=_json_encode_fallback)



# Generated at 2022-06-11 01:38:43.842498
# Unit test for function jsonify
def test_jsonify():
    # test with utf-8
    jsonify('abcd')
    # test with latin-1
    jsonify(b'abcd')



# Generated at 2022-06-11 01:38:54.796024
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils.basic import to_native
    from ansible.module_utils._text import to_text
    
    value = to_native({'test': '中文', 'test2': {'test3': '中文2'}}, errors='surrogate_then_replace')
    # if the test passes, it'll return the dict
    assert isinstance(value, dict)
    # ensure the values are not byte strings
    assert isinstance(value['test'], text_type)
    assert isinstance(value['test2'], dict)
    assert isinstance(value['test2']['test3'], text_type)
    # ensure the values are what they should be
    assert value['test'] == to_text(u'中文')
    assert value['test2']['test3']

# Generated at 2022-06-11 01:39:05.583746
# Unit test for function to_native
def test_to_native():
    '''
    to_native function is to translate python object to native, such as int, float, string, bool, list and dict.
    '''
    # test convert integer to native
    assert to_native(1, True) == 1
    assert type(to_native('1', True)) is int
    assert to_native(1, False) == '1'
    assert type(to_native(1, False)) is str
    # test converto float to native
    assert to_native(1.1, True) == 1.1
    assert type(to_native(1.1, True)) is float
    assert to_native(1.1, False) == '1.1'
    assert type(to_native(1.1, False)) is str
    # test convert string to native
    assert to_native('a', True)

# Generated at 2022-06-11 01:39:17.311576
# Unit test for function to_bytes
def test_to_bytes():
    # This can't be a doctest because doctests don't provide good enough
    # exception handling
    assert b'hi' == to_bytes('hi')
    assert b'hi' == to_bytes(b'hi')
    assert b'hi' == to_bytes('hi', nonstring='passthru')
    assert b'hi' == to_bytes(b'hi', nonstring='passthru')
    assert b'' == to_bytes(12345, nonstring='passthru')
    assert b'' == to_bytes(None, nonstring='passthru')
    assert b'' == to_bytes('hi', nonstring='empty')
    assert b'12345' == to_bytes(12345)
    assert b"<type 'int'>" == to_bytes(12345, encoding='ascii', errors='strict')


# Generated at 2022-06-11 01:39:20.367229
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify("a") == '"a"'
    assert jsonify("\x92") == '"\x92"'


# Generated at 2022-06-11 01:39:30.327779
# Unit test for function jsonify
def test_jsonify():
    class Test(dict):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            super(Test, self).__init__(*args, **kwargs)

        def __repr__(self):
            return self.__class__.__name__

    data = Test(dict=dict(a=1, b=dict(c=2, d=[1, 2, 3, 4])), list=[1, 2, 3])
    assert jsonify(data) == '{"dict": {"a": 1, "b": {"c": 2, "d": [1, 2, 3, 4]}}, "list": [1, 2, 3]}'



# Generated at 2022-06-11 01:39:33.418652
# Unit test for function jsonify
def test_jsonify():
    test_string = u"\xe1"
    test_dict = {u"foo" : test_string}
    assert jsonify(test_dict) == u'{"foo": "\\u00e1"}'


# Generated at 2022-06-11 01:39:40.945114
# Unit test for function to_native
def test_to_native():

    assert to_native(u'ABC') == u'ABC'
    assert to_native('ABC') == u'ABC'

    # unicode(3) fails with a traceback if we use to_text with nonstring='passthru'
    if PY3:
        nonstring = 'passthru'
    else:
        nonstring = 'simplerepr'

    assert to_native(3, nonstring=nonstring) == 3
    assert to_native(3.1, nonstring=nonstring) == 3.1
    assert to_native(True, nonstring=nonstring) is True
    assert to_native(False, nonstring=nonstring) is False
    assert to_native(None, nonstring=nonstring) is None

    o = object()
    # noinspection PyUnusedLocal