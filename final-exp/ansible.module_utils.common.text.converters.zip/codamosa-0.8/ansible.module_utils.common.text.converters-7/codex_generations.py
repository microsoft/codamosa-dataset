

# Generated at 2022-06-11 01:29:49.110382
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils._text import to_native, to_text

    for errors in (None, 'strict', 'surrogate_or_replace', 'surrogate_or_strict', 'surrogate_then_replace'):
        if errors == 'surrogate_or_replace' and not HAS_SURROGATEESCAPE:
            continue
        # A string that has no surrogates
        assert to_bytes(u'foo', errors=errors) == b'foo'
        # A string with surrogates
        assert to_bytes(u'\U0001f4a9', errors=errors) == b'\xf0\x9f\x92\xa9'
        if errors == 'surrogate_then_replace':
            # A string that is not encodable in latin-1
            assert to_

# Generated at 2022-06-11 01:30:00.639423
# Unit test for function to_native
def test_to_native():
    assert to_native('test') == u'test'
    assert to_native(u'test') == u'test'
    if PY3:
        assert to_native(b'test') == 'test'
        assert to_native(bytearray(b'test')) == 'test'
        assert to_native(5) == '5'
        assert to_native(5.5) == '5.5'
        assert to_native(b'\xe4\xb8\x96\xe7\x95\x8c', errors='surrogate_or_strict') == '\xe4\xb8\x96\xe7\x95\x8c'
    else:
        assert to_native(b'test') == u'test'

# Generated at 2022-06-11 01:30:11.899396
# Unit test for function to_native
def test_to_native():
    assert to_native(b'\xE2\x98\x83') == u'☃'
    assert to_native(u'xyz') == u'xyz'

    if PY3:
        prefix = u'bytes object: '
    else:
        prefix = u'str object: '

    assert to_native(b'xyz') == prefix + u'xyz'
    assert to_native(b'\xE2\x98\x83') == u'☃'
    assert to_native(b'\xe2\x98\x83') == prefix + u"b'\\\\xe2\\\\x98\\\\x83'"

# Generated at 2022-06-11 01:30:21.614678
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils._text import to_bytes

    def test_to_bytes_ex(expected, obj, encoding=None, errors=None, nonstring=None):
        assert expected == to_bytes(obj, encoding, errors, nonstring)

    # Check byte strings
    test_to_bytes_ex(b'', b'')
    test_to_bytes_ex(b'x', b'x')
    test_to_bytes_ex(b'', b'', encoding='utf-16')
    test_to_bytes_ex(b'x', b'x', encoding='utf-16')
    test_to_bytes_ex(b'x', b'x', encoding='utf-16', errors='strict')

# Generated at 2022-06-11 01:30:25.454763
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(1) == u'1'
    # assert to_native(to_text(b'foo')) == u'foo'

# Generated at 2022-06-11 01:30:35.794897
# Unit test for function to_native
def test_to_native():
    def _check(obj, expected):
        actual = to_native(obj)
        assert actual == expected

    # Test conversion of text strings
    _check(u'foo', 'foo')
    _check(u'\u2713', '\u2713')
    _check(u'\u2713'.encode('utf-8'), '\u2713')
    _check(u'\u2713'.encode('utf-16'), '\u2713')
    _check(u'\u2713'.encode('utf-32'), '\u2713')
    _check(u'\u2713'.encode('latin-1'), '\u2713')

    # Test conversion of byte strings
    _check(b'foo', 'foo')

# Generated at 2022-06-11 01:30:47.650790
# Unit test for function to_native
def test_to_native():
    import time

    # Test with bytestrings
    assert to_native('ni') == 'ni'
    assert to_native(u'ni') == 'ni'
    assert to_native(to_bytes('ni')) == u'ni'
    assert to_native(to_bytes(u'ni')) == u'ni'
    assert to_native(to_text('ni', errors='surrogate_or_strict')) == u'ni'

    # Test with regular strings
    assert to_native('ni') == 'ni'
    assert to_native(u'ni') == 'ni'
    assert to_native('ni', errors='surrogate_or_strict') == 'ni'
    assert to_native(u'ni', errors='surrogate_or_strict') == 'ni'
    # This works

# Generated at 2022-06-11 01:30:58.214448
# Unit test for function to_native
def test_to_native():
    """
    Test to_native function
    """
    if PY3:
        test_data = [
            (u'foo', 'foo'),
            (b'foo', 'foo'),
            (b'\xe1\x88\xb4', '\u1234'),
            (u'\u1234', '\u1234'),
            (b'\xff', '\ufffd')
        ]
    else:
        test_data = [
            (u'foo', u'foo'),
            (b'foo', u'foo'),
            (u'\u1234', u'\u1234'),
            (b'\xe1\x88\xb4', u'\u1234'),
            (b'\xff', '\xef\xbf\xbd')
        ]


# Generated at 2022-06-11 01:31:05.177601
# Unit test for function to_bytes
def test_to_bytes():
    import sys
    import types

    # Test with text strings
    assert to_bytes('hello') == b'hello'
    assert to_bytes('hello', encoding='ascii') == b'hello'
    assert to_bytes('\x80\x81', encoding='ascii', errors='strict') == b'\xc2\x80\xc2\x81'
    assert to_bytes('\x80\x81', encoding='ascii', errors='surrogate_or_strict') == b'\xc2\x80\xc2\x81'
    assert to_bytes('\x80\x81', encoding='ascii', errors='surrogate_or_replace') == b'\xc2\x80\xc2\x81'

# Generated at 2022-06-11 01:31:10.454360
# Unit test for function jsonify
def test_jsonify():
    data = {'key': 'value'}
    assert jsonify(data) == json.dumps(data)
    data = {'key': b'\x80'}
    try:
        jsonify(data)
        assert False == True
    except UnicodeDecodeError:
        # Good.
        assert True == True



# Generated at 2022-06-11 01:31:20.137501
# Unit test for function jsonify
def test_jsonify():
    check_result = jsonify({'a': 1, 'b': u'你好'}, sort_keys=True)
    assert check_result == '{"a": 1, "b": "你好"}'



# Generated at 2022-06-11 01:31:29.567046
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'asci\xe9') == b'asci\xc3\xa9'
    assert to_bytes(b'asci\xc3\xa9') == b'asci\xc3\xa9'
    assert to_bytes(b'asci\xe9', encoding='latin-1') == b'asci\xe9'
    assert to_bytes(u'asci\xe9', encoding='latin-1') == b'asci\xe9'
    assert to_bytes(u'asci\xe9', encoding='utf-8', errors='surrogate_or_replace') == b'asci\xc3\xa9'
    assert to_bytes

# Generated at 2022-06-11 01:31:35.212297
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.six import StringIO
    from .basic import gc_cache_reset
    gc_cache_reset()
    import sys

    # capture output
    real_stdout = sys.stdout
    fake_stdout = StringIO()
    sys.stdout = fake_stdout

    test_data = {
        u'a': u'foo',
        u'b': u'bar',
        u'c': [u'baz', u'qux'],
        u'd': {u'e': u'herp', u'f': u'derp'},
    }
    output = jsonify(test_data)

# Generated at 2022-06-11 01:31:47.273903
# Unit test for function to_native

# Generated at 2022-06-11 01:31:55.726035
# Unit test for function to_native
def test_to_native():
    assert to_native(u'my test') == u'my test'
    assert to_native(u'my test'.encode('utf-8')) == u'my test'
    assert to_native(u'my test'.encode('utf-16')) == u'my test'
    assert to_native(b'my test') == u'my test'
    assert to_native(u'¿my test?') == u'¿my test?'
    assert to_native(b'\xc2\xbfmy test\xc2\xbf') == u'¿my test¿'
    # assert to_native(b'\xc2\xbfmy test\xc2\xbf', errors='surrogate_or_strict') == u'¿my test¿'
    # assert to_native(b

# Generated at 2022-06-11 01:32:07.571916
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    import locale
    import sys

    if sys.version_info[0] < 3:
        assert to_native('abc') == b'abc'

    assert to_native(u'abc') == b'abc'
    assert to_native(5) == b'5'

    # Default encoding varies depending on the operating system
    # So we cannot check the output
    assert to_native(u'\u2318') is not None
    assert to_native(u'\u2318') != b''

    # However, we can assert that locale.getpreferredencoding returns the
    # same encoding as the default encoding used by to_native

# Generated at 2022-06-11 01:32:18.656125
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo', errors='surrogate_or_replace') == u'foo'
    assert to_native(u'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(b'foo', errors='surrogate_then_replace') == u'foo'
    if PY3:
        assert to_native(b'f\xed\xa1\xa3o', errors='surrogate_then_replace') == u'foo'

# Generated at 2022-06-11 01:32:30.517624
# Unit test for function to_bytes
def test_to_bytes():
    """ Tests for ansible.module_utils.basic.to_bytes """
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'foo'.encode('utf-16'), encoding='utf-16') == u'foo'.encode('utf-16')
    assert to_bytes(b'\xf1') == b'\xf1'
    assert to_bytes(u'\xf1') == b'\xc3\xb1'
    assert to_bytes(u'\xf1', 'latin-1') == b'\xf1'

# Generated at 2022-06-11 01:32:36.600390
# Unit test for function jsonify
def test_jsonify():

    # Test with a unicode string.
    data = u'\u7f51\u7edc'
    result = jsonify(data)
    assert result == '"\\u7f51\\u7edc"'

    # Test with a bytestring.
    data = b'\xd7\xf9\xd6\xd0'
    result = jsonify(data)
    assert result == '"\\u7f51\\u7edc"'



# Generated at 2022-06-11 01:32:48.409884
# Unit test for function to_native
def test_to_native():
    # Check that to_text handles byte strings correctly
    byte_strings = (
        (b'bytes', u'bytes'),
        (b'\x80\x81', u'\uFFFD\uFFFD'),
    )
    for bytes_string, unicode_string in byte_strings:
        assert to_text(bytes_string, errors='strict') == unicode_string

    # Check that to_bytes handles unicode strings correctly
    unicode_strings = (
        (u'unicode', b'unicode'),
        (u'\x80\x81', b'\xc2\x80\xc2\x81'),
    )
    for unicode_string, bytes_string in unicode_strings:
        assert to_bytes(unicode_string, errors='strict') == bytes_string

    # Check that

# Generated at 2022-06-11 01:33:06.830266
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=u"\u2603")) == '{"a": "\\u2603"}'
    assert jsonify(dict(a=u"\u2603"), ensure_ascii=False) == '{"a": "☃"}'
    assert jsonify(dict(a="☃")) == '{"a": "\\u2603"}'
    assert jsonify(dict(a="☃"), ensure_ascii=False) == '{"a": "☃"}'
    assert jsonify(dict(a="abc")) == '{"a": "abc"}'
    assert jsonify(dict(a="abc"), ensure_ascii=False) == '{"a": "abc"}'

    # Test data is just serialized using JSON, if no unicode chars

# Generated at 2022-06-11 01:33:15.653561
# Unit test for function jsonify
def test_jsonify():
    dict_test = {u'\u041c\u0430\u0440\u0442\u0438\u043d,': u'\u041c\u0430\u0440\u0442\u0438\u043d',
                 u'\u041c\u0430\u0440\u0442\u0438\u043d': u'\u041c\u0430\u0440\u0442\u0438\u043d'}
    result = jsonify(dict_test)
    print(result)



# Generated at 2022-06-11 01:33:21.978291
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1)) == '{"a": 1}'
    assert jsonify(dict(a=u'\u00f1')) == u'{"a": "\u00f1"}'
    assert jsonify(dict(a=u'\u00f1'), ensure_ascii=False) == u'{"a": "\\u00f1"}'
    assert jsonify([u'\u00f1', u'\u00f2']) == u'["\\u00f1", "\\u00f2"]'



# Generated at 2022-06-11 01:33:33.711949
# Unit test for function to_native
def test_to_native():
    assert to_native(u'ABC') == u'ABC'
    assert to_native('123') == u'123'
    assert to_native(123) == u'123'
    assert to_native(12.34) == u'12.34'
    assert to_native(b'123') == u'123'

    # Dicts and lists
    assert to_native({'a': 'b', 'c': 'd'}) == {'a': u'b', 'c': u'd'}
    assert to_native({'a': 'b', 'c': 'd'}, expand_lists=True) == {'a': u'b', 'c': u'd'}

# Generated at 2022-06-11 01:33:41.739531
# Unit test for function to_native
def test_to_native():
    assert to_native(b'\xff') == '\xff'
    assert to_native(u'\u1234') == '\u1234'

    assert to_native(b'\xff', nonstring='simplerepr') == '\xff'
    assert to_native(u'\u1234', nonstring='simplerepr') == '\u1234'

    assert to_native(b'\xff', nonstring='passthru') == b'\xff'
    assert to_native(u'\u1234', nonstring='passthru') == u'\u1234'


# Generated at 2022-06-11 01:33:51.879136
# Unit test for function to_bytes
def test_to_bytes():
    # Test default encoding
    assert to_bytes(u'россия') == b'\xd1\x80\xd0\xbe\xd1\x81\xd1\x81\xd0\xb8\xd1\x8f'

    # Test surrogateescape encoding
    if HAS_SURROGATEESCAPE:
        for errors in ('surrogate_or_replace', 'surrogate_then_replace', 'surrogate_or_strict'):
            assert to_bytes(u'\udc80', errors=errors) == b'\x80'

    # Test nonstring handling
    assert to_bytes(None, nonstring='passthru') is None
    assert to_bytes((), nonstring='simplerepr') == b'()'

# Generated at 2022-06-11 01:34:03.021101
# Unit test for function to_bytes
def test_to_bytes():
    def do_test(input_value, encoding='utf-8', errors='surrogate_then_replace',
                nonstring='simplerepr'):
        if errors == 'ignore' and not PY3:
            # ignore is only valid in python3
            return to_bytes(input_value, encoding='utf-8',
                            errors='surrogate_then_replace', nonstring=nonstring)

        return to_bytes(input_value, encoding=encoding, errors=errors, nonstring=nonstring)

    try:
        codecs.lookup_error('surrogateescape')
    except LookupError:
        pass
    else:
        # surrogateescape should always work if we're in python3
        assert do_test('abcd\udc80', errors=None) == b'abcd\xdc\x80'

# Generated at 2022-06-11 01:34:12.647796
# Unit test for function to_native
def test_to_native():
    # Pass through None
    assert to_native(None) is None

    # Pass through integers
    assert to_native(0) == 0
    assert to_native(1) == 1
    assert to_native(2**64) == 2**64

    # Pass through floats
    assert to_native(0.0) == 0.0
    assert to_native(1.0) == 1.0

    # Pass through dicts
    assert to_native({}) == {}
    assert to_native(dict(a=1, b=2)) == dict(a=1, b=2)

    # Pass through lists
    assert to_native([]) == []
    assert to_native([1, 2, 3]) == [1, 2, 3]

    # Pass through tuples
    assert to_native(()) == ()
    assert to_

# Generated at 2022-06-11 01:34:24.480754
# Unit test for function jsonify
def test_jsonify():
    expected_json_str = '{"key": "\ufffd"}'
    test_dict = {
        'key': '\xe3'
    }
    json_str = jsonify(test_dict)
    assert json_str == expected_json_str
    assert jsonify(test_dict) == expected_json_str
    assert jsonify(test_dict, ensure_ascii=False) == expected_json_str
    not_ascii_string = "这是一个测试"
    try:
        json_str = jsonify(not_ascii_string)
        raise Exception('Encoding should be failed in case of not ascii string')
    except UnicodeDecodeError:
        pass
    json_str = jsonify(not_ascii_string, ensure_ascii=False)

# Generated at 2022-06-11 01:34:34.119514
# Unit test for function to_bytes
def test_to_bytes():
    # Some of these will fail on python2.4 so we have to skip them
    from distutils.version import LooseVersion
    import sys

    if sys.version_info < (2, 5):
        raise nose.SkipTest('too old to test')

    # Test that it handles unicode
    text = u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert text == to_bytes(to_bytes(text))

    # Test that it handles ascii text
    assert 'hello' == to_bytes(to_bytes('hello'))

    # Test that it can force utf8 even if the text begins with non-utf8 bytes
    assert b'hello\xc2\xa2' == to_bytes('hello\xa2', encoding='utf8')


# Generated at 2022-06-11 01:34:55.300946
# Unit test for function jsonify
def test_jsonify():
    class TestObj(object):
        def __repr__(self):
            return('foo')

# Generated at 2022-06-11 01:34:58.254742
# Unit test for function to_native
def test_to_native():
    assert to_native(b'text', 'utf-8') == 'text'
    assert to_native(b'text') == 'text'
    assert to_native(u'text') == 'text'



# Generated at 2022-06-11 01:35:00.510944
# Unit test for function jsonify
def test_jsonify():
    assert(jsonify({u'unicode test': u'value'}) == '{"unicode test": "value"}')



# Generated at 2022-06-11 01:35:06.529415
# Unit test for function jsonify
def test_jsonify():
    test_dict = {'spam': 'eggs', b'spam': {u'eggs': u'foo'}, u'spam': {u'eggs': u'foo'}}
    assert jsonify(test_dict) == u'{"spam": {"eggs": "foo"}, "spam": {"eggs": "foo"}, "spam": "eggs"}'



# Generated at 2022-06-11 01:35:17.772138
# Unit test for function jsonify
def test_jsonify():
    # Make sure that the Set serialization works correctly in jsonify
    json_obj = jsonify(dict(a=Set([1,2,3])))
    assert json_obj == '{"a": [1, 2, 3]}'

    # Make sure that a datetime object can be serialized correctly
    date_obj = datetime.datetime(2012, 12, 12, 12, 12, 12, 12)
    json_obj = jsonify(dict(a=date_obj))
    assert json_obj == '{"a": "2012-12-12T12:12:12.000012"}'

    # Make sure that a string will be serialized correctly
    str_obj = '{"a": [1, 2, 3]}'
    json_obj = jsonify(str_obj)
    assert json_obj == str_obj

    # Make

# Generated at 2022-06-11 01:35:28.024939
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(to_text(b'\xc3\xbc', 'utf-8'), 'utf-8') == b'\xc3\xbc'
    assert to_bytes(to_text(b'\xc2\xa2', 'latin-1'), 'latin-1') == b'\xc2\xa2'
    assert to_bytes(to_text(b'\xc3\xb6', 'utf-8'), 'latin-1', errors='strict') == b'\xc3\xb6'
    assert to_bytes(to_text(b'\xc3\x8b', 'utf-8'), 'latin-1', errors='replace') == b'?'

# Generated at 2022-06-11 01:35:38.468402
# Unit test for function to_bytes
def test_to_bytes():
    # Test basic usage
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='utf-16') == b'\xff\xfe\x34\x12'
    assert to_bytes(b'\xe1\x88\xb4', encoding='latin-1') == b'\xe1\x88\xb4'

    # Test unicode errors
    assert to_bytes(u'\u1234\ufffd') == b'\xe1\x88\xb4\xef\xbf\xbd'
    assert to_bytes(u'\u1234\ufffd', errors='replace') == b'\xe1\x88\xb4\xef\xbf\xbd'
    assert to

# Generated at 2022-06-11 01:35:46.545412
# Unit test for function to_bytes
def test_to_bytes():
    """
    >>> test_to_bytes()
    """
    # Test that we can pass a non-string type
    bytes_string = to_bytes(5)
    assert isinstance(bytes_string, binary_type)

    # Test that we can pass a text string
    bytes_string = to_bytes(u'The mudskipper is a fish.')
    assert isinstance(bytes_string, binary_type)
    assert u'The mudskipper is a fish.' == to_text(bytes_string, errors='surrogate_then_replace')

    # Test that surrogates are preserved
    bytes_string = to_bytes(u'The mudskipper is a fish.  \U0001f40c')
    assert isinstance(bytes_string, binary_type)

# Generated at 2022-06-11 01:35:49.486709
# Unit test for function to_native
def test_to_native():
    result = to_native('“value”')
    assert isinstance(result, str)
    assert result == '“value”'


# Generated at 2022-06-11 01:35:59.870230
# Unit test for function jsonify
def test_jsonify():
    import sys
    input_data = {'a': '\xc3\xa1'}
    try:
        expected_result = json.dumps(input_data)
        actual_result = jsonify(input_data)
        assert actual_result == expected_result
        print("PASSED: jsonify()")
    except (AssertionError, UnicodeDecodeError):
        print("FAILED: jsonify()")
    if sys.version_info >= (3, 0):
        return

# Generated at 2022-06-11 01:36:20.549153
# Unit test for function to_native
def test_to_native():
    # When native strings are unicode in Python 2 and str in Python 3
    if PY3:
        native_str = str
        text_str = str
        text_repr = repr
    else:
        native_str = unicode
        # In Python2, str produces a byte string
        text_str = lambda obj: to_text(str(obj))
        # In Python2, repr produces an ascii byte string
        text_repr = lambda obj: to_text(repr(obj))

    class WeirdObject(object):
        # In Python2 unicode() calls __str__ internally
        def __str__(self):
            return to_text(b'\xff')

        def __repr__(self):
            return to_text(b'\xff')

        # In Python3 str() calls __str__ internally


# Generated at 2022-06-11 01:36:30.581094
# Unit test for function to_bytes
def test_to_bytes():
    import sys

    if sys.version_info < (3, 7):
        # Test surrogate_or_strict error handler
        if HAS_SURROGATEESCAPE:
            assert to_bytes(u'\udc00\ud800', errors='surrogate_or_strict') == b'\xed\xb0\x80\xed\xa0\x80'
        # Test surrogate_or_replace error handler
        if HAS_SURROGATEESCAPE:
            assert to_bytes(u'\udc00\ud800', errors='surrogate_or_replace') == b'\xed\xb0\x80\xed\xa0\x80'

# Generated at 2022-06-11 01:36:37.145224
# Unit test for function to_bytes
def test_to_bytes():
    try:
        codecs.lookup_error('strict')
        HAS_STRICT = True
    except LookupError:
        HAS_STRICT = False

    def check_result(obj, encoding, errors, result):
        assert to_bytes(obj, encoding=encoding, errors=errors) == result
        if PY3:
            assert type(to_bytes(obj, encoding=encoding, errors=errors)) == bytes

    check_result('', encoding='ascii', errors='surrogateescape', result=b'')
    check_result('abc', encoding='ascii', errors='surrogateescape', result=b'abc')
    check_result('\u4321', encoding='ascii', errors='surrogateescape', result=b'\udc21')

# Generated at 2022-06-11 01:36:48.580517
# Unit test for function to_bytes
def test_to_bytes():
    SURROGATE_OR_REPLACE = (HAS_SURROGATEESCAPE and 'surrogateescape') or 'replace'
    SURROGATE_OR_STRICT = (HAS_SURROGATEESCAPE and 'surrogateescape') or 'strict'

    # Test bytes path
    assert to_bytes('\xe2\x98\x83') == b'\xe2\x98\x83'

    # Test unicode path
    assert to_bytes(u'\u2603') == b'\xe2\x98\x83'

    # Test non-string path
    assert to_bytes(datetime.datetime.now(), nonstring='simplerepr') == to_bytes(repr(datetime.datetime.now()))

    # Test encoding

# Generated at 2022-06-11 01:36:55.047532
# Unit test for function to_bytes
def test_to_bytes():
    # Test ascii bytes
    assert to_bytes(b'hello world') == b'hello world'
    assert to_bytes(b'hello world', nonstring='empty') == b''
    assert to_bytes(b'hello world', nonstring='passthru') == b'hello world'

    # Test ascii text
    assert to_bytes('hello world') == b'hello world'
    assert to_bytes('hello world', nonstring='empty') == b''
    assert to_bytes('hello world', nonstring='passthru') == 'hello world'

    # Test unicode text (no surrogates)
    assert to_bytes(u'helló') == b'hell\xc3\xb3'
    assert to_bytes(u'helló', nonstring='empty') == b''

# Generated at 2022-06-11 01:37:02.363891
# Unit test for function to_native
def test_to_native():
    assert to_native(u'string') == u'string'
    assert to_native(b'bytes') == u'bytes'
    assert to_native(None) == u'None'
    assert to_native(23) == u'23'
    assert to_native(23.0) == u'23.0'
    assert to_native(23.5) == u'23.5'
    assert to_native(datetime.datetime(2001, 2, 3, 4, 5, 6)) == u'2001-02-03 04:05:06'
    assert to_native(datetime.date(2001, 2, 3)) == u'2001-02-03'
    assert to_native(datetime.time(4, 5, 6)) == u'04:05:06'

# Generated at 2022-06-11 01:37:03.398863
# Unit test for function to_native
def test_to_native():
    pass


# Generated at 2022-06-11 01:37:05.557167
# Unit test for function to_native
def test_to_native():
    assert to_native(1) == 1


# Generated at 2022-06-11 01:37:16.808235
# Unit test for function jsonify
def test_jsonify():
    import json
    import datetime
    # assume the default encoding is utf-8
    assert jsonify(b'ascii') == u'"ascii"'
    assert jsonify(u'\u2603') == u'"\u2603"'
    # assume the default encoding is utf-8
    assert jsonify(datetime.datetime.now())

    # Old simplejson does not supports encoding keyword.
    old_json = json
    if hasattr(json.dumps, '__globals__'):
        json.dumps.__globals__['__builtins__']['str'] = unicode
    else:
        json.dumps.func_globals['__builtins__']['str'] = unicode
    assert jsonify(u'unicode') == u'"unicode"'
    assert json

# Generated at 2022-06-11 01:37:23.243224
# Unit test for function to_native
def test_to_native():
    class Foo(object):
        def __repr__(self):
            return u'Baz'

        def __str__(self):
            return u'Quux'

    class Bar(object):
        def __repr__(self):
            return 'Baz'

        def __str__(self):
            return 'Quux'

    class Qux(object):
        def __repr__(self):
            return 'Baz' + 'uhoh'.decode('ascii')

        def __str__(self):
            return 'Quux' + 'uhoh'.decode('ascii')

    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'

# Generated at 2022-06-11 01:37:38.034180
# Unit test for function to_bytes
def test_to_bytes():
    for i in ('abc', '\xe5\xf6\xe5', '\xff', '\x00', '\xe5\xf6\xe5\xff', u'\u262f', u'\U0001f4a9'):
        print(to_bytes(i))
test_to_bytes()


# Generated at 2022-06-11 01:37:43.077585
# Unit test for function jsonify
def test_jsonify():
    data = dict(a=1, b=2, c=[1, 2, 3], d=dict(aa=11, bb=22))
    assert jsonify(data) == json.dumps(data, default=_json_encode_fallback)
    data = dict(a=[1, dict(b=2, c=3, d=dict(e=4, f='中文'), g=u'中文'), 5])
    assert jsonify(data) == json.dumps(data, default=_json_encode_fallback)
    data = dict(a=1, b=2, c=[1, 2, 3], d=dict(aa=11, bb=22))

# Generated at 2022-06-11 01:37:46.049339
# Unit test for function jsonify
def test_jsonify():
    if PY3:
        assert jsonify(u"english") == '"english"'
    else:
        assert jsonify(u"english") == '"english"'
        assert jsonify("english") == '"english"'



# Generated at 2022-06-11 01:37:57.519241
# Unit test for function jsonify
def test_jsonify():
    # Unicode string
    assert u('{"foo":"bar"}') == jsonify({u('foo'):u('bar')})
    assert u('["foo","bar"]') == jsonify([u('foo'),u('bar')])
    # Byte string as key or value
    assert u('{"foo":"bar"}') == jsonify({b('foo'):b('bar')})
    assert u('{"foo":"bar"}') == jsonify({u('foo'):b('bar')})
    assert u('{"foo":"bar"}') == jsonify({u('foo'):b('bar')})
    assert u('["foo","bar"]') == jsonify([b('foo'),b('bar')])
    assert u('["foo","bar"]') == jsonify([u('foo'),b('bar')])
    assert u('["foo","bar"]') == jsonify

# Generated at 2022-06-11 01:38:00.003239
# Unit test for function to_native
def test_to_native():
    assert to_native(b'hello') == 'hello'
    assert to_native(u'hello') == 'hello'

# Generated at 2022-06-11 01:38:09.240979
# Unit test for function to_bytes
def test_to_bytes():
    # pylint: disable=unreachable

    if PY3:
        # This test is meaningless in Python3 as you can't have surrogates in strings
        # and therefore you can't get the surrogate escape
        raise NotImplementedError

    test_string = u'\u30c6\u30b9\u30c8'
    test_bytes = b'\xe3\x83\x86\xe3\x82\xb9\xe3\x83\x88'

    # Testing nonstring='simplerepr'
    test_obj = object()
    obj_string = str(test_obj)
    obj_bytes = test_obj.encode('utf-8')
    assert to_bytes(test_obj, nonstring='simplerepr') == obj_bytes

# Generated at 2022-06-11 01:38:14.520051
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', encoding='ascii') == u'\ufffd'



# Generated at 2022-06-11 01:38:23.786367
# Unit test for function jsonify
def test_jsonify():
    data = {
        "ascii": b"ascii value",
        "utf8": u"h\xe9llo \u20ac",
        "ignore": b"\xff",
        "replace": b"\xff",
        "nested": {
            "ascii": b"ascii value",
            "utf8": u"h\xe9llo \u20ac",
            "ignore": b"\xff",
            "replace": b"\xff"
        }
    }

# Generated at 2022-06-11 01:38:34.554224
# Unit test for function to_native
def test_to_native():
    # This isn't a real unit test.  It's just here to document how to use
    # the function and serve as a sanity check.
    if PY3:
        assert to_native(u'foo') == u'foo'
        assert to_native(b'foo') == u'foo'
        assert to_native(u'\u1234') == u'\u1234'
        assert to_native(b'\xe1\x88\xb4') == u'\u1234'
        assert to_native(b'\xff') == u'\ufffd'
        assert to_native(['foo']) == ['foo']
    else:
        assert to_native(u'foo') == 'foo'
        assert to_native(b'foo') == 'foo'

# Generated at 2022-06-11 01:38:37.536698
# Unit test for function jsonify
def test_jsonify():
    data = {u'a': 1, b'b': 2, 'c': 3}
    res = jsonify(data)
    print("test_jsonify passed")


# Generated at 2022-06-11 01:39:07.480003
# Unit test for function jsonify
def test_jsonify():
    import copy
    from ansible.module_utils._text import to_text, to_bytes
    from six import PY3
    import datetime

    text_type = to_text(b'unicode: foo', errors='surrogate_or_strict')
    binary_type = to_bytes(u'unicode: foo', encoding='utf-8', errors='surrogate_or_strict')
    if PY3:
        basic_types = (text_type, binary_type)
    else:
        basic_types = (binary_type,)

    # Old systems using old simplejson module does not support encoding keyword.
    try:
        json.dumps(b'foo', encoding='utf-8')
        encoding_keyword = True
    except TypeError:
        encoding_keyword = False


# Generated at 2022-06-11 01:39:18.973972
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_bytes
    data = {
        'bytes': to_bytes('\xc4\x85'),
        'utf-8': '\xc4\x85',
        'unicode': u'\u0105',
        'bad unicode': '\xc4\x85',
        'non-string': {'foo': 'bar'},
        'datetime': datetime.datetime.utcnow(),
        'set': set([1, 2, 3])
    }
    json_data = jsonify(data)
    assert('"utf-8": "\\u0105"' in json_data)
    assert('"set": [1, 2, 3]' in json_data)
    assert('"non-string": {' in json_data)

# Generated at 2022-06-11 01:39:30.073565
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('test', 'utf-8') == b'test'
    assert to_bytes('test', 'utf-8', nonstring='empty') == b''
    assert to_bytes(u'\u043f', 'utf-8') == b'\xd0\xbf'
    assert to_bytes(u'\u043f', 'utf-8', errors='replace') == b'?'
    assert to_bytes(u'\u043f', 'utf-8', errors='surrogate_or_strict') == b'\xd0\xbf'
    assert to_bytes(u'\u043f', 'ascii') == b'?'
    assert to_bytes(u'\u043f', 'ascii', errors='surrogate_or_strict') == b'?'
    assert to_bytes

# Generated at 2022-06-11 01:39:33.547620
# Unit test for function jsonify
def test_jsonify():
    try:
        data = jsonify({'a': 'b'})
    except UnicodeError:
        pass
    else:
        raise AssertionError('Data was jsonified without error.')

# Unit tests for function json_encode_fallback