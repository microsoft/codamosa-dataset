

# Generated at 2022-06-11 01:30:05.259242
# Unit test for function to_bytes
def test_to_bytes():
    # to_bytes(obj, encoding='utf-8', errors=None, nonstring='simplerepr')
    # obj: object to make sure is a byte string.
    # encoding: The encoding to use to transform from a text string to a byte string.
    # errors: The error handler to use if the text string is not encodable using the
    # specified encoding.
    # nonstring: The strategy to use if a nonstring is specified in obj.
    # Returns: Typically this returns a byte string.
    # If a nonstring object is passed in this may be a different type depending on
    # the strategy specified by nonstring. This will never return a text string.
    assert to_bytes('') == b''
    assert to_bytes('Hello') == b'Hello'
    assert to_bytes(u'Hello') == b'Hello'

# Generated at 2022-06-11 01:30:15.000610
# Unit test for function to_bytes
def test_to_bytes():

    assert to_bytes('言') == b'\xe8\xa8\x80'
    # make sure we can encode utf-16 surrogate pairs
    assert to_bytes('\U0001D120') == b'\xf0\x9d\x84\xa0'
    assert to_bytes(b'\xe8\xa8\x80') == b'\xe8\xa8\x80'
    assert to_bytes(1) == b'1'
    test_string = '\xe8\xa8\x80 abcd'
    assert to_bytes('\xe8\xa8\x80 abcd') == test_string.encode('utf-8')

    # make sure we have surrogates

# Generated at 2022-06-11 01:30:25.492864
# Unit test for function jsonify

# Generated at 2022-06-11 01:30:35.838031
# Unit test for function to_bytes
def test_to_bytes():
    for test_obj in (b'bytes', 'text \xe2\x98\x83', u'unicode \u2603'):
        yield (test_obj, 'utf-8', None, 'simplerepr', b'text \xe2\x98\x83')
        yield (test_obj, 'utf-8', 'surrogate_or_replace', 'simplerepr', b'text \xe2\x98\x83')
        yield (test_obj, 'utf-8', 'surrogate_or_strict', 'simplerepr', b'text \xe2\x98\x83')
        yield (test_obj, 'utf-8', 'surrogate_then_replace', 'simplerepr', b'text \xe2\x98\x83')

# Generated at 2022-06-11 01:30:40.678191
# Unit test for function jsonify
def test_jsonify():
    """
    Test that JSON serialization works
    """
    # Just test that it serializes, not how it serializes.
    jsonify(dict(a=1, b=2, c=3))
    # Test that unicode strings are handled properly
    jsonify(dict(a=1, b=u"foo", c=3))



# Generated at 2022-06-11 01:30:52.491665
# Unit test for function to_native
def test_to_native():
    assert 'test' == to_native('test')
    assert u'test' == to_native(u'test')
    assert u'test' == to_native('test', errors='surrogate_then_replace')
    assert 'test' == to_native(b'test', encoding='utf-8')
    assert u'test' == to_native('test', encoding='utf-8')
    assert b'test' == to_native('test', encoding='utf-8',
                                errors='surrogate_or_strict')
    assert b'test' == to_native(u'test', encoding='utf-8',
                                errors='surrogate_or_strict')
    assert u'test' == to_native('test', encoding='utf-8',
                                errors='surrogate_then_replace')

# Generated at 2022-06-11 01:31:01.980043
# Unit test for function jsonify
def test_jsonify():
    class TestClass:
        def __init__(self, val=None):
            self.val = val
        def __repr__(self):
            return "TestClass(%s)" % self.val
        def __eq__(self, other):
            if self.val == other:
                return True
            return False

    class TestClass1(TestClass):
        def __init__(self, val=None):
            TestClass.__init__(self, val)
        def __str__(self):
            return "TestClass1(%s)" % self.val

    class TestClass2(TestClass):
        def __init__(self, val=None):
            TestClass.__init__(self, val)
        def __unicode__(self):
            return u"TestClass2(%s)" % self.val

# Generated at 2022-06-11 01:31:13.401927
# Unit test for function to_bytes
def test_to_bytes():
    # These are all text strings
    u_ascii = u'foo'
    u_nonascii = u'föö'
    b_ascii = u_ascii.encode('utf8')
    b_nonascii = u_nonascii.encode('utf8')
    u_surrogates = u'\ud800\udfff\ud800\udbff\udc00'
    u2_surrogates = u'\ud800\udbff\udc00'
    b = b'\xed\xa0\x80\xed\xbf\xbf\xed\xa0\x80\xed\xaf\xbf\xed\xb0\x80'

    # These are nonstrings
    nonstring = []
    nonstring_repr

# Generated at 2022-06-11 01:31:24.416346
# Unit test for function to_bytes
def test_to_bytes():
    # Basic functionality
    assert to_bytes(u'test') == b'test'
    assert to_bytes(u'\u00e9') == b'\xc3\xa9'
    assert to_bytes(u'\u00e9', 'ascii') == b'\xe9'
    assert to_bytes(u'\u00e9', 'ascii', 'surrogate_or_replace') == b'\xe9'
    assert to_bytes(u'\u00e9', 'ascii', 'surrogateescape') == b'\xe9'
    assert to_bytes(u'\u00e9', 'ascii', 'surrogate_or_strict') == b'\xe9'

# Generated at 2022-06-11 01:31:32.157525
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native

    # Zero length byte string
    assert to_native(b'') == '' and type(to_native(b'')) is str

    # Zero length text string
    assert to_native(u'') == '' and type(to_native(u'')) is str

    # Zero length text string (slightly larger)
    assert to_native(u'\u2800') == u'\u2800' and type(to_native(u'\u2800')) is str

    # Byte string to text string
    assert to_native(b'\xe9') == u'\xe9' and type(to_native(b'\xe9')) is str

    # Non-string values

# Generated at 2022-06-11 01:31:49.149300
# Unit test for function to_native
def test_to_native():
    for obj, encoded in ((u'\xe4', u'\xe4'), ('\xc3\xa4', u'\xe4'), (1, u'1'), (True, u'True'), (False, u'False'),
                         (datetime.datetime(1, 1, 1), u'0001-01-01 00:00:00'), ({}, u"{}"), (set(), u'set()'),
                         (Set(), u'{}'), (Dot(), u"{'foo': 'one'}")):
        assert to_native(obj) == encoded
        assert to_native(obj, nonstring='passthru') == obj

    # Test that we can pass in nonstrings to to_native
    assert u'1' == to_native(1)
    assert u'True' == to_native(True)
    assert u

# Generated at 2022-06-11 01:31:56.771585
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'fóo') == b'f\xc3\xb3o'
    assert to_bytes(b'foo', errors='surrogate_or_replace') == b'foo'
    assert to_bytes(b'f\xc3\xb3o', errors='surrogate_or_replace') == b'f\xc3\xb3o'
    assert to_bytes(b'\xff') == b'\xff'
    assert to_bytes(b'\xff', errors='surrogate_or_replace') == b'\xff'

    try:
        to_bytes(b'\xff\n')
        raise AssertionError
    except UnicodeDecodeError:
        pass


# Generated at 2022-06-11 01:32:09.041058
# Unit test for function to_bytes
def test_to_bytes():
    """Unit test for converting text strings to bytes

    This test is for a specific version of Python and should be run
    with that specific version of Python.  For example, to run this
    test in Python3.3::

        $ /usr/bin/python3.3 test_to_bytes.py

    Running the same test with Python3.4 will not work because the
    ``surrogateescape`` handler is expected to work and the test was
    written before the ``surrogateescape`` handler was available.

    .. versionadded:: 2.3
    """

    # Test strings with surrogates:
    #
    # The first test string ends with a single surrogate.  It is valid UTF-16 and
    # attempted conversion to UTF-8 should fail with 'surrogateescape'.
    #
    # The second test string has a surrogate pair (two code points in

# Generated at 2022-06-11 01:32:19.539711
# Unit test for function jsonify
def test_jsonify():
    failure_message = 'jsonify failed'
    obj1 = {'a': 1, 'b': 2, 'c': 3}
    obj2 = '{\"a\": 1, \"b\": 2, \"c\": 3}'
    obj3 = {'a': [1, 2, 'a', 'b'], 'b': {'c': 7}, 'c': '123'}
    obj4 = '{\"a\": [1, 2, \"a\", \"b\"], \"b\": {\"c\": 7}, \"c\": \"123\"}'
    obj5 = ['234', {'a': 1, 'b':'23'}, 'a']
    obj6 = '["234", {"a": 1, "b": "23"}, "a"]'
    obj7 = {'a': Set([1,2,3])}
    obj

# Generated at 2022-06-11 01:32:25.028093
# Unit test for function to_native
def test_to_native():
    assert isinstance(to_native(u'abc'), text_type)
    assert isinstance(to_native(b'abc'), text_type)
    assert not isinstance(to_native(u'abc'), binary_type)
    assert isinstance(to_native(b'abc', nonstring='simplerepr'), binary_type)



# Generated at 2022-06-11 01:32:29.384974
# Unit test for function jsonify
def test_jsonify():
    data = [{"a": {"b": "\\x00x"}}]
    data_json = b'[{"a": {"b": "\\\\x00x"}}]'
    output = jsonify(data)
    assert data_json == output


# Generated at 2022-06-11 01:32:38.821428
# Unit test for function to_native
def test_to_native():
    def test(input, expected_output, encoding=None, errors='surrogate_then_replace', expected_type=None, msg=None):
        actual_output = to_native(input, encoding=encoding, errors=errors)
        if expected_type is not None:
            assert isinstance(actual_output, expected_type), 'Failed to get proper type from to_native.  Expected %s but got %s' % (expected_type, type(actual_output))
        assert actual_output == expected_output, '"%s" != "%s" (%s)' % (actual_output, expected_output, msg or '')

    test(u'\u00E9', u'\u00E9', 'ascii', 'surrogate_then_replace', msg='surrogates replaced before decoding')

# Generated at 2022-06-11 01:32:40.949084
# Unit test for function jsonify
def test_jsonify():
    # just call it to make sure it doesn't fail
    jsonify({})



# Generated at 2022-06-11 01:32:43.682062
# Unit test for function jsonify
def test_jsonify():
    data = u"{\"v\u2012v\": 3}"
    result = jsonify(data)
    assert result == data



# Generated at 2022-06-11 01:32:52.717394
# Unit test for function to_native
def test_to_native():
    # Define 'surrogateescape' error handler (if not already defined)
    if not HAS_SURROGATEESCAPE:
        # This is the same definition as in the Python 3.4 standard library
        def surrogateescape(exc):
            bytes = exc.object[exc.start:exc.end]
            return (int(b, 16).to_bytes(1, byteorder='big') for b in bytes.decode('ascii').split())
        codecs.register_error('surrogateescape', surrogateescape)

    # Test that surrogate_then_replace error handler works
    to_native_str = to_text(str(u"\uDC80"), encoding='utf-8', errors='surrogate_then_replace')
    assert to_native_str == u"\uFFFD"

    # Test that surrogate_or

# Generated at 2022-06-11 01:32:59.887583
# Unit test for function to_native
def test_to_native():
    # Tested via the to_bytes tests
    pass



# Generated at 2022-06-11 01:33:11.889633
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.basic import to_bytes, to_text
    assert to_bytes('abc') == b'abc'
    assert to_bytes(b'abc') == b'abc'
    assert to_bytes(to_text(b'abc\xe0', 'latin-1'), 'utf-8') == b'abc\xe0'
    assert to_bytes(to_text(b'abc\xe0', 'ascii'), 'utf-8', errors='surrogate_or_strict') == b'abc\xe0'
    assert to_bytes(to_text(b'abc\xe0', 'ascii'), 'utf-8', errors='surrogate_or_replace') == b'abc\xef\xbf\xbd'

# Generated at 2022-06-11 01:33:21.448307
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({}) == u'{}'
    assert jsonify([False]) == u'[false]'
    assert jsonify(u'\u1234') == u'"\u1234"'
    assert jsonify(b'\xe9') == u'"\xe9"'
    assert jsonify(u'\xe9'.encode('latin-1')) == u'"\xe9"'
    assert jsonify({u'k': u'\xe9'}) == u'{"k": "\xe9"}'
    assert jsonify({u'k': u'\u1234'}) == u'{"k": "\u1234"}'
    assert jsonify({u'k': u'\u1234'.encode('utf-8')}) == u'{"k": "\u1234"}'

# Generated at 2022-06-11 01:33:32.868403
# Unit test for function to_bytes
def test_to_bytes():
    # Test that to_bytes doesn't fail when passed a non-string or make changes
    # to the object.  Note that we're not actually testing that the correct
    # string is returned yet.  That should come in another commit.
    real_function = to_bytes

    class Test(object):
        def __str__(self):
            return b'Test'

    def to_bytes(obj, *args, **kwargs):
        try:
            return real_function(obj, *args, **kwargs)
        except TypeError:
            return 'TypeError'

    # Test that none of the non-string options raises a TypeError
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='simplerepr') == b'1'

# Generated at 2022-06-11 01:33:43.321656
# Unit test for function to_bytes
def test_to_bytes():
    import sys

    # Test Unicode -> bytes path
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogateescape') == b'\xe1\x88\xb4'
    assert to_bytes(u'\udce4\udc00', errors='surrogateescape') == b'\xf0\x90\x90\x80'
    assert to_bytes(u'\udce4\udc00', errors='strict') == b'\xf0\x90\x90\x80'

# Generated at 2022-06-11 01:33:54.414243
# Unit test for function to_bytes
def test_to_bytes():
    # Test byte string input gets a byte string back
    assert to_bytes('abc') == b'abc'
    assert to_bytes(b'abc') == b'abc'

    # Test text string input gets a byte string back
    assert to_bytes(u'abc') == b'abc'

    # Test non-string input with simplerepr gets a byte string back
    assert to_bytes(3) == b'3'
    # via __repr__
    assert to_bytes(Set([1, 2, 3, 4])) == b'{1, 2, 3, 4}'

    # Test non-string input with passthru gets the object back
    assert to_bytes(3, nonstring='passthru') == 3
    assert to_bytes(Set([1, 2, 3, 4]), nonstring='passthru') == Set

# Generated at 2022-06-11 01:34:05.395541
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == u'foo'
    assert to_native(b'\xe2\x9d\xa4') == u'\u2764'
    assert to_native(b'\xe2\x9d\xa4\xe2\x9d\xa4') == u'\u2764\u2764'
    assert to_native(u'\u2764') == u'\u2764'
    assert to_native(u'\u2764\u2764') == u'\u2764\u2764'
    assert to_native(1) == u'1'
    assert to_native(0.5) == u'0.5'
    assert json.loads(to_native(json.dumps(u'foo'))) == u'foo'
    assert json

# Generated at 2022-06-11 01:34:13.959354
# Unit test for function to_bytes
def test_to_bytes():
    import sys
    import doctest
    from ansible.module_utils.basic import AnsibleFallbackNotUTF8

    # Manually set surrogateescape error handler for Python2
    if sys.version_info[0] < 3:
        from ansible.module_utils.six import reraise
        from ansible.module_utils.six import text_type

        class SurrogateEscapeError(UnicodeEncodeError, UnicodeDecodeError):
            pass

        def surrogateescape_handler(exception):
            if isinstance(exception, UnicodeEncodeError):
                return (text_type(exception.object[exception.start:exception.end]),
                        exception.end)

# Generated at 2022-06-11 01:34:25.306795
# Unit test for function jsonify
def test_jsonify():
    # Test primitives
    assert jsonify('strong') == '"strong"'
    assert jsonify(u'strong') == '"strong"'
    assert jsonify('strong') == '"strong"'
    assert jsonify(1234) == '1234'
    assert jsonify(1.234) == '1.234'
    assert jsonify(True) == 'true'
    assert jsonify(False) == 'false'
    assert jsonify(None) == 'null'

    # Test lists
    list_of_strings = ['string', 'strong', 'strung']
    list_of_numbers = [123, 456, 789]
    list_of_floats = [1.23, 4.56, 7.89]
    list_of_bools = [True, False, True]
    list_of_null

# Generated at 2022-06-11 01:34:34.678663
# Unit test for function to_bytes
def test_to_bytes():
    # Keep tests portable between Python2 and Python3
    try:
        u = unicode
    except NameError:
        u = str


    t1 = 'This is a string'
    b1 = to_bytes(t1)
    assert isinstance(b1, binary_type)
    assert b1 == b'This is a string'

    t2 = u('Héllo')
    b2 = to_bytes(t2)
    assert isinstance(b2, binary_type)
    assert b2 == b'H\xc3\xa9llo'

    t3 = 'Héllo'
    b3 = to_bytes(t3)
    assert isinstance(b3, binary_type)
    assert b3 == b'H\xc3\xa9llo'


# Generated at 2022-06-11 01:34:47.330454
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo'.encode('utf-8'), nonstring='simplerepr') == 'foo'
    assert to_native('foo') == 'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(True) == 'True'
    assert to_native(False) == 'False'
    assert to_native(None) == 'None'
    assert to_native(42) == '42'



# Generated at 2022-06-11 01:34:57.209989
# Unit test for function to_bytes
def test_to_bytes():
    """
    This test is intended to assert that the original version of to_bytes is
    not changed (i.e. to_bytes(text_string, errors='surrogate_or_replace')
    returns the same thing as the new to_bytes(text_string, errors='surrogateescape')
    """
    from ansible.module_utils import six

    # A set of all characters we can decode from latin-1.  All values from 0x00
    # to 0xFF, and then the special control characters
    all_possible_latin1 = set(range(256))

# Generated at 2022-06-11 01:34:58.217679
# Unit test for function to_native
def test_to_native():
    pass


# Generated at 2022-06-11 01:35:09.762819
# Unit test for function to_bytes
def test_to_bytes():
    # Test surrogate then replace behavior
    for errors in ['surrogate_then_replace', 'surrogate_or_replace']:
        assert b'a\ufffdc' == to_bytes(u'a\uDC00c', errors=errors)
        assert b'a\ufffdc' == to_bytes(u'a\uDC00c'.encode('utf-8'), errors=errors)
        assert b'a\ufffdc' == to_bytes(u'a\uFFFDc'.encode('utf-8'), errors=errors)

        if HAS_SURROGATEESCAPE:
            assert b'a\x80c' == to_bytes(u'a\uDC80c', errors=errors)

# Generated at 2022-06-11 01:35:20.214861
# Unit test for function jsonify
def test_jsonify():
    data = {u'\u5e93\u5b58': '\u5e93\u5b58', u'\u7ba1\u7406\u5458': '\u7ba1\u7406\u5458', u'\u5bc6\u7801': '\u5bc6\u7801', u'\u4fe1\u606f': '\u4fe1\u606f', u'\u6d4b\u8bd5': {u'\u6d4b\u8bd5': u'\u6d4b\u8bd5\u5b58\u50a8\u5e93'}, '123': 123, 'test': 'test'}
    print(jsonify(data))
# test_jsonify()



# Generated at 2022-06-11 01:35:28.088732
# Unit test for function to_native
def test_to_native():
    # Unicode strings
    assert to_native(u'hello') == u'hello'
    assert to_native(u'\u1234') == u'\u1234'

    # Byte strings - no decoding
    assert to_native(b'\x80abc') == b'\x80abc'

    # Byte strings - decode
    assert to_native(b'\xc3\xbc') == u'\xfc'

    # Non-string objects
    assert to_native(123) == u'123'



# Generated at 2022-06-11 01:35:32.381186
# Unit test for function jsonify
def test_jsonify():
    json_string = jsonify({u"\u4e2d\u6587":1})
    assert json_string == json.dumps({u"\u4e2d\u6587":1}, encoding='utf-8', default=_json_encode_fallback)


# Generated at 2022-06-11 01:35:41.653944
# Unit test for function to_bytes
def test_to_bytes():
    utf8_bom = b'\xef\xbb\xbf'
    utf16_bom = b'\xff\xfe'

    class MockObj:
        def __str__(self):
            return u'\u6b22\u8fce'

        def __unicode__(self):
            return u'\u6b22\u8fce'

        def __repr__(self):
            return u'\u6b22\u8fce'

    unencodable_string = u'\u30e0\U0001030f\u2282'

    assert to_bytes(True) == b'True'
    assert to_bytes(False) == b'False'
    assert to_bytes(int(10)) == b'10'

# Generated at 2022-06-11 01:35:48.043467
# Unit test for function jsonify
def test_jsonify():
    _data = {b'k1': 'hello', b'k2': 'you'}
    assert jsonify(_data) == '{"k1": "hello", "k2": "you"}'
    _data = {'k1': 'hello', b'k2': b'you'}
    assert jsonify(_data) == '{"k1": "hello", "k2": "you"}'
    _data = {'k1': 'hello', b'k2': 'you'}
    assert jsonify(_data) == '{"k1": "hello", "k2": "you"}'
    _data = {'k1': 'hello', 'k2': b'you'}
    assert jsonify(_data) == '{"k1": "hello", "k2": "you"}'

# Generated at 2022-06-11 01:35:58.521308
# Unit test for function to_native
def test_to_native():
    # bytes to unicode
    assert to_native(b'ascii', errors='surrogate_or_strict') == u'ascii'
    assert to_native(b'ascii', errors='strict') == u'ascii'
    assert to_native(b'\xe4\xb8\x96\xe7\x95\x8c', errors='surrogate_or_strict') == u'\u4e16\u754c'
    with pytest.raises(UnicodeDecodeError):
        to_native(b'\xe4\xb8\x96\xe7\x95\x8c', errors='strict')
    # unicode to unicode

# Generated at 2022-06-11 01:36:09.172488
# Unit test for function to_native
def test_to_native():
    """Test func:`ansible.module_utils._text.to_native`

    :returns: ``None``
    """
    from ansible.module_utils._text import to_native
    assert isinstance(to_native(u'\N{SNOWMAN}', errors='surrogate_or_replace'),
                      text_type)
    assert isinstance(to_native(b'\xE2\x98\x83', errors='surrogate_or_replace'),
                      text_type)


# Generated at 2022-06-11 01:36:19.609661
# Unit test for function jsonify
def test_jsonify():
    from random import randint, choice
    # Create a list of different unicode characters
    # chr(64) is @
    # chr(127) is DEL
    unicode_chars = [unichr(i) for i in range(65, 127)]
    # Create a dict of unicode characters
    unicode_data = dict((str(i), choice(unicode_chars)) for i in range(0, randint(1, 100)))
    # Create a JSON string
    json_str = jsonify(unicode_data)
    # json.loads will throw error if the encoding is wrong
    json.loads(json_str)
    # utf-8 is the default encoding
    assert json_str.startswith('{')
    assert json_str.endswith('}')



# Generated at 2022-06-11 01:36:28.494803
# Unit test for function to_bytes
def test_to_bytes():
    tests = [
        (None, ''),
        (42, '42'),
        (3.14, '3.14'),
        (u'test', b'test'),
        (u'te\xdf\ufffdt', b'te\xc3\x9ft'),
        (b'test', b'test'),
        ((1, 2, 3), '(1, 2, 3)'),
    ]

    for (value, expected_result) in tests:
        actual_result = to_bytes(value)
        assert actual_result == expected_result, "actual_result(%s) != expected_result(%s) for value(%s)" % (
            actual_result, expected_result, value)


# Generated at 2022-06-11 01:36:32.116405
# Unit test for function to_native
def test_to_native():
    '''test_to_native'''
    assert to_native(b'a') == 'a'
    assert to_native('a') == 'a'
    assert to_native(1) == '1'
    assert to_native(None) == 'None'


# Generated at 2022-06-11 01:36:33.467203
# Unit test for function to_native
def test_to_native():
    result = text.to_native('test string')
    assert result == 'test string'


# Generated at 2022-06-11 01:36:44.010461
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.basic import to_bytes
    assert to_bytes('') == b''
    assert to_bytes(None) == b''
    assert to_bytes(b'Hello', nonstring='strict') == b'Hello'
    assert to_bytes('Hello') == b'Hello'
    assert to_bytes(b'\xe1\xbc\xb8\xce\xbf\x20\xe1\xbd\xb0\xcf\x84\xe1\xbd\xb0'.decode('utf-8'),
                     'latin-1') == b'\xe1\xbc\xb8\xce\xbf\x20\xe1\xbd\xb0\xcf\x84\xe1\xbd\xb0'

    # Test surrogate handling

# Generated at 2022-06-11 01:36:55.635995
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.common._collections_compat import Unicode
    assert to_bytes('foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(Unicode('føo')) == b'f\xc3\xb8o'
    assert to_bytes('føo') == b'f\xc3\xb8o'
    assert to_bytes('føo', errors='surrogate_then_replace') == b'f\xc3\xb8o'
    assert to_bytes('føo', encoding='latin-1') == b'f\xf8o'
    assert to_bytes('føo', encoding='latin-1', errors='surrogate_then_replace') == b'f\xf8o'

# Generated at 2022-06-11 01:36:56.902342
# Unit test for function jsonify
def test_jsonify():
    json.dumps({'a': 'foo'})



# Generated at 2022-06-11 01:37:07.385976
# Unit test for function to_native
def test_to_native():
    global HAS_SURROGATEESCAPE
    # Test Python2 with surrogateescape error handler
    if PY2 and HAS_SURROGATEESCAPE:
        # If running in python2 and has surrogateescape
        # Test to_native with surrogateescape and nonstring=passthru
        assert to_native(b'\xf0\x90\x80\x80', nonstring='passthru') == u'\udcc0'
        assert to_native(b'\xf0\x90\x80\x80', nonstring='passthru', errors='surrogate_or_strict') == u'\udcc0'

# Generated at 2022-06-11 01:37:11.252613
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'my_key': 'my_value'}) == '{"my_key": "my_value"}'
    assert jsonify(['my_item']) == '["my_item"]'
    assert jsonify(('my_item',)) == '["my_item"]'
    assert jsonify(set(['my_item'])) == '["my_item"]'
    assert jsonify(datetime.datetime(2020, 1, 1, 12, 0, 0)) == '"2020-01-01T12:00:00"'



# Generated at 2022-06-11 01:37:32.432029
# Unit test for function jsonify
def test_jsonify():
    TheStr = "你好，世界"
    TheStr_utf8 = TheStr.encode('utf-8')
    TheStr_latin1 = TheStr.encode('latin-1')
    json_result = jsonify({'key': TheStr})
    assert json_result == "{\"key\": \"%s\"}" % TheStr
    json_result = jsonify({'key': TheStr_utf8})
    assert json_result == "{\"key\": \"%s\"}" % TheStr
    json_result = jsonify({'key': TheStr_latin1})
    assert json_result == "{\"key\": \"%s\"}" % TheStr


# Generated at 2022-06-11 01:37:35.068247
# Unit test for function jsonify
def test_jsonify():
    data = dict(a=1, b=dict(c=[1, 2.0, {'a':3}]))
    print(jsonify(data))


# Generated at 2022-06-11 01:37:40.463639
# Unit test for function jsonify
def test_jsonify():
    unicode_sample = {u'test': (u'\xff', u'\xff')}
    # Test that JSON serializer can handle unicode characters
    json_output = jsonify(unicode_sample)
    assert isinstance(json_output, basestring)
    assert len(json_output) > 0
# End unit test for function jsonify



# Generated at 2022-06-11 01:37:48.829110
# Unit test for function to_bytes
def test_to_bytes():
    # Test obj is None
    assert to_bytes(None).decode('utf-8') == b'None'.decode('utf-8')
    # Test obj is empty string
    assert to_bytes('').decode('utf-8') == b''.decode('utf-8')
    # Test obj is empty unicode
    assert to_bytes(u'').decode('utf-8') == b''.decode('utf-8')
    # Test obj is a mixed case string
    assert to_bytes('AaZz09!_').decode('utf-8') == b'AaZz09!_'.decode('utf-8')
    # Test obj is a mixed case unicode

# Generated at 2022-06-11 01:38:00.188865
# Unit test for function jsonify
def test_jsonify():

    test_string = {"list": ['a', 'b', 'c'], "unicode": u'\u20ac'}
    test_set = {"set": {'a', 'b', 'c'}}
    test_datetime = {"datetime": datetime.datetime.now()}

    # Test with encoding keyword
    try:
        json.dumps(test_string, encoding='utf-8', default=_json_encode_fallback)
    except TypeError:
        test_string = False

    try:
        json.dumps(test_set, encoding='utf-8', default=_json_encode_fallback)
    except TypeError:
        test_set = False


# Generated at 2022-06-11 01:38:02.175924
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"foo": "bar"}) == b'{"foo": "bar"}'



# Generated at 2022-06-11 01:38:10.460516
# Unit test for function to_native
def test_to_native():
    """
    ansible.module_utils._text.to_native
    """
    # Test ASCII bytes into native string
    assert isinstance(to_native(b'foobar'), str)
    assert to_native(b'foobar') == u'foobar'

    # Test ASCII into native string
    assert isinstance(to_native(u'foobar'), str)
    assert to_native(u'foobar') == u'foobar'

    # Test non-ASCII bytes into native string
    assert isinstance(to_native(u'\uffff'.encode('utf-8')), str)
    assert to_native(u'\uffff'.encode('utf-8')) == u'\uffff'

    # Test non-ASCII unicode into native string

# Generated at 2022-06-11 01:38:18.938061
# Unit test for function to_native
def test_to_native():
    for data, expected in (
        (bytearray(b"foo"), b"foo"),
        (buffer(b"foo"), b"foo"),
        (memoryview(b"foo"), b"foo")
    ):
        assert to_native(data) == expected
        assert isinstance(to_native(data), binary_type)

    for data, expected in (
        (u"foo", u"foo"),
        (bytearray(b"foo"), u"foo"),
        (buffer(b"foo"), u"foo"),
        (memoryview(b"foo"), u"foo")
    ):
        assert to_native(data) == expected
        assert isinstance(to_native(data), text_type)

    assert to_native(u"©") == to_bytes(u"©")

    # str on python2

# Generated at 2022-06-11 01:38:24.143301
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({u'foo': u'bar'}, sort_keys=True,indent=4, separators=(',', ': ')) == '{\n    "foo": "bar"\n}'
    assert jsonify({u'foo': u'bar', u'baz': u'qux'}, sort_keys=True) == '{"baz": "qux", "foo": "bar"}'



# Generated at 2022-06-11 01:38:35.401369
# Unit test for function to_bytes
def test_to_bytes():
    u = u'⇒'
    b = u.encode('utf-8')

    assert to_bytes(u) == b
    assert to_bytes(u, nonstring='passthru') == u
    assert to_bytes(None) == b'None'
    assert to_bytes(b) == b
    assert to_bytes(True) == b'True'
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u, encoding='ascii') == b'\xe2\x87\x92'
    assert to_bytes(u, errors='surrogate_or_strict') == b'\xe2\x87\x92'
    assert to_bytes(u, errors='surrogate_or_replace') == b'\xef\xbf\xbd'
   

# Generated at 2022-06-11 01:39:07.802645
# Unit test for function to_native
def test_to_native():
    for cls in (text_type, binary_type):
        # Test that text type does not change
        assert to_native(cls(u'string')) == cls(u'string')
        assert to_native(cls(u'string'), encoding='ascii') == cls(u'string')
        assert to_native(cls(u'string'), encoding='utf-8') == cls(u'string')

        # Test that byte type does not change
        assert to_native(cls(b'string')) == cls(b'string')
        assert to_native(cls(b'string'), encoding='ascii') == cls(b'string')

# Generated at 2022-06-11 01:39:19.107192
# Unit test for function to_bytes
def test_to_bytes():
    import sys
    import sysconfig
    from collections import OrderedDict

    if PY3:
        orig_to_bytes = to_bytes
        raw_to_bytes = to_bytes
        utf8_to_bytes = to_bytes
        utf8_safe_to_bytes = to_bytes
        surrogate_to_bytes = to_bytes
        surrogate_or_replace_to_bytes = to_bytes
        surrogate_or_strict_to_bytes = to_bytes
        surrogate_then_replace_to_bytes = to_bytes

        def to_bytes(obj, encoding='utf-8', errors='surrogate_or_replace', nonstring='simplerepr'):
            return orig_to_bytes(obj, encoding, errors, nonstring)


# Generated at 2022-06-11 01:39:21.738925
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': '中文', 'b': 123}) == '{"a": "\\u4e2d\\u6587", "b": 123}'



# Generated at 2022-06-11 01:39:32.978701
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=8, b=7)) == '{"a": 8, "b": 7}'
    assert jsonify(dict(a=u'\u20ac'), ensure_ascii=False) == u'{"a": "\u20ac"}'
    assert jsonify(dict(a=u'\u20ac', b=7, c=[1, 2, 3])) == '{"a": "\\u20ac", "c": [1, 2, 3], "b": 7}'
    assert jsonify(dict(a=u'\u20ac', b=7, c=[1, 2, 3]), ensure_ascii=False) == u'{"a": "\u20ac", "c": [1, 2, 3], "b": 7}'

# Generated at 2022-06-11 01:39:38.490238
# Unit test for function to_native
def test_to_native():
    bytes_str = to_native("test")
    assert isinstance(bytes_str, binary_type)
    assert bytes_str == u"test"

    bytes_str = to_native(u"test")
    assert isinstance(bytes_str, binary_type)
    assert bytes_str == u"test"

    bytes_str = to_native(b"test")
    assert isinstance(bytes_str, binary_type)
    assert bytes_str == u"test"
