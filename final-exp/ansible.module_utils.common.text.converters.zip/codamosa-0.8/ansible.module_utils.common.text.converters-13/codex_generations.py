

# Generated at 2022-06-11 01:29:58.278172
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('hi') == b'hi'
    assert to_bytes(b'hi') == b'hi'
    assert to_bytes(u'hi') == b'hi'
    assert to_bytes(u'é') == b'\xc3\xa9'
    assert to_bytes(u'\udca7') == b'\xed\xb2\xa7'

    assert to_bytes(u'\udca7', errors='surrogate_or_strict') == b'\xed\xb2\xa7'
    if HAS_SURROGATEESCAPE:
        assert to_bytes(u'\udca7', errors='surrogate_then_replace') == b'?'


# Generated at 2022-06-11 01:30:01.931989
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'foo': 'bar'}) == '{"foo": "bar"}'
    assert jsonify({'foo': to_bytes('bar')}) == '{"foo": "bar"}'



# Generated at 2022-06-11 01:30:12.886441
# Unit test for function jsonify
def test_jsonify():
    data = {"someu8": u"\u2713", "someascii": "ascii"}
    json_data = jsonify(data)
    assert '"someu8": "\\u2713"' in json_data
    assert '"someascii": "ascii"' in json_data
    # Test with a datetime object
    dt_data = {"somedt": datetime.datetime(2018, 1, 1)}
    json_data = jsonify(dt_data)
    assert '"somedt": "2018-01-01T00:00:00"' in json_data
    # Test with a set
    s_data = {"someset": set(["a", "b"])}
    json_data = jsonify(s_data)

# Generated at 2022-06-11 01:30:14.104757
# Unit test for function to_native
def test_to_native():
    """
    :returns: None
    :rtype: None
    """

# Generated at 2022-06-11 01:30:24.302733
# Unit test for function to_native
def test_to_native():
    """
    Verify that the function to_native correctly converts a byte or unicode string
    to the native string type
    """
    if PY3:
        # PY3 is all unicode
        # In PY3 we should not take a byte string as input
        test_string = b'foobarbaz'
        assert to_native(test_string) == 'foobarbaz'
        assert type(to_native(test_string)) is str
    else:
        # PY2 is all byte strings
        # In PY2 we should not take a unicode string as input
        test_string = u'foobarbaz'
        assert to_native(test_string) == 'foobarbaz'
        assert type(to_native(test_string)) is str



# Generated at 2022-06-11 01:30:27.713409
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(1, nonstring='passthru') == 1


# Generated at 2022-06-11 01:30:35.106195
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == b'foo'
    assert to_bytes('foo'.encode('ascii')) == b'foo'

    # Test that surrogates are escaped into bytes
    assert to_bytes(u'\udcff') == b'\\xed\\xb3\\xbf'

    # Test that surrogates are escaped and the result is encoded using the
    # specified encoding
    assert to_bytes(u'\udcff', encoding='utf-16') == b'\\xff\\xfd\\xff'

# Generated at 2022-06-11 01:30:46.650334
# Unit test for function to_bytes
def test_to_bytes():
    def _test(original_string, expected, encoding='utf-8', errors=None, nonstring='simplerepr'):
        result = to_bytes(original_string, encoding=encoding, errors=errors, nonstring=nonstring)

        assert result == expected, (original_string, encoding, errors, nonstring, result, type(result), expected)

    # Test byte strings
    for b in ['This is ascii', b'\xff', b'\xfe\xff\x00\x00\x00\x00\x00\x00\x00\x00', '\u1234']:
        _test(b, b, 'latin-1')
        _test(b, b, 'utf-8')

    # Test text strings

# Generated at 2022-06-11 01:30:57.386623
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo', errors='strict') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\udc80') == b'\xed\xb2\x80'
    assert to_bytes(u'\udc80', errors='strict') == b'\xed\xb2\x80'
    try:
        to_bytes(u'\udc80', errors='replace')
    except UnicodeEncodeError:
        pass

# Generated at 2022-06-11 01:31:04.735702
# Unit test for function to_bytes
def test_to_bytes():
    import sys
    # Note: In Python3 this is automatically a byte string
    assert isinstance(to_bytes('ascii string'), binary_type)

    if PY3:
        assert isinstance(to_bytes(b'bytes string'), binary_type)

        byte_string = b'\xff\xff'
        text_ascii = byte_string.decode('latin-1')
        assert isinstance(to_bytes(text_ascii), binary_type)

        text_latin_1 = byte_string.decode('latin-1', 'surrogateescape')
        assert isinstance(to_bytes(text_latin_1), binary_type)
    else:
        assert isinstance(to_bytes(b'bytes string'), binary_type)

        byte_string = b'\xff\xff'

# Generated at 2022-06-11 01:31:22.217761
# Unit test for function to_bytes
def test_to_bytes():
    import sys

    # Test surrogates that can be encoded
    #
    # u'\U0001f4a9' PILE OF POO
    # u'\U0001f4a9'.encode('utf-8') b'\xf0\x9f\x92\xa9'
    # u'\U0001f4a9'.encode('utf-8').decode('utf-8') u'\U0001f4a9'
    # u'\U0001f4a9'.encode('utf-8', 'surrogateescape') b'\xf0\x9f\x92\xa9'
    # u'\U0001f4a9'.encode('utf-8', 'surrogateescape').decode('utf-8', 'surrogateescape') u'\U0001f4a9'


# Generated at 2022-06-11 01:31:31.005660
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'foo', 'b': 2, 'c': [1, 2, 'bar']}
    new_data = jsonify(data)
    assert new_data == json.dumps(data, encoding='utf-8', default=_json_encode_fallback)
    data = {'a': b'foo', 'b': 2, 'c': [1, 2, b'bar']}
    new_data = jsonify(data)
    assert new_data == json.dumps(data, encoding='utf-8', default=_json_encode_fallback)
    data = {'a': 'foo', 'b': 2, 'c': [1, 2, 'bar']}
    new_data = jsonify(data,sort_keys=True)

# Generated at 2022-06-11 01:31:43.810789
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils.six import u


# Generated at 2022-06-11 01:31:50.522425
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u03b1') == b'\xce\xb1'
    assert to_bytes(u'\u03b1', nonstring='passthru') == u'\u03b1'
    #assert to_bytes(u'\u03b1', errors=None) == b'\xce\xb1'
    assert to_bytes(u'\u03b1', errors=None) == b'\xce\xb1'
    assert to_bytes(u'\u03b1', errors='surrogate_or_strict') == b'\xce\xb1'
    assert to_bytes(u'\u03b1', errors='surrogate_or_replace') == b'\xce\xb1'

# Generated at 2022-06-11 01:32:00.610226
# Unit test for function to_bytes
def test_to_bytes():
    # normal case - encode text to bytes
    assert to_bytes(u"testing") == b"testing"

    # already encoded
    assert to_bytes(b"testing") == b"testing"

    # nonstring object
    assert to_bytes(5) == b"5"

    # nonstring object with nonstring=passthru
    assert to_bytes(5, nonstring='passthru') == 5

    # nonstring object with nonstring=empty
    assert to_bytes(5, nonstring='empty') == b""

    # nonstring object with nonstring=strict
    try:
        to_bytes(5, nonstring='strict')
        raise AssertionError("Failed to raise TypeError on nonstring=strict")
    except TypeError:
        pass

    # nonstring object has no unicode representation

# Generated at 2022-06-11 01:32:10.559889
# Unit test for function to_bytes
def test_to_bytes():
    # This is a minimal set of tests.  For better test coverage see the tests
    # in lib/ansible/parsing/vault/test/test_vault.

    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u043b\u0438\u0442\u0440') == b'\xd0\xbb\xd0\xb8\xd1\x82\xd1\x80'

    assert to_bytes(0) == b'0'
    assert to_bytes(bytes) == b"<type 'bytes'>"



# Generated at 2022-06-11 01:32:20.647087
# Unit test for function to_native
def test_to_native():
    # pylint: disable=undefined-variable
    assert to_native(None) is None
    assert to_native(False) is False
    assert to_native(0) == 0
    assert to_native(['foo', 'bar']) == ['foo', 'bar']
    assert to_native({'foo': 'bar'}) == {'foo': 'bar'}
    # pylint: enable=undefined-variable

    assert to_native(u'this is a unicode string') == u'this is a unicode string'
    assert to_native(b'this is a byte string') == b'this is a byte string'

    if PY3:
        assert to_native(u'this is a unicode string'.encode('utf-8')) == u'this is a unicode string'

# Generated at 2022-06-11 01:32:21.722446
# Unit test for function to_native
def test_to_native():
    pass


# Generated at 2022-06-11 01:32:33.457249
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import jsonify
    from ansible.module_utils._text import to_native
    import json
    import sys

    if sys.version_info[0] > 2:
        to_text = to_native
        to_bytes = to_native
    mystring = to_bytes(u'\xe9')
    if PY2:
        assert jsonify(mystring) == '\"\\u00e9\"'
    else:
        assert jsonify(mystring) == '"\\u00e9"'



# Generated at 2022-06-11 01:32:40.788234
# Unit test for function to_bytes

# Generated at 2022-06-11 01:32:52.454614
# Unit test for function jsonify
def test_jsonify():
    foo = b'foo'
    bar = b'bar'

    utf8_dict = {u'foo': u'bar'}
    mixed_dict = {u'foo': bar}
    byte_dict = {foo: bar}

    assert jsonify(utf8_dict) == '{"foo": "bar"}'
    assert jsonify(mixed_dict) == '{"foo": "bar"}'
    assert jsonify(byte_dict) == '{"foo": "bar"}'



# Generated at 2022-06-11 01:32:58.116027
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'foo') == u'"foo"'
    # Regression tests for issue #9499
    myset = set([u'foo', u'bar'])
    assert jsonify(myset) == '["foo", "bar"]'



# Generated at 2022-06-11 01:33:09.793987
# Unit test for function to_native
def test_to_native():
    '''Test various permutations of to_native'''
    # to_native is an alias to to_text
    assert to_native(b'ascii') == u'ascii'
    assert to_native(b'\xe5\x96\x9c\xe5\x89\x8d') == u'\u5396\u524d'
    assert to_native(b'\xe5\x96\x9c\xe5\x89\x8d', encoding='euc_jp') == u'\u5396\u524d'
    assert to_native(b'\xc2\xdf', encoding='latin-1') == u'\u00df'
    assert to_native(b'\xc2\xdf', encoding='ascii') == u'\ufffd'
   

# Generated at 2022-06-11 01:33:20.252353
# Unit test for function to_bytes
def test_to_bytes():
    from datetime import time
    from itertools import chain

    import pytest

    from ansible.module_utils.six import text_type, binary_type

    surrogate_unicode = u'\udc80'

    # We should also test surrogates.  We don't need to test all unicode
    # ranges.  Just the one that is special: 0xd800-0xdfff
    # The first value in this range is 0xd7ff but the second value is 0xe000
    # We want values that are in the 0xd800-0xdfff range and a value that is in
    # the 0xe000 range to make sure that values outside of the range aren't
    # affected by the surrogate escape handling.

# Generated at 2022-06-11 01:33:30.931614
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY2

    # PY2
    if PY2:
        try:
            # Works on PY2 with utf-8 encoding
            assert jsonify(u'\u2713') == u'"\u2713"'
        except UnicodeDecodeError:
            assert False, "UnicodeDecodeError should not be raised"
        try:
            # Raises UnicodeEncodeError on PY2 with ascii encoding
            jsonify(u'\u2713')
        except UnicodeDecodeError:
            assert True
        except UnicodeEncodeError:
            assert False, "UnicodeEncodeError should not be raised"

# Generated at 2022-06-11 01:33:35.122706
# Unit test for function jsonify
def test_jsonify():
    """Try to jsonify the input data using utf-8 and latin-1"""
    test_data = { u'data': u'user_\U0001f62d' }
    assert jsonify(test_data)


# Generated at 2022-06-11 01:33:40.340796
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can pass a bytestring
    # This is the most common case so try it first.
    assert to_bytes(b'foo') == b'foo'
    # Test that we can pass unicode text.
    assert to_bytes('\xe2\x96\x88') == b'\xe2\x96\x88'
    # Test default encoding
    assert to_bytes('\xe2\x96\x88') == b'\xe2\x96\x88'
    # Test error handler
    assert to_bytes('\xe2\x96\x88', errors='ignore') == b''
    assert to_bytes('\xe2\x96\x88', errors='replace') == b'?'

# Generated at 2022-06-11 01:33:48.980936
# Unit test for function to_native
def test_to_native():
    # We are using str(...) to test the conversion in this function.
    # We use str() instead of the ansible_native conversion to
    # avoid masking errors with this function.
    str_b = b'foo'
    str_u = u'foo'
    int_i = 1
    float_f = 1.1

    # str() works for byte strings
    assert str_b == str(str_b)

    # str() works for text strings
    assert str_u == str(str_u)

    # str() works for int
    assert str(int_i) == str(int_i)

    # str() works for float
    assert str(float_f) == str(float_f)

    # str() works for lists
    assert str([str_b]) == str([str_b])
    assert str

# Generated at 2022-06-11 01:34:00.432960
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.six import b

    assert to_bytes('abc') == b('abc')
    assert to_bytes('abc', nonstring='empty') == b('')
    assert to_bytes('abc', nonstring='passthru') == 'abc'
    assert to_bytes(b('abc'), nonstring='passthru') == b('abc')

    if HAS_SURROGATEESCAPE:
        assert to_bytes(u'\udcc3') == b('\xed\xb3\x83', 'utf-8')
        # u'\uDCFF' can't be encoded in latin-1
        assert to_bytes(u'\uDCFF', encoding='latin-1') == b('\xff\xff')

# Generated at 2022-06-11 01:34:10.601574
# Unit test for function to_bytes

# Generated at 2022-06-11 01:34:27.421122
# Unit test for function to_native
def test_to_native():
    for s in [u'unicode', u'\u2713', u'ascii', 'ascii',
              b'bytes', b'\xe2\x9c\x93', b'ascii', 'ascii']:
        assert isinstance(to_native(s, errors='surrogate_or_strict'), text_type)
        assert isinstance(to_native(s, errors='strict'), text_type)
        assert isinstance(to_native(s, errors='surrogate_or_replace'), text_type)
        assert isinstance(to_native(s, errors='replace'), text_type)


# Unit test to_text

# Generated at 2022-06-11 01:34:35.686170
# Unit test for function jsonify
def test_jsonify():
   jsn = {"a": 1, "b": 2, "c": 3}
   assert jsonify(jsn) == u'{"a": 1, "c": 3, "b": 2}'
   assert jsonify(jsn, sort_keys=True) == u'{"a": 1, "b": 2, "c": 3}'
   assert jsonify(jsn, sort_keys=True, indent=4, separators=(',', ':')) == u'{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'
   assert jsonify(jsn, sort_keys=True, indent=4, separators=(':', '=')) == u'{\n    "a"=1,\n    "b"=2,\n    "c"=3\n}'


# Generated at 2022-06-11 01:34:47.908460
# Unit test for function to_bytes
def test_to_bytes():
    # pylint: disable=too-many-branches,too-many-locals,too-many-statements
    # Test a couple simple cases
    try:
        # Python3
        to_bytes('ascii')
        to_bytes('☃'.encode('utf-8'))
        to_bytes('☃')
    except NameError:
        # Python2
        to_bytes('ascii')
        to_bytes(unicode('☃', 'utf-8'))
        to_bytes(unicode('☃'))

    # Test with an object that has a __str__ but not a __bytes__
    class Foo(object):
        def __str__(self):
            return 'foo'

    foo = Foo()
    assert to_bytes(foo) == to_bytes('foo')

    #

# Generated at 2022-06-11 01:34:52.435123
# Unit test for function jsonify
def test_jsonify():
    input_text = {'a': '\xe9'}
    if PY3:
        assert jsonify(input_text) == '{"a": "\\u00e9"}'
    else:
        assert jsonify(input_text) == '{"a": "\\u00e9"}'



# Generated at 2022-06-11 01:35:00.598981
# Unit test for function to_bytes
def test_to_bytes():
    if not PY3:
        from ansible_collections.ansible.community.tests.unit.compat.mock import patch

        with patch('ansible_collections.ansible.community.plugins.module_utils.common._collections_compat.HAS_SURROGATEESCAPE', True):
            assert to_bytes('foo', errors='surrogate_or_replace') == b'foo'
            assert to_bytes('foo', errors='surrogate_or_strict') == b'foo'
            assert to_bytes('foo', errors='surrogate_then_replace') == b'foo'

# Generated at 2022-06-11 01:35:12.621820
# Unit test for function to_native
def test_to_native():
    # Test bytes
    assert to_native(b'test', 'utf-8') == u'test'
    # Test bytes that can't be decoded
    string = b'\x80\x81\x82\x83\x84\x85'
    if PY3:
        raises(UnicodeDecodeError, to_native, string)
        assert to_native(string) == u'\ufffd\ufffd\ufffd\ufffd\ufffd\ufffd'
    else:
        # python2 falls back to latin-1 if utf8 fails
        assert u'\ufffd\ufffd\ufffd\ufffd\ufffd\ufffd' == to_native(string)
    # Test text
    assert to_native(u'test') == u'test'
    # Test text with surrogates
   

# Generated at 2022-06-11 01:35:22.069127
# Unit test for function to_bytes
def test_to_bytes():
    # Default encoding is utf-8
    assert to_bytes('Hi') == b'Hi'

    # Nonstring defaults to simplerepr
    assert to_bytes(42) == b'42'

    # Can use different encoding
    assert to_bytes('Hi', 'ascii') == b'Hi'

    # Nonstrings work in other encodings too
    assert to_bytes(42, 'ascii') == b'42'

    # Invalid nonstring is an error
    try:
        to_bytes('foo', nonstring='invalid')
    except TypeError:
        pass
    else:
        assert False, 'Expected error not raised'

    # Can't use invalid encoding
    try:
        to_bytes('foo', 'foobarbaz')
    except LookupError:
        pass

# Generated at 2022-06-11 01:35:33.449292
# Unit test for function jsonify
def test_jsonify():
    data = {
        'simple': 'string',
        'boolean': True,
        'unicode': '\u2713',
        'bytes': b'bytes',
        'list': [b'bytes', u'unicode'],
        'dict': {
            'simple': 'string',
            'boolean': True,
            'unicode': '\u2713',
            'bytes': b'bytes',
            'list': [b'bytes', u'unicode']
        },
    }

    json_data = jsonify(data)

    for item in json.loads(json_data).items():
        assert item[0] in data
        assert item[1] == data[item[0]]

    json_data = jsonify(data, sort_keys=True)


# Generated at 2022-06-11 01:35:34.046901
# Unit test for function to_native
def test_to_native():
    pass


# Generated at 2022-06-11 01:35:36.572819
# Unit test for function to_native
def test_to_native():
    input_variable = 'test'
    expected = 'test'
    returned = to_native(input_variable)
    assert returned == expected

# Generated at 2022-06-11 01:35:44.102312
# Unit test for function to_native
def test_to_native():
    assert True

# Generated at 2022-06-11 01:35:48.439063
# Unit test for function jsonify
def test_jsonify():
    try:
        jsonify(dict(a=u'\xe9'))
    except UnicodeError as e:
        assert 'Invalid unicode encoding encountered' in to_text(e)
    else:
        raise Exception('Did not trigger exception')



# Generated at 2022-06-11 01:35:58.878987
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.common._collections_compat import HashableDict, MutableMapping, MutableSequence
    from datetime import datetime
    from ansible.module_utils._text import to_native

    d = dict(a=u'test', b=5, c=[1, 2, 3], d=dict(x=u'test'))
    j = jsonify(d)
    assert j == '{"a": "test", "c": [1, 2, 3], "b": 5, "d": {"x": "test"}}'

    d = dict(a=u'test', b=5, c=[1, 2, 3], d=dict(x=u'test'))
    j = jsonify(d, sort_keys=True)

# Generated at 2022-06-11 01:36:06.752495
# Unit test for function jsonify
def test_jsonify():
    output = jsonify(
        data=dict(
            one=1,
            two=2,
            three=3,
            four=[u'\u20ac', u'\u20ac', u'\u20ac', u'\u20ac'],
            five=dict(a=1, b=2)
        ),
        ensure_ascii=True
    )
    assert output == '{"four": ["\\u20ac", "\\u20ac", "\\u20ac", "\\u20ac"], "five": {"a": 1, "b": 2}, "one": 1, "three": 3, "two": 2}'



# Generated at 2022-06-11 01:36:17.013705
# Unit test for function to_native
def test_to_native():
    assert u"\u8721" == to_native(u"\u8721", errors='surrogate_or_replace')
    assert u"\u8721".encode('utf-8', 'surrogateescape').decode('utf-8', 'replace') == to_native(u"\u8721", errors='surrogate_then_replace')
    assert b'\x87!' == to_native(u"\u8721", errors='surrogate_then_replace', encoding='latin-1')
    assert u"\uD834\uDD1E" == to_native(u"\uD834\uDD1E", encoding='utf-8', errors='surrogate_or_strict')

# Generated at 2022-06-11 01:36:27.029657
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.basic import _to_bytes

    # Test passing in a string, ensure it comes back as bytes
    assert isinstance(_to_bytes(u'foo'), binary_type)
    assert _to_bytes(u'foo') == b'foo'

    # Test passing in a bytes
    assert isinstance(_to_bytes(b'bar'), binary_type)
    assert _to_bytes(b'bar') == b'bar'

    # Test passing in a non-string, ensure it comes back as bytes
    assert isinstance(_to_bytes(123), binary_type)
    assert _to_bytes(123) == b'123'

    # Test passing in a non-string, ensure it comes back as bytes
    assert isinstance(_to_bytes(123), binary_type)
    assert _to_bytes(123)

# Generated at 2022-06-11 01:36:34.592298
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'foo'.encode('latin1')) == u'foo'
    assert to_native(u'foo'.encode('latin1'), encoding='latin1') == u'foo'
    assert to_native(u'foo'.encode('utf-8'), encoding='latin1') == u'foo'

    # this is a bytearray, not a byte string
    assert to_native(u'foo'.encode('latin1')[1:]) == b'oo'

# Generated at 2022-06-11 01:36:45.171044
# Unit test for function jsonify
def test_jsonify():
    class A(object):
        def __repr__(self):
            return '{"key": "value"}'

    assert jsonify(data={'key': 'value'}) == '{"key": "value"}'
    assert jsonify(data={'key': u'value'}) == '{"key": "value"}'
    assert jsonify(data={u'key': 'value'}) == '{"key": "value"}'
    assert jsonify(data={u'key': u'value'}) == '{"key": "value"}'
    assert jsonify(data=A()) == '{"key": "value"}'

    assert jsonify(data=['a', 'b', u'c']) == '["a", "b", "c"]'

# Generated at 2022-06-11 01:36:56.096854
# Unit test for function jsonify
def test_jsonify():
    data = {
            "list": ["item1", {"item2": "value2"}],
            "int": 12345,
            "unicode": to_text(u'\u2713'),
            "bytestr": b'\xc3\xa9 \xc3\xab',
            "bytelist": [b'\xc3\xa9'],
            "datetime": datetime.datetime.now()
    }
    # expected: can be decoded using utf-8 and latin-1
    expected = json.dumps([u'item1', {u'item2': u'value2'}], sort_keys=True, indent=4)

    assert expected == jsonify(data['list'])


# Generated at 2022-06-11 01:37:02.861254
# Unit test for function to_bytes
def test_to_bytes():

    def _ntb(obj, encoding='utf-8', errors='surrogate_then_replace', nonstring='simplerepr'):
        return to_bytes(obj, encoding, errors, nonstring)

    assert _ntb(b'foo') == b'foo'
    assert _ntb(b'foo', 'utf-8') == b'foo'
    assert _ntb(b'foo', 'utf-8', 'surrogateescape', 'passthru') == b'foo'
    assert _ntb(b'foo', 'utf-8', 'surrogateescape', 'passthru') == b'foo'
    assert _ntb(b'foo', 'ascii', 'surrogateescape', 'passthru') == b'foo'


# Generated at 2022-06-11 01:37:19.694663
# Unit test for function jsonify
def test_jsonify():
    obj = dict(simple_val=to_text('what', 'latin-1'),
               int_val=10,
               array_val=[to_text(1, 'latin-1', 'replace'), to_text('2', 'latin-1', 'replace')],
               dict_val=dict(a=to_text(1, 'latin-1', 'replace')))

    def _json_encode_fallback_test(obj):
        if isinstance(obj, int):
            return to_text(str(obj), 'latin-1', 'replace')
        raise TypeError("Cannot json serialize %s" % to_native(obj))


# Generated at 2022-06-11 01:37:30.744772
# Unit test for function jsonify
def test_jsonify():
    # Test types that can't be serialized
    data = {to_bytes(u'foo'): to_bytes(u'bar')}
    try:
        jsonify(data)
    except TypeError:
        pass
    else:
        raise AssertionError('All bytes-like objects should not be serializable')
    data = Set([1, 2, 3])
    try:
        jsonify(data)
    except TypeError:
        pass
    else:
        raise AssertionError('Set objects should not be serializable')
    data = datetime.datetime.now()
    try:
        jsonify(data)
    except TypeError:
        pass
    else:
        raise AssertionError('Datetime objects should not be serializable')
    # Test types that can be serialized

# Generated at 2022-06-11 01:37:41.733808
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    # Test encoding default as utf-8
    data = {u'bytes': to_bytes(u'\u00A9'), u'text': u'\u00A9', u'set': set()}
    expected = '{"bytes": "\\u00a9", "text": "\\u00a9", "set": []}'
    assert jsonify(data) == expected
    # Test encoding as latin-1
    data = {u'bytes': to_bytes(u'\u00A9', 'latin-1'), u'text': u'\u00A9', u'set': set()}

# Generated at 2022-06-11 01:37:49.656186
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('abc') == 'abc'
    assert to_bytes(b'abc') == b'abc'
    assert to_bytes(u'abc') == b'abc'
    assert to_bytes(u'Я люблю тебя') == b'\xd0\xaf \xd0\xbb\xd1\x8e\xd0\xb1\xd0\xbb\xd1\x8e \xd1\x82\xd0\xb5\xd0\xb1\xd1\x8f'

    assert to_bytes(1) == b'1'
    assert to_bytes(u'\u2019') == b'\xe2\x80\x99'

# Generated at 2022-06-11 01:38:01.192917
# Unit test for function to_bytes
def test_to_bytes():
    class Foo:
        def __repr__(self):
            return 'Foo'

    assert to_bytes(u'ni\xc3\xb1o') == b'ni\xc3\xb1o'
    assert to_bytes('ni\xc3\xb1o') == b'ni\xc3\xb1o'
    assert to_bytes(b'ni\xc3\xb1o') == b'ni\xc3\xb1o'
    assert to_bytes(u'hi\xff') == b'hi\xff'
    assert to_bytes('hi\xff', errors='surrogate_or_strict') == b'hi\xff'
    assert to_bytes(u'hi\xff', errors='surrogate_or_replace') == b'hi\xff'

# Generated at 2022-06-11 01:38:09.873098
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('abc') == b'abc'
    assert to_bytes(u'abc') == b'abc'
    assert to_bytes(u'\xe9') == b'\xc3\xa9'
    assert to_bytes(u'\u8fd9') == b'\xe8\xbf\x99'
    assert to_bytes(b'\xe9') == b'\xe9'
    assert to_bytes(b'\xe9', errors='strict') == b'\xe9'
    assert u'\xe9'.encode('utf-8', 'surrogateescape') == b'\xe9'

    # Test that surrogate_or_strict does not traceback

# Generated at 2022-06-11 01:38:18.826775
# Unit test for function to_bytes

# Generated at 2022-06-11 01:38:27.443431
# Unit test for function to_bytes
def test_to_bytes():
    # python2.4 doesn't have b''
    to_bytes(b'hello') == 'hello'
    to_bytes('hello') == 'hello'
    to_bytes(u'hello') == 'hello'
    to_bytes(b'hello', encoding='latin-1') == 'hello'
    to_bytes('hello', encoding='latin-1') == 'hello'
    to_bytes(u'hello', encoding='latin-1') == 'hello'

    to_bytes(True) == 'True'
    to_bytes(False) == 'False'
    to_bytes(1) == '1'
    to_bytes(1.0) == '1.0'
    to_bytes(1 + 0j) == '(1+0j)'
    to_bytes(set()) == 'set([])'
    to

# Generated at 2022-06-11 01:38:39.007539
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_text
    import ast
    test_input = {u'string': u'\xe6\x96\xb0\xe5\x8a\xa0\xe5\x9d\xa1', u'unicode_string': u'\u6211\u6d77',
                  u'set': {u'n\xe5\x8e\x95', u'n\u5e95'},
                  u'date_time': datetime.datetime(2017, 5, 11, 10, 53, 16, 896683)}
    test_output = jsonify(test_input)
    test_output = ast.literal_eval(test_output)
    for key, value in iteritems(test_output):
        if isinstance(value, list):
            value

# Generated at 2022-06-11 01:38:44.702690
# Unit test for function jsonify
def test_jsonify():
    example_data = {to_bytes(u'foo'): u'bar', u'baz': to_bytes(u'baz1')}
    # A dict with unicode / bytes
    result = jsonify(example_data)
    assert isinstance(result, str)
    assert result == "{\"foo\": \"bar\", \"baz\": \"baz1\"}"



# Generated at 2022-06-11 01:39:08.013522
# Unit test for function to_native

# Generated at 2022-06-11 01:39:19.283379
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    assert module.to_native(1) == 1, "Failed to coerce int to native"
    assert module.to_native('1') == '1', "Failed to coerce string to native"
    assert module.to_native(b'1') == b'1', "Failed to coerce bytes to native"
    assert module.to_native(u'1') == '1', "Failed to coerce unicode to native"
    assert isinstance(module.to_native(None), type(None)), "Failed to coerce None to native"


# Generated at 2022-06-11 01:39:30.377934
# Unit test for function to_bytes
def test_to_bytes():
    # Test nonstring 'passthru'
    class Foo: pass

    f = Foo()
    assert to_bytes(f, nonstring='passthru') is f

    # Test nonstring 'simplerepr'
    class Bar:
        def __repr__(self):
            return 'A Bar Instance'

        def __str__(self):
            return 'A Bar Instance'

    assert to_bytes(Bar(), nonstring='simplerepr') == b'A Bar Instance'

    # Test nonstring 'empty'
    class Baz: pass

    assert to_bytes(Baz(), nonstring='empty') == b''

    # Test nonstring 'strict'
    assert to_bytes(Baz(), nonstring='strict') == b''

    # Invalid nonstring value

# Generated at 2022-06-11 01:39:39.267221
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    assert to_bytes(u'\ufffc') == b'?'