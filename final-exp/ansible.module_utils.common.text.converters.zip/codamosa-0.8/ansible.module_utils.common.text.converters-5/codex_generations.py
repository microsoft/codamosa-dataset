

# Generated at 2022-06-11 01:30:03.261597
# Unit test for function to_bytes
def test_to_bytes():
    utf_string = u'12345 abcdé'
    ascii_string = '12345 abcde'

    assert to_bytes(utf_string) == b'12345 abcd\xc3\xa9'
    assert to_bytes(utf_string, 'ascii', 'strict') == b'12345 abcde'
    assert to_bytes(utf_string, 'ascii', 'surrogate_or_strict') == b'12345 abcde'
    assert to_bytes(utf_string, 'ascii', 'surrogate_or_replace') == b'12345 abcde'
    assert to_bytes(utf_string, 'ascii', 'surrogate_then_replace') == b'12345 abcde'

# Generated at 2022-06-11 01:30:12.079397
# Unit test for function jsonify
def test_jsonify():
    a = b"\x80abc\x80"
    b = u"\x80abc\x80"
    assert jsonify(a) == jsonify(b)

    a = {u"\x80abc\x80": u"\x80abc\x80"}
    assert jsonify(a) == '{"\u0080abc\u0080": "\u0080abc\u0080"}'
    b = {b"\x80abc\x80": b"\x80abc\x80"}
    assert jsonify(b) == '{"\u0080abc\u0080": "\u0080abc\u0080"}'



# Generated at 2022-06-11 01:30:21.898631
# Unit test for function to_native
def test_to_native():

    original_errors = errors

    if errors in _COMPOSED_ERROR_HANDLERS:
        if HAS_SURROGATEESCAPE:
            errors = 'surrogateescape'
        elif errors == 'surrogate_or_strict':
            errors = 'strict'
        else:
            errors = 'replace'


# Generated at 2022-06-11 01:30:25.946306
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.six import u
    data = dict((u('key'), u('\u20ac')) for _ in range(3))
    data_json = u('{"key": "\u20ac", "key": "\u20ac", "key": "\u20ac"}')
    assert jsonify(data) == data_json



# Generated at 2022-06-11 01:30:36.248842
# Unit test for function to_native
def test_to_native():
    """Test function to_native"""
    assert 'a' == to_native(b'a')
    assert 'a' == to_native(b'a', nonstring='passthru')
    assert 'a' == to_native(u'a')
    assert 'a' == to_native(u'a', nonstring='passthru')
    assert 'a is 1' == to_native(u'a is 1')
    assert 'a is 1' == to_native(u'a is 1', nonstring='passthru')
    assert u'a is 1' == to_native(u'a is 1', nonstring='passthru', keep_string=True)
    assert 'a is 1' == to_native(1)
    assert 1 == to_native(1, nonstring='passthru')
    assert 'True'

# Generated at 2022-06-11 01:30:48.225830
# Unit test for function to_bytes
def test_to_bytes():
    string_type = text_type if PY3 else basestring
    if PY3:
        assert isinstance(to_bytes(u'\u1234'), binary_type)
        assert isinstance(to_bytes(u'\u1234', errors='strict'), binary_type)
        assert isinstance(to_bytes(u'\u1234', errors='surrogate_or_strict'), binary_type)
        assert isinstance(to_bytes(u'\u1234', errors='surrogate_or_replace'), binary_type)
        assert isinstance(to_bytes(u'\u1234', errors='surrogate_then_replace'), binary_type)

        assert isinstance(to_bytes(u'\ufffd'), binary_type)

# Generated at 2022-06-11 01:30:58.700234
# Unit test for function to_native
def test_to_native():
    # The two error handlers are used as part of tests.  We'll only raise an
    # error for them if we're rendering an error with unittest
    global _ANSIBLE_TESTING
    _ANSIBLE_TESTING = True

    # Note: We only test the error handlers used in to_bytes and to_text here.
    # See the tests in test_to_text and test_to_bytes for the rest of the error
    # handler tests.

# Generated at 2022-06-11 01:31:02.065458
# Unit test for function to_bytes
def test_to_bytes():
    assert(to_bytes(b'foo') == b'foo')
    assert(to_bytes('foo') == b'foo')
    assert(to_bytes(u'foo') == b'foo')
    assert(to_bytes(u'é') == b'\xc3\xa9')



# Generated at 2022-06-11 01:31:13.491848
# Unit test for function to_bytes
def test_to_bytes():
    try:
        codecs.lookup_error('surrogateescape')
    except LookupError:
        HAS_SURROGATEESCAPE = False
    else:
        HAS_SURROGATEESCAPE = True

    # Nonstrings
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='simplerepr') == b'1'
    assert to_bytes(1, nonstring='empty') == b''
    try:
        to_bytes(1)
    except TypeError:
        pass
    else:
        raise AssertionError('to_bytes did not raise TypeError on int')

    # Pass through byte strings
    assert to_bytes(b'asdf') == b'asdf'

    # Pass through invalid utf8
    assert to_

# Generated at 2022-06-11 01:31:20.142183
# Unit test for function to_native
def test_to_native():
    assert to_native(b'') == b''
    assert to_native(u'') == u''
    assert to_native(b'foo') == b'foo'
    assert to_native(u'foo') == u'foo'
    # non-utf8 byte string
    assert to_native(u'\u8f68'.encode('cp932')) == u'\u8f68'.encode('cp932')
    assert to_native(u'f\xf2o'.encode('iso-8859-1')) == u'f\xf2o'
    assert to_native(b'foo') == b'foo'
    assert to_native(3) == 3
    assert to_native(3.5) == 3.5
    assert to_native(None) is None
    assert to_native

# Generated at 2022-06-11 01:31:34.287191
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a='b')) == '{"a": "b"}'
    assert jsonify(set(['a', 'b'])) == '["a", "b"]'
    assert jsonify(dict(a=u'b\u5f20')) == '{"a": "b\u5f20"}'
    assert jsonify(dict(a=u'b\u5f20')) == '{"a": "b\u5f20"}'
    assert jsonify(set([u'a\u5f20', u'b'])) == '["a\u5f20", "b"]'
    assert jsonify(set([u'a', u'b\u5f20'])) == '["a", "b\u5f20"]'

# Generated at 2022-06-11 01:31:46.333081
# Unit test for function to_native
def test_to_native():
    assert to_native(1) == '1'
    assert to_native(str(b'foobar'), errors='strict') == b'foobar'
    if PY3:
        assert to_native(str('foobar'), errors='surrogate_or_strict') == 'foobar'
        assert to_native(str(b'foobar'), errors='surrogate_or_strict') == b'foobar'
    else:
        assert to_native(str(b'foobar'), errors='surrogate_or_strict') == u'foobar'
        assert to_native(str('foobar'), errors='surrogate_or_strict') == u'foobar'
    assert to_native(None) == 'None'

# Generated at 2022-06-11 01:31:49.769313
# Unit test for function jsonify
def test_jsonify():
    data = {'test': {'test2': u'\xe9'}}
    data_json = jsonify(data)
    assert isinstance(data_json, str)
    assert data == json.loads(data_json)



# Generated at 2022-06-11 01:31:51.757949
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'



# Generated at 2022-06-11 01:31:54.992235
# Unit test for function to_native
def test_to_native():
    for test_type, test_string in (
            (str, 'foo'),
            (str, b'bar'),
            (str, u'baz'),
            (str, 1),
            (str, 1.0),
    ):
        assert isinstance(to_native(test_string), str)



# Generated at 2022-06-11 01:31:56.712890
# Unit test for function jsonify
def test_jsonify():
    data = {"foo": u"bar"}
    print(jsonify(data))


# Generated at 2022-06-11 01:32:08.993384
# Unit test for function to_bytes
def test_to_bytes():
    if not PY3:
        class Foo(unicode):
            pass
    else:
        class Foo(str):
            pass

    class Bar(object):
        def __repr__(self):
            return '<Bar>'

    assert to_bytes('foo', 'utf-8') == b'foo'
    assert to_bytes(b'foo', 'utf-8') == b'foo'

    if PY3:
        assert to_bytes('foo', 'utf-8', 'surrogate_or_strict') == b'foo'
        assert to_bytes('foo', 'utf-8', 'surrogate_or_replace') == b'foo'
        assert to_bytes('foo', 'utf-8', 'surrogate_then_replace') == b'foo'

    # Before PY3 bytes aren't

# Generated at 2022-06-11 01:32:19.539766
# Unit test for function jsonify

# Generated at 2022-06-11 01:32:31.876359
# Unit test for function to_bytes

# Generated at 2022-06-11 01:32:40.190533
# Unit test for function jsonify
def test_jsonify():
    # data includes strings and dicts
    # test for unicode in keys (Python 2)
    data = {u"name": u"value"}
    assert jsonify(data) == to_native('{"name": "value"}')

    # test for bytes in keys (Python 3)
    data = {b"name": b"value"}
    assert jsonify(data) == to_native('{"name": "value"}')

    # test for other data types (binary and text)
    data = [b'binary_value', u'unicode_value']
    assert jsonify(data) == to_native('["binary_value", "unicode_value"]')

    data = {b'binary_key': u'unicode_value'}
    assert jsonify(data) == to_native('{"binary_key": "unicode_value"}')

# Generated at 2022-06-11 01:33:04.364142
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.six import u
    import sys

    # "empty" tests
    for value in ('', b'', [], (), {}, None, 0):
        result = to_bytes(value)
        if isinstance(result, (list, tuple, set)):
            result = type(result)(result)
        assert result == b'', 'Failed to handle empty input value %r' % value

    # Handle an exception in __repr__
    class BrokenRepr(object):
        def __repr__(self):
            1 / 0
    assert to_bytes(BrokenRepr()) == b'<ansible.module_utils.basic.BrokenRepr object at ', 'Failed to handle exception in __repr__'


# Generated at 2022-06-11 01:33:06.488396
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'😃') == u'😃'
    assert to_native(b'\xF0\x9F\x98\x83') == u'😃'
    

# Generated at 2022-06-11 01:33:17.979636
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native

# Generated at 2022-06-11 01:33:22.296918
# Unit test for function to_native
def test_to_native():
    # Test that to_native() returns str on both Py2 and Py3
    # and works with str, bytes, and unicode
    from ansible.module_utils._text import to_native
    assert isinstance(to_native(u'foo'), str)
    assert isinstance(to_native('foo'), str)
    assert isinstance(to_native(b'foo'), str)

# Generated at 2022-06-11 01:33:34.177191
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(Set([1, 2, 3])) == '{"__ansible_set__": [1, 2, 3]}'
    assert jsonify({'a': Set([1, 2, 3])}) == '{"a": {"__ansible_set__": [1, 2, 3]}}'
    assert jsonify({'a': {'b': Set([1, 2, 3])}}) == '{"a": {"b": {"__ansible_set__": [1, 2, 3]}}}'

    class _datetime(datetime.datetime):
        def __repr__(self):
            return "datetime.datetime(2012, 12, 12, 12, 12, 12)"


# Generated at 2022-06-11 01:33:39.547444
# Unit test for function to_native
def test_to_native():
    string = u'abc123'
    b_string = b'abc123'
    if PY3:
        assert to_native(string) == string
        assert to_native(b_string) == string
    else:
        assert to_native(string) == b_string
        assert to_native(b_string) == b_string


# Generated at 2022-06-11 01:33:45.737269
# Unit test for function jsonify
def test_jsonify():
    class TestEncoder(json.JSONEncoder):
        def default(self, o):
            return o

    assert jsonify({"a": "b", u"c\xe9": [1, 2, 3]}) == '{"a": "b", "c\\u00e9": [1, 2, 3]}'
    assert jsonify({"a": "b", u"c\xe9": [1, 2, 3]}, cls=TestEncoder) == '{"a": "b", "c\xe9": [1, 2, 3]}'



# Generated at 2022-06-11 01:33:54.562080
# Unit test for function to_native
def test_to_native():
    """Test to_native function, this would need to be more comprehensive. """

    assert to_native('', errors=None) == ''
    assert to_native(u'', errors='surrogate_or_strict') == u''
    assert to_native(u'abc', errors='surrogate_or_strict') == u'abc'
    assert to_native(u'abc\u2026') == u'abc\u2026'
    assert to_native(u'abc\u2026', errors='surrogate_or_strict') == u'abc\u2026'



# Generated at 2022-06-11 01:34:05.484378
# Unit test for function to_bytes
def test_to_bytes():
    """
    Test converting various input types using to_bytes

    This function has a fair number of corner cases.  These unit tests are
    designed to exercise all of those cases.
    """
    # Test encoding bytes
    assert to_bytes(b'foo') == b'foo'

    # Test encoding ascii
    assert to_bytes('foo') == b'foo'

    # Test encoding unicode without surrogates
    assert to_bytes(u'foo') == b'foo'

    # Test encoding unicode with surrogates
    assert to_bytes(u'foo\u1234', errors='surrogate_or_replace') == b'foo\xed\xa0\xb4'

    # Test encoding error handling

# Generated at 2022-06-11 01:34:14.016753
# Unit test for function jsonify
def test_jsonify():
    # Test list of int
    data = [1]
    expected = "[1]"
    actual = jsonify(data)
    assert actual == expected
    # Test list of unicode
    data = [u'\xa9']
    expected = '["\u00a9"]'
    actual = jsonify(data)
    assert actual == expected
    # Test a dictionary that can be jsonified
    data = {"a": "b"}
    expected = '{"a": "b"}'
    actual = jsonify(data)
    assert actual == expected
    # Test a dictionary that contains a unicode
    data = {"a": u'\xa9'}
    expected = '{"a": "\u00a9"}'
    actual = jsonify(data)
    assert actual == expected
    # Test a dictionary that contains a Set

# Generated at 2022-06-11 01:34:29.588089
# Unit test for function to_bytes

# Generated at 2022-06-11 01:34:33.782640
# Unit test for function jsonify
def test_jsonify():
    data = dict(a=to_bytes("\u00e9"), b=to_bytes("\u20ac"), c=to_bytes("\u1f60d"))
    assert jsonify(data) == '{"a": "\\u00e9", "c": "\\ud83d\\ude0d", "b": "\\u20ac"}'



# Generated at 2022-06-11 01:34:37.433865
# Unit test for function jsonify
def test_jsonify():
    json_data = jsonify({'name': u'中文字符'})
    assert json_data == '{"name": "\\u4e2d\\u6587\\u5b57\\u7b26"}'



# Generated at 2022-06-11 01:34:49.684459
# Unit test for function to_native

# Generated at 2022-06-11 01:34:56.044988
# Unit test for function jsonify
def test_jsonify():
    assert u"\"\"" == jsonify(u"")
    assert u"\"hallo welt\"" == jsonify(u"hallo welt")
    assert u"\"\\u00fc\"" == jsonify(u"\u00fc")
    assert u"\"\\u00fc\\n\"" == jsonify(u"\u00fc\n")
    assert u"\"\\u00fc\\u6c34\"" == jsonify(u"\u00fc\u6c34")



# Generated at 2022-06-11 01:35:02.473146
# Unit test for function jsonify
def test_jsonify():
    import sys
    # test unicode strings
    unicode_str = u'\u2603'
    data = {u'foo': unicode_str}
    if sys.version_info >= (3,):
        assert jsonify(data) == '{"foo": "\\u2603"}'
    else:
        assert jsonify(data) == '{"foo": "\\u2603"}'
    data = {u'foo': [unicode_str, unicode_str]}
    if sys.version_info >= (3,):
        assert jsonify(data) == '{"foo": ["\\u2603", "\\u2603"]}'
    else:
        assert jsonify(data) == '{"foo": ["\\u2603", "\\u2603"]}'

# Generated at 2022-06-11 01:35:14.112479
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('abc') == b'abc'
    assert to_bytes('abc', errors='strict') == b'abc'
    assert to_bytes('abc', errors='ignore') == b'abc'
    assert to_bytes(b'abc') == b'abc'
    assert to_bytes(b'abc', errors='strict') == b'abc'
    assert to_bytes(b'abc', errors='ignore') == b'abc'
    assert to_bytes(1) == b'1'
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='empty') == b''
    assert to_bytes(1, nonstring='strict') == b'1'


# Generated at 2022-06-11 01:35:20.696989
# Unit test for function jsonify
def test_jsonify():
    data = {'name': to_bytes("\xe8\xbf\x99\xe6\x98\xaf\xe4\xb8\x80\xe9\x94\xae\xe7\xac\x94\xe5\x8f\x8b", "UTF-8")}
    json_dumps = jsonify(data)
    assert(isinstance(json_dumps, text_type))
    assert(json_dumps == u'{"name": "这是一键笔友"}')


# Generated at 2022-06-11 01:35:32.746386
# Unit test for function jsonify
def test_jsonify():
    from os import getcwd
    from random import shuffle
    from tempfile import mkdtemp, mkstemp

    from ansible.utils.path import makedirs_safe
    from ansible.module_utils.six import unichr
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.parsing.convert_bool import boolean

    if not boolean(mkdtemp):
        import pytest
        pytest.skip()

    tmpdir = mkdtemp(prefix='ansible-test-jsonify-')
    stream = cStringIO()
    makedirs_safe(tmpdir)

    # Create a file with a unicode name
    # We don't use mkstemp because we need to know the name it used

# Generated at 2022-06-11 01:35:41.968377
# Unit test for function to_bytes
def test_to_bytes():
    # Test invalid values of nonstring
    try:
        to_bytes(u'foo', nonstring='unknown')
        raise AssertionError('to_bytes should have raised an exception for an unknown nonstring')
    except TypeError:
        pass

    # Test that to_bytes returns a byte string when given a byte string
    assert isinstance(to_bytes('foo'), binary_type)
    assert isinstance(to_bytes(b'foo'), binary_type)

    # Test empty_string
    assert to_bytes(u'', nonstring='empty') == b''

    # Test passthru
    assert to_bytes(u'foo', nonstring='passthru') == u'foo'
    assert to_bytes(u'foo', nonstring='passthru', encoding='utf-8') == u'foo'

    # Test surrogateescape

# Generated at 2022-06-11 01:36:02.598603
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify({'a': 'b'}, ensure_ascii=False) == '{"a": "b"}'
    assert jsonify({'a': 'b'}, ensure_ascii=True) == '{"a": "b"}'
    assert jsonify({u'\u20ac': 'b'}) == u'{"\u20ac": "b"}'
    assert jsonify({u'\u20ac': 'b'}, ensure_ascii=False) == u'{"\u20ac": "b"}'
    assert jsonify({u'\u20ac': 'b'}, ensure_ascii=True) == '{"\\u20ac": "b"}'
    assert jsonify('\u20ac') == u

# Generated at 2022-06-11 01:36:10.360350
# Unit test for function jsonify
def test_jsonify():
    print('\n------------Running Unit test for function jsonify')
    myDict = {'key1': 'value1', 'key2': 'value2'}
    myList = [1, 2, 3]
    myStr = "myStr"
    mySet = set("mySet")
    print("Test Case 1: myDict")
    print("Expected Result: {'key2': 'value2', 'key1': 'value1'}\nActual Result:  " + jsonify(myDict))
    print("Test Case 2: myList")
    print("Expected Result: [1, 2, 3]\nActual Result:  " + jsonify(myList))
    print("Test Case 3: mySet")

# Generated at 2022-06-11 01:36:19.694634
# Unit test for function to_bytes
def test_to_bytes():
    unicode_string = u'`1\xb7\u2260\xe2\x88\x9a\xf0\x9f\x94\xa5`'
    bytes_string = unicode_string.encode('utf-8')

    assert to_bytes(unicode_string) == bytes_string
    assert to_bytes(unicode_string, 'latin-1', 'surrogate_or_replace') == bytes_string
    assert to_bytes(unicode_string, 'latin-1', 'surrogate_then_replace') == bytes_string

    assert to_bytes(1) == '1'
    assert to_bytes(1, nonstring='strict') == TypeError


# Generated at 2022-06-11 01:36:29.811938
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u1234') == '\u1234'
    assert to_native(b'foo') == 'foo'
    assert to_native(b'\x80\x81') == '\u20ac\u20ac'
    assert to_native(b'\x80\x81', errors='surrogate_or_replace') == '\ufffd\ufffd'
    assert to_native(u'\u1234f\u20acoo') == '\u1234f\u20acoo'
    assert to_native(b'\x80\x81f\xe2\x82\xacoo') == '\u20ac\u20acf\u20acoo'

# Generated at 2022-06-11 01:36:36.852766
# Unit test for function to_bytes
def test_to_bytes():

    def te(test_input, test_output, **kwargs):
        return {'input': test_input, 'output': test_output, 'kwargs': kwargs}

    # Test text inputs

# Generated at 2022-06-11 01:36:40.717259
# Unit test for function jsonify
def test_jsonify():
    x = dict(foo=u'\xe9')
    try:
        json.dumps(x)
    except UnicodeDecodeError:
        pass
    else:
        raise AssertionError('Should have failed to jsonify')

    assert jsonify(x)



# Generated at 2022-06-11 01:36:44.893023
# Unit test for function jsonify
def test_jsonify():
    before = {u'bytes': b'\xff', u'unicode': u'\u2603'}
    after = u'{"unicode": "\\u2603", "bytes": "\\ufffd"}'
    assert jsonify(before) == after


# Generated at 2022-06-11 01:36:53.034579
# Unit test for function jsonify
def test_jsonify():
    # test jsonify
    example_dict = {"a": "abc", "b": "xyz"}
    assert jsonify(example_dict) == '{"a": "abc", "b": "xyz"}'
    # test invalid encoding error
    example_dict["a"] = u"\u1391"
    try:
        jsonify(example_dict)
    except UnicodeDecodeError:
        pass
    else:
        raise AssertionError('jsonify should throw UnicodeDecodeError')



# Generated at 2022-06-11 01:36:57.289281
# Unit test for function jsonify
def test_jsonify():
    if PY3:
        text = '{"a": "b"}'
        result = jsonify({'a': 'b'})
        assert text == result
    else:
        text = '{"a": "b"}'
        result = jsonify({'a': u'b'})
        assert text == result

        text = '{"a": "b"}'
        result = jsonify({'a': u'b'.encode('utf-8')})
        assert text == result


# Generated at 2022-06-11 01:37:07.858445
# Unit test for function to_native
def test_to_native():
    # Python 3 - native string already is unicode
    if PY3:
        assert to_native('привіт світ') == 'привіт світ'
        assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82 \xd1\x81\xd0\xb2\xd1\x96\xd1\x82') == 'привіт світ'
        assert to_native(b'\xc3\xbc') == 'ü'
        assert to_native(b'\xef\xbb\xbf') == '﻿'

# Generated at 2022-06-11 01:37:28.856001
# Unit test for function to_native
def test_to_native():
    if PY3:
        assert to_native(1) == '1'
        assert to_native(u'string') == 'string'
        assert to_native(b'bytes') == 'bytes'
        assert to_native(None) == 'None'
        assert to_native(b'\x80\x81\x82', errors='surrogate_or_strict') == '\udc80\udc81\udc82'
        assert to_native(b'\x80\x81\x82', errors='surrogate_or_replace') == '\udc80\udc81\udc82'
        assert to_native(b'\x80\x81\x82', errors='surrogate_then_replace') == '\udc80\udc81\udc82'

# Generated at 2022-06-11 01:37:37.771975
# Unit test for function to_native
def test_to_native():
    assert to_native(b'ascii') == 'ascii'
    assert to_native(u'ascii') == 'ascii'
    assert to_native(b'\x80') == u'\ufffd'

if PY3:
    def to_native(obj,errors='replace'):
        return to_text(obj,'utf-8',errors,nonstring='passthru')
    long = int
else:
    def to_native(obj,errors='replace'):
        return to_bytes(obj,'utf-8',errors,nonstring='passthru')

# Generated at 2022-06-11 01:37:41.865324
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': u'a', 'b': u'\uFFF0'})
    assert jsonify({'a': u'a\x80', 'b': u'\uFFF0'})
    assert jsonify({'a': 'a', 'b': set(['a', u'\uFFF0'])})
    assert jsonify(set([u'\uFFF0']))
    assert jsonify({'a': 'a\x80', 'b': set(['a', u'\uFFF0'])})



# Generated at 2022-06-11 01:37:46.665051
# Unit test for function to_native
def test_to_native():
    a = u"\u6c49\u5b57"
    b = a.encode('utf-8')
    c = b.decode('utf-8')
    assert to_native(a) == c
    assert to_native(b) == c
    assert to_native(c) == c
    assert to_native(None) is None
    assert to_native(123) == 123


# Generated at 2022-06-11 01:37:57.968496
# Unit test for function to_native
def test_to_native():

    # Check the bytes path
    assert to_native(b"\xc3\xbc") == u'ü'

    # Check the unicode path
    assert to_native(u'\xe9') == u'\xe9'

    # Check surrogate_or_strict, surrogate_or_replace, surrogate_then_replace

    if HAS_SURROGATEESCAPE:
        expected = u'\xed\xa0\x80'
        assert to_native(b'\xed\xa0\x80', errors='surrogate_or_strict') == expected
        assert to_native(b'\xed\xa0\x80', errors='surrogate_or_replace') == expected

# Generated at 2022-06-11 01:38:06.426804
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    assert to_native(u'\xe9') == u'\xe9'
    assert to_native(b'\xe9') == u'\xe9'
    assert to_native(u'\xe9'.encode('utf-8')) == u'\xe9'
    assert to_native(None) == u''
    assert to_native(1) == u'1'
    assert to_native([u'\xe9']) == u"['\\xe9']"
    assert to_native(u'\xe9', errors='surrogate_or_replace') == u'\ufffd'



# Generated at 2022-06-11 01:38:16.001911
# Unit test for function to_bytes
def test_to_bytes():
    class Foo(object):
        def __str__(self):
            return u'Foo!'
        def __repr__(self):
            return u'Foo!'

    assert to_bytes(u'\ufffd', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\ufffd', errors='surrogate_or_strict') == b'\xef\xbf\xbd'
    assert to_bytes(u'\ue000', errors='surrogate_or_replace') == b'\xef\xbf\xbd'
    assert to_bytes(u'\ue000', errors='surrogate_or_strict') == b'\xef\xbf\xbd'

# Generated at 2022-06-11 01:38:19.739620
# Unit test for function jsonify
def test_jsonify():
    data = {"key1": "value", "key2": "value2"}
    import json
    a = (jsonify(data))
    b = (json.dumps(data, default=_json_encode_fallback))
    assert (a == b)



# Generated at 2022-06-11 01:38:27.676935
# Unit test for function to_bytes
def test_to_bytes():
    # The primary use case of to_bytes is going to be when converting
    # text_type to binary_type for use with something that expects binary_type
    # strings.  We test encoding and decoding a random unicode string to make
    # sure that it works.
    text = '\u00e8.ogg'

    # We can also use it to simplify a common idiom in converting text strings
    # to byte strings.  In python2 this was:
    #   encoded_string = text.encode('utf-8', 'strict')
    # In python3 this is:
    #   encoded_string = text.encode('utf-8', 'surrogateescape')
    #
    # There are a few problems with this.  1) The 'surrogateescape' error
    # handler was added after python3.3 and so code that

# Generated at 2022-06-11 01:38:37.256908
# Unit test for function to_native
def test_to_native():
    assert to_native(to_bytes(u'नमस्ते', 'utf-8')) == u'नमस्ते'
    assert to_native(to_bytes(u'abc', 'utf-8')) == u'abc'
    assert to_native(to_bytes(u'abc', 'utf-8')) is not u'abc'
    assert to_native(to_bytes(b'abc'), 'utf-8') == u'abc'
    assert to_native(to_bytes(b'abc'), 'utf-8') is not u'abc'


# Generated at 2022-06-11 01:38:51.641772
# Unit test for function to_native
def test_to_native():
    assert to_native(None) is None
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'



# Generated at 2022-06-11 01:38:55.805880
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(['test', 'dict', {'a':1}]) == '["test", "dict", {"a": 1}]'
    assert jsonify('test') == '"test"'
    assert jsonify(dict(a=1)) == '{"a": 1}'
    assert jsonify(1) == '1'



# Generated at 2022-06-11 01:39:06.518005
# Unit test for function to_native
def test_to_native():
    assert to_native('a') == 'a'
    assert to_native(b'a') == 'a'
    assert to_native('\xe5') == '\xe5'
    assert to_native(b'\xe5') == '\xe5'
    assert to_native('\u2603') == '\u2603'
    assert to_native(u'\u2603') == '\u2603'
    assert to_native(b'\xe5', errors='surrogate_or_strict') == '\xe5'
    assert to_native(b'\xe5', errors='surrogate_or_replace') == '\xe5'

# Generated at 2022-06-11 01:39:18.522866
# Unit test for function to_native
def test_to_native():

    assert to_native(to_text('ascii', 'ascii')) == 'ascii'
    assert to_native(to_bytes('ascii'), 'ascii') == 'ascii'
    assert to_native(to_text(u'ŠĐĆŽćžšđ', 'utf-8'), 'utf-8') == u'ŠĐĆŽćžšđ'
    assert to_native(to_bytes(u'ŠĐĆŽćžšđ'.encode('utf-8')), 'utf-8') == u'ŠĐĆŽćžšđ'

# Generated at 2022-06-11 01:39:26.571311
# Unit test for function jsonify
def test_jsonify():
    json_str = jsonify(u'foo')
    assert_equal(json_str, '"foo"')

    json_str = jsonify(u'\xe9')
    assert_equal(json_str, '"\xc3\xa9"')

    json_str = jsonify({u'foo': u'\xe9'})
    assert_equal(json_str, '{"foo": "\xc3\xa9"}')

    json_str = jsonify([u'\xe9'])
    assert_equal(json_str, '["\xc3\xa9"]')



# Generated at 2022-06-11 01:39:36.924215
# Unit test for function to_native