

# Generated at 2022-06-11 01:30:02.906829
# Unit test for function to_native
def test_to_native():

    assert to_native(b"ascii") == "ascii"
    assert to_native("ascii") == "ascii"
    assert to_native(u"ascii") == u"ascii"
    assert to_native(u"ascii".encode("ascii")) == "ascii"
    assert to_native(u"ascii".encode("ascii"), errors="surrogate_or_strict") == u"ascii"
    assert to_native(u"ascii".encode("utf32"), errors="surrogate_or_strict") == u"ascii"

    # surrogate_or_strict raises an exception if the input cannot be encoded
    #  using surrogateescape.  surrogateescape was added in python3.

# Generated at 2022-06-11 01:30:13.575027
# Unit test for function to_bytes
def test_to_bytes():
    # Verify that surrogate_then_replace is the default
    assert to_bytes(u'foo', errors='surrogate_then_replace') == b'foo'
    # Verify that surrogateescape is what we end up using if surrogate_then_replace is specified
    assert to_bytes(u'foo', errors='surrogate_then_replace') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_replace') == b'foo'
    # Make sure surrogate_then_replace works as expected
    assert to_bytes(u'foo\udcff') == b'foo\ufffd'

    # Verify that surrogateescape does in fact escape surrogates
    assert to_bytes(u'foo\udcff', errors='surrogateescape') == b'foo\udcff'

# Generated at 2022-06-11 01:30:24.050793
# Unit test for function jsonify
def test_jsonify():
    """
    Test the module_utils_text.jsonify function
    """
    import sys

    # Input data to be passed to function

# Generated at 2022-06-11 01:30:34.430154
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native,to_bytes
    print("=========study to_native function=========")

    #print("to_native({})".format(to_native({})))
    #print("to_native({})".format(to_native({'key':'value'})))
    #print("to_native({},method='json')".format(to_native({'key':'value'},method='json')))
    #print("to_native(Set(['111','222']))".format(to_native(Set(['111','222']))))
    #print("to_native(Set(['111','222']),method='json')".format(to_native(Set(['111','222']),method='json')))
    #print("to_native(Set(['111','222']),

# Generated at 2022-06-11 01:30:40.832500
# Unit test for function jsonify
def test_jsonify():
    data={
         "ansible_facts": {
            "discovered_interpreter_python": "/usr/bin/python",
            "gather_subset": [
                "min",
                "hardware",
                "network"
            ],
            "group_names": [
                "all",
                "ungrouped"
            ]
         }
                  }

    print(jsonify(data))

if __name__ == "__main__":
    test_jsonify()

# Generated at 2022-06-11 01:30:44.120831
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=u'\u4500')) is not None
    assert jsonify(dict(a=b'\xe4\x94\x80')) is not None


# Generated at 2022-06-11 01:30:55.933754
# Unit test for function to_bytes
def test_to_bytes():

    # This is all of the error handlers that the standard Python3 codecs
    # implements.  These are documented in
    # https://docs.python.org/3/library/codecs.html#error-handlers
    error_handlers = set(['strict', 'ignore', 'replace',
                          'xmlcharrefreplace', 'backslashreplace'])

    # We'll add the 'surrogateescape' handler if it's available
    if HAS_SURROGATEESCAPE:
        error_handlers.add('surrogateescape')

    # Let's test all of them
    #
    # This is the test data we're going to use.  It's a list of tuples.  Each
    # tuple has the `input_string`, the `encoding` to encode a non-ascii
    # string to, and

# Generated at 2022-06-11 01:31:01.028831
# Unit test for function to_native
def test_to_native():
    b_test = u'hi there'
    t_test = b_test.encode('utf-8')
    n1 = to_native(t_test)
    assert n1 == b_test
    n2 = to_native(b_test)
    assert n2 == b_test
    n3 = to_native(t_test, errors='surrogate_or_strict')
    assert n3 == b_test


# Generated at 2022-06-11 01:31:06.848277
# Unit test for function to_native

# Generated at 2022-06-11 01:31:18.856285
# Unit test for function to_bytes
def test_to_bytes():
    # Note: not including surrogateescape tests with Python 2.6 or 2.7
    # To test for surrogateescape you need to run the tests using a Python 2.x
    # that has a backport of the codec
    # I would also like to test that surrogate_or_strict fails when
    # surrogateescape is not supported by the Python it's being run in but we
    # currently do not have a way to do that in a unit test

    # We don't have to check the while bytes alphabet on Python 2.x because
    # the Python str type is bytes on Python 2.x
    if PY3:
        # bytes only
        assert to_bytes(b'\xe2\x98\x83') == b'\xe2\x98\x83'

        # bytes and nonstring

# Generated at 2022-06-11 01:31:28.343553
# Unit test for function to_bytes
def test_to_bytes():
    if PY3:
        # Just make sure we don't traceback
        assert to_bytes(u'\U000ABCDE') == b''
    else:
        # Just make sure we don't traceback
        assert to_bytes(u'\U000ABCDE') == b''


# Generated at 2022-06-11 01:31:34.510446
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_bytes, to_text
    for u_str in (u'foo', u'f\u1234oo', u'\uffff'):
        # The following two lines return different types based on python version
        if PY3:
            expected_type = str
        else:
            expected_type = unicode
        assert isinstance(jsonify(u_str), expected_type)

        # We have to make sure that we don't return a unicode object
        assert not isinstance(jsonify(to_bytes(u_str, encoding='utf-8')), unicode)

        # The following two lines return different types based on python version
        if PY3:
            expected_type = str
        else:
            expected_type = unicode

# Generated at 2022-06-11 01:31:46.536854
# Unit test for function jsonify
def test_jsonify():
    # Copied from Ansible json_dump filter
    # https://github.com/ansible/ansible/blob/devel/lib/ansible/utils/unsafe_proxy.py#L1887
    import datetime
    d = {
        "k": datetime.datetime.now(),
        "j": datetime.datetime.now(),
        "l": datetime.datetime.now(),
        "m": {
            "n": datetime.datetime.now(),
            "o": datetime.datetime.now(),
            "p": datetime.datetime.now()
        },
        "q": [
            datetime.datetime.now(),
            datetime.datetime.now(),
            datetime.datetime.now()
        ]
    }


# Generated at 2022-06-11 01:31:55.304767
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils.common.dict_transformations import to_native
    d = {'a': 'foo', 'b': {'c': [1, 2, 3], 'd': 'bar'}, 'e': u'\xc6'}
    converted_d = to_native(d)
    assert converted_d == {'a': u'foo', 'b': {'c': [1, 2, 3], 'd': u'bar'}, 'e': '\xc6'}
    assert isinstance(converted_d['a'], text_type)
    assert isinstance(converted_d['b']['c'], list)
    assert isinstance(converted_d['b']['d'], text_type)
    assert isinstance(converted_d['e'], binary_type)

   

# Generated at 2022-06-11 01:32:07.043312
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"foo": "bar"}) == '{"foo": "bar"}'
    assert jsonify({"foo": to_bytes("bar",'utf-8')}) == '{"foo": "bar"}'
    assert jsonify({"foo": to_bytes("bar",'utf-8',errors='surrogateescape')}) == '{"foo": "bar"}'
    assert jsonify({"foo": to_bytes("bar",'utf-8',errors='surrogate_or_strict')}) == '{"foo": "bar"}'
    assert jsonify({"foo": to_bytes("bar",'utf-8',errors='surrogate_or_replace')}) == '{"foo": "bar"}'

# Generated at 2022-06-11 01:32:14.118187
# Unit test for function to_bytes
def test_to_bytes():
    '''
    This function tests the to_bytes function

    1. to_bytes with string type
    2. to_bytes with byte string type
    3. to_bytes with nonstring type
    '''
    assert to_bytes(u'Ansible 2018') == b'Ansible 2018'
    assert to_bytes(b'Ansible 2018') == b'Ansible 2018'
    assert to_bytes(2018, nonstring='simplerepr') == b'2018'



# Generated at 2022-06-11 01:32:22.625171
# Unit test for function to_native

# Generated at 2022-06-11 01:32:34.496127
# Unit test for function to_bytes
def test_to_bytes():
    # This is to make sure that a byte string stays a byte string, a
    # text string becomes a byte string, and a nontext object becomes
    # a byte string
    tests = [
        ('b', b'b'),
        (u'\u1234', b'\xe1\x88\xb4'),
        (u'\udcff\udc00', b'\xf4\x8f\xbf\x80'),
        (u'\ud800\udc00', b'\xf0\x90\x80\x80'),
        (u'\ud800\udc00\U00010000', b'\xf0\x90\x80\x80\xf0\x90\x80\x80'),
        (1, b'1'),
    ]


# Generated at 2022-06-11 01:32:46.379246
# Unit test for function to_bytes
def test_to_bytes():
    import unittest
    class TestToBytes(unittest.TestCase):
        def test_unicode_string(self):
            self.assertEqual(to_bytes('123'), b'123')
            self.assertEqual(to_bytes('\xe5'), u'\xe5'.encode('utf-8'))
            self.assertRaises(UnicodeEncodeError, to_bytes, u'\xe5', encoding='latin-1')
            self.assertEqual(to_bytes(u'\xe5', encoding='latin-1', errors='surrogate_or_strict'), b'?')
            self.assertEqual(to_bytes(u'\xe5', encoding='latin-1', errors='surrogate_or_replace'), b'?')

# Generated at 2022-06-11 01:32:55.534800
# Unit test for function to_native
def test_to_native():
    assert u"äö∂".encode("utf-8") == b"\xc3\xa4\xc3\xb6\xe2\x88\x82"
    assert to_native(u"äö∂") == b"\xc3\xa4\xc3\xb6\xe2\x88\x82"
    assert b"\xc3\xa4\xc3\xb6\xe2\x88\x82".decode('utf-8') == u"äö∂"
    assert to_native(b"\xc3\xa4\xc3\xb6\xe2\x88\x82") == u"äö∂"
    assert u'\\xe2\\x88\\x82'.encode('ascii') == b'\\xe2\\x88\\x82'
    string

# Generated at 2022-06-11 01:33:05.000966
# Unit test for function jsonify
def test_jsonify():
    data = {'str': 'aééééééé'}
    assert jsonify(data) == '{"str": "aééééééé"}'



# Generated at 2022-06-11 01:33:12.646410
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(to_bytes(u'abcd')) == '"abcd"'
    assert jsonify(u'abcd') == u'"abcd"'
    assert jsonify([to_bytes(u'abcd'), to_bytes(u'efgh')]) == '["abcd", "efgh"]'
    assert jsonify((to_bytes(u'abcd'), to_bytes(u'efgh'))) == '["abcd", "efgh"]'



# Generated at 2022-06-11 01:33:21.979519
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(text_type(u'foo')) == u'foo'
    assert to_native(binary_type(b'foo')) == u'foo'
    assert to_native(datetime.datetime.utcnow()) == str(datetime.datetime.utcnow())
    assert to_native(Set([b'foo', b'bar'])) == set([u'foo', u'bar'])
    assert to_native({b'foo': b'bar'}) == {u'foo': u'bar'}

# Generated at 2022-06-11 01:33:33.711494
# Unit test for function to_bytes
def test_to_bytes():
    # Can't test surrogateescape unless we have a version that supports it
    # TODO: Get a version of surrogateescape for Python2 to test this
    #if not HAS_SURROGATEESCAPE:
    #    return

    # A bytestring should not be touched by this function
    assert b'test' == to_bytes(b'test')
    assert b'test' == to_bytes(b'test', errors='surrogate_then_replace')

    # A unicode string should be returned as utf-8
    assert b'test' == to_bytes(u'test')
    assert b'test' == to_bytes(u'test', errors='surrogate_then_replace')
    assert b'test' == to_bytes(u'test', nonstring='simplerepr')

    # Non-ascii unicode

# Generated at 2022-06-11 01:33:43.816868
# Unit test for function to_bytes
def test_to_bytes():
    text = u'\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e'
    # Default encoding
    assert to_bytes(text) == b'\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e'
    # Default encoding with non-ascii object
    nonascii = object()
    nonascii.__str__ = lambda s: text
    assert to_bytes(nonascii) == b'\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e'
    # Non-default encoding

# Generated at 2022-06-11 01:33:55.014497
# Unit test for function to_bytes
def test_to_bytes():
    class FakeUnicodeObj(object):
        def __str__(self):
            return u'\xe5\xe4\xf6'

        def __repr__(self):
            return u'\xe5\xe4\xf6'

    class FakeLatin1Obj(object):
        def __str__(self):
            return '\xc3\xa4\xc3\xa5\xc3\xb6'

        def __repr__(self):
            return '\xc3\xa4\xc3\xa5\xc3\xb6'

    class NonStrObj(object):
        pass

    class BadReprObj(object):
        def __repr__(self):
            return u'\xe5\xe4\xf6'


# Generated at 2022-06-11 01:33:59.878515
# Unit test for function to_native
def test_to_native():
    # TODO: we need to actually test that this handles unicode, but this is
    # a decent start
    assert to_native(b'ascii') == u'ascii'
    assert to_native(u'unicode') == u'unicode'
    assert to_native('utf8') == u'utf8'



# Generated at 2022-06-11 01:34:07.388878
# Unit test for function to_native
def test_to_native():

    assert to_native('test') == 'test'
    assert to_native(u'test') == 'test'
    assert to_native(b'test') == 'test'
    assert to_native(u'\u00e9') == 'é'
    assert to_native(b'\xc3\xa9') == 'é'
    assert to_native(1) == '1'
    assert to_native(None) == 'None'
    assert to_native(dict(a=1)) == "{'a': 1}"



# Generated at 2022-06-11 01:34:09.746057
# Unit test for function jsonify
def test_jsonify():
    sample_1 = dict([(to_text(u'foo'), to_text('bar'))])
    assert sample_1 == json.loads(jsonify(sample_1))



# Generated at 2022-06-11 01:34:16.193613
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b"", 'latin-1') == b""
    assert to_bytes(b"\xe9", 'utf-8', errors='surrogate_or_replace') == b'\xc3\xa9'
    assert to_bytes(b"\xe9", 'utf-8', errors='surrogate_or_strict') == b'\xc3\xa9'
    assert to_bytes(b"\xe9", 'utf-8', errors='surrogate_then_replace') == b'\xc3\xa9'
    assert to_bytes(u'\xe9', 'utf-8') == b'\xc3\xa9'

# Generated at 2022-06-11 01:34:32.226486
# Unit test for function to_native
def test_to_native():
    class UnicodeClass(object):
        def __str__(self):
            return u'é'

    class NonUnicodeClass(object):
        def __str__(self):
            return b'\xc3\xa9'

    class NonASCIIRepr(object):
        def __repr__(self):
            return u'é'

    class NonUnicodeRepr(object):
        def __repr__(self):
            return b'\xc3\xa9'

    # unicode strings work normally
    assert to_text(u'é') == u'é'

    # byte strings are utf-8 decoded if possible
    assert to_text(b'\xc3\xa9') == u'é'

    # non-unicode classes are turned into unicode strings via str()
    assert to_text

# Generated at 2022-06-11 01:34:42.914822
# Unit test for function to_native
def test_to_native():
    data = {u'a': 1}
    json_data = json.dumps(data, ensure_ascii=False)
    assert isinstance(json_data, binary_type)
    json_data = json.dumps(data, ensure_ascii=False).decode('utf-8')
    assert isinstance(json_data, text_type)
    json_data = json.dumps(data, ensure_ascii=False).decode('utf-8').encode('utf-8')
    assert isinstance(json_data, binary_type)
    json_data = json.dumps(data, ensure_ascii=False).encode('utf-8')
    assert isinstance(json_data, binary_type)

# Generated at 2022-06-11 01:34:53.467998
# Unit test for function jsonify
def test_jsonify():
    data = {'str': 'foo',
            'unicode': u'\u2713',
            'int': 1,
            'float': 1.1,
            'complex': 1 + 5j,
            'bool': True,
            'list': [1, 'foo', u'\u2713'],
            'tuple': (1, 'foo', u'\u2713'),
            'dict': {'1': 1, 'foo': 'foo', u'\u2713': u'\u2713'},
            'set': set([1, 'foo', u'\u2713'])}
    text = jsonify(data)
    json_data = json.loads(text)
    assert data == json_data



# Generated at 2022-06-11 01:35:01.175499
# Unit test for function to_bytes
def test_to_bytes():
    # Test the basic Unicode to bytes transformations that we expect
    # to work.
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0456\u0442', 'utf-8') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82'
    # Test with nonstring being passthru
    nonstring = u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_bytes(nonstring, 'utf-8', nonstring='passthru') == nonstring
    # Test with nonstring being empty
    assert to_bytes(nonstring, 'utf-8', nonstring='empty') == b''
   

# Generated at 2022-06-11 01:35:12.011186
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({u'a': u'\xe4\xf6\xfc'}) == u'{"a": "\\u00e4\\u00f6\\u00fc"}'
    assert jsonify({'a': u'\xe4\xf6\xfc'}, ensure_ascii=False) == u'{"a": "äöü"}'
    assert jsonify({u'a': '\xe4\xf6\xfc'}) == u'{"a": "\\u00e4\\u00f6\\u00fc"}'
    assert jsonify({'a': '\xe4\xf6\xfc'}, ensure_ascii=False) == u'{"a": "\\xe4\\xf6\\xfc"}'



# Generated at 2022-06-11 01:35:21.859745
# Unit test for function to_bytes
def test_to_bytes():
    import sys
    import locale
    locale.setlocale(locale.LC_ALL, 'en_US.UTF-8')

    def check(obj, encoding, errors=None, nonstring='simplerepr', expected=None):
        # If a test wants to verify that to_bytes raises an exception it needs to set
        # this flag to True.  Otherwise if the test causes an error (such as supplying
        # an invalid error handler) we would never see that error as the test runner
        # would catch it first.
        expect_traceback = False

        actual = ''

# Generated at 2022-06-11 01:35:33.398678
# Unit test for function to_bytes
def test_to_bytes():
    def tb(obj, encoding='utf-8', errors='surrogate_or_strict', nonstring='simplerepr'):
        return to_bytes(obj, encoding, errors, nonstring)

    # Test basic usage with str, bytes, and unicode
    # Test to make sure that the return type is always bytes
    assert isinstance(tb(u'\u0fff'), binary_type)
    assert isinstance(tb('\xff'), binary_type)
    # Test to make sure double encoding doesn't occur
    assert tb('\xff') == b'\xff'

    # Test with error handlers
    assert tb(u'\u0fff', errors='surrogate_or_strict') == b'\xff'

# Generated at 2022-06-11 01:35:39.914123
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u00f1') == u'\xf1'
    assert to_native('\xe2\x98\x83') == u'\u2603'
    assert to_native(b'\xe2\x98\x83') == u'\u2603'
    assert to_native(u'\xe2\x98\x83') == u'\u2603'
    assert to_native({'a': 5}) == {'a': 5}
    assert to_native(5) == 5



# Generated at 2022-06-11 01:35:47.093441
# Unit test for function to_native
def test_to_native():
    """
    Test to_native
    """
    assert to_native(1) == '1'
    assert to_native(u'1') == '1'
    assert to_native('\u2122') == u'\u2122'
    assert to_native(b'\xe2\x84\xa2') == u'\u2122'
    assert to_native(b'\xe2\x84\xa2', errors='surrogate_or_strict') == u'\u2122'
    assert to_native(b'\xe2\x84\xa2', errors='surrogate_or_replace') == u'\u2122'
    assert to_native(b'\xe2\x84\xa2', errors='surrogate_then_replace') == u'\u2122'


# Generated at 2022-06-11 01:35:57.614703
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == b'foo'
    # Test with nonstring values
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    assert to_bytes(1) == b'1'
    assert to_bytes([1, 2, 3]) == b'[1, 2, 3]'
    # test with unicode arguments
    assert to_bytes(u'foó') == u'foó'.encode('utf-8')
    assert to_bytes(u'foó'.encode('utf-8'), encoding='latin-1') == u'foó'.encode

# Generated at 2022-06-11 01:36:10.949050
# Unit test for function to_bytes
def test_to_bytes():

    # Not much to test for this since it's all about error conditions.  We just
    # want to make sure that our branches are hit
    assert to_bytes('', nonstring='strict') == b''
    assert to_bytes([], nonstring='strict') == b''
    assert to_bytes({}, nonstring='strict') == b''
    assert to_bytes(u'ni\xf1o', encoding='ascii') == b'nio'
    assert to_bytes(u'ni\xf1o', encoding='ascii', errors='ignore') == b'nio'
    assert to_bytes(u'ni\xf1o', encoding='ascii', errors='strict') == b'nio'
    assert to_bytes(u'ni\xf1o', encoding='ascii', errors='replace') == b

# Generated at 2022-06-11 01:36:21.524091
# Unit test for function to_bytes
def test_to_bytes():
    # This mess is necessary to get the tests to pass under Python 2.6
    # Python 2.6's codecs doesn't like --invalid-name
    import sys
    import os
    if sys.version_info[:2] < (2, 7):
        encoding = os.environ.get('LC_ALL', os.environ.get('LANG'))
        if not encoding:
            encoding = 'ascii'
    else:
        encoding = sys.stdout.encoding

    assert to_bytes('hello') == b'hello'
    if encoding != 'ascii':
        # Latin-1 will always succeed in encoding
        assert to_bytes(b'\xff'.decode('latin-1'), errors='surrogate_or_strict') == b'\xff'

# Generated at 2022-06-11 01:36:29.268694
# Unit test for function to_bytes
def test_to_bytes():
    test_str = b'test \xe4\xbd\xa0\xe5\xa5\xbd'
    if PY3:
        test_str = codecs.decode(test_str, encoding='utf-8', errors='surrogateescape')
    assert to_bytes(test_str) == b'test \xe4\xbd\xa0\xe5\xa5\xbd'
    assert to_bytes(u'test \u4f60\u597d') == b'test \xe4\xbd\xa0\xe5\xa5\xbd'



# Generated at 2022-06-11 01:36:36.748284
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"foo": u'bar'}) == '{"foo": "bar"}'
    assert jsonify({"foo": u'bar'}, sort_keys=True) == '{"foo": "bar"}'
    assert jsonify(set([1,2,3])) == '[1, 2, 3]'
    assert jsonify(set([1,2,3]), sort_keys=True) == '[1, 2, 3]'
    assert jsonify({"foo": set([1,2,3])}) == '{"foo": [1, 2, 3]}'
    assert jsonify({"foo": set([1,2,3])}, sort_keys=True) == '{"foo": [1, 2, 3]}'
    assert jsonify((1,2,3)) == '[1, 2, 3]'

# Generated at 2022-06-11 01:36:47.961889
# Unit test for function to_native
def test_to_native():
    assert to_native(b'string') == 'string'
    assert to_native(b'string\x00') == 'string\x00'
    assert to_native(u'string') == 'string'
    assert to_native(u'string\x00') == 'string\x00'
    assert to_native(u'string', nonstring='passthru') == u'string'
    assert to_native(b'string', nonstring='passthru') == b'string'
    assert to_native([u'foo', 'bar']) == [u'foo', 'bar']
    assert to_native([u'\xe9']) == [u'\xe9']
    assert to_native(Set([u'foo', 'bar'])) == set([u'foo', 'bar'])

# Generated at 2022-06-11 01:36:49.897969
# Unit test for function jsonify
def test_jsonify():
    ascii_data = {b"foo": b"bar"}
    print(jsonify(ascii_data))
    json_data = {u"foo": u"bar"}
    print(jsonify(json_data))



# Generated at 2022-06-11 01:36:56.326638
# Unit test for function to_bytes
def test_to_bytes():
    import pytest


# Generated at 2022-06-11 01:37:06.633588
# Unit test for function to_native

# Generated at 2022-06-11 01:37:13.037471
# Unit test for function jsonify
def test_jsonify():
    # Test for basic Python types
    assert jsonify(None) == 'null'
    assert jsonify(True) == 'true'
    assert jsonify(False) == 'false'
    assert jsonify(1) == '1'
    assert jsonify(1.1) == '1.1'
    assert jsonify(1+1j) == '{"__complex__": true, "real": 1.0, "imag": 1.0}'
    assert jsonify("") == '""'
    assert jsonify("a") == '"a"'
    assert jsonify((1, 1.1, 1+1j)) == '[1, 1.1, {"__complex__": true, "real": 1.0, "imag": 1.0}]'
    assert jsonify({"a": "b"}) == '{"a": "b"}'

# Generated at 2022-06-11 01:37:21.392008
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import text_type
    x_unicode_string = u'\u03c3'
    x_str = x_unicode_string.encode('utf-8')
    assert to_native(x_str) == x_str
    assert to_native(x_str, errors='surrogate_or_strict') == u'\udcc3'
    assert to_native(x_str, errors='surrogate_or_replace') == u'?'
    assert to_native(x_str, errors='surrogate_then_replace') == u'?'
    assert to_native(x_unicode_string) == x

# Generated at 2022-06-11 01:37:30.079175
# Unit test for function to_bytes
def test_to_bytes():
    # It's easiest to just make sure this compiles so that codepaths are
    # exercised.
    obj = to_bytes(5, nonstring='strict')



# Generated at 2022-06-11 01:37:41.115251
# Unit test for function to_bytes
def test_to_bytes():
    """
    >>> test_to_bytes()
    True
    """
    assert to_bytes(b'123') == b'123'
    assert to_bytes('123') == b'123'
    try:
        to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442')
    except UnicodeEncodeError:
        # Different Python versions do different things :(
        pass
    else:
        raise AssertionError('to_bytes did not raise UnicodeEncodeError when given a Unicode string')
    assert to_bytes(1) == b'1'
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='empty') == b''
    assert to_bytes(None) == b'None'

# Generated at 2022-06-11 01:37:49.305134
# Unit test for function jsonify
def test_jsonify():

    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import StringIO

    try:
        #json.dumps(u'\x93')  # works on current systems
        json.dumps(u'\x93'.encode('latin-1').decode('utf-8'))  # works on old systems
    except UnicodeDecodeError:
        return False

    output = StringIO()


# Generated at 2022-06-11 01:38:00.876557
# Unit test for function to_bytes
def test_to_bytes():
    import sys
    # Test simple cases
    assert to_bytes('something') == b'something'
    assert to_bytes(u'something') == b'something'
    assert to_bytes(u'something', errors=None) == b'something'
    assert to_bytes(b'something', 'ascii') == b'something'

    if sys.version_info[0] >= 3:
        # Python3 is using surrogateescape
        # Try surrogateescape handling
        assert to_bytes(u'\udce4foo') == b'\xed\xb3\xa4foo'
        assert to_bytes(u'\udce4foo', errors='surrogate_or_replace') == b'\xed\xb3\xa4foo'

        # Try a character that should traceback

# Generated at 2022-06-11 01:38:09.658499
# Unit test for function to_bytes
def test_to_bytes():
    if PY3:
        # This is a no-op under python3
        assert to_bytes('abcd') == b'abcd'
        assert to_bytes(b'abcd') == b'abcd'
        assert to_bytes(str(b'abcd')) == b'abcd'
        assert to_bytes(bytearray(b'abcd')) == b'abcd'
        assert to_bytes(1, nonstring='simplerepr') == b'1'
        assert to_bytes(1, nonstring='passthru') == 1
        assert to_bytes(1, nonstring='empty') == b''
        assert to_bytes('1', encoding='ascii', errors='surrogateescape') == b'1'

# Generated at 2022-06-11 01:38:18.738832
# Unit test for function to_bytes

# Generated at 2022-06-11 01:38:27.387382
# Unit test for function to_native
def test_to_native():

    # No value
    assert to_native(None) == ''

    # Boolean
    assert to_native(True) == 'True'
    assert to_native(False) == 'False'

    # Bytes
    assert to_native(b'foo') == 'foo'
    assert to_native(b'\xc3\xb6\xc3\xa4\xc3\xbc') == u'\xf6\xe4\xfc'

    # Integer
    assert to_native(42) == '42'

    # Long
    if PY2:
        assert to_native(long(42)) == '42'

    # Float
    assert to_native(42.0) == '42.0'

    # Unicode

# Generated at 2022-06-11 01:38:38.838836
# Unit test for function to_native
def test_to_native():
    """
    Test :func:`ansible.module_utils._text.to_native`
    """
    # Python 2.6, 2.7, 3.5
    assert to_native(b'ASDF', errors='surrogate_or_strict') == u'ASDF'
    assert to_native(u'ASDF', errors='surrogate_or_strict') == u'ASDF'
    assert to_native(b'ASDF', errors='surrogate_or_replace') == u'ASDF'
    assert to_native(u'ASDF', errors='surrogate_or_replace') == u'ASDF'
    assert to_native(b'ASDF', errors='surrogate_then_replace') == u'ASDF'

# Generated at 2022-06-11 01:38:48.046638
# Unit test for function jsonify
def test_jsonify():
    class Test(object):
        def __str__(self):
            return u'\u7f51\u7edc'

        def __repr__(self):
            return u'\u4e00'

    data = {'tuple': (u"\u4e00", "b"), 'str': u"\u4e00", "dict": {"str": u"\u4e00"}, 'unicode': u"\u4e00", u'\u4e00': u'\u4e00', 'datetime': datetime.datetime.now(), 'obj': Test()}
    jsonify(data)



# Generated at 2022-06-11 01:38:57.571126
# Unit test for function to_bytes
def test_to_bytes():
    obj = 'foo'
    assert to_bytes(obj) == b'foo'
    assert to_bytes(obj, nonstring='empty') == b''
    assert to_bytes(obj, nonstring='strict') == b'foo'
    obj = u'\u20a1'
    assert to_bytes(obj) == b'\xe2\x82\xa1'
    assert to_bytes(obj, errors='surrogate_or_replace') == b'?\xe2\x82\xa1'
    assert to_bytes(obj, errors='surrogate_or_strict') == b'\xe2\x82\xa1'
    assert to_bytes(obj, errors='replace') == b'?\xe2\x82\xa1'

# Generated at 2022-06-11 01:39:19.646162
# Unit test for function to_bytes
def test_to_bytes():
    # Check that to_bytes returns the same thing when passed a bytes object
    # (regression for bug when initializing the _ansible_module_mutex)
    b_value = to_bytes('hi')
    for nonstring in ('simplerepr', 'passthru', 'empty', 'strict'):
        assert to_bytes(b_value, nonstring=nonstring) is b_value
    # Check that to_bytes returns the same thing when passed a unicode object
    # (regression for bug when initializing the _ansible_module_mutex)
    u_value = to_bytes(u'hi', nonstring='passthru')
    for nonstring in ('simplerepr', 'passthru', 'empty', 'strict'):
        assert to_bytes(u_value, nonstring=nonstring) is u_value

# Generated at 2022-06-11 01:39:22.693263
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({u'unicode': u'strings'}) == '{"unicode": "strings"}'
    assert jsonify({'byte': 'strings'}) == '{"byte": "strings"}'



# Generated at 2022-06-11 01:39:33.759621
# Unit test for function to_bytes
def test_to_bytes():
    # pylint: disable=too-many-cases, too-many-statements, too-many-branches, too-many-lines
    '''to_bytes()'''
    if PY3:
        import builtins
        string_types = (builtins.str,)
    else:
        import __builtin__
        string_types = (__builtin__.unicode, __builtin__.str)

    assert isinstance(to_bytes('ascii'), binary_type)
    assert isinstance(to_bytes(b'bytes'), binary_type)
    assert isinstance(to_bytes(u'unicode'), binary_type)
    assert isinstance(to_bytes(b'bytes', nonstring='simplerepr'), binary_type)