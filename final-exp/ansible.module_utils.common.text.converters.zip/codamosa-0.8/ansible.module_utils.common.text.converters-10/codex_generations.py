

# Generated at 2022-06-11 01:30:05.849392
# Unit test for function to_bytes
def test_to_bytes():
    class TestObj(object):
        pass

    obj = TestObj()
    obj.__str__ = lambda s: 'no_surrogates'
    obj.__repr__ = lambda s: 'surrogates_\udcff'

    # Test binary strings
    assert to_bytes('a string') == b'a string'

    # Test text strings
    assert to_bytes(u'a unicode string') == b'a unicode string'
    assert to_bytes(u'a unicode string'.encode('utf-16'), encoding='utf-8') == b'a unicode ' \
                                                                              b'string'
    assert to_bytes(u'non-ascii-\u0233'.encode('utf-16'), encoding='utf-8') == b'non-ascii-' \
                                

# Generated at 2022-06-11 01:30:15.438878
# Unit test for function to_bytes
def test_to_bytes():
    b2 = to_bytes(b'foo', nonstring='passthru')
    assert isinstance(b2, binary_type)
    assert b2 == b'foo'

    b2 = to_bytes(b'foo')
    assert isinstance(b2, binary_type)
    assert b2 == b'foo'

    # Check that we use surrogateescape when surrogate_then_replace is passed
    if PY3 and HAS_SURROGATEESCAPE:
        b2 = to_bytes(text_type('\udc00'), errors='surrogate_then_replace')
        assert isinstance(b2, binary_type)
        assert b2 == b'\xdc\x00'

        # This should not raise an exception
        b2.decode('utf-8', 'surrogateescape')

    # Check

# Generated at 2022-06-11 01:30:25.743897
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('plain text', 'ascii') == b'plain text'
    assert to_bytes('\xe8\xa8\x80\xe6\x96\x87', 'utf-8') == b'\xe8\xa8\x80\xe6\x96\x87'
    assert to_bytes(u'\u6c49\u5b57') == b'\xe6\xb1\x89\xe5\xad\x97'
    assert to_bytes(b'\xe8\xa8\x80\xe6\x96\x87') == b'\xe8\xa8\x80\xe6\x96\x87'

# Generated at 2022-06-11 01:30:36.089454
# Unit test for function jsonify
def test_jsonify():
    if not PY3:
        class UTF8Test(unittest.TestCase):
            def setUp(self):
                self.data = {'list': [u'\u2222', u'\u3333'], 'dict': {'key1':u'\u1111', 'key2':u'\u4444'}, 'unicode': u'\u5555'}
                self.assertRaises(UnicodeEncodeError, json.dumps, self.data)

            def test_jsonify_utf8(self):
                json_data = jsonify(self.data)
                self.assertIsInstance(json_data, str)

# Generated at 2022-06-11 01:30:48.070802
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1)) == '{"a": 1}'
    assert jsonify(dict(a=text_type('value1'))) == '{"a": "value1"}'
    assert jsonify(dict(a=binary_type('value1'))) == '{"a": "value1"}'

    assert jsonify(dict(a=dict(b=2))) == '{"a": {"b": 2}}'
    assert jsonify(dict(a=dict(b=text_type('value2')))) == '{"a": {"b": "value2"}}'
    assert jsonify(dict(a=dict(b=binary_type('value2')))) == '{"a": {"b": "value2"}}'


# Generated at 2022-06-11 01:30:50.007751
# Unit test for function jsonify
def test_jsonify():
    result = jsonify('{"A":1}')
    assert result == '{"A": 1}', result


# Generated at 2022-06-11 01:30:54.567686
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes('blah') == b'blah'
    assert to_bytes(b'blah') == b'blah'
    assert to_bytes(u'blah') == b'blah'
    assert to_bytes('blah', 'latin-1') == b'blah'
    assert to_bytes(b'blah', 'latin-1') == b'blah'
    assert to_bytes(u'blah', 'latin-1') == b'blah'
    assert to_bytes(u'blah', 'ascii', 'replace') == b'blah'

# Generated at 2022-06-11 01:31:03.298596
# Unit test for function to_bytes
def test_to_bytes():
    try:
        codecs.register_error('surrogate_escape', codecs.surrogateescape_error)
        HAS_SURROGATEESCAPE = True
    except AttributeError:
        HAS_SURROGATEESCAPE = False


# Generated at 2022-06-11 01:31:14.988714
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({u"key": u"value"}) == '{"key": "value"}'
    # Strings in bytestrings are not valid in JSON.
    # Strings in JSON can only be unicode.
    assert jsonify({b"key": b"value"}) == '{"key": "value"}'
    assert jsonify({b"key": u"value"}) == '{"key": "value"}'
    # non UTF-8 encoding is not supported
    assert jsonify({b"key": b"\x80"}) == '{"key": "\\u0080"}'
    assert jsonify({b"key": b"\x7f"}) == '{"key": "\\u007f"}'
    # if the bytestring can be decoded as latin-1, it is

# Generated at 2022-06-11 01:31:25.738626
# Unit test for function to_bytes
def test_to_bytes():

    assert to_bytes('') == b''
    # Null bytes get stripped when we convert from text to bytes
    assert to_bytes('\x00') == b'\x00'
    # Bytes stay bytes
    assert to_bytes(b'\x00') == b'\x00'
    # Non-strings get transformed to bytes using their __str__ method
    assert to_bytes(0) == b'0'
    # If the __str__ method doesn't exist, we'll get an error
    class Foo(object):
        pass
    f = Foo()
    try:
        to_bytes(f)
    except TypeError:
        assert True
    else:
        assert False, 'expected TypeError'

    # Invalid utf-8 can't be coerced to utf-8

# Generated at 2022-06-11 01:31:44.370374
# Unit test for function to_bytes
def test_to_bytes():
    # These should all be byte strings
    assert isinstance(to_bytes('unicode'), binary_type)
    assert to_bytes('unicode') == binary_type('unicode')
    assert to_bytes(b'strings') == b'strings'
    assert to_bytes('foø'.encode('utf-8'), 'latin-1') == b'fo\xf8'
    assert to_bytes(b'fo\xc3\xb8'.decode('utf-8'), 'latin-1') == b'fo\xc3\xb8'

    # Non-strings
    assert to_bytes(756) == b'756'
    assert to_bytes(756, nonstring='passthru') == 756
    assert isinstance(to_bytes(756, nonstring='passthru'), int)
    assert to_bytes

# Generated at 2022-06-11 01:31:54.037248
# Unit test for function to_native
def test_to_native():
    # We don't have unicode strings in Python3
    if PY3:
        pass
    # Unicode strings result in themselves
    assert to_native(u'foo') == 'foo'
    # Byte strings are decoded
    assert to_native('foo'.encode('utf-8')) == 'foo'
    # Non-strings are repr()'d
    assert to_native(42) == '42'
    # Non-strings are repr()'d
    assert to_native(datetime.datetime.now()) == repr(datetime.datetime.now())
    # Non-strings are repr()'d
    assert to_native(Exception()) == repr(Exception())

    class Foo(unicode):
        pass


# Generated at 2022-06-11 01:32:05.216995
# Unit test for function to_native
def test_to_native():
    # Test simple byte string and text string
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'

    # Test a non-string
    assert to_native(42) == '42'

    # Test various error handlers
    assert to_native(b'foo\xff') == 'foo\ufffd'
    assert to_native(b'foo\xff', errors='surrogate_or_replace') == 'foo\ufffd'
    assert to_native(b'foo\xff', errors='surrogate_or_strict') == 'foo\ufffd'
    assert to_native(b'foo\xff', errors='surrogate_then_replace') == 'foo\ufffd'

    # Test surrogate handling

# Generated at 2022-06-11 01:32:12.062555
# Unit test for function jsonify
def test_jsonify():
    """
    jsonify: it converts unicode data to utf-8 data and then dumps them
    :return:
    """
    assert jsonify([1, 2, 3]) == b'[1, 2, 3]'
    assert jsonify({1: 2, 3: 4}) == b'{"1": 2, "3": 4}'
    assert jsonify('123') == b'"123"'
    # TODO: add test for unicode data



# Generated at 2022-06-11 01:32:17.857428
# Unit test for function jsonify
def test_jsonify():
    '''
    function: test_jsonify
    Unit test for function: jsonify
    '''
    test_jsonify_dict = {'one': 'test', 'two': 'test2'}
    test_jsonify_json = jsonify(test_jsonify_dict)
    if type(test_jsonify_json) == str:
        return True
    else:
        return False



# Generated at 2022-06-11 01:32:24.103767
# Unit test for function jsonify
def test_jsonify():
    my_dict = {
        'one': 1,
        'two': 2,
        'three': 'three',
        'four': u'four',
        'five': datetime.datetime.now(),
        'six': '\xc3\x28',
        'seven': [u'\xc3\x28', '\xc3\x28'],
        'eight': (u'\xc3\x28', '\xc3\x28'),
    }
    json_obj = jsonify(my_dict)

# Generated at 2022-06-11 01:32:35.603737
# Unit test for function to_native
def test_to_native():
    """
    Test for function to_native.
    """
    # Tests for function to_native
    from collections import OrderedDict

    if PY3:
        # The type of a bytestring returned by to_native should not change
        # in Python3
        assert isinstance(to_native(b'\xff'), bytes)

        # Like the above but without specifying a nonstring handler which
        # should default to 'simplerepr'
        assert isinstance(to_native(bytearray(b'\xff')), bytes)

        # These should be text
        assert isinstance(to_native(u'foo'), text_type)
        assert isinstance(to_native('foo'), text_type)

# Generated at 2022-06-11 01:32:47.363971
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils._text import to_native
    from .six import u

    if not PY3:
        # Python2
        # Make sure that the --encoding option to 2to3 does not change the
        # encoding of the following test values.  (The \u is an escape for a
        # unicode character)
        assert u('\u2019'.encode('utf-8')) == "\xe2\x80\x99"
        assert u('\u2019'.encode('latin1')) == "\xe2\x80\x99"

    assert to_bytes(u('text string')) == b'text string'

    # Test bytes conversion
    assert to_bytes(u('\u2019').encode('utf-8')) == b"\xe2\x80\x99"
    assert to

# Generated at 2022-06-11 01:32:55.002439
# Unit test for function jsonify
def test_jsonify():
    data = {
        "test": b'\xe5\x98\x8a\xe5\x98\x8d\xe5\x98\x8f\xe5\x98\x94'.decode('utf8'),
        "test2": b'\xe2\x82\xac'.decode('utf8'),
        "test3": b'\xe2\x82\xac'.decode('utf8'),
        "test4": b'\xe2\x82\xac\xe2\x82\xac'.decode('utf8')
    }
    ret = jsonify(data)

# Generated at 2022-06-11 01:32:59.743672
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u8fd9\u662f\u4e2a\u6d4b\u8bd5') == u'\"\\u8fd9\\u662f\\u4e2a\\u6d4b\\u8bd5\"'
    assert jsonify([u'\u8fd9\u662f\u4e2a\u6d4b\u8bd5',u'\u8fd9\u662f\u4e2a\u6d4b\u8bd5']) == u'[\"\\u8fd9\\u662f\\u4e2a\\u6d4b\\u8bd5\",\"\\u8fd9\\u662f\\u4e2a\\u6d4b\\u8bd5\"]'

# Generated at 2022-06-11 01:33:10.992569
# Unit test for function jsonify
def test_jsonify():
    data = dict(test='test')
    print(jsonify(data))


# Generated at 2022-06-11 01:33:15.330748
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(None) == 'null'
    assert jsonify("hello world") == '"hello world"'
    assert jsonify({"test": 1}) == '{"test": 1}'
    assert jsonify({"test": u"1"}) == '{"test": "1"}'
    assert jsonify({"test": u"\u0A19"}) == '{"test": "\u0a19"}'
    assert jsonify({'test': datetime.datetime(2012, 4, 30, 12, 48, 0)}) == '{"test": "2012-04-30T12:48:00"}'



# Generated at 2022-06-11 01:33:23.326575
# Unit test for function to_bytes
def test_to_bytes():
    print(to_bytes('testing'))
    print(to_bytes(u'testing über unicode'))
    print(to_bytes(u'testing \ud83d\ude00 unicode', errors='surrogate_or_strict'))
    print(to_bytes(u'testing \ud83d\ude00 unicode', errors='surrogate_or_replace'))
    print(to_bytes(u'testing \ud83d\ude00 unicode', errors='surrogate_then_replace'))
    print(to_bytes(u'testing \ud83d\ude00 unicode', encoding='latin-1', errors='surrogate_then_replace'))


# We have the same function on native_ and this module.  The one on
# native_ is used when we're on Python2 and the one here

# Generated at 2022-06-11 01:33:33.763104
# Unit test for function to_native
def test_to_native():
    # ensure that to_native() is sane
    from ansible.module_utils._text import to_native
    # this test should pass natively in both py2 and py3
    assert to_native(u'foo') == u'foo'
    assert type(to_native(u'foo')) == type(u'foo')
    assert to_native(b'foo') == u'foo'
    assert type(to_native(b'foo')) == type(u'foo')
    # in py2, when str == bytes
    assert to_native('foo') == u'foo'
    assert type(to_native('foo')) == type(u'foo')

# unit test for function to_text

# Generated at 2022-06-11 01:33:39.205852
# Unit test for function jsonify
def test_jsonify():
    a = Set([1, 2, 3, 4])
    b = datetime.datetime.now()
    test_data = {'a': a, 'b': b}
    test_result = json.loads(jsonify(test_data))
    assert (test_result["a"] == list(a)) and (test_result["b"] == b.isoformat())



# Generated at 2022-06-11 01:33:46.933679
# Unit test for function to_native
def test_to_native():
    assert to_native('foo', nonstring='simplerepr') == 'foo'
    assert to_native(u'foo', nonstring='simplerepr') == 'foo'
    assert to_native(b'foo', nonstring='simplerepr') == 'foo'
    assert to_native(u'føo', nonstring='simplerepr') == 'føo'

# Generated at 2022-06-11 01:33:58.375154
# Unit test for function to_bytes
def test_to_bytes():
    if PY3:
        return

    # This is a list of tuples of (input, expected output, nonstring)
    #   We want to test:
    #   1) That input->output works (with various nonstrings)
    #   2) That output->input works with various nonsrings
    #   3) That we get the expected exception if we don't accept an
    #      arbitrary object

# Generated at 2022-06-11 01:34:06.381106
# Unit test for function jsonify
def test_jsonify():
    if not PY3:
        return
    a = '/bin/foo'
    assert jsonify(a) == '"/bin/foo"'
    a = to_bytes(a, encoding='latin-1')
    assert jsonify(a) == '"/bin/foo"'
    a = to_unicode(a, encoding='latin-1')
    assert jsonify(a) == '"/bin/foo"'
    a = to_unicode(a, encoding='utf-8')
    assert jsonify(a) == '"/bin/foo"'



# Generated at 2022-06-11 01:34:14.472639
# Unit test for function to_native
def test_to_native():
    '''
    Test for AnsibleModuleUnitTestCase.assertRaisesRegexp
    '''
    assert to_native('yes', 'binary') == b'yes'
    #assert to_native(b'yes', 'binary') == b'yes'
    assert to_native('yes', 'string') == 'yes'
    assert to_native(u'yes', 'string') == u'yes'
    assert to_native(lambda: 'yes', 'string') == 'yes'
    assert to_native(set([u'yes', 'no']), 'string') == set([u'yes', 'no'])
    assert to_native(set([u'yes', 'no']), 'binary') == set([b'yes', b'no'])
    assert to_native(set([u'yes', 'no']), 'unicode')

# Generated at 2022-06-11 01:34:23.184359
# Unit test for function to_native
def test_to_native():
    assert to_native(u'hello') == u'hello'
    assert to_native(u'ƒòô') == u'ƒòô'
    assert to_native('ƒòô'.encode(u'utf-8')) == u'ƒòô'
    assert to_native('ƒòô'.encode(u'latin-1')) == u'ƒòô'
    assert to_native('ƒòô'.encode(u'latin-1'), errors='surrogate_then_replace') == u'?ò?'


# Generated at 2022-06-11 01:34:42.586279
# Unit test for function jsonify
def test_jsonify():
    for test_data, expected_results in {
                                        u'{"name": "foo"}' : u'{"name": "foo"}',
                                        u'{"name": "f\xf6\xf6"}' : u'{"name": "f\xf6\xf6"}',
                                        }.items():
        assert jsonify(json.loads(test_data)) == expected_results

# Generated at 2022-06-11 01:34:46.386281
# Unit test for function to_native
def test_to_native():
    assert to_native(1) == 1
    assert to_native(b'string') == 'string'
    assert to_native(u'unicode') == u'unicode'



# Generated at 2022-06-11 01:34:56.539408
# Unit test for function to_native
def test_to_native():
    #checking for string 
    assert to_native('abc') == 'abc'

    #checking for byte string
    assert to_native(b'abc') == 'abc'

    #checking for datetime
    assert to_native(datetime.datetime.now()) == datetime.datetime.now()

    #checking for dict
    assert to_native({'a': 1}) == {'a':1}

    #checking for a list
    assert to_native([1,2]) == [1,2]

    #checking for an integer
    assert to_native(1) == 1

    #checking for an float
    assert to_native(1.0) == 1.0

    #checking for set
    assert to_native(set([1,2,3])) == set([1,2,3])

    #checking for None type

# Generated at 2022-06-11 01:35:02.707045
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils import _text
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_bytes
    # Test json encode, ensure that only ascii chars are used (i.e. can be decoded back to utf8)
    x = _text.jsonify({u'foo': u'bar'})
    # This is what we expect, no need to test it
    # y = '{"foo": "bar"}'
    y = to_text(x)
    assert y == u'{"foo": "bar"}', "expected %s, got %s" % (u'{"foo": "bar"}', y)
    assert to_

# Generated at 2022-06-11 01:35:14.317735
# Unit test for function jsonify

# Generated at 2022-06-11 01:35:19.859264
# Unit test for function to_bytes
def test_to_bytes():
    """Various possibilities for to_bytes
    """

    # Strings
    assert to_bytes('') == b''
    assert to_bytes('a') == b'a'
    assert to_bytes('abc') == b'abc'

    # Python3 unicode strings
    assert to_bytes('\u00e9') == b'\xc3\xa9'
    assert to_bytes('\U00010203') == b'\xf0\x90\x88\x83'

    # Unicode strings with surrogates
    import sys
    if sys.hexversion < 0x03000000:
        assert to_bytes(u'\udc80') == b'\\udc80'
        assert to_bytes(u'\udcaa') == b'\\udcaa'

# Generated at 2022-06-11 01:35:31.645976
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    assert to_native("\U0001f604") == "\U0001f604"
    assert to_native("\U0001f604".encode("utf-8")) == "\U0001f604"
    assert to_native("\U0001f604".encode("utf-16")) == "\U0001f604"
    assert to_native("\U0001f604".encode("latin-1")) == "\U0001f604".encode("latin-1")
    assert to_native(u"\U0001F604") == u"\U0001F604"
    assert to_native(b"\xf0\x9f\x98\x84") == u"\U0001F604"

# Generated at 2022-06-11 01:35:41.011830
# Unit test for function to_bytes
def test_to_bytes():
    # Unit tests for function to_bytes
    assert to_bytes(True) == b'True'
    assert to_bytes(False) == b'False'
    assert to_bytes('abc') == b'abc'
    assert to_bytes('\xe9') == b'\xc3\xa9'
    assert to_bytes(u'\xe9') == b'\xc3\xa9'
    assert to_bytes(u'\u20ac') == b'\xe2\x82\xac'
    assert to_bytes(u'\u20ac', encoding='latin-1') == b'\xac'
    assert to_bytes(b'abc') == b'abc'
    assert to_bytes(b'\xc3\xa9') == b'\xc3\xa9'

# Generated at 2022-06-11 01:35:46.210568
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u00e1') == u'\u00e1'
    assert to_native(b'\xc3\xa1') == u'\u00e1'
    if PY3:
        assert to_native(b'\xe1') == u'\u00e1'
    else:
        assert to_native(b'\xe1') == u'\ufffd'



# Generated at 2022-06-11 01:35:56.826402
# Unit test for function jsonify
def test_jsonify():
    # All the values that jsonify returns should be strings
    assert isinstance(jsonify({}), text_type)
    assert isinstance(jsonify([]), text_type)
    assert isinstance(jsonify("foo"), text_type)
    assert isinstance(jsonify(u"\u2603"), text_type)
    assert isinstance(jsonify({"a": u"a", u"b": "b", "c": "\x80"}), text_type)
    assert isinstance(jsonify({"a": u"a", u"b": "b", "c": "\x80"}, sort_keys=True), text_type)

    # Identical to jsonify, except it's possible to specify the encoding.  Needed in situations
    # where simplejson does not support the encoding paramater.

# Generated at 2022-06-11 01:36:15.778877
# Unit test for function jsonify
def test_jsonify():
    # check_container_unicode_format
    assert jsonify(dict(a = 'alpha', b = dict(c = 'gamma', d = 'delta'))) == "{\"a\": \"alpha\", \"b\": {\"c\": \"gamma\", \"d\": \"delta\"}}"
    assert jsonify(dict(a = 'alpha', b = dict(c = 'gamma', d = 'delta')), indent = None, sort_keys = True) == "{\"a\": \"alpha\", \"b\": {\"c\": \"gamma\", \"d\": \"delta\"}}"

# Generated at 2022-06-11 01:36:25.824253
# Unit test for function to_bytes
def test_to_bytes():
    # Test surrogates
    assert b'\xff\xff\xff' == to_bytes(u'\uffff', errors='surrogate_or_replace')
    assert b'\xff\xff\xff' == to_bytes(u'\uffff', errors='surrogate_or_strict')
    assert b'\xff\xff\xff' == to_bytes(u'\uffff', errors='surrogate_then_replace')

    if HAS_SURROGATEESCAPE:
        assert b'\xff\xff\xff' == to_bytes(u'\uffff', errors='surrogateescape')

        # Test that py3 doesn't have surrogates
        assert b'\xff\xff\xff' == to_bytes(u'\uffff', errors=None)

        # Test that py3 error handlers work like normal

# Generated at 2022-06-11 01:36:34.796436
# Unit test for function jsonify
def test_jsonify():
    # Various data types to be jsonified
    # json.loads is to load a string and convert it to a Python object
    assert json.loads(jsonify(dict(a=1, b='b', c=['c1', 'c2', True], d={'d1': 1, 'd2': [1, 2, 3]}))) == json.loads('{"a": 1, "b": "b", "c": ["c1", "c2", true], "d": {"d2": [1, 2, 3], "d1": 1}}')
    assert json.loads(jsonify(datetime.datetime(2012, 11, 13, 13, 13))) == json.loads('"2012-11-13T13:13:00"')

# Generated at 2022-06-11 01:36:45.704789
# Unit test for function jsonify
def test_jsonify():
    result = jsonify('str')
    assert result == '"str"'
    result = jsonify(b'str')
    assert result == '"str"'
    result = jsonify(u'str')
    assert result == '"str"'
    result = jsonify({'a':'b'})
    assert result == '{"a": "b"}'
    result = jsonify({b'a':b'b'})
    assert result == '{"a": "b"}'
    result = jsonify({'a':b'b'})
    assert result == '{"a": "b"}'
    result = jsonify({b'a':'b'})
    assert result == '{"a": "b"}'
    result = jsonify({u'a':b'b'})
    assert result == '{"a": "b"}'


# Generated at 2022-06-11 01:36:56.902704
# Unit test for function to_bytes
def test_to_bytes():

    import sys
    # Using a small sample of characters to test
    test_samples = [
        u'', u'\u043f\u0440\u0435\u0436\u0434\u0430', u'\u043f\u0440\u0435\u0436\u0434\u0430'*10,
        u'\u043f\u0440\u0435\u0436\u0434\u0430'*1000
    ]

    # test_samples are encoded in UTF-8, latin-1 and Windows-1252

# Generated at 2022-06-11 01:37:03.231622
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can correctly decode a variety of encodings
    test_pairs = (
        (u'\u2713', 'utf-8'),
        (u'\u2713', 'latin-1'),
        (u'\u2713', 'ascii'),
        (u'\u2713', 'Windows-1252'),
        (u'\xc3\xa9', 'latin-1'),
        (u'\xc3\xa9', 'ascii'),
        (u'\xc3\xa9', 'Windows-1252'),
        # This contains a non-decodable character (the y with diaeresis)
        (u'\xe9\u0177\u2026', 'Windows-1252'),
    )


# Generated at 2022-06-11 01:37:15.482976
# Unit test for function to_bytes

# Generated at 2022-06-11 01:37:18.672562
# Unit test for function to_native
def test_to_native():
    # Verify that it doesn't throw an exception
    assert to_native({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"


_NATIVE_TYPES = frozenset((text_type, binary_type, int, float))



# Generated at 2022-06-11 01:37:29.408950
# Unit test for function jsonify
def test_jsonify():
    # Test that non-unicode data can be converted to unicode
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    # Test that data with unicode can be converted to unicode
    assert jsonify({"a": u"b"}) == '{"a": "b"}'
    # Test that non-unicode data raises an exception
    try:
        jsonify({"a": "b".encode("utf-16")})
    except Exception as e:
        assert True
    else:
        assert False
    # Test that data with unicode can be converted to unicode
    try:
        jsonify({"a": b"b"})
    except Exception as e:
        assert True
    else:
        assert False

# Generated at 2022-06-11 01:37:40.595186
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\xe3\x81\x82') == u'\xe3\x81\x82'
    assert to_native('\xe3\x81\x82') == u'\xe3\x81\x82'
    assert to_native(u'\xe3\x81\x82'.encode('utf-8')) == u'\xe3\x81\x82'
    assert to_native('\xe3\x81\x82'.decode('utf-8')) == u'\xe3\x81\x82'
    assert to_native('\xe3\x81\x82'.decode('iso-8859-1')) == u'\xe3\x81\x82'

# Generated at 2022-06-11 01:38:08.997657
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    u = u'\u4500'
    # Surrogates
    assert to_bytes(u'replace: \ud800') == b'replace: ?'
    assert to_bytes(u'replace: \ud800', errors='surrogate_then_replace') == b'replace: \ufffd?'
    assert to_bytes(u'replace: \ud800', errors='surrogate_or_replace') == b'replace: ?'
    assert to_bytes(u'replace: \ud800', errors='surrogate_or_strict') == b'replace: ?'
    # Not surrogates

# Generated at 2022-06-11 01:38:18.401532
# Unit test for function jsonify

# Generated at 2022-06-11 01:38:25.598964
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2019') == u'"\u2019"'
    assert jsonify(u'\u2019'.encode('latin-1')) == u'"\u2019".encode("latin-1")'
    assert jsonify(u'\u2019'.encode('utf-8')) == u'"\u2019"'
    assert jsonify(u'\u2019'.encode('ascii', errors='backslashreplace')) == 'u"\\\\u2019"'
    assert jsonify(u'\u2019'.encode('ascii', errors='ignore')) == 'u"\\"'



# Generated at 2022-06-11 01:38:37.032108
# Unit test for function jsonify
def test_jsonify():
    # since it is probably utf-8, should work
    assert jsonify({u"a": "b", u"?": "c"}) == '{"a": "b", "?": "c"}'
    # latin-1 is an 8 bit encoding, so the ? can be encoded using utf-8
    assert jsonify({u"a": "b", u"?": "c"}, encoding="latin-1") == '{"a": "b", "?": "c"}'
    # since it is probably utf-8, should work
    assert jsonify({u"a": u"b", u"?": u"c"}) == '{"a": "b", "?": "c"}'
    # latin-1 is an 8 bit encoding, so the ? can be encoded using utf-8

# Generated at 2022-06-11 01:38:42.667254
# Unit test for function to_native
def test_to_native():
    # Test str input
    expected = 'mystring'
    actual = to_native(expected)

    assert expected == actual, "str input does not convert properly"

    # Test unicode input
    expected = u'mystring'
    actual = to_native(expected)

    assert expected == actual, "unicode input does not convert properly"

    # Test non-string input
    expected = 123
    actual = to_native(expected)

    assert expected == actual, "non-string input does not convert properly"


# Generated at 2022-06-11 01:38:47.996370
# Unit test for function jsonify
def test_jsonify():
    """ Test function: jsonify

        This function does not need to be tested as it uses method
        from python built-in modules.

        Inventory: inventory_hosts
        Playbook: jsonify.yml
        Module: test_jsonify.py
    """
    print("test: function: %s" % __name__)


# Generated at 2022-06-11 01:38:57.571262
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils import basic
    if PY3:
        # This test doesn't apply to python3 at all
        return

    def do_test(value, expected, encoding, errors):
        result = basic._ANSIBLE_ARGS['module_setup'](basic._ANSIBLE_ARGS['module'])
        result = basic._ANSIBLE_ARGS['to_bytes'](value, encoding=encoding, errors=errors)
        assert result == expected

    # Non string tests
    do_test(1, '1', 'ascii', 'strict')
    do_test(1, '1', 'ascii', 'replace')
    do_test(True, 'True', 'ascii', 'strict')
    do_test(True, 'True', 'ascii', 'replace')
    do_test

# Generated at 2022-06-11 01:39:05.962771
# Unit test for function jsonify
def test_jsonify():
    test_obj = set(['foo', b'bar'])
    result = jsonify(test_obj)
    assert result == '["foo", "bar"]'
    test_dict = {'test_obj': test_obj}
    result = jsonify(test_dict)
    assert result == '{"test_obj": ["foo", "bar"]}'
    test_list = [b'foo', 1, test_dict]
    result = jsonify(test_list)
    assert result == '["foo", 1, {"test_obj": ["foo", "bar"]}]'

# Generated at 2022-06-11 01:39:17.853670
# Unit test for function to_native
def test_to_native():
    assert to_text(1) == '1'
    assert to_text(None) == 'None'
    assert to_bytes(1) == b'1'
    assert to_bytes(None) == b'None'

    assert to_text(b'\xc3\xa9', encoding='latin-1', errors='surrogate_or_replace') == u'\xe9'
    assert to_text(b'\xc3\xa9', encoding='latin-1', errors='surrogate_or_strict') == u'\xe9'
    assert to_text(b'\xc3\xa9', encoding='latin-1', errors='surrogate_then_replace') == u'\xe9'

    invalid_text = u'\ufffd\xe9'

# Generated at 2022-06-11 01:39:28.636674
# Unit test for function to_bytes