

# Generated at 2022-06-11 01:29:59.412620
# Unit test for function to_bytes
def test_to_bytes():
    import codecs
    from ansible.module_utils.six import u

    # u'\U0001f1e6\U0001f1e8' is the flag of France
    # u'\u2620' is the biohazard symbol

    def test_str_input(str_input, encoding, errors, expected_b_output, nonstring):
        if nonstring == 'passthru':
            expected_output = expected_b_output
        else:
            expected_output = to_bytes(expected_b_output)
        b_output = to_bytes(str_input, encoding, errors, nonstring)
        assert b_output == expected_output, '%s was decoded to %s instead of %s' % (str_input, b_output, expected_b_output)


# Generated at 2022-06-11 01:30:04.369262
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\xa9', errors='strict') == codecs.BOM_UTF8 + b'\xc2\xa9'
    assert to_native(u'\xa9') == codecs.BOM_UTF8 + b'\xc2\xa9'


# Generated at 2022-06-11 01:30:09.363294
# Unit test for function jsonify
def test_jsonify():
    data = {u'a': 1, 'b': 2, 'c': {'d': [4, 5]}}
    result = jsonify(data)
    assert isinstance(result, str)
    assert result == '{"a": 1, "b": 2, "c": {"d": [4, 5]}}'



# Generated at 2022-06-11 01:30:17.458442
# Unit test for function to_bytes
def test_to_bytes():
    x = b'foo'
    assert to_bytes(x) is x
    assert to_bytes(x, errors='surrogate_or_strict') is x
    assert to_bytes(x, errors='surrogate_or_replace') is x
    assert to_bytes(x, errors='surrogate_then_replace') is x
    assert to_bytes(x, errors='strict') is x
    assert to_bytes(x, errors='replace') is x
    assert to_bytes(x, errors='ignore') is x
    assert to_bytes(x, errors='surrogateescape') is x
    assert to_bytes(x, errors='backslashreplace') is x

    if PY3:
        x = 'foo'
        assert to_bytes(x) is x.encode('utf-8')
       

# Generated at 2022-06-11 01:30:22.995071
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    assert(to_native(u'some string') == u'some string')
    if not PY3:
        assert(to_native('some string') == u'some string')
    else:
        assert(to_native('some string') == 'some string')


# Generated at 2022-06-11 01:30:32.768437
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'ok') == u'u"ok"'
    assert jsonify(b'ok') == u'"ok"'
    assert jsonify(u'\xe9') == u'u"\xe9"'
    assert jsonify(b'\xe9') == u'"\\u00e9"'
    assert jsonify({'a':u'\xe9'}) == u"{u'a': u'\\xe9'}"
    assert jsonify({'a':b'\xe9'}) == u'{"a": "\\u00e9"}'
    assert jsonify({'a':{'b':u'\xe9'}}) == u"{u'a': {u'b': u'\\xe9'}}"
    assert jsonify({'a':{'b':b'\xe9'}}) == u

# Generated at 2022-06-11 01:30:40.191067
# Unit test for function to_bytes
def test_to_bytes():
    test_cases = [
        # Test 1: bytes
        (b'hello world!', {}, b'hello world!'),
        (b'hello world!', {'nonstring': 'strict'}, b'hello world!'),
        (b'hello world!', {'nonstring': 'passthru'}, b'hello world!'),
        (b'hello world!', {'nonstring': 'simplerepr'}, b"b'hello world!'"),
        (b'hello world!', {'nonstring': 'empty'}, b''),
        (b'hello world!', {'encoding': 'ascii'}, b'hello world!'),
    ]


# Generated at 2022-06-11 01:30:42.462403
# Unit test for function to_native
def test_to_native():
    # Just a quick test of the simple case
    assert to_native(to_text('test')) == 'test'



# Generated at 2022-06-11 01:30:54.328178
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.six import PY2
    if PY2:
        from ansible.module_utils._text import to_bytes
    else:
        from ansible.module_utils._text import to_text as to_bytes
    assert jsonify({'foo': 'bar'}, encoding="utf-8") == "{\"foo\": \"bar\"}"
    assert jsonify({u'foo': u'bar'}, encoding="utf-8") == "{\"foo\": \"bar\"}"
    assert jsonify(to_bytes({'foo': 'bar'}), encoding="utf-8") == "{\"foo\": \"bar\"}"
    assert jsonify({u'foo': u'bar', u'baz': u'FOO'}, encoding="utf-8") == "{\"baz\": \"FOO\", \"foo\": \"bar\"}"



# Generated at 2022-06-11 01:31:03.143230
# Unit test for function to_bytes
def test_to_bytes():
    # basic test of unicode
    encoded_string = to_bytes('\xe9\u20ac\U0001f43e')
    assert isinstance(encoded_string, binary_type)
    assert b'\xc3\xa9\xe2\x82\xac\xf0\x9f\x91\xbe' == encoded_string

    # test nonstring passthru
    encoded_string = to_bytes(100)
    assert 100 == encoded_string

    # test nonstring simplerepr
    encoded_string = to_bytes(100, nonstring='simplerepr')
    assert b'100' == encoded_string

    # test non string strict

# Generated at 2022-06-11 01:31:22.823467
# Unit test for function jsonify
def test_jsonify():
    assert '"bar"' == jsonify({'foo': 1, 'bar': 'abc'})
    assert '["abc", "def"]' == jsonify(['abc', 'def'])
    assert '"2016-03-01T13:01:22Z"' == jsonify(datetime.datetime(2016, 3, 1, 13, 1, 22))
    assert '["1", "2"]' == jsonify([1, 2])

    def _test_error(data):
        try:
            jsonify(data)
            assert False
        except UnicodeError:
            pass
    _test_error({'foo': b'abc'})
    _test_error([b'abc', b'def'])
    _test_error({'foo': 123, b'bar': 456})
    _test_error([123, 456])

# Generated at 2022-06-11 01:31:31.125063
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'abc') == b'abc'
    # python2.4 doesn't have b''
    assert to_bytes('abc') == b'abc'
    assert to_bytes(u'abc') == b'abc'
    assert to_bytes(u'\xc3\xbc', encoding='latin-1') == b'\xfc'
    try:
        to_bytes(u'\xc3\xbc', encoding='ascii')
    except UnicodeEncodeError:
        # Correct
        pass
    else:
        raise AssertionError('UnicodeEncodeError should have been raised for encoding to ASCII')

    # Non-string
    assert to_bytes(None, nonstring='simplerepr') == b'None'

# Generated at 2022-06-11 01:31:43.966643
# Unit test for function to_bytes
def test_to_bytes():
    '''
    # just for py2
    import sys
    if sys.version_info < (3,0):
        reload(sys)
        sys.setdefaultencoding('utf-8')
    '''
    assert to_bytes(u'') == b''
    assert to_bytes(b'') == b''
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes(u'\u2603') == b'\xe2\x98\x83'
    assert to_bytes(b'\xe2\x98\x83') == b'\xe2\x98\x83'
    assert to_bytes(u'\udce2\udc98\udc83') == b'\xe2\x98\x83'

# Generated at 2022-06-11 01:31:53.767737
# Unit test for function to_native
def test_to_native():
    assert to_native("test", 'utf-8') == "test"
    assert to_native("test", 'utf-8', nonstring='empty') == ""
    assert to_native("test", 'utf-8', nonstring='strict') == ""
    assert to_native("test", 'utf-8', nonstring='passthru') == "test"
    assert to_native("test") == "test"
    assert to_native("test", nonstring='empty') == ""
    assert to_native("test", nonstring='strict') == ""
    assert to_native("test", nonstring='passthru') == "test"
    assert to_native(b"test", 'utf-8') == "test"
    assert to_native(b"test", 'utf-8', errors='surrogateescape') == "test"


# Generated at 2022-06-11 01:32:05.144119
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2713') == '"\\u2713"'
    assert jsonify(u'\u2713', ensure_ascii=False) == '"\u2713"'
    assert jsonify(u'\xe2\x9c\x93') == '"\\u2713"'
    assert jsonify(u'\u2713\xe2\x9c\x93') == '"\\u2713\\u2713"'
    assert jsonify(u'\xe2\x9c\x93\u2713') == '"\\u2713\\u2713"'
    assert jsonify(u'\xe2\x9c\x93\u2713\xe2\x9c\x93') == '"\\u2713\\u2713\\u2713"'


_H

# Generated at 2022-06-11 01:32:10.607538
# Unit test for function to_native
def test_to_native():
    """
    test_to_native:
        test to_native function
    """
    from ansible_collections.ansible.community.tests.unit.module_utils.text.test_to_native import TestToNative

    test_to_native = TestToNative()
    test_to_native.test_to_native()


# Generated at 2022-06-11 01:32:20.720996
# Unit test for function to_bytes
def test_to_bytes():
    """Test the function to_bytes using a few instances of all the combinations that should work."""
    # Basic conversions
    b = to_bytes('\u2500', nonstring='simplerepr')
    assert isinstance(b, binary_type)
    assert b == b'\xe2\x94\x80'

    u = to_bytes('\u2500', encoding='ascii')
    assert isinstance(u, binary_type)
    assert u == b'?'

    u = to_bytes('\u2500', encoding='ascii', errors='replace')
    assert isinstance(u, binary_type)
    assert u == b'?'

    u = to_bytes('\u2500', encoding='ascii', errors='surrogateescape')
    assert isinstance(u, binary_type)
    assert u == b'?'

# Generated at 2022-06-11 01:32:22.928809
# Unit test for function to_native
def test_to_native():
    # TBD: python2 and python3 versions for all tests
    pass


# Generated at 2022-06-11 01:32:34.738460
# Unit test for function to_bytes
def test_to_bytes():
    def _to_bytes(expected, *args, **kwargs):
        result = to_bytes(*args, **kwargs)
        if PY3:
            expected = expected.encode('latin-1')
        assert expected == result, \
            '(%s)' % (repr(expected),)

    # NOTE: Coverage doesn't properly track branch coverage of if, elif, else
    # blocks.  We'll just have to manually look at the code to make sure that
    # both branches of each block have been tested.
    # codecs.lookup_error('surrogateescape') Traceback (most recent call last):
    #   File "<stdin>", line 1, in <module>
    # LookupError: unknown error handler name 'surrogateescape'

    # Non-strings

# Generated at 2022-06-11 01:32:41.446484
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2, c=3)) == '{"a": 1, "c": 3, "b": 2}'
    assert jsonify('test') == '"test"'
    assert jsonify(u'\u6c49\u5b57') == '"\\u6c49\\u5b57"'
    assert jsonify(u'\u6c49\u5b57', ensure_ascii=False) == '"\u6c49\u5b57"'
    assert jsonify(u'\u6c49\u5b57', ensure_ascii=False, encoding='latin-1') == '"\\u6c49\\u5b57"'

# Generated at 2022-06-11 01:32:54.630311
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(foo='bar', baz='quux')) == b'{"foo":"bar","baz":"quux"}'
    assert jsonify(dict(foo=['bar', 'baz'])) == b'{"foo":["bar","baz"]}'
    assert jsonify(dict(foo=[dict(bar='baz'), dict(quux='quuux')])) == b'{"foo":[{"bar":"baz"},{"quux":"quuux"}]}'
    assert jsonify(dict(foo=[Set(('bar', 'baz'))])) == b'{"foo":[["bar","baz"]]}'
    assert jsonify(dict(foo=Set(('bar', 'baz')))) == b'{"foo":["bar","baz"]}'

# Generated at 2022-06-11 01:33:07.468257
# Unit test for function to_bytes
def test_to_bytes():
    def check_string(value, encoding='utf-8', errors=None, nonstring='simplerepr'):
        if isinstance(value, text_type):
            out = value.encode(encoding, errors)
            assert value == out.decode(encoding, errors), 'String round-trip failed'
        else:
            assert value == to_bytes(value, encoding, errors, nonstring), 'Round trip failed'

    # Test text_type objects
    check_string(text_type(''))
    check_string(text_type('abc'))
    check_string(text_type('\xe2\x9c\x93'))
    check_string(text_type('\uD83D\uDE00'))

    # Test byte strings
    check_string(b'')

# Generated at 2022-06-11 01:33:08.295839
# Unit test for function to_native
def test_to_native(): assert 1



# Generated at 2022-06-11 01:33:12.095816
# Unit test for function to_bytes
def test_to_bytes():
    # Basic identity
    assert to_bytes(b'foo') == b'foo'
    # Object converted to string
    assert to_bytes(Set(['foo'])) == b"set(['foo'])"



# Generated at 2022-06-11 01:33:16.560528
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 'a', 'b': b'b'}) == u'{"a": "a", "b": "b"}'
    assert jsonify({'a': 'a', 'c': u'c'}) == u'{"a": "a", "c": "c"}'



# Generated at 2022-06-11 01:33:20.307949
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 1, 'b': 2} # Valid json
    a_dict = {'a': u'1', 'b': u'2'} # Invalid json
    assert jsonify(data) == str(data)
    assert jsonify(a_dict) == str(data)


# Generated at 2022-06-11 01:33:30.932093
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('123') == b'123'
    assert to_bytes(b'123') == b'123'
    assert to_bytes(u'123') == b'123'
    assert to_bytes(u'¢') == u'¢'.encode('utf-8')
    assert to_bytes(u'°') == u'°'.encode('utf-8', 'surrogateescape')
    assert to_bytes(u'°', errors='surrogate_or_replace') == u'°'.encode('utf-8', 'replace')
    assert to_bytes(u'°', errors='surrogate_or_strict') == u'°'.encode('utf-8', 'strict')


# Generated at 2022-06-11 01:33:42.056523
# Unit test for function to_native
def test_to_native():
    # Test with native strings
    assert to_native(b'\xe2\x89\x88') == '\xe2\x89\x88'
    assert to_native(u'\u2248') == u'\u2248'
    # Test with non-strings
    assert to_native(None) == 'None'
    assert to_native(True) == 'True'
    assert to_native(False) == 'False'
    assert to_native(5) == '5'
    assert to_native(5.0) == '5.0'
    assert to_native(5j) == '5j'
    assert to_native(set([1, 2, 3])) == set([1, 2, 3])

# Generated at 2022-06-11 01:33:52.742904
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils._text import to_bytes
    # Tests on nonstrings
    assert to_bytes(None, nonstring='simplerepr') == b'None'
    assert to_bytes(None, nonstring='passthru') is None
    assert to_bytes(None, nonstring='empty') == b''
    # We can't test 'strict' as we'd get an uncaught exception
    # Tests on text strings
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\xe1\x88\xb4'

# Generated at 2022-06-11 01:34:03.387386
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    import datetime
    assert to_bytes(1, nonstring='simplerepr') == b'1'
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='empty') == b''
    assert to_bytes(u'foobar') == b'foobar'
    assert to_bytes(u'\u2603') == b'\xe2\x98\x83'
    assert to_bytes(u'\u2603', errors='strict') == b'\xe2\x98\x83'
    assert to_bytes(u'\uDC80') == b'\xed\xb2\x80'

# Generated at 2022-06-11 01:34:33.250004
# Unit test for function to_bytes
def test_to_bytes():
    # Python2
    if PY3:
        return

    try:
        # We want to use the system defaults for encodings on Python2
        # so that we know what we're going to get
        codecs.lookup('surrogate_or_strict')
    except LookupError:
        # In Python2, to_bytes has a couple of workarounds that are only
        # available if we register a codec
        codecs.register(
            lambda name: codecs.lookup('utf-8') if name == 'surrogate_or_strict' else None
        )

# Generated at 2022-06-11 01:34:44.616952
# Unit test for function to_bytes
def test_to_bytes():
    # Try a bunch of common string types
    # unicode
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo', nonstring='strict') == b'foo'
    # unicode surrogate pair
    assert to_bytes(u'\udc01\udc01') == six.b('\xed\xb1\x81\xed\xb1\x81')
    assert to_bytes(u'\udc01\udc01', nonstring='strict') == six.b('\xed\xb1\x81\xed\xb1\x81')
    # unicode surrogate pair with unencodable character

# Generated at 2022-06-11 01:34:55.447002
# Unit test for function jsonify
def test_jsonify():
    import os
    import sys
    sys.path.append(os.path.dirname(__file__))
    import test_utils as tu
    import ansible.module_utils._text as aput
    tu.t = tu.t

    data = jsonify({'a': '\xa9', 'b': ['\xa9'], 'c': [], 'd': 'a'}, sort_keys=True)
    if not PY3:
        tu.t(data == '{"a": "\\u00a9", "b": ["\\u00a9"], "c": [], "d": "a"}')
    else:
        tu.t(data == '{"a": "\\u00a9", "b": ["\\u00a9"], "c": [], "d": "a"}')



# Generated at 2022-06-11 01:35:06.535564
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('a') == b'a'
    assert to_bytes(b'a') == b'a'
    assert to_bytes(1) == b'1'
    assert to_bytes(u'a') == b'a'
    assert to_bytes(u'\xc0') == b'\xc3\x80'
    # Note that this fails in python2's stdlib because python2
    # doesn't support surrogate escapes (added in python3)
    assert to_bytes(u'\U00010000') == b'\xf0\x90\x80\x80'

    # Test with encoding

# Generated at 2022-06-11 01:35:17.724272
# Unit test for function to_native
def test_to_native():
    assert to_native(u'Žluťoučký koníček') == u'Žluťoučký koníček'
    assert to_native(u'\u0105\u0219\u0107\u010d\u0119\u0142') == u'\u0105\u0219\u0107\u010d\u0119\u0142'
    assert to_native(b'This is a byte string') == u'This is a byte string'
    assert to_native(b'\xc3\xab') == u'ë'
    assert to_native(1) == u'1'
    assert to_native(True) == u'True'
    assert to_native(False) == u'False'

# Generated at 2022-06-11 01:35:20.507000
# Unit test for function to_native
def test_to_native():
    assert to_native(1) == '1'
    assert to_native(True) == 'True'
    assert to_native(u'Я') == u'Я'
    assert to_native(b'\xbf\xbf') == u'\uFFFD'


# Generated at 2022-06-11 01:35:25.043316
# Unit test for function to_native
def test_to_native():
    assert to_native(u'test') == u'test'
    assert to_native(b'bytes') == b'bytes'

    if PY3:
        assert to_native(b'bytes'.decode('utf-8')) == b'bytes'


# Generated at 2022-06-11 01:35:36.437654
# Unit test for function to_bytes
def test_to_bytes():
    # Test with no error
    assert to_bytes('hello') == b'hello'
    assert to_bytes(b'hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes('\xe2\x82\xac', encoding='latin-1') == b'\xe2\x82\xac'
    assert to_bytes(u'\u20ac', encoding='latin-1') == b'\xe2\x82\xac'
    assert to_bytes(u'\u20ac', encoding='latin-1', nonstring='passthru') == u'\u20ac'
    assert to_bytes(3, nonstring='simplerepr') == b'3'
    assert to_bytes(None, nonstring='passthru') is None



# Generated at 2022-06-11 01:35:39.593053
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'é': 'è'}) == '{"\xc3\xa9": "\\u00e8"}'
    assert jsonify({'é': '\xe8'}) == '{"\xc3\xa9": "\u00e8"}'



# Generated at 2022-06-11 01:35:40.755937
# Unit test for function to_bytes
def test_to_bytes():
    # Nothing throws error, everything is tested elsewhere
    pass



# Generated at 2022-06-11 01:36:18.960303
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('') == b''
    assert to_bytes('', errors='surrogate_or_strict') == b''
    assert to_bytes('', errors='surrogate_or_replace') == b''
    assert to_bytes('', errors='surrogate_then_replace') == b''
    assert to_bytes(b'testing') == b'testing'
    assert to_bytes(b'testing', errors='surrogate_or_strict') == b'testing'
    assert to_bytes(b'testing', errors='surrogate_or_replace') == b'testing'
    assert to_bytes(b'testing', errors='surrogate_then_replace') == b'testing'
    assert to_bytes('\xc3\xbf') == b'\xff'

# Generated at 2022-06-11 01:36:24.479633
# Unit test for function jsonify
def test_jsonify():
    #Test set value
    data = set([u'\u2713'])
    jdata = '["\u2713"]'
    assert jsonify(data) == jdata
    #Test unicode value
    data = {u'test':u'\u2713'}
    jdata = '{"test": "\u2713"}'
    assert jsonify(data) == jdata


# Generated at 2022-06-11 01:36:33.791038
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils.parsing.convert_bool import boolean
    from units.compat.mock import patch
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

# Generated at 2022-06-11 01:36:44.198436
# Unit test for function to_bytes
def test_to_bytes():
    to_bytes('abc')
    for char in (u'\ufffd', u'\uDC80', u'\uDCff'):
        to_bytes(char)
        to_bytes(char, errors='strict')
        to_bytes(char, errors='surrogateescape')
        to_bytes(char, errors='surrogate_or_strict')
        to_bytes(char, errors='surrogate_or_replace')
        to_bytes(char, errors='surrogate_then_replace')

    try:
        to_bytes(u'\uDC80', errors='replace')
    except UnicodeEncodeError:
        pass
    else:
        raise AssertionError('u"\uDC80".encode("utf-8", "replace") should have failed')



# Generated at 2022-06-11 01:36:55.815171
# Unit test for function jsonify
def test_jsonify():
    """
    test_jsonify: test ansible.module_utils.basic.jsonify

    This function test jsonify by using different type of data,
    including normal str, unicode, list and Set.
    """
    my_str = 'test jsonify'
    my_unicode = u'test jsonify'
    my_list = ['test', 'jsonify']
    my_set = Set(['test', 'jsonify'])
    my_dict = {'a': 1, 'b': 2}
    my_tuple = (1, 2, 3)

    # Test for normal str
    result = jsonify(my_str)
    assert result == '"test jsonify"'

    # Test for normal str with sort_keys
    result = jsonify(my_str, sort_keys=True)

# Generated at 2022-06-11 01:37:05.920741
# Unit test for function to_native
def test_to_native():
    assert to_native(u'this is a test') == 'this is a test'
    assert to_native(b'this is a test') == u'this is a test'
    assert to_native('สวัสดีชาวโลก') == u'สวัสดีชาวโลก'
    assert to_native('नमस्ते दुनिया') == u'नमस्ते दुनिया'
    assert to_native('مرحبا بالعالم') == u'مرحبا بالعالم'

# Generated at 2022-06-11 01:37:17.111137
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('123', nonstring='strict') == b'123'
    assert to_bytes(u'123') == b'123'
    assert to_bytes(u'\u20ac', errors='strict') == b'?'

    # test surrogate_then_escape (which is default)
    assert to_bytes(u'123€', errors='surrogate_then_replace') == b'123?'
    assert to_bytes(u'123€') == b'123?'
    # test surrogate_or_replace
    assert to_bytes(u'123€', errors='surrogate_or_replace') == b'123?'
    assert to_bytes(u'123€', errors='surrogate_or_replace', encoding='ascii') == b'123?'
    # test surrogate_or_strict
    assert to

# Generated at 2022-06-11 01:37:27.880506
# Unit test for function jsonify
def test_jsonify():
    def test_dict(data):
        # Try to transform dict keys/values
        new_data = {}
        for k,v in iteritems(data):
            kk = container_to_text(k) if isinstance(k, binary_type) else k
            vv = container_to_text(v) if isinstance(v, binary_type) else v
            new_data[kk] = vv
        return new_data
    # Simulate the global variable `from_remote_plugin`
    from_remote_plugin = False
    data = {'test_key':'test_value'}
    from_remote_plugin = True
    assert jsonify(data) == '{"test_key": "test_value"}'
    data = '{"test_key": "test_value"}'

# Generated at 2022-06-11 01:37:39.088125
# Unit test for function jsonify
def test_jsonify():
    data = dict(key1="value1", key2='value2', key3=("tuple", "tuple"),
                key4=("tuple", "tuple", 123), key5={1: "one", 2: "two", 3: ("three", "three")},
                key6=["list", "list"], key7=Set([1, 2, 3, 4, 5]),
                key8=datetime.datetime(1900, 1, 1, 12, 12, 12))
    #assert('{"key1": "value1", "key2": "value2", "key3": ["tuple", "tuple"], "key8": "1900-01-01T12:12:12", "key6": ["list", "list"], "key5": {"1": "one", "2": "two", "3": ["three", "three"]

# Generated at 2022-06-11 01:37:48.010172
# Unit test for function to_bytes
def test_to_bytes():
    assert isinstance(to_bytes(u"\u611b"), binary_type)
    assert isinstance(to_bytes(u"\u611b", encoding='utf-16'), binary_type)
    assert to_bytes(u"\u611b") == b"\xe6\x84\x9b"
    assert to_bytes(u"\u611b", encoding='utf-16') == b"\xff\xfe\ 11\xb8"
    assert to_bytes(u"\u611b", errors='strict') == b"\xe6\x84\x9b"
    assert to_bytes(u"\u611b", errors='ignore') == b""
    assert to_bytes(u"\u611b", errors='replace') == b'?\x84\x9b'

# Generated at 2022-06-11 01:38:17.443705
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xef\xbf\xbd'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'

# Generated at 2022-06-11 01:38:26.453132
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'ascii') is b'ascii'
    assert to_bytes(b'ascii', errors='strict') is b'ascii'
    assert to_bytes(b'ascii', errors='surrogate_or_strict') is b'ascii'
    assert to_bytes(b'ascii', errors='surrogate_or_replace') is b'ascii'
    assert to_bytes(b'ascii', errors='surrogate_then_replace') is b'ascii'
    assert to_bytes('søre'.encode('utf-8'), errors='surrogate_or_strict') == 'søre'.encode('utf-8')

# Generated at 2022-06-11 01:38:37.948302
# Unit test for function jsonify
def test_jsonify():
    raw = dict(
        a=7,
        b=['A', 'B', u'\xe9'],
        c='C',
        d=None,
        e=u'\xe9',
        s=set([1, 2, 3]),
        dt=datetime.datetime.utcnow()
    )

    expected = json.dumps(raw, default=_json_encode_fallback)
    assert jsonify(raw) == expected
    assert jsonify(to_bytes(raw)) == expected

    raw[u'\xe9'] = 'E'
    with pytest.raises(TypeError):
        jsonify(raw)

    raw2 = dict(
        (to_bytes(k, 'latin-1'), v)
        for k, v in iteritems(raw)
    )


# Generated at 2022-06-11 01:38:41.034345
# Unit test for function to_native
def test_to_native():
    assert to_native('{ "name" : "foo", "value": 17 }') == u'{ "name" : "foo", "value": 17 }'
    assert to_native(b'{"name": "foo"}') == u'{"name": "foo"}'


# Generated at 2022-06-11 01:38:52.115157
# Unit test for function to_bytes
def test_to_bytes():
    def check_encoding(input_data, encoding, errors, expected):
        actual = to_bytes(input_data, encoding=encoding, errors=errors)
        assert actual == expected

    # Test control chars
    for char in b'\x09\x0A\x0D':
        check_encoding(char, encoding='latin-1', errors='strict', expected=char)

    # Test normal values
    check_encoding('normal', encoding='latin-1', errors='strict', expected=b'normal')
    check_encoding('normal', encoding='latin-1', errors='surrogateescape', expected=b'normal')
    check_encoding('normal', encoding='latin-1', errors='surrogate_or_strict', expected=b'normal')

# Generated at 2022-06-11 01:39:02.855769
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == 'foo'
    assert isinstance(to_bytes('foo'), binary_type)
    assert to_bytes('foo', encoding='latin-1') == 'foo'
    assert isinstance(to_bytes('foo', encoding='latin-1'), binary_type)
    assert to_bytes(u'Örebro') == 'Örebro'
    assert isinstance(to_bytes(u'Örebro'), binary_type)
    assert to_bytes(u'Örebro', encoding='latin-1') == '\xd6rebro'
    assert isinstance(to_bytes(u'Örebro', encoding='latin-1'), binary_type)
    assert to_bytes(u'Örebro', errors='surrogate_then_replace') == 'Orebro'

# Generated at 2022-06-11 01:39:10.097514
# Unit test for function to_bytes
def test_to_bytes():
    nonstrings = (
        'simplerepr',
        'empty',
        'passthru',
        'strict',
    )

    # Check that we get a byte string back with the right error handler
    test_strings = (
        ('foo', None),
        ('foo', 'strict'),
        ('foo', 'replace'),
        ('foo', 'surrogateescape'),
        ('\u1234', None),
        ('\u1234', 'strict'),
        ('\u1234', 'replace'),
        ('\u1234', 'surrogateescape'),
    )

# Generated at 2022-06-11 01:39:21.055606
# Unit test for function to_bytes
def test_to_bytes():
    def _assertEqual(obj, encoding, errors, expected, nonstring='simplerepr'):
        result = to_bytes(obj, encoding, errors, nonstring)
        if result != expected:
            raise AssertionError('to_bytes(%r, %r, %r, %r) => %r != %r' % (obj, encoding, errors, nonstring, result, expected))

    # Test str vs. unicode
    # Test nonstring
    # Test surrogate_or_strict, surrogate_or_replace, surrogate_then_replace
    #   (This may involve mocking out surrogateescape)
    # Test with surrogate (if PY3)
    _assertEqual('foo', 'utf-8', None, b'foo')

# Generated at 2022-06-11 01:39:32.315561
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils._text import to_bytes, to_text

    assert to_bytes('test') == b'test'
    assert to_bytes(b'test') == b'test'
    assert to_bytes(b'test', nonstring='passthru') == b'test'
    assert to_bytes(1) == b'1'
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='empty') == b''

    # To test surrogate_then_replace we'll try encoding a string with surrogates and
    # then decode it with a surrogate handler
    latin1_string = to_bytes(u'n\xed\xf1')

# Generated at 2022-06-11 01:39:40.676851
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'asdf') == b'asdf'
    assert to_bytes(u'asdf') == b'asdf'
    if PY3:
        assert to_bytes(u'\udcc3') == u'\udcc3'.encode('utf-8', 'surrogateescape')
    else:
        assert to_bytes(u'\udcc3') == u'\udcc3'.encode('utf-8', 'replace')
    assert to_bytes(u'\udcc3', errors='replace') == u'\udcc3'.encode('utf-8', 'replace')
    assert to_bytes(u'\udcc3', errors='surrogate_then_replace') == \
        u'\udcc3'.encode('utf-8', 'surrogateescape').decode