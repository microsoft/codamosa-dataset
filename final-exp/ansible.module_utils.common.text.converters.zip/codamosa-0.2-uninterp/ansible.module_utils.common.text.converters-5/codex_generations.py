

# Generated at 2022-06-16 22:59:07.109976
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a utf-8 string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a latin-1 string
    assert to_bytes(u'\u00e9', encoding='latin-1') == b'\xe9'

    # Test that we can encode a utf-8 string with surrogates
    assert to_bytes(u'\ud800\udc00') == b'\xf0\x90\x80\x80'

    # Test that we can encode a latin-1 string with surrogates
    assert to_bytes(u'\ud800\udc00', encoding='latin-1', errors='surrogate_or_replace') == b'?'

    # Test that we can encode a utf

# Generated at 2022-06-16 22:59:15.202389
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": : "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': '), ensure_ascii=False) == '{\n    "a": : "b"\n}'

# Generated at 2022-06-16 22:59:22.529196
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u2713') == '\u2713'
    assert to_native(u'\u2713'.encode('utf-8')) == '\u2713'
    assert to_native(u'\u2713'.encode('utf-8'), errors='surrogate_or_strict') == '\u2713'
    assert to_native(u'\u2713'.encode('utf-8'), errors='surrogate_or_replace') == '\u2713'
    assert to_native(u'\u2713'.encode('utf-8'), errors='surrogate_then_replace') == '\u2713'
    assert to_

# Generated at 2022-06-16 22:59:30.933575
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', 'utf-8') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', 'utf-16') == b'\xff\xfe\x04\x03\x04\x50\x04\x30\x04\x38\x04\x32\x04\x35\x04\x42'

# Generated at 2022-06-16 22:59:39.531556
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 22:59:51.238087
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(u'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(u'\u2713', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict')

# Generated at 2022-06-16 23:00:02.561387
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'

    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data, sort_keys=True) == '{"a": "b", "c": "d"}'

    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data, sort_keys=True, indent=4) == '{\n    "a": "b", \n    "c": "d"\n}'

    data = {'a': 'b', 'c': 'd'}

# Generated at 2022-06-16 23:00:10.285784
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:00:21.546301
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": : "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': '), encoding="latin-1") == '{\n  "a": : "b"\n}'

# Generated at 2022-06-16 23:00:30.581343
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_replace') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_strict') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_then_replace') == b'foo'
    assert to_bytes(u'foo', errors='replace') == b'foo'
    assert to_bytes(u'foo', errors='surrogateescape') == b'foo'
    assert to_bytes(u'foo', errors='strict') == b'foo'
    assert to_bytes(u'foo', errors='ignore') == b'foo'

# Generated at 2022-06-16 23:00:45.856331
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'foo'.encode('utf-16')) == u'foo'
    assert to_native(u'foo'.encode('utf-32')) == u'foo'
    assert to_native(u'foo'.encode('latin-1')) == u'foo'
    assert to_native(u'foo'.encode('ascii')) == u'foo'
    assert to_native(u'foo'.encode('utf-8'), errors='surrogate_or_strict') == u'foo'

# Generated at 2022-06-16 23:00:57.032783
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(1) == u'1'
    assert to_native(1.1) == u'1.1'
    assert to_native(True) == u'True'
    assert to_native(None) == u'None'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82')

# Generated at 2022-06-16 23:01:09.383213
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a utf-8 string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a latin-1 string
    assert to_bytes(u'\u00e9', encoding='latin-1') == b'\xe9'

    # Test that we can encode a string with surrogates
    assert to_bytes(u'\ud800\udc00') == b'\xf0\x90\x80\x80'

    # Test that we can encode a string with surrogates and a non-utf8 encoding
    assert to_bytes(u'\ud800\udc00', encoding='latin-1') == b'?'

    # Test that we can encode a string with surrogates and a non-utf8 encoding
   

# Generated at 2022-06-16 23:01:18.075703
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode unicode strings
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode byte strings
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode non-strings

# Generated at 2022-06-16 23:01:25.840203
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes('foo', encoding='ascii') == b'foo'
    assert to_bytes('foo', encoding='utf-8') == b'foo'
    assert to_bytes('foo', encoding='utf-16') == b'\xff\xfe\x00f\x00o\x00o\x00'
    assert to_bytes('foo', encoding='utf-32') == b'\xff\xfe\x00\x00\x00f\x00\x00\x00o\x00\x00\x00o\x00\x00\x00'

    # Test that we can encode a text string with non-ascii characters

# Generated at 2022-06-16 23:01:36.639873
# Unit test for function to_bytes
def test_to_bytes():
    # Test that to_bytes returns a byte string
    assert isinstance(to_bytes('foo'), binary_type)

    # Test that to_bytes returns the same byte string if passed a byte string
    assert to_bytes(b'foo') == b'foo'

    # Test that to_bytes returns a byte string that matches the encoding
    assert to_bytes('foo', encoding='utf-16') == u'foo'.encode('utf-16')

    # Test that to_bytes returns a byte string that matches the encoding
    # even if the input is a byte string
    assert to_bytes(b'foo', encoding='utf-16') == u'foo'.encode('utf-16')

    # Test that to_bytes returns a byte string that matches the encoding
    # even if the input is a byte string

# Generated at 2022-06-16 23:01:48.480836
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == u'\u2713'

# Generated at 2022-06-16 23:01:58.127859
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a":: "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': '), encoding='latin-1') == '{\n  "a":: "b"\n}'

# Generated at 2022-06-16 23:02:05.054653
# Unit test for function to_bytes
def test_to_bytes():
    # Test that it returns a byte string
    assert isinstance(to_bytes(u'foo'), binary_type)
    assert isinstance(to_bytes(u'foo', nonstring='passthru'), text_type)
    assert isinstance(to_bytes(u'foo', nonstring='empty'), binary_type)
    assert isinstance(to_bytes(u'foo', nonstring='strict'), binary_type)

    # Test that it returns the right byte string
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo', encoding='latin-1') == b'foo'
    assert to_bytes(u'foo', encoding='latin-1', errors='replace') == b'foo'

# Generated at 2022-06-16 23:02:16.430153
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:02:34.551332
# Unit test for function to_native
def test_to_native():
    # Test that to_native returns a native string
    assert isinstance(to_native(u'foo'), str)
    assert isinstance(to_native(b'foo'), str)
    assert isinstance(to_native(u'foo'.encode('utf-8')), str)
    assert isinstance(to_native(u'foo'.encode('latin-1')), str)

    # Test that to_native returns a string that is the same as the input
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo'.encode('utf-8')) == 'foo'
    assert to_native(u'foo'.encode('latin-1')) == 'foo'

    # Test that to_native can handle non-

# Generated at 2022-06-16 23:02:43.431979
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b'}
    assert jsonify(data) == '{"a": "b"}'
    data = {'a': u'\u2713'}
    assert jsonify(data) == '{"a": "\\u2713"}'
    data = {'a': u'\u2713'.encode('latin-1')}
    assert jsonify(data) == '{"a": "\\u2713"}'
    data = {'a': u'\u2713'.encode('utf-16')}
    assert jsonify(data) == '{"a": "\\u2713"}'
    data = {'a': u'\u2713'.encode('utf-32')}
    assert jsonify(data) == '{"a": "\\u2713"}'

# Generated at 2022-06-16 23:02:55.833918
# Unit test for function jsonify
def test_jsonify():
    data = {
        'a': 'b',
        'c': 'd',
        'e': {
            'f': 'g',
            'h': 'i',
        },
        'j': [
            'k',
            'l',
            'm',
        ],
        'n': Set(['o', 'p', 'q']),
        'r': datetime.datetime(2017, 1, 1, 1, 1, 1, 1),
    }
    assert jsonify(data) == '{"a": "b", "c": "d", "e": {"f": "g", "h": "i"}, "j": ["k", "l", "m"], "n": ["o", "p", "q"], "r": "2017-01-01T01:01:01.000001"}'



# Generated at 2022-06-16 23:03:06.643855
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2, "c": 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert jsonify({"a": 1, "b": 2, "c": 3, "d": 4}) == '{"a": 1, "b": 2, "c": 3, "d": 4}'
    assert jsonify({"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}) == '{"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}'
    assert jsonify

# Generated at 2022-06-16 23:03:14.561463
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2713') == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('latin-1')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-32')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16-le')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16-be')) == '"\\u2713"'

# Generated at 2022-06-16 23:03:22.006124
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:03:34.566080
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1)) == '{"a": 1}'
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2, c=3)) == '{"a": 1, "b": 2, "c": 3}'
    assert jsonify(dict(a=1, b=2, c=3, d=4)) == '{"a": 1, "b": 2, "c": 3, "d": 4}'
    assert jsonify(dict(a=1, b=2, c=3, d=4, e=5)) == '{"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}'

# Generated at 2022-06-16 23:03:47.213949
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode unicode strings
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode byte strings
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode non-strings

# Generated at 2022-06-16 23:03:57.704664
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xef\xbf\xbd\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\udc80') == b'\xed\xb2\x80'

# Generated at 2022-06-16 23:04:09.285001
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=2) == '{\n  "a": 1, \n  "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": 1, "b": 2\n}'

# Generated at 2022-06-16 23:04:30.482697
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:04:42.897276
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(1.1) == '1.1'
    assert to_native(None) == 'None'
    assert to_native(True) == 'True'
    assert to_native(False) == 'False'
    assert to_native(set([1, 2, 3])) == 'set([1, 2, 3])'
    assert to_native(dict(a=1, b=2, c=3)) == "{'a': 1, 'c': 3, 'b': 2}"

# Generated at 2022-06-16 23:04:51.552614
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a text string with surrogates
    assert to

# Generated at 2022-06-16 23:04:58.361829
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2713') == u'"\u2713"'
    assert jsonify(u'\u2713'.encode('utf-8')) == u'"\u2713"'
    assert jsonify(u'\u2713'.encode('latin-1')) == u'"\u2713"'
    assert jsonify(u'\u2713'.encode('ascii')) == u'"\\u2713"'
    assert jsonify(u'\u2713'.encode('ascii'), ensure_ascii=False) == u'"\u2713"'
    assert jsonify(u'\u2713'.encode('ascii'), ensure_ascii=True) == u'"\\u2713"'

# Generated at 2022-06-16 23:05:09.823173
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 23:05:21.787190
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a non-string
    assert to_

# Generated at 2022-06-16 23:05:33.002851
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b",\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': '), encoding="latin-1") == '{\n    "a": "b",\n}'

# Generated at 2022-06-16 23:05:44.068354
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == 'foo'
    assert to_native(b'foo', errors='surrogate_then_replace') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_strict', nonstring='empty') == ''
    assert to_native(b'foo', errors='surrogate_or_replace', nonstring='empty') == ''
    assert to_native(b'foo', errors='surrogate_then_replace', nonstring='empty') == ''

# Generated at 2022-06-16 23:05:55.191982
# Unit test for function jsonify
def test_jsonify():
    data = {u'a': u'\u00e9'}
    assert jsonify(data) == '{"a": "\\u00e9"}'
    assert jsonify(data, ensure_ascii=False) == u'{"a": "\u00e9"}'
    assert jsonify(data, ensure_ascii=False, encoding='latin-1') == u'{"a": "\u00e9"}'
    assert jsonify(data, ensure_ascii=False, encoding='utf-8') == u'{"a": "\u00e9"}'
    assert jsonify(data, ensure_ascii=True, encoding='latin-1') == '{"a": "\\u00e9"}'

# Generated at 2022-06-16 23:06:02.559125
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'foo'.encode('utf-16')) == u'foo'
    assert to_native(u'foo'.encode('utf-32')) == u'foo'
    assert to_native(u'foo'.encode('latin-1')) == u'foo'
    assert to_native(u'foo'.encode('ascii')) == u'foo'
    assert to_native(u'foo'.encode('utf-8'), errors='surrogate_or_strict') == u'foo'
    assert to_native(u'foo'.encode('utf-16'), errors='surrogate_or_strict')

# Generated at 2022-06-16 23:06:22.228390
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'

    # Test that we can encode a byte string
    assert to_bytes(b'hello') == b'hello'

    # Test that we can encode a nonstring
    assert to_bytes(5) == b'5'

    # Test that we can encode a nonstring with a different nonstring strategy
    assert to_bytes(5, nonstring='passthru') == 5

    # Test that we can encode a nonstring with a different nonstring strategy
    assert to_bytes(5, nonstring='empty') == b''

    # Test that we can encode a nonstring with a different nonstring strategy

# Generated at 2022-06-16 23:06:31.471152
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_replace') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_strict') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_then_replace') == b'foo'
    assert to_bytes(u'foo', errors='replace') == b'foo'
    assert to_bytes(u'foo', errors='surrogateescape') == b'foo'
    assert to_bytes(u'foo', errors='strict') == b'foo'
    assert to_bytes(u'foo', errors='ignore') == b'foo'

# Generated at 2022-06-16 23:06:44.156282
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:06:54.156946
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2, c=3)) == '{"a": 1, "c": 3, "b": 2}'
    assert jsonify(dict(a=1, b=2, c=3), sort_keys=True) == '{"a": 1, "b": 2, "c": 3}'
    assert jsonify(dict(a=1, b=2, c=3), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'

# Generated at 2022-06-16 23:07:05.344090
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b",\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': '), encoding="utf-8") == '{\n    "a": "b",\n}'

# Generated at 2022-06-16 23:07:15.612411
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a non-string
    assert to_bytes

# Generated at 2022-06-16 23:07:23.360904
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:07:36.492371
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'fóo') == b'f\xc3\xb3o'
    assert to_bytes(u'fóo', encoding='latin-1') == b'f\xf3o'
    assert to_bytes(u'fóo', encoding='latin-1', errors='surrogate_or_strict') == b'f\xf3o'
    assert to_bytes(u'fóo', encoding='latin-1', errors='surrogate_or_replace') == b'f\xf3o'

# Generated at 2022-06-16 23:07:44.288456
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode unicode strings
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode byte strings
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode non-strings

# Generated at 2022-06-16 23:07:52.096661
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2713') == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('latin-1')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-32')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16-be')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16-le')) == '"\\u2713"'

# Generated at 2022-06-16 23:08:17.862549
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": : "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': '), encoding='latin-1') == '{\n  "a": : "b"\n}'

# Generated at 2022-06-16 23:08:27.771779
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string to a byte string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\x34\x12'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='replace') == b'?\x12'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='ignore') == b'\x12'

    # Test that we can encode a byte string to a byte string
    assert to_bytes(b'foo') == b'foo'
   

# Generated at 2022-06-16 23:08:38.552272
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2713') == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-8')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('latin-1')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('ascii')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('ascii', 'surrogateescape')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('ascii', 'ignore')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('ascii', 'replace'))

# Generated at 2022-06-16 23:08:50.906633
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == 'foo'
    assert to_native(u'foo', errors='surrogate_or_strict') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == 'foo'
    assert to_native(u'foo', errors='surrogate_or_replace') == 'foo'
    assert to_native(b'foo', errors='surrogate_then_replace') == 'foo'
    assert to_native(u'foo', errors='surrogate_then_replace') == 'foo'