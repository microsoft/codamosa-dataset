

# Generated at 2022-06-16 22:59:14.263354
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='replace') == b'?'

# Generated at 2022-06-16 22:59:18.722052
# Unit test for function jsonify
def test_jsonify():
    data = {u'foo': u'bar', u'baz': [1, 2, 3], u'blong': True, u'nest': {u'a': 1, u'b': 2}}
    assert jsonify(data) == '{"foo": "bar", "baz": [1, 2, 3], "blong": true, "nest": {"a": 1, "b": 2}}'



# Generated at 2022-06-16 22:59:30.585894
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 22:59:39.307479
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can pass in a byte string and get back a byte string
    assert isinstance(to_bytes('foo'), binary_type)
    assert to_bytes('foo') == b'foo'

    # Test that we can pass in a text string and get back a byte string
    assert isinstance(to_bytes(u'foo'), binary_type)
    assert to_bytes(u'foo') == b'foo'

    # Test that we can pass in a nonstring and get back a byte string
    assert isinstance(to_bytes(1), binary_type)
    assert to_bytes(1) == b'1'

    # Test that we can pass in a nonstring and get back a byte string
    assert isinstance(to_bytes(1), binary_type)
    assert to_bytes(1) == b'1'

    # Test

# Generated at 2022-06-16 22:59:51.135251
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:00:02.476048
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:00:14.940231
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:00:25.793474
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', 'utf-8') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a text string with surrogates
    assert to_bytes(u'\ud83d\ude00', 'utf-8') == b'\xf0\x9f\x98\x80'

    # Test that we can encode a text string with surrogates and a non-utf8 encoding
    assert to_bytes(u'\ud83d\ude00', 'latin-1') == b'?'

    # Test that we can encode a

# Generated at 2022-06-16 23:00:37.265694
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2713') == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-8')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('latin-1')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('ascii')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-32')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16-be')) == '"\\u2713"'
   

# Generated at 2022-06-16 23:00:46.322745
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 23:01:01.621504
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', 'utf-8') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', 'utf-8', 'surrogate_or_replace') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

# Generated at 2022-06-16 23:01:12.945906
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, sort_keys=True) == '{"a": 1}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4, separators=(',', ': '), encoding='latin-1') == '{\n    "a": 1\n}'

# Generated at 2022-06-16 23:01:22.234788
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'привет') == u'привет'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'\xc3\xa9') == u'é'
    assert to_native(b'\xe2\x82\xac') == u'€'
    assert to_native(b'\xe2\x82\xac', errors='surrogate_or_strict') == u'€'
    assert to_native(b'\xe2\x82\xac', errors='surrogate_or_replace') == u'€'

# Generated at 2022-06-16 23:01:34.191551
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-16')) == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-16-le')) == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-16-be')) == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-32')) == u

# Generated at 2022-06-16 23:01:45.127208
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1, "b": 2\n}'

# Generated at 2022-06-16 23:01:55.847165
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:02:03.652482
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    # Test that we can encode a byte string
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'
    # Test that we can encode a nonstring
    assert to_bytes(1234) == b'1234'

    # Test that we can decode a text string
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\xe4\x8c\xb4'
    # Test that we can decode a byte string

# Generated at 2022-06-16 23:02:15.629777
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(1) == u'1'
    assert to_native(1.1) == u'1.1'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:02:23.001760
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:02:35.827278
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_then_replace')

# Generated at 2022-06-16 23:02:54.448855
# Unit test for function to_bytes
def test_to_bytes():
    """
    Test to_bytes function
    """
    assert to_bytes('foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'
   

# Generated at 2022-06-16 23:03:05.802611
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442'.encode('utf-8')) == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native('foo') == u'foo'
    assert to_native('\xc3\xb1') == u'\xf1'

# Generated at 2022-06-16 23:03:17.194763
# Unit test for function to_native
def test_to_native():
    # Test with byte strings
    assert to_native(b'foo') == 'foo'
    assert to_native(b'\xc3\xbc') == u'\xfc'
    assert to_native(b'\xc3\xbc', errors='surrogate_or_strict') == u'\xfc'
    assert to_native(b'\xc3\xbc', errors='surrogate_or_replace') == u'\xfc'
    assert to_native(b'\xc3\xbc', errors='surrogate_then_replace') == u'\xfc'
    assert to_native(b'\xc3\xbc', errors='strict') == u'\xfc'
    assert to_native(b'\xc3\xbc', errors='replace') == u'?'

# Generated at 2022-06-16 23:03:27.844419
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='ignore') == b''
    assert to_bytes(u'\u1234', errors='replace') == b'?'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:03:38.528042
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_then_replace') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_replace') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_strict') == b'foo'
    assert to_bytes(u'foo', errors='surrogateescape') == b'foo'
    assert to_bytes(u'foo', errors='replace') == b'foo'
    assert to_bytes(u'foo', errors='strict') == b'foo'
    assert to_bytes(u'foo', errors='ignore') == b'foo'

# Generated at 2022-06-16 23:03:50.522024
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == u'foo'
    assert to_native(u'foo') == u'foo'
    assert to_native(1) == u'1'
    assert to_native(None) == u'None'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to

# Generated at 2022-06-16 23:03:59.865522
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd', 'e': Set([1, 2, 3])}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": [1, 2, 3]}'
    data = {'a': 'b', 'c': 'd', 'e': datetime.datetime(2016, 1, 1, 1, 1, 1)}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": "2016-01-01T01:01:01"}'

# Generated at 2022-06-16 23:04:11.625703
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == u'foo'
    assert to_native(u'foo') == u'foo'
    assert to_native(1) == u'1'
    assert to_native(1.1) == u'1.1'
    assert to_native(True) == u'True'
    assert to_native(None) == u'None'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82')

# Generated at 2022-06-16 23:04:22.926093
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2713') == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('latin-1')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-32')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16-be')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16-le')) == '"\\u2713"'

# Generated at 2022-06-16 23:04:31.959163
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:04:52.774058
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 23:05:05.406753
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'\xe2\x98\x83') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_or_strict') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_or_replace') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_then_replace') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='replace') == u'?'
   

# Generated at 2022-06-16 23:05:12.112066
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == u'\u2713'

# Generated at 2022-06-16 23:05:24.207445
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a string
    assert to_bytes('foo') == b'foo'

    # Test that we can encode a unicode string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'foo') == b'foo'

    # Test that we can encode a unicode string with surrogates
    assert to_bytes(u'\udc80') == b'\xed\xb2\x80'

    # Test that we can encode a unicode string with surrogates and a non-utf8 encoding
    assert to_bytes(u'\udc80', encoding='latin-1') == b'\x80'

    # Test that we can encode a unicode string with surrogates and a non

# Generated at 2022-06-16 23:05:34.894906
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    assert to_native(u'\u1234') == u'\u1234'
    assert to_native(u'\u1234'.encode('utf-8')) == u'\u1234'
    assert to_native(u'\u1234'.encode('utf-16')) == u'\u1234'
    assert to_native(u'\u1234'.encode('utf-32')) == u'\u1234'
    assert to_native(u'\u1234'.encode('latin-1')) == u'\u1234'
    assert to_native(u'\u1234'.encode('ascii')) == u'\u1234'

# Generated at 2022-06-16 23:05:46.602092
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=2) == '{\n  "a": 1, \n  "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": 1, "b": 2\n}'

# Generated at 2022-06-16 23:05:57.345002
# Unit test for function jsonify

# Generated at 2022-06-16 23:06:09.353197
# Unit test for function jsonify

# Generated at 2022-06-16 23:06:22.659415
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd', 'e': u'\u2713'}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": "\\u2713"}'
    data = {'a': 'b', 'c': 'd', 'e': u'\u2713'}
    assert jsonify(data, ensure_ascii=False) == '{"a": "b", "c": "d", "e": "✓"}'
    data = {'a': 'b', 'c': 'd', 'e': u'\u2713'}
    assert jsonify

# Generated at 2022-06-16 23:06:31.821153
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b'}
    assert jsonify(data) == '{"a": "b"}'

    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'

    data = {'a': 'b', 'c': {'d': 'e'}}
    assert jsonify(data) == '{"a": "b", "c": {"d": "e"}}'

    data = {'a': 'b', 'c': ['d', 'e']}
    assert jsonify(data) == '{"a": "b", "c": ["d", "e"]}'

    data = {'a': 'b', 'c': ['d', {'e': 'f'}]}

# Generated at 2022-06-16 23:07:05.878316
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'foo'.encode('utf-16')) == u'foo'
    assert to_native(u'foo'.encode('utf-32')) == u'foo'
    assert to_native(u'foo'.encode('latin-1')) == u'foo'
    assert to_native(u'føø'.encode('latin-1')) == u'føø'
    assert to_native(u'føø'.encode('utf-8')) == u'føø'
    assert to_native(u'føø'.encode('utf-16')) == u'føø'
   

# Generated at 2022-06-16 23:07:16.092433
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a non-string
    assert to_bytes

# Generated at 2022-06-16 23:07:23.698022
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a":: "b"\n}'

# Generated at 2022-06-16 23:07:36.798797
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8')) == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8'), nonstring='passthru') == u'\u2713'.encode('utf-8')
    assert to_native(u'\u2713'.encode('utf-8'), nonstring='strict') == u'\u2713'

# Generated at 2022-06-16 23:07:44.498241
# Unit test for function to_native
def test_to_native():
    # Test with unicode
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(u'\u2713', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(u'\u2713', errors='surrogate_or_replace') == u'\u2713'
    assert to_native(u'\u2713', errors='surrogate_then_replace') == u'\u2713'
    assert to_native(u'\u2713', errors='ignore') == u''
    assert to_native(u'\u2713', errors='replace') == u'?'
    assert to_native(u'\u2713', errors='xmlcharrefreplace') == u'&#10003;'


# Generated at 2022-06-16 23:07:52.203687
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd', 'e': Set([1, 2, 3])}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": [1, 2, 3]}'
    data = {'a': 'b', 'c': 'd', 'e': datetime.datetime(2015, 1, 1)}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": "2015-01-01T00:00:00"}'

# Generated at 2022-06-16 23:08:04.297239
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:08:17.322854
# Unit test for function to_bytes
def test_to_bytes():
    # Test the default error handler
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\udc80') == b'\xed\xb2\x80'
    assert to_bytes(u'\udc80', errors='surrogate_then_replace') == b'?'
    assert to_bytes(u'\udc80', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\udc80', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\udc80', errors='surrogateescape') == b'\xed\xb2\x80'

    # Test the surrogate_then_replace error handler

# Generated at 2022-06-16 23:08:23.112960
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a utf-8 string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a latin-1 string
    assert to_bytes(u'\u00e9', encoding='latin-1') == b'\xe9'

    # Test that we can encode a utf-8 string with surrogates
    assert to_bytes(u'\ud800\udc00') == b'\xf0\x90\x80\x80'

    # Test that we can encode a latin-1 string with surrogates
    assert to_bytes(u'\ud800\udc00', encoding='latin-1') == b'\xed\xa0\x80\xed\xb0\x80'

    #

# Generated at 2022-06-16 23:08:30.783553
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify({'a': 'b'}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({'a': 'b'}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({'a': 'b'}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b"\n}'
    assert jsonify({'a': 'b'}, sort_keys=True, indent=4, separators=(',', ': '), encoding='latin-1') == '{\n    "a": "b"\n}'