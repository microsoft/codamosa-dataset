

# Generated at 2022-06-16 22:59:11.541416
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a string
    assert to_bytes('foo') == b'foo'

    # Test that we can encode a unicode string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'foo') == b'foo'

    # Test that we can encode a nonstring
    assert to_bytes(1) == b'1'

    # Test that we can encode a nonstring with a custom nonstring strategy
    assert to_bytes(1, nonstring='passthru') == 1

    # Test that we can encode a nonstring with a custom nonstring strategy
    assert to_bytes(1, nonstring='empty') == b''

    # Test that we can encode a nonstring with a custom nonstring

# Generated at 2022-06-16 22:59:20.406354
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(1.1) == '1.1'
    assert to_native(None) == 'None'
    assert to_native(True) == 'True'
    assert to_native(False) == 'False'
    assert to_native(set([1, 2, 3])) == 'set([1, 2, 3])'
    assert to_native(dict(a=1, b=2)) == "{'a': 1, 'b': 2}"
    assert to_native(datetime.datetime(2012, 12, 12, 12, 12, 12)) == '2012-12-12 12:12:12'

# Generated at 2022-06-16 22:59:32.066105
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, sort_keys=True, indent=4) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1, "b": 2\n}'

# Generated at 2022-06-16 22:59:40.219879
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'

    # Test that we can encode a string with non-ascii characters
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\x34\x12'

    # Test that we can encode a string with non-ascii characters and a non-utf8 encoding
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\x34\x12'

    # Test that we can encode a string with non-as

# Generated at 2022-06-16 22:59:51.598861
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes('hello', encoding='ascii') == b'hello'
    assert to_bytes(u'hello', encoding='ascii') == b'hello'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'?'

# Generated at 2022-06-16 23:00:02.842449
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a":: "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': '), encoding='latin-1') == '{\n  "a":: "b"\n}'

# Generated at 2022-06-16 23:00:14.987251
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_text

# Generated at 2022-06-16 23:00:20.037304
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('hello') == b'hello'
    assert to_bytes(b'hello') == b'hello'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_then_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_then_replace') == b'?'
    assert to_bytes

# Generated at 2022-06-16 23:00:30.426441
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": u"b"}) == '{"a": "b"}'
    assert jsonify({"a": u"b\u1234"}) == '{"a": "b\u1234"}'
    assert jsonify({"a": u"b\u1234".encode("utf-16")}) == '{"a": "b\\ud4d0"}'
    assert jsonify({"a": u"b\u1234".encode("latin-1")}) == '{"a": "b\\ud4d0"}'

# Generated at 2022-06-16 23:00:41.994059
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:00:59.898666
# Unit test for function to_native
def test_to_native():
    # Test that we can encode and decode all valid unicode characters
    # This is a bit of a brute force test but it's simple and it works
    for i in range(0x110000):
        char = to_text(chr(i), nonstring='strict')
        encoded = to_bytes(char)
        decoded = to_text(encoded)
        assert char == decoded

    # Test that we can encode and decode all valid unicode characters
    # This is a bit of a brute force test but it's simple and it works
    for i in range(0x110000):
        char = to_text(chr(i), nonstring='strict')
        encoded = to_bytes(char)
        decoded = to_text(encoded)
        assert char == decoded

    # Test that we can encode and decode all valid

# Generated at 2022-06-16 23:01:11.909563
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:01:20.219504
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b",\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': '), encoding="latin-1") == '{\n    "a": "b",\n}'

# Generated at 2022-06-16 23:01:27.197822
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2713') == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-8')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('latin-1')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('ascii')) == '"\\u2713"'



# Generated at 2022-06-16 23:01:37.405669
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes('foo', encoding='ascii') == b'foo'
    assert to_bytes('foo', encoding='latin-1') == b'foo'
    assert to_bytes('foo', encoding='utf-8') == b'foo'
    assert to_bytes('foo', encoding='utf-16') == b'\xff\xfe\x00f\x00o\x00o\x00'
    assert to_bytes('foo', encoding='utf-32') == b'\xff\xfe\x00\x00\x00f\x00\x00\x00o\x00\x00\x00o\x00\x00\x00'

    # Test that we can encode a byte string


# Generated at 2022-06-16 23:01:49.419047
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, sort_keys=True) == '{"a": 1}'
    assert jsonify({"a": 1}, indent=2) == '{\n  "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True, indent=2) == '{\n  "a": 1\n}'
    assert jsonify({"a": 1}, separators=(',', ':')) == '{"a":1}'
    assert jsonify({"a": 1}, sort_keys=True, separators=(',', ':')) == '{"a":1}'

# Generated at 2022-06-16 23:01:58.194590
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 23:02:05.116996
# Unit test for function jsonify
def test_jsonify():
    # Test for jsonify
    assert jsonify({'a': 1}) == '{"a": 1}'
    assert jsonify({'a': 1, 'b': 2}) == '{"a": 1, "b": 2}'
    assert jsonify({'a': 1, 'b': 2, 'c': 3}) == '{"a": 1, "b": 2, "c": 3}'
    assert jsonify({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == '{"a": 1, "b": 2, "c": 3, "d": 4}'

# Generated at 2022-06-16 23:02:11.193059
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:02:20.331253
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(1) == u'1'
    assert to_native(1, nonstring='passthru') == 1
    assert to_native(1, nonstring='empty') == u''
    assert to_native(1, nonstring='strict') == u'1'
    assert to_native(1, nonstring='simplerepr') == u'1'
    assert to_native(None) == u'None'
    assert to_native(None, nonstring='passthru') == None
    assert to_native(None, nonstring='empty') == u''
    assert to_native(None, nonstring='strict') == u'None'

# Generated at 2022-06-16 23:02:50.026302
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'foo') == b'foo'

    # Test that we can encode a non-string
    assert to_bytes(1) == b'1'
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='empty') == b''
    assert to_bytes(1, nonstring='strict') == b'1'

    # Test that we can encode a non-string that doesn't have a str

# Generated at 2022-06-16 23:03:02.181641
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 23:03:10.676104
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u2713') == '\u2713'
    assert to_native(b'\xe2\x9c\x93') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == '\u2713'

# Generated at 2022-06-16 23:03:19.550869
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b'}
    assert jsonify(data) == '{"a": "b"}'
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd', 'e': 'f'}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": "f"}'
    data = {'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h'}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": "f", "g": "h"}'

# Generated at 2022-06-16 23:03:31.863806
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes('foo', encoding='utf-16') == b'\xff\xfe\x00f\x00o\x00o\x00'
    assert to_bytes('foo', encoding='utf-16', errors='surrogate_or_replace') == b'\xff\xfe\x00f\x00o\x00o\x00'
    assert to_bytes('foo', encoding='utf-16', errors='surrogate_or_strict') == b'\xff\xfe\x00f\x00o\x00o\x00'

# Generated at 2022-06-16 23:03:40.228764
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=None) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent="\t") == '{\n\t"a": 1,\n\t"b": 2\n}'

# Generated at 2022-06-16 23:03:46.008541
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 1, 'b': [1, 2, 3], 'c': {'d': 'e'}}
    assert jsonify(data) == '{"a": 1, "c": {"d": "e"}, "b": [1, 2, 3]}'
    assert jsonify(data, sort_keys=True) == '{"a": 1, "b": [1, 2, 3], "c": {"d": "e"}}'
    assert jsonify(data, indent=4) == '{\n    "a": 1,\n    "c": {\n        "d": "e"\n    },\n    "b": [\n        1,\n        2,\n        3\n    ]\n}'

# Generated at 2022-06-16 23:03:56.668096
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a text string with surrogates
    assert to

# Generated at 2022-06-16 23:04:07.402694
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2713') == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-8')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('latin-1')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('ascii')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-32')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16-be')) == '"\\u2713"'
   

# Generated at 2022-06-16 23:04:19.475568
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u2713') == '\u2713'
    assert to_native(b'\xe2\x9c\x93') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == '\u2713'

# Generated at 2022-06-16 23:04:43.914015
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == u'\u2713'

# Generated at 2022-06-16 23:04:53.035636
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u00e9') == b'\xc3\xa9'

    # Test that we can encode a byte string
    assert to_bytes(b'\xc3\xa9') == b'\xc3\xa9'

    # Test that we can encode a nonstring
    assert to_bytes(1) == b'1'

    # Test that we can encode a nonstring with a nonstring strategy
    assert to_bytes(1, nonstring='passthru') == 1

    # Test that we can encode a nonstring with a nonstring strategy
    assert to_bytes(1, nonstring='empty') == b''

    # Test that we can encode a nonstring with a nonstring strategy

# Generated at 2022-06-16 23:05:05.766080
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:05:13.759932
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:05:25.841864
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-16')) == u'foo'
    assert to_native(u'\u1234') == u'\u1234'
    assert to_native(u'\u1234'.encode('utf-16')) == u'\u1234'
    assert to_native(u'\u1234'.encode('utf-16'), nonstring='empty') == u''
    assert to_native(u'\u1234'.encode('utf-16'), nonstring='passthru') == u'\u1234'.encode('utf-16')

# Generated at 2022-06-16 23:05:36.083526
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_then_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='replace') == b'?'

# Generated at 2022-06-16 23:05:47.650422
# Unit test for function to_native
def test_to_native():
    # Test that to_native returns a unicode string
    assert isinstance(to_native(u'foo'), text_type)
    assert isinstance(to_native(b'foo'), text_type)
    assert isinstance(to_native(u'\u2713'), text_type)
    assert isinstance(to_native(b'\xe2\x9c\x93'), text_type)
    assert isinstance(to_native(u'\u2713'.encode('utf-8')), text_type)
    assert isinstance(to_native(b'\xe2\x9c\x93'.decode('utf-8')), text_type)
    assert isinstance(to_native(u'\u2713'.encode('utf-8').decode('utf-8')), text_type)

# Generated at 2022-06-16 23:05:53.247681
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:06:01.672450
# Unit test for function to_bytes

# Generated at 2022-06-16 23:06:12.391277
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'foo'.encode('utf-16')) == u'foo'
    assert to_native(u'foo'.encode('utf-32')) == u'foo'
    assert to_native(u'føø'.encode('utf-8')) == u'føø'
    assert to_native(u'føø'.encode('utf-16')) == u'føø'
    assert to_native(u'føø'.encode('utf-32')) == u'føø'

# Generated at 2022-06-16 23:06:44.740165
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=dict(b=1, c=2), d=dict(e=3, f=4))) == '{"a": {"b": 1, "c": 2}, "d": {"e": 3, "f": 4}}'
    assert jsonify(dict(a=dict(b=1, c=2), d=dict(e=3, f=4)), sort_keys=True) == '{"a": {"b": 1, "c": 2}, "d": {"e": 3, "f": 4}}'

# Generated at 2022-06-16 23:06:54.381786
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u2713') == '\u2713'
    assert to_native(b'\xe2\x9c\x93') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == '\u2713'

# Generated at 2022-06-16 23:07:00.836338
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:07:07.800684
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_then_replace') == b'?'

# Generated at 2022-06-16 23:07:17.266966
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u1234') == '"\\u1234"'
    assert jsonify(u'\u1234'.encode('latin-1')) == '"\\u1234"'
    assert jsonify(u'\u1234'.encode('utf-16')) == '"\\u1234"'
    assert jsonify(u'\u1234'.encode('utf-32')) == '"\\u1234"'
    assert jsonify(u'\u1234'.encode('utf-16-be')) == '"\\u1234"'
    assert jsonify(u'\u1234'.encode('utf-16-le')) == '"\\u1234"'

# Generated at 2022-06-16 23:07:28.213793
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(u'foo', encoding='utf-8') == u'foo'

# Generated at 2022-06-16 23:07:40.530352
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:07:50.141802
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u2713') == '\u2713'
    assert to_native(b'\xe2\x9c\x93') == '\u2713'
    assert to_native(u'\u2713'.encode('utf-8')) == '\u2713'
    assert to_native(u'\u2713'.encode('utf-8'), nonstring='passthru') == u'\u2713'.encode('utf-8')
    assert to_native(u'\u2713'.encode('utf-8'), nonstring='strict') == '\u2713'

# Generated at 2022-06-16 23:08:02.282584
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2713') == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-8')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('latin-1')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('ascii')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('ascii', 'surrogateescape')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('ascii', 'ignore')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('ascii', 'replace'))

# Generated at 2022-06-16 23:08:13.052995
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b'}
    assert jsonify(data) == '{"a": "b"}'
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd', 'e': 'f'}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": "f"}'
    data = {'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h'}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": "f", "g": "h"}'