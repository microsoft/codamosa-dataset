

# Generated at 2022-06-16 22:59:12.892893
# Unit test for function to_bytes
def test_to_bytes():
    # Test that to_bytes returns a byte string
    assert isinstance(to_bytes('foo'), binary_type)
    assert isinstance(to_bytes(u'foo'), binary_type)
    assert isinstance(to_bytes(b'foo'), binary_type)

    # Test that to_bytes returns a byte string that is the same as the input
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'

    # Test that to_bytes returns a byte string that is the same as the input
    # when we specify an encoding
    assert to_bytes('foo', encoding='utf-8') == b'foo'
    assert to_bytes(u'foo', encoding='utf-8') == b'foo'
   

# Generated at 2022-06-16 22:59:20.913246
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1, "b": 2\n}'

# Generated at 2022-06-16 22:59:28.456514
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(1.1) == '1.1'
    assert to_native(None) == 'None'
    assert to_native(dict(a=1, b=2)) == "{'a': 1, 'b': 2}"
    assert to_native(dict(a=1, b=2), format=True) == "{'a': 1, 'b': 2}"
    assert to_native(dict(a=1, b=2), format=False) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-16 22:59:39.420137
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1, "b": 2\n}'

# Generated at 2022-06-16 22:59:51.187200
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode to utf-8
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode to latin-1
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', 'latin-1') == b'\xcf\xbf\xd0\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode to latin-1 with surrogates
    assert to

# Generated at 2022-06-16 23:00:02.519575
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 23:00:14.946298
# Unit test for function to_native
def test_to_native():
    # Test with a byte string
    assert to_native(b'foo') == 'foo'
    # Test with a text string
    assert to_native(u'foo') == 'foo'
    # Test with an int
    assert to_native(42) == 42
    # Test with a list
    assert to_native([1, 2, 3]) == [1, 2, 3]
    # Test with a dict
    assert to_native({'foo': 'bar'}) == {'foo': 'bar'}
    # Test with a datetime
    assert to_native(datetime.datetime(2017, 1, 1)) == '2017-01-01 00:00:00'
    # Test with a set
    assert to_native(set([1, 2, 3])) == [1, 2, 3]



# Generated at 2022-06-16 23:00:25.792359
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode unicode strings
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode byte strings
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode non-strings

# Generated at 2022-06-16 23:00:37.218268
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u2713') == '\u2713'
    assert to_native(b'\xe2\x9c\x93') == '\u2713'
    assert to_native(u'\u2713'.encode('utf-16')) == '\u2713'
    assert to_native(u'\u2713'.encode('utf-16'), errors='surrogate_or_strict') == '\u2713'
    assert to_native(u'\u2713'.encode('utf-16'), errors='surrogate_or_replace') == '\u2713'

# Generated at 2022-06-16 23:00:46.294109
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_strict') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_replace') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_then_replace') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_strict', encoding='latin-1') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_replace', encoding='latin-1') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_then_replace', encoding='latin-1') == b'foo'
    assert to_

# Generated at 2022-06-16 23:01:02.843573
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd', 'e': Set([1, 2, 3])}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": [1, 2, 3]}'
    data = {'a': 'b', 'c': 'd', 'e': datetime.datetime(2016, 1, 1, 1, 1, 1)}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": "2016-01-01T01:01:01"}'



# Generated at 2022-06-16 23:01:13.745472
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode unicode strings
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode byte strings
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode non-strings

# Generated at 2022-06-16 23:01:22.932050
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=2) == '{\n  "a": 1, \n  "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": 1, "b": 2\n}'

# Generated at 2022-06-16 23:01:34.744882
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\x34'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='replace') == b'?'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='ignore') == b''

    # Test that we can encode a byte string
    assert to_bytes(b'foo') == b'foo'

# Generated at 2022-06-16 23:01:45.872393
# Unit test for function to_bytes
def test_to_bytes():
    # Test that to_bytes returns a byte string
    assert isinstance(to_bytes('foo'), binary_type)

    # Test that to_bytes returns the same byte string
    assert to_bytes(b'foo') == b'foo'

    # Test that to_bytes returns the same byte string with a different encoding
    assert to_bytes(b'foo', 'ascii') == b'foo'

    # Test that to_bytes returns the same byte string with a different encoding
    # and error handler
    assert to_bytes(b'foo', 'ascii', 'surrogate_or_strict') == b'foo'

    # Test that to_bytes returns the same byte string with a different encoding
    # and error handler

# Generated at 2022-06-16 23:01:56.350941
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(None) == 'None'
    assert to_native(dict(a=1, b=2)) == "{'a': 1, 'b': 2}"
    assert to_native(dict(a=1, b=2), nonstring='passthru') == {'a': 1, 'b': 2}
    assert to_native(dict(a=1, b=2), nonstring='empty') == ''
    assert to_native(dict(a=1, b=2), nonstring='strict') == TypeError
    assert to_native(dict(a=1, b=2), nonstring='foo') == TypeError
    assert to

# Generated at 2022-06-16 23:02:07.446507
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\x34'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_strict') == b'\x34'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_replace') == b'?'

# Generated at 2022-06-16 23:02:17.972995
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == u'\u2713'

# Generated at 2022-06-16 23:02:30.743713
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_then_replace') == b'?'

# Generated at 2022-06-16 23:02:41.518349
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a non-string
    assert to_

# Generated at 2022-06-16 23:03:00.463812
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data, sort_keys=True) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data, indent=2) == '{\n  "a": "b", \n  "c": "d"\n}'
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data, separators=(',', ':')) == '{"a":"b","c":"d"}'

# Generated at 2022-06-16 23:03:09.607041
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\xe4\xb8\xad'

# Generated at 2022-06-16 23:03:15.814297
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(1.1) == '1.1'
    assert to_native(True) == 'True'
    assert to_native(None) == 'None'
    assert to_native(dict(a=1)) == "{'a': 1}"
    assert to_native(set([1, 2, 3])) == 'set([1, 2, 3])'
    assert to_native(['a', 'b', 'c']) == "['a', 'b', 'c']"
    assert to_native(datetime.datetime(2017, 1, 1)) == '2017-01-01 00:00:00'
    assert to_native

# Generated at 2022-06-16 23:03:21.821494
# Unit test for function jsonify
def test_jsonify():
    # Test for encoding keyword
    data = {'a': '\xe9'}
    assert jsonify(data) == '{"a": "\\u00e9"}'
    # Test for default keyword
    data = {'a': datetime.datetime(2017, 1, 1, 0, 0, 0)}
    assert jsonify(data) == '{"a": "2017-01-01T00:00:00"}'
    # Test for encoding error
    data = {'a': '\xe9'}
    try:
        jsonify(data, encoding='ascii')
    except UnicodeError:
        pass
    else:
        assert False


# Generated at 2022-06-16 23:03:34.305412
# Unit test for function to_native
def test_to_native():
    # Test that to_native returns a string
    assert isinstance(to_native(u'foo'), str)
    assert isinstance(to_native(b'foo'), str)
    assert isinstance(to_native(1), str)
    assert isinstance(to_native(1.0), str)
    assert isinstance(to_native(True), str)
    assert isinstance(to_native(None), str)
    assert isinstance(to_native([]), str)
    assert isinstance(to_native({}), str)
    assert isinstance(to_native(()), str)
    assert isinstance(to_native(set()), str)
    assert isinstance(to_native(datetime.datetime.now()), str)

    # Test that to_native returns a string with the correct content
    assert to_native

# Generated at 2022-06-16 23:03:47.080762
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1, "b": 2\n}'

# Generated at 2022-06-16 23:03:57.571678
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(u'foo', encoding='utf-8') == u'foo'

# Generated at 2022-06-16 23:04:09.100903
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:04:20.519320
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:04:30.119205
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(1) == u'1'
    assert to_native(1, nonstring='passthru') == 1
    assert to_native(1, nonstring='empty') == u''
    assert to_native(1, nonstring='strict') == u'1'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:04:49.112117
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', 'utf-8') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a text string with surrogates
    assert to_bytes(u'\ud83d\ude00', 'utf-8') == b'\xf0\x9f\x98\x80'

    # Test that we can encode a text string with surrogates using surrogateescape

# Generated at 2022-06-16 23:04:57.584832
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd', 'e': Set(['f', 'g'])}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": ["f", "g"]}'
    data = {'a': 'b', 'c': 'd', 'e': datetime.datetime(2015, 1, 1)}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": "2015-01-01T00:00:00"}'

# Generated at 2022-06-16 23:05:09.448033
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'fóo') == b'f\xc3\xb3o'
    assert to_bytes(u'fóo', encoding='latin-1') == b'f\xf3o'
    assert to_bytes(u'fóo', encoding='latin-1', errors='replace') == b'f?o'
    assert to_bytes(u'fóo', encoding='latin-1', errors='surrogate_or_replace') == b'f?o'

# Generated at 2022-06-16 23:05:21.115658
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='strict') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:05:32.412982
# Unit test for function jsonify

# Generated at 2022-06-16 23:05:40.116545
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_then_replace') == b'?'

# Generated at 2022-06-16 23:05:50.975972
# Unit test for function to_native
def test_to_native():
    # Test that to_native returns a string
    assert isinstance(to_native(u'foo'), str)
    assert isinstance(to_native(b'foo'), str)

    # Test that to_native returns a string that is decodable
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo') == 'foo'

    # Test that to_native returns a string that is decodable with surrogateescape
    assert to_native(u'\udcff') == '\udcff'
    assert to_native(b'\xff') == '\udcff'

    # Test that to_native returns a string that is decodable with surrogateescape
    # even if the string has surrogates

# Generated at 2022-06-16 23:06:00.821826
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b", "c": "d"}) == '{"a": "b", "c": "d"}'
    assert jsonify({"a": "b", "c": "d", "e": "f"}) == '{"a": "b", "c": "d", "e": "f"}'
    assert jsonify({"a": "b", "c": "d", "e": "f", "g": "h"}) == '{"a": "b", "c": "d", "e": "f", "g": "h"}'

# Generated at 2022-06-16 23:06:12.237186
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 23:06:24.789110
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'foo'.encode('utf-16')) == u'foo'
    assert to_native(u'foo'.encode('utf-32')) == u'foo'
    assert to_native(u'føø'.encode('utf-8')) == u'føø'
    assert to_native(u'føø'.encode('utf-16')) == u'føø'
    assert to_native(u'føø'.encode('utf-32')) == u'føø'

# Generated at 2022-06-16 23:06:48.784760
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a nonstring
    assert to_bytes(1) == b'1'
    assert to_bytes(1, nonstring='passthru') == 1

    # Test that we can encode a nonstring that doesn't have a str repr
    class Foo(object):
        def __repr__(self):
            return u'\u1234'

    assert to_bytes(Foo()) == b'\xe1\x88\xb4'

    # Test that we can encode a nonstring that doesn't have a repr

# Generated at 2022-06-16 23:06:57.178817
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=dict(b=u'\u6d4b\u8bd5'))) == '{"a": {"b": "\\u6d4b\\u8bd5"}}'
    assert jsonify(dict(a=dict(b=u'\u6d4b\u8bd5')), ensure_ascii=False) == '{"a": {"b": "测试"}}'
    assert jsonify(dict(a=dict(b=u'\u6d4b\u8bd5')), ensure_ascii=False, encoding='latin-1') == '{"a": {"b": "\\u6d4b\\u8bd5"}}'

# Generated at 2022-06-16 23:07:07.750636
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b",\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': '), encoding="latin-1") == '{\n    "a": "b",\n}'

# Generated at 2022-06-16 23:07:17.232137
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8')) == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8'), nonstring='passthru') == u'\u2713'.encode('utf-8')
    assert to_native(u'\u2713'.encode('utf-8'), nonstring='strict') == u'\u2713'

# Generated at 2022-06-16 23:07:28.213043
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a text string with surrogates
    assert to

# Generated at 2022-06-16 23:07:40.533629
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:07:50.140844
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(1.1) == '1.1'
    assert to_native(None) == 'None'
    assert to_native(dict(a=1)) == "{'a': 1}"
    assert to_native(dict(a=1), indent=4) == "{\n    'a': 1\n}"
    assert to_native(dict(a=1), format='json') == '{"a": 1}'
    assert to_native(dict(a=1), format='json', indent=4) == "{\n    \"a\": 1\n}"

# Generated at 2022-06-16 23:08:02.282742
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'

    # Test that we can encode a unicode string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a unicode string with surrogates
    assert to_bytes(u'\ud800\udc00') == b'\xf0\x90\x80\x80'

    # Test that we can encode a unicode string with surrogates and non-BMP

# Generated at 2022-06-16 23:08:13.052261
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 1, 'b': 2}
    assert jsonify(data) == '{"a": 1, "b": 2}'
    data = {'a': 1, 'b': 2, 'c': Set([1, 2, 3])}
    assert jsonify(data) == '{"a": 1, "b": 2, "c": [1, 2, 3]}'
    data = {'a': 1, 'b': 2, 'c': datetime.datetime(2016, 1, 1, 1, 1, 1)}
    assert jsonify(data) == '{"a": 1, "b": 2, "c": "2016-01-01T01:01:01"}'
    data = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    assert json

# Generated at 2022-06-16 23:08:24.007782
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": : "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': '), encoding='latin-1') == '{\n  "a": : "b"\n}'