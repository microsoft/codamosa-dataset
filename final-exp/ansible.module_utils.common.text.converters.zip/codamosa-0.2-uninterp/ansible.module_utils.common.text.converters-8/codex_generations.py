

# Generated at 2022-06-16 22:59:13.735915
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hello') == b'hello'

    # Test that we can encode a byte string
    assert to_bytes(b'hello') == b'hello'

    # Test that we can encode a text string with non-ascii characters
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a text string with non-ascii characters
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\xe1\x88\xb4'

    # Test that we can encode a text string with non-ascii characters
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_replace') == b

# Generated at 2022-06-16 22:59:21.625004
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8')) == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-16')) == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-32')) == u'\u2713'
    assert to_native(u'\u2713'.encode('latin-1')) == u'\u2713'
    assert to_native(u'\u2713'.encode('ascii')) == u'\u2713'

# Generated at 2022-06-16 22:59:32.536506
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd', 'e': Set([1, 2, 3])}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": [1, 2, 3]}'
    data = {'a': 'b', 'c': 'd', 'e': datetime.datetime(2017, 1, 1, 1, 1, 1)}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": "2017-01-01T01:01:01"}'

# Generated at 2022-06-16 22:59:44.527310
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'\xe2\x98\x83') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_or_strict') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_or_replace') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_then_replace') == u'\u2603'

# Generated at 2022-06-16 22:59:50.368005
# Unit test for function to_native
def test_to_native():
    # Test that to_native returns a native string
    assert isinstance(to_native(u'foo'), str)
    assert isinstance(to_native(b'foo'), str)
    assert isinstance(to_native(b'foo', errors='surrogate_or_strict'), str)
    assert isinstance(to_native(u'foo', errors='surrogate_or_strict'), str)
    assert isinstance(to_native(b'foo', errors='surrogate_or_replace'), str)
    assert isinstance(to_native(u'foo', errors='surrogate_or_replace'), str)
    assert isinstance(to_native(b'foo', errors='surrogate_then_replace'), str)

# Generated at 2022-06-16 23:00:01.814273
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(1.1) == '1.1'
    assert to_native(b'\xc3\xbc') == u'\xfc'
    assert to_native(u'\xfc') == u'\xfc'
    assert to_native(b'\xc3\xbc', errors='surrogate_or_strict') == u'\xfc'
    assert to_native(b'\xc3\xbc', errors='surrogate_or_replace') == u'\xfc'

# Generated at 2022-06-16 23:00:14.372802
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a text string with surrogates
    assert to

# Generated at 2022-06-16 23:00:25.299809
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(1) == u'1'
    assert to_native(1.1) == u'1.1'
    assert to_native(True) == u'True'
    assert to_native(None) == u'None'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82')

# Generated at 2022-06-16 23:00:36.843635
# Unit test for function to_bytes
def test_to_bytes():
    # Test that to_bytes works with unicode strings
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that to_bytes works with byte strings
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that to_bytes works with non-strings
   

# Generated at 2022-06-16 23:00:46.046892
# Unit test for function to_native
def test_to_native():
    # Test that to_native returns a native string
    assert isinstance(to_native(u'foo'), text_type)
    assert isinstance(to_native(b'foo'), text_type)
    assert isinstance(to_native(u'foo'.encode('utf-8')), text_type)
    assert isinstance(to_native(b'foo'.decode('utf-8')), text_type)
    assert isinstance(to_native(u'foo'.encode('utf-8').decode('utf-8')), text_type)
    assert isinstance(to_native(b'foo'.decode('utf-8').encode('utf-8')), text_type)
    assert isinstance(to_native(u'\u2713'), text_type)

# Generated at 2022-06-16 23:01:01.487094
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(1) == u'1'
    assert to_native(1.1) == u'1.1'
    assert to_native(True) == u'True'
    assert to_native(None) == u'None'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:01:12.800348
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode unicode strings
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode byte strings
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode non-strings

# Generated at 2022-06-16 23:01:22.113132
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:01:34.100320
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd', 'e': {'f': 'g'}}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": {"f": "g"}}'
    data = {'a': 'b', 'c': 'd', 'e': {'f': 'g'}, 'h': [1, 2, 3]}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": {"f": "g"}, "h": [1, 2, 3]}'

# Generated at 2022-06-16 23:01:44.874781
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'

    # Test that we can encode a string with non-ascii characters
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\x34\x12'

    # Test that we can encode a string with surrogates
    assert to_bytes(u'\udc80') == b'\x80'
    assert to_bytes(u'\udc80', encoding='latin-1') == b'\x80'

    # Test that we can

# Generated at 2022-06-16 23:01:51.564503
# Unit test for function jsonify
def test_jsonify():
    data = {
        'a': 'b',
        'c': [1, 2, 3],
        'd': {
            'e': 'f',
            'g': [4, 5, 6],
        },
    }
    assert jsonify(data) == '{"a": "b", "c": [1, 2, 3], "d": {"e": "f", "g": [4, 5, 6]}}'



# Generated at 2022-06-16 23:02:00.527940
# Unit test for function to_native
def test_to_native():
    # Test that to_native works with all the different types of strings
    # that we have
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'\xe2\x98\x83') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_or_strict') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_or_replace') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_then_replace') == u'\u2603'

# Generated at 2022-06-16 23:02:12.430445
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == 'foo'
    assert to_native(u'foo', errors='surrogate_or_strict') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == 'foo'
    assert to_native(u'foo', errors='surrogate_or_replace') == 'foo'
    assert to_native(b'foo', errors='surrogate_then_replace') == 'foo'
    assert to_native(u'foo', errors='surrogate_then_replace') == 'foo'

    assert to_native(b'\xff') == '\ufffd'

# Generated at 2022-06-16 23:02:21.067766
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:02:34.551838
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a non-string
    assert to_bytes

# Generated at 2022-06-16 23:02:53.951382
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8')) == u'\u2713'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == u'foo'

# Generated at 2022-06-16 23:03:05.485180
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, separators=(',', ':')) == '{"a":"b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ':')) == '{\n    "a":"b"\n}'

# Generated at 2022-06-16 23:03:12.597607
# Unit test for function jsonify
def test_jsonify():
    data = {u'foo': u'bar', u'baz': u'föö'}
    assert jsonify(data) == '{"foo": "bar", "baz": "f\\u00f6\\u00f6"}'
    assert jsonify(data, ensure_ascii=False) == '{"foo": "bar", "baz": "föö"}'



# Generated at 2022-06-16 23:03:20.801627
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\x34'

    # Test that we can encode a byte string
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'
    assert to_bytes(b'\xe1\x88\xb4', encoding='latin-1') == b'\xe1\x88\xb4'

    # Test that we can encode a non-string
    assert to_bytes(1) == b'1'
    assert to_bytes(1, nonstring='empty') == b''

# Generated at 2022-06-16 23:03:33.204341
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:03:40.818154
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": : "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': '), encoding='latin-1') == '{\n  "a": : "b"\n}'

# Generated at 2022-06-16 23:03:52.708346
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:04:03.609809
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='strict') == u'\u2713'
   

# Generated at 2022-06-16 23:04:14.662935
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == u'\u2713'

# Generated at 2022-06-16 23:04:26.182299
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": u"b"}) == '{"a": "b"}'
    assert jsonify({"a": u"b\u1234"}) == '{"a": "b\u1234"}'
    assert jsonify({"a": u"b\u1234".encode("utf-16")}) == '{"a": "b\u1234"}'
    assert jsonify({"a": u"b\u1234".encode("utf-16-le")}) == '{"a": "b\u1234"}'
    assert jsonify({"a": u"b\u1234".encode("utf-16-be")}) == '{"a": "b\u1234"}'

# Generated at 2022-06-16 23:04:49.111449
# Unit test for function to_native
def test_to_native():
    # Test that we can pass in a text string and get back a text string
    assert isinstance(to_native(u'foo'), text_type)

    # Test that we can pass in a byte string and get back a text string
    assert isinstance(to_native(b'foo'), text_type)

    # Test that we can pass in a nonstring and get back a text string
    assert isinstance(to_native(1), text_type)

    # Test that we can pass in a text string and get back a byte string
    assert isinstance(to_native(u'foo', nonstring='passthru'), text_type)

    # Test that we can pass in a byte string and get back a byte string
    assert isinstance(to_native(b'foo', nonstring='passthru'), binary_type)

    # Test that we can pass

# Generated at 2022-06-16 23:04:57.497635
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'foo'.encode('utf-16')) == u'foo'
    assert to_native(u'foo'.encode('utf-32')) == u'foo'
    assert to_native(u'føø'.encode('utf-8')) == u'føø'
    assert to_native(u'føø'.encode('utf-16')) == u'føø'
    assert to_native(u'føø'.encode('utf-32')) == u'føø'

# Generated at 2022-06-16 23:05:09.405988
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == 'foo'
    assert to_native(u'foo', errors='surrogate_or_strict') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == 'foo'
    assert to_native(u'foo', errors='surrogate_or_replace') == 'foo'
    assert to_native(b'foo', errors='surrogate_then_replace') == 'foo'
    assert to_native(u'foo', errors='surrogate_then_replace') == 'foo'

# Generated at 2022-06-16 23:05:21.000499
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('abc') == b'abc'
    assert to_bytes(u'abc') == b'abc'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_strict') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:05:32.316294
# Unit test for function jsonify
def test_jsonify():
    data = {u'a': u'\u00e9'}
    assert jsonify(data) == u'{"a": "\u00e9"}'
    data = {u'a': u'\u00e9'}
    assert jsonify(data, ensure_ascii=False) == u'{"a": "\\u00e9"}'
    data = {u'a': u'\u00e9'}
    assert jsonify(data, ensure_ascii=True) == u'{"a": "\\u00e9"}'
    data = {u'a': u'\u00e9'}
    assert jsonify(data, sort_keys=True) == u'{"a": "\u00e9"}'
    data = {u'a': u'\u00e9'}
   

# Generated at 2022-06-16 23:05:43.529207
# Unit test for function to_native
def test_to_native():
    # Test with text strings
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(u'foo', errors='surrogate_or_replace') == u'foo'
    assert to_native(u'foo', errors='surrogate_then_replace') == u'foo'

    # Test with byte strings
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == u'foo'

# Generated at 2022-06-16 23:05:53.240068
# Unit test for function jsonify
def test_jsonify():
    data = {
        'a': 'b',
        'c': [1, 2, 3],
        'd': {
            'e': 'f',
            'g': 'h',
        },
        'i': Set([1, 2, 3]),
        'j': datetime.datetime(2012, 12, 12, 12, 12, 12),
    }
    assert jsonify(data) == '{"a": "b", "c": [1, 2, 3], "d": {"e": "f", "g": "h"}, "i": [1, 2, 3], "j": "2012-12-12T12:12:12"}'



# Generated at 2022-06-16 23:06:01.671800
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a nonstring

# Generated at 2022-06-16 23:06:12.416222
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:06:24.926389
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:06:54.896796
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), indent=2) == '{\n  "a": 1, \n  "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=2) == '{\n  "a": 1, \n  "b": 2\n}'
    assert jsonify(dict(a=1, b=2), separators=(',', ':')) == '{"a":1,"b":2}'

# Generated at 2022-06-16 23:07:05.442142
# Unit test for function to_native
def test_to_native():
    # Test with a text string
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo', nonstring='simplerepr') == u'foo'
    assert to_native(u'foo', nonstring='passthru') == u'foo'
    assert to_native(u'foo', nonstring='empty') == u''
    assert to_native(u'foo', nonstring='strict') == u'foo'

    # Test with a byte string
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo', nonstring='simplerepr') == u'foo'
    assert to_native(b'foo', nonstring='passthru') == b'foo'
    assert to_native(b'foo', nonstring='empty') == u''

# Generated at 2022-06-16 23:07:15.746752
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent="\t") == '{\n\t"a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, separators=(',', ':')) == '{"a":"b"}'
    assert jsonify({"a": "b"}, sort_keys=True, separators=(',', ': ')) == '{"a": "b"}'
    assert jsonify

# Generated at 2022-06-16 23:07:23.441418
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'

    # Test that we can encode a byte string
    assert to_bytes(b'hello') == b'hello'

    # Test that we can encode a text string with non-ascii characters
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a text string with surrogates
    assert to_bytes(u'\ud800\udc00') == b'\xf0\x90\x80\x80'

    # Test that we can encode a text string with surrogates and non-ascii

# Generated at 2022-06-16 23:07:36.539395
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1, "b": "2"}) == '{"a": 1, "b": "2"}'
    assert jsonify({"a": 1, "b": "2", "c": [1, 2, 3]}) == '{"a": 1, "c": [1, 2, 3], "b": "2"}'
    assert jsonify({"a": 1, "b": "2", "c": [1, 2, 3], "d": {"e": 1}}) == '{"a": 1, "c": [1, 2, 3], "b": "2", "d": {"e": 1}}'

# Generated at 2022-06-16 23:07:44.344414
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:07:52.122044
# Unit test for function jsonify
def test_jsonify():
    # Test for jsonify function
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, separators=(',', ':')) == '{"a":"b"}'
    assert jsonify({"a": "b"}, sort_keys=True, separators=(',', ':')) == '{"a":"b"}'

# Generated at 2022-06-16 23:08:04.252941
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": : "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': '), ensure_ascii=False) == '{\n  "a": : "b"\n}'

# Generated at 2022-06-16 23:08:17.278008
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

    # Test that we can encode a nonstring
    assert to_bytes(1) == b'1'

    # Test that we can encode a nonstring with a custom error handler
    assert to_bytes(1, errors='surrogate_or_replace') == b'1'

    # Test that we can encode a nonstring with a custom error handler
    assert to_bytes(1, errors='surrogate_then_replace') == b'1'

    # Test that we can encode a nonstring with a

# Generated at 2022-06-16 23:08:27.344876
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(1) == u'1'
    assert to_native(1.1) == u'1.1'
    assert to_native(None) == u'None'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'