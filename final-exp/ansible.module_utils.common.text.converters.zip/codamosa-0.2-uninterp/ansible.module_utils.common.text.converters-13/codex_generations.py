

# Generated at 2022-06-16 22:59:05.011973
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_replace') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_strict') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_then_replace') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_then_replace', encoding='latin-1') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_replace', encoding='latin-1') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_strict', encoding='latin-1') == b'foo'
    assert to_

# Generated at 2022-06-16 22:59:15.747265
# Unit test for function jsonify
def test_jsonify():
    # Test for non-string data
    data = {'a': 1, 'b': 2}
    assert jsonify(data) == '{"a": 1, "b": 2}'

    # Test for string data
    data = {'a': '1', 'b': '2'}
    assert jsonify(data) == '{"a": "1", "b": "2"}'

    # Test for unicode data
    data = {'a': u'1', 'b': u'2'}
    assert jsonify(data) == '{"a": "1", "b": "2"}'

    # Test for non-ascii data
    data = {'a': u'\u4e2d\u6587', 'b': u'\u4e2d\u6587'}

# Generated at 2022-06-16 22:59:28.870523
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'?'
    assert to_bytes(u'\u1234', errors='replace') == b'?'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'?'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace', encoding='ascii') == b'?'

# Generated at 2022-06-16 22:59:38.080449
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 22:59:49.248738
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a byte string
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(b'foo', nonstring='strict') == b'foo'

    # Test that we can encode a text string
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo', nonstring='strict') == b'foo'

    # Test that we can encode a text string with surrogates
    assert to_bytes(u'foo\udcff') == b'foo\xed\xb3\xbf'
    assert to_bytes(u'foo\udcff', nonstring='strict') == b'foo\xed\xb3\xbf'

    # Test that we can encode a text string with surrogates using surrogateescape

# Generated at 2022-06-16 23:00:01.358093
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    # Test that we can encode a byte string
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'
    # Test that we can encode a nonstring
    assert to_bytes(1234) == b'1234'
    # Test that we can encode a nonstring with a nonstring strategy
    assert to_bytes(1234, nonstring='passthru') == 1234
    # Test that we can encode a nonstring with a nonstring strategy
    assert to_bytes(1234, nonstring='empty') == b''
    # Test that we can encode a nonstring with a nonstring strategy
    assert to_

# Generated at 2022-06-16 23:00:09.446455
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:00:21.314359
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    # Test that we can encode a non-string
    assert to_

# Generated at 2022-06-16 23:00:30.444660
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 23:00:41.993520
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'hello') == b'hello'

    # Test that we can encode a nonstring
    assert to_bytes(5) == b'5'
    assert to_bytes(5, nonstring='passthru') == 5
    assert to_bytes(5, nonstring='empty') == b''
    assert to_bytes(5, nonstring='strict') == b'5'

    # Test that we can encode a nonstring that can't be converted to text

# Generated at 2022-06-16 23:00:58.824897
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string to a byte string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a non-text string to a byte string
    assert to_bytes(1) == b'1'
    assert to_bytes(1.0) == b'1.0'
    assert to_bytes(b'foo') == b'foo'

    # Test that we can encode a text string to a byte string with a different
    # encoding
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\x88\xb4'

    # Test that we can encode a text

# Generated at 2022-06-16 23:01:05.551148
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2713') == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-8')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('latin-1')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('ascii')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('ascii', 'surrogateescape')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('ascii', 'replace')) == '"?"'

# Generated at 2022-06-16 23:01:16.171382
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:01:24.568237
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b",\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': '), encoding="latin-1") == '{\n    "a": "b",\n}'

# Generated at 2022-06-16 23:01:35.877261
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:01:47.302003
# Unit test for function to_native
def test_to_native():
    assert to_native(b'\xc3\xbc') == u'\xfc'
    assert to_native(u'\xfc') == u'\xfc'
    assert to_native(u'\xfc', encoding='ascii', errors='surrogate_or_strict') == u'\udcfc'
    assert to_native(u'\xfc', encoding='ascii', errors='surrogate_or_replace') == u'?'
    assert to_native(u'\xfc', encoding='ascii', errors='surrogate_then_replace') == u'?'
    assert to_native(u'\udcfc', encoding='ascii', errors='surrogate_or_strict') == u'\udcfc'

# Generated at 2022-06-16 23:01:57.490939
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a nonstring

# Generated at 2022-06-16 23:02:04.700006
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:02:16.158867
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:02:28.944013
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b'}
    assert jsonify(data) == '{"a": "b"}'

    data = {'a': u'\u2713'}
    assert jsonify(data) == '{"a": "\\u2713"}'

    data = {'a': u'\u2713'}
    assert jsonify(data, ensure_ascii=False) == u'{"a": "\u2713"}'

    data = {'a': u'\u2713'}
    assert jsonify(data, sort_keys=True) == '{"a": "\\u2713"}'

    data = {'a': u'\u2713'}

# Generated at 2022-06-16 23:02:43.235970
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:02:55.641962
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a non-string
    assert to_

# Generated at 2022-06-16 23:03:06.570020
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode unicode strings
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', nonstring='strict') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode byte strings

# Generated at 2022-06-16 23:03:17.445642
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, sort_keys=True) == '{"a": 1}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4, separators=(',', ': '), encoding='latin-1') == '{\n    "a": 1\n}'

# Generated at 2022-06-16 23:03:28.193056
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u2713') == '\u2713'
    assert to_native(b'\xe2\x9c\x93') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == '\u2713'

# Generated at 2022-06-16 23:03:35.708386
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'



# Generated at 2022-06-16 23:03:47.404069
# Unit test for function to_native
def test_to_native():
    # Test with a text string
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo', nonstring='simplerepr') == u'foo'
    assert to_native(u'foo', nonstring='passthru') == u'foo'
    assert to_native(u'foo', nonstring='empty') == u''
    assert to_native(u'foo', nonstring='strict') == u'foo'

    # Test with a byte string
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo', nonstring='simplerepr') == u'foo'
    assert to_native(b'foo', nonstring='passthru') == b'foo'
    assert to_native(b'foo', nonstring='empty') == u''

# Generated at 2022-06-16 23:03:57.828290
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

    # Test that we can encode a nonstring
    assert to_bytes(1234) == b'1234'

    # Test that we can encode a nonstring with a non-ascii character
    assert to_bytes(u'\u1234' + 1234) == b'\xe1\x88\xb41234'

    # Test that we can encode a nonstring with a non-ascii character
    # and a non-ascii byte string

# Generated at 2022-06-16 23:04:04.574693
# Unit test for function to_native
def test_to_native():
    # Test for function to_native
    # Test with a byte string
    assert to_native(b'\xc3\xbc') == u'\xfc'
    # Test with a text string
    assert to_native(u'\xfc') == u'\xfc'
    # Test with a nonstring
    assert to_native(1) == u'1'
    # Test with a nonstring and nonstring='passthru'
    assert to_native(1, nonstring='passthru') == 1
    # Test with a nonstring and nonstring='empty'
    assert to_native(1, nonstring='empty') == u''
    # Test with a nonstring and nonstring='strict'
    try:
        to_native(1, nonstring='strict')
    except TypeError:
        pass

# Generated at 2022-06-16 23:04:15.760254
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:04:31.540352
# Unit test for function to_native
def test_to_native():
    # Test with a text string
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo', 'ascii') == u'foo'
    assert to_native(u'foo', 'ascii', 'surrogate_or_strict') == u'foo'
    assert to_native(u'foo', 'ascii', 'surrogate_or_replace') == u'foo'
    assert to_native(u'foo', 'ascii', 'surrogate_then_replace') == u'foo'
    assert to_native(u'foo', 'ascii', 'strict') == u'foo'
    assert to_native(u'foo', 'ascii', 'replace') == u'foo'

# Generated at 2022-06-16 23:04:44.045603
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

    # Test that we can encode a non-string
    assert to_bytes(1) == b'1'

    # Test that we can encode a non-string with a non-ascii repr
    class Foo(object):
        def __repr__(self):
            return u'\u1234'
    assert to_bytes(Foo()) == b'\xe1\x88\xb4'

    # Test that we can encode a non-string with a non-ascii str
   

# Generated at 2022-06-16 23:04:53.141350
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:05:05.944503
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b",\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': '), encoding="latin-1") == '{\n    "a": "b",\n}'

# Generated at 2022-06-16 23:05:13.874149
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": : "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': '), ensure_ascii=False) == '{\n  "a": : "b"\n}'

# Generated at 2022-06-16 23:05:25.963324
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u2713') == '\u2713'
    assert to_native(b'\xe2\x9c\x93') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == '\u2713'

# Generated at 2022-06-16 23:05:36.170832
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8')) == u'\u2713'
    assert to_native(b'\xe2\x9c\x93'.decode('utf-8')) == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8').decode('utf-8')) == u'\u2713'

# Generated at 2022-06-16 23:05:47.736597
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo'.decode('utf-8')) == u'foo'
    assert to_native(u'fóo') == u'fóo'
    assert to_native(u'fóo'.encode('utf-8')) == u'fóo'
    assert to_native(b'f\xc3\xb3o') == u'fóo'
    assert to_native(b'f\xc3\xb3o'.decode('utf-8')) == u'fóo'

# Generated at 2022-06-16 23:05:53.266681
# Unit test for function jsonify

# Generated at 2022-06-16 23:05:59.789683
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:06:26.027986
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'\xe2\x98\x83') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_or_strict') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_or_replace') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_then_replace') == u'\u2603'

# Generated at 2022-06-16 23:06:34.144989
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:06:46.795255
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_then_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='replace') == b'?'

# Generated at 2022-06-16 23:06:55.644247
# Unit test for function to_native
def test_to_native():
    # Test with a text string
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo', nonstring='passthru') == u'foo'
    assert to_native(u'foo', nonstring='simplerepr') == u'foo'
    assert to_native(u'foo', nonstring='empty') == u''
    assert to_native(u'foo', nonstring='strict') == u'foo'

    # Test with a byte string
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo', nonstring='passthru') == b'foo'
    assert to_native(b'foo', nonstring='simplerepr') == u"b'foo'"

# Generated at 2022-06-16 23:06:58.581479
# Unit test for function jsonify
def test_jsonify():
    data = {'a': u'\u00e9'}
    assert jsonify(data) == '{"a": "\\u00e9"}'



# Generated at 2022-06-16 23:07:09.075328
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:07:12.430277
# Unit test for function jsonify
def test_jsonify():
    data = {u'a': u'\u00e9'}
    assert jsonify(data) == '{"a": "\\u00e9"}'
    data = {u'a': u'\u00e9'}
    assert jsonify(data, ensure_ascii=False) == u'{"a": "\u00e9"}'



# Generated at 2022-06-16 23:07:21.057534
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\udc80') == b'\xed\xb2\x80'

# Generated at 2022-06-16 23:07:32.002732
# Unit test for function to_bytes
def test_to_bytes():
    # Test that to_bytes returns a byte string
    assert isinstance(to_bytes('foo'), binary_type)

    # Test that to_bytes returns the same byte string it's given
    assert to_bytes(b'foo') == b'foo'

    # Test that to_bytes returns a byte string that matches the text string
    # it's given
    assert to_bytes('foo') == b'foo'

    # Test that to_bytes returns a byte string that matches the text string
    # it's given when given a unicode string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

# Generated at 2022-06-16 23:07:42.314434
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a non-string
    assert to_bytes

# Generated at 2022-06-16 23:08:05.592128
# Unit test for function jsonify
def test_jsonify():
    data = {
        "key1": "value1",
        "key2": "value2",
        "key3": {
            "key4": "value4",
            "key5": "value5"
        }
    }
    assert jsonify(data) == '{"key1": "value1", "key2": "value2", "key3": {"key4": "value4", "key5": "value5"}}'



# Generated at 2022-06-16 23:08:18.222994
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u20ac') == '"\\u20ac"'
    assert jsonify(u'\u20ac'.encode('utf-8')) == '"\\u20ac"'
    assert jsonify(u'\u20ac'.encode('latin-1')) == '"\\u20ac"'
    assert jsonify(u'\u20ac'.encode('ascii')) == '"\\u20ac"'
    assert jsonify(u'\u20ac'.encode('ascii', 'ignore')) == '""'
    assert jsonify(u'\u20ac'.encode('ascii', 'replace')) == '"?"'

# Generated at 2022-06-16 23:08:28.101987
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b",\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': '), encoding='latin-1') == '{\n    "a": "b",\n}'

# Generated at 2022-06-16 23:08:38.677113
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:08:41.986873
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'



# Generated at 2022-06-16 23:08:53.262807
# Unit test for function jsonify
def test_jsonify():
    # Test for function jsonify
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'