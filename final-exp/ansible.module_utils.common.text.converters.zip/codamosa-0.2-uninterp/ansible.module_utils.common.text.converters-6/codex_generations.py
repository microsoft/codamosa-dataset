

# Generated at 2022-06-16 22:59:13.849503
# Unit test for function to_native
def test_to_native():
    # Test with a text string
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(u'foo', errors='surrogate_or_replace') == u'foo'
    assert to_native(u'foo', errors='surrogate_then_replace') == u'foo'
    assert to_native(u'foo', errors='ignore') == u'foo'
    assert to_native(u'foo', errors='replace') == u'foo'
    assert to_native(u'foo', errors='strict') == u'foo'
    assert to_native(u'foo', errors='xmlcharrefreplace') == u'foo'

    # Test with a byte string
    assert to_

# Generated at 2022-06-16 22:59:21.715213
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 22:59:29.693016
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\xe4\xb8\xad'

# Generated at 2022-06-16 22:59:38.719396
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'

    # Test that we can encode a byte string
    assert to_bytes(b'foo') == b'foo'

    # Test that we can encode a text string with non-ascii characters
    assert to_bytes(u'f\u00f6\u00f6') == b'f\xc3\xb6\xc3\xb6'

    # Test that we can encode a text string with non-ascii characters
    assert to_bytes(u'f\u00f6\u00f6', encoding='latin-1') == b'f\xf6\xf6'

    # Test that we can encode a text string with non-ascii characters

# Generated at 2022-06-16 22:59:50.614188
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1, "b": 2\n}'

# Generated at 2022-06-16 23:00:02.038411
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a text string with surrogates
    assert to

# Generated at 2022-06-16 23:00:14.566038
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='replace') == b'?'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace', encoding='ascii') == b'?'
    assert to_

# Generated at 2022-06-16 23:00:25.436914
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8')) == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8'), nonstring='passthru') == u'\u2713'.encode('utf-8')
    assert to_native(b'\xe2\x9c\x93', nonstring='passthru') == b'\xe2\x9c\x93'
    assert to

# Generated at 2022-06-16 23:00:36.894179
# Unit test for function to_native
def test_to_native():
    """
    Test to_native function
    """
    from ansible.module_utils._text import to_native
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo'.decode('utf-8')) == u'foo'
    assert to_native(b'\xc3\xbc') == u'\xfc'
    assert to_native(b'\xc3\xbc'.decode('utf-8')) == u'\xfc'
    assert to_native(u'\xfc') == u'\xfc'
    assert to_native(b'\xc3\xbc', encoding='latin-1') == u'\xc3\xbc'

# Generated at 2022-06-16 23:00:46.077659
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-16')) == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-16'), errors='surrogate_or_strict') == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-16'), errors='surrogate_or_replace') == u'\u2713'

# Generated at 2022-06-16 23:01:03.403730
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a non-string
    assert to_bytes

# Generated at 2022-06-16 23:01:14.205606
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

    # Test that we can encode a non-string
    assert to_bytes(1234) == b'1234'

    # Test that we can encode a non-string with a non-ascii repr
    assert to_bytes(datetime.datetime.now())

    # Test that we can encode a non-string with a non-ascii str
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode

# Generated at 2022-06-16 23:01:23.306053
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a non-string
    assert to_

# Generated at 2022-06-16 23:01:34.986361
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode unicode strings
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\x34'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_strict') == b'\x34'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_then_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='replace')

# Generated at 2022-06-16 23:01:46.242588
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b",\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': '), ensure_ascii=False) == '{\n    "a": "b",\n}'

# Generated at 2022-06-16 23:01:56.682861
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, sort_keys=True) == '{"a": 1}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4, separators=(',', ': '), ensure_ascii=False) == '{\n    "a": 1\n}'

# Generated at 2022-06-16 23:02:07.951090
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'test') == b'test'
    assert to_bytes(u'test', errors='strict') == b'test'
    assert to_bytes(u'test', errors='surrogate_or_strict') == b'test'
    assert to_bytes(u'test', errors='surrogate_or_replace') == b'test'
    assert to_bytes(u'test', errors='surrogate_then_replace') == b'test'

    # Test that we can encode a text string with surrogates
    assert to_bytes(u'\udc80') == b'\xed\xb2\x80'
    assert to_bytes(u'\udc80', errors='strict') == b'\xed\xb2\x80'

# Generated at 2022-06-16 23:02:15.038857
# Unit test for function to_bytes
def test_to_bytes():
    # Test that to_bytes returns a byte string
    assert isinstance(to_bytes('foo'), binary_type)
    assert isinstance(to_bytes(u'foo'), binary_type)
    assert isinstance(to_bytes(b'foo'), binary_type)

    # Test that to_bytes returns a byte string that is the same as the input
    # string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'

    # Test that to_bytes can encode unicode
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that to_bytes can encode unicode with surrogates

# Generated at 2022-06-16 23:02:22.631990
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b",\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': '), encoding="latin-1") == '{\n    "a": "b",\n}'

# Generated at 2022-06-16 23:02:35.454039
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 23:02:54.733396
# Unit test for function to_native
def test_to_native():
    """
    Test to_native()
    """
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(1) == u'1'
    assert to_native(1.1) == u'1.1'
    assert to_native(None) == u'None'
    assert to_native(dict(a=1, b=2)) == u"{'a': 1, 'b': 2}"
    assert to_native(set([1, 2, 3])) == u'[1, 2, 3]'
    assert to_native(datetime.datetime(2015, 1, 1, 1, 1, 1)) == u'2015-01-01 01:01:01'

# Generated at 2022-06-16 23:03:06.022091
# Unit test for function to_native
def test_to_native():
    """
    Test to_native function
    """
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'fóo') == 'fóo'
    assert to_native(b'f\xc3\xb3o') == 'fóo'
    assert to_native(b'f\xc3\xb3o', encoding='latin-1') == 'f\xf3o'
    assert to_native(b'f\xc3\xb3o', errors='surrogate_or_strict') == 'fóo'
    assert to_native(b'f\xc3\xb3o', errors='surrogate_or_replace') == 'fóo'

# Generated at 2022-06-16 23:03:17.321199
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a string with surrogateescape
    # We have to use a non-utf8 encoding to trigger surrogateescape
    if HAS_SURROGATEESCAPE:
        # This is the string b'\xff\xfe\xfd\xfc' encoded as utf-16
        # The first two bytes are the BOM
        # The last two bytes are encoded as surrogates
        surrogate_string = u'\ufeff\udcff\udcfc'
        assert to_bytes(surrogate_string, 'utf-16', errors='surrogateescape') == b'\xff\xfe\xfd\xfc'

    # Test that we can encode a string with surrogate_then_replace
    # We have to use a non-utf8 encoding to trigger surrogateescape

# Generated at 2022-06-16 23:03:27.994104
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8')) == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-16')) == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-32')) == u'\u2713'
    assert to_native(u'\u2713'.encode('latin-1')) == u'\u2713'
    assert to_native(u'\u2713'.encode('ascii', 'surrogateescape')) == u'\u2713'

# Generated at 2022-06-16 23:03:38.636134
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:03:50.685044
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'fóo') == u'fóo'

# Generated at 2022-06-16 23:03:59.934610
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:04:11.728744
# Unit test for function to_native
def test_to_native():
    # Test that to_native returns a native string
    assert isinstance(to_native(u'foo'), text_type)
    assert isinstance(to_native(b'foo'), text_type)
    assert isinstance(to_native(u'foo'.encode('utf-8')), text_type)
    assert isinstance(to_native(u'foo'.encode('utf-16')), text_type)
    assert isinstance(to_native(u'foo'.encode('utf-32')), text_type)
    assert isinstance(to_native(u'foo'.encode('latin-1')), text_type)

    # Test that to_native returns a native string with the right content
    assert to_native(u'foo') == u'foo'

# Generated at 2022-06-16 23:04:23.028406
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, sort_keys=True, indent=4) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1, "b": 2\n}'

# Generated at 2022-06-16 23:04:31.990355
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u2713') == '\u2713'
    assert to_native(b'\xe2\x9c\x93') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == '\u2713'

# Generated at 2022-06-16 23:04:48.591402
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": u"b"}) == '{"a": "b"}'
    assert jsonify({"a": u"\u1234"}) == '{"a": "\\u1234"}'
    assert jsonify({"a": u"\u1234".encode("latin-1")}) == '{"a": "\\u1234"}'
    assert jsonify({"a": u"\u1234".encode("utf-16")}) == '{"a": "\\u1234"}'
    assert jsonify({"a": u"\u1234".encode("utf-32")}) == '{"a": "\\u1234"}'

# Generated at 2022-06-16 23:04:55.777295
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:05:09.063811
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b",\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': '), encoding="latin-1") == '{\n    "a": "b",\n}'

# Generated at 2022-06-16 23:05:20.181347
# Unit test for function to_native
def test_to_native():
    # Test with a text string
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo', nonstring='simplerepr') == u'foo'
    assert to_native(u'foo', nonstring='passthru') == u'foo'
    assert to_native(u'foo', nonstring='empty') == u''
    assert to_native(u'foo', nonstring='strict') == u'foo'

    # Test with a byte string
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo', nonstring='simplerepr') == u'foo'
    assert to_native(b'foo', nonstring='passthru') == b'foo'
    assert to_native(b'foo', nonstring='empty') == u''

# Generated at 2022-06-16 23:05:31.688083
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:05:39.678553
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == u'foo'
    assert to_native(b'foo', errors='surrogate_then_replace') == u'foo'
    assert to_native(b'foo', errors='strict') == u'foo'
    assert to_native(b'foo', errors='replace') == u'foo'
    assert to_native(b'foo', errors='surrogateescape') == u'foo'
    assert to_native(b'foo', errors='ignore') == u'foo'
    assert to_

# Generated at 2022-06-16 23:05:50.600006
# Unit test for function to_native
def test_to_native():
    """
    Test to_native function
    """
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:06:00.642131
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=u'\u1234')) == '{"a": 1, "b": "\\u1234"}'
    assert jsonify(dict(a=1, b=u'\u1234'), ensure_ascii=False) == '{"a": 1, "b": "\\u1234"}'
    assert jsonify(dict(a=1, b=u'\u1234'), ensure_ascii=True) == '{"a": 1, "b": "\\\\u1234"}'

# Generated at 2022-06-16 23:06:12.105416
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u2713') == '\u2713'
    assert to_native(b'\xe2\x9c\x93') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == '\u2713'

# Generated at 2022-06-16 23:06:24.695930
# Unit test for function jsonify

# Generated at 2022-06-16 23:06:47.366221
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\x34\x12'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\x34\x12'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\x34\x12'

# Generated at 2022-06-16 23:06:56.050040
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:07:06.287453
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='replace') == b'?'
    assert to_bytes(u'\u1234', errors='strict') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:07:16.463247
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == 'foo'
    assert to_native('foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(1.1) == '1.1'
    assert to_native(True) == 'True'
    assert to_native(None) == 'None'
    assert to_native(dict(a=1, b=2)) == "{'a': 1, 'b': 2}"
    assert to_native(dict(a=1, b=2), format=True) == "{'a': 1, 'b': 2}"
    assert to_native(dict(a=1, b=2), format=False) == "{'a': 1, 'b': 2}"
    assert to_native

# Generated at 2022-06-16 23:07:23.903746
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:07:37.013588
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:07:44.597837
# Unit test for function to_native
def test_to_native():
    assert to_native('foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace')

# Generated at 2022-06-16 23:07:52.229767
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:08:04.339788
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='replace') == u'?'

# Generated at 2022-06-16 23:08:17.364742
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:08:52.524178
# Unit test for function to_native
def test_to_native():
    # Test with a text string
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo', 'ascii') == u'foo'
    assert to_native(u'foo', 'utf-8') == u'foo'
    assert to_native(u'foo', 'latin-1') == u'foo'
    assert to_native(u'foo', 'surrogate_or_strict') == u'foo'
    assert to_native(u'foo', 'surrogate_or_replace') == u'foo'
    assert to_native(u'foo', 'surrogate_then_replace') == u'foo'

    # Test with a byte string
    assert to_native(b'foo') == u'foo'