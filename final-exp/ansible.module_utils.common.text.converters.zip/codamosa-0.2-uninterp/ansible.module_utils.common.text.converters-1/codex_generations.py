

# Generated at 2022-06-16 22:59:10.220238
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == 'foo'
    assert to_native(u'foo', errors='surrogate_or_strict') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == 'foo'
    assert to_native(u'foo', errors='surrogate_or_replace') == 'foo'
    assert to_native(b'foo', errors='surrogate_then_replace') == 'foo'
    assert to_native(u'foo', errors='surrogate_then_replace') == 'foo'

# Generated at 2022-06-16 22:59:20.020808
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 22:59:31.671452
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_then_replace')

# Generated at 2022-06-16 22:59:44.163466
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == 'foo'
    assert to_native(u'foo', errors='surrogate_or_strict') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == 'foo'
    assert to_native(u'foo', errors='surrogate_or_replace') == 'foo'
    assert to_native(b'foo', errors='surrogate_then_replace') == 'foo'
    assert to_native(u'foo', errors='surrogate_then_replace') == 'foo'

# Generated at 2022-06-16 22:59:50.004887
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8')) == u'\u2713'
    assert to_native(b'\xe2\x9c\x93'.decode('utf-8')) == u'\u2713'
    assert to_native(u'foo', nonstring='passthru') == u'foo'
    assert to_native(b'foo', nonstring='passthru') == b'foo'
    assert to_native

# Generated at 2022-06-16 23:00:01.679836
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'

    # Test that we can encode a byte string
    assert to_bytes(b'hello') == b'hello'

    # Test that we can encode a nonstring
    assert to_bytes(5) == b'5'
    assert to_bytes(5, nonstring='passthru') == 5
    assert to_bytes(5, nonstring='empty') == b''
    assert to_bytes(5, nonstring='strict') == b'5'

    # Test that we can encode a non-ascii text string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:00:14.139571
# Unit test for function to_native
def test_to_native():
    """
    Test to_native function
    """
    from ansible.module_utils._text import to_native
    assert to_native(u'\u1234') == u'\u1234'
    assert to_native(b'\xe1\x88\xb4') == u'\u1234'
    assert to_native(b'\xe1\x88\xb4', errors='surrogate_or_strict') == u'\u1234'
    assert to_native(b'\xe1\x88\xb4', errors='surrogate_or_replace') == u'\u1234'
    assert to_native(b'\xe1\x88\xb4', errors='surrogate_then_replace') == u'\u1234'

# Generated at 2022-06-16 23:00:19.900610
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 23:00:29.340124
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:00:40.922775
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 23:00:59.551238
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='replace') == b'?'
    assert to_bytes(u'\u1234', errors='surrogateescape') == b'\xe1\x88\xb4'
    assert to_

# Generated at 2022-06-16 23:01:11.471550
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hi') == b'hi'

    # Test that we can encode a byte string
    assert to_bytes(b'hi') == b'hi'

    # Test that we can encode a non-string
    assert to_bytes(1) == b'1'

    # Test that we can encode a non-string with a nonstring strategy
    assert to_bytes(1, nonstring='passthru') == 1

    # Test that we can encode a non-string with a nonstring strategy
    assert to_bytes(1, nonstring='empty') == b''

    # Test that we can encode a non-string with a nonstring strategy
    try:
        to_bytes(1, nonstring='strict')
    except TypeError:
        pass

# Generated at 2022-06-16 23:01:19.643845
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 23:01:31.793547
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u2603') == b'\xe2\x98\x83'
    assert to_bytes(u'\u2603', encoding='ascii') == b'?'
    assert to_bytes(u'\u2603', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u2603', encoding='ascii', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\u2603', encoding='ascii', errors='surrogate_then_replace') == b'?'
    assert to_

# Generated at 2022-06-16 23:01:39.321474
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:01:51.231199
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:02:00.209553
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'

    # Test that we can encode a string with non-ascii characters
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\x34\x12'

    # Test that we can encode a string with surrogates
    assert to_bytes(u'\udc80') == b'\xed\xb2\x80'

# Generated at 2022-06-16 23:02:12.321210
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a text string with surrogates
    assert to

# Generated at 2022-06-16 23:02:21.001456
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(u'\u2713') == '\u2713'
    assert to_native(b'\xe2\x9c\x93') == '\u2713'
    assert to_native(u'\u2713'.encode('utf-16')) == '\u2713'
    assert to_native(u'\u2713'.encode('utf-16-be')) == '\u2713'
    assert to_native(u'\u2713'.encode('utf-16-le')) == '\u2713'
    assert to_native(u'\u2713'.encode('utf-32')) == '\u2713'
   

# Generated at 2022-06-16 23:02:33.333721
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd', 'e': u'\u2713'}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": "\u2713"}'
    data = {'a': 'b', 'c': 'd', 'e': u'\u2713'}
    assert jsonify(data, ensure_ascii=False) == '{"a": "b", "c": "d", "e": "\\u2713"}'
    data = {'a': 'b', 'c': 'd', 'e': u'\u2713'}
    assert json

# Generated at 2022-06-16 23:03:00.808796
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(u'foo', errors='surrogate_or_strict') == u'foo'
    assert to_

# Generated at 2022-06-16 23:03:09.808207
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', encoding='latin-1') == b'\xcf\xbf\xd0\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    assert to

# Generated at 2022-06-16 23:03:17.670791
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=2) == '{\n  "a": 1, \n  "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": 1, "b": 2\n}'

# Generated at 2022-06-16 23:03:28.611707
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:03:32.813652
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(b'\xe2\x98\x83') == u'\u2603'
    assert to_native(u'\u2603') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_or_strict') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_or_replace') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_then_replace') == u'\u2603'

# Generated at 2022-06-16 23:03:40.617577
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode unicode strings
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

# Generated at 2022-06-16 23:03:52.522208
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:04:03.412871
# Unit test for function to_bytes
def test_to_bytes():
    # Test the basics
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_replace') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_strict') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_then_replace') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(b'foo', errors='surrogate_or_replace') == b'foo'
    assert to_bytes(b'foo', errors='surrogate_or_strict') == b'foo'
    assert to_bytes(b'foo', errors='surrogate_then_replace') == b'foo'

    # Test

# Generated at 2022-06-16 23:04:14.484578
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:04:25.960812
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:04:49.801207
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes('foo', encoding='ascii') == b'foo'
    assert to_bytes(u'foo', encoding='ascii') == b'foo'
    assert to_bytes('foo', encoding='latin-1') == b'foo'
    assert to_bytes(u'foo', encoding='latin-1') == b'foo'
    assert to_bytes('foo', encoding='utf-8') == b'foo'
    assert to_bytes(u'foo', encoding='utf-8') == b'foo'

    # Test that we can encode a text string with non-ascii characters

# Generated at 2022-06-16 23:04:59.725208
# Unit test for function jsonify
def test_jsonify():
    data = {'a': u'\u20ac', 'b': u'\u20ac'}
    assert jsonify(data) == '{"a": "\\u20ac", "b": "\\u20ac"}'
    data = {'a': u'\u20ac', 'b': u'\u20ac'}
    assert jsonify(data, ensure_ascii=False) == u'{"a": "\u20ac", "b": "\u20ac"}'
    data = {'a': u'\u20ac', 'b': u'\u20ac'}
    assert jsonify(data, sort_keys=True) == '{"a": "\\u20ac", "b": "\\u20ac"}'

# Generated at 2022-06-16 23:05:10.337673
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'foo'.encode('utf-16')) == u'foo'
    assert to_native(u'foo'.encode('utf-32')) == u'foo'
    assert to_native(u'foo'.encode('latin-1')) == u'foo'
    assert to_native(u'foo'.encode('ascii', 'surrogateescape')) == u'foo'
    assert to_native(u'foo'.encode('ascii', 'replace')) == u'foo'

# Generated at 2022-06-16 23:05:22.484113
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string to a byte string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\x34\x12'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_strict') == b'?'

# Generated at 2022-06-16 23:05:29.925519
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(1) == u'1'
    assert to_native(1, nonstring='passthru') == 1
    assert to_native(1, nonstring='empty') == u''
    assert to_native(1, nonstring='strict') == u'1'
    assert to_native(1, nonstring='simplerepr') == u'1'



# Generated at 2022-06-16 23:05:38.642784
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(1) == u'1'
    assert to_native(1, nonstring='passthru') == 1
    assert to_native(1, nonstring='empty') == u''
    assert to_native(1, nonstring='strict') == u'1'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:05:49.958138
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'foo') == b'foo'

    # Test that we can encode a non-string
    assert to_bytes(5) == b'5'

    # Test that we can encode a non-string with a custom error handler
    assert to_bytes(5, errors='surrogate_or_replace') == b'5'

    # Test that we can encode a non-string with a custom error handler
    assert to_bytes(5, errors='surrogate_or_strict') == b'5'

    # Test that we can encode a non-string with a custom error handler

# Generated at 2022-06-16 23:06:00.207677
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data, sort_keys=True) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data, indent=2) == '{\n  "a": "b", \n  "c": "d"\n}'
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data, separators=(',', ':')) == '{"a":"b","c":"d"}'

# Generated at 2022-06-16 23:06:11.760397
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_then_replace')

# Generated at 2022-06-16 23:06:24.259639
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode unicode strings
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode byte strings
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode non-strings

# Generated at 2022-06-16 23:06:50.375174
# Unit test for function to_native
def test_to_native():
    # Test with a byte string
    assert to_native(b'\xc3\xbc') == u'\xfc'
    assert to_native(b'\xc3\xbc', encoding='latin-1') == u'\xfc'
    assert to_native(b'\xc3\xbc', encoding='ascii') == u'\ufffd'
    assert to_native(b'\xc3\xbc', encoding='ascii', errors='surrogate_or_strict') == u'\ufffd'
    assert to_native(b'\xc3\xbc', encoding='ascii', errors='surrogate_or_replace') == u'\ufffd'

# Generated at 2022-06-16 23:06:58.043078
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_then_replace')

# Generated at 2022-06-16 23:07:08.531331
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'fóo') == 'fóo'
    assert to_native(b'f\xc3\xb3o') == 'fóo'
    assert to_native(b'f\xc3\xb3o', errors='surrogate_or_strict') == 'fóo'
    assert to_native(b'f\xc3\xb3o', errors='surrogate_or_replace') == 'fóo'
    assert to_native(b'f\xc3\xb3o', errors='surrogate_then_replace') == 'fóo'

# Generated at 2022-06-16 23:07:17.722187
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'hello') == b'hello'
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

    # Test that we can encode a nonstring
    assert to_bytes(5) == b'5'
    assert to_bytes(5, nonstring='passthru') == 5
    assert to_bytes(5, nonstring='empty') == b''

# Generated at 2022-06-16 23:07:28.263440
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a non-string
    assert to_bytes

# Generated at 2022-06-16 23:07:40.531185
# Unit test for function jsonify
def test_jsonify():
    data = {
        "a": "b",
        "c": [1, 2, 3],
        "d": {
            "e": "f",
            "g": "h"
        }
    }
    assert jsonify(data) == '{"a": "b", "c": [1, 2, 3], "d": {"e": "f", "g": "h"}}'
    assert jsonify(data, sort_keys=True) == '{"a": "b", "c": [1, 2, 3], "d": {"e": "f", "g": "h"}}'

# Generated at 2022-06-16 23:07:50.177372
# Unit test for function jsonify
def test_jsonify():
    data = {
        'a': 'foo',
        'b': 'bar',
        'c': [1, 2, 3],
        'd': {
            'e': 'baz',
            'f': 'qux'
        }
    }
    assert jsonify(data) == '{"a": "foo", "c": [1, 2, 3], "b": "bar", "d": {"e": "baz", "f": "qux"}}'
    assert jsonify(data, sort_keys=True) == '{"a": "foo", "b": "bar", "c": [1, 2, 3], "d": {"e": "baz", "f": "qux"}}'

# Generated at 2022-06-16 23:08:02.283790
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:08:10.166264
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-16 23:08:21.838151
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd', 'e': u'\u2713'}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": "\\u2713"}'
    data = {'a': 'b', 'c': 'd', 'e': u'\u2713', 'f': u'\u2714'}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": "\\u2713", "f": "\\u2714"}'

# Generated at 2022-06-16 23:08:50.333298
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(1.1) == '1.1'
    assert to_native(True) == 'True'
    assert to_native(None) == 'None'
    assert to_native(dict(a=1, b=2)) == "{'a': 1, 'b': 2}"
    assert to_native(dict(a=1, b=2), format=json.dumps) == '{"a": 1, "b": 2}'
    assert to_native(dict(a=1, b=2), format=lambda x: '<%s>' % x) == '<{"a": 1, "b": 2}>'
   