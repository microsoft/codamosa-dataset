

# Generated at 2022-06-16 22:59:11.490021
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 22:59:20.373778
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b",\n}'

# Generated at 2022-06-16 22:59:31.919748
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

    # Test that we can encode a nonstring
    assert to_bytes(1) == b'1'

    # Test that we can encode a nonstring with a nonstring strategy
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='empty') == b''
    assert to_bytes(1, nonstring='strict') == b'1'

    # Test that we can encode a nonstring with a nonstring strategy
    assert to_bytes

# Generated at 2022-06-16 22:59:40.107542
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == u'foo'
    assert to_native(u'foo') == u'foo'
    assert to_native(1) == u'1'
    assert to_native(1.1) == u'1.1'
    assert to_native(None) == u'None'
    assert to_native(dict(a=1, b=2)) == u"{'a': 1, 'b': 2}"
    assert to_native(Set([1, 2, 3])) == u'{1, 2, 3}'
    assert to_native(datetime.datetime(2017, 1, 1)) == u'2017-01-01 00:00:00'
    assert to_native(datetime.date(2017, 1, 1)) == u'2017-01-01'
    assert to

# Generated at 2022-06-16 22:59:51.474518
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": : "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': '), encoding="utf-8") == '{\n  "a": : "b"\n}'

# Generated at 2022-06-16 23:00:02.722620
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes('foo', encoding='latin-1') == b'foo'
    assert to_bytes('foo', encoding='utf-16') == b'\xff\xfe\x00f\x00o\x00o\x00'
    assert to_bytes('foo', encoding='utf-16', errors='surrogate_or_strict') == b'\xff\xfe\x00f\x00o\x00o\x00'
    assert to_bytes('foo', encoding='utf-16', errors='surrogate_or_replace') == b'\xff\xfe\x00f\x00o\x00o\x00'

# Generated at 2022-06-16 23:00:14.986856
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 23:00:25.792427
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes('\xe9') == b'\xc3\xa9'
    assert to_bytes(u'\xe9') == b'\xc3\xa9'
    assert to_bytes('\xe9', encoding='latin-1') == b'\xe9'
    assert to_bytes(u'\xe9', encoding='latin-1') == b'\xe9'

    # Test that we can decode a byte string
    assert to_bytes(b'hello') == b'hello'
    assert to_bytes(b'\xc3\xa9') == b'\xc3\xa9'

# Generated at 2022-06-16 23:00:37.218453
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='replace') == u'\ufffd'
    assert to

# Generated at 2022-06-16 23:00:46.293411
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442'.encode('utf-8')) == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:01:01.622057
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, sort_keys=True) == '{"a": 1}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4, separators=(',', ': '), encoding='latin-1') == '{\n    "a": 1\n}'

# Generated at 2022-06-16 23:01:12.940317
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:01:22.273283
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify({'a': 'b'}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({'a': 'b'}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({'a': 'b'}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b"\n}'
    assert jsonify({'a': 'b'}, sort_keys=True, indent=4, separators=(',', ': '), encoding='latin-1') == '{\n    "a": "b"\n}'

# Generated at 2022-06-16 23:01:34.192860
# Unit test for function to_native
def test_to_native():
    # Test with a text string
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(u'foo', errors='surrogate_or_replace') == u'foo'
    assert to_native(u'foo', errors='surrogate_then_replace') == u'foo'

    # Test with a byte string
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == u'foo'

# Generated at 2022-06-16 23:01:45.079119
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'foo'.encode('utf-16')) == u'foo'
    assert to_native(u'foo'.encode('utf-32')) == u'foo'
    assert to_native(u'føø'.encode('utf-8')) == u'føø'
    assert to_native(u'føø'.encode('utf-16')) == u'føø'
    assert to_native(u'føø'.encode('utf-32')) == u'føø'

# Generated at 2022-06-16 23:01:55.814334
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_then_replace')

# Generated at 2022-06-16 23:02:06.516028
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b",\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': '), encoding='latin-1') == '{\n    "a": "b",\n}'

# Generated at 2022-06-16 23:02:17.497400
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_then_replace') == b'?'

# Generated at 2022-06-16 23:02:29.944516
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a nonstring

# Generated at 2022-06-16 23:02:34.478492
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:02:54.169570
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:03:05.627346
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hello') == b'hello'
    assert to_bytes('hello', 'ascii') == b'hello'
    assert to_bytes('hello', 'utf-8') == b'hello'
    assert to_bytes('hello', 'utf-16') == b'\xff\xfel\x00l\x00o\x00'
    assert to_bytes('hello', 'utf-16-be') == b'\x00l\x00l\x00o\xff\xfe'
    assert to_bytes('hello', 'utf-16-le') == b'l\x00l\x00o\x00\xff\xfe'

# Generated at 2022-06-16 23:03:17.107180
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:03:27.749503
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\udc80') == b'\xed\xb2\x80'

# Generated at 2022-06-16 23:03:38.453069
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode unicode strings
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode byte strings
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode non-strings

# Generated at 2022-06-16 23:03:50.467802
# Unit test for function to_native
def test_to_native():
    """
    Test to_native function
    """
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(b'\xe2\x98\x83') == u'\u2603'
    assert to_native(u'\u2603') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_or_strict') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_or_replace') == u'\u2603'

# Generated at 2022-06-16 23:03:59.827149
# Unit test for function jsonify
def test_jsonify():
    # Test with a dict
    data = {'a': 'b'}
    assert jsonify(data) == '{"a": "b"}'

    # Test with a list
    data = ['a', 'b']
    assert jsonify(data) == '["a", "b"]'

    # Test with a set
    data = set(['a', 'b'])
    assert jsonify(data) == '["a", "b"]'

    # Test with a datetime
    data = datetime.datetime(2017, 1, 1)
    assert jsonify(data) == '"2017-01-01T00:00:00"'

    # Test with a unicode string
    data = u'\u00e9'
    assert jsonify(data) == '"\\u00e9"'

    # Test with a byte string

# Generated at 2022-06-16 23:04:11.677059
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": u"b"}) == '{"a": "b"}'
    assert jsonify({"a": u"\u2713"}) == '{"a": "\\u2713"}'
    assert jsonify({"a": u"\u2713".encode("utf-8")}) == '{"a": "\\u2713"}'
    assert jsonify({"a": u"\u2713".encode("latin-1")}) == '{"a": "\\u2713"}'
    assert jsonify({"a": u"\u2713".encode("ascii")}) == '{"a": "\\u2713"}'

# Generated at 2022-06-16 23:04:22.926216
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a non-string
    assert to_bytes

# Generated at 2022-06-16 23:04:31.928697
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:04:49.243505
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == u'foo'
    assert to_native(b'foo', errors='surrogate_then_replace') == u'foo'
    assert to_native(b'foo', encoding='ascii') == u'foo'
    assert to_native(b'foo', encoding='ascii', errors='surrogate_or_strict') == u'foo'
    assert to_native(b'foo', encoding='ascii', errors='surrogate_or_replace') == u'foo'
   

# Generated at 2022-06-16 23:04:53.223323
# Unit test for function to_native
def test_to_native():
    # Test that to_native works with bytes and text
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == 'foo'
    assert to_native(u'foo', errors='surrogate_or_strict') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == 'foo'
    assert to_native(u'foo', errors='surrogate_or_replace') == 'foo'
    assert to_native(b'foo', errors='surrogate_then_replace') == 'foo'
    assert to_native(u'foo', errors='surrogate_then_replace') == 'foo'

    # Test that

# Generated at 2022-06-16 23:05:06.034107
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', errors='surrogate_or_replace') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

# Generated at 2022-06-16 23:05:13.927478
# Unit test for function to_native
def test_to_native():
    """
    Test to_native function
    """
    assert to_native(b'abc', errors='surrogate_or_strict') == 'abc'
    assert to_native(b'abc', errors='surrogate_or_replace') == 'abc'
    assert to_native(b'abc', errors='surrogate_then_replace') == 'abc'
    assert to_native(u'abc', errors='surrogate_or_strict') == 'abc'
    assert to_native(u'abc', errors='surrogate_or_replace') == 'abc'
    assert to_native(u'abc', errors='surrogate_then_replace') == 'abc'
    assert to_native(b'\xe9', errors='surrogate_or_strict') == u'\xe9'
    assert to

# Generated at 2022-06-16 23:05:26.033106
# Unit test for function to_bytes
def test_to_bytes():
    # Test that to_bytes returns a byte string
    assert isinstance(to_bytes(u'foo'), binary_type)
    assert isinstance(to_bytes(b'foo'), binary_type)
    assert isinstance(to_bytes(u'foo', nonstring='passthru'), text_type)
    assert isinstance(to_bytes(b'foo', nonstring='passthru'), binary_type)

    # Test that to_bytes returns the correct value
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'foo', nonstring='passthru') == u'foo'
    assert to_bytes(b'foo', nonstring='passthru') == b'foo'

    # Test that to_bytes raises an error when

# Generated at 2022-06-16 23:05:36.204117
# Unit test for function to_native
def test_to_native():
    # Test with a byte string
    assert to_native(b'foo') == 'foo'
    assert to_native(b'foo', nonstring='passthru') == b'foo'
    assert to_native(b'foo', nonstring='empty') == ''
    assert to_native(b'foo', nonstring='strict') == 'foo'
    assert to_native(b'foo', nonstring='simplerepr') == 'foo'

    # Test with a text string
    assert to_native(u'foo') == 'foo'
    assert to_native(u'foo', nonstring='passthru') == u'foo'
    assert to_native(u'foo', nonstring='empty') == ''
    assert to_native(u'foo', nonstring='strict') == 'foo'

# Generated at 2022-06-16 23:05:46.557173
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'



# Generated at 2022-06-16 23:05:57.344458
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'hello') == b'hello'

    # Test that we can encode a nonstring
    assert to_bytes(5) == b'5'
    assert to_bytes(5, nonstring='passthru') == 5
    assert to_bytes(5, nonstring='empty') == b''
    assert to_bytes(5, nonstring='strict') == b'5'

    # Test that we can encode a non-ascii text string

# Generated at 2022-06-16 23:06:09.352613
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b",\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': '), encoding='latin-1') == '{\n    "a": "b",\n}'

# Generated at 2022-06-16 23:06:22.652299
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:06:45.945453
# Unit test for function to_native
def test_to_native():
    """
    to_native:
    """
    # Test with a byte string
    assert to_native(b'foo') == 'foo'
    # Test with a text string
    assert to_native(u'foo') == 'foo'
    # Test with a nonstring
    assert to_native(42) == '42'
    # Test with a nonstring that can't be converted to a string
    class Foo(object):
        def __str__(self):
            raise UnicodeError()
    assert to_native(Foo()) == '<ansible.module_utils._text.Foo object at 0x%x>' % id(Foo())
    # Test with a nonstring that can't be converted to a string
    class Foo(object):
        def __repr__(self):
            raise UnicodeError()
    assert to_native

# Generated at 2022-06-16 23:06:54.265675
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 1, 'b': 2, 'c': 3}
    assert jsonify(data) == '{"a": 1, "c": 3, "b": 2}'
    data = {'a': 1, 'b': 2, 'c': 3, 'd': {'e': 4, 'f': 5}}
    assert jsonify(data) == '{"a": 1, "c": 3, "b": 2, "d": {"e": 4, "f": 5}}'
    data = {'a': 1, 'b': 2, 'c': 3, 'd': {'e': 4, 'f': 5}, 'g': [6, 7, 8]}

# Generated at 2022-06-16 23:07:05.389338
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(1) == u'1'
    assert to_native(1.1) == u'1.1'
    assert to_native(True) == u'True'
    assert to_native(None) == u'None'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82')

# Generated at 2022-06-16 23:07:15.657566
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b'}
    assert jsonify(data) == '{"a": "b"}'
    data = {'a': 'b', 'c': u'\u2713'}
    assert jsonify(data) == '{"a": "b", "c": "\\u2713"}'
    data = {'a': 'b', 'c': u'\u2713'}
    assert jsonify(data, ensure_ascii=False) == '{"a": "b", "c": "✓"}'
    data = {'a': 'b', 'c': u'\u2713'}
    assert jsonify(data, sort_keys=True) == '{"a": "b", "c": "\\u2713"}'

# Generated at 2022-06-16 23:07:23.388183
# Unit test for function jsonify
def test_jsonify():
    data = {u'foo': u'bar'}
    assert jsonify(data) == '{"foo": "bar"}'
    data = {u'foo': u'bar', u'baz': [u'qux', u'quux']}
    assert jsonify(data) == '{"foo": "bar", "baz": ["qux", "quux"]}'
    data = {u'foo': u'bar', u'baz': [u'qux', u'quux'], u'corge': {u'grault': u'garply'}}
    assert jsonify(data) == '{"foo": "bar", "baz": ["qux", "quux"], "corge": {"grault": "garply"}}'

# Generated at 2022-06-16 23:07:36.492531
# Unit test for function to_native
def test_to_native():
    # Test that we can pass through a native string
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == 'foo'

    # Test that we can pass through a non-string
    assert to_native(1) == 1

    # Test that we can decode a byte string
    assert to_native(b'foo') == u'foo'

    # Test that we can encode a text string
    assert to_native(u'foo', encoding='ascii') == 'foo'

    # Test that we can encode a byte string
    assert to_native(b'foo', encoding='ascii') == 'foo'

    # Test that we can encode a non-string
    assert to_native(1, encoding='ascii') == '1'

    # Test that we can decode a text string
   

# Generated at 2022-06-16 23:07:46.274279
# Unit test for function to_native
def test_to_native():
    """
    Test to_native function
    """
    from ansible.module_utils._text import to_native
    assert to_native(u'\u1234') == u'\u1234'
    assert to_native(b'\xe1\x88\xb4') == u'\u1234'
    assert to_native(b'\xe1\x88\xb4', errors='surrogate_or_strict') == u'\u1234'
    assert to_native(b'\xe1\x88\xb4', errors='surrogate_or_replace') == u'\u1234'
    assert to_native(b'\xe1\x88\xb4', errors='surrogate_then_replace') == u'\u1234'

# Generated at 2022-06-16 23:07:57.064579
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:08:07.206923
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1, "b": 2\n}'

# Generated at 2022-06-16 23:08:18.973021
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2713') == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-8')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('latin-1')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('ascii')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-32')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16-le')) == '"\\u2713"'
   

# Generated at 2022-06-16 23:08:54.759895
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u2603') == b'\xe2\x98\x83'

    # Test that we can encode a byte string
    assert to_bytes(b'foo') == b'foo'

    # Test that we can encode a nonstring
    assert to_bytes(1) == b'1'
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='empty') == b''
    assert to_bytes(1, nonstring='strict') == b'1'

    # Test that we can encode a nonstring that has a non-ascii repr