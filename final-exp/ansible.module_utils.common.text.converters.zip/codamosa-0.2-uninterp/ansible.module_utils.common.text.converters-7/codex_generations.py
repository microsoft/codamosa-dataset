

# Generated at 2022-06-16 22:59:13.128160
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442'.encode('utf-8')) == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 22:59:21.054617
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, sort_keys=True) == '{"a": 1}'
    assert jsonify({"a": 1}, sort_keys=True, indent=2) == '{\n  "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True, indent=2, separators=(',', ': '), ensure_ascii=False) == '{\n  "a": 1\n}'

# Generated at 2022-06-16 22:59:32.161103
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 22:59:44.271981
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u2713') == '\u2713'
    assert to_native(b'\xe2\x9c\x93') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == '\u2713'

# Generated at 2022-06-16 22:59:56.190848
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

    # Test that we can encode a nonstring
    assert to_bytes(1) == b'1'
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='empty') == b''

# Generated at 2022-06-16 23:00:05.742044
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:00:17.577844
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == u'\u2713'

# Generated at 2022-06-16 23:00:27.581854
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": : "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': '), encoding="latin-1") == '{\n  "a": : "b"\n}'

# Generated at 2022-06-16 23:00:39.559010
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(1.1) == '1.1'
    assert to_native(True) == 'True'
    assert to_native(None) == 'None'
    assert to_native(dict(a=1, b=2)) == "{'a': 1, 'b': 2}"
    assert to_native(dict(a=1, b=2), format=True) == '{\n  "a": 1, \n  "b": 2\n}'

# Generated at 2022-06-16 23:00:48.919139
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:01:13.391281
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b",\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': '), encoding='latin-1') == '{\n    "a": "b",\n}'

# Generated at 2022-06-16 23:01:22.218748
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode unicode strings
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\x34'

    # Test that we can encode byte strings
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'
    assert to_bytes(b'\xe1\x88\xb4', encoding='latin-1') == b'\xe1\x88\xb4'

    # Test that we can encode non-strings
    assert to_bytes(1234) == b'1234'
    assert to_bytes(1234, nonstring='empty') == b''

# Generated at 2022-06-16 23:01:34.191610
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u2713') == '\u2713'
    assert to_native(b'\xe2\x9c\x93') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == '\u2713'

# Generated at 2022-06-16 23:01:45.030318
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='replace') == b'?'
    assert to_bytes(u'\u1234', errors='strict') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:01:55.760320
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, sort_keys=True) == '{"a": 1}'
    assert jsonify({"a": 1}, indent=4) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1}, separators=(',', ':')) == '{"a":1}'
    assert jsonify({"a": 1}, sort_keys=True, separators=(',', ':')) == '{"a":1}'

# Generated at 2022-06-16 23:02:06.352949
# Unit test for function to_bytes
def test_to_bytes():
    # Test with a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'?'

# Generated at 2022-06-16 23:02:17.376345
# Unit test for function to_native
def test_to_native():
    # Test with a text string
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo', nonstring='passthru') == u'foo'
    assert to_native(u'foo', nonstring='strict') == u'foo'
    assert to_native(u'foo', nonstring='empty') == u''
    assert to_native(u'foo', nonstring='simplerepr') == u'foo'

    # Test with a byte string
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo', nonstring='passthru') == b'foo'
    assert to_native(b'foo', nonstring='strict') == u'foo'
    assert to_native(b'foo', nonstring='empty') == u''


# Generated at 2022-06-16 23:02:29.850329
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='ignore') == b''

    # Test that we can encode a byte string
    assert to_bytes(b'hello') == b'hello'

# Generated at 2022-06-16 23:02:41.254502
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'foo'.encode('utf-16')) == u'foo'
    assert to_native(u'foo'.encode('utf-32')) == u'foo'
    assert to_native(u'foo'.encode('latin-1')) == u'foo'
    assert to_native(u'foo'.encode('ascii')) == u'foo'
    assert to_native(u'føø'.encode('utf-8')) == u'føø'
    assert to_native(u'føø'.encode('utf-16')) == u'føø'

# Generated at 2022-06-16 23:02:54.448622
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_then_replace') == b'?'

# Generated at 2022-06-16 23:03:09.977898
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, separators=(',', ':')) == '{"a":"b"}'
    assert jsonify({"a": "b"}, ensure_ascii=False) == '{"a": "b"}'
    assert jsonify({"a": "b"}, check_circular=False) == '{"a": "b"}'
    assert jsonify({"a": "b"}, allow_nan=False) == '{"a": "b"}'

# Generated at 2022-06-16 23:03:19.110348
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(u'\u2713') == '\u2713'
    assert to_native(b'\xe2\x9c\x93') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == '\u2713'

# Generated at 2022-06-16 23:03:31.387233
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:03:39.992981
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

    # Test that we can encode a nonstring
    assert to_bytes(1) == b'1'
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='empty') == b''

# Generated at 2022-06-16 23:03:52.223537
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode unicode strings
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode byte strings
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode non-strings

# Generated at 2022-06-16 23:04:03.168895
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a string
    assert to_bytes('foo') == b'foo'

    # Test that we can decode a byte string
    assert to_bytes(b'foo') == b'foo'

    # Test that we can decode a byte string with non-ascii characters
    assert to_bytes(b'\xc3\xa9') == b'\xc3\xa9'

    # Test that we can decode a text string with non-ascii characters
    assert to_bytes(u'\xe9') == b'\xc3\xa9'

    # Test that we can decode a text string with non-ascii characters
    assert to_bytes(u'\u03b1') == b'\xce\xb1'

    # Test that we can decode a text string with non-ascii characters

# Generated at 2022-06-16 23:04:14.204103
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:04:25.734042
# Unit test for function jsonify

# Generated at 2022-06-16 23:04:33.320855
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict', encoding='ascii')

# Generated at 2022-06-16 23:04:45.732027
# Unit test for function to_native
def test_to_native():
    # Test that to_native returns a native string
    assert isinstance(to_native(u'foo'), str)
    assert isinstance(to_native(b'foo'), str)
    assert isinstance(to_native(u'foo'.encode('utf-8')), str)
    assert isinstance(to_native(u'foo'.encode('latin-1')), str)

    # Test that to_native returns a string with the correct contents
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo'.encode('utf-8')) == 'foo'
    assert to_native(u'foo'.encode('latin-1')) == 'foo'

    # Test that to_native can handle non-string objects


# Generated at 2022-06-16 23:05:09.318285
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b", "c": "d"}) == '{"a": "b", "c": "d"}'
    assert jsonify({"a": "b", "c": "d", "e": "f"}) == '{"a": "b", "c": "d", "e": "f"}'
    assert jsonify({"a": "b", "c": "d", "e": "f", "g": "h"}) == '{"a": "b", "c": "d", "e": "f", "g": "h"}'

# Generated at 2022-06-16 23:05:20.833052
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_then_replace')

# Generated at 2022-06-16 23:05:32.171430
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd', 'e': Set([1, 2, 3])}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": [1, 2, 3]}'
    data = {'a': 'b', 'c': 'd', 'e': datetime.datetime(2015, 1, 1)}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": "2015-01-01T00:00:00"}'

# Generated at 2022-06-16 23:05:39.974486
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'foo'.encode('utf-16')) == u'foo'
    assert to_native(u'foo'.encode('utf-32')) == u'foo'
    assert to_native(u'foo'.encode('latin-1')) == u'foo'
    assert to_native(u'føø'.encode('utf-8')) == u'føø'
    assert to_native(u'føø'.encode('utf-16')) == u'føø'
    assert to_native(u'føø'.encode('utf-32')) == u'føø'

# Generated at 2022-06-16 23:05:50.892375
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u1234') == '"\\u1234"'
    assert jsonify(u'\u1234'.encode('latin-1')) == '"\\u1234"'
    assert jsonify(u'\u1234'.encode('utf-16')) == '"\\u1234"'
    assert jsonify(u'\u1234'.encode('utf-32')) == '"\\u1234"'
    assert jsonify(u'\u1234'.encode('utf-16-be')) == '"\\u1234"'
    assert jsonify(u'\u1234'.encode('utf-16-le')) == '"\\u1234"'

# Generated at 2022-06-16 23:06:00.822526
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:06:12.238161
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:06:24.789685
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'føø') == u'føø'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'f\xc3\xb8\xc3\xb8') == u'føø'
    assert to_native(b'f\xc3\xb8\xc3\xb8', errors='surrogate_or_strict') == u'føø'
    assert to_native(b'f\xc3\xb8\xc3\xb8', errors='surrogate_or_replace') == u'føø'

# Generated at 2022-06-16 23:06:33.302066
# Unit test for function to_native
def test_to_native():
    # Test that to_native returns a native string
    assert isinstance(to_native(u'foo'), str)
    assert isinstance(to_native(b'foo'), str)
    assert isinstance(to_native(u'foo'.encode('utf-8')), str)
    assert isinstance(to_native(u'foo'.encode('utf-16')), str)
    assert isinstance(to_native(u'foo'.encode('utf-32')), str)
    assert isinstance(to_native(u'foo'.encode('latin-1')), str)
    assert isinstance(to_native(u'foo'.encode('ascii')), str)
    assert isinstance(to_native(u'foo'.encode('cp037')), str)

# Generated at 2022-06-16 23:06:46.132490
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(u'foo', encoding='utf-8') == u'foo'

# Generated at 2022-06-16 23:07:16.821641
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\x34'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='replace') == b'?'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='ignore') == b''
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_replace') == b'?'

# Generated at 2022-06-16 23:07:24.116230
# Unit test for function jsonify
def test_jsonify():
    data = {u'foo': u'bar', u'baz': u'qux'}
    assert jsonify(data) == '{"foo": "bar", "baz": "qux"}'
    data = {u'foo': u'bar', u'baz': u'qux', u'list': [u'a', u'b', u'c']}
    assert jsonify(data) == '{"foo": "bar", "baz": "qux", "list": ["a", "b", "c"]}'
    data = {u'foo': u'bar', u'baz': u'qux', u'list': [u'a', u'b', u'c'], u'set': set([u'a', u'b', u'c'])}

# Generated at 2022-06-16 23:07:37.189857
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": u"b"}) == '{"a": "b"}'
    assert jsonify({"a": u"\u2713"}) == '{"a": "\\u2713"}'
    assert jsonify({"a": u"\u2713".encode("utf-8")}) == '{"a": "\\u2713"}'
    assert jsonify({"a": u"\u2713".encode("latin-1")}) == '{"a": "\\u2713"}'
    assert jsonify({"a": u"\u2713".encode("utf-16")}) == '{"a": "\\u2713"}'

# Generated at 2022-06-16 23:07:44.671343
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode unicode strings
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode byte strings
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode non-strings

# Generated at 2022-06-16 23:07:52.250735
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'\xe2\x98\x83') == u'\u2603'
    assert to_native(u'\u2603') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_or_strict') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_or_replace') == u'\u2603'
    assert to_native(b'\xe2\x98\x83', errors='surrogate_then_replace') == u'\u2603'

# Generated at 2022-06-16 23:08:04.341356
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can decode a byte string
    assert to_bytes(b'hello') == b'hello'

    # Test that we can decode a byte string with non-ascii characters
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

    # Test that we can decode a byte string with non-ascii characters
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

    # Test that

# Generated at 2022-06-16 23:08:17.323437
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u2713') == '\u2713'
    assert to_native(b'\xe2\x9c\x93') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == '\u2713'

# Generated at 2022-06-16 23:08:21.382607
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(1.1) == '1.1'
    assert to_native(None) == 'None'
    assert to_native(dict(a=1)) == "{'a': 1}"
    assert to_native(dict(a=1), format=True) == "{'a': 1}"
    assert to_native(dict(a=1), format=False) == "{'a': 1}"
    assert to_native(dict(a=1), format=None) == "{'a': 1}"
    assert to_native(dict(a=1), format=0) == "{'a': 1}"

# Generated at 2022-06-16 23:08:29.804280
# Unit test for function to_native
def test_to_native():
    # Test with a byte string
    assert to_native(b'foo') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == 'foo'
    assert to_native(b'foo', errors='surrogate_then_replace') == 'foo'
    assert to_native(b'foo', encoding='ascii') == 'foo'
    assert to_native(b'foo', encoding='ascii', errors='surrogate_or_strict') == 'foo'
    assert to_native(b'foo', encoding='ascii', errors='surrogate_or_replace') == 'foo'

# Generated at 2022-06-16 23:08:39.589621
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a utf-8 string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a latin-1 string
    assert to_bytes(u'\u00e9', encoding='latin-1') == b'\xe9'

    # Test that we can encode a string with surrogates
    assert to_bytes(u'\ud800\udc00', encoding='utf-16-be') == b'\x00\xd8\x00\xdc'

    # Test that we can encode a string with surrogates using surrogateescape