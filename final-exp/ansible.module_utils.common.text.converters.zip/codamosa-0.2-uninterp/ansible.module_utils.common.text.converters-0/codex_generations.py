

# Generated at 2022-06-16 22:59:04.586598
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == u'foo'
    assert to_native(b'foo', errors='surrogate_then_replace') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == u'foo'
    assert to_native(b'foo', errors='surrogate_then_replace') == u'foo'

# Generated at 2022-06-16 22:59:14.174659
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes('foo', encoding='ascii') == b'foo'
    assert to_bytes('foo', encoding='utf-8') == b'foo'
    assert to_bytes('foo', encoding='utf-16') == b'\xff\xfe\x00f\x00o\x00o\x00'
    assert to_bytes('foo', encoding='utf-32') == b'\xff\xfe\x00\x00\x00f\x00\x00\x00o\x00\x00\x00o\x00\x00\x00'

    # Test that we can encode a text string with non-ascii characters

# Generated at 2022-06-16 22:59:21.922479
# Unit test for function to_native
def test_to_native():
    # Test with a text string
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo', nonstring='passthru') == u'foo'
    assert to_native(u'foo', nonstring='strict') == u'foo'

    # Test with a byte string
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo', nonstring='passthru') == b'foo'
    assert to_native(b'foo', nonstring='strict') == b'foo'

    # Test with a nonstring
    assert to_native(1) == u'1'
    assert to_native(1, nonstring='passthru') == 1
    assert to_native(1, nonstring='strict') == u'1'

   

# Generated at 2022-06-16 22:59:30.200315
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, sort_keys=True) == '{"a": 1}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4, separators=(',', ': '), encoding="latin-1") == '{\n    "a": 1\n}'

# Generated at 2022-06-16 22:59:39.047899
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 22:59:50.929233
# Unit test for function to_bytes
def test_to_bytes():
    # Test that to_bytes returns a byte string
    assert isinstance(to_bytes('foo'), binary_type)

    # Test that to_bytes returns the same byte string
    assert to_bytes(b'foo') == b'foo'

    # Test that to_bytes returns a byte string when passed a text string
    assert isinstance(to_bytes(u'foo'), binary_type)

    # Test that to_bytes returns a byte string when passed a nonstring
    assert isinstance(to_bytes(1), binary_type)

    # Test that to_bytes returns a byte string when passed a nonstring
    assert isinstance(to_bytes(1), binary_type)

    # Test that to_bytes returns a byte string when passed a nonstring
    assert isinstance(to_bytes(1), binary_type)

    # Test that to_bytes returns

# Generated at 2022-06-16 22:59:56.554796
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b'}
    assert jsonify(data) == '{"a": "b"}'
    data = {'a': u'\u2713'}
    assert jsonify(data) == '{"a": "\\u2713"}'
    data = {'a': u'\u2713'.encode('utf-8')}
    assert jsonify(data) == '{"a": "\\u2713"}'
    data = {'a': u'\u2713'.encode('latin-1')}
    assert jsonify(data) == '{"a": "\\u2713"}'
    data = {'a': u'\u2713'.encode('ascii')}
    assert jsonify(data) == '{"a": "?"}'

# Generated at 2022-06-16 23:00:06.035790
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd', 'e': Set([1, 2, 3])}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": [1, 2, 3]}'
    data = {'a': 'b', 'c': 'd', 'e': datetime.datetime(2017, 1, 1, 1, 1, 1)}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": "2017-01-01T01:01:01"}'

# Generated at 2022-06-16 23:00:17.853124
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data, sort_keys=True) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data, indent=4) == '{\n    "a": "b",\n    "c": "d"\n}'
    data = {'a': 'b', 'c': 'd'}

# Generated at 2022-06-16 23:00:28.488393
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, separators=(',', ':')) == '{"a":1,"b":2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, separators=(',', ': ')) == '{"a": 1, "b": 2}'

# Generated at 2022-06-16 23:00:44.232232
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd', 'e': Set([1, 2, 3])}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": [1, 2, 3]}'
    data = {'a': 'b', 'c': 'd', 'e': datetime.datetime(2017, 1, 1, 1, 1, 1)}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": "2017-01-01T01:01:01"}'

# Generated at 2022-06-16 23:00:56.144862
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:01:08.251702
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:01:18.401021
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a non-string
    assert to_

# Generated at 2022-06-16 23:01:29.363153
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 23:01:38.513889
# Unit test for function jsonify
def test_jsonify():
    data = {u'foo': u'bar', u'baz': [1, 2, 3], u'blong': True, u'nonesuch': None}
    assert jsonify(data) == '{"foo": "bar", "baz": [1, 2, 3], "blong": true, "nonesuch": null}'
    assert jsonify(data, sort_keys=True) == '{"baz": [1, 2, 3], "blong": true, "foo": "bar", "nonesuch": null}'
    assert jsonify(data, indent=4) == '{\n    "foo": "bar", \n    "baz": [\n        1, \n        2, \n        3\n    ], \n    "blong": true, \n    "nonesuch": null\n}'


# Generated at 2022-06-16 23:01:50.431151
# Unit test for function jsonify
def test_jsonify():
    data = {u'foo': u'bar', u'baz': u'\xe9'}
    assert jsonify(data) == '{"foo": "bar", "baz": "\\u00e9"}'
    assert jsonify(data, ensure_ascii=False) == '{"foo": "bar", "baz": "é"}'
    assert jsonify(data, sort_keys=True) == '{"baz": "\\u00e9", "foo": "bar"}'
    assert jsonify(data, indent=4) == '{\n    "foo": "bar", \n    "baz": "\\u00e9"\n}'
    assert jsonify(data, separators=(',', ':')) == '{"foo":"bar","baz":"\\u00e9"}'

# Generated at 2022-06-16 23:01:59.599580
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:02:12.209763
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

    # Test that we can encode a nonstring
    assert to_bytes(1) == b'1'
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='empty') == b''

# Generated at 2022-06-16 23:02:20.935819
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string to bytes
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can decode a byte string to bytes
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

    # Test that we can encode a text string with surrogates to bytes
    assert to_bytes(u'\udcc3\udca3') == b'\xe1\x88\xb4'

    # Test that we can decode a byte string with surrogates to bytes
    assert to_bytes(b'\xed\xb3\x83\xed\xba\xa3') == b'\xe1\x88\xb4'

    # Test that we can encode a text string

# Generated at 2022-06-16 23:02:38.388091
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({'a': 'b'}) == '{"a": "b"}'
    assert jsonify({'a': 'b', 'c': 'd'}) == '{"a": "b", "c": "d"}'
    assert jsonify({'a': 'b', 'c': 'd'}, sort_keys=True) == '{"a": "b", "c": "d"}'
    assert jsonify({'a': 'b', 'c': 'd'}, sort_keys=True, indent=2) == '{\n  "a": "b", \n  "c": "d"\n}'

# Generated at 2022-06-16 23:02:45.363470
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:02:58.222230
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string

# Generated at 2022-06-16 23:03:08.087098
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='ignore') == b''

# Generated at 2022-06-16 23:03:18.076011
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a non-string
    assert to_

# Generated at 2022-06-16 23:03:29.145304
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:03:39.242713
# Unit test for function to_bytes
def test_to_bytes():
    # Test that it returns a byte string
    assert isinstance(to_bytes(u'foo'), binary_type)
    assert isinstance(to_bytes(u'foo', nonstring='passthru'), text_type)
    assert isinstance(to_bytes(u'foo', nonstring='empty'), binary_type)
    assert isinstance(to_bytes(u'foo', nonstring='strict'), binary_type)

    # Test that it returns the correct value
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo', nonstring='passthru') == u'foo'
    assert to_bytes(u'foo', nonstring='empty') == b''
    assert to_bytes(u'foo', nonstring='strict') == b'foo'

    # Test that it handles nonstrings


# Generated at 2022-06-16 23:03:44.147095
# Unit test for function jsonify
def test_jsonify():
    data = {u'a': u'\u00e4', u'b': u'\u00e4'}
    assert jsonify(data) == '{"a": "\\u00e4", "b": "\\u00e4"}'



# Generated at 2022-06-16 23:03:55.116656
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes('foo', encoding='ascii') == b'foo'
    assert to_bytes('foo', encoding='latin-1') == b'foo'
    assert to_bytes('foo', encoding='utf-8') == b'foo'
    assert to_bytes('foo', encoding='utf-16') == b'\xff\xfe\x00f\x00o\x00o\x00'
    assert to_bytes('foo', encoding='utf-32') == b'\xff\xfe\x00\x00\x00f\x00\x00\x00o\x00\x00\x00o\x00\x00\x00'

    # Test that we can encode a byte string


# Generated at 2022-06-16 23:04:05.736570
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:04:21.940338
# Unit test for function jsonify
def test_jsonify():
    data = {
        'a': 'a',
        'b': u'b',
        'c': [1, 2, 3],
        'd': {
            'e': u'e',
            'f': 'f',
            'g': [u'g', 'h'],
            'h': {
                'i': u'i',
                'j': 'j',
            }
        }
    }
    assert jsonify(data) == '{"a": "a", "c": [1, 2, 3], "b": "b", "d": {"e": "e", "g": ["g", "h"], "f": "f", "h": {"i": "i", "j": "j"}}}'

# Generated at 2022-06-16 23:04:31.291004
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string with a different encoding
   

# Generated at 2022-06-16 23:04:43.643148
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode text strings
    assert to_bytes(u'abc') == b'abc'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='utf-16') == b'\xff\xfe4\x12'
    assert to_bytes(u'\u1234', encoding='utf-16-be') == b'4\x12'
    assert to_bytes(u'\u1234', encoding='utf-16-le') == b'\x124'
    assert to_bytes(u'\u1234', encoding='utf-32') == b'\xff\xfe\x00\x004\x12\x00\x00'

# Generated at 2022-06-16 23:04:52.810658
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_strict') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:05:05.507272
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:05:12.112719
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:05:24.262621
# Unit test for function to_native
def test_to_native():
    # Test that to_native works with unicode
    assert to_native(u'\u2713') == u'\u2713'
    # Test that to_native works with bytes
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    # Test that to_native works with non-string types
    assert to_native(True) == u'True'
    # Test that to_native works with non-string types that have a __unicode__ method
    class Foo(object):
        def __unicode__(self):
            return u'foo'
    assert to_native(Foo()) == u'foo'
    # Test that to_native works with non-string types that have a __str__ method

# Generated at 2022-06-16 23:05:34.936348
# Unit test for function to_bytes
def test_to_bytes():
    # Test with a text string
    assert to_bytes('abc') == b'abc'
    assert to_bytes(u'abc') == b'abc'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_replace') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:05:46.603053
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(1) == u'1'
    assert to_native(1, nonstring='passthru') == 1
    assert to_native(1, nonstring='empty') == u''
    assert to_native(1, nonstring='strict') == u'1'
    assert to_native(u'\u1234') == u'\u1234'
    assert to_native(b'\xe1\x88\xb4', encoding='utf-8') == u'\u1234'
    assert to_native(b'\xe1\x88\xb4', encoding='utf-8', errors='surrogate_or_strict') == u'\u1234'

# Generated at 2022-06-16 23:05:57.344351
# Unit test for function jsonify

# Generated at 2022-06-16 23:06:13.142358
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode unicode strings
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_then_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='ignore') == b

# Generated at 2022-06-16 23:06:25.577977
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='ignore') == u''

# Generated at 2022-06-16 23:06:33.876363
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2713') == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('latin-1')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-32')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-32-be')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-32-le')) == '"\\u2713"'

# Generated at 2022-06-16 23:06:46.619594
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:06:55.546912
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2713') == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-8')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('latin-1')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('ascii')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('ascii'), ensure_ascii=False) == '"\u2713"'
    assert jsonify(u'\u2713'.encode('ascii'), ensure_ascii=False, encoding='latin-1') == '"\u2713"'

# Generated at 2022-06-16 23:07:05.923013
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == u'\u2713'

# Generated at 2022-06-16 23:07:16.135422
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=2) == '{\n  "a": 1, \n  "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": 1, "b": 2\n}'

# Generated at 2022-06-16 23:07:23.721846
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": : "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': '), encoding="latin-1") == '{\n  "a": : "b"\n}'

# Generated at 2022-06-16 23:07:36.798039
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(1.1) == '1.1'
    assert to_native(True) == 'True'
    assert to_native(None) == 'None'
    assert to_native(dict(a=1, b=2)) == "{'a': 1, 'b': 2}"
    assert to_native(dict(a=1, b=2), format=True) == "{'a': 1,\n 'b': 2}"
    assert to_native(['a', 'b']) == "['a', 'b']"

# Generated at 2022-06-16 23:07:44.473811
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(1, nonstring='passthru') == 1
    assert to_native(1, nonstring='empty') == ''
    assert to_native(1, nonstring='strict') == '1'
    assert to_native(None) == 'None'
    assert to_native(None, nonstring='passthru') == None
    assert to_native(None, nonstring='empty') == ''
    assert to_native(None, nonstring='strict') == 'None'

# Generated at 2022-06-16 23:08:06.680021
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string to bytes
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string to bytes
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a nonstring to bytes


# Generated at 2022-06-16 23:08:18.614733
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:08:28.376372
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == u'foo'
    assert to_native(b'foo', errors='surrogate_then_replace') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_strict', nonstring='empty') == u''
    assert to_native(b'foo', errors='surrogate_or_replace', nonstring='empty') == u''
    assert to_native(b'foo', errors='surrogate_then_replace', nonstring='empty') == u''


# Generated at 2022-06-16 23:08:38.889649
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u2713') == '\u2713'
    assert to_native(b'\xe2\x9c\x93') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == '\u2713'

# Generated at 2022-06-16 23:08:51.184086
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1, "b": 2}) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify({"a": 1, "b": 2}, sort_keys=True, indent=4) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify({"a": 1, "b": 2}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1, "b": 2\n}'