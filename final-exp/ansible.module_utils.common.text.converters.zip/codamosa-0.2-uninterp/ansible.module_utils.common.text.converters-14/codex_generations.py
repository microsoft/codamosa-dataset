

# Generated at 2022-06-16 22:59:04.446844
# Unit test for function to_bytes
def test_to_bytes():
    # Test that to_bytes returns a byte string
    assert isinstance(to_bytes('foo'), binary_type)

    # Test that to_bytes returns the same byte string
    assert to_bytes(b'foo') == b'foo'

    # Test that to_bytes returns the same byte string when passed unicode
    assert to_bytes(u'foo') == b'foo'

    # Test that to_bytes returns the same byte string when passed unicode with surrogates
    assert to_bytes(u'\U0001f4a9') == b'\xf0\x9f\x92\xa9'

    # Test that to_bytes returns the same byte string when passed unicode with surrogates
    # and surrogate_or_replace
    assert to_bytes(u'\U0001f4a9', errors='surrogate_or_replace')

# Generated at 2022-06-16 22:59:14.081437
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_replace') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_or_strict') == b'foo'
    assert to_bytes(u'foo', errors='surrogate_then_replace') == b'foo'
    assert to_bytes(u'foo', errors='replace') == b'foo'
    assert to_bytes(u'foo', errors='surrogateescape') == b'foo'
    assert to_bytes(u'foo', errors='ignore') == b'foo'
    assert to_bytes(u'foo', errors='xmlcharrefreplace') == b'foo'

# Generated at 2022-06-16 22:59:21.887779
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent="\t") == '{\n\t"a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent="\t", separators=(",", ":")) == '{\n\t"a":"b"\n}'

# Generated at 2022-06-16 22:59:30.134354
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == u'\u2713'

# Generated at 2022-06-16 22:59:38.984088
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 22:59:50.819711
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == '\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442'.encode('utf-8')) == '\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:00:02.170471
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(1) == u'1'
    assert to_native(1, nonstring='passthru') == 1
    assert to_native(1, nonstring='empty') == u''
    assert to_native(1, nonstring='strict') == u'1'
    assert to_native(1, nonstring='simplerepr') == u'1'
    assert to_native(None) == u'None'
    assert to_native(None, nonstring='passthru') == None
    assert to_native(None, nonstring='empty') == u''
    assert to_native(None, nonstring='strict') == u'None'

# Generated at 2022-06-16 23:00:14.779703
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'hello') == b'hello'
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

    # Test that we can encode a nonstring
    assert to_bytes(5) == b'5'
    assert to_bytes(5, nonstring='passthru') == 5
    assert to_bytes(5, nonstring='empty') == b''

# Generated at 2022-06-16 23:00:25.662280
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent="\t") == '{\n\t"a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=None) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent="") == '{"a": "b"}'

# Generated at 2022-06-16 23:00:37.058525
# Unit test for function to_bytes
def test_to_bytes():
    # Test that to_bytes returns a byte string
    assert isinstance(to_bytes(u'foo'), binary_type)
    assert isinstance(to_bytes(u'foo', nonstring='passthru'), text_type)
    assert isinstance(to_bytes(u'foo', nonstring='empty'), binary_type)
    assert isinstance(to_bytes(u'foo', nonstring='strict'), binary_type)
    assert isinstance(to_bytes(u'foo', nonstring='simplerepr'), binary_type)

    # Test that to_bytes returns the correct value
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo', nonstring='passthru') == u'foo'
    assert to_bytes(u'foo', nonstring='empty') == b''

# Generated at 2022-06-16 23:01:00.087356
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:01:11.956490
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 23:01:20.258650
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'fóo') == b'f\xc3\xb3o'
    assert to_bytes(u'fóo', encoding='latin-1') == b'f\xf3o'
    assert to_bytes(u'fóo', encoding='latin-1', errors='replace') == b'f?o'
    assert to_bytes(u'fóo', encoding='latin-1', errors='surrogate_or_replace') == b'f?o'

# Generated at 2022-06-16 23:01:32.532768
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:01:39.644076
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(1) == 1
    assert to_native(1.0) == 1.0
    assert to_native(None) is None
    assert to_native(True) is True
    assert to_native(False) is False
    assert to_native(set([1, 2, 3])) == set([1, 2, 3])
    assert to_native(['foo', 'bar']) == ['foo', 'bar']
    assert to_native({'foo': 'bar'}) == {'foo': 'bar'}
    assert to_native(datetime.datetime(2015, 1, 1)) == datetime.datetime(2015, 1, 1)

# Generated at 2022-06-16 23:01:51.323544
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == u'foo'
    assert to_native(b'foo', errors='surrogate_then_replace') == u'foo'
    assert to_native(u'\u1234') == u'\u1234'
    assert to_native(b'\xe1\x88\xb4', errors='surrogate_or_strict') == u'\u1234'
    assert to_native(b'\xe1\x88\xb4', errors='surrogate_or_replace')

# Generated at 2022-06-16 23:02:01.085135
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'foo'.encode('utf-16')) == u'foo'
    assert to_native(u'foo'.encode('utf-32')) == u'foo'
    assert to_native(u'føø'.encode('utf-8')) == u'føø'
    assert to_native(u'føø'.encode('utf-16')) == u'føø'
    assert to_native(u'føø'.encode('utf-32')) == u'føø'

# Generated at 2022-06-16 23:02:13.145396
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b'}
    assert jsonify(data) == '{"a": "b"}'
    assert jsonify(data, sort_keys=True) == '{"a": "b"}'
    assert jsonify(data, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify(data, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b"\n}'
    assert jsonify(data, sort_keys=True, indent=4, separators=(',', ': '), ensure_ascii=False) == '{\n    "a": "b"\n}'

# Generated at 2022-06-16 23:02:21.468006
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u6c49') == b'\xe6\xb1\x89'

    # Test that we can encode a byte string
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(b'\xe6\xb1\x89') == b'\xe6\xb1\x89'

    # Test that we can encode a nonstring
    assert to_bytes(1) == b'1'
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='empty') == b''

# Generated at 2022-06-16 23:02:33.744906
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode unicode strings
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode byte strings
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode non-strings

# Generated at 2022-06-16 23:02:59.656410
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes('foo', encoding='ascii') == b'foo'
    assert to_bytes('foo', encoding='utf-8') == b'foo'
    assert to_bytes('foo', encoding='utf-16') == b'\xff\xfe\x00f\x00o\x00o\x00'
    assert to_bytes('foo', encoding='utf-16', errors='surrogate_or_strict') == b'\xff\xfe\x00f\x00o\x00o\x00'

# Generated at 2022-06-16 23:03:09.360044
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'foo') == b'foo'

    # Test that we can encode a nonstring
    assert to_bytes(1) == b'1'
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='empty') == b''
    assert to_bytes(1, nonstring='strict') == b'1'

    # Test that we can encode a nonstring with surrogates

# Generated at 2022-06-16 23:03:18.833240
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='replace') == u'\ufffd'
    assert to

# Generated at 2022-06-16 23:03:30.986530
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": : "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': '), encoding='latin-1') == '{\n  "a": : "b"\n}'

# Generated at 2022-06-16 23:03:39.828896
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes('foo', encoding='latin-1') == b'foo'
    assert to_bytes('foo', encoding='utf-16') == b'\xff\xfe\x00f\x00o\x00o\x00'
    assert to_bytes('foo', encoding='utf-16', errors='surrogate_or_replace') == b'\xff\xfe\x00f\x00o\x00o\x00'
    assert to_bytes('foo', encoding='utf-16', errors='surrogate_or_strict') == b'\xff\xfe\x00f\x00o\x00o\x00'

# Generated at 2022-06-16 23:03:52.124288
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'foo'.encode('utf-16')) == u'foo'
    assert to_native(u'foo'.encode('utf-32')) == u'foo'
    assert to_native(u'foo'.encode('latin-1')) == u'foo'
    assert to_native(u'føø'.encode('utf-8')) == u'føø'
    assert to_native(u'føø'.encode('utf-16')) == u'føø'
    assert to_native(u'føø'.encode('utf-32')) == u'føø'

# Generated at 2022-06-16 23:04:03.073683
# Unit test for function jsonify
def test_jsonify():
    data = {u'a': u'\u20ac'}
    assert jsonify(data) == '{"a": "\\u20ac"}'
    data = {u'a': u'\u20ac'}
    assert jsonify(data, ensure_ascii=False) == u'{"a": "\u20ac"}'
    data = {u'a': u'\u20ac'}
    assert jsonify(data, sort_keys=True) == '{"a": "\\u20ac"}'
    data = {u'a': u'\u20ac'}
    assert jsonify(data, indent=4) == '{\n    "a": "\\u20ac"\n}'
    data = {u'a': u'\u20ac'}

# Generated at 2022-06-16 23:04:14.124895
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a nonstring

# Generated at 2022-06-16 23:04:25.643138
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u2713') == '\u2713'
    assert to_native(b'\xe2\x9c\x93') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == '\u2713'

# Generated at 2022-06-16 23:04:33.274112
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a non-string
    assert to_

# Generated at 2022-06-16 23:05:08.709954
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:05:15.401966
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b'}
    assert jsonify(data) == '{"a": "b"}'
    data = {'a': u'\u00e9'}
    assert jsonify(data) == '{"a": "\\u00e9"}'
    data = {'a': u'\u00e9'.encode('latin-1')}
    assert jsonify(data) == '{"a": "\\u00e9"}'
    data = {'a': u'\u00e9'.encode('utf-8')}
    assert jsonify(data) == '{"a": "\\u00e9"}'
    data = {'a': u'\u00e9'.encode('utf-16')}

# Generated at 2022-06-16 23:05:27.463078
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8')) == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-16')) == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-32')) == u'\u2713'
    assert to_native(u'\u2713'.encode('latin-1')) == u'\u2713'
    assert to_native(u'\u2713'.encode('ascii')) == u'\u2713'

# Generated at 2022-06-16 23:05:37.203291
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=u'\u20ac')) == '{"a": 1, "b": "\\u20ac"}'
    assert jsonify(dict(a=1, b=u'\u20ac'), ensure_ascii=False) == u'{"a": 1, "b": "\u20ac"}'
    assert jsonify(dict(a=1, b=u'\u20ac'), ensure_ascii=False, encoding='latin-1') == u'{"a": 1, "b": "\u20ac"}'

# Generated at 2022-06-16 23:05:48.649627
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a text string with surrogates
    assert to

# Generated at 2022-06-16 23:05:59.192740
# Unit test for function jsonify
def test_jsonify():
    # Test with a dict
    data = {'a': 'b'}
    assert jsonify(data) == '{"a": "b"}'

    # Test with a list
    data = ['a', 'b']
    assert jsonify(data) == '["a", "b"]'

    # Test with a set
    data = set(['a', 'b'])
    assert jsonify(data) == '["a", "b"]'

    # Test with a datetime
    data = datetime.datetime(2016, 1, 1, 12, 0, 0)
    assert jsonify(data) == '"2016-01-01T12:00:00"'

    # Test with a unicode string
    data = u'\u00e9'
    assert jsonify(data) == '"\\u00e9"'

   

# Generated at 2022-06-16 23:06:10.829909
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\udc80') == b'\xed\xb2\x80'

# Generated at 2022-06-16 23:06:23.687249
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    assert jsonify(data, sort_keys=True) == '{"a": "b", "c": "d"}'
    assert jsonify(data, sort_keys=True, indent=4) == '{\n    "a": "b", \n    "c": "d"\n}'
    assert jsonify(data, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b", "c": "d"\n}'

# Generated at 2022-06-16 23:06:32.521618
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

    # Test that we can encode a non-string
    assert to_bytes(1) == b'1'

    # Test that we can encode a non-string with a nonstring strategy
    assert to_bytes(1, nonstring='passthru') == 1

    # Test that we can encode a non-string with a nonstring strategy
    assert to_bytes(1, nonstring='empty') == b''

    # Test that we can encode a non-string with a nonstring strategy
    assert to_bytes

# Generated at 2022-06-16 23:06:45.632933
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(1, nonstring='passthru') == 1
    assert to_native(1, nonstring='empty') == ''
    assert to_native(1, nonstring='strict') == '1'
    assert to_native(None) == 'None'
    assert to_native(None, nonstring='passthru') == None
    assert to_native(None, nonstring='empty') == ''
    assert to_native(None, nonstring='strict') == 'None'
    assert to_native(u'\u1234') == u'\u1234'

# Generated at 2022-06-16 23:07:39.998913
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', 'utf-8') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a text string with surrogates
    assert to_bytes(u'\ud83d\ude00', 'utf-8') == b'\xf0\x9f\x98\x80'

    # Test that we can encode a text string with surrogates and errors='replace'
    assert to_bytes(u'\ud83d\ude00', 'utf-8', errors='replace') == b'?'

    # Test that we can encode

# Generated at 2022-06-16 23:07:50.068811
# Unit test for function to_native
def test_to_native():
    """
    Test to_native function
    """
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == 'привет'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == 'привет'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82', errors='surrogate_or_strict')

# Generated at 2022-06-16 23:08:02.235326
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

    # Test that we can encode a non-string
    assert to_bytes(1) == b'1'

    # Test that we can encode a non-string with a custom encoding
    assert to_bytes(1, encoding='ascii') == b'1'

    # Test that we can encode a non-string with a custom error handler
    assert to_bytes(1, errors='surrogate_or_replace') == b'1'

    # Test that we can encode a non-string with a custom

# Generated at 2022-06-16 23:08:10.136608
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:08:21.792935
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode text strings
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_strict') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:08:30.082089
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string to bytes
    assert to_bytes('foo') == b'foo'
    assert to_bytes('foo', encoding='ascii') == b'foo'
    assert to_bytes('föo', encoding='latin-1') == b'f\xf6o'
    assert to_bytes('föo', encoding='utf-8') == b'f\xc3\xb6o'
    assert to_bytes('föo', encoding='ascii', errors='surrogate_or_replace') == b'f?o'
    assert to_bytes('föo', encoding='ascii', errors='surrogate_or_strict') == b'f?o'

# Generated at 2022-06-16 23:08:39.645187
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a nonstring

# Generated at 2022-06-16 23:08:51.713366
# Unit test for function jsonify