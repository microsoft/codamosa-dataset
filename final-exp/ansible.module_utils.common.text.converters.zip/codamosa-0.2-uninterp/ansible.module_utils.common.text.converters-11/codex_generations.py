

# Generated at 2022-06-16 22:59:13.558397
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(u'foo', encoding='ascii') == u'foo'

# Generated at 2022-06-16 22:59:21.513672
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 22:59:32.490082
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 22:59:44.527910
# Unit test for function to_native
def test_to_native():
    # Test with a text string
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(u'foo', errors='surrogate_or_replace') == u'foo'
    assert to_native(u'foo', errors='surrogate_then_replace') == u'foo'

    # Test with a byte string
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == u'foo'

# Generated at 2022-06-16 22:59:51.525483
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a text string with surrogates
    assert to

# Generated at 2022-06-16 22:59:57.668982
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'foo') == b'foo'

    # Test that we can encode a nonstring
    assert to_bytes(1) == b'1'
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='empty') == b''
    assert to_bytes(1, nonstring='strict') == b'1'

    # Test that we can encode a nonstring that has a non-ascii repr

# Generated at 2022-06-16 23:00:06.687316
# Unit test for function to_native
def test_to_native():
    # Test that to_native returns a string
    assert isinstance(to_native(u'foo'), text_type)
    assert isinstance(to_native(b'foo'), text_type)
    assert isinstance(to_native(b'foo'.decode('utf-8')), text_type)
    assert isinstance(to_native(u'foo'.encode('utf-8')), text_type)

    # Test that to_native returns a string that is the same as the input
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo'.decode('utf-8')) == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'

    #

# Generated at 2022-06-16 23:00:12.768641
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'hello') == b'hello'

    # Test that we can encode a nonstring
    assert to_bytes(42) == b'42'
    assert to_bytes(42, nonstring='passthru') == 42
    assert to_bytes(42, nonstring='empty') == b''
    assert to_bytes(42, nonstring='strict') == b'42'

    # Test that we can encode a nonstring that doesn't have a str representation

# Generated at 2022-06-16 23:00:23.900324
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=None) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, separators=(',', ':')) == '{"a":"b"}'
    assert jsonify({"a": "b"}, sort_keys=True, separators=(',', ': ')) == '{"a": "b"}'

# Generated at 2022-06-16 23:00:31.902698
# Unit test for function to_native
def test_to_native():
    # Test that to_native returns a string
    assert isinstance(to_native(u'foo'), str)
    assert isinstance(to_native(b'foo'), str)
    assert isinstance(to_native(u'foo'.encode('utf-8')), str)
    assert isinstance(to_native(u'foo'.encode('utf-16')), str)
    assert isinstance(to_native(u'foo'.encode('utf-32')), str)
    assert isinstance(to_native(u'foo'.encode('latin-1')), str)
    assert isinstance(to_native(u'foo'.encode('ascii')), str)
    assert isinstance(to_native(u'foo'.encode('cp037')), str)

# Generated at 2022-06-16 23:00:53.766544
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:01:02.809548
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": : "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': '), encoding="latin-1") == '{\n  "a": : "b"\n}'

# Generated at 2022-06-16 23:01:08.950225
# Unit test for function jsonify
def test_jsonify():
    data = {u'foo': u'bar', u'baz': u'汉字'}
    assert jsonify(data) == '{"foo": "bar", "baz": "\\u6c49\\u5b57"}'
    assert jsonify(data, ensure_ascii=False) == '{"foo": "bar", "baz": "汉字"}'



# Generated at 2022-06-16 23:01:18.988382
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:01:30.346086
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_then_replace') == b'?'

# Generated at 2022-06-16 23:01:36.390783
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u00e9') == '"\\u00e9"'
    assert jsonify(u'\u00e9'.encode('latin-1')) == '"\\u00e9"'
    assert jsonify(u'\u00e9'.encode('utf-8')) == '"\\u00e9"'
    assert jsonify(u'\u00e9'.encode('utf-16')) == '"\\u00e9"'
    assert jsonify(u'\u00e9'.encode('utf-32')) == '"\\u00e9"'
    assert jsonify(u'\u00e9'.encode('ascii')) == '"\\u00e9"'

# Generated at 2022-06-16 23:01:47.854884
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'\xef\xbb\xbf' + b'foo') == u'foo'
    assert to_native(b'\xef\xbb\xbf' + b'foo', encoding='latin-1') == u'\ufefffoo'
    assert to_native(b'\xef\xbb\xbf' + b'foo', encoding='latin-1', errors='surrogate_or_strict') == u'\ufefffoo'

# Generated at 2022-06-16 23:01:57.955256
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a":: "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': '), encoding='latin-1') == '{\n  "a":: "b"\n}'

# Generated at 2022-06-16 23:02:04.983152
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd', 'e': Set([1, 2, 3])}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": [1, 2, 3]}'
    data = {'a': 'b', 'c': 'd', 'e': Set([1, 2, 3]), 'f': datetime.datetime(2017, 1, 1, 1, 1, 1)}

# Generated at 2022-06-16 23:02:16.383967
# Unit test for function to_native
def test_to_native():
    # Test that we can encode and decode utf-8
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8')) == u'\u2713'

    # Test that we can encode and decode latin-1
    assert to_native(u'\u00e9') == u'\u00e9'
    assert to_native(u'\u00e9'.encode('latin-1')) == u'\u00e9'

    # Test that we can encode and decode ascii
    assert to_native(u'a') == u'a'
    assert to_native(u'a'.encode('ascii')) == u'a'

    # Test that we can encode and decode

# Generated at 2022-06-16 23:02:37.467606
# Unit test for function to_native
def test_to_native():
    from ansible.module_utils._text import to_native
    assert to_native(u'\u1234') == u'\u1234'
    assert to_native(b'\xe1\x88\xb4') == u'\u1234'
    assert to_native(b'\xe1\x88\xb4', errors='surrogate_or_strict') == u'\u1234'
    assert to_native(b'\xe1\x88\xb4', errors='surrogate_or_replace') == u'\u1234'
    assert to_native(b'\xe1\x88\xb4', errors='surrogate_then_replace') == u'\u1234'

# Generated at 2022-06-16 23:02:44.885927
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:02:57.673368
# Unit test for function to_native
def test_to_native():
    # Test with a string
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(u'foo', errors='surrogate_or_replace') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == u'foo'
    assert to_native(u'foo', errors='surrogate_then_replace') == u'foo'
    assert to_native(b'foo', errors='surrogate_then_replace') == u'foo'

    #

# Generated at 2022-06-16 23:03:07.738317
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b",\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': '), encoding='latin-1') == '{\n    "a": "b",\n}'

# Generated at 2022-06-16 23:03:17.923574
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:03:29.024243
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(1.1) == '1.1'
    assert to_native(True) == 'True'
    assert to_native(None) == 'None'
    assert to_native(dict(a=1, b=2)) == "{'a': 1, 'b': 2}"
    assert to_native(dict(a=1, b=2), format=True) == "{'a': 1, 'b': 2}"
    assert to_native(dict(a=1, b=2), format=False) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-16 23:03:39.180205
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == u'foo'
    assert to_native(b'foo', errors='surrogate_then_replace') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_strict', nonstring='passthru') == b'foo'
    assert to_native(b'foo', errors='surrogate_or_replace', nonstring='passthru') == b'foo'

# Generated at 2022-06-16 23:03:51.369703
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(1) == u'1'
    assert to_native(1, nonstring='passthru') == 1
    assert to_native(1, nonstring='empty') == u''
    assert to_native(1, nonstring='strict') == u'1'

    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:04:00.365464
# Unit test for function to_bytes
def test_to_bytes():
    # pylint: disable=too-many-branches,too-many-statements
    # pylint: disable=too-many-locals,too-many-nested-blocks
    import sys
    import unittest

    # We need to test that we can encode all valid unicode characters.  We
    # can't just use the entire unicode range because some of those characters
    # are not valid in some encodings.  So we need to use a list of characters
    # that are valid in all encodings.
    #
    # The list of characters is from the Python3.3 source code.  It's in the
    # file Lib/encodings/aliases.py.  The list is in the variable
    # _aliases_raw.  We're using the list from Python3.3 because it's the
    #

# Generated at 2022-06-16 23:04:12.226600
# Unit test for function to_native
def test_to_native():
    # Test with a text string
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo', nonstring='passthru') == u'foo'
    assert to_native(u'foo', nonstring='strict') == u'foo'
    assert to_native(u'foo', nonstring='empty') == u''
    assert to_native(u'foo', nonstring='simplerepr') == u'foo'

    # Test with a byte string
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo', nonstring='passthru') == b'foo'
    assert to_native(b'foo', nonstring='strict') == u'foo'
    assert to_native(b'foo', nonstring='empty') == u''


# Generated at 2022-06-16 23:04:30.201652
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2713') == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('latin-1')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-32')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-8')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16-be')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16-le')) == '"\\u2713"'

# Generated at 2022-06-16 23:04:42.852132
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'fóo') == b'f\xc3\xb3o'
    assert to_bytes(u'fóo', encoding='latin-1') == b'f\xf3o'
    assert to_bytes(u'fóo', encoding='latin-1', errors='surrogate_or_strict') == b'f\xf3o'
    assert to_bytes(u'fóo', encoding='latin-1', errors='surrogate_or_replace') == b'f\xf3o'

# Generated at 2022-06-16 23:04:52.158245
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:05:04.409507
# Unit test for function to_native
def test_to_native():
    # Test that to_native() returns a string
    assert isinstance(to_native(u'foo'), str)
    assert isinstance(to_native(b'foo'), str)
    assert isinstance(to_native(u'\u2713'), str)
    assert isinstance(to_native(b'\xe2\x9c\x93'), str)
    assert isinstance(to_native(1), str)
    assert isinstance(to_native(1.1), str)
    assert isinstance(to_native(b'\xe2\x9c\x93'.decode('utf-8')), str)

    # Test that to_native() returns a string that is decodable
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo') == 'foo'
   

# Generated at 2022-06-16 23:05:12.951545
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'fóo') == b'f\xc3\xb3o'
    assert to_bytes(u'fóo', encoding='latin-1') == b'f\xf3o'
    assert to_bytes(u'fóo', encoding='latin-1', errors='replace') == b'f?o'
    assert to_bytes(u'fóo', encoding='latin-1', errors='surrogate_or_replace') == b'f?o'

# Generated at 2022-06-16 23:05:25.435693
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:05:35.792839
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(1) == '1'
    assert to_native(1.1) == '1.1'
    assert to_native(True) == 'True'
    assert to_native(None) == 'None'
    assert to_native(dict(a=1, b=2)) == "{'a': 1, 'b': 2}"
    assert to_native(dict(a=1, b=2), format=True) == '{\n    "a": 1, \n    "b": 2\n}'

# Generated at 2022-06-16 23:05:47.430733
# Unit test for function to_native
def test_to_native():
    # Test with a text string
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(u'foo', errors='surrogate_or_replace') == u'foo'
    assert to_native(u'foo', errors='surrogate_then_replace') == u'foo'
    assert to_native(u'foo', errors='strict') == u'foo'
    assert to_native(u'foo', errors='replace') == u'foo'
    assert to_native(u'foo', errors='ignore') == u'foo'
    assert to_native(u'foo', errors='surrogateescape') == u'foo'

    # Test with a byte string
    assert to_

# Generated at 2022-06-16 23:05:53.134691
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:06:01.620122
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2713') == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('latin-1')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-32')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16-be')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16-le')) == '"\\u2713"'

# Generated at 2022-06-16 23:06:28.959188
# Unit test for function jsonify

# Generated at 2022-06-16 23:06:40.913035
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

    # Test that we can encode a non-string
    assert to_bytes(1) == b'1'

    # Test that we can encode a non-string with a custom error handler
    assert to_bytes(1, errors='surrogate_or_replace') == b'1'

    # Test that we can encode a non-string with a custom error handler
    assert to_bytes(1, errors='surrogate_or_strict') == b'1'

    # Test that we can encode a

# Generated at 2022-06-16 23:06:51.869948
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a string
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes(b'hello') == b'hello'

    # Test that we can encode a unicode string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'?'

# Generated at 2022-06-16 23:07:04.488570
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(b'foo') == b'foo'

    # Test that we can encode a unicode string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\x34'

    # Test that we can encode a unicode string with surrogates
    assert to_bytes(u'\ud800\udc00') == b'\xf0\x90\x80\x80'

# Generated at 2022-06-16 23:07:14.797432
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == 'foo'
    assert to_native(u'foo', errors='surrogate_or_strict') == 'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == 'foo'
    assert to_native(u'foo', errors='surrogate_or_replace') == 'foo'
    assert to_native(b'foo', errors='surrogate_then_replace') == 'foo'
    assert to_native(u'foo', errors='surrogate_then_replace') == 'foo'

# Generated at 2022-06-16 23:07:18.372531
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 1, 'b': '2', 'c': [1, 2, 3], 'd': {'e': 'f'}}
    assert jsonify(data) == '{"a": 1, "c": [1, 2, 3], "b": "2", "d": {"e": "f"}}'



# Generated at 2022-06-16 23:07:24.621839
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1, "b": 2\n}'

# Generated at 2022-06-16 23:07:37.660840
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'foo'.encode('utf-16')) == u'foo'
    assert to_native(u'foo'.encode('utf-32')) == u'foo'
    assert to_native(u'foo'.encode('latin-1')) == u'foo'
    assert to_native(u'foo'.encode('ascii')) == u'foo'
    assert to_native(u'foo'.encode('utf-8'), errors='surrogate_or_strict') == u'foo'
    assert to_native(u'foo'.encode('utf-16'), errors='surrogate_or_strict')

# Generated at 2022-06-16 23:07:48.146430
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, indent=4) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True) == '{"a": 1}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4, separators=(',', ': '), ensure_ascii=True) == '{\n    "a": 1\n}'

# Generated at 2022-06-16 23:07:59.863162
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:08:50.864536
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a nonstring