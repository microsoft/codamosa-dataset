

# Generated at 2022-06-16 22:59:12.902618
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 22:59:20.922059
# Unit test for function jsonify
def test_jsonify():
    data = {u'foo': u'bar', u'baz': u'qux'}
    assert jsonify(data) == '{"foo": "bar", "baz": "qux"}'
    data = {u'foo': u'bar', u'baz': u'qux', u'quux': u'corge'}
    assert jsonify(data) == '{"foo": "bar", "baz": "qux", "quux": "corge"}'
    data = {u'foo': u'bar', u'baz': u'qux', u'quux': u'corge', u'grault': u'garply'}

# Generated at 2022-06-16 22:59:28.455204
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'fóo') == b'f\xc3\xb3o'
    assert to_bytes(u'fóo', encoding='latin-1') == b'f\xf3o'
    assert to_bytes(u'fóo', errors='replace') == b'f?o'
    assert to_bytes(u'fóo', errors='surrogate_or_replace') == b'f?o'
    assert to_bytes(u'fóo', errors='surrogate_or_strict') == b'f\xc3\xb3o'

# Generated at 2022-06-16 22:59:37.814326
# Unit test for function jsonify
def test_jsonify():
    data = {u'foo': u'bar'}
    assert jsonify(data) == '{"foo": "bar"}'
    data = {u'foo': u'bar', u'baz': u'\u20ac'}
    assert jsonify(data) == '{"foo": "bar", "baz": "\\u20ac"}'
    data = {u'foo': u'bar', u'baz': u'\u20ac'}
    assert jsonify(data, ensure_ascii=False) == '{"foo": "bar", "baz": "€"}'
    data = {u'foo': u'bar', u'baz': u'\u20ac'}

# Generated at 2022-06-16 22:59:48.980042
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == u'\u2713'

# Generated at 2022-06-16 23:00:01.129095
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode text strings
    assert to_bytes('abc') == b'abc'
    assert to_bytes(u'abc') == b'abc'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\x34'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='replace') == b'?'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='ignore') == b''

    # Test that we can encode byte strings
    assert to_bytes(b'abc') == b'abc'

# Generated at 2022-06-16 23:00:09.021069
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode unicode strings
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'

    # Test that we can encode byte strings
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:00:20.916594
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": : "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': '), encoding="latin-1") == '{\n  "a": : "b"\n}'

# Generated at 2022-06-16 23:00:30.162385
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=2) == '{\n  "a": 1, \n  "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": 1, "b": 2\n}'

# Generated at 2022-06-16 23:00:41.771393
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b",\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': '), encoding="latin-1") == '{\n    "a": "b",\n}'

# Generated at 2022-06-16 23:00:59.473017
# Unit test for function jsonify
def test_jsonify():
    data = {u'foo': u'bar'}
    assert jsonify(data) == '{"foo": "bar"}'
    data = {u'foo': u'bar', u'baz': u'\u20ac'}
    assert jsonify(data) == '{"foo": "bar", "baz": "\\u20ac"}'
    data = {u'foo': u'bar', u'baz': u'\u20ac'}
    assert jsonify(data, ensure_ascii=False) == '{"foo": "bar", "baz": "€"}'
    data = {u'foo': u'bar', u'baz': u'\u20ac'}

# Generated at 2022-06-16 23:01:11.471872
# Unit test for function to_bytes

# Generated at 2022-06-16 23:01:19.643252
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='replace') == b'?'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace', encoding='ascii') == b'?'
    assert to_

# Generated at 2022-06-16 23:01:31.794676
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='ignore') == u''

# Generated at 2022-06-16 23:01:40.141159
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'foo'.encode('utf-16')) == u'foo'
    assert to_native(u'foo'.encode('utf-32')) == u'foo'
    assert to_native(u'foo'.encode('latin-1')) == u'foo'
    assert to_native(u'føø'.encode('utf-8')) == u'føø'
    assert to_native(u'føø'.encode('utf-16')) == u'føø'
    assert to_native(u'føø'.encode('utf-32')) == u'føø'

# Generated at 2022-06-16 23:01:51.561915
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:02:01.399122
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == u'\u2713'

# Generated at 2022-06-16 23:02:13.516375
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=2) == '{\n  "a": 1, \n  "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": 1, "b": 2\n}'

# Generated at 2022-06-16 23:02:25.746383
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, sort_keys=True) == '{"a": 1}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4, separators=(',', ': '), encoding='latin-1') == '{\n    "a": 1\n}'

# Generated at 2022-06-16 23:02:37.935742
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a string with non-ascii characters
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', encoding='ascii') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a string with non-ascii characters and errors

# Generated at 2022-06-16 23:02:56.835269
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(b'foo'.decode('utf-8')) == 'foo'
    assert to_native(u'foo'.encode('utf-8')) == 'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8')) == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8').decode('utf-8')) == u'\u2713'

# Generated at 2022-06-16 23:03:07.094578
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\udc80') == b'\xed\xb2\x80'
    assert to

# Generated at 2022-06-16 23:03:17.567820
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, separators=(',', ':')) == '{"a":"b"}'
    assert jsonify({"a": "b"}, separators=(',', ': ')) == '{"a": "b"}'
    assert jsonify({"a": "b"}, separators=(', ', ': ')) == '{"a": "b"}'
    assert jsonify({"a": "b"}, separators=(',', ': ')) == '{"a": "b"}'
   

# Generated at 2022-06-16 23:03:28.561818
# Unit test for function jsonify
def test_jsonify():
    # Test with a dict
    data = {'a': 'b'}
    assert jsonify(data) == '{"a": "b"}'

    # Test with a list
    data = ['a', 'b']
    assert jsonify(data) == '["a", "b"]'

    # Test with a set
    data = set(['a', 'b'])
    assert jsonify(data) == '["a", "b"]'

    # Test with a datetime
    data = datetime.datetime(2017, 1, 1, 12, 0, 0)
    assert jsonify(data) == '"2017-01-01T12:00:00"'

    # Test with a string
    data = 'a'
    assert jsonify(data) == '"a"'

    # Test with a number
    data = 1


# Generated at 2022-06-16 23:03:38.955103
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a text string with surrogates
    assert to

# Generated at 2022-06-16 23:03:51.095323
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u2713') == '\u2713'
    assert to_native(b'\xe2\x9c\x93') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == '\u2713'

# Generated at 2022-06-16 23:04:00.203626
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"key": "value"}) == '{"key": "value"}'
    assert jsonify({"key": "value"}, sort_keys=True) == '{"key": "value"}'
    assert jsonify({"key": "value"}, sort_keys=True, indent=2) == '{\n  "key": "value"\n}'
    assert jsonify({"key": "value"}, sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "key":: "value"\n}'
    assert jsonify({"key": "value"}, sort_keys=True, indent=2, separators=(',', ': '), ensure_ascii=False) == '{\n  "key":: "value"\n}'

# Generated at 2022-06-16 23:04:12.031763
# Unit test for function jsonify
def test_jsonify():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_MAPPING

# Generated at 2022-06-16 23:04:23.315187
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2) == '{\n  "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a":: "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=2, separators=(',', ': '), encoding='latin-1') == '{\n  "a":: "b"\n}'

# Generated at 2022-06-16 23:04:32.132278
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a non-string
    assert to_

# Generated at 2022-06-16 23:04:50.817568
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='replace') == u'\ufffd'
    assert to

# Generated at 2022-06-16 23:05:02.185561
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'foo', nonstring='passthru') == u'foo'
    assert to_bytes(u'foo', nonstring='empty') == b''
    assert to_bytes(u'foo', nonstring='strict') == b'foo'
    assert to_bytes(u'foo', nonstring='simplerepr') == b'foo'

    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(b'foo', nonstring='passthru') == b'foo'
    assert to_bytes(b'foo', nonstring='empty') == b''
    assert to_bytes(b'foo', nonstring='strict') == b'foo'

# Generated at 2022-06-16 23:05:11.530343
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode unicode strings
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442', encoding='koi8-r') == b'\xf0\xe0\xe2\xe5\xf2'

# Generated at 2022-06-16 23:05:23.588416
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 1, 'b': 2}
    assert jsonify(data) == '{"a": 1, "b": 2}'
    data = {'a': 1, 'b': Set([1, 2, 3])}
    assert jsonify(data) == '{"a": 1, "b": [1, 2, 3]}'
    data = {'a': 1, 'b': datetime.datetime(2016, 1, 1, 1, 1, 1)}
    assert jsonify(data) == '{"a": 1, "b": "2016-01-01T01:01:01"}'
    data = {'a': 1, 'b': u'\u2713'}
    assert jsonify(data) == '{"a": 1, "b": "\\u2713"}'

# Generated at 2022-06-16 23:05:34.414735
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8')) == u'\u2713'
    assert to_native(b'\xe2\x9c\x93'.decode('utf-8')) == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8').decode('utf-8')) == u'\u2713'

# Generated at 2022-06-16 23:05:45.691048
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1, "b": 2\n}'

# Generated at 2022-06-16 23:05:56.907440
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a text string with surrogates
    assert to

# Generated at 2022-06-16 23:06:08.792091
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b",\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': '), encoding="latin-1") == '{\n    "a": "b",\n}'

# Generated at 2022-06-16 23:06:16.374303
# Unit test for function jsonify
def test_jsonify():
    data = {u'foo': u'bar', u'baz': u'汉字'}
    assert jsonify(data) == '{"foo": "bar", "baz": "\\u6c49\\u5b57"}'
    assert jsonify(data, ensure_ascii=False) == '{"foo": "bar", "baz": "汉字"}'



# Generated at 2022-06-16 23:06:27.403866
# Unit test for function to_native
def test_to_native():
    """
    Test to_native function
    """
    from ansible.module_utils._text import to_native
    assert to_native(u'\u1234') == u'\u1234'
    assert to_native('\xe4\xb8\xad\xe6\x96\x87') == u'\u4e2d\u6587'
    assert to_native('\xe4\xb8\xad\xe6\x96\x87', errors='surrogate_or_strict') == u'\u4e2d\u6587'
    assert to_native('\xe4\xb8\xad\xe6\x96\x87', errors='surrogate_or_replace') == u'\u4e2d\u6587'

# Generated at 2022-06-16 23:06:52.028915
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:07:04.539564
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:07:14.886427
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:07:22.814468
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'?'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_then_replace') == b'?'

    # Test that we can encode a byte string
    assert to_bytes(b'foo') == b'foo'
   

# Generated at 2022-06-16 23:07:35.786137
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'hello') == b'hello'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\x34'

    # Test that we can encode a byte string
    assert to_bytes(b'hello') == b'hello'
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'
    assert to_bytes(b'\xe1\x88\xb4', encoding='latin-1') == b'\xe1\x88\xb4'

    # Test that we

# Generated at 2022-06-16 23:07:43.844270
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(123) == u'123'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:07:51.835875
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 23:08:03.982952
# Unit test for function jsonify

# Generated at 2022-06-16 23:08:16.841241
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:08:26.962846
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:08:54.307814
# Unit test for function to_native
def test_to_native():
    """
    Test to_native function
    """
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'