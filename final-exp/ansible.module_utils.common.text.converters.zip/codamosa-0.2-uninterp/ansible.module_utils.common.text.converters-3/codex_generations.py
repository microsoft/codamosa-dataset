

# Generated at 2022-06-16 22:59:08.564346
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a utf8 string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a latin1 string
    assert to_bytes(u'\u00e9', encoding='latin-1') == b'\xe9'

    # Test that we can encode a string with surrogates
    assert to_bytes(u'\ud800\udc00', encoding='utf-16') == b'\xff\xfe\x00\xd8\x00\xdc'

    # Test that we can encode a string with surrogates and non-BMP characters

# Generated at 2022-06-16 22:59:15.845329
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == u'foo'
    assert to_native(u'foo') == u'foo'
    assert to_native(1) == u'1'
    assert to_native(1.1) == u'1.1'
    assert to_native(None) == u'None'
    assert to_native(dict(a=1, b=2)) == u"{'a': 1, 'b': 2}"
    assert to_native(dict(a=1, b=2), indent=2) == u"{\n  'a': 1,\n  'b': 2\n}"
    assert to_native(dict(a=1, b=2), format='json') == u'{"a": 1, "b": 2}'

# Generated at 2022-06-16 22:59:28.970882
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string to bytes
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string to bytes
    assert to_bytes(b'foo') == b'foo'
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

    # Test that we can encode a nonstring to bytes
    assert to_bytes(1) == b'1'
    assert to_bytes(1, nonstring='passthru') == 1
    assert to_bytes(1, nonstring='empty') == b''

# Generated at 2022-06-16 22:59:38.196391
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='replace') == u'?'

# Generated at 2022-06-16 22:59:49.472682
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8')) == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-16')) == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-32')) == u'\u2713'
    assert to_native(u'\u2713'.encode('latin-1')) == u'\u2713'
    assert to_native(u'\u2713'.encode('ascii', 'surrogateescape')) == u'\u2713'

# Generated at 2022-06-16 23:00:01.541261
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1)) == '{"a": 1}'
    assert jsonify(dict(a=1), sort_keys=True) == '{"a": 1}'
    assert jsonify(dict(a=1), sort_keys=True, indent=4) == '{\n    "a": 1\n}'
    assert jsonify(dict(a=1), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1\n}'
    assert jsonify(dict(a=1), sort_keys=True, indent=4, separators=(',', ': '), encoding='latin-1') == '{\n    "a": 1\n}'

# Generated at 2022-06-16 23:00:09.600545
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'foo'.encode('utf-16')) == u'foo'
    assert to_native(u'foo'.encode('utf-32')) == u'foo'
    assert to_native(u'foo'.encode('latin-1')) == u'foo'
    assert to_native(u'foo'.encode('ascii')) == u'foo'
    assert to_native(u'føø'.encode('utf-8')) == u'føø'
    assert to_native(u'føø'.encode('utf-16')) == u'føø'

# Generated at 2022-06-16 23:00:21.409554
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string to a byte string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'

    # Test that we can encode a text string with non-ascii characters to a byte string
    assert to_bytes(u'\u00a3') == b'\xc2\xa3'

    # Test that we can encode a byte string to a byte string
    assert to_bytes(b'foo') == b'foo'

    # Test that we can encode a text string with surrogates to a byte string
    assert to_bytes(u'\udc80') == b'\xed\xb2\x80'

    # Test that we can encode a text string with surrogates to a byte string
    assert to_bytes(u'\udc80')

# Generated at 2022-06-16 23:00:30.512096
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='ignore') == b''
    assert to_bytes(u'\u1234', errors='replace') == b'?'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xed\xa0\x81\xed\xb4\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xed\xa0\x81\xed\xb4\xb4'

# Generated at 2022-06-16 23:00:42.079937
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 23:01:02.242121
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a unicode string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'

    # Test that we can encode a byte string
    assert to_bytes(b'\xe1\x88\xb4') == b'\xe1\x88\xb4'

    # Test that we can encode a non-string
    assert to_bytes(1) == b'1'

    # Test that we can encode a non-string with a non-ascii repr
    class Foo(object):
        def __repr__(self):
            return u'\u1234'
    assert to_bytes(Foo()) == b'\xe1\x88\xb4'

    # Test that we can encode a non-string with a non-ascii str
   

# Generated at 2022-06-16 23:01:13.300706
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:01:22.131833
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2, c=3)) == '{"a": 1, "c": 3, "b": 2}'
    assert jsonify(dict(a=1, b=2, c=3), sort_keys=True) == '{"a": 1, "b": 2, "c": 3}'
    assert jsonify(dict(a=1, b=2, c=3), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'

# Generated at 2022-06-16 23:01:34.145347
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": u"b"}) == '{"a": "b"}'
    assert jsonify({"a": u"b\u1234"}) == '{"a": "b\u1234"}'
    assert jsonify({"a": u"b\u1234".encode("utf-16")}) == '{"a": "b\u1234"}'
    assert jsonify({"a": u"b\u1234".encode("utf-16-be")}) == '{"a": "b\u1234"}'
    assert jsonify({"a": u"b\u1234".encode("utf-16-le")}) == '{"a": "b\u1234"}'

# Generated at 2022-06-16 23:01:45.030244
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:01:55.760564
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b",\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': '), encoding="latin-1") == '{\n    "a": "b",\n}'

# Generated at 2022-06-16 23:02:06.405498
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_strict') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:02:17.458261
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:02:29.897489
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:02:41.255128
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:02:58.954682
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:03:07.778435
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo'.encode('utf-8')) == u'foo'
    assert to_native(u'foo'.encode('utf-16')) == u'foo'
    assert to_native(u'foo'.encode('utf-32')) == u'foo'
    assert to_native(u'føø'.encode('utf-8')) == u'føø'
    assert to_native(u'føø'.encode('utf-16')) == u'føø'
    assert to_native(u'føø'.encode('utf-32')) == u'føø'

# Generated at 2022-06-16 23:03:15.667423
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1, \n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1, "b": 2\n}'

# Generated at 2022-06-16 23:03:22.609040
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:03:35.005832
# Unit test for function to_native
def test_to_native():
    assert to_native(b'foo') == 'foo'
    assert to_native(u'foo') == 'foo'
    assert to_native(u'\u2713') == '\u2713'
    assert to_native(b'\xe2\x9c\x93') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == '\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == '\u2713'

# Generated at 2022-06-16 23:03:47.263783
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": "b"}) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True) == '{"a": "b"}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4) == '{\n    "a": "b"\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": "b",\n}'
    assert jsonify({"a": "b"}, sort_keys=True, indent=4, separators=(',', ': '), encoding="latin-1") == '{\n    "a": "b",\n}'

# Generated at 2022-06-16 23:03:57.747879
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd', 'e': u'\u00e9'}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": "\\u00e9"}'
    data = {'a': 'b', 'c': 'd', 'e': u'\u00e9'.encode('utf-8')}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": "\\u00e9"}'

# Generated at 2022-06-16 23:04:09.287576
# Unit test for function to_bytes
def test_to_bytes():
    assert to_bytes('hello') == b'hello'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', errors='surrogate_then_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\udc80') == b'\xed\xb2\x80'

# Generated at 2022-06-16 23:04:20.705892
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_strict') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_or_replace') == u'\u2713'
    assert to_native(b'\xe2\x9c\x93', errors='surrogate_then_replace') == u'\u2713'

# Generated at 2022-06-16 23:04:30.283856
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:04:47.538739
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='latin-1', errors='surrogate_or_replace') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:04:55.603999
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u043f\u0440\u0438\u0432\u0435\u0442') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a byte string
    assert to_bytes(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'

    # Test that we can encode a text string with surrogates
    assert to

# Generated at 2022-06-16 23:05:08.753761
# Unit test for function to_bytes
def test_to_bytes():
    from ansible.module_utils.six import u
    assert to_bytes(u('foo')) == b'foo'
    assert to_bytes(u('foo'), errors='surrogate_or_strict') == b'foo'
    assert to_bytes(u('foo'), errors='surrogate_or_replace') == b'foo'
    assert to_bytes(u('foo'), errors='surrogate_then_replace') == b'foo'
    assert to_bytes(u('foo'), encoding='ascii') == b'foo'
    assert to_bytes(u('foo'), encoding='ascii', errors='surrogate_or_strict') == b'foo'
    assert to_bytes(u('foo'), encoding='ascii', errors='surrogate_or_replace') == b'foo'
    assert to

# Generated at 2022-06-16 23:05:15.424375
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(u'\u2713') == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-8')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('latin-1')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('ascii')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-32')) == '"\\u2713"'
    assert jsonify(u'\u2713'.encode('utf-16-be')) == '"\\u2713"'
   

# Generated at 2022-06-16 23:05:27.462980
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes('foo', encoding='ascii') == b'foo'
    assert to_bytes('foo', encoding='latin-1') == b'foo'
    assert to_bytes('foo', encoding='utf-8') == b'foo'
    assert to_bytes('foo', encoding='utf-16') == b'\xff\xfe\x00f\x00o\x00o\x00'
    assert to_bytes('foo', encoding='utf-32') == b'\xff\xfe\x00\x00\x00f\x00\x00\x00o\x00\x00\x00o\x00\x00\x00'

    # Test that we can encode a text string with

# Generated at 2022-06-16 23:05:37.169003
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:05:47.607850
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'



# Generated at 2022-06-16 23:05:53.236337
# Unit test for function to_bytes
def test_to_bytes():
    # Test with a text string
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_then_replace') == b'\xe1\x88\xb4'
   

# Generated at 2022-06-16 23:06:01.672004
# Unit test for function to_native
def test_to_native():
    assert to_native(u'\u2713') == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-8')) == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-16')) == u'\u2713'
    assert to_native(u'\u2713'.encode('utf-32')) == u'\u2713'
    assert to_native(u'\u2713'.encode('latin-1')) == u'\u2713'
    assert to_native(u'\u2713'.encode('ascii', 'surrogateescape')) == u'\u2713'

# Generated at 2022-06-16 23:06:12.415445
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4) == '{\n    "a": 1,\n    "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-16 23:06:36.496226
# Unit test for function to_native
def test_to_native():
    # Test with a text string
    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(u'foo', errors='surrogate_or_replace') == u'foo'
    assert to_native(u'foo', errors='surrogate_then_replace') == u'foo'

    # Test with a byte string
    assert to_native(b'foo') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_strict') == u'foo'
    assert to_native(b'foo', errors='surrogate_or_replace') == u'foo'

# Generated at 2022-06-16 23:06:48.489202
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native('foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(b'\xc3\xbc') == u'\xfc'
    assert to_native(b'\xc3\xbc', encoding='latin-1') == u'\xfc'
    assert to_native(b'\xc3\xbc', encoding='ascii') == u'\ufffd'
    assert to_native(b'\xc3\xbc', encoding='ascii', errors='ignore') == u''
    assert to_native(b'\xc3\xbc', encoding='ascii', errors='replace') == u'?'

# Generated at 2022-06-16 23:06:56.934360
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0456\u0442') == u'\u043f\u0440\u0438\u0432\u0456\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd1\x96\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0456\u0442'

# Generated at 2022-06-16 23:07:07.450743
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": u"\u20ac"}) == '{"a": "\\u20ac"}'
    assert jsonify({"a": u"\u20ac"}, ensure_ascii=False) == '{"a": "\\u20ac"}'
    assert jsonify({"a": u"\u20ac"}, ensure_ascii=True) == '{"a": "\\\\u20ac"}'
    assert jsonify({"a": u"\u20ac"}, ensure_ascii=True, encoding='latin-1') == '{"a": "\\\\u20ac"}'
    assert jsonify({"a": u"\u20ac"}, ensure_ascii=True, encoding='utf-8') == '{"a": "\\\\u20ac"}'

# Generated at 2022-06-16 23:07:17.014772
# Unit test for function to_native
def test_to_native():
    # Test that to_native returns a native string
    assert isinstance(to_native(u'foo'), str)
    assert isinstance(to_native(b'foo'), str)
    assert isinstance(to_native(u'foo'.encode('utf-8')), str)
    assert isinstance(to_native(b'foo'.decode('utf-8')), str)
    assert isinstance(to_native(u'\u2713'), str)
    assert isinstance(to_native(b'\xe2\x9c\x93'), str)
    assert isinstance(to_native(u'\u2713'.encode('utf-8')), str)
    assert isinstance(to_native(b'\xe2\x9c\x93'.decode('utf-8')), str)

# Generated at 2022-06-16 23:07:27.829625
# Unit test for function to_native
def test_to_native():
    assert to_native(u'foo') == u'foo'
    assert to_native(b'foo') == u'foo'
    assert to_native(u'\u043f\u0440\u0438\u0432\u0435\u0442') == u'\u043f\u0440\u0438\u0432\u0435\u0442'
    assert to_native(b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82') == u'\u043f\u0440\u0438\u0432\u0435\u0442'

# Generated at 2022-06-16 23:07:40.328481
# Unit test for function jsonify
def test_jsonify():
    assert jsonify({"a": 1}) == '{"a": 1}'
    assert jsonify({"a": 1}, sort_keys=True) == '{"a": 1}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4, separators=(',', ': ')) == '{\n    "a": 1\n}'
    assert jsonify({"a": 1}, sort_keys=True, indent=4, separators=(',', ': '), encoding='latin-1') == '{\n    "a": 1\n}'

# Generated at 2022-06-16 23:07:50.143316
# Unit test for function jsonify
def test_jsonify():
    data = {'a': 'b'}
    assert jsonify(data) == '{"a": "b"}'
    data = {'a': 'b', 'c': 'd'}
    assert jsonify(data) == '{"a": "b", "c": "d"}'
    data = {'a': 'b', 'c': 'd', 'e': 'f'}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": "f"}'
    data = {'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h'}
    assert jsonify(data) == '{"a": "b", "c": "d", "e": "f", "g": "h"}'

# Generated at 2022-06-16 23:08:02.283805
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'fóo') == b'f\xc3\xb3o'
    assert to_bytes(u'fóo', encoding='latin-1') == b'f\xf3o'
    assert to_bytes(u'fóo', encoding='latin-1', errors='replace') == b'f?o'
    assert to_bytes(u'fóo', encoding='latin-1', errors='ignore') == b'fo'
    assert to_bytes(u'fóo', encoding='latin-1', errors='surrogate_or_replace') == b'f?o'

# Generated at 2022-06-16 23:08:12.951659
# Unit test for function to_bytes
def test_to_bytes():
    # Test that we can encode a text string
    assert to_bytes('foo') == b'foo'
    assert to_bytes(u'foo') == b'foo'
    assert to_bytes(u'\u1234') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_strict') == b'\xe1\x88\xb4'
    assert to_bytes(u'\u1234', encoding='ascii', errors='surrogate_or_replace') == b'\xe1\x88\xb4'

# Generated at 2022-06-16 23:08:49.867428
# Unit test for function jsonify
def test_jsonify():
    assert jsonify(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True) == '{"a": 1, "b": 2}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=2) == '{\n  "a": 1, \n  "b": 2\n}'
    assert jsonify(dict(a=1, b=2), sort_keys=True, indent=2, separators=(',', ': ')) == '{\n  "a": 1, "b": 2\n}'