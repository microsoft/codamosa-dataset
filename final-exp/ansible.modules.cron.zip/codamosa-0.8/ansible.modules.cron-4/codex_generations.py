

# Generated at 2022-06-11 06:50:18.252736
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({},
        supports_check_mode=True)
    
    n0 = None
    n1 = 'Ansible: test'
    n2 = '#Ansible: other'
    n3 = '#Ansible: test'
    n4 = 'Ansible: test'
    n5 = None
    n6 = 'Ansible: test'
    n7 = None
    n8 = 'Ansible: test'
    n9 = 'Ansible: test'
    
    ct = CronTab(module)
    lines = ["# a comment", "", "", "", ""]
    ct.lines = lines
    assert ct.remove_job(n0) == False

# Generated at 2022-06-11 06:50:19.421416
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    module = AnsibleModule(
        argument_spec = dict()
    )

    m = module.params



# Generated at 2022-06-11 06:50:30.766394
# Unit test for function main
def test_main():
    import sys
    import yaml
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import pytest

    def test_cron_remove_crlf_from_job_string_not_found():
        # Test that cron_remove_crlf_from_job_string doesn't change a string without embedded CR or LF characters
        job = "ls -al"
        result = cron_remove_crlf_from_job_string(job)
        pytest.assume(result == job)

    def test_cron_remove_crlf_from_job_string_found_cr_first():
        # Test that a job string with an embedded CR is changed to a LF
        job = "ls -al \r"
        result = cron_remove_cr

# Generated at 2022-06-11 06:50:39.170103
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    module = AnsibleModule(
        argument_spec=dict(
            user=dict(required=False, type='str'),
            cron_file=dict(required=False, type='str'),
        ),
    )
    crontab = CronTab(module=module)
    crontab.get_cron_job(minute='0', hour='*', day='1', month='*', weekday='*', job='/tmp/foobar.sh', special=None, disabled=False)
    with raises(CronTabError):
        crontab.get_cron_job(minute='@reboot', hour='*', day='1', month='*', weekday='*', job='/tmp/foobar.sh', special='boot', disabled=False)


# Generated at 2022-06-11 06:50:49.811369
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    import ansible.utils.template as template

    file = 'test/testcron'
    cron = '* * * * * /bin/true'
    jobname = 'test'

    template.template_from_file(file, { 'cron': cron, 'jobname': jobname})

    # read the file
    crons = CronTab(file)

    # remove the job
    crons.remove_job(jobname)

    # write the file
    crons.write()

    # read the file back in
    crons = CronTab(file)

    # make sure the job was removed
    assert crons.find_job(jobname, cron) == []


# Generated at 2022-06-11 06:50:57.007527
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    ct = CronTab()
    ct.lines = ['#Ansible: test1', '* * * * * echo hello', '#Ansible: test2', '* * * * * echo world', '#Ansible: test3', '* * * * * echo test']
    ct.update_job('test2', '* * * * * echo ansible')
    expected_list = ['#Ansible: test1', '* * * * * echo hello', '#Ansible: test2', '* * * * * echo ansible',
                     '#Ansible: test3', '* * * * * echo test']
    assert ct.lines == expected_list

# Generated at 2022-06-11 06:51:05.208254
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    module = AnsibleModule(argument_spec={})
    cron = CronTab(module)
    assert cron.lines == []
    cron.add_env('PATH=/usr/bin')
    assert cron.lines == ['PATH=/usr/bin']
    cron.add_env('HOME=/home/user', insertbefore='PATH=/usr/bin')
    assert cron.lines == ['HOME=/home/user', 'PATH=/usr/bin']
    cron.add_env('FOO=bar', insertafter='PATH=/usr/bin')
    assert cron.lines == ['HOME=/home/user', 'PATH=/usr/bin', 'FOO=bar']



# Generated at 2022-06-11 06:51:06.917062
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    assert CronTab("").do_comment("foo") == "#Ansible: foo"


# Generated at 2022-06-11 06:51:10.694964
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    crontab = CronTab(module=None, user=None, cron_file=None)
    lines = []
    decl = 'n=var'
    crontab.do_remove_env(lines, decl)
    assert lines is None

# Generated at 2022-06-11 06:51:14.725742
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    """
    Class CronTab remove_job method unit test stub
    """
    cron_tab=CronTab()

    # Clean the slate
    cron_tab.remove_job(name)

    # Add a job to remove in the test
    cron_tab.add_job(name, job)

    # Remove the job
    removed = cron_tab.remove_job(name)

    # Check the result
    assert removed == True

    # Clean the slate
    cron_tab.remove_job(name)

    # Add a job to remove in the test
    cron_tab.add_job(name, job)

    # Remove the job
    removed = cron_tab.remove_job(name)

    # Check the result
    assert removed == True


# Generated at 2022-06-11 06:52:10.432784
# Unit test for method read of class CronTab
def test_CronTab_read():
    assert CronTab.read('filename') == None, 'CronTab.read() failed'



# Generated at 2022-06-11 06:52:14.027143
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    ct = CronTab()
    ct.lines = ['foo=bar', 'baz', 'qux=quux']
    ct.remove_env('baz')
    assert ct.lines == ['foo=bar', 'qux=quux']


# Generated at 2022-06-11 06:52:16.955070
# Unit test for constructor of class CronTab
def test_CronTab():
    crontab = CronTab(None, "root")
    assert crontab is not None
    assert crontab.user == "root"
    assert crontab.root == True
    assert crontab.cron_file is None


# Generated at 2022-06-11 06:52:19.305555
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    ansible = "#Ansible: "
    name = "test"
    module = mock.MagicMock()
    cron = CronTab(module)
    assert cron.do_comment(name) == "%s%s" % (ansible, name)

# Generated at 2022-06-11 06:52:23.608322
# Unit test for function main
def test_main():
    # File path should be an absolute path.
    assert os.path.isabs(os.path.expanduser('#default:cron_file=/var/spool/cron/crontabs/ansible-crontab'))


# Generated at 2022-06-11 06:52:24.430538
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    assert True


# Generated at 2022-06-11 06:52:33.814235
# Unit test for function main
def test_main():
    cron_file = '/dev/null'
    user = 'root'
    name = 'Ansible'

    class Mock(object):
        """
        Mock class to replace AnsibleModule
        """

# Generated at 2022-06-11 06:52:36.511509
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    c = CronTab(None)
    c.ansible = "#Ansible: "

    assert c.do_comment("Hello") == "#Ansible: Hello"


# Generated at 2022-06-11 06:52:38.666036
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    assert CronTab(None).do_comment('test') == '#Ansible: test'

# Generated at 2022-06-11 06:52:50.485177
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    _CronTab = CronTab()

    with patch('ansible.module_utils.cron.CronTab', return_value=_CronTab) as crontab_mock:
        crontab_mock.lines = []
        assert _CronTab.is_empty() == True
        crontab_mock.lines = [""]
        assert _CronTab.is_empty() == True
        crontab_mock.lines = ["a"]
        assert _CronTab.is_empty() == False
        crontab_mock.lines = ["a", "b"]
        assert _CronTab.is_empty() == False
        crontab_mock.lines = ["", "a"]
        assert _CronTab.is_empty() == False

# Generated at 2022-06-11 06:53:52.873829
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict()
    )

    ct = CronTab(module)
    ct.add_env("FOO=BAR")
    assert ct.lines[0] == "FOO=BAR"


# Generated at 2022-06-11 06:54:01.793406
# Unit test for function main
def test_main():
    import pwd

# Generated at 2022-06-11 06:54:06.779526
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    ct = CronTab(None)
    ct.lines = [
        "PATH=/sbin:/bin:/usr/sbin:/usr/bin",
        "SHELL=/bin/bash",
    ]

    assert ct.find_env('PATH') == [0, "PATH=/sbin:/bin:/usr/sbin:/usr/bin"]
    assert ct.find_env('SHELL') == [1, "SHELL=/bin/bash"]
    assert ct.find_env('FOO') == []



# Generated at 2022-06-11 06:54:15.248536
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    import tempfile
    import os
    import pwd
    import os.path
    import sys
    import platform
    import re
    import shlex

    class module():
        def __init__(self):
            self.fail_json = lambda self, msg: self.fail(msg)

        def fail(self, msg):
            raise Exception(msg)

        def selinux_enabled(self):
            return False

        def set_default_selinux_context(self, path, isdir):
            return False

        def get_bin_path(self, cmd, required=True):
            if cmd == 'crontab':
                return '/usr/bin/crontab'

    module = module()

# Generated at 2022-06-11 06:54:16.576057
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    assert not crontab.CronTab.get_envnames()



# Generated at 2022-06-11 06:54:25.986671
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    with patch('ansible_collections.community.cron.plugins.module_utils.cron_helper.CronTab.CronTab.cron_file', new_callable=PropertyMock(return_value=None)):
        c = CronTab(None)
        assert c.get_cron_job('*', '*', '*', '*', '*', 'foo', None, False) == '* * * * * foo'
        assert c.get_cron_job('*', '*', '*', '*', '*', 'foo', None, True) == '#* * * * * foo'
        assert c.get_cron_job('*', '*', '*', '*', '*', 'foo', '@reboot', False) == '@reboot foo'
        assert c.get

# Generated at 2022-06-11 06:54:34.209047
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    module = fake_AnsibleModule()
    ct = CronTab(module)
    assert ct.get_cron_job(minute=1, hour=1, day=1, month=1, weekday=1, job='/bin/ls', special='daily', disabled=False) == '1 1 1 1 1 /bin/ls'
    assert ct.get_cron_job(minute=1, hour=1, day=1, month=1, weekday=1, job='/bin/ls', special='daily', disabled=True) == '#1 1 1 1 1 /bin/ls'

# Generated at 2022-06-11 06:54:37.392309
# Unit test for method render of class CronTab
def test_CronTab_render():
    ct = CronTab(None, user='testuser')
    ct.lines = ['test1', 'test2']
    assert ct.render() == 'test1\ntest2'

test_CronTab_render()



# Generated at 2022-06-11 06:54:42.719942
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    # Tests for method do_remove_env
    # Ensure the return type is correct
    assert(type(CronTab().do_remove_env(None,'') == None))
    # Ensure that the correct Exception was raised
    with pytest.raises(Exception):
        assert(type(CronTab().do_remove_env(Exception, '') == Exception))

# Generated at 2022-06-11 06:54:45.334108
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    crontab = CronTab('/etc/crontab')
    assert crontab.is_empty() == False, "Wrong result."


# Generated at 2022-06-11 06:56:48.585940
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    t = CronTab(None, user='testuser', cron_file=None)
    assert t.get_cron_job('*/5', '*', '*', '*', '*', 'testjob', '', False) == '*/5 * * * * testuser testjob'



# Generated at 2022-06-11 06:56:57.484694
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    module = AnsibleModule(
        argument_spec=dict(
        )
    )
    obj = CronTab(module)

    comment = 'test_comment_that_should_be_removed'
    job1 = '#test_job_that_should_be_removed'

    obj.add_job(comment, job1)
    assert obj.get_jobnames() == ['test_comment_that_should_be_removed']
    obj.remove_job(comment)
    assert obj.get_jobnames() == []
    obj.add_job(comment, job1)
    assert obj.get_jobnames() == []
    obj.add_job(comment, 'foo')
    assert obj.get_jobnames() == ['test_comment_that_should_be_removed']

# Generated at 2022-06-11 06:57:02.348816
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
        ct = CronTab()

        # Simple test
        lines = ["foo=bar", "baz=bam"]
        decl = "foo=bar"
        result_lines = ct.do_remove_env(lines, decl)
        assert result_lines == ["baz=bam"], "test_CronTab_do_remove_env - return value for simple case should be 'baz=bam'"


# Generated at 2022-06-11 06:57:04.778955
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    module = AnsibleModule(
        argument_spec = dict()
    )
    tab = CronTab(module)
    tab.remove_job_file()


# Generated at 2022-06-11 06:57:14.221166
# Unit test for method render of class CronTab
def test_CronTab_render():
    module = imp.new_module('test')
    module.fail_json = lambda **args: args['msg']

    class FakeModule:
        def __init__(self):
            pass

        def get_bin_path(self, name, required=False):
            return "/usr/bin/" + name

        def run_command(self, cmd, use_unsafe_shell=False):
            return 0, "", ""

        def selinux_enabled(self):
            return False

        def set_default_selinux_context(self, path, recursive=False):
            pass

    module.AnsibleModule = FakeModule
    module.CronTabError = CronTabError
    module.__name__ = __name__

    # Test empty lines
    c = CronTab(module, user=None)
    result = c.render()

# Generated at 2022-06-11 06:57:16.701392
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    c = CronTab(None)
    c.ansible = 'Ansible comment: '
    assert c.do_comment('test') == 'Ansible comment: test'


# Generated at 2022-06-11 06:57:25.536296
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True),
            job = dict(required=True),
            minute = dict(required=False),
            hour = dict(required=False),
            day = dict(required=False),
            month = dict(required=False),
            weekday = dict(required=False),
            special = dict(required=False),
            disabled = dict(required=False),
            comment = dict(required=False),
            user = dict(required=False),
            cron_file = dict(required=False),
        ),
        supports_check_mode=True
    )
    mycron = CronTab(module)
    mycron.add_job(module.params['name'], module.params['job'])



# Generated at 2022-06-11 06:57:26.821622
# Unit test for method read of class CronTab
def test_CronTab_read():
    assert True == False # Expected Error!


# Generated at 2022-06-11 06:57:32.559377
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    # Create a mock cronTab object
    cronTab = type('cronTab', (object,), {'lines': ["#Ansible: Job1", "", "#Ansible: ", "* * * * * user /home/user/command", "#Ansible: Job2", "", "#Ansible: "]})

    # Test that we get the correct job names
    result = CronTab.get_jobnames(cronTab)
    assert result == ["Job1", "", "Job2"]


# Generated at 2022-06-11 06:57:35.412594
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    tt = CronTab(None)
    tt.ansible = '#Ansible:'
    assert tt.do_comment('test') == '#Ansible:test'
