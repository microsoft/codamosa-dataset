

# Generated at 2022-06-11 06:50:18.556039
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    cron = CronTab(None, user=None)

    cron.lines = ['ABC=123', 'XYZ=789', '   XYZ   =   456']

    assert cron.find_env('ABC') == [0, 'ABC=123']
    assert cron.find_env('XYZ') == [2, 'XYZ=456']
    assert cron.find_env('FOO') == []



# Generated at 2022-06-11 06:50:20.154530
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
  crontab = _CronTab(module, user=None, cron_file=None)
  assert not crontab.remove_job(name=None)


# Generated at 2022-06-11 06:50:32.113517
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 06:50:43.344668
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    """
    Unit test for method update_job of class CronTab
    """
    # Set up mock stuff
    File.exists = Mock(return_value=False)
    argv_save = sys.argv
    sys.argv = ["ansible-doc", "cron"]

# Generated at 2022-06-11 06:50:53.895298
# Unit test for method render of class CronTab
def test_CronTab_render():
    module = AnsibleModule(
        argument_spec = dict()
    )
#    module = AnsibleModule()
    # This is a list of lists. Each list needs to be a cron job line.
    # The first element in the list is a string of the job definition,
    # and the second element is a list of any environment variables
    # that need to be exported.
    lines = [
        ['* * * * * /path/to/job', []],
        ['0 12 * * * /path/to/another/job', []]
    ]
    crontab = CronTab(module)
    for line in lines:
        crontab.lines.append(line[0])
        for env in line[1]:
            crontab.lines.append(env)

# Generated at 2022-06-11 06:50:58.584575
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    lines = []
    name = 'test'
    job = 'test'
    comment = '#Ansible: test'
    ct = CronTab(None, 'root')

    ct.do_add_job(lines, comment, job)
    assert lines[0] == comment
    assert lines[1] == job

# Generated at 2022-06-11 06:51:02.727559
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    cron = CronTab(None, user='user')
    cron.lines = ['#Ansible: Name', '*/60 * * * * command', '#Ansible: Name2', '#Ansible: Name3']
    assert cron.get_envnames() == []


# Generated at 2022-06-11 06:51:06.225238
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    crontab = CronTab(None, None)
    result = crontab.get_cron_job(None, None, None, None, None, 'this-is-a-job', None, None)

    assert result == 'this-is-a-job', result



# Generated at 2022-06-11 06:51:15.088336
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    module = AnsibleModule(argument_spec={})
    CronTab.module = module
    crontab = CronTab(module)
    crontab.lines = []
    crontab.lines.append("TEST=test")
    crontab.lines.append("A=A")
    crontab.lines.append("b=b")
    crontab.lines.append("C=c")
    crontab.lines.append("D=d")
    assert crontab.find_env("TEST") == [0, "TEST=test"]
    assert crontab.find_env("A") == [1, "A=A"]
    assert crontab.find_env("b") == [2, "b=b"]
    assert crontab.find_env("c") == []
    assert cront

# Generated at 2022-06-11 06:51:26.439002
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():

    cron_test = CronTab(user='pi', cron_file='test_cron_file')

    test_job_1 = "test 1"
    test_name_1 = "test_name_1"
    test_job_2 = "test 2"
    test_name_2 = "test_name_2"
    test_job_3 = "test 3"
    test_name_3 = "test_name_3"

    # build up some jobs and add them to cron_test
    job_1 = cron_test.get_cron_job('*', '*', '*', '*', '*', test_job_1, False, False)
    cron_test.add_job(test_name_1, job_1)

    job_2 = cron_test.get_cron

# Generated at 2022-06-11 06:52:28.503137
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    crontab = CronTab(None, user=None, cron_file='somefile')
    crontab.lines = ['some line', '# Ansible: minute testname', '* * * * * some comment']
    crontab.update_job('testname', '* * * * * some comment')

    assert crontab.lines == ['some line']

    crontab.lines = ['some line', '# Ansible: minute testname', '* * * * * some comment']
    crontab.update_job('testname', '*/15 * * * * some comment')

    assert crontab.lines == ['some line', '# Ansible: minute testname', '*/15 * * * * some comment']

    crontab.lines = ['some line']

# Generated at 2022-06-11 06:52:37.431998
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    test = CronTab(None)
    test.lines = ['#Ansible: job1', '0 0 * * * /bin/ls']
    assert test.get_jobnames() == ['job1']
    test.lines = ['#Ansible: job1', '#Ansible: job2', '0 0 * * * /bin/ls']
    assert test.get_jobnames() == ['job1', 'job2']
    test.lines = ['#Ansible: job1', '0 0 * * * /bin/ls', '#Ansible: job2']
    assert test.get_jobnames() == ['job1', 'job2']

# Generated at 2022-06-11 06:52:49.297056
# Unit test for method write of class CronTab
def test_CronTab_write():
    module = Mock()
    cron_tab = CronTab(module, user=None, cron_file="cron_tab_file")
    cron_tab_write_original = cron_tab.write
    assert_raises(CronTabError, cron_tab_write_original)
    assert_raises(CronTabError, cron_tab_write_original, "cron_tab_file")
    module = Mock()
    module.run_command = Mock(return_value=(0, "out", "err"))
    module.get_bin_path = Mock(return_value="cron_cmd")
    module.set_default_selinux_context = Mock()
    cron_tab = CronTab(module, user=None, cron_file="")
    cron_tab_write_original = cr

# Generated at 2022-06-11 06:52:57.986300
# Unit test for function main
def test_main():
    # FIXME: use tempfile.mkdtemp()
    tmpdir = tempfile.mkdtemp(prefix='ansibuletmp')
    cron_file = "%s/crontab.tmp" % (tmpdir)
    module = AnsibleModule({
        "name": "checkdirs",
        "job": "ls -alh > /dev/null",
        "hour": "5",
        "cron_file": cron_file,
        "state": "present",
        "backup": False,
        "minute": "*",
        "day": "*",
        "month": "*",
        "weekday": "*",
        "special_time": None,
        "disabled": False,
        "env": False
    })
    main()
    #assert cron_file == "path/to

# Generated at 2022-06-11 06:53:06.089875
# Unit test for method write of class CronTab
def test_CronTab_write():
    import tempfile

    fd, name = tempfile.mkstemp(prefix='crontab')
    os.close(fd)

    obj = CronTab(None, cron_file=name)
    # 'name' above is already an absolute path; we don't want to turn it into
    # a module argument.
    assert obj.cron_file == name

    try:
        obj.write()
        with open(obj.b_cron_file, 'rb') as f:
            assert f.read() == b''
    finally:
        os.remove(name)



# Generated at 2022-06-11 06:53:16.716883
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    import mock
    class MockFile(object):
        def __init__(self):
            pass
        def close(self):
            pass
    class MockModule(object):
        def __init__(self):
            self.params = {
                'name': 'test_CronTab_add_env',
                'minute': '*',
                'hour': '*',
                'day': '*',
                'month': '*',
                'weekday': '*',
                'job': 'test_job',
                'special_time': None,
                'cron_file': None,
                'enabled': True,
                'user': None}
            self.fail_json = mock.MagicMock()
        def selinux_enabled(self):
            return True

# Generated at 2022-06-11 06:53:19.472896
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    module = AnsibleModule(argument_spec=dict())
    c = CronTab(module)
    assert c.remove_job_file() is True

# Generated at 2022-06-11 06:53:29.472328
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    # TODO test adding a job in the middle of other jobs
    module = AnsibleModule(argument_spec=dict(
        name=dict(type='str', required=True),
        special_time=dict(type='str', required=True),
        job=dict(type='str', required=True),
        state=dict(type='str', required=True),
        minute=dict(type='str', required=True),
        hour=dict(type='str', required=True),
        day=dict(type='str', required=True),
        month=dict(type='str', required=True),
        weekday=dict(type='str', required=True),
    ))

# Generated at 2022-06-11 06:53:32.286258
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    module = AnsibleModule(argument_spec = dict())
    crontab = CronTab(module)
    assert crontab.is_empty() == True

# Generated at 2022-06-11 06:53:38.865860
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    c = CronTab('crontab')
    assert c.get_cron_job(minute='*', hour='1', day='*', month='*', weekday='*', job='echo "Hello World"', special=None, disabled=False) == '* 1 * * * echo "Hello World"'
    assert c.get_cron_job(minute='*', hour='1', day='*', month='*', weekday='*', job='echo "Hello World"', special='daily', disabled=False) == '@daily echo "Hello World"'


# Generated at 2022-06-11 06:55:43.678328
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    # Create a crontab-object from a static string
    cron = CronTab(None, None, None)
    cron_str = "#Ansible: jobname\nfoo=bar\n#Ansible: jobname2\nbar=foo\nbaz=foo\n"
    cron.lines = cron_str.split('\n')

    # Invoke the method under test
    actual = cron.get_envnames()

    # Check the result
    expected = ['foo', 'bar']
    assert actual == expected, "'%s' != '%s'" % (actual, expected)


# Generated at 2022-06-11 06:55:47.561914
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    """Method get_envnames of class CronTab"""
    tab = CronTab(module, user=None, cron_file=None)
    # TODO: fill in the args
    #tab.get_envnames(  )
    raise NotImplementedError()


# Generated at 2022-06-11 06:55:56.266020
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    c = CronTab()
    c.lines = ['foo=bar', 'bar=', 'baz=biz']

    c.update_env('foo', 'foo=baz')
    assert c.lines == ['foo=baz', 'bar=', 'baz=biz']
    c.lines = ['foo=bar', 'bar=', 'baz=biz']

    c.update_env('new', 'new=variable')
    assert c.lines == ['foo=bar', 'bar=', 'baz=biz', 'new=variable']
    c.lines = ['foo=bar', 'bar=', 'baz=biz']

    c.update_env('new', 'new=variable', insertafter='foo')
    assert c.lines == ['foo=bar', 'new=variable', 'bar=', 'baz=biz']
   

# Generated at 2022-06-11 06:56:06.586603
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    # test with empty lines
    lines = []
    crontab = CronTab(AnsibleModuleStub(), cron_file="/etc/cron.d/test")
    crontab.lines = lines
    result = crontab.is_empty()
    assert result

    # test with empty lines with trailing space
    lines = [" "]
    crontab = CronTab(AnsibleModuleStub(), cron_file="/etc/cron.d/test")
    crontab.lines = lines
    result = crontab.is_empty()
    assert result

    # test with lines with content
    lines = ["0 0 * * * dummy_command"]
    crontab = CronTab(AnsibleModuleStub(), cron_file="/etc/cron.d/test")
    crontab.lines = lines

# Generated at 2022-06-11 06:56:16.888088
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    """
    Unit test for method is_empty of class CronTab
    """
    module = AnsibleModule(
        argument_spec = dict()
    )
    module.exit_json = exit_json
    module.fail_json = fail_json

    crontab = CronTab(module)

    job = CronJob(minute='0', hour='0', day='*', month='*', weekday='*', job='/bin/echo test')
    assert crontab.is_empty() is True

    crontab.add_job('test', job)
    assert crontab.is_empty() is False
    crontab.remove_job('test')
    assert crontab.is_empty() is True

    job = CronJob(special='@hourly', job='/bin/echo test')
    crontab.add_

# Generated at 2022-06-11 06:56:18.103845
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    assert CronTab.find_env('') == [0]


# Generated at 2022-06-11 06:56:27.749141
# Unit test for method read of class CronTab
def test_CronTab_read():
    class TestModule(object):
        def __init__(self):
            self.params = {}
    module = TestModule()
    module.params["cron_file"] = "/file"
    module.params["cron_definition"] = "job"
    module.params["cron_special"] = "special"
    module.params["cron_disabled"] = True
    module.params["cron_minute"] = "minute"
    module.params["cron_hour"] = "hour"
    module.params["cron_day"] = "day"
    module.params["cron_month"] = "month"
    module.params["cron_weekday"] = "weekday"
    module.params["cron_job"] = "job"
    module.params["cron_name"] = "name"

# Generated at 2022-06-11 06:56:36.727858
# Unit test for method find_env of class CronTab

# Generated at 2022-06-11 06:56:39.821213
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    ct = CronTab(module, cron_file='test')
    ct._update_env = MagicMock()
    ct.remove_env('test')
    assert ct._update_env.called



# Generated at 2022-06-11 06:56:48.997089
# Unit test for method read of class CronTab