

# Generated at 2022-06-11 06:50:13.936249
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    crontab = CronTab(AnsibleModule(argument_spec={}))
    crontab.lines = ['#Ansible: job1', '00 01 * * * root env > /tmp/env', '00 02 * * * root env > /tmp/env']
    assert crontab.remove_job('job1') == True
    assert crontab.lines == ['#Ansible: job1', '00 02 * * * root env > /tmp/env']



# Generated at 2022-06-11 06:50:17.934035
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    module = AnsibleModule(
        argument_spec = dict()
    )
    test = CronTab(module)
    assert test.lines == []
    test.add_env('TEST=testing')
    assert test.lines == ['TEST=testing']


# Generated at 2022-06-11 06:50:21.425421
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    mytab = CronTab("user")
    mytab.lines = ["foo=bar", "#Ansible: test", "1 2 3 4 5 test /etc/test.sh", "baz=qux"]
    assert mytab.get_envnames() == ["foo", "baz"]


# Generated at 2022-06-11 06:50:23.798152
# Unit test for method render of class CronTab
def test_CronTab_render():
    test_cmp = CronTab(None)
    test_cmp.lines = ['test text']

    if test_cmp.render() != 'test text\n':
        raise AssertionError()



# Generated at 2022-06-11 06:50:31.322003
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    crontab = CronTab(module=None, user='user', cron_file=None)
    crontab_job = crontab.get_cron_job(minute='0,30', hour='*', day='*', month='*', weekday='*', job='/usr/bin/command arg1 arg2 arg3 arg4', special=None, disabled=False)
    assert crontab_job == '0,30 * * * * user /usr/bin/command arg1 arg2 arg3 arg4'



# Generated at 2022-06-11 06:50:39.147124
# Unit test for method write of class CronTab
def test_CronTab_write():
    class Module(object):
        def __init__(self):
            self.params = {'name': 'cron_test', 'special_time': 'reboot', 'minute': '1', 'hour': '2', 'day': '3', 'month': '4', 'weekday': '5', 'job': 'test', 'state': 'present'}
            self.module = None

        def fail_json(self, msg):
            raise CronTabError(msg)

        def get_bin_path(self, binary, required=False):
            if binary == 'crontab':
                return binary
            elif required:
                raise CronTabError("Unable to find required binary in path")
            else:
                return None


# Generated at 2022-06-11 06:50:48.982100
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    crontab_instance = CronTab(module=None, user=None, cron_file=None)
    job_name = "test_job"
    job_line = "* * * * * /bin/false"
    job_text = '{0} {1}\n{2}\n'.format(crontab_instance.do_comment(name=job_name), job_line, job_line)
    crontab_instance.lines = job_text.splitlines()
    assert len(crontab_instance.lines) == 3, "Not enough lines in test data"
    assert not crontab_instance.is_empty()


# Generated at 2022-06-11 06:50:53.107953
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    out = u'\n'
    new = CronTab(None, cron_file='/tmp/crontab')
    # compare original returned object with the desired object
    new.lines = out.splitlines()
    check = new.is_empty()
    assert check == True


# Generated at 2022-06-11 06:50:54.593746
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    assert CronTab(None).is_empty()



# Generated at 2022-06-11 06:50:55.811562
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    assert True



# Generated at 2022-06-11 06:51:47.854594
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    cron = CronTab(None)
    assert cron.remove_job_file() == False

    cron.n_existing = 'test'
    assert cron.remove_job_file() == False

    cron_file = os.path.join('/etc/cron.d', 'test_cron')
    open(cron_file, 'a').close()
    cron.cron_file = cron_file

    try:
        assert cron.remove_job_file() == True
    finally:
        os.remove(cron_file)

# Generated at 2022-06-11 06:51:55.914515
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    # Fixture for testing the CronTab class
    crontab = CronTab(None, None)
    crontab.lines.append("#Ansible: job1")
    crontab.lines.append("* * * * * /bin/true")
    crontab.lines.append("#Ansible: job2")
    crontab.lines.append("* * * * * /bin/true")
    crontab.lines.append("#Ansible: job3")
    crontab.lines.append("* * * * * /bin/true")

    # Test case 1
    assert crontab.get_jobnames() == ["job1", "job2", "job3"]

# Generated at 2022-06-11 06:52:06.749431
# Unit test for constructor of class CronTab
def test_CronTab():
    ct = CronTab(None)
    assert ct.user == None
    assert ct.lines == None
    assert ct.root == True
    assert ct.cron_cmd == '/usr/bin/crontab'
    assert ct.cron_file == None

    ct = CronTab(None, user='__user__', cron_file='/tmp/__cron_file__')
    assert ct.user == '__user__'
    assert ct.lines == None
    assert ct.root == True
    assert ct.cron_cmd == '/usr/bin/crontab'
    assert ct.cron_file == '/tmp/__cron_file__'

    ct.read()
    assert ct.lines == []

# Generated at 2022-06-11 06:52:16.606166
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    '''
    Unit test for way to remove crontab job in class CronTab
    '''
    # Create a new module
    module = AnsibleModule(
        argument_spec=dict(
            jobname=dict(type='str', required=True),
        ),
        supports_check_mode=True
    )

# Generated at 2022-06-11 06:52:19.933864
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    # Test Case #1:
    obj = CronTab(None)
    result = obj.get_cron_job('*/15', '*', '*', '*', '*', "touch /tmp/a", None, False)
    assert result == "*/15 * * * * touch /tmp/a"


# Unit test class for testing the CronTab class

# Generated at 2022-06-11 06:52:26.350115
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    assert CronTab.is_empty('')
    assert CronTab.is_empty('\n')
    assert CronTab.is_empty('\n  \n  \n')
    assert not CronTab.is_empty('\n  \n  \n  something')
    assert not CronTab.is_empty('\n  \n  something\n')
    assert not CronTab.is_empty('something')

#################################################################
# Tests for method get_jobnames of class CronTab
#################################################################

# Generated at 2022-06-11 06:52:30.637116
# Unit test for constructor of class CronTab
def test_CronTab():
    cron = CronTab()

    # Set the user
    cron.user = 'root'
    crontab = cron.render()
    assert crontab == ''

    # Unset the user
    cron.user = None
    crontab = cron.render()
    assert crontab == ''


# Generated at 2022-06-11 06:52:41.390773
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    # crontab = CronTab(user='root')
    crontab = CronTab()
    name = 'test'
    job =  "30 7 * * 3 /path/to/script"
    spec = 'reboot'
    disabled = False
    job = crontab.get_cron_job('30', '7', '*', '*', '3', job, spec, disabled)
    crontab.add_job(name, job)
    job = crontab.get_cron_job('30', '7', '*', '*', '3', job, spec, disabled)
    # no name, no failure
    crontab.add_job(None, job)
    # job with name twice
    name = 'test3'

# Generated at 2022-06-11 06:52:52.964979
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    """
    Test if .is_empty() works positive.
    """
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    c = CronTab(module)
    assert c.is_empty()

    # create the crontab
    cron1 = '* * * * * touch /tmp/1\n'
    cron2 = '* * * * * touch /tmp/2\n'
    required_cron1 = ''
    required_cron2 = ''
    if module.selinux_enabled():
        required_cron1 = module.set_default_selinux_context(cron1, False)
        required_cron2 = module.set_default_selinux_context(cron2, False)
    else:
        required_cron1 = cr

# Generated at 2022-06-11 06:52:57.292457
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    crontab = CronTab(module)
    lines = list()
    for i in range(0, 5):
        lines.append("%s=%s" % (random_letters(), random_letters()))
    crontab.lines = lines
    assert len(lines) == len(crontab.get_envnames())



# Generated at 2022-06-11 06:54:51.725606
# Unit test for method read of class CronTab
def test_CronTab_read():
	# Attempt to read in the crontab from the system
		self.lines = []
		if self.cron_file:
			# read the cronfile
			try:
				f = open(self.b_cron_file, 'rb')
				self.n_existing = to_native(f.read(), errors='surrogate_or_strict')
				self.lines = self.n_existing.splitlines()
				f.close()
			except IOError:
				# cron file does not exist
				return
			except Exception:
				raise CronTabError("Unexpected error:", sys.exc_info()[0])

# Generated at 2022-06-11 06:54:58.940671
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    c = CronTab('test')
    c.lines.append('job1=foo')
    c.lines.append('job2=bar')
    c.lines.append('job3=foobar')
    assert c.find_env('job1') == [0, 'job1=foo']
    assert c.find_env('job2') == [1, 'job2=bar']
    assert c.find_env('job3') == [2, 'job3=foobar']
    assert c.find_env('jobx') == []


# Generated at 2022-06-11 06:55:09.305627
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    # We may need a tempdir or something similar #future enhancement
    # The focus here is on the normal execution path.
    class ModifiedModule(object):
        def run_command(self, command):
            # the command is unimportant here
            n_existing = ''
            lines = n_existing.splitlines()
            count = 0
            for l in lines:
                if count > 2 or (not re.match(r'# DO NOT EDIT THIS FILE - edit the master and reinstall.', l) and
                                 not re.match(r'# \(/tmp/.*installed on.*\)', l) and
                                 not re.match(r'# \(.*version.*\)', l)):
                    self.lines.append(l)
                else:
                    pattern = re.escape(l) + '[\r\n]?'
                    self.n

# Generated at 2022-06-11 06:55:21.148185
# Unit test for method read of class CronTab
def test_CronTab_read():
    fake_module = Mock()
    config = """
#Ansible: myjob
* * * * * /bin/echo hello world
"""

    if not os.path.isdir('/tmp/ansible_test_crontab'):
        os.makedirs('/tmp/ansible_test_crontab')
    f = open('/tmp/ansible_test_crontab/test_read', 'wb')
    f.write(to_bytes(config, errors='surrogate_or_strict'))
    f.close()

    ct = CronTab(fake_module, cron_file='test_read')
    assert len(ct.lines) == 2
    assert ct.lines[0] == '#Ansible: myjob'

# Generated at 2022-06-11 06:55:23.745430
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    assert CronTab._CronTab__do_comment(CronTab,'test name') == "#Ansible: test name", "Test failed"


# Generated at 2022-06-11 06:55:25.646321
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
   ct = CronTab()
   job = ct.do_add_job("comment_job","job")
   #assert job == "comment_job /tmp/test\n"


# Generated at 2022-06-11 06:55:31.885107
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    ct = CronTab(user='test')
    test_vars_1 = ['A=1\n', 'B=2\n', 'C=3\n']
    for test_var in test_vars_1:
        ct.add_env(test_var)
    assert ct.lines == test_vars_1
    ct.add_env('E=5\n',insertafter='C')
    assert ct.lines == test_vars_1 + ['E=5\n']
    ct.add_env('D=4\n',insertbefore='E')
    assert ct.lines == test_vars_1 + ['E=5\n', 'D=4\n']


# Generated at 2022-06-11 06:55:35.084166
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    c = CronTab(None, user=None)
    c.lines = ['USER=foo', 'BAR=baz']
    assert c.get_envnames() == ['USER', 'BAR']



# Generated at 2022-06-11 06:55:46.377797
# Unit test for method read of class CronTab
def test_CronTab_read():
    import tempfile
    module = AnsibleModule(
        argument_spec = dict(
            user=dict(default='root', type='str'),
            cron_file=dict(default='', type='str'),
        ),
        supports_check_mode=True
    )

    test_read = CronTab(module, '', '')
    f = tempfile.NamedTemporaryFile(mode='wt', delete=False)
    f.write('\n'.join(test_read.lines))
    f.close()
    test_read.cron_file = f.name
    test_read.b_cron_file = to_bytes(f.name, errors='surrogate_or_strict')
    test_read.read()

    module.exit_json(changed=False)


# Generated at 2022-06-11 06:55:49.435961
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
  ct = CronTab('test.cron')

  # test with valid job, should succeed
  assert ct.remove_job('test') == False
