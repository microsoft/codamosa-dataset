

# Generated at 2022-06-11 06:50:03.869870
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    ct = CronTab('user')
    ct.add_env('test=test')
    assert ct.lines == ['test=test']



# Generated at 2022-06-11 06:50:09.088860
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    schedule = '*/10 * * * *'
    job_name = 'job_1'
    command = 'test_command'
    cron_job = CronTab.get_cron_job(schedule, job_name, command, False)
    assert cron_job == '*/10 * * * * #Ansible: job_1\ntest_command'
    job_name = None
    cron_job = CronTab.get_cron_job(schedule, job_name, command, False)
    assert cron_job == '*/10 * * * * #Ansible: None\ntest_command'
    job_name = 'job_2'
    command = None
    cron_job = CronTab.get_cron_job(schedule, job_name, command, False)
    assert cron

# Generated at 2022-06-11 06:50:09.808631
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    pass

# Generated at 2022-06-11 06:50:19.999585
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    # testing a module that should return nothing
    import os
    import sys
    import tempfile
    import time
    import StringIO
    import shutil
    import pwd

    # import the module to test
    from AnsibleModule import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from crontab import CronTab, CronTabError

    # set up some read-only variables
    os.environ['INVENTORY_ENABLED'] = 'False'
    os.environ['ANSIBLE_KEEP_REMOTE_FILES'] = 'True'
    os.environ['ANSIBLE_REMOTE_TEMP'] = '/tmp/ansible'

# Generated at 2022-06-11 06:50:24.384027
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    ct = CronTab(None, '/usr/bin/python', '/home/anisble/crontab')
    lines = ['test1']
    comment = 'test3'
    job = 'test4'
    ct.do_add_job(lines, comment, job)
    assert lines[1] == comment, "Add comment failed."
    assert lines[2] == job, "Add job failed."


# Generated at 2022-06-11 06:50:35.333996
# Unit test for function main

# Generated at 2022-06-11 06:50:40.093615
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    ct = CronTab(None)
    ct.lines = ['', '', '#Ansible: name1', 'job1']
    jobnames = ct.get_jobnames()
    assert jobnames == ['name1']


# Generated at 2022-06-11 06:50:45.549719
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    module = AnsibleModule(
        argument_spec = dict()
    )
    crontab = CronTab(module)
    crontab.add_job("test", "job")
    assert crontab.lines == ["#Ansible: test", "job"]
    # TODO more tests for this method


# Generated at 2022-06-11 06:50:55.361807
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    """
    Run the update_job() method of the class to test.
    """
    # set up the test data vars
    # set up the args required by the module
    args = dict()
    args.update(dict(name='test_unit_test_name'))
    args.update(dict(job='test_unit_test_job'))

    # set up the crontab to read in
    cronfile = tempfile.NamedTemporaryFile(mode='wb', delete=False)
    cronfile.write(to_bytes('#Ansible: test_unit_test_name' + u'\n'))
    cronfile.write(to_bytes('5 10 * * * root /usr/bin/test.sh' + u'\n'))
    cronfile.close()

    # set up

# Generated at 2022-06-11 06:51:02.593726
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    args = {}
    args['name'] = "myjob"
    args['job'] = "do this, because I said so"
    args['disabled'] = False

    crontab = CronTab(None, "bob", "/tmp/mycron")
    crontab.do_add_job(crontab.lines, "Ansible: myjob", "do this, because I said so")
    assert crontab.find_job("myjob", "do this, because I said so") == ["Ansible: myjob", "do this, because I said so"]


# Generated at 2022-06-11 06:51:54.366567
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    crontab = CronTab()
    job = crontab.new(command='/bin/foo', comment='ansible')
    job.minute.every(1)
    crontab.write('/tmp/crontab')
    crontab.read()
    changed = crontab.remove_job(job.comment)
    assert changed
    crontab.write()
    crontab.remove_job_file()


# Generated at 2022-06-11 06:52:04.874298
# Unit test for method remove_env of class CronTab

# Generated at 2022-06-11 06:52:12.186123
# Unit test for method read of class CronTab
def test_CronTab_read():
    # Initialize the CronTab class
    ct = CronTab(module, user=None, cron_file=None)

    # Test the read function
    ct.read()

    # check if the file was not found
    if len(ct.lines) == 0:
        pass
    # check if we have an ansible line
    elif ct.lines[0].strip() == '#Ansible: ansible-job':
        pass
    else:
        raise Exception('Something went wrong with the CronTab class!')


# Generated at 2022-06-11 06:52:16.089729
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    c = CronTab(None, 'bob')
    c.lines = ['#Ansible: foo', '* * * * * do something', '#Ansible: bar', '* * * * * do something else', 'an old fashioned cron entry']
    assert sorted(c.get_jobnames()) == ['bar', 'foo']



# Generated at 2022-06-11 06:52:20.328921
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    input = "* * * * * /home/user/bin/script\n#Ansible: foo\n"
    result = "* * * * * /home/user/bin/script\n"
    ct = CronTab(None)
    ct.lines = input.splitlines()
    ct.do_remove_job(ct.lines, '#Ansible: foo', "")
    assert ct.lines == result.splitlines()

# Generated at 2022-06-11 06:52:26.907912
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    crontab = CronTab(None, None, None)
    crontab.lines = ['#Ansible: test-job', '* * * * * touch /tmp/testfile']
    assert crontab.get_envnames() == []

    crontab = CronTab(None, None, None)
    crontab.lines = ['#Ansible: test-job', '* * * * * touch /tmp/testfile', 'HOME=/home/']
    assert crontab.get_envnames() == ['HOME']


# Generated at 2022-06-11 06:52:37.016086
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    # Method object
    obj = CronTab()

    # Constructor test
    obj2 = CronTab(user='a', cron_file='b')
    assert obj2.user == 'a'
    assert obj2.cron_file == 'b'
    # Method remove_job
    assert obj.remove_job(name='a') is None
    # Method add_job
    assert obj.add_job(name='a', job='b') is None
    # Method update_job
    assert obj.update_job(name='a', job='b') is None
    # Method remove_env
    assert obj.remove_env(name='a') is None
    # Method add_env
    assert obj.add_env(decl='a') is None
    assert obj.add_env(decl='a', insertbefore='b') is None

# Generated at 2022-06-11 06:52:43.881237
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    try:
        module = AnsibleModule(argument_spec=dict())
    except Exception:
        module = AnsibleModule(argument_spec=dict())

    cron_tab = CronTab(module)

    lines = []
    comment = '#Ansible: test-comment'
    job = 'test job'

    cron_tab.do_add_job(lines, comment, job)

    assert lines[0] == comment
    assert lines[1] == job

# Generated at 2022-06-11 06:52:50.485676
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    ct = CronTab("user")
    assert ct.get_envnames() == []

    ct.lines.append("HISTFILE=/dev/null")
    assert ct.get_envnames() == ['HISTFILE']

    ct.lines.append("PS1=$")
    assert ct.get_envnames() == ['HISTFILE', 'PS1']



# Generated at 2022-06-11 06:52:54.497981
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():

    # Create the object
    tab = CronTab()

    result = tab.remove_env('name')
    assert result is None



# Generated at 2022-06-11 06:54:52.055527
# Unit test for method render of class CronTab
def test_CronTab_render():
    ct = CronTab(None)
    ct.lines = ["#Ansible: job1", "@reboot job1"]
    assert ct.render() == '#Ansible: job1\n@reboot job1\n'


# Generated at 2022-06-11 06:54:58.162359
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    ct = CronTab(None, None, 'unittest')
    ct.lines = [
        '#Ansible: foo',
        '* * * * * /foo/bar/baz',
        '#Ansible: name with spaces',
        '* * * * * /foo/bar/baz',
    ]
    assert ct.get_jobnames() == ['foo', 'name with spaces']


# Generated at 2022-06-11 06:55:05.759840
# Unit test for method render of class CronTab
def test_CronTab_render():
    ct = CronTab(None)

    ct.lines = ['first line', 'second line']
    assert ct.render() == 'first line\nsecond line'

    ct.lines = ['first line', 'second line', '', '', '', '']
    assert ct.render() == 'first line\nsecond line'

    ct.lines = ['', '', '', '', '', 'first line', 'second line']
    assert ct.render() == 'first line\nsecond line'

    ct.lines = []
    assert ct.render() == ''


# Generated at 2022-06-11 06:55:16.705413
# Unit test for method do_remove_env of class CronTab

# Generated at 2022-06-11 06:55:22.896719
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    '''
    Test function remove_job of CronTab class.
    '''

    # Test fixture
    removed_job = CronTab.remove_job(self, name)
    # Test condition
    try:
        pass
    except Exception as e:
        pass
    # Test assertion
    assert (pass_or_fail)


# Generated at 2022-06-11 06:55:24.634077
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    tab = CronTab(None)
    assert tab.update_job('test', '') == True


# Generated at 2022-06-11 06:55:29.259588
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    import crontab
    c=crontab.CronTab()
    # make sure rosalind.log is a file
    lines=["ENV1=value","ENV2=value"]
    assert [0, lines[0]] == c.find_env("ENV1")
    assert [1, lines[1]] == c.find_env("ENV2")

ansible.module_utils.basic = basic
main()

# Generated at 2022-06-11 06:55:36.394923
# Unit test for method render of class CronTab
def test_CronTab_render():
    ct = CronTab(None)
    # simple test
    assert ct.render() == '', 'Simple test failed'
    # first line only
    ct.lines = ['', '', 'a']
    assert ct.render() == 'a', 'First line only test failed'
    # test with trailing space
    ct.lines = ['', ' ', 'a ']
    assert ct.render() == 'a ', 'Trailing space test failed'

# Generated at 2022-06-11 06:55:37.492849
# Unit test for method write of class CronTab
def test_CronTab_write():
    assert True



# Generated at 2022-06-11 06:55:39.795591
# Unit test for constructor of class CronTab
def test_CronTab():
    return CronTab('fake')


# ===========================================
# Main
# ===========================================
