

# Generated at 2022-06-11 06:50:16.207180
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    test_obj = CronTab(None, 'user')
    test_obj.lines = ['#Ansible: test_job\n', '#Ansible: test_environment\n', '* * * * * /bin/echo "hello"\n']
    assert test_obj.update_job('test_job', '* * * * * /bin/echo "world"') == True
    assert test_obj.lines == ['#Ansible: test_job\n', '#Ansible: test_environment\n', '* * * * * /bin/echo "world"\n']
    assert test_obj.update_job('test_job_not_exist', '* * * * * /bin/echo "world"') == False

# Generated at 2022-06-11 06:50:21.704859
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    module = AnsibleModule(argument_spec=dict(
        name=dict(default='FOO', type='str'),
        value=dict(default='BAR', type='str'),
        insertbefore=dict(default=False, type='str'),
        insertafter=dict(default=False, type='str'),
        state=dict(default='present', choices=['present', 'absent'])
    ))

    my_crons = [
        'SHELL=/bin/bash',
        'MAILTO=root',
        'MYVAR=myvalue',
        '',
        '#Ansible: cronjob1',
        '#Ansible: cronjob2',
        '0 * * * * /usr/bin/uptime'
    ]

# Generated at 2022-06-11 06:50:24.044760
# Unit test for method read of class CronTab
def test_CronTab_read():
    arg = dict(
        cron_file = 'cron_file.txt',
    )
    out = CronTab(module, **arg).read()
    assert out is None


# Generated at 2022-06-11 06:50:28.832265
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    ct = CronTab()
    ct.add_env('PATH=/bin:/usr/bin', insertafter='SHELL')
    ct.add_env('SHELL=/bin/sh', insertbefore='HOME')
    assert 'PATH=/bin:/usr/bin' in ct.lines


# Generated at 2022-06-11 06:50:37.979823
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    import unittest
    import yaml
    from ansible.module_utils import basic

    class CronTabTest(unittest.TestCase):

        def setUp(self):
            self.user  = 'test_user'
            self.job1 = {'name': 'test_job1', 'minute': '*/15', 'hour': '*', 'day': '*', 'month': '*', 'weekday': '*',
                        'job': "echo 'job1'", 'special': '', 'disabled': False}

            self.job2 = {'name': 'test_job2', 'minute': '*/5', 'hour': '*', 'day': '*', 'month': '*', 'weekday': '*',
                        'job': "echo 'job2'", 'special': '', 'disabled': False}

           

# Generated at 2022-06-11 06:50:46.849453
# Unit test for method read of class CronTab
def test_CronTab_read():
    module = AnsibleModule(argument_spec={
        'cron_file': {'type': 'str', 'default': None},
        'user': {'type': 'str', 'default': None},
    })

    ct = CronTab(module=module, user=None)
    ct.read()
    assert len(ct.lines) > 0
    assert ct.lines[0] == '#Ansible: minutely job'
    assert ct.lines[1] == '@daily echo "hello"'


# Generated at 2022-06-11 06:50:50.572374
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    cron = CronTab("test")
    cron.lines = [
        "* * * * * /bin/echo test",
        "#Ansible: test"
    ]
    assert cron.remove_job("test") == []


# Generated at 2022-06-11 06:50:57.989142
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    def check(description, minute, hour, day, month, weekday, *args):
        job = CronTab(None, None, None)
        found = job.find_job(description, get_cron_job(minute, hour, day, month, weekday, ''))
        assert found == [description, get_cron_job(minute, hour, day, month, weekday, '')]

    def fail(description, minute, hour, day, month, weekday, *args):
        job = CronTab(None, None, None)
        found = job.find_job(description, get_cron_job(minute, hour, day, month, weekday, ''))
        assert found == []
    check('1', '*', '*', '*', '*', '*', 'ls')

# Generated at 2022-06-11 06:51:02.875009
# Unit test for method render of class CronTab
def test_CronTab_render():
    crontab = CronTab('root')
    crontab.lines = [
      "#Ansible: name",
      "*/5 * * * * echo hi"
    ]
    assert crontab.render() == '\n'.join([
      "#Ansible: name",
      "*/5 * * * * echo hi"
    ]) + '\n'



# Generated at 2022-06-11 06:51:12.372608
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    module_args = {
        'name': '* * * * * echo "test"',
        'user': 'nobody',
        'special_time': '',
        'state': 'present',
        'minute': '*',
        'hour': '*',
        'day': '*',
        'month': '*',
        'weekday': '*',
        'job': 'echo "test"',
        'disabled': False,
    }

# Generated at 2022-06-11 06:52:00.138621
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    crontab = CronTab(**{u'user': None})
    crontab.lines = [u'#Ansible:jobs_test_user']
    crontab.jobnames = [u'jobs_test_user']
    assert crontab.get_jobnames() == [u'jobs_test_user']

# Generated at 2022-06-11 06:52:04.771314
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    m = MagicMock()
    c = CronTab(m)
    c.lines = []

    c.add_env(decl='DB_BACKUP_SERVER=localhost')

    compare = ['DB_BACKUP_SERVER=localhost']
    assert c.lines == compare


# Generated at 2022-06-11 06:52:07.825511
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    crontab = CronTab(user=None, cron_file=None)

    if crontab.remove_env(None):
        assert True
    else:
        assert False

# Generated at 2022-06-11 06:52:14.729336
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    ct = CronTab()

    ct.lines = ['MAILTO=email@example.com', '# MAILTO=email2@example.org', 'DISPLAY=hostname']

    assert [0, 'MAILTO=email@example.com'] == ct.find_env('MAILTO')
    assert [2, 'DISPLAY=hostname'] == ct.find_env('DISPLAY')
    assert [] == ct.find_env('ANOTHER')


# Unit tests for method find_job of class CronTab

# Generated at 2022-06-11 06:52:15.940070
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames(): 
    assert CronTab("name").get_envnames() == "name" 

# Generated at 2022-06-11 06:52:18.317819
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    crontab = CronTab(None)
    comment = 'comment_string'
    assert crontab.do_comment(comment) == '#Ansible: comment_string'

# Generated at 2022-06-11 06:52:24.434932
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    ct = CronTab(None, None, None)
    ct.lines.append('#Ansible: test')
    ct.lines.append('* * * * * echo "blah"')
    ct.remove_job('test')
    assert(ct.lines == ['* * * * * echo "blah"'])


# Generated at 2022-06-11 06:52:33.813764
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    c = CronTab({})
    c.root = False
    c.cron_file = None
    result = c.get_cron_job('*', '*', '*', '*', '*', '/bin/echo "hello"', None, False)
    assert result == "* * * * * /bin/echo \"hello\""
    c.root = True
    result = c.get_cron_job('*', '*', '*', '*', '*', '/bin/echo "hello"', None, False)
    assert result == "* * * * * root /bin/echo \"hello\""
    c.root = False
    c.cron_file = '/etc/cron.d/hello'

# Generated at 2022-06-11 06:52:44.967801
# Unit test for method read of class CronTab
def test_CronTab_read():
    import sys

    # object
    class State:
        def __init__(self):
            self.changed = False
            self.failed = False
            self.parsed_params = False

        def fail_json(self, msg):
            self.failed = True
            self.msg = msg

        def exit_json(self, **params):
            self.parsed_params = True
            [setattr(self, k, v) for k, v in params.items()]
            self.changed = params.get("changed", False)

    class AnsibleModule:
        def __init__(self):
            self.params = {}
            self.state = State()

        def fail_json(self, msg):
            return self.state.fail_json(msg)


# Generated at 2022-06-11 06:52:55.733082
# Unit test for constructor of class CronTab
def test_CronTab():
    ct = CronTab({'b_PATH': '/sbin:/usr/sbin:/bin:/usr/bin', 'CMD_ENV': ''})
    assert ct.user == None
    assert ct.cron_file == None
    assert ct.root == True
    assert ct.lines == []
    assert ct.ansible == '#Ansible: '
    assert ct.n_existing == ''

    ct = CronTab({'b_PATH': '/sbin:/usr/sbin:/bin:/usr/bin', 'CMD_ENV': ''}, user='johndoe', cron_file='def')
    assert ct.user == 'johndoe'
    assert ct.cron_file == '/etc/cron.d/def'
    assert ct.root == True
   

# Generated at 2022-06-11 06:54:43.225272
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    cron_file = 'testcron_root'

# Generated at 2022-06-11 06:54:49.337719
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    test = CronTab(None, None, None)
    # Test with a couple values
    lines = [
        'foo',
        'bar',
        'baz']
    comment = '#Ansible: test'
    job = 'echo test'
    result = test.do_remove_job(lines, comment, job)
    expected = None
    if result != expected:
        raise AssertionError("do_remove_job generated '{}' instead of '{}'".format(result, expected))



# Generated at 2022-06-11 06:54:56.912264
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    from ansible.module_utils.basic import AnsibleModule
    import json

    # Mock the AnsibleModule
    module = AnsibleModule(argument_spec=dict(
        baz=dict(type='str', required=True),
    ))

    c = CronTab(module, None, None)
    c.lines = ['#Ansible: foo', 'a', 'b', '#Ansible: bar', 'b', 'c']
    result = c.get_jobnames()
    assert result == ['foo', 'bar']


# Generated at 2022-06-11 06:55:02.600609
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    cron = CronTab('/etc/cron.d/ansible_test_file')
    cron.lines = [
    'VAR1=1234',
    'VAR2=5678',
    '#Ansible: test',
    '1 2 3 4 5 /bin/sh'
    ]

    cron.do_remove_env(cron.lines, 'VAR1=1234')

    assert cron.lines == [
    'VAR2=5678',
    '#Ansible: test',
    '1 2 3 4 5 /bin/sh'
    ]


# Generated at 2022-06-11 06:55:13.058654
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():

    # Run method with various inputs
    # Expect some values to not be found
    # Expected: [None]
    print(CronTab.find_env(None))
    # Expected: []
    print(CronTab.find_env(None, None))
    # Expected: []
    print(CronTab.find_env(None, None, None))
    # Expected: []
    print(CronTab.find_env(None, None, None, None))
    # Expected: []
    print(CronTab.find_env(None, None, None, None, None))
    # Expected: []
    print(CronTab.find_env(None, None, None, None, None, None))
    # Expected: []

# Generated at 2022-06-11 06:55:17.246508
# Unit test for function main
def test_main():
    mytest = CronModule()

    mytest.module.params = {
        "name": "check dirs",
        "job": "ls -alh > /dev/null",
    }
    mytest.module.check_mode = False
    mytest.module._diff = False
    mytest.main()
    assert mytest.module.changed is True
    assert mytest.module.jobs[0] == "check dirs"

    #add a new job
    mytest.module.params = {
        "name": "check dir",
        "job": "ls -alh > /dev/null",
    }
    mytest.module.check_mode = False
    mytest.module._diff = False
    mytest.main()
    assert mytest.module.changed is True

# Generated at 2022-06-11 06:55:26.509715
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    """
    Test is_empty method of class CronTab
    """

    if platform.system() == 'AIX':
        pytest.skip("AIX needs to be further tested")

    cron = CronTab(module=None)
    cron.lines = []
    assert cron.is_empty()

    cron.lines = ['#Ansible: test']
    assert not cron.is_empty()

    cron.lines = ['#Ansible: test', 'test2']
    assert not cron.is_empty()

    cron.lines = []
    assert cron.is_empty()




# Generated at 2022-06-11 06:55:37.659238
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    cron_lines = """#Ansible: task1
10 15 * * * /usr/bin/echo 'task1: 123456789' >> /tmp/cron_output
#Ansible: task2
10 16 * * * /usr/bin/echo 'task2: 123456789' >> /tmp/cron_output
#Ansible: task3
10 17 * * * /usr/bin/echo 'task3: 123456789' >> /tmp/cron_output"""
    crontab = CronTab(None, cron_file=None)
    crontab.lines = cron_lines.splitlines()
    crontab.update_job('task2', "10 16 * * * /usr/bin/echo 'task2: 123456789' >> /tmp/cron_output_update")
   

# Generated at 2022-06-11 06:55:49.043038
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    # FIXME implement test
    # module = AnsibleModule(
    #     argument_spec=dict(
    #         name=dict(type

# Generated at 2022-06-11 06:55:56.909699
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    # Create test object
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    crontab = CronTab(module)

    # Create test data
    name = None
    decl = "foo=bar"
    crontab.lines = []

    # Pre-test state
    assert crontab.lines == []

    # Run test
    crontab.update_env(name, decl)

    # Test result
    assert crontab.lines == [decl]

    # Test no name
    crontab.lines = []
    name = None
    crontab.update_env(name, decl)
    assert crontab.lines == [decl]

    # Test name
    crontab.lines = []
    name = "foobar"
    crontab