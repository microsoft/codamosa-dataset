

# Generated at 2022-06-11 06:50:23.119070
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    ct = CronTab(None, None, '/home/ansi/ct.txt')
    ansiblename1 = ct.do_comment('1')
    ansiblename2 = ct.do_comment('2')
    ansiblename3 = ct.do_comment('3')
    ansiblename4 = ct.do_comment('4')
    ansiblename5 = ct.do_comment('5')
    ansiblename6 = ct.do_comment('6')
    ansiblename7 = ct.do_comment('7')
    job1 = ct.get_cron_job('1', '2', '3', '4', '5', 'job1', None, False)

# Generated at 2022-06-11 06:50:25.189640
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    args = dict()
    args['module'] = FakeModule()

    crontab = CronTab(**args)
    assert crontab.remove_job_file() == False


# Generated at 2022-06-11 06:50:33.091165
# Unit test for function main
def test_main():
    class MockModule:
        def __init__(self, **kwargs):
            self.params = kwargs
            self.debug = lambda x, y: None
            self.exit_json = lambda **kwargs: None
            self.fail_json = lambda **kwargs: None
            self.check_mode = False
            self._diff = False
            if '_diff' in kwargs:
                self._diff = kwargs['_diff']

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:50:39.947258
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    module = AnsibleModule({})
    test_cronjob = CronTab(module)
    # test if the crontab file is empty
    assert test_cronjob.is_empty()
    test_cronjob.add_job('test', '* * * * * sleep 1')
    # test if do_add_job method is called
    assert test_cronjob.update_job('test', '* * * * * sleep 1')


# Generated at 2022-06-11 06:50:48.982063
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    module = AnsibleModule(
        argument_spec={
            'backup_file': {'required': False, 'type': 'str'},
            'cron_file': {'required': False, 'type': 'str'},
        },
        supports_check_mode=True
    )

    # TODO implement unit tests
    # crontab = CronTab(module, user=None, cron_file=None)
    # is_empty = crontab.is_empty(name=None)
    # assert is_empty == 'expected result'

    module.exit_json(changed=False)


# Generated at 2022-06-11 06:50:54.734413
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    crontab = CronTab(module, user=None, cron_file=None)
    lines = []
    lines.append('hello=world')
    lines.append('good=bye')
    lines.append('bye=bye')
    crontab.do_remove_env(lines, 'hello=world')
    assert lines[0] == 'good=bye'
    assert lines[1] == 'bye=bye'
    assert len(lines) == 2
    return 0

# Generated at 2022-06-11 06:51:04.592969
# Unit test for function main

# Generated at 2022-06-11 06:51:10.916517
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    # Initialize 'remove_job' method paramater
    name = None

    # Initialize class instance
    ct_instance = CronTab(module, user=None, cron_file=None)

    # Call 'remove_job' method
    result = ct_instance.remove_job(name)

    # Check result type
    if not isinstance(result, bool):
        raise AssertionError("Expected 'bool' result type, got '%s'"
                             % type(result))



# Generated at 2022-06-11 06:51:17.540956
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    crontab = CronTab(None)
    crontab.lines = ['00 14 * * * foo', '00 15 * * * bar', '#Ansible: foo', '00 18 * * * foo']
    assert crontab.find_job('foo') == ['foo', '00 14 * * * foo']
    assert crontab.find_job('bar') == []
    assert crontab.find_job('foo', '00 18 * * * foo') == ['foo', '00 18 * * * foo']

    crontab.lines = ['00 14 * * * foo', '00 15 * * * bar', '#Ansible: ', '00 18 * * * foo']
    assert crontab.find_job('foo') == ['foo', '00 18 * * * foo', True]
    assert crontab.find_job

# Generated at 2022-06-11 06:51:27.811890
# Unit test for method read of class CronTab
def test_CronTab_read():
    TEST_CRON_FILE = '/tmp/test-cron'
    TEST_CRON_FILE_SOL = '/tmp/test-cron-sol'
    if not os.path.exists('/tmp/test-cron'):
        ansible_module = AnsibleModule(
            argument_spec={
                'name': {'required': True, 'type': 'str'},
            }
        )
        ct = CronTab(ansible_module, cron_file='test-cron')
        assert ct.is_empty() == True
        ct_sol = CronTab(ansible_module, cron_file='test-cron-sol')
        assert ct_sol.is_empty() == True

# Generated at 2022-06-11 06:52:25.351121
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    module = AnsibleModule(argument_spec={})
    obj = CronTab(module)
    name = 'foo'
    actual = obj.do_comment(name)
    assert actual == '#Ansible: foo'

# Generated at 2022-06-11 06:52:34.876904
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    data = {
        'state': 'present',
        'name': 'Ansible cron job',
        'job': '/bin/true',
        'special_time': 'weekly',
    }

# Generated at 2022-06-11 06:52:46.465659
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    ct = CronTab(None)
    ct.lines = []
    # Case 1:
    ct.lines = ['a=b', 'FOO=bar', 'john=smith']
    assert ct.find_env('FOO') == [1, 'FOO=bar']
    # Case 2:
    ct.lines = ['', '']
    assert ct.find_env('FOO') == []
    # Case 3:
    ct.lines = ['', '']
    assert ct.find_env('john') == []
    # Case 4:
    ct.lines = ['john=smith', 'FOO=bar', 'a=b']
    assert ct.find_env('FOO') == [1, 'FOO=bar']
    # Case 5:

# Generated at 2022-06-11 06:52:53.235312
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    # Test function do_comment at every level of inheritance and also directly.
    module = MagicMock()
    crontab = CronTab(module)
    user = None
    cron_file = None

    assert isinstance(crontab, CronTab)
    crontab.name = 'name'
    assert crontab.do_comment('name') == '#Ansible: name'
    assert isinstance(crontab, object)



# Generated at 2022-06-11 06:53:03.484822
# Unit test for method get_jobnames of class CronTab

# Generated at 2022-06-11 06:53:05.363233
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    test_instance = CronTab()

    assert test_instance.get_envnames() == []


# Generated at 2022-06-11 06:53:07.268508
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    assert CronTab('', '').do_comment('') == '#Ansible: '


# Generated at 2022-06-11 06:53:17.895053
# Unit test for function main
def test_main():
    # This unit test requires a functioning system cron.  It should not be run
    # as part of the normal unit test suite, but should be run independently.
    # To accomplish this we test for __main__ == module_name.
    if __name__ == '__main__':
        import tempfile  # noqa
        from ansible.module_utils.basic import AnsibleModule  # noqa

# Generated at 2022-06-11 06:53:23.309857
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():

    #setup
    ct = CronTab(user='ansible')

    expected = ['#Ansible: unit test', '0 * * * * /bin/echo "foo bar"']
    # execute method
    ct.add_job('unit test', '0 * * * * /bin/echo "foo bar"')
    # verify results
    assert ct.lines == expected

    # teardown



# Generated at 2022-06-11 06:53:32.912100
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    module = AnsibleModule(argument_spec=dict())
    cron_tab = CronTab(module, user="foo")
    cron_tab.lines = [
        "#Ansible: test_job",
        "* * * * * echo test > /tmp/test_job.out"
    ]
    assert cron_tab.find_job("test_job") == ["#Ansible: test_job", "* * * * * echo test > /tmp/test_job.out"]
    assert cron_tab.find_job("test_job", job="* * * * * echo test > /tmp/test_job.out") == ["#Ansible: test_job", "* * * * * echo test > /tmp/test_job.out"]


# Generated at 2022-06-11 06:54:59.838448
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    # Instance creation of class CronTab
    crontab = CronTab()
    # Declaration 1 for get_envnames()
    decl1 = """MAILTO=foo"""
    # Declaration 2 for get_envnames()
    decl2 = """BAR=1"""
    # Declaration 3 for get_envnames()
    decl3 = """PATH=:/usr/bin"""
    # Declaration 4 for get_envnames()
    decl4 = """PATH=/usr/bin"""

    # Test 1 for get_envnames()
    crontab.lines = [decl1, decl2, decl3]
    assert crontab.get_envnames() == ['MAILTO', 'BAR', 'PATH']
    # Test 2 for get_envnames()
    crontab.lines = [decl1, decl2, decl3, decl4]

# Generated at 2022-06-11 06:55:10.036816
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    ct = CronTab(None)
    ct.lines = '''#Ansible: foo
@monthly    echo foo
#Ansible: bar
@reboot echo bar
'''.splitlines()
    assert ct.update_job('foo', 'foo') == False
    assert ct.lines == '''#Ansible: foo
@monthly    echo foo
#Ansible: bar
@reboot echo bar
'''.splitlines()
    assert ct.update_job('bar', 'bar') == False
    assert ct.lines == '''#Ansible: foo
@monthly    echo foo
#Ansible: bar
@reboot echo bar
'''.splitlines()
    assert ct.update_job('baz', 'baz') == True

# Generated at 2022-06-11 06:55:22.006115
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    module = AnsibleModule(
        argument_spec = dict(
            insertafter = dict(required=False, type='str'),
            insertbefore = dict(required=False, type='str'),
            decl = dict(required=True, type='str'),
            cron_file = dict(required=False, type='str', default=None),
        ),
        supports_check_mode=True
    )
    result = dict(
        changed=False,
    )

    crontab_file = module.params.get('cron_file')
    crontab = CronTab(module, cron_file=crontab_file)

    decl = module.params['decl']
    insertafter = module.params['insertafter']
    insertbefore = module.params['insertbefore']


# Generated at 2022-06-11 06:55:30.390617
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    module = AnsibleModule(argument_spec=dict())
    crontab = CronTab(module, user=None, cron_file=None)
    assert '@reboot root echo "test"' == crontab.get_cron_job(None, None, None, None, None, 'echo "test"', 'reboot', None)
    assert '*/3 * * * * root echo "test"' == crontab.get_cron_job('*/3', None, None, None, None, 'echo "test"', None, None)
    assert '* * * * * root echo "test"' == crontab.get_cron_job(None, None, None, None, None, 'echo "test"', None, None)
    assert '#* * * * * root echo "test"' == crontab.get_cron

# Generated at 2022-06-11 06:55:35.082902
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    ct = CronTab(None, 'vagrant')
    for job in ct.get_jobnames():
        assert job.startswith('ansible-')
        m = re.search('^ansible-([^.]+)', job)
        assert len(m.groups()) == 1


# Generated at 2022-06-11 06:55:37.136240
# Unit test for method write of class CronTab
def test_CronTab_write():
    assert CronTab.write('/etc/cron.d/test') == True


# Generated at 2022-06-11 06:55:47.422931
# Unit test for function main
def test_main():
    os.system('rm -f /tmp/_ansible_test_cron')
    os.system('cp ../test/test_crontab /tmp/_ansible_test_cron')

    my_cron = CronTab(module=None, user='root', cron_file='/tmp/_ansible_test_cron')
    assert my_cron.render() == '\n'.join([
        'PATH=/usr/bin:/bin',
        '# Ansible: foo',
        '* * * * * find /var/log -name "*.log" -print | xargs -r bzip2 ',
        '',
    ])
    os.system('rm -f /tmp/_ansible_test_cron')


main()

# Generated at 2022-06-11 06:55:51.822981
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():

    crontab = CronTab(None)

    crontab.lines = ['# Test1', 'TEST1="TEST1"', 'TEST2="TEST2"']

    assert crontab.get_envnames() == ['TEST1', 'TEST2']


# Generated at 2022-06-11 06:55:54.264113
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    t = CronTab('whoami')
    t.update_env("FOO", "FOO=bar")
    assert t.lines == ["#Ansible: FOO", "FOO=bar"]



# Generated at 2022-06-11 06:56:03.456598
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_bin_path
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    setattr(module, 'get_bin_path', get_bin_path)
    crontab = CronTab(module)
    assert 0 == len(crontab.lines)
    crontab.add_job('name', 'job')
    assert 2 == len(crontab.lines)
    assert '#Ansible: name' == crontab.lines[0]
    assert 'job' == crontab.lines[1]


# Generated at 2022-06-11 06:58:59.098025
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    module = AnsibleModule(argument_spec=dict())

    cron_tab_01 = CronTab(module)
    assert cron_tab_01.get_cron_job('*', '*', '*', '*', '*', '/etc/some_script', None, False) == '* * * * * /etc/some_script'
    assert cron_tab_01.get_cron_job('*', '*', '*', '*', '*', '/etc/some_script', None, True) == '#* * * * * /etc/some_script'
    assert cron_tab_01.get_cron_job('*', '*', '*', '*', '*', '/etc/some_script', 'daily', False) == '@daily /etc/some_script'
    assert cron

# Generated at 2022-06-11 06:59:02.399392
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    ct = CronTab(None)

    decl = "TESTENV=true"
    lines = []
    assert ct.do_add_env(lines, decl) == None
    assert len(lines) == 1
    assert lines[0] == "TESTENV=true"


# Generated at 2022-06-11 06:59:10.599672
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    module = AnsibleModule(
        argument_spec = dict(
            minute=dict(default='*', required=True),
            hour=dict(default='*', required=True),
            day=dict(default='*', required=True),
            month=dict(default='*', required=True),
            weekday=dict(default='*', required=True),
            job=dict(required=True),
            special=dict(default=None, required=False),
            user=dict(default=None, required=False),
            cron_file=dict(default=None, required=False),
            disabled=dict(type='bool', default=False, required=False)
        ),
        check_invalid_arguments=False,
        supports_check_mode=True
    )
    # mock out the module calls

    # set up cr

# Generated at 2022-06-11 06:59:12.179453
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    test = CronTab(None, cron_file='abc')
    assert test.remove_job_file() == True


# Generated at 2022-06-11 06:59:15.646308
# Unit test for method render of class CronTab
def test_CronTab_render():
    crontab = CronTab()
    # Comment is added by find_job()
    crontab.lines.append('#Ansible: test_job')
    crontab.lines.append('* * * * * test_job')
    assert crontab.render() == '#Ansible: test_job\n* * * * * test_job'

# Generated at 2022-06-11 06:59:17.318165
# Unit test for method read of class CronTab
def test_CronTab_read():
    ct = CronTab(None)
    assert check_output(ct._read_user_execute()) == "*** None ***"


# Generated at 2022-06-11 06:59:24.607997
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    class module(object):
        def selinux_enabled(self):
            return False

        def get_bin_path(self, arg, required=False):
            return True

        def run_command(self, cmd):
            return (0, '', '')

    class args(object):
        def __init__(self):
            self.name = "test"
            self.special_time = None
            self.backup = None

    # Arrange
    name = "test"
    job = "test"
    decl = "test"

    # Act
    try:
        cron = CronTab(module)
        cron.do_add_env(cron.lines, decl)
    except:
        assert False

    # Assert
    assert cron.lines[0] == decl