

# Generated at 2022-06-11 06:50:17.599804
# Unit test for function main
def test_main():
    pass


# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:50:23.325940
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    ct = CronTab(None)
    assert ct.get_cron_job('1', '2', '3', '4', '5', 'ls -l', '@daily', True) == '#@daily root ls -l'
    assert ct.get_cron_job('1', '2', '3', '4', '5', 'ls -l', '@daily', False) == '@daily root ls -l'
    assert ct.get_cron_job('1', '2', '3', '4', '5', 'ls -l', None, False) == '1 2 3 4 5 root ls -l'
    ct.cron_file = '/tmp/test.cron'

# Generated at 2022-06-11 06:50:34.357730
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    module_args = dict(
        minute='*/15',
        hour='*',
        day='*',
        month='*',
        weekday='*',
        job='/usr/bin/true',
        name='ansible-hourly'
    )

    ct = CronTab(module_args, None)
    assert ct.get_jobnames() == []
    assert ct.get_cron_job(module_args['minute'], module_args['hour'], module_args['day'], module_args['month'], module_args['weekday'], module_args['job'], None, False) == '*/15 * * * * /usr/bin/true'

# Generated at 2022-06-11 06:50:46.676720
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    # test disabling
    cron = CronTab(None, user='root', cron_file='/var/spool/cron/root')
    newjob = cron.get_cron_job('*', '*', '*', '*', '*', '/bin/foo', '', True)
    cron.update_job('test', newjob)
    cron.write()
    assert "#test" in cron.render()
    assert "#/bin/foo" in cron.render()

    # test enabling
    cron = CronTab(None, user='root', cron_file='/var/spool/cron/root')
    newjob = cron.get_cron_job('*', '*', '*', '*', '*', '/bin/foo', '', False)
    cron.update

# Generated at 2022-06-11 06:50:56.058667
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():

    class Module():
        def fail_json(self, msg):
            raise CronTabError('%s' % msg)

    def get_bin_path(*args, **kwargs):
        return 'crontab'


    class MockOS():
        def __init__(self):
            self.pathsep = os.path
            self.linesep = os.linesep


        def access(self, filename, mode):
            pass

        def getcwd(self):
            return '.'

        def getuid(self):
            return 0

        def getgid(self):
            return 0

        def walk(self, top, topdown=True, onerror=None, followlinks=False):
            yield 'meh', None, ['mycron.yml']

        def unlink(self, filename):
            pass

       

# Generated at 2022-06-11 06:51:05.834071
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    ct = crontab.CronTab()
    
    # Test 1
    ct.lines.append("#Ansible: test_CronTab_do_remove_job_1")
    ct.lines.append("0 2 * * * /usr/local/bin/make_check_lists")
    retval = ct.do_remove_job(ct.lines, "#Ansible: test_CronTab_do_remove_job_1", "0 2 * * * /usr/local/bin/make_check_lists")
    assert retval is None, "test_CronTab_do_remove_job_1 failed"

    # Test 2
    ct.lines = []
    ct.lines.append("#Ansible: test_CronTab_do_remove_job_2")
    ct

# Generated at 2022-06-11 06:51:08.341683
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    cron_file = None
    user = ''
    C = CronTab(cron_file,user)
    C.update_job(name,job)



# Generated at 2022-06-11 06:51:16.316918
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    module = AnsibleModule(
        argument_spec = dict(
            user = dict(required=False, default=None, type='str'),
            cron_file = dict(required=False, default=None, type='str'),
            name = dict(required=True, type='str'),
            job = dict(required='True', type='str'),
            state = dict(required=False, default='present', type='str', choices=['present', 'absent']),
        )
    )

    ct = CronTab(module)

    rc = ct.add_job(module.params['name'], module.params['job'])
    try:
        del module.params['job']
    except:
        pass # ignore if it didn't work
    module.exit_json(changed=rc, **module.params)

# Unit

# Generated at 2022-06-11 06:51:22.557870
# Unit test for method render of class CronTab
def test_CronTab_render():
    test_obj=CronTab(module)
    test_obj.ansible="test_ansible"
    test_obj.lines=["test_line1","test_line2","test_line3"]

    # See if expected result matches and return
    result = test_obj.render()
    assert result == "\ntest_line1\ntest_line2\ntest_line3\n"


# Generated at 2022-06-11 06:51:26.792576
# Unit test for method write of class CronTab
def test_CronTab_write():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            user = dict(default=None),
            cron_file = dict(default=None),
        )
    )

    ct = CronTab(module, user=None, cron_file=None)



# Generated at 2022-06-11 06:52:17.695329
# Unit test for method read of class CronTab
def test_CronTab_read():
    cron = CronTab()
    assert cron.n_existing == ''
    assert len(cron.lines) == 0


# Generated at 2022-06-11 06:52:23.341227
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    """
    Test update_env method of class CronTab
    """
    # Load the crontab object with a test crontab
    test_crontab = CronTab(0, user='root')
    test_crontab.lines = ["#Ansible: testjob", "00 00 * * 1,2,3 echo testjob"]
    test_crontab.lines.append("")
    test_crontab.lines.append("TEST_VAR1=somedata")
    test_crontab.lines.append("")
    test_crontab.lines.append("#Ansible: testjob2")
    test_crontab.lines.append("00 01 * * 1,2,3 echo testjob2")
    test_crontab.lines.append("")
    test_crontab.lines

# Generated at 2022-06-11 06:52:32.274923
# Unit test for constructor of class CronTab
def test_CronTab():
    cron = CronTab(dict(), user='root')
    assert cron.cron_cmd == '/usr/bin/crontab'
    assert cron.user == 'root'
    assert cron.root == True

    cron = CronTab(dict(), user='johndoe')
    assert cron.cron_cmd == '/usr/bin/crontab'
    assert cron.user == 'johndoe'
    assert cron.root == True

    cron = CronTab(dict(), user='johndoe', cron_file='tmp')
    assert cron.cron_cmd == '/usr/bin/crontab'
    assert cron.user == 'johndoe'
    assert cron.root == True

# Generated at 2022-06-11 06:52:36.069924
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True)
        )
    )
    object = CronTab(module)
    result = object.find_job('test_name')
    assert result == []

# Generated at 2022-06-11 06:52:38.231892
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    out = CronTab(module='test').add_job('test', 'job')
    assert out is not None

# Generated at 2022-06-11 06:52:49.191830
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    expected = ['PATH', 'USER', 'HOME', 'MAILTO']
    cron = CronTab(None, user='root')
    cron.lines = [
        'PATH=...',
        'USER=...',
        'HOME=...',
        'MAILTO=...',
        '',
        '#Ansible: test_job',
        '* * * * * echo test'
    ]
    result = cron.get_envnames()
    if not isinstance(result, list):
        return False
    if len(result) != len(expected):
        return False
    for i in range(len(expected)):
        if result[i] != expected[i]:
            return False
    return True


# Generated at 2022-06-11 06:52:55.499059
# Unit test for method render of class CronTab
def test_CronTab_render():
    c = CronTab()
    assert c.render() == ''
    c.lines = ['foo', 'bar']
    assert c.render() == 'foo\nbar'
    c.lines = ['foo', 'bar', '', 'baz']
    assert c.render() == 'foo\nbar\nbaz'
    c.lines = ['foo', '', '', 'bar']
    assert c.render() == 'foo\nbar'


if __name__ == "__main__":
    main()

# Generated at 2022-06-11 06:53:05.902644
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    ct = CronTab(None, 'root')
    ct.lines = [
        'a',
        'b',
        '#Ansible: test',
        'c',
        'd'
    ]

    assert ct.find_job(name='test') == ['test', 'c']
    assert ct.find_job(name='test', job='c') == ['test', 'c']
    assert ct.find_job(name='test2') == []
    assert ct.find_job(name='test2', job='c') == []
    assert ct.find_job(name='test', job='d') == []

    ct.lines = [
        'a',
        'b',
        'c',
        'd'
    ]


# Generated at 2022-06-11 06:53:16.480503
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    module = AnsibleModule(argument_spec={})
    cron = CronTab(module)

    # normal crontab entry
    t1 = cron.get_cron_job('*', '*', '*', '*', '*', '/usr/bin/command', '', False)
    assert t1 == '* * * * * /usr/bin/command'

    # normal crontab entry with user
    t2 = cron.get_cron_job('*', '*', '*', '*', '*', '/usr/bin/command', '', False)
    assert t2 == '* * * * * /usr/bin/command'

    # special crontab

# Generated at 2022-06-11 06:53:26.579689
# Unit test for method render of class CronTab
def test_CronTab_render():
    import os
    import sys

    # This is the class we are testing
    from crontab import CronTab

    # Test 1
    lines = [
        '#Ansible: Test1',
        '10 10 * * * /bin/test1',
    ]

    expected_out = '\n'.join(lines)

    c = CronTab(None, user=None, cron_file=None)
    c.lines = lines

    output = c.render()
    assert output == expected_out, "Expected output did not match render output."

    # Test 2
    lines = [
        '#Ansible: Test2',
        '10 10 * * * /bin/test2',
        '#Ansible: Test3',
    ]

    expected_out = '\n'.join(lines)


# Generated at 2022-06-11 06:55:28.537741
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    crontab = CronTab(None)

    # Test for non-special (according to Ansible)
    job = crontab.get_cron_job(minute='*', hour='*', day='*', month='*', weekday='*', job='/usr/bin/foo', special=None, disabled=False)
    assert(job == '* * * * * /usr/bin/foo')

    # Test for special @reboot
    job = crontab.get_cron_job(minute='*', hour='*', day='*', month='*', weekday='*', job='/usr/bin/foo', special='reboot', disabled=False)
    assert(job == '@reboot /usr/bin/foo')

    # Test for special @annually

# Generated at 2022-06-11 06:55:40.136102
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    module = AnsibleModule(argument_spec={
        "name": {"type": 'str', "default": None},
        "decl": {"type": 'str', "default": None},
        "insertafter": {"type": 'str', "default": None},
        "insertbefore": {"type": 'str', "default": None}
    }, supports_check_mode=True)

    # Instantiate the cron object
    cron = CronTab(module)

    # Add the enviornment variable declaration
    result = cron.add_env(module.params['decl'], module.params['insertafter'], module.params['insertbefore'])

    result = {'changed': True, 'environment': cron.render(), 'warnings': []}

    module.exit_json(**result)

# Generated at 2022-06-11 06:55:50.952665
# Unit test for method write of class CronTab
def test_CronTab_write():
    module = AnsibleModule(
        argument_spec = dict(),
    )
    ctab = CronTab(module)

    # cron_file should not be set
    assert ctab.cron_file is None

    # run write with make backup
    backup_file = tempfile.NamedTemporaryFile(prefix='root.cron.backup').name
    ctab.write(backup_file=backup_file)

    # verify backup has the same count of lines
    with open(backup_file, 'rb') as ctf:
        n_new = to_native(ctf.read(), errors='surrogate_or_strict')
        assert len(ctab.n_existing.splitlines()) == len(n_new.splitlines())

    # run write without backup

# Generated at 2022-06-11 06:55:59.850918
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    ct = CronTab(module=None, user=None)

    # Create a mock for class AnsibleModule and set configuration
    mock_AnsibleModule = MagicMock()
    mock_AnsibleModule_config = {'minute': '*', 'hour': '*', 'day': '*', 'month': '*', 'weekday': '*', 'job': 'true', 'special': '', 'disabled': False, 'name': 'test_job'}
    mock_AnsibleModule.params = mock_AnsibleModule_config
    ct.module = mock_AnsibleModule

    # Create a mock for class CronTab and set configuration
    ct.lines = []

    ct._update_job('test_job', 'true', ct.do_add_job)

# Generated at 2022-06-11 06:56:03.689788
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    cron = CronTab({"path": "/usr/bin/crontab"})
    assert cron.is_empty() is True
    cron.lines = ['#Ansible: test']
    assert cron.is_empty() is False


# Generated at 2022-06-11 06:56:10.537624
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    import tempfile

    result = None

# Generated at 2022-06-11 06:56:18.070746
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    c = CronTab(module)
    assert(c.find_env('name') == [])
    c.lines = ['#Ansible: name', 'other: name', 'name=value', '#Ansible: other_name', 'other_name=other_value']
    assert(c.find_env('name') == [2, 'name=value'])
    assert(c.find_env('other_name') == [4, 'other_name=other_value'])


# Generated at 2022-06-11 06:56:27.663995
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    global default_args
    default_args['state']['value'] = 'present'
    default_args['name']['value'] = 'test1'
    default_args['minute']['value'] = '*'
    default_args['hour']['value'] = '*'
    default_args['day']['value'] = '*'
    default_args['month']['value'] = '*'
    default_args['weekday']['value'] = '*'
    default_args['job']['value'] = '/path/to/some/command'
    module = AnsibleModule(default_args)

    # module.fail_json = Mock(returns=module.exit_json())
    module.exit_json = Mock(returns=None)
    # module.run_command = Mock(

# Generated at 2022-06-11 06:56:29.007867
# Unit test for method write of class CronTab
def test_CronTab_write():
    # This is a stub, not implemented yet
    pass

# Generated at 2022-06-11 06:56:38.437999
# Unit test for function main
def test_main():
    import tempfile
    import os
    import stat
    import textwrap
    import ansible_collections.community.general.tests.unit.compat.mock as mock
    from ansible.module_utils.basic import AnsibleModule
    # We can assume that /bin/crontab exists, because we require it to be present
    CRONTAB_COMMAND = '/bin/crontab'
    # pretend to be linux
    _system_to_pretend = 'Linux'
    # Because we are using /bin/crontab, for the cron_file option, we do not have to
    # populate it with anything
    CRON_FILE_PATH = tempfile.mktemp()
    fd = open(CRON_FILE_PATH, 'w+')
    fd.close()