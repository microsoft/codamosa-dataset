

# Generated at 2022-06-11 06:50:20.754283
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    global module
    module = AnsibleModule(argument_spec=dict())
    ct = CronTab(module, user='foo', cron_file='/etc/cron.d/file')
    ct.add_job('test', '*/5 * * * * /usr/local/bin/test_job')
    assert ct.lines == [
        "#Ansible: test",
        "*/5 * * * * /usr/local/bin/test_job"
    ]



# Generated at 2022-06-11 06:50:27.437271
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    uid = os.getuid()
    if uid == 0:
        # create a blank cron file
        (fd1, f1) = tempfile.mkstemp(prefix='cron')
        os.chmod(f1, int('0644', 8))
        os.close(fd1)
        # create non-zero length cron file (non-zero length never removed)
        (fd2, f2) = tempfile.mkstemp(prefix='cron')
        os.write(fd2, b"* * * * * echo 'test'")
        os.close(fd2)
        # create zero length cron file (zero length always removed)
        (fd3, f3) = tempfile.mkstemp(prefix='cron')
        os.write(fd3, b"")
        os.close

# Generated at 2022-06-11 06:50:35.171160
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    # set up object
    module = AnsibleModule(argument_spec={})
    crontab = CronTab(module, 'root', 'ansible')

    crontab.lines = [] # reset to empty

    # run tested method
    crontab.do_add_env(crontab.lines, "PATH=/usr/bin:/bin")

    index = 0
    rendered = crontab.render()

    assert rendered == "PATH=/usr/bin:/bin"
    assert crontab.lines[index] == "PATH=/usr/bin:/bin"


# Generated at 2022-06-11 06:50:37.614785
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    c = CronTab(None,True)
    c.cron_cmd = "/usr/bin/crontab"
    assert c._read_user_execute() == "/usr/bin/crontab -l"

# Generated at 2022-06-11 06:50:46.623105
# Unit test for method write of class CronTab
def test_CronTab_write():
    cron = CronTab(None, user=None, cron_file=None)
    cron.cron_file = None
    cron.cron_cmd = "/usr/bin/crontab"
    cron.user = None
    cron.root = False
    cron.lines = ["#cron"]
    cron.ansible = "#Ansible: "
    cron.n_existing = "cron"
    cron.module = None

    cron.write()
    assert True


# Generated at 2022-06-11 06:50:49.552261
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    crontab = CronTab(module=dict(run_command=run_command),cron_file="/etc/mycron")
    assert crontab

# Generated at 2022-06-11 06:50:50.620142
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    CronTab.add_env()



# Generated at 2022-06-11 06:50:54.992871
# Unit test for constructor of class CronTab
def test_CronTab():
    class TestModule(object):
        @staticmethod
        def get_bin_path(bin, required=False):
            if bin == 'crontab':
                return "/usr/bin/crontab"

    module = TestModule()
    crontab = CronTab(module)
    assert crontab.cron_cmd == "/usr/bin/crontab"


# Generated at 2022-06-11 06:50:59.140100
# Unit test for method render of class CronTab
def test_CronTab_render():
    """
    Test render method of class CronTab
    """
    ct = CronTab(None, "test")
    ct.lines = ["test", "test2"]
    result = ct.render()
    expected = 'test\ntest2\n'
    assert result == expected



# Generated at 2022-06-11 06:51:02.866496
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    module = mock.MagicMock()
    ct = CronTab(module, user=None, cron_file=None)
    ct.ansible = '#Ansible'
    assert ct.do_comment('name') == "#Ansible: name"


# Generated at 2022-06-11 06:52:58.226594
# Unit test for function main

# Generated at 2022-06-11 06:53:05.569129
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    args = dict(
        name=dict(type='str'),
    )
    module = AnsibleModule(
        argument_spec=args,
        supports_check_mode=True
    )

    with tempfile.NamedTemporaryFile() as crontab_file:
        ct = CronTab(module, None, crontab_file.name)

        name = 'foo'
        result = ct.do_comment(name)
        expected = "#Ansible: foo"
        assert result == expected


# Generated at 2022-06-11 06:53:16.149867
# Unit test for method get_cron_job of class CronTab

# Generated at 2022-06-11 06:53:20.520541
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    ansible = Ansible()
    user = 'jerry'
    cron_file = None
    crontab = CronTab(ansible, user, cron_file)
    decl = 'TEST_VAR=test'
    crontab.add_env(decl)



# Generated at 2022-06-11 06:53:22.759730
# Unit test for method write of class CronTab
def test_CronTab_write():
    c = CronTab(None, None, None)
    r = c.write()
    assert r is None
    del c, r


# Generated at 2022-06-11 06:53:27.217679
# Unit test for method render of class CronTab
def test_CronTab_render():
    c = CronTab(None, None, '/etc/cron.d/test')

    assert c.render() == ''

    c.lines = ['test']

    assert c.render() == 'test'

    c.lines = ['test1', 'test2']

    assert c.render() == 'test1\ntest2'


# Generated at 2022-06-11 06:53:37.262486
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 06:53:40.617627
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    module = AnsibleModule(
        argument_spec = dict()
    )
    obj = CronTab('test', module, 'test')

    obj.lines = [
        '* * * * * test'
    ]

    assert obj.get_jobnames() == ['test']


# Generated at 2022-06-11 06:53:45.998683
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    # Dummy class for testing (similar to AnsibleModule)
    class DummyClass:
        def __init__(self):
            pass
        @staticmethod
        def fail_json(*args, **kwargs):
            pass
        @staticmethod
        def get_bin_path(*args, **kwargs):
            return '/usr/bin/crontab'
    module=DummyClass()

    name='test'

    cron = CronTab(module)
    cron.lines = ['', '', '#Ansible: test', '* * * * * /tmp/test']
    cron.do_remove_job(cron.lines, name, None)
    assert cron.lines == []


# Generated at 2022-06-11 06:53:48.953977
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    '''
    Unit test for method do_remove_env of class CronTab
    '''
    module = AnsibleModule({})
    ntp_module = NtpModule(module)
    cron = CronTab(module)
    cron.remove_env("test")


# Generated at 2022-06-11 06:55:55.547614
# Unit test for method render of class CronTab
def test_CronTab_render():
    assert CronTab(module)[2] == "30 * * * * /tmp/foo.sh"


# Generated at 2022-06-11 06:56:05.924972
# Unit test for method write of class CronTab
def test_CronTab_write():
    # Tests with backup file
    ct = CronTab()

    ct.write('/tmp/crontab')
    f = open('/tmp/crontab', 'r')
    assert f.read() == "#Ansible: None\n"
    f.close()
    os.remove('/tmp/crontab')

    ct.lines = ['#Ansible: None', '* * * * * /bin/sleep 600']
    ct.write('/tmp/crontab')
    f = open('/tmp/crontab', 'r')
    assert f.read() == "#Ansible: None\n* * * * * /bin/sleep 600\n"
    f.close()
    os.remove('/tmp/crontab')

    # Tests with no backup file

# Generated at 2022-06-11 06:56:16.086487
# Unit test for method write of class CronTab

# Generated at 2022-06-11 06:56:18.078269
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    module = AnsibleModule(argument_spec={})
    ct = CronTab(module)
    assert ct.is_empty() == True

# Generated at 2022-06-11 06:56:27.664182
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    args = dict(
        name="foo",
        decl="BAR=bat",
        insertafter="foo",
        insertbefore="foo"
    )

    module = AnsibleModule(argument_spec=dict(
        name=dict(type='str'),
        decl=dict(type='str'),
        insertafter=dict(type='str'),
        insertbefore=dict(type='str')
    ))

    mock_object = Mock()
    with patch.object(CronTab, "add_env", return_value=mock_object):
        crontab_instance = CronTab(module)
        assert crontab_instance.add_env(name=args["name"], decl=args["decl"], insertafter=args["insertafter"], insertbefore=args["insertbefore"]) == mock_object

# Generated at 2022-06-11 06:56:32.546977
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    ct = CronTab(None, cron_file=CRON_FILE)
    ct.update_job("job1", "* * * * * /bin/echo hello world")
    assert(ct.render() == "")
    ct.write(CRON_FILE)
    ct = CronTab(None, cron_file=CRON_FILE)
    ct.update_job("job2", "* * * * * /bin/echo hello world")
    assert(ct.render().count("Ansible:") == 2)
    ct.write(CRON_FILE)
    ct = CronTab(None, cron_file=CRON_FILE)
    ct.update_job("job1", "* * * * * /bin/echo hello world")

# Generated at 2022-06-11 06:56:36.252426
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    ct = CronTab(None)
    ct.lines = ['#Ansible: test', 'MAILTO=test', 'ANSIBLE_VAR=test']
    assert ct.get_envnames() == ['MAILTO', 'ANSIBLE_VAR']

# Generated at 2022-06-11 06:56:45.315264
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.basic as ansible_basic

    class ModuleMock():
        def __init__(self):
            self.params = dict()
            self.check_mode = False
            self.debug = False
            self.fail_json = lambda x: None
            self.run_command = lambda x: (0, '', '')
            self.get_bin_path = lambda x: '/bin/test'
            self.set_default_selinux_context = lambda x, y: None
            self.selinux_enabled = lambda: False

    class AnsibleModuleMock(AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.params = dict()
            self.check_mode = False


# Generated at 2022-06-11 06:56:50.248739
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    module = AnsibleModule(
    )
    ct = CronTab(module)
    ct.add_job('test', 'test')
    ct.add_job('test2', 'test')
    ct.add_job('test3', 'test')
    names = ct.get_jobnames()
    assert names == ['test', 'test2', 'test3']


# Generated at 2022-06-11 06:56:51.619314
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    CronTab.remove_env(name)
    assert True
