

# Generated at 2022-06-11 06:50:19.919955
# Unit test for constructor of class CronTab
def test_CronTab():
    import shutil
    import filecmp
    import tempfile

# Generated at 2022-06-11 06:50:22.838953
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    cron_tab_test = CronTab(None)
    cron_tab_test.lines.append("#Ansible: test")
    cron_tab_test.lines.append("* * * * * /tmp/test.sh")
    assert cron_tab_test.get_jobnames() == ["test"]
test_CronTab_get_jobnames()

# Generated at 2022-06-11 06:50:33.858239
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    c = CronTab(None, None)
    c.lines = ['#Ansible: job0', '0 0 * * * /bin/echo', '#Ansible: job1', '0 0 * * * /bin/echo', '#Ansible: job2', '0 0 * * * /bin/echo']
    assert c.find_job('job1') == ['job1', '0 0 * * * /bin/echo']
    assert c.find_job('job1', '0 0 * * * /bin/echo') == ['job1', '0 0 * * * /bin/echo']
    assert c.find_job('jobfoo') == []
    assert c.find_job('jobfoo', '0 0 * * * /bin/echo') == []

# Generated at 2022-06-11 06:50:45.924579
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    # create a fresh TestModule with a temp filepath
    module = TestModule()
    module.tmpdir = tempfile.mkdtemp()
    module.cron_file = os.path.join(module.tmpdir, 'test')
    # create an empty crontab
    cron = CronTab(module)
    cron.write(module.cron_file)
    # make sure our cron_file is empty
    assert len(cron.lines) == 0
    # add a job
    cron.add_job("testname1", "* * * * * job1")
    cron.write(module.cron_file)
    # make sure our cron_file has both (comment and job)
    assert len(cron.lines) == 2
    # make sure our job is in the crontab
   

# Generated at 2022-06-11 06:50:50.524163
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    crontab = CronTab()
    crontab.lines = ['#Ansible: test', 'PATH=/usr/local/bin:/usr/bin:/bin', 'SHELL=/bin/sh']
    assert crontab.get_envnames() == ['PATH', 'SHELL']


# Generated at 2022-06-11 06:50:53.053654
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    print("test_CronTab_remove_job_file")
    c = CronTab(user='root')

    c.remove_job_file()



# Generated at 2022-06-11 06:50:57.842468
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    cron = CronTab(None)
    cron.lines = ['#Ansible: foo', '*/5 * * * *', '#Ansible: bar', '*/5 * * * *', 'foo bar']

    result = cron.get_jobnames()
    assert result == ['foo', 'bar']



# Generated at 2022-06-11 06:51:04.513961
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    ct = CronTab(None)
    assert ct.is_empty() == True
    ct.lines.append("\n")
    assert ct.is_empty() == True
    ct.lines.append("test\n")
    assert ct.is_empty() == False
    ct.lines = ["\n", "\n"]
    assert ct.is_empty() == True
    ct.lines = ["\n", "test\n"]
    assert ct.is_empty() == False

# Generated at 2022-06-11 06:51:13.807611
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    # Initialize the test environment
    tmpdir = gettempdir()
    cron_file = os.path.join(tmpdir, 'crontab')
    with open(cron_file, 'w') as f:
        lines = [
            'PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
            'SHELL=/bin/bash',
            'MAILTO=',
            'HOME=/',
            '@reboot root test1',
            '#Ansible: test_job',
            '*/15 * * * * test2',
            '* * * * * test3',
        ]
        f.write('\n'.join(lines))

    c_tab = CronTab(None, 'root', cron_file)

    # Test results

# Generated at 2022-06-11 06:51:17.014049
# Unit test for constructor of class CronTab
def test_CronTab():
    cron = CronTab()
    print("test§ cron.cron_cmd = %s" % cron.cron_cmd)
    print("test$ cron.root = %s" % cron.root)
    print("test$ cron.user = %s" % cron.user)
    print("test$ cron.cron_file = %s" % cron.cron_file)

# Generated at 2022-06-11 06:52:10.486957
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    cron_tab = CronTab(module=None, user='root', cron_file=None)
    cron_tab.do_comment('Ansible')
    job = cron_tab.get_cron_job(minute='*', hour='*', day='*', month='*', weekday='*', job='cat /home/user/testfile.txt', special=None, disabled=False)
    assert cron_tab.add_job('Ansible', job)
    assert cron_tab.lines[0] == "#Ansible: Ansible"
    assert cron_tab.lines[1] == "* * * * * root cat /home/user/testfile.txt"

# Generated at 2022-06-11 06:52:18.915581
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    c = CronTab(None)

    assert c.get_cron_job("*", "*", "*", "*", "*", "echo foo", "", "") == "* * * * * echo foo"
    assert c.get_cron_job("*", "*", "*", "*", "*", "echo foo", "", "False") == "* * * * * echo foo"
    assert c.get_cron_job("*", "*", "*", "*", "*", "echo foo", "", "True") == "#* * * * * echo foo"
    assert c.get_cron_job("*", "*", "*", "*", "*", "echo foo", "daily", "") == "@daily echo foo"

# Generated at 2022-06-11 06:52:26.155294
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    """
    Test get_envnames()
    """
    envvars = [
        'SHELL=/bin/bash',
        'USER=root',
        'HOME=/root',
        'PATH=/bin:/usr/bin',
        'FOO=foo'
    ]

    c = CronTab()
    c.lines = envvars

    expected = ['SHELL', 'USER', 'HOME', 'PATH', 'FOO']
    assert c.get_envnames() == expected



# Generated at 2022-06-11 06:52:35.958572
# Unit test for function main
def test_main():
    with open('/tmp/ansible.log', 'a') as log:
        log.write('>>> unit test: cron\n')

    class Module:
        def __init__(self):
            self.params = dict()
            self.check_mode = False
            self._diff = False

        def fail_json(self, **kwargs):
            log.write('failing with %s\n' % repr(kwargs))
            assert False

        def exit_json(self, **kwargs):
            log.write('exiting with %s\n' % repr(kwargs))
            assert False

        def debug(self, message):
            log.write('debug: %s\n' % message)
            log.flush()


# Generated at 2022-06-11 06:52:39.881733
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    ct = CronTab(None, None, None)

    ct.add_job('test', 'minute hour day month weekday command')

    assert(ct.lines == ['#Ansible: test', 'minute hour day month weekday command'])



# Generated at 2022-06-11 06:52:49.083579
# Unit test for method read of class CronTab
def test_CronTab_read():
    ct = CronTab(None, None)
    ct.lines = []
    ct.b_cron_file = None
    ct.cron_file = None
    ct.read()
    assert ct.lines == []
    assert ct.user is None
    assert ct.root is True
    assert ct.lines is not None
    assert ct.ansible == "#Ansible: "
    assert ct.n_existing == ''
    assert ct.cron_cmd == '/usr/bin/crontab'
    assert ct.cron_file is None



# Generated at 2022-06-11 06:52:57.874126
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():

    module = AnsibleModule(
        argument_spec = dict(
        )
    )

    # set up CronTab object
    crontab = CronTab(module)
    crontab.lines = [
        '',
        'DEBUG=on',
        '',
        'DEBUG=on',
        'FOO=bar',
        '',
        'DEBUG=on',
        'FOO=bar',
        '# Ansible: foo',
        '',
        '',
        'DEBUG=on',
        'FOO=bar',
    ]

    assert crontab.find_env('DEBUG') == [1, 'DEBUG=on']
    assert crontab.find_env('DEBUG') == [4, 'DEBUG=on']
    assert crontab.find_env('DEBUG') == [7, 'DEBUG=on']

# Generated at 2022-06-11 06:53:04.395442
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    # test with the default argument values for args
    args = {}
    args['user']='user'
    args['cron_file']='cron_file'

    cron_tab = CronTab(args)
    # We should have set this object to make every other method call
    # a pass, except this one.  We will check that the mock worked
    # by asserting that the test method is invoked.

    # test with a values not in the defaults for args


# Generated at 2022-06-11 06:53:15.037427
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    module = AnsibleModule(argument_spec={})
    module.selinux_enabled = MagicMock(return_value=False)
    module.run_command = MagicMock(
        return_value=(0, '', '')
    )

    cron_file = '/etc/cron.d/test_crontab'
    crontab = CronTab(module, cron_file=cron_file)

    with open(cron_file, 'w') as f:
        f.write('\n#Ansible: test_cronjob\n* * * * * root /bin/true\n')

    crontab.read()
    if len(crontab.get_envnames()) != 0:
        module.fail_json(msg="Should be no envnames for crontab.")


# Generated at 2022-06-11 06:53:22.263044
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    module = AnsibleModule(
        argument_spec = dict(
            user = dict(type='str', required=False),
            cron_file = dict(type='str', required=False),
            name = dict(type='str', required=False)
        )
    )
    module.exit_json = exit_json
    module.fail_json = fail_json

    # Run code here
    crontab = CronTab(module)

    # Print results
    print(crontab.get_jobnames())

# Generated at 2022-06-11 06:55:12.160985
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    cron_tab = CronTab()
    cron_tab.lines = ['#Ansible: test1\n', '* * * * * test\n']
    assert cron_tab.update_job('test1', '* * * * * new_test') == True
    assert cron_tab.lines == ['#Ansible: test1\n', '* * * * * new_test\n']



# Generated at 2022-06-11 06:55:23.559842
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    # Test basic case
    c = CronTab("")
    c.do_add_env(c.lines, "TEST_VARIABLE=abcdefg")
    assert c.lines[0] == "TEST_VARIABLE=abcdefg"
    # Test basic case when there are existing lines
    c.lines.append("")
    c.lines.append("30 7 * * *  root    test -x /etc/init.d/check_error && /etc/init.d/check_error restart")
    c.do_add_env(c.lines, "TEST_VARIABLE=1234567")
    assert c.lines[0] == "TEST_VARIABLE=1234567"


# Generated at 2022-06-11 06:55:32.690392
# Unit test for function main

# Generated at 2022-06-11 06:55:43.898220
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    crontab = CronTab()

    crontab.lines = []
    if not crontab.is_empty():
        raise Exception('Empty crontab list not empty')

    crontab.lines = ['# test crontab']
    if not crontab.is_empty():
        raise Exception('Empty crontab list not empty')

    crontab.lines = ['# test crontab', '']
    if not crontab.is_empty():
        raise Exception('Empty crontab list not empty')

    crontab.lines = [['# test crontab'], ['# test crontab']]
    if not crontab.is_empty():
        raise Exception('Empty crontab list not empty')


# Generated at 2022-06-11 06:55:53.742575
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    crontab = CronTab(user='testuser')
    assert "0 0 0 0 0" == crontab.get_cron_job(minute='0', hour='0', day='0', month='0', weekday='0', job='', special='', disabled='')
    assert "#0 0 0 0 0" == crontab.get_cron_job(minute='0', hour='0', day='0', month='0', weekday='0', job='', special='', disabled='disabled')
    assert "@daily" == crontab.get_cron_job(minute='0', hour='0', day='0', month='0', weekday='0', job='', special='daily', disabled='')

# Generated at 2022-06-11 06:55:56.855453
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
  module = AnsibleModule(argument_spec={})
  crontab = CronTab(module)

  lines = [1]
  comment = 'this is a comment'
  job = 'this is a job'

  crontab.do_remove_job(lines, comment, job)
  assert lines == []



# Generated at 2022-06-11 06:55:57.936309
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    # FIXME
    pass


# Generated at 2022-06-11 06:56:07.699463
# Unit test for function main
def test_main():
    global changed, backup_file
    changed, backup_file = False, None
    fake_module = AnsibleModule({
        'name': 'check dirs',
        'user': '',
        'job': 'ls -alh > /dev/null',
        'cron_file': '',
        'state': 'present',
        'backup': False,
        'minute': '*',
        'hour': '*',
        'day': '*',
        'month': '*',
        'weekday': '*',
        'special_time': None,
        'disabled': False,
        'env': False,
        'insertafter': '',
        'insertbefore': ''
    })
    main()
    assert changed == False
    assert backup_file is None


# Generated at 2022-06-11 06:56:08.697887
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    assert True


# Generated at 2022-06-11 06:56:18.671763
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    # pkg_resources is needed for some unit test to work.
    import pkg_resources
    from ansible.module_utils.basic import AnsibleModule
    from tempfile import mkdtemp
    from shutil import rmtree, copyfile
    from stat import S_IRWXU
    import os

    # pylint: disable=unused-argument
    def _fail_json(self, *args, **kwargs):
        raise RuntimeError("fail_json was called")

    # pylint: disable=unused-argument
    def _run_command(self, *args, **kwargs):
        return

    def remove_job_file_test(file_name, with_permission):
        temp_dir = mkdtemp()
        cron_file = os.path.join(temp_dir, file_name)