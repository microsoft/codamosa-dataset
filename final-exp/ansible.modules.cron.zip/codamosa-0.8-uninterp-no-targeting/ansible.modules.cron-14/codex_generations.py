

# Generated at 2022-06-20 21:30:45.483344
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    import tempfile
    p1 = tempfile.mktemp()
    crontab = CronTab(None, cron_file=p1)
    crontab.update_env('LABEL', "LABEL='\\$(date +'%Y-%m-%d %H:%M:%S')'")
    crontab.write()
    f = open(p1, 'rb')
    s = f.read()
    f.close()
    assert s == b"LABEL='\\$(date +'%Y-%m-%d %H:%M:%S')'\n"
    os.remove(p1)


# Generated at 2022-06-20 21:30:49.544967
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    test_lines = []
    test_comment = 'test_comment'
    test_job = 'test_job'

    try:
        instance = CronTab()
        instance.do_add_job(test_lines, test_comment, test_job)
    except Exception as e:
        assert False
    assert test_lines == [test_comment, test_job]

# Generated at 2022-06-20 21:30:52.487312
# Unit test for constructor of class CronTab
def test_CronTab():
    module = AnsibleModule(argument_spec={})
    cron = CronTab(module, 'root', '/etc/cron.d/pytest')



# Generated at 2022-06-20 21:30:55.393762
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    pass  # TODO

# Generated at 2022-06-20 21:31:00.313958
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    crontab = CronTab(None, None)
    lines = ['foo', 'bar']
    comment = '#Ansible: jobname'
    job = '@monthly /bin/false'
    crontab.do_add_job(lines, comment, job)
    assert lines == ['foo', 'bar', '#Ansible: jobname', '@monthly /bin/false']


# Generated at 2022-06-20 21:31:05.864880
# Unit test for method render of class CronTab
def test_CronTab_render():
    c = CronTab(module)
    crons = ['a', 'b', 'c']
    c.lines = crons
    result = c.render()

    assert result == '\n'.join(crons)


# Generated at 2022-06-20 21:31:13.507603
# Unit test for method write of class CronTab
def test_CronTab_write():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.facts.system.selinux

    # mock module class
    class TestModule(AnsibleModule):
        pass

    # mock module instance
    module = TestModule()

    mock = MagicMock()

    run_command = patch('ansible.module_utils.basic.AnsibleModule.run_command').start()
    run_command.return_value = (0, '', '')

    set_default_selinux_context = patch('ansible.module_utils.facts.system.selinux.set_default_selinux_context').start()
    selinux_enabled = patch('ansible.module_utils.facts.system.selinux.selinux_enabled').start()
    selinux_enabled.return_

# Generated at 2022-06-20 21:31:21.142237
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    ct = CronTab(mock.mock_module)
    ct.module = mock.mock_module

    input = "*/20 * * * * /bin/echo 'job' > /dev/null 2>&1"
    name = "/etc/cron.d/ansible-test-job"
    ct.do_remove_job(ct.lines, name, input)
    assert ct.lines == []

# Generated at 2022-06-20 21:31:29.173408
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    class MockAnsibleModule(object):
        def fail_json(self, *args, **kwargs):
            print(*args, **kwargs)
    mock_ansible_module = MockAnsibleModule()
    mock_ansible_module.check_mode = False
    mock_ansible_module.exit_json = lambda x: x
    mock_ansible_module.run_command = lambda x, **kwargs: ('', '', 0)
    mock_ansible_module.get_bin_path = lambda name, **kwargs: '/usr/bin/crontab'
    mock_ansible_module.set_default_selinux_context = lambda path, user: None
    mock_ansible_module.selinux_enabled = lambda : False
    module = mock_ansible_module

    ct = CronTab

# Generated at 2022-06-20 21:31:33.704569
# Unit test for constructor of class CronTabError
def test_CronTabError():
    try:
        raise CronTabError("test")
    except CronTabError as e:
        if not str(e) == "test":
            raise Exception("test fail")



# Generated at 2022-06-20 21:32:22.369303
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    assert CronTab.do_add_env(None, None) == None

# Generated at 2022-06-20 21:32:30.917527
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    check = CronTab(user=None, cron_file=None)
    check = CronTab(user=None, cron_file=None)
    check = CronTab(user=None, cron_file=None)
    check = CronTab(user=None, cron_file=None)
    check = CronTab(user=None, cron_file=None)
    check = CronTab(user=None, cron_file=None)
    check = CronTab(user=None, cron_file=None)
    check = CronTab(user=None, cron_file=None)
    check = CronTab(user=None, cron_file=None)


# Generated at 2022-06-20 21:32:38.405520
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():

    class TestModule(Module):
        def __init__(self, *args, **kwargs):
            self.params = args[0]
            self.args = args
            self.kwargs = kwargs
        def fail_json(self, **kwargs):
            self.rc = 1
        def get_bin_path(self, executable, opt_dirs=None, required=False):
            return executable
        def get_bin_paths(self, executable, opt_dirs=None):
            return self.get_bin_path(executable, opt_dirs, True)
    class TestAnsibleModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(TestAnsibleModule, self).__init__(*args, **kwargs)

# Generated at 2022-06-20 21:32:44.478056
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    tb = CronTab(None)
    tb.lines = [u'SHELL=/bin/bash']
    name = 'SHELL'
    result = tb.remove_env(name)
    assert result == True
    assert tb.lines == []


# Generated at 2022-06-20 21:32:47.105903
# Unit test for constructor of class CronTab
def test_CronTab():
    ct = CronTab(None, 'root')
    assert ct is not None

# Generated at 2022-06-20 21:32:49.683567
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    c = CronTab()
    assert c.remove_job_file() == False

# Generated at 2022-06-20 21:32:52.367823
# Unit test for method write of class CronTab
def test_CronTab_write():
    crontab = CronTab()
    out = crontab.write()
    assert out.startswith("#Ansible: ")


# Generated at 2022-06-20 21:33:04.522459
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    # setup the module objects
    module = AnsibleModule({})
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock

    # setup the crontab object
    cron = None
    cron = CronTab(module)

    # check if crontab is empty
    if cron.is_empty():
        module.fail_json(msg="crontab is empty")
        return

    # get envnames
    envnames = cron.get_envnames()

    # check for results
    if len(envnames) == 0:
        module.fail_json(msg="crontab does not contain any environment variables")
        return
    else:
        module.exit_json(ansible_facts={'cron_envnames': envnames})




# Generated at 2022-06-20 21:33:14.999507
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    import os
    import tempfile
    import textwrap
    from contextlib import contextmanager
    from ansible.module_utils.basic import AnsibleModule
    @contextmanager
    def tempfile_open(name):
        f = open(name, "w")
        try:
            yield f
        finally:
            f.close()
    # set up a temporary directory
    tmpdir = tempfile.mkdtemp()
    # set up a tempfile, which will be a crontab
    tf = tempfile.NamedTemporaryFile(mode='w', delete=False, dir=tmpdir)
    cron_file = tf.name

# Generated at 2022-06-20 21:33:27.968621
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    # Will create a test module used to call the class CronTab
    class AnsibleModule:
        pass
    ansible_module = AnsibleModule()
    ansible_module.run_command = my_run_command
    ansible_module.get_bin_path = my_get_bin_path
    ansible_module.selinux_enabled = my_selinux_enabled
    ansible_module.set_default_selinux_context = my_set_default_selinux_context
    ansible_module.fail_json = my_fail_json

# Generated at 2022-06-20 21:35:31.984297
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    ct = CronTab(None, None, '/etc/cron.d/cron-test')

    test_vars = ['foo="bar"', 'bar="baz"', 'baz="foo"']
    ct.add_env(test_vars[0])
    ct.add_env(test_vars[1])
    ct.add_env(test_vars[2])

    ct.remove_env('bar')

    assert test_vars[0] in ct.lines
    assert test_vars[1] not in ct.lines
    assert test_vars[2] in ct.lines


# Generated at 2022-06-20 21:35:39.232438
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    cron = CronTab(None, None)
    cron.lines = [
        '#Ansible: foo',
        '*/5 * * * * /usr/bin/echo foo',
        '*/5 * * * * /usr/bin/echo bar',
    ]
    names = []
    for l in cron.lines:
        if re.match(r'^\S+=', l):
            names.append(l.split('=')[0])
    assert (names == [])
    cron.update_env('foo', 'foo=bar')
    names = []
    for l in cron.lines:
        if re.match(r'^\S+=', l):
            names.append(l.split('=')[0])
    assert (names == ['foo'])


# Generated at 2022-06-20 21:35:40.230819
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    pass

# Generated at 2022-06-20 21:35:48.100302
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    ct = CronTab(None)
    ct.lines = []
    assert ct.get_envnames() == []
    ct.lines = ['foo=bar']
    assert ct.get_envnames() == ['foo']
    ct.lines = ['foo=bar', 'foo2=bar2']
    assert ct.get_envnames() == ['foo', 'foo2']
    ct.lines = ['foo=bar', 'foo2=bar2', 'line']
    assert ct.get_envnames() == ['foo', 'foo2']


# Generated at 2022-06-20 21:35:52.375418
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    ct = CronTab(None, user="dummy")

    lines = []
    ct.do_add_job(lines, "comment", "body")

    if lines[0] != "comment":
        raise AssertionError()
    if lines[1] != "body":
        raise AssertionError()



# Generated at 2022-06-20 21:36:04.051843
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    cron_tab = CronTab(module, user=None, cron_file=None)

    cron_tab.lines.append("#")
    cron_tab.lines.append("# Ansible: name1")
    cron_tab.lines.append("* * * * * command1")
    cron_tab.lines.append("# Ansible:  ")
    cron_tab.lines.append("* * * * * command2")
    cron_tab.lines.append("#")
    cron_tab.lines.append("# Ansible: name3")
    cron_tab.lines.append("* * * * * command3")

    job_names = cron_tab.get

# Generated at 2022-06-20 21:36:15.228634
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    job = CronTab.get_cron_job('*', '*', '*', '*', '*', 'ls -l', None, False)
    if job != '* * * * * ls -l':
        sys.exit(1)

    job = CronTab.get_cron_job('*', '*', '*', '*', '*', 'ls -l', 'reboot', False)
    if job != '* * * * * @reboot ls -l':
        sys.exit(1)

    job = CronTab.get_cron_job('*', '*', '*', '*', '*', 'ls -l', 'reboot', True)
    if job != '#* * * * * @reboot ls -l':
        sys.exit(1)

    job = CronTab.get_

# Generated at 2022-06-20 21:36:23.034961
# Unit test for function main
def test_main():
    args = dict(name='check dirs', hour='5,2', job='ls -alh > /dev/null', state='present')
    obj = AnsibleModule(argument_spec=args)
    crontab = CronTab(obj, '', '')


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:36:25.922281
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    """
    is_empty() returns False if all lines are empty
    """
    x = CronTab(None)
    x.lines = []

    return(x.is_empty() == True)


# Generated at 2022-06-20 21:36:32.254547
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    ct = CronTab("")
    # test 1
    ct.lines = ["", "#ansible: das", "SECRET_KEY=secretmrniceguy", "#ansible: obj", "CELERY_BROKER_URL=redis://localhost:6379/0",
                "#ansible: orm"]
    assert(ct.get_envnames() == ["CELERY_BROKER_URL", "SECRET_KEY"])

