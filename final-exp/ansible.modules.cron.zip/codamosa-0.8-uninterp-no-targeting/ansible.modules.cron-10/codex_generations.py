

# Generated at 2022-06-20 21:30:48.334250
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    t = CronTab()
    t.lines = [
        "#Ansible: some job",
        "15 14 * * * root ls -al",
        "0 0 0 * * root some other job",
        "#Ansible: another job",
        "15 14 * * * root rm -rf /",
    ]

    t.do_remove_job(t.lines, '#Ansible: some job', '15 14 * * * root ls -al')
    assert t.lines == [
        "#Ansible: another job",
        "15 14 * * * root rm -rf /",
    ]

    # Should do nothing
    t.do_remove_job(t.lines, '#Ansible: another job', '')

# Generated at 2022-06-20 21:30:57.758447
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    m = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    # Initialise object 'cron'
    cron = CronTab(m)
    # Initialise parameters
    minute = "0"
    hour = "0"
    day = "1"
    month = "1"
    weekday = "0"
    job = "job"
    special = None
    disabled = False
    output = cron.get_cron_job(minute, hour, day, month, weekday, job, special, disabled)
    assert output == "0 0 1 1 0 job"
    # Initialise parameters
    minute = "0"
    hour = "0"
    day = "1"
    month = "1"
    weekday = "0"
    job = "job"
    special = "reboot"

# Generated at 2022-06-20 21:31:05.830161
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    """
    Test get_jobnames method of class CronTab
    """
    c = CronTab(user=None)
    c.lines = ['#Ansible: foobar']
    assert c.get_jobnames() == ['foobar']
    c.lines = ['#Ansible: foobar', '#Ansible: barfoo']
    assert c.get_jobnames() == ['foobar', 'barfoo']
    c.lines = ['#Ansible: foobar', '#Ansible: barfoo', '#', '#Ansible: bazbaz']
    assert c.get_jobnames() == ['foobar', 'barfoo', 'bazbaz']
    c.lines = ['']
    assert c.get_jobnames() == []

# Generated at 2022-06-20 21:31:11.272657
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    # Test skipping when parameters are incorrect
    if CronTab.do_remove_job.__doc__ is None:
        raise ValueError("No docstring")
    # Test when exception is raised
    try:
        raise Exception("Exception message")
    except Exception:
        assert CronTab.do_remove_job(Exception, "Exception message") == "Exception message"
    # Test when function returns None
    assert CronTab.do_remove_job(None, None) is None

# Generated at 2022-06-20 21:31:16.529602
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    module = AnsibleModule(argument_spec={})
    cron_tab = CronTab(module)
    cron_tab.lines = ['key=value2', 'key2=value', 'key=value']
    assert cron_tab.find_env('key') == [0, 'key=value2']
    assert cron_tab.find_env('key2') == [1, 'key2=value']
    assert cron_tab.find_env('key3') == []


# Generated at 2022-06-20 21:31:18.584710
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    result = CronTab.find_env()
    assert result is None, "Method find_env of class CronTab did not return None as expected!"


# Generated at 2022-06-20 21:31:21.878270
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    ct=CronTab(None, None, None)
    #name = 'update_job_name'
    #job = 'update_job_job'
    #addlinesfunction = ct.do_add_job
    assert True


# Generated at 2022-06-20 21:31:31.354691
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class MockModule(object):
        @staticmethod
        def fail_json(msg): raise Exception(msg)

        def run_command(self, cmd, **kwargs):
            return 0, '', ''

        def selinux_enabled(self):
            return False

        @staticmethod
        def _load_params(*args, **kwargs):
            return {}

        @staticmethod
        def get_bin_path(name, required=False):
            return 'crontab'

    fake_args = {
        'user': 'someone',
        'backup': False,
        'state': 'present',
    }

    # Case: cron_file does not exists

# Generated at 2022-06-20 21:31:42.088056
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    module = AnsibleModule(argument_spec=dict())
    input_lines = """
#Ansible: test1
30 2 * * * root test_command1
#Ansible: test2
30 2 * * * root test_command2
#Ansible: test3
30 2 * * * root test_command3
#Ansible: test4
#Ansible: test5
"""
    expected_output = ['test1', 'test2', 'test3', 'test4', 'test5']
    crontab = CronTab(module)
    crontab.lines = input_lines.splitlines()
    assert crontab.get_jobnames() == expected_output, 'Parsing of \'Ansible:\' comments failed'


# Generated at 2022-06-20 21:31:55.001151
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True),
            job = dict(required=True),
            cron_file = dict(required=False),
            user = dict(required=False),
        ),
        supports_check_mode=True
    )

    cron_file = module.params['cron_file']
    user = module.params['user']
    name = module.params['name']
    job = module.params['job']

    c = CronTab(module, cron_file, user)

    c.update_job(name, job)

    if module.check_mode:
        module.exit_json(changed=True)

# Generated at 2022-06-20 21:32:40.744921
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    #TODO - implement
    pass


# Generated at 2022-06-20 21:32:51.337690
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    from ScriptingLayerForUnix import crontab

    ct = crontab.CronTab(user=None, cron_file=None)
    ct.do_add_env(ct.lines, 'SOMEVAR=/some/path')
    print(ct.lines)
    print(ct.render())

    ct.do_add_env(ct.lines, 'SOMEVAR2=/some/path2')
    print(ct.lines)
    print(ct.render())



# Generated at 2022-06-20 21:32:54.334991
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    module = AnsibleModule(argument_spec={})
    ct = CronTab(module)
    ct.do_add_env(['line1', 'line2'], 'decl3')
    assert (ct.lines == ['line1', 'line2', 'decl3'])



# Generated at 2022-06-20 21:33:02.005983
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict()
    )

    module.params = dict(
        name='TEST'
    )

    c = CronTab(module)

    assert c.do_remove_env(None, None) == None


# Generated at 2022-06-20 21:33:05.890098
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    ct = CronTab(None, "root", "test")
    result = ct.do_comment("test")
    assert result == "#Ansible: test"


# Generated at 2022-06-20 21:33:12.999356
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    lines = []
    comment = "comment"
    job = "job"
    cron = CronTab(basic.AnsibleModule(argument_spec={}))
    cron.do_add_job(lines, comment, job)
    assert lines == ["comment", "job"]


# Generated at 2022-06-20 21:33:15.509208
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    # test for method remove_env of class CronTab
    assert True



# Generated at 2022-06-20 21:33:28.528581
# Unit test for method update_job of class CronTab

# Generated at 2022-06-20 21:33:37.848202
# Unit test for function main
def test_main():
    test_args = dict(
        name="test_job",
        user="test_user",
        job="test_job",
        cron_file="test_cron_file",
        state="test_state",
        backup=True,
        minute="test_minute",
        hour="test_hour",
        day="test_day",
        month="test_month",
        weekday="test_weekday",
        special_time="daily",
        disabled=False,
        env=True,
        insertafter="test_insertafter",
        insertbefore="test_insertbefore",
    )
    with pytest.raises(SystemExit):
        main(ansible_args=test_args)

# Generated at 2022-06-20 21:33:40.036091
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    obj = CronTab(module=dict())
    obj.write()


# Generated at 2022-06-20 21:34:35.350978
# Unit test for method render of class CronTab
def test_CronTab_render():
    # Common config
    module = Mock()
    module.selinux_enabled.return_value = False
    module.get_bin_path.return_value = '/bin/crontab'
    # Instantiate and configure the tested instance
    n=CronTab(module)
    n.lines = ['a', 'b']
    # Expected result
    expected = 'a\nb\n'
    # Real result
    result = n.render()
    # Assertion
    assert result == expected

# Generated at 2022-06-20 21:34:43.650227
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    from ansible.module_utils.basic import AnsibleModule
    # TODO: we should get rid of using AnsibleModule in the tests
    m = AnsibleModule(argument_spec={})
    ct = CronTab(m)
    ct.add_job("my_job", "* * * * * /bin/true")
    assert ct.lines == ['#Ansible: my_job', '* * * * * /bin/true']

# Generated at 2022-06-20 21:34:50.331178
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    class Mod():
        def __init__(self, out):
            self.out = out

        def run_command(self, cmd):
            return (0, self.out, '')

    c = CronTab(Mod('#Ansible: do_something\n* * * * * touch /tmp/do_something\n'))
    assert c.get_jobnames() == ['do_something']

    c = CronTab(Mod('* * * * * touch /tmp/do_something\n'))
    assert c.get_jobnames() == []

    c = CronTab(Mod('#Ansible: do_something\n* * * * * touch /tmp/do_something\n#Ansible: do_something_else\n* * * * * touch /tmp/something_else\n'))

# Generated at 2022-06-20 21:34:56.804888
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    # Read a crontab from the system
    c = CronTab('/etc/crontab')

    # Add a job, with name myjob
    c.add_job('myjob', '* * * * * /tmp/test.sh')

    # Update the job
    c.update_job('myjob', '* * * * * /tmp/test.pl')

    # Write the crontab back to the system
    c.write()



# Generated at 2022-06-20 21:34:59.249311
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    lines = []

    cron = CronTab(None, 'test_user')
    cron.do_add_job(lines, 'test_comment', 'test_job')

    assert lines == ['test_comment', 'test_job']



# Generated at 2022-06-20 21:35:02.540208
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    c = CronTab()
    lines = []
    comment = 'test'
    job = 'foo'
    c.do_add_job(lines, comment, job)
    assert lines == ['#Ansible: test', 'foo']



# Generated at 2022-06-20 21:35:08.882386
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    # Initialize the class to test
    test_ct = CronTab()

    # Declare variable to test
    name = 'VAR1'

    # Test find_env with different variable names and lengths
    name = 'VAR1'
    test_env = 'VAR1=1'
    expected_outcome = [0, test_env]
    assert test_ct.find_env(name) == expected_outcome

    name = 'VAR2'
    test_env = 'VAR2=1'
    expected_outcome = [1, test_env]
    assert test_ct.find_env(name) == expected_outcome

    name = 'VAR3'
    test_env = 'VAR3=1'
    expected_outcome = [2, test_env]
    assert test_ct.find

# Generated at 2022-06-20 21:35:10.917452
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    module = AnsibleModule(argument_spec={})
    cron = CronTab(module)
    assert cron.remove_env("FOO") == False


# Generated at 2022-06-20 21:35:22.513673
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    """
    Test expected correct behavior of add_env
    """
    # Example module input
    module = AnsibleModule(
        argument_spec=dict(
            job=dict(required=False, type='str'),
            _raw_params=dict(required=False, type='str'),
        ),
        supports_check_mode=False
    )

    crontab = CronTab(module, user=None, cron_file=None)

    # Example call to add_env
    decl = ("BAR='some value'")
    insertafter = ("FOO")
    insertbefore = (None)

    crontab.add_env(decl, insertafter, insertbefore,)

    # Example expected output
    assert crontab.lines[0] == "BAR='some value'"



# Generated at 2022-06-20 21:35:26.504294
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    for x in ["\n"]:
        c=CronTab(x)
        try:
            assert c.is_empty() == True
        except CronTabError:
            pass

# Generated at 2022-06-20 21:36:53.305618
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    ct = CronTab(None)
    assert ct.update_job('foo', 'bar') == False


# Generated at 2022-06-20 21:36:58.091741
# Unit test for function main

# Generated at 2022-06-20 21:37:03.845631
# Unit test for method write of class CronTab
def test_CronTab_write():
    ct = CronTab()
    ct.user = 'jhoblitt'
    with mock.patch.object(ct.module, 'run_command') as mock_rc:
        ct.write()
        mock_rc.assert_called_once()
        assert(mock_rc.call_args[0][0] == 'crontab -u jhoblitt -')


# Generated at 2022-06-20 21:37:12.218965
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True),
            job = dict(),
            cron_file = dict(),
        )
    )

    my_crontab = CronTab(module)

    test_cases = [
        ["name", "job", [], "name job"],
        ["name", "job", ["not this name", "job"], "name NOT job"],
        ["name", "job", ["name", "not this job"], "name job NOT"],
        ["name", "", ["name", "job"], "name job but job is empty"],
    ]

    for (name, job, answer, test_name) in test_cases:
        expected = answer

        my_crontab.find_job(name, job)
        actual = my_crontab.find_job

# Generated at 2022-06-20 21:37:19.500570
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    # instantiate
    crontab = CronTab(module)
    # peform test
    result = crontab.remove_job(name='')
    # compare
    assert result is True
    # peform test
    result = crontab.remove_job(name='')
    # compare
    assert result is True


# Generated at 2022-06-20 21:37:28.664838
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    tab = CronTab(module, user=None, cron_file=None)
    tab.lines = []
    assert tab.is_empty() is True
    tab.lines = ['#comment', '', '', '', 'other']
    assert tab.is_empty() is False
    tab.lines = ['#comment', '', '', '', '', '     ', '', ';']
    assert tab.is_empty() is True



# Generated at 2022-06-20 21:37:39.234424
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    # Test for find_env
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True),
            user=dict(type='str', required=False),
            cron_file=dict(type='str', required=False),
        ),
        supports_check_mode=True,
    )
    name = module.params['name']
    user = module.params['user']
    cron_file = module.params['cron_file']
    c = CronTab(module, user, cron_file)
    index = c.find_env(name)
    module.exit_json(index=index)



# Generated at 2022-06-20 21:37:46.702935
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    crontab = CronTab(user=None, cron_file=None)
    crontab.lines = ['comment', 'job', 'dead', 'beef']
    crontab.do_remove_job(crontab.lines, 'dead', 'beef')
    assert len(crontab.lines) == 1


# Generated at 2022-06-20 21:37:51.420550
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    module = AnsibleModule(argument_spec={})
    ct = CronTab(module)
    ct.lines = ["#Ansible: test","* * * * * /bin/echo test"]
    ct.remove_job("test")
    assert ct.lines == []


# Generated at 2022-06-20 21:37:59.169330
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    ct = CronTab(None)
    assert ct.get_cron_job('*', '*', '*', '*', '*', '/some/path', None, False) == '* * * * * /some/path'
    assert ct.get_cron_job('*', '*', '*', '*', '*', '/some/path', None, True) == '#* * * * * /some/path'
    assert ct.get_cron_job('*', '*', '*', '*', '*', '/some/path', 'daily', False) == '* * * * * /some/path'