

# Generated at 2022-06-20 21:30:46.999435
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    module.fail_json = lambda x: True
    module.run_command = lambda x: (0, '', '')
    cron = CronTab(module)
    cron.do_comment = lambda x: '#Ansible:' + x
    cron.do_add_job(['#Ansible:job1','10 * * * * user cmd1','#Ansible:job3'], '#Ansible:job2', '10 * * * * user cmd2')
    assert cron.lines == ['#Ansible:job1','10 * * * * user cmd1','#Ansible:job2','10 * * * * user cmd2','#Ansible:job3']

#

# Generated at 2022-06-20 21:30:50.842474
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    c = CronTab(module, cron_file='mycron')
    c.add_env('new_line', insertafter='another_line')
    assert c.lines == ['#Ansible: another_line', 'another_line', 'new_line', '#Ansible: one_more_line', 'one_more_line']


# Generated at 2022-06-20 21:30:58.212240
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    for test_input, expected in [
        (["SOME_VAR=some_value", "SOME_VAR=some_other_value"], [0, "SOME_VAR=some_value"]),
        (["SOME_VAR=some_value", "VARIABLE=value"], [0, "SOME_VAR=some_value"]),
        (["VARIABLE=some_value", "SOME_VAR=value"], [1, "SOME_VAR=value"]),
    ]:
        ct = CronTab(None)
        ct.lines = test_input
        assert ct.find_env("SOME_VAR") == expected

# Generated at 2022-06-20 21:31:03.810527
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    crontab = CronTab(None, user='root', cron_file=None)
    
    if crontab.lines:
      assert len(crontab.lines) > 0, 'lines should not be empty.'


# Generated at 2022-06-20 21:31:06.802956
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
  import os
  cron = CronTab(None)
  cron.find_env()


# Generated at 2022-06-20 21:31:13.757671
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    from ansible.module_utils.crontab import CronTab
    import os
    import pwd
    import tempfile

    cron_file = "/etc/cron.d/test"
    job = "* * * * * root echo test"

    try:
        f = open(cron_file, 'wb')
        f.write(job)
        f.close()
    except Exception:
        raise CronTabError("Unexpected error:", sys.exc_info()[0])

    user = pwd.getpwuid(os.getuid())[0]
    ct = CronTab(user, cron_file)

    assert ct.find_job("test") == ["test", "* * * * * root echo test"]

if __name__ == '__main__':
    import sys

# Generated at 2022-06-20 21:31:17.559290
# Unit test for function main
def test_main():
    import __builtin__ as builtins
    try:
        set_module_args({
            'name': '**UNIT TEST**'
            })

        # Restore the builtins on exit:
        yield patch_builtins
    except Exception:
        pass
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:31:26.446347
# Unit test for method remove_env of class CronTab

# Generated at 2022-06-20 21:31:29.888333
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    (ret, err) = crontab._remove_job_file()
    assert not ret and err == "cron file does not exist"


# Generated at 2022-06-20 21:31:38.664560
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    job_name = "hippo"
    job = "* * * * * /bin/run_me_now"
    ct = CronTab(None, user="root")
    ct.do_add_job(ct.lines, job_name, job)
    expected = ["#Ansible: hippo", "* * * * * /bin/run_me_now"]
    assert ct.lines == expected



# Generated at 2022-06-20 21:33:31.267971
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, testfile = tempfile.mkstemp(dir=tmpdir, prefix='test_CronTab_remove_job', text=True)

    # Test call to method remove_job of class CronTab with a non-existant cron job
    ct = CronTab(user='root', cron_file=testfile)
    ct.remove_job('test')
    assert ct.lines == []

    # Test call to method remove_job of class CronTab with a existant cron job
    ct = CronTab(user='root', cron_file=testfile)
    ct.write(backup_file=testfile)

# Generated at 2022-06-20 21:33:34.952285
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
        ct = CronTab(None)
        ct.lines = ['']
        assert ct.is_empty() == True

# Generated at 2022-06-20 21:33:47.232883
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    ct = CronTab(None)

    # Test one-liner env
    assert ct.add_env("FOO=BAR") is None
    assert len(ct.lines) == 1
    assert ct.lines[0] == "FOO=BAR"

    # Test multi-liner env
    assert ct.add_env("FOO=BAR\n") is None
    assert len(ct.lines) == 2
    assert ct.lines[0] == "FOO=BAR"
    assert ct.lines[1] == ""

    # Test insertafter
    ct.lines = []
    assert ct.add_env("FOO=BAR\n", insertafter="BAR") is None
    assert len(ct.lines) == 1

# Generated at 2022-06-20 21:33:55.358455
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    test_name = "test name"
    test_job = "test job"
    test_special = "test special"
    minute = '*'
    hour = '*'
    day = '*'
    month = '*'
    weekday = '*'

    crontab = CronTab(name, crontab)
    disabled = False
    cronjob_exp = '%s %s %s %s %s %s %s %s' % (
        minute, hour, day, month, weekday, name, test_job)
    cronjob = crontab.get_cron_job(
        minute, hour, day, month, weekday, test_job, None, disabled)
    assert (cronjob == cronjob_exp)

    disabled = True

# Generated at 2022-06-20 21:33:59.696096
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    o = CronTab(module)

    o.do_add_job(o.lines, '#Ansible: test', 'TEST')

    assert o.lines[0] == '#Ansible: test'
    assert o.lines[1] == 'TEST'

# Generated at 2022-06-20 21:34:09.732811
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    crontab = CronTab(module)
    # make a dummy crontab
    crontab.lines = ['#Ansible: abc\n', '* * * * * test']
    crontab.add_env('a=1')
    assert crontab.lines == ['a=1\n', '#Ansible: abc\n', '* * * * * test']
    crontab.add_env('b=2', insertafter='a')
    assert crontab.lines == ['a=1\n', 'b=2\n', '#Ansible: abc\n', '* * * * * test']
    crontab.add_env('c=3', insertbefore='b')

# Generated at 2022-06-20 21:34:19.916211
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    module = AnsibleModule(
        argument_spec = dict(
            user = dict(default=None),
            cron_file = dict(default=None),
        ),
        supports_check_mode = True
    )
    cron = CronTab(module, user=module.params['user'], cron_file=module.params['cron_file'])
    assert len(set(cron.get_jobnames()) & set(['job1', 'job2', 'job3', 'job4', 'job5', 'job6', 'job7', 'job8', 'job9', 'job10', 'CronTab', 'test_CronTab_get_jobnames', 'test_CronTab_remove_job'])) == 11,"test_CronTab_get_jobnames : job names are incorrect"


# Generated at 2022-06-20 21:34:29.054648
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    import tempfile
    import os

    assertCrond = True
    assertModule = True

    assertCrond = 'crontab' in os.listdir('/usr/bin/')
    assertModule = 'cron' in os.listdir('/usr/lib/python2.6/site-packages/ansible/modules/')

    if assertCrond and assertModule:
        fd, path = tempfile.mkstemp(prefix='crontab')
        os.chmod(path, int('0644', 8))

        dut = CronTab(None, cron_file=path)

        # test remove env

        # add an env
        dut.add_env('ENV1=value1')

        # verify add env
        env = dut.find_env('ENV1')

# Generated at 2022-06-20 21:34:29.808549
# Unit test for constructor of class CronTabError
def test_CronTabError():
    CronTabError()



# Generated at 2022-06-20 21:34:34.455208
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    ansible_module = AnsibleModule(
        argument_spec = dict()
    )
    ct = CronTab(ansible_module)
    assert ct.is_empty() == True


# Generated at 2022-06-20 21:36:39.090721
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    module = AnsibleModule(
        argument_spec=dict(
            a=dict(type='int'),
            b=dict(type='int')
        )
    )
    crontab = CronTab(module)
    lines = []
    ansible_test_testvariable_name = 'testvariable'
    ansible_test_testvariable_value = 'testvalue'
    ansible_test_testvariable_decl = 'testvariable=testvalue'
    crontab.do_add_env(lines, ansible_test_testvariable_decl)
    assert lines[0] == ansible_test_testvariable_decl


# Generated at 2022-06-20 21:36:50.372621
# Unit test for constructor of class CronTab
def test_CronTab():
    import tempfile
    import shutil

    testdir = tempfile.mkdtemp()
    testfile = os.path.join(testdir, 'testfile')
    testfile2 = os.path.join(testdir, 'testfile2')

    ct = CronTab(None)

    # ensure functions work when not using a file
    ct.is_empty()
    ct.get_jobnames()
    ct.render()

    # make sure we can create the file
    ct = CronTab(None, user=None, cron_file=testfile)
    assert ct.cron_file == testfile

    # make sure we can read the file
    ct = CronTab(None, user=None, cron_file=testfile)
    assert ct.cron_file == testfile

    #

# Generated at 2022-06-20 21:36:52.468140
# Unit test for method write of class CronTab
def test_CronTab_write():
    check_write = CronTab(user='dummyuser', cron_file='dummyfile')
    check_write.write()

if __name__ == '__main__':
    test_CronTab_write()

# Generated at 2022-06-20 21:36:55.120497
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    test_class = CronTab(module, cron_file='test_file')
    test_class.remove_job_file()



# Generated at 2022-06-20 21:36:58.432699
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    _ct = CronTab(None, user=None, cron_file=None)
    result = _ct.find_env("PYTHONPATH")
    assert result == [], "Test failure in test_CronTab_find_env"

# Generated at 2022-06-20 21:37:02.491976
# Unit test for method write of class CronTab
def test_CronTab_write():
    with tempfile.NamedTemporaryFile('w+') as f:
        cron = CronTab(user='root', cron_file=f.name)
        cron.write()
        f.seek(0)
        assert f.read() == cron.render()



# Generated at 2022-06-20 21:37:08.948073
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    user_id = utils.get_uid(module)
    user = pwd.getpwuid(user_id)[0]
    c = CronTab(module, user=user)

    modifications = 0
    for name in ['1', '2', '3']:
        try:
            c.remove_job(name)
            modifications += 1
        except Exception:
            pass

    assert modifications == 0, "Failed to update crontab"

# Generated at 2022-06-20 21:37:14.501802
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    assert CronTab(None).get_cron_job('minute', 'hour', 'day', 'month', 'weekday', 'job', 'Special value', False) == 'minute hour day month weekday job'
    assert CronTab(None).get_cron_job('minute', 'hour', 'day', 'month', 'weekday', 'job', 'Special value', True) == '#minute hour day month weekday job'
    assert CronTab(None).get_cron_job('1', '*', '*', '*', '*', 'ansible-test-command', None, False) == '1 * * * * ansible-test-command'


# Generated at 2022-06-20 21:37:29.399401
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    module = AnsibleModule(
        argument_spec = dict(
            user = dict(required=False, default=None),
            cron_file = dict(required=False, default=None),
        ),
        supports_check_mode=True
    )

    ct = CronTab(module, user='noone', cron_file='/etc/cron.d/anyfile')
    ct.add_job('noone_job', '* * * * * echo "test_CronTab_add_job"')
    assert ct.render() == '#Ansible: noone_job\n* * * * * echo "test_CronTab_add_job"\n', "ct.render() returned "+ct.render()


# Generated at 2022-06-20 21:37:39.234178
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    lines = []
    lines.append('#Ansible: test1')
    lines.append('* * * * * /bin/false')
    lines.append('#Ansible: test3')
    lines.append('* * * * * /bin/true')
    comment = '#Ansible: test2'
    job = '* * * * * /bin/true'
    expected = None
    result = do_remove_job(lines,comment,job)
    assert result == expected, "Expected {0}, got {1}".format(expected, result)
