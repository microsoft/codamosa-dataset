

# Generated at 2022-06-20 21:30:42.795407
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    """
    Test case for function add_env of class CronTab
    """
    pass

# Generated at 2022-06-20 21:30:52.706556
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    # try 1 - empty
    c = CronTab(user="root")
    assert c.is_empty()

    # try 2 - not empty
    c = CronTab(user="root")
    c.lines = [ '#Ansible: foo', '* * * * * /usr/bin/echo foo' ]
    assert not c.is_empty()

    # try 3 - not empty but all comment or whitespace
    c = CronTab(user="root")
    c.lines = [ '#This is a comment', '    ' ]
    assert c.is_empty()


# Generated at 2022-06-20 21:31:08.800888
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    """
    Unit testing for method of CronTab class.
    See documentation of the method do_add_env for more information.
    """
    ##################
    # Setup
    ##################
    mylines = []
    mydecl = 'FOO=BAR'
    lines = ['Some other cron job',
             'Some other cron job',
             'Some other cron job',
             'Some other cron job',
             'Some other cron job']
    ##################
    # Run
    ##################
    for l in lines:
        mylines.append(l)
    mylines.append(mydecl)
    ##################
    # Verification
    ##################
    assert lines[0] == "Some other cron job"
    assert lines[1] == "Some other cron job"

# Generated at 2022-06-20 21:31:14.697207
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    # ensure all behaviors of CronTab.remove_job are covered
    c = CronTab(None)
    assert len(c.lines) == 0

    c.lines = ["#Ansible: remove_job1", "remove_job1_cron_line"]
    c.remove_job("remove_job1")
    assert len(c.lines) == 0

    c.lines = ["remove_job2_cron_line"]
    assert len(c.lines) > 0
    c.remove_job("remove_job2")
    assert len(c.lines) == 0

    c.lines = ["#ansible: remove_job3", "remove_job3_cron_line"]
    c.remove_job("remove_job3")
    assert len(c.lines) == 1

# Generated at 2022-06-20 21:31:17.249374
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    assert CronTab(None).is_empty()



# Generated at 2022-06-20 21:31:20.496394
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    utils = AnsibleModule(argument_spec={'test': {"required": True, "type": "bool"}})
    assert CronTab(utils).do_add_env(['test'], 'test') == ['test', 'test']



# Generated at 2022-06-20 21:31:23.346212
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    cron_tab = CronTab()
    comment = '#Ansible: test remove_env'
    var_name = 'NAME'
    var = '%s=value_for_var' % var_name
    cron_tab.lines = [comment, var]
    cron_tab.remove_env(var_name)
    assert cron_tab.lines == [comment]


# Generated at 2022-06-20 21:31:30.624453
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    test_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Create a crontab to test
    crontab = CronTab(test_module, user="root", cron_file="/tmp/test_cron")

# Generated at 2022-06-20 21:31:36.350393
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    n = '$PATH'
    d = '/bin/sh'
    c = CronTab(None)
    c.add_env(d)
    if c._find_env(n) != [0, d]:
        return False
    return True

# Generated at 2022-06-20 21:31:39.143159
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    # TODO: implement tests for test_CronTab_find_job
    pass



# Generated at 2022-06-20 21:32:34.266085
# Unit test for constructor of class CronTabError
def test_CronTabError():
    try:
        raise CronTabError()
    except CronTabError:
        pass



# Generated at 2022-06-20 21:32:43.912946
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    module = AnsibleModule(argument_spec=dict())
    obj = CronTab(module)
    test_is_empty_param = None

    try:
        obj.is_empty(test_is_empty_param)
    except Exception:
        assert False, "Exception thrown"

    # Tests with edge cases
    # TODO: Log error if test case fails.
    # TODO: Write test cases for all edge cases.



# Generated at 2022-06-20 21:32:50.612702
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    ct = CronTab()
    lines = []
    comment = '#Ansible: test1'
    job = '@hourly ls'
    ct.do_add_job(lines, comment, job)
    assert lines == ['#Ansible: test1', '@hourly ls']


# Generated at 2022-06-20 21:32:52.367427
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    assert CronTab.do_remove_env(None, None, None) == None


# Generated at 2022-06-20 21:32:57.035439
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    crontab = CronTab()
    lines = []
    comment = '#Ansible: test_job'
    job = '* * * * * /usr/bin/echo foobar'
    crontab.do_add_job(lines, comment, job)
    assert lines == ['#Ansible: test_job', '* * * * * /usr/bin/echo foobar']
    return True


# Generated at 2022-06-20 21:32:59.924136
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    # test method do_remove_env
    c = CronTab()
    assert c.do_remove_env([], ''), None


# Generated at 2022-06-20 21:33:01.558274
# Unit test for constructor of class CronTab
def test_CronTab():
    cron = CronTab()
    assert cron


# Generated at 2022-06-20 21:33:11.175466
# Unit test for constructor of class CronTab
def test_CronTab():
    # test for standard user
    c = CronTab()
    assert (c.user == getpass.getuser())
    assert (c.root == False)

    # test for root user
    uid = os.getuid()
    try:
        os.setuid(0)
        c = CronTab()
        assert(c.user == getpass.getuser())
        assert(c.root == True)
    finally:
        os.setuid(uid)

    # test for special cron file
    c = CronTab('/etc/cron.d/some_other_cron_file')
    assert (c.cron_file == '/etc/cron.d/some_other_cron_file')

    # test for user
    c = CronTab(user='some_user')

# Generated at 2022-06-20 21:33:15.959314
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
  crontab = CronTab(None,"test_crontab_name")
  jobnames = crontab.get_jobnames()
  jobnames_expected = "test_crontab_name"
  assert jobnames == jobnames_expected

# Generated at 2022-06-20 21:33:26.206063
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    TEST_CASES = [
        ("test comment", "test job", ["test comment", "test job"]),
    ]

    for (comment, job, expected) in TEST_CASES:
        ct = CronTab("test")
        lines = []
        ct.do_add_job(lines, comment, job)
        if lines != expected:
            print("Unexpected result: %s" % repr(lines))
            print("Expected result:   %s" % repr(expected))
            sys.exit(1)
    print("All tests OK.")
    sys.exit(0)

# Generated at 2022-06-20 21:35:33.134703
# Unit test for method read of class CronTab
def test_CronTab_read():

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    module = AnsibleModule(
        argument_spec=dict(
            user=dict(required=False, type='str'),
            cron_file=dict(required=False, type='str'),
        ),
        supports_check_mode=True
    )

    try:
        ct = CronTab(module)
    except Exception as e:
        module.fail_json(msg=get_exception())

    s = ct.render()
    module.exit_json(changed=False, crontab=s)

# Generated at 2022-06-20 21:35:36.060213
# Unit test for method read of class CronTab
def test_CronTab_read():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    module.exit_json = exit_json
    crontab = CronTab(module)
    # TODO: Implement tests for crontab.read()


# Generated at 2022-06-20 21:35:48.052282
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    module = AnsibleModule(argument_spec={})
    crontab = CronTab(module, cron_file='/etc/cron.d/test1')
    assert crontab.get_cron_job('*', '*', '*', '*', '*', 'test', None, False) == '* * * * * test'
    assert crontab.get_cron_job('*', '*', '*', '*', '*', 'test', None, True) == '#* * * * * test'
    assert crontab.get_cron_job('*', '*', '*', '*', '*', 'test', 'reboot', True) == '#@reboot test'

# Generated at 2022-06-20 21:36:04.312489
# Unit test for method render of class CronTab
def test_CronTab_render():
    ct = CronTab('root')
    ct.lines = ['#', '# This is a comment', '#']
    assert ct.render() == '\n'.join(ct.lines[1:]) + '\n'
    ct.lines = ['0', '0', '0', '0', '0', '0', '0']
    assert ct.render() == '\n'.join(ct.lines) + '\n'
    ct.lines.extend(['#', '# This is a comment', '#'])
    assert ct.render() == '\n'.join(ct.lines[:-3]) + '\n' + '\n'.join(ct.lines[-2:-1]) + '\n'
    ct.lines = []
    assert ct.render() == ''


# Generated at 2022-06-20 21:36:08.393801
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    crontab = CronTab()
    crontab.update_job("test", "test")
    assert(crontab.lines[0] == "#Ansible: test")
    assert(crontab.lines[1] == "test")

# Generated at 2022-06-20 21:36:10.867519
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    # Use unconditional return for unit tests
    assert True


# Generated at 2022-06-20 21:36:21.288919
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    module = AnsibleModule(argument_spec={})
    cron_tab = CronTab(module, 'root')
    cron_tab.lines = ['TERM=xterm', 'SHELL=/bin/bash']
    assert cron_tab.find_env('TERM') == [0, 'TERM=xterm']
    assert cron_tab.find_env('SHELL') == [1, 'SHELL=/bin/bash']
    assert cron_tab.find_env('EDITOR') == []


# Generated at 2022-06-20 21:36:24.925662
# Unit test for constructor of class CronTabError
def test_CronTabError():
    try:
        raise CronTabError("error message")
    except CronTabError as e:
        assert(e.args[0] == "error message")



# Generated at 2022-06-20 21:36:36.720383
# Unit test for function main

# Generated at 2022-06-20 21:36:41.384359
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    test_object = CronTab(user=None, cron_file=None)
    assert(test_object.do_comment('name') == '#Ansible: name')

