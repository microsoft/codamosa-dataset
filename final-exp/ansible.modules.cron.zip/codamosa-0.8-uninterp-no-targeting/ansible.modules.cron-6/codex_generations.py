

# Generated at 2022-06-20 21:30:42.077517
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    ct = CronTab(user='root', cron_file='cron_file')
    # Test with invalid parameters
    assert ct.add_env(decl='', insertafter=None, insertbefore=None) == None, "CronTab.add_env failed with invalid parameters"

# Generated at 2022-06-20 21:30:50.228605
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.basic
    module = AnsibleModule(
        argument_spec={
            "name": {"required": True, "type": 'str'},
            "minute": {"required": True, "type": 'str'},
            "hour": {"required": True, "type": 'str'},
            "day": {"required": True, "type": 'str'},
            "month": {"required": True, "type": 'str'},
            "weekday": {"required": True, "type": 'str'},
            "job": {"required": True, "type": 'str'},
        },
    )

    def get_bin_path(arg1=None, arg2=None):
        return "/bin/true"


# Generated at 2022-06-20 21:31:01.501653
# Unit test for method do_remove_env of class CronTab

# Generated at 2022-06-20 21:31:12.075478
# Unit test for method read of class CronTab
def test_CronTab_read():
    module = AnsibleModule({})

    # Test for none user and valid cron_file
    ct = CronTab(module, None, "aaa")
    assert ct.read() is None
    # Raise an exception if tested with invalid filename
    try:
        ct.cron_file = "abc"
        ct.read()
    except CronTabError:
        assert True

    # Test for none user and None cron_file
    ct.cron_file = None
    crontab_file = tempfile.NamedTemporaryFile(mode='w', delete=True)

    ct.n_existing = crontab_file.read()
    ct.lines = ct.n_existing.splitlines()

    # Test for non-root user and valid cron_file

# Generated at 2022-06-20 21:31:19.073527
# Unit test for method read of class CronTab
def test_CronTab_read():
    class ModuleMock(object):
        def get_bin_path(self, arg, required=False):
            return "crontab"


# Generated at 2022-06-20 21:31:25.570818
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    ut_CronTab_find_env_cron_file = 'fake_cron_file'
    ut_CronTab_find_env_user = 'root'
    ut_CronTab_find_env_name = 'PATH'

    ct = CronTab(ut_CronTab_find_env_cron_file, ut_CronTab_find_env_user)

    assert ct.find_env(ut_CronTab_find_env_name) == [1, 'PATH=/sbin:/bin:/usr/sbin:/usr/bin']


# Generated at 2022-06-20 21:31:37.848533
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    def __init__(self, module, user=None, cron_file=None):
        pass
    from tempfile import mkstemp
    from os.path import isdir
    from os import close
    from os import remove
    from os import rmdir
    from os import unlink
    from os import devnull
    from shutil import rmtree
    from shutil import copytree
    from os import chmod
    from sys import version_info
    from os import system

    # Save the current state
    saved_path = CronTab.__init__.__defaults__

    def cleanup_CronTab_is_empty(path):
        # Restore the state
        CronTab.__init__.__defaults__ = saved_path

    # Set up test inputs
    path = mkstemp()
    # Perform the test
   

# Generated at 2022-06-20 21:31:48.932192
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    class module_mock(object):
        def fail_json(self, msg):
            raise Exception(msg)

        def run_command(self, cmd, use_unsafe_shell):
            return (0, "", "")

        def selinux_enabled(self):
            return False

        def set_default_selinux_context(self, path, is_file):
            return False

    cron_tab = CronTab(module_mock(), user=None, cron_file=None)


# Generated at 2022-06-20 21:31:51.750113
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    module = AnsibleModule(
        argument_spec = dict()
    )
    module.exit_json = exit_json
    crontab = CronTab(module)
    assert crontab.update_job("name", "job") == False

# Generated at 2022-06-20 21:31:53.202555
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    result = CronTab.do_add_env("", "")
    assert result == None

# Generated at 2022-06-20 21:32:54.003009
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    # set up a crontab object
    crontab = CronTab()

    # add a job
    jobname = 'testjob'
    minute = '*'
    hour = '*'
    day = '*'
    month = '*'
    weekday = '*'
    job = '/bin/echo test'
    job = crontab.get_cron_job(minute, hour, day, month, weekday, job, None, False)
    crontab.add_job(jobname, job)

    # read the crontab and compare
    crontab2 = CronTab()
    expected_crontab = crontab2.render() + '\n#Ansible: testjob\n' + job + '\n'
    actual_crontab = crontab.render()

    return actual_

# Generated at 2022-06-20 21:33:06.228273
# Unit test for method read of class CronTab
def test_CronTab_read():
    out = """
# DO NOT EDIT THIS FILE - edit the master and reinstall.
# (/tmp/crontab.YOoq3p/crontab installed on Fri Jul 17 16:49:36 2020)
# (Cron version -- $Id: crontab.c,v 2.13 1994/01/17 03:20:37 vixie Exp $)
4 3 * * * /usr/bin/test
5 3 * * * /usr/bin/test
"""
    f = open('./test/test_crontab_read.txt', 'wb')
    f.write(to_bytes(out))
    f.close()

    c = CronTab(user=None, cron_file='./test/test_crontab_read.txt')

# Generated at 2022-06-20 21:33:10.900223
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    line = "TestString"
    ct = CronTab("")
    ct.lines = [line]
    # First execute do_remove_job method with two params
    ct.do_remove_job(ct.lines, "TestString", "TestString")
    assert ct.lines == []



# Generated at 2022-06-20 21:33:12.458491
# Unit test for constructor of class CronTabError
def test_CronTabError():
    try:
        raise CronTabError("Error Message")
    except CronTabError as e:
        assert str(e) == "Error Message"


# Generated at 2022-06-20 21:33:26.107968
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    log.info('Testing CronTab.find_job')
    cls = CronTab(None, user=getpass.getuser())
    assert cls.find_job('name', 'job') == [], \
        'Find empty job'
    assert cls.find_job('name', 'job') == [], \
        'Find empty job'
    cls.module.run_command('echo "job" >> /tmp/test_crontab.txt')
    cls = CronTab(None, user=getpass.getuser())
    cls.read()
    assert cls.find_job('wrong name', 'job') == [], \
        'Find wrong job incorrect'
    assert cls.find_job('', 'job') == [], \
        'Find wrong job'

# Generated at 2022-06-20 21:33:27.591592
# Unit test for constructor of class CronTab
def test_CronTab():
    """
        simple unit test of class CronTab
    """
    c = CronTab(None, 'root', '/etc/cron.d/crontest')
    c.write()



# Generated at 2022-06-20 21:33:34.482435
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    ct = CronTab(module)

    lines = []
    comment = 'a test job'
    job = 'ls -l /'

    ct.do_add_job(lines, comment, job)

    assert lines == ['#Ansible: a test job', 'ls -l /']

# Generated at 2022-06-20 21:33:40.802730
# Unit test for method render of class CronTab
def test_CronTab_render():
    c = CronTab()
    c.lines.append('* * * * * echo')
    c.lines.append('#Ansible: foo')
    c.lines.append('@hourly echo')
    c.lines.append('#Ansible: bar')
    c.lines.append('@reboot echo')
    c.lines.append('#Ansible: null')
    c.lines.append('#Ansible: null')
    assert c.render() == '* * * * * echo\n#Ansible: foo\n@hourly echo\n#Ansible: bar\n@reboot echo\n#Ansible: null\n#Ansible: null\n'
    c.lines.append('')

# Generated at 2022-06-20 21:33:42.503812
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    """
    Test method add_env of class CronTab
    """
    assert False



# Generated at 2022-06-20 21:33:45.153089
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    test_object = CronTab(None)
    test_object.lines = ['test', 'test']
    ret = test_object.do_remove_env(None, None)
    assert ret == None


# Generated at 2022-06-20 21:35:34.738722
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import StringIO

    module = AnsibleModule(
        argument_spec = dict(
            name = dict(type='str', required=True),
            user = dict(type='str', required=True),
            special_time = dict(type='str', required=True),
            disabled = dict(type='bool', required=True),
        ),
        supports_check_mode=True,
    )
    user = module.params['user']

    ct = CronTab(module, user)

    ct.add_job('myjob', 'myjob')

    ct.update_job('myjob', 'myjob2')

    ct.write()

# Generated at 2022-06-20 21:35:47.112905
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    # Remove job
    #
    # If you call this with a comment and a job it should remove
    # the comment line and the job line together.
    myobj = CronTab('')
    comment = "Do something at 5PM"
    job1 = "0 17 * * * /bin/do_something"
    job2 = "*/10 * * * * /bin/do_something_else"
    myobj.lines = [comment, job1, job2]
    myobj.do_remove_job(myobj.lines, comment, job1)
    assert myobj.lines == [job2]

    # If you call this with a comment and no job, it should still remove
    # the comment line
    myobj = CronTab('')
    comment = "Do something at 5PM"

# Generated at 2022-06-20 21:35:51.235925
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    module = AnsibleModule(argument_spec=dict())
    crontab = CronTab(module)
    assert crontab.get_cron_job('*/5', '2-5', '2-15', '12', '1', 'echo hello', 'reboot', True) == '#@reboot echo hello'


# Generated at 2022-06-20 21:36:06.119595
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
  # Remove everything in list and make sure the list is empty
  lines = ['one', 'two', 'three']
  new_lines = []
  for l in lines:
    comment = 'foo'
    job = 'bar'
    foo = ct.do_remove_job(new_lines, comment, job)
  assert new_lines == []

  # Remove everything in list and make sure nothing is removed
  lines = ['one', 'two', 'three']
  new_lines = ['one', 'two', 'three']
  for l in lines:
    comment = 'foo'
    job = 'bar'
    foo = ct.do_remove_job(new_lines, comment, job)
  assert new_lines == ['one', 'two', 'three']


# Generated at 2022-06-20 21:36:11.815170
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    cron_tab = CronTab('')

    cron_tab.lines = ['hello world']

    do_remove_env_result = cron_tab.do_remove_env(cron_tab.lines, None)
    #assert do_remove_env_result == None
    assert do_remove_env_result is None


# Generated at 2022-06-20 21:36:23.566695
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    '''
    Unit test for method update_job of class CronTab
    '''
    c = CronTab(None, None, None)

    if c is None:
        raise Exception("Failed to instantiate CronTab object")

    result = c.update_job("test", "0 * * * * /bin/frobozz\n")

    if not result:
        raise Exception("update_job failed")

if __name__ == '__main__':
  # Unit test for method update_job of class CronTab
    test_CronTab_update_job()

# Generated at 2022-06-20 21:36:35.108581
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    filename = "/etc/cron.d/cron1"
    cron_file = CronTab(module, user=None, cron_file=filename)
    cron_file.remove_job_file()
    if os.path.exists(filename):
        raise AssertionError("Cron file %s was not removed." % filename)

if __name__ == '__cron':
    # Load Ansible module.
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 21:36:38.610847
# Unit test for method render of class CronTab
def test_CronTab_render():
    import doctest
    # TODO: write a test class.
    doctest.testmod(m=CronTab)



# Generated at 2022-06-20 21:36:49.681701
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            user=dict(required=False, type='str'),
            cron_file=dict(required=False, type='str'),
        ),
        supports_check_mode=True,
    )

    p = module.params

    cron = CronTab(module, p['user'], p['cron_file'])
    result = cron.remove_job(p['name'])

    if result:
        module.exit_json(changed=True, result=crons.render())
    else:
        module.exit_json(changed=False, result=cron.render())


# Generated at 2022-06-20 21:36:57.820675
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True),
        ),
    )
    module.exit_json = exit_json
    cron = CronTab(module, user='ansible')
    returned = cron.find_env(module.params['name'])
    module.exit_json(changed=False, meta=returned)
