

# Generated at 2022-06-20 21:30:46.968698
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    # Build mock environment
    module_args = dict(
        minute='10',
        hour='12',
        day='*',
        month='*',
        weekday='*',
        name='test',
        job='test with spaces',
        special_time='@yearly',
        disabled=False,
        user='root',
        state='present',
    )

    env1 = {'HOME': '/root', 'PATH': "/usr/bin:/bin:/usr/sbin:/sbin"}
    m1 = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    crontab = CronTab(m1, user='root')
    crontab.add_job(name='test', job='test with spaces')


# Generated at 2022-06-20 21:30:55.381928
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    module = AnsibleModule(argument_spec={})
    set_module_args(dict(
        name='MyJob',
        job='#Ansible: MyJob\n* * * * * true',
    ))

    cron = CronTab(module)
    cron.lines = [
        '#Ansible: MyJob',
        '* * * * * true',
        '#Ansible: OtherJob',
        '0 0 * * * false',
    ]
    found = cron.find_job('MyJob', '* * * * * true')
    assert found == ['MyJob', '* * * * * true']


# Generated at 2022-06-20 21:31:02.041949
# Unit test for method render of class CronTab
def test_CronTab_render():
    cron = CronTab(None)
    cron.lines = [ "# Ansible: foo", "* * * * * /usr/bin/bar" ]
    assert cron.render() == "# Ansible: foo\n* * * * * /usr/bin/bar\n"


# Generated at 2022-06-20 21:31:03.599474
# Unit test for constructor of class CronTabError
def test_CronTabError():
    e = CronTabError("test exception")
    assert e.args[0] == "test exception"



# Generated at 2022-06-20 21:31:10.066493
# Unit test for constructor of class CronTab
def test_CronTab():
    import tempfile
    from subprocess import Popen, PIPE

    def get_uid(username):
        p = Popen(["id", "-u", "%s" % username], stdout=PIPE)
        out, err = p.communicate()
        return int(out)

    def get_gid(username):
        p = Popen(["id", "-g", "%s" % username], stdout=PIPE)
        out, err = p.communicate()
        return int(out)

    rhnuser = pwd.getpwuid(int(os.getuid()))[0]
    newuser = "ansibltestuser"
    newuser_uid = None
    newuser_home = None
    p = None

# Generated at 2022-06-20 21:31:14.836652
# Unit test for function main
def test_main():
    old_path = os.path
    os.path = MagicMock()
    os.path.isfile.return_value = True
    os.path.join.return_value = True

    #cron.run_command = function_mock
    cron.run_command = MagicMock(return_value = [('stdout', 'stdin', 'stderr')])
    cron.AnsibleModule = MagicMock()
    cron.AnsibleModule.check_mode=False
    cron.AnsibleModule.params = {'name': 'Test1', 'job': 'Test1'}
    cron.AnsibleModule.run_command = function_mock
    cron.AnsibleModule.run_command.return_value = [('stdout', 'stdin', 'stderr')]

# Generated at 2022-06-20 21:31:26.037831
# Unit test for function main

# Generated at 2022-06-20 21:31:38.041207
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    class ModuleStub():
        def __init__(self):
            self.fail_json = lambda msg, **kwargs: msg
            self.fail_json.__name__ = 'fail_json'

    class CronTabStub(CronTab):
        def __init__(self, module, user=None, cron_file=None):
            self.module = module # the module parameter is expected by the parent class
            self.user = user
            self.root = (os.getuid() == 0)
            self.lines = []
            self.ansible = "#Ansible: "
            self.n_existing = ''
            self.cron_cmd = '/bin/true' # we just need to tell the parent class that the cron_cmd is available


# Generated at 2022-06-20 21:31:44.658730
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    cls = CronTab(None)
    cls.lines = [
        '#Ansible: name',
        '@reboot root /path/to/script arg'
    ]
    add_decl = 'SHELL=/bin/sh'
    cls.do_add_env(cls.lines, add_decl)
    assert cls.lines == [
        '#Ansible: name',
        'SHELL=/bin/sh',
        '@reboot root /path/to/script arg'
    ]

# Generated at 2022-06-20 21:31:49.052053
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    C = CronTab()
    C.add_job("test_name", "test_job")
    return C.lines == ['#Ansible: test_name', 'test_job']


# Generated at 2022-06-20 21:32:41.144043
# Unit test for constructor of class CronTab
def test_CronTab():
    cron_tab = CronTab(None, 'root', '/etc/cron.d/testing')
    assert None != cron_tab.cron_file
    assert 'root' == cron_tab.user
    assert '#Ansible' == cron_tab.ansible

# Unit tests for find_job() method

# Generated at 2022-06-20 21:32:48.142549
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    module = FakeModule()
    cron_file = None
    crontab = CronTab(module, cron_file=cron_file)

    # Test 1: No match should occur
    name = 'test_job'
    job = '* * * * * /usr/bin/foo'
    assert(crontab.find_job(name, job) == [])

    # Test 2: Match with no comment should occur
    crontab.lines.append(job)
    assert(crontab.find_job(name, job) == [None, job])

    # Test 3: Match with comment should occur
    crontab.lines.append(crontab.do_comment(name))
    assert(crontab.find_job(name, job) == [crontab.do_comment(name), job])

   

# Generated at 2022-06-20 21:32:52.415223
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    c = CronTab(None)
    c.lines = []
    if (c.is_empty() == True):
        print ('is_empty() => Success')
    else:
        print ('is_empty() => Fail')


# Generated at 2022-06-20 21:32:56.236330
# Unit test for method write of class CronTab
def test_CronTab_write():
    crontab = CronTab(None)
    crontab.lines = [
        '*/10 * * * *     root  /usr/sbin/anacron -s',
        '#Ansible: test',
        '* * * * * foo'
    ]
    crontab.write()



# Generated at 2022-06-20 21:33:01.914935
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    print('Testing do_remove_env')
    lines = []
    decl = 'Test'
    ct = CronTab(None)
    ct.do_remove_env(lines, decl)
    assert lines == []
    print('do_remove_env() passed all tests')


# Generated at 2022-06-20 21:33:11.615332
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    module = AnsibleModule(
        argument_spec = dict()
    )
    crontab = CronTab(module)
    #case 1
    crontab.lines = ['']
    decl = ''
    result =  crontab.do_remove_env(crontab.lines, decl)
    assert result == None

    #case 2
    crontab.lines = ['AAA=123']
    decl = 'AAA=123'
    result =  crontab.do_remove_env(crontab.lines, decl)
    assert result == None

    #case 3
    crontab.lines = ['AAA=123', 'BBB=456', 'CCC=789']
    decl = 'BBB=789'
    result =  crontab.do_remove_env(crontab.lines, decl)
   

# Generated at 2022-06-20 21:33:24.702930
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    from ansible import utils
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.collections import ImmutableDict
    import ansible.module_utils.basic
    import ansible.module_utils.facts
    import ansible.module_utils.parsing
    import ansible.module_utils.urls
    import ansible.plugins.connection.local

    inventory = InventoryManager(utils.loader, sources='./test/units/library/cron/ansible_hosts')
    variable_manager = VariableManager(loader=utils.loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-20 21:33:31.627580
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    module = AnsibleModule(
        argument_spec = dict()
    )

    ct = CronTab(module)

    if ct.remove_job('job_name'):
        module.exit_json(changed = True)
    else:
        module.exit_json(changed = False)



# Generated at 2022-06-20 21:33:36.399888
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    tab = CronTab('test_module')
    tab.root = True
    tab.lines = ['test 1', 'test 2', 'test 3']

    def do_add_job_test(name, job):
        tab.do_add_job(tab.lines, tab.do_comment(name), job)

    do_add_job_test('test job 1', 'test job 1 line')

    assert(tab.lines == ['test 1', 'test 2', 'test 3', '#Ansible: test job 1', 'test job 1 line'])

    do_add_job_test('test job 2', 'test job 2 line')


# Generated at 2022-06-20 21:33:39.975660
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    module = AnsibleModule(argument_spec=dict())
    crontab = CronTab(module)
    name = 'name'
    job = 'job'
    lines = ['line1', 'line2', 'line3']
    comment = 'comment'

    crontab.do_add_job(lines, comment, job)

    assert lines == ['line1', 'line2', 'line3', 'comment', 'job']


# Generated at 2022-06-20 21:35:27.868712
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():  
    cron = CronTab(module, user=None, cron_file='/etc/cron.d/ansible-cron-test')
    assert cron.do_comment(name = None) == '#Ansible: '
    assert cron.do_comment(name = 'test') == '#Ansible: test'

# Generated at 2022-06-20 21:35:31.370553
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    cron = CronTab()
    result = cron.get_envnames()
    assert(result == None)



# Generated at 2022-06-20 21:35:34.208815
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    assert CronTab.do_remove_job(self, lines, comment, job) == None


# Generated at 2022-06-20 21:35:38.251931
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    cron = CronTab("name")
    cron.lines = ["test"]
    assert cron.is_empty() == False

# Generated at 2022-06-20 21:35:47.559298
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    ct = CronTab()
    ct.read()
    env_list = ['VAR1', 'VAR2', 'VAR3']
    ct.lines = []
    ct.lines = ['#Ansible: monthly']
    ct.lines.append('@monthly VAR1=foo VAR2=bar VAR3=baz /bin/false')
    ct.lines.append('')
    for environment in env_list:
        ct.remove_env(environment)
    assert ct.lines == ['#Ansible: monthly', '@monthly /bin/false', '']


# Generated at 2022-06-20 21:35:50.108600
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    name = "name"
    job = "job"
    c = CronTab(AnsibleModule(argument_spec={}), 'user')
    c.remove_job(name)

# Generated at 2022-06-20 21:35:59.971412
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    ctab = CronTab()
    ctab.lines = [
            "#Ansible: job_name_1",
            "0 1 2 3 4",
            "#Ansible: job_name_2",
            "0 1 2 3 4",
            "#Ansible: job_name_3",
            "0 1 2 3 4",
            "#NotAnsible"]
    assert ctab.get_jobnames() == ["job_name_1", "job_name_2", "job_name_3"]



# Generated at 2022-06-20 21:36:04.318991
# Unit test for method render of class CronTab
def test_CronTab_render():
    cron = CronTab(None, user='username', cron_file='test.tab')
    cron.lines = ['line1', 'line2 # trailing comment']

    assert cron.render() == 'line1\nline2 # trailing comment'


# Generated at 2022-06-20 21:36:08.047156
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    # Remove cron file for user if it exists
    cron = CronTab(user='nobody', cron_file='ansible_tmp')
    assert cron.remove_job_file() == False

# Generated at 2022-06-20 21:36:24.170787
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    print("Test add_env - ")

    # Testing for add_env without insertafter/insertbefore
    cron = CronTab(None)
    cron.lines = ['env1=value1', 'env2=value2', 'env3=value3']
    cron.add_env('newenv=newvalue')
    if cron.lines == ['newenv=newvalue', 'env1=value1', 'env2=value2', 'env3=value3']:
        print("Test1 - Passed")
    else:
        print("Test1 - Failed")

    # Testing for add_env with insertafter
    cron = CronTab(None)
    cron.lines = ['env1=value1', 'env2=value2', 'env3=value3']