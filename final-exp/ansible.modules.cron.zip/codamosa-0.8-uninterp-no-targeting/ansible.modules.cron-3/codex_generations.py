

# Generated at 2022-06-20 21:30:44.053458
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    module = AnsibleModule(
        argument_spec = dict(
            name=dict(required=True, type='str'),
        ),
        supports_check_mode=True
    )
    set_module_args(dict(name = "TEST_VAR"))

    cron = CronTab(module=module)
    output = cron.remove_env("TEST_VAR")

    assert output == "None", "remove_env returned an incorrect value: %s" % output


# Generated at 2022-06-20 21:30:49.221504
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    module = AnsibleModule(argument_spec={})
    lines_list = []
    comment_str = 'the comment'
    job_str = 'the job'
    crontab = CronTab(module)
    assert crontab.lines == []

    ret = crontab.do_add_job(lines_list, comment_str, job_str)
    assert lines_list == ['the comment', 'the job']
    assert ret == None



# Generated at 2022-06-20 21:30:51.551780
# Unit test for constructor of class CronTabError
def test_CronTabError():
    CronTabError('foo')


cron_file_exts = ('cron', 'tab')



# Generated at 2022-06-20 21:30:52.890811
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    assert True


# Generated at 2022-06-20 21:31:08.836850
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    file_name = '/tmp/ansible_cron_module_test_data_file'

# Generated at 2022-06-20 21:31:14.696955
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():

    from ansible.module_utils.six import PY3

    # test cases for ansible header comment match
    crontab_1 = "* * * * * echo hello\n#Ansible: foo\n* * * * * echo goodbye"
    crontab_2 = "#Ansible: foo\n* * * * * echo hello"
    crontab_3 = "#Ansible: foo\n* * * * * echo goodbye"
    crontab_4 = "#Ansible: foo\n* * * * * echo goodbye\n#Ansible: bar\n* * * * * echo goodbye"
    crontab_5 = "#Ansible: bar\n* * * * * echo goodbye\n#Ansible: foo\n* * * * * echo hello"

# Generated at 2022-06-20 21:31:25.861260
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys

    class AttrDict(dict):
        def __init__(self, *args, **kwargs):
            super(AttrDict, self).__init__(*args, **kwargs)
            self.__dict__ = self


# Generated at 2022-06-20 21:31:36.032017
# Unit test for constructor of class CronTab
def test_CronTab():
    ctab = CronTab(None, 'root')
    assert ctab.user == 'root', "Root's crontab can't be read."
    assert ctab.lines is not None, "Lines in the crontab are None."

    ctab = CronTab(None, 'root', 'testfile')

    assert ctab.cron_file == '/etc/cron.d/testfile', "Absolute path is not properly set."
    assert ctab.lines is None, "Root's crontab can't be read."

    try:
        ctab = CronTab(None, 'thisuserdoesnotexist')
        assert False, "Non existing user's crontab can be read."
    except CronTabError:
        assert True

# Generated at 2022-06-20 21:31:50.035075
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    crontab = CronTab(None)

    # Test case with cron_file
    crontab.cron_file = "/some/cron/file"
    crontab.user = "someuser"
    result = crontab.get_cron_job("*", "*", "*", "*", "*", "/some/command -a foo -b bar", None, False)
    expected = "* * * * * someuser /some/command -a foo -b bar"
    assert result == expected

    # Test case without cron_file
    crontab.cron_file = None
    crontab.user = None
    result = crontab.get_cron_job("*", "*", "*", "*", "*", "/some/command -a foo -b bar", None, False)

# Generated at 2022-06-20 21:31:55.303332
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    """TODO: Implement"""
    ct = CronTab(None, user=None, cron_file=None)
    assert ct.add_job("name", "job") == None



# Generated at 2022-06-20 21:32:55.157565
# Unit test for method read of class CronTab
def test_CronTab_read():

    class module(object):

        def run_command(self, cmd, use_unsafe_shell=False):
            # if use_unsafe_shell == True then cmd is not split
            if use_unsafe_shell:
                return [0, 'Example crontab line one\nExample crontab line two', '']
            else:
                return [0, 'Example crontab line one\nExample crontab line two', '']

        def get_bin_path(self, arg, required=False):
            return 'crontab'

    class TestCronTab(CronTab):

        def _read_user_execute(self):
            return 'crontab -l'

        def _write_execute(self, path):
            return 'crontab %s' % (path)

    testCron = TestCron

# Generated at 2022-06-20 21:33:06.951816
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    # running find_job on a CronTab with name==None and an exact match
    c = CronTab(None, None, None)
    c.lines = ['foobar', '@daily foo']
    c.find_job(None, '@daily foo') == ['', '@daily foo']
    # running find_job on a CronTab with name!=None and an exact match
    c = CronTab(None, None, None)
    c.lines = ['foobar', '@daily foo']
    c.find_job('test', '@daily foo') == ['test', '@daily foo']
    # running find_job on a CronTab with name!=None and an exact match WITH NO ANSIBLE HEADER
    c = CronTab(None, None, None)
    c.lines = ['foobar', '@daily foo']
    c

# Generated at 2022-06-20 21:33:16.503015
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    class Test_CronTab(CronTab):
        def __init__(self):
            pass

    crontab = Test_CronTab()
    crontab.lines = ["this is one line", "#Ansible: name", "0 0 * * * /bin/true", "#"]
    crontab.ansible = "#Ansible: "
    crontab.update_job("name", "0 0 * * * /bin/false")
    assert crontab.lines == ["this is one line", "#Ansible: name", "0 0 * * * /bin/false", "#"]


# Generated at 2022-06-20 21:33:29.107287
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    ct = CronTab(module)
    ct.lines = [
        "#Ansible: myjob",
        "*/5 * * * * echo hi",
        "MYVAR=hi",
        "OTHERVAR=there",
        "#Ansible: myjob2",
        "*/5 * * * * echo hi2"
    ]
    ct.update_env("MYVAR", "MYVAR=foo")

    assert(ct.lines == [
        "#Ansible: myjob",
        "*/5 * * * * echo hi",
        "MYVAR=foo",
        "OTHERVAR=there",
        "#Ansible: myjob2",
        "*/5 * * * * echo hi2"
    ])


# Generated at 2022-06-20 21:33:31.001755
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    assert True



# Generated at 2022-06-20 21:33:39.258912
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleExitJson, AnsibleFailJson
    from ansible.module_utils.six.moves.StringIO import StringIO

    # cron_file=fake_name, user=bogus, state=present, job='ls -alh > /dev/null'
    # cron_file=fake_name, user=bogus, state=present, job='ls -alh > /dev/null'
    raw_params1 = dict(
        name='check dirs',
        cron_file='fake_name',
        user='bogus',
        state='present',
        job='ls -alh > /dev/null',
    )

# Generated at 2022-06-20 21:33:48.590365
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    crontab = CronTab(user="root")
    crontab.lines = [
        "#Ansible: foo",
        "* * * * * /bar",
        "PATH=/usr/bin",
        "MAILTO=root",
        "#Ansible: baz",
        "* * * * * /baz",
        "FOO=bar",
        "#Ansible: qux",
        "* * * * * /qux"
    ]
    envnames = crontab.get_envnames()
    assert envnames == ["PATH", "MAILTO", "FOO"]


# Generated at 2022-06-20 21:33:51.692965
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    test_CronTab = CronTab(None)
    name = "test_name"
    result = test_CronTab.do_comment(name)
    assert result == "#Ansible: test_name"


# Generated at 2022-06-20 21:34:04.158960
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():

    # check all the wrong types
    module = None
    cron_tab = CronTab(module, user=None, cron_file=None)
    try:
        cron_tab.get_cron_job("minute", 'hour', 'day', 'month', 'weekday', 'job', 'special', 'disabled')
    except Exception:
        pass

    # check the wrong values
    module = None
    cron_tab = CronTab(module, user=None, cron_file=None)
    try:
        cron_tab.get_cron_job("", '', '', '', '', '', '', '')
        cron_tab.get_cron_job("", '', '', '', '', '', 'special', '')
    except Exception:
        pass

    # check the right values


# Generated at 2022-06-20 21:34:09.295886
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception

    x = CronTab(AnsibleModule({}))
    assert x.do_remove_job(None, None, None) == None



# Generated at 2022-06-20 21:36:04.189483
# Unit test for constructor of class CronTabError
def test_CronTabError():
    e = CronTabError('test')
    assert e.__str__() == 'test'



# Generated at 2022-06-20 21:36:14.725389
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    ct = CronTab(module=None, user='root', cron_file='/tmp/test1')
    assert ct.update_job('test1', '* * * * * root    /usr/bin/true') is False
    assert ct.lines == ['#Ansible: test1', '* * * * * root    /usr/bin/true']
    ct.lines = ['* * * * * root    /usr/bin/true']
    assert ct.update_job('test1', '* * * * * root    /usr/bin/false') is True
    assert ct.lines == ['#Ansible: test1', '* * * * * root    /usr/bin/false']



# Generated at 2022-06-20 21:36:23.635365
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    # Create instance of class (using invoke_module, so we have full module available)
    args = dict(
        state='present',
        name='set_timezone',
        special='reboot',
    )
    module = AnsibleModule(**args)

    # create instance of CronTab
    cron = CronTab(module, user='root')

    # run test
    name = 'set_timezone'
    result = cron.do_comment(name)
    assert result == '#Ansible: set_timezone'
    # Unit test for method is_empty of class CronTab

# Generated at 2022-06-20 21:36:30.302292
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    obj1 = CronTab(module=None, user='user1', cron_file='cron_file1')
    obj1.ansible = None
    obj1.do_comment('name1')
    assert obj1.ansible == '#Ansible: '



# Generated at 2022-06-20 21:36:34.864794
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    cron = CronTab(None, user='root', cron_file='/root/cronfile')
    assert cron.get_jobnames() == ['job1', 'job2', 'job3']


# Generated at 2022-06-20 21:36:40.776423
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    module = AnsibleModule({})
    crontab = CronTab(module, cron_file='test.txt')
    crontab.lines = ['PATH=/bin:/usr/bin']
    assert crontab.get_envnames() == ['PATH']

# Generated at 2022-06-20 21:36:48.838853
# Unit test for function main
def test_main():
    import sys
    import tempfile
    import subprocess
    # Run the test
    test_result = True

# Generated at 2022-06-20 21:36:54.802502
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    # Setup test arguments
    c = CronTab()
    c.lines = [
        '#Ansible: firstjob',
        '0 0 * * * user1 /path/to/command1',
        '#Ansible: secondjob',
        '0 0 * * * user2 /path/to/command2',
        '0 0 * * * user3 /path/to/command3',
        '#Ansible: thirdjob',
        '0 0 * * * user4 /path/to/command4',
        '0 0 * * * user5 /path/to/command5',
    ]

    assert c.get_jobnames() == ['firstjob', 'secondjob', 'thirdjob']


# Generated at 2022-06-20 21:36:59.903429
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    ct = CronTab(module=None, user=None, cron_file=None)
    name = "your-name"
    job = "your-job"
    ct.remove_job(name=name, job=job)


# Generated at 2022-06-20 21:37:06.902238
# Unit test for function main
def test_main():
    args = {
        'name': 'job_name',
        'job': 'job_command',
        'cron_file': 'cron_file',
        'user': 'user',
        'state': 'present',
        'backup': False,
        'minute': '*',
        'hour': '*',
        'day': '*',
        'month': '*',
        'weekday': '*',
        'special_time': 'reboot',
        'disabled': False,
        'env': False,
        'insertafter': 'insertafter',
        'insertbefore': 'insertbefore',
    }
    rc = main()
    assert rc is None


if __name__ == '__main__':
    main()