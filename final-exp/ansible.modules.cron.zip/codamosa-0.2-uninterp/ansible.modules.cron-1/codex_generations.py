

# Generated at 2022-06-17 04:13:51.476065
# Unit test for method write of class CronTab
def test_CronTab_write():
    # Create a dummy module
    module = AnsibleModule(
        argument_spec = dict()
    )

    # Create a dummy CronTab object
    crontab = CronTab(module)

    # Create a dummy cron file
    cron_file = tempfile.mkstemp(prefix='crontab')[1]

    # Write the crontab to the dummy cron file
    crontab.write(cron_file)

    # Read the dummy cron file
    f = open(cron_file, 'rb')
    cron_file_content = to_native(f.read(), errors='surrogate_or_strict')
    f.close()

    # Remove the dummy cron file
    os.unlink(cron_file)

    # Assert that the dummy cron file is empty
    assert cr

# Generated at 2022-06-17 04:14:00.883570
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    crontab = CronTab(None, user=None, cron_file=None)
    crontab.lines = ['#Ansible: test_name', '#Ansible: test_name2', '#Ansible: test_name3', '#Ansible: test_name4']
    crontab.n_existing = '\n'.join(crontab.lines)
    crontab.update_job('test_name', 'test_job')
    assert crontab.lines == ['#Ansible: test_name', 'test_job', '#Ansible: test_name2', '#Ansible: test_name3', '#Ansible: test_name4']
    crontab.update_job('test_name2', 'test_job2')
    assert crontab.lines

# Generated at 2022-06-17 04:14:08.051761
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    # Test with no insertafter or insertbefore
    ct = CronTab(None, None, None)
    ct.lines = []
    ct.do_add_env(ct.lines, 'FOO=bar')
    assert ct.lines == ['FOO=bar']

    # Test with insertafter
    ct = CronTab(None, None, None)
    ct.lines = ['FOO=bar']
    ct.do_add_env(ct.lines, 'BAZ=qux', insertafter='FOO')
    assert ct.lines == ['FOO=bar', 'BAZ=qux']

    # Test with insertbefore
    ct = CronTab(None, None, None)
    ct.lines = ['FOO=bar']

# Generated at 2022-06-17 04:14:10.974293
# Unit test for method write of class CronTab
def test_CronTab_write():
    module = AnsibleModule(
        argument_spec = dict(
            user = dict(required=False, default=None),
            cron_file = dict(required=False, default=None),
        ),
        supports_check_mode=True
    )
    cron = CronTab(module)
    cron.write()


# Generated at 2022-06-17 04:14:17.115849
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    module = AnsibleModule(argument_spec={})
    cron = CronTab(module)
    cron.lines = []
    assert cron.is_empty() == True
    cron.lines = [""]
    assert cron.is_empty() == True
    cron.lines = ["#Ansible: test"]
    assert cron.is_empty() == False
    cron.lines = ["#Ansible: test", ""]
    assert cron.is_empty() == False
    cron.lines = ["#Ansible: test", "", ""]
    assert cron.is_empty() == False
    cron.lines = ["", "#Ansible: test"]
    assert cron.is_empty() == False
    cron.lines = ["", "#Ansible: test", ""]

# Generated at 2022-06-17 04:14:20.374698
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    c = CronTab(None, None, None)
    c.lines = ['#Ansible: test1', '* * * * * /bin/true', '#Ansible: test2', '* * * * * /bin/true']
    assert c.get_jobnames() == ['test1', 'test2']


# Generated at 2022-06-17 04:14:27.279927
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    cron = CronTab(None, None, None)
    cron.lines = ['#Ansible: test', '* * * * * test']
    cron.remove_job('test')
    assert cron.lines == []


# Generated at 2022-06-17 04:14:38.093974
# Unit test for method render of class CronTab
def test_CronTab_render():
    ct = CronTab()
    ct.lines = ['#Ansible: test', '* * * * * /bin/true']
    assert ct.render() == '#Ansible: test\n* * * * * /bin/true\n'


# Generated at 2022-06-17 04:14:47.199480
# Unit test for constructor of class CronTab
def test_CronTab():
    module = AnsibleModule(argument_spec={})
    cron = CronTab(module)
    assert cron.cron_cmd == module.get_bin_path('crontab', required=True)
    assert cron.root == (os.getuid() == 0)
    assert cron.user is None
    assert cron.cron_file is None
    assert cron.lines is None
    assert cron.ansible == "#Ansible: "
    assert cron.n_existing == ''
    assert cron.b_cron_file is None

    cron = CronTab(module, user='test_user', cron_file='test_cron_file')
    assert cron.cron_cmd == module.get_bin_path('crontab', required=True)

# Generated at 2022-06-17 04:14:51.414579
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True),
            job=dict(required=True),
            state=dict(default='present', choices=['present', 'absent']),
            minute=dict(default='*'),
            hour=dict(default='*'),
            day=dict(default='*'),
            month=dict(default='*'),
            weekday=dict(default='*'),
            special_time=dict(default=''),
            disabled=dict(default=False, type='bool'),
            user=dict(default=None),
            cron_file=dict(default=None),
            backup=dict(default=False, type='bool'),
        ),
        supports_check_mode=True
    )

    name = module.params['name']

# Generated at 2022-06-17 04:16:37.119763
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    module = AnsibleModule(argument_spec={})
    cron = CronTab(module)
    assert cron.is_empty() == True


# Generated at 2022-06-17 04:16:48.511538
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    # Test with a job that has a name
    ct = CronTab(None, None, None)
    ct.lines = [
        '#Ansible: test_job',
        '* * * * * /bin/true'
    ]
    assert ct.find_job('test_job') == ['#Ansible: test_job', '* * * * * /bin/true']

    # Test with a job that has no name
    ct = CronTab(None, None, None)
    ct.lines = [
        '* * * * * /bin/true'
    ]
    assert ct.find_job('test_job') == []

    # Test with a job that has a name but no comment
    ct = CronTab(None, None, None)

# Generated at 2022-06-17 04:16:56.961352
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    ct = CronTab(None, None, None)
    ct.lines = ['foo=bar', 'baz=qux']
    assert ct.find_env('foo') == [0, 'foo=bar']
    assert ct.find_env('baz') == [1, 'baz=qux']
    assert ct.find_env('qux') == []


# Generated at 2022-06-17 04:17:04.264741
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    ct = CronTab(None)
    ct.lines = ['PATH=/usr/bin:/bin', 'MAILTO=root', 'HOME=/var/spool/cron']
    assert ct.find_env('PATH') == [0, 'PATH=/usr/bin:/bin']
    assert ct.find_env('MAILTO') == [1, 'MAILTO=root']
    assert ct.find_env('HOME') == [2, 'HOME=/var/spool/cron']
    assert ct.find_env('FOO') == []


# Generated at 2022-06-17 04:17:10.300845
# Unit test for method read of class CronTab
def test_CronTab_read():
    module = AnsibleModule(
        argument_spec = dict()
    )
    ct = CronTab(module)
    ct.read()
    assert ct.lines == []


# Generated at 2022-06-17 04:17:15.803250
# Unit test for method render of class CronTab
def test_CronTab_render():
    c = CronTab(None, None, None)
    c.lines = ['#Ansible: foo', '* * * * * foo']
    assert c.render() == '#Ansible: foo\n* * * * * foo\n'


# Generated at 2022-06-17 04:17:19.074291
# Unit test for method render of class CronTab
def test_CronTab_render():
    c = CronTab(None, user='root')
    c.lines = ['#Ansible: foo', '* * * * * /bin/true']
    assert c.render() == '#Ansible: foo\n* * * * * /bin/true\n'


# Generated at 2022-06-17 04:17:28.509277
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    # Test with a job that has a name
    ct = CronTab(None)
    ct.lines = ['#Ansible: test_job', '* * * * * /bin/true']
    assert ct.find_job('test_job') == ['#Ansible: test_job', '* * * * * /bin/true']

    # Test with a job that has no name
    ct = CronTab(None)
    ct.lines = ['* * * * * /bin/true']
    assert ct.find_job('test_job') == []

    # Test with a job that has a name but no comment
    ct = CronTab(None)
    ct.lines = ['* * * * * /bin/true']

# Generated at 2022-06-17 04:17:32.558037
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    crontab = CronTab(module, user=None, cron_file=None)
    assert crontab.remove_job_file() == False


# Generated at 2022-06-17 04:17:38.517795
# Unit test for method render of class CronTab
def test_CronTab_render():
    cron = CronTab(None, None, None)
    cron.lines = ['#Ansible: test', '0 0 * * * /bin/true']
    assert cron.render() == '#Ansible: test\n0 0 * * * /bin/true\n'



# Generated at 2022-06-17 04:19:41.718175
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    ct = CronTab(None, user='root')
    ct.lines = ['#Ansible: foo', '* * * * * /bin/true', '#Ansible: bar', '* * * * * /bin/false']
    assert ct.get_jobnames() == ['foo', 'bar']


# Generated at 2022-06-17 04:19:48.887131
# Unit test for method write of class CronTab
def test_CronTab_write():
    module = AnsibleModule(
        argument_spec = dict(
            user = dict(required=False, type='str'),
            cron_file = dict(required=False, type='str'),
        ),
        supports_check_mode=True
    )
    ct = CronTab(module)
    ct.write()


# Generated at 2022-06-17 04:19:59.791518
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    ct = CronTab(None, None, None)

# Generated at 2022-06-17 04:20:09.690097
# Unit test for constructor of class CronTab
def test_CronTab():
    module = AnsibleModule(argument_spec={})
    cron = CronTab(module)
    assert cron.cron_cmd == '/usr/bin/crontab'
    assert cron.user is None
    assert cron.root is True
    assert cron.lines == []
    assert cron.ansible == '#Ansible: '
    assert cron.n_existing == ''
    assert cron.cron_file is None

    cron = CronTab(module, user='root', cron_file='/etc/cron.d/test')
    assert cron.cron_cmd == '/usr/bin/crontab'
    assert cron.user == 'root'
    assert cron.root is True
    assert cron.lines == []

# Generated at 2022-06-17 04:20:13.106723
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    module = AnsibleModule(argument_spec={})
    lines = ['#Ansible: test_job', '* * * * * /bin/true']
    comment = '#Ansible: test_job'
    job = '* * * * * /bin/true'
    crontab = CronTab(module)
    assert crontab.do_remove_job(lines, comment, job) is None


# Generated at 2022-06-17 04:20:17.789280
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    module = AnsibleModule(
        argument_spec = dict()
    )
    cron = CronTab(module)
    assert cron.remove_job_file() == False


# Generated at 2022-06-17 04:20:29.289872
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    # Test with no arguments
    try:
        crontab = CronTab(None, None, None)
        crontab.do_remove_job()
    except TypeError as e:
        assert e.args[0] == "do_remove_job() takes exactly 3 arguments (1 given)"
    # Test with one argument
    try:
        crontab = CronTab(None, None, None)
        crontab.do_remove_job(None)
    except TypeError as e:
        assert e.args[0] == "do_remove_job() takes exactly 3 arguments (2 given)"
    # Test with two arguments
    try:
        crontab = CronTab(None, None, None)
        crontab.do_remove_job(None, None)
    except TypeError as e:
        assert e.args

# Generated at 2022-06-17 04:20:38.022029
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    ct = CronTab(None, None)
    ct.lines = ['a=b', 'c=d', 'e=f']
    assert ct.find_env('a') == [0, 'a=b']
    assert ct.find_env('c') == [1, 'c=d']
    assert ct.find_env('e') == [2, 'e=f']
    assert ct.find_env('x') == []


# Generated at 2022-06-17 04:20:41.840038
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    # Test with no arguments
    assert CronTab.do_remove_job(None, None, None) is None


# Generated at 2022-06-17 04:20:47.306556
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True),
        ),
        supports_check_mode=True
    )

    crontab = CronTab(module)

    name = module.params['name']

    crontab.remove_env(name)

    module.exit_json(changed=True, crontab=crontab.render())
