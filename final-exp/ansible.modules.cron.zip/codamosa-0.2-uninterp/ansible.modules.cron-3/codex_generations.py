

# Generated at 2022-06-17 04:13:40.185754
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    crontab = CronTab(None)
    lines = []
    comment = '#Ansible: test'
    job = '* * * * * /bin/true'
    crontab.do_remove_job(lines, comment, job)
    assert lines == []


# Generated at 2022-06-17 04:13:46.912930
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    crontab = CronTab(None, None, None)
    crontab.lines = ['#Ansible: test', '@reboot /usr/bin/test', '#Ansible: test2', '@reboot /usr/bin/test2']
    crontab.remove_env('test')
    assert crontab.lines == ['#Ansible: test2', '@reboot /usr/bin/test2']


# Generated at 2022-06-17 04:13:56.033392
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    # Test case 1
    crontab = CronTab(None, None, None)
    crontab.lines = ['#Ansible: test', '* * * * * echo "test"']
    assert crontab.find_job('test') == ['#Ansible: test', '* * * * * echo "test"']

    # Test case 2
    crontab = CronTab(None, None, None)
    crontab.lines = ['#Ansible: test', '* * * * * echo "test"']
    assert crontab.find_job('test', '* * * * * echo "test"') == ['#Ansible: test', '* * * * * echo "test"']

    # Test case 3
    crontab = CronTab(None, None, None)

# Generated at 2022-06-17 04:13:57.352289
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    ct = CronTab(None)
    assert ct.do_comment('test') == '#Ansible: test'


# Generated at 2022-06-17 04:14:04.247969
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    ct = CronTab(None, None, None)
    ct.lines = ['foo=bar', 'baz=qux']
    assert ct.find_env('foo') == [0, 'foo=bar']
    assert ct.find_env('baz') == [1, 'baz=qux']
    assert ct.find_env('quux') == []


# Generated at 2022-06-17 04:14:12.568908
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    # Test with a valid value
    ct = CronTab(None)
    ct.lines = []
    ct.do_add_env(ct.lines, "TEST=test")
    assert ct.lines == ["TEST=test"]

    # Test with a invalid value
    ct = CronTab(None)
    ct.lines = []
    ct.do_add_env(ct.lines, "TEST")
    assert ct.lines == []


# Generated at 2022-06-17 04:14:15.460226
# Unit test for method write of class CronTab
def test_CronTab_write():
    cron = CronTab(module, user=None, cron_file=None)
    cron.lines = ['#Ansible: test_job', '* * * * * echo "test"']
    cron.write()
    assert cron.lines == ['#Ansible: test_job', '* * * * * echo "test"']


# Generated at 2022-06-17 04:14:27.123191
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    ct = CronTab(None)
    ct.lines = ['PATH=/usr/bin:/usr/sbin:/sbin:/bin',
                'MAILTO=root',
                'HOME=/',
                'SHELL=/bin/sh',
                '#Ansible: test_job',
                '* * * * * /bin/true']
    assert ct.find_env('PATH') == [0, 'PATH=/usr/bin:/usr/sbin:/sbin:/bin']
    assert ct.find_env('MAILTO') == [1, 'MAILTO=root']
    assert ct.find_env('HOME') == [2, 'HOME=/']
    assert ct.find_env('SHELL') == [3, 'SHELL=/bin/sh']
    assert ct.find_env('FOO')

# Generated at 2022-06-17 04:14:44.011267
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    crontab = CronTab()

# Generated at 2022-06-17 04:14:46.021889
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    module = AnsibleModule(
        argument_spec = dict(
            user = dict(default=None),
            cron_file = dict(default=None),
        ),
        supports_check_mode=True
    )

    ct = CronTab(module)
    ct.remove_job_file()


# Generated at 2022-06-17 04:15:45.327918
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    # Setup
    module = AnsibleModule(argument_spec={})
    crontab = CronTab(module)
    name = 'test_job'
    job = '* * * * * /bin/true'

    # Test
    crontab.add_job(name, job)

    # Verify
    assert crontab.lines[0] == '#Ansible: test_job'
    assert crontab.lines[1] == '* * * * * /bin/true'


# Generated at 2022-06-17 04:15:55.123996
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    ct = CronTab(None)

# Generated at 2022-06-17 04:16:01.239432
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    crontab = CronTab(None, None, None)
    lines = []
    comment = "comment"
    job = "job"
    crontab.do_add_job(lines, comment, job)
    assert lines == [comment, job]


# Generated at 2022-06-17 04:16:04.717632
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    ct = CronTab(None)
    lines = []
    comment = '#Ansible: test'
    job = '* * * * * echo "test"'
    ct.do_add_job(lines, comment, job)
    assert lines == ['#Ansible: test', '* * * * * echo "test"']


# Generated at 2022-06-17 04:16:10.843914
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    ct = CronTab(None)
    assert ct.get_cron_job('*', '*', '*', '*', '*', 'echo "hello"', None, False) == '* * * * * echo "hello"'
    assert ct.get_cron_job('*', '*', '*', '*', '*', 'echo "hello"', None, True) == '#* * * * * echo "hello"'
    assert ct.get_cron_job('*', '*', '*', '*', '*', 'echo "hello"', '@reboot', False) == '@reboot echo "hello"'

# Generated at 2022-06-17 04:16:12.140568
# Unit test for method read of class CronTab
def test_CronTab_read():
    module = AnsibleModule(argument_spec={})
    cron = CronTab(module)
    cron.read()
    assert cron.lines is not None


# Generated at 2022-06-17 04:16:20.234599
# Unit test for method read of class CronTab
def test_CronTab_read():
    module = AnsibleModule(
        argument_spec = dict(
            user=dict(default=None, required=False),
            cron_file=dict(default=None, required=False),
        ),
        supports_check_mode=True
    )
    crontab = CronTab(module)
    assert crontab.lines == []


# Generated at 2022-06-17 04:16:26.380579
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True),
        ),
        supports_check_mode=True
    )

    cron = CronTab(module)
    cron.remove_env(module.params['name'])
    result = cron.render()

    module.exit_json(changed=True, result=result)


# Generated at 2022-06-17 04:16:32.494008
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    ct = CronTab(None, None, None)
    ct.lines = ['PATH=/bin:/usr/bin', 'MAILTO=root', 'HOME=/var/spool/mail']
    assert ct.find_env('PATH') == [0, 'PATH=/bin:/usr/bin']
    assert ct.find_env('MAILTO') == [1, 'MAILTO=root']
    assert ct.find_env('HOME') == [2, 'HOME=/var/spool/mail']
    assert ct.find_env('FOO') == []


# Generated at 2022-06-17 04:16:39.664913
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    crontab = CronTab(module=None, user=None, cron_file=None)
    crontab.lines = ['#Ansible: test', '@hourly /bin/true']
    crontab.remove_env('test')
    assert crontab.lines == ['@hourly /bin/true']


# Generated at 2022-06-17 04:18:19.859688
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    crontab = CronTab(None, None, None)
    name = 'test'
    job = '* * * * * /bin/true'
    crontab.add_job(name, job)
    assert crontab.lines == ['#Ansible: test', '* * * * * /bin/true']


# Generated at 2022-06-17 04:18:29.157785
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    ct = CronTab(None)
    ct.lines = ['#Ansible: foo', '* * * * * /bin/true', '#Ansible: bar', '* * * * * /bin/false']
    ct.add_env('FOO=bar')
    assert ct.lines == ['FOO=bar', '#Ansible: foo', '* * * * * /bin/true', '#Ansible: bar', '* * * * * /bin/false']
    ct.lines = ['#Ansible: foo', '* * * * * /bin/true', '#Ansible: bar', '* * * * * /bin/false']
    ct.add_env('FOO=bar', insertafter='foo')

# Generated at 2022-06-17 04:18:34.577849
# Unit test for method write of class CronTab
def test_CronTab_write():
    module = AnsibleModule(
        argument_spec = dict(
            user=dict(default=None, required=False),
            cron_file=dict(default=None, required=False),
        ),
        supports_check_mode=True
    )
    ct = CronTab(module)
    ct.write()
    assert ct.render() == ''


# Generated at 2022-06-17 04:18:36.578094
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    ct = CronTab(None)
    assert ct.do_comment('test') == '#Ansible: test'


# Generated at 2022-06-17 04:18:38.572401
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    ct = CronTab(None)
    assert ct.do_comment('name') == '#Ansible: name'


# Generated at 2022-06-17 04:18:48.750906
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True),
            job = dict(required=True),
            minute = dict(required=True),
            hour = dict(required=True),
            day = dict(required=True),
            month = dict(required=True),
            weekday = dict(required=True),
            special = dict(required=True),
            disabled = dict(required=True),
        ),
        supports_check_mode=True
    )
    ct = CronTab(module)

# Generated at 2022-06-17 04:18:55.134377
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    cron = CronTab(None)
    cron.lines = ['foo=bar', 'baz=qux']
    assert cron.find_env('foo') == [0, 'foo=bar']
    assert cron.find_env('baz') == [1, 'baz=qux']
    assert cron.find_env('qux') == []


# Generated at 2022-06-17 04:19:01.458258
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True),
            job = dict(required=True),
            minute = dict(required=True),
            hour = dict(required=True),
            day = dict(required=True),
            month = dict(required=True),
            weekday = dict(required=True),
            special = dict(required=True),
            disabled = dict(required=True),
        ),
        supports_check_mode=True
    )
    ct = CronTab(module)
    ct.add_job('test_job', ct.get_cron_job('*', '*', '*', '*', '*', 'echo "test"', None, False))

# Generated at 2022-06-17 04:19:03.614308
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    ct = CronTab(None)
    ct.lines = ['a', 'b', 'c']
    ct.do_remove_env(ct.lines, 'b')
    assert ct.lines == ['a', 'c']


# Generated at 2022-06-17 04:19:09.300624
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True),
        ),
        supports_check_mode=True
    )

    cron = CronTab(module)
    cron.remove_env(module.params['name'])
    module.exit_json(changed=True, msg="Successfully removed environment variable %s" % module.params['name'])
