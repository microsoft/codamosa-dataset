

# Generated at 2022-06-25 02:12:49.829833
# Unit test for constructor of class CronTab
def test_CronTab():
    cron_tab = CronTab(None)
    cron_tab = CronTab(None, user=None)
    cron_tab = CronTab(None, cron_file=None)
    cron_tab = CronTab(None, user=None, cron_file=None)

    with pytest.raises(CronTabError):
        test_case_0()


if __name__ == '__main__':
    test_CronTab()

# Generated at 2022-06-25 02:12:53.109268
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    cron_tab_0 = CronTab()
    var_0 = cron_tab_0.remove_env(None)
    assert var_0 is False
    assert cron_tab_0.lines == []


# Generated at 2022-06-25 02:12:56.782321
# Unit test for method write of class CronTab
def test_CronTab_write():
    cron_tab_0 = CronTab(module=module_0, user="user_0", cron_file="cron_file_0")
    cron_tab_0.write(backup_file="backup_file_0")


# Generated at 2022-06-25 02:13:00.670250
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    # Unit test for method do_remove_env of class CronTab
    test_cron_tab = CronTab(None, None, None)
    test_cron_tab.do_remove_env(line_list, decl)



# Generated at 2022-06-25 02:13:10.692167
# Unit test for constructor of class CronTab
def test_CronTab():
    this_module = ansible.module_utils.basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    this_cron_tab_0 = CronTab(module=this_module)
    this_cron_tab_1 = CronTab(module=this_module, cron_file='foo.cron')
    this_cron_tab_2 = CronTab(module=this_module, user='foo')

    this_cron_tab_0.read()
    this_cron_tab_0.write()

    this_cron_tab_0.add_job('foo', 'bar')
    this_cron_tab_0.remove_job('bar')
    this_cron_tab_1.update_job('foo', 'baz')

    this_cron_tab_

# Generated at 2022-06-25 02:13:11.560434
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    test_case_0()


# Generated at 2022-06-25 02:13:16.255435
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    crontab_0 = CronTab(module, user=None, cron_file=None)
    crontab_0.update_env(name=None, decl=None)

    crontab_1 = CronTab(module, user=None, cron_file=None)
    crontab_1.update_env(name=None, decl=None)


# Generated at 2022-06-25 02:13:18.859504
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    ct = CronTab(None)
    ct.update_env("name", "decl")
    assert ct.decl == "name", "wrong value returned"


# Generated at 2022-06-25 02:13:28.782095
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(name=dict(required=True, type='str'),
                           module=dict(required=True, type='str'),
                           state=dict(required=True, type='str'),
                           special_time=dict(required=False, type='str'),
                           time=dict(required=False, type='dict')),
        supports_check_mode=False)
    name = 'name'
    minute = ''
    hour = ''
    day = ''
    month = ''
    weekday = ''
    job = 'job'
    special = ''
    disabled = False
    cron_tab_0 = CronTab(module, user=None, cron_file=None)
    cron_tab_0.get

# Generated at 2022-06-25 02:13:30.586936
# Unit test for method read of class CronTab
def test_CronTab_read():
    test_CronTab = CronTab()
    test_CronTab.read()


# Generated at 2022-06-25 02:14:43.156009
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    cron_tab_0 = CronTab(module, user=None, cron_file=None)
    if cron_tab_0.is_empty():
        cron_tab_0.lines = []
        cron_tab_0.lines.append('comment')
        cron_tab_0.lines.append('* * * * * root /usr/bin/curl http://www.google.com > /dev/null 2>&1')
    cron_tab_0.remove_job(name=None)
    cron_tab_0.remove_job(name='comment')
    cron_tab_0.remove_job_file()
    return cron_tab_0


# Generated at 2022-06-25 02:14:45.062157
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 02:14:53.919238
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)

    # Ensure empty crontab is seen as empty
    cron_tab_0 = CronTab(module)
    assert cron_tab_0.is_empty() == True

    # Ensure non-empty crontab is not seen as empty
    cron_tab_1 = CronTab(module, cron_file="/tmp/cron_tab_test_file_0")
    os.system('echo "* * * * * echo 0 >> /tmp/cron_tab_test_file_0" > %s' % cron_tab_1.cron_file)
    cron_tab_1.read()
    assert cron_tab_1.is_empty() == False

    # Ensure blank crontab is not seen as empty
    cr

# Generated at 2022-06-25 02:14:58.505627
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    cron_tab_0 = CronTab(module, 'user', 'cron_file')
    # Method add_job of class CronTab calls method do_comment of class CronTab
    assert cron_tab_0.add_job('name', 'job')


# Generated at 2022-06-25 02:15:07.471457
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    cron_tab_0 = CronTab(module, user, cron_file)
    cron_tab_0.lines = [line.rstrip('\r\n') for line in ['']]
    cron_tab_0.lines = cron_tab_0.lines[0]
    cron_tab_0.lines = cron_tab_0.lines[0:0]
    cron_tab_0.lines = []
    cron_tab_0.lines = [line.rstrip('\r\n') for line in ['', '', '', '', '']]
    cron_tab_0.lines = cron_tab_0.lines[0]
    cron_tab_0.lines = cron_tab_0.lines[0:0]

# Generated at 2022-06-25 02:15:14.907764
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, 'run_command', return_value=(0, '', '')):
        test_crontab = dict(
            name="check dirs",
            user="root",
            job="ls -alh > /dev/null",
            state="present",
            backup=False,
            minute="10",
            hour="5,2",
            day="*",
            month="*",
            weekday="3",
            special_time=None,
            disabled=False,
            env=False,
            insertafter=None,
            insertbefore=None
        )
        main(AnsibleModule(test_crontab))

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:15:18.355075
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    cron_tab_0 = CronTab(0)
    result = cron_tab_0.is_empty()
    assert result == None


# Generated at 2022-06-25 02:15:20.495124
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    ct = CronTab('/etc/crontab', 'someuser')
    ct.remove_env('someuser')


# Generated at 2022-06-25 02:15:25.796027
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    cron_tab_0 = CronTab(module)
    assert cron_tab_0.remove_job_file() == False
    cron_tab_1 = CronTab(module)
    assert cron_tab_1.remove_job_file() == False
    cron_tab_2 = CronTab(module)
    assert cron_tab_2.remove_job_file() == False


# Generated at 2022-06-25 02:15:28.248594
# Unit test for method write of class CronTab
def test_CronTab_write():
    stub_path = 'test_dir/test_file'
    stub_cron_tab = CronTab(None, stub_path)
    assert(stub_cron_tab.write() == 1)


# Generated at 2022-06-25 02:17:56.840356
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    c = CronTab(module)

    if c.get_envnames() != []:
        raise Exception('Unexpected value returned by method get_envnames of class CronTab')



# Generated at 2022-06-25 02:18:02.931365
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    # Create instance of class CronTab
    cron_tab_instance_0 = CronTab(module, user, cron_file)
    # Call cron_tab_instance_0.do_remove_job with arguments lines, comment, job
    cron_tab_return_value_0 = cron_tab_instance_0.do_remove_job(lines, comment, job)
    # Check if cron_tab_return_value_0 equals None
    if cron_tab_return_value_0 == None:
        return True
    else:
        return False


# Generated at 2022-06-25 02:18:08.621738
# Unit test for method render of class CronTab
def test_CronTab_render():
    cron_tab_0 = CronTab('')
    cron_tab_0.lines = ['#Ansible: cron_job_0', '#Ansible: cron_job_1']
    str_result = cron_tab_0.render()
    assert isinstance(str_result, str)
    assert str_result == '#Ansible: cron_job_0\n#Ansible: cron_job_1\n'


# Generated at 2022-06-25 02:18:11.455240
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    tab = CronTab(None)
    tab.lines = ['#Ansible: test_name', '* * * * * /bin/foo']
    assert tab.find_env('test_name') == []


# Generated at 2022-06-25 02:18:14.329623
# Unit test for method render of class CronTab
def test_CronTab_render():
    test_module = AnsibleModule(argument_spec=dict(module_arg=dict(type='str')))

    cron_tab_0 = CronTab(test_module)
    print(cron_tab_0.render())


# Generated at 2022-06-25 02:18:17.529133
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    ct = CronTab(object(), user='root')
    result = ct.update_job("name", "job")
    assert True == result


# Generated at 2022-06-25 02:18:27.155576
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    cron_tab_0 = CronTab(module, user=None, cron_file=None)
    cron_tab_1 = CronTab(module, user=None, cron_file='/etc/cron.d/cronie')
    cron_tab_2 = CronTab(module, user='root', cron_file=None)
    cron_tab_3 = CronTab(module, user='root', cron_file='/etc/cron.d/cronie')

    result = cron_tab_0.get_jobnames()
    assert result == None
    result = cron_tab_1.get_jobnames()
    assert result == None
    result = cron_tab_2.get_jobnames()
    assert result == None
    result = cron_tab_3.get_job

# Generated at 2022-06-25 02:18:29.021075
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    cron_tab = CronTab()
    assert cron_tab.is_empty() == True


# Generated at 2022-06-25 02:18:32.251559
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    ct = CronTab(None, 'localhost', '/etc/cron.d/ansible_test_job')
    ct.update_job('my_job', '* * * * * echo "Test"')
    ct.write()


# Generated at 2022-06-25 02:18:37.758235
# Unit test for method render of class CronTab
def test_CronTab_render():
    cron_tab_0 = CronTab( module=None, user='daniel', cron_file=None)
    cron_tab_0.lines = ['JOB_0', 'JOB_1', 'JOB_2', 'JOB_3']
    result = cron_tab_0.render()
    assert result == 'JOB_0\nJOB_1\nJOB_2\nJOB_3\n'
