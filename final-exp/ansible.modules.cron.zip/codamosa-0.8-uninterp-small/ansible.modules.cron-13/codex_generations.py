

# Generated at 2022-06-25 02:12:51.798915
# Unit test for function main

# Generated at 2022-06-25 02:12:53.626148
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    ct = CronTab()
    ct.do_remove_job('ls',0)


# Generated at 2022-06-25 02:12:59.391022
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    # ansible/ansible-modules-core#3755
    lines = []
    comment = '#Ansible: test-name'
    job = '@hourly /bin/true'
    expected_result = [comment, job]
    result = []
    CronTab.do_add_job(lines, comment, job)
    result.append(lines)
    assert result == expected_result


# Generated at 2022-06-25 02:13:02.931299
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    cronTab = CronTab(None)
    lines = []
    decl = 'a'
    exp = ['a']
    cronTab.do_add_env(lines, decl)
    assert lines == exp


# Generated at 2022-06-25 02:13:12.224294
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    if platform.system() in ['SunOS', 'HP-UX', 'AIX']:
        test = CronTab(None, 'root')
        assert test.get_cron_job('0','0','0','0','0','root','','true') == '#@0 root root'
        assert test.get_cron_job('0','0','0','0','0','root','@0','false') == '@0 root root'
    else:
        test = CronTab(None, 'root')
        assert test.get_cron_job('0','0','0','0','0','root','','true') == '#0 0 0 0 0 root'
        assert test.get_cron_job('0','0','0','0','0','root','@0','false') == '@0 root'


# Generated at 2022-06-25 02:13:15.790922
# Unit test for method write of class CronTab
def test_CronTab_write():

    # Init a CronTab object
    cron_tab_0 = CronTab(module)

    # write the crontab to the system
    ansible_0_write = cron_tab_0.write(backup_file=None)

    # Verify the result
    assert(ansible_0_write == None)


# Generated at 2022-06-25 02:13:19.171018
# Unit test for method read of class CronTab
def test_CronTab_read():
    """
    Unit test for method read of class CronTab
    """
    cron_tab_0 = CronTab(user = None, cron_file = None)
    cron_tab_0.read()


# Generated at 2022-06-25 02:13:21.012349
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    crontab_0_get_envnames = CronTab(None)
    assert crontab_0_get_envnames.get_envnames() == []


# Generated at 2022-06-25 02:13:30.773140
# Unit test for method write of class CronTab
def test_CronTab_write():
    file_handle_0 = open('/tmp/ansible_test_cron_tab_file', 'wb')
    assert file_handle_0 != None

    cron_tab_0 = CronTab(None, 'ansible', cron_file='/tmp/ansible_test_cron_tab_file')
    cron_tab_0.write()

    file_handle_1 = open('/tmp/ansible_test_cron_tab_file')
    assert file_handle_1 != None

    content_0 = file_handle_1.read()
    assert content_0 != None

    file_handle_0.close()
    file_handle_1.close()


# Generated at 2022-06-25 02:13:36.655885
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    ct = CronTab(None)
    ct.lines = [
        'a=value1',
        'b=value2',
        'c=value3'
    ]

    assert ['0', 'a=value1'] == ct.find_env('a')
    assert ['1', 'b=value2'] == ct.find_env('b')
    assert ['2', 'c=value3'] == ct.find_env('c')
    assert [] == ct.find_env('d')


# Generated at 2022-06-25 02:14:46.727469
# Unit test for function main
def test_main():

    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-25 02:14:53.070175
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():

    """
    Test find_job with input from file.
    """

    cron_tab_0 = CronTab(module)

    # Input for variable comment
    comment_0 = cron_tab_0.do_comment("testcase01")

    # Input for variable job
    job_0 = cron_tab_0.get_cron_job("*", "*", "*", "*", "*", "/bin/test_case_0", "None", True)

    # Calling the method find_job of class CronTab with the input
    output = cron_tab_0.find_job("testcase01", job_0)

    # Assertion in order to check whether the expected result is equal to the output
    assert output == [comment_0, job_0]



# Generated at 2022-06-25 02:14:54.381085
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    cron_tab_0 = CronTab()


# Generated at 2022-06-25 02:15:04.417792
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    test_obj = CronTab(None)
    test_obj.lines = ['MINUTE=0', 'HOUR=2', 'DAY=3', 'MONTH=5', 'WEEKDAY=0', 'USER=root', 'COMMAND=/usr/lib64/sa/sa1', '1 2 3 4 5 /tmp/test.sh']
    name = 'MINUTE'
    result = test_obj.find_env(name)
    assert result == [0, 'MINUTE=0']
    name = 'COMMAND'
    result = test_obj.find_env(name)
    assert result == [5, 'COMMAND=/usr/lib64/sa/sa1']
    name = 'USER'
    result = test_obj.find_env(name)
    assert result == [4, 'USER=root']
   

# Generated at 2022-06-25 02:15:13.264952
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            decl=dict(required=True, type='str'),
            user=dict(required=True, type='str'),
            cron_file=dict(required=True, type='str')
        ),
        supports_check_mode=True
    )

    name = module.params['name']
    decl = module.params['decl']
    user = module.params['user']
    cron_file = module.params['cron_file']

    cron_tab_1 = CronTab(module, user, cron_file)
    env_var_0 = cron_tab_1.update_env(name, decl)


# Generated at 2022-06-25 02:15:16.053304
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    C = CronTab(None)
    env_names = ["PATH", "SHELL", "MAILTO", "HOME", "LOGNAME"]
    result = C.find_env("PATH")
    assert result != []  # Path should not be empty and contain the result
    assert env_names[0] in result[1]  # In the path there should be PATH

# Generated at 2022-06-25 02:15:25.620456
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():

    # Setup
    cron_tab_1 = CronTab()
    cron_tab_1.lines = None
    cron_tab_1.ansible = "#Ansible: "
    cron_tab_1.n_existing = ''
    cron_tab_1.cron_cmd = '/usr/bin/crontab'
    cron_tab_1.cron_file = None
    cron_tab_1.b_cron_file = None

    lines_2 = []
    job_3 = '* * * * * ansible-playbook /etc/ansible/roles/crontab/tasks/main.yml'
    cron_tab_1.do_add_job(lines_2, 'test_case_0', job_3)
    # assert lines_2[0]

# Generated at 2022-06-25 02:15:30.803329
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    from ansible.module_utils.pycompat24 import get_exception
    try:
        # testing with user=None
        test_obj = CronTab(None)
        test_obj.remove_job_file()
    except Exception as e:
        raise AssertionError(repr(get_exception()))
    except:
        raise AssertionError("Removing job file failed.  Method remove_job_file of class CronTab not working as expected.")


# Generated at 2022-06-25 02:15:33.732058
# Unit test for method write of class CronTab
def test_CronTab_write():
    cron = CronTab()
    back_file = '/tmp/cron_backup_file.txt'
    cron.write(back_file)
    fileh = open(back_file, 'rb')
    result = to_native(fileh.read(), errors='surrogate_or_strict')
    fileh.close()
    assert result == '\n'

# unit test for method remove_job_file of class CronTab

# Generated at 2022-06-25 02:15:38.628366
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    # create a cron
    cron_0 = CronTab(module, cron_file='test')
    # create a job
    job_0 = Job(command='ls', user='root')
    # add the job to the cron
    cron_0.add_job('job0', job_0)
    # test updating a job
    with pytest.raises(CronTabError):
        cron_0.update_job('job1', job_0)
    # test updating a job
    assert cron_0.update_job('job0', job_0) == False


# Generated at 2022-06-25 02:16:52.938737
# Unit test for method render of class CronTab
def test_CronTab_render():
    str_0 = '3jE\nN7M7.9<z\x0bMA:T'
    cron_tab_0 = CronTab(str_0)
    var_0 = cron_tab_0.render()
    assert var_0 == '3jE\nN7M7.9<z\x0bMA:T'


# Generated at 2022-06-25 02:16:57.962824
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    str_0 = 'C"xGU\x14-\x1c\x14\x1d\x1e$$z\r'
    cron_tab_0 = CronTab(str_0)
    str_1 = '8Qd\x7f\x1a'
    decl_0 = str_1
    cron_tab_0.add_env(decl_0)


# Generated at 2022-06-25 02:17:04.405576
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    str_0 = '\x10\x87\xda\xde\xf2\xdd\xd8\x18\xee\xc6\x1d\x8f\x81\xa1\x0c\x12\xe6\xa0\x9aN\xaf\x1d(\xa3'
    str_1 = '\xe2$\xa8\x04\x9f\xbc\x8e\xe3\xe3\xbf\x07\xd8\x01\xee\xfe\x94\xf5\x8a\x80\xf1-\x0c6\xc8l'
    result_1 = CronTab(str_0, str_1).get_envnames()

# Generated at 2022-06-25 02:17:05.093709
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 02:17:09.308779
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True),
            job = dict(required=True)
        ),
        supports_check_mode=True
    )
    cron_tab_0 = CronTab(module)
    name = module.params.get("name")
    job = module.params.get("job")
    result = cron_tab_0.find_job(name, job)
    module.exit_json(changed=True, ansible_facts=dict(crontab_find_job=result))


# Generated at 2022-06-25 02:17:11.568878
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    str_1 = '<'
    cron_tab_1 = CronTab(str_1)
    cron_tab_1.add_env('m')


# Generated at 2022-06-25 02:17:14.756086
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    str_0 = 'SAv\x92\x8d'
    str_1 = 'Q\x92\x8d'
    cron_tab_0 = CronTab(str_0)
    cron_tab_0.remove_job(str_1)


# Generated at 2022-06-25 02:17:20.608703
# Unit test for function main

# Generated at 2022-06-25 02:17:23.464665
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    str_0 = 'uV^G{E<@u1Yi_'
    str_1 = 'I07/\x0cN&D,0y"N'
    cron_tab_0 = CronTab(str_0)
    var_0 = cron_tab_0.update_job(str_1, str_0)
    print(var_0)



# Generated at 2022-06-25 02:17:32.121579
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    str_0 = '3jE\nN7M7.9<z\x0bMA:T'
    cron_tab_0 = CronTab(str_0)
    str_1 = '3jE\nN7M7.9<z\x0bMA:T'
    array_0 = [str_1]
    str_2 = '3jE\nN7M7.9<z\x0bMA:T'
    cron_tab_0.do_remove_env(array_0, str_2)


# Generated at 2022-06-25 02:20:00.184257
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    str_0 = '4jE\nN7M7.9<z\x0bMA:T'
    cron_tab_0 = CronTab(str_0)
    str_1 = '4jE\nN7M7.9<z\x0bMA:T'
    str_2 = '4jE\nN7M7.9<z\x0bMA:T'
    cron_tab_0.do_add_job(str_1, str_2, str_0)


# Generated at 2022-06-25 02:20:07.136554
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    str_0 = 'bDdMk\n'
    cron_tab_0 = CronTab(str_0)
    str_1 = 'IF#g{Bf'
    str_2 = 'yL|7Gn}'
    var_0 = cron_tab_0.find_job(str_1, str_2)


# Generated at 2022-06-25 02:20:13.039978
# Unit test for function main
def test_main():
  ansible_params = {'name': 'foo',
                    'user': 'root',
                    'job': 'ls',
                    'cron_file': '/etc/cron.d/foobar',
                    'state': 'present',
                    'backup': False,
                    'minute': '*',
                    'hour': '*',
                    'day': '*',
                    'month': '*',
                    'weekday': '*',
                    'special_time': None,
                    'disabled': False,
                    'env': False,
                    'insertafter': None,
                    'insertbefore': None,
                    'check_mode': False,
                    'diff': False}


# Generated at 2022-06-25 02:20:19.871021
# Unit test for method write of class CronTab
def test_CronTab_write():

    # Setup
    str_0 = 'Tp\x7fpz\x18Uww\x1e'
    str_1 = 'n\x12\x1d\x19\x17X\x01\x05\x0b\x06\x10\x00\x1b\x11\t\x02t\x13\x1a'

# Generated at 2022-06-25 02:20:25.751728
# Unit test for method render of class CronTab
def test_CronTab_render():
    module = get_module_path("cron")
    for x in module.params['cron_jobs']:
        cron_tab = CronTab(module, cron_file=module.params['name'])
        cron_tab.read()
        cron_tab.add_job(x.get('name'), cron_tab.get_cron_job(
            x.get('minute'), x.get('hour'), x.get('day'), x.get('month'), x.get('weekday'), x.get('job'),
            x.get('special_time'),
            x.get('disabled')))
        cron_tab.write(backup_file=None)
        cron_tab.render()

# Generated at 2022-06-25 02:20:33.947097
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    str_0 = 'I1\x17\t4D8L\x01'
    str_1 = ')rQ\x0cP\x10'
    cron_tab_0 = CronTab(str_0)
    cron_tab_0.add_env(str_0, None, None)
    cron_tab_0.add_env(str_1, str_0, str_0)
    cron_tab_0.add_env(str_1, str_1, str_0)
    cron_tab_0.add_env(str_0, str_0, str_1)
    cron_tab_0.add_env(str_1, str_1, str_1)


# Generated at 2022-06-25 02:20:36.413806
# Unit test for function main
def test_main():
    if test_case_0() == '<assertion error>':
        raise Exception('Assertion Error')

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 02:20:44.494913
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    str_0 = "1W\x8b^d\x0c\x15\x11\x8a\x88\x1d{\x1a\x8aq\x10\x97C\x7f \x86\x9a\x16{_\x7fa'\x8a\x80\x17\x8a\x8e\x9e\x9f\x16\x17_\x0b\x1d'j\x84\x8f\x9b"

# Generated at 2022-06-25 02:20:48.277513
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    var_0 = CronTab('')
    var_1 = ['', '', '']
    var_2 = '5'
    var_3 = '1'
    var_0.do_add_job(var_1, var_2, var_3)
    var_4 = ['5', '1']
    assert var_1 == var_4


# Generated at 2022-06-25 02:20:55.242025
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    str_0 = '3jE\nN7M7.9<z\x0bMA:T'
    str_1 = '/*'
    str_2 = 'q$+@gX\nC\x7fB[+#'
    cron_tab_0 = CronTab(str_0)
    cron_tab_0.read()
    str_3 = '?'
    str_4 = 'bFJ*\'D3YH-I!\x7f'
    cron_tab_0.find_job(str_3, str_4)
