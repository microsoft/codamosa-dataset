

# Generated at 2022-06-25 02:13:05.085873
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    c = CronTab(None, "root")
    c.lines = ["PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games", "AWS_SECRET_ACCESS_KEY=xyz", "AWS_ACCESS_KEY_ID=abc"]
    c.remove_env("AWS_SECRET_ACCESS_KEY")
    assert c.lines == ["PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games", "AWS_ACCESS_KEY_ID=abc"]


# Generated at 2022-06-25 02:13:08.373887
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    _cron_tab = CronTab(module, user="nobody", cron_file=None)
    _name = None
    _job = None
    _cron_tab.add_job(_name, _job)
    return _cron_tab


# Generated at 2022-06-25 02:13:13.353885
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    cron = CronTab(None)
    cron.add_env("a=b")
    assert cron.lines[0] == "a=b\n"
    cron.add_env("c=d")
    assert cron.lines[1] == "c=d\n"
    cron.add_env("e=f", insertafter="a=b")
    assert cron.lines[1] == "e=f\n"


# Generated at 2022-06-25 02:13:22.676296
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    # Tests for method get_cron_job on class CronTab
    cron_tab = CronTab()

    def test_case_1():
        job_1 = "foo job"
        var_1 = cron_tab.get_cron_job("*", "*", "*", "*", "*", job_1, "", False)

    def test_case_2():
        job_2 = "*/5 * * * * foo job"
        var_2 = cron_tab.get_cron_job("*/5", "*", "*", "*", "*", job_2, "", False)

    def test_case_3():
        job_3 = "@hourly foo job"

# Generated at 2022-06-25 02:13:27.473802
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    var_1 = CronTab(user='root')
    var_2 = var_1.get_envnames()
    if (var_2 == None):
        print('\n *********************Test Fail*********************')
    else:
        print('\n *********************Test Pass*********************')


# Generated at 2022-06-25 02:13:31.930884
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    var_0 = CronTab()
    var_1 = 'test_01'
    var_2 = '30 2 * * * /bin/echo job1'
    var_0.add_job(var_1, var_2)

    assert var_0.find_job(var_1, var_2)


# Generated at 2022-06-25 02:13:39.340567
# Unit test for function main

# Generated at 2022-06-25 02:13:42.299304
# Unit test for method write of class CronTab
def test_CronTab_write():
    print("Testing write...")
    var_0 = CronTab(user, cron_file)
    # Testing
    var_1 = var_0.write()
    print("Test 1 passed!")


# Generated at 2022-06-25 02:13:43.170657
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    # TODO
    assert True


# Generated at 2022-06-25 02:13:46.852792
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())
    crontab = CronTab(module)
    envname = "HOME"
    decl = "HOME=/home/user"
    crontab.update_env(envname, decl)
    assert crontab.find_env(envname)


# Generated at 2022-06-25 02:14:50.030750
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    crontab = CronTab()
    lines = []
    comment = None
    job = None
    crontab.do_add_job(lines, comment, job)


# Generated at 2022-06-25 02:14:53.067933
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    ct = CronTab(None)
    var_0 = ct.do_add_env(["Minute	  Hour	Day	Month	Weekday	User	  Command\n"], "LIBAUTH_CONF=/opt/IBM/ldap/V6.3/etc/tls/mqclient/ldap.conf\n")


# Generated at 2022-06-25 02:14:53.999081
# Unit test for method read of class CronTab
def test_CronTab_read():
    var_1 = CronTab()



# Generated at 2022-06-25 02:14:59.222509
# Unit test for constructor of class CronTab
def test_CronTab():
    cron_file = '/var/lib/pcsd/cores/pcsd-20161201-073001-16087-2.core'
    cron_user = 'root'
    cron_tab_0 = CronTab(cron_file, cron_user)
    return cron_tab_0


# Generated at 2022-06-25 02:15:03.600130
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    path = "CronTab_get_cron_job"
    a = CronTab()
    assert(a.get_cron_job(minute = "*",hour = "*",day = "*",month = "*",weekday = "*",job = "echo abc",special = None,disabled = True) == "#* * * * * echo abc")


# Generated at 2022-06-25 02:15:05.192006
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    var_1 = CronTab(None)
    var_2 = var_1.get_jobnames()


# Generated at 2022-06-25 02:15:06.216118
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-25 02:15:10.393651
# Unit test for method render of class CronTab
def test_CronTab_render():
    var_cron = CronTab(module)
    var_cron.lines = ['#Ansible: test1', '30 8 * * * run-parts /etc/cron.daily', '#Ansible: test2', '30 9 * * * run-parts /etc/cron.daily']
    var_result = var_cron.render()
    var_expected = ('#Ansible: test1\n30 8 * * * run-parts /etc/cron.daily\n'
                    '#Ansible: test2\n30 9 * * * run-parts /etc/cron.daily')
    assert var_result == var_expected


# Generated at 2022-06-25 02:15:14.260947
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    # param_2 = { }
    param_2 = None

    # param_1 = str
    param_1 = 'DECL'
    try:
        var_0 = CronTab(**param_2).find_env(param_1)
    except:
        var_0 = None

    assert var_0 == None


# Generated at 2022-06-25 02:15:16.381062
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    find_job_obj = CronTab(user = "user", cron_file = "cron_file")
    assert find_job_obj.find_job(name = "name", job = "job") == [], "Return value is incorrect"


# Generated at 2022-06-25 02:17:58.471843
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    # Setup
    var_0 = CronTab(module=None, user=None, cron_file=None)

# Generated at 2022-06-25 02:17:59.569880
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    var_1 = CronTab.find_env(var_0, 'SHELL')


# Generated at 2022-06-25 02:18:01.236203
# Unit test for method render of class CronTab
def test_CronTab_render():
    obj = CronTab(module)
    obj.read()
    # Expecting exception
    obj.write()


# Generated at 2022-06-25 02:18:10.347138
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    # Test case 0
    '''
    Setup
    '''
    my_cron_file_path = ''
    my_crontab = CronTab(my_cron_file_path)
    my_crontab.read()

    # Test case 1
    '''
    Remove declaration "PATH=/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin" from crontab
    '''
    test_case_variable_0 = 'PATH=/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin'
    my_crontab.remove_env(test_case_variable_0)
    test_case_result_0 = my_crontab.render()
    assert test_case_result_0 == test_case_result_0

#

# Generated at 2022-06-25 02:18:12.267149
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    # Create instance of class CronTab
    var_CronTab_inst = CronTab()
    # Actual Test
    assert var_CronTab_inst.add_job('name', 'job') == None


# Generated at 2022-06-25 02:18:17.624783
# Unit test for method read of class CronTab
def test_CronTab_read():
    var_1 = CronTab(user='root', cron_file='test')
    try:
        var_1.read()
    except Exception:
        var_1.module.fail_json(msg=traceback.format_exc())
    else:
        var_1.module.exit_json(changed=False)



# Generated at 2022-06-25 02:18:20.492875
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    # Instantiate a new CronTab object named test_1
    test_1 = CronTab()
    # Invoke get_cron_job method of test_1 and assign result to var_1
    var_1 = test_1.get_cron_job(None, None, None, None, None, None, None, None)


# Generated at 2022-06-25 02:18:23.780240
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    job_0 = CronTab.get_cron_job('', '', '', '', '', '', '', False)
    test_var = job_0
    if test_var is None:
        raise Exception("Cron job is none")


# Generated at 2022-06-25 02:18:31.028013
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    global var_0

    data = [
        {'lines': [], 'comment': 'test_job', 'job': '* * * * * /bin/test_job.sh'},
        {'lines': ['test_job'], 'comment': 'test_job', 'job': '* * * * * /bin/test_job.sh'}
    ]
    # Function returns None
    for item in data:
        result = var_0.do_remove_job(item['lines'], item['comment'], item['job'])
        assert(result == None)




# Generated at 2022-06-25 02:18:38.652500
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    m = Module()
    cron_file = '/etc/cron.d/test_ansible_cron'
    cron = CronTab(m, cron_file=cron_file)
    os.system('echo -e \n>>%s' % cron_file)
    cron.read()
    assert cron.is_empty()
    test_env = "export TEST_ENV=TEST"
    cron.add_env(test_env)
    assert not cron.is_empty()
    cron.write()
    #assert cron.find_env('TEST_ENV')
    os.system('rm -rf %s' % cron_file)
