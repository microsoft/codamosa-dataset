

# Generated at 2022-06-25 02:12:47.420885
# Unit test for constructor of class CronTab
def test_CronTab():
    try:
        test_case_0()
    except:
        print("Error in test case 0")

if __name__ == "__main__":
    test_CronTab()

# Generated at 2022-06-25 02:12:51.520716
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    # Testing basic functionality
    cron_tab_0 = CronTab()
    try:
        cron_tab_0.add_env('env_decl', 'env_insertafter', 'env_insertbefore')
        assert True
    except:
        assert False


# Generated at 2022-06-25 02:12:54.022029
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    args = dict(decl='test_decl')
    obj = CronTab(args)
    obj.do_add_env(obj.lines, **args)


# Generated at 2022-06-25 02:13:01.077545
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    print('Running test_CronTab_get_jobnames...')
    ct = CronTab(0)
    ct.lines = [
        '# Ansible: this is a job',
        'job_line_0',
        '# Ansible: this is another job',
        'job_line_1'
    ]
    assert ct.get_jobnames() == ['this is a job', 'this is another job'], 'test_CronTab_get_jobnames case 0 failed!'


# Generated at 2022-06-25 02:13:05.484732
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    cron_tab_0 = CronTab(module, user=None, cron_file=None)
    cron_tab_0.lines = ['1', '2']
    cron_tab_0.do_remove_job(cron_tab_0.lines, None, None)


# Generated at 2022-06-25 02:13:07.151090
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    test_obj = CronTab()
    assert type(test_obj.get_jobnames()) == list


# Generated at 2022-06-25 02:13:10.887911
# Unit test for function main
def test_main():
    try:
        assert True
    except AssertionError as e:
        raise e

test_cases = [
    test_case_0,
    test_main
]

test_set = {
    "test_cases": test_cases
}


# Generated at 2022-06-25 02:13:12.678003
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    c = CronTab(object, user='test')
    assert c.lines == []


# Generated at 2022-06-25 02:13:18.509350
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    cron_tab_0 = CronTab(module=None)
    cron_tab_0.get_envnames()
    try:
        cron_tab_0.get_envnames()
    except NameError:
        pass
    except:  # noqa: E722 do not use bare 'except'
        cron_tab_0.get_envnames()
    else:
        cron_tab_0.get_envnames()


# Generated at 2022-06-25 02:13:22.044327
# Unit test for method read of class CronTab
def test_CronTab_read():
    module = AnsibleModule(argument_spec={})
    cron_tab_0 = CronTab(module, cron_file='/etc/cron.d/ansible-test')
    assert cron_tab_0.read() is None


# Generated at 2022-06-25 02:14:13.366348
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    assert isinstance(test_case_0(), bool) == True


# Generated at 2022-06-25 02:14:15.258788
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    cron_tab_1 = CronTab(cron_tab_0, cron_tab_error_0, int_0)
    var_1 = cron_tab_1.is_empty()


# Generated at 2022-06-25 02:14:20.397451
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    cron_tab_error_0 = CronTabError()
    int_0 = 1760
    cron_tab_0 = CronTab(cron_tab_error_0, cron_tab_error_0, int_0)
    var_0 = cron_tab_0.get_envnames()


# Generated at 2022-06-25 02:14:25.290516
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    str_0 = 'KtB'
    int_0 = 585
    cron_tab_0 = CronTab(str_0, int_0, str_0)
    str_1 = 'Y3q'
    int_1 = 778
    var_1 = cron_tab_0.find_job(str_1, int_1)


# Generated at 2022-06-25 02:14:30.441871
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    job_0 = 'patate'
    name_0 = 'patate'
    cron_tab_0 = CronTab()
    lines_0 = [cron_tab_0]
    decl_0 = 'patate'
    comment_0 = cron_tab_0.do_comment(name_0)
    var_0 = cron_tab_0.do_remove_job(lines_0, comment_0, job_0)


# Generated at 2022-06-25 02:14:39.386301
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    cron_tab_error_0 = CronTabError()
    int_0 = 2118
    cron_tab_0 = CronTab(cron_tab_error_0, cron_tab_error_0, int_0)
    int_0 = 537
    str_0 = 'abcdefghijklmnopqrstuvwxyz'
    str_1 = 'abcdefghijklmnopqrstuvwxyz'
    str_2 = 'abcdefghijklmnopqrstuvwxyz'
    int_1 = 0

# Generated at 2022-06-25 02:14:41.612354
# Unit test for method read of class CronTab
def test_CronTab_read():
    cron_tab_CronTab_0 = CronTab()
    cron_tab_CronTab_0.read()


# Generated at 2022-06-25 02:14:44.084304
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    cron_tab_0 = CronTab('ut_module', 'ut_user', 'ut_cron_file')
    cron_tab_0.update_env('ut_name', 'ut_decl')


# Generated at 2022-06-25 02:14:48.139616
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    comment_0 = '_'
    job_0 = '_'
    cron_tab_error_0 = CronTabError()
    int_0 = 1760
    cron_tab_0 = CronTab(cron_tab_error_0, cron_tab_error_0, int_0)
    lines_0 = ['_']
    cron_tab_0.do_add_job(lines_0, comment_0, job_0)


# Generated at 2022-06-25 02:14:49.987259
# Unit test for constructor of class CronTab
def test_CronTab():
    cron_tab_0 = CronTab(0, 0, 0)


# Generated at 2022-06-25 02:16:26.079408
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    cron_tab_error_0 = CronTabError()
    int_0 = 1760
    cron_tab_0 = CronTab(cron_tab_error_0, cron_tab_error_0, int_0)
    string_0 = 'qrykXEIe'
    string_1 = '3qxypT8wj'
    var_0 = cron_tab_0.update_job(string_0, string_1)


# Generated at 2022-06-25 02:16:28.044057
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    cron_tab_0 = CronTab(module, user, cron_file)
    cron_tab_0.write()
    var_1 = cron_tab_0.get_envnames()
    print(var_1)


# Generated at 2022-06-25 02:16:33.551320
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    cron_tab_error_0 = CronTabError()
    int_0 = 5221
    cron_tab_0 = CronTab(cron_tab_error_0, cron_tab_error_0, int_0)
    int_0 = 3354
    int_1 = 4138
    int_2 = 2172
    int_3 = 2656
    int_4 = 3832
    str_0 = 'job_2'
    # str -> bool
    bool_0 = bool(None)
    str_1 = 'job_3'
    # str -> bool
    bool_1 = bool(None)
    str_2 = 'job_0'
    # str -> bool
    bool_2 = bool(None)
    str_3 = 'job_1'
    # str -> bool
    bool_3

# Generated at 2022-06-25 02:16:36.987907
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    cron_tab_error_1 = CronTabError()
    int_1 = 1760
    cron_tab_1 = CronTab(cron_tab_error_1, cron_tab_error_1, int_1)
    var_1 = cron_tab_1.get_envnames()


# Generated at 2022-06-25 02:16:40.854060
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    cron_tab_error_0 = CronTabError()
    int_0 = 1760
    cron_tab_1 = CronTab(cron_tab_error_0, cron_tab_error_0, int_0)
    str_0 = "foo"
    str_1 = "bar"
    str_2 = "baz"
    cron_tab_1.add_env(str_0, str_1, str_2)


# Generated at 2022-06-25 02:16:43.968334
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    ansible_module_0 = AnsibleModule(ansible_module_0)
    cron_tab_0 = CronTab(ansible_module_0, ansible_module_0, ansible_module_0)
    str_0 = 'ABCD'
    bool_0 = cron_tab_0.do_remove_env(str_0, str_0)
    assert bool_0



# Generated at 2022-06-25 02:16:48.818560
# Unit test for function main

# Generated at 2022-06-25 02:16:50.306698
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    cron_tab_0 = CronTab(file='')
    cron_tab_0.get_jobnames()


# Generated at 2022-06-25 02:16:55.572182
# Unit test for method read of class CronTab
def test_CronTab_read():
    cron_tab_error_0 = CronTabError()
    int_0 = 1660
    cron_tab_0 = CronTab(cron_tab_error_0, cron_tab_error_0, int_0)
    var_0 = cron_tab_0.read()


# Generated at 2022-06-25 02:16:57.186161
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    cron_tab_0 = CronTab()
    var_0 = cron_tab_0.remove_job_file()


# Generated at 2022-06-25 02:21:03.000232
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    try:
        cron_tab_1 = CronTab(0)
        cron_tab_1.remove_env(0)
    except:
        assert False


# Generated at 2022-06-25 02:21:07.205597
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    cron_tab_0 = CronTab(CronTabError(), cron_tab_error_0, int_0)
    var_0 = cron_tab_0.remove_job_file()


# Generated at 2022-06-25 02:21:11.270057
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    cron_tab_error_0 = CronTabError()
    int_0 = 1760
    cron_tab_0 = CronTab(cron_tab_error_0, cron_tab_error_0, int_0)
    cron_tab_0.do_add_job(None, None, None)


# Generated at 2022-06-25 02:21:17.219895
# Unit test for method write of class CronTab
def test_CronTab_write():
    pass

# Test for method: write
# Test with the specified arguments
#    def write(self, backup_file=None):
#        """
#        Write the crontab to the system. Saves all information.
#        """
#        if backup_file:
#            fileh = open(backup_file, 'wb')
#        elif self.cron_file:
#            fileh = open(self.b_cron_file, 'wb')
#        else:
#            filed, path = tempfile.mkstemp(prefix='crontab')
#            os.chmod(path, int('0644', 8))
#            fileh = os.fdopen(filed, 'wb')
#
#        fileh.write(to_bytes(self.render()))
#        fileh.close()


# Generated at 2022-06-25 02:21:19.700010
# Unit test for method read of class CronTab
def test_CronTab_read():
    obj_CronTab_class = CronTab()
    obj_CronTab_class.read()


# Generated at 2022-06-25 02:21:22.854270
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    cron_tab_0 = CronTab(None)
    # var_0 is supposed to be an instance of the class Exception, not a variable
    var_0 = Exception()
    int_0 = cron_tab_0.update_job(var_0, var_0)


# Generated at 2022-06-25 02:21:28.963853
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    cron_tab_0 = CronTab(None, None, None)
    int_0 = 1
    str_0 = "e1KjwQkTb"
    cron_tab_0.update_job(int_0, str_0)


# Generated at 2022-06-25 02:21:31.951716
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    cron_tab_error_3 = CronTabError()
    int_3 = 1760
    str_3 = 'str_3'
    str_4 = 'str_4'
    cron_tab_1 = CronTab(cron_tab_error_3, cron_tab_error_3, int_3)
    assert not cron_tab_1.update_job(str_3, str_4)


# Generated at 2022-06-25 02:21:36.922123
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    cron_tab_error_0 = CronTabError()
    int_0 = 1760
    cron_tab_0 = CronTab(cron_tab_error_0, cron_tab_error_0, int_0)
    var_0 = cron_tab_0.write()


# Generated at 2022-06-25 02:21:41.789667
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    cron_tab_0 = CronTab(cron_tab_error_0, cron_tab_error_0, int_0)
    var_1 = cron_tab_0.remove_job_file()
    print (var_1)

