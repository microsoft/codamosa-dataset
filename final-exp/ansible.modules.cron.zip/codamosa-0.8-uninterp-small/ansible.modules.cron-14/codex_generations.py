

# Generated at 2022-06-25 02:12:55.100042
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    var_1 = CronTab(0, 0.0, )
    var_2 = main()
    var_3 = main()
    var_1.add_env(var_2, var_3)


# Generated at 2022-06-25 02:13:00.513531
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    var_0 = CronTab(module, user=None, cron_file=None)
    lines = lines_0
    comment = "Ansible: test"
    job = "* * * * * /bin/true"
    do_remove_job(var_0, lines, comment, job)
    print("should be \"0\":", len(var_0))


# Generated at 2022-06-25 02:13:03.288225
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    ctab = CronTab(user=None, cron_file='cron.tab')
    result = ctab.remove_job_file()
    assert result == True


# Generated at 2022-06-25 02:13:10.497459
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str'),
            job=dict(type='str'),
        ),
        supports_check_mode=True,
    )
    # Initialize the CronTab object
    crontab_obj = CronTab(module)

    name = module.params['name']
    job = module.params['job']
    result = crontab_obj.find_job(name, job)
    module.exit_json(changed=False, ansible_facts=dict(cron_result=result))


# Generated at 2022-06-25 02:13:12.453928
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    out = CronTab_find_env("my_name")
    # Add additional tests here


# Generated at 2022-06-25 02:13:14.311939
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    obj = CronTab()
    son = obj.update_job(name, job)
    print(son)


# Generated at 2022-06-25 02:13:19.044793
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    print('Testing get_envnames of CronTab')
    var_1 = CronTab()
    var_2 = var_1.get_envnames()
    print('Returned value from get_envnames is {}'.format(var_2))


if __name__ == '__main__':
    print('Testing CronTab')
    print('Testing main of CronTab')
    test_case_0()
    print('Testing get_envnames of CronTab')
    test_CronTab_get_envnames()

# Generated at 2022-06-25 02:13:26.209107
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    var_0 = CronTab()
    var_1 = var_0.get_cron_job('minute')
    var_2 = var_0.get_cron_job('minute', 'hour')
    var_3 = var_0.get_cron_job('minute', 'hour', 'day')
    var_4 = var_0.get_cron_job('minute', 'hour', 'day', 'month')
    var_5 = var_0.get_cron_job('minute', 'hour', 'day', 'month', 'weekday')
    var_6 = var_0.get_cron_job('minute', 'hour', 'day', 'month', 'weekday', 'job')

# Generated at 2022-06-25 02:13:29.314062
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    var_0 = CronTab(None)
    var_1 = "job1"
    var_2 = "job"
    var_0.add_job(var_1,var_2)


# Generated at 2022-06-25 02:13:32.881266
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    var_0 = CronTab(user=None, cron_file=None)
    var_1 = []
    var_2 = ''
    var_3 = ''
    var_0.do_add_job(var_1, var_2, var_3)


# Generated at 2022-06-25 02:14:44.158947
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    cron = CronTab('test')
    cron.lines = []
    assert cron.get_jobnames() == []

    cron.lines = ['#Ansible: foo']
    assert cron.get_jobnames() == ['foo']

    cron.lines = ['#Ansible: foo', '* * * * * foo', '#Ansible: bar', '* * * * * bar']
    assert cron.get_jobnames() == ['foo', 'bar']

    cron.lines = ['foo', '* * * * * foo', '#Ansible: bar', '* * * * * bar']
    assert cron.get_jobnames() == ['bar']


# Generated at 2022-06-25 02:14:45.901557
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    var_0 = CronTab(module)
    var_0.do_add_env(var_0.lines, var_0.decl)


# Generated at 2022-06-25 02:14:46.848200
# Unit test for constructor of class CronTab
def test_CronTab():
    var_1 = main()
    var_1.CronTab()


# Generated at 2022-06-25 02:14:48.262836
# Unit test for method read of class CronTab
def test_CronTab_read():
    var_1 = CronTab()
    var_2 = var_1.read()


# Generated at 2022-06-25 02:14:50.102176
# Unit test for method read of class CronTab
def test_CronTab_read():
    job = CronTab('')
    job.read()


# Generated at 2022-06-25 02:14:58.849983
# Unit test for function main
def test_main():
    var_0 = False
    var_1 = False
    var_2 = False
    var_3 = False
    var_4 = False
    var_5 = False
    var_6 = False
    case_0 = True
    if var_0:
        case_0 = var_1
    if var_2:
        case_0 = var_3
    if var_4:
        case_0 = var_5
    if case_0:
        case_0 = var_6
    return case_0

if __name__ == '__main__':
    test_case_0()
    test_main()

# Generated at 2022-06-25 02:15:02.312390
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    var_1 = CronTab()
    var_2 = var_1.lines
    var_3 = 'foo'
    var_4 = 'bar'
    var_5 = var_1.do_remove_job(var_2, var_3, var_4)


# Generated at 2022-06-25 02:15:11.495199
# Unit test for method add_env of class CronTab

# Generated at 2022-06-25 02:15:13.164238
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    var_1 = CronTab()
    testcase = var_1.get_envnames()
    assert testcase


# Generated at 2022-06-25 02:15:18.519143
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    var_1 = {}
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = var_1['name']
    var_8 = var_1['minute']
    var_9 = var_1['hour']
    var_10 = var_1['day']
    var_11 = var_1['month']
    var_12 = var_1['weekday']
    var_13 = var_1['job']
    var_14 = var_1['special_time']
    var_15 = var_1['disabled']
    var_16 = var_1['job']
    var_17 = var_1['job']
    var_18 = var_1['name']

# Generated at 2022-06-25 02:17:56.608163
# Unit test for method write of class CronTab
def test_CronTab_write():
    test_case_0()


# Generated at 2022-06-25 02:17:58.038348
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    var_0 = CronTab()
    var_1 = var_0.is_empty()
    assert var_1 == True


# Generated at 2022-06-25 02:18:04.009650
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    var_0 = CronTab()
    var_0.user = 'test'
    var_0.cron_file = 'test'
    var_0.b_cron_file = 'test'
    var_0.n_existing = 'test'
    var_0.cron_cmd = 'test'
    var_0.lines = ['test', 'test', 'test']
    var_0.ansible = 'test'
    var_1 = var_0.lines
    var_2 = 'test'
    var_3 = 'test'
    var_0.do_add_job(var_1, var_2, var_3)
    print(str(var_0.lines))


# Generated at 2022-06-25 02:18:07.132950
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    var_1 = CronTab(None, 'user', 'file')
    var_1.lines = ['a', 'b', 'c']
    var_2 = var_1.get_envnames()
    assert var_2 == ['a', 'b', 'c']


# Generated at 2022-06-25 02:18:13.194323
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    # Create an instance of class CronTab
    obj_CronTab = CronTab(var_0, 'root')
    # Try to find a job
    obj_CronTab.find_job('cron_job1', '/usr/bin/bar')
    # Try to find a job by name
    obj_CronTab.find_job('cron_job1')
    # Try to find a job that does not exist
    obj_CronTab.find_job('foo', '/usr/bin/bar')


# Generated at 2022-06-25 02:18:16.538200
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    test_var_0 = CronTab(module, user=None, cron_file=None)
    test_var_1 = lines
    test_var_2 = comment
    test_var_3 = job
    test_var_0.do_add_job(test_var_1, test_var_2, test_var_3)


# Generated at 2022-06-25 02:18:24.181481
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    CronTab_0 = CronTab(module, user=user, cron_file=cron_file)
    CronTab_1 = CronTab(module, user=user, cron_file=cron_file)
    CronTab_2 = CronTab(module, user=user, cron_file=cron_file)
    CronTab_1.remove_env(name)
    CronTab_2.remove_env(name)
    if(CronTab_1 != CronTab_2):
        print("Error - delete job command")


# Generated at 2022-06-25 02:18:25.975617
# Unit test for method read of class CronTab
def test_CronTab_read():
    var_1 = CronTab(module, user=None, cron_file=None)
    var_1.read()


# Generated at 2022-06-25 02:18:30.740499
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    print('Testing get_cron_job of CronTab')
    crons_0 = CronTab()
    var_0 = crons_0.get_cron_job('minute', 'hour', 'day', 'month', 'weekday', 'job', 'special', 'disabled')
    print(var_0)


# Generated at 2022-06-25 02:18:35.680087
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={
        'name': {'required': True, 'type': 'str'},
        'env': {'type': 'dict'},
    })

    ct = CronTab(module, user=module.params['name'])
    return ct.update_env(module.params['name'], module.params['env'])


# Generated at 2022-06-25 02:21:55.967542
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    var_1 = new_CronTab()
    var_2 = new_str()
    var_2 = 'TEST'
    var_3 = new_str()
    var_3 = 'TEST=VALUE'
    var_1.add_env(var_3)
    var_4 = var_1.get_envnames()
    print("get_envnames = ", var_4)


# Generated at 2022-06-25 02:21:56.863027
# Unit test for function main
def test_main():
    test_case_0()

# Collect all test cases in this file