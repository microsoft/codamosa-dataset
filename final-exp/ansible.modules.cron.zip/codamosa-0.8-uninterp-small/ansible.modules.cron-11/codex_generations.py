

# Generated at 2022-06-25 02:12:56.502773
# Unit test for method write of class CronTab
def test_CronTab_write():
    c = CronTab(None)
    backup_file = None
    c.write(backup_file)


# Generated at 2022-06-25 02:12:57.904878
# Unit test for method read of class CronTab
def test_CronTab_read():
    class_0 = CronTab()
    class_0.read()


# Generated at 2022-06-25 02:13:01.126618
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    cron_tab_obj = CronTab("user")
    time_string = "cron_string"
    cron_tab_obj.remove_job(time_string)


# Generated at 2022-06-25 02:13:04.350942
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    var_0 = main()
    var_1 = var_0.do_comment('job_9')
    # assert var_1 == '#Ansible: job_9'


# Generated at 2022-06-25 02:13:10.615309
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    # Create instance of class
    mock_crontab = CronTab(
        user='root',
    )
    # Run method "add_job" of CronTab class
    mock_crontab.add_job(
        name='test',
        job='testjob',
    )
    # Check the variable "mock_crontab.lines"
    assert mock_crontab.lines == [
        '#Ansible: test',
        'testjob'
    ]


# Generated at 2022-06-25 02:13:12.222222
# Unit test for method read of class CronTab
def test_CronTab_read():
    var_0 = CronTab(module, user=None, cron_file=None)
    var_0.read()


# Generated at 2022-06-25 02:13:15.525808
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    try:
        var_0 = CronTab('module', 'user', 'cron_file')
        var_1 = var_0.find_job('name', 'job')
        pass_flag = True
    except:
        pass_flag = False

    return pass_flag


# Generated at 2022-06-25 02:13:17.233518
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    var_0 = CronTab()
    var_0.is_empty()


# Generated at 2022-06-25 02:13:25.935913
# Unit test for function main
def test_main():
    args = '{"name":"test_case_1","user":"test_case_1","job":"test_case_1","cron_file":"test_case_1","state":"test_case_1","backup":true,"minute":"test_case_1","hour":"test_case_1","day":"test_case_1","month":"test_case_1","weekday":"test_case_1","special_time":"test_case_1","disabled":true,"env":true,"insertafter":"test_case_1","insertbefore":"test_case_1","check_mode":true}'
    # parse args
    args = json.loads(args)
    import pprint
    pprint.pprint(args)
    # call target module
    main()
    print('\n')

if __name__ == '__main__':
    main

# Generated at 2022-06-25 02:13:35.430060
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():

    import shutil
    if os.path.exists('/tmp/test_crontab.bak'):
        shutil.rmtree('/tmp/test_crontab.bak')

    module = AnsibleModule(
        argument_spec=dict(
            name="this is a test name",
            job="a test job",
            user="root",
            cron_file='/etc/cron.d/test_crontab.bak',
            state='present'
        ),
        supports_check_mode=False
    )

    mycron = CronTab(module)
    mycron.add_job("this is a test name", "a test job")
    mycron.write()


# Generated at 2022-06-25 02:14:46.947032
# Unit test for function main
def test_main():
    # mock the module action and params
    class ModuleMock(object):
        """ mock module """
        def __init__(self):
            self.params = {}
            self.check_mode = False
            self.debug = False
            self.fail_json = None
            self.exit_json = None

    module_mock = ModuleMock()

    def mock_fail_json(msg):
        """ mock fail_json """
        module_mock.fail_json = msg

    def mock_exit_json(msg):
        """ mock exit_json """
        module_mock.exit_json = msg

    module_mock.fail_json = mock_fail_json
    module_mock.exit_json = mock_exit_json

    # mock the class CronTab

# Generated at 2022-06-25 02:14:51.713162
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    var_1 = CronTab(boolean_0=False, cron_file_path=None, env_decl=None, name=None, minute='*', hour='*', day='*', month='*', weekday='*', user=None, job=None, state='present')
    var_1.get_envnames()


# Generated at 2022-06-25 02:14:52.620653
# Unit test for constructor of class CronTab
def test_CronTab():
    var_0 = CronTab()

# Generated at 2022-06-25 02:15:01.382483
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    global module_args
    # global n_existing
    # global lines
    global ansible
    module_args = dict(
        name='test_job',
        minute='*/15',
        user='root',
        job='ls -al /',
        cron_file=None
    )
    # n_existing = ''
    lines = None
    ansible = '#Ansible: '
    crontab = CronTab(module, user, cron_file)
    # Set up the test case
    # Call the function to be tested
    res = crontab.get_envnames()
    assert isinstance(res,list) == True


# Generated at 2022-06-25 02:15:02.041350
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    main()


# Generated at 2022-06-25 02:15:04.956925
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    testobj = CronTab(module, user=None, cron_file=None)
    str_arg = 'str_arg'
    actual_result = testobj.do_comment(str_arg)
    expected_result = '#Ansible: str_arg'
    assert actual_result == expected_result, 'Expected "%s", but got "%s"' % (expected_result, actual_result)


# Generated at 2022-06-25 02:15:06.958542
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    ct = CronTab(module, user=None, cron_file=None)
    result = ct.get_envnames()


# Generated at 2022-06-25 02:15:15.110907
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    test_user = pwd.getpwuid(os.getuid()).pw_name

# Generated at 2022-06-25 02:15:23.361691
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    # Unit test for method update_env of class CronTab

    cron_tab = CronTab()
    cron_tab.lines = ['var_0=',
                      'var_1=',
                      'var_2=',
                      'var_3=']
    cron_tab.update_env('var_1', 'var_1=value_1')
    assert cron_tab.lines == ['var_0=',
                          'var_2=',
                          'var_3=',
                          'var_1=value_1']


# Generated at 2022-06-25 02:15:25.247928
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    var_1 = CronTab( )
    var_2 = var_1.find_env()

    print(var_2)


# Generated at 2022-06-25 02:16:31.117116
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    cron_0 = CronTab()
    var_1 = 'test'
    var_2 = 'test'
    var_3 = 'test'
    var_0 = cron_0.do_remove_job(var_1, var_2, var_3)
    return var_0


# Generated at 2022-06-25 02:16:39.722279
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    p = platform.system()
    if (p == "Darwin" or p == "Linux" or p == "SunOS"):
        var_0 = CronTab(None, None)
        # Tested:
        # new CronTab()
        # c.add_job("/tmp/test", "* * * * * /bin/true")
        var_1 = CronTab(None, None, "/tmp/test")
        var_2 = var_1.get_jobnames()
        assert (len(var_2) == 1)
        assert (var_2[0] == "/tmp/test")
        var_1 = CronTab(None, None, "/etc/cron.d/test")
        var_2 = var_1.get_jobnames()
        assert (len(var_2) == 1)

# Generated at 2022-06-25 02:16:45.247371
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():

    print("Testing method find_job of class CronTab")

    # Set up
    minutes = "*"
    hours = "*"
    days = "*"
    months = "*"
    weekdays = "*"
    job = "echo test"
    special = None
    disabled = False
    jobname = "test_job1"
    cron = CronTab(None)
    cron.add_job(jobname, cron.get_cron_job(minutes, hours, days, months, weekdays, job, special, disabled))

    # Test case
    assert cron.find_job(jobname) == ['test_job1', '* * * * * echo test']
    assert cron.find_job(jobname, job) == ['test_job1', '* * * * * echo test']



# Generated at 2022-06-25 02:16:54.129303
# Unit test for method write of class CronTab
def test_CronTab_write(): #test_1
    my_module = AnsibleModule(
            argument_spec = dict(
                    name = dict(required=True),
                    hour = dict(required=True),
                    minute = dict(required=True),
                    job = dict(required=True),
                    user = dict(required=False),
                    disabled = dict(required=False),
                    comment = dict(required=False),
                    backup = dict(required=False)
                    )
            )

    cron = CronTab(my_module)
    disabled=True
    job = "ls"
    name = 'test'
    hour = '*'
    minute = '*'
    special = None
    day = '*'
    month = '*'
    weekday = '*'


# Generated at 2022-06-25 02:16:57.415639
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Unexpected error:", sys.exc_info()[1])
        raise


if  __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 02:16:59.434383
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    # FIXME: unit test goes here
    a_job = None
    cron_tab = CronTab(user=None)
    cron_tab.add_job("", a_job)


# Generated at 2022-06-25 02:17:02.377668
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    var_0 = CronTab()
    var_1 = var_0.find_job("1")
    var_2 = var_0.find_job("2")

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 02:17:03.961337
# Unit test for method render of class CronTab
def test_CronTab_render():
    test_CronTab = CronTab()
    test_CronTab = CronTab()
    assert test_CronTab.render() == "\n"


# Generated at 2022-06-25 02:17:07.277072
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    var_0 = CronTab(test_case_0())
    ansible_id, state, name, job, special, env, backup, minute, hour, day, month, weekday, disabled = ''
    var_1 = var_0.add_job(name, job, special, env, backup, minute, hour, day, month, weekday, disabled)
    var_2 = var_0.get_jobnames()
    assert var_1 == var_2


# Generated at 2022-06-25 02:17:09.963195
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    test_cron_tab = CronTab()
    test_lines = ["test_line_0", "test_line_1"]
    test_decl = "test_decl"
    test_cron_tab.do_add_env(test_lines, test_decl)
    assert test_lines[1] == "test_decl"


# Generated at 2022-06-25 02:19:37.040332
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    crontab = CronTab(name, minute, hour, day, month, weekday, job, special, disabled, insertbefore, insertafter, backup, state, cron_file, env, user)
    lines = ['foo', 'bar']
    comment = 'baz'
    job = 'qux'

    crontab.do_add_job(lines, comment, job)

    if lines != ['foo', 'bar', comment, job]:
        raise Exception("Failed do_add_job test")


# Generated at 2022-06-25 02:19:41.613502
# Unit test for method read of class CronTab
def test_CronTab_read():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    main_obj_1 = CronTab(var_1, var_2, var_3)
    main_obj_1.read()


# Generated at 2022-06-25 02:19:45.145798
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    """
    Test method find_env of class CronTab
    """
    main()


# Generated at 2022-06-25 02:19:46.547544
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    print('Testing remove_env')
    var_1 = CronTab();
    var_1.remove_env()
    print('END TEST: remove_env')


# Generated at 2022-06-25 02:19:49.741559
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    var_1 = CronTab(ansible_module, "brill", "/etc/cron.d/whatever")
    var_2 = var_1.find_job("whatever")
    assert len(var_2) == 0


# Generated at 2022-06-25 02:19:50.972855
# Unit test for constructor of class CronTab
def test_CronTab():
    var_9 = CronTab(None)


# Generated at 2022-06-25 02:20:01.498233
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    if __name__ == '__main__':
        var_1 = CronTab(user = "user", cron_file = "cron_file")
        var_2 = var_1.do_comment("name")
        try:
            var_3 = var_2 == "#Ansible: name"
        except:
            var_3 = False
        try:
            var_4 = var_2 == "#Ansible:1"
        except:
            var_4 = False
        try:
            var_5 = var_2 == "#Ansible: name"
        except:
            var_5 = False
        try:
            var_6 = var_2 == "#Ansible: name"
        except:
            var_6 = False

# Generated at 2022-06-25 02:20:07.406059
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    # instantiate
    var_1 = CronTab()
    # declare the class variables
    var_1.lines = ListType()
    # initialize the class
    var_1.do_comment("test_name")
    # check the value of instance attribute lines
    assert var_1.lines == [], "instance attribute lines not set to [], but: %r" % var_1.lines


# Generated at 2022-06-25 02:20:09.759240
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    tab = CronTab()
    lines = []
    tab.do_remove_env(lines, "")


# Generated at 2022-06-25 02:20:11.427262
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    test_Job = CronTab(module, user=None, cron_file=None)
    var_0 = test_Job.do_comment('name')
    return var_0
