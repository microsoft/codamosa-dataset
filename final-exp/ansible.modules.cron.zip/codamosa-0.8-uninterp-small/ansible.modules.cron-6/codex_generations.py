

# Generated at 2022-06-25 02:12:51.003737
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    var_0 = CronTab('/test/test_cron')
    var_1 = 'HOME='
    assert var_0.update_env('HOME', var_1) == False

# main() entry point

# Generated at 2022-06-25 02:13:00.178040
# Unit test for constructor of class CronTab
def test_CronTab():
    ansible_mock = mock.Mock()
    ansible_mock.get_bin_path.return_value = '/bin/crontab'
    ansible_mock.run_command.return_value = (1, 'foo', None)
    #ansible_mock = AnsibleModule
    cron = CronTab(ansible_mock)
    print("cron: %s" % cron)
    print("cron.ansible: %s" % cron.ansible)
    print("cron.cron_cmd: %s" % cron.cron_cmd)
    print("cron.lines: %s" % cron.lines)


# Generated at 2022-06-25 02:13:02.511964
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    var_1 = CronTab(module)
    var_2 = var_1.do_remove_job()
    return var_2


# Generated at 2022-06-25 02:13:04.939189
# Unit test for function main
def test_main():
    assert check_function_output(main) == True

if __name__ == '__main__':
    test_case_0()
    test_main()

# Generated at 2022-06-25 02:13:13.380729
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    ct = CronTab(None, None)
    ct.lines.append("")
    ct.lines.append("")
    ct.lines.append("")
    ct.lines.append("")
    ct.lines.append("")
    ct.lines.append("")
    ct.lines.append("")
    ct.lines.append("")
    ct.lines.append("")
    ct.lines.append("")
    ct.lines.append("")
    ct.lines.append("")
    ct.lines.append("")
    ct.lines.append("")
    ct.lines.append("")
    ct.lines.append("")
    ct.lines.append("")
    ct.lines.append("")
    ct.lines.append

# Generated at 2022-06-25 02:13:20.554126
# Unit test for method read of class CronTab
def test_CronTab_read():
    # get variable
    var_1 = ''
    var_2 = ''
    var_3 = ''
    var_4 = ''
    var_5 = ''
    var_6 = ''
    var_7 = ''
    var_8 = ''
    var_9 = ''
    var_10 = ''
    var_11 = ''
    var_12 = ''

    # run method
    var_0 = CronTab(var_1, var_2, var_3)
    var_13 = var_0.read()

    # return
    return


# Generated at 2022-06-25 02:13:25.187780
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    # Test if function returns expected result
    var_0 = main()
    var_1 = ["@reboot","#Ansible: comment","@reboot","* * * * *","#comment","* * * * *","#Ansible: other_comment","* * * * *"]
    var_2 = "var_0.do_remove_env(var_1)"
    var_3 = var_0.do_remove_env(var_1)
    assert var_3 == var_2


# Generated at 2022-06-25 02:13:27.779449
# Unit test for method write of class CronTab
def test_CronTab_write():
    pass


if __name__ == '__main__':
    # test_case_0()
    test_CronTab_write()

# Generated at 2022-06-25 02:13:31.133893
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    args = {}
    args['name'] = 'FOO'
    # No exception should be thrown
    try:
        obj = CronTab(args)
        obj.find_env(args['name'])
    except:
        raise


# Generated at 2022-06-25 02:13:33.185382
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    var_CronTab = CronTab(None)    
    var_CronTab.get_jobnames()


# Generated at 2022-06-25 02:14:42.449224
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    rc, out, err = main()
    assert rc == 0 or rc == 1 or rc == 2 or rc == 3 or rc == 4 or rc == 5 or rc == 6 or rc == 7 or rc == 8 or rc == 9 or rc == 10 or rc == 11 or rc == 12 or rc == 13 or rc == 14 or rc == 15 or rc == 16 or rc == 17 or rc == 18 or rc == 19 or rc == 20 or rc == 21 or rc == 22 or rc == 23 or rc == 24 or rc == 25 or rc == 26 or rc == 27 or rc == 28 or rc == 29 or rc == 30 or rc == 31 or rc == 32 or rc == 33 or rc == 34 or rc == 35 or rc == 36 or rc == 37 or rc == 38 or rc == 39 or rc == 40 or rc == 41 or rc == 42 or rc == 43 or rc == 44 or rc == 45 or rc == 46

# Generated at 2022-06-25 02:14:46.855814
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    var_1 = CronTab()
    var_2 = [
        '* * * * *',
        'Hello World',
        '@reboot echo "hello"'
    ]
    var_3 = 'export TEST=1'
    var_1.do_add_env(var_2, var_3)
    assert var_2 == [
        'export TEST=1',
        '* * * * *',
        'Hello World',
        '@reboot echo "hello"'
    ]


# Generated at 2022-06-25 02:14:50.577188
# Unit test for constructor of class CronTab
def test_CronTab():
    user = "abc"
    cron_file = "abc.txt"
    cronTab = CronTab(user, cron_file)
    assert cronTab.user == user
    assert cronTab.cron_file == cron_file


# Generated at 2022-06-25 02:14:55.685422
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    cron_job_0 = CronTab('minute', 'hour', 'day', 'month', 'weekday', 'test_job', 'special', True)
    update_job_result_0 = cron_job_0.update_job('test_name', 'test_job')

    assert update_job_result_0 == True


# Generated at 2022-06-25 02:14:57.609074
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    var_1 = CronTab(user='root')
    var_2 = 'test'
    var_3 = '* * * * * /usr/bin/true'
    var_4 = var_1.add_job(var_2, var_3)


# Generated at 2022-06-25 02:14:59.058673
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    var_0 = do_add_env()


# Generated at 2022-06-25 02:15:08.001714
# Unit test for method render of class CronTab
def test_CronTab_render():
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True),
            minute = dict(default='*'),
            hour = dict(default='*'),
            day = dict(default='*'),
            month = dict(default='*'),
            weekday = dict(default='*'),
            job = dict(required=True),
            user = dict(),
            backup = dict(type='bool', default=False),
            special_time = dict(),
            disabled = dict(type='bool', default=False),
        ),
        supports_check_mode = True,
    )

    # var_0 = copy.deepcopy(module.params)
    var_0 = {}
    var_0['state'] = 'present'
    var_0['name'] = 'test'

# Generated at 2022-06-25 02:15:12.796532
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    crontab = CronTab('module')
    comment = ''
    decl = ''
    lines = []
    # adding test data
    lines.append('@daily cd $HOME ; backup')
    lines.append('#Ansible: test')
    lines.append('*/5 * * * * cd $HOME ; backup')
    crontab.do_remove_env(lines, decl)


# Generated at 2022-06-25 02:15:17.370317
# Unit test for method write of class CronTab
def test_CronTab_write():

    try:
        fileh1 = open('/etc/cron.d/test_cron_file', 'wb')
        fileh1.write(to_bytes('test_cron_file_content'))
        fileh1.close()
    except IOError:
        # cron file does not exist
        return

    c = CronTab(
        module='ansible.builtin.cron',
        user='root',
        cron_file='test_cron_file'
        )

    c.write(backup_file='/etc/cron.d/test_cron_file_backup')



# Generated at 2022-06-25 02:15:20.876432
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    var_1 = main()

    # Call method
    var_1.do_add_job(['test'], 'test_comment', 'test_job')

    assert var_1.lines == ['test', 'test_comment', 'test_job']


# Generated at 2022-06-25 02:17:40.357767
# Unit test for method render of class CronTab
def test_CronTab_render():
    cr = CronTab()
    cr.add_job('job', '* * * * * command')
    cr.add_job('job2', '@daily command')
    cr.add_job('job3', '@reboot command')
    cr.add_env('PATH=/bin:/usr/bin')
    cr.add_env('MAILTO=root')
    print(cr.render())

if __name__ == '__main__':
    test_case_0()
    test_CronTab_render()
    print('Done')

# Generated at 2022-06-25 02:17:49.421985
# Unit test for method remove_env of class CronTab

# Generated at 2022-06-25 02:17:55.225015
# Unit test for method find_job of class CronTab
def test_CronTab_find_job():
    cron_tab = CronTab(None)
    minute = "0"
    hour = "0"
    day = "1"
    month = "1"
    weekday = "0"
    job = "test user"
    special = ""
    disabled = False

    result = cron_tab.get_cron_job(minute, hour, day, month, weekday, job, special, disabled)

    assert result == '0 0 1 1 0 test user'


# Generated at 2022-06-25 02:18:02.266040
# Unit test for method update_job of class CronTab
def test_CronTab_update_job():
    test_instance_0 = CronTab(module)
    test_instance_1 = CronTab(module)
    test_instance_2 = CronTab(module)
    test_instance_3 = CronTab(module)
    test_instance_4 = CronTab(module)
    test_instance_5 = CronTab(module)
    test_instance_6 = CronTab(module)
    test_instance_7 = CronTab(module)
    test_instance_7.read()
    test_instance_8 = CronTab(module)
    test_instance_8.read()
    # Assertion message
    assert test_instance_8.update_job(name, job) == test_instance_7.update_job(name, job)


# Generated at 2022-06-25 02:18:11.104045
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3


# Generated at 2022-06-25 02:18:18.072389
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    module = AnsibleModule(
        argument_spec=dict(
            minute=dict(),
            hour=dict(),
            day=dict(),
            month=dict(),
            weekday=dict(),
            job=dict(required=True),
            name=dict(),
            user=dict(),
            cron_file=dict(),
            special_time=dict(),
            disabled=dict(default=False, aliases=['state'], type='bool'),
            backup=dict(default=False, type='bool'),
            backup_name=dict(default='cron.{ansible_date_time}')
        )
    )

    # Instantiate the class

# Generated at 2022-06-25 02:18:23.317300
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    var_0 = CronTab(module, user=None, cron_file=None)
    # Initialize test variables
    args = [
        var_0,
        [],
        "foo='bar'"
    ]
    # Set expected return value and call method
    expected_result = None
    result = var_0.do_add_env(*args)
    # Check result and expected result
    assert result == expected_result, 'Expected and given result do not match!'
    # Return success flag
    return True


# Generated at 2022-06-25 02:18:29.561599
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    ct = CronTab()
    ct.lines = ["#Ansible: name", "# */5 * * * * -xterm /tmp/foo", "", "", "ALERT=always", "#Ansible: other_name", "# */5 * * * * -xterm /tmp/foo", "", "", "SUBJECTS=foo,bar"]
    actual = ct.get_envnames()
    assert actual == ['ALERT', 'SUBJECTS']


# Generated at 2022-06-25 02:18:31.113459
# Unit test for method render of class CronTab
def test_CronTab_render():
    var_1 = CronTab()
    assert var_1.render() == '\n'


# Generated at 2022-06-25 02:18:31.682523
# Unit test for function main
def test_main():
    var_main = main()
