

# Generated at 2022-06-25 02:12:46.519785
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    lines = [u'#Ansible: Comment 0', u'0 * * * * /[[FOO]]']
    comment = u'#Ansible: Comment 1'
    job = u'1 * * * * /[[BAR]]'
    passed = False

    cron_tab_0 = CronTab(module)
    cron_tab_0.do_add_job(lines, comment, job)

    if lines[-1] == job and lines[-2] == comment:
        passed = True

    assert passed == True


# Generated at 2022-06-25 02:12:56.550037
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    cron_tab_0 = CronTab()
    list_0 = ['#$#', '$#', '$', '#$#', '$#$', '%(', '*#', ' * ', '$#', '*#', '#$', '#*#', '*#$', '#*#', '#*#', '$#$', '#$', '*#', '#*#', '*#', '#$', '#*#', '$#', '$#$', '#$', '$#', '$#$', '$#', '$#$', '#*', '*#']

# Generated at 2022-06-25 02:12:59.682501
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    cron_tab_0 = CronTab()
    assert cron_tab_0
    assert not cron_tab_0.do_remove_env(list(), str())


# Generated at 2022-06-25 02:13:09.947147
# Unit test for method get_envnames of class CronTab
def test_CronTab_get_envnames():
    cron_tab_0 = CronTab('module', 'user', 'cron_file')
    assert cron_tab_0.get_envnames() == []
    cron_tab_1 = CronTab('module', 'user', 'cron_file')
    assert cron_tab_1.get_envnames() == []
    cron_tab_2 = CronTab('module', 'user', 'cron_file')
    assert cron_tab_2.get_envnames() == []
    cron_tab_3 = CronTab('module', 'user', 'cron_file')
    assert cron_tab_3.get_envnames() == []
    cron_tab_4 = CronTab('module', 'user', 'cron_file')
    assert cron_tab_4.get_envnames() == []

# Generated at 2022-06-25 02:13:12.001804
# Unit test for constructor of class CronTab
def test_CronTab():
    a = CronTab(user='root', cron_file='/etc/cron.d/test')


# Generated at 2022-06-25 02:13:15.880944
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    try:
        # call the method
        cron_tab_0 = CronTab(module_0, None, "crontab")
        ret_val_0 = cron_tab_0.remove_job_file()
    except Exception:
        print(sys.exc_info())


# Generated at 2022-06-25 02:13:18.005424
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    a = CronTab()
    assert a.do_comment('a') == '#Ansible: a'


# Generated at 2022-06-25 02:13:20.677766
# Unit test for constructor of class CronTab
def test_CronTab():
    try:
        cron_tab = CronTab()
    except Exception:
        assert(cron_tab_error_0.msg == CronTabError.msg)


# Generated at 2022-06-25 02:13:25.879402
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    # Create an instance of CronTab
    cron_tab_0 = CronTab(module, user='root', cron_file='mycron')

    # Invoking the method remove_env of CronTab with arguments name
    # The expected output returned is None
    assert cron_tab_0.remove_env('name') is None


# Generated at 2022-06-25 02:13:28.172585
# Unit test for method write of class CronTab
def test_CronTab_write():
    cron_tab_write_0 = CronTab()
    cron_tab_write_0.write()


# Generated at 2022-06-25 02:14:29.426257
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    user = 'root'
    cron_file = 'test'
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    cron_tab_0 = CronTab(module, user, cron_file)
    decl = 'decl'
    insertafter = 'insertafter'
    insertbefore = 'insertbefore'
    cron_tab_0.add_env(decl, insertafter, insertbefore)


# Generated at 2022-06-25 02:14:33.166181
# Unit test for method write of class CronTab
def test_CronTab_write():
    try:
        cron_tab_class_0 = CronTab()
    except NameError:
        pass
    # Call function write of class CronTab
    try:
        cron_tab_class_0.write()
    except Exception:
        pass


# Generated at 2022-06-25 02:14:36.011554
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    # Test case 0
    cron_tab_0 = CronTab(user="user_0")
    name_0 = "var"
    assert cron_tab_0.remove_env(name_0) == False


# Generated at 2022-06-25 02:14:43.818186
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    job_1 = "ls"
    name_1 = "ls_job"
    job_2 = "date"
    name_2 = "date_job"
    cron_1 = CronTab(None)
    cron_1.do_add_job(cron_1.lines, cron_1.do_comment(name_1), job_1)
    cron_1.do_add_job(cron_1.lines, cron_1.do_comment(name_2), job_2)
    cron_2 = CronTab(None)
    cron_2.add_job(name_1, job_1)
    cron_2.add_job(name_2, job_2)
    assert cron_1.lines == cron_2.lines



# Generated at 2022-06-25 02:14:45.296045
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    assert cron_tab_0.do_comment(name="name_1") == "#Ansible: name_1"


# Generated at 2022-06-25 02:14:48.578644
# Unit test for method do_remove_job of class CronTab
def test_CronTab_do_remove_job():
    try:
        cron_tab_do_remove_job_0 = CronTab()
        lines = None
        comment = None
        job = None
        cron_tab_do_remove_job_0.do_remove_job(lines, comment, job)

    except Exception:
        cron_tab_do_remove_job_0 = None
    assert cron_tab_do_remove_job_0 is None


# Generated at 2022-06-25 02:14:52.346841
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    cron_tab_0 = CronTab()
    test_case_0()
    test_case_0()

if __name__ == '__main__':
    test_CronTab_remove_job()

# Generated at 2022-06-25 02:14:54.255340
# Unit test for method read of class CronTab
def test_CronTab_read():
    ctab = CronTab(None, cron_file='cron_test_file')
    ctab.read()


# Generated at 2022-06-25 02:14:58.419666
# Unit test for method read of class CronTab
def test_CronTab_read():
    module = AnsibleModule(argument_spec={})
    cron_tab_0 = CronTab(module)
    try:
        assert cron_tab_0.read() == None
    except Exception:
        assert False


# Generated at 2022-06-25 02:14:59.681204
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    assert CronTab.find_env("foo_name") == []


# Generated at 2022-06-25 02:16:04.196679
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    cron_tab_1 = CronTab(os.getuid())
    cron_tab_1.n_existing = "SHELL=/bin/sh"
    cron_tab_1.find_env("SHELL")
    cron_tab_1.find_env("BASH")


# Generated at 2022-06-25 02:16:05.774616
# Unit test for method write of class CronTab
def test_CronTab_write():
    cron_tab_1 = CronTab(user=None, cron_file=None)
    cron_tab_1.write()


# Generated at 2022-06-25 02:16:13.179229
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    out = ''
    err = ''

    cron = CronTab(None)

# Generated at 2022-06-25 02:16:15.589106
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    test = CronTab()
    test.lines = [
        '#Ansible: test',
        '32 */2 * * * echo "test"'
    ]
    assert test.is_empty() == False


# Generated at 2022-06-25 02:16:17.311293
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    cron_tab_0 = CronTab(module, 'None', 'None')
    cron_tab_0.remove_job_file()


# Generated at 2022-06-25 02:16:19.640690
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    fixture_CronTab_add_env()
    ct = CronTab(user='mclarence')
    ct.add_env(decl='VARIABLE=value')

    assert len(ct.get_envnames()) == 1


# Generated at 2022-06-25 02:16:22.279324
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    test_crontab = CronTab(2)
    test_crontab.add_env("test_env")
    test_crontab.add_env("test_env", "test_env", True)
    test_crontab.add_env("test_env", True, "test_env")


# Generated at 2022-06-25 02:16:28.164529
# Unit test for method add_job of class CronTab
def test_CronTab_add_job():
    # Test examples
    test_cases = [
        CronTab('ls', 'testuser', 'testcronfile'),
        CronTab('ls', 'testuser'),
        CronTab('ls'),
        CronTab('ls', 'cronduser', '/etc/cron.d/cronduser'),
        CronTab('ls', 'cronduser', '/usr/lib/cron/tabs/cronduser'),
        CronTab('ls', 'cronduser', '/etc/crontab')
    ]

    def _add_job(cron_tab, cron, job):
        cron_tab.add_job(cron, job)
        return cron_tab.render()


# Generated at 2022-06-25 02:16:30.089885
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    cron_tab_0 = CronTab(module = None, cron_file = None)
    cron_tab_0.lines = ['a']
    cron_tab_0.add_env('abc')


# Generated at 2022-06-25 02:16:35.224492
# Unit test for method do_add_env of class CronTab
def test_CronTab_do_add_env():
    cron_tab_0 = CronTab(module=module)
    new_env = 'test=test'

    # The new_env is successfully added to the beginning
    cron_tab_0.do_add_env(cron_tab_0.lines, new_env)
    assert cron_tab_0.lines[0] == new_env

    # The new_env is successfully added after the specified name
    cron_tab_0.do_add_env(cron_tab_0.lines, new_env, insertafter='test')
    assert cron_tab_0.lines[1] == new_env

    # The new_env is successfully added before the specified name
    cron_tab_0.do_add_env(cron_tab_0.lines, new_env, insertbefore='test')
   

# Generated at 2022-06-25 02:18:11.686731
# Unit test for method find_env of class CronTab
def test_CronTab_find_env():
    ct = CronTab(None)
    ct.lines = ["foo=bar", "baz=fizz"]
    result = ct.find_env("baz")
    assert_list_equal(result, [1, "baz=fizz"])
    result = ct.find_env("bar")
    assert_list_equal(result, [])


# Generated at 2022-06-25 02:18:18.481081
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    cron_tab_0 = CronTab(module, user=None, cron_file=None)
    cron_tab_1 = CronTab(module, user=None, cron_file=None)
    cron_tab_2 = CronTab(module, user=None, cron_file=None)
    cron_tab_3 = CronTab(module, user=None, cron_file=None)
    cron_tab_4 = CronTab(module, user=None, cron_file=None)
    cron_tab_5 = CronTab(module, user=None, cron_file=None)
    cron_tab_6 = CronTab(module, user=None, cron_file=None)
    cron_tab_7 = CronTab(module, user=None, cron_file=None)

# Generated at 2022-06-25 02:18:21.916138
# Unit test for method do_comment of class CronTab
def test_CronTab_do_comment():
    c = CronTab(None, user=None)
    expected_result = "#Ansible: test_name"
    result = c.do_comment("test_name")
    assert (result == expected_result)


# Generated at 2022-06-25 02:18:25.648656
# Unit test for method write of class CronTab
def test_CronTab_write():
    cron_tab_write_0 = CronTab(module = None, user = None, cron_file = None)
    cron_tab_write_0.write()

    

if __name__ == '__main__':
    # Unit tests for method CronTab.write
    # test_case_0()
    test_CronTab_write()

# Generated at 2022-06-25 02:18:32.129580
# Unit test for method remove_job of class CronTab
def test_CronTab_remove_job():
    cron_tab_0 = CronTab(ansible_module,
                         user=default_user,
                         cron_file='ansible_crontab')

    assert cron_tab_0 is not None

    assert_fail(cron_tab_0.remove_job, 'anacron_non_exists')

    cron_tab_0.remove_job('anacron')

    assert cron_tab_0.find_job('anacron') == []


# Generated at 2022-06-25 02:18:36.063116
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    import os
    import tempfile
    import sys
    import re
    import platform
    import pwd

    cron_tab_obj_0 = CronTab()
    if cron_tab_obj_0.is_empty():
        print("cron job is present")
    else:
        print("cron job is not present")


# Generated at 2022-06-25 02:18:43.038047
# Unit test for method remove_job_file of class CronTab
def test_CronTab_remove_job_file():
    global username
    cron_tab_obj_0 = CronTab()
    cron_tab_obj_0._CronTab__cron_cmd = 'crontab'
    cron_tab_obj_0._CronTab__user = username
    cron_tab_obj_0._CronTab__root = os.getuid() == 0
    cron_tab_obj_0.ansible = '#Ansible: '
    cron_tab_obj_0._CronTab__n_existing = ''
    cron_tab_obj_0.lines = ['#Ansible: test', '* * * * * echo "test"']
    cron_tab_obj_0.remove_job_file()
    return


# Generated at 2022-06-25 02:18:49.627095
# Unit test for method get_cron_job of class CronTab
def test_CronTab_get_cron_job():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=0)
    cron_tab0 = CronTab(module)
    cron_tab0.cron_file = None
    result = cron_tab0.get_cron_job("minute", "hour", "day", "month", "weekday", "job", "special", "disabled")
    print(result)


# Generated at 2022-06-25 02:18:52.035951
# Unit test for method write of class CronTab
def test_CronTab_write():
    try:
        # Create a CronTab
        cronTab = CronTab(module=AnsibleModule(argument_spec={}, supports_check_mode=False))

        # Write the crontab
        cronTab.write()

        return True
    except:
        return False


# Generated at 2022-06-25 02:18:56.538545
# Unit test for method update_env of class CronTab
def test_CronTab_update_env():
    cron_tab_instance_empty = CronTab(None, None, None)

    # assign instance attributes
    cron_tab_instance_empty.lines = [  ]

    # assign parameter values
    name = "name"
    decl = "decl"

    # update_env method
    cron_tab_instance_empty.update_env(name, decl)

    # return result
    # get instance attributes
    assert cron_tab_instance_empty.lines == [ "name=decl" ]


# Generated at 2022-06-25 02:20:51.564940
# Unit test for method do_remove_env of class CronTab

# Generated at 2022-06-25 02:20:55.074523
# Unit test for method do_add_job of class CronTab
def test_CronTab_do_add_job():
    ct = CronTab(module=None)
    ct.state = 'present'
    decl = 'test=test'
    comment = '#test'
    job = 'testtest'
    lines = []
    ct.do_add_job(lines, comment, job)
    assert lines[0] == '#test'
    assert lines[1] == job


# Generated at 2022-06-25 02:20:58.262068
# Unit test for constructor of class CronTab
def test_CronTab():
    module = AnsibleModule(
        argument_spec=dict(
            user=dict(required=False, default=None),
            cron_file=dict(required=False, default=None)
        ),
        supports_check_mode=True
    )
    CronTab(module, 'usman.sajjad', '/etc/cron.d/test')



# Generated at 2022-06-25 02:21:00.309587
# Unit test for method remove_env of class CronTab
def test_CronTab_remove_env():
    try:
        cron_tab = CronTab()
        cron_tab.remove_env(None)
    except Exception as e:
        if isinstance(e, AttributeError):
            pass
        else:
            raise CronTabError()


# Generated at 2022-06-25 02:21:07.105112
# Unit test for method render of class CronTab
def test_CronTab_render():
    """
        Unit test for method render of class CronTab
    """
    cron_tab_0 = CronTab(module=None)
    cron_tab_0.lines = ["<>|{}#$~", "# test line", "0 0 * * * /a/b/c/d/e.py", "10 0 * * * /a/b/c/d/e.py", "@monthly /a/b/c/d/e.py"]
    out = cron_tab_0.render()
    assert out == '''
<>|{}#$~
# test line
0 0 * * * /a/b/c/d/e.py
10 0 * * * /a/b/c/d/e.py
@monthly /a/b/c/d/e.py
'''
   

# Generated at 2022-06-25 02:21:14.621533
# Unit test for method do_remove_env of class CronTab
def test_CronTab_do_remove_env():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-25 02:21:20.939781
# Unit test for method is_empty of class CronTab
def test_CronTab_is_empty():
    test_modules = AnsibleModuleMock()
    test_cron_tab_class = CronTab(test_modules)
    test_cron_tab_class.lines = list(range(10))
    assert test_cron_tab_class.is_empty() == False
    test_cron_tab_class.lines = []
    assert test_cron_tab_class.is_empty() == True


# Generated at 2022-06-25 02:21:25.602588
# Unit test for method write of class CronTab
def test_CronTab_write():
    crontab_obj = CronTab()
    crontab_obj.write()


# Generated at 2022-06-25 02:21:30.690922
# Unit test for method get_jobnames of class CronTab
def test_CronTab_get_jobnames():
    cron_tab_0 = CronTab()
    comment = 'ansible-test0'
    minute = '*'
    hour = '*'
    day = '*'
    month = '*'
    weekday = '*'
    job = '/bin/echo "This is a test command0"'
    cron_job_0 = cron_tab_0.get_cron_job(minute, hour, day, month, weekday, job, None, False)
    cron_tab_0.add_job(comment, cron_job_0)
    assert comment in cron_tab_0.get_jobnames()


# Generated at 2022-06-25 02:21:34.246762
# Unit test for method add_env of class CronTab
def test_CronTab_add_env():
    # Create a test CronTab object:
    tab = CronTab(module=None, user='root', cron_file='ansible-crontab-test-1')

    # Test error handling:
    try:
        tab.add_env('FAKE_VAR', insertafter=True)
    except CronTabError:
        pass

    # Test adding a variable:
    assert tab.add_env('FAKE_VAR', insertafter='SHELL') is None
    return True
