

# Generated at 2022-06-11 14:40:39.372896
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    i = InventoryManager('/home/snow/git/ansible/tests/inventory_test.ini')
    p = InventoryModule(i)

    p._parse('/home/snow/git/ansible/tests/inventory_test.ini', TEST_INI_CONTENT)
    assert p.lineno == 40
    # assert len(p.groups['group1'].vars) == 2
    # assert len(p.groups['group2'].vars) == 2
    # assert len(p.groups['group2'].child_groups) == 2


# Generated at 2022-06-11 14:40:41.098707
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Unit test for method parse of class InventoryModule
    '''

    pass

# Generated at 2022-06-11 14:40:46.765297
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule(None)
    filename = 'ansible/inventory/tests/inventory'
    with open(filename, 'r') as f:
        data = f.readlines()

    try:
        module._parse(filename, data)
    except Exception as e:
        pytest.fail(str(e))


# Generated at 2022-06-11 14:40:54.138383
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    ini = '''
# comment
[group1:vars]
# comment
host1 user=test
host2
host3

[group2]
host4
'''

    yaml = '''
# comment
group1:
  hosts:
    host1:
      ansible_ssh_user: test
    host2: {}
    host3: {}
group2:
  hosts:
    host4:
'''

    inv = InventoryModule()
    inv.parse(ini, None)
    assert inv.generate() == yaml


# Generated at 2022-06-11 14:41:02.935760
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module_class = 'InventoryModule'
    module_class_file = module_class.lower()
    module_name = 'test_' + module_class_file

    module_path = os.path.join(unit_test_path, module_name + '.py')
    f = open(module_path, 'w')
    old_umask = os.umask(0)

# Generated at 2022-06-11 14:41:11.111910
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryManager()
    imodule = InventoryModule(inventory)

# Generated at 2022-06-11 14:41:13.084909
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv_obj = InventoryModule(None)
    inv_obj.parse('data')



# Generated at 2022-06-11 14:41:24.438350
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Since the InventoryModule.parse() method depends on global variables,
    # the global variables need to be defined beforehand.
    Ansible._load_shell_plugins()
    Ansible._load_inventory_plugins()

    # A temporary directory is created to hold files to be parsed during
    # the test.

    # Temporary directory for test file.
    temp_dir = tempfile.mkdtemp()
    # print 'temp_dir=' + temp_dir
    # Full path name of the test file.
    test_file = os.path.join(temp_dir, TEST_INI_FILE)

    # Use a python list as a container to hold the content of the test file.
    lines = []
    lines.append('# Sample test inventory file' + '\n')
    lines.append('[group1]' + '\n')

# Generated at 2022-06-11 14:41:28.231900
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Create an instance of InventoryModule
    inventory_module = InventoryModule()
    # Create an empty Inventory
    inventory_module.inventory = Inventory()
    # Load the inventory file
    inventory_module._load_inventory_file("inventory")

    # Create an empty dictionary
    expected_groups = {}
    expected_groups['ungrouped'] = {'children': [], 'vars': {}}

    # Compare dictionaries
    assert  inventory_module.inventory.groups == expected_groups


# Generated at 2022-06-11 14:41:34.775854
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()
    inv.parse("./discover/test/inventory/test.ini")
    assert inv.inventory.groups == {u'test': Group(u'test')}
    assert inv.inventory.hosts == {u'192.168.0.1': Host(u'192.168.0.1'), u'192.168.0.2': Host(u'192.168.0.2')}
    assert inv.inventory.get_host(u'192.168.0.2').vars == {
        u'ansible_ssh_host': u'192.168.0.2',
        u'ansible_ssh_port': 22,
        u'ansible_ssh_user': u'root'
    }


# Generated at 2022-06-11 14:41:56.154148
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Parse test took from the Ansible's official one

    test_string = '''
    [webservers]
    foo.example.com

    [dbservers]
    one.example.com
    two.example.com
    three.example.com

    [datacenter:children]
    dbservers
    webservers
    '''

    inv = InventoryModule()
    inv.parse(test_string)

    assert len(inv.inventory.groups) == 2
    assert inv.inventory.groups['datacenter'].name == 'datacenter'
    assert inv.inventory.groups['datacenter']._children['dbservers'].name == 'dbservers'

# Generated at 2022-06-11 14:42:03.670598
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule("testhosts")

    # Test parsing of section [foo]
    inv._parse("testhosts", ["[foo]"])
    assert len(inv.groups) == 1
    assert "foo" in inv.groups
    assert len(inv.groups["foo"].get_hosts()) == 0

    # Test parsing of host a.b.c in section [foo]
    inv._parse("testhosts", ["[foo]", "a.b.c"])
    assert len(inv.groups) == 1
    assert "foo" in inv.groups
    assert len(inv.groups["foo"].get_hosts()) == 1
    assert len(inv.hosts) == 1
    assert "a.b.c" in inv.hosts

# Generated at 2022-06-11 14:42:11.873537
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    errors=[]
    for filename in test_inventory_paths:
        if filename.endswith(".ini"):
            data = to_text(open(filename, 'rb').read(100000), errors='surrogate_or_strict').split('\n')
            tmp = InventoryModule()
            try:
                tmp._parse(filename, data)
            except AnsibleError as e:
                errors.append(e)
    if errors:
        raise AnsibleError(to_native(errors))

#
# Inventory source parser for installing software packages
#

# Generated at 2022-06-11 14:42:24.396304
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-11 14:42:35.779228
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    if bool(os.environ.get('CI_RUN_TESTS', False)):
        pytest.skip('Tests against inventory modules cannot be run automatically on CI', allow_module_level=True)
    import tempfile
    fd, name = tempfile.mkstemp()
    os.write(fd, b'''[webservers]\nhost1\nhost2\n''')
    os.close(fd)
    im = InventoryModule()
    im.parse(name)
    # If there are no exceptions, then consider the method successful
    assert im.inventory.groups.get('webservers', None) is not None
    assert len(im.inventory.groups.get('webservers', [])) == 2
    assert im.inventory.groups['webservers'].hosts['host1']

# Generated at 2022-06-11 14:42:40.533060
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module._parse(path, data)
    assert inventory_module.groups == {'ungrouped': {'hosts': ['test1.example.com']}}

test_InventoryModule_parse()

# Class Ini file format parser

# Generated at 2022-06-11 14:42:52.630567
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.splitter import parse_kv
    from ansible.inventory.host import Host


# Generated at 2022-06-11 14:42:53.690156
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # FIXME
    assert False is True


# Generated at 2022-06-11 14:43:03.343797
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    import os.path
    import tempfile
    import shutil

    path = os.path.dirname(os.path.realpath(__file__))
    path = os.path.realpath(path + '/../test/unit/lib/ansible/inventory/')
    path = path + '/'

    fd, test_dir = tempfile.mkstemp(prefix='ansible_test_inventory_dir_')
    os.close(fd)


# Generated at 2022-06-11 14:43:07.221711
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Do a basic test of the parse method of class InventoryModule
    '''
    module = InventoryModule()
    inventory = InventoryManager(module)
    module._populate(inventory, "/dev/null")



# Generated at 2022-06-11 14:43:25.700949
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryManager(loader=None, sources=[])

    inventory.groups = {}
    inventory.hosts = {}

    mod = InventoryModule(inventory, os.path.join(os.path.dirname(__file__), '../data/inventory/host_vars'), 'host_vars')
    mod.parse()

    assert 'example.com' in inventory.groups['ungrouped'].hosts
    assert inventory.groups['ex_group_a'].vars['ex_var_a'] == 'foo'
    assert inventory.groups['ex_group_a'].vars['ex_var_b'] == 'bar'
    assert inventory.hosts['test.example.com'].vars['test_var'] == 'test'
    assert inventory.hosts['test.example.com'].vars['example_var']

# Generated at 2022-06-11 14:43:35.432144
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    path = "tests/unit/ansible/inventory/test_files/ini_sample_1"
    data = []
    lines = []
    with open(path, 'rb') as f:
        for line in f:
            lines.append(to_text(line, errors='surrogate_or_strict'))
            data.append(to_text(line, errors='surrogate_or_strict'))

    inv = Inventory(loader=DictDataLoader())
    inv.parse_inventory(lines)
    inventory = InventoryModule(loader=DictDataLoader())
    inventory._parse(path, data)
    assert inventory.inventory == inv


# Generated at 2022-06-11 14:43:43.166766
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print("START: test_InventoryModule_parse")
    inventory = Inventory(host_list=[])
    # TODO: Inventory requires a Hosts list, we should only pass it the option
    im = InventoryModule(inventory=inventory)
    # No error raise
    im.parse(path="", data=["", "#", " #", " # "])
    # No error raise
    im.parse(path="", data=["[test:children]", "[test2:children]", "test", "[test:vars]", "k=v"])
    print("END: test_InventoryModule_parse")


# Generated at 2022-06-11 14:43:48.142294
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # code goes here...
    m = AnsibleModule()
    data = '''
[my_group]
my_host ansible_user=foo
my_host2
    '''
    m.include = 'inventory_file.ini'
    InventoryModule.parse(m, data, m.include)



# Generated at 2022-06-11 14:43:57.275332
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    module.parse(u'host1')
    assert len(module.groups)==1
    assert len(module.groups['all'].hosts)==1
    #assert module.groups[u'all'].hosts[u'host1'].connection == 'ssh'
    #assert module.groups[u'all'].hosts[u'host1'].port == 22
    #assert module.groups[u'all'].hosts[u'host1'].has_variable('ansible_connection') == False

test_InventoryModule_parse()


# Generated at 2022-06-11 14:44:06.612798
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-11 14:44:09.497637
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print("\n====> Test parse()")
    # This method does not need to be tested
    print("\n====> Test parse() - DONE!")

# Generated at 2022-06-11 14:44:20.717234
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-11 14:44:25.653908
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """
    Test `parse` method of InventoryModule class
    """
    groups = dict()  # stores group objects
    hostvars = dict()  # stores host objects
    inventory = Inventory(hosts=hostvars, groups=groups)
    module = InventoryModule(inventory=inventory)
    assert(hasattr(module, 'parse'))



# Generated at 2022-06-11 14:44:35.342051
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Set up test fixture
    inventory = InventoryModule()
    inventory._filename = 'myfile'
    inventory._subset = None

    # Execute test
    inventory._parse('/path/to/file', ['# this is a comment', 'localhost:2222', '', '[group1]', 'me.example.com', 'ansible', 'localhost', '[group2:children]', 'group1', '', '[group3:vars]', 'somvar=someval', 'othervar =   otherval'])

    # Verify results
    assert inventory._subset is None
    assert inventory._filename == 'myfile'
    assert len(inventory.groups) == 3
    assert inventory.hosts['localhost'].groups == ['group1', 'ungrouped']

# Generated at 2022-06-11 14:45:04.555684
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule() 
    inventory_module.parse("sample_inventory/Hosts")
    assert inventory_module.inventory.groups["all"].get_host("localhost")
    assert inventory_module.inventory.groups["webservers"].get_host("192.168.1.1")
    assert inventory_module.inventory.groups["webservers"].get_host("192.168.1.2")
    assert inventory_module.inventory.groups["webservers"].get_host("192.168.1.3")
    assert inventory_module.inventory.groups["dbservers"].get_host("192.168.1.4")
    assert inventory_module.inventory.groups["dbservers"].get_host("192.168.1.5")
    assert inventory_module.inventory.groups

# Generated at 2022-06-11 14:45:15.156497
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    im = InventoryModule(None)


# Generated at 2022-06-11 14:45:25.403460
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module=InventoryModule()

# Generated at 2022-06-11 14:45:37.185094
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print('Testing method parse of class InventoryModule')
    inv = InventoryModule()
    inv.parse('/some/path', ['[group1]','[group2]','[group1:children]'])
    assert inv.inventory.groups['group1'].name == 'group1'
    assert inv.inventory.groups['group2'].name == 'group2'
    assert inv.inventory.groups['group1'].children == ['group2']
    inv.parse('/some/path', ['[group1]','[group3]','[group1:children]','[group3:children]'])
    assert inv.inventory.groups['group2'].name == 'group2'
    assert inv.inventory.groups['group3'].name == 'group3'
    assert inv.inventory.groups['group2'].children == ['group3']
   

# Generated at 2022-06-11 14:45:44.299840
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()
    # not using the full path for test cases to be simpler
    inv._parse(path="invalid inventory directory: /foo/bar/baz", lines=["[group1]", "foo", "  bar"])
    inv._parse(path="/foo/bar/baz", lines=["[group1]", "foo", "  bar"])
    inv._parse(path="/foo/bar/baz", lines=["[group1]", "foo", "bar"])
    inv._parse(path="/foo/bar/baz", lines=["[group1]", "foo"])
    inv._parse(path="/foo/bar/baz", lines=["[group1]"])

# Generated at 2022-06-11 14:45:50.839059
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # create a mock inventory
    inventory = Inventory(host_list=['localhost'])
    # create a mock InventoryModule
    inventory_module = InventoryModule(inventory, [])
    # call the parse method
    inventory_module._parse('path', ['[group]', 'localhost'])
    # assert if the group "group" is present
    assert "group" in inventory.groups
    # assert if localhost is in the group "group"
    assert "localhost" in inventory.groups["group"].hosts


# Generated at 2022-06-11 14:46:02.497512
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module._parse("/path/to/my.ini", """
[ungrouped]
# some tool
host01
host02:5309
host03:5309 sudo='true'

[groupname]
host04
host05:5439
host06:5439 sudo='true'

[anothergroup:vars]
foo = 'bar'
baz = ['one','two','three','four'] # a list

[anothergroup:children]
groupname

[notthere:children]
foobar
""".splitlines())
    assert inventory_module.inventory.groups["ungrouped"].get_hosts() == ["host01","host02","host03"]
    assert inventory_module.inventory.groups["ungrouped"].get_variables() == {}
    assert inventory_

# Generated at 2022-06-11 14:46:13.048181
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Checking for # Commented line at the end of the file
    inventory_yaml_input = '''
        [CommentedGroup]
        # Some hostname
        some_hostname

        [CommentedGroupTwo]
        # Some hostname
        some_hostname
        # The end
        '''

    the_inventory = InventoryModule()
    the_inventory._parse('test-inventory.yml', inventory_yaml_input.split('\n'))
    # Testing for the presence of the group
    assert 'CommentedGroup' in the_inventory.inventory.groups
    # Testing for the presence of the hostname
    assert 'some_hostname' in the_inventory.inventory.groups['CommentedGroup'].hosts
    # Testing for the presence of the group
    assert 'CommentedGroupTwo' in the_inventory.inventory.groups

# Generated at 2022-06-11 14:46:25.485187
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    obj = InventoryModule()

    # DataLoader mockup for test
    class DataLoaderMockup(object):
        def __init__(self):
            pass  

        def load_from_file(self, path):
            data = '[test]\nlocalhost\n[test2:children]\n[test2:vars]\nfoo=bar'
            return data

    # TODO: InventoryManager
    # -> Group
    # -> Host
    loader = DataLoaderMockup()
    inventory = InventoryManager(loader=loader, sources='/somefile')
    obj.inventory = inventory
    obj.patterns

# Generated at 2022-06-11 14:46:33.465645
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    data = '''
[groupname]
alpha
beta:2345 user=admin
gamma sudo=True user=root
'''
    module = InventoryModule()
    module._parse(None, data.split('\n'))
    assert len(module.inventory.groups) == 4
    assert 'groupname' in module.inventory.groups
    assert 'all' in module.inventory.groups
    assert 'groupname' in module.inventory.groups['groupname'].hosts
    assert 'alpha' in module.inventory.groups['groupname'].hosts
    assert 'beta' in module.inventory.groups['groupname'].hosts
    assert 'gamma' in module.inventory.groups['groupname'].hosts
    assert 'groupname' in module.inventory.hosts['alpha'].groups
    assert 'groupname' in module

# Generated at 2022-06-11 14:47:18.484009
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert 1 == 1


# Generated at 2022-06-11 14:47:28.379522
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Instantiate object of class InventoryModule
    import sys
    import ansible.inventory.manager

    # If method parse of class InventoryModule is implemented correctly
    # then we should be able to load a test inventory and verify that it is
    # successful.
    test_inventory_path = '/home/daniel/ansible/test/units/inventory/test_inventory_file'
    test_inventory = ansible.inventory.manager.InventoryManager('test_inventory')
    test_inventory_module = InventoryModule(test_inventory)

    try:
        test_inventory_module.parse(test_inventory_path, cache=False)
    except AnsibleParserError as e:
        sys.exit("Method parse of class InventoryModule failed to parse a test inventory file")


# Generated at 2022-06-11 14:47:30.125513
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # args = dict()
    # assert <condition> , "failed"
    assert True
test_InventoryModule_parse.unittest = ['.inventory', 'parse']
# END UNIT TEST

# BEGIN UNIT TEST

# Generated at 2022-06-11 14:47:31.808118
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()
    inv.parse("test/inventory/test_hosts")
    if inv.inventory.hosts:
        print("Parsing ok")
    else:
        print("Parsing error")

# Generated at 2022-06-11 14:47:33.122240
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import doctest
    doctest.testmod(InventoryModule)

# Generated at 2022-06-11 14:47:39.382198
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    import tempfile
    import os

    # Create temporary file for inventory
    fd, f = tempfile.mkstemp()
    os.write(fd, to_bytes("""
[test-group]
localhost

[test-group:vars]
ansible_user = vagrant
ansible_port = 22

[test-group2]
localhost ansible_user=vagrant ansible_port=22

[test-group3]
localhost ansible_user=vagrant ansible_port=22

[test-group3:vars]
ansible_user = root
"""))
    os.close(fd)

    # Test correct parsing
    iom = InventoryModule(loader=None, inventory=None)

    iom.parse(f)

    # Check if correct number of groups is found

# Generated at 2022-06-11 14:47:51.230240
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_host = 'host01'
    from ansible.inventory import Host, Inventory
    from ansible.parsing.yaml.dumper import AnsibleDumper

    inv = Inventory(loader=None)
    inv.add_host(test_host)
    inv.set_variable(test_host, 'myvar01', 'myvalue01')
    inv.add_group('mygroup')
    inv.add_child('mygroup', test_host)
    inv.set_variable('mygroup', 'myvar02', 'myvalue02')
    inv.add_host(test_host)
    inv.add_host(test_host)

    im = InventoryModule(loader=None, inventory=inv, vault_password=None)
    inv_data = inv.get_host_variables(test_host)
    inv_

# Generated at 2022-06-11 14:48:02.165662
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_data = """
        [all:variables]
        my_var=simple value
        my_dict={'key': 'test'}
        my_list=[0, 1]

        [test:children]
        children1
        children2

        [children1]
        localhost ansible_connection=local

        [children2]
        localhost ansible_connection=local
    """

    # Create an Inventory object from an inventory file path
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    inventory = Inventory(loader=DataLoader())
    inventory.parse_inventory(inventory_data)

    # Inventory contains groups and hosts
    groups = inventory.groups
    hosts = inventory.hosts
    host_names = [host.name for host in hosts]

    # Groups can

# Generated at 2022-06-11 14:48:11.236267
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create a mock inventory
    inventory = MagicMock()

    # Create a single mock for the class
    # and use it for all instances
    with patch('ansible.parsing.dataloader.get_file_contents', return_value='---\n'):
        mock_open = mock_open()

        # Make sure we patch the same object that is instantiated

# Generated at 2022-06-11 14:48:19.817204
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
  with open(os.getcwd()+'/inventory/hosts') as f:
    inv = HostInventory(loader=DataLoader())
    im = InventoryModule(loader=DataLoader(), inventory=inv)
    im.parse_inventory(f.name,None)
    inventory_keys = inv.groups.keys()
    assert 'all' in inventory_keys
    assert 'webservers' in inventory_keys
    assert 'dbservers' in inventory_keys
    assert 'ungrouped'in inventory_keys
    assert 'atlanta' in inventory_keys
    assert 'raleigh' in inventory_keys
    assert 'durham' in inventory_keys
    assert 'losangeles' in inventory_keys
    assert 'norcal' in inventory_keys
    assert 'orc' in inventory_keys
    assert 'chicago' in inventory

# Generated at 2022-06-11 14:49:55.557484
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    lines = [
        '[vagrant]',
        'localhost ansible_connection=local',
        '',
        '[vagrant:vars]',
        'ansible_python_interpreter="/usr/bin/python"'
    ]

    inv = InventoryModule('', lines)
    inv.parse()

    assert inv.get_host('localhost').vars['ansible_connection'] == 'local'
    assert inv.get_host('localhost').vars['ansible_python_interpreter'] == '/usr/bin/python'

# Generated at 2022-06-11 14:50:06.664692
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    class MockVarsModule:
        def __init__(self, module_name):
            self.module_name = module_name

    module = InventoryModule()
    inv = Inventory()
    module.set_inventory(inv)

    # Just a single host
    path = os.path.join(unit_path, 'hosts')
    module.parse(path)
    assert len(inv.groups) == 1
    assert 'test_group' in inv.groups
    assert len(inv.groups['test_group'].get_hosts()) == 1
    assert 'localhost' in inv.groups['test_group'].get_hosts()
    assert inv.groups['test_group'].get_host('localhost').port is None

# Generated at 2022-06-11 14:50:08.777744
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()
    inv.inventory = Inventory()
    inv._filename = "/test/path"
    inv.parse_from_file("/test/path")
    assert inv.inventory.groups['ungrouped'].hosts == {}
    assert inv.inventory.hosts == {}
    assert inv.inventory.groups['ungrouped'].vars == {}


# Generated at 2022-06-11 14:50:18.168273
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Unit tests for method InventoryModule.parse
    '''
    #######################################
    #
    # [unittest_InventoryModule_parse_1]
    #
    # Tests:
    #   InventoryModule.parse() with a non-existing file
    #
    #######################################

    path = os.path.join(C.DEFAULT_LOCAL_TMP, "non-existing_file")
    inventory_source = {
        "plugin": "auto",
        "host_filter": "all",
        "inventory": [path]
    }
    with pytest.raises(AnsibleParserError) as excinfo:
        InventoryModule(inventory_source)

    assert "The file %s does not exist\n" % path in excinfo.value.message

    #######################################
    #


# Generated at 2022-06-11 14:50:27.308029
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module._raise_error = lambda self, message: raise_(AnsibleParserError, message)
    inventory_module._parse_value = lambda self, v: v
    inventory_module._parse_host_definition = lambda self, line: (list(shlex_split(line)), None, {})
    inventory_module._expand_hostpattern = lambda self, hostpattern: (list(shlex_split(hostpattern)), None)
    inventory_module._compile_patterns()

    inventory_module._parse(filename='myfile', lines=[
        '[oldgroup]', 'host1 host2',
        '[newgroup]', 'host3 host4',
        '[newgroup:vars]', 'j=k',
    ])