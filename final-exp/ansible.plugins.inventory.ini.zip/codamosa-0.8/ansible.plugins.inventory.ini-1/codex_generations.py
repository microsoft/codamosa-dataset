

# Generated at 2022-06-11 14:40:43.310633
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    mod = InventoryModule()

    inventory_path = os.path.join('test', 'test_inventory_testcase.yml')
    mod._parse(inventory_path, None)
    assert len(mod.inventory.groups) is 2

    inventory_path = os.path.join('test', 'test_inventory_testcase2.yml')
    mod._parse(inventory_path, None)
    assert len(mod.inventory.groups) is 3

    inventory_path = os.path.join('test', 'test_inventory_testcase3.yml')
    mod._parse(inventory_path, None)
    assert len(mod.inventory.groups) is 4

    inventory_path = os.path.join('test', 'test_inventory_testcase4.yml')
    mod._parse(inventory_path, None)

# Generated at 2022-06-11 14:40:49.059271
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_instance = InventoryModule()
    inventory_instance._options = {}
    inventory_instance._options['host_pattern'] = r'^([^:]*):?([0-9]{1,5})?$'
    inventory_instance._options['host_list'] = None
    inventory_instance._options['groups'] = None
    inventory_instance.inventory = InventoryManager(None)

    # test for an inventory file with an error in it
    inventory_file = tempfile.NamedTemporaryFile()
    inventory_file.write(b'[group1]\n')
    inventory_file.write(b'[group2 # this is illegal\n')
    inventory_file.flush()

    inventory_instance._options['host_file'] = inventory_file.name
    inventory_instance._options['inventory'] = inventory_file.name



# Generated at 2022-06-11 14:40:53.170865
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    filename = 'test_file'
    data = ["[group]",
            "test:test.org"]
    inv = InventoryModule()
    inv._parse(filename, data)
    assert inv.inventory.groups == {'group': {'hosts': ['test', 'test.org'], 'vars': {}}}

# Generated at 2022-06-11 14:41:04.937085
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Instantiate the class and get the parse method

    inventory_module = InventoryModule()
    parse_method = inventory_module.parse
    parse_method.__func__.__doc__ = '''
    Populates this inventory by parsing the contents of a file or list (of lines)
    '''

    # Test the contents of the doctest docstring
    expected_output = {
        'all': {
            'hosts': ['testhost'],
            'vars': {'testhostvar': 'testvalue'}
        },
        'ungrouped': {
            'hosts': ['testhost'],
            'vars': {'testhostvar': 'testvalue'}
        }
    }


# Generated at 2022-06-11 14:41:08.282491
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-11 14:41:20.608877
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    test_data = '''
[test]
foo
bar:17 user=steve
baz sudo=True user=foo # comment
'''

    module._parse('test', test_data.split('\n'))

    assert 'test' in module.inventory.groups
    group = module.inventory.groups['test']

    assert group.name == 'test'
    assert group.vars == {}

    assert len(group.children) == 0
    assert len(group.hosts) == 3

    foo = group.get_host('foo')
    bar = group.get_host('bar')
    baz = group.get_host('baz')

    assert foo.name == 'foo'

# Generated at 2022-06-11 14:41:21.954547
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    h = InventoryModule('hosts.ini')


# Generated at 2022-06-11 14:41:33.814172
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import sys
    import os

    # Check that the module can be loaded successfully
    im = InventoryModule()
    assert im is not None

    file_path = os.path.join(os.path.dirname(__file__), '../../../', 'contrib/inventory/test/inventory_sample')

    # Check that the sample inventory can be loaded without errors
    try:
        im._parse(file_path, file(file_path).readlines())
    except AnsibleError as e:
        assert False, "Error when parsing sample inventory: %s" % str(e)

    # Check that the sample inventory has parsed correctly
    assert 'test' in im.inventory.groups
    assert 'test2' in im.inventory.groups
    assert 'test3' in im.inventory.groups
    assert 'test4' in im.inventory.groups

# Generated at 2022-06-11 14:41:43.571313
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    constructor_test_cases = [
        # Each list item is a test case tuple with these items:
        # * desc: Short test case description.
        # * kwargs: Keyword arguments for the test case.
        # * exp_msg: Expected exception message or None.
        ('no params', dict(), None),
    ]

    for desc, kwargs, exp_msg in constructor_test_cases:
        if exp_msg is None:
            InventoryModule(**kwargs)

        else:
            with pytest.raises(AnsibleParserError) as excinfo:
                InventoryModule(**kwargs)
            assert exp_msg == to_text(excinfo.value)

# Unit test class for method _compile_patterns of class InventoryModule

# Generated at 2022-06-11 14:41:46.349973
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    config_path = 'tests/inventory/'
    i = Inventory(config_path)
    inv = InventoryModule(i)
    inv.parse('hosts')


# Generated at 2022-06-11 14:42:15.809566
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    path = "/etc/ansible/hosts"
    lines = []

    lines.append("# This is a comment")
    lines.append("")
    lines.append("[local]")
    lines.append("localhost")
    lines.append("")
    lines.append("[local:vars]")
    lines.append("ansible_connection=local")
    lines.append("")
    lines.append("[testme]")
    lines.append("testserver.example.org")
    lines.append("")
    lines.append("[testme:vars]")
    lines.append("ansible_user=michael")
    lines.append("ansible_ssh_pass=testing")
    lines.append("")
    lines.append("[web]")
    lines.append("www1.example.com")


# Generated at 2022-06-11 14:42:28.031072
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from StringIO import StringIO

    string_inventory = StringIO("""
        [test1]
        192.168.1.10:10022
        192.168.1.11
        192.168.1.12
        usr=asd
        [test2:vars]
        [test3:children]
    """)

    inventory_module = InventoryModule(None)

    inventory_module._parse(string_inventory.name, string_inventory.readlines())

    assert inventory_module.inventory.groups[0].name == 'test2'
    assert inventory_module.inventory.groups[1].name == 'test3'
    assert inventory_module.inventory.groups[2].name == 'test1'
    assert inventory_module.inventory.groups[2].hosts[0].name == '192.168.1.10'

# Generated at 2022-06-11 14:42:37.773786
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Unit test of parse method of class InventoryModule
    '''

    inventory = dict()
    c = InventoryModule(inventory)
    # test that when unparsable YAML is present, we report the line number.
    # The parse function of InventoryModule overrides the method in
    # InventoryFile common, but is still parsing the file contents into a
    # string array. This means we can test by passing the contents to parse.
    # We have to have at least one valid host entry to bypass other parsing
    # errors.

# Generated at 2022-06-11 14:42:49.982705
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    
    try:
        # Invalid section name
        ansible_source = "[somegroup1:vars]"
        m = InventoryModule()
        m.parse(ansible_source, "")
    except AnsibleParserError as e:
        assert 'empty group name' in to_text(e)

    try:
        # Invalid host pattern
        ansible_source = "[somegroup]\nhostname:port"
        m = InventoryModule()
        m.parse(ansible_source, "")
    except AnsibleParserError as e:
        assert 'host pattern' in to_text(e)


# Generated at 2022-06-11 14:42:54.733903
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Unit test for method parse of class InventoryModule
    '''

    # Create an instance of class InventoryModule
    inventory_module = InventoryModule()
    inventory_module.parse('example.yml', '''
        [webservers]
        one.example.org
        two.example.org
    ''')

# Generated at 2022-06-11 14:43:04.689061
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # First create an instance of InventoryModule
    inventoryModule = InventoryModule()
    # The file we are testing has the following content:
    filecontent = """
[webservers]
mywebserver

[webservers:vars]
myvar1=42
myvar2=foo
"""
    # Now we try to parse it. This should raise an AnsibleError exception as vars are not allowed for groups
    # unless the group has already been declared
    try:
        inventoryModule._parse('/tmp/ansible_test', filecontent.split('\n'))
    except AnsibleError as e:
        # This is expected, so we just pass
        pass
    else:
        # If the test doesn't raise an exception as expected, we need to raise an error
        assert False, 'Expected an AnsibleError exception'


# Generated at 2022-06-11 14:43:17.062506
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    IM = InventoryModule.__new__(InventoryModule)
    # init module
    IM._init_vars()
    # prepare fake play
    mock_play = MagicMock()
    mock_play.connection = 'smart'
    # prepare inventory
    mock_inventory = MagicMock()
    mock_inventory.extra_vars = {'a': '1'}
    mock_inventory._subset = None
    mock_inventory._restriction = None
    # prepare basic inventory
    inventory = u"""[ungrouped]
localhost ansible_connection=local

[all:vars]
ansible_ssh_port=22
ansible_python_interpreter=/usr/bin/python"""
    # write fake inventory file
    tempf = tempfile.NamedTemporaryFile()

# Generated at 2022-06-11 14:43:25.322381
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-11 14:43:34.679160
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = get_inventory_module()
    data = inventory_module.get_inventory_object(None, host_list=['dummy_host'])

    filename = os.path.abspath(os.path.join(__file__, '../../../lib/ansible/inventory/dummy_hosts'))
    inventory_module.parse(filename, data)
    assert len(data.groups.keys()) == 4
    assert 'group1' in data.groups
    assert 'group2' in data.groups
    assert 'group3' in data.groups
    assert 'all' in data.groups



# Generated at 2022-06-11 14:43:38.871901
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryModule()
    inventory.parse('[groupname]\n# comment\n1.2.3.4')
    assert inventory.inventory.groups['groupname'].hosts[0].name == '1.2.3.4'

# Generated at 2022-06-11 14:44:29.339241
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv_mod = InventoryModule()
    inv_mod.inventory.add_host("host1", "host1")
    inv_mod.get_option("key1", "value1")
    inv_mod.set_option("key2", "value2")
    inv_mod.get_option("key3", "value3")
    inv_mod.get_option("key4", "value4")
    inv_mod.get_option("key5", "value5")
    inv_mod.get_option("key6", "value6")
    inv_mod.get_option("key7", "value7")
    inv_mod.get_option("key8", "value8")
    inv_mod.get_option("key9", "value9")
    inv_mod.get_option("key10", "value10")
   

# Generated at 2022-06-11 14:44:37.434697
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = AnsibleModule(argument_spec=dict())
    lines = []
    lines.append('[group1]')
    lines.append('host1')
    lines.append('[group2]')
    lines.append('host2')
    lines.append('[group1:vars]')
    lines.append('var1=test')
    lines.append('[group2:vars]')
    lines.append('var1=test')
    inventory_path = os.path.join(ANSIBLE_INVENTORY, 'test.yaml')
    with open(inventory_path, 'w') as f:
        for line in lines:
            f.write(line+'\n')
    inventory_path = os.path.join(ANSIBLE_INVENTORY, 'test.yaml')
    inventory_object

# Generated at 2022-06-11 14:44:48.141006
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    module._filename = 'dummy'
    # empty
    module.parse([])
    # host only
    module.parse(['host1'])
    # host with port
    module.parse(['host1:123'])
    # host with port and variables
    module.parse(['host1:123 name=something'])
    # comments with EOF whitespace
    module.parse(['host1 name=something  # foo', '# bar', ' '])
    # comments with EOF whitespace and blank lines
    module.parse(['host1 name=something  # foo', '', '# bar', ' '])
    # various definitions without [], with comments

# Generated at 2022-06-11 14:44:58.018654
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()

    test_case = '''
[group1]
foo.example.org
bar.example.org

[group1:vars]
ansible_ssh_user=test_user
ansible_ssh_pass='test_pass'
test_var=test_value
test_array=[test_value1, test2, "test3"]
test_dict={ test1: 1, test2: 2, test3: 3, test4: "test", test5: "test" }
test_var_with_no_value

[group2]
baz.example.org
'''

    lines = test_case.splitlines()
    inv._parse('test_path', lines)
    hostnames = inv.inventory.get_hosts()
    res = [x.name for x in hostnames]


# Generated at 2022-06-11 14:44:59.818581
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv_mod = InventoryModule()
    inv_mod.parse('test_inv', './test/test_ansible_hosts', None)



# Generated at 2022-06-11 14:45:11.438038
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-11 14:45:14.176629
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    with pytest.raises(Exception) as e_info:
        i = InventoryModule()
        i.parse()
    assert e_info.value.message == 'Attempted to parse without a filename'



# Generated at 2022-06-11 14:45:24.331679
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.vault import VaultLib
    from ansible import context
    from ansible.cli.adhoc import AdHocCLI


# Generated at 2022-06-11 14:45:25.569559
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert True


# Generated at 2022-06-11 14:45:31.072089
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()
    inv._parse('', [
        '[web]',
        'host1',
        'host2'
    ])

    assert len(inv.groups['web']['hosts']) == 2
    assert inv.groups['web']['hosts'] == ['host1', 'host2']

# Generated at 2022-06-11 14:46:13.485997
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryModule()
    path = './test_inventory.yaml'
    inventory._parse(path, ['localhost ansible_ssh_host=localhost'])


# Generated at 2022-06-11 14:46:25.945404
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create a fake loader plugin to be used by the inventory
    class TestLoader(object):
        def __init__(self, inventory, loader, path, cache=True, vault_password=None):
            pass

        def load(self, filepath):
            return dict()

    # Create a fake vault plugin to be used by the inventory
    class TestVault(object):
        def __init__(self, inventory, vault_password=None):
            pass

        def decrypt(self, vault_data):
            return dict()


# Generated at 2022-06-11 14:46:30.821186
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_mod = InventoryModule()
    inventory_mod.inventory = Inventory()
    inventory_mod._parse('/home/user/.ansible/inventory', ['localhost', 'foo.bar.com:8080'])
    assert len(inventory_mod.inventory.groups) == 1
    assert inventory_mod.inventory.groups['ungrouped'].get_hosts() == ['foo.bar.com:8080']



# Generated at 2022-06-11 14:46:41.297610
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import os
    import tempfile

    test_dir = os.path.dirname(__file__)
    test_data_dir = os.path.join(test_dir, '../data')
    inventory_file = os.path.join(test_data_dir, 'plugin_inventory.yml')
    inventory = InventoryModule(loader=None)

    # Make sure all groups in inventory are loaded
    inventory.parse(inventory_file, 'yaml')
    for group, group_attributes in inventory.groups.items():
        assert group_attributes.name == group
        for host in group_attributes.hosts:
            assert host.name in group_attributes.hosts
            assert host.port is None
        for parent_group in group_attributes.get_ancestors():
            assert parent_group.get_name

# Generated at 2022-06-11 14:46:51.842856
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_file = """
    # pass
    # This is a comment and will be ignored, except for empty lines above
    [ungrouped]
    foo ansible_ssh_host=10.0.0.1
    [nope]
    a1.example.org
    #[already_defined]
    # 192.168.1.99
    # 192.168.99.88

    [group1]
    foo ansible_ssh_host=10.0.0.1
    [group2:vars]
    ntp_server=10.0.0.1
    """

    inventory_object = InventoryModule()
    inventory_object._parse(FakeFilename("unused"), inventory_file.splitlines(True))

    assert inventory_object.inventory.groups['ungrouped'].name == 'ungrouped'


# Generated at 2022-06-11 14:46:54.203845
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryModule()
    assert inventory.parse(get_fixture_path('inventory')) == None


# Generated at 2022-06-11 14:47:05.666912
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryModule()
    inventory.parse(['host1', 'host2:2', 'host3:','host4:3 hostname=host4', 'host5:33 hostname=host5 ansible_ssh_port=4444 ansible_ssh_pass=mypass', 'host6:33 ansible_ssh_port=5555'])
    assert inventory.get_host("host1") is not None
    assert inventory.get_host("host2").get_vars()['ansible_ssh_port'] == 2
    assert inventory.get_host("host3") is not None
    assert inventory.get_host("host4").get_vars()['ansible_ssh_port'] == 3
    assert inventory.get_host("host4").get_vars()['hostname'] == 'host4'
    assert inventory.get_

# Generated at 2022-06-11 14:47:16.061818
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create a test inventory for this unit test.
    inventory = InventoryManager(loader=DataLoader())
    custom_inventory = InventoryModule(inventory)

    # The example inventory given in the module source file.

# Generated at 2022-06-11 14:47:26.551007
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''InventoryModule.parse'''

    InventoryModule = ansible.parsing.inventory.InventoryModule
    mod = InventoryModule()

    # this is the test data that should produce the correct data

# Generated at 2022-06-11 14:47:35.635851
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    path = os.path.join(os.path.dirname(__file__), "data", "test_inventory.ini")
    inventory = InventoryModule()
    inventory.parse(path)
    assert len(inventory.groups.items()) == 4
    assert inventory.groups['group1']
    assert inventory.groups['group1'].name == 'group1'
    assert inventory.groups['group1'].variables == {}
    assert inventory.groups['group1'].children == []
    assert inventory.groups['group1'].hosts == [ 'host1', 'host2' ]

    assert inventory.groups['group2']
    assert inventory.groups['group2'].name == 'group2'
    assert inventory.groups['group2'].variables == { 'k1':'v1', 'k2':'v2' }
   

# Generated at 2022-06-11 14:49:12.485863
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    mock_path = MagicMock()
    mock_data = MagicMock()
    module._parse = MagicMock()
    module.parse(mock_path, mock_data)
    module._parse.assert_called_with(mock_path, mock_data)


# Generated at 2022-06-11 14:49:22.542805
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Unit tests for method parse
    '''
    import json
    import os
    import shutil
    import tempfile
    import unittest

    # FIXME: Provide tests for the parser.

    global class_instance
    if class_instance is None:
        raise Exception('InventoryModule class not instantiated')

    # TODO: Find a way to not require the role here.
    # TODO: Find a way to not require the role here.
    class_instance._basedir = './tests/support/'

    # TODO: Find a way to not require the role here.
    class_instance._basedir = './tests/support/'

    class_instance._filename = './tests/units/inventory/test_file'

    #from ansible.playbook.play_context import PlayContext
    #class_

# Generated at 2022-06-11 14:49:34.392717
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_file = NamedTemporaryFile()
    test_file_name = test_file.name
    test_file.close()
    test_dir = mkdtemp(dir="/tmp")
    test_dir_name = os.path.basename(test_dir)

# Generated at 2022-06-11 14:49:45.220695
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    host_list = '''[groupname]
                alpha
                beta:2345 user=admin      # we'll tell shlex
                gamma sudo=True user=root # to ignore comments
                '''
    temp_filename = 'test_inventory.txt'
    with open(temp_filename, 'w') as fh:
      fh.write(host_list)
    inventory_obj = InventoryModule()
    inventory_obj.parse(temp_filename)

    assert inventory_obj.inventory.groups['groupname'].get_hosts()[0].name == 'alpha'
    assert inventory_obj.inventory.groups['groupname'].get_hosts()[1].name == 'beta'
    assert inventory_obj.inventory.groups['groupname'].get_hosts()[1].port == 2345
    assert inventory_obj.inventory

# Generated at 2022-06-11 14:49:51.328942
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    parser = AnsibleInventoryParser('/foo/bar/inventory')
    parser._parse("path","lines as array")
    assert parser.inventory.groups["ungrouped"].get_vars()['children'] == 'all'
    assert parser.inventory.groups["all"].get_vars()['test'] == 'test'

test_InventoryModule_parse()
# wrap public interface functions to ensure that a single 'parser' object is used


# Generated at 2022-06-11 14:50:00.069288
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Testing inventory and group creation from file.
    inventory_file = [
        "[all]",
        "foo:2222",
        "bar",
        "baz ansible_ssh_port=3333",
        "[webservers]",
        "foobar",
        "foobaz",
        "[dbservers]",
        "barbaz",
        "[somenonesense]",
        "foobarbaz",
    ]

    # Testing that port number is properly set using the following file.
    inventory_file_ports = [
        "[all]",
        "foo:2222",
        "bar:3333",
        "baz",
    ]

    # Testing that host vars are properly set with the following file.

# Generated at 2022-06-11 14:50:11.515397
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = Inventory('/xyz')
    mod = InventoryModule(loader=None, inventory=inventory, path='/xyz')
    data = ['# first line', '[group1]', '# second line', '   # third line', '[group2:vars]', 'var1=value1', 'var2=value2', '[group3:children]', 'group4', '[group4]', 'host1', 'host2']
    mod._parse('/xyz', data)
    assert 'group1' in inventory.groups
    assert 'group2' in inventory.groups
    assert 'group3' in inventory.groups
    assert 'group4' in inventory.groups
    assert 'host1' in inventory.hosts
    assert 'host2' in inventory.hosts
    assert inventory.groups['group2'].get_vars() == dict

# Generated at 2022-06-11 14:50:19.549255
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    host_data = '''
[test]
localhost

[test:vars]
ansible_connection=local
'''
    host_file = open(test_host_file, 'w')
    host_file.write(host_data)
    host_file.close()

    path_to_host_file = os.path.abspath(test_host_file)

    inventory = InventoryManager(ModuleLoader())
    # Clear any possible previous data in the inventory.
    inventory = InventoryManager(ModuleLoader())
    yaml_inventory = InventoryModule(loader=None, sources=[path_to_host_file])
    yaml_inventory.parse(path_to_host_file)

    assert 'test' in yaml_inventory.groups
    assert 'localhost' in yaml_inventory.groups['test'].hosts
   