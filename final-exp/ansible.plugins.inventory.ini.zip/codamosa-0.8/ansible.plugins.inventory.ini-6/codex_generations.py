

# Generated at 2022-06-11 14:40:31.557432
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """Test InventoryModule.parse"""
    module = AnsibleModule()
    # TODO: implement basic test for InventoryModule.parse
    assert False


# Generated at 2022-06-11 14:40:33.139687
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert False, "Unit test not implemented."


# Generated at 2022-06-11 14:40:35.033913
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    for test in bad_ini_tests:
        yield parse_bad_ini_test, test


# Generated at 2022-06-11 14:40:42.382039
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test a clean configuration
    test_string = to_bytes(
    '''[test_group]
    test_host_a''')
    inventory = Inventory(loader=_load(test_string))
    inv_dict = inventory.get_host_vars_dict()
    assert 'test_host_a' in inv_dict
    assert 'test_group' in inventory.groups
    assert 'test_host_a' in inventory.groups['test_group'].get_hosts()


# Generated at 2022-06-11 14:40:53.594531
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-11 14:41:05.440907
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    #This is a template test, you can write your own test here
    #assert 0, "TODO: Write your own test"
    # AssertionError: TODO: Write your own test
    # This test is just a placeholder to get you started
    # with writing your own tests

    # Here's an example of how you might write a test to check
    # that the output of a method called 'foo' is as expected:

    #obj = InventoryModule()
    # actual = obj.foo(param)
    # expected = 'expected value'
    # assert actual == expected

    # Here's an example of how you might write a test to check
    # that a method called 'foo' raises a particular exception:

    #obj = InventoryModule()
    # raises(Exception, obj.foo, params)

    obj = InventoryModule()
    #obj.

# Generated at 2022-06-11 14:41:16.802445
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryModule()
    inventory.parse('''
        [unreachable]
        unreachable.example.com    # this host will have its connection type set to 'local'
        unreachable.example2.com    # this host will have its connection type set to 'local'

        [webservers]
        foo.example.com

        [dbservers]
        one.example.com
        two.example.com
        three.example.com

        [ungrouped]
        192.168.1.100
        192.168.1.101
        192.168.1.102
        foobar.example.com
    ''')

    assert type(inventory.hosts) == dict
    assert len(inventory.hosts) == 9

    assert type(inventory.groups) == dict

# Generated at 2022-06-11 14:41:26.304867
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """Unit test for method parse of class InventoryModule"""
    dummy_get_config = lambda x: {}
    dummy_get_option = lambda x: ''
    dummy_inventory = MagicMock()
    dummy_inventory.set_variable = MagicMock()
    dummy_inventory.add_group = MagicMock()
    dummy_inventory.add_host = MagicMock()
    dummy_inventory.add_child = MagicMock()
    dummy_loader = MagicMock()
    im = InventoryModule(
        loader=dummy_loader,
        inventory=dummy_inventory,
        get_option=dummy_get_option,
        get_config=dummy_get_config,
    )
    im._filename = "test_filename"
    im.lineno = 0


# Generated at 2022-06-11 14:41:38.177519
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    from ansible.cli.playbook import PlaybookCLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-11 14:41:46.068465
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
  sections = '\n'.join([
    '[localhost]',
    'localhost ansible_connection=local',
    '[testgroup:children]',
    'group1',
    'group2',
    '[group1:vars]',
    'var1=group1 var1 val',
    'var2=group1 var2 val',
    'var3=group1 var3 val',
    '[group1]',
    'localhost'])
  inventory_module = InventoryModule()

  d = inventory_module.parse(sections)

  assert d['localhost']['var1'] == "group1 var1 val"
  assert d['localhost']['var2'] == "group1 var2 val"
  assert d['localhost']['var3'] == "group1 var3 val"

# Generated at 2022-06-11 14:42:03.779757
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    path = os.path.join(config.data_prefix, 'inventory.ini')
    inventory = InventoryModule()
    inventory.parse(path, cache=False)
    # Test hosts
    hosts = inventory.get_hosts()
    assert hosts == ['example.com', 'server.example.com']
    # Test groups
    groups = inventory.get_groups_dict()
    assert groups.keys() == ['group1', 'subgroup1', 'subgroup2', 'subgroup3', 'subgroup4']
    assert groups['subgroup1'] == ['example.com']
    assert groups['subgroup2'] == ['server.example.com']
    assert groups['subgroup3'] == ['example.com', 'server.example.com']
    assert groups['subgroup4'] == ['example.com', 'server.example.com']
   

# Generated at 2022-06-11 14:42:13.941194
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Inventory definition is 
    # [group1]
    # host1  ansible_host=1.1.1.1
    # host2  ansible_host=2.2.2.2
    filename = './test_inventory1'
    print("testing %s" % filename)
    inv = InventoryModule(filename)
    inv.parse()
    for host in inv.inventory.get_hosts():
        print("%s has hostname:%s, port:%s, variables:%s" % (host.name, host.vars.get('ansible_host', host.name), host.port, host.vars))
    assert inv.inventory.get_groups_dict()['all']['hosts'] == ['host1', 'host2']

# Generated at 2022-06-11 14:42:26.071116
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    with pytest.raises(AnsibleError) as e_info:
        InventoryModule('testmodule.yml').parse()
    assert 'testmodule.yml:0' in str(e_info.value)
    assert '#!/bin/sh' in str(e_info.value)
    assert 'Invalid section entry:' in str(e_info.value)

    with pytest.raises(AnsibleError) as e_info:
        InventoryModule('testmodule2.yml', loader=DataLoader()).parse()
    assert 'testmodule2.yml:0' in str(e_info.value)
    assert '#!/bin/sh' in str(e_info.value)
    assert 'Invalid section entry:' in str(e_info.value)

# Generated at 2022-06-11 14:42:35.104435
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    invmod = InventoryModule()
    invmod._parse('/path/to/inventory', ['[first_group]', '1.1.1.1', '[second_group:children]', 'first_group', '[second_group:vars]', 'foo=bar'])
    assert invmod.inventory.groups == {'first_group': {'hosts': {'1.1.1.1': {'vars': {}}}, 'children': []}, 'second_group': {'hosts': {}, 'children': ['first_group'], 'vars': {'foo': 'bar'}}}


# Generated at 2022-06-11 14:42:47.683726
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    lines = [
        "[web]",
        "foo ansible_ssh_host=1.2.3.4 ansible_connection=local",
        "bar",
        "[webservers:vars]",
        "http_port=80",
        "maxRequestsPerChild=808",
        "# comment",
        "max_clients=909",
        "[test:vars]",
        "ansible_ssh_host=2.3.4.5 ansible_port=22 ansible_connection=ssh ansible_user=test",
    ]
    module._parse('/tmp/test', lines)
    assert 'webservers' in module.inventory.groups
    assert 'web' in module.inventory.groups
    assert 'test' in module.inventory.groups

# Generated at 2022-06-11 14:42:50.333270
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule(Inventory())
    inv.parse("test/inventory/test_ini_parser", 'foo')


# Generated at 2022-06-11 14:42:56.237524
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryManager(Loader())
    inventory._options = Options()

    im = InventoryModule(inventory, "test_parse")
    im.parse("[group1]\nhost1\nhost2")
    data = inventory.get_host("host1")
    assert data.get_vars() == {}, "Fail: inventory module parse"
    assert im.inventory.groups["group1"].get_hosts() == ["host1", "host2"]


# Generated at 2022-06-11 14:43:06.074274
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryModule()
    inventory._filename = 'sample'
    inventory._parse([
        '[localhost]',
        'localhost',
        'foo=bar',
        '[otherhosts]',
        'host0 host1',
        '[otherhosts:vars]',
        'ansible_user=root',
        '[ungrouped]',
        '[ungrouped:vars]',
        'ansible_user=root',
        '[group1:children]',
        'group2',
        '[group2:children]',
        'all:!ungrouped'
    ])


# Generated at 2022-06-11 14:43:18.202838
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test if InventoryModule().parse() raises the correct exception (if any)
    # when fed invalid input.

    # Test for correct error message on empty inventory
    try:
        InventoryModule().parse_inventory(inventory_file=[''])
        raise AssertionError("No error raised on empty inventory")
    except AnsibleParserError as e:
        assert e.message == 'No group or host definitions found in provided inventory source(s)'

    # Test for correct error message on invalid syntax
    try:
        InventoryModule().parse_inventory(inventory_file=['!invalid'])
    except AnsibleParserError as e:
        assert e.message == "Error parsing host definition '!invalid': No closing quotation"

    # Test for correct error message on invalid host pattern

# Generated at 2022-06-11 14:43:25.813773
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    i=InventoryModule(None)
    path="my_file"

# Generated at 2022-06-11 14:43:56.361018
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # This method is used internally to generate a configuration dictionary
    def create_ini_file(filename, conf):
        with open(filename, 'w') as f:
            f.write(conf)

    # Generate a configuration file
    ini_file = '/tmp/ansible_test_inventory.ini'
    test_conf = """
# Comments are allowed
[ungrouped]
    localhost ansible_connection=local
    192.168.1.1
    default ansible_ssh_user=root ansible_ssh_port=22

[othergroup]
    # Another comment
    192.168.1.2 ansible_ssh_user=foo

[newgroup:children]
    othergroup
"""
    create_ini_file(ini_file, test_conf)

    # Instantiate a Hosts object from such configuration

# Generated at 2022-06-11 14:44:06.077401
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.read_file("tests/inventory/vault")
    inventory_module.parse("tests/inventory/vault", ["[group]", "localhost ansible_connection=local ansible_python_interpreter=/usr/bin/python3"], True)
    inventory_module.parse("tests/inventory/vault", ["[group:vars]", "key1=value1 key2=value2"], True)
    inventory_module.parse("tests/inventory/vault", ["[group]", "localhost ansible_connection=local ansible_python_interpreter=/usr/bin/python3", "[group:vars]", "key1=value1 key2=value2"], True)

# Generated at 2022-06-11 14:44:17.616289
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
	#data = '''[ungrouped]
	#test-test-test
	#test-test-test:22
	#test-test-test:2222
	#test-test-test:2223
	#test-test-test:2224
	#test-test-test:2225
	#test-test-test:2226
	#test-test-test:2227
	#test-test-test:2228
	#[ungrouped]
	#[ungrouped]
	#[ungrouped]
	#[ungrouped]
	#'''
	with open('/tmp/inventory') as f:
		data = f.readlines()

	inventory = InventoryModule()
	inventory._parse('/tmp/inventory', data)

# Generated at 2022-06-11 14:44:28.576044
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    data = '''
[group1]
host1.example.org

[group2]
host2.example.org
host3.example.org

[group2:vars]
foo = bar
'''
    im = InventoryModule()
    im.read_string(data)
    hosts = im._hosts_cache
    assert(hosts == {
        'host1.example.org': [ 'group1' ],
        'host2.example.org': [ 'group2' ],
        'host3.example.org': [ 'group2' ],
    })
    groups = im._groups_cache

# Generated at 2022-06-11 14:44:37.042118
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-11 14:44:38.694681
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryModule()
    inventory.parse('localhost')

# Generated at 2022-06-11 14:44:48.396939
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_file_path = "./test_inventory.ini"

    inventory_ini_content = '''
[report_servers]
# comment
10.0.0.1:2222                user=myuser # comment
10.0.0.2
    '''
    with open(inventory_file_path, "w") as f:
        f.write(inventory_ini_content)

    inventory_module = InventoryModule()
    inventory_module.parse(inventory_file_path, False)

    inventory = inventory_module.inventory
    inventory.clear_pattern_cache()

    assert inventory.list_hosts("report_servers") == ["10.0.0.1", "10.0.0.2"]


# Generated at 2022-06-11 14:44:58.257400
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Unit test for method parse of class InventoryModule
    '''
    inventory_module = InventoryModule()
    file_name = 'test_yaml.yml'
    inventory = Inventory()
    inventory_module._parse(file_name, ['[group1:children]', 'group2', 'group3'])
    assert 'group1' in inventory.groups
    assert 'group2' in inventory.groups
    assert 'group3' in inventory.groups
    assert len(inventory.groups['group2'].parents) == 0
    assert len(inventory.groups['group3'].parents) == 0
    assert len(inventory.groups['group1'].children) == 2


# Generated at 2022-06-11 14:45:10.033651
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    invfile = 'test/assets/test_inventory.ini'
    module.parse(invfile)
    assert module.inventory.groups['test_group'].hosts['hostA'].vars['ansible_port'] == '22'
    assert module.inventory.groups['test_group'].hosts['hostB'].vars['ansible_port'] == '22'
    assert module.inventory.groups['test_group'].hosts['hostC'].vars['ansible_port'] == '22'
    assert module.inventory.groups['test_group'].vars['group_var'] == 'bar'
    assert module.inventory.groups['test_group'].children['child_group'].vars['child_var'] == 'foo'

# Generated at 2022-06-11 14:45:15.450496
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryModule()
    inventory._parse("~/ansible/ansible.cfg", ["[dev:vars]", "ansible_ssh_user=root", "ansible_ssh_pass=secretpassword", "[dev]", "server1", "server2"])
    assert inventory.inventory.groups == dict()
    return inventory

inventory = test_InventoryModule_parse()

# Testing the print_groups method of InventoryModule

# Generated at 2022-06-11 14:45:58.153232
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse('foo/bar')
    #assert inventory_module is True
    #assert inventory_module is True
    #assert inventory_module is True

# Generated at 2022-06-11 14:46:05.613120
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_mod = InventoryModule()


# Generated at 2022-06-11 14:46:14.704173
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    c = InventoryModule()
    path = 'ansible/playbooks/inventory/test'
    lines = ['fakehost']
    c._parse(path, lines)
    assert c.lineno == 1
    assert c.inventory.groups['ungrouped'].get_vars() == {}
    assert c.inventory.groups['ungrouped'].get_hosts() == ['fakehost']
    #assert c.inventory.groups['ungrouped'].get_children() == []
    path = 'ansible/t/test-inventory.ini'

# Generated at 2022-06-11 14:46:16.204277
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    pass


# Generated at 2022-06-11 14:46:28.172762
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Test method parse of class InventoryModule.
    '''
    options = C.config.get_config_value('DEFAULT', 'inventory_ignore_extensions')
    data = '''
    [group1]
    host_1
    host_2
    host_3
    [group2:children]
    group1
    [group3:vars]
    var=val
    '''
    data2 = '''
    [group1]
    host_1
    host_2
    host_3
    [group2:children]
    group1
    [group3:vars]
    var=val
    '''

# Generated at 2022-06-11 14:46:32.883903
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    def test_valid(path, data):
        im = InventoryModule()
        im.parse(path, data)

    paths = [
        'test1',
        'test2',
    ]
    data = [
        """
        [group1]
        localhost
        """,
        """
        [group1]
        localhost
        127.0.0.1
        """,
    ]
    for path, d in zip(paths, data):
        yield test_valid, path, d


# Generated at 2022-06-11 14:46:38.945842
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    path = os.path.dirname(os.path.realpath(__file__)) + "/../../../inventory"
    inventory = Inventory(path)
    inventory_module = InventoryModule(inventory)
    inventory_module.parse(path)

    assert(inventory_module.lineno == 10)
    assert(inventory_module.groups == {})
    #assert(inventory_module.patterns == {})
    assert(inventory.groups == {'wombat': {'hosts': ['one', 'two']}})


# Test the class InventoryParser

# Generated at 2022-06-11 14:46:47.883273
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print('Test parse')
    
    m = InventoryModule()
    # TODO: instanciate a mock inventory object so that we can check later what was done
    m.inventory = Mock()
    m.lineno = 0
    
    # TODO: parse a sample inventory to check that what is returns is what we expect
    # TODO: check that the inventory was parsed, the groups created etc
    # TODO: check that the correct error is thrown if there are errors in the inventory
    
test_InventoryModule_parse()

# Generated at 2022-06-11 14:46:59.494554
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-11 14:47:04.083314
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()
    inv.parse('realworld', ['[local]\nlocalhost\n[remote]\notherhost\n'])

if __name__ == '__main__':
    test_InventoryModule_parse()
    print('ok')

# Generated at 2022-06-11 14:48:48.291187
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    _inventory = InventoryManager([])

# Generated at 2022-06-11 14:48:52.440832
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryManager(loader=None, sources='/tmp/hosts')
    parser = InventoryModule(inventory)

    # test parse
    parser.parse(path='/tmp/hosts', lines=
        [
          u'[group1]',
          u'localhost'
        ]
    )
    assert('localhost' in inventory.groups['group1'].hosts)

# Generated at 2022-06-11 14:49:01.421346
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = AnsibleModule({})
    inv_module = InventoryModule()
    inv_module.set_options({})
    inv_module.inventory = Inventory('/dev/null')
    inv_module._parse('hosts', 'host1 host2:23 host3:2345 host4 ansible_ssh_host=1.2.3.4 ansible_port=1234')
    assert inv_module.inventory.get_host('host1').vars == {}
    assert inv_module.inventory.get_host('host2').vars['ansible_ssh_port'] == 23
    assert inv_module.inventory.get_host('host3').vars['ansible_ssh_port'] == 2345

# Generated at 2022-06-11 14:49:13.056509
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from string import ascii_lowercase

    for filename in ["./test/test.yml", "./test/test.yaml"]:
        for parser_type in ['yaml', 'json', 'ini']:
            print("Testing parsing of '%s' using parser '%s'" % (filename, parser_type))
            im = InventoryModule()
            im.parse(filename, None, parser_type)

            # Check group names
            group_names = ascii_lowercase + '_'
            group_names_set = set(group_names)
            for group in im.groups:
                assert group in group_names_set
                group_names_set.remove(group)

            # Make sur we have check all groups names
            assert len(group_names_set) == 0

            # Check variables from groups
           

# Generated at 2022-06-11 14:49:19.806097
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    lines = '''
    [test]
    localhost ansible_connection=local
    [other:vars]
    foo=bar
    '''
    data = StringIO(lines)
    path = 'test'
    inventory = InventoryManager()
    InventoryModule(inventory, 'test', data, path).parse()
    inventory.get_hosts()
    assert inventory.get_group('test')
    assert 'localhost' in inventory.get_host('localhost').get_vars().keys()
    assert inventory.get_group('other').get_vars()['foo'] == 'bar'
    assert 'bar' == inventory.get_host("localhost").get_vars()['foo']

# Generated at 2022-06-11 14:49:30.174978
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryManager(loader=None, sources='.')
    inventory_module = InventoryModule(inventory)
    inventory_module.parse('test_InventoryModule_parse', lines=[
        '[group]',
        'host1',
        'host2',
        'host3',
        ''
    ])
    assert len(inventory.groups) == 1
    assert inventory.groups[0].name == 'group'
    assert inventory.groups[0].hosts[0].name == 'host1'
    assert inventory.groups[0].hosts[1].name == 'host2'
    assert inventory.groups[0].hosts[2].name == 'host3'


# Generated at 2022-06-11 14:49:38.941726
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
  inventory = InventoryModule()

  s = '''
[webservers]
#source name
shadowcat1.example.com #comment
shadowcat2.example.com # comment
  shadowcat3.example.com # comment

[appservers]
shadowcat4.example.com   # comment
shadowcat5.example.com
[dbservers]
shadowcat7.example.com
shadowcat8.example.com
'''

  inventory.parse('', s)


# Generated at 2022-06-11 14:49:50.276217
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
	# Initializing the inventory module
	inv = InventoryModule('blah',[
		'[groupname]',
		'alpha',
		'beta:2345 user=admin      # we\'ll tell shlex',
		'gamma sudo=True user=root # to ignore comments'])
	# Calling the parse method
	inv.parse()

	# Asserting that the correct variables are set
	assert inv.inventory.groups['groupname'].hosts['alpha'].vars['ansible_host'] == 'alpha'
	assert inv.inventory.groups['groupname'].hosts['alpha'].vars['ansible_port'] == 22
	assert inv.inventory.groups['groupname'].hosts['beta'].vars['ansible_host'] == 'beta'

# Generated at 2022-06-11 14:49:59.517690
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()
    inv.parse('/tmp/test.ini', ['[test]', 'localhost'])
    assert inv.groups['test'] is not None
    assert inv.groups['test'].name == 'test'
    assert inv.groups['test'].hosts == {}
    assert inv.hosts['localhost'] == inv.groups['test'].hosts['localhost']
    inv.parse('/tmp/test.ini', ['[test]', 'localhost ansible_ssh_port=2121'])
    assert inv.hosts['localhost'].port == 2121
    inv.parse('/tmp/test.ini', ['[test]', 'localhost ansible_ssh_port=2121', 'localhost ansible_ssh_port=3000'])

# Generated at 2022-06-11 14:50:10.999488
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.cli.playbook import PlaybookCLI
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs, add_directory
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    import ansible.constants as C
    #import ansible.inventory.manager
    #import ansible.parsing.vault
    #import ansible.plugins.loader
    #import ansible.errors
    from ansible.errors import AnsibleError