

# Generated at 2022-06-11 14:40:34.600386
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    invmod = InventoryModule()
    invmod._parse = Mock()
    invmod.parse('test_path', ['line_1', 'line_2'])
    invmod._parse.assert_called_once_with('test_path', ['line_1', 'line_2'])


# Generated at 2022-06-11 14:40:46.402743
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    filename = 'test/ansible/inventory/inventory_module_parse.txt'
    with open(filename, 'r') as f:
        lines = [to_text(l, errors='surrogate_or_strict') for l in f.readlines()]

    inventory = InventoryManager(loader=DataLoader())
    parser = InventoryModule(inventory=inventory)
    parser._parse(filename, lines)

    # for group in inventory.groups:
    #    print(group)
    #    for child in inventory.groups[group].children:
    #        print('\t' + child)

    assert 'ungrouped' in inventory.groups
    assert 'localhost' in inventory.groups['ungrouped'].hosts
    assert '127.0.0.1' in inventory.groups['ungrouped'].hosts

# Generated at 2022-06-11 14:40:48.408262
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
  inv_mod = InventoryModule()
  inv_mod.parse('inventory_file')


# Generated at 2022-06-11 14:40:56.828129
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    class TestModule:
        def __init__(self):
            self.config = dict()
            self.params = dict()
            self.connection = None
            self.inventory = Inventory(None, None)
            self.playbooks = []
            self.playbook = 'test.yaml'
            self.inventory.clear_pattern_cache()
            self.inventory.subset = None

    test_instance = TestModule()

    test_instance.config = dict()
    test_instance.params = dict()
    test_instance.connection = None

    test_instance.config['INTERNAL_DATA'] = '{"group_names": [], "vars": {}}'
    test_instance.params['source'] = 'data/ansible/test_InventoryModule_parse.ini'

    global_result = []

    test_instance

# Generated at 2022-06-11 14:41:08.149596
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()

# Generated at 2022-06-11 14:41:10.002050
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryModule(None)
    # inventory._parse()


# === AnsiblePlugin class ===


# Generated at 2022-06-11 14:41:22.130428
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_path = os.path.join(os.path.dirname(__file__), 'ansible.inventory')
    with open(inventory_path) as f:
        inventory_lines = f.readlines()


    inventory = InventoryManager(loader=DictDataLoader({"/tmp/ansible.inventory": inventory_lines}))
    inventory_obj = InventoryModule(inventory=inventory)

    inventory_obj._parse("fake_path", inventory_lines)
    groups = inventory.get_groups_dict()
    assert groups['ungrouped']['vars'] == {}
    assert groups['ungrouped']['children'] == []
    assert groups['ungrouped']['hosts'][0].get_name() == 'localhost'

# Generated at 2022-06-11 14:41:34.033877
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    filename = './test/test_inventory.ini'
    i = InventoryModule()
    i.parse(filename, 'test')
    assert i.inventory._hosts['test'] == '127.0.0.1'
    assert i.inventory._hosts['test1'] == '127.0.0.2'
    assert i.inventory._variables['all'] == {'var1': 'value1', 'var2': 'value2'}
    assert i.inventory._vars['test']['var1'] == 'value1'
    assert i.inventory._vars['test1']['var1'] == 'value2'
    assert i.inventory._groups['group1']['hosts'] == ['test']
    assert i.inventory._groups['group1']['vars'] == {}
    assert i.inventory._

# Generated at 2022-06-11 14:41:43.076767
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    filename = './InventoryModule.yaml'

    # Create an instance of the class to test
    testInventory = InventoryModule()

    # Read the inventory file
    with open(filename, 'r') as content_file:
        testInventory.parse(content_file.name, [line.strip() for line in content_file], None, None)

    # Print the json representation of the results
    print(json.dumps(testInventory.inventory.get_hosts(), indent=4, sort_keys=True))

    # Print the json representation of the results
    print(json.dumps(testInventory.inventory.get_hosts(), indent=4, sort_keys=True))


test_InventoryModule_parse()

# Generated at 2022-06-11 14:41:53.964128
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    invmod = InventoryModule()
    invmod._parse("filename", [
        "[ungrouped]",
        "10.20.30.2",
        "10.20.30.3",
        "10.20.30.4",
        "[south:children]",
        "north",
        "east",
        "west",
        "[east:children]",
        "west",
        "[west]",
        "10.20.30.4",
        "10.20.30.5",
        "[north:vars]",
        "domain=northwest.net",
        "[east:vars]",
        "domain=southeast.net",
        "[south:vars]",
        "domain=south.net",
        "[west:vars]",
        "domain=west.net",
    ])

# Generated at 2022-06-11 14:42:14.123271
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    data = [
        '[group1]',
        'foo1',
        '[group2]',
        'foo2',
        '[ungrouped]',
        'foo3',
        '[group1:vars]',
        'group_var1=foo4',
        '[group2:vars]',
        'group_var2=foo5',
        '[ungrouped:vars]',
        'ungrouped_var1=foo6',
        '[group1:children]',
        'group2',
        '[group1:vars]',
        'g1v2=foo10',
        '[group2:vars]',
        'g2v2=foo11'
    ]

    inventory = AnsibleInventory(config_file=None)
    inventory_parser = InventoryModule()

    inventory_parser

# Generated at 2022-06-11 14:42:26.557171
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()

    # Set up a fake inventory to play with.
    fake_inv = FakeInventoryModule()
    fake_inventory = FakeInventoryModule()
    inv._filename = 'fakefile'

    # This is the source code we'll feed to parse().

# Generated at 2022-06-11 14:42:32.912086
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
        data='''
[group1]
host1
[group2]
host2
[group3]
'''
        inv=InventoryModule(None, '', True)
        inv._parse('/dev/null', data.split('\n'))
        assert inv.groups == {'ungrouped': {'hosts': [], 'vars': {}, 'children': []}, 'group1': {'hosts': ['host1'], 'vars': {}, 'children': []}, 'group2': {'hosts': ['host2'], 'vars': {}, 'children': []}, 'group3': {'hosts': [], 'vars': {}, 'children': []}}


# Generated at 2022-06-11 14:42:39.679337
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    expected_groups = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']

    # Test parser with a mock file obj

# Generated at 2022-06-11 14:42:41.273750
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    im = InventoryModule()
    im._parse("path", GROUPS)

# Generated at 2022-06-11 14:42:53.281297
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop


# Generated at 2022-06-11 14:43:02.648192
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-11 14:43:15.535803
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Unit test for method parse of class InventoryModule
    
    '''
    
    # function usage info
    usage = '%prog [options]\n' + __doc__ + '''\
    Unit test for method parse of class InventoryModule
    '''

    # create the parser
    parser = OptionParser(usage)
    parser.add_option('-f', '--file', dest="filename", type="string", help="The file to be parsed", metavar="FILE")
    parser.add_option('-v', '--verbose', dest="verbose", action="store_true", help="Verbose flag", default=False)
    (options, args) = parser.parse_args(sys.argv[1:])


# Generated at 2022-06-11 14:43:24.472146
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()
    inv._parse('test', [
        '[web]',
        'a1ansible_host',
        'a1 web1=True',
        '[new:vars]',
        'a=b',
        '[old]',
        'b1:1234',
        '[ungrouped]',
        'c1',
        'c2',
    ])
    assert inv.inventory.get_host('a1ansible_host').get_vars()['web1'] == True
    assert inv.inventory.get_host('a1ansible_host').port is None
    assert inv.inventory.get_host('b1ansible_host').port == 1234
    assert inv.inventory.get_host('c1ansible_host').vars == {}
    assert inv.inventory.get_host

# Generated at 2022-06-11 14:43:35.873542
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    base_dir = os.path.dirname(__file__)
    inventory_file = os.path.join(base_dir, 'inventory')
    inventory = Inventory(loader=Loader())
    inventory_mod = InventoryModule(inventory=inventory, loader=Loader())


# Generated at 2022-06-11 14:43:57.571756
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Unit test for method parse of class InventoryModule
    '''

    # setup
    inventory_data = dedent('''
    [group1]
    host1
    host2:1234
    host3 ansible_ssh_user=testuser ansible_ssh_host=testhost
    host4 ansible_ssh_host=testhost
    host5 ansible_ssh_host=testhost
    [group2:vars]
    var1=value1
    var2=value2
    [group3:children]
    group4
    group5
    ''')

    inventory_data2 = dedent('''
    [group1]
    host1
    host2
    host3
    ''')

    # execution

# Generated at 2022-06-11 14:44:00.726927
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule(None, None, None)
    inv.parse('samples/ini_files/test_ini_file')
    assert inv.inventory.groups == {'ungrouped': Group(name='ungrouped', vars={}), 
                                    'group1': Group(name='group1', vars={}), 
                                    'group2': Group(name='group2', vars={}),
                                    'all': Group(name='all', vars={})}

# Generated at 2022-06-11 14:44:08.250082
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    def get_inventory(path):
        inventory = InventoryModule()
        inventory.load_from_file(path)
        return inventory

    # This test only covers a small subset of the inventory parser for now. It
    # should be expanded when it's possible to assert that plugins have been
    # successfully installed.

    data = '''
# inventory-1.0
all:
  hosts:
    test1:
      ansible_port: 11
    test2:
      ansible_port: 22
    test3:
      ansible_port: 33
    test4:
      ansible_port: 44
    test5:
      ansible_port: 55
    test6:
      ansible_port: 66
'''

    f = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-11 14:44:19.481168
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-11 14:44:29.186837
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
  inv = InventoryModule()
  path = './inventory_file'

  # test _parse of an empty file
  inv._parse(path, '')
  inv._parse(path, '\n')

  # test _parse of file without a '['
  inv._parse(path, 'a')
  inv._parse(path, '\na')

  # test _parse of file with a [ in it
  inv._parse(path, '][')
  inv._parse(path, '[')
  inv._parse(path, ']')
  inv._parse(path, 'a\n]')
  inv._parse(path, '[\n\n]')

test_InventoryModule_parse()


# Generated at 2022-06-11 14:44:37.566493
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = dict(create_inventory(dict(
        filename=join(fixtures_path, 'inventory', 'hosts'),
        private=dict(vars=dict(ansible_connection='local'))
    )))

# Generated at 2022-06-11 14:44:48.252513
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-11 14:44:58.139729
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager

    loader = DataLoader()

    inv_path = "/home/vagrant/ansible/inventory"
    i = InventoryModule(loader, inv_path)

    # pdb.set_trace()
    # i._parse(inv_path, [
    #     "[group1]",
    #     "host1",
    #     "host2",
    #     "",
    #     "[group2]",
    #     "host2",
    #     "host3",
    #     "",
    #     "[group3]",
    #     "host4",
    #     "host5",
    #     "",
    #     "[ungrouped

# Generated at 2022-06-11 14:45:00.691235
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()
    inv.parse('/path/to/inventory_file', [])



# Generated at 2022-06-11 14:45:12.018398
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = Inventory(None)
    host_list = [u"testserver1.example.com", u"testserver2.example.com", u"testserver3.example.com", u"testserver4.example.com", u"testserver5.example.com"]
    port = None
    variables = {u"ansible_ssh_user": u"root"}
    path = u'/home/username/ansible/hosts'

    data = u"[group1]\n" + host_list[0] + u" ansible_ssh_port=" + str(port) + "\n\n"

    data += u"[group1:vars]\n"
    for key, value in variables.items():
        data += key + u"=" + value + "\n"

    data += u"[group2]\n" + host_

# Generated at 2022-06-11 14:45:42.732375
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    m = InventoryModule()
    comments = '''
    # a comment
    # another comment
    '''
    not_comments = '''
    a # comment
    another comment#
    #a comment
    # another comment
    '''
    lines = [
        "a host",
        "a host:23",
        "a host:var1=val1",
        "a host:var1=val1 var2=val2",
        "a host:var1=1",
        "a host:var1=1.5",
        "a host:var1=test=\"test\"",
        "a host:var1=test='test'",
        "a host:var1=test=test",
        ]

# Generated at 2022-06-11 14:45:52.372474
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible import constants as C
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    m = InventoryModule()
    m.inventory = InventoryManager(loader=DataLoader())
    # This should succeed, though there's no real content.
    m.parse([], '')

    # Input with a valid host definition and a valid set of key=value
    # variables.
    m.parse([],
'''
[groupname]
alpha
beta:2345 user=admin      # we'll tell shlex
gamma sudo=True user=root # to ignore comments
''')
    assert 'alpha:unspecified' in m.inventory.get_hosts('groupname')
    assert 'beta:2345' in m.inventory.get_hosts('groupname')

# Generated at 2022-06-11 14:46:03.160605
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print("\n===TESTING parse()===")

    # create an InventoryModule object
    inven = InventoryModule()

    # Set this to True to see the actual result of the tests
    verbose = False

    # Attempt to call parse() with an empty path
    # (we expect this to raise an exception)
    try:
        inven.parse('', '', '', '')
    except AnsibleParserError as e:
        if verbose:
            print(e)
        else:
            pass

    # Example of a valid inventory file

# Generated at 2022-06-11 14:46:13.383815
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Test method parse of InventoryModule class
    '''
    # Test that parsing ipv4 address works
    def test_ipv4_address(buf, group, hostname):
        inv = InventoryModule()
        inv.parse(buf, cache=False)
        assert inv.inventory.hosts[hostname].name == hostname
        assert inv.inventory.hosts[hostname].groups[0].name == group

    # Test that parsing ipv6 address works
    def test_ipv6_address(buf, group, hostname):
        inv = InventoryModule()
        inv.parse(buf, cache=False)
        assert inv.inventory.hosts[hostname].name == hostname
        assert inv.inventory.hosts[hostname].groups[0].name == group

    # Test that parsing hostname with range works
   

# Generated at 2022-06-11 14:46:25.792464
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module_path = os.path.join(current_test_dir, 'TestInventoryModule')
    im = InventoryModule(module_path)

    #test that it reads hosts and groups correctly
    assert im.host_list == ['testhost1', 'testhost2', 'testhost3']
    #get the 'testgroup' group and check it's children and variables
    test_group = im.get_group('testgroup')
    assert test_group.name == 'testgroup'
    assert set(test_group.child_groups.keys()) == set(['testgroup1', 'testgroup2'])
    assert test_group.get_variables() == { u'key1': u'value1', u'key2': u'value2', u'key3': u'value3'}
    #get the 'testgroup1' group

# Generated at 2022-06-11 14:46:33.597342
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
   # Test with an empty inventory file
   inv = InventoryModule()
   yaml_path = './empty_inventory'
   inv.parse(yaml_path)

   # Test with an inventory file containing a single host
   inv = InventoryModule()
   yaml_path = './single_host'
   inv.parse(yaml_path)

   # Test with an inventory file containing a single group and one host with an attribute
   inv = InventoryModule()
   yaml_path = './single_group'
   inv.parse(yaml_path)

   # Test with an inventory file containing a single group and one host with an attribute
   inv = InventoryModule()
   yaml_path = './single_host_with_attribute'
   inv.parse(yaml_path)

   # Test with an inventory file containing a single group and one host

# Generated at 2022-06-11 14:46:41.100823
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule(filename='example.ini')
    filename = 'example.ini'
    if not os.path.isfile(filename):
        raise IOError("file %s does not exist." % filename)
    fd = open(filename, 'r')
    lines = fd.readlines()
    fd.close()
    module._parse(filename, lines)
    assert isinstance(module.inventory.groups, OrderedDict)
    assert len(module.inventory.groups) == 4
    assert list(module.inventory.groups.keys()) == ['ungrouped', 'rtrs', 'switches', 'servers']
    assert isinstance(module.patterns['section'], Pattern)
    assert isinstance(module.patterns['groupname'], Pattern)

# Generated at 2022-06-11 14:46:49.571776
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
  inven=InventoryModule()
  inven.set_options(connection='paramiko',module_path=None,forks=100,remote_user='None',private_key_file=None,ssh_common_args=None,ssh_extra_args=None,sftp_extra_args=None,scp_extra_args=None,become=False,become_method='sudo',become_user='root',verbosity=None,check=False,diff=False)
  inven.parse(['localhost'])


# Generated at 2022-06-11 14:47:01.460001
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Unit test for method parse of class InventoryModule
    '''
    text = '''
[all]
localhost

[all:vars]
a=1
b=2

[test]
localhost ansible_connection=local
example.com

[test:vars]

[other:children]
test

[other:vars]
c=3
'''
    inventory = InventoryManager(loader=DictDataLoader({'hosts':text}))
    inventory.parse_inventory(inventory)

    # check the host vars
    test_inventory_manager_host_vars(inventory)

    # check group vars
    test_inventory_manager_group_vars(inventory)

    # check child groups
    test_inventory_manager_child_groups(inventory)

# Generated at 2022-06-11 14:47:09.171852
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Method parse under test
    data = '''
[hosts]
  host1:2222 user=admin
  host2:2222
  host3:2222
    '''
    inventory = Inventory()
    inv_mod = InventoryModule(inventory)
    inv_mod.parse(data)
    # Test result
    assert getattr(inv_mod, 'lineno') == 4
    assert inventory.groups['all'] == inventory.get_group('all')
    assert inventory.groups['all'].name == 'all'
    assert inventory.groups['all'].vars == {}
    assert inventory.groups['all'].child_groups == {}
    assert inventory.groups['all'].hosts == set(['host1', 'host2', 'host3'])
    assert inventory.groups['all'].depth == 0

# Generated at 2022-06-11 14:48:04.038469
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from mock import patch
    from collections import namedtuple
    # pylint: disable=no-member,import-error
    class Inventory(namedtuple('Inventory', ['groups'])):
        # pylint: disable=invalid-name,redefined-builtin
        def add_child(self, parent, child):
            self.groups[parent].add_child(child)

        def add_group(self, group):
            self.groups[group] = FakeGroup(group)

        def set_variable(self, group, key, value):
            self.groups[group].set_variable(key, value)

    class FakeGroup:
        def __init__(self, name):
            self.name = name
            self._children = []
            self._variables = {}


# Generated at 2022-06-11 14:48:14.233378
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    check = Check()
    module = check.ansible_module_for_inventory()
    inventory = Inventory()
    for host in ['localhost', '127.0.0.1', '::1']:
        inventory.add_host(host)

    for group in ["all", "all1", "all2", "all3"]:
        inventory.add_group(group)

    inventory.add_child("all", "all1")
    inventory.add_child("all", "all2")

    module.parse(inventory, [os.path.join(check.path, "inventory_hosts")])

    # check inventory groups
    groups = [group.name for group in inventory.groups.values() if group.name != "ungrouped"]

# Generated at 2022-06-11 14:48:21.098135
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Just a test of valid parsing
    data = """
# Create two groups, 'ungrouped' and 'example', and add a host 'alpha' to 'ungrouped'.
# Set some host variables for 'alpha'.
# Add 'example' as a child of 'ungrouped'.

[example]
beta
gamma

[example:vars]
some_server_var=foo

[alpha:children]  # adds 'example' as a child to the 'alpha' group (invalid!)

[ungrouped]
alpha ansible_connection=local ansible_ssh_port=2222

[alpha]
alpha

[alpha:vars]
ansible_ssh_port=2222

[alpha:children]
example

[example:children]
bad_parent
"""

    im = InventoryModule()

    #

# Generated at 2022-06-11 14:48:31.050461
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    ### GIVEN ###
    # Imports and declarations go here
    mod_path = os.path.realpath(inspect.getfile(inspect.currentframe()))
    file_path = os.path.join(os.path.dirname(mod_path), 'fixture', 'test_InventoryModule.py')
    # Method to be tested
    m = InventoryModule()
    ### WHEN ###
    # Method under test
    m.parse(file_path, 'test_InventoryModule')
    # Tasks to be done after method under test
    # Check assertion

# Generated at 2022-06-11 14:48:43.376635
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_file = """
[databases]
# comment
server.example.com
# comment

[webservers:vars]
haproxy_hosts=5

[webservers]
web[1:5].example.net
www[6:9].example.com

# comment
[nfs:children]
# comment
databases
# comment
webservers
"""
    inv = InventoryModule('')
    inv.filename = "myfile"
    inv.parse(inventory_file.splitlines(True))


# Generated at 2022-06-11 14:48:52.833284
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import ansible.parsing.vault as vault_lib

    # create a dummy file
    # have to set the group name to something more than just 'ungrouped'
    tmp_file = tempfile.NamedTemporaryFile()
    tmp_file.write(b'[groupfoo]\n')
    tmp_file.write(b'moderate.example.org\n')
    tmp_file.write(b'[groupfoo:vars]\n')
    tmp_file.write(b'ansible_ssh_user=root\n')
    tmp_file.write(b'[groupfoo:children]\n')
    tmp_file.write(b'groupbaz\n')
    tmp_file.write

# Generated at 2022-06-11 14:49:01.853649
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-11 14:49:04.988151
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = ansible.inventory.InventoryModule()
    inventory_module.parse('my_inventory_path', 'my_inventory_content')


# Generated at 2022-06-11 14:49:06.635520
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryModule()
    assert inventory.parse() == None
    

# Generated at 2022-06-11 14:49:14.268960
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_definition_yaml = """
    all:
      hosts:
        192.17.0.2:
          ansible_user: docker
        127.0.0.1:
          ansible_user: vagrant
          ansible_port: 2222
    """
    inventory = InventoryModule()
    inventory.parse(inventory_definition_yaml)
    assert inventory.get_host("192.17.0.2")
    assert inventory.get_host("127.0.0.1")