

# Generated at 2022-06-21 05:22:18.255627
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    parser = InventoryModule()
    assert parser != None, "Failed to create inventory parser!"
    assert parser.patterns == None, "Patterns initialized when module not loaded!"


# Generated at 2022-06-21 05:22:30.916790
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()

    # Set up the inventory to be parsed
    source = '[webservers]\nfoo\nbar\n[dbservers]\nbaz\n[ungrouped]\nspam\neggs'
    fake_filename = '/tmp/ansible_hosts'
    inventory._parse(fake_filename, source.split('\n'))

    assert inventory.groups["webservers"].get_hosts() == ["foo", "bar"]
    assert inventory.groups["webservers"].vars == {}

    assert inventory.groups["dbservers"].get_hosts() == ["baz"]
    assert inventory.groups["dbservers"].vars == {}


# Generated at 2022-06-21 05:22:34.559106
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv_obj = InventoryModule([''])
    inv_obj.parse('./tests/inventory_file.yml')
    assert inv_obj.host_list is not None


# Generated at 2022-06-21 05:22:48.127720
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    filename = 'tests/' + os.path.basename(__file__).replace('.py', '.ini')
    config_data = open(filename).read()

    inventory = Inventory()
    module = InventoryModule()
    module.parse(inventory, filename, config_data)

    assert inventory.groups['group-1'].vars == {'group-var-1': 'group-1-value'}
    assert inventory.groups['group-1'].child_groups == ['sub-group-1', 'sub-group-2']
    assert inventory.groups['group-1'].hosts == {'group-host-1', 'group-host-2'}
    assert inventory.groups['group-1'].vars_plugins == {'group_var_plugin': 'group-1-var-plugin'}
    assert inventory.groups

# Generated at 2022-06-21 05:23:00.695571
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """ Test that the inventory_module.parse() method
        behaves correctly with all possibilities
        we have in the yaml file
    """

# Generated at 2022-06-21 05:23:02.271625
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' inventory_ini.py:InventoryModule constructor unit test '''

    im = InventoryModule()
    assert im is not None


# Generated at 2022-06-21 05:23:08.186779
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    im = InventoryModule()
    for path in ['/dev/null', u'/dev/null']:
        im.parse_inventory(path)
        im.parse_inventory(path, [])
        if PY2:
            im.parse_inventory(path, [u'[foo]', 'bar'])
        else:
            im.parse_inventory(path, ['[foo]', b'bar'])


# Generated at 2022-06-21 05:23:17.790796
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # init
    inventory = InventoryManager(loader=None, sources=None)
    yaml_data = """\
# This is a YAML file
[ungrouped]
{%(hostname)s} ansible_ssh_host={{ ansible_ssh_host }} ansible_ssh_port={{ ansible_ssh_port|int + 100 }}
[group1:children]
group2
group3

[group3:vars]
var1 = test

[group2]
{%(hostname)s}:1234

[group1:vars]
var2 = test2
"""
    yfile = tempfile.NamedTemporaryFile()
    yfile.write(yaml_data)
    yfile.flush()

# Generated at 2022-06-21 05:23:26.190500
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    new_obj = InventoryModule('foo', 'bar')
    new_obj.parse({'hostfile': 'hostfile', 'host_list': 'host_list', 'group_list': 'group_list', 'dirname': 'dirname'}, 'some_data')
    assert new_obj.inventory == 'foo'
    assert new_obj.loader == 'bar'


# Generated at 2022-06-21 05:23:28.822803
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()
    inventory.parse_inventory('path', 'data')


# Generated at 2022-06-21 05:23:43.709641
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    """
    This is a unit test for InventoryModule
    """
    parser = InventoryModule()
    print(parser)

if __name__ == "__main__":
    test_InventoryModule()

# Generated at 2022-06-21 05:23:44.627525
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    im = InventoryModule()

# Generated at 2022-06-21 05:23:56.098063
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    script = InventoryScript('')
    module = InventoryModule('/dev/null', script)
    assert module
    assert len(module.inventory.groups) > 0
    assert module.inventory.groups['all']
    assert module.inventory.groups['all'] == module.inventory.groups['ungrouped']
    assert len(module.inventory.groups['all'].get_hosts()) == 0
    assert len(module.inventory.groups['all'].get_hosts(subgroup_patterns=['*'])) == 0
    assert module.inventory.groups['all'].get_variable('foo') is None
    assert module.inventory.groups['all'].get_variables() == dict()
    assert module.inventory.groups['all'].get_vars() == dict()
    assert not module.inventory.groups['all'].has_

# Generated at 2022-06-21 05:24:00.453970
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' test_InventoryModule.py: Unit test for constructor of class InventoryModule '''

    # Constructor test without parameters
    module = InventoryModule()
    assert module is not None


# Generated at 2022-06-21 05:24:15.813178
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import pickle

    # identify current directory
    test_dir = os.path.dirname(os.path.realpath(__file__))

    # run constructor
    im = InventoryModule()
    print(im)

    # test example inventory
    example_inventory = os.path.join(test_dir, '../../examples/hosts')
    im = InventoryModule(example_inventory)
    print(im)

    # create pickle file of inventory
    pickle_file = os.path.join(test_dir, 'temp_inventory.p')
    im.create_pickle_file(pickle_file)
    # test if this file can be read
    assert os.path.exists(pickle_file)
    # load the inventory
    im2 = InventoryModule(pickle_file)
    assert im == im

# Generated at 2022-06-21 05:24:17.272359
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module is not None

# Generated at 2022-06-21 05:24:19.830449
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv.get_default_group_name() == "ungrouped"


# Generated at 2022-06-21 05:24:23.878811
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' test_InventoryModule constructor '''
    module = AnsibleModule(argument_spec={})
    result = InventoryModule(module)
    assert isinstance(result, InventoryModule)

# Generated at 2022-06-21 05:24:33.459358
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print(InventoryModule.parse.__doc__)
    data = """
[groupname]
[somegroup:vars]
[naughty:children] # only get coal in their stockings
    """
    inventory = InventoryModule()
    inventory.parse(None, data)
    assert inventory.groups['groupname']
    assert inventory.groups['somegroup'].get_vars()
    assert inventory.groups['naughty'].get_variables()

# Generated at 2022-06-21 05:24:44.553634
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test with one line hosts definitions
    lines = [
        '[group1]',
        'test_hostname',
        '[group2]',
        'test_hostname2',
        '[group3:children]',
        'group1',
        'group2',
        '[group3:vars]',
        'ansible_ssh_user=user',
        'ansible_ssh_private_key_file=/private/key',
        '[group4:children]',
        'group5',
        '[group5]',
        'test_hostname5',
    ]
    inventory = Inventory('')
    # Use assert_raises to test if a exception is raised by a function
    # assert_raises(exception, callable, *args, **kwds)
    # assert_raises(InventoryParserError,

# Generated at 2022-06-21 05:25:05.357936
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    invp = InventoryModule(None)
    invp.parse('example.yaml')
    assert(invp.groups["spanningtree"])
    assert(invp.groups["routing"]["vars"]["ansible_python_interpreter"] == "/usr/bin/python")
    assert(invp.groups["routing"]["children"] == ["spanningtree"])
    
    inventory_file_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), os.path.pardir, os.path.pardir)
    inventory_file_path = os.path.join(inventory_file_path, "inventory", "sample", "hosts.yaml")
    invp.parse(inventory_file_path)

# Generated at 2022-06-21 05:25:19.419604
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    hosts = []

# Generated at 2022-06-21 05:25:34.441019
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = AnsibleInventory()
    inventory.groups = dict()
    inventory.groups['all'] = Group('all')
    o = InventoryModule(inventory)

# Generated at 2022-06-21 05:25:43.379561
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = Mock()
    inventory.add_group = lambda x: True
    inventory.set_variable = lambda a, b, c: True
    inventory.groups = {}
    inventory.add_child = lambda x, y: True

    inv_mod = InventoryModule(inventory)

    inv_mod.patterns = {}
    inv_mod._compile_patterns()

    inv_mod.lineno = 1
    inv_mod._filename = "foo"

# Generated at 2022-06-21 05:25:53.661125
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule([])
    module_path = os.path.dirname(os.path.abspath(__file__))
    inventory_path = os.path.join(module_path, "./sample_inventory")
    inventory_module.parse(inventory_path)
    assert 'localhost' in inventory_module.inventory.hosts
    assert 'host1' in inventory_module.inventory.hosts
    assert 'host2' in inventory_module.inventory.hosts



# Generated at 2022-06-21 05:25:59.257564
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    module.parse("localhost ansible_connection=local")
    print(module.inventory.list_hosts())

if __name__ == "__main__":
    test_InventoryModule_parse()

# Generated at 2022-06-21 05:26:01.612628
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    i = InventoryModule()
    assert type(i).__name__ == 'InventoryModule'



# Generated at 2022-06-21 05:26:06.729432
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    im = InventoryModule()

    # validate the default config
    assert im.get_option('enable_plugins') is True
    assert im.get_option('plugin_dirs') == ['library']

    # validate empty list of plugin dir
    im2 = InventoryModule([])
    assert im2.get_option('enable_plugins') is True
    assert im2.get_option('plugin_dirs') == []

    # validate the plugin_dirs list
    im3 = InventoryModule(['a', 'b'])
    # make sure we don't store the same object
    assert im3.get_option('plugin_dirs') != ['a', 'b']
    assert im3.get_option('plugin_dirs') == ['a', 'b']

    # make sure we handle string input
    im4 = InventoryModule('c')
   

# Generated at 2022-06-21 05:26:20.648957
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    module = InventoryModule()
    module.parse([
        '# Test inventory file for Ansible',
        '[group1]',
        'some.domain.name',
        '[group1:vars]',
        'some_variable = a_value',
        'another_variable = 42',
        '[group2]',
        '192.168.1.1',
        '[group2:vars]',
        'some_variable = another_value',
        'answered=42'
    ], '/dummy/file.yml')

# Generated at 2022-06-21 05:26:34.917170
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' inventory_plugins/host_list.py:InventoryModule:__init__ '''
    # Does the constructor raise AnsibleError for 'hostfile' in args?
    #
    # Create a parser with 'hostfile' passed as an argument, as if from the
    # command line.
    #
    # We catch and test the exception, which is allowed here because this is a
    # unit test and not a functional test.
    #
    with pytest.raises(AnsibleError) as excinfo:
        InventoryModule('hostfile', 'inventory')
    # pylint: disable=unsubscriptable-object
    assert "does not (yet) support new connection based syntax" in to_text(excinfo.value)



# Generated at 2022-06-21 05:26:47.322776
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert isinstance(inv, InventoryModule)



# Generated at 2022-06-21 05:26:56.624299
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_data = """
[test]
alpha
beta
[test:vars]
foo = bar
baz = bang
[test:children]
a
b
[a]
a1
a2
[b]
b1
b2
[b:vars]
d = e
    """

    inv = InventoryManager(loader=DataLoader())
    inv.add_group('test')
    inv.add_group('test').add_child('a')
    inv.add_group('test').add_child('b')
    inv.add_group('a')
    inv.add_group('a').add_host(Host('a1'))
    inv.add_group('a').add_host(Host('a2'))
    inv.add_group('b')
    inv.add_group('b').add

# Generated at 2022-06-21 05:27:06.659978
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' inventory_plugins/ini.py:InventoryModule:__init__ '''
    import os

    # Set up mock inventory
    inv = InventoryManager('localhost')
    inv._inventory = Mock()

    # Set up mock loader
    loader = Mock()
    loader.get_basedir.return_value = os.path.dirname(os.path.abspath(__file__))

    # Construct object
    filename = 'data/test_ini_inventory.ini'
    ini = InventoryModule(loader, filename, inv, 'localhost')

    # Set up data for assertions
    groups = ['group1', 'group2', 'ungrouped']
    hosts = ['localhost', 'test_alias']

    # Assertions
    assert ini._inventory == inv

# Generated at 2022-06-21 05:27:09.682446
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_mod = InventoryModule()
    assert isinstance(inv_mod, InventoryModule)


# Generated at 2022-06-21 05:27:13.132748
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    mock_groups = {}
    mock_hosts = {}
    inventory = Inventory(mock_groups, mock_hosts)
    InventoryModule(inventory)

# Generated at 2022-06-21 05:27:22.024916
# Unit test for constructor of class InventoryModule
def test_InventoryModule():

    def mock_get_file_content(path, default_content=b'', decode=False):
        '''
        Decodes or returns the provided content.
        '''
        if decode:
            return to_text(default_content, errors='surrogate_or_strict')
        else:
            return default_content


# Generated at 2022-06-21 05:27:37.090683
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    testInventory = InventoryModule(loader=None, variable_manager=None, host_list=None)
    testInventory._COMMENT_MARKERS = ('#', ';')
    testInventory.host_pattern = '[a-z]+[0-9]*(\\.[a-z]+)+'
    testInventory.vars_regexp = '''\s*?(?P<varname>[A-Za-z_]+[A-Za-z0-9_]*)\s*?=\s*?(?P<quote>["'])(?P<value>.*?)(?P=quote)\s*?$'''

# Generated at 2022-06-21 05:27:45.249950
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()

    assert inventory.inventory_basedir == inventory.get_basedir(), "base dir not correctly set"
    assert os.path.exists(inventory.inventory_basedir), "base dir doesn't exist"
    assert inventory.inventory_filename == inventory.get_file_name(), "inventory filename not correctly set"
    assert os.path.isfile(inventory.inventory_filename), "inventory file doesn't exist"

# Generated at 2022-06-21 05:27:47.962078
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_module = InventoryModule()
    assert inv_module.inventory is not None


# Generated at 2022-06-21 05:27:51.715904
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' inventory_ini.py:InventoryModule constructor unit test '''

    inventory_ini.InventoryModule(None)


# Generated at 2022-06-21 05:28:18.268522
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    m = inventory_base.InventoryModule.load('ini')
    # Populate the inventory using an in-memory source.
    # We have to add some boilerplate to make this a valid ini file, but
    # otherwise it's just the same as before.
    data = '[ungrouped]\n'
    data += 'alpha\n'
    data += 'beta:2345 host=bravo user=admin\n'
    data += 'gamma sudo=True user=root\n'
    data += '[othergroup]\n'
    data += 'epsilon one_var=1 other_var=2\n'
    data += '[somegroup:children]\n'
    data += 'othergroup\n'
    data += '[somegroup:vars]\n'

# Generated at 2022-06-21 05:28:20.398520
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert hasattr(InventoryModule(), '__init__')


# Generated at 2022-06-21 05:28:32.172233
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()


# Generated at 2022-06-21 05:28:42.441578
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module_name = 'InventoryModule'
    test_parser = AnsibleModuleTest(group=module_name)
    test_parser.load_module(['./library/yaml_inventory.py'])
    cls = getattr(test_parser.module, module_name)()

# Generated at 2022-06-21 05:28:47.566064
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()
    assert isinstance(inventory, InventoryModule)
    assert hasattr(inventory, 'parser')
    assert isinstance(inventory.parser, ConfigParser)



# Generated at 2022-06-21 05:28:56.471341
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    module = AnsibleModule(argument_spec={'test': dict(required=False, type='bool')})

    paths = [ os.path.join(os.path.dirname(__file__), 'test_inventory'),
              os.path.join(os.path.dirname(__file__), 'test_inventory/hosts') ]
    inv_mod = InventoryModule(module, paths=paths)
    inv_mod.parse()

    assert inv_mod.inventory.groups['all'].name == 'all'
    assert len(inv_mod.inventory.groups['all'].hosts) == 6
    assert len(inv_mod.inventory.groups['all'].vars) == 2
    assert inv_mod.inventory.groups['fakegroup'].name == 'fakegroup'

# Generated at 2022-06-21 05:29:08.627575
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module_set_ipv6()
    inventory = InventoryManager(loader=None, sources=None)
    path = '/some/fictional/relative/path'
    data = []
    data.append(to_text("[group]", errors='surrogate_or_strict'))
    data.append(to_text("foo", errors='surrogate_or_strict'))
    data.append(to_text("bar : 2", errors='surrogate_or_strict'))
    data.append(to_text("baz:3123", errors='surrogate_or_strict'))
    data.append(to_text("a:b:c", errors='surrogate_or_strict'))

# Generated at 2022-06-21 05:29:14.918667
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    myplugin = InventoryModule()
    myplugin.parse(['./tests/ansible-inventory'], 'none')
'''
# uncomment these lines to get the output of this function printed
    for group in myplugin.groups:
        print(group)
        for child in myplugin.groups[group].get_children():
            print("\tchildren: " + child)
        for host in myplugin.groups[group].get_hosts():
            print("\t" + host.get_name())
            print("\t" + str(host.get_vars()))
'''

if __name__ == '__main__':
    test_InventoryModule_parse()

# Generated at 2022-06-21 05:29:27.788206
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host

    # We need to hack the class loader to bypass the cache because we are testing a method from a child class
    # and the ansible cache requires the name of the class to match the module name
    mod = 'ansible.inventory.ini'
    cls = 'InventoryModule'
    del sys.modules[mod]
    del sys.modules['.'.join([mod, cls])]

    # Create an inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    host = Host(name='test')
    group = Group(name='test')
    inventory.add_host(host)


# Generated at 2022-06-21 05:29:38.425570
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryManager(loader=None, sources='localhost,') # required args only
    inventory.set_variable('localhost', 'foo', 'bar')
    inventory.set_variable('localhost', 'answer', 42)
    inventory.set_variable('localhost', 'empty array', [])
    inventory.set_variable('localhost', 'nested', {'a':'foo'})
    inventory_source = StringIO()
    inventory_source.write('\n'.join(inventory.get_host_vars('localhost')))
    inventory_source.seek(0)
    new_inventory = InventoryManager(loader=None, sources='localhost,') # required args only
    parser = InventoryModule(filename='test_InventoryModule_parse',
                             inventory=new_inventory)
    parser.parse(inventory_source)

# Generated at 2022-06-21 05:30:08.135628
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    #declare instance of class to test
    testInventoryModule = InventoryModule()
    #declare a fake path
    path = "testPath"
    #delcare some fake lines
    lines = ["testString","test:String"]
    #create an Inventory object
    inventory = Inventory()
    #set the test class's inventory attribute
    testInventoryModule.inventory = inventory
    #set test class's patterns attribute to an empty dict
    testInventoryModule.patterns = dict()
    #create a dict to hold fake patterns
    patterns = dict()
    #create a fake pattern for the _parse_group_name method

# Generated at 2022-06-21 05:30:12.639806
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    print (inv)

from ansible import constants as C
from ansible.playbook.play_context import PlayContext
from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.executor.playbook_executor import PlaybookExecutor
from ansible.plugins.callback import CallbackBase
from ansible.inventory.manager import InventoryManager
from ansible.vars.manager import VariableManager
from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-21 05:30:21.710717
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    (infile, lines) = tempfile.mkstemp()
    os.close(infile)


# Generated at 2022-06-21 05:30:23.472036
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv.inventory is not None, "The object has no inventory object?"

# Generated at 2022-06-21 05:30:26.225390
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert isinstance(module, InventoryModule)

InventoryModule._setup_patterns()

# Generated at 2022-06-21 05:30:37.874063
# Unit test for constructor of class InventoryModule
def test_InventoryModule():

    # constants
    UNDEFINED = AnsibleUndefinedVariable()

    # simple inventory file
    filename = os.path.join(os.path.dirname(__file__), 'test-inventory')
    inv = InventoryModule(filename)
    assert inv.inventory.groups['ungrouped'].hosts['jupiter']

    # non-existent inventory file
    try:
        InventoryModule('/no/such/path')
        assert False, "did not throw exception on missing inventory"
    except AnsibleError:
        pass

    # missing group in inventory file
    try:
        inv.inventory.groups['nosuchgroup']
        assert False, "did not throw exception on missing group"
    except KeyError:
        pass

    # missing host in inventory file

# Generated at 2022-06-21 05:30:45.886119
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()

    assert inventory.patterns == {}
    assert inventory.host_patterns == {}
    assert inventory.inventory == None
    assert inventory.host_list == []
    assert inventory.group_list == []
    assert inventory.filename == None
    assert inventory.lineno is None
    assert inventory._COMMENT_MARKERS == tuple('#;')


# Generated at 2022-06-21 05:30:57.653168
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test = InventoryModule()
    test.parse('', 'inventory/test/unit/ansible/test_inventory.ini', 'xyz.cfg')
    inventory = Inventory(host_list=['xyz.cfg'])
    assert hasattr(inventory, 'groups') is True
    assert len(inventory.groups) == 4
    assert 'group1' in inventory.groups
    assert 'group2' in inventory.groups
    assert 'group3' in inventory.groups
    assert 'ungrouped' in inventory.groups
    assert len(inventory.groups['group1'].get_hosts()) == 2
    assert 'host1' in inventory.groups['group1'].get_hosts()
    assert 'host2' in inventory.groups['group1'].get_hosts()

# Generated at 2022-06-21 05:30:58.902736
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryModule()
    inventory.parse()



# Generated at 2022-06-21 05:31:05.039233
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    script = InventoryScript(None, '/dev/null')
    src = '''host1 ansible_ssh_host=host1 ansible_ssh_port=2222
    host2 ansible_ssh_host=host2 ansible_ssh_port=2222'''
    # legacy format
    i1 = InventoryModule([script], 'legacy', None, False)
    i1.parse_legacy_inventory(src)

    # ini format
    i2 = InventoryModule([script], 'ini', None, False)
    i2.parse_inventory(src)

    # yaml format
    i3 = InventoryModule([script], 'yaml', None, False)
    i3.parse_inventory(src)

test_InventoryModule()

# Generated at 2022-06-21 05:31:58.977831
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """
    test_InventoryModule_parse(file)
    Tests method InventoryModule.parse()
    """
    print('Testing method parse of class InventoryModule')
    inv = InventoryModule()
    # The test inventory is used while developing this module, because there is
    # no good output to compare against, the results of the parser are printed
    results = inv.parse(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'inventory', 'test_inventory')))
    print(results)
