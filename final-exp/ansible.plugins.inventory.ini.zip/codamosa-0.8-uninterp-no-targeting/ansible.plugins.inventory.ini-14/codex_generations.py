

# Generated at 2022-06-21 05:22:20.312880
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert_equal(InventoryModule()._subclass, "inventory")

# Generated at 2022-06-21 05:22:23.390123
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' inventory_test.py:Unit test for constructor of class InventoryModule '''

    inventory = Inventory(loader=None)
    im = InventoryModule(inventory=inventory, host_list='/path/to/hosts', cache=None)
    assert im is not None


# Generated at 2022-06-21 05:22:37.027792
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import unittest
    import os
    from io import StringIO
    from ansible.parsing.dataloader import DataLoader

    class TestInventoryModule(unittest.TestCase):

        def setUp(self):
            self._loader = DataLoader()

        def tearDown(self):
            pass

        def test_constructor(self):

            string = u'#!/usr/bin/python\n\n' \
                     u'import json\n' \
                     u'import sys\n' \
                     u'\n\n' \
                     u'if __name__ == "__main__":\n' \
                     u'    print(json.dumps({}))'
            name = 'inventory_loader.py'

# Generated at 2022-06-21 05:22:41.569265
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()
    assert isinstance(inventory, BaseInventoryPlugin)
    assert isinstance(inventory, InventoryBase)
    assert isinstance(inventory, InventoryModule)



# Generated at 2022-06-21 05:22:49.493860
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv_source = textwrap.dedent("""
    [somegroup]                                                                                             
    somehost

    [somegroup:vars]
    somevar=somedata
                                                                                                             
    [ungrouped]                                                                                             
    localhost ansible_connection=local
    localhost ansible_connection=local somevar=foo
    """)
    inv = InventoryModule(loader=DictDataLoader({ 'test_inv' : (inv_source, 'utf-8') }))
    inv.parse_inventory()
    # FIXME: check more specific info, e.g. default vars, host vars, group vars
    assert inv is not None
    assert 'somegroup' in inv.inventory.groups
    assert 'somehost' in inv.inventory.groups['somegroup'].host

# Generated at 2022-06-21 05:22:57.380120
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory_module = InventoryModule()
    assert isinstance(inventory_module, InventoryModule)

    assert isinstance(inventory_module._patterns, dict)
    assert_equal(len(inventory_module._patterns), 0, "Expected an empty dict")

    inventory_module.parse('/etc/ansible/hosts', '{ "all": { "hosts": ["foo.example.com"]}}')

    assert_equal(inventory_module._hosts['foo.example.com'].name, 'foo.example.com')
    assert_equal(inventory_module._hosts['foo.example.com'].port, None)
    assert_equal(inventory_module._hosts['foo.example.com'].vars, {})

    assert_equal(len(inventory_module.groups.keys()), 2)

# Generated at 2022-06-21 05:23:00.162359
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    t = InventoryModule()
    assert t is not None


# Generated at 2022-06-21 05:23:09.783809
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.module_utils.common.collections import ImmutableDict

    inventory = InventoryDirectory("/tmp/inventory")
    assert isinstance(inventory, InventoryDirectory)

    # inventory is an InventoryDirectory.
    #
    # data is an immutable dict.
    #
    # filename is a string.
    data = ImmutableDict(dict(ansible_ssh_host='127.0.0.1'))
    filename = "/tmp/inventory"
    inventory_im = InventoryModule(inventory, data, filename)
    assert isinstance(inventory_im, InventoryModule)
    assert isinstance(inventory_im.inventory, InventoryDirectory)
    assert isinstance(inventory_im.data, ImmutableDict)
    assert inventory_im.filename == filename
    assert inventory_im.inventory == inventory
    assert inventory_im.data == data

# Generated at 2022-06-21 05:23:11.222353
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_mod = InventoryModule()
    assert inv_mod

# Generated at 2022-06-21 05:23:19.441161
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    ini_dir = os.path.dirname(__file__)

    INVENTORY_PATH = os.path.join(ini_dir, 'hosts')

    # This is what a 'real' AnsibleInventory should look like.
    real_inv = AnsibleInventory(host_list=INVENTORY_PATH)
    inv = InventoryModule()
    inv.parse(INVENTORY_PATH)

    # Convert the real inventory into the same format that the test inventory
    # has.

# Generated at 2022-06-21 05:23:45.886224
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-21 05:23:47.300896
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert False, "No test for parse()"


# Generated at 2022-06-21 05:23:50.172380
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory_module = InventoryModule()
    assert isinstance(inventory_module, InventoryModule)


# Generated at 2022-06-21 05:24:02.008580
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    
    data = '''
      [test_group]
      testhost
      [group:children]
      another_group
      [group:vars]
    '''
    inv = InventoryModule()
    inv.parse('hosts', data.split(os.linesep))
    assert 'group' in inv.inventory.groups
    assert 'another_group' in inv.inventory.groups['group'].get_children()
    assert 'group' in inv.inventory.groups['another_group'].get_ancestors()
    assert inv.inventory.groups['another_group'].get_vars() == {}

    assert 'test_group' in inv.inventory.groups
    assert inv.inventory.groups['test_group'].get_hosts()[0].get_name() == 'testhost' 

# Generated at 2022-06-21 05:24:12.281168
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
  inv = YAMLInventory({'foo': 'bar'})
  im = InventoryModule(inv, '/foo/bar')
  data = '''
  [group1]
  foo
  [group2]
  foo
  [group1:vars]
  foo=bar
  '''
  im._parse('', data.split('\n'))
  assert_equal(im.inventory.groups['group1']['hosts'], ['foo'])
  assert_equal(im.inventory.groups['group2']['hosts'], ['foo'])
  assert_equal(im.inventory.groups['group1']['vars'], {'foo': 'bar'})
  assert_equal(im.inventory.groups['group2']['vars'], {})



# Generated at 2022-06-21 05:24:22.492621
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Set up the module object
    module = AnsibleModule(
        argument_spec = dict(
            src = dict(type='str',required=True),
        ),
        supports_check_mode=False,
        mutually_exclusive=[],
        required_together=[],
    )
    module._ansible_debug = False

    # Set up the InventoryModule object
    im = InventoryModule(
        loader=DataLoader(),
        variable_manager=VariableManager(),
        host_list='/dev/null'
    )

    # Run the parse method
    results = im.parse(module.params['src'])

    # Check the results
    assert type(results) == dict
    assert results.has_key('hosts')
    assert type(results['hosts']) == list


# Generated at 2022-06-21 05:24:37.377113
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    fd, fname = mkstemp()
    os.close(fd)
    # sample inventory file content
    data = '[ungrouped]\nhost1\nhost2\nhost3 : [group1]\nhost5 : [foo:children]\n'
    with open(fname, 'w') as f:
        f.write(data)
    # run parse method
    inv = InventoryModule()
    inv.parse(fname)
    # remove the file
    os.remove(fname)
    # check the default group
    assert inv.inventory.groups['ungrouped'].get_hosts() == ['host1', 'host2', 'host3']
    # check the group1 group
    assert inv.inventory.groups['group1'].get_hosts() == ['host3']

# Unit test

# Generated at 2022-06-21 05:24:43.544608
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule(None, 'testInventory')
    assert isinstance(inventory, InventoryModule)
    assert inventory.hosts() == []
    assert inventory.get_host('localhost') is None
    assert inventory.groups() == []
    assert inventory.get_group('all') is None
    assert inventory.get_host('localhost') == {}
    assert inventory.get_variable('all', 'foo') is None


# Generated at 2022-06-21 05:24:45.099995
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory_module = InventoryModule()
    assert inventory_module

# Generated at 2022-06-21 05:24:56.453474
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    class TestInventoryModule(InventoryModule):
        def __init__(self, data=None):
            self.inventory = Mock(Inventory)
            self.data = data
            self.parser = Mock(InventoryParser)
            self.patterns = self._compile_patterns()

    class TestGroup(Group):
        def __init__(self, name=None, host_patterns=None):
            self.name = name
            self.host_patterns = host_patterns
            self.vars = dict()
            self._children = dict()
            self.parent = None

        def add_child(self, group):
            self._children[group.name] = group
            group.parent = self

        def add_host(self, host):
            self.hosts[host.name] = host

# Generated at 2022-06-21 05:25:22.461841
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    m = InventoryModule(playbook_basedir='', variable_manager=None, loader=None, cache=None)
    with pytest.raises(AnsibleError) as excinfo:
        m._parse(path='/tmp/test_inventory', lines=[u'unparsed: line'])
        assert excinfo.value == "Expected group name, got: unparsed: line"



# Generated at 2022-06-21 05:25:23.835364
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    pass


# Generated at 2022-06-21 05:25:34.551666
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    _cfg = ("[web]\n"
            "192.168.1.1\n"
            "[web:vars]\n"
            "ansible_host=192.168.1.1\n"
            "ansible_user=root\n"
            "\n"
            "[test]\n"
            "192.168.1.2\n"
            "[test:vars]\n"
            "ansible_host=192.168.1.2\n"
            "ansible_user=root\n"
            )

    with tempfile.NamedTemporaryFile() as tmp_cfg:
        tmp_cfg.write(to_bytes(_cfg))
        tmp_cfg.flush()

        mi = InventoryModule()
        mi.parse(tmp_cfg.name)

        assert mi.inventory

# Generated at 2022-06-21 05:25:43.393280
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Unit test will add these calls to InventoryModule.parse() in an attempt to compare to actual functionality
    #
    #  self._compile_patterns()
    #  self.lineno = 0
    #
    # NOTE: The rest is assumed to be tested in other tests

    inv = InventoryModule()

    test_ary_1 = []
    test_ary_2 = ['']
    test_ary_3 = ['#']
    test_ary_4 = ['# comment']

# Generated at 2022-06-21 05:25:54.184418
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    module.parse_from_file("test_data/inventory.ini")
    assert module.inventory.groups["nested_2"].child_groups[0].name == "nested_3"
    assert module.inventory.groups["nested_3"].child_groups[0].name == "nested_4"
    assert len(module.inventory.groups["nested_2"].hosts) == 1
    assert len(module.inventory.groups["nested_3"].hosts) == 1
    assert module.inventory.groups["nested_2"].hosts[0].vars["ansible_ssh_host"] == "127.0.0.1"

# Generated at 2022-06-21 05:26:02.725186
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """ test the behavior of parse method from InventoryModule class"""
    inventory = InventoryModule()
    inventory_file_content = '''[group_name]
---
- host_name
- host_name2
'''
    inventory.parse(inventory_file_content)
    assert isinstance(inventory.inventory, Inventory)
    assert len(inventory.inventory.groups) == 1
    assert len(inventory.inventory.groups['group_name'].hosts) == 2
    assert inventory.inventory.groups['group_name'].hosts[0].name == 'host_name'
    assert inventory.inventory.groups['group_name'].hosts[1].name == 'host_name2'


# Generated at 2022-06-21 05:26:09.046873
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventoryModule = InventoryModule()
    inventoryModule.parse("sampleInventory.txt")
    print(inventoryModule.inventory.get_groups_dict())
    print(inventoryModule.inventory.get_host("server01"))
    print(inventoryModule.inventory.get_host("localhost"))

test_InventoryModule_parse()


# Generated at 2022-06-21 05:26:22.022032
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    lines = []
    lines.append("#!/usr/bin/python")
    lines.append("#")
    lines.append("# ANSIBLE_INVENTORY: generator script")
    lines.append("#")
    lines.append("# written by: Bill McKenzie <wmckenzie@hpe.com>")
    lines.append("#")
    lines.append("# version 0.01")
    lines.append("")
    lines.append("from __future__ import print_function")
    lines.append("from __future__ import absolute_import")
    lines.append("import os")
    lines.append("import sys")
    lines.append("import json")
    lines.append("")
    lines.append("from ansibullbot.utils.account_details import account_details_client")


# Generated at 2022-06-21 05:26:25.615255
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule(None)
    assert inv is not None

# Generated at 2022-06-21 05:26:27.720922
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()
    assert inventory is not None



# Generated at 2022-06-21 05:27:18.614631
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule.load(b_('test_file.ini'), None)
    assert inv.name == 'test_file.ini'

# Generated at 2022-06-21 05:27:21.514777
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule([])
    assert inventory._filename is None
    assert inventory.parser is None


# Generated at 2022-06-21 05:27:30.109018
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' inventory constructor test '''
    import os.path
    dummy_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'plugins', 'inventory', 'ansible_inventory.py')
    inventory = InventoryModule(dummy_file)
    print(inventory.filename)
    print(inventory.path_cache)

if __name__ == "__main__":
    test_InventoryModule()

# Generated at 2022-06-21 05:27:35.736205
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' inventory_inifile.py:TestInventoryModule.test_init()

        Test to ensure the InventoryModule is constructed properly
    '''
    module = InventoryModule(None)

    assert module._filename == ''
    assert module._parser is None
    assert module._hosts_cache is None
    assert module._vars_cache is None
    assert module._cache_filename == ''


# Generated at 2022-06-21 05:27:38.092351
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    im = InventoryModule()
    assert isinstance(im, InventoryModule)

# Generated at 2022-06-21 05:27:39.150342
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventoryModule =InventoryModule()
    inventoryModule.parse()
    assert 0


# Generated at 2022-06-21 05:27:54.347909
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # Test InventoryModule creation with a static inventory
    static_inventory = """
[consul:children]
servers
clients

[servers]
consul-1
consul-2

[clients]
consul-3
consul-4

[consul-1]
127.0.0.1
"""
    inventory = InventoryModule(loader=None,inventory=static_inventory)
    assert 'servers' in inventory.inventory.groups
    assert 'clients' in inventory.inventory.groups
    assert 'consul-1' in inventory.inventory.groups
    assert 'consul-2' in inventory.inventory.groups
    assert 'consul-3' in inventory.inventory.groups
    assert 'consul-4' in inventory.inventory.groups

# Generated at 2022-06-21 05:28:01.983431
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    raw = \
"""
[web]
host1 ansible_port=9001 ansible_host=10.0.0.1
host2 ansible_port=9002 ansible_host=10.0.0.2

[db]
host3 ansible_port=9003 ansible_host=10.0.0.3
host4 ansible_port=9004 ansible_host=10.0.0.4

[all:vars]
ansible_connection=local ansible_become=yes ansible_become_method=sudo
"""
    i = InventoryModule()
    i.parse(None, raw, None)

    assert i.groups['web'].hosts['host1'].vars['ansible_port'] == 9001

# Generated at 2022-06-21 05:28:07.824648
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print('Test parse in class InventoryModule')
    obj = InventoryModule()
    # void InventoryModule::parse(string path, string data, string filename = '')
    # TODO: implement your test here
    raise SkipTest # TODO: implement your test here


# Generated at 2022-06-21 05:28:10.320840
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # create inventory module instance
    inventory = InventoryModule()
    assert inventory is not None

# Generated at 2022-06-21 05:30:00.355282
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    ansible_vars = dict()
    ansible_vars['ansible_connection'] = 'local'
    ansible_vars['ansible_python_interpreter'] = '/usr/bin/python'
    with open("/tmp/test-inventory", "w") as f:
        f.write("""[test]
localhost ansible_python_interpreter=/usr/bin/python2.7
[test:vars]
ansible_python_interpreter=/usr/bin/python2.7
ansible_connection=local
[test:children]
test
""")
    inventory = InventoryModule(InventoryManager(loader=None, sources="/tmp/test-inventory"))
    inventory.parse("/tmp/test-inventory", None)

# Generated at 2022-06-21 05:30:04.968192
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    t = InventoryModule()
    t._compile_patterns()

# Generated at 2022-06-21 05:30:18.436242
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import sys
    import StringIO

    # Test empty inventory
    s = StringIO.StringIO()
    sys.stdin = s
    im = InventoryModule()
    assert len(im.inventory.groups) == 1
    assert 'all' in im.inventory.groups
    assert im.lineno == 0

    s = StringIO.StringIO("""
    [testgroup]
    host1
    """)
    sys.stdin = s
    im = InventoryModule()
    assert len(im.inventory.groups) == 2
    assert 'all' in im.inventory.groups
    assert 'testgroup' in im.inventory.groups
    assert len(im.inventory.groups['testgroup'].get_hosts()) == 1
    assert im.lineno == 2


# Generated at 2022-06-21 05:30:19.912659
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    i = InventoryModule()
    assert isinstance(i, InventoryModule)
    assert isinstance(i, BaseInventoryScript)


# Generated at 2022-06-21 05:30:26.364717
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader, variable_manager)
    InventoryModule({}, None, variable_manager, loader, inventory).parse('/tmp/test_InventoryModule', [])
    assert inventory.get_groups_dict() == {}



# Generated at 2022-06-21 05:30:37.934789
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """
    Return True if all tests pass, False otherwise.
    """

    # getlist() is a method of class PlaybookInventory
    # get_hosts() is a method of class PlaybookInventory
    # get_host() is a method of class PlaybookInventory
    # get_groups() is a method of class PlaybookInventory
    # get_group() is a method of class PlaybookInventory
    # get_vars() is a method of class PlaybookInventory
    # get_vars() is a method of class PlaybookInventory
    # get_host() is a method of class PlaybookInventory
    # get_host_variables() is a method of class PlaybookInventory
    # get_host_variable() is a method of class PlaybookInventory
    # get_group() is a method of class PlaybookIn

# Generated at 2022-06-21 05:30:49.252970
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from io import StringIO

    inv_data = StringIO("""
[group1]
host1
host2:1234
host3 ansible_ssh_host=host3.example.com
host4 ansible_ssh_host=host4.example.com:4567
host5 ansible_ssh_port=7890 ansible_ssh_host=host5.example.com
host6:9999 ansible_ssh_port=7890 ansible_ssh_host=host6.example.com
    """)

    inv_obj = InventoryModule()
    inv_obj.parse(inv_data, '')

    groups = inv_obj.inventory.get_groups_dict()

    assert len(groups) == 1
    assert 'group1' in groups
    assert 'host1' in groups['group1'].all_hosts

# Generated at 2022-06-21 05:30:53.652843
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule({'foo': 'bar'})
    assert inv.plugin_options()[b'foo'] == 'bar'



# Generated at 2022-06-21 05:31:01.981698
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_path = os.path.join(os.path.dirname(__file__), 'inventory')
    inv = InventoryModule(loader=DictDataLoader(), sources=(inventory_path,))
    inv.parse_inventory(inventory_path)
    assert inv.groups['ungrouped'].vars == dict(a='a', b=42)
    assert inv.groups['ungrouped'].hosts['host9'].vars == dict(c=None, d=True)
    assert inv.groups['ungrouped'].hosts['host9'].port == None
    assert inv.groups['group1'].vars == dict(a='a', b=42, d=True)
    assert inv.groups['group1'].hosts['host1'].vars == dict(c='c', d=True)

# Generated at 2022-06-21 05:31:07.980164
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_modules_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../test_modules')
    inventory_path = os.path.join(test_modules_path, 'inventory_basic')
    i = InventoryModule()
    i.parse(inventory_path)
    assert isinstance(i.inventory, Inventory)