

# Generated at 2022-06-21 05:22:19.257035
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryManager(loader=None, sources='localhost,')
    im = InventoryModule(inventory)
    im._parse(path='test', lines=['localhost'])
    assert im.inventory.list_hosts() == ['localhost']



# Generated at 2022-06-21 05:22:31.772655
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = MockInventory([])
    # yaml_inventory

# Generated at 2022-06-21 05:22:36.332127
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path'),
        ),
        supports_check_mode=False,
    )
    path = module.params['path']

    inventory = InventoryModule(path)
    invoke_line = inventory.inventory_basedir()

# Generated at 2022-06-21 05:22:40.062751
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    # make sure the regexes are compiled
    inv.patterns


# Generated at 2022-06-21 05:22:46.252216
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    path = '/dev/null'
    script = 'foobar'

    im = InventoryModule('/dev/null', 'foobar')
    assert im._filename == path
    assert im._script == script
    assert im._script_vars is None
    assert isinstance(im.inventory, Inventory)
    assert im.patterns == {}



# Generated at 2022-06-21 05:22:56.536397
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # Test function for InventoryModule class
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.dataloader import DataLoader

    module = InventoryModule([], config={'vault_password_file': 'test/test-vault-password-file.txt'})

    assert module.vault_password_file == 'test/test-vault-password-file.txt'
    assert module.loader is not None
    assert isinstance(module.loader, DataLoader)
    assert module.vault_secrets is not None
    assert len(module.vault_secrets) == 1
    assert isinstance(module.vault_secrets[0], VaultSecret)
    assert isinstance(module.vault, VaultLib)

# Generated at 2022-06-21 05:23:08.862393
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    test_file = os.path.join(os.path.dirname(__file__), 'inventory_test.ini')
    inv_m = InventoryModule()
    inv_m.parse_inventory(test_file)
    assert inv_m.inventory.groups['ungrouped'].hosts['localhost'].vars['var1'] == 'something in var1'
    assert inv_m.inventory.groups['group1'].hosts['host1'].vars['var2'] == 'something in var2'
    assert inv_m.inventory.groups['group1'].vars['var3'] == 'something in var3'
    assert inv_m.inventory.groups['group1'].vars['var4'] == 'something in var4'

# Generated at 2022-06-21 05:23:17.819609
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test the method parse of class InventoryModule
    # Test for valid input
    Test = InventoryModule()
    Test._parse('test_ini_for_parse_method_valid', ['[groupname]\nhost1'])
    assert Test.inventory.groups['groupname'].get_hosts() == {'host1': {}}
    # Test for invalid input
    Test = InventoryModule()
    with pytest.raises(AnsibleParserError) as err:
        Test._parse('test_ini_for_parse_method_invalid', ['[groupname]\nhost1\n[groupname1'])
    assert ":8: Expected group name, got: [groupname1" in to_native(err.value)

# Generated at 2022-06-21 05:23:26.180467
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    """
    This is a Test.
    """

    inventory = dict(
        plugin='simple_plugin.yaml',
        host_list=['localhost', 'otherhost'],
        group_list=['ungrouped'],
        host_vars={},
        group_vars={}
    )

    inv = InventoryModule(inventory)
    assert inv.inventory == inventory

# Generated at 2022-06-21 05:23:27.669761
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    im = InventoryModule()


# Generated at 2022-06-21 05:23:53.037295
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' inventory module: constructor: instantiate class '''

    # Create inventory directory, inventory script and test YAML inventory
    # file
    inventory_dir = tempfile.mkdtemp()
    inventory_file = os.path.join(inventory_dir, "foo.yaml")
    test_file = open(inventory_file, 'w')
    test_file.write("all:\n"
                    "  hosts:\n"
                    "    somehost: {}")
    test_file.close()

    # Instantiate InventoryModule object
    ii = InventoryModule()
    ii._load_inventory_sources(host_list=[inventory_file])
    host = ii._hosts_cache['somehost']
    assert host.vars == {}
    assert host.get_variable('inventory_dir') == inventory_dir
    assert host.get

# Generated at 2022-06-21 05:23:56.463884
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    parser = InventoryModule('', 'inventory_test')
    parser._parse_host_definition('testhost')

# Generated at 2022-06-21 05:24:04.477509
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    argv = dict(path='inventory', cache=None, vault_password=None)

    inv = InventoryModule(**argv)
    inv.ds = dict(path='example_hosts_file')
    inv._parse_inventory_file()

    return inv.inventory

if __name__ == "__main__":
    import pprint
    pprint.pprint(test_InventoryModule_parse())

# Generated at 2022-06-21 05:24:16.025852
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import ConfigParser
    config = ConfigParser.SafeConfigParser()
    config.read('../ansible-playbook-python/playbook.cfg')
    env = dict(config.items('Ansible'))
    inventory_file = env['inventory']
    inventory_path = '../ansible-playbook-python/'
    inventory_file_path = inventory_path + inventory_file
    inventory_data = file(inventory_file_path).read()
    inventory = InventoryModule(inventory_data)
    # print(inventory._parse(inventory_file_path, inventory_data))


# Generated at 2022-06-21 05:24:23.607983
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_mod = InventoryModule()
    assert inv_mod._patterns == {}
    assert inv_mod.patterns == inv_mod._patterns

    assert inv_mod.group_pattern == 'all'
    assert inv_mod.host_pattern == 'all'
    assert inv_mod.inventory == None
    assert inv_mod.runner == None

    # let's try to set them again, to see if this will work (i.e. does the property work?
    inv_mod.group_pattern = 'all'
    inv_mod.host_pattern = 'all'
    inv_mod.inventory = None
    inv_mod.runner = None



# Generated at 2022-06-21 05:24:34.272859
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-21 05:24:37.376995
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # test the constructor
    s = InventoryModule("/some/path/")
    assert isinstance(s, BaseInventory)
    assert s._filename == "/some/path/"


# Generated at 2022-06-21 05:24:45.826309
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    log.info("Testing InventoryModule parse")
    inv = InventoryModule()
    inv.parse('/usr/local/ansible/tests/test_inventory_module.py', host_list=['localhost'])
    assert len(inv.groups) == 3, 'Incorrect number of groups'
    assert 'ungrouped' in inv.groups, 'Expected group ungrouped does not exist'
    assert 'g1' in inv.groups, 'Expected group g1 does not exist'
    assert 'g2' in inv.groups, 'Expected group g2 does not exist'
    assert 'localhost' in inv.groups['ungrouped'].hosts, 'Expected host localhost is not in group ungrouped'

# Generated at 2022-06-21 05:24:56.760394
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test empty host list
    inv = ansible.utils.inventory.InventoryDatabase(None)
    inv_mod = InventoryModule(inv)
    inv_mod._parse(None, [])
    assert inv.list_hosts() == []

    # Test non-empty host list
    inv = ansible.utils.inventory.InventoryDatabase(None)
    inv_mod = InventoryModule(inv)
    inv_mod._parse(None, ["foobar1", "foobar2", "foobar3"])
    assert inv.list_hosts() == [
        'foobar1',
        'foobar2',
        'foobar3'
    ]

    # Test host specification
    inv = ansible.utils.inventory.InventoryDatabase(None)
    inv_mod = InventoryModule(inv)

# Generated at 2022-06-21 05:25:05.814643
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    '''
    This test requires an example file in the testing directory
    '''

    module = InventoryModule(loader=None, inventory=None)
    test_file = os.path.join(os.path.dirname(__file__), '../utils/test_inventory.ini')
    module.parse_inventory(test_file)
    results = dict(module.inventory.groups_list())
    assert 'testgroup1' in results
    assert results['testgroup1']['vars'] == dict(a=1, b=2)
    assert 'testgroup2' in results
    assert results['testgroup2']['vars'] == dict(c=3, d=4)
    assert 'testgroup3' in results
    assert results['testgroup3']['vars'] == dict(e=5, f=6)


# Generated at 2022-06-21 05:25:24.886590
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    '''InventoryModule unit test'''
    path_data = [
        'test/testdata/hosts',
        'test/testdata/hosts.ini'
    ]

    # test constructor of InventoryModule class
    i = InventoryModule(path_data)

# Generated at 2022-06-21 05:25:35.058168
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # pylint: disable=too-many-branches
    ''' constructor for the InventoryModule class '''

    # failed import
    if load_plugin_utils_module is not None:
        # pylint: disable=redefined-outer-name
        load_plugin_utils_module.return_value = None

    inv_mod = InventoryModule()

    assert inv_mod.inventory_class_name == 'InventoryFile'
    assert isinstance(inv_mod.inventory_class, InventoryFile)

    assert inv_mod.inventory_class.pattern_cache is not None
    assert inv_mod.inventory_class.pattern_cache == {}

    assert inv_mod.inventory_class.pattern_cache_regexp is not None
    assert inv_mod.inventory_class.pattern_cache_regexp == {}

    # good import


# Generated at 2022-06-21 05:25:39.586303
# Unit test for constructor of class InventoryModule
def test_InventoryModule():

    # Test constructor without options
    module = InventoryModule()

    # Test constructor with options
    module = InventoryModule(filename='test_hosts.txt', check=False)

# Generated at 2022-06-21 05:25:52.602549
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    im = InventoryModule()
    im._parse('path', ['[ungrouped]', '1.1.1.1', '', '# comment', '[groupname]', '1.1.1.2', '1.1.1.3', '', '[groupname:vars]', 'ansible_ssh_pass=secret', '', '[groupname:children]', 'child_groupname', ''])
    assert(im.inventory.groups['ungrouped'].hosts['1.1.1.1'].vars == {})
    assert(im.inventory.groups['groupname'].hosts['1.1.1.2'].vars == {'ansible_ssh_pass': 'secret'})

# Generated at 2022-06-21 05:25:54.126502
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module is not None

# Generated at 2022-06-21 05:25:56.619788
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print('Testing method parse of class InventoryModule')
    # TODO: Write Unit Test

# Generated at 2022-06-21 05:26:04.374515
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module._parse(path="path",lines=["[groupname]","alpha","beta:2345 user=admin","gamma sudo=True user=root"])

# Generated at 2022-06-21 05:26:16.427578
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_inventory', 'hosts')
    module.parse(path)
    assert module.inventory.hosts['a'].name == 'a'
    assert 'b' in module.inventory.groups['group1'].children
    assert module.inventory.groups['group1'].variables['test1'] == 'group_var1_value'
    assert module.inventory.groups['group2'].variables['test1'] == 'group_var2_value'
    assert module.inventory.groups['group2'].variables['test2'] == 'group_var2_value2'

# Generated at 2022-06-21 05:26:23.849688
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()
    inv.parse("test.txt", '''
[group1]
foo
bar
[group2:children]
group1
    ''')
    assert inv.inventory.groups['group1'].hosts == {'foo': {}, 'bar': {}}
    assert inv.inventory.groups['group1']._parent_groups == []
    assert inv.inventory.groups['group2'].hosts == {}
    assert inv.inventory.groups['group2']._parent_groups == []
    assert inv.inventory.groups['group2']._child_groups == ['group1']
    assert inv.inventory.groups['group1']._child_groups == []


# Generated at 2022-06-21 05:26:38.703736
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test the InvnetoryModule_parse method.

    # Process a string containing valid host inventory.
    test_input = '''
    [group1]
    foo
    bar
    [group1:vars]
    myvar1 = hello
    myvar2 = 42
    [group1:children]
    child1
    child2:children
    childf:vars
    child2
    [group2]
    baz
    '''
    test_input = to_bytes(test_input)
    inventory = InventoryModule(None)
    inventory._parse('/test_InventoryModule_parse', to_lines(test_input))

    # Check the resulting group structure.
    group1 = inventory.inventory.groups['group1']
    group1_vars = group1.get_vars()

# Generated at 2022-06-21 05:27:02.600837
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv.get_option('foo') is None
    assert inv.get_option('foo', 'val') == 'val'
    assert inv.get_option('foo', 'val', boolean=True) is True


# Generated at 2022-06-21 05:27:04.095327
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert isinstance(InventoryModule(), InventoryModule)

# Generated at 2022-06-21 05:27:19.004836
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_cons_obj = InventoryModule(loader=DictDataLoader({'hosts': """
[webservers]
foo ansible_port=5309 ansible_host=192.168.1.5
bar
[dbservers]
one
two
[ungrouped]
example.org ansible_python_interpreter=/usr/bin/python

    """}))
    print(inv_cons_obj)
    for host in inv_cons_obj.get_hosts():
        print(host)
        print(inv_cons_obj.get_host(host.name))
        print(inv_cons_obj.get_host(host.name).vars)
    print(inv_cons_obj.get_group('webservers').vars)

# Generated at 2022-06-21 05:27:34.031834
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import os
    from pprint import pprint
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    current_dir = os.path.dirname(os.path.realpath(__file__))
    inventory_dir = os.path.join(current_dir, 'test_data')

    inventory = InventoryManager(loader=DataLoader(), sources=["%s/hosts" % inventory_dir])
    inv = inventory.hosts

    print("----------\n")

    pprint(inv['all'])
    print('all.vars = %s' % inv['all'].vars)

    print("----------\n")

    pprint(inv['ungrouped'])

# Generated at 2022-06-21 05:27:47.454234
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_data = """
[groupname]
a=10
b=20
c="some string"
d=[1,2,3]
[groupname2]
e=10
f=20
h=[1,2,3]
"""
    inventory_data = inventory_data.replace("\n","\r\n")
    im = InventoryModule("/file/path","groupname")
    im._parse("/file/path", inventory_data.split("\r\n"))
    assert(im.inventory.groups["groupname"]["vars"] == dict(a=10,b=20,c='some string',d=[1,2,3]))
    assert(im.inventory.groups["groupname2"]["vars"] == dict(e=10,f=20,h=[1,2,3]))

# Generated at 2022-06-21 05:27:50.105907
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    invm = InventoryModule()
    assert invm is not None


# Generated at 2022-06-21 05:27:52.780893
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()
    assert isinstance(inventory.inventory, Inventory)

# Unit tests for constructor of class Inventory

# Generated at 2022-06-21 05:28:01.510938
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """Test for method parse of class InventoryModule"""

    # Tests for method parse of class InventoryModule
    # Empty inventory

    inventory = InventoryModule(loader=DictDataLoader())
    inventory.parse([], 'inventory_file')
    assert len(inventory.groups) == 1
    assert 'all' in inventory.groups
    assert len(inventory.groups['all'].get_hosts()) == 0
    assert len(inventory.groups['all'].get_vars()) == 0
    assert len(inventory.groups['all'].get_children()) == 0

    # One group with one host, no vars

    inventory = InventoryModule(loader=DictDataLoader())
    inventory.parse(['[group1]', 'alpha'], 'inventory_file')
    assert len(inventory.groups) == 2
    assert 'group1' in inventory.groups

# Generated at 2022-06-21 05:28:17.592366
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    im = InventoryModule()
    inv = Inventory(None)
    im.inventory = inv


# Generated at 2022-06-21 05:28:19.079731
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    m = InventoryModule()


# Generated at 2022-06-21 05:29:09.612709
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import __main__
    import sys

    from ansible.utils.display import Display
    from ansible.inventory import Inventory

    from ansible.parsing.dataloader import DataLoader

    if __name__ == "__main__":
        parser = InventoryModule(
            loader=DataLoader(),
            variable_manager=VariableManager(),
            host_list=sys.argv[1] if len(sys.argv) > 1 else None,
        )
        inventory = Inventory(loader=parser.loader, variable_manager=parser.variable_manager, host_list=parser.host_list)
        parser.parse(inventory=inventory)

        display = Display()
        display.display(u"%s" % inventory.get_groups_dict())

# Generated at 2022-06-21 05:29:12.523355
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule('inventory_classes/ini.py')
    assert isinstance(inv, InventoryModule)


# Generated at 2022-06-21 05:29:26.163004
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import pytest
    import os

    @pytest.fixture
    def mock_group(mocker):
        def mock_add_group(name):
            return Group(name)
        mocker.patch('ansible.inventory.group.Group.add_group', mock_add_group)

    @pytest.fixture
    def mock_set_variable(mocker):
        mocker.patch('ansible.inventory.group.Group.set_variable')

    @pytest.fixture
    def mock_add_child(mocker):
        mocker.patch('ansible.inventory.group.Group.add_child')


# Generated at 2022-06-21 05:29:31.940840
# Unit test for constructor of class InventoryModule
def test_InventoryModule():

    inventory_module = InventoryModule()
    assert isinstance(inventory_module, InventoryModule)

    assert isinstance(inventory_module.parser, InventoryParser)
    assert isinstance(inventory_module.loader, DataLoader)
    assert isinstance(inventory_module.inventory, Inventory)



# Generated at 2022-06-21 05:29:37.188138
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # create an empty inventory
    im = InventoryModule()
    assert im != None

    assert im.inventory != None
    assert im.inventory.groups != {}
    assert im.inventory.groups['all'].name == 'all'
    assert im.inventory.groups['all'].hosts == {}
    assert im.inventory.hosts[None] == None


# Generated at 2022-06-21 05:29:47.071379
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule(None, None)
    # Test with a None inventory_module
    inventory_module._parse('/tmp/bar', None)
    assert_raises(AnsibleParserError, inventory_module._parse, '/tmp/bar', [])
    inventory_module._parse('/tmp/bar', ['[foo:children]', '[bar:vars]'])
    inventory_module._parse('/tmp/bar', ['[foo:children]', '[foo:vars]'])
    inventory_module._parse('/tmp/bar', ['[foo:vars]', '[bar:children]'])
    # Test with a None hostname
    inventory_module._parse('/tmp/bar', ['', '', '', '', '', ''])
    # Test with a None variable

# Generated at 2022-06-21 05:29:58.074193
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule('my_inventory')
    inv.inventory = Mock()

# Generated at 2022-06-21 05:30:04.621731
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_source = """
    [group1:vars]
    foo=bar
    [group1]
    host1
    host2
    """
    inv = InventoryModule(loader=None)
    inv.parse(inventory_source, 'group_vars', [])
    group1 = inv.get_group('group1')
    assert group1.get_variable('foo') == 'bar'
    assert group1.hosts == ['host1', 'host2']
    assert group1.children == []
    assert group1.vars == {'foo': 'bar'}

# Generated at 2022-06-21 05:30:08.189976
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_module = InventoryModule()
    assert test_module._parse == test_module.parse


# Generated at 2022-06-21 05:30:15.076716
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # simple inventory test
    module = InventoryModule()
    module.parse('/path/to/file', ['[foo]', 'bar'])
    assert module.inventory.groups == dict(foo=dict(hosts=['bar'], vars=dict()))

    # inventory test with host with port
    module = InventoryModule()
    module.parse('/path/to/file', ['[foo]', 'bar:123'])
    assert module.inventory.groups == dict(foo=dict(hosts=['bar'], vars=dict(ansible_ssh_port='123')))

    # inventory test with host with port set to 0
    module = InventoryModule()
    module.parse('/path/to/file', ['[foo]', 'bar:0'])

# Generated at 2022-06-21 05:31:11.510252
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    '''
    Basic unit tests for constructor of class InventoryModule.
    '''

    # Passing in a stream
    module = InventoryModule(object())
    assert isinstance(module, InventoryModule)

    # Passing in a string
    module = InventoryModule('/etc/ansible/hosts')
    assert isinstance(module, InventoryModule)

    # Passing in an invalid type
    with pytest.raises(AnsibleParserError):
        InventoryModule([])  # Data to be in stream or string format.

    # Passing in an ansible.parsing.dataloader.DataLoader object
    dataloader = DataLoader()
    module = InventoryModule(dataloader)
    assert isinstance(module, InventoryModule)

    # Passing in an ansible.parsing.dataloader.DataLoader object with valid loader arguments

# Generated at 2022-06-21 05:31:14.247476
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()
    assert inventory is not None

# Unit test function for the function "_parse"

# Generated at 2022-06-21 05:31:22.288451
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create instance of class
    inventory_module = InventoryModule()
    
    # Create file to test on
    temp_dir = tempfile.mkdtemp()
    temp_file = tempfile.NamedTemporaryFile(mode='w+', dir=temp_dir, delete=False)

# Generated at 2022-06-21 05:31:31.785784
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Define test inventory
    test_data = """
[unittest1]
# comment
host1 http_port=1
host2
host3:4
host4:5 

[unittest3]
host5 

[unittest2:children]
unittest1
unittest2
unittest3

[unittest2:vars]
test_var = 123
test1_var = one two three
    """

    # Setup inventory object
    inv = InventoryModule()
    inv.filename = './test_inventory.ini'
    inv.parse(test_data)

    # Test inventory object
    for group in inv.inventory.groups:
        print("Group: " + group)

# Generated at 2022-06-21 05:31:41.947967
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = Inventory('')
    inventoryFile = InventoryModule(inventory=inventory, filename='samples/inventory_sample')

# Generated at 2022-06-21 05:31:53.647085
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    im = InventoryModule('host_list', None, [{'hostname': 'localhost', 'port': '2222', 'username': 'foo'}])
    assert isinstance(im, InventoryModule)
    assert im.groups == {'all': {'hosts': {}, 'children': {}, 'vars': {}}, 'ungrouped': {'hosts': {}, 'children': {}, 'vars': {}}}
    assert im.hostname == 'host_list'
    assert im.port is None
    assert im.username == 'foo'
    assert im.password is None
    assert im.private_key_file is None
    assert im.public_key_file is None
    assert im.become == False
    assert im.become_user is None
    assert im.become_method is None
    assert im.bec

# Generated at 2022-06-21 05:32:02.358026
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse('[all]\nlocalhost ansible_connection=local ansible_python_interpreter=/usr/bin/python3')
    assert inventory_module.inventory.groups['all'] is not None
    assert inventory_module.inventory.groups['all'].hosts['localhost'] is not None
    assert inventory_module.inventory.groups['all'].hosts['localhost'].vars['ansible_connection'] == 'local'
    assert inventory_module.inventory.groups['all'].hosts['localhost'].vars['ansible_python_interpreter'] == '/usr/bin/python3'
