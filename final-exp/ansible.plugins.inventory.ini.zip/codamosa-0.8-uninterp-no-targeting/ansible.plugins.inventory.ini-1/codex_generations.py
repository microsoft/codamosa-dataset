

# Generated at 2022-06-21 05:22:18.034143
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule('/dev/null')
    assert inv
    assert inv.inventory


# Generated at 2022-06-21 05:22:19.772879
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv is not None


# Generated at 2022-06-21 05:22:21.506247
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' Test deriving a class from InventoryModule. '''

    class TestInventory(InventoryModule):
        pass

    test_inventory = TestInventory()

# Generated at 2022-06-21 05:22:35.366434
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryManager(loader=None, sources=[])
    inv_parser = InventoryModule(loader=None, inventory=inventory)
    inv_parser.parse(path="tests/inventory_samples/test_hosts", cache=False)
    # test for hosts and groups
    assert inventory.hosts['host1'].name == 'host1'
    assert inventory.hosts['host2'].name == 'host2'
    assert inventory.hosts['host3'].name == 'host3'
    assert inventory.hosts['host4'].name == 'host4'
    assert inventory.groups['group1']['hosts'][0].name == 'host1'
    assert inventory.groups['group2']['hosts'][0].name == 'host2'

# Generated at 2022-06-21 05:22:48.627371
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    print("Testing InventoryModule()")

    # InventoryModule(inventory)
    inventory_group1 = Group("group1")
    inventory_group2 = Group("group2")
    inventory_host1 = Host("host1")
    inventory_host2 = Host("host2")

    inventory_group1.add_host(inventory_host1)
    inventory_group1.add_host(inventory_host2)
    inventory_group1.add_child_group(inventory_group2)

    inventory_group2.add_host(inventory_host1)
    inventory_group2.add_host(inventory_host2)

    inventory = Inventory()
    inventory.add_group(inventory_group1)
    inventory.add_group(inventory_group2)
    inventory.add_host(inventory_host1)

# Generated at 2022-06-21 05:22:55.069108
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' inventory_advanced.py:TestInventoryModule:test_Inventory '''

    inventory = InventoryModule('/tmp/etc_ansible_hosts')
    assert isinstance(inventory, InventoryModule)
    assert inventory.__class__.__name__ == 'InventoryModule'

# Generated at 2022-06-21 05:23:08.377368
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_source = '''
    [test_group]
    test1
    test2 ansible_host=10.0.0.5 ansible_port=5555
    test3 ansible_host=10.0.0.6 ansible_port=22
    '''
    # Write the test inventory to a temporary file
    test_inventory_file = mkstemp()
    os.write(test_inventory_file[0], inventory_source)
    os.close(test_inventory_file[0])
    # Do the test
    inventory = Inventory(strict=True)
    im = InventoryModule(inventory)
    im._parse(test_inventory_file[1], inventory_source.split('\n'))
    # Test the result
    os.unlink(test_inventory_file[1])
    # FIXME:

# Generated at 2022-06-21 05:23:10.602345
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory_module = InventoryModule()
    assert isinstance(inventory_module, InventoryModule)


# Generated at 2022-06-21 05:23:13.170396
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()
    assert inventory is not None

# vim: set expandtab smarttab shiftwidth=4:

# Generated at 2022-06-21 05:23:16.592607
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' unit test for constructor of class InventoryModule '''
    _test_inventory = InventoryModule()
    print (_test_inventory)
    print (_test_inventory.params)


# Generated at 2022-06-21 05:23:32.253253
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
  obj = InventoryModule()
  obj.parse("/tmp/test/test.ini")

if __name__ == "__main__":
  test_InventoryModule_parse()

# Generated at 2022-06-21 05:23:35.756624
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' inventory_ini constructor returns an InventoryModule object.'''

    i = InventoryModule()

    assert isinstance(i, InventoryModule)

# Generated at 2022-06-21 05:23:41.250251
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' inventory_script/__init__.py:InventoryModule() unit test'''

    ###########################################################################
    # Construct the module object
    ###########################################################################

    module = InventoryModule()

    ###########################################################################
    # Parse the script arguments
    ###########################################################################


# Generated at 2022-06-21 05:23:45.534811
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
  """
  Test that the method `parse` of class `InventoryModule`

  - Test 1
  - Test 2
  """

  
  pass




# Generated at 2022-06-21 05:23:49.988585
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ini_path = os.path.join(os.path.dirname(__file__), 'inventory_ini_1.ini')
    inventory = InventoryModule(path=ini_path)
    print(inventory.groups)

if __name__ == "__main__":
    test_InventoryModule()


# Generated at 2022-06-21 05:23:51.579998
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # TODO: implement
    pass


# Generated at 2022-06-21 05:24:02.562390
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
  inv = dict()
  inv["groups"] = {
    "ungrouped": {
      "vars": {},
      "children": []
    }
  }
  inv["_meta"] = {
    "hostvars": {}
  }
  inv["web"] = {
    "vars": {},
    "hosts": {}
  }
  inventory = Inventory(inv)
  mod = InventoryModule()
  mod._filename = "test_hosts"
  mod._inventory = inventory
  module_args = dict()
  module_args["host_file"] = "test_hosts"
  module_args["host_list"] = []
  mod.run(module_args, 'local')
  assert mod.lineno == 3

if __name__ == "__main__":
  test_InventoryModule

# Generated at 2022-06-21 05:24:12.413095
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_data = '''
[group1]
host1
host2
host3

[group2]
host3
host4

[all:children]
group1
group2

[group1]
host1
host2
host3
'''

    inventory_dir = os.path.dirname(__file__)
    file_name = "%s/hosts.ini" % inventory_dir

    with open(file_name, 'w') as f:
        f.write(inventory_data)

    parser = InventoryModule(filename=file_name)
    parser.parse()

    assert parser.inventory.get_groups() == ['all', 'group1', 'group2'], "groups was %s" % parser.inventory.get_groups()

# Generated at 2022-06-21 05:24:13.784495
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()
    assert inventory is not None

# Generated at 2022-06-21 05:24:22.741437
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # In this unit test we try to create an InventoryModule and pass it some text
    # We then try to parse it with the parse function and make sure it returns the
    # proper structure
    class NullDisplay:
        verbosity  = 0

# Generated at 2022-06-21 05:24:41.499442
# Unit test for constructor of class InventoryModule

# Generated at 2022-06-21 05:24:44.142938
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv is not None

# Unit tests for private method _compile_patterns

# Generated at 2022-06-21 05:24:56.039940
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    #print("testing method 'parse' of class InventoryModule")

    # 1. test with valid ini file

    # get the content of  file for testing
    # file is in the same directory with test_ini.py
    curdir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(curdir, "valid1.ini")
    with open(file_path, "r") as f:
        lines = f.readlines()

    # set the host pattern matcher
    # use the default one
    #hp = HostPattern(host_pattern)

    # create a InventoryModule instance
    #im = InventoryModule(patterns = [hp])
    im = InventoryModule()
    # parse the file
    im.parse(file_path, lines)

    #

# Generated at 2022-06-21 05:25:09.568528
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import os
    import tempfile
    tf = tempfile.NamedTemporaryFile(prefix='ansible_inventory_module_', delete=False)
    tf.write(b"""
[test]

test1
test2:1234

test1,test2 some_host_var=3 value=3

[test2:vars]

[test:children]
test2

""")
    tf.close()

    inventoryModule = InventoryModule(loader=DictDataLoader({}))
    inventoryModule._read_config_data(path=tf.name)
    assert len(inventoryModule.inventory.groups) == 2
    assert inventoryModule.inventory.groups['test'].get_hosts()[0].name == 'test1'

# Generated at 2022-06-21 05:25:12.107779
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_module = InventoryModule.load()
    assert inv_module.__class__.__name__ == 'InventoryModule'
    assert inv_module.read_file == InventoryModule.read_file


# Generated at 2022-06-21 05:25:23.596690
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryManager([])
    mod = InventoryModule(inventory, None)
    data = StringIO()
    data.write(u'[1]\n')
    data.write(u'[1:vars]\n')
    data.write(u'[2]\n')
    data.write(u'[2:children]\n')
    data.write(u'[3]\n')
    data.write(u'[3:vars]\n')
    data.write(u'[4:children]\n')
    data.seek(0)
    mod._parse('string_io', data.read().splitlines())
    assert len(inventory.groups.keys()) == 2

# Generated at 2022-06-21 05:25:25.860993
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = 'test'
    inventory = Inventory(Loader)
    config = {}
    InventoryModule(module, inventory, config)

    assert module == 'test'
    assert inventory == Inventory(Loader)
    assert config == {}

# Generated at 2022-06-21 05:25:35.433808
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-21 05:25:36.317688
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    i = InventoryModule()
    assert isinstance(i, InventoryModule)
    assert isinstance(i.inventory, Inventory)

# Generated at 2022-06-21 05:25:39.844254
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    """
    Creates a new InventoryModule object.
    """

    inventory = InventoryModule([], [])

    assert isinstance(inventory, InventoryModule)


# Generated at 2022-06-21 05:26:12.011966
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # Test that no errors are thrown when creating an InventoryModule
    # with a normal path.
    path = os.path.dirname(__file__)
    InventoryModule(path=path)

    # Test that an error is thrown when we give a bad path or we don't
    # provide one.
    path = 'this_path_does_not_exist'
    try:
        InventoryModule(path=path)
    except AnsibleError:
        pass
    else:
        raise Exception("InventoryModule failed to throw an error with a bad path")

    try:
        InventoryModule()
    except AnsibleError:
        pass
    else:
        raise Exception("InventoryModule failed to throw an error with no path requested")


# Generated at 2022-06-21 05:26:23.030521
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test a successful parse of a well formed inventory file

    # Create an instance of the class for testing
    inventory_test = InventoryModule()

    # Specify inventory file to test
    inv_fp = "test.inventory"

    # Expected data to be returned from parse
    expected = {
        'all': ['localhost'],
        '_meta': {
            'hostvars': {
                'localhost': {
                    'ansible_connection': 'local',
                    'ansible_host': 'localhost',
                    'var1': 'hit',
                    'var2': 'hit',
                    'var3': 'hit',
                    'var4': 'hit'
                }
            }
        },
        'ungrouped': ['localhost']
    }

    # Create temporary inventory file to test

# Generated at 2022-06-21 05:26:38.293159
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # These tests assume this inventory:
    #
    # [groupname]
    # # some comment
    # host01
    # host02 # other comment
    #
    # [groupname:vars]
    # # some comment
    # a=1
    # b="2"
    # c=3 # other comment
    #
    # [groupname:children]
    # # some comment
    # child01
    # child02 # other comment
    #
    # [child01]
    # host[03:05]

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    dl = DataLoader()
    im = InventoryManager(loader=dl, sources='/dev/null')

    iom = InventoryModule(im)
    iom._filename

# Generated at 2022-06-21 05:26:42.583446
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert isinstance(inv, InventoryModule)

    # Localhost needs to be defined!
    assert inv.get_host('localhost') == '127.0.0.1'



# Generated at 2022-06-21 05:26:54.020537
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # Create an InventoryModule object from a simple file.
    inv = InventoryModule(filename="tests/inventory", parser=IniParser)

    # Check the number of groups in inventory
    groups_length = len(inv.inventory.groups)
    assert groups_length == 6

    # Check if the group 'group2' exists
    group2 = inv.inventory.groups.get('group2')
    assert group2 is not None

    # Check if the group 'group3' exists
    group3 = inv.inventory.groups.get('group3')
    assert group3 is not None

    # Check if the group 'group1' exists
    group1 = inv.inventory.groups.get('group1')
    assert group1 is not None

    # Check if the host 'a' exists
    a = inv.inventory.get_host('a')

# Generated at 2022-06-21 05:27:04.765744
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    i = InventoryModule(None)
    i._read_pattern = MagicMock()
    i._read_pattern.return_value = ['a']
    i._parse_host_definition = MagicMock()
    i._parse_host_definition.return_value = [['h1'], [9999], {'k1': 'v1'}]
    i._populate_host_vars = MagicMock()

    s = StringIO()
    with redirect_stdout(s):
        i.parse('h', 'fake_path')
    output = s.getvalue().strip()

    assert output == '''\
[h]
h1 ansible_port=9999 k1=v1'''

# Generated at 2022-06-21 05:27:06.751073
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()
    assert isinstance(inventory, InventoryModule)


# Generated at 2022-06-21 05:27:15.353407
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    if DEBUG_TESTS:
        print("\n***test_parse***")

    test_lines = ['[groupname]',
                  '[somegroup:vars]',
                  '[naughty:children] # only get coal in their stockings',
                  "groupname:vars",
                  "somegroup",
                  "naughty:children"] # noqa

    # test_sections = [dict(groupname='groupname', state='hosts'),
    #                  dict(groupname='somegroup', state='vars'),
    #                  dict(groupname='naughty', state='children'),
    #                  dict(groupname='groupname:vars', state='hosts'),
    #                  dict(groupname='somegroup', state='hosts'),
    #                  dict(groupname='naughty', state='children')]

    module = InventoryModule

# Generated at 2022-06-21 05:27:28.078869
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryManager(loader=DictDataLoader())
    inventory.set_playbook_basedir("")
    module = InventoryModule(loader=DictDataLoader())
    groups = module._parse("hosts", ["[foo]", "#comment", "a b", "a b c=1", "a b c=1 d=2", "[foo:children]", "bar", "[bar]", "[foo:vars]", "foo=bar", "a b c=1 d=2", "foo=bar", "foo=baz", "[foo:vars]", "foo=baz"])

# Generated at 2022-06-21 05:27:33.273154
# Unit test for constructor of class InventoryModule
def test_InventoryModule():

    class Options():
        pass

    opts = Options()

    opts.inventory = "inventory_file.ini"
    opts.list = True
    opts.host = None

    inv_mod = InventoryModule(loader=None, variable_manager=None, options=opts)

    assert inv_mod is not None


# Generated at 2022-06-21 05:28:28.025689
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryManager(loader=DataLoader())
    inventory.set_source("[testgroup]\ntesthost:port=123")
    inventory_parser = InventoryModule(inventory=inventory)
    assert len(inventory.groups.values()) == 1
    assert len(inventory.hosts.values()) == 1
    assert next(inventory.hosts.values()).port == 123

# Generated at 2022-06-21 05:28:31.193501
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_module = InventoryModule()
    assert inv_module.__class__.__name__ == 'InventoryModule'



# Generated at 2022-06-21 05:28:38.443800
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """
    Unit test for method parse of class InventoryModule
    """
    module = InventoryModule()

    # Check if the test variable is there
    module.parse('[unittest_group]\nfoo.example.com\n[another_group]\nbar.example.com\n[unittest_group:vars]\nansible_ssh_port=222\nanother_var=42')
    assert 'unittest_group' in module.inventory.groups
    assert 'another_group' in module.inventory.groups
    assert module.inventory.groups['unittest_group'].vars['ansible_ssh_port'] == 222
    assert module.inventory.groups['another_group'].vars['another_var'] == 42

    # Check if unittest_group is there with 1 host

# Generated at 2022-06-21 05:28:44.546408
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # TODO: Add tests for more methods
    module = AnsibleModule({},
                           supports_check_mode=True)
    inventory = Inventory(module)
    inventory_module = InventoryModule()
    inventory_module.update_cache_if_changed()
    #inventory_module.parse(to_bytes('hosts'), None, inventory, None, cache=False)
    #inventory_module.read_or_reload_file('hosts')
    os.getcwd()
    #path = '/Users/tommy/software/ansible/lib/ansible/plugins/inventory/ini.py'
    path = '/Users/tommy/software/ansible/inventory/localhost'
    cache_file = '/Users/tommy/software/ansible/inventory/localhost.cache'
    #inventory_module.parse(path, None, inventory

# Generated at 2022-06-21 05:28:55.808787
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
   inventory_ini = """
[group1]
host1 ansible_ssh_host=203.0.113.10 ansible_ssh_port=22 ansible_user=user
host2 ansible_ssh_host=203.0.113.11 ansible_ssh_port=22 ansible_user=user
[group2]
host3 ansible_ssh_host=203.0.113.12 ansible_ssh_port=22 ansible_user=user
[group3:children]
group1
group2
[group4:vars]
ansible_connection=local
ansible_ssh_host=203.0.113.13
ansible_ssh_port=22
ansible_user=user
"""


# Generated at 2022-06-21 05:29:03.697405
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    '''
    Make sure the constructor of class InventoryModule works as
    intended.
    '''
    inventory = InventoryModule()
    assert inventory.filename == 'default.inventory'
    assert inventory.is_playbook
    assert isinstance(inventory.inventory, Inventory)
    assert isinstance(inventory.loader, DataLoader)

    inventory = InventoryModule('test.inventory', False)
    assert inventory.filename == 'test.inventory'
    assert not inventory.is_playbook
    assert inventory.inventory is None
    assert inventory.loader is None



# Generated at 2022-06-21 05:29:19.069855
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import pytest
    inventory = Inventory(None)
    spec = 'test/test_inventory/test.ini'

    inventory_module = InventoryModule(inventory, spec)

    # inventory_module.parse()
    inventory_module._parse(spec, [u'[test]', u'localhost ansible_connection=mock'])
    assert len(inventory.groups) == 1
    assert inventory.groups['test'] is not None
    # group = inventory.groups['test']
    # assert group.name == 'test'
    assert len(inventory.get_hosts()) == 1
    assert inventory.get_host('localhost').name == 'localhost'

if __name__ == '__main__':
    pytest('test_inventory.py', '-v', '-x')

# Generated at 2022-06-21 05:29:28.844816
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()
    lines = """# test inventory file
    [testgroup]
    testhost
    10.10.1.1 foo=bar bam=baz
    10.10.1.2 foo=bar baz=bam
    [testgroup:children]
    [testgroup:vars]
    testvar=testvalue
    [testgroup2:vars]
    testvar2=testvalue2
    """
    inv._parse('test', lines.split('\n'))
    assert (inv.inventory.groups['testgroup'].name == 'testgroup')
    assert ('testvar' in inv.inventory.groups['testgroup'].vars)
    assert ('testvar2' in inv.inventory.groups['testgroup2'].vars)

# Generated at 2022-06-21 05:29:41.122820
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print("[debug] test_InventoryModule_parse()")
    # executable = [sys.executable]
    # command = [sys.executable, '-m', 'ansible.inventory.InventoryModule']
    # command = executable + command
    i = InventoryModule()

# Generated at 2022-06-21 05:29:43.219483
# Unit test for constructor of class InventoryModule
def test_InventoryModule():

    inv = InventoryModule()
    assert inv is not None


# Generated at 2022-06-21 05:31:24.520462
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # This test is somewhat difficult because the constructor of InventoryModule
    # may have side effects, including generating exceptions that it cannot
    # handle. We should consider refactoring the code to separate construction
    # from parsing.

    # Create an inventory instance for testing.
    inventory = Inventory("")

    # Simple successful case
    data = """
    [group1]
    localhost

    [group2:vars]
    test=ok
    """
    m = InventoryModule(inventory=inventory)
    m.parse_source("", data)

    assert inventory.get_groups_dict() == {'group1': {'hosts': ['localhost'], 'vars': {}},
                                           'group2': {'hosts': [], 'vars': {'test': 'ok'}}}

    # Whitespace handling

# Generated at 2022-06-21 05:31:26.733830
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule(filename=C.DEFAULT_HOST_LIST)
    assert isinstance(inventory, InventoryModule), "inventory should be an object of type Inventory"


# Generated at 2022-06-21 05:31:39.016652
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    lines = textwrap.dedent("""
        [test1]
        var1=foo
        localhost ansible_connection=local
        """).splitlines()
    inv_mod = InventoryModule()
    inv_mod.parse('/non/existing', lines)
    assert inv_mod.inventory.get_groups_dict().has_key('test1')
    test1 = inv_mod.inventory.get_groups_dict()['test1']
    assert test1.get_variables() == {'var1': 'foo'}
    assert inv_mod.inventory.get_host('localhost').get_variables() == {'ansible_connection': 'local'}


# Generated at 2022-06-21 05:31:50.475131
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    host_list = [
        {
            'hostname': '104.154.175.141',
        },
        {
            'hostname': '104.155.10.153',
        },
        {
            'hostname': '104.155.14.248',
        },
    ]
    path = '/tmp/test'
    data = [
        '[all]',
        '104.154.175.141',
        '104.155.10.153',
        '104.155.14.248',
        '',
        '# some comment',

    ]
    inventory = Inventory(host_list=host_list)
    im = InventoryModule(inventory)
    im._parse(path, data)



# Generated at 2022-06-21 05:31:53.922847
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert 'InventoryModule' in globals()
    im = InventoryModule()
    assert isinstance(im, InventoryModule)


# Generated at 2022-06-21 05:32:02.660992
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    if not isinstance(module, InventoryModule):
        raise AssertionError('Failed to initialize InventoryModule')
    test_file = tempfile.NamedTemporaryFile(mode='w+t', prefix='ansible-test-inventory-', delete=False)
    test_file_name = test_file.name
    test_file.write('[test_group]\n')
    test_file.write('localhost ansible_connection=local\n')
    test_file.seek(0)
    try:
        module.parse(test_file_name)
    finally:
        test_file.close()
        os.unlink(test_file_name)
