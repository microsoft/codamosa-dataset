

# Generated at 2022-06-21 05:22:20.485917
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' inventory_test inventory_module constructor test '''
    show_inventory_directive = os.environ.get('SHOW_INVENTORY_DIRECTIVE', False)
    inventory_module = InventoryModule(show_inventory_directive=show_inventory_directive)

    print("inventory_module.__dict__")
    pprint.pprint(inventory_module.__dict__)

    print("")
    print("inventory_module.inventory.__dict__")
    pprint.pprint(inventory_module.inventory.__dict__)


# Generated at 2022-06-21 05:22:34.215603
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Todo:  Test is failing due to fact that the InventoryModule is
    # importing the underlying base class in it's constructor, hence
    # not being able to be initialized without the base class being restored
    # to the original version.
    inv_parser = InventoryModule(loader, 'ansible')
    # Define some test input
    filename = './tests/inventory/test_inventory.yml'
    with open(filename, 'r') as f:
        test_input = f.readlines()
    # define expected output

    inv = Inventory(loader=loader)
    inv.add_group('all')
    inv.add_group('ungrouped')
    inv.add_group('group1')
    inv.add_group('group2')
    inv.add_group('group3')

# Generated at 2022-06-21 05:22:47.893001
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse('/etc/ansible/hosts', "localhost ansible_connection=local")
    inventory_module.parse('/etc/ansible/hosts', "[test_g1]")
    inventory_module.parse('/etc/ansible/hosts', "localhost ansible_connection=local")
    inventory_module.parse('/etc/ansible/hosts', "test_g2:")
    inventory_module.parse('/etc/ansible/hosts', """host1 ansible_connection=local ansible_ssh_port=22 ansible_ssh_host=127.0.0.1\nhost2 ansible_connection=nonlocal\nhost3""")

# Generated at 2022-06-21 05:22:50.897862
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module is not None


# Generated at 2022-06-21 05:22:55.467013
# Unit test for constructor of class InventoryModule
def test_InventoryModule(): # pylint: disable=invalid-name
    ''' constructor of class InventoryModule '''
    inventory_module = InventoryModule()
    inventory_module.get_host_variables("local", {}, True)

# Generated at 2022-06-21 05:22:59.797273
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    '''
    Unit test for constructor of class InventoryModule
    '''
    inventory = InventoryModule()

    assert inventory is not None


# Generated at 2022-06-21 05:23:09.692288
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """
    #
    # Unit test for method parse of class InventoryModule
    #
    """
    sample_hosts = '''
    [ungrouped]
    go : 10.1.1.1 user=root sudo=True
    test a.b.c.d user=root sudo=True
    test a.b.c.d:123 user=root sudo=True
    alpha beta gamma user=root sudo=True
    [group1]
    host1 ansible_port=22 ansible_host=10.1.1.1
    [group2]
    host1
    host2
    '''

    # Create a temporary test file
    fd, path = tempfile.mkstemp(prefix='ansible_inventory_')
    os.close(fd)

    # Write sample data to file

# Generated at 2022-06-21 05:23:13.986632
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    a = InventoryModule()
    # test if default file is set
    if a._filename != DEFAULT_HOST_LIST:
        raise Exception('Default file for _filename not set.')


# Generated at 2022-06-21 05:23:16.387734
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule("name", False, False)
    assert module.parse("test.ini", "") == None


# Generated at 2022-06-21 05:23:31.705872
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    host1 = Host(name="local", port=22)
    host2 = Host(name="remote", port=22)
    group1 = Group(name="ungrouped")
    group1.add_host(host1)
    group1.add_host(host2)
    group2 = Group(name="nogroup")
    group2.add_child_group(group1)
    
    inventory = Inventory([])
    inventory.add_group(group1)
    inventory.add_group(group2)
    inventory.add_host(host1)
    inventory.add_host(host2)
    inventory.get_host("local").set_variable("foo", "bar")
    inventory.get_host("local").set_variable("ansible_ssh_pass", "pass123")

# Generated at 2022-06-21 05:24:03.465144
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-21 05:24:07.266393
# Unit test for constructor of class InventoryModule
def test_InventoryModule():

    # See if the class of the result is InventoryModule
    assert isinstance(InventoryModule(), InventoryModule)

    # See if the class of the result is InventoryModule
    # and the constructor did provide a file path
    assert isinstance(InventoryModule(path='test'), InventoryModule)


# Generated at 2022-06-21 05:24:14.457448
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    data = '''
[group1]
foo1

[group1:vars]
ansible_ssh_host=host1

[group2]
foo2 ansible_ssh_host=host2

[group2:vars]
foo=bar

[group3]
foo3

[ungrouped]
foo4

'''

    filename = os.path.join(os.path.dirname(__file__), 'test_inventory.ini')
    with open(filename, 'w') as f:
        f. write(data)

    inv = InventoryModule()
    inv.parse_inventory(filename)

# Generated at 2022-06-21 05:24:23.205164
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    filename = 'tests/inventory/test_inventory.ini'
    inventory = InventoryModule(loader=None)
    inventory.read_inventory(filename)
    assert isinstance(inventory.inventory, Inventory)
    assert inventory.inventory.groups == {'ungrouped': group.Group('ungrouped'),
                                          'all': group.Group('all'),
                                          'web': group.Group('web'),
                                          'web:children': group.Group('web:children'),
                                          'london': group.Group('london'),
                                          'london:children': group.Group('london:children')}

# Generated at 2022-06-21 05:24:30.958848
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    data = u'''
    [ungrouped]
    foo
    [servers]
    dbserver ansible_ssh_host=10.0.0.51
    appserver ansible_ssh_host=10.0.0.60
    '''
    data = to_bytes(data)
    data = io.BytesIO(data)
    # If nothing is defined in inventory, data.readlines() returns empty list
    # which causes error in _parse method.
    # So return one empty line to test _parse method.
    data.readline = lambda: u''
    # if parse method has been validated, _parse method will be tested.
    # This is not a perfect unit test, but it is the simplest.
    i = InventoryModule()
    i.read_file = lambda x: None
    i.parse(data)

# Generated at 2022-06-21 05:24:43.793206
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule(dict())
    assert isinstance(inventory, InventoryModule)
    assert isinstance(inventory.patterns, dict)
    assert isinstance(inventory.host_patterns, dict)
    assert isinstance(inventory.groups, dict)
    assert inventory.inventory is None
    assert inventory.filename is None
    assert inventory.parser is None
    assert inventory.host_list is None
    assert inventory._restriction is None
    assert inventory._subset is None
    assert inventory.inventory_basedir is None
    assert inventory.vars_plugins is None
    assert inventory.enable_plugins is None
    assert not inventory._options
    assert not inventory._vars
    assert not inventory.yamlfiles
    assert inventory.lineno == 0
    assert inventory.plugin_filenames is None


# Generated at 2022-06-21 05:24:51.895315
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    '''
    Test the constructor of the InventoryModule class.

    :returns: ``True`` on success and ``False`` on failure.
    '''

    # Construct an InventoryModule object.
    module = InventoryModule()

    # We expect the object to be an instance of the InventoryModule class.
    assert isinstance(module, InventoryModule)

    return True


# Generated at 2022-06-21 05:25:03.642882
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' inventory_ini.py:Test for InventoryModule. '''

    def n(x):
        return to_bytes(x, errors='surrogate_or_strict')

    module = InventoryModule()
    assert isinstance(module, InventoryModule)

    assert module._get_base_parser() == ConfigParser.RawConfigParser
    assert module._get_parser_options() == dict(allow_no_value=True)

    assert module._COMMENT_MARKERS == '#;'
    assert module.patterns == {}
    assert module.lineno == 0

    # Test empty

    data = ''
    path = ':memory:'

    group = dict()
    def add_group(self, groupname):
        group[groupname] = dict(name=groupname, children=[], host=[], vars={})
    Inventory

# Generated at 2022-06-21 05:25:14.352393
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Testing args
    # Arg 1: path
    # Arg 2: data
    # Return nothing
    
    # BEGIN of test code
    # We test the argument path
    # The ansible.cfg file is located in the ansible folder of the user
    # We stock the content of it in the obj config, then we get the path of the inventory file
    # If the inventory file is not set in ansible.cfg, the default path is /etc/ansible/hosts
    config = configparser.ConfigParser()
    config.read(expanduser('~')+'/.ansible/ansible.cfg')
    try:
        default_inventory = config.get('defaults','inventory')
    except:
        default_inventory = '/etc/ansible/hosts'
    path = default_inventory
    # If the inventory file does not exist

# Generated at 2022-06-21 05:25:25.284786
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryModule()
    lines = []

    lines.append("[group1]")
    lines.append("host1 ansible_port=2222")
    lines.append("[group2]")
    lines.append("host2")
    lines.append("[group2:vars]")
    lines.append("ansible_user=root")
    lines.append("[ungrouped]")
    lines.append("localhost")

    path = "/etc/ansible/hosts"
    inventory._parse(path, lines)

    assert set(inventory.groups.keys()) == set(['group1','group2','ungrouped'])

    assert inventory.groups['group1'].hosts['host1'].vars == {'ansible_port':2222}

# Generated at 2022-06-21 05:26:21.952979
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Arrange
    inventory_path = "tests/data/test_InventoryModule_parse/inventory"

    # Act
    module = InventoryModule()
    with open(inventory_path, "r") as inventory_file:
        module.parse(inventory_file.read())

    # Assert
    tools.assert_equals(module.inventory.list_hosts(), set(['some_host']))
    tools.assert_equals(module.inventory.list_groups(), set(['a_group']))
    tools.assert_equals(module.inventory.get_host(hostname='some_host').get_vars(), dict(my_var='foo'))
    tools.assert_equals(module.inventory.get_host(hostname='some_host').get_group_vars(), dict(group_var='bar'))

# Generated at 2022-06-21 05:26:24.071741
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert not module.fail_on_error


# Generated at 2022-06-21 05:26:24.797229
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert isinstance(module, InventoryModule)


# Generated at 2022-06-21 05:26:35.092895
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_file_content = """
[group1]
aaa 
bbb

[group2:children]
group1

[group2:vars]
ansible_ssh_private_key_file=/tmp/private.key
ansible_ssh_user=root
    """

    inventory_file_content_with_invalid_child = """
[group1]
aaa 
bbb

[group2:children]
group1
group2 

[group2:vars]
ansible_ssh_private_key_file=/tmp/private.key
ansible_ssh_user=root
    """


# Generated at 2022-06-21 05:26:46.827368
# Unit test for constructor of class InventoryModule
def test_InventoryModule():

    # Construct an instance of InventoryModule with empty string
    inventory_module = InventoryModule('', '')

    # Should have an Inventory object (internal variable _inventory)
    assert isinstance(inventory_module._inventory, Inventory)
    # Should have a _hosts variable (dictionary)
    assert isinstance(inventory_module._hosts, dict)
    # Should have an empty list of _patterns (private variable)
    assert isinstance(inventory_module._patterns, list)
    # Should have a _filename variable (private variable)
    assert isinstance(inventory_module._filename, str)

    # Should have a list of _COMMENT_MARKERS (private variable)
    assert isinstance(inventory_module._COMMENT_MARKERS, list)

# Generated at 2022-06-21 05:26:50.637147
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' inventory_ini.py:TestInventoryModule:test_InventoryModule '''

    inventory = InventoryModule()
    group = inventory.inventory.get_group("all")
    assert group.get_variable("ansible_connection") == "ssh"
    assert group.get_variable("ansible_ssh_user") == "root"


# Generated at 2022-06-21 05:26:57.762476
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = Inventory("")
    inventory._vars = {"ansible_ssh_user":"vagrant"}
    parser = InventoryModule(inventory, "/home/vagrant/inventory")

# Generated at 2022-06-21 05:27:07.055499
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
	#test_data = """
	#[foo]
	#ansible ansible_host=192.168.0.10
	#[bar:vars]
	#ansible_host=bar.example.com
	#"""
	test_data = """
	[win32_group]
	win_ansible ansible_host=192.168.0.140 ansible_winrm_server_cert_validation=ignore
		
	[linux_group]
	linux_ansible ansible_host=192.168.0.200
	"""
	#create instance of InventoryModule
	inventory = InventoryModule()
	#inject test data
	inventory.parse(test_data, "inventory_configfile")
	print("inventory_configfile: begin")
	print(inventory.inventory.hosts)

# Generated at 2022-06-21 05:27:15.468553
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Parameter 'data' is a list of lines
    data = [
        '# a comment',
        '[groupname]',
        'host1 var1=1',
        'host2 var2=2',
        '[group2]',
        'host3 var3=3'
    ]
    inventory_module = InventoryModule('filename')
    inventory_module.parse(data)
    # print(inventory_module.inventory.groups)

# Generated at 2022-06-21 05:27:28.156956
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import os
    import os.path
    script_dir = os.path.dirname(__file__)
    test_inventory = os.path.join(script_dir, './test_filter_plugins/test_inventory.ini')
    module = InventoryModule(filename=test_inventory)
    assert module._filename == test_inventory
    assert module._hosts_list == ['testhost1.localdomain', 'testhost2.localdomain']
    assert module.inventory._groups['ungrouped']._vars == {'foo': 'bar', 'spam': 'ham'}
    assert module.inventory.groups['group1']._vars == {'foo': 'baz', 'spam': 'eggs'}

# Generated at 2022-06-21 05:28:12.683329
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    im = InventoryModule()
    assert im.get_default_group() == 'ungrouped'

# Generated at 2022-06-21 05:28:14.115599
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
  pass # test already implemented in InventoryModule

# Generated at 2022-06-21 05:28:21.770585
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    test_path = 'test/test_inventory_module.txt'

    inventory_module.parse(test_path, None)
    assert inventory_module.inventory.get_group('ungrouped')
    assert inventory_module.inventory.get_group('ungrouped').get_host('alpha')
    assert inventory_module.inventory.get_group('ungrouped').get_host('beta')
    assert inventory_module.inventory.get_group('ungrouped').get_host('gamma')
    assert inventory_module.inventory.get_group('ungrouped').get_host('alpha').get_vars()['user'] == 'admin'
    assert inventory_module.inventory.get_group('ungrouped').get_host('beta').get_vars()['user'] == 'admin'

# Generated at 2022-06-21 05:28:29.810319
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    im = InventoryModule()
    assert im.vars == dict()
    assert im.patterns == dict()
    assert isinstance(im.inventory, Inventory)

if __name__ == '__main__':

    inv = Inventory()
    im = InventoryModule(inventory=inv)
    im.parse_inventory(sys.argv[1])
    print(json.dumps(inv.groups, sort_keys=True, indent=4))

# Generated at 2022-06-21 05:28:41.647824
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    '''inventory_test_InventoryModule'''
    setup_loader()
    # Create the inventory
    i = InventoryModule()

    # Verify it has no hosts
    if len(i.get_hosts()) > 0:
        raise Exception("Expected zero hosts")

    # Verify it has no groups
    groups = i.get_groups()
    if len(groups) > 0:
        raise Exception("Expected zero groups")

    # Create the groups and hosts
    i.add_group("group1")
    i.add_host("192.0.2.10")
    i.add_host("192.0.2.11")
    i.add_child("group1", "192.0.2.10")
    i.add_child("group1", "192.0.2.11")

    # Verify the hosts

# Generated at 2022-06-21 05:28:54.166397
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    print ("--- BEGIN Unit test for constructor of class InventoryModule ---")
    # construct a test Inventory
    test1_inventory = Inventory(host_list=[])
    print ("Host list of this Inventory:")
    print (test1_inventory.host_list)
    print ("Host list of each group in this Inventory:")
    for name, group in test1_inventory.groups.items():
        print ("Group: " + name)
        print (group.get_hosts())
        print ("Children of this group:")
        print (group.get_children())
        print ("Variables of this group:")
        print (group.get_variables())
    print ("--- END Unit test for constructor of class InventoryModule ---\n")


# Generated at 2022-06-21 05:29:01.528031
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module_args = dict(
        path='/path/to/file',
        plugin='auto'
    )
    module = utils.import_module_from_path('lib/ansible/module_utils/basic.py')
    module = module.AnsibleModule(module_args)
    inv_module = InventoryModule(module)
    assert isinstance(inv_module, InventoryModule)


# Generated at 2022-06-21 05:29:11.595190
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # Create the inventory object
    inv_obj = InventoryModule()

    # Check the read_file
    assert not inv_obj.read_file
    assert not inv_obj.config_file_path 

    # Check the host list
    assert len(inv_obj.hosts) == 0
    assert inv_obj.groups == dict()
    assert inv_obj.get_hosts('') == list()
    assert inv_obj.get_host('foonotahost') == None


# Generated at 2022-06-21 05:29:25.737375
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    # InventoryModule._parse unit test
    '''

    # Initialization
    inventory_module = InventoryModule('foo')

    # Check error
    with pytest.raises(AnsibleError) as pytest_wrapped_e:
        inventory_module._parse('/path/to/inventory', None)
    assert 'is not a valid file' in pytest_wrapped_e.value.message

    # Check error
    with pytest.raises(AnsibleError) as pytest_wrapped_e:
        inventory_module._parse('/path/to/inventory', '')
    assert 'is not a valid file' in pytest_wrapped_e.value.message

    # Check success
    inventory_module._parse('path/to/inventory', ['# comment', '[group1]'])

# Generated at 2022-06-21 05:29:29.031694
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # No suitable test provider
    return

# vim: set et ts=4 sw=4:

# Generated at 2022-06-21 05:30:14.520791
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # tests the _parse() method
    pass



# Generated at 2022-06-21 05:30:25.087986
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
	inv_module = InventoryModule()
	# create a file
	f = open("test_parse_ini","w+")
	f.write("[group1]\n")
	f.write("host1:port=1234 vars=y\n")
	f.write("host2 vars=x\n")
	f.write("[group1:vars]\n")
	f.write("somevar=somevalue\n")
	f.write("[ungrouped]\n")
	f.write("host3:port=4567 vars=z\n")
	f.write("host4\n")
	f.write("[group2]\n")
	f.write("host10 vars=m\n")
	f.write("host20\n")
	f.close()
	

# Generated at 2022-06-21 05:30:37.432970
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    path_to_inventory = 'test/test_inventory'
    inventory = InventoryModule(path_to_inventory)
    # test constructor
    assert len(inventory._InventoryModule__cache) == 0

    # test clear_cache
    inventory.clear_cache()
    assert len(inventory._InventoryModule__cache) == 0

    # test get_cache
    assert inventory._InventoryModule__get_cache() == {}

    # test set_cache
    inventory._InventoryModule__set_cache({'a': 1})
    assert inventory._InventoryModule__get_cache() == {'a': 1}

    # test get_group_vars_for_host
    assert inventory._InventoryModule__get_group_vars_for_host('test_host') == []

    # test get_host_vars
    assert inventory._In

# Generated at 2022-06-21 05:30:43.961700
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    test _parse method of InventoryModule class
    '''
    module = InventoryModule([])
    assert not hasattr(module, '_compile_patterns')
    path = os.path.join(os.path.dirname(__file__), 'test_inventory_module.ini')
    module.parse(path)
    assert module.inventory.groups['ungrouped'].hosts.keys() == ['foo', 'somehost', 'somehost1']
    assert module.inventory.groups['group1'].hosts.keys() == ['somehost1', 'somehost2']
    assert module.inventory.groups['group2'].hosts.keys() == ['somehost', 'somehost1', 'somehost2']

# Generated at 2022-06-21 05:30:55.938767
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # create dummy inventory module
    my_inventory = InventoryModule('/dev/null')

    # create dummy loader
    loader = DataLoader()

    # create inventory
    inventory = InventoryManager(loader=loader, sources=['/dev/null'])

    # create variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # parse dummy inventory
    my_inventory.parse(loader=loader,
                       inventory=inventory,
                       variable_manager=variable_manager)

# Generated at 2022-06-21 05:31:08.980856
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Testing correct inventory input.
    data_dir = os.path.dirname(os.path.realpath(__file__)) + os.sep + 'data'

    # Testing all different inventory types.
    inv = InventoryModule()
    inv.parse_inventory(data_dir + '/simple_hosts', None)
    inv.parse_inventory(data_dir + '/simple_hosts_multivars', None)
    inv.parse_inventory(data_dir + '/complex_hosts_file', None)
    inv.parse_inventory(data_dir + '/complex_hosts_file_with_yaml', None)
    inv.parse_inventory(data_dir + '/hosts_hostvars', None)
    inv.parse_inventory(data_dir + '/hosts_groupvars', None)
    inv.parse_

# Generated at 2022-06-21 05:31:11.631402
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    myInventoryModule = InventoryModule()
    assert myInventoryModule is not None

# unit test for get_option

# Generated at 2022-06-21 05:31:16.011978
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' inventory_parsers.InventoryModule(_io_file) constructor'''

    inventory_module = InventoryModule([])
    assert isinstance(inventory_module, InventoryModule)


# Generated at 2022-06-21 05:31:27.377747
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    """
    Test the InventoryModule constructor
    """
    # create a test inventory
    test_inventory = InventoryManager(loader=None, sources=None)

    assert test_inventory.groups == {}
    assert test_inventory.hosts == {}

    # test copy of the inventory
    copied_inventory = InventoryManager(loader=None, sources=None, inventory=test_inventory)
    assert copied_inventory.groups == {}
    assert copied_inventory.hosts == {}

    assert copied_inventory != test_inventory

    # test adding a group
    assert test_inventory.groups == {}
    test_inventory.add_group("test_group")
    assert test_inventory.groups == {"test_group": InventoryGroup("test_group")}

    # test adding a child to the group

# Generated at 2022-06-21 05:31:40.537844
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """
    Test method parse of class InventoryModule
    """
    from collections import namedtuple
    mock_filename  = 'mocked file'
    mock_data      = [
        '# a comment',
        'foo',
        '[group1]',
        'alpha',
        '[group2]',
        'bravo',
        '[group2:vars]',
        'ansible_ssh_port=99',
        '[group3:children]',
        'group1',
    ]
    mock_inv       = namedtuple('Inventory', ['groups'])()
    mock_inv.groups = {}
    inv_mod = InventoryModule(mock_inv, mock_filename)
    inv_mod._parse(mock_filename, mock_data)
    assert len(inv_mod.inventory.groups) == 3
