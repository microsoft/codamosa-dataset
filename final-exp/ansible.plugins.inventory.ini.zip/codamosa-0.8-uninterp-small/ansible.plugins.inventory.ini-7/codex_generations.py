

# Generated at 2022-06-25 10:01:37.061338
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # TODO: Test for the case that the inventory file does not exist.
    InventoryModule().parse("tests/test_inventory.ini", cache=False)

test_cases = [test_case_0, test_InventoryModule_parse]

# TODO: Test the following (or at least think of more to test):
#
# - variable precedence between host, group-level, and parent group-level
# - variable precedence between multiple sources of the same variable
#   - host, group, and parent group definition in inventory
#   - host definition in inventory and fact
# - host vars in ini sections vs. other sections
# - positional arguments in command line that should override inventory source
# - host vars in inventory vs. host vars in command line
# - explicit vs. implicit localhost
# - behavior for unknown variables
# - host definition for same host in

# Generated at 2022-06-25 10:01:44.991208
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse("""
[group1]
localhost ansible_ssh_port=2222
127.0.0.1 ansible_connection=local

[group1:vars]
some_var="some_test_value"
""", os.path.join(os.getcwd(), "test_inventory_module_parse.ini"))

    group_names = set()
    for group in inventory_module_1.inventory.groups:
        group_names.add(group)
    expected_group_names = set(['group1', 'all', 'ungrouped'])
    assert expected_group_names == group_names, "InventoryModule.parse(): test 1 failed, expected group names from ini file were not found."

    group_vars = inventory_module_

# Generated at 2022-06-25 10:01:53.658050
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Test of function parse of class InventoryModule
    '''
    # Create an instance of class InventoryModule
    inventory_module = InventoryModule()

    # Test method parse of class InventoryModule: path = None
    try:
        inventory_module.parse()
        raise AssertionError("'path = None' test of method parse of class InventoryModule has failed")
    except TypeError:
        pass

    # ToDo: Test method parse of class InventoryModule: path is an invalid file
    # ToDo: Test method parse of class InventoryModule: path is a valid file but with an invalid content
    # ToDo: Test method parse of class InventoryModule: path is a valid file but with an invalid yaml structure
    # ToDo: Test method parse of class InventoryModule: path is a valid file with a valid yaml structure


# Generated at 2022-06-25 10:01:59.407878
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    # Input parameters to function parse:
    #   path = /etc/ansible/hosts
    #   data = None
    path = "/etc/ansible/hosts"
    data = None
    inventory_module_0.parse(path, data)


# Generated at 2022-06-25 10:02:01.805168
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse('/etc/ansible/hosts')


# Generated at 2022-06-25 10:02:02.884538
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse('hosts')
    inventory_module.parse_with_inventory()


# Generated at 2022-06-25 10:02:10.814874
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Test InventoryModule parse
    '''
    # Create a section [uzi] with one host fred
    TEST_INVENTORY_0 = """
[uzi]
fred
"""
    INVENTORY_0 = InventoryManager(loader=DataLoader())
    INVENTORY_0.add_host('fred')
    INVENTORY_0.add_group('uzi')
    INVENTORY_0.add_child('uzi', 'fred')

    # Create a section [uzi] with one host fred and variables user=root,port=99
    TEST_INVENTORY_1 = """
[uzi]
fred port=99 user=root
"""
    INVENTORY_1 = InventoryManager(loader=DataLoader())
    INVENTORY_1.add_host('fred')
    INVENTORY_

# Generated at 2022-06-25 10:02:15.223157
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    # Test with valid file
    inventory_module_0.parse('../../lib/ansible/inventory/inito.yaml')
    # Test with invalid file
    inventory_module_0.parse('../../lib/ansible/inventory/none.yaml')


# Generated at 2022-06-25 10:02:23.276293
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    temp_path = tempfile.mktemp()

# Generated at 2022-06-25 10:02:31.721416
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    # Create an Emulator object
    emulator_obj = Emulator()

    # Get ansible_ssh_host
    ansible_ssh_host = emulator_obj.emulate_inventory_data("inventory", "ansible_ssh_host")

    # Get ansible_port
    ansible_port = emulator_obj.emulate_inventory_data("inventory", "ansible_port")

    # Get ansible_ssh_private_key_file
    ansible_ssh_private_key_file = emulator_obj.emulate_inventory_data("inventory", "ansible_ssh_private_key_file")

    # Get ansible_ssh_user
    ansible_ssh_user = emulator_obj.emulate_inventory_data("inventory", "ansible_ssh_user")

    # Get ansible_ssh

# Generated at 2022-06-25 10:02:56.431476
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    filename = os.path.join(inventory_module.cwd, 'sample_inventory_file.txt')
    inventory_module.parse_inventory_file(filename)


# Generated at 2022-06-25 10:03:01.641152
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse("/tmp/hosts", "", "", "")
    assert inventory_module.inventory.groups
    assert inventory_module.inventory.hosts


# Generated at 2022-06-25 10:03:10.945192
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_dict_0 = MockInventory()
    inventory_module_0 = InventoryModule()
    inventory_dict_0.add_group('groupname')
    inventory_module_0.filename = '/etc/ansible/hosts'
    hostnames = ['alpha']
    port = None
    variables = {}
    inventory_dict_0.add_group('groupname')
    inventory_module_0.filename = '/etc/ansible/hosts'
    hostnames = ['beta']
    port = '2345'
    variables = {'user': 'admin'}
    inventory_dict_0.add_group('groupname')
    inventory_module_0.filename = '/etc/ansible/hosts'
    hostnames = ['gamma']
    port = None

# Generated at 2022-06-25 10:03:16.706060
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    parse_test_files = [
        'test/ansible_hosts_test0',
        'test/ansible_hosts_test1',
        'test/ansible_hosts_test2',
        'test/ansible_hosts_test3',
        'test/ansible_hosts_test4',
    ]

    for test_file in parse_test_files:
        inventory_module = InventoryModule()
        inventory_module._parse(test_file, open(test_file).readlines())


# Generated at 2022-06-25 10:03:22.177892
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # fixture: test_basic_multiline_entry
    fixture_path = os.path.join(os.path.dirname(__file__), 'inventory_module_smoke.txt')
    params = dict()
    params['filename'] = fixture_path
    params['cache'] = False
    params['_ansible_playbook_basedir'] = os.path.dirname(__file__)
    params['_ansible_playbook_pid'] = 12345
    params['vault_password'] = None
    inventory_module = InventoryModule()
    try:
        inventory_module.parse(params)
    except Exception as e:
        print("exception: {0}".format(e))
        assert False, 'the inventory_module.parse should not fail'


# Generated at 2022-06-25 10:03:24.053753
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse("test.inventory",['[mysql]'])


# Generated at 2022-06-25 10:03:31.366779
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Initialization
    inventory_module_1 = InventoryModule()
    data_dir = '../tests/inventory_data/'

    inventory_module_1.parse(data_dir+'sample_0.yml', 'sample_0.yml')
    inventory_module_1.parse(data_dir+'sample_1.yml', 'sample_1.yml')
    inventory_module_1.parse(data_dir+'sample_2.yml', 'sample_2.yml')
    inventory_module_1.parse(data_dir+'sample_3.yml', 'sample_3.yml')


# Generated at 2022-06-25 10:03:41.709671
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create inventory
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(path='inventory', filename='inventory_1.ini')
    # Assert that the inventory has been initialized
    assert isinstance(inventory_module_1.inventory, Inventory)
    # Assert that all groups have been created
    assert set(inventory_module_1.inventory.groups) == {'group1', 'group2', 'group3', 'group4'}
    # Assert that the group group1 has been initialized
    assert isinstance(inventory_module_1.inventory.groups['group1'], Group)
    # Assert that the group group2 has been initialized
    assert isinstance(inventory_module_1.inventory.groups['group2'], Group)
    # Assert that the group group3 has been initialized

# Generated at 2022-06-25 10:03:51.905470
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    i = InventoryScript('inventory/testcases/test_case_0.inventory')
    assert i.filename == 'inventory/testcases/test_case_0.inventory'
    assert i.get_host('test_case_0').vars == {'ansible_port': 22, 'ansible_host': 'test_case_0', 'ansible_user': 'root'}
    assert i.get_host('test_case_0').get_vars() == {'ansible_port': 22, 'ansible_host': 'test_case_0', 'ansible_user': 'root', 'group_names': ['test_case_0_group']}


# Generated at 2022-06-25 10:03:59.201816
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    filename = TESTDIR + '/test_inventory_ini_extras'
    cache = {}
    inventory_module.parse(filename, cache)
    # FIXME: This is broken and assumes that the groups are added to
    # self.inventory in the right order.
    assert(inventory_module.groups == ['ungrouped', 'group2', 'group1'])
    assert(inventory_module.inventory.get_group_variables('group1') == {'group_var': 'bar'})
    assert(inventory_module.inventory.get_group_variables('group2') == {'group_var': 'foo'})
    assert(inventory_module.patterns['section'].match('[group:children]') != None)

# Generated at 2022-06-25 10:04:23.210396
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse("/usr/share/ansible/ansible/inventory/inventory.py")


# Generated at 2022-06-25 10:04:26.177963
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse([u'[webservers]', u'foo.example.com', u'  bar.example.com  # a comment'])


# Generated at 2022-06-25 10:04:38.739423
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create an instance of InventoryModule
    inventory_module = InventoryModule()
    # Create a path for the host file
    path = './test/integration/inventory_host.ini'
    # Parse the host file
    inventory_module.parse(path)
    # Create a copy of the inventory
    inventory_copy = inventory_module.inventory.copy()
    # Create a list with hosts that must be present in the inventory

# Generated at 2022-06-25 10:04:51.325009
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    file_name = './test_inventory.ini'

    inventory_module_0 = InventoryModule(loader = DictDataLoader({}))
    inventory_module_0.parse(file_name)
    assert isinstance(inventory_module_0.inventory.groups, dict)
    assert isinstance(inventory_module_0.inventory.hosts, dict)
    assert isinstance(inventory_module_0.inventory.patterns, dict)
    assert isinstance(inventory_module_0.inventory.pattern_cache, dict)
    assert isinstance(inventory_module_0.inventory.vars, dict)
    assert isinstance(inventory_module_0.inventory.get_groups_dict(), dict)
    assert isinstance(inventory_module_0.inventory.get_hosts_dict(), dict)

# Generated at 2022-06-25 10:04:54.690121
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # TODO:
    pass



# Generated at 2022-06-25 10:04:56.518264
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(os.path.dirname(__file__) + "/test_inventory.txt", "test_inventory.txt")


# Generated at 2022-06-25 10:05:08.321213
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

# Generated at 2022-06-25 10:05:14.972177
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()

    inventory_module_parse._read_config_data("./test_valid_ini_file.ini")
    assert len(inventory_module_parse.inventory.get_groups()) == 3

    inventory_module_parse._read_config_data("./test_broken_ini_file.ini")
    assert len(inventory_module_parse.inventory.get_groups()) == 0


if __name__ == '__main__':
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 10:05:22.304362
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    all_groups = inventory_module_0.inventory.groups
    assert 'ungrouped' in all_groups
    assert len(all_groups) == 1

    inventory_module_0._parse(path=None, lines=['[group1]'])
    all_groups = inventory_module_0.inventory.groups
    assert 'group1' in all_groups
    assert len(all_groups) == 2

    inventory_module_0._parse(path=None, lines=['[group2]'])
    all_groups = inventory_module_0.inventory.groups
    assert 'group1' in all_groups
    assert 'group2' in all_groups
    assert len(all_groups) == 3

    group2 = all_groups['group2']

# Generated at 2022-06-25 10:05:27.566812
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse('/etc/ansible/hosts', 'localhost   ansible.test_host')
    #assert inventory_module_0.hosts()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 10:05:58.103355
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.patterns = {}
    inventory_module_0.patterns['comment'] = re.compile(
        to_text(r'''(?P<comment>
                ^(?P<leading_whitespace>\s*)
                (?P<comment_marker>#|\;)
                (?P<inline_comment>.*)
                $
            )''', errors='surrogate_or_strict'), re.X
    )


# Generated at 2022-06-25 10:06:00.762554
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create a InventoryModule object
    inventory_module = InventoryModule()

    # Call the parse method
    result = inventory_module.parse('i_ve_got_no_friends')
    # Verify the results
    assert(result == None)


# Generated at 2022-06-25 10:06:08.194020
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse('/etc/ansible/hosts', '''[webservers]
    foo.example.com
    10.25.1.100
    10.25.1.101
''')
    assert inventory_module_1.inventory.get_host('foo.example.com')
    assert inventory_module_1.inventory.get_host('10.25.1.100')
    assert inventory_module_1.inventory.get_host('10.25.1.101')
    assert inventory_module_1.inventory.get_group('webservers')


# Generated at 2022-06-25 10:06:15.777137
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_test_1 = InventoryModule()
    inventory_module_test_1.parse(host_list=['localhost ansible_connection=local'], group='test_1', filename='test_1')
    assert len(inventory_module_test_1.inventory.get_groups()) == 1
    assert len(inventory_module_test_1.inventory.get_hosts()) == 1
    assert inventory_module_test_1.inventory.get_groups()[0].name == 'test_1'
    assert inventory_module_test_1.inventory.get_hosts()[0].name == 'localhost'
    assert inventory_module_test_1.inventory.get_groups()[0].get_hosts()[0].name == 'localhost'

# Generated at 2022-06-25 10:06:27.690394
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    m = InventoryModule()
    m._parse(path=os.path.join(os.path.dirname(__file__), 'test_inventory_module_parse'), data=None)

    m.get_hosts('all')
    h = m.get_host('all')
    h = m.get_host('host1')
    h = m.get_host('host2')
    h = m.get_host('host3')
    h = m.get_host('host4')
    h = m.get_host('host5')
    h = m.get_host('host6')

    m.get_hosts('ungrouped')
    h = m.get_host('host1')

    m.get_hosts('group1')
    h = m.get_host('host1')
    h

# Generated at 2022-06-25 10:06:30.745350
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    # inventory_module_0.parse(path='', cache=False)


# Generated at 2022-06-25 10:06:33.185153
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    lines = ['[ungrouped]']
    inventory_module_parse._parse('', lines)


# Generated at 2022-06-25 10:06:35.482107
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse()


# Generated at 2022-06-25 10:06:38.369873
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print("Testing InventoryModule class method parse")
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse('/home/vikram/ansible/hacking/test/units/module_utils/inventory_plugins/inventory/simple_static', [])


# Generated at 2022-06-25 10:06:43.191519
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryManager()
    inventory_module_0 = InventoryModule(filename='hosts', inventory=inventory)
    inventory_module_0.parse()
    assert len(inventory.groups) == 3


# Generated at 2022-06-25 10:07:46.781052
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    # Path to inventory file is not provided

# Generated at 2022-06-25 10:07:53.795132
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """
    Test against a simple minimal inventory specification: one group, one host
    """
    inventory_module_1 = InventoryModule()
    lines_1 = [
        '[ungrouped]',
        'localhost',
        ]
    inventory_module_1._parse('/tmp/foo', lines_1)
    assert inventory_module_1.groups['ungrouped']
    assert inventory_module_1.groups['ungrouped'].get_hosts('all')[0].name == 'localhost'


# Generated at 2022-06-25 10:08:00.532427
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 10:08:01.753027
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse()


# Generated at 2022-06-25 10:08:07.979538
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0._parse("/etc/ansible/hosts", ["[groupname]"])
    return inventory_module_0


# Generated at 2022-06-25 10:08:15.951363
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    #file_name = "/home/shihao/ansible/inventory/test_inv.ini"
    #file_name = os.path.join(os.path.dirname(os.path.realpath(__file__)) + "/../../inventory/test_inv.ini")
    # inventory_module = InventoryModule(file_name)
    # inventory_module.parse()
    pass

if __name__ == '__main__':
    test_case_0()
    #test_InventoryModule_parse()
    pass

# Generated at 2022-06-25 10:08:24.366224
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_0 = InventoryModule([])
    inventory_module_0.parse(os.path.dirname(__file__) + "/unit_tests_inventory/test_case_0.inventory")
    assert str(inventory_module_0.inventory._groups) == "{'all': {'vars': {'test_var': 'test_value'}}, 'test_group': {}}"
    assert str(inventory_module_0.inventory._hosts_and_children) == "{'test_host': {'groups': ['all', 'test_group']}}"

    inventory_module_0 = InventoryModule([])
    inventory_module_0.parse(os.path.dirname(__file__) + "/unit_tests_inventory/test_case_1.inventory")
    assert str(inventory_module_0.inventory._groups)

# Generated at 2022-06-25 10:08:28.562636
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    assert inventory_module_parse.parse(path=None, cache=None) == None


# Generated at 2022-06-25 10:08:37.083123
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0._parse("test_case_0", ["host0", "host1", "host2", "host3", "host4", "host5", "host6", "host7", "host8", "host9", "host10", "host11", "host12", "host13", "host14", "host15", "host16", "host17", "host18", "host19", "host20", "host21", "host22", "host23", "host24", "host25", "host26", "host27", "host28", "host29", "host30", "host31", "host32", "host33", "host34", "host35"])


# Generated at 2022-06-25 10:08:43.819383
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 10:10:43.701638
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_inventory_file_0 = '''
[loadbalancer]
frontend

[app]
app1 ansible_host=app1.example.com
app2
app3

[db]
db1

[all:vars]
ansible_connection=local
ansible_python_interpreter=/usr/bin/python3
'''
    inventory_module_0 = InventoryModule()
    inventory_module_0._parse('', test_inventory_file_0.split('\n'))
    assert isinstance(inventory_module_0.inventory, Inventory) == True
    assert inventory_module_0.inventory._restriction == 'all'
    assert inventory_module_0.inventory.list_hosts('all') == ['app1', 'app2', 'app3', 'db1', 'frontend']
   

# Generated at 2022-06-25 10:10:46.360468
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    # 'hosts' is our inventory file
    inventory_module.parse('./hosts', 'all')


# Generated at 2022-06-25 10:10:51.124346
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create an instance of InventoryModule
    inventory_module_1 = InventoryModule()
    # Create an instance of InventoryFile
    inventory_file_1 = InventoryFile()
    # Set the inventory file of the InventoryModule to inventory_file_1
    inventory_module_1.set_inventory(inventory_file_1)
    # Parse the inventory file
    inventory_module_1.parse(INVENTORY_FILE)


# Generated at 2022-06-25 10:10:59.158144
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.strategy import StrategyBase
    import ansible.constants as C
    import ansible.callbacks
    import logging

    options = C.Options()
    options.module_path = '../../hacking/build_module_zilla'

# Generated at 2022-06-25 10:11:06.836270
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

# Generated at 2022-06-25 10:11:13.587959
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    with pytest.raises(AnsibleParserError) as e_info:
        inventory_module_0.parse([])
    assert 'path' in str(e_info.value)

# unit test for method _populate_host_vars of class InventoryModule