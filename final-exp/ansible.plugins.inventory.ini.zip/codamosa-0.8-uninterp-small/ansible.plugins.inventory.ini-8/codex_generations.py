

# Generated at 2022-06-25 10:01:31.477365
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module._parse('/path/to/inventory', [ '  # comment', '[groupname:children]', '[groupname:vars]', ])


# Generated at 2022-06-25 10:01:34.532308
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse("inventory_module_1", ["[group_1]", "localhost"], True)
    inventory_module_1.get_host("localhost")
    inventory_module_1.get_group("group_1")


# Generated at 2022-06-25 10:01:39.179483
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    if os.path.isfile("/etc/ansible/hosts"):
        inventory_module.parse("/etc/ansible/hosts", None, None)
    else:
        pytest.skip("/etc/ansible/hosts file doesn't exist")


# Generated at 2022-06-25 10:01:51.220503
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    new_yaml_mod_obj = YamlInventoryParser()
    inventory_str = StringIO('''
    [group_1]
    host_1

    [group_2]
    host_2

    [group_3:children]
    group_4

    [group_4]
    host_1
    ''')
    # Read a yaml inventory file and create group and host objects.
    new_yaml_mod_obj.parse(inventory_str)
    new_yaml_mod_obj.list_groups()
    new_host_list = new_yaml_mod_obj.list_hosts()
    global INV_DICT
    INV_DICT = new_yaml_mod_obj.inventory.get_dict()
    inventory_str.close()
    new_yaml_mod_obj

# Generated at 2022-06-25 10:02:03.472588
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 10:02:11.113489
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print(">>> Testing parse method of InventoryModule class")

    inventory_module_parse = InventoryModule()
    test_file_path = "./inventory_module_parse.yml"
    print(">>> Write to test file %s" % (test_file_path))
    test_file = open(test_file_path, "w")

# Generated at 2022-06-25 10:02:20.792462
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """
    This test is to check basic functionality of the method parse
    """
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse("/Users/john/Git/ansible-modules/test/test_MozillaInventory.ini", None, None)
    hosts_0 = inventory_module_1.inventory.get_host("hq-a-prod-yp-01")
    assert hosts_0._attributes['ansible_ssh_host'] == "172.10.2.2" and hosts_0._attributes['ansible_ssh_port'] == "22" and hosts_0.name == "hq-a-prod-yp-01"
    hosts_1 = inventory_module_1.inventory.get_host("hq-b-prod-yp-01")
    assert hosts_

# Generated at 2022-06-25 10:02:30.042238
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    # Test case 1
    # Input data
    try:
        inventory_module_1.parse(None, None, None)
    except AnsibleParserError as e:
        pass
    else:
        assert False

    # Test case 2
    # Input data
    try:
        inventory_module_1.parse('/home/ansible/ansible/test/test_inventory_ini.py', None, None)
    except AnsibleParserError as e:
        raise e

    # Test case 3
    # Input data
    try:
        inventory_module_1.parse(None, '/home/ansible/ansible/test/test_inventory_ini.py', None)
    except AnsibleParserError as e:
        raise e

    # Test case 4
    # Input data
   

# Generated at 2022-06-25 10:02:32.743309
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = Inventory("host_list")
    inventory_module._parse("host_list", [ 'a b c', 'a b', 'a' ])

if __name__ == "__main__":
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 10:02:33.873401
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0._parse == InventoryModule._parse


# Generated at 2022-06-25 10:02:50.795903
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    ip = InventoryModule()
    ip._parse("test_hosts", "test line")

if __name__ == '__main__':
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 10:02:57.172772
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory_module_0._loader, "valid_1.ini")
    inventory_module_0.get_host(inventory_module_0.groups["nginx"]["hosts"][0][0]).to_dict()
    inventory_module_0.get_host(inventory_module_0.groups["apache"]["hosts"][0][0]).to_dict()
    inventory_module_0.get_host(inventory_module_0.groups["lamp"]["hosts"][0][0]).to_dict()
    inventory_module_0.get_host(inventory_module_0.groups["lamp"]["hosts"][1][0]).to_dict()

# Generated at 2022-06-25 10:03:08.262691
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 10:03:17.229305
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    inventory_module_0.parse(loader=None, paths='../etc/ansible/hosts',
        filename="../etc/ansible/hosts", name="ansible_etc_ansible_hosts")

    assert inventory_module_0.inventory is not None
    assert inventory_module_0.inventory.get_groups_dict() is not None

    assert 'group01' in inventory_module_0.inventory.get_groups_dict()
    assert 'name' in inventory_module_0.inventory.get_groups_dict()['group01']
    assert type(inventory_module_0.inventory.get_groups_dict()['group01']['name']) == str

# Generated at 2022-06-25 10:03:22.695486
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory_module_0 = InventoryModule(loader=loader)
    inventory_module_1 = InventoryModule(loader=loader, filename="ansible.cfg")
    inventory_module_2 = InventoryModule(loader=loader, filename="")
    inventory_module_3 = InventoryModule(loader=loader, filename="../../tests/test_data/inventory_test_1")
    # test wrong input_data
    try:
      inventory_module_0._parse("ansible.cfg", ["[group_name:children\n", "host_name\n"])
    except AnsibleParserError:
      pass

# Generated at 2022-06-25 10:03:27.303139
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse('/path/to/ini', ['[group1]', 'alpha'])
    assert(inventory_module_1.inventory.groups['group1'].get_hosts()[0].name == 'alpha')


# Generated at 2022-06-25 10:03:34.954103
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import os
    import sys
    import unittest


    # Setup of test inventory contents for testing

# Generated at 2022-06-25 10:03:40.571375
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_parse = InventoryModule()

    # Dummy inventory file
    fd, inv_file = tempfile.mkstemp()
    os.write(fd, "[group1]\nhostname1\nhostname2\nhostname3\n")
    os.close(fd)

    # Parse the file
    inventory_module_parse.parse(inv_file)

    # Test there is 3 hosts
    assert len(inventory_module_parse.inventory.get_hosts()) == 3

    # Get all hosts
    hosts_in_inventory = inventory_module_parse.inventory.hosts.keys()

    assert "hostname1" in hosts_in_inventory
    assert "hostname2" in hosts_in_inventory
    assert "hostname3" in hosts_in_inventory



# Generated at 2022-06-25 10:03:45.012485
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    try:
        inventory_module_0 = InventoryModule()
        inventory_module_0.parse()
    except AnsibleError as err:
        #print(err.message)
        pass


# Generated at 2022-06-25 10:03:54.507696
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

# Generated at 2022-06-25 10:04:08.838925
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory = InventoryManager(inventory_module_0, 'localhost')
    inventory_module_0.parse(inventory, '/home/aymen/PycharmProjects/ansible/inventory_test_file', None)

test_case_0()
test_InventoryModule_parse()

# Generated at 2022-06-25 10:04:11.694855
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    try:
        inventory_module.parse(ANSIBLE_INVENTORY_FILE)
    except AnsibleParserError as ap:
        return False
    return True

# Main method to run all tests

# Generated at 2022-06-25 10:04:12.558535
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert(True)


# Generated at 2022-06-25 10:04:14.397605
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0._parse('path', ['# test'])


# Generated at 2022-06-25 10:04:18.909899
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse('./test/static/inventory/static_host_file', '')
    assert(inventory_module.inventory.get_host("host1").get_vars()["inventory_hostname"] == "host1")
    assert(inventory_module.inventory.get_group("group1").get_hosts()[0].get_name() == "host1")


# Generated at 2022-06-25 10:04:30.075180
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # creation of the inventory module
    inventory_module = InventoryModule()

    # Creation of the test file
    test_file = tempfile.NamedTemporaryFile(mode="w")
    test_file.close()
    test_file = open(test_file.name, "w")
    test_file.write("[test]\n")
    test_file.write("[test2]\n")
    test_file.write("[test:vars]\n")
    test_file.write("[test:children]\n")
    test_file.write("[test2:vars]\n")
    test_file.write("[test2:children]\n")
    test_file.close()

    inv_parser = InventoryParser(inventory_module, filename=test_file.name)
    inv_parser

# Generated at 2022-06-25 10:04:32.671966
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse("hoge.txt")


# Generated at 2022-06-25 10:04:39.564840
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse("test/inventory_test_0.ini")
    inventory_module_0.get_host_variables("host_0")

if __name__ == "__main__":
    test_InventoryModule_parse()

# Generated at 2022-06-25 10:04:43.384619
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    inventory_module_parse.parse('/tmp/hosts', b'[host]\nhost')

# Generated at 2022-06-25 10:04:47.166336
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create a new inventory module
    inventory_module = InventoryModule()
    # Use the base class method _parse to parse the inventory file
    inventory_module._parse(path="/etc/ansible/hosts", lines=[])

# Generated at 2022-06-25 10:05:17.333869
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(path='/opt/couchbase/lib/python3.6/site-packages/ansible/plugins/inventory/test.ini',
                             loader=None, cache=False)

    # The following output is for debug purpose only
    # for k in inventory_module_1.inventory.groups:
    #     print(k, inventory_module_1.inventory.groups[k])
    #
    # for host_name in inventory_module_1.inventory.hosts:
    #     print(host_name, inventory_module_1.inventory.hosts[host_name])
    assert 'test' in inventory_module_1.inventory.groups
    assert 'test_child' in inventory_module_1.inventory.groups['test'].child_groups
   

# Generated at 2022-06-25 10:05:24.188288
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse('[testgroup]\n192.168.1.1 ansible_ssh_user=root\n192.168.1.2 ansible_ssh_user=centos\n')

# Generated at 2022-06-25 10:05:33.209487
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    # Test case with all valid inputs
    # Tests that group is created correctly
    assert (inventory_module_1.inventory.groups[0]['ungrouped']) == {}
    inventory_module_1.parse('[groupname]')
    assert (inventory_module_1.inventory.groups[0]['groupname']) == {}
    # Tests that a host is added to a group correctly
    inventory_module_1._parse_host_definition('tsun:22')
    assert (inventory_module_1.inventory.groups[0]['ungrouped']['hosts'][0]['name']) == 'tsun'

# Generated at 2022-06-25 10:05:43.872863
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # WARNING, this test is hard coded to work only with
    # certain inventory file path.
    inventories_path = "tests/inventory"
    inventory_file_name = "test_case_0.ini"
    inventory_file_path = os.path.join(inventories_path, inventory_file_name)

    inventory_module = InventoryModule()
    groups_dict = dict()
    inventory_module.parse(inventory_file_path, groups_dict)

    assert(groups_dict.keys() == ['ungrouped', 'all', 'tomcat', 'other_tomcat', 'apache', 'other_apache', 'webserver'])


# Generated at 2022-06-25 10:05:47.072449
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print("\nUnit test for method parse of class InventoryModule...")
    inventory_module_1 = InventoryModule()


# Generated at 2022-06-25 10:05:49.746161
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    inventory_module_0.parse(['localhost'], [''], [''], 'dummy_path')
    assert inventory_module_0.inventory.list_hosts('all') == ['localhost']


# Generated at 2022-06-25 10:05:56.263029
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse('test1.ini', '''
[group1]
10.0.0.1
10.0.0.2
10.0.0.3
[group2]
10.0.0.2
10.0.0.3
10.0.0.4
10.0.0.5
[group3:children]
group1
group2
[group3:vars]
some_server_var=foo
[group4:children]
group2
[group5:vars]
group4
[ungrouped]
[group6]
192.168.19.1
[group7]
''')

# Generated at 2022-06-25 10:05:58.911920
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Unit test for method _parse of class InventoryModule
    inventory_module_0 = InventoryModule()

    inventory_module_0._parse(None, None)


# Generated at 2022-06-25 10:06:02.067543
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    inventory_module_parse.parse("test_inventory_parse")

try:
    if __name__ == "__main__":
        test_case_0()
        test_InventoryModule_parse()
except Exception as e:
    print(e)

# Generated at 2022-06-25 10:06:05.436481
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    fixture_path_0 = 'test/fixtures/ansible_test_inventory.txt'
    inventory_module_0.parse(fixture_path_0, cache=False)
    return inventory_module_0


# Generated at 2022-06-25 10:07:02.602419
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    filename = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../../test/units/module_utils/hosts.ini'))
    inventory_module_1.parse(filename)

    assert len(inventory_module_1.inventory.groups) == 1

    assert list(inventory_module_1.inventory.get_hosts())[0].vars['ansible_ssh_port'] == 22

    assert list(inventory_module_1.inventory.get_hosts())[0].vars['ansible_connection'] == 'ssh'

    assert list(inventory_module_1.inventory.get_hosts())[0].vars['ansible_ssh_user'] == 'bob'

# Generated at 2022-06-25 10:07:08.437626
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1._parse('path', ['[groupname:vars]', 'git_branch=master'])


# Generated at 2022-06-25 10:07:13.954830
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse('test_inventory/test_inventory.ini', cache=False)
    assert len(inventory_module.inventory.groups) == 4, 'len(inventory_module.inventory.groups) == 4'
    assert len(inventory_module.inventory.hosts) == 3, 'len(inventory_module.inventory.hosts) == 3'
    # test groups names
    for g in inventory_module.inventory.groups:
        assert g in ('group0', 'group1', 'group2', 'group3')
    # test groups host vars
    grp = inventory_module.inventory.groups['group0']
    assert len(grp.vars) == 0, 'group0.vars == 0'
    grp = inventory_module.inventory.groups['group1']
    assert gr

# Generated at 2022-06-25 10:07:24.576315
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    path = '../nodes_vars/nodes_vars.yml'
    inventory_module_1.parse(path)
    assert(inventory_module_1.inventory.get_host('host01').get_vars()== {'hostName': 'host01', 'os': 'CentOS 7.1'})
    assert(inventory_module_1.inventory.get_host('host02').get_vars()== {'hostName': 'host02', 'os': 'Ubuntu 14.04'})
    assert(inventory_module_1.inventory.get_host('host03').get_vars()== {'hostName': 'host03', 'os': 'CentOS 7.1'})

# Generated at 2022-06-25 10:07:29.075804
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(path='/Users/es/dev/ansible/inventory/inventory.py', filename='/Users/es/dev/ansible/inventory/inventory.py', loader=None)


# Generated at 2022-06-25 10:07:38.727336
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    # TODO:
    #
    # We can easily test the correct operation of the parse() method by
    # populating the host and group dictionaries in self._inventory as we go,
    # and then comparing the final result against a fixed structure.
    # Unfortunately, we should probably be returning the inventory instead of
    # storing it as a module attribute, which means we'll need to update the
    # test to reflect the new API.
    #
    # Note that we can bypass the built-in logic in parse() that relies on the
    # file name extension to find the correct parser by passing an array
    # directly. However, this means we'll need to choose the correct extension
    # in order to test each parser.

    # Test empty input

    inventory_module_1._parse('empty', [])
    #assert

# Generated at 2022-06-25 10:07:40.366292
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse("inventory_hostfile", "hosts_data")


# Generated at 2022-06-25 10:07:49.234709
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_cases = {}
    inventory_module = InventoryModule()

    test_cases[0] = {'a': 'b', 'c': [0, 1]}
    test_cases[1] = {'a': 'b\n', 'c': [0, 1]}
    test_cases[2] = {'a': 'b\n', 'c': [0, 1], 'd': ['e', 'f']}
    test_cases[3] = {'a': 'b\n', 'c': "0, 1", 'd': ['e', 'f']}
    test_cases[4] = {'a': {'b': 'c'}, 'd': ['e', 'f']}

# Generated at 2022-06-25 10:07:51.316501
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.parse()==None


# Generated at 2022-06-25 10:07:56.554239
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_file_path = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        '../../../inventory', 'sample'
    )
    inventory_module = InventoryModule()
    inventory_module.parse(inventory_file_path)
    assert inventory_module.lineno == 7
    assert inventory_module.inventory.groups[u'local'] == \
        Group.Group(u'local', inventory_module.inventory, None, None)
    assert inventory_module.inventory.hosts[u'localhost'] == \
        Host.Host(u'localhost', inventory_module.inventory, None, None)
    assert inventory_module.inventory.hosts[u'localhost'].has_key(u'foo')

# Generated at 2022-06-25 10:09:45.496487
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 10:09:49.710023
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse("inventory_module_test")


# Generated at 2022-06-25 10:09:54.152225
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    path = ''
    data = ['']
    inventory_module_0._parse(path, data)


# Generated at 2022-06-25 10:10:02.242223
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.yaml.objects import AnsibleSequence
    inventory_module_0 = InventoryModule()
    inventory_module_0._filename = 'inventory_file_0'
    inventory_module_0.parse()

# Test class to test the behaviour of class InventoryModule

# Generated at 2022-06-25 10:10:06.187243
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    path = 'test_file_0'
    data = ['[all]', 'foo', 'bar']
    inventory_module_parse._parse(path, data)


# Generated at 2022-06-25 10:10:10.662027
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse('hosts', [], [])


# Generated at 2022-06-25 10:10:15.104157
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
#    example_0 = [b'localhost ansible_connection=local']
    example_0 = [b'localhost\n']
    inventory_module_1.parse_inventory(example_0)
    assert inventory_module_1.inventory.groups['all'].hosts.keys() == set(['localhost'])


# Generated at 2022-06-25 10:10:21.982451
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_instance_0 = InventoryModule()
    # Type error
    with pytest.raises(AnsibleError) as excinfo:
        inventory_module_instance_0.parse(inventory_module_instance_0, 'path', 'lines')
    assert 'an integer is required' in str(excinfo.value)
    # Type error
    with pytest.raises(AnsibleError) as excinfo:
        inventory_module_instance_0.parse(inventory_module_instance_0, 5, 'lines')
    assert 'an integer is required' in str(excinfo.value)
    # Type error
    with pytest.raises(AnsibleError) as excinfo:
        inventory_module_instance_0.parse(inventory_module_instance_0, 'path', 5)

# Generated at 2022-06-25 10:10:23.776849
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    InventoryModule().parse('/root/ansible/ansible/inventory/myinventory', [u'[local]', u'localhost'])

# Generated at 2022-06-25 10:10:27.712705
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_InventoryModule = InventoryModule()
    assert os.path.exists(os.path.join(inventory_path, 'test_hosts'))
    test_InventoryModule.parse(os.path.join(inventory_path, 'test_hosts'), test_InventoryModule._extract_file_vars(''), is_template=False)
    assert test_InventoryModule is not None