

# Generated at 2022-06-25 10:01:30.584976
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0._parse()


# Generated at 2022-06-25 10:01:43.261478
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print("Testing the method parse of class InventoryModule")
    inventory_module_parse = InventoryModule(loader=None, groups={})
    inventory_module_parse.parse('/etc/ansible/hosts', [u'MyHost ansible_ssh_port=22 ansible_ssh_user=root'])
    assert inventory_module_parse.inventory.groups['all'].hosts['MyHost'].vars['ansible_ssh_port'] == 22
    assert inventory_module_parse.inventory.groups['all'].hosts['MyHost'].vars['ansible_ssh_user'] == 'root'

# Generated at 2022-06-25 10:01:47.324433
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test InventoryModule parsing logic
    parser = InventoryParser(loader=None, sources="/root/tmp/inventory")
    inventory_module = parser.parse()

# Generated at 2022-06-25 10:01:49.391621
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse('./Inventory/inventory.ini', './Inventory/')

# Generated at 2022-06-25 10:02:01.497369
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    # inventory_module.parse(path=None, data=None)
    inventory_module.parse(path=None, data='host1')
    inventory_module.parse(path=None, data='host1:1')
    inventory_module.parse(path=None, data='host1:1 user=admin')
    inventory_module.parse(path=None, data='host1:1 var1=admin var2=abc')
    inventory_module.parse(path=None, data='host1:1 var1=admin var2=abc\nhost2')
    inventory_module.parse(path=None, data='host1:1 var1=admin var2=abc\nhost2\n[group1]')

# Generated at 2022-06-25 10:02:10.149421
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    path = "test_inventory_module_path"
    lines = ['# test_inventory_module_comment']
    lines.append('[test_inventory_module_group:test_inventory_module_children]')
    lines.append('test_inventory_module_host_0')
    lines.append('test_inventory_module_host_1 ansible_python_interpreter=/usr/bin/python2.7')
    lines.append('test_inventory_module_host_2:test_inventory_module_port ansible_python_interpreter=/usr/bin/python3.6')
    lines.append('[test_inventory_module_group_0:test_inventory_module_vars]')

# Generated at 2022-06-25 10:02:13.188279
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    sys.stderr.write("Testing InventoryModule.parse()\n")
    inv_mod = InventoryModule()
    inv_mod.parse()
    sys.stderr.write("------------\n")


# Generated at 2022-06-25 10:02:22.105994
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 10:02:28.444375
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    data_0 = []
    data_0.append('[webservers:children:vars]')
    data_0.append('[webservers:children]')
    data_0.append('[:children:vars]')
    data_0.append('[:children]')
    data_0.append('[:vars]')
    data_0.append('[:vars]')
    data_0.append('[:vars]')
    path_0 = 'foo.txt'
    try:
        inventory_module_0.parse(path_0, data_0, None)
        assert False
    except AssertionError:
        assert True
    except Exception:
        assert False


# Generated at 2022-06-25 10:02:34.869368
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    test_filename = "./inventory/test_inventory"
    inventory_module_1.parse(test_filename, None, None)
    var_2 = inventory_module_1.inventory.get_group('all')
    assert var_2 == None

    var_3 = inventory_module_1.inventory.get_group(u'ungrouped')
    assert var_3 == None
    var_4 = inventory_module_1.inventory.get_group(u'ungrouped')
    assert var_4 == None
    var_5 = inventory_module_1.inventory.get_host(u'[omitting port]')
    assert var_5 == None

    var_6 = inventory_module_1.inventory.get_host(u'server2')
    assert var_6 == None

# Generated at 2022-06-25 10:02:59.105698
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    file_name = os.path.join(os.path.dirname(__file__), 'test_InventoryModule_parse.inventory')
    with open(file_name, 'r') as f:
        inventory_module.parse(file_name, f)
    assert len(inventory_module.inventory.groups) == 6
    assert len(inventory_module.inventory.groups['ungrouped'].hosts) == 4
    assert inventory_module.inventory.groups['ungrouped'].vars == {'test_var': 'test_val'}
    assert len(inventory_module.inventory.groups['groupname'].hosts) == 3
    assert isinstance(inventory_module.inventory.groups['groupname'].hosts['hostname'], InventoryHost)

# Generated at 2022-06-25 10:03:03.232761
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    path = 'hosts'
    data = ['[ungrouped]', 'localhost', '[local:children]', 'localhost']
    inventory_module._parse(path, data)


# Generated at 2022-06-25 10:03:13.034142
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module_test = InventoryModule()
    text = b"""
# dummy module inventory for testing purposes

[test_group]
test_host1

[test_other_group]
test_host2
test_host3
""".strip()
    data = [to_text(l, errors='surrogate_or_strict') for l in text.splitlines()]
    path = "/tmp/test_inventory_file"
    module_test._parse(path, data)
    # test_inventory_file can contains only test_host1, test_host2, test_host3 and not test_host
    assert "test_host1" in module_test.inventory._hosts
    assert "test_host2" in module_test.inventory._hosts
    assert "test_host3" in module_test.inventory._hosts


# Generated at 2022-06-25 10:03:18.304601
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_case_0()
    inventory_module_0 = InventoryModule()
    test_text = '[sec:children]\n' + 'one=2\n' + '[sec:vars]\n' + 'one=1\n' + 'two=2\n'
    inventory_module_0.parse(test_text)
    assert inventory_module_0.inventory.get_groups_dict() == dict()
    assert inventory_module_0.inventory.get_hosts().__class__ == dict


# Generated at 2022-06-25 10:03:29.448744
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    #
    # Init inventory_module
    #
    inventory_module = InventoryModule()
    #
    # Init a path
    #
    path = 'test_inventory_file'
    #
    # Init an array of text lines
    #
    raw_lines = [
        '[group1]',
        '#The following two lines should be recognized as hosts',
        'host1 ansible_ssh_port=2222',
        'host2 ansible_ssh_port=3333',
        '[group2]',
        '#The following line should be recognized as a child',
        'group1',
        '[group3:vars]',
        '#The following line should be recognized as a variable',
        'ansible_ssh_port = 3333'
        ]
    #
    # Init empty data array
    #
    data

# Generated at 2022-06-25 10:03:31.267972
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()

    assert inventory_module.parse("/path/to/file", "string") is None



# Generated at 2022-06-25 10:03:41.091896
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()

    # [fiji:children]
    inventory_module._parse('test_case_1.ini', [
        '[fiji:children]',
        'islands',
        'continents'])
    assert set(inventory_module.inventory.list_groups()) == set(['all', 'fiji', 'islands', 'continents'])
    assert set(inventory_module.inventory.list_groups_for_host('islands')) == set(['all', 'fiji', 'islands'])
    assert set(inventory_module.inventory.list_groups_for_host('continents')) == set(['all', 'fiji', 'continents'])

    # [continents:children]

# Generated at 2022-06-25 10:03:52.715956
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse(file_name='test/test_inventory_module/test/test_inventory_module/test_inventory_file_case_0.ini')
    #print('inventory_module: {0}'.format(inventory_module))
    #print('inventory_module.groups: {0}'.format(inventory_module.groups))

# Generated at 2022-06-25 10:03:59.746244
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # FIXME: InventoryModule.parse is not a static method, so it cannot be tested
    # in the way done in this function.
    #
    # InventoryModule.parse('./inventory_module_0.ini')

    inventory_module_0 = InventoryModule()
    inventory_module_0.parse('./inventory_module_0.ini')

    expected_inventory_module_0_groups = ['ungrouped', 'group1', 'group1_children']
    expected_inventory_module_0_hosts = ['host1', 'host2', 'host3']

# Generated at 2022-06-25 10:04:05.255939
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Setup
    ## Test data
    # Returns [host1, host2, host3]
    test_data_path = './test/test_fixtures/inventory_module/test_data_0.txt'
    # Returns [host1, host2, host3, host4, host5, host6]
    test_data_path2 = './test/test_fixtures/inventory_module/test_data_1.txt'
    test_data_path3 = './test/test_fixtures/inventory_module/test_data_2.txt'

    ## Test inventory
    inventory_module = InventoryModule()

    # Test
    with open(test_data_path, 'r') as f:
        data = f.readlines()
        inventory_module._parse(test_data_path, data)


# Generated at 2022-06-25 10:04:51.978783
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test case 0
    # Input:
    # - inventory_data: ['# Test comment', '[group-alpha]', 'host-a', 'host-b']
    # - path: 'test/path'
    # - Vault password: None
    # Output:
    # - inventory:
    #   {'group-alpha': {},
    #    'all': {},
    #    '_meta': {'hostvars': {'host-a': {}, 'host-b': {}}}}
    inventory_data_0 = ['# Test comment', '[group-alpha]', 'host-a', 'host-b']
    path_0 = 'test/path'
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory_data_0, path_0, None)
    assert inventory_module

# Generated at 2022-06-25 10:04:55.146306
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    with mock.patch.object(open, 'read') as mocked_method:
        mocked_method.return_value = ''
        inventory_module_parse.parse("")


# Generated at 2022-06-25 10:04:57.061245
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse('./test/hosts', 'host', 'group')


# Generated at 2022-06-25 10:05:03.994905
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Unit test for method parse of class InventoryModule
    '''

    print("test_InventoryModule_parse") 
    inventory_module_parse_0 = InventoryModule()

    try:
        inventory_module_parse_0._parse()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 10:05:05.286383
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()



# Generated at 2022-06-25 10:05:11.766046
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    inventory_module_parse._parse('some tests','some other tests')
    inventory_module_parse.inventory


# Generated at 2022-06-25 10:05:18.208362
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory import Inventory
    inventory_module_1 = InventoryModule()
    inventory_obj = Inventory(loader=None)
    inventory_obj.groups = {}
    inventory_module_1.inventory = inventory_obj
    inventory_module_1.parse('hosts','[test]\nhost1\nhost2')
    assert inventory_obj.groups['test'].get_hosts() == ['host1','host2']
    try:
        inventory_module_1.parse('hosts', '[test]\nhost1\nhost2\nhost3:xx\n')
    except AnsibleParserError:
        pass
    try:
        inventory_module_1.parse('hosts', '[test2]\nhost1\nhost2\nxx:xxx\n')
    except AnsibleParserError:
        pass

# Generated at 2022-06-25 10:05:26.992328
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse("./test_cases/test_case_1.txt")

    inventory_module_2 = InventoryModule()
    inventory_module_2.parse("./test_cases/test_case_2.txt")

    inventory_module_3 = InventoryModule()
    inventory_module_3.parse("./test_cases/test_case_3.txt")

    inventory_module_4 = InventoryModule()
    inventory_module_4.parse("http://example.com")


# Generated at 2022-06-25 10:05:34.168077
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_1 = InventoryModule()
    inventory_module_1._parse('path', ['[group1]', '[group2]'])

    inventory_module_2 = InventoryModule()
    inventory_module_2._parse('path', ['[group1]', '[group2:vars]'])

    inventory_module_3 = InventoryModule()
    inventory_module_3._parse('path', ['[group1]', '[group2:children]'])

    inventory_module_4 = InventoryModule()
    inventory_module_4._parse('path', ['[group1]', 'host1', 'host2', '[group2:children]'])

    inventory_module_5 = InventoryModule()
    inventory_module_5._parse('path', ['[group1]', 'host1 port=1234', 'host2', '[group2:children]'])



# Generated at 2022-06-25 10:05:35.963291
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 10:06:56.919215
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # FIXME: This test case can be updated with a more concrete and less complex inventory
    # data.
    inventory_module_0 = InventoryModule()
    str_0 = 'foo:bar'
    str_1 = 'foo:bar'
    try:
        inventory_module_0.parse(str_0, str_1)
    except Exception as e:
        str_2 = type(e)
        assert type(e) is AnsibleError
    else:
        raise AssertionError("Expected exception not raised")


# Generated at 2022-06-25 10:07:06.062031
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse("test_hosts_0.ini","all")
    for host in inventory_module.inventory.hosts:
        print("host.name = ", host.name)
        for variable in host.vars:
            print("host.vars[", variable ,"] = ", host.get_variable(variable))
        for variable in host.vars_cache:
            print("host.vars_cache[", variable ,"] = ", host.vars_cache[variable])
        print("")


# Generated at 2022-06-25 10:07:12.107995
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_file_name = "./unit_test/inventory/inventory_file_sample"
    test_file_name_1 = "./unit_test/inventory/inventory_file_sample_1"
    test_file_name_2 = "./unit_test/inventory/inventory_file_sample_2"
    test_file_name_3 = "./unit_test/inventory/inventory_file_sample_3"
    test_file_name_4 = "./unit_test/inventory/inventory_file_sample_4"
    test_file_name_5 = "./unit_test/inventory/inventory_file_sample_5"
    inventory_module_0 = InventoryModule()
    inventory_module_0._parse(test_file_name, None)

# Generated at 2022-06-25 10:07:17.023731
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Given
    inventory_module = InventoryModule()


# Generated at 2022-06-25 10:07:24.710449
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    def test_case_1():
        #config_file = """
        #[test_group]
        #test_host
        #"""
        config_file = """
        # The name of the host group, here we call them [servers]
        [servers]

        # The following two lines define hosts called web1 and web2
        web1 http_port=80 maxRequestsPerChild=808
        web2 http_port=443 maxRequestsPerChild=1024

        # You might want to add a description for the group, like so
        [servers:vars]
        group_description="The user-facing web servers"
        """
        inventory_module_1 = InventoryModule()
        inventory_module_1.parse(StringIO(config_file), "test_file")

# Generated at 2022-06-25 10:07:26.401380
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    pass


# Generated at 2022-06-25 10:07:28.648183
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse("/path/to/nothing", [], [])


# Generated at 2022-06-25 10:07:30.703206
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse('/hosts')


# Generated at 2022-06-25 10:07:35.026812
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(os.path.dirname(__file__)+"/../../../plugins/inventory/inventory_file.ini")

if __name__ == "__main__":
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 10:07:42.371685
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    This test case is to verify method parse of class InventoryModule.
    '''
    # These tests should not raise exceptions
    inventory_module_1 = InventoryModule()
    inventory_module_1._parse('dummy_path', ['[test_group]'])
    inventory_module_1._parse('dummy_path', ['[test_group:child]'])
    inventory_module_1._parse('dummy_path', ['[test_group:children]'])
    inventory_module_1._parse('dummy_path', ['[test_group:vars]'])
    inventory_module_1._parse('dummy_path', ['[test_group]', 'localhost', '127.0.0.1'])

# Generated at 2022-06-25 10:09:10.298844
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    
    lines = ["[webservers]",
    "foo.example.org",
    "bar.example.org",
    "",
    "# a comment",
    "",
    "[dbservers]",
    "one.example.org",
    "two.example.org",
    "three.example.org"]
    #input_file = "../test_data/inventory/test_inventory_1.txt"
    #with open(input_file, 'r') as f:
    #    lines = f.read().splitlines()
    inventory_module_1.parse(lines)


# Generated at 2022-06-25 10:09:15.925876
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    dummy_group = Group("dummy_group")
    dummy_inventory = Inventory("some_inventory",dummy_group)
    inventory_module = InventoryModule(dummy_inventory)

    # Test case 0
    path = "some_path"
    lines = ["host1", "host2.example.com:1234 user=root", "host3:1234 "]
    inventory_module._parse(path, lines)
    assert (lines[0] in dummy_inventory.hosts)
    assert (lines[1] in dummy_inventory.hosts)
    assert (lines[2] in dummy_inventory.hosts)

    # Test case 1
    path = "some_path"
    lines = ["[group]", "host1", "host2.example.com:1234 user=root", "host3:1234 "]


# Generated at 2022-06-25 10:09:17.304155
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    result = inventory_module_1.parse("test")
    assert result == None


# Generated at 2022-06-25 10:09:18.395068
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(None, None)


# Generated at 2022-06-25 10:09:23.135577
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_parse_0 = InventoryModule()

    # Line number: 4
    inventory_module_parse_0.line = '[unix:children]'
    inventory_module_parse_0.path = 'test/inventory/inventory_module_parse'
    inventory_module_parse_0.parse(inventory_module_parse_0.path)


# Generated at 2022-06-25 10:09:30.702951
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module = InventoryModule()

    # Expect to raise exception
    with pytest.raises(AnsibleParserError) as err:
        inventory_module.parse('/tmp/test_yaml_0.yml')
        assert 'AnsibleParserError' in str(err)

    # Expect to raise exception
    with pytest.raises(AnsibleParserError) as err:
        inventory_module.parse('/tmp/test_yaml_1.yml')
        assert 'AnsibleParserError' in str(err)

    inventory_module.parse('/tmp/test_yaml_2.yml')
    inventory_module.parse('/tmp/test_yaml_3.yml')
    inventory_module.parse('/tmp/test_yaml_4.yml')

# Generated at 2022-06-25 10:09:34.152062
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse_0 = InventoryModule()
    file_path = "test/file_ansible_hosts"
    inventory_module_parse_0.parse(file_path)

test_case_0()
test_InventoryModule_parse()

# Generated at 2022-06-25 10:09:45.336690
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    try:
        with open("..\\..\\..\\ansible\\inventory\\test_data\\test_inventory_0", "r") as inventory_file:
            inventory_module_1.parse(inventory_file.name, inventory_file)
    except AnsibleParserError as e:
        print("test_InventoryModule_parse: %s" % e)
        return
    except AnsibleError as e:
        print("test_InventoryModule_parse: %s" % e)
        return
    except Exception as e:
        print("test_InventoryModule_parse: %s" % e)
        return


# Generated at 2022-06-25 10:09:49.673583
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse("inventory.txt")

# Generated at 2022-06-25 10:09:52.952730
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
