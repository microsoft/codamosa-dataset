

# Generated at 2022-06-25 10:01:31.153142
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    path_0 = 'path'
    data_0 = ['[a]', 'a']
    inventory_module_1.parse(path_0, data_0)


# Generated at 2022-06-25 10:01:42.466624
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Creating an object of class InventoryModule
    inventory_module_0 = InventoryModule()

    # Calling method parse of InventoryModule class which returns the inventory object
    inventory_0 = inventory_module_0.parse(path='inventory')

    # Testing that inventory is of the class Inventory
    assert isinstance(inventory_0, Inventory), 'Expected Inventory'

    # Testing the group names
    group_names = inventory_0.list_groups()
    assert group_names == ['ungrouped', 'france', 'france:children', 'awesome', 'awesome:children', 'noc', 'noc:children', 'france:vars', 'awesome:vars', 'noc:vars'], "The expected groupnames don't match with the actual groupnames"

    # Testing host variables of hosts
    host_0 = inventory_0.get

# Generated at 2022-06-25 10:01:52.684099
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = Inventory('test_create')
    inventory_module_0.inventory = inventory_0
    inventory_module_0.patterns = {'groupname': re.compile('''^([^:\]\s]+)\\s*(?:\\#.*)?\\s*$''', re.VERBOSE), 'section': re.compile('''^\\[\\s*([^:]+)(?::(\\w+))?\\s*\\]\\s*(?:\\#.*)?\\s*$''', re.VERBOSE)}
    inventory_module_0.lineno = 0
    inventory_0.create_host_file()

# Generated at 2022-06-25 10:01:55.445603
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    inventory_module_0.parse('')


# Generated at 2022-06-25 10:02:05.379505
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    # input_str of parse is of type str
    input_str = " [groupname ]\n\n[groupname:children]\n\n[groupname:vars]\n\n[groupname:hosts]\n\n[groupname :children]\n\n[groupname :vars]\n\n[groupname :hosts]\nkey=value # comment\nkey1 =value1\n\nkey2= value2\n\nkey3=value 3\n"
    # Path of parse is of type str
    path = "path"
    inventory_module_0.parse(input_str, path)


# Generated at 2022-06-25 10:02:07.364172
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    bool_0 = False
    inventory_module_0.parse(bool_0)


# Generated at 2022-06-25 10:02:17.813087
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Path of one file:
    # /home/user/ansible/hosts
    path_1 = '/home/user/ansible/hosts'

    # Define string with content of file
    lines_0 = "all    ansible_ssh_host=test1.example.com"

    inventory_module_0 = InventoryModule()
    inventory_module_0._parse(path_1, lines_0)

    # Unit test for method _populate_host_vars of class InventoryModule
    hostnames_0 = ['all']
    variables_0 = {'ansible_ssh_host': 'test1.example.com'}
    groupname_0 = None
    port_0 = None

# Generated at 2022-06-25 10:02:26.945361
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    bool_0 = True
    str_0 = "test_case_0"
    str_1 = "test_case_1"
    str_2 = "test_case_2"
    str_3 = "test_case_3"
    str_4 = "test_case_4"
    str_5 = "test_case_5"
    str_6 = "test_case_6"
    str_7 = "test_case_7"
    str_8 = "test_case_8"
    str_9 = "test_case_9"
    str_10 = "test_case_10"
    str_11 = "test_case_11"
    str_12 = "test_case_12"
    str_13 = "test_case_13"

# Generated at 2022-06-25 10:02:29.545411
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_2 = InventoryModule()
    path_0 = None
    data_0 = None
    inventory_module_2.parse(path_0, data_0)


# Generated at 2022-06-25 10:02:31.600794
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    path_0 = 'path_0'
    lines_0 = ['']
    inventory_module_0._parse(path_0, lines_0)


# Generated at 2022-06-25 10:02:54.019048
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse("test_inventory", "[webservers] \nsomehost.example.com\n-----")

    inventory_module_1 = InventoryModule()
    inventory_module_1.parse("test_inventory", "[webservers] \nsomehost.example.com\n[dbservers]\nsomehost.example.com\n[all:vars]\nansible_ssh_user=ubuntu\nansible_ssh_private_key_file=.vagrant/machines/default/virtualbox/private_key\n")

# Generated at 2022-06-25 10:02:55.727428
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    inventory_module_parse._parse()


# Generated at 2022-06-25 10:03:03.057655
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # 1. Instantiate InventoryModule
    inventory_module = InventoryModule()
    # 2. Read the inventory data from a file
    data = []
    with open('/home/david/Documents/ansible_inventory/ansible_inventory/test_data/test_inventory_ejemplo', 'r') as f:
        lines = f.readlines()
    f.close()
    # 3. Parse the inventory data
    inventory_module._parse('test_inventory_ejemplo', data)
    
    
    
    
if __name__ == '__main__':
    print('Test the module')
    test_case_0()

# Generated at 2022-06-25 10:03:10.737835
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse(["[ungrouped]\n[ungrouped:vars]\nvariable_1='foo'\nvariable_2=\"bar\""])
    assert(inventory_module.inventory.groups['ungrouped'].variables['variable_1'] == to_text('foo'))
    assert(inventory_module.inventory.groups['ungrouped'].variables['variable_2'] == to_text('bar'))

if __name__ == '__main__':
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 10:03:15.071785
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    with open('/etc/ansible/hosts', 'r') as f:
        lines = f.readlines()
        lines = [ line.strip() for line in lines]
    inventory_module = InventoryModule()
    inventory_module._parse('/etc/ansible/hosts', lines)

# test_case_0()
test_InventoryModule_parse()

# Generated at 2022-06-25 10:03:17.004902
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    path = '/etc/ansible/hosts'
    data = []
    inventory_module_0._parse(path, data)


# Generated at 2022-06-25 10:03:20.806844
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    inventory_module_parse.parse("hosts", "/Users/michael/Workspace/Ansible/playbooks/hosts", None)


# Generated at 2022-06-25 10:03:25.471008
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(path='<string>', content='[group1:children]\nweb')
    assert getattr(inventory_module_1.inventory, "groups")
    assert getattr(inventory_module_1.inventory.groups, "group1")
    assert inventory_module_1.inventory.groups['group1'].children == ['web']


# Generated at 2022-06-25 10:03:29.086467
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse("test.yml")
    # pdb.set_trace()


if __name__ == '__main__':
    test_InventoryModule_parse()

# Generated at 2022-06-25 10:03:31.826632
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    # No exception raised
    inventory_module_0.parse('foo', None)
    # No exception raised, does not raise AnsibleError
    inventory_module_0.parse(None, None)


# Generated at 2022-06-25 10:04:00.265747
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    #test_case_0()

    print("test_InventoryModule_parse")
    inventory_module_1 = InventoryModule([], 'fake_inventory')
    result = inventory_module_1.parse()
    assert result == [], "Test failed with input " + "'fake_inventory'" + result

    inventoryModule_2 = InventoryModule([], '../samples/sampleInventory.ini')
    result = inventoryModule_2.parse()
    assert result == '', "Test failed with input " + "'../samples/sampleInventory.ini'" + result

    inventoryModule_3 = InventoryModule(
        [], '../samples/parsing/parse_address.ini')
    result = inventoryModule_3.parse()
    assert result == '', "Test failed with input " + "'../samples/parsing/parse_address.ini'"

# Generated at 2022-06-25 10:04:11.399007
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    with pytest.raises(AnsibleError) as cm:
        inventory_module_1._parse('', ['[section', '[sectionname:var'])
        assert str(cm.value) == "Error parsing host definition '[]': No closing quotation"
    with pytest.raises(AnsibleError) as cm:
        inventory_module_1._parse('', ['[section', '[sectionname:var]'])
        assert str(cm.value) == "Error parsing host definition '[]': No closing quotation"
    with pytest.raises(AnsibleError) as cm:
        inventory_module_1._parse('', ['[section', '[sectionname:var]', 'host1=host1:8081'])

# Generated at 2022-06-25 10:04:12.865221
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse('', 'some file name')

# Generated at 2022-06-25 10:04:15.256688
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(os.path.join(os.path.dirname(sys.argv[0]),"inventory_dynamic.sh"))



# Generated at 2022-06-25 10:04:21.220621
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    path = "test_files/inventory/test_inventory_script.ini"
    inventory_module_1.parse(path)

test_case_0()
test_InventoryModule_parse()

# Generated at 2022-06-25 10:04:28.608985
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    path = ''
    data = dict()
    inventory_module_0._parse(path, data)


# Generated at 2022-06-25 10:04:31.527476
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse(path='')


# Generated at 2022-06-25 10:04:39.175738
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse_0 = InventoryModule()
    temp = inventory_module_parse_0.vars
    Path = os.path
    temp_Path = os.path.exists
    exists_Path = os.path.exists
    exists_Path_0 = os.path.exists
    exists_Path_0.return_value = False
    exists_Path.return_value = False
    temp_Path.return_value = True
    inventory_module_parse_0.parse(Path, group_prefix=None, var_prefix=None, cache=False)


# Generated at 2022-06-25 10:04:51.735074
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test 1 : with data
    lines = ["[test_group]\n", "test_host\n", "[test_group:vars]\n", "test_variable=test_value\n"]
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse('/tmp/test_inventory_file', lines)
    assert inventory_module_1.inventory.groups.keys() == ['test_group']
    assert inventory_module_1.inventory.groups['test_group'].hosts.keys() == ['test_host']
    assert inventory_module_1.inventory.groups['test_group'].vars == dict(test_variable='test_value')

    # Test 2 : with empty data
    lines = ["[test_group]\n", "[test_group:vars]\n"]
    inventory_

# Generated at 2022-06-25 10:04:53.936709
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse("/tmp/ansible_samples/sample_inventory.ini", sample_inventory_ini_content)


# Generated at 2022-06-25 10:05:42.831916
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    data = "[ungrouped]"
    data += "\n"
    data += "localhost\n"
    inventory_module._parse("/dev/null", data)
    assert inventory_module.inventory.groups.__len__() == 1
    assert inventory_module.inventory.groups['ungrouped'].hosts.__len__() == 1
    assert inventory_module.inventory.groups['ungrouped'].hosts == ['localhost']

# Generated at 2022-06-25 10:05:50.450066
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

# Generated at 2022-06-25 10:05:57.699796
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    dir_path = os.path.dirname(os.path.realpath(__file__))
    path = os.path.join(dir_path, 'test_InventoryModule.txt')
    #print(path)
    inventory_module_0._parse(path, 'test')


# Generated at 2022-06-25 10:05:59.501082
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    file_name = "testfiles/inventory_file_unit_test_0"
    inventory_module.parse(file_name)


# Generated at 2022-06-25 10:06:06.517086
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 10:06:11.354315
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    sys.argv[1] = 'sample.ini'
    inventory_module_0.parse()


# Generated at 2022-06-25 10:06:21.718205
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """
    Test case for method parse of class InventoryModule
    """
    inventory_module = InventoryModule()

    # Catch errors raised when parsing an empty YAML file
    with pytest.raises(AnsibleParserError):
        inventory_module._parse('/tmp/test_case_0', '')

    # Catch errors raised when parsing malformed inventory file

# Generated at 2022-06-25 10:06:32.712490
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    data = '''[test]
    localhost ansible_connection=local
    foo:4545
    [group2:children]
    test
    [group3:vars]
    foo=bar'''
    inv = InventoryModule()
    inv._parse(None, data.split('\n'))
    assert(inv.groups == ['ungrouped', 'group2', 'group3', 'test'])
    assert(inv.groups['group2']['children'] == ['test'])
    assert(inv.hosts['localhost']['ansible_connection'] == 'local')
    assert(inv.hosts['foo:4545']['port'] == '4545')


# Generated at 2022-06-25 10:06:41.146149
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Prepare a test case
    file_name = os.path.expanduser('~/mytest_inventory')

# Generated at 2022-06-25 10:06:49.020327
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    yaml_data = '''
    all:
      hosts:
        host_1:
          ansible_connection: local
        host_2:
          ansible_connection: local
    '''

    with open('/tmp/hosts', 'w') as f:
        f.write(yaml_data)

    #yaml_data = '''
    #all:
      #hosts:
        #host_1:
          #ansible_connection: local
        #host_2:
          #ansible_connection: local
    #'''
    #inventory_module_0 = obj_yaml(data=yaml_data)

    inventory_module_0.parse('/tmp/hosts', None)
    assert inventory_module_0.inventory.get_groups_

# Generated at 2022-06-25 10:07:37.837429
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse("inventory", "test_data/test_inventory_0.ini")

test_InventoryModule_parse()

# Generated at 2022-06-25 10:07:42.061862
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Setup
    inventory_module = InventoryModule()
    path = 'testHosts.cfg'
    lines = [
        'web01 ansible_host=web01.ansible.com',
        'web02 ansible_host=web02.ansible.com',
        '[webservers]'
    ]

    # Exercise
    inventory_module._parse(path, lines)

    # Verify
    assert len(inventory_module.inventory._groups) == 1


# Generated at 2022-06-25 10:07:43.679498
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse("/home/ansible/ansible/lib/ansible/inventory/test/inventory.yaml", None, None)


# Generated at 2022-06-25 10:07:49.165694
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    self_0 = inventory_module_0

    #Input params
    # For function _parse_value
    value_0 = '"value"'

    # For function _parse_variable_definition
    line_0 = 'variable = value'

    # For function _parse_host_definition
    line_1 = 'host = value'

    # For function _parse_group_name
    line_2 = '[group]'

    # For function _compile_patterns
    self_1 = inventory_module_0

    # For function _expand_hostpattern
    hostpattern_0 = 'host'

    # For function _parse_value
    # Input params
    value_1 = "value"

    # Output params
    # For function parse

# Generated at 2022-06-25 10:07:52.638424
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_test = InventoryModule()
    path = "test_inventory_file"
    data = ["[test_group_name]",
            "test_host_1",
            "test_host_2 user=test_user"]
    inventory_module_test._parse(path, data)
    assert inventory_module_test.inventory.groups.keys() == ['test_group_name']


# Generated at 2022-06-25 10:07:59.873359
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    path_1 = '/home/shamith/PlayGround/ansible/test/integration/inventory_tests'
    lines_1 = ["[ungrouped]", "alpha:5050", "beta:5051", "[group1]", "alpha", "beta", "gamma", "[group2]", "delta", "epsilon", "[group3]", "gamma", "delta", "epsilon", "[group4:children]", "group1", "group2", "[group5:vars]", "some_server=foo.example.com", "[group6]", "some_server=bar.example.com"]
    inventory_module_0._parse(path_1, lines_1)
    assert inventory_module_0.inventory.groups['group3'].get_hosts

# Generated at 2022-06-25 10:08:05.132759
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse('tests/inventory_hosts_test.ini', cache=False)

    assert len(inventory_module.inventory.groups) == 5
    assert 'valid_group_name' in inventory_module.inventory.groups
    assert 'valid-groupname' in inventory_module.inventory.groups
    assert 'group_with_vars' in inventory_module.inventory.groups
    assert 'group-with-children' in inventory_module.inventory.groups
    assert 'group-with-duplicate-vars' in inventory_module.inventory.groups

    assert len(inventory_module.inventory.get_group('valid_group_name').get_hosts()) == 1
    assert inventory_module.inventory.get_group('valid_group_name').get_host('alpha').vars['user']

# Generated at 2022-06-25 10:08:15.467556
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Prepare arguments
    inventory_module_0 = InventoryModule()
    path = '/etc/ansible/hosts'
    lines = []
    lines.append('[groupname]')
    lines.append('host1')
    lines.append('host2')
    lines.append('[othergroup:vars]')
    lines.append('red=blue')
    lines.append('[yetanothergroup:children]')
    lines.append('groupname')

    try:
        # Call parse()
        inventory_module_0._parse(path, lines)
    except Exception as e:
        print(e)
        raise

if __name__ == '__main__':
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 10:08:18.607011
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    try:
        inventory_module_1.parse('/etc/ansible/hosts')
    except AnsibleError as e:
        pytest.fail("AnsibleError: %s" % e)


# Generated at 2022-06-25 10:08:26.102410
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_str = '''
[one]
localhost ansible_connection=local

[one:vars]
foo=bar

[two]
127.0.0.1

[two:vars]
service=apache

[three]
host1=host1.example.com
host2=host2.example.com
host3
'''
    with tempfile.NamedTemporaryFile() as fd:
        fd.write(to_bytes(test_str))
        fd.flush()
        inventory_module = InventoryModule()
        inventory_module.parse(fd.name)
        assert 'one' in inventory_module.inventory.groups
        assert 'localhost' in inventory_module.inventory.groups['one'].hosts

# Generated at 2022-06-25 10:09:18.764070
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Creating list of hostnames for unit test
    hostnameList = ["gorge","meadows","joe"]
    # Creating expected list of hostnames for unit test
    expectedList = ["gorge","meadows","joe"]
    # Creating port instance for unit test
    port = 4432
    # Creating expected port instance for unit test
    expectedPort = 4432
    # Creating expected dictionary of variables for unit test
    expectedDict = {"ansible_port" : 4432}
    # Creating dictionary of variables to pass to unit test
    dict = {"ansible_port": 4432}
    # Creating the inventory obj
    myInventory = InventoryManager(None)
    # Creating the inventory module obj
    inventory_module = InventoryModule()
    # Setting the inventory in the obj
    inventory_module.inventory = myInventory
    # Setting the dict/

# Generated at 2022-06-25 10:09:22.835516
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """
    Test InventoryModule.parse()
    """
    print(test_InventoryModule_parse.__doc__)
    inventory_module_1 = InventoryModule()
    # Call InventoryModule.parse()
    inventory_module_1.parse('/etc/ansible/hosts')

# Test suite

# Generated at 2022-06-25 10:09:25.142090
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    # should return a dict
    result = inventory_module_1._parse()
    assert isinstance(result, object)



# Generated at 2022-06-25 10:09:26.997980
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse("inventory_file.ini","[group]")


# Generated at 2022-06-25 10:09:37.779973
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    lines = [
        '''# This is a comment line in inventory_module_0.ini''',
        '''[group_0]''',
        '''# This is the hosts line for group_0''',
        '''192.168.133.100 [user1, user2] foo=bar private=192.168.133.100 not_a_key''',
        '''192.168.133.101''',
        '''192.168.133.102:22'''
    ]
    path = "/some/path/inventory_module_0.ini"
    # d = inventory_module_0._parse(path, lines)
    d = inventory_module_0._parse(None, lines)


# Generated at 2022-06-25 10:09:48.686890
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1._parse('inventory_module.parse', ['[group1]', 'host1 ansible_port=2222'])
    assert inventory_module_1.inventory.get_host('host1').get_vars()['ansible_port'] == 2222
    
    inventory_module_2 = InventoryModule()
    inventory_module_2._parse('inventory_module.parse', ['[group1]', 'host1 ansible_port=2222', '[group1:vars]', 'some_var=someval'])
    assert inventory_module_2.inventory.get_host('host1').get_vars()['ansible_port'] == 2222

# Generated at 2022-06-25 10:09:54.982555
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    path = os.path.join(os.path.dirname(__file__), 'test_inventory_ini.txt')
    inventory_module.parse(path)
    assert len(inventory_module.inventory.groups) == 3
    assert len(inventory_module.inventory.get_hosts()) == 3


# Generated at 2022-06-25 10:10:01.641325
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    path = './1.txt'
    try:
        inventory_module_1._parse(path, [])
    except AnsibleParserError:
        pass


# Generated at 2022-06-25 10:10:06.587966
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_InventoryModule_parse_0()
    test_InventoryModule_parse_1()
    test_InventoryModule_parse_2()
    test_InventoryModule_parse_3()
    test_InventoryModule_parse_4()
    test_InventoryModule_parse_5()


# Generated at 2022-06-25 10:10:17.821242
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # ~ import unittest
    # ~ class TestInventoryModule(unittest.TestCase):
    # ~ def setUp(self):
    # ~ self.inventory_module_0 = InventoryModule()
    # ~ def test_parse(self):
    # ~ path = ''
    # ~ data = []
    # ~ self.inventory_module_0.parse(path, data)
    # ~ 
    inventory_module_1 = InventoryModule()