

# Generated at 2022-06-12 16:49:19.340223
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import (_create_test_downloader, _download_testdata,
                       mock_open_for_reading)

    test_data_dir = os.path.join(_TEST_DIR, 'hls')
    info_dict = {
        'url': 'http://example.com/manifest.m3u8',
        'id': 'example_id',
        'ext': 'mp4',
        'title': 'Example video',
        'http_headers': {},
    }
    output_file = os.path.join(_TEST_DIR, 'example.mp4')
    expected_output_file = os.path.join(test_data_dir, 'example.mp4')


# Generated at 2022-06-12 16:49:33.202092
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Generate test data.
    import random
    import io
    import base64
    import hmac
    import hashlib
    import pycrypto

    # Tests are run with the current working directory set to tests/ in the
    # project root.
    manifest_path = ".test_encrypted_hls/master.m3u8"
    manifest_relpath_segment_url = manifest_path.replace("master.m3u8", "media_%03d.ts")
    decryption_key_relpath = ".test_encrypted_hls/test_key"

    # Construct the manifest from its parts

# Generated at 2022-06-12 16:49:46.193382
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test_io import MockYDL, get_testcases_by_names
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .utils import parse_m3u8_attributes

    # Load the tests
    test_cases = get_testcases_by_names(['hls', 'hls_variant'])

    def _build_it(self, url, **kwargs):
        # Build a temporary InfoExtractor class using the code provided in the test case
        if 'ie_code' in kwargs:
            ie_code = kwargs['ie_code']

# Generated at 2022-06-12 16:49:47.779560
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('', {})


# Generated at 2022-06-12 16:49:58.205821
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import io
    import os
    import tempfile
    import unittest
    import zlib

    from .external import ExternalFD
    from ..compat import (
        compat_urlopen,
        compat_urllib_request,
        compat_urllib_parse,
        compat_urllib_error,
        compat_http_client,
    )
    from ..downloader import FileDownloader

    data_server_port = 8001
    data_server_docroot = os.path.join(os.path.dirname(__file__), 'hls_testdata')

    class DataServer(object):
        def __init__(self):
            self._next_connection = 0

        def serve_forever(self):
            self.setup_server()
            self._server.serve_forever()


# Generated at 2022-06-12 16:50:06.733025
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.http import HlsFD

    # Test is_live heuristic
    live_url = r'#EXT-X-MEDIA-SEQUENCE:47'
    assert HlsFD.can_download(live_url, {'is_live': True})
    assert not HlsFD.can_download(live_url, {'is_live': False})

    # Test byte range heuristic
    byte_range_url = r'#EXT-X-BYTERANGE:7980@1456'
    assert HlsFD.can_download(byte_range_url, {})
    assert not HlsFD.can_download(byte_range_url, {'is_live': True})
    assert not HlsFD.can_download(byte_range_url, {'is_live': False})

    # Test encryption method

# Generated at 2022-06-12 16:50:14.555257
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import functools
    import io
    import xml.etree.ElementTree as ET
    from .fragment import FileFragmentFD
    from .external import FFmpegFD
    from ..utils import (
        encodeFilename,
        prepend_extension,
    )

    def _build_manifest(encryption,
                        extra_param_to_segment_url,
                        segment_urls,
                        unencrypted_segment_urls,
                        has_byterange=False):
        m3u8 = io.StringIO()
        m3u8.write('#EXTM3U\n')
        m3u8.write('#EXT-X-VERSION:4\n')

# Generated at 2022-06-12 16:50:25.168481
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import FakeYDL
    from ..extractor.http import HlsFD

    # Test with a dash_manifest hls video
    expected_output = b'\x00' * 1024 * 1024 * 2

    lyadl = FakeYDL()
    lyadl.add_info_extractors()

    url = 'https://bitdash-a.akamaihd.net/content/MI201109210084_1/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8'

# Generated at 2022-06-12 16:50:29.287688
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    import pytest
    sys.modules['pycrypto'] = python_mock('Crypto')
    test_class = HlsFD(None, {'test': True})
    assert test_class

test_HlsFD()

# Generated at 2022-06-12 16:50:40.697466
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import common
    from ..extractor.common import InfoExtractor
    from ..downloader.f4m import F4mFD
    from ..utils import parse_duration

    class DummyYDL(object):
        def __init__(self):
            self.params = InfoExtractor._initialize_default_extractor_params()
            self.params['test'] = True

        def urlopen(self, url):
            class FakeUrlOpen(object):
                def __init__(self, url):
                    self.url = url

                def geturl(self):
                    return self.url


# Generated at 2022-06-12 16:51:03.270149
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .utils import HlsFDTest
    HlsFDTest('https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8').test()
    HlsFDTest('https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_adv_example_hevc/master.m3u8').test()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:51:11.502009
# Unit test for constructor of class HlsFD

# Generated at 2022-06-12 16:51:24.710358
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-12 16:51:35.270686
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import unittest
    import unittest.mock
    from ..downloader import YoutubeDL
    from .external import ExternalFD

    # To ensure tests to be repeatable
    ExternalFD._is_available = False


# Generated at 2022-06-12 16:51:48.343278
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import fake_http_server
    import doctest
    import requests

    reqs = []
    with fake_http_server(lambda path: path.endswith('.m3u8'), content_type='application/x-mpegURL') as s:
        content = '''
#EXTM3U
#EXTINF:2.001,
https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4
#EXT-X-ENDLIST
'''.strip()
        s.content.write(content.encode('utf-8'))
        s.content.seek(0)
        assert requests.get(s.get_url()).text == content

# Generated at 2022-06-12 16:51:56.119302
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os, inspect, sys
    import json
    import unittest

    # Get the parent directory name of this file
    parent_dir = os.path.abspath(inspect.getfile(inspect.currentframe())).rsplit(os.sep, 1)[0]
    sys.path.insert(0, parent_dir)
    from downloader.common import FileDownloader

    from .downloader.http import HttpFD
    from .downloader.external import FFmpegFD


    class TestHlsFD(unittest.TestCase):

        def setUp(self):
            self.HLS_TEST_STREAM = 'https://mnmedias.api.telequebec.tv/m3u8/29880.m3u8'

# Generated at 2022-06-12 16:52:07.913945
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import unittest
    from .test_fragment import BoxdInsecureRequestHandler
    from .test_external import dummy_opener
    from .test_fragment import MockYDL
    from .test_fragment import _start_server, _stop_server
    from .test_fragment import MockServerHandler
    _, server = _start_server(MockServerHandler, BoxdInsecureRequestHandler)

    def is_hlsnative_likely_suitable(manifest):
        return HlsFD.can_download(manifest, {'is_live': False})

    class TestHlsFD_real_download(unittest.TestCase):
        def setUp(self):
            self.ydl = MockYDL()
            self.fd = HlsFD(self.ydl, {})

# Generated at 2022-06-12 16:52:10.342701
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hlsFD = HlsFD({}, {})
    hlsFD.real_download("./filename", {
        'url': 'https://www.youtube.com/watch?v=dQw4w9WgXcQ&ab_channel=RickAstleyVEVO',
        'format': 'best'})

# Generated at 2022-06-12 16:52:22.304697
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    sys.path.append('..')
    from downloader import YoutubeDL
    from tests.test_downloader import MockYDL
    from tests.downloader import get_testcases_by_names
    from tests.compat import unittest

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.mockydl = MockYDL()
            self.fract = HlsFD(self.mockydl, {'format': 'bestvideo+bestaudio', 'hls_use_mpegts': True})
            self.testcases = get_testcases_by_names(['test2'])

        def test_hlsfd(self):
            self.assertTrue(self.fract.real_download('test.mp4', self.testcases[0]))


# Generated at 2022-06-12 16:52:33.687104
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .http import HttpFD

    try:
        from Crypto.Cipher import AES
        can_decrypt_frag = True
    except ImportError:
        can_decrypt_frag = False

    def _test_can_download(manifest, info_dict):
        assert HlsFD.can_download(manifest, info_dict)

    def _test_cant_download(manifest, info_dict):
        assert not HlsFD.can_download(manifest, info_dict)

    def _test_equal_downloads(manifest, download_info, params=None):
        params['test'] = True
        hls_fd = HlsFD(None, params, download_info['url'], download_info['info_dict'])

# Generated at 2022-06-12 16:52:58.684838
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import ydl_testing as yt
    class YDL:
        params = {'nooverwrites': True}
        def __init__(self, params):
            self.params = params
            self.logger = yt.FakeLogger()
            self.tmpfilename = yt.TEST_FILES_PATH

        def urlopen(self, url):
            url = url.to_string()
            if url == 'https://www.youtube.com/api/manifest/dash/id/bf5bb2419360daf1/source/youtube?as=fmp4_audio_clear%2Cfmp4_sd_hd_clear':
                return yt.FakeFile('dashmanifest.mpd')

# Generated at 2022-06-12 16:53:10.242477
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.generic import GenericIE
    from ..extractor import YoutubeIE
    ydl_opts = {
        'quiet': True,
        'skip_download': True,
        'simulate': True,
        'noplaylist': True,
        'format': 'bestvideo+bestaudio/best',
        'hls_use_mpegts': False,
        'prefer_ffmpeg': True,
    }
    # Do not use start_time and end_time as some of these vods can have multiple
    # parts and it is better to check that all the parts are present.

# Generated at 2022-06-12 16:53:22.518585
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import youtube_dl.extractor.test

    def test_cipher(enc_str, iv_str, key, expected_str):
        iv = binascii.unhexlify(iv_str)
        enc = binascii.unhexlify(enc_str)
        dec = AES.new(binascii.unhexlify(key), AES.MODE_CBC, iv).decrypt(enc)
        assert binascii.hexlify(dec).decode('utf-8') == expected_str

    # Test AES-128 decryption. See https://github.com/ytdl-org/youtube-dl/issues/27660.
    # Test 1

# Generated at 2022-06-12 16:53:33.567330
# Unit test for constructor of class HlsFD

# Generated at 2022-06-12 16:53:44.925173
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testdata_file
    from .test import get_testvideo_streams

    FIELDS = ('id', 'url', 'ext', 'width')

# Generated at 2022-06-12 16:53:54.925399
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """
    Test HlsFD._real_download() to make sure it downloads the correct segments
    and decrypts it correctly.
    """
    from .test import get_testdata_file_name

    # Download a manifest that contains both encrypted and unencrypted media data.
    # Manually compare that the data downloaded and decrypted is identical to
    # the original file.
    test_fn_1 = get_testdata_file_name('HLS_testdata_01.m3u8')
    # Download a manifest that contains only unencrypted media data.
    # Manually compare that the data downloaded is identical to the original file.
    test_fn_2 = get_testdata_file_name('HLS_testdata_02.m3u8')

    from .dash import DashSegmentsFD
    # It is important that this has empty binary data instead

# Generated at 2022-06-12 16:54:02.022425
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .testutils import FakeYDL
    from .extractor import youtube_dl_extractor_for_url
    extractor = youtube_dl_extractor_for_url('https://www.youtube.com/playlist?list=PLybvIgjeFSpR_Qz-7XuZG3Nq3CQUi8f1K')
    extractor._prepare_extraction(FakeYDL())

    filename = 'test hls_native_seg_1.mp4'

# Generated at 2022-06-12 16:54:03.044820
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass

## Unit test for HlsFD

# Generated at 2022-06-12 16:54:14.063528
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .test import get_test_video_url

    hls_manifest = get_test_data('hls_manifest')
    url = get_test_video_url()

# Generated at 2022-06-12 16:54:24.799920
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    from .external import FFmpegFD
    from .utils import encodeFilename
    from .downloader import YoutubeDL

    # Create the test manifest and test fragments

# Generated at 2022-06-12 16:55:07.462582
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    s = '#EXT-X-KEY:METHOD=AES-128,URI="https://priv.example.com/key.php?r=52",IV=0x9c7db8778570d05c3177c349fd9236aa'
    info_dict = {}

    assert HlsFD.can_download(s, info_dict)


# Generated at 2022-06-12 16:55:10.153722
# Unit test for constructor of class HlsFD
def test_HlsFD():
    url = 'https://example.com'
    hls = HlsFD(url)
    assert hls.url == url


# Generated at 2022-06-12 16:55:20.108007
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import shutil
    import tempfile
    import subprocess
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.twitch import TwitchIE
    modified_test_file = sys.argv[1] if len(sys.argv) > 1 else 'test.m3u8'
    output_file = sys.argv[2] if len(sys.argv) > 2 else 'out.ts'
    tmp_dir = tempfile.mkdtemp(prefix='ytdl_test_', suffix='_' + modified_test_file)
    test

# Generated at 2022-06-12 16:55:28.182461
# Unit test for constructor of class HlsFD

# Generated at 2022-06-12 16:55:38.256497
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ydl = FakeYdl()
    params = {
        'hls_prefer_native': True,
        'fragment_retries': 7,
        'fragments_prefer_native': True,
        'skip_unavailable_fragments': False,
    }
    hls_fd = HlsFD(ydl, params).__class__
    assert hls_fd.FD_NAME == 'hlsnative'
    assert hls_fd.params == params
    assert hls_fd._progress_hooks == []
    assert hls_fd._progress_hook_lock == False
    assert hls_fd._progress_hooks_stop_fd == None



# Generated at 2022-06-12 16:55:46.512173
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..utils import unescapeHTML

    fake_info = {
        "url": "https://your.favourite.video/url.m3u8",
        "http_headers": {
            "User-Agent": "Mozilla Firefox"
        },
        "player_url": "https://your.favourite.video/player.js",
        "info_dict": {
            "title": "Video name"
        }
    }
    hls = HlsFD(None, fake_info)

    # Test without decrypting any info
    fake_info['fragment_index'] = 2
    fake_info['fragment_retries'] = 1

# Generated at 2022-06-12 16:55:52.198138
# Unit test for constructor of class HlsFD
def test_HlsFD():
    if not can_decrypt_frag:
        return

# Generated at 2022-06-12 16:56:01.520041
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testdata_files_path
    from .test import get_testcases_for_extractor
    from .test import get_filesystem_encoding
    from .test import get_temp_files_path
    from .test import Result
    from .test import setUp as _setUp
    from .test import tearDown as _tearDown
    from .test import TESTS_DIR
    from .test import TESTS_PATH

    import os
    import shutil
    import sys
    import tempfile
    import yaml
    from youtube_dl import YoutubeDL

    class HlsFD_UnitTest(HlsFD):

        def __init__(self, *args, **kwargs):
            HlsFD.__init__(self, *args, **kwargs)
            self.results = []
            self

# Generated at 2022-06-12 16:56:12.184803
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import io
    import tempfile
    from .wrappers import FileDownloader
    from .extractor import gen_extractors
    from .downloader import gen_ydl
    from .utils import fake_http_server
    from .postprocessor import FFmpegMergerPP

    # This should download the first fragment of the playlist

# Generated at 2022-06-12 16:56:15.414775
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test.test_download import test_url as test_download_url
    return test_download_url('http://hls.trt.com.tr/s1/x/live.m3u8', HlsFD)

# Generated at 2022-06-12 16:57:59.875436
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import encode_data_uri
    from ..extractor.common import InfoExtractor
    # A short live stream example
    test_url = encode_data_uri(
        'm3u8',
        '''#EXTM3U
    #EXT-X-VERSION:3
    #EXT-X-MEDIA-SEQUENCE:0
    #EXT-X-TARGETDURATION:10
    #EXT-X-KEY:METHOD=AES-128,URI=data:,key
    #EXTINF:10.000,
    #EXT-X-BYTERANGE:62228@1013352
    https://example.com/frag.ts
    #EXT-X-ENDLIST
    ''')
    ie = InfoExtractor(HlsFD.get_info_extractor({}))
    info_

# Generated at 2022-06-12 16:58:10.649312
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Can't download
    m = '#EXTM3U\n#EXT-X-VERSION:4\n#EXT-X-TARGETDURATION:2\n'
    i = {}
    assert HlsFD.can_download(m, i) == False
    m += '#EXT-X-KEY:METHOD=AES-128\n'
    assert HlsFD.can_download(m, i) == False
    m += '#EXT-X-BYTERANGE:10@20\n'
    assert HlsFD.can_download(m, i) == False
    i['is_live'] = True
    assert HlsFD.can_download(m, i) == False
    i['is_live'] = False
    m += '#EXT-X-MEDIA-SEQUENCE:10\n'
   

# Generated at 2022-06-12 16:58:15.582768
# Unit test for constructor of class HlsFD
def test_HlsFD():
    class TestHlsFD(HlsFD):
        def __init__(self):
            self.ydl = self
            self.params = {}

        def report_error(self, msg):
            print(msg)

        def report_warning(self, msg):
            print(msg)

        def _prepare_url(self, info_dict, url):
            return url

        def urlopen(self, url):
            return open('test_urlopen.txt', 'rb')

        def to_screen(self, message):
            pass

    TestHlsFD()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:58:22.807541
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-12 16:58:34.057498
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from .http import HttpFD
    from .fragment import FileFragmentFD
    from ..downloader import YoutubeDL
    from .dash import DashSegmentsFD
    from ..compat import compat_str

    HlsFD.can_download = HlsFD.can_download.__func__
    ydl = YoutubeDL({
        'format': 'best[protocol=m3u8_native]/best[protocol=m3u8_native]/best/bestaudio',
        'extractors': gen_extractors(),
        'dump_intermediate_pages': True,
    })
    # Test normal video
    hfd = HlsFD(ydl, [])
    assert isinstance(hfd, HlsFD)
    # Test live video

# Generated at 2022-06-12 16:58:43.321670
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # It suffices to just test that the real_download method does not crash.
    # Specific testing for various HLS features (master playlists, fragments, fragments with decryption)
    # is done in the test_extractor module.
    from .extractor.common import InfoExtractor
    from ..compat import compat_urllib_request
    import tempfile
    import shutil
    import os
