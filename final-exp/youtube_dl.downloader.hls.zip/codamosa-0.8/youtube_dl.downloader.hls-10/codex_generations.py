

# Generated at 2022-06-12 16:49:31.685970
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.generic import YoutubeIE
    from ..utils import SearchInfoExtractor

    import os
    from io import BytesIO
    from tempfile import mkstemp

    class FakeYDL():
        def urlopen(self, *args, **kwargs):
            return FakeUrlOpen(*args, **kwargs)

    class FakeUrlOpen():
        def __init__(self, *args, **kwargs):
            pass

        def geturl(self):
            return "http://test.com"

        def read(self):
            return b""

    # Method real_download should fail if the playlist (manifest) is encrypted
    # #EXT-X-KEY:METHOD=AES-128-128,URI="https://priv.example.com/key.php?r=52"

# Generated at 2022-06-12 16:49:44.184227
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.utils
    import sys
    import traceback
    from .utils import FakeYDL

    def _get_exception_traceback():
        exc_type, exc_value, exc_traceback = sys.exc_info()
        return ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback))


# Generated at 2022-06-12 16:49:55.456651
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class DummyInfoDict:
        def __init__(self, is_live):
            self.is_live = is_live

    class DummyYDL:
        def __init__(self):
            self.params = {}
        def report_warning(self, msg):
            print(msg)


# Generated at 2022-06-12 16:50:05.126290
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import warnings
    warnings.filterwarnings('ignore', '', DeprecationWarning, r'^test_')

    from ..extractor import gen_extractors
    from ..utils import DateRange

    youtube_ie = None
    for ie in gen_extractors():
        if ie.IE_NAME == 'youtube':
            youtube_ie = ie
            break
    assert youtube_ie
    info_dict = youtube_ie.extract('https://youtu.be/BaW_jenozKc')
    assert info_dict
    assert info_dict['ext'] == 'mp4'
    assert info_dict['format_id'] == '133'
    assert info_dict['playlist'] == 'BaW_jenozKc'
    assert info_dict['protocol'] == 'm3u8_native'


# Generated at 2022-06-12 16:50:13.141008
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ydl = YoutubeDL()

    class DummyUrlOpen(object):
        """
        Dummy class to mimic one of the return values of youtube_dl.YoutubeDL.urlopen(),
        specifically the read() method, used by HlsFD.real_download().
        """

        def __init__(self, content):
            self._content = content

        def read(self):
            return self._content

    # Test downloading one and multiple fragments

    def test_download(content, n_frags, frag_index_start=1, fragment_retries=0, skip_unavailable_fragments=True, test=False):
        manifest = content[1:-1] if content.startswith('#EXTM3U') else content
        ydl.urlopen = lambda _, __: DummyUrlOpen(manifest)
        info_

# Generated at 2022-06-12 16:50:23.118829
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import youtube as youtube_ies
    from ..utils import DateRange
    from ..postprocessor import FFmpegMergerPP
    from ..YoutubeDL import YoutubeDL
    from .external import FFmpegFD

    ydl = YoutubeDL({
        'forceurl': True,
        'simulate': True,
        'quiet': True,
        'skip_download': True,
        'format': 'best',
        'outtmpl': 'test_%(format)s-%(id)s.f4m',
        'hls_prefer_native': True,
    })
    ies = ['youtube']
    ies_names = [ie.IE_NAME for ie in ies]
    ydl.add_default_info_extractors(ies)


# Generated at 2022-06-12 16:50:35.575697
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import IsFalse, IsTrue
    from ..extractor import YoutubeDL
    from .fragment import FragmentProgressHook

    class MockInfoDict(dict):
        pass

    # Non-live HLS video without an encryption key
    manifest_text = '#EXTM3U\n#EXT-X-VERSION:3\n#EXTINF:3.000,\nfileSequence0.ts\n#EXTINF:3.000,\nfileSequence1.ts\n#EXTINF:3.000,\nfileSequence2.ts\n#EXTINF:3.999,\nfileSequence3.ts\n#EXT-X-ENDLIST'
    manifest_url = 'https://example.com/manifest.m3u8'

# Generated at 2022-06-12 16:50:41.769849
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    print('==================== Testing method real_download of class HlsFD ====================')
    ydl = pytest.importorskip('youtube_dl. YoutubeDL')
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    from .fragments import _run_generic_test
    _run_generic_test(ydl, HlsFD)
# End of unit test for method real_download of class HlsFD

# Generated at 2022-06-12 16:50:44.957886
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hlsfd = HlsFD(None, {
        'test': True,
        'outtmpl': '%(id)s'
    })
    assert hlsfd.params['test']
    assert hlsfd.ydl is None
    assert hlsfd.FD_NAME == 'hlsnative'

# Generated at 2022-06-12 16:50:46.183230
# Unit test for constructor of class HlsFD
def test_HlsFD():
    return HlsFD('http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-12 16:51:09.017550
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .extractor import get_info_extractor
    from ..utils import unified_strdate


# Generated at 2022-06-12 16:51:22.512987
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_parse_urlencode
    from .extractor.common import InfoExtractor
    from .compat import (
        compat_urllib_parse_unquote,
        compat_urllib_parse_unquote_plus,
    )

    old_http_scheme_re = InfoExtractor._VALID_URL_SCHEMES_RE
    old_sanitized_Request = InfoExtractor._sanitized_Request
    def setUp():
        InfoExtractor._VALID_URL_SCHEMES_RE = re.compile(r'^(?:https?|mms|rtsp)$')
        InfoExtractor._sanitized_Request = lambda self, url: True

# Generated at 2022-06-12 16:51:25.153542
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .tests import get_test_file_url
    url = get_test_file_url('hls_frag_aes128.m3u8')
    fd = HlsFD(None, {'test': True})
    _, info_dict = fd._extract_info(url)
    assert fd.real_download(None, info_dict)


# Generated at 2022-06-12 16:51:34.222413
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    test_url = 'http://example.com/media.m3u8'
    ie = InfoExtractor(None, {})
    ie.params = {'hls_prefer_native': False}
    fd = HlsFD(ie, ie.params)
    # Force ffmpeg
    assert not fd.can_download('', {'url': test_url})
    ie.params['hls_prefer_native'] = True
    fd = HlsFD(ie, ie.params)
    assert fd.can_download('', {'url': test_url})

# Generated at 2022-06-12 16:51:48.156897
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    def get_m3u8(name):
        return os.path.join(os.path.dirname(os.path.realpath(__file__)), name)

    def can_download_playlist(playlist):
        # Since we don't have an info_dict, we need to pass in one here,
        # we can use empty dictionaries since they are not used
        # so long as is_live is set to false
        return HlsFD.can_download(
            open(get_m3u8(playlist)).read(),
            {
                "http_headers": '',
                "http_cookies": '',
                "is_live": False,
            })


# Generated at 2022-06-12 16:51:55.131334
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.__name__ == 'HlsFD'
    assert HlsFD.__module__ == 'youtube_dl.downloader.hls'
    assert HlsFD.FD_NAME == 'hlsnative'
    assert HlsFD.can_download.__name__ == 'can_download'
    assert HlsFD.can_download.__module__ == 'youtube_dl.downloader.hls'
    assert HlsFD.real_download.__name__ == 'real_download'
    assert HlsFD.real_download.__module__ == 'youtube_dl.downloader.hls'

# Unit test to check if can_download callable is returning the right values

# Generated at 2022-06-12 16:51:55.701627
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass

# Generated at 2022-06-12 16:52:07.653233
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-12 16:52:19.472894
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    import tempfile
    import os
    import shutil
    import requests

    # Create test files
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 16:52:27.097695
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import tempfile
    import os
    import shutil
    from .external import ExternalFD
    from .external import ExternalPD
    from .fragment import FragmentFD
    from .external import FFmpegFD
    from . import YoutubeDL
    from .utils import encodeFilename
    from .postprocessor import run_postprocessors
    from .cache import Cache

    ydl = YoutubeDL({
        'quiet': True,
        'logger': YoutubeDL.null_logger(),
        'nooverwrites': True })
    ydl.add_default_info_extractors()
    ydl._setup_opener()

    tmp_dir = tempfile.mkdtemp()

    # Test HlsFD with m3u8 playlist and known URL

# Generated at 2022-06-12 16:52:56.365151
# Unit test for constructor of class HlsFD
def test_HlsFD():
    fd = HlsFD({'params': {}})
    assert isinstance(fd, FragmentFD)
    fd = HlsFD({'params': {'test': True}})
    assert isinstance(fd, FragmentFD)
    assert fd.params['test'] is True

# Generated at 2022-06-12 16:53:08.656093
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import re
    import sys
    import tempfile
    import urllib.error
    import urllib.request

    def Fake_urlopen(url, **kwargs):
        class FakeURLOpen(object):
            def __init__(self, url):
                self.url = url
            def __enter__(self):
                if re.match(r'^https?://', self.url):
                    self.content = urllib.request.urlopen(self.url).read()
                else:
                    self.content = b'init.mp4'
                    if self.url.endswith('adkey.bin'):
                        self.content = b'ad_enc_key'
                return self
            def __exit__(self, *args):
                pass

# Generated at 2022-06-12 16:53:20.601670
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    from .utils import verify_true
    from ydl.utils import FakeYDL
    from ydl.downloader.external import ExternalFD
    from ydl.extractor.common import InfoExtractor

    # Run the unit test for HlsFD
    HlsFD_real_download = HlsFD.real_download  # function for the unit test
    def HlsFD_real_download_unit_test(self, filename, info_dict):
        # set the test-specific values
        info_dict.setdefault('test', True)
        info_dict.setdefault('extra_param_to_segment_url', 'some_extra_param')
        info_dict.setdefault('_decryption_key_url', 'some_key_url')
        # setup FakeYDL
        info_dict_ydl = {}


# Generated at 2022-06-12 16:53:31.562761
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-12 16:53:39.224999
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.params = {}
    ydl._hook_manager = {}

    url = 'http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8'
    urlh = ydl.urlopen(url)
    manifest = urlh.read().decode('utf-8', 'ignore')

    hlsfd = HlsFD(ydl, ydl.params)
    assert hlsfd.can_download(manifest, {})

    url = 'http://devimages.apple.com/iphone/samples/bipbop/gear4/prog_index.m3u8'
    urlh = ydl.urlopen(url)
    manifest = urlh.read

# Generated at 2022-06-12 16:53:51.298376
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import local_tempfile as lt
    import io_utils
    import filecmp
    import itertools

    io_utils.set_stream_logger()  # For debugging test

    def check_downloaded_data(fd, test_filename):
        assert fd.real_download(lt.get_temp_filename(), {'url': "http://test"})
        assert filecmp.cmp(lt.get_temp_filename(), test_filename)

    # For generating a test m3u8 file to be used in this test
    # Have to be able to set the DYLD_LIBRARY_PATH for HLSDownloader to use openssl
    # Have to comment out the EXT-X-BYTERANGE lines in the test file before running
    # HLSDownloader to get it to generate an m3u8
    # HLSDownload

# Generated at 2022-06-12 16:53:59.940281
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert HlsFD.real_download(
        {
            'url': 'https://www.example.com',
            'http_headers': {},
        }, 'file.mp4') == False
    assert HlsFD.real_download(
        {
            'url': 'https://www.example.com',
            'http_headers': {},
            'is_live': False,
        }, 'file.mp4') == True

# Generated at 2022-06-12 16:54:05.030430
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys

# Generated at 2022-06-12 16:54:07.310015
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """ HlsFD constructor test """
    HlsFD(None)

# Generated at 2022-06-12 16:54:14.281110
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import tempfile
    info_dict = {'url': 'http://example.com/index.m3u8', '_decryption_key_url': None, 'http_headers': {}, 'is_live': False}
    ctx = {'filename': tempfile.TemporaryFile()}
    hls = HlsFD(None, {})
    hls._prepare_and_start_frag_download(ctx)
    hls._append_fragment(ctx, b'hello, world!')
    hls._finish_frag_download(ctx)

# Generated at 2022-06-12 16:55:28.705408
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DownloadError

    ydl = YoutubeDL(params={'skip_download': True})

    class MyHlsFD(HlsFD):
        def __init__(self, ydl, params):
            super(MyHlsFD, self).__init__(ydl, params)
            self.fragment_index = 0
            self.frag_content = None

        def _prepare_and_start_frag_download(self, ctx):
            assert ctx['total_frags'] == 2
            assert ctx['ad_frags'] == 0
            return super(MyHlsFD, self)._prepare_and_start_frag_download(ctx)


# Generated at 2022-06-12 16:55:32.451609
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD("https://www.youtube.com/watch?v=--5lFAf6zdA")

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:55:35.071401
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hlsFD = HlsFD(object, object)
    assert hlsFD.FD_NAME == "hlsnative"


# Generated at 2022-06-12 16:55:44.502292
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    import tempfile
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    import youtube_dl.YoutubeDL
    class TestInfoExtractor(InfoExtractor):
        IE_NAME = 'Test'
        def __init__(self, ie_urls):
            InfoExtractor.__init__(self)
            self._ie_urls = ie_urls
        def extract(self, url):
            return {
                '_type': 'url_transparent',
                'url': self._ie_urls[url],
            }
        @staticmethod
        def suitable(url):
            return url in TestInfoExtractor._IE_URLS

# Generated at 2022-06-12 16:55:54.986411
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    import os

    test_dir = os.path.dirname(os.path.abspath(__file__))

    ie = InfoExtractor()
    ie.add_info_extractor(YoutubeIE)

    video = ie.extract('https://www.youtube.com/watch?v=N_ZvG8WJ5Uo')


# Generated at 2022-06-12 16:55:57.765198
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ydl = YoutubeDL({})
    hls = HlsFD(ydl, {'skip_unavailable_fragments': True})
    assert hls.params['skip_unavailable_fragments']

# Generated at 2022-06-12 16:56:05.537629
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from .http import HttpFD
    from .rtmp import RtmpFD

    # basic test
    ie = InfoExtractor(None, {})
    ie.add_info_extractor(RtmpFD.ie_key())
    ie.add_info_extractor(HttpFD.ie_key())
    ie.add_info_extractor(HlsFD.ie_key())

    formats = ie.extract('http://www.example.com/test/manifest.m3u8', {})['formats']
    # There should be 2 fmt groups with 2 formats each
    assert len(formats) == 2

    formats = ie.extract('http://www.example.com/test/manifest-3.m3u8', {})['formats']
    # There should

# Generated at 2022-06-12 16:56:15.657729
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import determine_ext
    class FakeYDL(object):
        def __init__(self, *args, **kwargs):
            self.tmpfilename = kwargs.get('tmpfilename')

        @staticmethod
        def urlopen(*args, **kwargs):
            import io

# Generated at 2022-06-12 16:56:22.884613
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import shutil
    from .test import get_testdata_files_dir
    from .extractor import get_info_extractor

    try:
        shutil.rmtree('hlsnative_test')
    except OSError:
        pass

# Generated at 2022-06-12 16:56:32.773250
# Unit test for constructor of class HlsFD
def test_HlsFD():
    h = HlsFD({}, None)
    assert_equal(h.can_download('#EXTM3U\n\n', {}), True)
    assert_equal(h.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:7\n', {}), True)
    assert_equal(h.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\n', {}), False)
    assert_equal(h.can_download('#EXTM3U\n#EXT-X-BYTERANGE:960228@18446744073709551615\n', {}), False)
    assert_equal(h.can_download('#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:9\n', {}), False)