

# Generated at 2022-06-12 16:49:17.315060
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def can_download(input_manifest, input_info_dict, expected_result):
        class FakeYDL:
            def __init__(self):
                self.params = {'quiet': True}
        ydl = FakeYDL()
        assert HlsFD(ydl, ydl.params).can_download(input_manifest, input_info_dict) == expected_result

    can_download('#EXTM3U', {}, True)
    can_download('#EXTM3U\n#EXT-X-KEY:METHOD=NONE', {}, True)
    can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {}, True)

# Generated at 2022-06-12 16:49:22.289440
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.generic import GenericIE
    from ..utils import ExtractorError, determine_ext

    ytdl = YoutubeDL()
    ie = GenericIE(ytdl)
    hls_fd = HlsFD(ytdl, ie, 'test_url', 'test_filename.mp4')

    if hls_fd.test() != True:
        raise ExtractorError

    file_url = 'https://dr4.cdn.asset.aparat.com/aparat-video/ab8c31bcf7c295f0a37d0f2c907e13bf16640956-480p__76979.mp4'

# Generated at 2022-06-12 16:49:35.801019
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import pytest
    from .http import HttpFD
    from .dash import DashSegmentsFD
    from .f4m import F4mFD
    from .flv import FlvFD

    # This is basically a copy of youtube_dl/downloader/common.py:test_download()
    # but using HlsFD instead of the base class FragmentFD.
    #
    # For test_HlsFD_real_download to actually use HlsFD, the basics.py file
    # which is imported by common.py has to be patched before it is imported
    # (see the comments at the end of this file).

    # This test only exercises the real_download method of HlsFD.
    # For a more extensive unit test use
    #
    #     youtube-dl --match-filter 'hlsnative and not is_

# Generated at 2022-06-12 16:49:46.799970
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    with open('t/data/hls.m3u8', 'rt') as f:
        man_str = f.read()

    class FakeInfoDict:
        pass

    info_dict = FakeInfoDict()
    info_dict.url = 'https://example.com/vod.m3u8'
    info_dict.http_headers = {}

    hls = HlsFD(None, {'test': True})
    assert hls.can_download(man_str, info_dict), 'can_download should return True'
    assert hls.real_download('test.mp4', info_dict), 'real_download should return True'

# Generated at 2022-06-12 16:49:57.426350
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import unittest
    from .test_utils import FakeYDL
    from .compat import mock
    from .common import FakeFD

    class HlsFDTestCase(unittest.TestCase):
        def setUp(self):
            self.temp_file = 'HlsFDTestCase'
            self.temp_files = [self.temp_file]
            self.filename = os.path.join(os.getcwd(), self.temp_file)
            self.ydl_opts = {
                'noprogress': True,
                'quiet': True,
                'simulate': True,
                'skip_download': True,
                'outtmpl': self.filename,
            }

# Generated at 2022-06-12 16:50:04.986632
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-12 16:50:12.994625
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hlsfd = HlsFD(None)
    assert hlsfd.can_download('#EXTM3U', {}) == True
    assert hlsfd.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=NONE', {}) == True
    assert hlsfd.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {'_decryption_key_url': 'http://example.com'}) == True
    assert hlsfd.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {}) == False
    assert hlsfd.can_download('#EXTM3U\n#EXT-X-BYTERANGE', {}) == False

# Generated at 2022-06-12 16:50:18.156901
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import tempfile
    from .testcommon import file_size, gettestdata, compare_file_data

    testdata = gettestdata('HlsFD/test.m3u8')
    with tempfile.NamedTemporaryFile() as outfd:
        HlsFD({'test': True}, {'params': {'outtmpl': outfd.name}}).real_download(
            outfd.name, {'url': testdata, 'is_live': False})

        compare_file_data(outfd.name, gettestdata('HlsFD/test.ts'))

# Generated at 2022-06-12 16:50:20.064911
# Unit test for constructor of class HlsFD
def test_HlsFD():
    fd = HlsFD(None, {})
    assert fd.FD_NAME == 'hlsnative'


# Generated at 2022-06-12 16:50:33.311268
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert issubclass(HlsFD, FragmentFD)
    hls_fd = HlsFD({}, {'url': 'http://example.com/playlist.m3u8'})
    assert hls_fd.ydl is not None, 'The input parameter was not assigned to the instance element ydl'
    assert hls_fd.params is not None, 'The input parameter was not assigned to the instance element params'
    assert isinstance(hls_fd._progress_hooks, list), 'The instance element _progress_hooks is not a list'
    assert not hls_fd._progress_hooks, 'The instance element _progress_hooks is not empty'

# Generated at 2022-06-12 16:50:55.478858
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import FakeYoutubeDL

    ydl = FakeYoutubeDL()
    fd = HlsFD(ydl, {})
    url = 'https://example.com/sample.m3u8'
    fd.real_download('sample.ts', {
        'url': url,
        'http_headers': {'User-Agent': 'Test'},
        'test': True,
    })
    assert ydl.urlopen_calls == [
        ('GET', url, {'User-Agent': 'Test'}),
        ('GET', 'https://example.com/2.ts', {'User-Agent': 'Test'}),
    ]

# Generated at 2022-06-12 16:51:02.914876
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass


if __name__ == '__main__':
    from . import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(HlsFD(ydl))
    ydl.download(['https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_16x9/bipbop_16x9_variant.m3u8'])

# Generated at 2022-06-12 16:51:05.314152
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert(HlsFD.FD_NAME == 'hlsnative')
    hlsfd = HlsFD(None)
    assert(hlsfd.fd_name == 'hlsnative')

# Generated at 2022-06-12 16:51:17.422412
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    from ..downloader.common import FileDownloader
    from .external import FFmpegFD
    from .dash import make_minimal_dash_manifest
    import os
    import tempfile
    import shutil
    import atexit
    from subprocess import call

    # create a temporary directory and make it the current directory
    tmp_path = tempfile.mkdtemp()
    os.chdir(tmp_path)

    # register a clean-up function
    def delete_tmp_path():
        shutil.rmtree(tmp_path)

    atexit.register(delete_tmp_path)

    # create a minimal DASH manifest
    mpd_url = make_minimal_dash_manifest(0, False)

    # create

# Generated at 2022-06-12 16:51:30.531982
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import io
    import unittest
    import youtube_dl.YoutubeDL
    class MockInfoDict:
        def __init__(self, url, is_live):
            self.get = lambda k: None
            self.is_live = is_live
            self.url = url

# Generated at 2022-06-12 16:51:37.824338
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeDL
    from .fragment import FragmentFD

    ydl = YoutubeDL()

# Generated at 2022-06-12 16:51:50.705281
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import common
    from ..compat import compat_HTTPError
    from .common import FakeYDL
    from .test_fragment import FakeHttpResponse

    class FakeUrlOpen:
        def __init__(self, real_url_open):
            self.real_url_open = real_url_open
            self.info = {
                'EXTM3U': 'EXTM3U',
                'EXT-X-KEY': 'METHOD="NONE"',
                'EXTINF': 'DURATION',
                'FRAGMENT_URI': 'FRAGMENT_URI',
            }

# Generated at 2022-06-12 16:51:57.213258
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .tests.test_downloader import FakeYDL, FakeInfoDict, MatchAnything, MatchAnythingWithAttrs
    import os
    import mock
    import tempfile

    abort_exception = compat_urllib_error.HTTPError(
        'http://example.com', 404, '', {}, None)

    def _download_fragment_side_effect(ctx, url, info_dict, headers):
        if url == 'http://example.com/frag_bad':
            raise abort_exception
        elif url == 'http://example.com/frag_timeout':
            raise compat_urllib_error.URLError('timed out')
        elif 'Range' in headers:
            return True, b'ad'
        else:
            return True, b'content'

    ydl = Fake

# Generated at 2022-06-12 16:52:08.859423
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .smild import SmilFD
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1280000\nhttp://example.com/video.m3u8\n', {'url': 'http://example.com/video.m3u8'}), 'non-live and unencrypted single-caster HLS stream'
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1280000\nhttp://example.com/video.m3u8\n', {'url': 'http://example.com/video.m3u8', 'is_live': True}), 'live and unencrypted single-caster HLS stream'
    assert SmilFD.can_download

# Generated at 2022-06-12 16:52:15.845744
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import os.path
    import shutil
    import tempfile
    import youtube_dl.utils
    import youtube_dl.extractor.common

    class HlsFdTest(unittest.TestCase):
        def test_HlsFD(self):
            (fd, filename) = tempfile.mkstemp()
            hls_fd = HlsFD(YouTubeDL({'hls_prefer_native': True}), {
                'fragment_retries': 0,
                'skip_unavailable_fragments': True,
            })

            test_url = youtube_dl.utils.urljoin(
                'https://example.org', 'test.mp4')

# Generated at 2022-06-12 16:52:55.136014
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import ydl
    ydl.params['continuedl'] = False
    ydl.params['test'] = True
    ydl.params['quiet'] = True
    ydl.params['skip_download'] = True


# Generated at 2022-06-12 16:52:59.838348
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({})
    fd = HlsFD(ydl, {})

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:53:09.128484
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .utils import FakeYDL
    from .downloader import YoutubeDL
    from .extractor import get_info_extractor
    from .extractor.common import InfoExtractor
    from .compat import (
        compat_urllib_parse_urlparse,
        compat_urlparse_urlparse,
    )

    ydl = YoutubeDL(FakeYDL({
        'skip_download': True,
        'quiet': True,
        'format': '137+140',
        'simulate': True,
    }))

    # Get an extractor to test
    ie = get_info_extractor('youtube')
    # Remove downloader before running the test
    ie._downloader = None

    # Set an HLS URL
    ie._downloader = ie._determine_ie()

# Generated at 2022-06-12 16:53:21.270196
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Test some basic functionality of the class
    manifest = """
#EXTM3U
#EXT-X-MEDIA-SEQUENCE:0
#EXT-X-TARGETDURATION:10
#EXTINF:10,
http://media.example.com/first.ts
#EXTINF:10,
http://media.example.com/second.ts
#EXT-X-ENDLIST
"""
    # A HlsFD object shall be created correctly
    hlsfd = HlsFD()
    # property FD_NAME shall be correctly set
    assert hlsfd.FD_NAME == "hlsnative"
    # property params shall be correctly set
    assert isinstance(hlsfd.params, dict)
    # The function "can_download" shall return True

# Generated at 2022-06-12 16:53:26.097016
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .extractor.test_common import test_can_download
    # Explicitly pass HlsFD functionality tests, since it's a builtin extractor
    test_can_download(HlsFD, ['HlsFD'])

if __name__ == '__main__':
    test_HlsFD_can_download()

# Generated at 2022-06-12 16:53:35.797632
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import json
    import os
    import sys
    from urllib.parse import urlparse
    from tempfile import mkdtemp
    from contextlib import contextmanager

    class NullYDL(object):
        class MockOpener(object):
            def __init__(self, urlh):
                self.urlh = urlh

            def open(self, url, data=None, timeout=None):
                return self.urlh

            def read(self):
                return self.urlh.read()

        def __init__(self):
            self.urlopen = self.retrieve = self.MockOpener

        def to_screen(self, msg):
            sys.stderr.write(msg + '\n')

        def prepare_filename(self, info_dict):
            return info_dict['id']


# Generated at 2022-06-12 16:53:48.387926
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    def _make_HlsFD(filename, manifest, extra_params=None, is_live=False, test=False):
        """ Create an HlsFD object for testing """
        from .extractor import YoutubeIE
        from ..YoutubeDL import YoutubeDL
        from ..extractor.common import InfoExtractor
        from ..utils import encode_data_uri
        ydl = YoutubeDL({
            'outtmpl': filename,
            'continuedl': 'false',
            'quiet': 'true',
            'test': 'true' if test else 'false',
            'merge_output_format': 'mkv',
            'format': 'bestaudio/best',
            'simulate': 'true',
            'debug_printtraffic': 'true',
        })
        ydl.add_default_info_extractors()
        ie

# Generated at 2022-06-12 16:53:49.345274
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert False, "This function has not been implemented yet"

# Generated at 2022-06-12 16:53:54.187256
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """Unit test for constructor of class HlsFD"""
    from .ytdl_extractor import YoutubeDL
    ydl = YoutubeDL()
    with ydl:
        hlsfd = HlsFD(ydl, {'format': '450'})
        assert hlsfd.ydl == ydl
        assert hlsfd.params == {'format': '450'}

# Generated at 2022-06-12 16:54:01.639408
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import FileDownloader
    gen_extractors()
    url = "https://example.com"
    params = {'forceurl': True,
              'url': url,
              'usenetrc': False,
              'username': 'testusername',
              'password': 'testpassword',
              'quiet': True}
    test_downloader = FileDownloader(params)
    test_downloader.add_info_extractor(HlsFD)
    test_downloader.add_info_extractor(HlsFD)  # Should not be added twice
    def t(name, ie_key, ie):
        ie_match = ie_key == ie and 'SUCCESS: ' or 'FAILURE: '

# Generated at 2022-06-12 16:55:16.005786
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    import os
    import ydl_opts

# Generated at 2022-06-12 16:55:24.350827
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .http import HttpFD
    url = 'http://foo.com/out.m3u8'
    fd = HlsFD(ydl=HttpFD(use_proxy=False), params={'http_chunk_size': 100},
               url=url, info_dict={'url': url, 'http_headers': {'User-Agent': 'Dum'}})
    assert fd.ydl == HttpFD(use_proxy=False)
    assert fd.params == {'http_chunk_size': 100}
    assert fd.url == url
    assert fd.info_dict['http_headers']['User-Agent'] == 'Dum'

# Generated at 2022-06-12 16:55:25.344857
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD("", {})

# Generated at 2022-06-12 16:55:38.067749
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('', {})
    assert HlsFD.can_download('#EXTM3U', {})
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=NONE', {})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=FOOBAR', {})
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=NONE', {'is_live': False})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=NONE', {'is_live': True})

# Generated at 2022-06-12 16:55:46.386425
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .external import FFmpegFD
    from .external import UnknownFD
    from .external import Downloader
    from .external import YoutubeDL
    from .external import FileDownloader

    assert(HlsFD.can_download('', {'url': ''}))
    assert(HlsFD.can_download('#EXTM3U', {'url': ''}))
    assert(not HlsFD.can_download('#EXT-X-KEY:METHOD=foo', {'url': ''}))
    assert(HlsFD.can_download('#EXT-X-KEY:METHOD=NONE', {'url': ''}))
    assert(HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'url': ''}))

# Generated at 2022-06-12 16:55:56.366322
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..downloader import FileDownloader

    try:
        from .test_test_utils import (
            match_regex
        )
    except ImportError:
        from test_utils import (
            match_regex
        )


    class IEMock(InfoExtractor):

        def __init__(self, downloader=None):
            self._downloader = downloader

    ie = IEMock()
    ie._downloader = FileDownloader(params={'verbose': False, 'quiet': True})
    ie._downloader.add_info_extractor(ie)
    ie._downloader.to_screen = lambda *args, **kargs: None
    ie.add_info_extractor(ie)

# Generated at 2022-06-12 16:56:04.605932
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import shutil
    import tempfile

    from .test_utils import FakeYDL
    from ..utils import encodeFilename

    ydl = FakeYDL()
    hls_url = 'https://example.com/playlist.m3u8'
    output_filename = encodeFilename('%(playlist_title)s-%(id)s.%(ext)s')
    info_dict = {
        'url': hls_url,
        'title': 'example',
        'id': 'id',
        'ext': 'mp4',
        'http_headers': { 'User-Agent': 'Mozilla' }
    }
    hls_fd = HlsFD(ydl, {'outtmpl': output_filename})

# Generated at 2022-06-12 16:56:14.621284
# Unit test for constructor of class HlsFD
def test_HlsFD():
    class TestInfoDict:
        def __init__(self, url):
            self.url = url
    info_dict = TestInfoDict('https://test-url.com')

    class TestYDL:
        def __init__(self, url):
            self.url = url

        def urlopen(self, url):
            if self.url == url:
                return True
            return False

    class TestParams:
        def __init__(self, url):
            self.url = url

    class TestHlsFD:
        def __init__(self, url):
            self.url = url

        def can_download(self, manifest, info_dict):
            return self.url == info_dict.url

    ydl = TestYDL(info_dict)
    params = TestParams(info_dict)

# Generated at 2022-06-12 16:56:22.061472
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from youtube_dl.downloader import HlsFD

    base_url = 'http://foo.bar/'

    # Test 1
    man_url = base_url + 'master.m3u8'

# Generated at 2022-06-12 16:56:23.211691
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD