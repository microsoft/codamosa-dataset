

# Generated at 2022-06-12 16:49:29.882004
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import os
    import sys
    import tempfile
    from .downloader import YoutubeDL
    from .extractor import get_info_extractor
    from .utils import match_filter_func

    ie = get_info_extractor(
        'testvideo',
        {'url': 'http://localhost/testvideo.m3u8',
         'ie_key': 'HlsFD'})
    ydl = YoutubeDL({
        'outtmpl': '%(id)s.%(ext)s',
        'format': 'best',
        'nooverwrites': True,
        'quiet': True})
    file_descriptor, temp_file = tempfile.mkstemp()
    os.close(file_descriptor)
    sys.modules['__main__'].temp_file = temp_file
   

# Generated at 2022-06-12 16:49:31.738897
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:49:44.241615
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """
    HlsFD.real_download(str, str, str, str) -> bool
    Checks method real_download of class HlsFD by comparing output with expected output
    """
    import os
    import shutil
    import tempfile

    class FakeYDL(object):
        def __init__(self):
            self.tempdir = tempfile.mkdtemp()
            self.download_retcode = {0: 0, 1: 8}

        def prepare_filename(self, info_dict):
            filename = os.path.join(self.tempdir, 'test')


# Generated at 2022-06-12 16:49:55.498890
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os.path
    import tempfile
    import shutil
    assert can_decrypt_frag
    from .test import get_testdata_dir
    from .utils import (
        OnDemandPagedList,
    )
    from .fragment import (
        FragmentFD,
        FileDownloader,
    )
    from .external import (
        FFmpegFD,
    )
    from .subtitles import (
        SubtitlesFD,
    )

    SubtitlesFD._available = True
    FFmpegFD._available = True
    HlsFD._available = True


# Generated at 2022-06-12 16:50:03.804742
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import make_HTTPServer
    from ..extractor import YoutubeIE
    from ..compat import parse_qs

    # Create a server that returns the given content for every GET request
    server = make_HTTPServer({'content': 'This is a test'})

    # A dummy YouTube video ie
    youtube_ie = YoutubeIE({})

    # Dummy YouTube video info with HLS url and encryption info

# Generated at 2022-06-12 16:50:05.812509
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ydl = FakeYDL()
    params = {
        'test': True
    }
    fd = HlsFD(ydl, params)
    ok_(isinstance(fd, HlsFD))


# Generated at 2022-06-12 16:50:13.774545
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import test
    if not test.is_online():
        test.skip('skipping due to offline')


# Generated at 2022-06-12 16:50:23.185884
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import json
    import time
    from .downloader import YoutubeDL
    from .extractor import gen_extractors
    import tests.mockserver
    import tests.helper

    tests.mockserver.start(block=False)
    gen_extractors()


# Generated at 2022-06-12 16:50:35.685530
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    test_data = get_test_data()

    def _test(test_case, real_download_urls):
        """
        Test get_real_download_url method against test cases
        :param test_case: tuple of (url, expected_real_download_url, expected_result)
        :param real_download_urls: list of urls that the expected_real_download_url should be in
        """
        url, expected_real_download_url, expected_result = test_case
        ctx = {'info_dict': {'url': url}}
        fd = HlsFD(None, None)
        real_url = fd._prepare_url(ctx, url)
        assert real_url in real_download_urls
        assert fd.can_

# Generated at 2022-06-12 16:50:42.538640
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    ie = InfoExtractor()
    ie._downloader.params.update({
        'proxy': '127.0.0.1:8118',
        'noprogress': True,
    })
    fd = HlsFD(ie._downloader, {'format': '251', 'noprogress': True})
    # A successful result of the constructor is enough to pass the test
    fd

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:51:05.743742
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import copy
    import collections
    import re

    class FakeInfoDict(collections.namedtuple('FakeInfoDict', ('url', 'is_live', 'http_headers', '_decryption_key_url'))):
        pass

    def do_test(manifest: str, expected: bool, is_live: bool = False, url: str = 'http://foo.bar/baz.m3u8', extra_param_to_segment_url: str = None, _decryption_key_url: str = None) -> None:
        infodict = FakeInfoDict(url=url, is_live=is_live, http_headers=None, _decryption_key_url=_decryption_key_url)
        if extra_param_to_segment_url:
            infodict = infodict

# Generated at 2022-06-12 16:51:17.593320
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download(
        '#EXTM3U\n#EXTINF:2\nhttp://example.com/1\n#EXTINF:2\nhttp://example.com/2',
        {'url': 'http://example.com/'})
    assert not HlsFD.can_download(
        '#EXTM3U\n#EXT-X-PLAYLIST-TYPE:EVENT\n#EXTINF:2\nhttp://example.com/1\n#EXTINF:2\nhttp://example.com/2',
        {'url': 'http://example.com/'})

# Generated at 2022-06-12 16:51:23.375333
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\n'
                              'https://example.com/frag1.ts', {'url': 'http://example.com/index.m3u8'})

# Generated at 2022-06-12 16:51:34.099453
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    u'''
    Test real_download function
    '''
    from .common import create_test_result

    hlsFD = HlsFD({}, {'test': True})
    result = hlsFD.real_download(u'sample.mp4', {
        u'url': u'https://example.com/video/Manifest',
        u'abr': u'128kbps',
        u'format_id': u'hls',
        u'protocol': u'hls',
        u'vcodec': u'avc1.64001e',
        u'ext': u'mp4',
        'manifest_type': u'hls'
    })
    create_test_result(u'sample.mp4', result)


# Generated at 2022-06-12 16:51:39.251391
# Unit test for constructor of class HlsFD
def test_HlsFD():
    FD = HlsFD({}, 0, '')
    assert FD.FD_NAME == 'hlsnative'
    assert not FD.can_download(None, None)
    assert not FD.real_download(None, None)


# Generated at 2022-06-12 16:51:51.645374
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import YoutubeDL
    youtubeDL = YoutubeDL({'no_warnings': True, 'logger': YoutubeDL.std_logger})

    url = 'https://c.brightcove.com/services/mobile/streaming/index/master.m3u8?videoId=5821589514001'
    url += '&pubId=1091057125&secure=true'
    url += '&videoFullLengthId=5821595126001&token=null&range=0-10000'
    url += '&bckey=AQ~~,AAABq-s1sEU~,0OsZcx4w4CNITyYjYfhlr_v9GQS1B4RB&origin='
    url += 'http%3A%2F%2Fwww.abc.com'

    info

# Generated at 2022-06-12 16:52:04.471147
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    import tempfile
    import os
    url = 'https://www.youtube.com/watch?v=1dJhMthW8rU'
    destfile = tempfile.mkstemp()[1]
    yt = YoutubeIE()
    yt.extract(url)
    hls = HlsFD()
    # Set query_parameters to test that if test query_parameter still needs to be appended
    # to segment URLs for decryption keys
    yt.ydl.query_parameters = 'test'
    hls.params = {'test': True}
    hls.real_download(destfile, yt.ydl.extract_info(url, download=False))
    os.remove(destfile)

# Generated at 2022-06-12 16:52:11.936965
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    import tempfile
    with tempfile.NamedTemporaryFile() as tmp_file:
        ydl = YoutubeDL({'logger': False, 'progress_hooks': [], 'nooverwrites': True, 'continuedl': False, 'outtmpl': tmp_file.name})
        assert(HlsFD.can_download('', {'url': 'http://example.com/doesntmatter.m3u8'}))
        HlsFD(ydl, {}).real_download(tmp_file.name, {})

# Generated at 2022-06-12 16:52:17.458034
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from youtube_dl.extractor import get_info_extractor
    from youtube_dl.tests.testutils import FakeYDL


# Generated at 2022-06-12 16:52:26.023304
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.youtube import YoutubeIE
    from .common import FakeYdl
    from .fragment import FragmentFD
    from .dash import DASHIE


# Generated at 2022-06-12 16:52:54.838867
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    import shutil
    import os
    import tempfile
    import time

    # Create a HlsFD object with all its attributes
    ydl_obj = object()
    params = {'hls_use_ffmpeg': True}
    HlsFDobj = HlsFD(ydl_obj, params)

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a file (manifest) and copy a playlist (s) in it
    filename = os.path.join(temp_dir, 'manifest.mp4')
    fd = open(filename, 'w')

# Generated at 2022-06-12 16:53:03.387700
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    ie = InfoExtractor()
    ie.add_info_extractor('hls', HlsFD)
    info = ie._real_extract('hls', 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8')
    assert info['url'] == 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8'

# Generated at 2022-06-12 16:53:13.555425
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """ This method tests if real_download of class HlsFD works as expected """
    from .http import HttpFD
    from ..extractor.generic import GenericIE

    class FakeYDL:
        params = {}

        def __init__(self):
            self.ies = [GenericIE()]


# Generated at 2022-06-12 16:53:21.920786
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """ Test HlsFD constructor """
    class YDL(object):
        downloader_options_defs = []
        params = {}
        verbose = True
    ydl = YDL()
    ydl.params['test'] = True

    hlsfd = HlsFD(ydl, {})
    assert hlsfd.verbose == True

    hlsfd = HlsFD(ydl, {})
    assert hlsfd.test == True


# Generated at 2022-06-12 16:53:33.035072
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.youtube import YoutubeIE
    from .external import FFmpegFD
    from .fragment import AbstractFragmentFD
    from .dash import (
        DefaultDashStreamFD,
        UrlDashStreamFD,
    )

    assert not HlsFD.can_download(manifest=b'', info_dict={})

    # Non supported by HLSNative
    assert not HlsFD.can_download(
        manifest=b'#EXT-X-KEY:METHOD=SAMPLE-AES,URI="https://priv.example.com/key.php?r=52"',
        info_dict={})
    assert not HlsFD.can_download(
        manifest=b'#EXT-X-MEDIA-SEQUENCE:9999999999',
        info_dict={})
    assert not HlsFD.can_download

# Generated at 2022-06-12 16:53:38.838367
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Tests that the downloaded data matches the data in the manifest
    def _test_download(man_url, frag_urls, data, expected_frag_data):
        class FakeYdl(object):
            def prepare_url(self, url):
                return url

            def urlopen(self, url):
                for i in range(len(frag_urls)):
                    if url == frag_urls[i]:
                        return FakeUrlOpen(data[i])
                return FakeUrlOpen(man_url)

        class FakeLogger(object):
            def debug(self, msg):
                pass

            def warning(self, msg):
                print(msg)

            def error(self, msg):
                raise ValueError(msg)

        ydl = FakeYdl()

# Generated at 2022-06-12 16:53:50.891990
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os.path
    import shutil
    import tempfile
    from .test_download import download_dir_path

    url = 'http://example.org/playlist.m3u8'
    dest_dir = tempfile.mkdtemp()
    filename = os.path.join(download_dir_path, 'out.ts')
    info_dict = {
        'id': 'A',
        'url': url,
        'title': 'Minimal example',
        'ext': 'ts',
        'http_headers': {
            'X-Custom-Header': 'Example'
        },
        'format_id': 'HLS_1',
        'manifest_url': url,
    }

# Generated at 2022-06-12 16:53:52.862166
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert FFmpegFD is not None
    assert can_decrypt_frag is False

# Generated at 2022-06-12 16:54:00.071551
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    manifest_url = 'https://video-dev.github.io/streams/x36xhzz/x36xhzz.m3u8'
    temp_filename = 'test.mp4'
    downloader = create_downloader_for_test({
        'test': True,
        'skip_download': False,
        'quiet': True,
        'outtmpl': temp_filename,
    })
    info_dict = {
        'id': 'x36xhzz',
        'url': manifest_url,
    }
    dl = HlsFD(downloader, {})
    assert dl.real_download(temp_filename, info_dict)


# Generated at 2022-06-12 16:54:12.819524
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .http import HttpFD
    from .external import ExternalFD
    from ..downloader import MockYDL
    from ..extractor.common import InfoExtractor
    from ..utils import SearchInfoExtractor
    import tempfile
    class MockYDLHlsFD(MockYDL):
        def __init__(self):
            super(MockYDLHlsFD, self).__init__()
            self.content_length = 0
            self.test_mode = True
            self.cookies = {}
            self.filenames = {}

        def urlopen(self, url, timeout=None):
            if url.startswith('http://ad-url/'):
                content = '{"sequence": "ad"}'
            else:
                content = '{"sequence": "%s"}' % self._match_id(url)


# Generated at 2022-06-12 16:55:03.422190
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Given
    import os
    import json
    import tempfile
    import youtube_dl.utils
    from .test_download import (
        FakeYDL,
        MockHttpServer,
        MockTimeout,
        MockEncryptedVideo,
        fragments_count,
        fragments_size,
    )

    # Mock video fragments

# Generated at 2022-06-12 16:55:13.125833
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .external import ExternalFD
    # Create an instance of HlsFD
    HlsFD(ExternalFD(), {"youtube_include_dash_manifest": True})
    # Create an instance of HlsFD and check for an error in the constructor
    assert_raises(ValueError, HlsFD, ExternalFD(), {"youtube_include_dash_manifest": "Testing value"})
    # Create an instance of HlsFD and check for an error in the constructor
    assert_raises(ValueError, HlsFD, ExternalFD(), {"youtube_skip_dash_manifest": True})

# Generated at 2022-06-12 16:55:21.499165
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import FileDownloader
    from ..extractor.common import InfoExtractor
    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                '_type': 'url',
                'url': url,
                'is_live': False,
                'format_id': '139',
                'ext': 'm4a',
            }
    class FakeFFmpegFD(object):
        def real_download(self, filename, info_dict):
            return True
    class FakeAES(object):
        def new(self, key, mode, iv):
            return self
        def decrypt(self, frag_content):
            return frag_content.decode('utf-8-sig')

# Generated at 2022-06-12 16:55:28.912716
# Unit test for constructor of class HlsFD

# Generated at 2022-06-12 16:55:40.429837
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():

    def _test_download(manifest_filename, video_id, extra_params, expected_segment_urls):
        from .common import FakeYDL

        # Cleanup _download_fragment from previous invocation
        try:
            del HlsFD._download_fragment
        except AttributeError:
            pass

        class FakeHlsFD(HlsFD):
            _fragment_index = 0

            def _download_fragment(self, ctx, url, info_dict, headers):
                self._fragment_index += 1
                assert url == expected_segment_urls[self._fragment_index - 1]

# Generated at 2022-06-12 16:55:47.819842
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import shutil
    import tempfile
    import unittest

    # basic test cases of HlsFD.real_download
    # not using the YDL class to avoid having to load all the extractors
    # Can be run with:
    #   python -m youtube_dl.downloader.hls  # runs all test cases
    #   python -m youtube_dl.downloader.hls.HlsFD  # runs all test cases
    #   python -m youtube_dl.downloader.hls.HlsFD.test_HlsFD_real_download  # runs test_real_download_*


# Generated at 2022-06-12 16:55:53.450447
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Test that can_download returns True on correct manifest
    manifest = '#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXT-X-MEDIA-SEQUENCE:0\n'
    + '#EXTINF:10,\nhttps://example.com/video-001.ts\n'
    + '#EXTINF:10,\nhttps://example.com/video-002.ts\n'
    + '#EXT-X-ENDLIST\n'
    info_dict = {}
    assert HlsFD.can_download(manifest, info_dict)

    # Test that can_download returns False if the manifest is of live stream (EXT-X-MEDIA-SEQUENCE is not 0)

# Generated at 2022-06-12 16:55:54.554466
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, None)

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:56:04.748559
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        from Crypto.Cipher import AES
        can_decrypt_frag = True
    except ImportError:
        can_decrypt_frag = False

    hls_fd = HlsFD(None, None)
    assert hls_fd.can_download('', '') is True
    assert hls_fd.can_download(
        '#EXT-X-KEY:METHOD=AES-128', '') is can_decrypt_frag
    assert hls_fd.can_download(
        '#EXT-X-KEY:METHOD=AES-128', '') is not can_decrypt_frag
    assert hls_fd.can_download(
        '#EXT-X-KEY:METHOD=AES-128', '') is can_decrypt_frag
    assert hls_fd.can

# Generated at 2022-06-12 16:56:14.835329
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .external import ExternalFD
    from .dashsegments import (
        SegmentListFD,
        SegmentedFD,
        SegmentedDownloadError,
    )
    # Consider the following m3u8 file, which has the following properties:
    # 1. is not live (no "#EXT-X-MEDIA-SEQUENCE")
    # 2. is not encrypted ("#EXT-X-KEY" with method none)
    # 3. is not composed of byte ranges of media files ("#EXT-X-BYTERANGE")
    # 4. does not have segments appended to it ("#EXT-X-PLAYLIST-TYPE:EVENT")
    # 5. does not have an initializing fragment ("#EXT-X-MAP")
    # 6. has live attribute ("#EXT-X-PLAYLIST-TYPE:EVENT")
    m3u

# Generated at 2022-06-12 16:58:01.606925
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import fake_server, get_testcases
    from ..utils import _post_video_info_request
    config_dict = {
        'test': True,
        'socket_timeout': 60,
        'writeinfojson': True,
        'writesubtitles': True,
        'writeautomaticsub': True,
        'subtitlesformat': 'ttml',
        'writethumbnail': True,
        'youtube_include_dash_manifest': False,
        'skip_download': True,
        'min_views': 0,
        'simulate': True,
        'no_warnings': True,
    }
    urls, videos = get_testcases()

    for video in videos:
        (serv, port) = fake_server(video)
        if not serv:
            continue
       

# Generated at 2022-06-12 16:58:11.501047
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import YoutubeDL
    ydl = YoutubeDL({})

    # test the result of can_download
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXT-X-VERSION:3', {'is_live': True}) == False
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXT-X-VERSION:3', {'is_live': False}) == True
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXT-X-VERSION:3\n#EXT-X-KEY:METHOD=NONE', {'is_live': False}) == True
    assert HlsFD

# Generated at 2022-06-12 16:58:21.597014
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.http import USER_AGENT

# Generated at 2022-06-12 16:58:33.654419
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os

    class HlsFD_Mock(HlsFD):
        # Unit test requires a separate class because we
        # need to override _download_fragment method

        def __init__(self, ydl):
            super(HlsFD.__class__, self).__init__(ydl, {})

            dir_path = os.path.dirname(os.path.realpath(__file__))

            self.man_url = 'https://pythonserver/hls/index.m3u8'
            self.manifest_content = open(os.path.join(
                dir_path, 'm3u8', 'test_HlsFD_real_download.m3u8'), 'rb').read().decode('utf-8')


# Generated at 2022-06-12 16:58:34.925471
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD()


# Generated at 2022-06-12 16:58:43.321519
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    import mock
    import pytest
    from youtube_dl.FetchKen import FetchKen

    fk = FetchKen()
    fk.parseManifest(sys.argv[1])

    ydl_mock = mock.MagicMock()
    ydl_mock.urlopen.return_value.read.return_value = fk.manifestText
    ydl_mock.urlopen.return_value.geturl.return_value = 'https://example.com/manifest'

    hfd = HlsFD(ydl_mock, {})
    with pytest.raises(NotImplementedError):
        hfd.real_download('a.mp4', fk.manifest)

# Generated at 2022-06-12 16:58:54.320593
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import FakeYDL
    from .extractor import _hls_get_fragment_retries
    from .extractor import _hls_get_skip_unavailable_fragments
    from .extractor import _default_fragment_retries
    from .extractor import _default_skip_unavailable_fragments
    from .extractor import _NO_DEFAULT

    # set test_urls for HlsFD.can_download method