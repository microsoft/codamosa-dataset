

# Generated at 2022-06-12 16:49:23.035148
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import make_HTTPServer, FakeYDL
    from ..extractor.common import InfoExtractor
    from ..compat import parse_qs


# Generated at 2022-06-12 16:49:33.964068
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE

    ydl = InfoExtractor()
    url = 'https://vimeo.com/66626050'
    ie = GenericIE._html_search_meta(ydl, 'video', url, default=None)
    info = ie.extract(url)
    assert info['formats'][0]['format_id'] == 'hls-174'
    fd = HlsFD(ydl, {})
    fd.real_download('./dummy.mp4', info)


# Generated at 2022-06-12 16:49:46.992588
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import sys
    import tempfile

    import pytest

    try:
        import youtube_dl.extractor.common
        youtube_dl_exists = True
    except ImportError:
        youtube_dl_exists = False

    if youtube_dl_exists:
        from youtube_dl.extractor.common import ExtractorError

        import youtube_dl.downloader.F4MFD
        import youtube_dl.downloader.fragment
        import youtube_dl.downloader.http
        import youtube_dl.utils

        test_url = 'http://example.com/index.m3u8'


# Generated at 2022-06-12 16:49:57.552029
# Unit test for constructor of class HlsFD

# Generated at 2022-06-12 16:50:05.077410
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import encode_data_uri
    from ..extractor import gen_extractors
    from ..compat import compat_etree_fromstring
    from ..compat import compat_oyaml as yaml

    url = 'https://www.youtube.com/watch?v=18nwTTFL7Hg'

# Generated at 2022-06-12 16:50:13.069459
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.youtube import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..utils import prepend_extension

    ydl = FileDownloader({'outtmpl': '%(id)s%(ext)s'})

# Generated at 2022-06-12 16:50:21.222327
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .tests import get_test_data
    from ..downloader import YoutubeDL
    import os

    # setup

# Generated at 2022-06-12 16:50:34.070647
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import mock_http_server_downloader_factory
    from .http import HttpFD

    # HLS test case 1
    dl = mock_http_server_downloader_factory(HlsFD)

# Generated at 2022-06-12 16:50:43.938680
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..downloader import Downloader
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    downloader = Downloader(params={})
    ie = gen_extractors(downloader)
    for i in ie:
        if i.IE_NAME == 'hlsnative':
            HlsFD(downloader, {'ydl_params': {}})
            break
    # test can_download method
    for i in ie:
        if i.IE_NAME == 'hlsnative':
            if not match_filter_func(i.IE_NAME, ['hlsnative']):
                continue

# Generated at 2022-06-12 16:50:53.477836
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import FakeYDL
    from .test_test import _prepare_test
    from .test_file import _prepare_file_test

    # Test for HLSNativeFD with native support for AES-128 encryption
    ydl = FakeYDL()
    # Download a single fragment for testing only
    ydl.params['test'] = True
    info_dict = {
        'url': 'http://example.com/hls-playlist.m3u8',
        'playlist_id': 'hls-playlist',
        '_decryption_key_url': 'https://example.com/decryption_key.bin',
        'http_headers': {},
    }

# Generated at 2022-06-12 16:51:17.479467
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import simplified_scraper_test
    help(HlsFD)
    help(InfoExtractor)
    help(InfoExtractor._download_webpage)
    help(simplified_scraper_test)
    help(simplified_scraper_test())
    if HlsFD.can_download('#EXTM3U\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=5000000\n'
        + 'http://devimages.apple.com/iphone/samples/bipbop/gear1/'
        + 'prog_index.m3u8\n', dict(url='url')):
        return True
    else:
        return False


# Generated at 2022-06-12 16:51:20.277793
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .testcases import TestCase
    with TestCase() as testcase:
        testcase.test_HlsFD()

# Generated at 2022-06-12 16:51:32.213511
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import io
    import tempfile
    import os

    def _get_output_path():
        fd, output_path = tempfile.mkstemp()
        os.close(fd)
        os.unlink(output_path)
        return output_path


# Generated at 2022-06-12 16:51:38.827252
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import YoutubeDL
    ydl = YoutubeDL()
    yd = HlsFD(ydl, {})
    info_dict = {}

# Generated at 2022-06-12 16:51:40.685851
# Unit test for constructor of class HlsFD
def test_HlsFD():
    return HlsFD

__all__ = ['HlsFD']

# Generated at 2022-06-12 16:51:52.660100
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import shutil
    import tempfile

    from ytdl.YoutubeDL import YoutubeDL
    import abstract_tests as base

    class my_YoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            self.test_data = kwargs.pop('test_data')
            self.test_media_sequence = kwargs.pop('test_media_sequence')
            super(my_YoutubeDL, self).__init__(*args, **kwargs)

        def urlopen(self, url):
            if url.startswith('http://www.example.com/man.m3u8'):
                return base.FakeUrlOpen(self.test_data['manifest'])

# Generated at 2022-06-12 16:52:05.294202
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import sys
    import os
    import tempfile
    from subprocess import check_call, CalledProcessError
    from ..utils import sanitize_open
    if (hasattr(sys, 'getwindowsversion')
            and sys.getwindowsversion()[:2] >= (6, 0)):  # Vista or later
        try:
            check_call(['reg', 'add', 'HKEY_CURRENT_USER\\SOFTWARE\\Wow6432Node\\youtube-dl\\test', '/v', 'wow_mode', '/t', 'REG_DWORD', '/d', '0', '/f'])
        except (OSError, CalledProcessError):
            raise unittest.SkipTest('reg is not available')
    from ..postprocessor.ffmpeg import FFmpegPostProcessor
    from ..extractor import gen_extract

# Generated at 2022-06-12 16:52:15.348888
# Unit test for constructor of class HlsFD
def test_HlsFD():
    manifest_url = 'http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8'
    info_dict = {
        'id': '1',
        'url': manifest_url,
        'ext': 'mp4',
        'title': 'test',
        '_type': 'hls',
        'http_headers': {
            'Cookie': 'key=value'
        }
    }
    fd = HlsFD(None, {'test': True})
    assert not fd.can_download(None, None)
    assert not fd.can_download('#EXT-X-KEY:METHOD=INVALID', None)

# Generated at 2022-06-12 16:52:18.187441
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert can_decrypt_frag is True

# Generated at 2022-06-12 16:52:19.118577
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD('', {})

# Generated at 2022-06-12 16:52:42.327052
# Unit test for constructor of class HlsFD
def test_HlsFD():

    def fake_http_open(self, url, data=None, retries=None):
        return urlopen.URLopener.open(self, url, data)

    old_urlopener_open = urlopen.URLopener.open
    old_real_download = HlsFD.real_download
    urlopen.URLopener.open = fake_http_open  # Overwrite the open function
    HlsFD.real_download = HlsFD.bigbuckbunny_real_download  # Use the real_download function from big buck bunny

    # Get the HlsFD object from the big buck bunny video
    ydl = FakeYdl({'noprogress': True,
                   'format': 'bestvideo+bestaudio/best',
                   'test': True})

# Generated at 2022-06-12 16:52:47.617591
# Unit test for constructor of class HlsFD
def test_HlsFD():
    if not can_decrypt_frag:
        print('WARNING: pycrypto not found. Skip decryption tests.')
    unencrypted_master_url = 'https://www.example.com/unencrypted/prog_index.m3u8'

# Generated at 2022-06-12 16:52:49.342690
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    file = open('C:/Users/andre/Documents/Programming/youtube-dl/py.txt','w') 
    file.write('HlsFD_real_download') 
    file.close() 



# Generated at 2022-06-12 16:52:59.557188
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    rv = HlsFD.can_download

    UNSUPPORTED_FEATURES = (
        '#EXT-X-KEY:METHOD=AES-128',
        '#EXT-X-BYTERANGE',
        '#EXT-X-MEDIA-SEQUENCE:1',
        '#EXT-X-PLAYLIST-TYPE:EVENT',
        '#EXT-X-MAP:',
    )
    # known unsupported
    for feature in UNSUPPORTED_FEATURES:
        assert not rv('\n'.join([feature]), {})
    # known supported
    assert rv('#EXTM3U\n#EXT-X-VERSION:3\n#EXTINF:8,\nfoo.mp4', {})
    assert not rv('\n'.join(UNSUPPORTED_FEATURES), {})



# Generated at 2022-06-12 16:53:10.826606
# Unit test for constructor of class HlsFD
def test_HlsFD():
    params = {
        'noprogress': True,
        'skip_download': True,
        'simulate': True,
        'quiet': True,
        'forcetitle': True,
        'forceurl': True,
        'forcethumbnail': True,
        'forcedescription': True,
        'forcefilename': True,
        'forcejson': True,
        'dump_single_json': True,
        'outtmpl': True,
        'ignoreerrors': True,
        'skip_unavailable_fragments': True,
        'keep_fragments': True,
        'fragment_retries': 0,
        'test': True,
    }
    ydl = FakeYdl(params)

# Generated at 2022-06-12 16:53:17.809399
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    from ..extractor import video_id, gen_extractors
    from ..downloader import YoutubeDL
    temp_dir = tempfile.mkdtemp(prefix='ytdl-test-hlsnative-')
    ydl = YoutubeDL({'outtmpl': os.path.join(temp_dir, '%(id)s.%(ext)s')})
    extractor_gen = gen_extractors()
    next(extractor_gen)

# Generated at 2022-06-12 16:53:29.400199
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    from urllib.parse import urljoin
    ydl = YoutubeDL()
    # Test that HlsFD is only used for ad videos
    hlsfd = HlsFD(ydl, {'skip_ad_fragments': True})

# Generated at 2022-06-12 16:53:37.796419
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import mock

# Generated at 2022-06-12 16:53:49.919951
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os, random, string, tempfile, shutil
    def random_string(length):
        return ''.join(random.choice(string.ascii_letters) for m in range(length))
    class DummyYDL(object):
        def __init__(self):
            self.params = {}
        def urlopen(self, url):
            class DummyUrlHandle(object):
                def __init__(self, url):
                    self.url = url
                def read(self):
                    frag_content = random_string(40).encode('utf-8')
                    return frag_content
                def geturl(self):
                    return self.url
            return DummyUrlHandle(url)

# Generated at 2022-06-12 16:53:58.933951
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """ Test the real_download method of HlsFD """
    from ..downloader import YoutubeDL
    from ..extractor import youtube

# Generated at 2022-06-12 16:54:42.012479
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """
    Test that the constructor of class HlsFD is working properly.
    """
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    params = {'continuedl': False}
    hlsfd = HlsFD(ydl, params)
    assert hlsfd.params['continuedl'] == False

# Generated at 2022-06-12 16:54:52.360250
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import gen_extractors
    from ..downloader import Downloader
    from ..version import __version__

    ydl = Downloader()

# Generated at 2022-06-12 16:55:02.964197
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os.path
    from .test_utils import test_can_download

    # file containing the manifest to download
    manifest_filename = 'media_playlist.m3u8'

# Generated at 2022-06-12 16:55:15.567728
# Unit test for constructor of class HlsFD
def test_HlsFD():
    print("--test HlsFD--")
    import youtube_dl
    import sys
    import os

    args = [
        '--http-chunk-size', '1M',
        '-f', '250',
        'https://www.youtube.com/watch?v=W-n8JMYr1OA'
    ]
    with youtube_dl.YoutubeDL(params={'forcejson': True}) as ydl:
        print("Testing HlsFD...")
        try:
            sys.argv = args
            ydl.download([ydl.prepare_filename(
                ydl.extract_info(ydl.params['url'], download=False))])
        except SystemExit:
            pass
        info_dir = '__ydl_info__'

# Generated at 2022-06-12 16:55:25.008963
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .youtube_dl.YoutubeDL import YoutubeDL
    from .youtube_dl.extractor import common
    from .youtube_dl.downloader.http import HttpFD
    from .youtube_dl.downloader.http_head_request import HttpHeadRequest
    import os
    # This sets up a hls download test with a mock manifest file and an actual http download

# Generated at 2022-06-12 16:55:28.127881
# Unit test for constructor of class HlsFD
def test_HlsFD():
    c = HlsFD(None, None)

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:55:39.880663
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-12 16:55:40.828707
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, None)



# Generated at 2022-06-12 16:55:45.423610
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import determine_ext
    from ..compat import compat_urllib_parse_urlencode
    from .http import HttpFD
    from .fragment import FragmentFD

    # test constructor raises an exception if no argument passed.
    # this tests for the correct number of arguments expected.
    # see issue #26133
    try:
        HlsFD()
        raise AssertionError('Failed to raise an exception.')
    except TypeError:
        pass

    # test can_download returns False with unknown extractors.
    # this tests if can_download function works correctly.
    # see issue #26133
    with InfoExtractor(downloader=None) as ie:
        ie.IE_NAME = 'unknown_extractor'
        hlsfd = Hls

# Generated at 2022-06-12 16:55:47.000058
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download("", {})



# Generated at 2022-06-12 16:57:15.636069
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import time
    import http.server
    import threading
    import urllib.request, urllib.parse, urllib.error
    import errno

    ad_frags = 8
    media_frags = 5
    man_url = 'http://127.0.0.1:8888/ad+media.m3u8'

# Generated at 2022-06-12 16:57:22.492148
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # This test will execute if and only if the youtube_dl.downloader.hls module is available.
    from ..downloader import HlsFD
    # A few examples of valid manifest URLs to test this function against
    manifest_URLS = [
        "https://example.com/m3u8_manifest",
        "https://example.com/m3u8_manifest/",
        "https://example.com/m3u8_manifest.m3u8",
    ]

# Generated at 2022-06-12 16:57:27.983005
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import sys
    import unittest
    # We need to insert the parent directory to test the import of
    # the parent module (youtube_dl)
    sys.path.insert(0, os.path.abspath('..'))
    import youtube_dl.YoutubeDL

    def _html_header(s):
        return ''.join(['%02X' % ord(x) for x in s])

    class MyHlsFD(HlsFD):
        def _prepare_url(self, info_dict, url):
            return url

        def _download_fragment(self, ctx, frag_url, info_dict, headers):
            content = open(frag_url.replace('file://', ''), 'rb').read()
            return (True, content)


# Generated at 2022-06-12 16:57:38.098915
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import sys
    import unittest
    import contextlib

    from .external_fd_utils import ExternalFDTest

    if sys.platform == 'win32':
        pycrypto_path = os.path.join(os.path.dirname(
            sys.executable), 'Lib', 'site-packages', 'Crypto')
        with contextlib.suppress(ImportError):
            sys.path.insert(0, pycrypto_path)

    from .FragmentFD import get_test_cases
    from .external_fd_utils import run_fd_test

    @unittest.skipIf(not can_decrypt_frag, 'requires pycrypto')
    class HlsFDTest(ExternalFDTest):
        def setUp(self):
            super(HlsFDTest, self).setUp()
           

# Generated at 2022-06-12 16:57:48.019971
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .external import FFmpegFD
    from .dash import DASHFD
    from .is_m3u8 import is_m3u8
    from ..downloader import YoutubeDL
    fd = HlsFD(YoutubeDL(), {})
    assert fd._check_hls_parameters_compat({})
    assert not fd._check_hls_parameters_compat({'prefer_ffmpeg': True})
    assert fd._check_hls_parameters_compat({'hls_prefer_ffmpeg': True})
    assert not fd._check_hls_parameters_compat({'dash_fragment_retries': 1})
    assert fd._check_hls_parameters_compat({'hls_fragment_retries': 1})
    assert not fd._

# Generated at 2022-06-12 16:57:51.398546
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """Unit tests for HlsFD constructor"""
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    HlsFD(ydl, {})


# Generated at 2022-06-12 16:57:58.788847
# Unit test for constructor of class HlsFD
def test_HlsFD():
    def fake_downloader_constructor(ydl, params):
        class FakeInfoDict(object):
            def get(self, name):
                # pylint: disable=unused-argument
                return None
        return FakeInfoDict()

    ydl = fake_downloader_constructor
    params = {}
    HlsFD(ydl, params)


if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:58:05.805020
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import gen_extractors
    # It is set to be True only when tests are executed
    is_test = 'youtube-dl.test' in sys.argv[0]
    # Build a video info structure
    # video_id,url,player_url,http_headers,fragments,decrypt_info
    video_info = ['0XvXk-HUFQQ',
                  'https://mnmedias.api.telequebec.tv/m3u8/29880.m3u8',
                  '',
                  {'User-Agent': 'iPad'},
                  [],
                  {}]
    # Instantiate downloader for HlsFD
    ydl = YoutubeDL(params={'quiet': True, 'test': is_test})
    (content, _) = ydl._real_

# Generated at 2022-06-12 16:58:13.555973
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.http import HttpFD
    from ..utils import encode_data_uri

    from .fragment import LimitFileReader

    # Example from https://github.com/ytdl-org/youtube-dl/issues/11504

# Generated at 2022-06-12 16:58:21.992015
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import tempfile
    import os.path
    #  input_filename = "http://hls-geo.daserste.de/i/videoportal/Film/c_620000/622873/format,716451,716457,716450,716458,716459,.mp4.csmil/index_3_av.m3u8?null=0"
    input_filename = sys.argv[1]
    #  output_filename = "test.mp4"
    output_filename = sys.argv[2]
    ydl = None
    params = {'skip_download': True, 'format': 'bestaudio/best'}
    hls_fd = HlsFD(ydl, params)
    info_dict = {'url': input_filename}
