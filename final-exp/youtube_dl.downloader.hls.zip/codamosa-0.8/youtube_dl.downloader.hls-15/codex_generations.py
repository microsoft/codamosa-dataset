

# Generated at 2022-06-12 16:49:17.291012
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .extractor.youtube import YoutubeIE
    from ..utils import determine_ext
    from ..downloader import YoutubeDL

    DOWNLOADER_PATH = os.path.join(os.path.dirname(__file__), '..', 'youtube-dl')

    def test_url(url):
        def process_info(info):
            url = info['url']
            assert url.startswith('http') and determine_ext(url) == 'm4s', 'URL is not valid %s' % url

# Generated at 2022-06-12 16:49:20.987823
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # The same unit test that works for FragmentFD should work for HlsFD
    FragmentFD.test_FragmentFD()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:49:34.697724
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import youtube
    from ..utils import FakeYDL
    ydl = FakeYDL()

# Generated at 2022-06-12 16:49:39.017886
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .utils import ManifestURLTestCase

    class can_downloadTestCase(ManifestURLTestCase):
        manifest_type = 'hls_native'
        fd_to_test = 'hlsnative'

        def test_hls_native_is_live(self):
            self.assertFalse(HlsFD.can_download(self.manifest, {'is_live': True}))


# Generated at 2022-06-12 16:49:51.813623
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """ Unit test for constructor of class HlsFD """
    assert HlsFD.can_download('', {})
    assert HlsFD.can_download('#EXT-X-DISCONTINUITY', {})
    assert HlsFD.can_download('#EXT-X-DISCONTINUITY\n#EXT-X-KEY:METHOD=AES-128', {})
    assert HlsFD.can_download('#EXT-X-DISCONTINUITY\n#EXT-X-KEY:METHOD=AES-128\n', {'is_live': True})
    assert HlsFD.can_download('#EXT-X-DISCONTINUITY\n#EXT-X-KEY:METHOD=AES-128\n', {'is_live': True, 'url': ''})

# Generated at 2022-06-12 16:50:04.978453
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader

    # Test 1: encrypted stream
    info = {
        'id': 'abc',
        'url': 'https://example.com/media.m3u8',
    }
    s = '#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-KEY:METHOD=AES-128\n'
    assert not HlsFD.can_download(s, info)
    assert HlsFD.can_download(s.replace('METHOD=AES-128', 'METHOD=NONE'), info)

    # Test 2: media composed of byte ranges of other
    s = '#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-BYTERANGE:121090@0'
   

# Generated at 2022-06-12 16:50:12.955667
# Unit test for constructor of class HlsFD
def test_HlsFD():
    manifest = """\
#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:5
#EXT-X-MAP:URI="http://example.com/test.ts",BYTERANGE="720@0"
#EXT-X-MEDIA-SEQUENCE:1
#EXT-X-PLAYLIST-TYPE:VOD
#EXTINF:4.000000,
http://example.com/test.ts
#EXT-X-ENDLIST
"""
    assert HlsFD.can_download(manifest, {})


# Generated at 2022-06-12 16:50:14.362073
# Unit test for constructor of class HlsFD
def test_HlsFD():
    TestYDL().HlsFD_test(HlsFD)



# Test for HlsFD.real_download()
import os
from .test_downloads import TestDownloads

# Generated at 2022-06-12 16:50:23.200822
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import unittest
    from .test_download import context, MockYDL

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.test_ctx = context()

        @staticmethod
        def _get_urls(manifest, **kwargs):
            ctx = context()
            ydl = MockYDL()
            ctx['ydl'] = ydl
            for k, v in kwargs.items():
                ctx[k] = v
            fd = HlsFD(ydl, {})

# Generated at 2022-06-12 16:50:35.741588
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download("#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:2.160,\nhttp://example.com/fileSequence0.ts\n#EXTINF:2.080,\nhttp://example.com/fileSequence1.ts\n#EXTINF:2.080,\nexample.com/fileSequence2.ts\n#EXTINF:2.080,\nhttp://example.com/fileSequence3.ts\n#EXT-X-ENDLIST", {})

# Generated at 2022-06-12 16:50:52.528643
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert HlsFD.real_download(1, 2) == False

# Generated at 2022-06-12 16:50:56.070946
# Unit test for constructor of class HlsFD
def test_HlsFD():
    if FFmpegFD.available():
        exit(0)
    else:
        exit(1)


if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:51:00.286315
# Unit test for constructor of class HlsFD
def test_HlsFD():
    url = 'http://example.com'
    ydl = YoutubeDL(dict(format=dict()))
    HlsFD(ydl, {}).get_real_downloader(url, {})
test_HlsFD()

# Generated at 2022-06-12 16:51:09.795687
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    class TestYdl:
        def report_skip_fragment(self, frag_index):
            pass

        def report_retry_fragment(self, err, frag_index, count, fragment_retries):
            pass

        def report_error(self, message):
            pass

        def urlopen(self, url):
            return TestYdlUrlOpen(url)

    class TestYdlUrlOpen:
        def __init__(self, url):
            self.url = url

        def close(self):
            pass

        def geturl(self):
            return self.url

        def info(self):
            return {}


# Generated at 2022-06-12 16:51:23.320843
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import os.path
    import subprocess
    import tempfile
    import shutil

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()


# Generated at 2022-06-12 16:51:32.662980
# Unit test for constructor of class HlsFD
def test_HlsFD():
    url = ('http://hls-geo.daserste.de/i/videoportal/Film/c_620000/622873/format,716451,716457,716450,716458,716459,.mp4.csmil/master.m3u8')
    urlh = urllib.request.urlopen(url)
    s = urlh.read().decode('utf-8', 'ignore')
    assert(not can_download(s, None))
    print('Unit test for constructor of class HlsFD done')

# Test for method can_download() of class HlsFD

# Generated at 2022-06-12 16:51:39.124636
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..downloader import FileDownloader
    from ..extractor import YoutubeIE
    from ..utils import prepend_extension

    ydl = FileDownloader({})
    ydl.add_info_extractor(YoutubeIE())
    downloader_params = {
        'usenetrc': False,
        'username': 'test',
        'password': 'test'
    }


# Generated at 2022-06-12 16:51:51.535035
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import youtube_dl_server.extractor.common
    from youtube_dl_server.utils import FakeYDL
    from youtube_dl_server.extractor.youtube import YoutubeIE
    sys.modules['youtube_dl.extractor.common'] = youtube_dl_server.extractor.common
    sys.modules['youtube_dl.utils'] = youtube_dl_server.utils
    sys.modules['youtube_dl.extractor.youtube'] = youtube_dl_server.extractor.youtube
    ydl = FakeYDL()
    ydl.add_info_extractor(YoutubeIE())
    ydl.add_default_info_extractors()
    ydl.params['test'] = True

# Generated at 2022-06-12 16:52:04.805109
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    ie = InfoExtractor(params={})
    fd = HlsFD(ie, ie.params)
    info_dict = {}

    # test METHOD=NONE
    info_dict['url'] = None
    manifest = '#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXT-X-VERSION:3\n#EXT-X-MEDIA-SEQUENCE:0\n#EXT-X-PLAYLIST-TYPE:VOD\n#EXTINF:10,\nmedia-0.ts\n#EXT-X-ENDLIST\n'
    assert fd.can_download(manifest, info_dict)

    # test METHOD=AES-128

# Generated at 2022-06-12 16:52:14.744847
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls = HlsFD(None, None)
    assert hls.can_download('#EXTM3U', None)
    assert not hls.can_download('#EXTM3U\n' +
        '#EXT-X-KEY:METHOD=AES-128,URI="https://priv.example.com/key.php?r=52"', None)
    assert hls.can_download('#EXTM3U\n' +
        '#EXT-X-KEY:METHOD=NONE,URI="https://priv.example.com/key.php?r=52"', None)

# Generated at 2022-06-12 16:52:31.927832
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hfd = HlsFD({}, {})

# Generated at 2022-06-12 16:52:34.147007
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, None)

# This unit test only tests if the class initialises correctly
# TODO Make a unit test for the download function

# Generated at 2022-06-12 16:52:43.289023
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from . import YoutubeDL
    from .extractor.generic import GenericIE
    ydl = YoutubeDL({'skip_download': True})
    ie = GenericIE('test')
    ydl.add_info_extractor(ie)

# Generated at 2022-06-12 16:52:55.527080
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Test is live stream
    info_dict = {'is_live': True}
    manifest = ''
    assert not HlsFD.can_download(manifest, info_dict)

    # Test is not live stream
    info_dict = {'is_live': False}
    manifest = ''
    assert HlsFD.can_download(manifest, info_dict)

    # Test is not live stream but has unsupported EXT-X-MEDIA-SEQUENCE
    info_dict = {'is_live': False}
    manifest = '#EXT-X-MEDIA-SEQUENCE:101\n'
    assert not HlsFD.can_download(manifest, info_dict)

    # Test is not live stream but has unsupported EXT-X-KEY:METHOD
    info_dict = {'is_live': False}
    manifest

# Generated at 2022-06-12 16:53:08.113798
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..utils import match_filter_func
    from ..extractor.twitch import Twitch
    from ..compat import compat_urlparse

    assert HlsFD.can_download('#EXTM3U', {'is_live': False})

    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {'is_live': False})

    assert not HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-KEY:METHOD=AES-128\n'
        '#EXT-X-KEY:METHOD=NONE\n'
        '#EXT-X-BYTERANGE:7914228@6258769', {'is_live': False})


# Generated at 2022-06-12 16:53:16.178044
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import tempfile

    # Test for can_download()
    class TestYDL:
        params = {}
        urlopen = lambda *args, **kwargs: None
    ydl = TestYDL()
    assert HlsFD.can_download('', ydl)
    assert HlsFD.can_download(r'#EXT-X-KEY:METHOD=AES-128,URI="https://example.com"', ydl)

    # Test for real_download()
    class TestYDL:
        params = {'test': True}
        urlopen = lambda *args, **kwargs: None
        extract_info = lambda *args, **kwargs: {
            'url': 'https://manifest_url.com',
        }
    ydl = TestYDL()

# Generated at 2022-06-12 16:53:28.483266
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import unittest

    YDL_ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    TESTS_DIR = os.path.abspath(os.path.join(YDL_ROOT_DIR, 'tests'))

    from .fragment import (
        FragmentFDTestBase,
        FragmentFDTestContent,
    )

    test_fragment_data = FragmentFDTestContent(TESTS_DIR, 'test.ts')
    test_fragment_data2 = FragmentFDTestContent(TESTS_DIR, 'test.ts')
    test_fragment_data3 = FragmentFDTestContent(TESTS_DIR, 'test.ts')



# Generated at 2022-06-12 16:53:37.134836
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import gen_extractors

# Generated at 2022-06-12 16:53:49.433640
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """ Unit test for constructor of class HlsFD """
    from .downloader import Downloader
    from .http import HTTPDownloader
    from .http import HEADRequest
    from .hooks import FileDownloadHook
    params = {'noprogress': True, 'retries': 0, 'continuedl': False}
    ydl = Downloader(params)
    info_dict = {}
    info_dict['url'] = 'https://test_url'
    info_dict['http_headers'] = {'Test-header': 'Test value'}
    # Here we create an object of HlsFD
    hls_fd = HlsFD(ydl, FileDownloadHook(HTTPDownloader(params, ydl.socket_wrappers), params, {'Test-header': 'Test value'}))
    assert hls_

# Generated at 2022-06-12 16:53:58.558454
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..postprocessor.ffmpeg import FFmpegPostProcessor
    from .common import FakeYDL
    from .test_fragment import FragmentFDTest

    class FakeXDL(FakeYDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__()

# Generated at 2022-06-12 16:54:36.948045
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ydl = object()
    params = {'format': 'best'}

    hls_fd1 = HlsFD(ydl, params)

    assert hls_fd1.ydl == ydl
    assert hls_fd1.params == params
    assert hls_fd1.name == HlsFD.FD_NAME

    hls_fd2 = HlsFD(ydl, params, 'test')

    assert hls_fd2.name == 'test'


# Generated at 2022-06-12 16:54:46.939737
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    from zipfile import ZipFile

    try:
        if sys.version_info.major == 2:
            import urlparse as compat_urlparse
    except:
        from .compat import compat_urlparse

    from . import YoutubeDL
    from .common import InfoExtractor

    ydl = YoutubeDL(
        {
            'cachedir': False,
            'nooverwrites': True,
            'sleep_interval': 0,
            'quiet': True,
            'skip_download': True,
            'simulate': True,
            'no_warnings': True,
            'progress_hooks': [lambda a, b: None]
        }
    )


# Generated at 2022-06-12 16:54:47.852893
# Unit test for constructor of class HlsFD
def test_HlsFD():
    return HlsFD

# Generated at 2022-06-12 16:54:55.659929
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    downloader = Downloader()
    downloader.add_info_extractor(YoutubeIE(downloader))

# Generated at 2022-06-12 16:55:05.054098
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    from .external import FFmpegFD
    ydl = YoutubeDL({
        'outtmpl': 'test.mp4',
        'quiet': True,
        'no_color': True
    })
    ydl.add_default_info_extractors()
    ie = ydl._ies[0](ydl)

# Generated at 2022-06-12 16:55:17.033719
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from unittest import TestCase
    from .common import BaseTestCase

    class HlsFDRealDownloadTest(TestCase, BaseTestCase):
        def setUp(self):
            self.setUpSuite()
            self.params['skip_unavailable_fragments'] = False
            self.params['fragment_retries'] = 0

        def tearDown(self):
            self.tearDownSuite()


# Generated at 2022-06-12 16:55:17.887441
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, {})

# Generated at 2022-06-12 16:55:24.525730
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # The fragment_retries and skip_unavailable_fragments parameters are not
    # required for the unit test to assure that HlsFD does not download
    # unavailable (possibly temporary) fragments and hence does not fail.
    # The following is a mockup of the first fragment of a valid HLS stream.
    manifest = (
        '#EXTM3U\n'
        '#EXT-X-VERSION:3\n'
        '#EXT-X-MEDIA-SEQUENCE:0\n'
        '#EXT-X-PLAYLIST-TYPE:VOD\n'
        '#EXTINF:3.003,\n'
        'http://media.example.com/first.ts\n'
        '#EXT-X-ENDLIST'
    )


# Generated at 2022-06-12 16:55:36.967253
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import tempfile
    from .downloader import _common_options
    from ..compat import (
        compat_urllib_request,
    )
    import sys
    if sys.version_info[0] >= 3:
        from io import StringIO
        import urllib.parse
    else:
        from StringIO import StringIO
        import urlparse as urllib

# Generated at 2022-06-12 16:55:40.474596
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hfd = HlsFD(None, {
        'fragment_retries': 0,
        'skip_unavailable_fragments': True,
        'test': True,
    })

    assert(hfd is not None)

# Generated at 2022-06-12 16:57:04.416777
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # TODO use config parser and make test.ini file
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import HLSV2IE
    ret = []
    HLSV2IE.suitable(ret, 'https://trs-cdn.lovelive.tv/live/smile/playlist.m3u8')
    assert isinstance(ret[0], HlsFD)


# Generated at 2022-06-12 16:57:16.002660
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .extractor.common import InfoExtractor
    import tempfile
    import os

# Generated at 2022-06-12 16:57:22.765401
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError
    from ..jsinterp import JSInterpreter
    class FakeYDL(object):
        def __init__(self, *_):
            self.params = {}
            self.cache = None
            self.to_screen = print
            self.extractor = InfoExtractor('')
            self.extractor.ie_key = ''
            self.extractor._downloader = self
            self.js_interpreter = JSInterpreter(self.extractor, self.params)
        def to_screen(self, *args, **kwargs):
            pass
        def report_error(self, *args, **kwargs):
            raise ExtractorError('_test_report_error_')

# Generated at 2022-06-12 16:57:27.667395
# Unit test for constructor of class HlsFD
def test_HlsFD():
    info_dict = {'url': '', 'http_headers': {'User-Agent': ''}, 'fragment_retries': 0}
    fd = HlsFD('', info_dict)

    # Check if test_HlsFD() can properly detect missing requirements in method can_download()
    info_dict['url'] = '#EXT-X-KEY:METHOD=AES-128'
    assert fd.can_download('#EXT-X-KEY:METHOD=AES-128', info_dict) == False

    info_dict['url'] = '#EXT-X-BYTERANGE'
    assert fd.can_download('#EXT-X-BYTERANGE', info_dict) == False

# Generated at 2022-06-12 16:57:38.021531
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os.path
    import tempfile
    import unittest

    from .test_downloads import FakeYdl


# Generated at 2022-06-12 16:57:40.646188
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """
        Testing the constructor of class HlsFD
    """
    hls_fd = HlsFD()

# Generated at 2022-06-12 16:57:49.068260
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import match_filter_func

    class HlsIE(InfoExtractor):
        _VALID_URL = r'https?://(?P<id>.+)'

        def _real_extract(self, url):
            return {
                '_type': 'url',
                'url': url,
            }


# Generated at 2022-06-12 16:58:01.606624
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import sys
    import os
    from ..compat import compat_urllib_request
    from ..YoutubeDL import YoutubeDL
    from .test_fragment import _prepare_test_download

    if can_decrypt_frag:
        key = b'\x00' * 16
        iv = b'\x00' * 16
        aes_key_cdn = ('#EXT-X-KEY:METHOD=AES-128,URI="https://testcdn.com/k.bin"\n')
        aes_key_cdn_wrong = ('#EXT-X-KEY:METHOD=AES-128,URI="https://testcdn.com/k2.bin"\n')

# Generated at 2022-06-12 16:58:11.501830
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .fragment import FragmentFD
    from .external import FFmpegFD
    from .dash import DashSegmentsFD
    from .http import HttpFD
    from ..downloader import YoutubeDL
    from ..downloader.common import FileDownloader
    from ..compat import compat_urlparse

    _, inj = YoutubeDL._extract_info(FileDownloader({'nopart': True}), None, 'http://www.dailymotion.com/video/x21t6u0_sport-vines-september-2014_sport', download=False, process=False)
    assert isinstance(inj['fragment_downloader'], HlsFD)

    assert HlsFD.can_download('#EXTM3U\n', {'url': ''}) is False

# Generated at 2022-06-12 16:58:21.593534
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import FakeYDL
    ydl = FakeYDL()
    fd = HlsFD(ydl, {'format': 'best'})
    assert fd.real_download('foo.mp4', {
        'url': 'http://example.com/manifest.m3u8',
    })
    assert fd.real_download('foo.mp4', {
        'url': 'http://example.com/manifest.m3u8',
        'http_headers': {'Foo': 'Bar'},
    })
    assert fd.real_download('foo.mp4', {
        'url': 'http://example.com/manifest.m3u8',
        'extra_param_to_segment_url': '',
    })