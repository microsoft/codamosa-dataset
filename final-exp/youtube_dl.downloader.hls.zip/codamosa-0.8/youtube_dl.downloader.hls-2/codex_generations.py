

# Generated at 2022-06-12 16:49:15.431431
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Initialize the module HlsFD
    hls_fd = HlsFD(None, {'test':True})
    hls_fd.add_progress_hook = lambda a: None

    # Return true
    return hls_fd.real_download('sample.mp4',{'url': 'https://raw.githubusercontent.com/ytdl-org/youtube-dl/master/resources/test/test_hls_native/playlist.m3u8', 'http_headers': {'Range': 'bytes=0-7'}})

# Generated at 2022-06-12 16:49:29.761597
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import shutil
    import tempfile
    import unittest

    from ..extractor import gen_extractors

    TEST_URL = 'https://video.twimg.com/ext_tw_video/1287266787972845569/pu/pl/720x720/sXHxyWK6UOBf_UgT.m3u8'

# Generated at 2022-06-12 16:49:32.061247
# Unit test for constructor of class HlsFD
def test_HlsFD():
    instance = HlsFD(None, None)
    assert isinstance(instance, HlsFD)

# Generated at 2022-06-12 16:49:44.727718
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import io
    import os
    import random
    import tempfile
    import shutil
    import unittest

    from .http import HttpFD

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.hls_base_url = 'https://some_url.com/'
            self.hls_manifest_url = self.hls_base_url + 'manifest.m3u8'
            self.hls_frag_url = self.hls_base_url + 'frag.mp4'
            self.hls_enc_key_url = self.hls_base_url + 'enc.key'
            self.hls_enc_iv = 'a1b2c3d4'

# Generated at 2022-06-12 16:49:52.470490
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor

    import tempfile

    with tempfile.NamedTemporaryFile() as tf:
        class FakeInfoDict(object):
            pass

        info_dict = FakeInfoDict()
        info_dict.url = 'http://some_url'
        info_dict.filename = tf.name
        ie = InfoExtractor(HlsFD.get_info_extractor(info_dict))
        HlsFD.real_download(ie, info_dict)

# Generated at 2022-06-12 16:49:58.163811
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():

    import sys
    import os
    from os.path import join
    from .test import test_HlsFD as base_test_HlsFD

    filenames = ['test_frag_dl.py', 'HlsFD.py']

    # The following input.txt is expected to match the output produced by
    # executing "print(repr(s))" in method FFmpegFD.real_download(...) of
    # class HlsFD in file HlsFD.py at line 60

# Generated at 2022-06-12 16:50:06.701649
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeDL
    hls_fd = HlsFD(YoutubeDL({
        'outtmpl': '%(id)s.%(ext)s',
        'merge_output_format': 'mkv',
        'format': 'best',
        'nooverwrites': True,
        'verbose': True,
        'quiet': False,
        'no_warnings': True,
        'continuedl': False,
        'logger': YoutubeDL.logger_class('test_hlsfd').debug,
        'skip_download': True,
        'progress_hooks': [lambda a, b, c: None],
        'skip_unavailable_fragments': False,
        'fragment_retries': 0,
    }), {'test': True})

    # Test

# Generated at 2022-06-12 16:50:14.527561
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import os
    import youtube_dl
    import youtube_dl.FileDownloader
    from .fragment import FragmentFDTest
    from .external import FFmpegFDTest

    def _extract_manifest(fn):
        with open(fn) as f:
            return f.read()

    test = FragmentFDTest()
    test.downloader = youtube_dl.FileDownloader({'noplaylist': True})
    test.downloader.cache.remove()

    test.add_default_callback(
        extract_flat, 'hls', '# downloaded m3u8 manifest',
        'test.m3u8', content_re=r'(?s)#EXTM3U.*?')

    test_id = 'test_id'
    baseurl = 'baseurl'

# Generated at 2022-06-12 16:50:23.227149
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..utils import UnavailableVideoError

    url = 'https://video-http.media-imdb.com/MV5BMTQ2MjkwNDM5NF5BMl5BanBnXkFtZTgwMjMyMzM0OTE@.mp4Set=hls-ch1&s=9ceb9d0e-e2cd-41dd-8b6e-af6c89950d55'
    with youtube_dl.YoutubeDL({'hls_prefer_native': True}) as ydl:
        video_info = ydl.extract_info(url)
        hls_formats = [f for f in video_info['formats'] if f.get('protocol') == 'm3u8_native']

# Generated at 2022-06-12 16:50:23.880630
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ''' check if HlsFD can be created successfully '''
    assert HlsFD()

# Generated at 2022-06-12 16:50:50.855921
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    sys.path.append("..")
    from ydl.YoutubeDL import YoutubeDL
    ydl_opts = {
        'outtmpl': 'test',
        'quiet': True,
        'test': True
    }

    def prepare_download(manifest):
        fd = HlsFD(YoutubeDL(ydl_opts), None)
        fd.real_download('test', {'url': manifest})

    def test_m3u8(manifest):
        prepare_download(manifest)

    # http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8

# Generated at 2022-06-12 16:51:03.520040
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """
    Testing whether or not function real_download can download successfully
    """
    from .file_test import file_test
    from .utils import fake_os
    from .url_test import url_test_factory

    fake_os.requests_mock = url_test_factory(
        text='#EXTM3U\n#EXTINF:10,\nfileSequence0.ts\n'
             '#EXT-X-KEY:METHOD=AES-128,URI="http://example.com/key"\n'
             '#EXTINF:10,\nfileSequence1.ts\n'
             '#EXTINF:10,\nfileSequence2.ts\n',
        binary_content='\x00' * 4096
    )

# Generated at 2022-06-12 16:51:14.340077
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
	from .downloader import Downloader
	from .extractor import YoutubeIE
	downloader = Downloader()
	downloader.params.update({'noprogress': True, 'quiet': True})
	downloader.add_info_extractor(YoutubeIE())
	expected_output = """\
[hlsnative] Downloading m3u8 manifest
[hlsnative] Downloading the last fragment
[download] Destination: _
"""
	downloader.params.update({'test': True})
	assert expected_output == downloader.process_info(YoutubeIE().extract('http://www.youtube.com/watch?v=BaW_jenozKc'), downloader.cache)

# Generated at 2022-06-12 16:51:28.046944
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..downloader import YoutubeDL

    ydl = YoutubeDL()


# Generated at 2022-06-12 16:51:36.376726
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .extractor import gen_extractors

    def test_can_download(fd_name, manifest, info, expected_result):
        info_dict = {'url': info}
        extractor = gen_extractors(info_dict)[0]
        if fd_name == 'hlsnative':
            assert extractor.suitable and extractor.IE_NAME == 'hls' and extractor.FD_NAME == fd_name
            result = HlsFD.can_download(manifest, info_dict)
        else:
            assert not extractor.suitable
            result = False
        assert result == expected_result

    # with no content
    test_can_download('hlsnative', '', '', False)

    # AES-128 encrypted fragments

# Generated at 2022-06-12 16:51:49.352969
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXTINF:1.0\n#EXT-X-DISCONTINUITY\nhttp://example.com/seg1.ts', {})
    assert HlsFD.can_download('#EXTM3U\n#EXTINF:1.0\n#EXT-X-BYTERANGE:30580@495872\nhttp://example.com/seg1.ts', {})
    assert HlsFD.can_download('#EXTM3U\n#EXTINF:1.0\n#EXT-X-KEY:METHOD=AES-128,URI=http://example.com/key.bin\nhttp://example.com/seg1.ts', {})

# Generated at 2022-06-12 16:51:56.372941
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import FakeYDL
    import os
    import tempfile
    import shutil
    import socket
    import mimetypes
    from ..downloader.external.ffmpeg import FFmpegPostProcessor

    # Test basic m3u8 download
    def test_basic_m3u8_download(m3u8_string, expected_results, media_extension, has_ts_bom=False):
        tempdir = tempfile.mkdtemp(prefix=__name__ + '-', suffix='-test_basic_m3u8_download')

        ie = InfoExtractor(None, {'logger': FakeYDL()})
        ie.cache = None
        ie.url = 'https://example.com/index.m3u8'
        ie.cache_dir

# Generated at 2022-06-12 16:52:08.234661
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader.common import FileDownloader
    from ..extractor import YoutubeIE
    from .retryfd import RetryFD
    dl = FileDownloader({'noprogress': True, 'nooverwrites': True, 'quiet': True,
                         'youtube_include_dash_manifest': False,
                         'outtmpl': '%(id)s.%(ext)s'})
    dl.add_info_extractor(YoutubeIE())
    dl.add_info_extractor(YoutubeIE(YoutubeIE.ie_key() + '_dash'))
    dl.add_info_extractor(YoutubeIE(YoutubeIE.ie_key() + '_dash_fragments'))

# Generated at 2022-06-12 16:52:15.792775
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import os
    import tempfile
    from .external import FFmpegFD
    from ..utils import format_bytes
    from ..downloader.common import FileDownloader


# Generated at 2022-06-12 16:52:25.868745
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .testcases import FakeYDL
    from .tests.test_fragment import MockFragmentFD
    def test_hook(d):
        assert 'downloaded_frags' in d
        assert d['downloaded_frags'] == 1
        assert 'fragment_index' in d
        assert d['fragment_index'] == 2
        assert 'filename' in d
        assert d['filename'] == 'foo.ts'
        return True
    params = {
        'format': '251',
        'outtmpl': '%(id)s',
        'noprogress': True,
        'quiet': True,
        'nopart': True,
        'test': True,
    }

# Generated at 2022-06-12 16:52:59.311104
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Constructor HlsFD()
    hls_fd = HlsFD(None, None)

    # Constructor HlsFD.real_download()
    # hls_fd.real_download(None, None)
    # Uncomment line above to test the method

    # Constructor HlsFD.can_download()
    # hls_fd.can_download(None, None)
    # Uncomment line above to test the method

    # Constructor HlsFD.real_download()
    # hls_fd.real_download(None, None)
    # Uncomment line above to test the method

# Generated at 2022-06-12 16:53:02.357477
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Downloading m3u8 manifest
    def _download_fragment(self, url, params, headers):
        """ return True, content """


# Generated at 2022-06-12 16:53:09.499565
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor import YoutubeIE

    test_data = get_test_data(YoutubeIE, 'https://www.youtube.com/watch?v=5W5pdytLVFE',
                              False, None, False)
    fd = HlsFD(test_data['ydl'], test_data['params'])
    assert fd.real_download('', test_data['info_dict'])


# Generated at 2022-06-12 16:53:10.068193
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    None

# Generated at 2022-06-12 16:53:16.927408
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ydl_tests.youtube_dl_test_suite import (
        YoutubeDL,
        FullArgumentParser,
        optbase,
    )
    base_opts = optbase.copy()
    parser = FullArgumentParser()
    opts = parser.parse_args(args=[], namespace=base_opts)
    ydl = YoutubeDL(opts)
    hls_fd = HlsFD(ydl, opts)
    assert isinstance(hls_fd, HlsFD)
    try:
        from Crypto.Cipher import AES
    except ImportError:
        assert hls_fd.FD_NAME == 'hls'
    else:
        assert hls_fd.FD_NAME == 'hlsnative'

# Generated at 2022-06-12 16:53:28.974436
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import iso639_to_mid
    class FakeYDL():
        def __init__(self, *args, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass

        def report_warning(self, msg):
            print(msg)

        def urlopen(self, url):
            from ..extractor import youtube
            class FakeURLOpen():
                def __init__(self, ydl, url):
                    self.ydl = ydl
                    self.url = url

                def read(self):
                    return youtube.m3u8_url_result(self.url, self.ydl)

                def geturl(self):
                    return self.url
            return FakeURLOpen(self, url)

# Generated at 2022-06-12 16:53:37.459367
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # This test is based on the following issue:
    # https://github.com/ytdl-org/youtube-dl/issues/13620

    # This is a very basic test that tests the following:
    #  * If a URL is given to HlsFD (as input) it should be downloaded.
    #  * If the URL is malformed, an error should be returned.
    #  * If the video contains ads, they should be skipped.
    #  * If the video is valid and has ads in it, HlsFD should return successfully.

    # Parameters to pass to HlsFD
    params = {
        'test': True,  # Only download the first fragment of a video.
        'noprogress': True,
    }
    # Library object used to download from URL
    ydl = None

    # Helper function that returns an

# Generated at 2022-06-12 16:53:49.564845
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os, sys
    # Set the value of working directory
    os.chdir('/home/bimba/youtube-dl/youtube_dl')
    # Set the value of sys.argv[0]
    sys.argv[0] = 'youtube-dl'
    # Create a instance for class YoutubeDL
    ydl_opts = {}
    ydl = YoutubeDL(ydl_opts)
    # Initialize params, which is passed to the class HlsFD
    params = {
    }
    # Initialize info_dict, which is passed to the class HlsFD

# Generated at 2022-06-12 16:53:58.670363
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert HlsFD.can_download(
        '#EXTM3U\n#EXTINF:10,\nhttp://example.com/hi.ts\n#EXT-X-ENDLIST',
        {'is_live': False}
    )
    assert not HlsFD.can_download(
        '#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\n#EXTINF:10,\nhttp://example.com/hi.ts\n#EXT-X-ENDLIST',
        {'is_live': False}
    )

# Generated at 2022-06-12 16:54:11.413643
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """ Test HlsFD._download_fragment method """
    from io import BytesIO
    from six.moves import urllib_request as urllib
    from .external import FFmpegFD
    from .test.test_download import FakeYDL
    from .downloader import FileDownloader
    from .utils import DateRange

    class FakeIE():
        def __init__(self):
            self.ie_key = 'youtube'

        def extract_info(self, url, ie_key):
            assert ie_key == self.ie_key

# Generated at 2022-06-12 16:55:26.057520
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .extractor.generic import GenericIE
    from .extractor.youtube import YoutubeIE

    youtube_ie = YoutubeIE()
    generic_ie = GenericIE()

    # YouTube HLS stream
    # See https://github.com/ytdl-org/youtube-dl/blob/master/youtube_dl/extractor/youtube.py

# Generated at 2022-06-12 16:55:36.914521
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """
    Test HlsFD
    """
    from ..downloader import YoutubeDL
    d = YoutubeDL({'hls_prefer_native': True})
    fd = HlsFD(d, {'url': 'https://video.example.com.vh.akamaihd.net/i/videos/t/v001/'})
    assert fd.name() == 'hlsnative'
    assert fd.can_download({'url': 'https://video.example.com.vh.akamaihd.net/i/videos/t/v001/'},
                           {})


if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:55:42.504752
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        from ydl.extractor import youtube
    finally:
        pass
    ydl = youtube.YoutubeDL({})
    retu = {'url': 'url', 'http_headers': {'k1': 'v1'}, '_decryption_key_url': '_decryption_key_url'}
    hls = HlsFD(ydl, retu)
    assert isinstance(hls, HlsFD)

# Generated at 2022-06-12 16:55:53.849731
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .url_fd import URLFD
    from .youtube_dl.utils import urljoin
    from .youtube_dl.YoutubeDL import YoutubeDL

    def dummy_urlopen(url):
        class DummyCookieJar(object):
            def add_cookie_header(self, req):
                pass

            def extract_cookies(self, req, resp):
                pass

        class DummyResponse(object):
            def info(self):
                i = compat_urllib_response.addinfourl(
                    None,
                    {
                        'Content-Type': 'application/vnd.apple.mpegurl',
                    },
                    url
                )
                i.code = 200
                i.msg = 'OK'
                return i

            def read(self, *args, **kwargs):
                return dummy_urlopen._response

# Generated at 2022-06-12 16:56:02.782813
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .extractor.common import InfoExtractor
    from ..utils import ExtractorError
    from ..compat import compat_urllib_error

    class FakeInfoExtractor(InfoExtractor):
        def _download_webpage(self, *args, **kwargs):
            pass

        def _download_fragment(self, *args, **kwargs):
            return True, 'fragment_content'

    class FakeYtdl:
        def urlopen(self, *args, **kwargs):
            raise ExtractorError('urlopen raises an error', expected=True)

        def report_warning(self, *args, **kwargs):
            pass

        def report_retry_fragment(self, *args, **kwargs):
            pass


# Generated at 2022-06-12 16:56:13.880622
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Class object (HlsFD) requires most arguments.
    # The arguments below are real-world examples that can be used with unit test.
    # Note: The content of the M3U8 file is not real.
    HlsFD_args = {
        'manifest': '#EXTM3U\n' +
                    '#EXT-X-TARGETDURATION:10\n' +
                    '#EXT-X-VERSION:3\n' +
                    '#EXT-X-MEDIA-SEQUENCE:1\n',
        'info_dict': {
            'id': '09',
            'url': 'https://www.youtube.com/watch?v=09',
            'ext': 'mp4',
        },
    }

    from .extractor.generic import YoutubeIE

# Generated at 2022-06-12 16:56:15.362285
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert isinstance(HlsFD('url'), HlsFD)

# Generated at 2022-06-12 16:56:21.499512
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    from .downloader import FileDownloader
    from .utils import prepend_extension
    from .extractor import gen_extractors
    from .compat import compat_urlparse

    (ydl, params, info) = FileDownloader._prepare_and_initialize_direct_download({
        'test': True,
        'simulate': True,
        'noplaylist' : True,
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
        'nocheckcertificate': True,
        'outtmpl': '%(id)s.%(ext)s',
    }, 'http://localhost:8080/test.m3u8')

# Generated at 2022-06-12 16:56:25.148586
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import os

    os.chdir(os.path.dirname(__file__))

    try:
        HlsFD('http://test.com', {})
    except TypeError:
        return True
    return False

# Generated at 2022-06-12 16:56:31.802213
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .test import get_testdata_files_directory