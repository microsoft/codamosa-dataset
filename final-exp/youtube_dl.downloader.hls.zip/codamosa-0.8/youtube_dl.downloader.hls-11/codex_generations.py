

# Generated at 2022-06-12 16:49:19.515848
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test_utils import download_playlist

# Generated at 2022-06-12 16:49:20.526181
# Unit test for constructor of class HlsFD
def test_HlsFD():
    (fd, _) = HlsFD.gen_extractor({})
    assert fd is not None


# Generated at 2022-06-12 16:49:34.281711
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import _configuration_for_test
    from ..utils import get_cachedir

    cachedir = get_cachedir("pytest")
    ydl = _configuration_for_test()
    urlh = ydl.urlopen("http://www.twitch.tv/dota2ti")
    url = urlh.geturl()

# Generated at 2022-06-12 16:49:38.613339
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    class MockYDL(FileDownloader):
        def __init__(self, params):
            super(MockYDL, self).__init__(params)
            self.cache = {}

        def cache_response(self, key, response, data):
            self.cache[key] = response

        def to_screen(self, message, *args, **kargs):
            pass

        def report_warning(self, message):
            pass

        def urlopen(self, url, params=None):
            return self.cache[url]

    import unittest

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.ie = Info

# Generated at 2022-06-12 16:49:41.338255
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .fragment import FragmentFDTest
    return FragmentFDTest(HlsFD).run()

# Generated at 2022-06-12 16:49:50.883309
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Download an HLS fragment and write the result to a file
    from ..downloader import YoutubeDL

    ydl = YoutubeDL()
    ydl.add_progress_hook(lambda x: test_HlsFD.progress_hook(x, ydl))
    ydl.download(['https://bitdash-a.akamaihd.net/content/MI201109210084_1/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8'])

test_HlsFD.progress_hook = None

# Generated at 2022-06-12 16:49:55.111082
# Unit test for constructor of class HlsFD
def test_HlsFD():
    class FakeYdl(object):
        def __init__(self):
            self.urlopen_calls = []

        def urlopen(self, url):
            self.urlopen_calls.append(url)

    ydl = FakeYdl()
    fd = HlsFD(ydl=ydl, params={'test': True})

    # Test that urlopen is called with the correct url
    info_dict = {
        'url': 'http://test/test'
    }
    fd.real_download('0', info_dict)
    assert ydl.urlopen_calls[0] == 'http://test/test'

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:50:05.088898
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import Downloader

    ydl = Downloader()

    def test_hook(d):
        return

    ydl.add_progress_hook(test_hook)

    hfd = HlsFD(ydl, {'test': True})

    # TODO: Add more tests (m3u8 manifests with different features)

    # m3u8 manifest with a single media segment

# Generated at 2022-06-12 16:50:13.104443
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import encode_base64_urlsafe
    url = 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8'
    params = {'http_chunk_size': 10, 'http_chunk_num': 0, 'test': True}
    info_dict = {'formats': [{'url': url, 'format_id': '0', 'http_headers': {
        'Authorization': 'Basic %s' % encode_base64_urlsafe('0x36xhzz:AYHvRDFUCLg6Uo9XC4cYLQvF1Z4lr4xq'),
    }}]}
    fd = HlsFD(None, params)
    assert fd.real_download('example.mp4', info_dict)

# Generated at 2022-06-12 16:50:21.223002
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import encodeFilename
    from .fragment import MetaM3U8FD
    from .external import FFmpegFD

    class MockYoutubeDL:
        def __init__(self):
            self._encoding = 'UTF-8'
            class MockHeadRequest:
                def __init__(self):
                    self.headers = {}
                def getheader(self, header_name, default=None):
                    return self.headers.get(header_name, default)
            self.urlopen = lambda _: MockHeadRequest()

        def encodeFilename(self, name):
            return encodeFilename(name, self._encoding)

    class MockFileDownloader:
        def __init__(self):
            self.params = {}
            self.cache = {}
            self.to_screen = lambda *args: None
            self.report

# Generated at 2022-06-12 16:50:43.904666
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .downloader import HlsFD
    from .extractor import YoutubeIE
    from .extractor import GenericIE
    from .test import get_testdata_file, get_testcases_from_test_file

    YoutubeIE._WORKAROUND_URL = 'http://example.com/'

    def _test_hls_download(testcases, extractor, extra_options):
        for test in testcases:
            companion_test(
                test,
                extractor,
                HlsFD,
                'hlsnative',
                (*extra_options, '--test'),
                'Download of first fragment',
                match_range=(0, 65536),
                video_id=lambda: test.get('video_id'),
            )

    # ffmpeg

# Generated at 2022-06-12 16:50:50.812124
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.generic import GenericIE
    ie = GenericIE({})
    ie.params['username'] = 'abc'
    ie.params['password'] = 'def'
    ie.params['http_headers'] = 'g:h\ni:j'
    ie.report_warning = lambda msg: None
    ie.report_error = lambda msg: None
    hlsFD = HlsFD(ie, {})
    assert hlsFD.ydl == ie
    assert hlsFD.params == {}
    assert hlsFD._prepare_url({'url': 'a', 'ie_key': 'b'}, 'c') == 'a'

# Generated at 2022-06-12 16:51:00.637929
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import youtube_dl
    params = {
        'skip_fragments': True,
        'test': True,
        'quiet': True,
        'outtmpl': '%(id)s.%(ext)s',
        'fragment_retries': 2,
        'skip_unavailable_fragments': False
    }
    with youtube_dl.YoutubeDL(params) as ydl:
        HlsFD(ydl, params).real_download('', {'url': 'http://example.com/path/to/m3u8'})

# Generated at 2022-06-12 16:51:10.008519
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys

    from . import FileDownloader
    from .external import ExternalFD
    ydl = FileDownloader({
        'noprogress': True,
        'writethumbnail': False,
        'quiet': True,
        'format': 'best',
    })
    ydl.cache.remove()
    fd = HlsFD(ydl, {'format': 'best'})
    assert fd.handle is None
    assert fd._ready is False
    assert fd.total_frags == 0
    assert fd.pending_frags == 0
    assert fd.fragment_index == 0
    assert isinstance(fd._ffmpeg_fd, ExternalFD)
    assert fd._ffmpeg_fd.handle is None
    assert fd._ffmpeg_fd._ready is False

# Generated at 2022-06-12 16:51:11.398961
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """Test constructor of HlsFD"""
    # TODO

# Generated at 2022-06-12 16:51:24.610970
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import YoutubeDL
    from ..compat import compat_http_server
    from ..extractor import common as cmn
    from ..utils import create_http_server_handler

    orig_stdout = cmn.stdout
    orig_stderr = cmn.stderr


# Generated at 2022-06-12 16:51:35.210852
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_url = 'http://example.net/test.m3u8'
    manifest = '#EXTM3U\n' \
               '#EXT-X-KEY:METHOD=NONE\n' \
               '#EXTINF:10.000,\n' \
               '1.ts'
    ydl = FakeYdl(params=dict())
    ydl.urlopen = lambda url: FakeUrl(url, manifest)

    class FakeInfoDict(dict):
        def __init__(self, url):
            self.url = url

    info_dict = FakeInfoDict(test_url)
    hlsfd = HlsFD(ydl, ydl.params)
    assert hlsfd.can_download(manifest, info_dict)

# Generated at 2022-06-12 16:51:44.896810
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import re
    url = 'https://vodhls-uk-live.akamaized.net/hls/live/2002310/s2/index.m3u8'
    #url = 'http://localhost/hls.m3u8'
    ydl = 'test'
    params = {}
    HlsFD(ydl, params)
    #HlsFD.real_download('filename', {'url': url})

if __name__ == '__main__':
    test_HlsFD();

# Generated at 2022-06-12 16:51:48.106731
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testcases
    for test_in, expected in get_testcases('test_hlsFD'):
        result = HlsFD.real_download('filename', test_in)
        assert result == expected

# Generated at 2022-06-12 16:51:55.990591
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    class TestHlsFD(HlsFD):
        def __init__(self):
            self.test_lock = Lock()

        def _prepare_url(self, info_dict, url):
            return url

        def _download_fragment(self, ctx, frag_url, info_dict, headers):
            self.test_lock.acquire()
            try:
                assert 'http://frag' in frag_url
                assert 'Range' in headers
                assert headers['Range'] == 'bytes=10-13'
                self._append_fragment(ctx, b'1234567890abcdef')
                return True, None
            finally:
                self.test_lock.release()


# Generated at 2022-06-12 16:52:26.903047
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange
    from ..downloader import YoutubeDL

    class FakeYoutubeDL(YoutubeDL):
        def download(self, info_dict):
            assert info_dict.get('hls_url') == 'http://example.com/hls.m3u8'
            assert info_dict.get('http_headers')['Referer'] == 'http://youtube.com/fake'
            assert info_dict.get('format') == 'bestvideo+bestaudio'
            assert DateRange.from_str('20120101-20120101').is_in(info_dict.get('requested_date'))
            assert info_dict.get('fragment_base_url') == 'http://example.com/hls_frag/'
            assert info_dict

# Generated at 2022-06-12 16:52:38.895138
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    ydl = YoutubeIE()
    # A URL as used in Youtube tests

# Generated at 2022-06-12 16:52:53.140527
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..downloader import YoutubeDL
    from .fragment import get_fragment_retries

    FD_CLASS_NAME = 'HlsFD'

    # Dummy manifest to test
    dummy_manifest = """#EXTM3U
#EXT-X-TARGETDURATION:10
#EXT-X-VERSION:3
#EXT-X-MEDIA-SEQUENCE:0
#EXTINF:10.00000,
segment-0.ts
#EXTINF:10.00000,
segment-1.ts
#EXTINF:10.00000,
segment-2.ts
#EXTINF:10.00000,
segment-3.ts
#EXT-X-ENDLIST
    """

    # Dummy manifest to test

# Generated at 2022-06-12 16:53:04.766409
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():

    from .__main__ import _real_main
    from .__main__ import parseOpts
    from .__main__ import opts

    test_input_file = str(Path(__file__).parent / 'test_media/hls/manifest.m3u8')
    test_output_file = str(Path(__file__).parent / 'test_media/hls/out.ts')

    global opts
    try:
        opts, _ = parseOpts(['-f', 'hlsnative', '-o', test_output_file, test_input_file])
        _real_main()
    except:
        raise

    outstr = str(Path(test_output_file).read_bytes())


# Generated at 2022-06-12 16:53:14.568606
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .tests.test_downloader import GetFileDownloader
    expected = b'\x08\x00\x00\x00\x00\x00\x00\x00'
    hls_args = {
        'outtmpl': '%(id)s.%(ext)s',
        'format': '3',
        'fragment_retries': 0,
        'skip_unavailable_fragments': 'false',
        'test': True
    }
    ydl = GetFileDownloader(hls_args, {'ydl_total_frags': 1})
    fd = HlsFD(ydl, hls_args)

# Generated at 2022-06-12 16:53:18.543992
# Unit test for constructor of class HlsFD
def test_HlsFD():

    # Test constructors
    HlsFD_inst = HlsFD(None, None)
    assert HlsFD_inst is not None

    return True


# Generated at 2022-06-12 16:53:20.330173
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD = HlsFD()
    assert(HlsFD)


# Generated at 2022-06-12 16:53:31.431042
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors
    import itertools
    import os
    import glob

    def parse_manifest(man_path, extractors):
        with open(man_path) as man_file:
            man_content = man_file.read()
        for ie in extractors:
            # Necessary so that extractor does not have to have any video present
            ie.suitable = lambda url: True
            ie.report_extraction = lambda url: None
            info_dict = ie.extract(man_content)
            if info_dict is None:
                continue
            info_dict['url'] = man_content
            return info_dict
        return None


# Generated at 2022-06-12 16:53:34.438566
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import FakeYDL
    from .test_fragment import test_FragmentFD_real_download

    ydl = FakeYDL()
    fd = HlsFD(ydl)
    test_FragmentFD_real_download(fd)

# Generated at 2022-06-12 16:53:41.079700
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .utils import MockYDL

    test_values = {
        'url': 'http://www.youtube.com/watch?v=BaW_jenozKc',
        'playlist_index': 0,
        'fragment_index': 1,
        'expected_fragment_filename': 'BaW_jenozKc-frag-0002.ts',
        'expected_fragment_contents': 'YTD\x00\x00\x00\x01',
        'expected_fragment_content_type': 'video/mp2t',
    }
    test_values.update(test_values['url'])
    mock_ydl = MockYDL()
    mock_ydl.params['test'] = True
    mock_ydl.params['fragment_retries'] = 0
   

# Generated at 2022-06-12 16:54:40.094048
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_fd = HlsFD(None, None)
    assert hls_fd.FD_NAME == 'hlsnative'


# Generated at 2022-06-12 16:54:41.374091
# Unit test for constructor of class HlsFD
def test_HlsFD():
    print("Testing: HlsFD")
    HlsFD()



# Generated at 2022-06-12 16:54:51.893627
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os.path
    import tempfile
    import unittest
    import yaml  # pyyaml
    from .downloader import YoutubeDL

    # Helper classes used in the unit test
    class MockYdlFileFD(object):
        def __init__(self, filename):
            self.name = filename

    class MockYdlUrlOpen(object):
        def __init__(self, ydl):
            self.ydl = ydl
            self.urls = []

        def add_url(self, filename):
            self.urls.append(filename)

        def geturl(self):
            return 'https://example.com'

        def read(self):
            if self.urls:
                return open(self.urls.pop(0), 'rb').read()

# Generated at 2022-06-12 16:55:02.384029
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import json
    import subprocess

    if not can_decrypt_frag:
        return

    def testHlsFD(manifest, info_dict):
        tempdir = tempfile.mkdtemp()
        fd = HlsFD(None, None)
        for ph in fd._progress_hooks:
            ph.temp_names[tempdir] = os.path.join(tempdir, 'video')
        fd.real_download(os.path.join(tempdir, 'video'), info_dict)
        return fd._progress_hooks[0].temp_names[tempdir]


# Generated at 2022-06-12 16:55:14.995194
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .test_utils import FakeYDL
    from .common import _MinimalYoutubeDl

# Generated at 2022-06-12 16:55:23.935619
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import re

    class FakeYDL:
        class params:
            get = lambda *args: None
            fragment_retries = 3

        urlopen = classmethod(lambda *args: None)

    def assert_can_download(manifest, is_live, expected):
        info_dict = dict(url='', is_live=is_live)
        assert HlsFD.can_download(manifest, info_dict) == expected, (
            'Failed for manifest: %s' % manifest)

    # Not encrypted
    assert_can_download('#EXTM3U', False, True)
    # Encrypted with AES-128 (supported)
    assert_can_download('#EXTM3U\n'
                        '#EXT-X-KEY:METHOD=AES-128',
                        False, True)
    # Encrypted with

# Generated at 2022-06-12 16:55:30.003752
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .utils import _extract_from_m3u8
    import tempfile
    from .downloader import YoutubeDL

    def test_helper(url, filename):
        ydl = YoutubeDL({'outtmpl': '-', 'hls_use_mpegts': False})
        dl = lambda: _extract_from_m3u8(ydl, url)
        with tempfile.NamedTemporaryFile() as f:
            dl()
            with open(filename, 'rb') as f2:
                f.write(f2.read())
            dl()
            assert f.tell() == os.path.getsize(filename)


# Generated at 2022-06-12 16:55:41.087436
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..downloader import Downloader
    class MockIE(InfoExtractor):
        def __init__(self, downloader=None, ie_key=None, ie_name=None, ie_url=None, search_key=None, default_search=None, is_playlist=False):
            super(MockIE, self).__init__(downloader, ie_key, ie_name, ie_url, search_key, default_search, is_playlist)

    # Constructor should set the correct 'ie_key' value.
    dl = Downloader()
    info_dict = {'url': 'dummy'}
    fd = HlsFD(dl, {'ie_key': 'test'}, info_dict)
    assert fd.ie is None
    f

# Generated at 2022-06-12 16:55:51.801353
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .fragment import FragmentFD

    class FakeYDL:
        def __init__(self, params):
            self.params = params

    tests_params = [
        {'live': False},
        {'live': True},
    ]

    # YouTube
    for test_params in tests_params:
        ydl = FakeYDL(test_params)
        fd = HlsFD(ydl, test_params)

# Generated at 2022-06-12 16:56:01.156347
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-12 16:58:27.561585
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import unittest

    test_dir = os.path.dirname(__file__)
    test_dir = os.path.join(test_dir, 'youtube', 'tests', 'data')
    fake_ydl = FakeYDL()
    fake_ydl.params = {}
    fake_ydl.params['fragment_retries'] = 1
    fake_ydl.extract_info = lambda _: None
    fake_ydl.add_default_info_extractors = lambda: None
    fake_ydl.report_warning = lambda msg: print(msg)
    fake_ydl.report_error = lambda msg: print(msg)
    fake_ydl.urlopen = lambda url: urlhandle(url)


# Generated at 2022-06-12 16:58:39.515158
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n', {'is_live': True}) is False
    assert not HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-KEY:METHOD=NONE\n'
        'http://example.com/segment.ts',
        {'is_live': False})
    assert HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-KEY:METHOD=AES-128\n'
        'http://example.com/segment.ts',
        {'is_live': False}) is False

# Generated at 2022-06-12 16:58:46.269541
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import re
    import shutil
    import tempfile
    import unittest
    import xml.etree.ElementTree as ET
    from six.moves import configparser
    from six.moves.urllib.parse import urljoin
    from six.moves.urllib.request import pathname2url
    from six.moves.urllib.error import HTTPError
    from six.moves import mock

    from .stream import Stream

    from ..extractor.hls import HlsFD
    from ..compat import (
        compat_http_client,
        compat_urllib_error,
        compat_urllib_request,
        compat_urlparse,
        compat_str,
    )
