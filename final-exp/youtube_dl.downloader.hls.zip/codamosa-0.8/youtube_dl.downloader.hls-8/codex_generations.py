

# Generated at 2022-06-12 16:49:29.546066
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():

    import os
    import tempfile
    import shutil
    import pytest

    # Run the test in a temporary directory
    # where we can create temporary files
    temp_dir = tempfile.mkdtemp()
    curr_dir = os.getcwd()
    os.chdir(temp_dir)

    # Create the test directory
    os.makedirs('src/ytdl_files')
    os.chdir('src/ytdl_files')

    # Create the required test files
    with open('video1.frag', 'w') as f:
        f.write('Hello World')

    with open('video2.frag', 'w') as f:
        f.write('')

    with open('video3.frag', 'w') as f:
        f.write('')


# Generated at 2022-06-12 16:49:42.216823
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os, sys, shutil
    from pprint import PrettyPrinter
    from ydl.YoutubeDL import YoutubeDL
    from ydl.extractor.common import InfoExtractor
    from .testutils import FakeYDL, FakeInfoExtractor, FakeFD
    from .testutils import gettestcases, gettestcases_playlist
    from .testutils import load_testdata, load_testdata_playlist
    from .testutils import Mock, patch

    test_cases = gettestcases(FD_NAME, ['testid', 'playlist'])
    test_playlist_cases = gettestcases_playlist(FD_NAME)

    for input, expected_output in load_testdata(test_cases):
        test_id, playlist_test = input
        if playlist_test:
            continue

# Generated at 2022-06-12 16:49:54.037851
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_cases = [
        # url, params, expected_return_value, expected_ctx
        ('https://example.com/m3u8_with_ads.m3u8',
         {'skip_unavailable_fragments': True,
          'fragment_retries': 0,
          'test': True
         },
         True,
         {
             'filename': None,
             'total_frags': 8,
             'ad_frags': 7,
             'fragment_index': 0,
             'codecs': [],
             'fragment_base_url': 'https://example.com/',
             'fragment_filename': '%(fragment_index)s.m4s',
             'frag_content': ()
         }
        ),
    ]


# Generated at 2022-06-12 16:50:00.127097
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Test with ffmpeg not installed
    HlsFD.need_ffmpeg = False
    try:
        # Test with incomplete hls manifest
        HlsFD.can_download(manifest=b'#EXT-X-VERSION:', info_dict={})
        assert False
    except ValueError:
        pass

# Generated at 2022-06-12 16:50:03.998929
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """
    Constructor of class FragmentFD
    """
    Manifest = HlsFD(None, None)
    # Test with invalid manifest
    assert Manifest.can_download('invalid manifest', None) == False
    # Test with valid manifest
    assert Manifest.can_download('#EXTM3U', None) == True

# Generated at 2022-06-12 16:50:10.319062
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    import pytest
    from youtube_dl.downloader.external.ffmpeg import FFmpegDownloader
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DownloadError

    class FakeYDL:
        def __init__(self, params):
            self.params = params
            self.http_headers = params.get('http_headers', {})

        def report_warning(self, msg):
            pass

        def to_screen(self, msg):
            pass

        def urlopen(self, url):
            class FakeUrl:
                def geturl(self):
                    return url

                def read(self):
                    return b'#EXTM3U\n#EXT-X-BYTERANGE:10@3\n\nfragment'

            return FakeUrl()


# Generated at 2022-06-12 16:50:12.248391
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_fd = HlsFD(None, None)
    assert hls_fd.can_download(None, None) is True

# Generated at 2022-06-12 16:50:18.089773
# Unit test for constructor of class HlsFD

# Generated at 2022-06-12 16:50:24.861037
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('', {}) is True
    assert not HlsFD('test').test(
        'http://s3.amazonaws.com/Akamai_TestVid/BigBuck.m3u8')
    assert HlsFD('test').test(
        'http://download.tsi.telecom-paristech.fr/gpac/DASH_CONFORMANCE/TelecomParisTech/mp4-live-rm-frag/mp4-live-rm-frag_metadata.m3u8')
    assert HlsFD('test').test(
        'http://download.tsi.telecom-paristech.fr/gpac/DASH_CONFORMANCE/TelecomParisTech/mp4-live-frag/mp4-live-frag_metadata.m3u8')

# Generated at 2022-06-12 16:50:34.789950
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    ie = YoutubeIE()
    t_url = 'https://youtu.be/BaW_jenozKc'
    t_fmt_list = ie._get_available_formats(ie._download_webpage(t_url, None, note='Downloading video info webpage'))
    for t_fmt in t_fmt_list:
        print('%s: %s' % (t_fmt, t_fmt_list[t_fmt]))
        HlsFD(ie, {})

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:51:01.304074
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .extractor.generic import GenericIE
    from .downloader import Downloader
    from .compat import compat_urlparse
    from .utils import encode_base64
    from .extractor.common import InfoExtractor
    from .postprocessor import FFmpegMergerPP
    from .downloader import YoutubeDL

    class MockYoutubeDl(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDl, self).__init__(*args, **kwargs)
            self._cached_manifest_file = None
            self._cached_manifest_urlh = None
            self._cached_manifest_url = None

        def to_screen(self, *args, **kwargs):
            pass


# Generated at 2022-06-12 16:51:04.305028
# Unit test for constructor of class HlsFD
def test_HlsFD():
    u = 'https://example.com/video.mkv'
    ydl = {'params': {}}
    downloader = {'ydl': ydl}
    HlsFD(downloader, ydl)

# Generated at 2022-06-12 16:51:16.673869
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import shutil
    import tempfile

    from .common import FakeYDL

    root_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 16:51:29.947900
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import unittest
    from io import BytesIO
    from io import StringIO
    import tempfile
    from .mock_http_server import MockHttpServer
    from .mock_server_handler import MockServerHandler

    import youtube_dl.extractor.generic
    try:
        from ..utils import IsolatedAsyncHTTPClient
    except ImportError:
        from .testsuite.test_utils import IsolatedAsyncHTTPClient

    def build_http_server_handler(code, headers, content):
        def get_response(self):
            host = self.headers['Host']
            self.send_response(code)
            for k, v in headers.items():
                self.send_header(k, v)
            self.send_header('Connection', 'close')
            self.end_headers()

# Generated at 2022-06-12 16:51:34.416174
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, {'playlist_item': {'url': 'http://www.example.com'}, 'playlist_items': [{'url': 'http://www.example.com/1'}, {'url': 'http://www.example.com/2'}]})

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:51:38.457605
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import YoutubeDL
    ydl = YoutubeDL()

    # Test HlsFD can be constructed
    hls_fd = HlsFD(ydl, {})

# Generated at 2022-06-12 16:51:50.976581
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from youtube_dl.utils import *
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_urlparse
    from .external import FFmpeg
    class MyHlsFD(HlsFD):
        def __init__(self, ydl):
            self.ydl = ydl
        def _download_fragment(self, ctx, frag_url, info_dict, headers):
            return True, self.ydl.urlopen(self._prepare_url({'http_headers': headers}, frag_url)).read()
        def _prepare_url(self, args, url):
            return compat_urlparse.urljoin('http://base-url.test/', url)

# Generated at 2022-06-12 16:51:57.339049
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import FakeYDL
    from .test_fragment import _prepare_and_start_frag_download
    from .test_fragment import _append_fragment
    from .test_fragment import _finish_frag_download
    from .test_fragment import _download_fragment
    from .test_fragment import _prepare_url

    # Use this as the size of the fragments
    fragment_size = 512
    max_count = 6
    count = 0

    # Create the fake ydl object that is passed to HlsFD.real_download
    ydl = FakeYDL()

# Generated at 2022-06-12 16:52:08.945647
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..postprocessor.common import PostProcessor
    from ..extractor import get_info_extractor
    from ..utils import encodeFilename, clean_html
    try:
        from unittest.mock import MagicMock, patch
    except ImportError:
        from mock import MagicMock, patch
    def _mock_callback(d):
        pass
    def _mock_hook(d):
        pass
    def _mock_get_info_extractor(ie_key, ie_url):
        return MagicMock(spec=get_info_extractor(ie_key, ie_url))

# Generated at 2022-06-12 16:52:15.843424
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """ Test method HlsFD.real_download """
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.utils

    test_dir = os.path.join(os.path.dirname(__file__), 'test')

    youtube_dl.utils.get_exe_version = lambda x: '201602121234'
    for test in os.listdir(test_dir):
        if not test.endswith('.txt'):
            continue
        test_name = os.path.splitext(test)[0]
        print(('Testing %s' % test_name))
        infos = {}
        arch = open(os.path.join(test_dir, test_name, 'in.txt'), 'rb')
        while True:
            line

# Generated at 2022-06-12 16:52:55.233508
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..utils import make_HTTPServer
    from ..extractor import GenericIE
    import tempfile

    server = make_HTTPServer()

# Generated at 2022-06-12 16:53:08.045052
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .http import HTTPFD
    from .html import HTMLFD
    from .dash import DashFD

    test_cases = [
        # Simple HTTP URL for a playlist
        (
            'http://example.com/playlist.m3u8',
            HTTPFD,
        ),
        # An absolute path, it should still be HTTP
        (
            '/playlist.m3u8',
            HTTPFD,
        ),
        # Some other URL, it should be HTML
        (
            'https://example.com/video?id=1',
            HTMLFD,
        ),
        # A DASH manifest URL
        (
            'https://example.com/dash.mpd',
            DashFD,
        ),
    ]


# Generated at 2022-06-12 16:53:16.150422
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test_fragment import TestFD
    from ..compat import urlretrieve
    from ..extractor.common import InfoExtractor
    from copy import copy
    from os import remove
    from sys import stderr
    # We must mock urlretrieve function to not download the fragment.
    # Since we have already downloaded it.
    def mock_urlretrieve(url, filename, reporthook=None, data=None):
        return (open(url.split('/')[-1], 'rb'), None)

    # We must mock download method of YoutubeDL object
    # to not download the manifest.
    # Since we have already downloaded it.
    def mock_download(params):
        return params

    extractor = InfoExtractor('foo')
    extractor._real_initialize()

# Generated at 2022-06-12 16:53:22.462765
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import youtube_dl
    import sys
    YoutubeDL = youtube_dl.YoutubeDL
    HlsFD = youtube_dl.downloader.hls.HlsFD
    ydl = YoutubeDL({})
    hls_fd = HlsFD(ydl, {})
    assert isinstance(hls_fd, HlsFD)

# Generated at 2022-06-12 16:53:33.521230
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test_utils import FakeYdl

    ydl = FakeYdl()
    ydl.add_progress_hook((lambda x, y, z: None))
    ydl.params = {'test': 'true'}

    filename = 'filename'
    info_dict = {
        'url': 'url',
        'http_headers': {'Accept': 'text/html'},
        'fragment_base_url': 'fragment_base_url',
        '_decryption_key_url': '_decryption_key_url',
        'extra_param_to_segment_url': 'extra_param_to_segment_url',
    }

    fd = HlsFD(ydl, ydl.params)

    # Test handling of unsupported features

# Generated at 2022-06-12 16:53:44.857201
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download(): # pylint: disable=invalid-name

    import os.path
    import tempfile
    import shutil
    from .external import ExternalFD

    from ..utils import encodeFilename
    from ..compat import urllib_request

    from .test_HlsFragmentsFD import mock_urlopen_for_test, with_urlopen_mock

    test_dir = tempfile.mkdtemp(prefix='youtube-dl_test_hlsNative_')

# Generated at 2022-06-12 16:53:54.882385
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .http import HttpFD
    from ..extractor.generic import GenericIE

    # Create a HttpFD instance
    class FakeYdl(object):
        def __init__(self):
            self.params = {}

        def urlopen(self, url):
            return HttpFD()._download_webpage(url, self.params)

    ydl = FakeYdl()
    params = {'test': True}
    ydl.params.update(params)

    # Create a HlsFD instance using the HttpFD instance
    hls_fd = HlsFD(ydl, params)

    # Create a GenericIE instance to extract the hls manifest
    generic_ie = GenericIE()

# Generated at 2022-06-12 16:54:01.998999
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os.path
    import sys
    from .extractor.generic import GenericIE
    from ..utils import DownloadRetry
    from ..compat import (
        compat_urllib_request,
    )


# Generated at 2022-06-12 16:54:13.257956
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .fragment import FragmentFD
    from .fragment import FragmentFD
    from .fragment import FragmentFD
    from .fragment import FragmentFD


# Generated at 2022-06-12 16:54:19.320445
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from youtube_dl.utils import DateRange
    from .extractor.common import InfoExtractor
    from .downloader import FileDownloader
    from .utils import DateRange
    downloader = FileDownloader({})
    downloader.add_info_extractor(InfoExtractor(downloader))
    downloader.params.update({'hls_use_mpegts': True, 'format': 'mp4'})
    extractor = downloader.IE_NAME_TO_CLASS['HlsFD'](downloader)
    url = 'https://bitdash-a.akamaihd.net/content/MI201109210084_1/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8'

# Generated at 2022-06-12 16:55:27.957150
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import format_bytes
    from ..compat import compat_str
    from .test_fragment_downloader import _test_downloader
    ie = InfoExtractor('test_ie', 'test_id')


# Generated at 2022-06-12 16:55:39.739371
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """
    This test checks if HlsFD class is able to download the m3u8 file
    """
    import os
    import unittest
    import tempfile
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DownloadError
    import youtube_dl.utils.logger as logger

    logger.disabled = True
    logger.error_count = 0
    class DummyInfoDict:
        def get(self, key, default=None):
            return None

    here = os.path.dirname(__file__)
    outdir = tempfile.mkdtemp(prefix='youtubedltest_')

# Generated at 2022-06-12 16:55:44.436088
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    from .utils import _ExtractorTest
    from .common import InfoExtractor

    class _HlsFD(_HlsFD, InfoExtractor):
        @classmethod
        def suitable(cls, url):
            return False

        def __init__(self, ydl, params):
            super(_HlsFD, self).__init__(ydl, params)

    class _TestHlsFD(_HlsFD):
        @classmethod
        def suitable(cls, url):
            return True

    sys.modules['youtube_dl.extractor.hlsnative'] = sys.modules['__main__']

# Generated at 2022-06-12 16:55:54.893268
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import tempfile
    import os
    import time
    import shutil
    import sys
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from youtube_dl.extractor.generic import DownloadError
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.postprocessor.ffmpeg import FFmpegPostProcessor
    from youtube_dl.cache import Cache
    from youtube_dl.compat import (
        compat_urllib_request,
        compat_urllib_error,
        compat_http_client,
        compat_struct_pack,
    )
    from .common import FakeYDL


# Generated at 2022-06-12 16:56:05.371568
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    class InfoDict(dict):
        def __init__(self, manifest_url, manifest_content, http_headers, decryption_key_url):
            super(dict, self).__init__()
            self['url'] = manifest_url
            self['http_headers'] = http_headers
            self['_manifest_content'] = manifest_content
            self['_decryption_key_url'] = decryption_key_url

    class TestYDL:
        def __init__(self, manifest_url, manifest_content, http_headers, decryption_key_url):
            self.info_dict = InfoDict(manifest_url, manifest_content, http_headers, decryption_key_url)

        def urlopen(self, url):
            return self

        def geturl(self):
            return self.info_

# Generated at 2022-06-12 16:56:15.469981
# Unit test for constructor of class HlsFD

# Generated at 2022-06-12 16:56:18.093482
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_fd = HlsFD('test_ydl')
    assert hls_fd.FD_NAME == 'hlsnative'


if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:56:24.156731
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():

    FD = HlsFD({})
    assert FD.can_download('#EXTM3U', {}) is True
    assert FD.can_download('#EXT-X-KEY:METHOD=ABCD', {}) is False
    assert FD.can_download('#EXT-X-BYTERANGE', {}) is False
    assert FD.can_download('#EXT-X-KEY:METHOD=AES-128', {}) is True
    assert FD.can_download('#EXT-X-KEY:METHOD=AES-128\n#EXT-X-BYTERANGE', {}) is False
    assert FD.can_download('#EXT-X-MEDIA-SEQUENCE:1', {}) is False
    assert FD.can_download('#EXT-X-PLAYLIST-TYPE:EVENT', {}) is False
    assert FD.can_download

# Generated at 2022-06-12 16:56:33.799463
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    sys.path.append('..')
    import youtube_dl
    opts = {}
    ydl = youtube_dl.YoutubeDL(opts)
    # this is a test manifest in order to make sure the downloader has been
    # selected and that it works. It has been taken from a real video.
    info_dict = {
        'url': 'http://127.0.0.1/fakeurl',
        'num_fragments': 2,
        '_duration': 10.0,
    }
    class FakeUrlopen:
        def __init__(self):
            self.real_url = 'http://127.0.0.1/test.m3u8'
        def geturl(self):
            return self.real_url

# Generated at 2022-06-12 16:56:43.431452
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """ Testing downloading single file in download method of HlsFD"""
    import tempfile
    import urllib.request
    import io

    test_file = io.BytesIO()
    # this data is fixed because the fragment index to download is set to 0 (one fragment only)
    test_file.write(b"""#EXTM3U
#EXT-X-VERSION:3
#EXT-X-MEDIA-SEQUENCE:0
#EXT-X-TARGETDURATION:10

#EXTINF:10, no desc
media-b0_0.ts
#EXT-X-ENDLIST
""")
    test_file.name = 'media.m3u8'
    test_file.seek(0)
