

# Generated at 2022-06-12 16:49:17.405072
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import FakeYDL
    import os
    class FakeSegmentFD(FragmentFD):
        # This test only cares about testing HlsFD and not if FragmentFD
        # functions properly on its own.
        def _download_fragment(self, ctx, frag_url, info_dict, headers):
            return True, frag_url.encode('utf-8')

    class FakeFFmpegFD(FFmpegFD):
        def check_supported(self, info_dict):
            assert False, 'Real FFmpeg download attempted'

    def mock_open(name, mode='r'):
        return FakeYDL(name, mode)

    ydl = FakeYDL()
    ydl.urlopen = mock_open
    ydl.build_opener = mock_open

# Generated at 2022-06-12 16:49:22.395882
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import common
    class MyYoutubeDL(object):
        def __init__(self, params):
            self.params = params or {}
            self.cache = {}
        def to_screen(self, s):
            pass
        def trouble(self, s, tb=None):
            raise Exception(s)
        def report_error(self, s):
            raise Exception(s)
        def report_warning(self, s):
            self.trouble(s)
        def extract_info(self, url, download=None):
            if not download:
                download = lambda *args: (True, '')

# Generated at 2022-06-12 16:49:33.856159
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import try_get

    extra_param_to_segment_url = 'param1=val&param2=val'
    url = 'http://example.com/manifest.m3u8'
    info = InfoExtractor()._download_webpage(url, 'test', {'extra_param_to_segment_url': extra_param_to_segment_url})
    info_dict = try_get(info, lambda x: x['info_dict'], dict)
    HlsFD(None, {}).real_download('', info_dict).encode('utf-8')

# Generated at 2022-06-12 16:49:46.854053
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-12 16:49:57.469295
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import io
    import re
    import os
    import sys
    from unittest import TestCase
    from .test_download import FakeYdl
    from .test_download import (
        BaseTestDownload,
        match_regex,
        FakeFile,
        NO_DEFAULT,
    )
    from .test_download import DummyFileDownloader as DummyFD
    from .test_download import TEMPDIR
    from .test_download import USER_AGENT
    from .test_download import END_MARK
    from .test_download import TEST_FILES_DIR
    from .test_download import ask_for_confirmation
    from .test_download import skip_if
    from .test_download import test_render_method

# Generated at 2022-06-12 16:50:05.013875
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import os
    import tempfile
    import unittest
    from ..compat import decode_compat_str
    from ..extractor import YoutubeDL

    class HlsFDTester(unittest.TestCase):
        def test_HlsFD(self):
            with tempfile.NamedTemporaryFile(suffix='.mp4') as otf:
                ydl = YoutubeDL({
                    'outtmpl': decode_compat_str(otf.name),
                    'quiet': True,
                    'skip_download': True,
                })
                res = ydl.extract_info('https://example.org/index.m3u8', download=False)
                self.assertEqual('hlsnative', res['protocol'])

    unittest.main()
    

# Generated at 2022-06-12 16:50:13.032534
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    from .downloader import external_downloader, FakeYDL
    from .extractor import gen_extractors
    from .common import FakeHttpServer
    from .fragment import FragmentFD


# Generated at 2022-06-12 16:50:21.060387
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import sys
    import unittest
    import subprocess
    from .test_file import test_file, TestFile

    # Date: 2016-10-24
    # Last date: 2017-03-21
    # URL: https://bitdash-a.akamaihd.net/content/MI201109210084_1/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8
    # Manifest:
    #     #EXTM3U
    #     #EXT-X-VERSION:3
    #     #EXT-X-TARGETDURATION:39
    #     #EXT-X-MEDIA-SEQUENCE:0
    #     #EXTINF:8,
    #     #EXT-X

# Generated at 2022-06-12 16:50:22.733612
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:50:35.318354
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import common
    from ..utils import encode_data_uri
    def can_download(manifest):
        ydl = common.YoutubeDL()
        info_dict = {'url': 'http://localhost/'}
        return HlsFD.can_download(manifest, info_dict)

    # Test AES-128 non-fragmented
    manifest = encode_data_uri('application/vnd.apple.mpegurl', '#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="https://example.com/key"\n#EXTINF:10,\nhttps://example.com/segment')
    assert can_download(manifest) == can_decrypt_frag
    # Test AES-128 fragmented

# Generated at 2022-06-12 16:50:59.262116
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test.helper import check_output_file
    from .test.test_HlsFD import test_HlsFD_real_download as hlsfd_test
    from .test.test_HlsFD import test_download_hls_with_byterange as hls_byterange_test
    hlsfd_test(HlsFD)
    hls_byterange_test(HlsFD)
    # Test with an encrypted video
    filename = check_output_file(HlsFD, 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8')
    assert filename is not None

# Generated at 2022-06-12 16:51:08.962520
# Unit test for constructor of class HlsFD

# Generated at 2022-06-12 16:51:22.438472
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .downloader import get_suitable_downloader
    from .extractor import get_info_extractor
    from .common import InfoExtractor
    from .utils import compat_urlparse

    class MockYtdl(object):
        def __init__(self, url):
            self.params = {'hls_prefer_native': True}
            self.urlopen = urlopen_mock
            self.url = url
            self.IE_NAME = 'MockIE'
            self.ie = get_info_extractor(self.IE_NAME)
            self.ie._set_info_extractor(MockIE)

    def urlopen_mock(self, url):
        return compat_urlopen(url)

    class MockIE(InfoExtractor):
        _VALID_URL = r'.*'
       

# Generated at 2022-06-12 16:51:33.807181
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    from .test_utils import FakeYDL
    from .test_utils import FakeUrlFD
    from urllib.error import HTTPError
    from urllib.parse import urljoin

    ydl = FakeYDL()
    ydl.params.update({
        'noprogress': True,
        'quiet': True
    })

    def fake_urlopen(request):
        assert(request.full_url == urljoin('http://test.com/m3u8/', 'index.m3u8'))

# Generated at 2022-06-12 16:51:48.056377
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Import only here to speed up normal downloads.
    # See https://github.com/ytdl-org/youtube-dl/issues/27371
    from ..extractor.common import InfoExtractor
    from ..utils import FakeYDL
    ie = InfoExtractor('test-id')
    ie.params = {
        'daterange': {
            'start_date': ''
        }
    }
    ie.to_screen = lambda *args, **kargs: None
    ie._downloader = FakeYDL()
    hls = HlsFD(ie._downloader, {})

# Generated at 2022-06-12 16:51:55.553052
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testdata
    from ..utils import unescape_html

    real_download = HlsFD.real_download
    params = {'noprogress': True, 'youtube_include_dash_manifest': False, 'outtmpl': '%(id)s.%(ext)s', 'nopart': True}

# Generated at 2022-06-12 16:52:06.051995
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    frag_index = 0
    expected_frags = [
        'كيف تحصل على اللعبة',
        'https://example.com/frag-1.ts',
        'https://example.com/frag-2.ts',
        'https://example.com/frag-3.ts',
        'https://example.com/frag-4.ts',
    ]
    for frag_url in expected_frags:
        frag_index += 1
        frag_content = frag_url.encode('utf-8') + b'\n\n'
        yield frag_content, frag_index


# Generated at 2022-06-12 16:52:17.961842
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import youtube_dl.FileDownloader
    import youtube_dl.extractor

    def download():
        """
        The method download requires the following parameters:
        :param filename: name of the file
        :param info_dict: dictionary holding information such as url and others
        :return: True if file was downloaded, False otherwise
        """
        # The object is created with only parameters the method requires
        test_FD = HlsFD(ydl, params)
        pl = {'fragments': [{'url': 'url1', 'raw': True},
                            {'url': 'url2', 'raw': True},
                            {'url': 'url3', 'raw': True}]}

# Generated at 2022-06-12 16:52:26.171512
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # pylint: disable=R0914

    import os
    import base64
    import tempfile
    import shutil

    from ..extractor.generic import GenericIE
    from ..extractor.youtube import YoutubeIE

    from .common import is_outdated_version, get_testdata_files_dir
    from .downloader import _download_from_url

    _download_from_url(os.path.join(get_testdata_files_dir(), 'youtube-dl.py'), 'https://yt-dl.org/downloads/2016.11.26/youtube-dl.py')

    if is_outdated_version('2016.11.26'):
        print('Skipping HlsFD_real_download test due to being an outdated version')
        return


# Generated at 2022-06-12 16:52:38.273161
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .downloader import YoutubeDL
    from .extractor import gen_extractors
    import os

    ytdl_opts = {
        'format': 'bestvideo+bestaudio/best',
        'outtmpl': '%(id)s.%(ext)s',
        'writedescription': 'True',
        'writeinfojson': 'True',
        'writethumbnail': 'True',
        'writeautomaticsub': 'True',
        'writesubtitles': 'True',
        'allsubtitles': 'True',
    }


# Generated at 2022-06-12 16:53:14.947160
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    HlsFD.real_download(
        {
            'url': '',
            '_decryption_key_url': 'http://example.com/key',
            'extra_param_to_segment_url': '',
            'is_live': False,
        },
        {
            'url': 'http://example.com/index.m3u8',
            'http_headers': {},
            'test': True,
            'player_url': '',
            'fragment_base_url': 'http://example.com/',
        },
        'test_output.mp4',
    )

if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-12 16:53:27.490813
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..compat import compat_urllib_parse_unquote

    class HlsTestIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                    'url': url,
                    'format': 'hls',
                    'format_id': 'hls-live',
                    'ext': 'mp3',
                    'filesize': 1024,
                    'duration': 5,
                    'abr': 128,
                    'tbr': 256,
                }

    ie = HlsTestIE()
    ie.widget = YoutubeDL(ie._downloader.params)
    ie.params = ie._downloader.params
    ie.report_warning = lambda msg: None  # Ignore warnings

# Generated at 2022-06-12 16:53:36.380885
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        from youtube_dl.extractor import CommonIE
        from youtube_dl.downloader.http import HttpFD
    except ImportError as e:
        e.args += ('Please do not use ExYoutubeDL.',)
        raise
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DownloadError
    from youtube_dl.PostProcessor import PostProcessor

    class FakeYDL(YoutubeDL):
        def process_ie_result(self, ie_result):
            # Forbid calling of the downloader
            if ie_result and ie_result.get('_type', None) == 'url':
                raise DownloadError('TESTING')
            return super(FakeYDL, self).process_ie_result(ie_result)

# Generated at 2022-06-12 16:53:37.412874
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass

# Generated at 2022-06-12 16:53:49.565550
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-12 16:53:58.705998
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import pytest
    from tempfile import NamedTemporaryFile
    from ..utils import (
        encodeFilename,
        read_json_file,
        remove_quotes,
    )

    # Check that HlsFD.real_download creates an expected output file and returns True
    def func_test_HlsFD_real_download(test_file, output_file_path, output_file_size, content_len, expected_file_output, expected_return_value):
        print("\nTest_file:")
        print(test_file)
        print("\nExpected_file_output:")
        print(expected_file_output)
        # Arrange
        fd = HlsFD({'ydl': 1}, {'test': True, 'skip_unavailable_fragments': True})
        info

# Generated at 2022-06-12 16:54:11.500495
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert can_decrypt_frag


# Generated at 2022-06-12 16:54:22.158630
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import shutil
    import tempfile
    from .downloader import FileDownloader
    from .cache import CacheManager


# Generated at 2022-06-12 16:54:32.135308
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    from .test_fragment import TestFragmentFD
    class TestHlsFD(TestFragmentFD, HlsFD):
        def __init__(self, *args, **kwargs):
            super(TestHlsFD, self).__init__(*args, **kwargs)
            self._hooks = {}

        def _download_fragment(self, *args, **kwargs):
            return True, self._hooks['_download_fragment'](*args, **kwargs)

        def _prepare_url(self, *args, **kwargs):
            return self._hooks['_prepare_url'](*args, **kwargs)


# Generated at 2022-06-12 16:54:40.885802
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    import tempfile
    import os
    import sys
    if sys.version_info < (3, 6):
        pytest.skip('Incompatible Python: %s' % sys.version)
    try:
        from Crypto.Cipher import AES
    except ImportError:
        pytest.skip('Crypto not installed, can not run test')
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.hls import HlsFD

    # Test setup
    info_dict = {
        'url': 'http://example.com',
        'extra_param_to_segment_url': '',
    }
    ydl = YoutubeDL({'quiet': True, 'noprogress': True})
    fd = HlsFD(ydl, {})

    # Test can_

# Generated at 2022-06-12 16:55:53.207230
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    import os
    tmp_dir = os.path.join(os.path.dirname(__file__), 'yt-dl-hls-fd-tests')
    if not os.path.exists(tmp_dir):
        os.makedirs(tmp_dir)

# Generated at 2022-06-12 16:55:53.598311
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass

# Generated at 2022-06-12 16:56:02.026007
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import youtube_dl.YoutubeDL
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.hls import HlsFD
    from youtube_dl.version import __version__ as version
    ydl = YoutubeDL({'prefer_insecure': True, 'test': True, 'verbose': True})
    ydl.user_agent += ' ytdl/%s' % version
    ydl.add_default_info_extractors()
    if len(sys.argv) < 2:
        raise Exception('Expected at least one argument: the URL of a HLS manifest.')
    HlsFD.real_download(ydl, sys.argv[1])

# Generated at 2022-06-12 16:56:12.626667
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader

    ydl = FileDownloader()
    ydl.add_info_extractor(YoutubeIE())

    ydl.add_default_info_extractors()
    ydl.result_type = 'url'
    ydl.params['quiet'] = True
    result = ydl.extract_info('https://www.youtube.com/watch?v=7ZOaBtWV27U', download=False)
    assert result['url'] == 'https://www.youtube.com/watch?v=7ZOaBtWV27U'
    assert result['extractor'] == 'youtube:watch'

    file_dowloader = FileDownloader(params={'noprogress': True, 'quiet': True})
    file_

# Generated at 2022-06-12 16:56:14.449470
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD('/1', {})

# Unit tests for can_download() method of class HlsFD

# Generated at 2022-06-12 16:56:21.106917
# Unit test for constructor of class HlsFD
def test_HlsFD():
    p = 'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/gear1/fileSequence0.m3u8'
    p += '#http://example.com/fileSequence0##plain#frag1#hlsnative'
    p += '##http://example.com/fileSequence0##plain#frag2#hlsnative'
    p += '##http://example.com/fileSequence0##plain#frag3#hlsnative'
    p += '##http://example.com/fileSequence0##plain#frag4#hlsnative'
    p += '##http://example.com/fileSequence0##plain#frag5#hlsnative'

# Generated at 2022-06-12 16:56:31.881146
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    try:
        from cStringIO import cStringIO as BytesIO
    except Exception:
        from io import BytesIO
    from ..downloader.common import FileDownloader
    from ..utils import format_bytes

    URN = 'https://player.vimeo.com/external/159962941.m3u8?s=557a1c24b8f8fe3c3d2fad8004d4e852'

# Generated at 2022-06-12 16:56:38.390863
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import httplib
    import json
    import socket
    import tempfile
    import threading
    from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
    from os.path import isfile

    try:
        from Crypto.Cipher import AES
    except ImportError:
        AES = None

    from .utils import (
        HEADRequestHandler,
        encode_compat_str,
    )

    class HlsNativeServer(HTTPServer):
        """ Very basic HTTP server that can serve a HLS fragment """
        def __init__(self, data):
            HTTPServer.__init__(self, ('0.0.0.0', 0), lambda *a: None)
            self.data = data
            self.thread = threading.Thread(target=self.serve_forever)

# Generated at 2022-06-12 16:56:49.074856
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .http import HttpFD
    from .http import HttpFDTest
    from .http import HttpTestData

    # Test for hlsnative.HlsFD.__init__
    hlsnative_http_fd_test_obj = HttpFDTest(HttpTestData.URL, HttpTestData.ARGS)  # pylint: disable=abstract-class-instantiated
    hlsnative_obj = HlsFD(hlsnative_http_fd_test_obj.ydl, hlsnative_http_fd_test_obj.params)
    assert hlsnative_obj.ydl == hlsnative_http_fd_test_obj.ydl
    assert hlsnative_obj.params == hlsnative_http_fd_test_obj.params
    assert hlsnative_obj._fd is None

# Generated at 2022-06-12 16:57:00.499481
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import common
    from ..extractor.common import InfoExtractor
    from ..utils import download_json

    class TestIE(InfoExtractor):
        def _real_extract(self, url):
            return self.url_result(url, 'HlsFD')

    ie = TestIE()