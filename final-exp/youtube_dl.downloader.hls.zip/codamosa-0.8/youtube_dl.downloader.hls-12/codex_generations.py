

# Generated at 2022-06-12 16:49:22.845768
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXTINF:10,\nhttp://example.com/fileSequence0.ts\n#EXT-X-ENDLIST',
                              {'url': '',
                               'http_headers': {'User-Agent': 'youtube-dl'},
                               'format': 'url'})

# Generated at 2022-06-12 16:49:27.315139
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .m3u8 import M3U8FD
    M3U8FD.test_download()
# end of unit test for method real_download of class HlsFD

# Generated at 2022-06-12 16:49:40.013308
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    class TestHlsFDRealDownload(unittest.TestCase):
        def setUp(self):
            self.hls_fd = HlsFD({'test': True}, {})


# Generated at 2022-06-12 16:49:52.470584
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import common
    from ..extractor import youtube
    # Test for a normal case

# Generated at 2022-06-12 16:50:01.533940
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .http import HttpFD
    from .external import FFmpegDl
    from .dash import DASHFD
    from ..extractor.generic import YoutubeIE
    from ..utils import unescapeHTML
    import os.path
    import requests
    from tempfile import gettempdir

    def check_real_download_test_cases(test_cases):
        check_test_cases(test_cases, ['youtube_dl.extractor.generic.YoutubeIE', 'youtube_dl.downloader.http.HttpFD', 'youtube_dl.downloader.external.FFmpegDl', 'youtube_dl.downloader.dash.DASHFD', 'youtube_dl.downloader.hls.HlsFD', 'youtube_dl.FileDownloader'])

# Generated at 2022-06-12 16:50:08.832080
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import format_bytes
    ie = InfoExtractor(
        downloader=None,
        params={'usenetrc': False, 'username': 'test', 'password': 'test'},
        ie_key='HlsFD',
    )

# Generated at 2022-06-12 16:50:15.924171
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import HEADRequest

    # gen_extractors returns an array of extractors
    ydl = gen_extractors()[0]
    ydl.request = HEADRequest

# Generated at 2022-06-12 16:50:23.815395
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .http_fd import HttpFD
    from ..extractor import gen_extractors
    from ..utils import sanitize_open

    class FakeYtdl:
        def __init__(self, params):
            self.params = params
            self.extractor_names = []
            self.extractors = []
            self.num_downloads = 0

        def add_info_extractor(self, ie):
            self.extractor_names.append(ie.IE_NAME)
            self.extractors.append(ie)

        def to_screen(self, *args, **kwargs):
            pass

        def trouble(self, *args, **kwargs):
            pass

        def report_error(self, *args, **kwargs):
            pass


# Generated at 2022-06-12 16:50:27.218994
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD is not None
    print('Successfully import HlsFD')

if __name__ == "__main__":
    test_HlsFD()

# Generated at 2022-06-12 16:50:31.341742
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """ test class HlsFD constructor """
    hls_fd = HlsFD("test_ydl", "test_params")
    assert "test_ydl" == hls_fd.ydl
    assert "test_params" == hls_fd.params

# Generated at 2022-06-12 16:50:57.544280
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest

    url = 'https://www.youtube.com/watch?v=RFinNxS5KN4'

    def HlsFD_real_download(tested_method, video_id, video_url, video_ext, video_formats, video_thumbnail, video_title, video_duration, video_age_limit, expected_value, expected_format, expected_count, binary, override_params={}):
        params = {
            'filename': 'test',
            'format': 'best',
            'noprogress': 'True',
            'quiet': 'True'
        }
        params.update(override_params)

        from youtube_dl import YoutubeDL
        from youtube_dl.downloader.common import FileDownloader
        from youtube_dl.extractor import YoutubeIE


# Generated at 2022-06-12 16:51:07.923567
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .downloader import FileDownloader
    from .extractor import gen_extractors

    def get_manifest_and_info_dict(src):
        fd = FileDownloader({})
        fd.params.update({
            'format': 'best',
            'hls_prefer_native': True,
            'test': True,
            'ignoreerrors': False,
            'skip_download': True,
        })
        fd.add_info_extractor(next(iter(gen_extractors(src))))
        return fd.result['manifest_url'], fd.result['info_dict']

    def test_manifest(src, expected_supported):
        manifest_url, info_dict = get_manifest_and_info_dict(src)
        urlh = fd._prepare_

# Generated at 2022-06-12 16:51:21.115572
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import YoutubeDL
    from .extractor.youtube import YoutubeIE
    from .url import urlparse

    url = 'https://master.pl-0-4.hls.ttvnw.net/hls-vod/2aba13c7-069e-4c75-96da-4f7c4d6caa70/vod_252409d3-a500-4a9b-9f99-aae7d453f2b2/high/master_playlist.m3u8'
    info_dict = YoutubeIE._extract_info(YoutubeDL({'nooverwrites': True, 'quiet': True}), url, {})
    assert HlsFD.can_download(None, info_dict)

# Generated at 2022-06-12 16:51:32.886753
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testdata_files
    from .http import HttpFD
    from .external import ExternalFD
    from .fragment import FragmentFD
    from ..extractor import YoutubeIE
    # Test whether or not HlsFD can download merged fragments
    test_source = 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8'
    test_ie = YoutubeIE()
    source_file = get_testdata_files('x36xhzz/x36xhzz_frag_b0_v4_a1.ts')[1]
    url_handle = HttpFD().open(test_source)

# Generated at 2022-06-12 16:51:37.853584
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from . import YoutubeDL
    from .extractor.generic import GenericIE
    from .postprocessor.ffmpeg import FFmpegPostProcessor
    youtube_dl = YoutubeDL({'outtmpl': '%(id)s%(ext)s'})
    youtube_dl.add_info_extractor(GenericIE())
    pp = FFmpegPostProcessor(youtube_dl)
    p = pp.run(['http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8'])
    assert not p

# Generated at 2022-06-12 16:51:39.898058
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:51:52.105407
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import re
    from .common import fake_extractor
    from .fragment import FragmentFD

    ydl = fake_extractor('hlsnative', {})
    info_dict = {
        'url': 'http://test.segment.url/path/Manifest.m3u8',
    }
    urlh = ydl.urlopen('http://test.manifest.url/path/Manifest.m3u8')
    manifest = urlh.read().decode('utf-8', 'ignore')

    # Manifest has unsupported features
    assert not HlsFD.can_download(manifest, info_dict)

    # Manifest has unsupported features and pycrypto is not installed

# Generated at 2022-06-12 16:52:05.104890
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import io
    import io
    import pytest
    from .static_fd import StaticFD

    # Tests for decryption that are not possible from Python 3.2- pre-installed PyCrypto
    if can_decrypt_frag:
        def _test_decryption(s, decrypt_info, result):
            info_dict = {
                'url': 'http://example.com/manifest.m3u8',
                'format_id': '123',
                'ext': 'mp4',
                '_decryption_key_url': 'http://example.com/key',
                'is_live': False,
            }
            key = decrypt_info.get('KEY') or b'ABCDEF0123456789'
            iv = decrypt_info.get('IV') or (b'\x00' * 16)
           

# Generated at 2022-06-12 16:52:15.089840
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest

    from youtube_dl.extractor.generic import YoutubeIE
    from youtube_dl.downloader import Downloader

    # Test real download
    ie = YoutubeIE(Downloader(params={'fragment_retries': 0, 'skip_unavailable_fragments': True, 'test': False}))

# Generated at 2022-06-12 16:52:25.483106
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import YoutubeDL
    from ..utils import sanitize_open
    import tempfile

    # Sample manifest taken from https://github.com/ytdl-org/youtube-dl/pull/27660

# Generated at 2022-06-12 16:53:03.339771
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """
    This test will pass if the method real_download of the class HlsFD
    is functioning properly.
    """
    from .test_utils import fake_http_server
    http_server = fake_http_server()
    http_server.serve_content(
        u'#EXTM3U\n'
        u'#EXT-X-MEDIA-SEQUENCE:0\n'
        u'#EXTINF:2,\n'
        u'http://{0}/0\n'.format(http_server.address).encode('ascii'),
        headers=[(u'Content-Type', u'application/x-mpegURL')])
    http_server.serve_content(b'0' * 1024)

    from .extractor import YoutubeDL
    ydl = YoutubeDL({})
   

# Generated at 2022-06-12 16:53:10.157562
# Unit test for constructor of class HlsFD
def test_HlsFD():
    def my_add_progress_hook(x):
        return 1
    ydl = YoutubeDL('https://www.youtube.com/watch?v=JxR1wzQFIfc')
    hls = HlsFD(ydl,1)
    hls.add_progress_hook(my_add_progress_hook)
    assert len(hls._progress_hooks) == 1
    hls.real_download(1,1)


# Generated at 2022-06-12 16:53:22.463283
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .tests.test_fragment_downloader import FakeYdl
    from ..extractor import gen_extractors
    fake_ydl = FakeYdl(params={'hls_prefer_native': True})
    gen_extractors(fake_ydl)
    url = 'https://www.example.com/hlsplaylist.m3u8'
    playlist_url = 'https://www.example.com/rootplaylist.m3u8'

# Generated at 2022-06-12 16:53:33.522314
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from test.test_download_common import FakeYDL
    from .external import ExternalFD
    from .utils import check_data_integrity

    def check_HlsFD(info_dict, filename, expected_size):
        ydl = FakeYDL()
        ydl.add_info_extractor(ExternalFD)
        ydl.add_info_extractor(HlsFD)
        ydl.params.update(
            {'continuedl': False, 'nooverwrites': True, 'restrictfilenames': True})
        res = ydl.extract_info(
            'http://127.0.0.1:9000/hls-fragment/%s' % info_dict['url'],
            download=True)

        assert res is not None
        assert 'entries' not in res


# Generated at 2022-06-12 16:53:34.218818
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert True

# Generated at 2022-06-12 16:53:45.623771
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Functionality tests
    from .common import FakeYDL
    from . import _test_pycryptodomex as _test_pycryptodomex
    if not can_decrypt_frag:
        _test_pycryptodomex.download()
    ydl = FakeYDL()
    hlsfd = HlsFD(ydl)
    for opt in ('', '-f bestvideo[abr>1]'):
        info_dict = {
            'url': 'http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8',
            'ext': 'mp4',
        }
        from .common import FileDownloader

# Generated at 2022-06-12 16:53:55.562907
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .external import SimpleFD
    from .fragment import FragmentFD
    from .http import HttpFD
    hls_fd_1 = HlsFD(None, {'test': True})
    assert isinstance(hls_fd_1, FragmentFD)
    hls_fd_2 = HlsFD(None, {'test': False})
    assert isinstance(hls_fd_2, HttpFD)
    hls_fd_3 = HlsFD(None, {})
    assert isinstance(hls_fd_3, SimpleFD)
    hls_fd_4 = HlsFD(None, {'fragment_retries': 0})
    assert isinstance(hls_fd_4, HttpFD)

# Generated at 2022-06-12 16:54:07.897106
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import HEADRequest

    def _open_for_test(self, test_request, *args, **kwargs):
        return self._request_webpage(test_request, *args, **kwargs)

    ydl = YoutubeIE()  # pylint: disable=abstract-class-instantiated
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())
    ydl.add_info_extractor(YoutubeIE(u'channel'))
    ydl.add_info_extractor(YoutubeIE(u'playlist'))
    hlsfd = HlsFD(ydl, {})

# Generated at 2022-06-12 16:54:16.648601
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import time
    import tempfile
    import os.path
    import subprocess
    # Create temporary files
    tmp_out_file = tempfile.mkstemp(suffix='.mp4')[1]
    tmp_downloaded_file = tempfile.mkstemp(suffix='.mp4')[1]
    tmp_downloaded_file2 = tempfile.mkstemp(suffix='.mp4')[1]
    # Create test

# Generated at 2022-06-12 16:54:27.931776
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import match_filter_func
    from ..compat import compat_socket
    from ..extractor.test.test_test import _download_cases
    import json
    import copy

    def mock_urlopen(request, data=None):
        class MockStream(object):
            def read(self, _):
                if data:
                    return data.read(65536)
                return None

            def close(self):
                pass
        class MockResponse(object):
            def __init__(self, url):
                self.url = url
                self.code = 200
                self.headers = {}
                self.fileno = MockStream()
            def geturl(self):
                return self.url

# Generated at 2022-06-12 16:55:39.982837
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.generic import GenericIE
    from ..downloader.common import FileDownloader
    from .external import ExternalFD
    from .dash import DashSegmentsFD


# Generated at 2022-06-12 16:55:43.133563
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import youtube_dl.YoutubeDL
    params = {'outtmpl': '/tmp/test_%(playlist_index)s_%(id)s.%(ext)s'}
    ydl = youtube_dl.YoutubeDL(params)
    hls_fd = HlsFD(ydl, params)
    assert hls_fd.params == params
    assert hls_fd.ydl == ydl

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:55:54.095854
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .youtube import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['skip_download'] = True
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_use_mpegts'] = True
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(HlsFD(ydl))

# Generated at 2022-06-12 16:55:58.695423
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from . import YoutubeDL
    from .compat import compat_tempfile
    with compat_tempfile.NamedTemporaryFile(mode='w+t') as f:
        ydl = YoutubeDL({'outtmpl': f.name})
        hls_fd = HlsFD(ydl, {})
        assert isinstance(hls_fd, HlsFD)

# Generated at 2022-06-12 16:56:06.302466
# Unit test for constructor of class HlsFD
def test_HlsFD():
    url1 = "http://www.example.com/playlist.m3u8"
    url2 = "http://www.example.com/playlist.m3u8?foo=bar"
    url3 = "http://www.example.com/playlist.m3u8?foo=bar"
    # Test that URLs are normalized properly
    assert (HlsFD.can_download(url1) == HlsFD.can_download(url2))
    assert (HlsFD.can_download(url2) == HlsFD.can_download(url3))



# Generated at 2022-06-12 16:56:16.283863
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """Test example manifests."""
    from ..extractor import gen_extractors
    for ie in gen_extractors():
        ie.CHECK_IF_BIN_DL = False
        if ie.ie_key() == 'hlsnative':
            break
    ie.download = ie.real_download
    test_manifests = [
        'https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8',
        'http://qa-assets.anvato.net/p/nowthis/prod/hls/one/index.m3u8',
    ]
    for manifest_url in test_manifests:
        ie.url = manifest_url
        ie.extract()

# Generated at 2022-06-12 16:56:22.072695
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    ydl = gen_extractors()

    class InfoDict:
        def __init__(self, query):
            self.url = 'http://example.com/?%s' % query

    class Params:
        def __init__(self, extra_param_to_segment_url):
            self.extra_param_to_segment_url = extra_param_to_segment_url

    # E.g. https://www.youtube.com/watch?v=7VuKfYkvT9U
    info_dict = InfoDict(query='')
    params = Params(extra_param_to_segment_url='')
    assert HlsFD.can_download('', info_dict)

# Generated at 2022-06-12 16:56:32.558801
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .http_fd import HttpFD
    from .dashsegments import SegmentFD
    from .external import FFmpegFD
    from .fragment import FragmentFD
    from .dash import DashFD
    from .m3u8 import M3u8FD
    from .external import ExternalFD
    from ..downloader import Downloader
    from ..postprocessor import PostProcessor
    from ..extractor import YoutubeIE, InfoExtractor

    def check_download(info_dict, expected_mode):
        downloader = Downloader(YoutubeIE(), params={})

# Generated at 2022-06-12 16:56:41.992614
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.downloader.common

    name = 'hlsnative'

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp(prefix='%s-' % name)

    # Create the configuration directory inside it
    confdir = os.path.join(tmpdir, 'config')
    os.makedirs(confdir)

    # Save the default configuration inside the configuration directory
    ydl = youtube_dl.YoutubeDL({'config_location': confdir, 'download_archive': os.devnull})
    ydl.params.dump()

    # Download the HLS fragment from https://github.com/ytdl-org/youtube-dl/blob/master/tests/test_fragments/hls/

# Generated at 2022-06-12 16:56:54.715354
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import youtube_dl
    o = youtube_dl.options.parseOpts(['-g', '--hls-use-mpegts'])[0]
    o.test = True
    o.hls_use_mpegts = True
    o.fragment_retries = 0
    o.skip_unavailable_fragments = False
    fd = HlsFD(ydl=youtube_dl.YoutubeDL(o), params=o)
    fd.add_progress_hook(lambda a, b : print(a, b))
    assert fd.real_download('test.ts', {'url': 'https://example.com'}) == False
    fd.real_download('test.mp4', {'url': 'https://example.com'})