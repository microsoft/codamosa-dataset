

# Generated at 2022-06-12 16:49:20.441883
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import tempfile

    from .test import MockYDL
    from .extractor import YoutubeDL

    manifest = open(sys.argv[1], 'rb').read().decode('utf-8')
    video_id = sys.argv[2]
    for fd_class in (HlsFD, FFmpegFD):
        ydl = YoutubeDL(dict(noplaylist=True))
        ydl.add_default_info_extractors()
        ydl.params['noplaylist'] = True
        ydl.params['hls_native'] = isinstance(fd_class, HlsFD)

# Generated at 2022-06-12 16:49:34.227614
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .tests.test_HlsFD import (
        HlsFDTest,
        HlsFDWithFFmpegTest,
    )
    HlsFDTest('https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8').run()
    HlsFDWithFFmpegTest('https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8').run()

from ..extractor import registered_extractors
from ..downloader import registered_downloaders
from ..downloader.common import FileDownloader

# Generated at 2022-06-12 16:49:47.270896
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # An exception is thrown if pycrypto is not present
    try:
        from Crypto.Cipher import AES
    except ImportError:
        return
    from .test_file import TestDownloadManager
    from ..downloader.common import FileDownloader
    from ..compat import mock

    def test_hook(d):
        pass

    def mock_open(file):
        class f:
            def write(self, s):
                pass

            def close(self):
                pass
        return f()

    def mock_urlopen(url):
        class MockUrl(object):

            def __init__(self, url):
                self.url = url

            def geturl(self):
                return self.url


# Generated at 2022-06-12 16:49:57.779858
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import pytest
    from .test_fragment import is_test_excluded
    with open('youtube_dl/extractor/test_data/test.m3u8') as f:
        man_str = f.read()
    def request_mock(self, url, *args, **kwargs):
        host_mock, url_mock = url.split('/', 3)[2:]
        assert host_mock == 'redirector.m.legs.cdn.brave.software'

# Generated at 2022-06-12 16:50:05.234347
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import re
    from .__main__ import FakeYdl
    from .external import TempFD
    from .file import FileFD
    from .dash import DashSegmentsFD
    from .http import HttpFD
    class HlsFD_test(HlsFD):
        # overriding with empty method
        def _download_fragment(self, *args):
            return True, b''

        def __enter__(self):
            return self

        # overriding _append_fragment to count only data appended to file
        def _append_fragment(self, ctx, data):
            ctx['data'].extend(data)


# Generated at 2022-06-12 16:50:13.251832
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-12 16:50:21.933000
# Unit test for constructor of class HlsFD
def test_HlsFD(): 
    obj = HlsFD({})
    assert obj.real_download('test', {}) == False
    assert obj.can_download('#EXT-X-KEY:METHOD=NONE', {}) == True
    assert obj.can_download('#EXT-X-KEY:METHOD=INVALID', {}) == False
    assert obj.can_download('#EXT-X-KEY:METHOD=AES-128', {}) == False
    assert obj.can_download('#EXT-X-KEY:METHOD=AES-128', {'is_live': True}) == False

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:50:34.834606
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            self._ies = []
            self.ie_result = None

        def _real_initialize(self):
            pass

        @staticmethod
        def suitable(ie_name):
            return True

        @staticmethod
        def gen_extractors():
            return []

        def _real_extract(self, *args):
            return self.ie_result

        def _download_webpage(self, *args, **kwargs):
            return '#EXTM3U\n'

    ydl = FakeYDL()
    ie = FakeInfoExtractor(ydl)


# Generated at 2022-06-12 16:50:44.367263
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Verify that the HlsFD can download the first fragment in a playlist
    # See https://github.com/ytdl-org/youtube-dl/pull/27660

    from .test_download import FakeYDL
    from .http import HttpFD

    info_dict = {
        'id': 0,
        'url': 'https://example.com/playlist.m3u8',
        'http_headers': {},
    }
    ydl = FakeYDL()
    fd = HlsFD(ydl, {})
    fd.to_screen = lambda *args, **kwargs: None

    def _download_fragment(ctx, fragment_url, info_dict, headers):
        frag_content = 'fragment'
        self._append_fragment(ctx, frag_content)
        return

# Generated at 2022-06-12 16:50:47.918995
# Unit test for constructor of class HlsFD
def test_HlsFD():
    class Mock_info_dict():
        pass
    info_dict = Mock_info_dict()
    info_dict.url = "info_dict.url"
    info_dict.get = lambda key, default: default
    test = HlsFD(None, None)
    assert test.real_download("filename", info_dict) == False
    return 0

# Generated at 2022-06-12 16:51:09.612476
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    from .test_fragment_downloader import FragmentDownloaderTestBase
    from .fd_utils import m3u8_data, string_to_file

    # This test downloads and reads the first fragment of an HLS stream.
    # It only checks that the first fragment downloads and is read successfully,
    # it does not check that the downloaded data is correct.

    class HlsFDTests(FragmentDownloaderTestBase):
        def _test(self, ydl, filename, data):
            info_dict = {}
            hls_fd = HlsFD(ydl, {})
            success = hls_fd.real_download(filename, info_dict)
            if not success:
                self.fail('real_download method of HlsFD returned False')

    tests = []

    # an

# Generated at 2022-06-12 16:51:12.444159
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, None).download('/dev/null', {'url': 'http://url.org/playlist.m3u8'})

# Generated at 2022-06-12 16:51:15.606434
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('', {'is_live': False})

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:51:16.571267
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass

# Generated at 2022-06-12 16:51:21.320977
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors, list_extractors
    for ie in gen_extractors():
        if ie.IE_NAME == 'hlsnative':
            return
    raise RuntimeError('HlsFD not registered')


# Generated at 2022-06-12 16:51:33.016242
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        from Crypto.Cipher import AES
        can_decrypt_frag = True
    except ImportError:
        can_decrypt_frag = False
    # Without _decryption_key_url
    info_dict = {
        'url': '  https://localhost/index.m3u8 ',
        'playlist_mincount': 1,
        'playlist': [
            {'url': 'https://localhost/frag-1.ts', 'ext': 'ts'},
            {'url': 'https://localhost/frag-2.ts', 'ext': 'ts'},
        ],
    }

# Generated at 2022-06-12 16:51:35.476694
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ydl = YoutubeDL()
    ydl.add_progress_hook(lambda: None)
    hlsfd = HlsFD(ydl, {'fragment_retries': 0})
    assert hlsfd is not None

# Generated at 2022-06-12 16:51:48.389596
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .dash import DASHFD


# Generated at 2022-06-12 16:51:49.171108
# Unit test for constructor of class HlsFD
def test_HlsFD():
    print(HlsFD.can_download(str, None))

# Generated at 2022-06-12 16:51:56.271312
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import json
    import random
    import shutil
    import tempfile
    import unittest

    from ..compat import (compat_urllib_error, compat_urlparse, compat_getproxies)
    from ..extractor import gen_extractors, list_extractors
    from ..utils import (
        encode_data_uri,
        match_filter_func,
    )
    from .test_download import (
        check_lf,
        FakeYDL,
        read_batch_urls,
        test_download,
    )

    def get_extractor_by_name(name):
        for ie in gen_extractors():
            if ie.IE_NAME == name:
                return ie
        return None

    def setUpModule():
        gen_extractors()



# Generated at 2022-06-12 16:52:27.017636
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import youtube_dl.YoutubeDL
    import os
    import sys
    import tempfile
    import random
    import string
    import shutil

    # Create a temporary directory
    test_dir = tempfile.mkdtemp()

    # Enter the temporary directory
    old_cwd = os.getcwd()
    os.chdir(test_dir)

    # Set a random string for filename
    test_file_name = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(12))

    # Create a dummy hls playlist file
    playlist_file = open(test_file_name + '.m3u8', 'w')

# Generated at 2022-06-12 16:52:39.081608
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import test_playlists
    from .fragment import FragmentFD

    # Original test for HlsFD.can_download
    assert HlsFD.can_download('', {})
    assert HlsFD.can_download('#EXTM3U', {})
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10', {})
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10', {'is_live': True})
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXT-X-KEY', {})

# Generated at 2022-06-12 16:52:45.293487
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls = HlsFD({}, {})
    assert len(hls._progress_hooks) == 0
    assert hls._fragment_retries == 0
    assert hls._skip_unavailable_fragments == True
    assert hls._test is False


# Generated at 2022-06-12 16:52:57.114555
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    try:
        from nose.tools import nottest
    except ImportError:
        def nottest(fn):
            pass

    @nottest
    def test_method(self, manifest_url, manifest, assert_query_in_url=None,
                    assert_key_url=None, assert_key=None, assert_iv=None):
        from . import YoutubeDL
        from .extractor.common import InfoExtractor
        from .utils import DateRange


# Generated at 2022-06-12 16:53:09.148892
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .external import ExternalFD
    from ..extractor import youtube_dl
    if not can_decrypt_frag:
        return
    ydl = youtube_dl.YoutubeDL(params={})
    ydl.add_info_extractor(ExternalFD(ydl, {'ie_key': 'HlsFD'}))
    ydl._ies = list(filter(lambda ie: ie.ie_key() == 'HlsFD', ydl._ies))
    ydl.params['cachedir'] = False
    ydl.params['nooverwrites'] = True
    ydl.params['noprogress'] = True
    ydl.params['quiet'] = True
    ydl.params['test'] = True

# Generated at 2022-06-12 16:53:16.217956
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import io
    import os
    import sys
    import tempfile

    info_dict = {
        'url': 'http://example.org/',
        'player_url': 'http://example.org/',
        'id': 'example',
        'title': 'example',
        'ext': 'mp4',
        'format': '19 - 720p',
        'thumbnail': 'http://example.org/',
        'description': 'example',
    }

    # Create a dummy m3u8 manifest

# Generated at 2022-06-12 16:53:28.533678
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import io
    import unittest
    from .test_fragment import MockYtdl

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.ydl = MockYtdl()


# Generated at 2022-06-12 16:53:33.198049
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import io
    import json
    import os
    from .test import get_testdata_files_dir, get_tmp_files_dir
    from .extractor.common import InfoExtractor
    from .utils import _get_troublesome_ie

    TROUBLESOME_IE = _get_troublesome_ie()
    TROUBLESOME_IE_NAMES = set(ie.IE_NAME for ie in TROUBLESOME_IE)

    def _load_tests(tests_file_in):
        with io.open(tests_file_in, 'r', encoding='utf-8') as f:
            tests = json.load(f)
        return tests['fragments']


# Generated at 2022-06-12 16:53:38.894242
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert can_decrypt_frag, 'Cannot run HlsFdTest without Crypto.Cipher'

    def _test_manifest(manifest, expected_aes_params, expected_total_frags, expected_bytes, expected_ad_frags=0):
        class _FakeInfoDict(object):
            pass
        info_dict = _FakeInfoDict()
        info_dict.get = lambda *args, **kwargs: None
        info_dict.update = lambda *args, **kwargs: None
        res = HlsFD.can_download(manifest, info_dict)
        assert res == True, 'Can download manifest'
        manifest = manifest.encode('utf-8')
        hls_fd = HlsFD(None, {})

# Generated at 2022-06-12 16:53:50.935777
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import get_testdata_video_url, TEST_VIDEO_DATA, mock_http_server
    from .test_youtube_dl import YoutubeDL
    from .extractor.common import InfoExtractor
    from .utils import sanitize_open
    import shutil
    import tempfile

    ydl = YoutubeDL(YoutubeDL.params)
    ydl.add_info_extractor(InfoExtractor(ydl))

    with mock_http_server():
        (test_video_url, test_size) = get_testdata_video_url()
        video_info = ydl.extract_info(test_video_url, download=False)
        video_url = video_info['url']


# Generated at 2022-06-12 16:54:55.728809
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import YoutubeDL
    # Test HlsFD.real_download when there is no encryption.
    ydl = YoutubeDL(params={'skip_download': True})

# Generated at 2022-06-12 16:54:57.477691
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .tests.test_HlsFD import TestHlsFD
    return TestHlsFD('test:hls').run()

# Generated at 2022-06-12 16:55:06.208015
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import get_info_extractor
    from ..downloader.common import FileDownloader

    class FakeYDL(object):
        def __init__(self, ydl):
            self.params = ydl.params
            self.cache = ydl.cache
            self._progress_hooks = []

        def add_progress_hook(self, ph):
            self._progress_hooks.append(ph)

        @staticmethod
        def urlopen(url):
            return compat_urllib_request.urlopen(url)


# Generated at 2022-06-12 16:55:17.890844
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .downloader import _parseOpts
    from .extractor import gen_extractors
    for extractor in gen_extractors():
        if not getattr(extractor, '_WORKING', True):
            continue
        if not getattr(extractor, '_TEST', False):
            continue
        ie = extractor(downloader=None)
        if not ie.suitable():
            continue
        ie.working = True
        ie.prepare()
        if not ie.working:
            continue

# Generated at 2022-06-12 16:55:24.554009
# Unit test for constructor of class HlsFD

# Generated at 2022-06-12 16:55:37.019397
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\nmedia.ts\n#EXT-X-ENDLIST', {})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\nmedia.ts\n#EXT-X-ENDLIST\n#EXT-X-KEY:METHOD=AES-128,URI="http://test",IV=0x00000000000000000000000000000000', {'is_live': True})

# Generated at 2022-06-12 16:55:45.748839
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .utils import FakeYDL
    from .downloader import DownloadContext
    from .fragment import (
        FragmentFDContextBase,
        FragmentFDContext,
    )
    from ..extractor.common import InfoExtractor
    from ..utils import parse_duration
    from ..compat import (
        compat_struct_pack,
        compat_urlparse,
    )
    ydl = FakeYDL()

    # Test info_dict being passed properly to urlopen
    ydl.urlopen = lambda url, *args, **kwargs: url
    info_dict = {
        'url': 'http://example.org/manifest.m3u8',
        'http_headers': {
            'Cookie': 'c1=1; c2=2',
        },
    }

    # Test valid manifest
    manifest

# Generated at 2022-06-12 16:55:46.904639
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, None)

# Generated at 2022-06-12 16:55:56.785523
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    here = os.path.dirname(os.path.abspath(__file__))
    test_dir = os.path.join(here, '..', '..', '..', 'youtube_dl', 'test', 'files')

    # Test #EXT-X-KEY:METHOD=NONE
    manifest = (os.path.join(test_dir, 'hls-aes-128.m3u8'),
                os.path.join(test_dir, 'hls-manifest-key-version.m3u8'),
                os.path.join(test_dir, 'hls-playready.m3u8'))
    for url in manifest:
        with open(url, 'r') as f:
            m3u8 = f.read()

# Generated at 2022-06-12 16:56:04.885851
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    from ..postprocessor.metadata import _write_dummy_json
    from ..downloader.common import FileDownloader
    from ..extractor import YoutubeIE
    from .common import FakeYDL
    from .http import SimpleHttpFD
    from .http import HttpFD
    from .fragment import FragmentFD
    from .dash import DASHFD
    from .hls import HlsFD

    # Initialize a downloader in debug mode
    params = {'debug_printtraffic': True, 'nooverwrites': True, 'verbose': True, 'skip_download': True}
    with FileDownloader({}, params) as ydl:
        ydl.logger.setLevel(0)

# Generated at 2022-06-12 16:58:39.517199
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import FakeYDL
    from .external import ExternalFD
    from .http import HttpFD
    ydl = FakeYDL()
    ydl.params = {}
    ydl.add_info_extractor(ExternalFD(ydl, ydl.params))
    ydl.add_info_extractor(HttpFD(ydl, ydl.params))
    ydl.add_info_extractor(HlsFD(ydl, ydl.params))
    # HttpFD and ExternalFD are required to test the HlsFD
    ae = ydl._ies[ExternalFD.ie_key()]
    ae._ies.appendleft(ydl._ies[HttpFD.ie_key()])

# Generated at 2022-06-12 16:58:46.294716
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import pytest
    from .testutils import (
        FakeYDL,
        MockUrlOpen,
        read_test_data,
    )
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from ..downloader.http.httpfd import HttpFD

    manifest_data = read_test_data('hls/manifest.m3u8')
    fragment_data = read_test_data('hls/segment.ts')

    ie = InfoExtractor(YoutubeIE.ie_key())
    ie.extractor = YoutubeIE
    ie.params = YoutubeIE._formats(ie, 'https://youtube.com/watch?v=z0lJ9Oqv5y8')[0]
    ie.params['test'] = True
    ie.params