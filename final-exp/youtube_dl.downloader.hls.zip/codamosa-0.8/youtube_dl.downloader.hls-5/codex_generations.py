

# Generated at 2022-06-12 16:49:12.072127
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .extractor.twitch import TwitchIE
    from .downloader import common as downloader_common

    class FakeStream(object):

        def __init__(self, content):
            self.content = content.encode('utf-8')

        def read(self):
            return self.content


# Generated at 2022-06-12 16:49:25.529238
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    fd = HlsFD('youtube-dl')
    assert fd.can_download(
        '#EXTM3U\n'
        '#EXT-X-TARGETDURATION:10\n'
        '#EXT-X-VERSION:3\n'
        '#EXTINF:10,\n'
        'fileSequence0.ts\n'
        '#EXT-X-ENDLIST',
        {'is_live': False})

# Generated at 2022-06-12 16:49:38.251202
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .f4m import F4mFD
    from .fragment import FragmentFD

    assert issubclass(HlsFD, FragmentFD)
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10\nfileSequence0.ts', {})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10\nfileSequence0.ts\n#EXT-X-KEY:METHOD=AES-128', {})

# Generated at 2022-06-12 16:49:51.267988
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..extractor import YoutubeIE
    from ..utils import encode_data_uri
    from ..compat import compat_struct_pack
    from io import BytesIO

    ydl = YoutubeIE()

    ydl.params['hls_use_mpegts'] = True
    manifest_url = 'https://manifest_url.test/path/to/manifest.m3u8'
    sha256_hash = '2e057f49b0d53b719f5e8a1b6a002412f9ff6f582708a59b5c5d5a5e29a5e8f5'


# Generated at 2022-06-12 16:49:56.532441
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import shutil
    import tempfile
    from .downloader import YoutubeDL
    from .extractor import get_info_extractor
    from .extractor.youtube import YoutubeIE

    with tempfile.NamedTemporaryFile(prefix='youtube-dl-test-HlsFD-') as tmp:
        # Download a HLS video
        sys.argv = ['youtube-dl', '-o', tmp.name, 'https://www.youtube.com/watch?v=pCbHlA77rzw']
        HlsFD.can_download = classmethod(lambda cls, manifest, info_dict: True)
        YoutubeDL(params={'noplaylist': True}).download(None)

        # Extract the URLs of all media fragments

# Generated at 2022-06-12 16:50:04.449874
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import youtube_dl.YoutubeDL
    from .utils import FakeYdl
    from .options import Options
    from .extractor.common import InfoExtractor

    fake_ydl = FakeYdl()
    fake_ydl.params = Options({})
    fake_ydl.add_default_info_extractors()

    fd = HlsFD(fake_ydl, {'http_chunk_size': 10})
    assert fd.blocksize == 10 * 1024 * 1024
    assert fd.retries == 10

    def _prepare_url(self, url):
        if url == 'http://example.org/index.m3u8':
            raise Exception('test error')
        return url
    InfoExtractor._prepare_url = _prepare_url

# Generated at 2022-06-12 16:50:12.292016
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import youtube_dl.version
    import youtube_dl.YoutubeDL
    import youtube_dl.postprocessor.ffmpeg


# Generated at 2022-06-12 16:50:18.206959
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os.path
    import tempfile
    from .test_download import setup_test_download
    from .downloader import _calc_expected_size
    from .utils import sanitize_open

    ydl, params, test_cases = setup_test_download()
    params['test'] = True

    for test_case in test_cases:
        if test_case.result != 'downloading':
            continue
        if test_case.name != "hls_native_test":
            continue
        prefix = '[download] '

        tmp_manifest_name = test_case.test_filename + '.m3u8'
        tmp_manifest = os.path.join(params['temp_dir'], tmp_manifest_name)

# Generated at 2022-06-12 16:50:22.903008
# Unit test for constructor of class HlsFD
def test_HlsFD():
    obj = HlsFD(None, None)
    assert 'HlsFD' == obj.FD_NAME
    demo_playlist = "#EXTM3U\n" \
                    "#EXT-X-TARGETDURATION:10\n" \
                    "#EXTINF:10,\n" \
                    "http://media.example.com/entire.ts\n" \
                    "#EXT-X-ENDLIST"
    assert not obj.can_download(demo_playlist, {})

# Generated at 2022-06-12 16:50:35.313907
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from . import YoutubeDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urlretrieve
    import platform
    import sys

    class DummyIE(InfoExtractor):
        def report_warning(self, message):
            pass
        def report_error(self, message):
            pass

    # Avoid encoding errors on Python 3.2 (see http://bugs.python.org/issue15576).
    if sys.version_info[:2] == (3, 2):
        class DummyYDL(YoutubeDL):
            def to_screen(self, message, skip_eol=False):
                pass

        ydl = DummyYDL()

# Generated at 2022-06-12 16:51:01.141835
# Unit test for constructor of class HlsFD
def test_HlsFD():
    '''
    Check that the HlsFD is called when the manifest is ffmpeg compatible
    '''
    import sys
    import os
    import tempfile

    from six.moves import urllib as compat_urllib
    from ..downloader.YoutubeDL import YoutubeDL
    from ..utils import encodeFilename, sanitize_open
    from .fragment import FragmentFD
    from .external import FFmpegFD


# Generated at 2022-06-12 16:51:10.326968
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    from ..utils import FakeYDL

    class FakeHlsFD(HlsFD):
        def __init__(self, ydl, params):
            super(FakeHlsFD, self).__init__(ydl, params)
            self.segment_data = None
            self.manifest = ''

        def _download_fragment(self, ctx, frag_url, info_dict, headers):
            return True, self.segment_data

        def _append_fragment(self, ctx, fragment):
            ctx['filename'].write(fragment)

        def _finish_frag_download(self, ctx):
            ctx['filename'].flush()
            ctx['filename'].close()


# Generated at 2022-06-12 16:51:15.237230
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .http import HttpFD
    from .http import HEADRequest
    from .utils import SameFileError
    from . import YoutubeDL
    from .extractor.youtube import YoutubeIE
    from .postprocessor.ffmpeg import FFmpegPostProcessor
    import os
    import random
    import hashlib
    import shutil
    import tempfile
    import traceback
    import warnings
    warnings.simplefilter('ignore', SameFileError)

    def write_file(filename, content):
        with open(filename, 'wb') as out_file:
            out_file.write(content)

    def hash_file(filename, blocksize, hasher):
        with open(filename, 'rb') as f:
            buf = f.read(blocksize)
            while len(buf) > 0:
                hasher.update(buf)
               

# Generated at 2022-06-12 16:51:27.972457
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import FakeYdl
    from .extractor import get_info_extractor

    ydl = FakeYdl()
    url = 'https://example.com/manifest.m3u8'
    ie = get_info_extractor(url)
    info = ie._real_extract(ydl, url)

    # Test that the HlsFD object to be created in the real_extract function in both cases.
    assert isinstance(info['formats'][0]['fragment_downloader'], HlsFD)
    assert isinstance(info['formats'][1]['fragment_downloader'], HlsFD)

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:51:36.350064
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import random
    import hashlib
    import tempfile
    import shutil
    from youtube_dl.downloader.hls import HlsFD

    # In order to download the file we need to specify a ydl instance and a info
    class TestInfo:
        pass

    class TestYDL:
        def __init__(self):
            self.urlopen_handlers = {}
            self.dir = tempfile.mkdtemp()

        def urlopen(self, url):
            return self.urlopen_handlers[url]()

        def add_urlopen_handler(self, url, handler):
            self.urlopen_handlers[url] = handler

        def remove_urlopen_handler(self, url):
            del self.urlopen_handlers[url]


# Generated at 2022-06-12 16:51:49.306339
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import tempfile
    import os
    import sys
    import shutil

    from ..utils import (
        find_x_byte,
        decode_compat_http_headers,
    )

    class HlsFDRealDownloadTest(unittest.TestCase):

        def setUp(self):
            self.dir = tempfile.mkdtemp(prefix='youtube-dl-test-hls-frag')
            self.filename = os.path.join(self.dir, 'test.ts')

        def tearDown(self):
            shutil.rmtree(self.dir, ignore_errors=True)


# Generated at 2022-06-12 16:51:50.461865
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert isinstance(HlsFD(), HlsFD)


# Generated at 2022-06-12 16:51:57.045522
# Unit test for constructor of class HlsFD
def test_HlsFD():
    class MockYDL(object):

        def __init__(self):
            self.params = {}

        def add_progress_hook(self, ph):
            pass

    class MockFD(object):

        def __init__(self):
            self._progress_hooks = []

        def add_progress_hook(self, ph):
            self._progress_hooks.append(ph)

    ydl = MockYDL()
    fd = HlsFD(ydl, {})
    # FD_NAME
    assert fd.FD_NAME == 'hlsnative'
    # can_download
    assert fd.can_download('', {}) is False
    assert fd.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=NONE\n', {}) is True

# Generated at 2022-06-12 16:52:08.733718
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import ExtractorError
    from .external import FFmpegFD

    # Test segments interleaving

# Generated at 2022-06-12 16:52:15.818305
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('', {'is_live': True}) == False, 'case 1'
    assert HlsFD.can_download('', {'is_live': False}) == True, 'case 2'
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'is_live': False}) == True, 'case 3'
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'is_live': False}) == False, 'case 4'
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128:URI="https://example.com/key"', {'is_live': False}) == False, 'case 5'

# Generated at 2022-06-12 16:52:36.310092
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from . import YoutubeDL
    from .common import FileDownloader

    params = []
    ydl = YoutubeDL(params)
    fd = HlsFD(ydl, params)
    assert isinstance(fd, FileDownloader)
    assert fd.params is params
    assert fd.ydl is ydl

# Generated at 2022-06-12 16:52:44.265620
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .extractor import YoutubeIE
    from .downloader import YoutubeDL
    from .url import Url
    from .compat import compat_str
    from .__main__ import parseOpts

    url = 'https://example.com/test.m3u8'
    parseOpts(['--hls-use-mpegts', '--no-part',
               '--hls-prefer-native', '--no-prefer-ffmpeg'])
    ydl = YoutubeDL({'hls_prefer_native': True, 'hls_use_mpegts': True})
    ydl.add_default_info_extractors()
    ie = YoutubeIE(ydl)
    u = Url(url)

# Generated at 2022-06-12 16:52:56.365111
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    method = HlsFD.can_download
    # hls streams not supported by native HLS implementation (e.g. encrypted)

# Generated at 2022-06-12 16:53:08.643721
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .http import HttpFD
    from .rtmp import RtmpFD
    from ..extractor import get_info_extractor


# Generated at 2022-06-12 16:53:20.603440
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # failure on import and ydl is undefined
    if not can_decrypt_frag:
        return

    from ..extractor import common as extractor_common
    from .mock import MockYdl
    from .mock_http_server import MockServer
    from .test_utils import FakeFD

    fakefd = FakeFD()
    ydl = MockYdl(params={'simulate': True})
    ydl.add_info_extractor(extractor_common.InfoExtractor)
    test = HlsFD(ydl, {'url': 'http://localhost:%d/manifest' % MockServer.PORT})
    assert test.real_download(fakefd, {'url': 'http://localhost:%d/manifest' % MockServer.PORT})

# Generated at 2022-06-12 16:53:31.563632
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import FileDownloader
    from .extractor import YoutubeIE
    from .common import FileDownloaderTest
    class _LoggingPopen(object):
        def __init__(self, args, **kwargs):
            pass
        def communicate(self):
            return b'the_key_string', b''
    FileDownloader.popen = _LoggingPopen
    with FileDownloaderTest() as (ydl, fd):
        fd.params['test'] = True
        fd.add_progress_hook(ydl.hooks.progress_hook)

# Generated at 2022-06-12 16:53:38.399219
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .external import FFmpegFD
    from ..downloader import YoutubeDL

    ydl = YoutubeDL({'hls_use_mpegts': False, 'writeinfojson': True, 'nooverwrites': True})
    ydl.add_default_info_extractors()

    extractor = ydl.extractor_by_name('youtube')
    ext = extractor.get_info_extractor()

    url = 'https://www.youtube.com/watch?v=szn3Dpfq0Z0'
    url_data = ext._download_webpage(url, None, note=False, errnote=False)
    video_info_dict = ext._parse_generic_info(url, url_data)

# Generated at 2022-06-12 16:53:50.445574
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import os
    import shutil
    import tempfile

    from .external import FFmpegFD

    from ..compat import (
        compat_urllib_request,
    )
    from ..utils import (
        extract_attributes,
    )

    from .downloader import YoutubeDL

    # Create temp directory
    temp_dir = tempfile.mkdtemp(prefix='ytdl-hlsfd-test-')

    # Setup YoutubeDL
    ydl = YoutubeDL({'logger': YoutubeDL.std_logger, 'noplaylist': False,
                     'outtmpl': os.path.join(temp_dir, '%(title)s.%(ext)s')})

    # Setup logger
    ydl.params['logger'] = ydl.to_screen

    # Setup downloader

# Generated at 2022-06-12 16:53:59.314968
# Unit test for constructor of class HlsFD

# Generated at 2022-06-12 16:54:12.141368
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.youtube import YoutubeIE
    from ..extractor.common import InfoExtractor
    from ..utils import DateRange
    from .external import FFmpegFD

    youtube_ie = YoutubeIE(InfoExtractor())
    formats = youtube_ie._extract_info(
        {'url': 'https://www.youtube.com/watch?v=pwzMj6AsZRM', 'ie_key': YoutubeIE.ie_key()},
        download=True,
        process=False,
        extra_info={'extractor': youtube_ie, 'extractor_key': YoutubeIE.ie_key()})['formats']
    hls_url = next((f['url'] for f in formats if f['format_id'] == '140'), None)
    assert hls_url
    hls_info = youtube_ie._

# Generated at 2022-06-12 16:54:55.453229
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    import youtube_dl
    sys.argv = [sys.argv[0], '--test-fragments']
    uri = "https://bitdash-a.akamaihd.net/content/MI201109210084_1/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8"
    ydl = youtube_dl.YoutubeDL()
    info_dict = {
        'url': uri,
        'id': 'test_HlsFD',
        'ext': 'webm',
        'is_live': False
    }

    HlsFD.can_download(info_dict)
    print(HlsFD.can_download(info_dict, info_dict))
    H

# Generated at 2022-06-12 16:55:04.925296
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import json
    import sys
    import tempfile
    import importlib

    def _test(module_name, test_name):
        module = importlib.import_module(module_name)
        importlib.reload(module)  # Workaround for https://bugs.python.org/issue24372
        test = module.__dict__[test_name]
        temp = tempfile.NamedTemporaryFile(delete=False)
        temp.close()
        test(temp.name)
        temp.close()
        return temp.name

    def test_native_hls(filename):
        import youtube_dl.extractor.common
        import youtube_dl.YoutubeDL


# Generated at 2022-06-12 16:55:16.956028
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .http import HttpFD
    from .api import YoutubeDL

    ydl = YoutubeDL({'logger': YoutubeDL.no_op_logger()})
    fd = HlsFD(ydl, {'test': True})
    assert isinstance(fd, HlsFD)
    assert isinstance(fd, FragmentFD)
    assert not isinstance(fd, HttpFD)
    assert not isinstance(fd, YoutubeDL)

    fd = HlsFD(ydl, {'test': True, 'noprogress': True})
    assert isinstance(fd, HlsFD)
    assert isinstance(fd, FragmentFD)
    assert not isinstance(fd, HttpFD)
    assert not isinstance(fd, YoutubeDL)


# Generated at 2022-06-12 16:55:23.882854
# Unit test for constructor of class HlsFD
def test_HlsFD():
    obj1 = HlsFD({'url': 'http://example.com/video.m3u8', 'format': 'mp4'}, None)
    assert obj1.can_download('#EXTM3U', {})
    assert obj1.can_download('#EXTM3U\n#EXT-X-PLAYLIST-TYPE:EVENT', {})
    assert obj1.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {})
    assert not obj1.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\n#EXTINF:3 end="this"', {'is_live': True})

# Generated at 2022-06-12 16:55:25.682855
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.FD_NAME == 'hlsnative'
    assert HlsFD.can_download(None, None)

    return True

# Generated at 2022-06-12 16:55:38.398899
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert(HlsFD.can_download("#EXTM3U\n#EXT-X-VERSION:4\n#EXTINF:5.005,\na.ts\n", {}))
    assert(not HlsFD.can_download("#EXTM3U\n#EXT-X-VERSION:4\n#EXT-X-KEY:METHOD=AES-128\n#EXTINF:5.005,\na.ts\n", {}))
    assert(HlsFD.can_download("#EXTM3U\n#EXT-X-VERSION:4\n#EXTINF:5.005,\na.ts\n", {'_decryption_key_url': 'https://key'}))


# Generated at 2022-06-12 16:55:46.574866
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_handler
    ydl = get_test_handler()
    ydl.params['ignoreerrors'] = False
    ydl.params['cachedir'] = False
    ydl.params['test'] = True
    ydl.params['verbose'] = True
    ydl.params['hls_use_mpegts'] = True
    ydl.params['hls_prefer_ffmpeg'] = False
    # ydl.params['nooverwrites'] = True
    # ydl.params['outtmpl'] = '%(id)s.%(ext)s'  # Uncomment to avoid using temporary file
    # ydl.add_progress_hook(lambda *args: None)  # Uncomment to limit log output


# Generated at 2022-06-12 16:55:56.443144
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors
    from ..utils import urljoin

    def _test_can_download(url, expected):
        for ie in gen_extractors():
            if isinstance(ie, HlsFD) and ie.suitable(url) and ie._is_valid_url(url, ie.ie_key()):
                break
        assert ie
        assert ie.can_download(
            'EXT-X-PLAYLIST-TYPE:EVENT', {'is_live': True, 'url': url}) == expected

    base_url = 'https://example.com/'
    assert HlsFD.can_download('', {'url': urljoin(base_url, 'foo.mp4')})

# Generated at 2022-06-12 16:56:04.670229
# Unit test for constructor of class HlsFD
def test_HlsFD():
    '''
        Use unit test to test the constructor of class HlsFD.
        Simply call the constructor.
        Confirm that it returns an object as expected.
    '''
    url = 'https://youtube.com/watch?v=ABCD-EFGHIJK'
    params = {'verbose': True, 'no_warnings': True, 'geo_bypass': True, 'geo_bypass_country': 'NL'}
    opts = {'username': 'abc', 'password': '123'}

    # These should be errors, and cause the constructor to fail:
    params_1 = {}
    opts_1 = {}
    params_2 = {'verbose': True, 'no_warnings': True}
    opts_2 = {'username': 'abc'}

    # Constructor should work:


# Generated at 2022-06-12 16:56:14.672732
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """ This test checks if the method real_download of class HlsFD """
    """ works as expected. """
    print('Testing HlsFD.real_download')

    from ..extractor.generic import GenericIE
    from ..downloader.http import HttpFD
    from ..compat import compat_str
    from ..utils import encode_data_uri

    expected_content = compat_str('This is a content')


# Generated at 2022-06-12 16:57:50.912298
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .compat import compat_http_client
    from .test import TestDownloader, SearchInfoExtractor

    class DummySrcExtractor(SearchInfoExtractor):
        def _real_extract(self, url): pass

    class DummyPDFD(FragmentFD):
        FD_NAME = 'dummypfd'
        def _prepare_and_start_frag_download(self, ctx): pass
        def _download_fragment(self, ctx, frag_url, info_dict, headers): pass
        def _append_fragment(self, ctx, frag_content): pass
        def _finish_frag_download(self, ctx): pass

    # test AES decryption

# Generated at 2022-06-12 16:58:02.026056
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import MockYDL
    import os
    import copy

    def mock_urlopen(self, url):
        _, path = url.split('://', 1)
        frag_index = int(path.split('/')[-1])

# Generated at 2022-06-12 16:58:11.784351
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    def progress_hook(size, read):
        assert size > 0
        assert read <= size
    ext_dict = gen_extractors()
    url = 'https://cdn.svt.se/vod/d18daec6-c25f-45a6-8e22-2373cdbd515b/video/mp4/53/53bbd573-7e94-49e8-b740-80b9c3d1e0f3_2000k_vp9.mp4.list.m3u8'
    ext = 'hlsnative'
    fd = ext_dict[ext](dict(ydl=None))
    fd.add_progress_hook(progress_hook)
    info_dict = {}
    info_dict['url'] = url

# Generated at 2022-06-12 16:58:21.595556
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    """
    Unit test for method HlsFD.can_download.
    """
    import io

    assert can_download(io.StringIO('#EXTM3U'), {'is_live': False})
    assert can_download(io.StringIO('#EXTM3U\n#EXT-X-PLAYLIST-TYPE:VOD'), {'is_live': False})
    assert can_download(io.StringIO('#EXTM3U\n#EXT-X-PLAYLIST-TYPE:EVENT\n#EXT-X-ENDLIST'), {'is_live': False})
    assert can_download(io.StringIO('#EXTM3U\n#EXT-X-PLAYLIST-TYPE:EVENT'), {'is_live': False})


# Generated at 2022-06-12 16:58:33.656074
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .youtube import YoutubeFD
    from .dash import DashFD
    from .fragment import FragmentFD
    from ..extractor import YoutubeIE
    from ..ytdl_test_data import test_data
    from ..utils import fake_request_handler

    class FakeYDL:
        def urlopen(self, url):
            return fake_request_handler(url)

    test_data = test_data(
        'live', 'https://www.youtube.com/watch?v=MvfzKjV7T-A', 'live-hls',
        'live', 'https://www.youtube.com/watch?v=zbiESKeo6OQ', 'live-dash',
    )

    for params, ie_key in test_data:
        if FragmentFD.can_download(params):
            download

# Generated at 2022-06-12 16:58:43.159025
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import FileDownloader

    url = 'https://www.youtube.com/watch?v=0fKBhvDjuy0'
    ydl = FileDownloader({'format': 'bestvideo[protocol!=http_dash_segments]'})
    ydl.add_info_extractor(file_extractor_interf_ytdl(ydl))
    # Test the case where a subformat is selected, and where the parent format is HLS
    hls_info = ydl.process_ie_result(ydl.extract_info(url, download=False), download=False)
    hls_subfmt = next(s for s in hls_info['formats'] if 'mp4' in s['format_id'])
    hls_subfmt_manifest = hls_subf