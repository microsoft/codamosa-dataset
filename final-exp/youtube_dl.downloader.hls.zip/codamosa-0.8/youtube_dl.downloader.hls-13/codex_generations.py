

# Generated at 2022-06-12 16:49:14.080270
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD()

# Generated at 2022-06-12 16:49:19.993296
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import re
    import tempfile
    from .external import ExternalFD
    from .utils import download_checksum
    from ..extractor import YoutubeIE
    from ..utils import compat_urllib_request

    url = 'https://www.youtube.com/watch?v=a_isgmB6pv4'
    retval = YoutubeIE()._extract_info(
        YoutubeIE._download_webpage, url, None, download_webpage=False)
    youtube_url = retval['url']

    HlsFD.can_download(
        YoutubeIE()._extract_info(
            ExternalFD(YoutubeIE())._download_webpage,
            youtube_url, None, download_webpage=False), None)

    unittest_file = tempfile.NamedTemporaryFile(delete=False).name
   

# Generated at 2022-06-12 16:49:33.800370
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .extractor.common import InfoExtractor
    from .downloader import HlsFD
    from .compat import urlparse
    url = 'https://my-video-url.com/media/media.m3u8?my-query-parameter=my-value'
    info_dict = {
        'url': url,
        '_decryption_key_url': 'https://decryption-key-url.com/decryption-key.php?key=my-value',
        'extra_param_to_segment_url': 'my-key=my-value',
        'http_headers': {'my-header': 'my-value'},
        'test': True
    }
    ie = InfoExtractor(HlsFD())
    ie.ydl = HlsFD()

# Generated at 2022-06-12 16:49:46.799411
# Unit test for constructor of class HlsFD

# Generated at 2022-06-12 16:49:53.618992
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .tests import getTestFile

    from ..extractor.generic import GenericIE
    from ..jsinterp import JSInterpreter

    js = getTestFile('HlsFD.real_download.js', False)
    url = JSInterpreter(js).extract_function('url')()
    info_dict = GenericIE()._real_extract(url, {})

    fd = HlsFD()
    fd.real_download(None, info_dict)

# Generated at 2022-06-12 16:50:04.712734
# Unit test for constructor of class HlsFD
def test_HlsFD():
    '''
    Test the HlsFD constructor
    '''
    from ..downloader import YoutubeDL
    ydl = YoutubeDL({'verbose': True})
    hlsfd = HlsFD(ydl, {'skip_unavailable_fragments': True})

    assert(hlsfd.params['fragment_retries'] == 0)
    assert(hlsfd.params['skip_unavailable_fragments'] == True)

    hlsfd = HlsFD(ydl, {'fragment_retries': 5, 'verbose': True})
    assert(hlsfd.params['fragment_retries'] == 5)
    assert(hlsfd.params['skip_unavailable_fragments'] == False)


# Generated at 2022-06-12 16:50:12.623121
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeDL

# Generated at 2022-06-12 16:50:19.840306
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import io
    import tempfile
    import subprocess

    from ..extractor.generic import YoutubeIE
    from ..PostProcessor import run_postprocessors

    # We should not run this test if Python 2 is used
    if sys.version_info < (3,):
        sys.exit()

    # Test with YouTube playlist
    ydl = YoutubeIE(params={'noplaylist': True})
    ydl.add_default_info_extractors()

    result = ydl.extract_info(
        'https://www.youtube.com/watch?v=X_vO8W_IzOc',
        download=False,
    )
    playlist_id = result['id']

    # Get the fragment data
    urls = []

# Generated at 2022-06-12 16:50:33.087771
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    class Mock_urlopen():
        # Mock up of class urllib.request.urlopen
        def __init__(self, url, headers):
            self.url = url
            self.headers = headers
        def geturl(self):
            return self.url
        def read(self):
            return 'HLS test content'

    class Mock_FFmpegFD():
        # Mock up of class FFmpegFD
        def __init__(self, ydl, params):
            self._ydl = ydl
            self._params = params
        def _prepare_url(self, info_dict, url):
            return url
        def real_download(self, filename, info_dict):
            self._filename = filename
            self._info_dict = info_dict
            return True


# Generated at 2022-06-12 16:50:43.087752
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import FakeYDL
    ydl = FakeYDL()
    ydl._prepare_url = lambda *args: args[1]
    with open('test/testdata/hls/test.m3u8', 'rb') as test_file:
        test_manifest = test_file.read().decode()
    info_dict = {
        'id': 'test',
        'url': 'https://example.com/test.m3u8',
        'http_headers': {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:72.0) Gecko/20100101 Firefox/72.0'
        }
    }
    hls_fd = HlsFD(ydl, {})
    assert hls_fd.can_download

# Generated at 2022-06-12 16:51:07.458955
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U', {'url': 'http://foo.bar/', 'is_live': False, 'ext': 'mp4'})
    params = {'fragment_retries': 2, 'skip_unavailable_fragments': True}
    test_filename = 'test.mp4'
    from .extractor.common import InfoExtractor
    ie = InfoExtractor(None, {})
    # Failed download of fragment
    with ie._downloader.tmp_filename(test_filename) as test:
        assert not HlsFD.can_download('#EXTM3U', {'url': 'http://foo.bar/', 'is_live': False, 'ext': 'mp4'})

# Generated at 2022-06-12 16:51:20.505763
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from . import YoutubeDL
    from .extractor.youtube import YoutubeIE

    assert HlsFD.can_download(
        """#EXTM3U
#EXT-X-PLAYLIST-TYPE:VOD
#EXT-X-TARGETDURATION:8
#EXT-X-VERSION:3
#EXT-X-MEDIA-SEQUENCE:1
#EXT-X-KEY:METHOD=AES-128,URI="https://priv.example.com/key.php?r=52"
#EXTINF:2.833,
https://example.com/fileSequence52-A.ts
#EXTINF:15.0,
https://example.com/fileSequence52-B.ts
#EXT-X-ENDLIST
""", {'url': 'https://example.com/vod.m3u8'})

# Generated at 2022-06-12 16:51:32.429459
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testcases, MockYDL
    from ..extractor import youtube
    from ..utils import urlparse

    retcode = 0
    for t in get_testcases(True, [youtube], [(__file__.rsplit('.', 1)[0] + '.py', 'hlsnative')]):
        data = MockYDL(t.get('cfg'))
        data.add_default_info_extractor(youtube.YoutubeIE)
        ext = data.get_info_extractor(urlparse.urlparse(t['args'][0]).hostname)
        ext._real_extract = youtube._real_extract
        ext.http_headers = t.get('http_headers')
        ext._sleep = lambda x: None
        ext._file = None
        ext._downloader = data
        ext._

# Generated at 2022-06-12 16:51:33.532167
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Tested in test/test_download.py
    pass

# Generated at 2022-06-12 16:51:39.707802
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil

    from .filesystem import FileFD

    cwd = os.path.dirname(__file__)
    root = os.path.join(cwd, os.pardir, os.pardir)
    test_m3u8_file = os.path.join(root, 'youtube_dl', 'test', 'testid_HLS_140_1.m3u8')
    test_file = os.path.join(root, 'youtube_dl', 'test', 'test.tmp')

    with open(test_m3u8_file) as f:
        test_m3u8 = f.read()

    with open(test_file, 'rb') as f:
        test_content = f.read()

    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-12 16:51:51.957645
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # basic test for method real_download of HlsFD class
    from . import YoutubeDL
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    import os
    import tempfile
    import unittest
    import uuid

    class HlsFdTest(unittest.TestCase):

        def setUp(self):
            self.ydl = YoutubeDL({'format': 'bestvideo[height<=720]',
                                  'outtmpl': os.path.join(tempfile.gettempdir(), '%(id)s.%(ext)s'),
                                  'prefer_ffmpeg': False})

        def test_download_hls_native(self):
            playlist = self.ydl.extract_info(self.PLAYLIST, download=False)

# Generated at 2022-06-12 16:51:54.509241
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Test instantiation of class HlsFD
    HlsFD(None, {}, {})

# Generated at 2022-06-12 16:52:06.467688
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    try:
        from unittest.mock import patch
        from unittest.mock import MagicMock
    except ImportError:
        from mock import patch
        from mock import MagicMock
    from ..extractor.common import InfoExtractor
    from ..downloader.http import HttpFD
    ie = InfoExtractor()
    ie._prepare_url = MagicMock(return_value="http://test.url")
    ie._download_webpage = MagicMock(return_value=("test page", "test page url"))
    ie._download_manifest = MagicMock(return_value=("test manifest", "test manifest url"))
    ie._prepare_and_start_frag_download = MagicMock()
    ie._download_fragment = MagicMock(return_value=(True, b"fake data"))

# Generated at 2022-06-12 16:52:07.828919
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.__name__ == 'HlsFD'


# Generated at 2022-06-12 16:52:09.390635
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import doctest
    doctest.testmod(HlsFD)

if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-12 16:52:54.988702
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .http import HttpFD
    from .fragment import FragmentFD
    from ..utils import LimitFile
    from ..extractor import ExtractorError
    from .external import FFmpegFD
    from .dash import DashFD

    def test_real_download(urls, expected_frags, expected_error=None, extra_args=None):
        extra_args = extra_args or {}
        info = {
            'url': urls,
            'playlist': urls,
            'playlist_id': 0,
            'id': '',
            '_filename': '',
            'http_headers': {},
            '_decryption_key_url': None,
        }

# Generated at 2022-06-12 16:52:56.172873
# Unit test for constructor of class HlsFD
def test_HlsFD():
    return True

# Generated at 2022-06-12 16:53:08.452107
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from . import YoutubeDL
    # Construct a real-world test case
    ydl = YoutubeDL({'simulate': True})
    params = {}
    info_dict = {
        'http_headers': {
            'Range': 'bytes=0-69'
        }
    }
    frag_content = b'\xf0\x9f\x91\x8e\xf0\x9f\x91\x8e\xf0\x9f\x91\x8e\xf0\x9f\x91\x8e'
    def _download_fragment(ctx, frag_url, info_dict, headers):
        return True, frag_content
    # Ensure that the test case works

# Generated at 2022-06-12 16:53:09.435081
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass # TODO


# Generated at 2022-06-12 16:53:10.987226
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import CommonFDTestCase
    CommonFDTestCase(HlsFD).test_real_download()

# Generated at 2022-06-12 16:53:23.865059
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test_utils import _create_test_extractor

    FakeYoutubeDL = _create_test_extractor(HlsFD)

    def _fake_urlopen(url):
        return FakeFile(url)

    ydl = FakeYoutubeDL({'outtmpl': '%(id)s%(ext)s', 'format': '137+140/best'})
    ydl.urlopen = _fake_urlopen
    ydl.params['test'] = True
    ydl.params['fragment_retries'] = 1

    # Format 137+140/best

# Generated at 2022-06-12 16:53:35.078308
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .http import HttpFD
    from .external import FFmpegFD
    import datetime
    import unittest
    import youtube_dl
    import json
    import os
    import random
    import tempfile
    import shutil
    import sys
    import re
    assert sys.version_info >= (2, 7)

    class TestHlsNativeFD(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.ydl = youtube_dl.YoutubeDL({'outtmpl': os.path.join(self.temp_dir, '%(id)s-%(format_id)s-%(fragment_index)s.%(ext)s'),
                                             'quiet': True})

# Generated at 2022-06-12 16:53:47.180843
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import json
    from .f4m import F4mFD
    from .dash import DashFD
    from .http import HttpFD
    from .scte35 import Scte35FD
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import sanitize_open

    def download_video(url, ext, params={}):
        ydl = YoutubeDL({'quiet': True, 'skip_download': True})
        ie = YoutubeIE(ydl)
        result = ie.extract(url)
        info_dict = json.loads(json.dumps(result))
        params = dict(params)
        params['quiet'] = True
        params['format'] = '%(format_id)s'
        params['nooverwrites'] = True

# Generated at 2022-06-12 16:53:56.882810
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # class object should be defined outside of function scope
    # in order to be used in assert statements
    class HlsFD(HlsFD):
        @staticmethod
        def can_download(manifest, info_dict):
            return FragmentFD.can_download(manifest, info_dict)

    # Can download non-encrypted stream
    manifest = '#EXTM3U\n#EXTINF:10,\n001.ts\n#EXTINF:10,\n002.ts\n#EXTINF:10,\n003.ts\n'
    info_dict = {}
    assert HlsFD.can_download(manifest, info_dict)

    # Can download encrypted stream

# Generated at 2022-06-12 16:54:04.489623
# Unit test for constructor of class HlsFD
def test_HlsFD():
    class YDlMock(object):
        def urlopen(self, url):
            return url

    ydl = YDlMock()
    params = {'test': True}
    url = 'http://video.example.com/manifest.m3u8'
    hlsfd = HlsFD(ydl, params)
    hlsfd.add_progress_hook(lambda *args: None)
    assert hlsfd.real_download(None, {'url': url})

# Generated at 2022-06-12 16:55:20.388774
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..downloader.http import HttpFD
    from ..utils import sanitize_open

    class HlsFDTest(HlsFD):
        ydl = InfoExtractor({})
        urlopen = HttpFD().urlopen

        def report_warning(self, msg):
            pass

        def report_error(self, msg):
            pass

        def _prepare_url(self, ie, url):
            return url

        def _download_fragment(self, ctx, frag_url, info_dict, headers):
            # just return a slice of some data
            frag_content = b'a' * (ctx['total_frags'] - ctx['fragment_index'])
            ctx['fragment_index'] += 1
            return True, frag_

# Generated at 2022-06-12 16:55:28.236859
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from unittest import TestCase

# Generated at 2022-06-12 16:55:39.925229
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testdata
    from ..utils import determine_ext

    fragment_handle = compat_urllib_request.urlopen(get_testdata('5s_frag.ts'))
    fragment_content = fragment_handle.read()

    manifest_handle = compat_urllib_request.urlopen(get_testdata('5s_playlist.m3u8'))
    manifest_unparsed = manifest_handle.read()
    manifest_content = manifest_unparsed.decode('utf-8', 'ignore')
    manifest_url = manifest_handle.geturl()


# Generated at 2022-06-12 16:55:47.514078
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import FileDownloader
    from .extractor.generic import GenericIE
    import os
    from .common import InfoExtractor
    from .compat import compat_urlparse
    from .extractor.youtube import YoutubeIE
    from .utils import url_basename
    IE_NAME = 'test'
    test = HlsFD(FileDownloader({
        'format': 'bestvideo[protocol^=http]/best',
        'outtmpl': os.devnull,
        'noprogress': True,
        'quiet': True,
    }))
    MANIFEST_URL = 'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8'
    URL_PARSED

# Generated at 2022-06-12 16:55:52.963549
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    class HlsFD(HlsFD):
        def __init__(self, *args, **kwargs):
            super(HlsFD, self).__init__(*args, **kwargs)
            self.test_method_real_download_called = False
            self.test_method_prepare_url_called = False
            self.test_method_download_fragment_called = False
            self.test_method_append_fragment_called = False
            self.test_method_finish_frag_download_called = False
            self.test_method_frag_progress_called = False
            self.test_method_download_fragment_enc_called = False


# Generated at 2022-06-12 16:56:01.462039
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import verify_file_checksum_in_url
    from .fragment import FragmentFD
    from .http import HttpFD
    from .dash import DashSegmentsFD
    # Check one of the HLS variants
    url = "https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8"
    info_dict = {
        '_type': 'hls',
        'id': 'test_hlsfd_realdownload',
        'url': url,
        'title': 'test_hlsfd_realdownload',
        'ext': 'mp4',
        'http_headers': {},
    }
    ydl_parameters = {}
    # Test the

# Generated at 2022-06-12 16:56:12.095905
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    from ..extractor.lifenews import LifenewsIE
    from ..extractor.aenetworks import AENetworksIE
    from ..compat import compat_str
    from unittest import TestCase
    import os
    import pprint
    import subprocess

    TEST_DIR = os.path.dirname(__file__)

    class BaseTestCase(TestCase):
        def setUp(self):
            self.test_data_dir = os.path.join(TEST_DIR, 'test_data', self.__class__.__name__)


# Generated at 2022-06-12 16:56:19.715797
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import re
    import io
    import os
    import http.server
    import socketserver
    import threading
    import binascii
    from .external import FFmpegFD
    from .fragment import FragmentFD
    from .external import YoutubeDLHandler
    from .utils import FileDownloader
    from ..compat import (
        compat_urllib_error,
        compat_urlparse,
        compat_struct_pack)
    from ..utils import sanitize_open
    from ..extractor import YoutubeIE
    from ..utils import (
        parse_m3u8_attributes,
        update_url_query)

    def mock_urlopen(url, **kwargs):
        class MockResponse(object):
            def __init__(self, text):
                self.text = text


# Generated at 2022-06-12 16:56:30.639312
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..compat import unittest
    from ..extractor.common import InfoExtractor

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.ie = InfoExtractor(None)

        # No need to test cases that are not handled by real_download,
        # HlsFD.can_download calls can handle those cases
        # @unittest.skip('Not sure how to test live streams.')
        def test_live_streams(self):
            pass

        # @unittest.skip('Not sure how to test playlists composed of byte ranges of media files.')
        def test_playlists_composed_of_byte_ranges_of_media_files(self):
            pass

        # @unittest.skip('Not sure how to test media segments are appended to the

# Generated at 2022-06-12 16:56:37.516025
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import sys
    import unittest

    import ytdl_mocks

    from .external import ExternalFD

    from ..extractor import YoutubeDL
    from ..utils import encodeFilename

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.ydl = YoutubeDL({'hls_prefer_native': True})
            self.ydl.cache.remove()
            self.ydl.params['nooverwrites'] = True
            self.ydl.params['outtmpl'] = encodeFilename('%(title)s-%(id)s.%(ext)s')
            self.ydl.params['test'] = True

        def test_download(self):
            id_ = '68tOiOt-fz0'
            self.ydl