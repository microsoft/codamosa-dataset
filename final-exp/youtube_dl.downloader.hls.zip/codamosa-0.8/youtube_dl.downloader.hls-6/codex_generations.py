

# Generated at 2022-06-12 16:49:20.259131
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    def run_test_HlsFD_real_download(info_dict, media_fragment_index, ref_fd, ref_fd_params=None,
                                     fragment_retries=0, skip_unavailable_fragments=True):
        fd = HlsFD(None, {}) # ydl will be replaced by test code in real_download
        fd.params = {
            'fragment_index': media_fragment_index,
            'fragment_retries': fragment_retries,
            'skip_unavailable_fragments': skip_unavailable_fragments,
        }
        return fd.real_download('test.ts', info_dict)

# Generated at 2022-06-12 16:49:31.900495
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'noprogress': True, 'logger': sys.stdout})
    ydl.add_default_info_extractors()
    HlsFD.real_download(
        HlsFD(ydl, {'socket_timeout': 300}),
        'test.ts',
        {
            'id': 'testid',
            'url': 'http://example.com/index.m3u8',
            '_type': 'hls',
        })

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-12 16:49:44.398758
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    print("UNIT TEST STARTED FOR CLASS HlsFD")
    import sys
    import os
    print("Adding {} to path".format(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))))
    sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))) # For importing youtube_dl
    import youtube_dl

    # Since we are testing the download process, we donot need the logger
    ydl_logger = logging.getLogger("youtube_dl")
    ydl_logger.disabled = True

    ydl = youtube_dl.YoutubeDL({'logtostderr': False, 'quiet': True, 'noprogress': True, 'verbose': False})


# Generated at 2022-06-12 16:49:55.652773
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Can download
    assert HlsFD.can_download(
        '''#EXTM3U
#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=200000
lo/prog_index.m3u8
#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=311111
hi/prog_index.m3u8
#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=484444
hls_450k_video.ts''',
        {})

# Generated at 2022-06-12 16:50:05.191976
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import shutil
    import tempfile
    import unittest
    from unittest import mock

    from ..utils import prepend_extension
    from ..compat import compat_urlopen

    def get_info_dict(url, **kwargs):
        return {
            'url': url,
            'id': 'test',
            'display_id': 'test',
            'filename': 'test',
            'protocol': 'hls_native',
            'http_headers': {},
        }

    def _test_hls_fd(context, manifest, test_function):
        base_url = 'http://example.com/'
        mock_urlopen = mock.MagicMock(side_effect=lambda x, timeout=None: compat_urlopen(base_url + x, timeout=timeout))
       

# Generated at 2022-06-12 16:50:05.978028
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # TODO: Write the unit test
    pass

# Generated at 2022-06-12 16:50:07.063415
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.__name__ == 'HlsFD'
    return True

# Generated at 2022-06-12 16:50:14.803135
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    filename = 'test_data/test_HlsFD_real_download_frag.ts'
    manifest = b'''#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:13
#EXT-X-MEDIA-SEQUENCE:0
#EXT-X-KEY:METHOD=AES-128,URI="https://priv.example.com/key.php?r=52",IV=0x9c7db8778570d05c3177c349fd9236aa
#EXTINF:4.000000,
http://media.example.com/segment1.ts
#EXTINF:10.000000,
http://media.example.com/segment2.ts
#EXT-X-ENDLIST
'''

    ydl = MockYdl()

    # Test not

# Generated at 2022-06-12 16:50:16.255556
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD('youtube-dl') is not None

# Generated at 2022-06-12 16:50:18.042641
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD({}, {}, None)._download_fragment({}, None, {}, {})

# Generated at 2022-06-12 16:50:41.728649
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    for ie in gen_extractors():
        if hasattr(ie, '_WORKING') and not ie._WORKING:
            continue
        if not hasattr(ie, '_VALID_URL'):
            continue
        if not ie._VALID_URL:
            continue
        if ie.IE_NAME in ('Gfycat', 'Imgur'):
            # Gfycat and Imgur pass confirmed_working=False to
            # YoutubeDL.__init__ which would make tests fail as it will
            # redirect to URL with age verification form
            continue

        ie.extractor = ie
        ie.suitable = lambda *args: True
        ie._download_webpage = lambda *args, **kargs: (args, kargs)

# Generated at 2022-06-12 16:50:48.194094
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import time
    import os
    import sys
    import tempfile
    from io import BytesIO
    from ..utils import fmt_bytes

    time_start = time.time()
    params = {
        'format': '141/251',  # DASH mp4 video and audio
        'noplaylist': True,
        'skip_download': True,
        'test': True,
    }
    ydl = YouTubeDL(params)

    videoid = 'dQw4w9WgXcQ'
    videoid_url = 'http://www.youtube.com/watch?v=%s' % videoid

    # Test with a non-existent video id
    (result, info) = ydl.extract_info(videoid_url, download=False)

# Generated at 2022-06-12 16:50:49.503502
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD

# Generated at 2022-06-12 16:51:02.022769
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import YoutubeDL
    from .extractor import YoutubeIE
    from .utils import FakeYDL
    from .extractor.common import InfoExtractor
    test_cases = [
        ('https://www.youtube.com/watch?v=hY7m5jjJ9mM', True, 'hls', False),
        ('https://www.youtube.com/watch?v=y_YpJuzk5cA', False, 'hls', True),
        ('https://www.youtube.com/watch?v=kfVsfOSbJY0', False, 'hls', True),
        ('https://www.youtube.com/watch?v=jkpPT5o5Pdg', True, 'hls', False),
    ]


# Generated at 2022-06-12 16:51:10.851858
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader

    # TODO: Add more unit tests for this extraction method
    # Call real_download method to create a video using method real_download
    # of class HlsFD
    hlsfd = HlsFD()
    hlsfd._prepare_url = lambda a, b: b
    hlsfd.real_download(
        filename='test_video.mp4',
        info_dict={
            'id': '987567',
            'url': 'http://test.url/test.mp4',
            'http_headers': {'User-Agent': 'test user agent'},
        }
    )

    # TODO: Remove dependency on extractor/downloader
    # Call real_download method to create a video using method real_download

# Generated at 2022-06-12 16:51:24.064766
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import tempfile

    # TODO: Add tests for other methods

    # Test with an encrypted hls stream
    def _test_hls_encrypted(video_info):
        with tempfile.NamedTemporaryFile(suffix='.ts') as tf:
            fd = HlsFD(None, video_info['params'] or {})
            fd.real_download(tf.name, video_info)


# Generated at 2022-06-12 16:51:34.897905
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testcases

    for name, url, kwargs in get_testcases(['hlsnative']):
        import os
        import math
        import youtube_dl.YoutubeDL
        print('Running test %s' % name)
        filename = os.path.join(os.path.dirname(__file__), 'test_files', name)
        expected_filesize = int(math.ceil(kwargs['filesize'] / (kwargs.get('fragsize') or kwargs['filesize'])))
        with youtube_dl.YoutubeDL({'outtmpl': filename, 'format': 'hlsnative-test', 'quiet': True, 'skip_download': True, 'nooverwrites': True, 'test': True}) as ydl:
            kwargs['url'] = url
           

# Generated at 2022-06-12 16:51:48.296248
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import platform
    import sys
    import os
    test_dir = os.path.dirname(__file__)
    sys.path.insert(0, os.path.join(test_dir, '..', '..', '..'))
    from youtube_dl.YoutubeDL import YoutubeDL
    from tests.test_downloader_http import MockServerProcessHandler

    class HlsFDDLTest(unittest.TestCase):
        def setUp(self):
            super(HlsFDDLTest, self).setUp()

            class HlsFD(HlsFD):
                def __init__(self, ydl, params):
                    super(HlsFD, self).__init__(ydl, params)

                def _prepare_url(self, info_dict, url):
                    return url

# Generated at 2022-06-12 16:51:50.422777
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hf = HlsFD()
    print('Successfully imported HlsFD')

if __name__ == "__main__":
    test_HlsFD()

# Generated at 2022-06-12 16:51:57.062730
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import YoutubeDL
    from ..utils import encodeFilename
    import threading
    import socket
    import json
    import os

    video_id = 'mKnwWYGwiIk'
    youtube_url = 'http://www.youtube.com/watch?v=%s' % video_id

# Generated at 2022-06-12 16:52:15.885224
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Test hlsnative can_download
    # unpatch
    hlsnative_can_download = HlsFD.can_download
    # patch
    hlsnative_can_download_called = False
    def can_download_patch(manifest, info_dict):
        hlsnative_can_download_called = True
        return hlsnative_can_download(manifest, info_dict)
    HlsFD.can_download = can_download_patch

    # good manifest

# Generated at 2022-06-12 16:52:20.098906
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import unittest
    import os.path
    from .testutils import FakeYDL

    test_files_dir = os.path.join(os.path.dirname(__file__), 'test_files')

    def get_test_file_fobj(filename):
        return open(os.path.join(test_files_dir, filename), 'rb')

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.ydl = FakeYDL()
            self.fd = HlsFD(self.ydl, {'simulate': True})
            self.fd.to_stdout = lambda x: sys.stdout.write(x + '\n')


# Generated at 2022-06-12 16:52:21.713965
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD(None, {}).FD_NAME == 'hlsnative'


# Generated at 2022-06-12 16:52:32.870019
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .utils import FakeYDL
    import os
    import tempfile
    can_down_test_dir_path = os.path.join(os.path.dirname(__file__), 'test_cases', 'can_down')
    for test_file_name in os.listdir(can_down_test_dir_path):
        test_file_path = os.path.join(can_down_test_dir_path, test_file_name)
        test_file = open(test_file_path, 'r')
        test_m3u8 = test_file.read()
        test_file.close()
        test_file = open(test_file_path.replace('_m3u8', '_result'), 'r')
        expected_result = bool(int(test_file.read()))
        test

# Generated at 2022-06-12 16:52:42.506615
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .helpers import FakeYDL
    from .extractor.common import InfoExtractor
    from ..utils import *

    # Downloading the video does not require any additional parameters, mock up extractor.
    class HlsNativeIE(InfoExtractor):
        IE_NAME = 'hlsnative'
        def __init__(self, ydl): pass
        def _real_extract(self, url):
            pass

    ydl = FakeYDL()
    ie = HlsNativeIE(ydl)
    fd = HlsFD(ydl, {'format': '22', 'test_hls_download': True})
    # Manifest url is not used, we mock up the manifest data.

# Generated at 2022-06-12 16:52:47.748132
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import FakeYDL, FakeInfoDict
    from ..utils import write_stringio

    import io
    import tempfile

    ydl = FakeYDL(params={'test': True})

# Generated at 2022-06-12 16:52:58.761974
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import gen_extractors
    from ..compat import compat_urllib_request
    import io
    import os
    import random
    import sys
    import tempfile
    import threading

    extractors = gen_extractors()
    HlsFD.can_download = lambda *args: True
    HlsFD._download_fragment = lambda *args: (False, None)


# Generated at 2022-06-12 16:53:01.898933
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('', {'url': 'url'}) == True

if __name__ == 'main':
    test_HlsFD()

# Generated at 2022-06-12 16:53:12.505061
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ytdl.downloader import YoutubeDL
    from ytdl.utils import is_url

    opts = {
        "verbose": True,
        "playlist_items": 50,
        "dump_single_json": True,
        "skip_download": True,
        "youtube_include_dash_manifest": False,
        "min_views": 0,
    }
    ydl = YoutubeDL(opts)
    url = "http://www.youtube.com/watch?v=FIR6i_T0T9E"
    vid = "FIR6i_T0T9E"

    with open("youtube3.dump") as f:
        meta = f.read()
    info_dict = ydl.process_ie_result(meta, download=False)["entries"][0]

# Generated at 2022-06-12 16:53:25.409644
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import sys
    import pytest
    from .test_utils import FakeYDL, FakeXAttrFD, FakeInfoDict, Partial
    from io import BytesIO

    # Create an instance of the Ydl class
    def call_download(ydl, url, info_dict, filename):
        # Override default filename with the URL's path
        filename = os.path.join(
            os.path.dirname(__file__), filename)
        # Create a fake instance of XAttrMetadataFD and attach
        # it to the downloader as the HLS fragment downloader
        ydl.xattr_fd = FakeXAttrFD()
        fd = HlsFD()
        for ph in fd._progress_hooks:
            fd.remove_progress_hook(ph)
        fd.add_

# Generated at 2022-06-12 16:54:06.954652
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import shutil
    from unittest import TestCase
    from tempfile import mkstemp
    from ..compat import parse_qs, urlparse
    from ..downloader import FakeYDL

    class HlsFDTest(TestCase):

        def setUp(self):
            self.test = HlsFD(FakeYDL(), None)
            self.test.to_screen = lambda *a, **k: None

        def test_real_download(self):
            _, self.tmp_file = mkstemp(text=True)

            self.expected_download_count = 0
            def mock_download_fragment(_ctx, _frag_url, _info_dict, headers):
                self.assertEqual(self.expected_download_count, 0)
                self.expected_download_count += 1
                self.assertE

# Generated at 2022-06-12 16:54:16.040842
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..downloader import YoutubeDL
    from .fragment import DownloadContext

    ydl = YoutubeDL()
    ydl.add_info_extractor('m3u8')
    # taken from http://devimages.apple.com/iphone/samples/bipbop/gear1/prog_index.m3u8

# Generated at 2022-06-12 16:54:26.953030
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # common scenarios
    assert HlsFD.can_download('#EXTM3U', {})
    assert HlsFD.can_download(
        ('#EXTM3U\n'
         '#EXT-X-STREAM-INF:BANDWIDTH=2090000,RESOLUTION=1024x576\n'
         'high/index.m3u8\n'
         '#EXT-X-STREAM-INF:BANDWIDTH=65000,RESOLUTION=304x176\n'
         'low/index.m3u8\n'),
        {})

# Generated at 2022-06-12 16:54:28.104709
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, None)

# Generated at 2022-06-12 16:54:29.413528
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert(HlsFD.can_download('', {'url': 'https://example.com/'}))


# Generated at 2022-06-12 16:54:38.217652
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # import necessary modules
    import sys
    import os
    import io
    import tempfile
    import unittest.mock
    import pytest
    import subprocess

    # import youtube_dl
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))
    from youtube_dl import YoutubeDL

    # do not allow file output, _real_download_convert_to_aes is not implemented
    def fake_can_download(manifest, info_dict):
        return HlsFD.can_download(manifest, info_dict) and not get

# Generated at 2022-06-12 16:54:48.590293
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # import youtube_dl.downloader.HlsFD
    # import youtube_dl.utils
    # youtube_dl.downloader.HlsFD.HlsFD().can_download(youtube_dl.utils.FileDownloader("", {}), {})
    #    raises TypeError("can_download() missing 1 required positional argument: 'info_dict'")
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    # downloader.HlsFD.HlsFD().can_download(ydl, {})
    #    raises TypeError("can_download() missing 1 required positional argument: 'info_dict'")
    from youtube_dl.downloader.http import HttpFD
    # HttpFD.HttpFD(ydl, {}).can_download(ydl, {})
    #    complains that 'man

# Generated at 2022-06-12 16:54:54.242112
# Unit test for constructor of class HlsFD
def test_HlsFD():
    manifest_url = 'https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8'
    ydl_opts = {}
    info_dict = {
        'id': 'bipbop_4x3',
        'extractor': 'hlsnative',
        'url': manifest_url,
    }
    hls_fd = HlsFD(ydl_opts, info_dict)

# Generated at 2022-06-12 16:54:56.520834
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD(None, {}).FD_NAME == 'hlsnative'


# Generated at 2022-06-12 16:55:05.635276
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from test.helper import FakeYDL
    fake_ydl = FakeYDL()
    hls_fd = HlsFD(fake_ydl, None)
    # Test call with unsupported manifest attributes

# Generated at 2022-06-12 16:56:19.182486
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import json
    import os
    import shutil
    import sys
    import tempfile

    try:
        from pycryptodome.cipher import AES
    except ImportError:
        print('Skipping test_HlsFD_real_download. pycryptodome not found.', file=sys.stderr)
        return

    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .utils import determine_ext, search_dict

    def _run_real_download(ie, video_id, test, result_path):
        video_info = ie._real_extract(video_id)
        fd = HlsFD(ie._downloader, ie._downloader.params)

# Generated at 2022-06-12 16:56:29.962481
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import json
    from sys import exit
    from .downloader import YoutubeDL

    # Test data:
    #  7 segements of test video
    #  start parameter included with "extra_param_to_segment_url"
    #  encrypted (concatenated)

# Generated at 2022-06-12 16:56:37.056120
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from tests.test_download import fake_info_dict
    from .common import FakeYDL
    from .http import HttpFD

    ydl = FakeYDL()
    hls_fd = HlsFD(ydl, {'prefer_ffmpeg': False})
    url = 'https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_adv_example_hevc/master.m3u8'
    info_dict = fake_info_dict(url, params={
        'skip_unavailable_fragments': True,
        'fragment_retries': 5
    })
    assert hls_fd.real_download('./test_output.mp4', info_dict) is True

    ydl.counters['retry'] = 0
    hls_fd_

# Generated at 2022-06-12 16:56:42.470606
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testdata_file, get_temp_filename
    from .external import ExternalFD
    from .utils import SameFileError
    from .extractor.common import InfoExtractor

    data_dir = get_testdata_file('hls')
    ie = InfoExtractor('foo', {'http_chunk_size': 10})
    ie._downloader = object()
    ie._downloader.params = {'test': True}
    ie._downloader.cache = None

    # test Apple HLS manifest
    manifest_path = os.path.join(os.path.dirname(data_dir), 'AppleHttpLiveStreaming.m3u8')
    result_file_path = get_temp_filename('test1.ts')

# Generated at 2022-06-12 16:56:55.208588
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testcases_supporting_fragdownloader_by_fdname
    testcases = get_testcases_supporting_fragdownloader_by_fdname('hlsnative')
    # Filter out testcases that are not supported by HlsFD
    testcases = [tc for tc in testcases if HlsFD.can_download(tc['manifest'], tc['info_dict'])]
    # Filter out testcases where the downloaded data has been explicitly truncated
    # During the tests we only download the first fragment
    testcases = [tc for tc in testcases if r'#EXT-X-MAP:' not in tc['manifest']]
    # Filter out testcases where the downloaded data is not to a valid block size

# Generated at 2022-06-12 16:57:03.991598
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        import Crypto.Cipher.AES
    except ImportError:
        print('\n[Warning] test_HlsFD() was skipped because the pycryptodomex package was not found.\n')
        return
    from .downloader import FileDownloader
    from .extractor import YoutubeIE

    ydl_opts = {
        'skip_download': True,
        'writeinfojson': True,
        'nopart': True,
        'quiet': True,
        'simulate': True,
        'format': '141/140/249/250',
    }
    video_id = '8C_5Y5-fYyU'
    with FileDownloader(ydl_opts) as ydl:
        ydl.add_info_extractor(YoutubeIE)
        # first check if

# Generated at 2022-06-12 16:57:09.365345
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_url = 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8'
    assert HlsFD.can_download(test_url)
    ydl = YoutubeDL({'verbose': False})
    assert HlsFD(ydl, {}).can_download(test_url)

# Generated at 2022-06-12 16:57:19.249330
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'quiet': True, 'skip_download': True, 'hls_prefer_native': True})
    ydl.add_default_info_extractors()
    hls_fd = HlsFD(ydl, {})
    assert(hls_fd.can_download('#EXTM3U', {'url': ''}))
    assert(not hls_fd.can_download('#EXT-X-KEY:METHOD=AES-128', {'url': ''}))
    assert(hls_fd.can_download('#EXT-X-MEDIA-SEQUENCE:0', {'url': '', 'is_live': False}))

# Generated at 2022-06-12 16:57:26.398860
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .http import HttpFD
    from .fragment import FragmentFD
    from .external import FFmpegFD
    class NullYDL():
        class NullIE():
            def __init__(self):
                self.name = 'test'
        ie = NullIE()
        def report_error(self, msg):
            print(msg)
        def to_screen(self, msg):
            print(msg)
        @staticmethod
        def urlopen(url):
            print("Downloaded '%s'" % url)
            return lambda x: "Downloaded '%s'" % x
    hls_fd = HlsFD(NullYDL(), {'test':'test'})
    assert isinstance(hls_fd, FragmentFD)
    assert not isinstance(hls_fd, FFmpegFD)

# Generated at 2022-06-12 16:57:35.964891
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    class YDL:
        params = {}

        def add_progress_hook(self, hook):
            pass

        def urlopen(self, url):

            class HTTPError(object):
                headers = {'Content-Length': 3}
                code = 200
                msg = 'OK'
                url = url

                def read(self):
                    return b'abc'

            if url == 'abc.m3u8':
                return HTTPError()
            if url == 'http://a.com/a/a.ts':
                return HTTPError()
            if url == 'http://a.com/a/a1.ts':
                return HTTPError()
            raise Exception(url)

        def to_screen(self, msg):
            pass

        def report_error(self, msg):
            raise Exception(msg)

    assert Hls