

# Generated at 2022-06-18 13:20:08.131479
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ie = YoutubeIE(ydl)
    info = ie.extract('https://www.youtube.com/watch?v=hY7m5jjJ9mM')
    fd = HlsFD(ydl, {'hls_prefer_native': True})
    fd.real_download(info['id'] + '.mp4', info)

    # Test with a key
    info = ie.extract('https://www.youtube.com/watch?v=J---aiyznGQ')

# Generated at 2022-06-18 13:20:19.710711
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    from .common import FakeYDL

    class FakeIE(InfoExtractor):
        def _real_initialize(self):
            pass

    ie = FakeIE({})
    ydl = FakeYDL()
    ydl.add_info_extractor(ie)
    ydl.params['test'] = True
    ydl.params['noprogress'] = True
    ydl.params['quiet'] = True
    ydl.params['skip_download'] = True
    ydl.params['outtmpl'] = '%(id)s'
    ydl.params['writedescription'] = True
    ydl.params['writeinfojson'] = True

# Generated at 2022-06-18 13:20:32.183264
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .utils import encode_data_uri

    def _mock_urlopen(url):
        if url == 'http://manifest.url/manifest.m3u8':
            return compat_urllib_request.addinfourl(
                compat_urllib_request.BytesIO(get_test_data(
                    'hls_manifest.m3u8')),
                '', url, 200)

# Generated at 2022-06-18 13:20:42.740278
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ie = YoutubeIE(ydl)
    info = ie.extract('https://www.youtube.com/watch?v=BaW_jenozKc')
    fd = HlsFD(ydl, {'hls_prefer_native': True})
    fd.real_download(info['id'] + '.mp4', info)

    # Test with AES-128 encryption
    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ie = YoutubeIE(ydl)

# Generated at 2022-06-18 13:20:53.230267
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import fake_http_server_handler

    class FakeIE(InfoExtractor):
        IE_NAME = 'FakeIE'
        _VALID_URL = r'https?://.*'

        def _real_extract(self, url):
            return {
                'id': 'fake_id',
                'url': url,
                'title': 'fake_title',
                'formats': [{
                    'url': 'http://127.0.0.1:8080/fake_manifest.m3u8',
                    'format_id': 'hls',
                    'ext': 'mp4',
                }],
            }

    class FakeGenericIE(GenericIE):
        IE_NAME = 'FakeGenericIE'

# Generated at 2022-06-18 13:21:04.615261
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .http import HttpFD
    from .external import ExternalFD

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'test': True,
                'noprogress': True,
            }


# Generated at 2022-06-18 13:21:18.060261
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..utils import prepare_filename
    from ..compat import compat_urllib_request

    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    ydl = FileDownloader({'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_info_extractor(YoutubeIE())
    ydl.add_default_info_extractors()
    ydl.params['test'] = True
    ydl.params['noplaylist'] = True
    ydl.params['quiet'] = True
    ydl.params['forcetitle'] = True
    ydl.params['forceid'] = True

# Generated at 2022-06-18 13:21:30.904964
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str
    from ..extractor.common import InfoExtractor
    from ..postprocessor import FFmpegMergerPP
    from ..postprocessor.common import PostProcessor
    from ..postprocessor.ffmpeg import FFmpegPostProcessor
    from ..postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from ..postprocessor.ffmpeg import FFmpegMetadataPP
    from ..postprocessor.ffmpeg import FFmpegFixupStretchedPP
    from ..postprocessor.ffmpeg import FFmpegFixupM3u8PP
    from ..postprocessor.ffmpeg import FFmpegFixupM4aPP
    from ..postprocessor.ffmpeg import FFmpegFixupM4aPP


# Generated at 2022-06-18 13:21:40.345282
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..utils import prepend_extension
    from ..compat import compat_str
    from .fragment import FragmentFD
    from .external import FFmpegFD

    # Test that HlsFD is not used when it should not be
    # (e.g. encrypted streams, live streams)
    def test_HlsFD_not_used(manifest, info_dict):
        fd = HlsFD(FileDownloader({}), {})
        assert not fd.can_download(manifest, info_dict)

    # Test that HlsFD is used when it should be
    # (e.g. non-encrypted streams, non-live streams)
    def test_HlsFD_used(manifest, info_dict):
        f

# Generated at 2022-06-18 13:21:49.717324
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError
    from .http import HttpFD
    from .external import ExternalFD
    from .dash import DashSegmentsFD
    from .m3u8 import M3u8FD

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params

        def to_screen(self, msg):
            pass

        def report_warning(self, msg):
            pass

        def report_error(self, msg):
            raise ExtractorError(msg)

        def urlopen(self, url):
            return HttpFD(self, {'url': url}).download()

    class FakeIE(InfoExtractor):
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-18 13:22:18.322926
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..compat import compat_urllib_request
    from ..utils import encode_data_uri

    # Test data
    # The following m3u8 file is a truncated version of the one from
    # https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8
    # The first fragment is not encrypted, the second one is encrypted with the key
    # from https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/gear1/prog_index.m3u8
    # The third fragment is not encrypted and is a byte range of the

# Generated at 2022-06-18 13:22:30.876055
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.utils
    import youtube_dl.downloader.fragment
    import youtube_dl.downloader.hls
    import youtube_dl.downloader.http

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(delete=False, dir=temp_dir)
    temp_file.close()

    # Create a youtube-dl object

# Generated at 2022-06-18 13:22:40.284927
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..compat import compat_urllib_request
    from ..utils import url_basename

    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    ie = InfoExtractor(FileDownloader())
    info_dict = ie.extract(url)
    hls_url = info_dict['url']
    hls_basename = url_basename(hls_url)
    hls_fd = HlsFD(FileDownloader(), {'hls_use_mpegts': True})
    hls_fd.real_download(hls_basename, {'url': hls_url})

# Generated at 2022-06-18 13:22:52.257863
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    from .test_utils import FakeYDL
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .compat import compat_str
    from .utils import encode_data_uri

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a fake ydl object
    ydl = FakeYDL()
    ydl.params['noprogress'] = True
    ydl.params['logger'] = ydl
    ydl.params['outtmpl'] = os.path.join(temp_dir, '%(id)s')
    ydl.params['writedescription'] = False
    ydl.params['writeinfojson'] = False

# Generated at 2022-06-18 13:23:03.451314
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .common import FakeYDL
    from .test_fragment import TestFragmentFD
    import os
    import tempfile

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'is_live': False,
                'extractor': 'test',
                'title': 'test',
            }

    class FakeHlsFD(HlsFD):
        def _download_fragment(self, ctx, frag_url, info_dict, headers):
            return True, b'\x00' * ctx['fragment_size']


# Generated at 2022-06-18 13:23:14.103955
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'quiet': True})
    ie = YoutubeIE(ydl)
    ie.extract('https://www.youtube.com/watch?v=XxVg_s8xAms')
    info_dict = ydl.extract_info(
        'https://www.youtube.com/watch?v=XxVg_s8xAms', download=False)

    # Test with a manifest that has no encryption

# Generated at 2022-06-18 13:23:25.980682
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str

    def test_HlsFD_can_download(manifest, info_dict):
        return HlsFD.can_download(manifest, info_dict)

    def test_HlsFD_real_download(filename, info_dict):
        return HlsFD(gen_ydl()).real_download(filename, info_dict)

    def test_HlsFD_can_download_and_real_download(url, info_dict):
        ydl = gen_ydl()
        for ie in gen_extractors():
            if match_filter_func(ie.IE_NAME)(url):
                ie = ie.ie
                break

# Generated at 2022-06-18 13:23:34.175668
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    from .common import FakeYDL
    from .test_fragment import _test_frag_download
    from .test_external import _test_external_download
    from .test_external import _test_external_download_with_info_dict
    from .test_external import _test_external_download_with_info_dict_and_params
    from .test_external import _test_external_download_with_info_dict_and_params_and_hooks


# Generated at 2022-06-18 13:23:46.824993
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str

    ydl = gen_ydl()
    ydl.params['noplaylist'] = True
    ydl.params['quiet'] = True
    ydl.params['format'] = 'bestvideo+bestaudio/best'
    ydl.params['match_filter'] = match_filter_func('is_live == False')
    ydl.params['test'] = True
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_use_mpegts'] = True
    ydl.params['hls_segment_skip_seconds'] = 1

# Generated at 2022-06-18 13:23:55.671464
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request

    # Test with a non-encrypted stream
    ydl = YoutubeDL({'hls_prefer_native': True})
    ydl.add_default_info_extractors()
    ie = YoutubeIE(ydl)
    info = ie.extract('https://www.youtube.com/watch?v=nPt8bK2gbaU')
    assert info['formats'][0]['protocol'] == 'm3u8_native'

    # Test with an encrypted stream
    ydl = YoutubeDL({'hls_prefer_native': True})
    ydl.add_default_info_extractors()
    ie = Youtube

# Generated at 2022-06-18 13:24:45.882540
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import FakeYDL
    from ..compat import compat_urllib_request
    from .test_fragment import _test_frag_download

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'FakeInfoExtractor'
        _VALID_URL = r'https?://(?:www\.)?fake\.com/video/\d+'


# Generated at 2022-06-18 13:24:54.786414
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import sys
    import tempfile
    import unittest
    from .test_downloads import FakeYDL
    from .test_downloads import FakeHttpServer
    from .test_downloads import assertRegex
    from .test_downloads import assertNotRegex

    def _start_http_server(manifest, media_fragments, ad_fragments):
        httpd = FakeHttpServer()
        httpd.serve_content(manifest)
        for i, frag in enumerate(media_fragments):
            httpd.serve_content(frag, {'Content-Type': 'video/mp2t'}, '/media_%d.ts' % i)

# Generated at 2022-06-18 13:25:04.306738
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func

    ydl = gen_ydl()
    ydl.params.update({
        'match_filter': match_filter_func('hlsnative'),
        'test': True,
    })
    for ie in gen_extractors():
        if ie.suitable(ydl, 'https://example.com/'):
            ie.extract(ydl, 'https://example.com/')
            break
    else:
        assert False, 'No extractor found'

# Generated at 2022-06-18 13:25:13.484820
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    from .external import FFmpegFD
    from .fragment import FragmentFD
    from .dash import DashSegmentsFD
    from .hls import HlsFD
    from .http import HttpFD
    from .m3u8 import M3u8FD
    from .ism import IsmFD
    from .f4m import F4mFD
    from .rtmp import RtmpFD
    from .smoothstreams import SmoothstreamsFD
    from .srt import SrtFD
    from .subtitles import SubtitlesFD

# Generated at 2022-06-18 13:25:25.273134
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.utils
    import youtube_dl.downloader.external

    def _test_download(ydl, manifest, expected_output, expected_return_code, expected_warnings):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            f.write(manifest.encode('utf-8'))
            f.close()

# Generated at 2022-06-18 13:25:37.316113
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..downloader import YoutubeDL
    from ..postprocessor import FFmpegMergerPP
    from ..extractor import YoutubeIE
    from ..extractor import YoutubePlaylistIE
    from ..extractor import YoutubeSearchIE
    from ..extractor import YoutubeChannelIE
    from ..extractor import YoutubeShowIE
    from ..extractor import YoutubeFavouritesIE
    from ..extractor import YoutubeUserIE
    from ..extractor import YoutubeSubscriptionsIE
    from ..extractor import YoutubeRecommendedIE
    from ..extractor import YoutubeWatchLaterIE
    from ..extractor import YoutubeHistoryIE
    from ..extractor import YoutubeSearchDateIE
    from ..extractor import YoutubeSearchURLIE

# Generated at 2022-06-18 13:25:48.195342
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import unittest
    from .test_downloader import FakeYDL

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.ydl = FakeYDL()
            self.params = {
                'format': 'best',
                'outtmpl': os.path.join(tempfile.gettempdir(), '%(id)s.%(ext)s'),
                'test': True,
            }
            self.hlsfd = HlsFD(self.ydl, self.params)


# Generated at 2022-06-18 13:25:56.277331
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import common
    from ..utils import encode_data_uri
    from .common import FakeYDL

    ydl = FakeYDL()
    ydl.params['test'] = True
    ydl.params['noprogress'] = True
    ydl.params['quiet'] = True
    ydl.params['skip_download'] = True
    ydl.params['simulate'] = True
    ydl.params['outtmpl'] = '%(id)s'
    ydl.params['writedescription'] = True
    ydl.params['writeinfojson'] = True
    ydl.params['writesubtitles'] = True
    ydl.params['writeautomaticsub'] = True
    ydl.params['writeannotations'] = True

# Generated at 2022-06-18 13:26:04.607734
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import determine_ext

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'Fake'
        _VALID_URL = r'https?://.+'
        _TEST = {
            'url': 'http://fake.url',
            'info_dict': {
                'id': 'fake_id',
                'ext': 'mp4',
                'title': 'fake_title',
                'duration': 10,
                'is_live': False,
            },
        }

        def _real_extract(self, url):
            return self._TEST

    class FakeGenericIE(GenericIE):
        IE_NAME = 'FakeGeneric'

# Generated at 2022-06-18 13:26:13.505035
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..compat import compat_str
    from ..utils import ExtractorError
    from .common import FakeYDL

    class FakeIE(InfoExtractor):
        IE_NAME = 'fake'
        _VALID_URL = r'https?://.+'
        _TEST = {
            'url': 'http://fake.url/',
            'info_dict': {
                'id': 'fakeid',
                'ext': 'mp4',
                'title': 'faketitle',
                'is_live': False,
            },
        }


# Generated at 2022-06-18 13:27:43.694032
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..compat import compat_str

    # Test for non-encrypted stream
    manifest = '''
#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:10
#EXT-X-MEDIA-SEQUENCE:0
#EXTINF:10,
http://media.example.com/fileSequence0.ts
#EXTINF:10,
http://media.example.com/fileSequence1.ts
#EXTINF:10,
http://media.example.com/fileSequence2.ts
#EXTINF:10,
http://media.example.com/fileSequence3.ts
#EXT-X-ENDLIST
'''

# Generated at 2022-06-18 13:27:52.165441
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri

    class FakeYDL:
        def __init__(self):
            self.params = {
                'test': True,
                'skip_download': True,
                'quiet': True,
                'noprogress': True,
                'logger': InfoExtractor._create_logger(),
            }

        def urlopen(self, url):
            if url.startswith('data:'):
                return encode_data_uri(url)
            return url

    ydl = FakeYDL()
    fd = HlsFD(ydl, ydl.params)

# Generated at 2022-06-18 13:28:03.585057
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str

    ydl = gen_ydl()
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_use_mpegts'] = False
    ydl.params['hls_segment_skip'] = 'all'
    ydl.params['hls_skip_download'] = True
    ydl.params['hls_prefer_ffmpeg'] = False
    ydl.params['hls_prefer_native'] = True
    ydl.params['test'] = True

# Generated at 2022-06-18 13:28:15.902521
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str

    ydl = gen_ydl()
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_use_mpegts'] = True
    ydl.params['match_filter'] = match_filter_func('best')
    ydl.params['test'] = True
    ydl.params['noprogress'] = True
    ydl.params['quiet'] = True
    ydl.params['simulate'] = True
    ydl.params['skip_download'] = True
    ydl.params['writeinfojson'] = True
    ydl.params['writesubtitles'] = True
    y

# Generated at 2022-06-18 13:28:22.759056
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\nmedia-00001.ts\n#EXT-X-ENDLIST\n', {})
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\nmedia-00001.ts\n#EXT-X-ENDLIST\n', {'is_live': True})
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\nmedia-00001.ts\n#EXT-X-ENDLIST\n', {'is_live': False})
    assert not H

# Generated at 2022-06-18 13:28:35.425894
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..compat import compat_str
    from ..utils import encode_data_uri

    def _test_download(url, expected_frag_content):
        ydl = YoutubeDL({'quiet': True, 'skip_download': True})
        ie = YoutubeIE(ydl)
        info = ie.extract(url)
        fd = HlsFD(ydl, {'test': True})
        assert fd.real_download(None, info)
        assert fd._frag_content == expected_frag_content

    # Test unencrypted fragment

# Generated at 2022-06-18 13:28:46.021890
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .test_fragment import _test_frag_download
    from .test_external import _test_external_download
    from .test_http import _test_http_download
    from .test_rtmp import _test_rtmp_download

    def _test_hls_download(ie, manifest_url, expected_fragments, expected_info_dict, expected_filename, expected_params, expected_test_result, expected_warning_count=0):
        ie.params.update(expected_params)
        info_dict = {
            'url': manifest_url,
            'ie_key': ie.ie_key(),
        }
        info_dict.update(expected_info_dict)
        fd = Hls

# Generated at 2022-06-18 13:28:56.201479
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    from ..utils import ExtractorError
    from ..compat import compat_urllib_request
    from ..downloader.common import FileDownloader
    from ..downloader.external import ExternalFD
    from ..downloader.http import HttpFD
    from ..downloader.f4m import F4mFD
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.hls import HlsFD as HlsFD_old
    from ..downloader.fragment import FragmentFD
    from ..downloader.external import FFmpegFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.ism import IsmFD
    from ..downloader.hds import HdsFD

# Generated at 2022-06-18 13:29:06.305084
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str

    ydl = gen_ydl()
    ydl.params['noplaylist'] = True
    ydl.params['quiet'] = True
    ydl.params['format'] = 'bestvideo+bestaudio/best'
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ydl.params['writesubtitles'] = True
    ydl.params['allsubtitles'] = True
    ydl.params['writeautomaticsub'] = True
    ydl.params['subtitleslangs'] = ['en']

# Generated at 2022-06-18 13:29:15.969442
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.utils

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmp_file = tempfile.mkstemp(dir=tmp_dir)
    os.close(fd)

    # Create a youtube-dl object
    ydl_opts = {
        'outtmpl': tmp_file,
        'quiet': True,
        'no_warnings': True,
        'simulate': True,
        'skip_download': True,
        'hls_prefer_native': True,
        'test': True,
    }