

# Generated at 2022-06-18 13:20:10.841366
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import ExtractorError
    from ..compat import compat_urllib_request
    from .common import FakeYDL

    class FakeHlsFD(HlsFD):
        def __init__(self, ydl, params):
            super(FakeHlsFD, self).__init__(ydl, params)
            self.frag_content = None
            self.frag_url = None
            self.frag_info_dict = None
            self.frag_headers = None

        def _download_fragment(self, ctx, frag_url, info_dict, headers):
            self.frag_url = frag_url
            self.frag_info_dict = info_dict
            self.frag_headers = headers
            return True, self.frag_

# Generated at 2022-06-18 13:20:21.605766
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    ydl = gen_ydl(gen_extractors())
    ydl.params['hls_use_mpegts'] = True
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_prefer_ffmpeg'] = False
    ydl.params['hls_segment_skip_live_edge'] = False
    ydl.params['hls_live_edge'] = 0
    ydl.params['hls_live_restart'] = False
    ydl.params['hls_segment_attempts'] = 0
    ydl.params['hls_segment_threads'] = 1
    ydl.params['hls_segment_timeout'] = 10


# Generated at 2022-06-18 13:20:34.653635
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..utils import SearchInfoExtractor
    from ..compat import compat_urllib_request
    from ..downloader.common import FileDownloader
    from ..downloader.external import ExternalFD
    from ..downloader.f4m import F4mFD
    from ..downloader.hls import HlsFD
    from ..downloader.http import HttpFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.smoothstreams import SmoothstreamsFD
    from ..downloader.dash import DashFD
    from ..downloader.ism import IsmFD
    from ..downloader.m3u8 import M3u8FD
    from ..downloader.external import FFmpegFD
    from ..downloader.fragment import FragmentFD

# Generated at 2022-06-18 13:20:44.046538
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=836280,RESOLUTION=640x360,CODECS="avc1.4d401f, mp4a.40.2"\nhttps://priv.example.com/fileSequence52-A.ts\n#EXT-X-ENDLIST', {})

# Generated at 2022-06-18 13:20:53.947156
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str

    ydl = gen_ydl()
    for ie in gen_extractors():
        if ie.ie_key() == 'hlsnative':
            break
    else:
        raise Exception('HlsFD not found')

    def _test_download(url, expected_frag_count, expected_frag_index):
        ie.url = url
        info_dict = ie.extract(ydl.prepare_filename(ie.ie_key()))
        assert info_dict['_type'] == 'hls'
        assert info_dict['url'] == url
        assert info_dict['ext'] == 'mp4'
        assert info_

# Generated at 2022-06-18 13:21:05.480902
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str

    ydl = gen_ydl()
    ydl.params.update({
        'match_filter': match_filter_func(['hlsnative']),
        'hls_prefer_native': True,
        'hls_use_mpegts': True,
        'skip_download': True,
        'quiet': True,
    })
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(gen_extractors()[0])

# Generated at 2022-06-18 13:21:18.916550
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError
    from .m3u8 import M3u8IE
    from .fragment import FragmentFD
    from .external import FFmpegFD

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'quiet': True,
                'simulate': True,
                'skip_download': True,
            }
            self.cache = None
            self.extractor = InfoExtractor()
            self.extractor.add_info_extractor(M3u8IE.ie_key())

        def to_screen(self, msg):
            pass

        def to_stdout(self, msg):
            pass


# Generated at 2022-06-18 13:21:31.725673
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .utils import encode_data_uri

    # Test with a live stream
    ie = InfoExtractor(FileDownloader())
    ie.params = {'noplaylist': True}
    ie.add_default_info_extractors()
    ie.extract(
        'https://www.youtube.com/watch?v=JNwNXF9Y6kY',
        download=False,
    )

# Generated at 2022-06-18 13:21:40.882919
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    # Test data
    # https://github.com/ytdl-org/youtube-dl/issues/27660

# Generated at 2022-06-18 13:21:50.080709
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    import os

    ydl = YoutubeDL({'quiet': True, 'skip_download': True})
    ydl.add_default_info_extractors()
    ie = YoutubeIE(ydl)
    ie.extract('https://www.youtube.com/watch?v=J---aiyznGQ')
    info = ydl.extract_info(
        'https://www.youtube.com/watch?v=J---aiyznGQ',
        download=False,
        process=False)
    assert HlsFD.can_download(info['formats'][0]['manifest_url'], info['formats'][0])

    # Test with a non-encrypted stream
    ydl

# Generated at 2022-06-18 13:22:23.323176
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str

    ydl = gen_ydl()
    ydl.params['hls_use_mpegts'] = True
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_prefer_ffmpeg'] = False
    ydl.params['hls_segment_skip'] = 0
    ydl.params['hls_segment_preference'] = 'lowest'
    ydl.params['hls_segment_attempts'] = 10
    ydl.params['hls_segment_threads'] = 1
    ydl.params['hls_segment_timeout'] = 10
   

# Generated at 2022-06-18 13:22:34.436702
# Unit test for constructor of class HlsFD

# Generated at 2022-06-18 13:22:46.303407
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeDL
    from ..utils import encode_data_uri
    from .common import FakeYDL
    from .test_fragment import _test_frag_download

    def _test_real_download(ydl, manifest, info_dict, expected_frag_content):
        ydl.params['test'] = True
        ydl.params['outtmpl'] = '%(id)s.mp4'
        ydl.params['skip_download'] = True
        ydl.params['quiet'] = True
        ydl.params['simulate'] = True
        ydl.params['nooverwrites'] = True
        ydl.params['writedescription'] = False
        ydl.params['writeinfojson'] = False
        ydl.params['writeannotations'] = False

# Generated at 2022-06-18 13:22:58.251913
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.utils
    import youtube_dl.downloader.fragment
    import youtube_dl.downloader.hls
    import youtube_dl.downloader.http
    import youtube_dl.downloader.external
    import youtube_dl.extractor.youtube
    import youtube_dl.extractor.generic

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a youtube-dl object

# Generated at 2022-06-18 13:23:03.732500
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import common
    from ..downloader import HttpFD
    from ..utils import encode_data_uri

    class FakeYDL:
        def __init__(self):
            self.params = {
                'test': True,
                'noprogress': True,
                'quiet': True,
                'skip_download': True,
                'simulate': True,
                'outtmpl': '%(id)s.%(ext)s',
            }
            self.cache = {}

        def to_screen(self, msg):
            pass

        def trouble(self, msg, tb=None):
            pass

        def report_error(self, msg, tb=None):
            pass

        def urlopen(self, url):
            return HttpFD(self, {'url': url}).download

# Generated at 2022-06-18 13:23:14.559622
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import prepend_extension

    ydl = gen_ydl()
    ydl.add_default_info_extractors()
    for ie in gen_extractors():
        ydl.add_info_extractor(ie)

    # Test HlsFD with a non-encrypted stream
    # https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8
    hls_fd = HlsFD(ydl, {'hls_prefer_native': True})

# Generated at 2022-06-18 13:23:26.353367
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import get_testdata_file
    from .external import FFmpegFD
    from .fragment import FragmentFD
    from .http import HttpFD
    from .dash import DashFD

    def _test_real_download(url, expected_frag_content, expected_frag_index, expected_frag_count,
                            expected_ad_frag_count, expected_delegated_to_ffmpeg,
                            expected_delegated_to_dash, expected_delegated_to_http,
                            expected_delegated_to_fragment):
        ydl = YoutubeIE()
        fd = HlsFD(ydl, {})
        fd.add_progress_hook(lambda *args: None)

# Generated at 2022-06-18 13:23:34.384834
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..compat import compat_urllib_request

    class FakeYdl(object):
        def __init__(self, params):
            self.params = params

        def urlopen(self, url):
            return compat_urllib_request.urlopen(url)

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ydl):
            self.ydl = ydl

    class FakeFileDownloader(FileDownloader):
        def __init__(self, ydl):
            super(FakeFileDownloader, self).__init__(ydl)
            self.ie = FakeInfoExtractor(ydl)

    ydl = FakeYdl({})

# Generated at 2022-06-18 13:23:46.900112
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testdata_file
    from ..utils import encode_data_uri
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..compat import compat_str
    from .external import FFmpegFD
    import os
    import tempfile
    import shutil
    import subprocess

    def _test_HlsFD_real_download(manifest_url, expected_fragment_data, expected_fragment_index, expected_fragment_retries):
        ydl = YoutubeDL({'hls_use_mpegts': True})
        ydl.add_default_info_extractors()
        ie = YoutubeIE(ydl)
        info_dict = ie.extract(manifest_url)
        assert info_dict['_type'] == 'url'

# Generated at 2022-06-18 13:23:55.734061
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import youtube_dl.extractor.common as common
    import youtube_dl.extractor.youtube as youtube
    import youtube_dl.downloader.external as external
    import youtube_dl.downloader.hls as hls

    def _get_test_cases(test_data_dir):
        test_cases = []
        for test_case_file in os.listdir(test_data_dir):
            if not test_case_file.endswith('.json'):
                continue
            test_case_path = os.path.join(test_data_dir, test_case_file)
            with open(test_case_path, 'r') as f:
                test_case = json.load(f)
            test_

# Generated at 2022-06-18 13:24:27.930237
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func

    ydl = gen_ydl()
    ydl.params.update({
        'hls_prefer_native': True,
        'hls_use_mpegts': True,
        'match_filter': match_filter_func('hlsnative'),
    })
    for ie in gen_extractors():
        if ie.IE_NAME == 'generic':
            continue
        ydl.add_info_extractor(ie)
    ydl.download(['https://www.youtube.com/watch?v=H7jtC8vjXw8'])

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-18 13:24:39.398508
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    from .common import FakeYDL

    class FakeIE(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeIE, self).__init__(*args, **kwargs)
            self.num_downloads = 0

        def _real_initialize(self):
            pass

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'formats': [],
            }


# Generated at 2022-06-18 13:24:50.990132
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.utils
    import youtube_dl.downloader.hls
    import youtube_dl.downloader.fragment

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a YoutubeDL object

# Generated at 2022-06-18 13:25:03.705516
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-VERSION:3\n'
        '#EXT-X-TARGETDURATION:10\n'
        '#EXT-X-MEDIA-SEQUENCE:0\n'
        '#EXTINF:10.0,\n'
        'http://example.com/0\n'
        '#EXTINF:10.0,\n'
        'http://example.com/1\n'
        '#EXTINF:10.0,\n'
        'http://example.com/2\n'
        '#EXT-X-ENDLIST\n',
        {'is_live': False}
    )

# Generated at 2022-06-18 13:25:13.172613
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    from .external import FFmpegFD
    import os
    import tempfile

    def _test_HlsFD_real_download(ie, video_id, expected_fragments, expected_fragment_content):
        ydl = YoutubeDL({
            'outtmpl': os.path.join(tempfile.gettempdir(), '%(id)s.%(ext)s'),
            'quiet': True,
            'skip_download': True,
            'simulate': True,
            'test': True,
        })
        info_dict = ydl.extract_info(ie.ie_key, video_id)
        assert info_dict['id'] == video_id

# Generated at 2022-06-18 13:25:24.730126
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import unittest

    from .downloader import YoutubeDL
    from .extractor import get_info_extractor

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.ydl = YoutubeDL({
                'outtmpl': os.path.join(self.tmp_dir, '%(id)s.%(ext)s'),
                'quiet': True,
                'skip_download': True,
                'simulate': True,
                'test': True,
            })

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)


# Generated at 2022-06-18 13:25:36.878304
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    ydl = YoutubeDL({'skip_download': True})
    ie = YoutubeIE(ydl)
    info_dict = ie.extract('https://www.youtube.com/watch?v=BaW_jenozKc')
    assert HlsFD.can_download(info_dict['url'], info_dict)
    assert HlsFD(ydl, {}).real_download(None, info_dict)
    assert not HlsFD.can_download(info_dict['url'], {'is_live': True})
    assert not HlsFD.can_download(info_dict['url'], {'extra_param_to_segment_url': 'foo=bar'})

# Generated at 2022-06-18 13:25:47.780027
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import SearchInfoExtractor
    from ..compat import compat_urllib_request
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD
    from ..downloader.external import ExternalFD
    from ..downloader.f4m import F4mFD
    from ..downloader.hls import HlsFD as HlsFD_old
    from ..downloader.dash import DashFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.ism import IsmFD
    from ..downloader.fragment import FragmentFD
    from ..downloader.external import FFmpegFD
    from ..downloader.http import HttpFD
    from ..downloader.http import HttpFD

# Generated at 2022-06-18 13:25:55.997442
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import unittest
    from .test_downloader import MockYDL
    from .test_downloader import MockInfoDict
    from .test_downloader import MockFD
    from .test_downloader import MockFD_download
    from .test_downloader import MockFD_add_progress_hook
    from .test_downloader import MockFD_report_error
    from .test_downloader import MockFD_report_warning
    from .test_downloader import MockFD_report_retry_fragment
    from .test_downloader import MockFD_report_skip_fragment
    from .test_downloader import MockFD_prepare_url
    from .test_downloader import MockFD_urlopen
    from .test_downloader import MockFD_read
   

# Generated at 2022-06-18 13:26:04.421048
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError
    from .common import FakeYDL
    from .test_fragment import _test_download_fragment

    class FakeIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'fake',
                'url': url,
                'title': 'fake',
                'ext': 'mp4',
                'is_live': False,
            }

    ydl = FakeYDL()
    ydl.add_info_extractor(FakeIE)
    ydl.params['hls_use_mpegts'] = True
    fd = HlsFD(ydl, {})


# Generated at 2022-06-18 13:26:57.837161
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    def _test_HlsFD_real_download(url, expected_frag_content):
        ydl = YoutubeDL({'hls_prefer_native': True})
        ie = YoutubeIE(ydl)
        info_dict = ie.extract(url)
        assert info_dict['extractor'] == 'youtube'
        assert info_dict['protocol'] == 'm3u8'
        assert info_dict['url'] == url
        assert info_dict['ext'] == 'mp4'
        assert info_dict['format_id'] == '22'
        assert info_dict['format'] == '720p'
        assert info_dict['height'] == 720

# Generated at 2022-06-18 13:27:04.209688
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_info_extractor(YoutubeIE())

# Generated at 2022-06-18 13:27:12.098283
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..utils import SearchInfoExtractor

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'fakeid',
                'url': url,
                'title': 'faketitle',
                'ext': 'mp4',
                'is_live': False,
            }

    class FakeSearchInfoExtractor(SearchInfoExtractor):
        def _real_extract(self, query):
            return {
                'id': 'fakeid',
                'url': 'fakeurl',
                'title': 'faketitle',
                'ext': 'mp4',
                'is_live': False,
            }

    ie = FakeInfoExtractor()
    sie = FakeSearchInfoExtractor()

# Generated at 2022-06-18 13:27:22.453314
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=836280,RESOLUTION=848x360,CODECS="avc1.4d401f,mp4a.40.2"\nindex.m3u8?null=0\n', {'url': 'http://example.com/index.m3u8?null=0'})

# Generated at 2022-06-18 13:27:32.597770
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    from .test import get_test_data
    from .external import FFmpegFD
    from .utils import (
        encodeFilename,
        sanitize_open,
    )
    from ..compat import (
        compat_urllib_request,
        compat_urllib_error,
    )
    from ..utils import (
        clean_html,
        ExtractorError,
    )
    from ..extractor import (
        get_info_extractor,
    )

    def _test_download(ie, video_id, expected_filename, expected_status, expected_content, expected_warnings=None):
        expected_warnings = expected_warnings or []
        info = ie.extract(video_id)
        assert info['id'] == video_id

# Generated at 2022-06-18 13:27:40.673379
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import determine_ext
    from ..downloader.http import HttpFD
    from ..downloader.http.http_req_download import HttpRequest
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urlparse
    from ..compat import compat_struct_pack
    from ..utils import parse_m3u8_attributes
    from ..utils import update_url_query
    from ..utils import url_basename
    from ..utils import urljoin
    from ..utils import url_basename
    from ..utils import url_or_none
    from ..utils import url_basename
    from ..utils import url_basename
    from ..utils import url_basename

# Generated at 2022-06-18 13:27:48.459152
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .mock import MockYDL
    from .test_fragment import _test_frag_download

    def _test_HlsFD_real_download(ydl, info_dict, expected_fragments):
        info_dict['url'] = encode_data_uri(info_dict['url'], info_dict['manifest_type'])
        info_dict['test'] = True
        ie = InfoExtractor(ydl, {})
        ie.add_info_extractor(HlsFD)
        ie.extract(info_dict['url'])
        _test_frag_download(ydl, expected_fragments)

    # Test AES-128 encrypted stream
    _test_HlsFD_real_

# Generated at 2022-06-18 13:27:56.142840
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_info_extractor(HlsFD)

    # Test with a non-encrypted stream

# Generated at 2022-06-18 13:28:08.873760
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urlparse
    from ..compat import compat_struct_pack
    from ..compat import compat_struct_unpack
    from ..compat import compat_str
    from ..compat import compat_chr
    from ..compat import compat_ord
    from ..compat import compat_urllib_parse_unquote
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib_parse_urlunparse
    from ..compat import compat_urllib_parse

# Generated at 2022-06-18 13:28:13.016014
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..downloader import YoutubeDL
    import os
    import tempfile

    # Create a temporary file
    fd, temp_file_path = tempfile.mkstemp()
    os.close(fd)

    # Create a YoutubeDL object
    ydl = YoutubeDL({
        'noplaylist': True,
        'outtmpl': temp_file_path,
        'quiet': True,
        'simulate': True,
        'skip_download': True,
    })

    # Create a YoutubeIE object
    ie = YoutubeIE(ydl)

    # Test the constructor of class HlsFD

# Generated at 2022-06-18 13:29:23.105651
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import tempfile
    import unittest

    from ..utils import encode_data_uri

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.hlsfd = HlsFD(None, {})
            self.manifest_dir = tempfile.mkdtemp()

        def tearDown(self):
            os.rmdir(self.manifest_dir)

        def test_can_download(self):
            manifest_path = os.path.join(self.manifest_dir, 'manifest.m3u8')
            manifest_url = encode_data_uri(manifest_path, b'#EXTM3U')

# Generated at 2022-06-18 13:29:31.027255
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import unittest
    from .test_downloader import FakeYDL
    from .test_downloader import FakeHttpServer
    from .test_downloader import FakeInfoExtractor
    from .test_downloader import FakeFileDownloader

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.server = FakeHttpServer()
            self.server.start()
            self.server.handler.protocols = {
                'http': FakeHttpServer.TestHTTPHandler,
                'https': FakeHttpServer.TestHTTPHandler,
            }