

# Generated at 2022-06-18 13:20:08.179901
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    def _run_test(url, expected_fragment_data):
        ydl = YoutubeDL({'quiet': True, 'skip_download': True})
        ie = YoutubeIE(ydl)
        info = ie.extract(url)
        assert info['_type'] == 'hls'
        fd = HlsFD(ydl, {'test': True})
        assert fd.real_download(None, info)
        assert fd.fragment_data == expected_fragment_data

    # Test a simple HLS stream

# Generated at 2022-06-18 13:20:13.314494
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    from .test import get_testdata_files_dir
    from .test import get_testdata_dir
    from .test import get_testdata_file
    from .test import get_testdata_video_url
    from .test import get_testdata_video_url_with_query
    from .test import get_testdata_video_url_with_query_and_fragment
    from .test import get_testdata_video_url_with_fragment
    from .test import get_testdata_video_url_with_query_and_fragment_and_key
    from .test import get_testdata_video_url_with_query_and_fragment_and_key_and_iv
    from .test import get_testdata_video

# Generated at 2022-06-18 13:20:22.846910
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import unittest
    from .test_downloader import FakeYDL
    from .test_downloader import MockHttpServer
    from .test_downloader import MockServerHandler

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.server = MockHttpServer()
            self.server.start()
            self.server.handler.protocol_version = 'HTTP/1.1'
            self.server.handler.add_handler('/index.m3u8', MockServerHandler.m3u8_handler)
            self.server.handler.add_handler('/fragment.ts', MockServerHandler.fragment_handler)

# Generated at 2022-06-18 13:20:36.108603
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_str

    # Test with a live stream
    info_dict = {
        'url': 'https://www.youtube.com/watch?v=T_qz_8q3q-Q',
        'is_live': True,
    }
    for ie in gen_extractors():
        if match_filter_func(ie.IE_NAME)(info_dict):
            break
    assert ie.IE_NAME == 'youtube'
    manifest = ie._download_webpage(info_dict['url'], info_dict['url'], 'Downloading webpage')
    assert not HlsFD.can_download(manifest, info_dict)

    # Test with a non-live stream

# Generated at 2022-06-18 13:20:44.857742
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.downloader.http
    import youtube_dl.downloader.http.hls
    import youtube_dl.downloader.http.hls_native

    class DummyYDL(youtube_dl.YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(DummyYDL, self).__init__(*args, **kwargs)
            self.params['test'] = True

        def to_screen(self, *args, **kwargs):
            pass

        def report_warning(self, *args, **kwargs):
            pass

        def report_error(self, *args, **kwargs):
            pass


# Generated at 2022-06-18 13:20:53.390199
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    ydl = gen_ydl(gen_extractors(), {'hls_prefer_native': True})
    ydl.add_default_info_extractors()
    ydl.params['noprogress'] = True
    ydl.params['quiet'] = True
    ydl.params['logger'] = None
    ydl.params['nooverwrites'] = True
    ydl.params['test'] = True
    ydl.params['format'] = 'bestvideo+bestaudio'
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ydl.params['writedescription'] = False
    ydl.params['writeinfojson'] = False
    y

# Generated at 2022-06-18 13:21:04.832606
# Unit test for constructor of class HlsFD

# Generated at 2022-06-18 13:21:18.260789
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import gen_extractors
    from ..utils import get_testdata_file
    from ..compat import compat_urllib_request

    def _test_HlsFD_real_download(extractor_name, manifest_url, expected_filename, expected_data):
        extractor = gen_extractors()[extractor_name]()
        extractor.params = {
            'test': True,
            'fragment_retries': 0,
            'skip_unavailable_fragments': False,
        }
        info_dict = extractor.extract(manifest_url)
        assert info_dict['_type'] == 'hls'
        assert info_dict['url'] == manifest_url
        assert info_dict['ext'] == 'mp4'

# Generated at 2022-06-18 13:21:31.109402
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import random
    import string
    import hashlib
    import base64
    from .utils import (
        encode_data_uri,
        encode_base_n,
        encode_filename,
        sanitize_open,
        sanitized_Request,
    )
    from .external import (
        FFmpegFD,
    )
    from .fragment import (
        FragmentFD,
    )
    from .dash import (
        DASHFD,
    )
    from ..extractor import (
        get_info_extractor,
    )
    from ..downloader import (
        YoutubeDL,
    )

# Generated at 2022-06-18 13:21:40.474068
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from .external import FFmpegFD
    from .fragment import FragmentFD
    from .dash import DASHFD
    from .hls import HlsFD
    from .http import HttpFD
    from .m3u8 import M3U8FD
    from .ism import IsmFD
    from .smoothstreams import SmoothstreamsFD
    from .rtmp import RtmpFD
    from .rtmpe import RtmpeFD
    from .rtmps import RtmpsFD
    from .rtmpt import RtmptFD
    from .rtmpte import RtmpteFD
    from .rtmpts import RtmptsFD
    from .rtp import RtpFD
    from .rtsp import RtspFD
   

# Generated at 2022-06-18 13:22:09.907961
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..utils import ExtractorError
    from .common import FakeYDL

    ydl = FakeYDL()
    ie = YoutubeIE(ydl)
    info = {
        'id': 'test',
        'url': 'http://test.com/test.m3u8',
        'ext': 'mp4',
        'title': 'test',
        'thumbnail': 'http://test.com/test.jpg',
        'http_headers': {'User-Agent': 'test'},
        '_type': 'hls',
        '_decryption_key_url': 'http://test.com/test.key',
        '_decryption_key': '1234567890abcdef1234567890abcdef',
        'is_live': False,
    }
    # Test

# Generated at 2022-06-18 13:22:23.098381
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import shutil
    import tempfile
    import unittest
    from .test_downloader import MockYDL
    from .test_downloader import MockInfoDict
    from .test_downloader import MockFileDownloader

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.ydl = MockYDL()
            self.ydl.params['noprogress'] = True
            self.ydl.params['quiet'] = True
            self.ydl.params['outtmpl'] = os.path.join(self.tmp_dir, '%(id)s.%(ext)s')
            self.ydl.params['test'] = True
            self.ydl.add_info_ext

# Generated at 2022-06-18 13:22:34.252730
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_use_mpegts'] = False
    ydl.params['hls_segment_format'] = 'mp4'
    ydl.params['hls_segment_filename'] = '%(playlist_index)s-%(fragment_index)s.%(format)s'
    ydl.params['hls_segment_size'] = 1048576
    ydl.params['hls_segment_wrap'] = 0
    ydl.params['hls_fragment_retries'] = 10
    ydl.params['hls_skip_unavailable_fragments'] = True

# Generated at 2022-06-18 13:22:46.079584
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request

    class TestIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'ext': 'mp4',
                'title': 'test',
                'http_headers': {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:56.0) Gecko/20100101 Firefox/56.0',
                },
            }

    ie = TestIE()
    ie.add_info_extractor(HlsFD)

    # Test AES-128 encryption

# Generated at 2022-06-18 13:22:58.038071
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import YoutubeDL
    from ..extractor import YoutubeIE
    from ..utils import encode_data_uri
    from .external import FFmpegFD

    def _test_HlsFD_real_download(url, expected_frag_content):
        ydl = YoutubeDL({'quiet': True, 'skip_download': True})
        ydl.add_default_info_extractors()
        ie = YoutubeIE(ydl)
        info = ie.extract(url)
        assert info['_type'] == 'url'
        assert info['url'] == url
        assert info['ie_key'] == 'Youtube'
        assert info['ext'] == 'mp4'
        assert info['format_id'] == '137+140'
        assert info['protocol'] == 'm3u8_native'
        assert info

# Generated at 2022-06-18 13:23:07.680398
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    from .common import FakeYDL
    from .test_fragment import _test_frag_download

    def _test_download(ydl, ie, video_id, expected_fragments, expected_warnings=None, expected_errors=None,
                       expected_fragment_retries=None, expected_skip_fragments=None, expected_fragment_urls=None):
        expected_warnings = expected_warnings or []
        expected_errors = expected_errors or []
        expected_fragment_retries = expected_fragment_retries or {}
        expected_skip_fragments = expected_skip_fragments or []

# Generated at 2022-06-18 13:23:20.500968
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import ExtractorError
    from ..compat import compat_urllib_request
    from .common import FakeYDL

    class FakeIE(InfoExtractor):
        IE_NAME = 'fake'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'fake_id',
                'url': url,
                'title': 'fake_title',
                'is_live': False,
            }

    class FakeLiveIE(InfoExtractor):
        IE_NAME = 'fake_live'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return

# Generated at 2022-06-18 13:23:30.760380
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    ydl = YoutubeIE()
    ydl.params['noplaylist'] = True
    ydl.params['nocheckcertificate'] = True
    ydl.params['test'] = True
    ydl.params['quiet'] = True
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ydl.params['format'] = 'bestvideo+bestaudio'
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_use_mpegts'] = False
    ydl.params['hls_segment_skip_silence'] = False
    ydl.params['hls_segment_type'] = 'mp4'

# Generated at 2022-06-18 13:23:35.850383
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    ydl = gen_ydl()
    extractors = gen_extractors(ydl)
    for ie in extractors:
        if ie.IE_NAME == 'hlsnative':
            break
    ie.suitable(ydl, {'url': 'https://example.com/test.m3u8'})
    ie.download_playlist(ydl, {'url': 'https://example.com/test.m3u8'}, [])
    ie.download(ydl, {'url': 'https://example.com/test.m3u8'})

# Generated at 2022-06-18 13:23:47.537650
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'quiet': True, 'skip_download': True})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE.ie_key())

    # Test for https://github.com/ytdl-org/youtube-dl/issues/27660
    info = ydl.extract_info(
        'https://www.youtube.com/watch?v=jNQXAC9IVRw',
        download=False,
        process=False)
    assert info['formats'][0]['protocol'] == 'm3u8_native'

# Generated at 2022-06-18 13:24:32.260342
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\nhttp://example.com/1\n#EXTINF:10,\nhttp://example.com/2\n#EXTINF:10,\nhttp://example.com/3\n#EXT-X-ENDLIST\n', {})

# Generated at 2022-06-18 13:24:44.179947
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import determine_ext
    from ..compat import compat_urlparse
    from ..extractor.youtube import YoutubeIE
    from ..extractor.youtube import YoutubePlaylistIE
    from ..extractor.youtube import YoutubeChannelIE
    from ..extractor.youtube import YoutubeSearchIE
    from ..extractor.youtube import YoutubeShowIE
    from ..extractor.youtube import YoutubeFavouritesIE
    from ..extractor.youtube import YoutubeHistoryIE
    from ..extractor.youtube import YoutubeRecommendedIE
    from ..extractor.youtube import YoutubeSubscriptionsIE
    from ..extractor.youtube import YoutubeWatchLaterIE
    from ..extractor.youtube import YoutubeTruncatedURLIE
    from ..extractor.youtube import YoutubeIE

# Generated at 2022-06-18 13:24:48.757973
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    from .external import FFmpegFD
    import os
    import tempfile

    # Test that HlsFD can download a fragment
    def test_HlsFD_real_download_fragment(url, expected_fragment_content):
        ydl = YoutubeDL(params={'noplaylist': True})
        info_dict = ydl.extract_info(url, download=False)
        fd = HlsFD(ydl, params={'test': True})
        with tempfile.NamedTemporaryFile(delete=False) as f:
            filename = f.name

# Generated at 2022-06-18 13:24:59.458716
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..compat import compat_urlparse
    from ..utils import parse_m3u8_attributes

    def _test_can_download(url, expected_result):
        ydl = gen_ydl()
        info_dict = {'url': url}
        for ie in gen_extractors():
            if ie.suitable(url) and ie.IE_NAME.lower() == 'hls':
                ie.extract(ydl, url)
                info_dict = ydl.extract_info(url, download=False)
                break
        manifest_url = info_dict['url']
        manifest_urlh = ydl.urlopen(manifest_url)
        manifest_url = manifest_urlh.geturl

# Generated at 2022-06-18 13:25:10.569029
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import fake_http_to_https_headers

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'Fake'
        _VALID_URL = r'https?://(?:www\.)?fake\.com/video/(?P<id>\d+)'

# Generated at 2022-06-18 13:25:18.545994
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.utils
    import youtube_dl.extractor.common

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a fake youtube-dl object
    ydl_obj = youtube_dl.YoutubeDL({'outtmpl': os.path.join(tmp_dir, '%(id)s-%(format_id)s-%(resolution)s.%(ext)s')})

    # Create a fake info dict

# Generated at 2022-06-18 13:25:26.719618
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE

    ie = InfoExtractor(YoutubeIE.ie_key())
    ie.params = {'noplaylist': True}
    ie.add_info_extractor(YoutubeIE())
    info = ie.extract('https://www.youtube.com/watch?v=BaW_jenozKc')
    assert HlsFD.can_download(info['url'], info)

# Generated at 2022-06-18 13:25:38.356331
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str

    ydl = gen_ydl()
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_use_mpegts'] = True
    ydl.params['match_filter'] = match_filter_func('best')
    ydl.params['test'] = True
    ydl.params['noprogress'] = True
    ydl.params['quiet'] = True
    ydl.params['logger'] = None
    ydl.params['verbose'] = False
    ydl.params['dump_intermediate_pages'] = False
    ydl.params['writeinfojson'] = False
    y

# Generated at 2022-06-18 13:25:49.168139
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE.ie_key())

    # Test with a single fragment

# Generated at 2022-06-18 13:25:56.876595
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
            self.extractors = gen_extractors()
            self.filter_func = match_filter_func(params)

        def urlopen(self, url):
            return compat_urllib_request.urlopen(url)

    ydl = FakeYDL({})
    fd = HlsFD(ydl, {'format': 'best'})

# Generated at 2022-06-18 13:27:22.144437
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    from .external import ExternalFD
    from .utils import sanitize_open
    from ..utils import (
        encodeFilename,
        prepend_extension,
    )

    def _test_HlsFD_real_download(url, expected_filename, expected_content, expected_content_type):
        temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:27:32.296931
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-VERSION:3\n'
        '#EXT-X-TARGETDURATION:10\n'
        '#EXT-X-MEDIA-SEQUENCE:0\n'
        '#EXTINF:10,\n'
        'http://example.com/0.ts\n'
        '#EXTINF:10,\n'
        'http://example.com/1.ts\n'
        '#EXTINF:10,\n'
        'http://example.com/2.ts\n'
        '#EXT-X-ENDLIST\n',
        {'is_live': False}
    )

# Generated at 2022-06-18 13:27:38.139765
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    from .utils import (
        FakeYDL,
        FakeHttpServer,
        parse_m3u8_attributes,
        update_url_query,
    )
    from .external import FFmpegFD
    from .fragment import FragmentFD
    from .dash import DashSegmentsFD
    from .http import HttpFD
    from .hls import HlsFD
    from .ism import IsmFD
    from .m3u8 import M3U8FD
    from .rtmp import RtmpFD
    from .smoothstreams import SmoothStreamsFD
    from .utils import (
        compat_urllib_error,
        compat_urlparse,
        compat_struct_pack,
    )

# Generated at 2022-06-18 13:27:45.297068
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    import os

    # Test with a live stream
    ydl = YoutubeDL(YoutubeIE.ie_key_map())
    ydl.params['hls_use_mpegts'] = True
    ydl.params['skip_download'] = True
    ydl.params['quiet'] = True
    ydl.params['test'] = True
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ydl.params['format'] = 'bestvideo+bestaudio/best'
    ydl.params['noplaylist'] = True
    ydl.params['nocheckcertificate'] = True
    ydl.params['ignoreerrors'] = True
    ydl

# Generated at 2022-06-18 13:27:54.037551
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..utils import encode_data_uri
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..compat import compat_urlparse


# Generated at 2022-06-18 13:27:59.043574
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import encode_data_uri
    from ..compat import compat_str

    def _test_HlsFD_real_download(ydl, manifest_url, expected_fragment_content):
        info_dict = {
            'url': manifest_url,
            'http_headers': {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36',
            },
        }
        fd = HlsFD(ydl, {'test': True})
        success = fd.real_download('test.mp4', info_dict)

# Generated at 2022-06-18 13:28:12.020081
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    from .external import FFmpegFD
    from .fragment import FragmentFD

    # Test that HlsFD is a subclass of FragmentFD
    assert issubclass(HlsFD, FragmentFD)

    # Test that HlsFD is not a subclass of FFmpegFD
    assert not issubclass(HlsFD, FFmpegFD)

    # Test that HlsFD is not a subclass of YoutubeDL
    assert not issubclass(HlsFD, YoutubeDL)

    # Test that HlsFD is not a subclass of YoutubeIE
    assert not issubclass(HlsFD, YoutubeIE)

    # Test that HlsFD is not a subclass of object
    assert not issubclass(HlsFD, object)



# Generated at 2022-06-18 13:28:17.299387
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import sys
    import tempfile
    import unittest

    from .test_downloader import FakeYDL
    from .test_downloader import get_testdata_dir

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.testdata_dir = get_testdata_dir()
            self.temp_dir = tempfile.mkdtemp()
            self.ydl = FakeYDL()
            self.ydl.params['hls_prefer_native'] = True
            self.ydl.params['hls_use_mpegts'] = False
            self.ydl.params['test'] = True
            self.ydl.params['verbose'] = True
            self.ydl.params['quiet'] = False

# Generated at 2022-06-18 13:28:26.123480
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .common import FakeYDL

    class FakeIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'fake',
                'url': url,
                'title': 'fake',
                'is_live': False,
                'formats': [],
            }

    ie = FakeIE(FakeYDL())
    ie.add_info_extractor(HlsFD)

    # Test with an empty manifest
    manifest = encode_data_uri(b'#EXTM3U\n')
    info_dict = ie.extract(manifest)
    assert info_dict['formats'][0]['format_id'] == 'hlsnative'

    # Test with a

# Generated at 2022-06-18 13:28:39.000057
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str

    ydl = gen_ydl()
    ydl.params['noplaylist'] = True
    ydl.params['nocheckcertificate'] = True
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_use_mpegts'] = False
    ydl.params['hls_segment_format'] = 'mp4'
    ydl.params['hls_segment_size'] = 10485760
    ydl.params['hls_segment_skip_unavailable'] = True
    ydl.params['hls_segment_ignore_names'] = False
    ydl