

# Generated at 2022-06-18 13:20:19.053548
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_urlparse
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    from ..extractor.generic import GenericIE
    from ..extractor.youtube import YoutubePlaylistIE
    from ..extractor.youtube import YoutubeChannelIE
    from ..extractor.youtube import YoutubeSearchIE
    from ..extractor.youtube import YoutubeFavouritesIE
    from ..extractor.youtube import YoutubeHistoryIE
    from ..extractor.youtube import YoutubeRecommendedIE
    from ..extractor.youtube import YoutubeSubscriptionsIE
    from ..extractor.youtube import YoutubeShowIE
    from ..extractor.youtube import YoutubeIE

# Generated at 2022-06-18 13:20:31.316578
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str

    def _test_HlsFD(ydl, info_dict):
        fd = HlsFD(ydl, ydl.params)
        fd.real_download(compat_str(info_dict['id']), info_dict)

    ydl = gen_ydl()
    ydl.params.update({
        'match_filter': match_filter_func('is_hls'),
        'test': True,
        'skip_download': True,
    })
    for ie in gen_extractors():
        if ie.IE_NAME == 'generic':
            continue
        ydl.add_info_extractor(ie)


# Generated at 2022-06-18 13:20:42.113983
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urlparse
    from .utils import sanitize_open

    # Test with a non-encrypted stream
    ie = InfoExtractor(FileDownloader())
    ie.params = {'noplaylist': True}
    ie.add_info_extractor(HlsFD())
    ie.add_info_extractor(FFmpegFD())
    ie.extract('http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8')

# Generated at 2022-06-18 13:20:52.620229
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import sys
    import tempfile
    import unittest
    from .test_downloader import MockYDL
    from .test_downloader import MockInfoDict
    from .test_downloader import MockFD
    from .test_downloader import MockHook
    from .test_downloader import MockUrlOpen

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.ydl = MockYDL()
            self.ydl.params = {
                'noprogress': True,
                'quiet': True,
                'skip_download': True,
                'test': True,
            }

# Generated at 2022-06-18 13:21:03.844955
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import unittest
    from .test_downloader import MockYDL
    from .test_downloader import MockInfoDict
    from .test_downloader import MockFD

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.ydl = MockYDL()
            self.ydl.params['noprogress'] = True
            self.ydl.params['quiet'] = True
            self.ydl.params['test'] = True
            self.ydl.params['outtmpl'] = os.path.join(self.temp_dir, '%(id)s.%(ext)s')
            self.ydl.add_info_extractor(MockFD())


# Generated at 2022-06-18 13:21:17.348796
# Unit test for constructor of class HlsFD

# Generated at 2022-06-18 13:21:29.988792
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..utils import encode_data_uri

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'ext': 'mp4',
                'title': 'test',
                'http_headers': {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0',
                },
            }

    class FakeFileDownloader(FileDownloader):
        def __init__(self, params):
            FileDownloader.__init__(self, params)

# Generated at 2022-06-18 13:21:39.730050
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Test for encrypted streams
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=SAMPLE-AES', {})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=SAMPLE-AES-CTR', {})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=SAMPLE-AES-CENC', {})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=SAMPLE-AES-CBC', {})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=SAMPLE-AES-CTR', {})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=SAMPLE-AES-CTR', {})
    assert not H

# Generated at 2022-06-18 13:21:49.197124
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import _get_troublesome_youtube_ie
    from ..downloader import Downloader
    from ..postprocessor import FFmpegMergerPP

    # Test with a live stream
    ie = YoutubeIE(Downloader())
    info_dict = ie.extract('https://www.youtube.com/watch?v=JxWfvtnHtS0')
    assert not HlsFD.can_download(info_dict['url'], info_dict)

    # Test with a live stream
    ie = YoutubeIE(Downloader())
    info_dict = ie.extract('https://www.youtube.com/watch?v=JxWfvtnHtS0')
    assert not HlsFD.can_download(info_dict['url'], info_dict)

    #

# Generated at 2022-06-18 13:21:57.737297
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..compat import compat_urllib_request
    from ..utils import encode_data_uri

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'test': True,
                'skip_download': True,
                'quiet': True,
            }
            self.cache = {}
            self.add_default_info_extractors()

        def add_default_info_extractors(self):
            self.ie = InfoExtractor()
            self.ie.add_default_info_extractors()

        def urlopen(self, url):
            if url in self.cache:
                return self.cache[url]

# Generated at 2022-06-18 13:22:24.902434
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri

    class TestIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'ext': 'mp4',
                'http_headers': {
                    'Range': 'bytes=0-%d' % (len(url) - 1),
                },
            }

    ie = TestIE()
    ie.add_info_extractor(HlsFD)

    # Test with a single fragment

# Generated at 2022-06-18 13:22:35.620890
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    ydl = YoutubeDL({'noplaylist': True})
    ydl.add_info_extractor(YoutubeIE())
    ydl.add_default_info_extractors()
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_use_mpegts'] = True
    ydl.params['skip_download'] = True
    ydl.params['quiet'] = True
    ydl.params['test'] = True
    ydl.params['simulate'] = True
    ydl.params['skip_unavailable_fragments'] = True
    ydl.params['fragment_retries'] = 0

# Generated at 2022-06-18 13:22:48.002490
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..utils import prepare_filename
    from ..compat import compat_urllib_request

    # Test for non-live stream
    url = 'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/gear2/prog_index.m3u8'
    ie = YoutubeIE(FileDownloader())
    info = ie.extract(url)
    fd = HlsFD(FileDownloader(), {'outtmpl': prepare_filename(info['id'])})
    assert fd.can_download(compat_urllib_request.urlopen(url).read().decode('utf-8', 'ignore'), info)

# Generated at 2022-06-18 13:22:59.897527
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    # Test for HlsFD constructor
    def test_HlsFD_constructor(url, expected_result):
        ydl = gen_ydl()
        ydl.params['hls_prefer_native'] = True
        ydl.params['hls_use_mpegts'] = False
        ydl.params['hls_segment_filename'] = '%(playlist_index)s-%(segment_id)s.ts'
        ydl.params['hls_playlist_re'] = '.*'
        ydl.params['hls_segment_format'] = 'mpegts'

# Generated at 2022-06-18 13:23:09.060793
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    def _get_url(url):
        return compat_urllib_request.urlopen(url).read().decode('utf-8')

    def _get_url_m3u8(url):
        return _get_url(url).splitlines()

    def _get_url_m3u8_frag(url):
        return _get_url_m3u8(url)[-1]

    def _get_url_m3u8_frag_url(url):
        return _get_url_m3u8_frag(url).split(',')[0]


# Generated at 2022-06-18 13:23:21.452474
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str
    from .external import ExternalFD
    from .fragment import FragmentFD
    from .dash import DashSegmentsFD
    from .hls import HlsFD
    from .http import HttpFD
    from .f4m import F4mFD
    from .ism import IsmFD
    from .m3u8 import M3u8FD
    from .rtmp import RtmpFD
    from .rtsp import RtspFD
    from .smoothstreams import SmoothstreamsFD
    from .stream import StreamFD
    from .subtitles import SubtitlesFD
    from .wvm import WvmFD

    ydl = gen_yd

# Generated at 2022-06-18 13:23:31.509592
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    from .http import HttpFD
    from .external import FFmpegFD
    from .fragment import FragmentFD
    from .dash import DashSegmentsFD

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
            self.extractor = InfoExtractor()
            self.extractor.add_default_info_extractors()

        def urlopen(self, url):
            if url.startswith('data:'):
                return encode_data_uri(url)
            else:
                return compat_urllib_request.urlopen(url)


# Generated at 2022-06-18 13:23:43.998280
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testdata_file
    from .utils import make_fake_info_dict
    from .extractor import gen_extractors
    from .downloader import gen_ydl

    # Test for aes-128 encrypted stream

# Generated at 2022-06-18 13:23:51.197921
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    # Test with a live stream
    ydl = YoutubeDL(YoutubeIE.ie_key_map())
    ydl.add_default_info_extractors()
    info_dict = ydl.extract_info(
        'https://www.youtube.com/watch?v=KlR7-C1hJYc', download=False)
    assert not HlsFD.can_download(info_dict['url'], info_dict)

    # Test with a non-live stream
    ydl = YoutubeDL(YoutubeIE.ie_key_map())
    ydl.add_default_info_extractors()

# Generated at 2022-06-18 13:23:56.094753
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_can_download(url, expected_result):
        for ie in gen_extractors():
            if match_filter_func(ie.IE_NAME)(url):
                break
        else:
            assert False, 'No extractor found for url %s' % url
        ie.extract(url)
        assert ie.suitable(url)
        assert ie.working == expected_result

    _test_can_download('https://www.youtube.com/watch?v=_HSylqgVYQI', True)

# Generated at 2022-06-18 13:24:42.016663
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    from .test_utils import FakeYDL
    from .extractor.common import InfoExtractor
    from .extractor.generic import GenericIE

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a fake ydl object
    ydl = FakeYDL()
    ydl.params['noprogress'] = True
    ydl.params['logger'] = ydl
    ydl.params['test'] = True
    ydl.params['outtmpl'] = os.path.join(tmp_dir, '%(id)s.%(ext)s')

    # Create a fake info dict

# Generated at 2022-06-18 13:24:52.963239
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    def _get_url(url):
        return compat_urllib_request.urlopen(url).read().decode('utf-8')

    def _test_url(url):
        for ie in gen_extractors():
            if match_filter_func(ie.IE_NAME)(url):
                ie = ie()
                ie.extract(url)
                return True
        return False

    def _test_hls_url(url):
        ie = HlsFD()
        ie.extract(url)
        return True

    assert _test_url('https://www.youtube.com/watch?v=yPYZpwSpKmA')

# Generated at 2022-06-18 13:25:05.579918
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import prepend_extension
    from ..compat import compat_urlparse

    def _test_HlsFD(url, expected_filename, expected_fragments, expected_ad_fragments):
        ydl = gen_ydl()
        ie = gen_extractors(ydl)[0].suitable(url)()
        info_dict = ie.extract(url)
        filename = prepend_extension(ydl.prepare_filename(info_dict), ie.ie_key())
        fd = HlsFD(ydl, {'outtmpl': filename})
        assert fd.real_download(filename, info_dict)
        assert fd.total_frags == expected_fragments


# Generated at 2022-06-18 13:25:14.087825
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_info_extractor(YoutubeIE.ie_key())

# Generated at 2022-06-18 13:25:26.014344
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    import os
    import tempfile
    import shutil

    class FakeYDL(object):
        def __init__(self):
            self.temp_dir = tempfile.mkdtemp()
            self.params = {
                'outtmpl': os.path.join(self.temp_dir, '%(id)s.%(ext)s'),
                'test': True,
            }

        def urlopen(self, url):
            return FakeUrlOpen(url)

    class FakeUrlOpen(object):
        def __init__(self, url):
            self.url = url

        def geturl(self):
            return self.url

        def read(self):
            return encode_data_uri(self.url)



# Generated at 2022-06-18 13:25:37.924556
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_str
    from .http import HttpFD
    from .external import FFmpegFD

    class FakeYDL:
        def __init__(self):
            self.params = {
                'test': True,
                'skip_download': True,
                'quiet': True,
            }
            self.cache = None
            self.server = None
            self.to_screen = lambda *args, **kargs: None
            self.report_error = lambda *args, **kargs: None
            self.report_warning = lambda *args, **kargs: None
            self.report_file_already_downloaded = lambda *args, **kargs: None

# Generated at 2022-06-18 13:25:48.763127
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..downloader import Downloader
    from ..postprocessor import FFmpegMergerPP
    from ..cache import Cache
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..extractor.youtube import YoutubeIE
    from ..extractor.youtube_dl import YoutubeDLIE
    from ..extractor.youtube_dl_extractor import YoutubeDLExtractor
    from ..extractor.youtube_dl_extractor.common import InfoExtractor
    from ..extractor.youtube_dl_extractor.youtube import YoutubeIE
    from ..extractor.youtube_dl_extractor.youtube_dl import YoutubeDLIE

# Generated at 2022-06-18 13:25:56.640056
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'test': True,
                'skip_download': True,
                'quiet': True,
            }
            self.cache = {}
            self.to_screen = lambda *args, **kargs: None

        def urlopen(self, url):
            if url in self.cache:
                return self.cache[url]
            else:
                raise compat_urllib_request.URLError('Fake error')

    class FakeIE(InfoExtractor):
        def __init__(self, ydl):
            self

# Generated at 2022-06-18 13:26:04.829334
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    ydl = YoutubeDL({'hls_prefer_native': True})
    ie = YoutubeIE(ydl)

# Generated at 2022-06-18 13:26:13.856022
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .common import FakeYDL
    from .test_fragment import _test_frag_download

    def _test_download(ydl, info_dict, expected_fragments, expected_warnings=None):
        expected_warnings = expected_warnings or []
        fd = HlsFD(ydl, {})
        return _test_frag_download(
            fd, 'test.mp4', info_dict, expected_fragments, expected_warnings)

    def _test_download_with_frag_retries(ydl, info_dict, expected_fragments, expected_warnings=None):
        expected_warnings = expected_warnings or []

# Generated at 2022-06-18 13:27:45.473899
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_hls_fd(url, expected_fd_name):
        ydl = YoutubeDL({'hls_prefer_native': True})
        ydl.add_default_info_extractors()
        ydl.add_info_extractor(gen_extractors(ydl, match_filter_func=match_filter_func('hls')))
        info_dict = ydl.extract_info(url, download=False)
        assert info_dict['_type'] == 'url'
        assert info_dict['protocol'] == 'm3u8'
        assert info_dict['extractor'] == 'hls'
        assert info_dict['url'] == url

# Generated at 2022-06-18 13:27:54.138319
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import unittest

    from .utils import FakeYDL

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.temp_dir, 'test.mp4')
            self.test_file_size = 0
            self.test_file_md5 = None
            self.test_file_sha256 = None
            self.test_file_sha512 = None
            self.test_file_sha1 = None
            self.test_file_sha3_256 = None
            self.test_file_sha3_512 = None
            self.test_file_crc32

# Generated at 2022-06-18 13:28:06.576547
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download(
        '#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXT-X-VERSION:3\n#EXT-X-MEDIA-SEQUENCE:0\n#EXT-X-PLAYLIST-TYPE:VOD\n#EXTINF:10,\nmedia-00001.ts\n#EXT-X-ENDLIST\n',
        {'url': 'http://example.com/playlist.m3u8'})

# Generated at 2022-06-18 13:28:18.093347
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.utils
    import youtube_dl.downloader.http
    import youtube_dl.downloader.fragment
    import youtube_dl.downloader.hls
    import youtube_dl.downloader.external

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a YoutubeDL object

# Generated at 2022-06-18 13:28:25.409036
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.utils

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a youtube-dl object
    ydl_opts = {
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
        'outtmpl': os.path.join(temp_dir, '%(id)s.%(ext)s'),
        'quiet': True,
        'no_warnings': True,
        'simulate': True,
        'skip_download': True,
    }

# Generated at 2022-06-18 13:28:38.535543
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_urlparse
    from ..extractor.common import InfoExtractor
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_urllib_parse_unquote
    from ..compat import compat_urllib_parse_unquote_plus
    from ..compat import compat_urllib_parse_urljoin
    from ..compat import compat_urllib_

# Generated at 2022-06-18 13:28:49.154288
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    # Test with a live stream
    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ie = YoutubeIE(ydl)
    info = ie.extract('https://www.youtube.com/watch?v=nfWlot6h_JM')
    assert info['is_live']
    assert not HlsFD.can_download(info['url'], info)

    # Test with a non-live stream
    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ie = YoutubeIE(ydl)

# Generated at 2022-06-18 13:28:58.451576
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'test': True,
                'skip_download': True,
            }

        def to_screen(self, msg):
            pass

        def report_warning(self, msg):
            pass

        def report_error(self, msg):
            raise Exception(msg)

        def urlopen(self, url):
            return FakeUrlOpen(url)

    class FakeUrlOpen(object):
        def __init__(self, url):
            self.url = url

        def geturl(self):
            return self.url

        def read(self):
            return encode_data_uri(self.url)


# Generated at 2022-06-18 13:29:04.857503
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    gen_extractors()
    for ie in match_filter_func(lambda ie: ie.IE_NAME == 'hlsnative')(gen_extractors()):
        ie.suitable(ie.url)
        ie.download(ie.url)

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-18 13:29:13.926726
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri

    # Test with a manifest that contains a single fragment
    manifest = encode_data_uri(get_test_data('hls/single_fragment.m3u8'))
    ie = InfoExtractor({'hls_prefer_native': True})
    ie.add_info_extractor(HlsFD)
    ie.add_info_extractor(FFmpegFD)
    ie.extract(manifest)

    # Test with a manifest that contains multiple fragments
    manifest = encode_data_uri(get_test_data('hls/multiple_fragments.m3u8'))
    ie = InfoExtractor({'hls_prefer_native': True})
    ie