

# Generated at 2022-06-18 13:20:07.254660
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import urljoin

    ydl = gen_ydl()
    ydl.params['hls_use_mpegts'] = True
    ydl.params['skip_unavailable_fragments'] = True
    ydl.params['fragment_retries'] = 0
    ydl.params['test'] = True
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ydl.params['quiet'] = True
    ydl.params['noprogress'] = True
    ydl.params['nooverwrites'] = True
    ydl.params['simulate'] = True
    ydl.params['format'] = 'bestvideo+bestaudio/best'


# Generated at 2022-06-18 13:20:19.143622
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str

    ydl = gen_ydl()
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_use_mpegts'] = True
    ydl.params['match_filter'] = match_filter_func('all')
    ydl.params['test'] = True
    ydl.params['noprogress'] = True
    ydl.params['quiet'] = True
    ydl.params['skip_download'] = True
    ydl.params['simulate'] = True
    ydl.params['dump_single_json'] = True
    ydl.params['writeinfojson'] = True
    y

# Generated at 2022-06-18 13:20:31.522676
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import encode_data_uri
    from .common import FakeYDL
    from .test_fragment import _test_frag_download
    from .test_external import _test_external_download

    def _test_HlsFD_real_download(ydl, url, expected_fragments, expected_warnings=None, expected_info=None, expected_error=None, expected_fragment_index=None, expected_fragment_retries=None, expected_skip_unavailable_fragments=None, expected_test=None):
        info_dict = YoutubeIE()._real_extract(ydl, url)
        assert info_dict['_type'] == 'url'
        assert info_dict['url'] == url
        assert info_dict['ie_key']

# Generated at 2022-06-18 13:20:42.239382
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import youtube_dl.YoutubeDL
    import youtube_dl.utils

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = os.path.join(temp_dir, 'temp_file')

    # Create a temporary manifest
    temp_manifest = os.path.join(temp_dir, 'temp_manifest')

# Generated at 2022-06-18 13:20:52.730100
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import gen_extractors
    from ..utils import prepend_extractor
    from ..downloader import gen_ydl
    from ..compat import compat_urllib_request
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..extractor.youtube import YoutubeIE
    from ..postprocessor import FFmpegMergerPP
    from ..postprocessor.common import PostProcessor
    from ..postprocessor.ffmpeg import FFmpegPostProcessor
    from ..postprocessor.ffmpeg import FFmpegExtractAudioPP
    from ..postprocessor.ffmpeg import FFmpegMetadataPP
    from ..postprocessor.ffmpeg import FFmpegVideoConvertor
    from ..postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from ..postprocessor.ffmpeg import FFmpegFixupSt

# Generated at 2022-06-18 13:21:03.969368
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'test': True,
                'fragment_retries': 0,
                'skip_unavailable_fragments': False,
            }


# Generated at 2022-06-18 13:21:17.501735
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_info_extractor(YoutubeIE())

# Generated at 2022-06-18 13:21:30.324029
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import tempfile
    import unittest
    from .test_fragment import MockYDL

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.ydl = MockYDL()
            self.params = {
                'fragment_retries': 0,
                'skip_unavailable_fragments': True,
                'test': True,
            }
            self.fd = HlsFD(self.ydl, self.params)


# Generated at 2022-06-18 13:21:39.888528
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import ExtractorError
    from ..compat import compat_urllib_request
    from .test_fragment import TestFragmentFD

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'FakeInfoExtractor'
        _VALID_URL = r'https?://(?:www\.)?fake\.com/video/(?P<id>[0-9]+)'


# Generated at 2022-06-18 13:21:49.305675
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    # Test that the HlsFD can download a single fragment
    ydl = YoutubeDL({'quiet': True})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE.ie_key())
    ydl.params['test'] = True
    ydl.params['fragment_retries'] = 0
    ydl.params['skip_unavailable_fragments'] = False
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_use_mpegts'] = False
    ydl.params['hls_segment_format'] = 'mp4'

# Generated at 2022-06-18 13:22:18.159038
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    def _test_download(url, expected_content):
        ydl = YoutubeDL({'quiet': True})
        info = ydl.extract_info(url, download=False)
        assert info['_type'] == 'url_transparent'
        assert info['url'] == url
        assert info['ie_key'] == 'Youtube'
        assert info['protocol'] == 'm3u8'
        assert info['ext'] == 'mp4'
        assert info['title'] == 'test'
        assert info['alt_title'] == 'test'
        assert info['display_id'] == 'test'
        assert info['id'] == 'test'
        assert info['duration'] == 1
        assert info

# Generated at 2022-06-18 13:22:30.828665
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    from .utils import (
        encodeFilename,
        prepend_extension,
    )

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp(prefix='youtube-dl-test-')

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(
        prefix='youtube-dl-test-',
        suffix='.m3u8',
        dir=temp_dir,
        delete=False)

    # Write the m3u8 file

# Generated at 2022-06-18 13:22:38.619145
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest

# Generated at 2022-06-18 13:22:50.770520
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError
    from ..compat import compat_urllib_request
    from .http import HttpFD
    from .external import ExternalFD
    from .fragment import FragmentFD
    from .dash import DashSegmentsFD
    from .ism import IsmFD
    from .f4m import F4mFD
    from .m3u8 import M3u8FD

    # Test the constructor of class HlsFD

# Generated at 2022-06-18 13:23:02.313917
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    def _test_download(url, expected_fragments):
        ydl = gen_ydl()
        ydl.params['noprogress'] = True
        ydl.params['quiet'] = True
        ydl.params['test'] = True
        ydl.params['match_filter'] = match_filter_func(url)
        ydl.params['outtmpl'] = '%(id)s.%(ext)s'
        ydl.params['fragment_retries'] = 0
        ydl.params['skip_unavailable_fragments'] = False
        ydl.add_default_info_

# Generated at 2022-06-18 13:23:12.745127
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-18 13:23:24.671370
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import unittest

    from .external import ExternalFD
    from .utils import (
        encodeFilename,
        sanitize_open,
    )

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file = os.path.join(self.temp_dir, 'temp_file')

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-18 13:23:33.512186
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encodeFilename
    import os
    import tempfile
    import shutil

    def _test_HlsFD_real_download(url, expected_filename, expected_content):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            f.close()
            filename = encodeFilename(f.name)
            ydl = YoutubeDL({
                'format': 'bestvideo+bestaudio/best',
                'outtmpl': filename,
                'hls_prefer_native': True,
                'test': True,
            })
            ie = YoutubeIE(ydl)
            info = ie._real_extract(url)
            assert info['url'] == url
            assert info['ext'] == 'mp4'
           

# Generated at 2022-06-18 13:23:46.278030
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error

    # Test for aes-128 encrypted stream
    # https://github.com/ytdl-org/youtube-dl/issues/27660
    def _mock_urlopen(req):
        if req.get_full_url() == 'https://example.com/key':
            return get_test_data('aes128_key.bin')
        elif req.get_full_url() == 'https://example.com/fragment':
            return get_test_data('aes128_fragment.bin')
        else:
            raise compat_ur

# Generated at 2022-06-18 13:23:55.383588
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import SearchInfoExtractor

    class FakeYDL(object):
        def __init__(self):
            self.params = {}

        def urlopen(self, url):
            class FakeUrlOpen(object):
                def __init__(self, url):
                    self.url = url
                    self.read_count = 0

                def geturl(self):
                    return self.url

                def read(self):
                    self.read_count += 1

# Generated at 2022-06-18 13:24:44.585492
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import json
    import unittest
    from .test_download import FakeYDL
    from .test_download import get_testdata_dir

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.ydl = FakeYDL()
            self.ydl.params['noprogress'] = True
            self.ydl.params['quiet'] = True
            self.ydl.params['test'] = True
            self.ydl.params['outtmpl'] = os.path.join(self.test_dir, '%(id)s.%(ext)s')

# Generated at 2022-06-18 13:24:54.301278
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_urlparse
    from ..downloader import Downloader
    from ..postprocessor import FFmpegMergerPP
    from ..extractor import gen_extractors
    from ..extractor.generic import YoutubeIE
    from ..extractor.common import InfoExtractor
    from ..compat import (
        compat_urllib_request,
        compat_urllib_error,
        compat_urllib_parse,
        compat_urllib_parse_urlparse,
        compat_urllib_parse_urlencode,
        compat_urllib_parse_unquote,
    )

# Generated at 2022-06-18 13:25:06.756788
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..extractor import YoutubeIE
    from ..utils import encode_data_uri

    # Test for a live stream

# Generated at 2022-06-18 13:25:15.217268
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import tempfile
    import unittest
    from .test_downloader import FakeYDL
    from .test_downloader import MockHttpServer
    from .test_downloader import MockHttpsServer
    from .test_downloader import MockServerRule
    from .test_downloader import read_files

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.test_files_dir = os.path.join(os.path.dirname(__file__), 'test_files')
            self.test_manifest_dir = os.path.join(self.test_files_dir, 'hls')

# Generated at 2022-06-18 13:25:20.494097
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    ydl = gen_ydl()
    gen_extractors(ydl)
    info_dict = {'url': 'https://example.com/manifest.m3u8'}
    HlsFD(ydl, {}).real_download('test.mp4', info_dict)

# Generated at 2022-06-18 13:25:33.925440
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import FakeYDL
    from .test_fragment_downloader import FakeFragmentFD

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'fake'
        _VALID_URL = r'https?://(?:www\.)?fake\.com/video/(?P<id>[^/]+)'


# Generated at 2022-06-18 13:25:45.239492
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download(
        '#EXTM3U\n#EXT-X-KEY:METHOD=NONE\n#EXTINF:10,\nmedia.ts\n',
        {'url': 'http://example.com/manifest.m3u8'})
    assert HlsFD.can_download(
        '#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\n#EXTINF:10,\nmedia.ts\n',
        {'url': 'http://example.com/manifest.m3u8'})

# Generated at 2022-06-18 13:25:54.263439
# Unit test for constructor of class HlsFD

# Generated at 2022-06-18 13:26:03.440180
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..utils import prepend_extension
    from ..compat import compat_urlparse

    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    ie = YoutubeIE(FileDownloader())
    info_dict = ie.extract(url)
    info_dict['url'] = info_dict['url'] + '&ratebypass=yes'
    info_dict['http_headers'] = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'}

# Generated at 2022-06-18 13:26:12.201561
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_info_extractor(YoutubeIE())

# Generated at 2022-06-18 13:27:07.003233
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..utils import FakeYDL
    from ..compat import compat_urllib_request
    from ..extractor.generic import GenericIE
    from ..extractor.youtube import YoutubeIE

    def _test_HlsFD_can_download(url, expected_result):
        ie = InfoExtractor(FakeYDL(), {'username': 'test', 'password': 'test'})
        ie.add_info_extractor(GenericIE())
        ie.add_info_extractor(YoutubeIE())
        ie.extract(url)
        assert ie._ies[0]._downloader.params.get('hls_use_mpegts') == expected_result


# Generated at 2022-06-18 13:27:17.508677
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..compat import compat_urllib_request

    def _test_can_download(url, expected_result):
        ydl = gen_ydl()
        info_dict = {}
        for ie in gen_extractors():
            try:
                ie.extract(ydl, url)
            except Exception:
                pass
            else:
                info_dict = ie.get_info_dict(ydl)
                break
        assert info_dict
        with compat_urllib_request.urlopen(url) as urlh:
            manifest = urlh.read().decode('utf-8', 'ignore')
        assert HlsFD.can_download(manifest, info_dict) == expected_result

    _test

# Generated at 2022-06-18 13:27:27.250221
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import ExtractorError
    from .fragment import FragmentFD
    from .external import FFmpegFD

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.setdefault('_type', 'url')
            self.setdefault('url', 'https://example.com/')
            self.setdefault('http_headers', {})
            self.setdefault('protocol', 'm3u8_native')


# Generated at 2022-06-18 13:27:31.834404
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    def _fake_urlopen(req):
        class FakeUrlOpen(object):
            def __init__(self, req):
                self.req = req
            def geturl(self):
                return self.req.get_full_url()
            def read(self):
                return '#EXTM3U\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=836280,RESOLUTION=640x360\n' + self.req.get_full_url() + '\n'
        return FakeUrlOpen(req)


# Generated at 2022-06-18 13:27:40.051403
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor import gen_extractors
    from .downloader import gen_ydl
    from .utils import match_filter_func

    def _test_HlsFD_real_download(ydl, info_dict):
        filename = 'test.mp4'
        HlsFD(ydl, {}).real_download(filename, info_dict)
        with open(filename, 'rb') as f:
            data = f.read()
        assert data == b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        return True

    ydl = gen_ydl(params={'noplaylist': True})
   

# Generated at 2022-06-18 13:27:47.839173
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import unittest
    from .test_downloader import FakeYDL
    from .test_downloader import FakeHttpServer
    from .test_downloader import MockServerRule

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.server = FakeHttpServer()
            self.server.start()
            self.server_rule = MockServerRule(self.server)

# Generated at 2022-06-18 13:27:55.803855
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import FakeYDL
    from ..compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'https?://.*'

# Generated at 2022-06-18 13:28:08.549912
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError
    from .http import HttpFD
    from .external import ExternalFD

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'hls_prefer_native': True,
                'hls_use_mpegts': False,
            }

        def urlopen(self, url):
            return HttpFD(self, {'url': url})

    class FakeIE(InfoExtractor):
        def __init__(self, ydl, url):
            self.ydl = ydl
            self.url = url

    ie = FakeIE(FakeYDL(), 'https://example.com/')
    fd = ie.get_media_data_fd()

# Generated at 2022-06-18 13:28:19.424677
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .common import FakeYDL

    class FakeIE(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeIE, self).__init__(*args, **kwargs)
            self.test_result = None

        def _download_webpage(self, *args, **kwargs):
            return encode_data_uri(self.test_result)

    ie = FakeIE(FakeYDL())

# Generated at 2022-06-18 13:28:30.336515
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..downloader import YoutubeDL
    from .external import FFmpegFD
    from .fragment import FragmentFD

    # Test for HlsFD

# Generated at 2022-06-18 13:29:30.989217
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    def _test_downloader(ydl, info_dict):
        info_dict = info_dict.copy()
        info_dict['url'] = 'http://localhost:8080/test.m3u8'