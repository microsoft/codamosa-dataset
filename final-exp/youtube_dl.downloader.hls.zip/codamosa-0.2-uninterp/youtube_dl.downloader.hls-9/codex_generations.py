

# Generated at 2022-06-18 13:20:08.143258
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import unittest
    from .test_downloader import MockYDL
    from .test_downloader import MockFileDownloader
    from .test_downloader import MockInfoExtractor
    from .test_downloader import MockHttpDlProgress
    from .test_downloader import MockHook
    from .test_downloader import MockFile

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.ydl = MockYDL()
            self.ydl.params['nooverwrites'] = True
            self.ydl.params['continuedl'] = False
            self.ydl.params['quiet'] = True

# Generated at 2022-06-18 13:20:19.711067
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def test_can_download(manifest, info_dict, expected_result):
        extractors = gen_extractors()
        extractors = match_filter_func(extractors, lambda e: e.IE_NAME == 'hls')
        for extractor in extractors:
            if extractor.can_download(manifest, info_dict):
                assert expected_result == True
            else:
                assert expected_result == False

    # Test for encrypted streams

# Generated at 2022-06-18 13:20:32.171697
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError
    from ..compat import compat_urllib_request
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD
    from ..downloader.external import ExternalFD
    from ..downloader.f4m import F4mFD
    from ..downloader.ism import IsmFD
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.hls import HlsFD as HlsFD_old
    from ..downloader.hls import HlsFD as HlsFD_new
    from ..downloader.fragment import FragmentFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.smoothstreaming import SmoothStreamingFD

# Generated at 2022-06-18 13:20:42.783198
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'quiet': True})
    ydl.add_default_info_extractors()
    ie = YoutubeIE(ydl)
    info = ie._real_extract(
        'https://www.youtube.com/watch?v=BaW_jenozKc')
    assert HlsFD.can_download(
        encode_data_uri(info['url']), info)
    assert not HlsFD.can_download(
        encode_data_uri(info['url'].replace(
            'METHOD=NONE', 'METHOD=AES-128')), info)

# Generated at 2022-06-18 13:20:53.270718
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..compat import compat_str
    from .test_fragment import _test_download_fragment
    from .test_external import _test_download_external


# Generated at 2022-06-18 13:21:04.670285
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import FakeYDL
    from .common import BaseTest

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'FakeInfoExtractor'
        _VALID_URL = r'https?://(?:www\.)?fake\.com/video/(?P<id>[0-9]+)'

# Generated at 2022-06-18 13:21:18.155908
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.utils
    import youtube_dl.extractor.common

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a youtube-dl object
    ydl_opts = {
        'format': 'best',
        'outtmpl': os.path.join(temp_dir, '%(id)s-%(format)s-%(format_id)s-%(resolution)s.%(ext)s'),
        'quiet': True,
        'simulate': True,
        'skip_download': True,
        'logger': youtube_dl.YoutubeDL.YoutubeDL(ydl_opts),
    }

    # Create a youtube-dl extractor

# Generated at 2022-06-18 13:21:31.009342
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'quiet': True})
    ydl.add_default_info_extractors()
    ie = YoutubeIE(ydl)

    # Test with a simple m3u8 manifest

# Generated at 2022-06-18 13:21:40.415247
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    from .common import FakeYDL

    class FakeIE(InfoExtractor):
        def _real_initialize(self):
            pass

    ie = FakeIE(FakeYDL())
    ie.params = {'test': True}
    ie.add_info_extractor(HlsFD)

    # Test with an unencrypted fragment

# Generated at 2022-06-18 13:21:49.750671
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    from ..utils import ExtractorError

    class FakeYDL:
        def __init__(self, params):
            self.params = params

        def to_screen(self, s):
            pass

        def trouble(self, s, tb=None):
            pass

        def report_warning(self, s):
            pass

        def report_error(self, s, tb=None):
            pass

        def urlopen(self, url):
            class FakeUrlOpen:
                def __init__(self, url):
                    self.url = url
                    self.code = 200
                    self.headers = {'Content-Type': 'text/plain'}
                    self.content = b''
                    self.info = lambda: self.headers

# Generated at 2022-06-18 13:22:21.532759
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError
    from ..compat import compat_urllib_request
    from .http import HttpFD
    from .http import HttpIE
    from .http import HttpRequest
    from .http import HEADRequest
    from .http import HEADRequest
    from .http import HEADRequest
    from .http import HEADRequest
    from .http import HEADRequest
    from .http import HEADRequest
    from .http import HEADRequest
    from .http import HEADRequest
    from .http import HEADRequest
    from .http import HEADRequest
    from .http import HEADRequest
    from .http import HEADRequest
    from .http import HEADRequest
    from .http import HEADRequest
    from .http import HEADRequest
    from .http import HEADRequest
    from .http import HEADRequest
   

# Generated at 2022-06-18 13:22:33.177387
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import encode_data_uri

    # Test for issue #27660
    # The test data is a truncated fragment of the following HLS stream:
    # https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8
    # The fragment is truncated to the first 16 bytes of the first fragment.
    # The first 16 bytes of the fragment are:
    # 0x00, 0x00, 0x00, 0x01, 0x09, 0x10, 0x00, 0x00, 0x00, 0x01, 0x67, 0x42

# Generated at 2022-06-18 13:22:44.379458
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..extractor import YoutubeIE
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request

    def _test_download(url, expected_fragment_count, expected_fragment_data):
        ydl_opts = {
            'outtmpl': '%(id)s.%(ext)s',
            'quiet': True,
            'skip_download': True,
            'test': True,
        }
        ie = YoutubeIE(ydl_opts)
        info = ie.extract(url)
        assert info['_type'] == 'url'
        assert info['url'] == url
        assert info['ie_key'] == 'HlsFD'

# Generated at 2022-06-18 13:22:56.474064
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func


# Generated at 2022-06-18 13:23:06.446534
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_downloader
    from ..postprocessor import gen_pp
    from ..utils import prepend_extension
    from ..compat import compat_str
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    from ..extractor.generic import GenericIE
    from ..downloader.f4m import F4mFD
    from ..downloader.hls import HlsFD
    from ..downloader.http import HttpFD
    from ..postprocessor.ffmpeg import FFmpegPostProcessor
    from ..postprocessor.ffmpegmetadata import FFmpegMetadataPP
    from ..postprocessor.execafterdownload import ExecAfterDownloadPP
    from ..postprocessor.xattrpp import XAttrMetadataPP

# Generated at 2022-06-18 13:23:12.822071
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..extractor import YoutubeIE
    from ..utils import encode_data_uri

    # Test for a live stream
    info_dict = {
        'id': 'live_stream',
        'url': 'https://example.com/live_stream.m3u8',
        'ext': 'mp4',
        'title': 'live_stream',
        'is_live': True,
    }
    ie = YoutubeIE(params={})
    ie.extract_info(info_dict)
    assert not HlsFD.can_download(get_test_data('live_stream.m3u8'), info_dict)

    # Test for a live stream with EXT-X-PLAYLIST-TYPE:EVENT

# Generated at 2022-06-18 13:23:24.761291
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..extractor.common import InfoExtractor
    from ..compat import compat_urllib_request
    from ..utils import encode_data_uri

    def _mock_urlopen(url):
        if url == 'http://example.com/manifest.m3u8':
            return get_test_data('test.m3u8')
        elif url == 'http://example.com/frag1.ts':
            return get_test_data('frag1.ts')
        elif url == 'http://example.com/frag2.ts':
            return get_test_data('frag2.ts')
        elif url == 'http://example.com/frag3.ts':
            return get_test_data('frag3.ts')
       

# Generated at 2022-06-18 13:23:33.569112
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func

    ydl = gen_ydl()
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_use_mpegts'] = False
    ydl.params['hls_segment_skip'] = 0
    ydl.params['hls_segment_preference'] = 'lowest'
    ydl.params['hls_segment_attempts'] = 10
    ydl.params['hls_segment_threads'] = 1
    ydl.params['hls_segment_timeout'] = 10.0
    ydl.params['hls_fragment_retries'] = 0

# Generated at 2022-06-18 13:23:46.318018
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..compat import compat_urllib_request
    from ..utils import url_basename

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {'id': url_basename(url), 'url': url}

    ie = FakeInfoExtractor({})
    ie.add_info_extractor(HlsFD.ie_key())

    def test_can_download(url, expected):
        info_dict = ie._real_extract(url)
        assert HlsFD.can_download(
            compat_urllib_request.urlopen(info_dict['url']).read().decode('utf-8'), info_dict) == expected


# Generated at 2022-06-18 13:23:55.383040
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\nmedia.ts\n#EXT-X-ENDLIST\n', {})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\nmedia.ts\n#EXT-X-ENDLIST\n', {'is_live': True})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\nmedia.ts\n#EXT-X-ENDLIST\n', {'extra_param_to_segment_url': 'foo=bar'})


# Generated at 2022-06-18 13:24:48.092972
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..extractor import gen_extractors
    from ..utils import encode_data_uri

    def _test_real_download(url, expected_frag_content):
        extractors = gen_extractors()
        for ie in extractors:
            if ie.suitable(url) and ie.IE_NAME in ie.GENERIC_IE_NAME:
                break
        else:
            assert False, 'No extractor found for URL %r' % url

        ie = ie.ie
        info = ie._real_extract(ie._request_webpage(url, None, 'Downloading webpage'))
        info_dict = info['info_dict']
        info_dict['url'] = url

# Generated at 2022-06-18 13:24:58.123621
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..compat import compat_str
    from ..utils import encode_data_uri

    # Test for encrypted streams
    manifest = '#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\n'
    info_dict = {'id': '12345', 'ext': 'mp4', 'title': 'test', 'url': 'http://test.com/test.m3u8'}
    assert not HlsFD.can_download(manifest, info_dict)

    # Test for live streams
    manifest = '#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:1\n'

# Generated at 2022-06-18 13:25:09.534800
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import sys
    import tempfile
    import unittest
    from .test_downloader import FakeYDL
    from .test_downloader import FakeHttpServer
    from .test_downloader import get_testdata_dir

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.ydl = FakeYDL()
            self.ydl.params['noprogress'] = True
            self.ydl.params['quiet'] = True
            self.ydl.params['outtmpl'] = os.path.join(self.test_dir, '%(id)s.%(ext)s')
            self.ydl.params['test'] = True

# Generated at 2022-06-18 13:25:17.821079
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func

    ydl = gen_ydl(params={'hls_prefer_native': True})
    ydl.add_info_extractor(gen_extractors(ydl))
    info_dict = ydl.extract_info(
        'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8',
        download=False)
    assert HlsFD.can_download(info_dict['url'], info_dict)

    ydl = gen_ydl(params={'hls_prefer_native': True})
    ydl.add_info

# Generated at 2022-06-18 13:25:30.702038
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import youtube_dl.YoutubeDL
    import youtube_dl.downloader.hls
    import youtube_dl.downloader.http
    import youtube_dl.extractor.common
    import youtube_dl.extractor.youtube
    import youtube_dl.utils

    def _run_test(test_name, test_data, expected_data, expected_warnings, expected_errors):
        temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:25:41.562359
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    from .external import FFmpegFD

    ydl = YoutubeDL({'quiet': True})
    ie = YoutubeIE(ydl)
    info_dict = ie.extract(encode_data_uri(
        'https://www.youtube.com/watch?v=WKsjaOqDXgg'))
    assert HlsFD.can_download(info_dict['url'], info_dict)
    hlsfd = HlsFD(ydl, {'quiet': True})
    assert isinstance(hlsfd, HlsFD)
    assert not isinstance(hlsfd, FFmpegFD)


# Generated at 2022-06-18 13:25:51.348254
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..compat import compat_urllib_request
    from ..utils import encode_data_uri

    # Test with a simple m3u8 manifest

# Generated at 2022-06-18 13:26:01.618477
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import shutil
    import tempfile
    import unittest
    from .test_download import FakeYDL
    from .test_download import get_testdata_dir

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.ydl = FakeYDL()
            self.ydl.params['outtmpl'] = os.path.join(self.test_dir, '%(id)s.%(ext)s')
            self.fd = HlsFD(self.ydl, {})

        def tearDown(self):
            shutil.rmtree(self.test_dir)


# Generated at 2022-06-18 13:26:10.055113
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..extractor import gen_extractors
    from ..utils import encode_data_uri

    # Test for a live stream
    info_dict = {
        'id': '622873',
        'ext': 'mp4',
        'title': 'Test',
        'url': 'http://hls-geo.daserste.de/i/videoportal/Film/c_620000/622873/format,716451,716457,716450,716458,716459,.mp4.csmil/master.m3u8?null=0',
        'is_live': True,
    }
    ie = gen_extractors(info_dict)['hlsnative']

# Generated at 2022-06-18 13:26:17.718011
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import unittest
    from .test_downloader import FakeYDL

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.ydl = FakeYDL()
            self.ydl.params['noprogress'] = True
            self.ydl.params['quiet'] = True
            self.ydl.params['outtmpl'] = os.path.join(self.test_dir, '%(id)s.%(ext)s')

        def tearDown(self):
            shutil.rmtree(self.test_dir)


# Generated at 2022-06-18 13:27:47.308639
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import prepend_extension
    from ..compat import compat_urlparse

    ydl = gen_ydl()
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(gen_extractors()[0])

    url = 'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8'
    url_parsed = compat_urlparse.urlparse(url)
    url_parsed = url_parsed._replace(path=prepend_extension(url_parsed.path, 'mp4'))
    url

# Generated at 2022-06-18 13:27:55.448944
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.utils
    import youtube_dl.downloader.fragment

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a youtube-dl object

# Generated at 2022-06-18 13:28:08.121863
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import common
    from ..downloader.common import FileDownloader
    from ..utils import encode_data_uri
    from .fragment import FragmentFD
    import os
    import tempfile
    import shutil
    import random
    import string

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a random string
    def random_string(length):
        return ''.join(random.choice(string.ascii_lowercase) for i in range(length))

    # Create a random file
    def random_file(filename, length):
        with open(filename, 'wb') as f:
            f.write(os.urandom(length))

    # Create a temporary file
    temp_file = os.path.join(temp_dir, 'temp_file')


# Generated at 2022-06-18 13:28:19.077753
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    import os
    import tempfile
    import shutil
    import subprocess
    import sys

    def _test_HlsFD_real_download(url, expected_output_filename):
        with tempfile.NamedTemporaryFile(delete=False) as output_file:
            output_filename = output_file.name

# Generated at 2022-06-18 13:28:27.406187
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_HlsFD(url, expected_result):
        extractors = gen_extractors()
        extractor = match_filter_func(extractors, lambda e: e.suitable(url))[0]
        assert isinstance(extractor, HlsFD) == expected_result

    _test_HlsFD('http://example.com/index.m3u8', True)
    _test_HlsFD('http://example.com/index.m3u8?foo=bar', True)
    _test_HlsFD('http://example.com/index.m3u8#foo', True)

# Generated at 2022-06-18 13:28:39.040526
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import unittest
    from .test_downloader import MockYDL
    from .test_downloader import MockInfoDict
    from .test_downloader import MockFD

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.temp_dir, 'test.mp4')
            self.test_url = 'http://example.com/test.m3u8'

# Generated at 2022-06-18 13:28:49.771116
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..compat import compat_str
    from ..utils import encode_data_uri

    def _test_can_download(manifest, expected_result, expected_warning=None):
        ie = InfoExtractor(None)
        ie._downloader = None
        ie.params = {}
        result = HlsFD.can_download(manifest, ie)
        assert result == expected_result, 'Expected %s but got %s' % (expected_result, result)
        if expected_warning:
            assert ie.report_warning.call_count == 1
            assert expected_warning in compat_str(ie.report_warning.call_args[0][0])


# Generated at 2022-06-18 13:28:58.920562
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import ExtractorError
    from .fragment import FragmentFD
    from .external import FFmpegFD

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'fake_id',
                'url': url,
                'extractor': 'fake',
                'title': 'fake_title',
            }

    class FakeIE(GenericIE):
        _VALID_URL = r'https?://(?:www\.)?fake\.com/video/(?P<id>[^/]+)'

# Generated at 2022-06-18 13:29:09.370017
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri

    class TestIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'url': url,
                'id': 'test',
                'title': 'test',
                'ext': 'mp4',
            }

    ie = TestIE()
    ie.add_info_extractor(HlsFD)

    # Test with a single fragment

# Generated at 2022-06-18 13:29:20.656077
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_info_extractor(YoutubeIE())

    # Test HlsFD constructor with a valid manifest