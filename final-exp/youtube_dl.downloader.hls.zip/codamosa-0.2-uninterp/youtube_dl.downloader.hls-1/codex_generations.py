

# Generated at 2022-06-18 13:20:09.842683
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.utils

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = os.path.join(temp_dir, 'temp_file')

    # Create a youtube-dl object
    ydl_opts = {
        'outtmpl': temp_file,
        'quiet': True,
        'no_warnings': True,
        'simulate': True,
        'skip_download': True,
    }
    ydl = youtube_dl.YoutubeDL(ydl_opts)

    # Create a HlsFD object

# Generated at 2022-06-18 13:20:18.121246
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'noplaylist': True})
    ie = YoutubeIE(ydl)
    info_dict = ie.extract(encode_data_uri(
        'https://www.youtube.com/watch?v=yVpbFMhOAwE'))
    fd = HlsFD(ydl, {'test': True})
    assert fd.real_download('test.mp4', info_dict)

# Generated at 2022-06-18 13:20:29.628746
# Unit test for constructor of class HlsFD

# Generated at 2022-06-18 13:20:40.725706
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_str

    def test_hls_fd(url):
        for ie in gen_extractors():
            if not ie.suitable(url) or not ie.IE_NAME.startswith('hls'):
                continue
            ie = ie.ie
            ie = ie(compat_str(url))
            ie.extract()
            info = ie.extract_info(ie.url, ie.video_id)
            if 'formats' not in info:
                continue
            for f in info['formats']:
                if f.get('protocol') == 'm3u8_native' and HlsFD.can_download(f['url'], info):
                    return True
       

# Generated at 2022-06-18 13:20:51.403593
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    # Test with a playlist that has a single fragment
    url = 'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8'
    ydl = gen_ydl(params={'hls_use_mpegts': True})
    ydl.add_info_extractor(gen_extractors()[0])
    ydl.params['match_filter'] = match_filter_func(url)
    ydl.params['test'] = True
    ydl.params['quiet'] = True
    y

# Generated at 2022-06-18 13:21:02.047193
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeDL
    ydl = YoutubeDL({})
    hls_fd = HlsFD(ydl, {})
    assert hls_fd.FD_NAME == 'hlsnative'

# Generated at 2022-06-18 13:21:15.412445
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_info_extractor(YoutubeIE())

# Generated at 2022-06-18 13:21:28.308558
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s', 'quiet': True, 'skip_download': True})
    ie = YoutubeIE(ydl)
    ie.extract('https://www.youtube.com/watch?v=p4yYp_Mv6W8')
    info_dict = ydl.extract_info(
        'https://www.youtube.com/watch?v=p4yYp_Mv6W8', download=False)
    info_dict['url'] = encode_data_uri(info_dict['url'])

# Generated at 2022-06-18 13:21:38.598172
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urlparse

    def _run_test(ie, url, expected_frag_content):
        params = {
            'format': 'best',
            'test': True,
            'noplaylist': True,
            'outtmpl': '%(id)s.%(ext)s',
        }
        fd = FileDownloader(params)
        fd.add_info_extractor(ie)
        fd.add_default_info_extractors()
        fd.download([url])
        assert fd.downloaded_info_dicts[0]['url'] == url
        assert fd.downloaded_info_dict

# Generated at 2022-06-18 13:21:44.541497
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .common import FakeYDL
    from .test_fragment import _test_frag_download

    def _test_download(ydl, ie, expected_frag_content, expected_frag_index):
        info_dict = ie.extract('dummy')
        info_dict['url'] = encode_data_uri(info_dict['url'], 'text/plain')
        info_dict['http_headers'] = {'User-Agent': 'test'}
        info_dict['_decryption_key_url'] = encode_data_uri(info_dict['_decryption_key_url'], 'text/plain')

# Generated at 2022-06-18 13:22:14.949161
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import unittest
    from .test_utils import FakeYDL

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.ydl = FakeYDL()
            self.ydl.params['hls_use_mpegts'] = True
            self.ydl.params['test'] = True
            self.ydl.params['outtmpl'] = os.path.join(self.test_dir, '%(id)s.%(ext)s')
            self.fd = HlsFD(self.ydl, self.ydl.params)

        def tearDown(self):
            shutil.rmtree(self.test_dir)


# Generated at 2022-06-18 13:22:27.797878
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeDL
    from ..downloader.common import FileDownloader
    from ..utils import encode_data_uri
    from .fragment import FragmentFD
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)

    # Create a temporary manifest file
    temp_manifest = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)

    # Create a temporary key file
    temp_key = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)

    # Create a temporary fragment file
    temp_fragment = tempfile.NamedTemporaryFile

# Generated at 2022-06-18 13:22:37.213305
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str

    ydl = gen_ydl(params={'hls_prefer_native': True})
    extractors = gen_extractors(ydl)
    for ie in extractors:
        if ie.IE_NAME == 'hlsnative':
            break
    else:
        raise ValueError('HlsFD not found')

    def _test_HlsFD(url, expected_result):
        info_dict = ie._real_extract(ydl, compat_str(url))
        assert HlsFD.can_download(info_dict['url'], info_dict) == expected_result


# Generated at 2022-06-18 13:22:49.457392
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import ExtractorError

    # Test for non-encrypted stream
    ie = InfoExtractor(GenericIE())
    ie.params = {'noplaylist': True}
    ie._downloader = object()
    ie._downloader.params = {'hls_prefer_native': True}
    ie.url = 'https://example.com/'
    ie.info = {'url': 'https://example.com/'}
    ie.info['extractor'] = 'generic'
    ie.info['extractor_key'] = 'Generic'
    ie.info['_type'] = 'hls'
    ie.info['url'] = 'https://example.com/'
    ie.info['manifest_url']

# Generated at 2022-06-18 13:23:01.403078
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .utils import encodeFilename
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urljoin
    from .compat import compat_urllib_parse_urlsplit
    from .compat import compat_ur

# Generated at 2022-06-18 13:23:07.972991
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    ydl = gen_ydl()
    for ie in gen_extractors():
        if ie.ie_key() == 'hlsnative':
            break
    ie.extract_info(ydl, 'https://www.youtube.com/watch?v=0iIzYBV6sH8', download=False)
    info_dict = ie._get_info_dict(ydl)
    assert HlsFD.can_download(info_dict['url'], info_dict)

# Generated at 2022-06-18 13:23:20.776335
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    from ..downloader import Downloader
    from ..downloader.common import FileDownloader
    from ..downloader.external import ExternalFD
    from ..downloader.f4m import F4mFD
    from ..downloader.hls import HlsFD
    from ..downloader.http import HttpFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.dash import DashFD
    from ..downloader.ism import IsmFD
    from ..downloader.fragment import FragmentFD
    from ..downloader.external import FFmpegFD
    from ..downloader.external import FFmpegDownloader
    from ..downloader.external import FFmpegPostProcessor
   

# Generated at 2022-06-18 13:23:31.016758
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .extractor.generic import GenericIE
    from .compat import compat_urlparse

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'Fake'
        _VALID_URL = r'(?i)^https?://.*'

        def _real_extract(self, url):
            return {
                'id': 'fake',
                'url': url,
                'title': 'fake',
                'formats': [{
                    'url': url,
                    'format_id': 'fake',
                    'ext': 'mp4',
                }],
            }

    class FakeIE(GenericIE):
        IE_NAME = 'Fake'

# Generated at 2022-06-18 13:23:43.286684
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..utils import prepend_extension

    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    ie = YoutubeIE(FileDownloader())
    info_dict = ie.extract(url)

# Generated at 2022-06-18 13:23:50.828364
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .common import FakeYDL
    from .test_download import TestDownloadManager

    # Test that HlsFD can download a single fragment
    def test_single_fragment(self):
        ie = InfoExtractor(FakeYDL(), {})
        ie.params = {'test': True}
        ie.add_info_extractor(HlsFD)
        ie.add_info_extractor(FFmpegFD)

# Generated at 2022-06-18 13:24:41.493161
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader.common import FileDownloader
    from ..utils import match_filter_func

    # Test that HlsFD can be instantiated
    ydl = FileDownloader({'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_info_extractor(gen_extractors(ydl, match_filter_func('hlsnative')))
    ydl.download(['https://www.youtube.com/watch?v=pwYjLZk-_q0'])

# Generated at 2022-06-18 13:24:52.577318
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    from .test_fragment import _test_real_download

    def _test_real_download_with_params(params, expected_filename, expected_content):
        tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:25:05.135591
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-18 13:25:13.837049
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    # Test for a live stream
    info_dict = {
        'id': 'live',
        'url': 'https://example.com/live.m3u8',
        'ext': 'mp4',
        'title': 'live',
        'is_live': True,
    }
    ydl = YoutubeDL({'simulate': True})
    ydl.add_info_extractor(YoutubeIE(ydl))
    fd = HlsFD(ydl, {'hls_use_mpegts': False})

# Generated at 2022-06-18 13:25:25.762036
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..compat import compat_urllib_request
    from ..utils import encode_data_uri

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'test': True,
                'noprogress': True,
            }
            self.to_screen = lambda *args, **kargs: None

        def urlopen(self, url):
            if url.startswith('data:'):
                return compat_urllib_request.urlopen(url)
            return compat_urllib_request.urlopen(encode_data_uri(url))

    class FakeIE(InfoExtractor):
        def __init__(self, manifest, info_dict):
            self.manifest = manifest
            self.info_dict

# Generated at 2022-06-18 13:25:37.737895
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import Downloader
    from ..utils import encodeFilename
    import os
    import tempfile
    import shutil
    import subprocess

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_file = tempfile.mkstemp(dir=temp_dir)
    os.close(fd)

    # Download a video
    ydl = Downloader({'outtmpl': temp_file, 'quiet': True, 'test': True})
    ydl.add_info_extractor(YoutubeIE)
    ydl.download(['https://www.youtube.com/watch?v=BaW_jenozKc'])

    # Check if the file is not empty

# Generated at 2022-06-18 13:25:48.627476
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..downloader import YoutubeDL
    from ..postprocessor import FFmpegMergerPP
    from ..postprocessor.ffmpeg import FFmpegPostProcessor
    from ..postprocessor.ffmpeg import FFmpegExtractAudioPP
    from ..postprocessor.ffmpeg import FFmpegMetadataPP
    from ..postprocessor.ffmpeg import FFmpegVideoConvertor
    from ..postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from ..postprocessor.ffmpeg import FFmpegFixupStretchedPP
    from ..postprocessor.ffmpeg import FFmpegFixupM3u8PP
    from ..postprocessor.ffmpeg import FFmpegFixupM4aPP

# Generated at 2022-06-18 13:25:56.558328
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str

    def _test_HlsFD(url, expected_result):
        ydl = gen_ydl()
        ydl.params['noplaylist'] = True
        ydl.params['match_filter'] = match_filter_func(url)
        ydl.params['test'] = True
        ydl.params['quiet'] = True
        ydl.params['forcejson'] = True
        ydl.params['simulate'] = True
        ydl.params['dump_single_json'] = True
        ydl.params['skip_download'] = True
        ydl.params['writeinfojson'] = True

# Generated at 2022-06-18 13:26:04.787397
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import FakeYDL
    from ..extractor import get_info_extractor
    from ..compat import compat_urllib_request

    class FakeUrlOpen(object):
        def __init__(self, url):
            self.url = url
            self.content = None
            self.headers = {}

        def geturl(self):
            return self.url

        def read(self):
            return self.content

        def info(self):
            return self.headers

    class FakeYdl(FakeYDL):
        def __init__(self, *args, **kwargs):
            super(FakeYdl, self).__init__(*args, **kwargs)
            self.urlopen = FakeUrlOpen


# Generated at 2022-06-18 13:26:13.822924
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    from youtube_dl.utils import DownloadError

    def _test_HlsFD_real_download(manifest, info_dict, expected_content, expected_error=None):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            tmp_filename = f.name

# Generated at 2022-06-18 13:27:46.792688
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import json
    import youtube_dl.extractor.common
    import youtube_dl.utils

    def _get_test_cases():
        test_cases = []
        for test_case in os.listdir(os.path.join(os.path.dirname(__file__), 'test_cases')):
            if test_case.startswith('hlsnative_') and test_case.endswith('.json'):
                test_cases.append(test_case)
        return test_cases

    def _get_test_case_data(test_case):
        with open(os.path.join(os.path.dirname(__file__), 'test_cases', test_case)) as f:
            return json.load(f)


# Generated at 2022-06-18 13:27:55.041536
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('', {})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=NONE', {})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'_decryption_key_url': 'http://example.com/key'})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'_decryption_key_url': 'http://example.com/key', 'is_live': True})

# Generated at 2022-06-18 13:28:07.624996
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor import gen_extractors
    from .downloader import gen_ydl
    from .utils import urljoin

    # Create a test downloader
    ydl = gen_ydl()
    ydl.params['nooverwrites'] = True
    ydl.params['continuedl'] = False
    ydl.params['quiet'] = True
    ydl.params['noprogress'] = True
    ydl.params['test'] = True

    # Create a test extractor
    extractor = gen_extractors(ydl)[0]
    extractor.params['test'] = True

    # Create a test fragment downloader
    fd = HlsFD(ydl, extractor.params)

    # Test a non-encrypted fragment download
    test_url

# Generated at 2022-06-18 13:28:18.681720
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor import gen_extractors
    from .downloader import gen_ydl
    from .utils import sanitize_open

    ydl = gen_ydl(gen_extractors(), {'hls_use_mpegts': True})
    ydl.params.update({
        'noprogress': True,
        'quiet': True,
        'skip_download': True,
        'test': True,
    })

    # Test with a live stream

# Generated at 2022-06-18 13:28:28.531514
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    from .external import FFmpegFD
    from .fragment import FragmentFD
    from .dash import DashSegmentsFD

    # Test for HlsFD
    def test_HlsFD(url, expected_fragments, expected_fragment_index, expected_fragment_retries, expected_fragment_skip):
        ydl = YoutubeDL({'hls_use_mpegts': False})
        ie = YoutubeIE(ydl)
        info = ie.extract(url)
        info_dict = info['formats'][0]

# Generated at 2022-06-18 13:28:33.711187
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import match_filter_func

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'match_filter': match_filter_func(None),
            }

        def urlopen(self, url):
            return FakeUrlOpen(url)

    class FakeUrlOpen(object):
        def __init__(self, url):
            self.url = url

        def geturl(self):
            return self.url

        def read(self):
            return b''

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'Fake'
        _VALID_URL = r'https?://.+'


# Generated at 2022-06-18 13:28:44.113622
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.utils
    import youtube_dl.postprocessor.ffmpeg

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a youtube-dl object

# Generated at 2022-06-18 13:28:54.715655
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .common import FakeYDL
    ydl = FakeYDL()
    fd = HlsFD(ydl, {})

    # Test 1:
    #   - no unsupported features
    #   - no encryption
    #   - not live
    #   - no extra_param_to_segment_url
    #   - no _decryption_key_url
    #   - no is_live

# Generated at 2022-06-18 13:29:04.941706
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import ExtractorError
    from ..downloader import YoutubeDL
    from ..compat import compat_urllib_request
    from .test_fragment import FakeYDL
    from .test_downloader import FakeHttpServer
    from .test_downloader import MockServerRule
    from .test_downloader import MockServerThread
    from .test_downloader import MockServerRequestHandler
    from .test_downloader import MockServer
    from .test_downloader import MockServerProcess
    from .test_downloader import MockServerPortRange
    from .test_downloader import MockServerSocket
    from .test_downloader import MockServerSocketThread
    from .test_downloader import MockServerSocketProcess
    from .test_downloader import MockServerSocketPortRange

# Generated at 2022-06-18 13:29:14.210079
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    # Test with a live stream
    info_dict = {
        'id': 'test_id',
        'url': 'https://example.com/live.m3u8',
        'ext': 'mp4',
        'title': 'test_title',
        'is_live': True,
    }
    ydl = YoutubeDL(YoutubeIE._prepare_format_params(info_dict))
    fd = HlsFD(ydl, {'skip_download': True})