

# Generated at 2022-06-18 13:20:16.763892
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import ExtractorError

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'fake_id',
                'url': url,
                'extractor': 'generic',
                'extractor_key': 'Generic',
                'title': 'fake_title',
                'formats': [],
            }

    class FakeGenericIE(GenericIE):
        def _real_extract(self, url):
            return {
                'id': 'fake_id',
                'url': url,
                'title': 'fake_title',
                'formats': [],
            }

    ie = FakeInfoExtractor()
    ie.ie_key

# Generated at 2022-06-18 13:20:24.558017
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader.common import FileDownloader
    from ..extractor import YoutubeIE
    from ..utils import encode_data_uri
    from .external import FFmpegFD
    from .fragment import FragmentFD
    from .http import HttpFD
    from .dash import DashSegmentsFD
    from .ism import IsmFD
    from .m3u8 import M3u8FD
    from .rtmp import RtmpFD
    from .smoothstreams import SmoothstreamsFD
    from .subtitles import SubtitlesFD
    from .utils import DownloadContext


# Generated at 2022-06-18 13:20:37.118084
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    def _test_HlsFD_real_download(url, expected_frag_content):
        ydl = YoutubeDL({'hls_prefer_native': True})
        ie = YoutubeIE(ydl)
        info = ie.extract(url)
        fd = HlsFD(ydl, {'test': True})
        assert fd.real_download('', info)
        assert fd.fragment_content == expected_frag_content

    # Test unencrypted fragment

# Generated at 2022-06-18 13:20:45.445635
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..utils import FakeYDL

    class FakeIE(InfoExtractor):
        def __init__(self, manifest, info_dict):
            self.manifest = manifest
            self.info_dict = info_dict

    def test_can_download(manifest, info_dict, expected):
        ie = FakeIE(manifest, info_dict)
        ydl = FakeYDL()
        fd = HlsFD(ydl, {})
        assert fd.can_download(ie.manifest, ie.info_dict) == expected

    # Test cases

# Generated at 2022-06-18 13:20:54.327409
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import youtube_dl.extractor.common as common
    import youtube_dl.extractor.http as http
    import youtube_dl.utils as utils

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Download the test video
    ydl_opts = {
        'format': 'best',
        'outtmpl': os.path.join(temp_dir, '%(id)s.%(ext)s'),
        'quiet': True,
        'noplaylist': True,
        'nocheckcertificate': True,
        'simulate': True,
        'skip_download': True,
    }

# Generated at 2022-06-18 13:21:06.025319
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    ydl = gen_ydl(gen_extractors())

# Generated at 2022-06-18 13:21:19.442721
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .test_fragment import _test_frag_download
    from .test_external import _test_external_download
    from .test_http import _test_http_download

    def _test_hls_download(ie, manifest, info_dict, expected_frags, expected_warnings=None, expected_info=None, expected_skip=None, expected_retries=None):
        if expected_warnings is None:
            expected_warnings = []
        if expected_info is None:
            expected_info = {}
        if expected_skip is None:
            expected_skip = []
        if expected_retries is None:
            expected_retries = []
        info_dict['url'] = manifest
        info_

# Generated at 2022-06-18 13:21:32.045556
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    from .external import FFmpegFD
    from .fragment import FragmentFD
    from .dash import DashSegmentsFD
    from .http import HttpFD
    from .http import HttpQuietDownloader
    from .http import HttpFD
    from .http import HttpQuietDownloader
    from ..utils import (
        encodeFilename,
        sanitize_open,
    )
    from ..extractor import gen_extractors
    from ..compat import (
        compat_urllib_error,
        compat_urlparse,
        compat_struct_pack,
    )
    from ..utils import (
        parse_m3u8_attributes,
        update_url_query,
    )

# Generated at 2022-06-18 13:21:41.025759
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import json
    import youtube_dl.YoutubeDL
    from youtube_dl.utils import DownloadError

    def _test_HlsFD_real_download(manifest, info_dict, expected_filename, expected_error=None):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            f.close()

# Generated at 2022-06-18 13:21:50.206739
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .common import FakeYDL
    from .test_fragment import TestFragmentFD

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'ext': 'mp4',
                'is_live': False,
                'formats': [{
                    'url': url,
                    'ext': 'mp4',
                }],
            }

    ie = FakeInfoExtractor({})
    ie.add_info_extractor(HlsFD.ie_key())
    ie.add_info_extractor(TestFragmentFD.ie_key())

    ydl

# Generated at 2022-06-18 13:22:19.056584
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-18 13:22:23.934691
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import YoutubeDL
    ydl = YoutubeDL({})
    hlsfd = HlsFD(ydl, {'format': 'best'})
    assert hlsfd.params['format'] == 'best'
    assert hlsfd.ydl == ydl

# Generated at 2022-06-18 13:22:34.894537
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..utils import match_filter_func
    from .fragment import FragmentFD
    from .external import FFmpegFD

    # Test for constructor of class HlsFD
    def test_HlsFD_constructor(self):
        self.assertIsInstance(self.fd, HlsFD)

    # Test for constructor of class FragmentFD
    def test_FragmentFD_constructor(self):
        self.assertIsInstance(self.fd, FragmentFD)

    # Test for constructor of class FFmpegFD
    def test_FFmpegFD_constructor(self):
        self.assertIsInstance(self.fd, FFmpegFD)

    # Test for constructor of class HlsFD

# Generated at 2022-06-18 13:22:47.005762
# Unit test for constructor of class HlsFD

# Generated at 2022-06-18 13:22:58.943370
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeDL
    from ..utils import encode_data_uri
    from .common import FakeYDL
    from .test_fragment import _test_frag_download
    from .test_external import _test_external_download

    def _test_hls_download(ydl, info_dict, expected_fragments, expected_warnings, expected_additional_info):
        hls_fd = HlsFD(ydl, {})
        hls_fd.add_progress_hook(lambda *args: None)
        hls_fd.real_download(
            'test.mp4', info_dict)
        _test_frag_download(
            ydl, expected_fragments, expected_warnings, expected_additional_info)


# Generated at 2022-06-18 13:23:08.378757
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..utils import encode_data_uri

    # Test data

# Generated at 2022-06-18 13:23:20.839741
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    ydl = gen_ydl()
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(gen_extractors()[0])
    ydl.params['test'] = True
    ydl.params['noprogress'] = True
    ydl.params['quiet'] = True
    ydl.params['simulate'] = True
    ydl.params['format'] = 'bestvideo+bestaudio'
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ydl.params['writesubtitles'] = True


# Generated at 2022-06-18 13:23:31.060955
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    def _test_HlsFD(url, expected_result):
        class FakeYDL:
            def __init__(self):
                self.params = {
                    'test': True,
                    'noplaylist': True,
                    'match_filter': match_filter_func('best'),
                }
                self.extractors = gen_extractors()
                self.cache = None
                self.progress_hooks = []

            def urlopen(self, url):
                return compat_urllib_request.urlopen(url)

        ydl = FakeYDL()

# Generated at 2022-06-18 13:23:43.338372
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func

    def test_extractor(extractor_class):
        if not hasattr(extractor_class, '_WORKING'):
            return
        if not hasattr(extractor_class, '_TEST'):
            return
        if not extractor_class._TEST:
            return
        if not hasattr(extractor_class, '_VALID_URL'):
            return
        if not extractor_class._VALID_URL:
            return

        ydl = gen_ydl()
        ydl.add_default_info_extractors()
        ydl.params['noplaylist'] = True
        ydl.params['nocheckcertificate'] = True
       

# Generated at 2022-06-18 13:23:47.362568
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .utils import encode_data_uri

    class FakeYDL(object):
        def __init__(self, ie):
            self.ie = ie
            self.params = {
                'noprogress': True,
                'quiet': True,
                'test': True,
            }

        def to_screen(self, msg):
            pass

        def report_error(self, msg):
            raise Exception(msg)

        def urlopen(self, url):
            return compat_urllib_request.urlopen(url)


# Generated at 2022-06-18 13:24:33.844587
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import FakeYDL
    from .test_fragment import _test_frag_download
    from .test_external import _test_external_download

    def _test_real_download(ie, video_id, expected_fragments, expected_warnings=None):
        ydl = FakeYDL()
        ydl.add_info_extractor(ie)
        ie = ydl._ies[0]
        ie.set_downloader(ydl)
        info = ie._real_extract(video_id)

# Generated at 2022-06-18 13:24:46.315748
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ie = YoutubeIE(ydl)

    # Test with a single fragment

# Generated at 2022-06-18 13:24:54.989062
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    from .test_fragment import _download_fragment

    def _test_HlsFD_real_download(manifest, info_dict, expected_frag_content):
        with tempfile.NamedTemporaryFile(suffix='.mp4') as f:
            ydl = youtube_dl.YoutubeDL({'outtmpl': f.name, 'test': True})
            hlsfd = HlsFD(ydl, {})
            hlsfd.real_download(f.name, info_dict)
            f.seek(0)
            assert f.read() == expected_frag_content


# Generated at 2022-06-18 13:24:59.999162
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    ydl = YoutubeDL({'quiet': True})
    ydl.add_info_extractor(YoutubeIE())
    ydl.download(['https://www.youtube.com/watch?v=W0LHTWG-UmQ'])

# Generated at 2022-06-18 13:25:10.982751
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..utils import ExtractorError
    from ..compat import compat_str

    # Test with a non-live stream
    ie = YoutubeIE()
    info_dict = ie.extract('https://www.youtube.com/watch?v=BaW_jenozKc')
    assert HlsFD.can_download(info_dict['url'], info_dict)

    # Test with a live stream
    ie = YoutubeIE()
    info_dict = ie.extract('https://www.youtube.com/watch?v=BaW_jenozKc')
    assert not HlsFD.can_download(info_dict['url'], info_dict)

    # Test with a stream that has unsupported features
    ie = YoutubeIE()

# Generated at 2022-06-18 13:25:16.664652
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    from .external import FFmpegFD

    # Test that the method real_download of class HlsFD works correctly
    # for a simple hls video.
    def test_simple_hls_video():
        ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
        ydl.add_default_info_extractors()
        ydl.add_info_extractor(YoutubeIE.ie_key())
        ydl.params['noplaylist'] = True
        ydl.params['skip_download'] = True
        ydl.params['quiet'] = True
        ydl.params['test'] = True

# Generated at 2022-06-18 13:25:29.472946
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib_parse_unquote
    from ..compat import compat_urllib_parse_unquote_plus
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_urllib_parse_urljoin
    from ..compat import compat_urllib_parse_urlsplit
    from ..compat import compat_urllib_parse_urlunsplit
    from ..compat import compat_urllib_

# Generated at 2022-06-18 13:25:41.441911
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func

    ydl = gen_ydl()
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(gen_extractors()[0])

    def test_url(url, expected_result):
        info_dict = ydl.extract_info(url, download=False)
        assert HlsFD.can_download(info_dict['url'], info_dict) == expected_result

    test_url('https://example.com/master.m3u8', True)
    test_url('https://example.com/master.m3u8?foo=bar', True)

# Generated at 2022-06-18 13:25:51.264027
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('', {})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'_decryption_key_url': 'http://example.com/key'})
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'_decryption_key_url': 'http://example.com/key'}, True)
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'extra_param_to_segment_url': 'foo=bar'})

# Generated at 2022-06-18 13:26:01.620946
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import sys
    import tempfile
    import unittest
    from .test_downloader import MockYDL
    from .test_downloader import MockInfoDict
    from .test_downloader import MockFD
    from .test_downloader import MockHook
    from .test_downloader import MockProgressHook

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.ydl = MockYDL()
            self.ydl.params['noprogress'] = True
            self.ydl.params['quiet'] = True
            self.ydl.params['logger'] = MockHook()
            self.ydl.params['progress_hooks'] = [MockProgressHook()]
           

# Generated at 2022-06-18 13:27:34.458704
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import determine_ext
    from ..downloader.common import FileDownloader
    from ..compat import compat_urllib_request

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'ext': determine_ext(url),
                'title': 'test',
            }

    class FakeYDL(FileDownloader):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.result_queue = []

        def to_screen(self, s):
            pass

        def trouble(self, s, tb=None):
            self

# Generated at 2022-06-18 13:27:41.187623
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    ydl = gen_ydl(gen_extractors())
    ydl.params.update({
        'hls_prefer_native': True,
        'hls_use_mpegts': True,
        'hls_segment_format': 'mpegts',
    })

# Generated at 2022-06-18 13:27:48.951726
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import subprocess
    import unittest
    import youtube_dl.extractor.common as common
    import youtube_dl.extractor.http as http
    import youtube_dl.extractor.hls as hls

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file = os.path.join(self.temp_dir, 'temp_file')
            self.temp_file_fd = open(self.temp_file, 'wb')
            self.hls_fd = HlsFD(common.FileDownloader({'outtmpl': self.temp_file}), {})


# Generated at 2022-06-18 13:27:56.412477
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..extractor import YoutubeIE
    from ..utils import encode_data_uri
    from ..downloader import YoutubeDL
    from ..compat import compat_str

    ydl = YoutubeDL(YoutubeIE.ie_key())
    ydl.params['test'] = True
    ydl.params['noplaylist'] = True
    ydl.params['quiet'] = True
    ydl.params['skip_download'] = True
    ydl.params['format'] = 'bestvideo+bestaudio'
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ydl.params['writedescription'] = False
    ydl.params['writeinfojson'] = False
    ydl.params['writeannotations'] = False
    ydl

# Generated at 2022-06-18 13:28:09.254252
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import YoutubeDL
    from .extractor import get_info_extractor
    from .postprocessor import FFmpegMergerPP
    from .cache import Cache
    from .utils import encodeFilename


# Generated at 2022-06-18 13:28:19.915261
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..downloader.http import HttpFD
    from ..utils import encode_data_uri

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'test': True,
                'noprogress': True,
            }
            self.http_fd = HttpFD(self, self.params)

        def urlopen(self, url):
            return self.http_fd.urlopen(url)

    class FakeIE(InfoExtractor):
        def __init__(self, ydl):
            self.ydl = ydl

    ie = FakeIE(FakeYDL())
    hls_fd = HlsFD(ie, ie.ydl.params)

    # Test with a manifest that contains a single fragment

# Generated at 2022-06-18 13:28:27.991889
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str

    ydl = gen_ydl()
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_use_mpegts'] = True
    ydl.params['match_filter'] = match_filter_func('best')
    ydl.params['test'] = True
    ydl.params['quiet'] = True
    ydl.params['simulate'] = True
    ydl.params['skip_download'] = True
    ydl.params['noprogress'] = True
    ydl.params['logger'] = ydl
    ydl.params['progress_hooks'] = []
    ydl

# Generated at 2022-06-18 13:28:39.081071
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import YoutubeDL
    from ..extractor import YoutubeIE
    from ..utils import encodeFilename
    from .common import FakeYDL
    from .test_download import get_testcases

    def test_download(testcase):
        ydl = FakeYDL()
        ydl.params.update(testcase['params'])
        ydl.add_info_extractor(YoutubeIE.ie_key())
        ydl.add_default_info_extractors()
        ydl.download([testcase['url']])
        assert ydl.downloaded_info_dicts[0]['id'] == testcase['id']
        assert encodeFilename(ydl.downloaded_info_dicts[0]) == testcase['filename']


# Generated at 2022-06-18 13:28:49.820237
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..extractor import gen_extractors
    from ..utils import encode_data_uri

    # Test for https://github.com/ytdl-org/youtube-dl/issues/27660
    # The first fragment is truncated to a non-block size and should not be decrypted
    # The second fragment is not truncated and should be decrypted

# Generated at 2022-06-18 13:28:54.040565
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testdata_file
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .utils import encode_data_uri

    def _mock_urlopen(url):
        if url == 'http://manifest.url/manifest.m3u8':
            return get_testdata_file('hls/manifest.m3u8')
        elif url == 'http://manifest.url/decrypt.key':
            return get_testdata_file('hls/decrypt.key')
        elif url == 'http://manifest.url/fragment.ts':
            return get_testdata_file('hls/fragment.ts')