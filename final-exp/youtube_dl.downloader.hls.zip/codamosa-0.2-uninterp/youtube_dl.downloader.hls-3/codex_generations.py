

# Generated at 2022-06-18 13:20:08.086523
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE.ie_key())
    ydl.params['noplaylist'] = True
    ydl.params['quiet'] = True
    ydl.params['skip_download'] = True
    ydl.params['test'] = True
    ydl.params['simulate'] = True
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ydl.params['writedescription'] = True
    ydl.params['writeinfojson'] = True
    ydl.params['writeannotations'] = True

# Generated at 2022-06-18 13:20:19.669701
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import encode_data_uri

    def _test_HlsFD_real_download(ydl, url, expected_frag_content):
        info_dict = ydl.extract_info(url, download=False)
        assert info_dict['extractor'] == 'hlsnative'
        assert HlsFD.can_download(info_dict['url'], info_dict)

        ydl.params['test'] = True
        ydl.params['noprogress'] = True
        ydl.params['quiet'] = True
        ydl.params['skip_download'] = True
        ydl.params['format'] = 'bestvideo+bestaudio'

# Generated at 2022-06-18 13:20:32.171178
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..utils import prepare_filename
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_urllib_parse_unquote
    from ..compat import compat_urllib_parse_unquote_plus
    from ..compat import compat_urllib_parse_urljoin
    from ..compat import compat_urllib_parse_urlsplit
    from ..compat import compat_urllib_parse_urlunsplit

# Generated at 2022-06-18 13:20:42.733128
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .common import FakeYDL

    class FakeIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'url': url,
                'id': 'fake',
                'title': 'fake',
                'ext': 'mp4',
            }

    ie = FakeIE(FakeYDL())
    ie.add_info_extractor(HlsFD.ie_key())

    # Test AES-128 decryption

# Generated at 2022-06-18 13:20:53.189324
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import youtube_dl.extractor.common as common
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.hls import HlsFD

    def _test_HlsFD_real_download(url, expected_content):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            pass

# Generated at 2022-06-18 13:21:04.572017
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..compat import compat_str
    from ..utils import encode_data_uri

    def _test_HlsFD_real_download(url, expected_frag_content):
        ydl = YoutubeDL({'quiet': True})
        ydl.add_default_info_extractors()
        info_dict = ydl.extract_info(url, download=False)
        assert info_dict['_type'] == 'url'
        assert info_dict['url'] == url
        assert info_dict['ie_key'] == 'Youtube'
        assert info_dict['ext'] == 'mp4'
        assert info_dict['protocol'] == 'm3u8'
        assert info_dict['format_id'] == '135'

# Generated at 2022-06-18 13:21:18.059506
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import _download_webpage
    from ..compat import compat_urllib_request
    import os
    import tempfile
    import shutil
    import subprocess


# Generated at 2022-06-18 13:21:30.904176
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    from .test_fragment import TestFragmentFD
    from .test_external import TestFFmpegFD

    class TestIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'ext': 'mp4',
                'is_live': False,
            }

    class TestYDL(object):
        def __init__(self):
            self.params = {}
            self.cache = None

        def to_screen(self, msg):
            pass

        def report_warning(self, msg):
            pass


# Generated at 2022-06-18 13:21:40.309048
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import encode_data_uri

    # Test for issue #27660
    # https://github.com/ytdl-org/youtube-dl/issues/27660
    #
    # The test data is a truncated fragment from
    # https://www.youtube.com/watch?v=0Njn0GZpN7k
    #
    # The fragment is truncated to the first 16 bytes of the fragment.
    # The fragment is encrypted with AES-128-CBC.
    # The IV is the first 16 bytes of the fragment.
    # The key is the first 16 bytes of the file
    # https://r2---sn-nfpnnjvh-1gis.googlevideo.com/videoplayback?expire=1587755951&ei=0d1

# Generated at 2022-06-18 13:21:49.691529
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    from .external import ExternalFD
    from .utils import sanitize_open

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = os.path.join(temp_dir, 'temp_file')

    # Create a temporary manifest file
    temp_manifest = os.path.join(temp_dir, 'temp_manifest')

    # Create a temporary key file
    temp_key = os.path.join(temp_dir, 'temp_key')

    # Create a temporary output file
    temp_output = os.path.join(temp_dir, 'temp_output')

    # Create a temporary output file

# Generated at 2022-06-18 13:22:17.709165
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    def _test_HlsFD_real_download(url, expected_frag_content):
        ydl = YoutubeDL({'hls_prefer_native': True})
        ie = YoutubeIE(ydl)
        info_dict = ie.extract(url)
        info_dict['url'] = encode_data_uri(info_dict['url'], info_dict['url'])
        fd = HlsFD(ydl, {'test': True})
        assert fd.real_download('test.mp4', info_dict)
        assert fd.fragment_content == expected_frag_content


# Generated at 2022-06-18 13:22:22.240634
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..downloader import Downloader
    from ..downloader.common import FileDownloader
    from ..downloader.f4m import F4mFD
    from ..downloader.hls import HlsFD
    from ..downloader.external import ExternalFD
    from ..downloader.http import HttpFD
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.fragment import FragmentFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.ism import IsmFD
    from ..downloader.m3u8 import M3u8FD
    from ..downloader.f4m import F4mFD

# Generated at 2022-06-18 13:22:33.676104
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str

    ydl = gen_ydl()
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(gen_extractors()[0])
    ydl.params['test'] = True
    ydl.params['noplaylist'] = True
    ydl.params['match_filter'] = match_filter_func(
        'https://www.youtube.com/watch?v=a1Y73sPHKxw')
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ydl.params['hls_prefer_native'] = True

# Generated at 2022-06-18 13:22:45.084083
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import unittest
    from .test_downloader import MockYDL
    from .test_downloader import MockInfoDict
    from .test_downloader import MockFileDownloader

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.ydl = MockYDL()
            self.ydl.params['noprogress'] = True
            self.ydl.params['quiet'] = True
            self.ydl.params['test'] = True
            self.ydl.params['outtmpl'] = os.path.join(self.test_dir, '%(id)s.%(ext)s')

# Generated at 2022-06-18 13:22:57.170629
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testdata_files_dir
    from .extractor import gen_extractors
    from .downloader import gen_ydl
    from .utils import encodeFilename
    from .compat import compat_urllib_error

    def _test_HlsFD_real_download(ydl, url, expected_filename, expected_fragments):
        info_dict = ydl.extract_info(url, download=False)
        filename = encodeFilename(info_dict)
        assert filename == expected_filename
        assert HlsFD.can_download(info_dict['url'], info_dict)
        assert HlsFD(ydl, {}).real_download(filename, info_dict)
        with open(filename, 'rb') as f:
            content = f.read()
        assert content == expected_fr

# Generated at 2022-06-18 13:23:07.055472
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import unittest
    from .test_downloader import MockYDL
    from .test_downloader import MockInfoDict
    from .test_downloader import MockFileDownloader
    from .test_downloader import MockHttpDl
    from .test_downloader import MockHook

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.ydl = MockYDL()
            self.ydl.params['noprogress'] = True
            self.ydl.params['quiet'] = True
            self.ydl.params['outtmpl'] = os.path.join(self.temp_dir, '%(id)s.%(ext)s')
            self.yd

# Generated at 2022-06-18 13:23:19.614326
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    import os
    import tempfile

    def _test_download(url, expected_filesize):
        with tempfile.NamedTemporaryFile(suffix='.mp4') as f:
            ydl = YoutubeDL({'outtmpl': f.name})
            ydl.add_default_info_extractors()
            ydl.download([url])
            assert os.path.getsize(f.name) == expected_filesize

    _test_download('https://www.youtube.com/watch?v=nPt8bK2gbaU', 6291456)
    _test_download('https://www.youtube.com/watch?v=nPt8bK2gbaU&hl=en', 6291456)
   

# Generated at 2022-06-18 13:23:30.104233
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    def test_url(url, expected_result):
        class FakeYDL:
            def __init__(self):
                self.params = {}
            def add_info_extractor(self, ie):
                self.ie = ie
            def urlopen(self, url):
                return compat_urllib_request.urlopen(url)
        ydl = FakeYDL()
        gen_extractors(ydl)
        ie = ydl.ie
        ie.extract(url)
        assert ie.get_info_extractor(url) == expected_result

    test_url('http://example.com/test.m3u8', HlsFD)
   

# Generated at 2022-06-18 13:23:36.175106
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import random
    import string
    import hashlib
    import base64
    import binascii
    import struct
    import re
    import time
    import urllib.parse
    import urllib.request
    import urllib.error
    from io import BytesIO
    from collections import namedtuple
    from .external import FFmpegFD
    from .fragment import FragmentFD
    from .dash import DASHFD
    from .http import HttpFD
    from .http import HttpQuietDownloader
    from .http import HttpFD
    from .http import HttpQuietDownloader
    from .http import HttpFD
    from .http import HttpQuietDownloader

# Generated at 2022-06-18 13:23:47.634787
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    from youtube_dl.utils import DownloadError

    def _test_HlsFD_real_download(ydl, manifest, info_dict, expected_content):
        with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
            pass
        try:
            ydl.params['outtmpl'] = tmp_file.name
            ydl.params['test'] = True
            ydl.process_ie_result(info_dict, download=True)
            with open(tmp_file.name, 'rb') as tmp_file:
                content = tmp_file.read()
            assert content == expected_content
        except DownloadError as e:
            assert e.exc_info[1].code == expected_content
       

# Generated at 2022-06-18 13:24:34.312878
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urlparse

    def _test_HlsFD(url, expected_result):
        info_dict = {}
        for ie in gen_extractors():
            if match_filter_func(ie.IE_NAME)(url):
                info_dict = ie.extract(url)
                break
        assert info_dict, 'Could not extract info from URL %s' % url
        assert HlsFD.can_download(info_dict['url'], info_dict) == expected_result

    _test_HlsFD('https://www.youtube.com/watch?v=zYm9FU0F8_U', True)

# Generated at 2022-06-18 13:24:46.759711
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_urlparse
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    from ..extractor.generic import GenericIE
    from ..extractor.hls import HlsIE
    from ..extractor.http import HttpIE
    from ..extractor.dash import DashIE
    from ..extractor.rtmp import RTMPIE
    from ..extractor.m3u8 import M3U8IE
    from ..extractor.ism import IsmIE
    from ..extractor.mms import MmsIE
    from ..extractor.rtsp import RtspIE
    from ..extractor.bliptv import BlipTVIE

# Generated at 2022-06-18 13:24:55.179137
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_info_extractor(YoutubeIE())

# Generated at 2022-06-18 13:25:07.455521
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .utils import encode_data_uri

    # Test with a single fragment
    test_data = get_test_data()
    ie = InfoExtractor(FileDownloader())
    ie.params = {'noplaylist': True}
    ie.add_info_extractor(HlsFD())
    ie.add_info_extractor(FFmpegFD())
    ie.extract_info(
        'http://localhost:8080/hls/single_fragment.m3u8',
        downloader=FileDownloader(params={'test': True}))

    # Test with a multiple fragments
    test_data

# Generated at 2022-06-18 13:25:12.580473
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import tempfile
    from .downloader import YoutubeDL

    def _test_can_download(manifest, info_dict, expected_result):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            f.write(manifest.encode('utf-8'))
            f.close()
            ydl = YoutubeDL({'hls_prefer_native': True})
            ydl.add_default_info_extractors()
            info_dict['url'] = 'file://' + f.name
            result = HlsFD.can_download(manifest, info_dict)
            os.unlink(f.name)
            assert result == expected_result

    # Test for encrypted streams

# Generated at 2022-06-18 13:25:21.373803
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_HlsFD(ydl, url, expected_result):
        extractors = gen_extractors(ydl, match_filter_func(url))
        assert len(extractors) == 1
        assert isinstance(extractors[0], HlsFD) == expected_result

    # Test for non-HLS URL
    _test_HlsFD(None, 'http://example.com/', False)

    # Test for HLS URL
    _test_HlsFD(None, 'http://example.com/index.m3u8', True)

# Generated at 2022-06-18 13:25:34.615275
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import random
    import string
    import hashlib
    import base64
    import binascii
    import time
    import re
    import platform
    from .external import FFmpegFD
    from .fragment import FragmentFD
    from .dash import DASHFD
    from .http import HttpFD
    from .http import HttpQuietDownloader

# Generated at 2022-06-18 13:25:45.849069
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import encode_data_uri
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE.ie_key())
    ydl.process_ie_result(YoutubeIE()._real_extract(
        'https://www.youtube.com/watch?v=B3eAMGXFw1o'),
        download=False)
    info_dict = ydl.prepare_filename(ydl.extract_info(
        'https://www.youtube.com/watch?v=B3eAMGXFw1o',
        download=False))
   

# Generated at 2022-06-18 13:25:54.690414
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_str
    from .common import FakeYDL

    # Test with a simple m3u8 manifest
    info_dict = {
        'id': 'test_id',
        'url': 'http://example.com/manifest.m3u8',
        'ext': 'mp4',
        'title': 'test_title',
        'http_headers': {'User-Agent': 'test_user_agent'},
        'fragment_retries': 1,
        'skip_unavailable_fragments': False,
    }
    ie = InfoExtractor(ydl=FakeYDL(), downloader=None)

# Generated at 2022-06-18 13:26:03.712659
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import sys
    import unittest
    import tempfile
    import shutil
    import youtube_dl.utils
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_http_client
    from youtube_dl.compat import compat_struct_pack
    from youtube_dl.compat import compat_struct_unpack
    from youtube_dl.compat import compat_str
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_urllib_parse

# Generated at 2022-06-18 13:27:31.524420
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func

    ydl = gen_ydl()
    ydl.params['noplaylist'] = True
    ydl.params['nocheckcertificate'] = True
    ydl.params['quiet'] = True
    ydl.params['skip_download'] = True
    ydl.params['test'] = True
    ydl.params['fragment_retries'] = 0
    ydl.params['skip_unavailable_fragments'] = False
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_use_mpegts'] = True

# Generated at 2022-06-18 13:27:39.839372
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL(params={'noplaylist': True})
    ydl.add_default_info_extractors()
    ie = YoutubeIE(ydl)
    info = ie.extract('https://www.youtube.com/watch?v=0zM3nApSvMg')
    assert HlsFD.can_download(info['formats'][0]['manifest_url'], info)

    # Test AES-128 decryption
    info = ie.extract('https://www.youtube.com/watch?v=W7qWa52k-nE')
    assert HlsFD.can_download(info['formats'][0]['manifest_url'], info)

# Generated at 2022-06-18 13:27:47.655266
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import gen_extractors
    from ..utils import prepend_extractor
    from .common import FakeYDL

    class TestHlsFD(HlsFD):
        def _download_fragment(self, ctx, frag_url, info_dict, headers):
            return True, b'foobar'

    class TestHlsFDExtractor(object):
        IE_NAME = 'hls'

# Generated at 2022-06-18 13:27:55.672337
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    from ..utils import ExtractorError
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self, ie):
            self.ie = ie

# Generated at 2022-06-18 13:28:08.388332
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..utils import match_filter_func
    from ..compat import compat_str

    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    ie = YoutubeIE()
    info_dict = ie.extract(url)
    fd = HlsFD(FileDownloader({'format': 'bestvideo[protocol^=http_dash_segments]+bestaudio[protocol^=http_dash_segments]/best[protocol^=http_dash_segments]'}), {'test': True})
    fd.real_download(compat_str(info_dict['id']), info_dict)

# Generated at 2022-06-18 13:28:19.333994
# Unit test for constructor of class HlsFD

# Generated at 2022-06-18 13:28:30.177961
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .extractor import YoutubeIE
    from ..utils import ExtractorError
    from ..compat import compat_urlparse

    def _test_can_download(url, expected_result):
        ie = YoutubeIE(params={})
        ie.extract(url)
        assert ie.can_download_dash() == expected_result

    # Test for HLS streams
    _test_can_download('https://www.youtube.com/watch?v=8JNrz6rWYQQ', True)
    _test_can_download('https://www.youtube.com/watch?v=8JNrz6rWYQQ&hl=de', True)

# Generated at 2022-06-18 13:28:40.419806
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import determine_ext
    from .fragment import FragmentFD
    from .external import FFmpegFD
    from .dash import DashSegmentsFD
    from .ism import IsmFD
    from .m3u8 import M3U8FD
    from .f4m import F4mFD
    from .smoothstreams import SmoothStreamsFD
    from .hls import HlsFD
    from .http import HttpFD
    from .http import HttpQuietDownloader
    from .http import HttpFD
    from .http import HttpQuietDownloader
    from .http import HttpFD
    from .http import HttpQuietDownloader
    from .http import HttpFD
    from .http import Http

# Generated at 2022-06-18 13:28:51.701627
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .extractor.generic import GenericIE
    from .downloader.common import FileDownloader
    from .compat import compat_str
    from .utils import encode_data_uri

    def _test_HlsFD_real_download(ie, ie_name, expected_fragments, expected_fragment_urls, expected_fragment_contents, expected_fragment_content_types, expected_fragment_content_encodings, expected_fragment_content_lengths, expected_fragment_content_md5s):
        info_dict = ie.extract(ie_name)

# Generated at 2022-06-18 13:28:59.875030
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    from .common import FakeYDL

    class FakeIE(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeIE, self).__init__(*args, **kwargs)
            self._downloader = FakeYDL()

        def _real_initialize(self):
            pass

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'ext': 'mp4',
                'http_headers': {
                    'User-Agent': 'test',
                },
            }
