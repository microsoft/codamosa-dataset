

# Generated at 2022-06-18 13:20:06.291770
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_str
    from .utils import encode_data_uri

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
            self.to_screen = params.get('to_screen')
            self.to_stderr = params.get('to_stderr')

        def urlopen(self, url):
            return compat_urllib_request.urlopen(url)

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ydl):
            self.ydl = ydl


# Generated at 2022-06-18 13:20:18.479076
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .utils import encode_data_uri

    url = 'https://example.com/playlist.m3u8'

# Generated at 2022-06-18 13:20:25.508251
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    ydl = YoutubeDL({'quiet': True})
    ie = YoutubeIE(ydl)
    info_dict = ie._real_extract('https://www.youtube.com/watch?v=BaW_jenozKc')
    assert HlsFD.can_download(info_dict['url'], info_dict)
    assert HlsFD(ydl, {}).real_download(None, info_dict)

# Generated at 2022-06-18 13:20:37.416889
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..extractor.youtube import YoutubeIE
    from ..postprocessor import FFmpegMergerPP
    from ..postprocessor.common import PostProcessor
    from ..postprocessor.ffmpeg import FFmpegPostProcessor
    from ..postprocessor.ffmpegmetadata import FFmpegMetadataPP
    from ..postprocessor.execafterdownload import ExecAfterDownloadPP
    from ..postprocessor.xattrpp import XAttrMetadataPP
    from ..postprocessor.embedthumbnail import EmbedThumbnailPP
    from ..postprocessor.metadatafromtitle import MetadataFromTitlePP

# Generated at 2022-06-18 13:20:45.575789
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..downloader import YoutubeDL
    ydl = YoutubeDL({})
    fd = HlsFD(ydl, {})
    assert fd.FD_NAME == 'hlsnative'
    assert fd.can_download({}, {})
    assert not fd.can_download('#EXT-X-KEY:METHOD=AES-128', {})
    assert not fd.can_download('#EXT-X-BYTERANGE', {})
    assert not fd.can_download('#EXT-X-MEDIA-SEQUENCE:1', {'is_live': False})
    assert not fd.can_download('#EXT-X-PLAYLIST-TYPE:EVENT', {})
    assert not fd.can_download('#EXT-X-MAP:', {})

# Generated at 2022-06-18 13:20:54.853002
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .common import FakeYDL
    from .test_fragment import FakeFragmentFD
    from .test_external import TestFFmpegFD
    import os
    import tempfile
    import shutil
    import subprocess
    import sys


# Generated at 2022-06-18 13:21:06.480808
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri

    class TestHlsFD(HlsFD):
        def _download_fragment(self, ctx, frag_url, info_dict, headers):
            return True, encode_data_uri(frag_url)

    ie = InfoExtractor(None, {})
    ie._downloader = None
    ie.params = {
        'test': True,
        'skip_download': True,
        'format': 'best',
    }
    ie.add_info_extractor(TestHlsFD)

    # Test with a manifest that has a single fragment

# Generated at 2022-06-18 13:21:20.217573
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .common import FakeYDL
    from .test_fragment import _test_frag_download
    from .test_external import _test_external_download


# Generated at 2022-06-18 13:21:32.612899
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import youtube_dl.extractor.common as common
    from youtube_dl.utils import DownloadError

    def _test_HlsFD_real_download(manifest, expected_output_file, expected_error=None):
        with tempfile.NamedTemporaryFile(delete=False) as tf:
            pass
        output_file = tf.name

# Generated at 2022-06-18 13:21:41.042789
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import youtube_dl.utils
    import youtube_dl.extractor.common
    import youtube_dl.downloader.common
    import youtube_dl.downloader.hls
    import youtube_dl.downloader.http
    import youtube_dl.downloader.external
    import youtube_dl.postprocessor.ffmpeg

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    temp_file.close()

    # Create a fake ydl object
    ydl = youtube_dl.YoutubeDL({})
    ydl.params['nooverwrites'] = True
    y

# Generated at 2022-06-18 13:22:10.320994
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse
    from ..compat import compat_urlparse
    from ..compat import compat_struct_pack
    from ..compat import compat_struct_unpack
    from ..compat import compat_str
    from ..compat import compat_chr
    from ..compat import compat_ord
    from ..compat import compat_b64decode
    from ..compat import compat_b64encode
    from ..compat import compat_http_client
    from ..compat import compat_urllib_parse_urlparse
   

# Generated at 2022-06-18 13:22:23.595712
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import FakeYDL
    from .common import download_media
    from .test_fragment import _test_download_fragment
    from .test_external import _test_download_external

    class FakeIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'fake',
                'url': url,
                'title': 'fake',
            }

    ie = FakeIE(FakeYDL())
    ie.add_info_extractor(HlsFD.ie_key())

    # Test HlsFD with a non-encrypted stream

# Generated at 2022-06-18 13:22:34.646201
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.utils
    import youtube_dl.downloader.common

    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:22:46.678877
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .extractor.generic import GenericIE
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_error
    from .utils import encode_data_uri

    def _test_download(url, expected_content, expected_fragment_count=None, expected_fragment_retries=None):
        ie = InfoExtractor(FileDownloader())
        ie.add_info_extractor(GenericIE())
        info_dict = ie.extract(url)
        assert info_dict['_type'] == 'hls'
        assert info_dict['protocol'] == 'm3u8'
        assert info_dict['ext'] == 'mp4'
        assert info_dict['url']

# Generated at 2022-06-18 13:22:58.605364
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    from .common import FakeYDL

    # Test with a live stream
    ydl = YoutubeDL(YoutubeIE.ie_key())
    ydl.add_default_info_extractors()
    ydl.params['noplaylist'] = True
    ydl.params['quiet'] = True
    ydl.params['test'] = True
    ydl.params['hls_prefer_native'] = True
    ydl.params['skip_download'] = True
    ydl.params['simulate'] = True
    ydl.params['skip_unavailable_fragments'] = False
    ydl.params['fragment_retries'] = 0

# Generated at 2022-06-18 13:23:04.453582
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..downloader import YoutubeDL
    from ..postprocessor import FFmpegMergerPP

    url = 'https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8'
    urlh = compat_urllib_request.urlopen(url)
    s = urlh.read().decode('utf-8', 'ignore')
    info_dict = {'url': url, 'http_headers': {}}
    assert HlsFD.can_download(s, info_dict)


# Generated at 2022-06-18 13:23:15.949541
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encodeFilename
    import os
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a YoutubeDL object
    ydl_opts = {
        'format': 'bestvideo+bestaudio/best',
        'outtmpl': os.path.join(temp_dir, '%(id)s.%(ext)s'),
        'quiet': True,
        'noplaylist': True,
        'logger': YoutubeDL().logger,
        'progress_hooks': [],
    }
    ydl = YoutubeDL(ydl_opts)

    # Get the video id
    video_id = '7nFdg-gRqfE'

   

# Generated at 2022-06-18 13:23:27.285999
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..utils import encode_data_uri

    ie = InfoExtractor()
    ie.add_info_extractor(HlsFD.ie_key())
    ie.add_info_extractor(FFmpegFD.ie_key())
    ie.add_info_extractor(HlsFD.ie_key())
    ie.add_info_extractor(FFmpegFD.ie_key())
    ie.add_info_extractor(HlsFD.ie_key())
    ie.add_info_extractor(FFmpegFD.ie_key())
    ie.add_info_extractor(HlsFD.ie_key())
    ie.add_info_extractor(FFmpegFD.ie_key())
    ie.add

# Generated at 2022-06-18 13:23:34.862992
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_str
    from ..downloader import Downloader
    from ..postprocessor import FFmpegMergerPP
    from ..cache import Cache

    def _get_extractor(url):
        for ie in gen_extractors():
            if ie.suitable(url) and ie.IE_NAME != 'generic':
                return ie

    def _get_info_extractor(url):
        ie = _get_extractor(url)
        if ie is None:
            return
        return ie.ie_key()


# Generated at 2022-06-18 13:23:46.970126
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..utils import prepend_extension
    from ..compat import compat_tempfile
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_parse
    from ..compat import compat_urllib_error
    from ..compat import compat_http_client
    from ..compat import compat_urlparse
    from ..compat import compat_struct_pack
    from ..compat import compat_struct_unpack
    from ..compat import compat_struct_calcsize
    from ..compat import compat_os_path
    from ..compat import compat_str
    from ..compat import compat_chr
    from ..compat import compat_ord
    from ..compat import compat_ur

# Generated at 2022-06-18 13:24:32.213463
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_urlparse

    ydl = gen_ydl()
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(gen_extractors()[0])

    url = 'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8'
    info = ydl.extract_info(url, download=False)
    assert info['url'] == url
    assert info['ext'] == 'mp4'
    assert info['protocol'] == 'm3u8_native'
   

# Generated at 2022-06-18 13:24:44.128802
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..downloader.http import HttpFD
    from ..downloader.f4m import F4mFD
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.hls import HlsFD as HlsFD_old
    from ..downloader.external import ExternalFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.ism import IsmFD
    from ..downloader.fragment import FragmentFD
    from ..downloader.hls import HlsFD as HlsFD_new
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.f4m import F4mFD
    from ..downloader.http import HttpFD

# Generated at 2022-06-18 13:24:54.097303
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
            self.extractors = gen_extractors()
            self.filter_func = match_filter_func(params)

        def urlopen(self, url):
            return compat_urllib_request.urlopen(url)

    class FakeInfoDict(object):
        def __init__(self, url, http_headers):
            self.url = url
            self.http_headers = http_headers

    url = 'https://example.com/manifest.m3u8'
    http_headers = {'User-Agent': 'test'}
   

# Generated at 2022-06-18 13:25:06.596692
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import encode_data_uri
    from .common import FakeYDL

    ydl = FakeYDL()
    ydl.params['noprogress'] = True
    ydl.params['test'] = True
    ydl.params['skip_download'] = True
    ydl.params['quiet'] = True
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_use_mpegts'] = True
    ydl.params['fragment_retries'] = 0
    ydl.params['skip_unavailable_fragments'] = False

    # Test with a non-encrypted stream
    ie = YoutubeIE(ydl)

# Generated at 2022-06-18 13:25:15.068864
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import Downloader
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import gen_pp

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'noprogress': True,
                'quiet': True,
                'simulate': True,
                'skip_download': True,
                'format': 'best',
            }
            self.cache = None
            self.postprocessors = gen_pp(self)
            self.extractors = gen_extractors()
            self.IE_NAME = 'youtube'
            self.ie = InfoExtractor(self, 'youtube')
            self.downloader = Downloader(self)


# Generated at 2022-06-18 13:25:27.467630
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.utils
    import youtube_dl.postprocessor.ffmpeg
    import youtube_dl.postprocessor.common

    def _download_fragment(ctx, frag_url, info_dict, headers):
        return True, b'\x00' * (ctx['frag_size'] - 1)

    def _append_fragment(ctx, frag_content):
        ctx['frag_size'] = len(frag_content)

    def _finish_frag_download(ctx):
        assert ctx['frag_size'] == ctx['total_frags']

    def _prepare_and_start_frag_download(ctx):
        c

# Generated at 2022-06-18 13:25:39.092880
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..utils import ExtractorError
    from ..compat import compat_urllib_request
    from ..downloader import Downloader
    from ..postprocessor import FFmpegMergerPP
    from ..cache import Cache

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
            self.cache = Cache(params)
            self.downloader = Downloader(params)
            self.postprocessor = FFmpegMergerPP(params)

        def to_screen(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass

        def report_warning(self, *args, **kargs):
            pass

        def report_error(self, *args, **kargs):
            pass

       

# Generated at 2022-06-18 13:25:49.846604
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..compat import compat_str
    from ..utils import encode_data_uri

    # Test that HlsFD can be constructed with a manifest URL

# Generated at 2022-06-18 13:26:01.403696
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from .external import FFmpegFD
    from .fragment import FragmentFD
    from .dash import DashSegmentsFD
    from .hls import HlsFD


# Generated at 2022-06-18 13:26:09.717260
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader.common import FileDownloader
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'ext': 'mp4',
                'http_headers': {
                    'Range': 'bytes=0-%d' % (len(url) - 1),
                },
            }

    class FakeFileDownloader(FileDownloader):
        def __init__(self, ydl, params):
            super(FakeFileDownloader, self).__init__(ydl, params)
            self._test_result = None


# Generated at 2022-06-18 13:27:43.972069
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import FakeYDL
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse
    from ..compat import compat_http_client
    from ..compat import compat_struct_pack

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'ext': 'mp4',
                'is_live': False,
                'formats': [],
                'http_headers': {},
            }


# Generated at 2022-06-18 13:27:52.547769
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import match_filter_func
    from ..compat import compat_str


# Generated at 2022-06-18 13:28:04.158244
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .http import HttpFD
    from .external import ExternalFD
    from .fragment import FragmentFD
    import os
    import tempfile

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
            self.to_screen = lambda *args, **kargs: None
            self.report_error = lambda *args, **kargs: None
            self.report_warning = lambda *args, **kargs: None
            self.report_retry_fragment = lambda *args, **kargs: None
            self.report_skip_fragment = lambda *args, **kargs: None
            self.urlopen = lambda *args, **kargs: None


# Generated at 2022-06-18 13:28:16.513970
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import FakeYDL
    from .test_fragment import _test_frag_download
    from .test_external import _test_external_download

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'Fake'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'fake',
                'url': url,
                'title': 'fake',
                'ext': 'mp4',
            }

    class FakeGenericIE(GenericIE):
        IE_NAME = 'FakeGeneric'
        _VALID_URL = r'https?://.+'


# Generated at 2022-06-18 13:28:25.551131
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError
    from ..compat import compat_urllib_request
    from .http import HttpFD
    from .external import ExternalFD
    from .fragment import FragmentFD
    from .dash import DashSegmentsFD
    from .ism import IsmFD
    from .f4m import F4mFD
    from .m3u8 import M3u8FD
    from .rtmp import RtmpFD

    # Test HlsFD constructor
    #
    # This test case is designed to test the constructor of class HlsFD.
    # It will first create a HlsFD object with a fake manifest url.
    # Then it will check the attributes of the HlsFD object.
    #
    # The test fixture is a fake manifest url.
    # The

# Generated at 2022-06-18 13:28:38.792785
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import Downloader
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .postprocessor import FFmpegMergerPP
    from .utils import match_filter_func
    from .compat import compat_urllib_request
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_error
    from .compat import compat_urllib_response
    from .compat import compat_urllib_parse_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_unquote
    from .compat import compat_urllib_parse_unquote_plus
    from .compat import compat_urllib_parse_urljoin

# Generated at 2022-06-18 13:28:49.465892
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import ExtractorError
    from .m3u8 import M3u8IE
    from .fragment import FragmentFD
    from .external import FFmpegFD

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeInfoExtractor, self).__init__(*args, **kwargs)
            self._downloader = None

        def _real_extract(self, url):
            return {
                'id': 'fake_id',
                'url': url,
                'title': 'fake_title',
                'formats': [],
            }

    class FakeYoutubeDL(object):
        def __init__(self):
            self

# Generated at 2022-06-18 13:28:58.706626
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL(params={'hls_prefer_native': True})
    ydl.add_info_extractor(YoutubeIE())

# Generated at 2022-06-18 13:29:09.174422
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import encode_data_uri
    from .external import ExternalFD
    from .fragment import FragmentFD
    from .http import HttpFD
    from .dash import DashFD
    from .ism import IsmFD
    from .f4m import F4mFD
    from .m3u8 import M3u8FD
    from .rtmp import RtmpFD
    from .rtmpe import RtmpeFD
    from .rtmps import RtmpsFD
    from .rtmpt import RtmptFD
    from .rtmpte import RtmpteFD
    from .rtp import RtpFD
    from .rtsp import RtspFD
    from .scte35 import Scte35FD
    from .srt import SrtFD
    from .subtitles import SubtitlesFD

# Generated at 2022-06-18 13:29:20.137490
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testdata_file
    from .extractor import YoutubeIE
    from .downloader import YoutubeDL
    from .utils import encodeFilename
    import os

    ydl = YoutubeDL({'outtmpl': encodeFilename('%(id)s.%(ext)s')})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE.ie_key())