

# Generated at 2022-06-18 13:20:08.490691
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import FakeYDL
    from ..compat import compat_str

    class FakeIE(InfoExtractor):
        IE_NAME = 'fake'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'fake',
                'url': url,
                'title': 'fake',
                'formats': [{
                    'url': url,
                    'format_id': 'fake',
                    'ext': 'mp4',
                }],
            }

    class FakeGenericIE(GenericIE):
        IE_NAME = 'fake_generic'
        _VALID_URL = r'https?://.+'


# Generated at 2022-06-18 13:20:20.002323
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import ExtractorError
    from ..compat import compat_urllib_request
    from ..downloader.http import HttpFD
    from ..downloader.http.http_req_test import FakeHttpRequest
    from ..downloader.external import ExternalFD

    # Test HlsFD constructor
    # Test case 1: HlsFD can download the manifest
    # Test case 2: HlsFD cannot download the manifest, but ffmpeg can
    # Test case 3: HlsFD cannot download the manifest, and ffmpeg cannot either
    # Test case 4: HlsFD can download the manifest, but ffmpeg cannot
    # Test case 5: HlsFD can download the manifest, but ffmpeg can as well
    # Test case 6: HlsFD can download

# Generated at 2022-06-18 13:20:26.160343
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..downloader import Downloader
    from ..postprocessor import FFmpegMergerPP

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
            self.cache = {}

        def urlopen(self, url):
            if url in self.cache:
                return self.cache[url]
            else:
                return compat_urllib_request.urlopen(url)

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ydl, ie_name, ie_id, params):
            self.ydl = ydl
            self.ie_

# Generated at 2022-06-18 13:20:38.042564
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    from .external import ExternalFD
    from .fragment import FragmentFD
    from .dash import DashSegmentsFD

    ydl = YoutubeDL({})
    ydl.add_default_info_extractors()

    # Test for non-live stream
    ie = YoutubeIE(ydl)
    info_dict = ie.extract('https://www.youtube.com/watch?v=BaW_jenozKc')
    assert HlsFD.can_download(info_dict['url'], info_dict)
    assert not ExternalFD.can_download(info_dict['url'], info_dict)
    assert not FragmentFD.can_download(info_dict['url'], info_dict)


# Generated at 2022-06-18 13:20:49.535243
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    ydl = gen_ydl()
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(gen_extractors()[0])
    ydl.params['hls_use_mpegts'] = True
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_prefer_ffmpeg'] = False
    ydl.params['hls_segment_format'] = 'mpegts'
    ydl.params['hls_segment_size'] = 10485760
    ydl.params['hls_segment_skip_unavailable'] = True
    ydl.params['hls_segment_ignore_names'] = False

# Generated at 2022-06-18 13:20:56.912971
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .http import HttpFD
    from .dash import DashSegmentsFD
    from .fragment import FragmentFD
    from .external import FFmpegFD

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
            self.to_screen = lambda *args, **kargs: None
            self.report_warning = lambda *args, **kargs: None
            self.report_error = lambda *args, **kargs: None
            self.report_retry_fragment = lambda *args, **kargs: None
            self.report_skip_fragment = lambda *args, **kargs: None
            self.urlopen = lambda *args, **kargs: None



# Generated at 2022-06-18 13:21:09.540927
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError
    from .common import FakeYDL

    class FakeIE(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeIE, self).__init__(*args, **kwargs)
            self.test_result = None

        def _real_initialize(self):
            pass

        def _real_extract(self, url):
            return self.test_result

    ie = FakeIE()

# Generated at 2022-06-18 13:21:22.635852
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func

    ydl = gen_ydl()
    for ie in gen_extractors():
        if ie.IE_NAME == 'hlsnative':
            break

    ie.extract_info(ydl, 'https://www.youtube.com/watch?v=UxxajLWwzqY', download=False)
    assert ie._downloader.params.get('test', False)
    assert ie._downloader.params.get('noprogress', False)
    assert ie._downloader.params.get('quiet', False)
    assert ie._downloader.params.get('format', 'best') == 'best'

# Generated at 2022-06-18 13:21:34.710741
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    # Test with a non-encrypted stream
    ydl = YoutubeDL(YoutubeIE.ie_key())
    ydl.params['noprogress'] = True
    ydl.params['quiet'] = True
    ydl.params['test'] = True
    ydl.params['skip_download'] = True
    ydl.params['writeinfojson'] = False
    ydl.params['simulate'] = True
    ydl.params['fragment_retries'] = 0
    ydl.params['skip_unavailable_fragments'] = False
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_use_mpegts'] = False
    y

# Generated at 2022-06-18 13:21:42.325186
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import prepend_extension
    from ..compat import compat_urlparse
    from ..downloader import YoutubeDL
    from ..postprocessor import FFmpegMergerPP
    from ..cache import Cache
    import os
    import tempfile
    import shutil
    import random
    import string

    def _random_string(length):
        return ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(length))

    def _random_url():
        return 'http://%s.com/%s' % (_random_string(10), _random_string(10))


# Generated at 2022-06-18 13:22:15.551613
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\nhttp://example.com/1.ts\n#EXTINF:10,\nhttp://example.com/2.ts\n#EXTINF:10,\nhttp://example.com/3.ts\n#EXT-X-ENDLIST', {})

# Generated at 2022-06-18 13:22:28.642763
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .common import FakeYDL

    # Test that the method real_download of class HlsFD works correctly
    # with a non-encrypted stream
    ydl = FakeYDL()
    ie = InfoExtractor(ydl, {})
    ie.params['test'] = True
    ie.params['noplaylist'] = True
    ie.params['skip_download'] = True
    ie.params['format'] = 'bestvideo+bestaudio'
    ie.params['outtmpl'] = '%(id)s'
    ie.params['writesubtitles'] = True
    ie.params['writeautomaticsub'] = True
    ie.params['writeinfojson'] = True

# Generated at 2022-06-18 13:22:37.548339
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .common import FakeYDL

    class FakeIE(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeIE, self).__init__(*args, **kwargs)
            self._type = 'hls'

# Generated at 2022-06-18 13:22:49.566883
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .common import FakeYDL
    from .test_fragment import _test_download_fragment

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'ext': 'mp4',
                'is_live': False,
                'http_headers': {},
            }

    ie = FakeInfoExtractor({})
    ydl = FakeYDL()
    ydl.add_info_extractor(ie)
    ydl.params['hls_use_mpegts'] = True
    ydl.params['skip_download'] = True

# Generated at 2022-06-18 13:23:01.496901
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import encode_data_uri
    from ..downloader import Downloader
    from ..compat import compat_str
    from ..extractor.common import InfoExtractor
    from ..postprocessor import FFmpegMergerPP
    from ..postprocessor.ffmpeg import FFmpegPostProcessor
    from ..postprocessor.ffmpeg import FFmpegExtractAudioPP
    from ..postprocessor.ffmpeg import FFmpegMetadataPP
    from ..postprocessor.ffmpeg import FFmpegVideoConvertorPP
    from ..postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from ..postprocessor.ffmpeg import FFmpegFixupStretchedPP
    from ..postprocessor.ffmpeg import FFmpegFixupM3u8PP
    from ..postprocessor.ffmpeg import FFmpegFixupM4aPP

# Generated at 2022-06-18 13:23:09.982569
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    from .external import FFmpegFD

    def test_HlsFD_real_download_helper(url, expected_frag_content, expected_frag_count):
        ydl = YoutubeDL({
            'outtmpl': '%(id)s.%(ext)s',
            'skip_download': True,
            'quiet': True,
            'simulate': True,
            'test': True,
        })
        ie = YoutubeIE(ydl)
        info_dict = ie.extract(url)
        assert info_dict['ext'] == 'mp4'
        assert info_dict['format_id'] == '137+140'

# Generated at 2022-06-18 13:23:22.639261
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..utils import encode_data_uri
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    import os
    import tempfile
    import shutil
    import subprocess

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Download the test video

# Generated at 2022-06-18 13:23:27.805918
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import encode_data_uri
    from .common import FakeYDL

    ydl = FakeYDL()
    ydl.params['hls_prefer_native'] = True
    ydl.params['test'] = True
    ydl.params['skip_download'] = True
    ydl.params['quiet'] = True
    ydl.params['simulate'] = True
    ydl.params['skip_unavailable_fragments'] = False
    ydl.params['fragment_retries'] = 0
    ydl.params['noprogress'] = True
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ydl.add_info_extractor(YoutubeIE.ie_key())

    # Test a

# Generated at 2022-06-18 13:23:35.112856
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import DateRange


# Generated at 2022-06-18 13:23:47.071308
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import unittest

    from .external import ExternalFD
    from ..utils import (
        encodeFilename,
        prepend_extension,
    )

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.test_file_name = 'test.mp4'
            self.test_file_path = os.path.join(self.temp_dir, self.test_file_name)
            self.test_file_url = 'http://example.com/' + self.test_file_name
            self.test_file_size = 1024

# Generated at 2022-06-18 13:24:42.801088
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .common import FakeYDL

    # Test with a non-encrypted stream
    ie = InfoExtractor(FakeYDL(), {})
    ie.params['test'] = True
    ie.params['noplaylist'] = True
    ie.params['format'] = 'bestvideo+bestaudio'
    ie.params['outtmpl'] = '%(id)s.%(ext)s'
    ie.params['nopart'] = True
    ie.params['quiet'] = True
    ie.params['skip_download'] = True
    ie.params['logger'] = None
    ie.params['writedescription'] = False
    ie.params['writeinfojson'] = False
    ie.params['writeannotations'] = False

# Generated at 2022-06-18 13:24:53.360435
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError
    from .http import HttpFD
    from .m3u8 import M3u8FD
    from .dash import DashSegmentsFD

    # Test that HlsFD is not used for non-HLS manifests
    ie = InfoExtractor()
    ie.add_info_extractor(M3u8FD.ie_key())
    ie.add_info_extractor(DashSegmentsFD.ie_key())
    ie.add_info_extractor(HlsFD.ie_key())
    ie.add_info_extractor(HttpFD.ie_key())
    ie.add_info_extractor(FFmpegFD.ie_key())
    ie.add_info_extractor(FragmentFD.ie_key())

    # Test that

# Generated at 2022-06-18 13:25:05.730194
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.utils
    import youtube_dl.extractor.common
    import youtube_dl.downloader.hls
    import youtube_dl.downloader.fragment
    import youtube_dl.downloader.http

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a YoutubeDL object

# Generated at 2022-06-18 13:25:14.140136
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import unittest
    from .test_downloader import FakeYDL
    from .test_downloader import MockHttpServer
    from .test_downloader import MockServerHandler
    from .test_downloader import MockServerThread
    from .test_downloader import MockServerRequestHandler
    from .test_downloader import MockServerRequestHandlerWithContentRange
    from .test_downloader import MockServerRequestHandlerWithContentRangeAndContentLength
    from .test_downloader import MockServerRequestHandlerWithContentRangeAndContentLengthAndContentEncoding
    from .test_downloader import MockServerRequestHandlerWithContentRangeAndContentLengthAndTransferEncoding
    from .test_downloader import MockServerRequestHandlerWithContentRangeAndContentLengthAndContentEncodingAndTransferEncoding
    from .test_downloader import MockServerRequestHandlerWithContentRange

# Generated at 2022-06-18 13:25:26.064095
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import pytest
    from .test_downloads import (
        MockYDL,
        MockFD,
        MockUrlOpen,
        MockFile,
        MockInfoDict,
        MockProgressHook,
    )

# Generated at 2022-06-18 13:25:30.289855
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import parse_duration
    from ..compat import compat_str
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD
    from ..downloader.external import ExternalFD
    from ..downloader.f4m import F4mFD
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.hls import HlsFD as HlsFD_old
    from ..downloader.ism import IsmFD
    from ..downloader.fragment import FragmentFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.rtsp import RtspFD
    from ..downloader.generic import GenericFD
    from ..downloader.external import ExternalFD

# Generated at 2022-06-18 13:25:42.077890
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    from ..utils import encode_data_uri

    # Test for a non-encrypted stream
    ie = InfoExtractor(YoutubeIE.ie_key())
    ie.params = {'noplaylist': True}
    ie.add_info_extractor(YoutubeIE())
    info_dict = ie.extract('https://www.youtube.com/watch?v=BzMLA8YIgG0')
    info_dict['url'] = encode_data_uri(info_dict['url'])
    info_dict['fragment_base_url'] = encode_data_uri(info_dict['fragment_base_url'])
    info_dict['fragments'][0]['url'] = encode_data

# Generated at 2022-06-18 13:25:51.724535
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import ExtractorError
    from .common import FakeYDL
    from .test_fragment import FakeFragmentFD
    from .test_external import TestFFmpegFD

    class FakeHlsFD(HlsFD):
        def __init__(self, ydl, params):
            super(FakeHlsFD, self).__init__(ydl, params)
            self.frag_downloader = FakeFragmentFD(ydl, params)

    class FakeFFmpegFD(FFmpegFD):
        def __init__(self, ydl, params):
            super(FakeFFmpegFD, self).__init__(ydl, params)
            self.frag_downloader = TestFFmpegFD(ydl, params)


# Generated at 2022-06-18 13:26:01.781155
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..extractor.common import InfoExtractor
    from ..compat import compat_urllib_parse_urlparse

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'formats': [],
            }

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'test': True,
                'noplaylist': True,
                'match_filter': match_filter_func('all'),
            }

# Generated at 2022-06-18 13:26:10.330677
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import ExtractorError
    from ..compat import compat_urllib_request
    from .common import FakeYDL

    class FakeHlsFD(HlsFD):
        def _download_fragment(self, ctx, frag_url, info_dict, headers):
            if frag_url == 'http://example.com/fragment.ts':
                return True, b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-18 13:27:54.886778
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    from .test_utils import FakeYDL
    from .test_utils import FakeFileDownloader
    from .test_utils import FakeHttpServer

    def test_HlsFD_real_download_helper(manifest, expected_fragments, expected_fragment_index, expected_fragment_count, expected_ad_fragment_count, expected_fragment_retries, expected_skip_unavailable_fragments, expected_test, expected_extra_param_to_segment_url, expected_decryption_key_url, expected_is_live, expected_http_headers):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            filename = f.name

# Generated at 2022-06-18 13:28:07.123680
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..extractor import YoutubeIE

    # Test for a live stream

# Generated at 2022-06-18 13:28:18.542676
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\nhttp://example.com/1\n#EXTINF:10,\nhttp://example.com/2\n#EXTINF:10,\nhttp://example.com/3\n#EXT-X-ENDLIST', {})

# Generated at 2022-06-18 13:28:27.036602
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import unittest
    from .test_downloader import FakeYDL
    from .test_downloader import FakeHttpServer
    from .test_downloader import MockServerRule
    from .test_downloader import MockServerThread

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.ydl = FakeYDL()
            self.ydl.params['noprogress'] = True
            self.ydl.params['quiet'] = True
            self.ydl.params['outtmpl'] = os.path.join(self.test_dir, '%(id)s.%(ext)s')
            self.ydl.params['test'] = True
           

# Generated at 2022-06-18 13:28:31.398883
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.utils

    def _test_HlsFD_real_download(manifest, expected_output):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            pass

# Generated at 2022-06-18 13:28:36.430609
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .common import FakeYDL
    from .test_fragment import TestFragmentFD
    from .test_external import TestFFmpegFD

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'fake',
                'url': url,
                'title': 'fake',
                'ext': 'mp4',
                'http_headers': {
                    'User-Agent': 'Fake',
                },
                'is_live': False,
            }

    class FakeHlsFD(HlsFD):
        def _download_fragment(self, ctx, frag_url, info_dict, headers):
            return True, b'\x00'

# Generated at 2022-06-18 13:28:41.765001
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_str
    from .common import FakeYDL
    from .test_fragment import _test_frag_download
    from .test_external import _test_external_download

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'ext': 'mp4',
                'http_headers': {
                    'User-Agent': 'test',
                },
                'is_live': False,
            }

    class FakeYDL(FakeYDL):
        def __init__(self, params):
            super(FakeYDL, self).__

# Generated at 2022-06-18 13:28:52.664503
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..utils import fake_http_response_with_headers

    class FakeIE(InfoExtractor):
        def _real_extract(self, url):
            return {'url': url}

    ie = FakeIE()
    ie.add_info_extractor(HlsFD.ie_key())

    # Test for a non-encrypted stream

# Generated at 2022-06-18 13:29:00.456975
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from .fragment import FragmentFD
    from .external import FFmpegFD
    from .dash import DashSegmentsFD

    ydl = gen_ydl()
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_use_mpegts'] = True
    ydl.params['hls_segment_skip_live_gap'] = False
    ydl.params['hls_live_restart'] = False
    ydl.params['hls_live_edge'] = 0
    ydl.params['hls_live_start_index'] = -1
    ydl.params['hls_live_start_offset'] = 0


# Generated at 2022-06-18 13:29:10.353451
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .common import FakeYDL
    from .test_fragment import TestFragmentFD
    from .test_external import TestFFmpegFD

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'ext': 'mp4',
                'http_headers': {
                    'User-Agent': 'test',
                },
            }

    class TestHlsFD(TestFragmentFD, TestFFmpegFD):
        def __init__(self, *args, **kwargs):
            super(TestHlsFD, self).__init__(*args, **kwargs)
           