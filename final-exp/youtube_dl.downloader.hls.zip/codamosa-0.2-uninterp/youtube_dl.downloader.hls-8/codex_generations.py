

# Generated at 2022-06-18 13:19:58.386431
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data

    def _test_HlsFD_real_download(manifest, expected_fragments):
        from ..extractor import YoutubeDL
        from ..utils import encode_data_uri

        ydl = YoutubeDL({
            'skip_download': True,
            'quiet': True,
            'test': True,
        })
        info_dict = {
            'url': encode_data_uri(manifest, 'text/plain'),
            'http_headers': {
                'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20100101 Firefox/10.0 (Chrome)',
            },
        }
        fd = HlsFD(ydl, {})

# Generated at 2022-06-18 13:20:10.006954
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    import os
    import tempfile
    import shutil
    import subprocess

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file for the manifest
    manifest_file = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-18 13:20:21.067292
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .common import FakeYDL

    class FakeIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'ext': 'mp4',
                'http_headers': {
                    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20100101 Firefox/10.0 (Chrome)',
                    'Referer': 'https://www.youtube.com/watch?v=BaW_jenozKc',
                },
            }


# Generated at 2022-06-18 13:20:34.149181
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import fake_urlopen

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'formats': [],
            }

    class FakeGenericIE(GenericIE):
        IE_NAME = 'test'
        _VALID_URL = r'https?://.*'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'formats': [],
            }

    ie = FakeInfoExtractor()

# Generated at 2022-06-18 13:20:43.764898
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..downloader import Downloader
    from ..postprocessor import FFmpegMergerPP
    from ..postprocessor.ffmpeg import FFmpegPostProcessor
    from ..postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from ..postprocessor.ffmpeg import FFmpegMetadataPP
    from ..postprocessor.ffmpeg import FFmpegExtractAudioPP
    from ..postprocessor.ffmpeg import FFmpegVideoConvertorPP
    from ..postprocessor.ffmpeg import FFmpegFixupStretchedPP
    from ..postprocessor.ffmpeg import FFmpegFixupM3u8PP
    from ..postprocessor.ffmpeg import FFmpegFixupM

# Generated at 2022-06-18 13:20:53.876730
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    from .external import FFmpegFD
    import os
    import shutil
    import tempfile
    import unittest

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test.mp4')
            self.test_file_size = 0
            self.test_file_sha256 = ''
            self.test_file_sha256_ad = ''
            self.test_file_sha256_ad_frag = ''
            self.test_file_sha256_ad_frag_decrypted = ''

# Generated at 2022-06-18 13:21:05.431827
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    from .test_utils import FakeYDL, FakeInfoDict
    from .test_utils import FakeFD

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = os.path.join(temp_dir, 'temp_file')
    with open(temp_file, 'w') as f:
        f.write('test')

    # Create a temporary file
    temp_file2 = os.path.join(temp_dir, 'temp_file2')
    with open(temp_file2, 'w') as f:
        f.write('test')

    # Create a temporary file
    temp_file3 = os.path.join(temp_dir, 'temp_file3')

# Generated at 2022-06-18 13:21:18.865135
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'quiet': True})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE.ie_key())

    # Test with a non-encrypted stream
    info = ydl.extract_info(
        'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8',
        download=False)
    assert HlsFD.can_download(info['url'], info)
    assert HlsFD(ydl, {}).real_download(
        'test.mp4', info)

   

# Generated at 2022-06-18 13:21:31.680210
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..utils import prepare_filename
    from ..compat import compat_urllib_request
    from ..cache import Cache

    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    ie = YoutubeIE(FileDownloader())
    info = ie.extract(url)

# Generated at 2022-06-18 13:21:40.852276
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import youtube_dl.extractor.common as common
    from youtube_dl.utils import DownloadError
    from youtube_dl.YoutubeDL import YoutubeDL
    from .test_utils import FakeYDL

    def _test_HlsFD_real_download(ydl, manifest, expected_output, expected_error=None):
        """
        Test HlsFD.real_download with the given manifest and expected output.
        """
        # Create a temporary directory
        tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:22:05.889695
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import ExtractorError
    from .common import FakeYDL
    from .test_fragment import _test_frag_download
    from .test_external import _test_external_download

    def _test_HlsFD_real_download(ie, info_dict, expected_fragments, expected_warnings=None, expected_infos=None, expected_errors=None, expected_fragment_index=None):
        with FakeYDL(params={'skip_download': True}) as ydl:
            ydl.add_info_extractor(ie)
            ydl.add_default_info_extractors()
            ydl.params.update(info_dict)

# Generated at 2022-06-18 13:22:17.572628
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    ydl = gen_ydl(gen_extractors())
    hlsfd = HlsFD(ydl, {'hls_use_mpegts': True})
    assert hlsfd.params['hls_use_mpegts'] == True
    assert hlsfd.params['fragment_retries'] == 0
    assert hlsfd.params['skip_unavailable_fragments'] == True
    assert hlsfd.params['test'] == False
    assert hlsfd.params['keep_fragments'] == False
    assert hlsfd.params['fragment_retries'] == 0
    assert hlsfd.params['skip_unavailable_fragments'] == True
    assert hlsfd.params['test']

# Generated at 2022-06-18 13:22:30.477296
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    from .external import FFmpegFD

    def _test_HlsFD_real_download(ydl, ie, url, expected_frag_content):
        info_dict = ie._real_extract(url)
        assert HlsFD.can_download(info_dict['url'], info_dict)
        assert not FFmpegFD.can_download(info_dict['url'], info_dict)
        ydl.params['test'] = True
        ydl.params['outtmpl'] = encode_data_uri(info_dict['ext'], expected_frag_content)
        assert HlsFD(ydl, ydl.params).real_download(None, info_dict)

    ydl = Youtube

# Generated at 2022-06-18 13:22:38.445779
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import unittest
    from .test_downloader import MockYDL
    from .test_downloader import MockFileDownloader
    from .test_downloader import MockInfoExtractor

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.ydl = MockYDL()
            self.fd = HlsFD(self.ydl, {'test': True})
            self.fd.add_progress_hook(self.ydl.hooks['progress'])
            self.fd.add_finished_hook(self.ydl.hooks['finished'])
            self.fd.add_error_hook(self.ydl.hooks['error'])

# Generated at 2022-06-18 13:22:50.603911
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'test': True,
                'skip_download': True,
                'quiet': True,
            }
            self.cache = {}

        def urlopen(self, url):
            if url in self.cache:
                return self.cache[url]
            raise ExtractorError('FakeYDL cannot open %s' % url)

        def to_screen(self, msg):
            pass

        def report_warning(self, msg):
            pass

        def report_error(self, msg):
            pass


# Generated at 2022-06-18 13:23:02.180305
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import unittest
    from .test_utils import FakeYDL
    from .test_utils import FakeHttpServer
    from .test_utils import FakeServerHandler
    from .test_utils import MockServerProcess
    from .test_utils import MockServerThread
    from .test_utils import MockServerProcessHandler
    from .test_utils import MockServerThreadHandler
    from .test_utils import MockServerProcessHandlerWithError
    from .test_utils import MockServerThreadHandlerWithError
    from .test_utils import MockServerProcessHandlerWithErrorAndRetry
    from .test_utils import MockServerThreadHandlerWithErrorAndRetry
    from .test_utils import MockServerProcessHandlerWithErrorAndSkip
    from .test_utils import MockServerThreadHandlerWithErrorAndSkip

# Generated at 2022-06-18 13:23:10.401301
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    from ..downloader import Downloader
    from ..postprocessor import FFmpegMergerPP
    from ..extractor.youtube import YoutubeIE
    from ..extractor.generic import GenericIE
    from ..extractor.hls import HlsIE
    from ..extractor.http import HTTPIE
    from ..extractor.rtmp import RTMPIE
    from ..extractor.smotri import SmotriIE
    from ..extractor.vimeo import VimeoIE
    from ..extractor.vk import VKIE
    from ..extractor.vlive import VLiveIE
    from ..extractor.vrt import VRTIE
    from ..extractor.xhamster import XHamsterIE
   

# Generated at 2022-06-18 13:23:23.260551
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func

    ydl = gen_ydl(params={'noplaylist': True})
    ydl.add_info_extractor(gen_extractors()[0])
    ydl.add_info_extractor(gen_extractors()[1])
    ydl.add_info_extractor(gen_extractors()[2])
    ydl.add_info_extractor(gen_extractors()[3])
    ydl.add_info_extractor(gen_extractors()[4])
    ydl.add_info_extractor(gen_extractors()[5])

# Generated at 2022-06-18 13:23:32.573496
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    def _test_HlsFD(url, expected_result, expected_warning=None):
        class FakeYDL:
            def __init__(self):
                self.params = {
                    'test': True,
                    'noprogress': True,
                }

            def urlopen(self, url):
                return compat_urllib_request.urlopen(url)

        ydl = FakeYDL()
        for ie in gen_extractors():
            if match_filter_func(ie.IE_NAME)(url):
                ie = ie.ie
                break
        else:
            assert False, 'Unsupported URL: %s' % url

# Generated at 2022-06-18 13:23:45.441297
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import FakeYDL
    from ..compat import compat_urllib_request
    import os
    import tempfile
    import shutil

    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'https?://(?:www\.)?test\.com/video\.mp4'


# Generated at 2022-06-18 13:24:35.907606
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'simulate': True})
    ydl.add_info_extractor(YoutubeIE())
    ydl.params['noplaylist'] = True

    # Test with a single fragment

# Generated at 2022-06-18 13:24:48.255598
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..utils import encode_data_uri

    # Test with a non-encrypted HLS stream
    ie = InfoExtractor(FileDownloader())
    ie.add_info_extractor(HlsFD)
    ie.extract('https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8')

    # Test with an encrypted HLS stream
    ie = InfoExtractor(FileDownloader())
    ie.add_info_extractor(HlsFD)

# Generated at 2022-06-18 13:24:58.495522
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..utils import match_filter_func
    from ..compat import compat_urlparse

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'ext': 'mp4',
                'is_live': False,
            }

    class FakeFileDownloader(FileDownloader):
        def __init__(self, ydl, params):
            super(FakeFileDownloader, self).__init__(ydl, params)
            self.test_result = None

        def to_screen(self, s, skip_eol=False):
            pass


# Generated at 2022-06-18 13:25:09.837139
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    from .http import HttpFD
    from .external import ExternalFD
    from .fragment import FragmentFD
    from .dash import DashSegmentsFD
    from .hls import HlsFD
    from .http import HttpFD
    from .external import ExternalFD
    from .fragment import FragmentFD
    from .dash import DashSegmentsFD
    from .hls import HlsFD
    from .http import HttpFD
    from .external import ExternalFD
    from .fragment import FragmentFD
    from .dash import DashSegmentsFD
    from .hls import HlsFD
    from .http import HttpFD
    from .external import ExternalFD
   

# Generated at 2022-06-18 13:25:18.044879
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import unittest

    from .external import ExternalFD

# Generated at 2022-06-18 13:25:30.893626
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import prepend_extension
    from ..downloader import YoutubeDL
    from ..compat import compat_urlparse
    import os
    import shutil
    import tempfile
    import unittest

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.temp_dir, 'test.mp4')
            self.test_file_partial = prepend_extension(self.test_file, 'partial')
            self.test_file_partial_2 = prepend_extension(self.test_file, 'partial.2')

# Generated at 2022-06-18 13:25:42.667036
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urlparse
    from ..downloader import YoutubeDL
    from ..postprocessor import FFmpegMergerPP
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..extractor.youtube import YoutubeIE
    from ..extractor.youtube_dl import YoutubeDLIE
    from ..extractor.soundcloud import SoundcloudIE
    from ..extractor.vimeo import VimeoIE
    from ..extractor.bandcamp import BandcampIE
    from ..extractor.twitch import TwitchIE
    from ..extractor.mixcloud import MixcloudIE
    from ..extractor.dailymotion import DailymotionIE
    from ..extractor.facebook import FacebookIE

# Generated at 2022-06-18 13:25:52.120544
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors
    from ..downloader.common import FileDownloader
    from ..compat import compat_urllib_request
    from ..utils import encode_data_uri

    def _test_HlsFD_can_download(url, expected_result):
        ydl = FileDownloader({})
        info_dict = {}
        for ie in gen_extractors():
            if ie.suitable(url) and ie.IE_NAME != 'generic':
                ie.extract(ydl, url)
                info_dict = ydl.result['info_dict']
                break
        assert info_dict
        assert HlsFD.can_download(
            compat_urllib_request.urlopen(url).read().decode('utf-8'), info_dict) == expected_result

    # Test

# Generated at 2022-06-18 13:26:02.198996
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    from .test_utils import FakeYDL
    from .test_utils import FakeHttpServer
    from .test_utils import MockServerRule
    from .test_utils import MockServerTestCase

    class TestHlsFD(MockServerTestCase):
        def setUp(self):
            super(TestHlsFD, self).setUp()
            self.ydl = FakeYDL()
            self.ydl.params['hls_use_mpegts'] = False
            self.ydl.params['test'] = True
            self.ydl.params['outtmpl'] = os.path.join(tempfile.gettempdir(), '%(id)s.%(ext)s')
            self.ydl.params['quiet'] = True
            self.ydl.params['simulate'] = True

# Generated at 2022-06-18 13:26:10.763187
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.postprocessor.ffmpeg
    import youtube_dl.utils
    import youtube_dl.downloader.fragment

    def _download_fragment(ctx, frag_url, info_dict, headers):
        """
        Mock _download_fragment method of FragmentFD
        """
        assert frag_url == 'http://localhost/fragment.ts'
        assert info_dict['http_headers'] == {'Range': 'bytes=0-1023'}
        assert headers == {'Range': 'bytes=0-1023'}
        return True, b'\x00' * 1024


# Generated at 2022-06-18 13:27:46.401425
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    def _test_HlsFD_can_download(url, expected_result):
        extractors = gen_extractors()
        extractor = match_filter_func(extractors, lambda e: e.suitable(url))[0]
        info_dict = extractor.extract(url)
        assert HlsFD.can_download(info_dict['url'], info_dict) == expected_result

    _test_HlsFD_can_download('https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8', True)

# Generated at 2022-06-18 13:27:54.726541
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    def _test_HlsFD(url):
        extractors = gen_extractors()
        for ie in extractors:
            if match_filter_func(ie)(url):
                ie = ie.ie
                break
        else:
            raise Exception('No extractor found for url: %s' % url)
        ie = ie(url)
        ie.extract()
        info_dict = ie.result
        fd = HlsFD(ie, {})
        fd.real_download(info_dict['id'] + '.mp4', info_dict)


# Generated at 2022-06-18 13:28:06.905702
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    from .external import ExternalFD
    from .utils import sanitize_open
    from .fragment import FragmentFD
    from .http import HttpFD
    from .dash import DashSegmentsFD
    from .ism import IsmFD
    from .f4m import F4mFD
    from .m3u8 import M3U8FD
    from .smoothstreams import SmoothStreamsFD
    from .rtmp import RtmpFD
    from .rtsp import RtspFD
    from .generic import GenericFD
    from .hls import HlsFD as HlsFD_ffmpeg
    from .dash import DashFD as DashFD_ffmpeg
    from .external import FFmpegFD

# Generated at 2022-06-18 13:28:18.366032
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    from .external import ExternalFD
    from ..utils import (
        encodeFilename,
        prepend_extension,
    )

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp(prefix='youtube-dl-test-hls-')

    # Create a dummy manifest
    manifest = os.path.join(temp_dir, 'manifest.m3u8')

# Generated at 2022-06-18 13:28:25.761070
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    from .test_fragment import _test_frag_download
    from .test_external import _test_external_download

    def _test_HlsFD_real_download(test_data, expected_data):
        with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
            tmp_file.close()

# Generated at 2022-06-18 13:28:38.998631
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..compat import compat_urllib_request
    from ..utils import encode_data_uri

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'test': True,
                'skip_download': True,
            }


# Generated at 2022-06-18 13:28:49.718586
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import ExtractorError
    from .common import FakeYDL

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'formats': [{
                    'url': 'http://example.com/test.m3u8',
                    'format_id': 'hls',
                    'ext': 'mp4',
                }],
            }

    class FakeGenericIE(GenericIE):
        IE_NAME = 'test'
        _VALID_URL = r

# Generated at 2022-06-18 13:28:58.850838
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import youtube_dl.extractor.common as common
    from youtube_dl.utils import DownloadError
    from youtube_dl.downloader.external import FFmpegFD
    from youtube_dl.downloader.fragment import FragmentFD
    from youtube_dl.downloader.hls import HlsFD
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.downloader.http.http import HEADRequest
    from youtube_dl.downloader.http.http import HEADResponse
    from youtube_dl.downloader.http.http import HTTPDownloader
    from youtube_dl.downloader.http.http import HTTPDownloadHandler
    from youtube_dl.downloader.http.http import HTTPDownloadRequest

# Generated at 2022-06-18 13:29:09.332287
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    from youtube_dl.extractor.http import HlsFD
    from youtube_dl.utils import sanitize_open

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a youtube_dl object
    ydl_opts = {
        'outtmpl': os.path.join(temp_dir, '%(id)s-%(format_id)s-%(resolution)s.%(ext)s'),
        'format': 'bestvideo[height<=480]+bestaudio/best',
        'quiet': True,
        'simulate': True,
        'skip_download': True,
    }
    ydl = youtube_dl.YoutubeDL(ydl_opts)

# Generated at 2022-06-18 13:29:20.588828
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import FakeYDL
    from ..extractor import get_info_extractor
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_parse
    from ..compat import compat_urllib_error
    from ..compat import compat_http_client
    from ..compat import compat_struct_pack
    from ..compat import compat_struct_unpack
    from ..compat import compat_chr
    from ..compat import compat_ord
    from ..compat import compat_str
    from ..compat import compat_urlparse
    from ..compat import compat_parse_qs
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_ur