

# Generated at 2022-06-18 13:20:02.382982
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'username': 'user',
                'password': 'pass',
                'http_chunk_size': 1,
                'fragment_retries': 0,
                'skip_unavailable_fragments': True,
            }
            self.cache = None
            self.extractor = InfoExtractor()

        def to_screen(self, *args, **kargs):
            pass

        def to_stdout(self, *args, **kargs):
            pass

        def trouble(self, *args, **kargs):
            pass


# Generated at 2022-06-18 13:20:14.589582
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..utils import encode_data_uri
    from ..extractor import YoutubeIE

    # Test that the method real_download of class HlsFD can download the first fragment of a
    # media playlist.
    def test_download_first_fragment(self, manifest, info_dict):
        # Create a HlsFD object
        hls_fd = HlsFD(self.ydl, self.params)
        # Set the manifest of the HlsFD object
        hls_fd.manifest = manifest
        # Set the info_dict of the HlsFD object
        hls_fd.info_dict = info_dict
        # Set the test flag of the HlsFD object
        hls_fd.test = True
        # Call the method real_download of the HlsFD object
       

# Generated at 2022-06-18 13:20:23.584883
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'test': True,
                'skip_download': True,
            }

        def to_screen(self, msg):
            pass

        def trouble(self, msg=None, tb=None):
            pass

        def report_error(self, msg, tb=None, expected=False):
            pass

        def report_warning(self, msg):
            pass

        def urlopen(self, url):
            return compat_urllib_request.urlopen(url)

    class FakeIE(InfoExtractor):
        def __init__(self, ydl):
            self.ydl = ydl


# Generated at 2022-06-18 13:20:36.914972
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError
    from ..downloader.http import HttpFD
    from ..downloader.http.http_req_test import FakeYDL
    from ..compat import compat_urllib_error

    class FakeIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'is_live': False,
            }

    class FakeHttpFD(HttpFD):
        def real_download(self, filename, info_dict):
            return True

    class FakeHlsFD(HlsFD):
        def _download_fragment(self, ctx, frag_url, info_dict, headers):
            return True, b''

# Generated at 2022-06-18 13:20:45.313563
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
            self.to_screen = lambda *args, **kwargs: None
            self.report_warning = lambda *args, **kwargs: None
            self.report_error = lambda *args, **kwargs: None
            self.report_retry_fragment = lambda *args, **kwargs: None
            self.report_skip_fragment = lambda *args, **kwargs: None
            self.urlopen = lambda *args, **kwargs: None

    class FakeIE(InfoExtractor):
        def __init__(self, params):
            self.params = params

# Generated at 2022-06-18 13:20:54.104863
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import match_filter_func
    from ..compat import compat_str

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'match_filter': match_filter_func('all'),
                'test': True,
            }


# Generated at 2022-06-18 13:21:05.708793
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import random
    import string
    import subprocess
    import json
    import hashlib
    import base64
    import struct
    from .external import FFmpegFD
    from .utils import (
        encodeFilename,
        sanitize_open,
        sanitized_Request,
    )

# Generated at 2022-06-18 13:21:19.010674
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import json
    import youtube_dl.YoutubeDL
    from youtube_dl.extractor import gen_extractors
    from youtube_dl.utils import DownloadError
    from .test_fragment import _test_frag_download


# Generated at 2022-06-18 13:21:31.827306
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import unittest
    from .test_downloader import FakeYDL
    from .test_downloader import FakeHttpServer
    from .test_downloader import MockServerRule
    from .test_downloader import get_testdata_dir

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.ydl = FakeYDL()
            self.ydl.params['hls_use_mpegts'] = True
            self.ydl.params['test'] = True
            self.ydl.params['verbose'] = True
            self.ydl.params['quiet'] = True

# Generated at 2022-06-18 13:21:40.952172
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str

    ydl = gen_ydl(params={'hls_use_mpegts': True})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(gen_extractors()[0])
    ydl.add_info_extractor(gen_extractors()[1])
    ydl.add_info_extractor(gen_extractors()[2])
    ydl.add_info_extractor(gen_extractors()[3])
    ydl.add_info_extractor(gen_extractors()[4])

# Generated at 2022-06-18 13:22:12.755729
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..utils import encode_data_uri
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    from ..compat import compat_urllib_request
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD
    from ..downloader.external import ExternalFD
    from ..downloader.f4m import F4mFD
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.hls import HlsFD as HlsFD_
    from ..downloader.ism import IsmFD
    from ..downloader.fragment import FragmentFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.smoothstreams import SmoothstreamsFD

# Generated at 2022-06-18 13:22:25.901573
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.utils
    import youtube_dl.downloader.fragment

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a dummy manifest file
    manifest_file = os.path.join(temp_dir, 'manifest.m3u8')

# Generated at 2022-06-18 13:22:36.044501
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urlparse

    def _test_can_download(url, expected_result):
        ie = InfoExtractor()
        ie.add_info_extractor(HlsFD.ie_key())
        fd = FileDownloader({})
        fd.add_info_extractor(ie)
        fd.params['noplaylist'] = True
        fd.params['nocheckcertificate'] = True
        fd.params['prefer_insecure'] = True
        fd.params['format'] = 'best'
        fd.params['outtmpl'] = '%(id)s.%(ext)s'
        fd.params['quiet'] = True


# Generated at 2022-06-18 13:22:48.371576
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'ext': 'mp4',
                'http_headers': {
                    'User-Agent': 'test',
                },
            }

    class FakeYDL(object):
        def __init__(self, params):
            self.params = params
            self.extractor_descs = gen_extractors()


# Generated at 2022-06-18 13:23:00.268534
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    def _test_HlsFD_real_download(url, expected_fragment_data, expected_fragment_index):
        ydl = YoutubeDL()
        ydl.add_default_info_extractors()
        info = ydl.extract_info(url, download=False)
        assert info['_type'] == 'url'
        assert info['url'] == url
        assert info['ie_key'] == YoutubeIE.ie_key()
        assert info['protocol'] == 'm3u8'
        assert info['ext'] == 'mp4'
        assert info['title'] == 'Test'
        assert info['format'] == '137+140'
        assert info['format_id']

# Generated at 2022-06-18 13:23:09.282156
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func

    ydl = gen_ydl(params={'hls_prefer_native': True})
    extractors = gen_extractors(ydl)
    for ie in extractors:
        if ie.IE_NAME == 'hlsnative':
            break
    else:
        assert False, 'HlsFD not found'

    def test_url(url, expected_result):
        info_dict = {'url': url}
        assert ie._real_extract(info_dict) is expected_result

    test_url('https://example.com/manifest.m3u8', True)

# Generated at 2022-06-18 13:23:21.662373
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from .external import ExternalFD
    from .fragment import FragmentFD
    from .dash import DashSegmentsFD
    from .http import HttpFD
    from .m3u8 import M3u8FD
    from .hls import HlsFD

    # Test for HlsFD
    def test_HlsFD(url, expected_fragments, expected_fragment_urls, expected_fragment_content):
        ydl = YoutubeDL({'quiet': True})
        info_dict = ydl.extract_info(url, download=False)
        fd = HlsFD(ydl, {'hls_use_mpegts': False})
        fd.real_download('test.mp4', info_dict)

# Generated at 2022-06-18 13:23:31.668953
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    from .common import FakeYDL

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'ext': 'mp4',
                'title': 'test',
                'http_headers': {
                    'User-Agent': 'test',
                },
            }


# Generated at 2022-06-18 13:23:44.280036
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import unittest
    from .test_downloader import FakeYDL
    from .test_downloader import FakeHttpServer
    from .test_downloader import MockServerRule
    from .test_downloader import get_testdata_dir

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.testdata_dir = get_testdata_dir()
            self.temp_dir = tempfile.mkdtemp()
            self.server = FakeHttpServer()
            self.server.start()
            self.server_rule = MockServerRule(self.server)

# Generated at 2022-06-18 13:23:55.242433
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import prepend_extension
    from .common import FakeYDL
    from .test_fragment import _test_frag_download
    from .test_external import _test_external_download

    ydl = FakeYDL()
    ydl.params['hls_use_mpegts'] = True
    ydl.params['test'] = True
    ydl.params['noprogress'] = True
    ydl.params['quiet'] = True
    ydl.params['skip_download'] = True
    ydl.params['simulate'] = True
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ydl.params['writedescription'] = True
    ydl.params['writeinfojson'] = True
   

# Generated at 2022-06-18 13:24:48.966924
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.utils
    import youtube_dl.downloader.http
    import youtube_dl.downloader.fragment
    import youtube_dl.downloader.hls
    import youtube_dl.downloader.external


# Generated at 2022-06-18 13:24:59.837085
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..utils import prepend_extension
    from .fragment import FragmentFD
    from .external import FFmpegFD

    # Test for constructor of class HlsFD

# Generated at 2022-06-18 13:25:10.859509
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import fake_urlopen

    class FakeIE(InfoExtractor):
        IE_NAME = 'fake'
        _VALID_URL = r'https?://.*'

        def _real_extract(self, url):
            return {
                'id': 'fake',
                'url': url,
                'title': 'fake',
                'is_live': False,
            }

    ie = FakeIE()
    ie._downloader = GenericIE._create_downloader({})
    ie._downloader.urlopen = fake_urlopen()
    ie._downloader.cache.get = lambda *args, **kwargs: None

    # Test with a manifest that contains unsupported features

# Generated at 2022-06-18 13:25:18.741829
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import youtube_dl.extractor.common as common
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DownloadError

    def _test_HlsFD_real_download(manifest, info_dict, expected_result, expected_output):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            f.write(manifest.encode('utf-8'))
            f.close()

# Generated at 2022-06-18 13:25:31.608280
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeDL
    from ..utils import encode_data_uri

    def _test_HlsFD_real_download(url, expected_fragment_count, expected_fragment_data):
        ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})

# Generated at 2022-06-18 13:25:43.408487
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import tempfile
    import shutil
    import unittest

    from .test_download import FakeYDL

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.ydl = FakeYDL()
            self.ydl.params['hls_prefer_native'] = True
            self.ydl.params['hls_use_mpegts'] = False
            self.ydl.params['outtmpl'] = os.path.join(self.test_dir, '%(id)s.%(ext)s')

        def tearDown(self):
            shutil.rmtree(self.test_dir)


# Generated at 2022-06-18 13:25:52.709608
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    import os
    import tempfile
    import shutil
    import random
    import string

    def random_string(length):
        return ''.join(random.choice(string.ascii_lowercase) for _ in range(length))

    def get_test_file(filename):
        return os.path.join(os.path.dirname(__file__), 'test_files', filename)

    def get_test_content(filename):
        with open(get_test_file(filename), 'rb') as f:
            return f.read()

    def get_test_manifest(filename):
        return get_test_content(filename).decode('utf-8')


# Generated at 2022-06-18 13:26:02.796598
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_info_extractor(YoutubeIE.ie_key())

# Generated at 2022-06-18 13:26:11.371583
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import unittest
    from .test_download import FakeYDL
    from .test_download import FakeHttpServer
    from .test_download import TESTS_DATA_ROOT

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.ydl = FakeYDL()
            self.ydl.params['hls_prefer_native'] = True
            self.ydl.params['test'] = True
            self.ydl.params['outtmpl'] = os.path.join(self.test_dir, '%(title)s-%(id)s.%(ext)s')
            self.ydl.params['noprogress'] = True

# Generated at 2022-06-18 13:26:18.645193
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..downloader import YoutubeDL
    from ..postprocessor import FFmpegMergerPP

    def _get_extractor(url):
        for ie in gen_extractors():
            if ie.suitable(url) and ie.IE_NAME != 'generic':
                return ie
        return None

    def _get_info_extractor(url):
        ie = _get_extractor(url)
        if ie is None:
            return None

# Generated at 2022-06-18 13:27:53.400203
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Download a video

# Generated at 2022-06-18 13:28:05.836359
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    # Test with a video that has a single fragment
    video_id = 'HlsFD_real_download_single_fragment'
    video_url = 'https://www.youtube.com/watch?v=%s' % video_id

# Generated at 2022-06-18 13:28:12.021268
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_info_extractor(YoutubeIE())
    ydl.download(['https://www.youtube.com/watch?v=BaW_jenozKc'])
    return True

# Generated at 2022-06-18 13:28:17.264530
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    from .external import FFmpegFD
    from .utils import (
        encodeFilename,
        prepend_extension,
    )
    from ..compat import (
        compat_urllib_request,
        compat_urllib_error,
    )

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create the manifest file
    manifest_file = os.path.join(temp_dir, 'manifest.m3u8')

# Generated at 2022-06-18 13:28:26.088495
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\nhttp://example.com/1.ts\n#EXTINF:10,\nhttp://example.com/2.ts\n#EXTINF:10,\nhttp://example.com/3.ts\n#EXT-X-ENDLIST', {})

# Generated at 2022-06-18 13:28:39.011213
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import youtube_dl.utils
    from youtube_dl.extractor import YoutubeDL
    from .common import FakeYDL


# Generated at 2022-06-18 13:28:49.769480
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import fake_urlopen

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'test': True,
                'outtmpl': '%(id)s.%(ext)s',
            }
            self.cache = None
            self.extractor = InfoExtractor(self, 'test')
            self.extractor.add_info_extractor(GenericIE(self.extractor))

        def urlopen(self, url):
            return fake_urlopen(url)

    ydl = FakeYDL()
    ydl.params['test'] = True
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
   

# Generated at 2022-06-18 13:28:58.919322
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors
    from ..downloader.common import FileDownloader
    from ..utils import match_filter_func

    def test_can_download(manifest, info_dict, expected_result):
        extractors = gen_extractors()
        for ie in extractors:
            if ie.suitable(manifest) and ie.IE_NAME in ('hls', 'hlsnative'):
                break
        else:
            assert False, 'No extractor found for manifest'

        ydl = FileDownloader({'hls_prefer_native': True})
        ydl.add_info_extractor(ie)
        ydl.params['noprogress'] = True
        ydl.params['quiet'] = True
        ydl.params['test'] = True

# Generated at 2022-06-18 13:29:09.409257
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func

    ydl = gen_ydl(params={'noplaylist': True})
    for ie in gen_extractors():
        if ie.IE_NAME == 'hlsnative':
            ie = ie(ydl=ydl)
            break
    else:
        assert False, 'HlsFD not found'

    # Test that HlsFD can download a manifest

# Generated at 2022-06-18 13:29:20.733762
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .http import HttpFD
    from .external import ExternalFD
    from .fragment import FragmentFD
    from .dash import DashSegmentsFD
    from .hls import HlsFD
    from .ism import IsmFD
    from .m3u8 import M3u8FD
    from .f4m import F4mFD
    from .rtmp import RtmpFD
    from .smoothstreams import SmoothStreamsFD
    from .youtube import YoutubeFD
    from .generic import GenericFD
    from .external import FFmpegFD
    from .dash import DashFD
    from .dash import DashSegmentsFD
    from .dash import DashManifestFD
    from .dash import DashIsmFD
    from .dash import DashIs