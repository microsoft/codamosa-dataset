

# Generated at 2022-06-18 13:19:55.599679
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..downloader import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_use_mpegts'] = True
    ydl.params['fragment_retries'] = 2
    ydl.params['skip_unavailable_fragments'] = False
    ydl.params['test'] = True
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ydl.params['quiet'] = True
    ydl.params['simulate'] = True
    ydl.params['nooverwrites'] = True
    ydl.params['writedescription'] = True
    ydl.params['writeinfojson'] = True
    ydl.params['writesubtitles'] = True

# Generated at 2022-06-18 13:20:06.774957
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import unittest

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test.mp4')
            self.test_url = 'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8'

# Generated at 2022-06-18 13:20:18.825058
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from .common import FakeYDL

    class FakeIE(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeIE, self).__init__(*args, **kwargs)
            self._test_downloader = None

        def _download_webpage(self, *args, **kwargs):
            return encode_data_uri(self._test_manifest, 'text/plain')

        def _real_initialize(self):
            self._test_downloader = HlsFD(FakeYDL(), {})

    ie = FakeIE({})

# Generated at 2022-06-18 13:20:30.921841
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError
    from .http import HttpFD
    from .http import HttpIE
    from .http import HttpTestDataServer

    ie = InfoExtractor(HlsIE.ie_key())
    ie.add_info_extractor(HttpIE.ie_key())
    ie.add_info_extractor(HlsIE.ie_key())
    ie.add_info_extractor(HlsFD.ie_key())

    server = HttpTestDataServer()

# Generated at 2022-06-18 13:20:41.902887
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..utils import encode_data_uri
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..compat import compat_str

    def _test_HlsFD_real_download(ydl, url, expected_fragment_count, expected_fragment_data):
        ie = YoutubeIE(ydl)
        info_dict = ie.extract(url)
        fd = HlsFD(ydl, {'test': True})
        fd.real_download(None, info_dict)
        assert fd.ctx['total_frags'] == expected_fragment_count
        assert fd.ctx['fragments'] == expected_fragment_data


# Generated at 2022-06-18 13:20:52.410562
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import match_filter_func

    ie = InfoExtractor(None, {})
    ie.add_info_extractor(HlsFD.ie_key())
    ie.add_info_extractor(FFmpegFD.ie_key())

    # Test that HlsFD is selected for a manifest that it can download

# Generated at 2022-06-18 13:21:03.531593
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import youtube_dl.YoutubeDL
    import youtube_dl.utils
    import youtube_dl.extractor.common
    import youtube_dl.extractor.youtube
    import youtube_dl.extractor.generic

    class TestYoutubeDL(youtube_dl.YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(TestYoutubeDL, self).__init__(*args, **kwargs)
            self.to_screen = lambda *args, **kwargs: None
            self.processed_info_dicts = []

        def process_info(self, info_dict):
            self.processed_info_dicts.append(info_dict)


# Generated at 2022-06-18 13:21:16.777561
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import FakeYDL

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'FakeInfoExtractor'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return {
                'id': 'test_id',
                'url': url,
                'title': 'test_title',
                'ext': 'mp4',
                'is_live': False,
            }

    class FakeGenericIE(GenericIE):
        IE_NAME = 'FakeGenericIE'
        _VALID_URL = r'https?://.+'


# Generated at 2022-06-18 13:21:29.726424
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..utils import encode_data_uri
    from ..extractor import YoutubeIE
    from ..compat import compat_urllib_request
    from ..downloader import Downloader

    # Test for a single fragment

# Generated at 2022-06-18 13:21:39.566951
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    from ..downloader import Downloader
    from ..downloader.common import FileDownloader
    from ..downloader.external import ExternalFD
    from ..downloader.f4m import F4mFD
    from ..downloader.hls import HlsFD
    from ..downloader.http import HttpFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.smoothstreams import SmoothstreamsFD
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.fragment import FragmentFD
    from ..downloader.external import FFmpegFD
    from ..downloader.ism import IsmFD

# Generated at 2022-06-18 13:22:17.370461
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..downloader import get_suitable_downloader

    def get_manifest(url):
        return compat_urllib_request.urlopen(url).read().decode('utf-8', 'ignore')

    def get_info_dict(url):
        return gen_extractors(get_suitable_downloader(url), [url])[0].result['info_dict']

    def get_can_download(url):
        return HlsFD.can_download(get_manifest(url), get_info_dict(url))


# Generated at 2022-06-18 13:22:30.271067
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'test': True,
                'noprogress': True,
            }

        def urlopen(self, url):
            class FakeUrlOpen(object):
                def __init__(self, url):
                    self.url = url

                def read(self):
                    return b'abc'

            return FakeUrlOpen(url)

        def to_screen(self, msg):
            pass

        def report_warning(self, msg):
            pass

        def report_error(self, msg):
            raise ExtractorError(msg)


# Generated at 2022-06-18 13:22:38.352572
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    def _test_HlsFD_real_download(url, expected_fragment_content, expected_fragment_index):
        ydl = YoutubeDL({'quiet': True, 'skip_download': True, 'test': True})
        ydl.add_default_info_extractors()
        ie = YoutubeIE(ydl)
        info = ie.extract(url)
        assert info['_type'] == 'url_transparent'
        assert info['url'] == url
        assert info['ie_key'] == 'HlsFD'
        assert info['protocol'] == 'm3u8'
        assert info['ext'] == 'mp4'
        assert info['title'] == 'Test'


# Generated at 2022-06-18 13:22:50.552284
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import unittest

    from .http import HttpFD
    from .external import FFmpegFD
    from .fragment import FragmentFD
    from ..utils import (
        encodeFilename,
        prepend_extension,
    )

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test.mp4')
            self.test_file_encrypted = os.path.join(self.test_dir, 'test_encrypted.mp4')

# Generated at 2022-06-18 13:23:02.135987
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    import tempfile
    import os
    import shutil
    import random
    import string

    def _random_string(length):
        return ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(length))

    def _random_bytes(length):
        return bytes(bytearray(random.getrandbits(8) for _ in range(length)))

    def _random_hex(length):
        return binascii.hexlify(_random_bytes(length)).decode('ascii')

    def _random_iv():
        return _random_hex(16)


# Generated at 2022-06-18 13:23:10.370239
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri

    def _test_download(url, expected_fragment_count, expected_fragment_data):
        ie = InfoExtractor(params={'noplaylist': True})
        ie.add_info_extractor(HlsFD)
        info = ie.extract(url)
        assert info['_type'] == 'hls'
        assert info['url'] == url
        assert info['ext'] == 'mp4'
        assert info['title'] == 'test'
        assert info['is_live'] is False
        assert info['fragment_count'] == expected_fragment_count
        assert info['fragments'] == expected_fragment_data

    test_

# Generated at 2022-06-18 13:23:23.213293
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import sys
    import tempfile
    import unittest
    import youtube_dl.extractor.common as common
    import youtube_dl.utils as utils

    class MockYDL(object):
        def __init__(self, params):
            self.params = params
            self.to_screen = lambda *args, **kwargs: None
            self.report_warning = lambda *args, **kwargs: None
            self.report_error = lambda *args, **kwargs: None
            self.report_retry_fragment = lambda *args, **kwargs: None
            self.report_skip_fragment = lambda *args, **kwargs: None
            self.urlopen = lambda *args, **kwargs: None


# Generated at 2022-06-18 13:23:32.538041
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_info_extractor(YoutubeIE())

    # Test with a single fragment

# Generated at 2022-06-18 13:23:45.399699
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_str
    from .common import FakeYDL
    from .test_fragment import _test_frag_download

    # Test with a single fragment
    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'https?://(?:www\.)?test\.com/video\.m3u8'

        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'is_live': False,
            }


# Generated at 2022-06-18 13:23:55.349320
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .utils import encode_data_uri

    # Test manifest

# Generated at 2022-06-18 13:24:43.748774
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    ie = YoutubeIE(ydl)
    info_dict = ie.extract('https://www.youtube.com/watch?v=BaW_jenozKc')
    fd = HlsFD(ydl, {'test': True})
    assert fd.can_download(info_dict['url'], info_dict)
    assert fd.real_download(None, info_dict)

# Generated at 2022-06-18 13:24:53.911486
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.utils
    import youtube_dl.extractor.common
    import youtube_dl.downloader.fragment
    import youtube_dl.downloader.hls

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a YoutubeDL object
    ydl_opts = {
        'format': 'best',
        'outtmpl': os.path.join(temp_dir, '%(id)s-%(format)s-%(format_id)s-%(resolution)s.%(ext)s'),
        'quiet': True,
        'simulate': True,
        'skip_download': True,
        'test': True,
    }
    y

# Generated at 2022-06-18 13:25:06.235418
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import encode_data_uri
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import json
    import time

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    temp_file = os.path.join(temp_dir, 'temp_file')
    with open(temp_file, 'wb') as f:
        f.write(b'\x00' * 100)

    # Create a temporary file for the manifest
    temp_manifest = os.path.join(temp_dir, 'temp_manifest')

# Generated at 2022-06-18 13:25:14.386902
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD
    from ..utils import encode_data_uri

    def _test_can_download(url, expected_result):
        info_dict = {
            'url': url,
            'extractor': 'test',
            'extractor_key': 'test',
            'webpage_url': 'test',
            'webpage_url_basename': 'test',
            'id': 'test',
            'title': 'test',
            '_type': 'test',
            'formats': [],
            'is_live': False,
        }
        extractors = gen_extractors()

# Generated at 2022-06-18 13:25:26.613869
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import ExtractorError
    from .common import FakeYDL

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'fake'
        _VALID_URL = r'https?://.+'
        _TEST = {
            'url': 'http://fake.url/',
            'info_dict': {
                'id': 'fake',
                'ext': 'mp4',
                'title': 'fake',
                'is_live': False,
            },
        }

        def _real_extract(self, url):
            return self._download_json(url, 'fake')

    class FakeGenericIE(GenericIE):
        IE_NAME = 'fake_generic'
        _VALID_

# Generated at 2022-06-18 13:25:38.263815
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..compat import compat_urllib_request
    from ..utils import encode_data_uri
    from .http import HttpFD
    from .external import ExternalFD
    from .fragment import FragmentFD
    from .dash import DashSegmentsFD
    from .hls import HlsFD
    from .ism import IsmFD
    from .f4m import F4mFD
    from .m3u8 import M3u8FD
    from .rtmp import RtmpFD
    from .rtsp import RtspFD
    from .smoothstreams import SmoothStreamsFD
    from .youtube import YoutubeFD
    from .generic import GenericFD


# Generated at 2022-06-18 13:25:49.077974
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    # Test data
    # The first fragment is encrypted with AES-128 and the key is in the same directory as the playlist
    # The second fragment is not encrypted
    # The third fragment is encrypted with AES-128 and the key is in the same directory as the playlist
    # The fourth fragment is encrypted with AES-128 and the key is in the same directory as the playlist
    # The fifth fragment is encrypted with AES-128 and the key is in the same directory as the playlist
    # The sixth fragment is encrypted with AES-128 and the key is in the same directory as the playlist
    # The seventh fragment is encrypted with AES-128 and the key is in the same directory as the playlist
    # The eighth fragment is encrypted with AES-128 and the key is in the same

# Generated at 2022-06-18 13:25:56.822358
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri

    # Test data is a m3u8 file with two fragments.
    # The first fragment is a video fragment and the second one is an audio fragment.
    # The video fragment is encrypted with AES-128 and the audio fragment is not encrypted.
    # The video fragment is also a byte range of a media file.
    # The audio fragment is not a byte range of a media file.
    # The video fragment is downloaded first and then the audio fragment is downloaded.

# Generated at 2022-06-18 13:26:04.934514
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\nhttp://media.example.com/first.ts\n#EXTINF:10,\nhttp://media.example.com/second.ts\n#EXTINF:10,\nhttp://media.example.com/third.ts\n#EXT-X-ENDLIST\n', {'url': 'http://media.example.com/playlist.m3u8'})

# Generated at 2022-06-18 13:26:13.927222
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'noplaylist': True, 'quiet': True, 'skip_download': True})
    ie = YoutubeIE(ydl)
    ie.extract('https://www.youtube.com/watch?v=BxV14h0kFs0')
    info = ydl.extract_info('https://www.youtube.com/watch?v=BxV14h0kFs0', download=False)
    info['url'] = encode_data_uri(info['url'], info['http_headers'])
    info['http_headers'] = {}

# Generated at 2022-06-18 13:27:55.591509
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    # Test a simple HLS stream
    ydl = YoutubeDL({'hls_prefer_native': True})
    ie = YoutubeIE(ydl)
    info_dict = ie.extract('https://www.youtube.com/watch?v=_HSylqgVYQI')
    assert info_dict['formats'][0]['protocol'] == 'm3u8'
    assert info_dict['formats'][0]['ext'] == 'mp4'
    assert info_dict['formats'][0]['format_id'] == '251'

# Generated at 2022-06-18 13:28:08.278540
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urlparse
    from .utils import encodeFilename

    def _test_real_download(ie, manifest_url, expected_filename, expected_fragments, expected_fragment_size):
        ie.params['test'] = True
        ie.params['noprogress'] = True
        ie.params['quiet'] = True
        ie.params['outtmpl'] = encodeFilename('%(id)s.%(ext)s')
        ie.params['format'] = 'bestvideo+bestaudio'
        ie.params['skip_download'] = True
        ie.params['nopart'] = True

# Generated at 2022-06-18 13:28:19.206070
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    def _test_HlsFD_real_download(url, expected_frag_content):
        ydl = YoutubeDL({'hls_use_mpegts': True})
        ie = YoutubeIE(ydl)
        info = ie.extract(url)
        info_dict = info['entries'][0] if 'entries' in info else info
        fd = HlsFD(ydl, {'test': True})
        fd.real_download('', info_dict)
        assert fd._frag_content == expected_frag_content

    # Test a simple HLS stream

# Generated at 2022-06-18 13:28:25.277553
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL.YoutubeDL({})
    hlsfd = HlsFD(ydl, {})
    assert hlsfd.ydl == ydl
    assert hlsfd.params == {}
    assert hlsfd.progress_hooks == []
    assert hlsfd.fragment_retries == 0
    assert hlsfd.skip_unavailable_fragments == True
    assert hlsfd.test == False


# Generated at 2022-06-18 13:28:31.377677
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import determine_ext
    from ..compat import compat_urllib_request
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD
    from ..downloader.f4m import F4mFD
    from ..downloader.hls import HlsFD as HlsFD_old
    from ..downloader.dash import DashFD
    from ..downloader.external import ExternalFD
    from ..downloader.fragment import FragmentFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.ism import IsmFD
    from ..downloader.m3u8 import M3u8FD
    from ..downloader.f4m import F4mFD

# Generated at 2022-06-18 13:28:37.347217
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    ydl = gen_ydl()
    for ie in gen_extractors():
        if ie.IE_NAME == 'hlsnative':
            ie = ie(ydl=ydl)
            break
    else:
        raise Exception('HlsFD not found')
    ie.extract('http://example.com/')

# Generated at 2022-06-18 13:28:47.719063
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri

    # Test data
    # The first fragment is a media fragment, the second is an ad fragment.
    # The third fragment is a media fragment, the fourth is an ad fragment.
    # The fifth fragment is a media fragment.
    # The sixth fragment is a media fragment.
    # The seventh fragment is a media fragment.
    # The eighth fragment is a media fragment.
    # The ninth fragment is a media fragment.
    # The tenth fragment is a media fragment.
    # The eleventh fragment is a media fragment.
    # The twelfth fragment is a media fragment.
    # The thirteenth fragment is a media fragment.
    # The fourteenth fragment is a media fragment.
    # The fifteenth fragment is a media fragment.
    # The sixteenth fragment is a

# Generated at 2022-06-18 13:28:57.562340
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    ydl = YoutubeIE()
    ydl.params['hls_use_mpegts'] = True
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_prefer_ffmpeg'] = False
    ydl.params['hls_segment_skip_manifest'] = True
    ydl.params['hls_segment_skip_fragments'] = True
    ydl.params['hls_segment_skip_live_start'] = True
    ydl.params['hls_segment_skip_live_end'] = True
    ydl.params['hls_segment_skip_ads'] = True
    ydl.params['hls_segment_format'] = 'ts'

# Generated at 2022-06-18 13:29:08.038527
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import tempfile
    import shutil
    import unittest

    from ..extractor import YoutubeIE
    from ..utils import determine_ext

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test.mp4')

        def tearDown(self):
            shutil.rmtree(self.test_dir)

        def test_can_download(self):
            def test_can_download_for_url(url, expected_result):
                ie = YoutubeIE(params={'noplaylist': True})
                info_dict = ie.extract(url)

# Generated at 2022-06-18 13:29:17.992712
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from .external import FFmpegFD
    from .fragment import FragmentFD
    from .dash import DashSegmentsFD
    from .http import HttpFD
    from .f4m import F4mFD
    from .smoothstreams import SmoothStreamsFD
    from .m3u8 import M3U8FD
    from .ism import IsmFD
    from .rtmp import RtmpFD
    from .rtsp import RtspFD
    from .hls import HlsFD
    from .generic import GenericFD
    from .external import ExternalFD
    from .ffmpegmux import FFmpegMuxFD
    from .ffmpegmuxedstream import FFmpegMuxedStreamFD
    from .ffmpegaudio import FFmpegAudioFD