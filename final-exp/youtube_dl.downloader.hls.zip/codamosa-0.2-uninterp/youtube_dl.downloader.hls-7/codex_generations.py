

# Generated at 2022-06-18 13:20:07.704866
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('', {'url': '', 'is_live': False})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'url': '', 'is_live': False})
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'url': '', 'is_live': False, '_decryption_key_url': ''})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'url': '', 'is_live': True, '_decryption_key_url': ''})

# Generated at 2022-06-18 13:20:19.496562
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    ydl = gen_extractors()['youtube']
    ydl.params['hls_use_mpegts'] = True
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_prefer_ffmpeg'] = False
    ydl.params['hls_segment_format'] = 'mpegts'
    ydl.params['hls_segment_size'] = 1048576
    ydl.params['hls_segment_skip_unavailable'] = True
    ydl.params['hls_segment_ignore_names'] = False
    ydl.params['hls_segment_type'] = 'mp4'
    ydl.params['hls_segment_key_info_file'] = None
    y

# Generated at 2022-06-18 13:20:32.116147
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors
    from ..extractor.common import InfoExtractor
    from ..compat import compat_urllib_request
    from ..utils import url_basename

    def _mock_urlopen(url):
        if url == 'http://example.com/manifest.m3u8':
            return compat_urllib_request.BytesIO(b'#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="http://example.com/key"\nhttp://example.com/segment1.ts\nhttp://example.com/segment2.ts\n')
        elif url == 'http://example.com/key':
            return compat_urllib_request.BytesIO(b'0123456789abcdef')

# Generated at 2022-06-18 13:20:42.692299
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri

    class TestIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'url': url,
                'id': 'test',
                'title': 'test',
            }

    ie = TestIE()
    ie.add_info_extractor(HlsFD)

    # Test with a non-encrypted stream

# Generated at 2022-06-18 13:20:51.097841
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    ydl = YoutubeDL({'hls_prefer_native': True})
    ie = YoutubeIE(ydl)
    info = ie._extract_info(
        'http://www.youtube.com/watch?v=BaW_jenozKc',
        download=False)
    fd = HlsFD(ydl, {'hls_prefer_native': True})
    assert fd.can_download(encode_data_uri(info['url']), info)

# Generated at 2022-06-18 13:21:01.822475
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func

    # Test that HlsFD is not listed as a downloader for non-HLS videos
    extractors = gen_extractors()
    extractors = list(filter(match_filter_func('youtube:watchlater'), extractors))
    assert not any(e.IE_NAME == 'hlsnative' for e in extractors)

    # Test that HlsFD is listed as a downloader for HLS videos
    extractors = gen_extractors()

# Generated at 2022-06-18 13:21:15.194894
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    from .http import HttpFD
    import os
    import tempfile

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_file_path = tempfile.mkstemp(dir=temp_dir)
    os.close(fd)

    # Create a temporary file to store the manifest
    fd, temp_manifest_path = tempfile.mkstemp(dir=temp_dir)
    os.close(fd)

    # Create a temporary file to store the decryption key
    fd, temp_key_path = tempfile.mkstemp(dir=temp_dir)
    os.close

# Generated at 2022-06-18 13:21:28.005777
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func

    ydl = gen_ydl(params={'noplaylist': True})
    extractors = gen_extractors(ydl)
    for ie in extractors:
        if ie.IE_NAME == 'hlsnative':
            break
    else:
        assert False, 'hlsnative extractor not found'

    def _test_HlsFD(url, expected_result):
        info_dict = ie._real_extract(url)
        assert info_dict['extractor'] == 'hlsnative'
        assert HlsFD.can_download(info_dict['url'], info_dict) == expected_result


# Generated at 2022-06-18 13:21:38.397147
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_info_extractor(YoutubeIE())

# Generated at 2022-06-18 13:21:44.424783
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_urlparse

    ydl = gen_ydl()
    ydl.params.update({
        'match_filter': match_filter_func(
            ['hlsnative', 'hls', 'http', 'https', 'http_dash_segments', 'http_generic_segment_urls']),
        'test': True,
    })
    ydl.add_default_info_extractors()
    for ie in gen_extractors():
        ydl.add_info_extractor(ie)


# Generated at 2022-06-18 13:22:28.690498
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ie = YoutubeIE(ydl)
    info_dict = {
        'id': 'test',
        'url': 'https://example.com/test.m3u8',
        'ext': 'mp4',
        'title': 'test',
        'thumbnail': 'https://example.com/test.jpg',
        'duration': 10,
        'http_headers': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0',
        },
    }

# Generated at 2022-06-18 13:22:37.577209
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_urlparse

    ydl = gen_ydl()
    ydl.params['noplaylist'] = True
    ydl.params['nocheckcertificate'] = True
    ydl.params['simulate'] = True
    ydl.params['quiet'] = True
    ydl.params['format'] = 'bestvideo+bestaudio/best'

    # Test that HlsFD is selected for HLS streams
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'generic':
            continue
        if ie.IE_NAME.startswith('test_'):
            continue

# Generated at 2022-06-18 13:22:49.620628
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func

    ydl = gen_ydl(params={'hls_prefer_native': True})
    for ie in gen_extractors():
        if ie.ie_key() == 'hlsnative':
            break
    else:
        raise Exception('HlsFD not found')
    ie.set_downloader(ydl)
    info_dict = {
        'url': 'https://example.com/manifest.m3u8',
        'http_headers': {'User-Agent': 'test'},
    }
    fd = ie._real_extract(info_dict)
    assert isinstance(fd, HlsFD)
    assert fd.ydl is ydl


# Generated at 2022-06-18 13:23:01.542459
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_str

    class FakeYDL(object):
        def __init__(self, ie):
            self.ie = ie

        def urlopen(self, url):
            return compat_urllib_request.urlopen(url)

    class FakeInfoDict(object):
        def __init__(self, ie):
            self.ie = ie

        def get(self, key, default=None):
            if key == 'url':
                return 'http://example.com/manifest.m3u8'
            elif key == 'http_headers':
                return {'User-Agent': 'FakeUA'}

# Generated at 2022-06-18 13:23:10.011237
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import encode_data_uri
    from .common import FakeYDL

    ydl = FakeYDL()
    ydl.params['hls_use_mpegts'] = True
    ydl.params['test'] = True
    ydl.params['skip_download'] = True
    ydl.params['quiet'] = True
    ydl.params['noprogress'] = True
    ydl.params['simulate'] = True
    ydl.params['fragment_retries'] = 0
    ydl.params['skip_unavailable_fragments'] = False
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ydl.params['writedescription'] = True

# Generated at 2022-06-18 13:23:22.637500
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..downloader import YoutubeDL
    ydl = YoutubeDL({})
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=836280,RESOLUTION=848x360,CODECS="avc1.4d401f,mp4a.40.2"\nmedia.m3u8\n', {'url': 'http://example.com/media.m3u8', 'http_headers': {}})

# Generated at 2022-06-18 13:23:32.221838
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..utils import encode_data_uri

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'url': url,
                '_type': 'hls',
                'is_live': False,
                'extractor': 'hls',
                'title': 'test',
                'id': 'test',
                'formats': [],
            }

    class FakeFileDownloader(FileDownloader):
        def __init__(self, ydl, params):
            super(FakeFileDownloader, self).__init__(ydl, params)
            self.result_path = None


# Generated at 2022-06-18 13:23:45.059011
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..compat import compat_str
    from ..utils import encode_data_uri

    def _test_HlsFD_can_download(manifest, info_dict, expected_result):
        ydl = gen_ydl()
        ydl.add_default_info_extractors()
        for ie in gen_extractors():
            ydl.add_info_extractor(ie)
        info_dict['url'] = encode_data_uri(compat_str(manifest), 'text/plain')
        info_dict['ext'] = 'mp4'

# Generated at 2022-06-18 13:23:55.315765
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    from .common import FakeYDL

    class FakeIE(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(FakeIE, self).__init__(*args, **kwargs)
            self.num_downloads = 0

        def _real_extract(self, url):
            return {
                'id': '1337',
                'url': url,
                'title': 'WyIxMzM3Il0=',
                'formats': [
                    {'url': 'http://example.com/1337.mp4'},
                ],
            }


# Generated at 2022-06-18 13:24:01.065116
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..downloader.http import HttpFD
    from ..downloader.external import ExternalFD
    from ..downloader.f4m import F4mFD
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.hls import HlsFD as HlsFD_old
    from ..downloader.ism import IsmFD
    from ..downloader.m3u8 import M3u8FD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.rtsp import RtspFD
    from ..downloader.smoothstreams import SmoothstreamsFD
    from ..downloader.youtube import YoutubeFD
    from ..downloader.fragment import FragmentFD

# Generated at 2022-06-18 13:24:46.760246
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request

    def _mock_urlopen(req):
        if req.get_full_url() == 'http://manifest.url/manifest.m3u8':
            return get_test_data('test.m3u8')
        elif req.get_full_url() == 'http://manifest.url/media.ts':
            return get_test_data('test.ts')
        elif req.get_full_url() == 'http://manifest.url/media.key':
            return get_test_data('test.key')

# Generated at 2022-06-18 13:24:55.178550
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import youtube_dl.extractor.common as common
    from youtube_dl.utils import DownloadError
    from .test_utils import FakeYDL

    def _test_HlsFD_real_download(manifest, expected_content, expected_error=None, **kwargs):
        tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:25:07.456324
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    ydl = gen_ydl()
    ext = gen_extractors(ydl)['hlsnative']
    fd = ext(ydl, {'format': 'hlsnative'})
    assert fd.FD_NAME == 'hlsnative'
    assert fd.can_download({'url': 'http://example.com/'}, {'url': 'http://example.com/'})
    assert not fd.can_download({'url': 'http://example.com/'}, {'url': 'http://example.com/', 'is_live': True})

# Generated at 2022-06-18 13:25:15.945461
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import encode_data_uri
    from ..compat import compat_str
    from .http import HttpFD
    from .external import ExternalFD
    from .fragment import FragmentFD
    from .dash import DashSegmentsFD
    from .ism import IsmFD
    from .m3u8 import M3u8FD
    from .f4m import F4mFD
    from .smoothstreams import SmoothstreamsFD
    from .hds import HdsFD
    from .hls import HlsFD
    from .http import HttpFD
    from .rtmp import RtmpFD
    from .rtsp import RtspFD
    from .rtmpdump import RtmpdumpFD
    from .youtube import YoutubeFD
    from .generic import GenericFD
   

# Generated at 2022-06-18 13:25:28.517174
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import unittest
    from .test_downloader import MockYDL
    from .test_downloader import MockInfoDict
    from .test_downloader import MockFD
    from .test_downloader import MockHook
    from .test_downloader import MockUrlOpen

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test.mp4')
            self.ydl = MockYDL()
            self.ydl.params['outtmpl'] = self.test_file
            self.ydl.params['test'] = True
            self.ydl.urlopen = MockUrlOpen()

# Generated at 2022-06-18 13:25:40.508954
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import prepend_extension
    from ..compat import compat_urlparse
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_struct_pack
    from ..compat import compat_struct_unpack
    from ..compat import compat_str
    from ..compat import compat_chr
    from ..compat import compat_ord
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib_parse_unquote
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_urllib_parse_urljoin
   

# Generated at 2022-06-18 13:25:50.626018
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..compat import compat_urllib_request
    from ..utils import encodeFilename

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'outtmpl': encodeFilename('%(id)s.%(ext)s'),
                'test': True,
            }
            self.cache = None
            self.progress_hooks = []

        def urlopen(self, url):
            return compat_urllib_request.urlopen(url)

        def to_screen(self, msg):
            pass

        def to_stdout(self, msg):
            pass

        def to_stderr(self, msg):
            pass


# Generated at 2022-06-18 13:26:01.535847
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'hlsnative':
            break
    else:
        assert False, 'HlsFD not found'
    ie.suitable('https://example.com/manifest.m3u8')
    ie.suitable('https://example.com/manifest.m3u8?foo=bar')
    ie.suitable('https://example.com/manifest.m3u8#foo=bar')
    ie.suitable('https://example.com/manifest.m3u8?foo=bar#foo=bar')
    ie.suitable('https://example.com/manifest.m3u8?foo=bar#foo=bar')

# Generated at 2022-06-18 13:26:09.937879
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from .fragment import FragmentFD
    from .external import FFmpegFD
    from .dash import DashSegmentsFD

    ydl = gen_ydl(params={'hls_prefer_native': True})
    extractors = gen_extractors()
    for ie in extractors:
        if ie.IE_NAME == 'youtube':
            break
    ie.extract_info(
        'https://www.youtube.com/watch?v=VYOjWnS4cMY',
        download=False,
        ie_key=None,
        extra_info={},
        process=False,
        force_generic_extractor=False,
    )
    info

# Generated at 2022-06-18 13:26:17.593909
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader.common import FileDownloader
    from ..utils import match_filter_func
    from ..compat import compat_str

    def _get_extractor(url):
        for ie in gen_extractors():
            if ie.suitable(url) and ie.IE_NAME != 'generic':
                return ie

    def _get_info_dict(url, ie, downloader):
        # Simulate extractor
        ie.ydl = downloader
        ie._setup_opener()
        ie.url = url
        return ie._real_extract(url)

    def _get_manifest(url, ie, downloader):
        info_dict = _get_info_dict(url, ie, downloader)
        return info_dict['url']


# Generated at 2022-06-18 13:27:41.593005
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import json
    import unittest
    from .test_downloads import (
        FakeYDL,
        FakeHttpServer,
        get_testcases_from_id,
        get_testcases_from_url,
    )

    def _get_test_info_dict(test_id):
        test_cases = get_testcases_from_id(test_id)
        test_info_dict = {}
        for test_case in test_cases:
            if test_case['type'] == 'manifest':
                test_info_dict['url'] = test_case['url']
            elif test_case['type'] == 'fragment':
                test_info_dict['fragments'].append(test_case['url'])

# Generated at 2022-06-18 13:27:49.797862
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import match_filter_func

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'test': True,
                'skip_download': True,
                'match_filter': match_filter_func(['test']),
            }
            self.extractor = InfoExtractor(self, GenericIE.ie_key())

        def urlopen(self, url):
            return compat_urllib_request.urlopen(url)

    ydl = FakeYDL()
    hls_fd = HlsFD(ydl, ydl.params)
    assert hls_fd.can_download('#EXTM3U', {'url': 'http://example.com/'})

# Generated at 2022-06-18 13:27:59.049908
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-18 13:28:12.021350
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import unittest
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.postprocessor.ffmpeg

    class FakeYDL(youtube_dl.YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(FakeYDL, self).__init__(*args, **kwargs)
            self.to_screen = lambda *args, **kwargs: None

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.__setitem__('_type', 'hls')
            self.__setitem__('ext', 'mp4')


# Generated at 2022-06-18 13:28:21.938774
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import youtube_dl.YoutubeDL
    import youtube_dl.utils
    import youtube_dl.extractor.common
    import youtube_dl.extractor.youtube
    import youtube_dl.extractor.generic

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create a youtube-dl object

# Generated at 2022-06-18 13:28:29.173368
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    import os

    # Test for a live stream
    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ie = YoutubeIE(ydl)
    info = ie.extract('https://www.youtube.com/watch?v=5qap5aO4i9A')
    assert not HlsFD.can_download(info['url'], info)

    # Test for a non-live stream
    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ie = YoutubeIE(ydl)

# Generated at 2022-06-18 13:28:34.587316
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .extractor.generic import GenericIE
    from .downloader.http import HttpFD
    from .downloader.http.http_req_download import HttpRequest
    from .compat import compat_str
    from .utils import encode_data_uri
    from .extractor import get_info_extractor

    # Test data
    test_data = get_test_data()
    test_url = 'https://example.com/test.m3u8'
    test_manifest = test_data.decode('utf-8')
    test_fragment_url = 'https://example.com/test.ts'

# Generated at 2022-06-18 13:28:44.934133
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.utils
    import youtube_dl.downloader.fragment
    import youtube_dl.downloader.http
    import youtube_dl.downloader.hls
    import youtube_dl.downloader.external

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a youtube-dl object

# Generated at 2022-06-18 13:28:55.411938
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .test import get_test_handler
    from .test import get_test_youtube_dl
    from .test import get_test_info_dict
    from .test import get_test_filename
    from .test import get_test_params

    test_handler = get_test_handler()
    test_youtube_dl = get_test_youtube_dl()
    test_info_dict = get_test_info_dict()
    test_filename = get_test_filename()
    test_params = get_test_params()

    test_params['test'] = True
    test_params['fragment_retries'] = 0
    test_params['skip_unavailable_fragments'] = False


# Generated at 2022-06-18 13:29:05.610184
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import encode_data_uri

    def _test_HlsFD_real_download(ydl, info_dict, expected_filename, expected_fragments_count):
        hlsfd = HlsFD(ydl, {})
        assert hlsfd.real_download(expected_filename, info_dict)
        assert hlsfd.ctx['total_frags'] == expected_fragments_count
        assert hlsfd.ctx['fragment_index'] == expected_fragments_count

    def _test_HlsFD_real_download_error(ydl, info_dict, expected_error_message):
        hlsfd = HlsFD(ydl, {})
        assert not hlsfd.real_