

# Generated at 2022-06-18 13:20:05.075194
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    from .external import ExternalFD

    def _test_HlsFD_real_download(manifest_url, expected_data, expected_fragments, expected_ad_fragments,
                                  extra_param_to_segment_url=None, http_headers=None,
                                  decryption_key_url=None, decryption_key=None,
                                  decryption_iv=None, decryption_method='AES-128'):
        temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 13:20:17.311509
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..utils import encode_data_uri

    # Test with a simple HLS playlist
    ie = InfoExtractor(FileDownloader())
    ie.add_info_extractor(HlsFD)

# Generated at 2022-06-18 13:20:27.400023
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'outtmpl': '-'})
    ydl.add_info_extractor(YoutubeIE.ie_key())

# Generated at 2022-06-18 13:20:39.010285
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    from .external import FFmpegFD
    from .fragment import FragmentFD
    from .dash import DashSegmentsFD

    # Test for a non-encrypted stream
    url = 'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8'
    ie = YoutubeIE(YoutubeDL())
    info_dict = ie.extract(url)
    assert HlsFD.can_download(info_dict['url'], info_dict)
    assert not FFmpegFD.can_download(info_dict['url'], info_dict)
    assert not FragmentFD.can_download

# Generated at 2022-06-18 13:20:47.121657
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'noplaylist': True})
    ie = YoutubeIE(ydl)
    info = ie.extract('https://www.youtube.com/watch?v=BaW_jenozKc')
    fd = HlsFD(ydl, {'hls_prefer_native': True})
    assert fd.can_download(encode_data_uri(info['url']), info)
    assert fd.real_download(None, info)

# Generated at 2022-06-18 13:20:55.487006
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import determine_ext
    from ..downloader import YoutubeDL
    from ..compat import compat_str

    ydl = YoutubeDL({'quiet': True, 'skip_download': True, 'simulate': True})
    ie = YoutubeIE(ydl)
    info_dict = ie.extract('https://www.youtube.com/watch?v=BaW_jenozKc')
    fd = HlsFD(ydl, {})
    filename = 'test' + determine_ext(info_dict)
    assert fd.real_download(filename, info_dict)
    with open(filename, 'rb') as f:
        assert compat_str(f.read(4), 'utf-8') == 'FLV\x01'

# Generated at 2022-06-18 13:21:07.921478
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .extractor import YoutubeIE
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    from ..extractor.generic import GenericIE
    from ..extractor.youtube import YoutubePlaylistIE
    from ..extractor.youtube import YoutubeChannelIE
    from ..extractor.youtube import YoutubeSearchIE
    from ..extractor.youtube import YoutubeShowIE
    from ..extractor.youtube import YoutubeFavouritesIE
    from ..extractor.youtube import YoutubeHistoryIE
    from ..extractor.youtube import YoutubeRecommendedIE
    from ..extractor.youtube import YoutubeSubscriptionsIE
    from ..extractor.youtube import YoutubeWatchLaterIE
    from ..extractor.youtube import YoutubeTruncatedURLIE

# Generated at 2022-06-18 13:21:20.951236
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import unittest


# Generated at 2022-06-18 13:21:33.208270
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encodeFilename
    from .common import FakeYDL
    from .test_fragment import _test_frag_download
    from .test_external import _test_external_download


# Generated at 2022-06-18 13:21:42.575117
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    from .test_utils import FakeYDL
    from .test_utils import FakeHttpServer
    from .test_utils import FakeInfoDict

    def _test_HlsFD_real_download(manifest, info_dict, expected_filename, expected_content):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            f.close()
            filename = f.name

# Generated at 2022-06-18 13:22:10.139126
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encodeFilename
    from .external import ExternalFD
    from .fragment import FragmentFD
    from .dash import DashFD
    from .hls import HlsFD
    from .http import HttpFD
    from .rtmp import RtmpFD
    from .smoothstreams import SmoothstreamsFD
    from .ism import IsmFD
    from .rtsp import RtspFD
    from .m3u8 import M3u8FD
    from .f4m import F4mFD
    from .mms import MmsFD
    from .rtp import RtpFD
    from .scte35 import Scte35FD
    from .srt import SrtFD
    from .ttml import TtmlFD

# Generated at 2022-06-18 13:22:23.375530
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .common import InfoExtractor
    from ..utils import encode_data_uri

    test_data = get_test_data()
    ie = InfoExtractor(params={'skip_download': True})
    ie.add_info_extractor(HlsFD)
    ie.add_info_extractor(FFmpegFD)

    # Test case 1: AES-128 encrypted stream
    # The key is not provided in the playlist, so it is downloaded from the URL
    # specified in the EXT-X-KEY tag.
    # The IV is provided in the playlist, so it is not downloaded.
    # The key is not provided in the playlist, so it is downloaded from the URL
    # specified in the EXT-X-KEY tag.
    # The IV is provided in the playlist, so it is not downloaded.

# Generated at 2022-06-18 13:22:34.473324
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    from youtube_dl.downloader.hls import HlsFD
    from youtube_dl.utils import DownloadError

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a youtube-dl object
    ydl_opts = {
        'format': 'best',
        'outtmpl': os.path.join(temp_dir, '%(id)s-%(format)s-%(resolution)s.%(ext)s'),
        'quiet': True,
        'simulate': True,
        'skip_download': True,
        'hls_prefer_native': True,
        'hls_use_mpegts': False,
    }
    ydl = youtube_dl

# Generated at 2022-06-18 13:22:46.408544
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor import gen_extractors
    from .downloader import gen_ydl
    from .downloader import FileDownloader
    from .utils import encode_data_uri

    # Test data
    test_data = get_test_data()
    test_url = 'https://example.com/test.m3u8'

# Generated at 2022-06-18 13:22:58.353578
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func

    def _test_HlsFD(ydl, info_dict):
        fd = HlsFD(ydl, {'format': 'best'})
        fd.real_download(info_dict['_filename'], info_dict)

    def _test_HlsFD_with_ffmpeg(ydl, info_dict):
        fd = FFmpegFD(ydl, {'format': 'best'})
        fd.real_download(info_dict['_filename'], info_dict)


# Generated at 2022-06-18 13:23:07.973076
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str

    ydl = gen_ydl()
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_use_mpegts'] = True
    ydl.params['match_filter'] = match_filter_func('all')
    ydl.params['test'] = True
    ydl.params['quiet'] = True
    ydl.params['simulate'] = True
    ydl.params['skip_download'] = True
    ydl.params['noplaylist'] = True
    ydl.params['outtmpl'] = '%(id)s.%(ext)s'
    ydl.params

# Generated at 2022-06-18 13:23:20.776674
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    from .external import FFmpegFD
    from .fragment import FragmentFD

    # Test that HlsFD is a subclass of FragmentFD
    assert issubclass(HlsFD, FragmentFD)

    # Test that HlsFD is a subclass of FFmpegFD
    assert issubclass(HlsFD, FFmpegFD)

    # Test that HlsFD is a subclass of YoutubeDL
    assert issubclass(HlsFD, YoutubeDL)

    # Test that HlsFD is a subclass of YoutubeIE
    assert issubclass(HlsFD, YoutubeIE)

    # Test that HlsFD is a subclass of YoutubeDL
    assert issubclass(HlsFD, YoutubeDL)

    # Test that Hls

# Generated at 2022-06-18 13:23:31.017397
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func

    ydl = gen_ydl(params={'hls_prefer_native': True})
    extractors = gen_extractors(ydl)
    for ie in extractors:
        if ie.IE_NAME == 'hlsnative':
            break
    else:
        assert False, 'HlsFD not found'

    # Test that HlsFD is used for HLS streams

# Generated at 2022-06-18 13:23:43.337426
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encodeFilename

    ydl = YoutubeDL({
        'format': 'bestvideo+bestaudio/best',
        'outtmpl': encodeFilename('%(id)s.%(ext)s'),
        'writesubtitles': True,
        'allsubtitles': True,
        'writethumbnail': True,
        'writeautomaticsub': True,
        'subtitleslangs': 'en',
        'test': True,
    })
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE.ie_key())
    ydl.download(['https://www.youtube.com/watch?v=BaW_jenozKc'])

# Generated at 2022-06-18 13:23:50.853655
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import YoutubeDL
    from ..extractor import YoutubeIE
    from ..utils import encode_data_uri
    from .external import FFmpegFD
    import os
    import tempfile

    # Test that HlsFD can download a HLS stream
    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s', 'quiet': True})
    ydl.add_info_extractor(YoutubeIE())

# Generated at 2022-06-18 13:24:38.087846
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors
    from ..downloader.common import FileDownloader
    from ..compat import compat_urllib_request
    from ..utils import encode_data_uri
    from ..extractor.common import InfoExtractor
    from ..compat import compat_str

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'FakeInfoExtractor'
        _VALID_URL = r'https?://.+'


# Generated at 2022-06-18 13:24:50.033659
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urlparse

    def test_can_download(url):
        info_dict = {}
        info_dict['url'] = url
        info_dict['extractor'] = 'hls'
        info_dict['extractor_key'] = 'HlsFD'
        info_dict['http_headers'] = {}
        info_dict['http_headers']['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36'

# Generated at 2022-06-18 13:25:02.339090
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_str
    from .utils import encodeFilename

    def _run_test(test_name, expected_fragment_count, expected_fragment_data):
        test_data = get_test_data()
        test_data_path = test_data.subpath(test_name)
        test_data_url = test_data.get_url(test_name)
        test_data_manifest = test_data_path.read_text('utf-8')

        ie = InfoExtractor(FileDownloader({}))
        ie.params = {'noplaylist': True}
        ie._downloader.params = {'test': True}


# Generated at 2022-06-18 13:25:12.337606
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func
    from ..compat import compat_str

    # Test that HlsFD is not available if pycrypto is not installed
    ydl = gen_ydl()
    assert 'hlsnative' not in ydl.list_extractors(ydl)

    # Test that HlsFD is available if pycrypto is installed
    try:
        import Crypto.Cipher
        ydl = gen_ydl()
        assert 'hlsnative' in ydl.list_extractors(ydl)
    except ImportError:
        pass

    # Test that HlsFD is not available if ffmpeg is not installed

# Generated at 2022-06-18 13:25:23.809440
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import tempfile
    import unittest
    from .test_downloader import FakeYDL

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.ydl = FakeYDL()
            self.params = {
                'format': 'bestvideo+bestaudio/best',
                'outtmpl': os.path.join(tempfile.gettempdir(), '%(id)s.%(ext)s'),
                'writesubtitles': True,
                'writeautomaticsub': True,
                'allsubtitles': True,
                'subtitleslangs': ['en'],
            }


# Generated at 2022-06-18 13:25:36.080611
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    from .external import ExternalFD
    from .utils import encodeFilename

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file in the temporary directory
    fd, temp_file = tempfile.mkstemp(dir=temp_dir)

    # Close opened file
    os.close(fd)

    # Delete the temporary file
    def cleanup_temp_file():
        os.remove(temp_file)

    # This is a magic incantation to add cleanup_temp_file() to the
    # list of things to do when the interpreter exits.
    import atexit
    atexit.register(cleanup_temp_file)

    # Download the video

# Generated at 2022-06-18 13:25:47.058140
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader

    # Test for aes-128 encrypted stream
    ie = InfoExtractor(FileDownloader())
    ie.add_info_extractor(HlsFD)

# Generated at 2022-06-18 13:25:55.501761
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .utils import sanitize_open

    def _mock_urlopen(req):
        if req.get_full_url() == 'https://example.com/manifest.m3u8':
            return get_test_data('test.m3u8')
        elif req.get_full_url() == 'https://example.com/media.ts':
            return get_test_data('test.ts')
        elif req.get_full_url() == 'https://example.com/media.ts?extra_param':
            return get_test_data('test.ts')

# Generated at 2022-06-18 13:26:04.101911
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import gen_ydl
    from ..utils import match_filter_func

    def _test_HlsFD(url, expected_result):
        ydl = gen_ydl()
        ydl.params.update({
            'match_filter': match_filter_func(url),
            'test': True,
        })
        extractors = gen_extractors(ydl)
        for ie in extractors:
            if ie.suitable(url) and ie.IE_NAME != 'generic':
                ie.download(url)
                assert ydl.downloaded_info_dicts[0]['hlsnative_download'] == expected_result
                return
        assert False


# Generated at 2022-06-18 13:26:12.990395
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError
    from ..compat import compat_urllib_error

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'test': True,
                'skip_download': True,
                'quiet': True,
            }
            self.cache = None
            self.to_screen = lambda *args, **kargs: None
            self.report_warning = lambda *args, **kargs: None
            self.report_error = lambda *args, **kargs: None
            self.urlopen = lambda *args, **kargs: None

    class FakeIE(InfoExtractor):
        def __init__(self, ydl):
            self.ydl = ydl


# Generated at 2022-06-18 13:27:36.305143
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_info_extractor(YoutubeIE())

    # Test for a single fragment
    # https://github.com/ytdl-org/youtube-dl/issues/27660
    url = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'
    info = ydl.extract_info(url, download=False)

# Generated at 2022-06-18 13:27:43.658951
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import random
    import string
    import hashlib
    import base64
    import binascii
    from .external import FFmpegFD
    from .fragment import FragmentFD
    from .utils import (
        encodeFilename,
        sanitize_open,
    )
    from .extractor import (
        gen_extractors,
        get_info_extractor,
    )
    from .downloader import (
        YoutubeDL,
        FileDownloader,
    )
    from .compat import (
        compat_urllib_error,
        compat_urlparse,
        compat_struct_pack,
    )

# Generated at 2022-06-18 13:27:52.124587
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_str
    from .utils import encode_data_uri

    class FakeYDL(object):
        def __init__(self):
            self.cache = {}

        def urlopen(self, url):
            return FakeUrlOpen(self, url)

    class FakeUrlOpen(object):
        def __init__(self, ydl, url):
            self.ydl = ydl
            self.url = url

        def read(self):
            return self.ydl.cache[self.url]

        def geturl(self):
            return self.url


# Generated at 2022-06-18 13:28:03.533502
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    def _test_HlsFD(url, expected_result):
        extractors = gen_extractors()
        extractor = match_filter_func(extractors, lambda e: e.suitable(url))[0]
        info_dict = extractor.extract(url)
        assert info_dict['extractor'] == expected_result

    _test_HlsFD('https://www.youtube.com/watch?v=hY7m5jjJ9mM', 'youtube')

# Generated at 2022-06-18 13:28:15.856985
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'match_filter': match_filter_func(None),
                'test': True,
            }

        def urlopen(self, url):
            return compat_urllib_request.urlopen(url)

    class FakeIE(InfoExtractor):
        def __init__(self, ydl):
            self.ydl = ydl

    ydl = FakeYDL()
    ie = FakeIE(ydl)
    hls_fd = HlsFD(ydl, {'ie_key': ie.ie_key()})
    assert hls_fd.can_

# Generated at 2022-06-18 13:28:25.021902
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .utils import encode_data_uri

    # Test for a live stream
    ie = InfoExtractor(FileDownloader())
    ie.params = {'noplaylist': True}
    ie.add_default_info_extractors()
    ie.extract('https://www.youtube.com/watch?v=6wXkI4t7nuc')

# Generated at 2022-06-18 13:28:31.251782
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import random
    import string
    import hashlib
    import base64
    import binascii
    import time
    import re
    import urllib.parse
    import urllib.request
    import urllib.error
    import http.server
    import socketserver
    import threading
    import ssl
    import socket
    import struct
    import traceback
    import unittest
    from io import BytesIO
    from collections import namedtuple
    from Crypto.Cipher import AES
    from Crypto.Util import Counter

    from .common import FileDownloader
    from .external import FFmpegFD
    from .fragment import FragmentFD

# Generated at 2022-06-18 13:28:41.891248
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    from .utils import (
        encodeFilename,
        sanitize_open,
    )

    if not can_decrypt_frag:
        print('pycrypto not found. Please install it.')
        return

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a temporary file to store the manifest
    manifest_file = os.path.join(temp_dir, 'manifest.m3u8')

# Generated at 2022-06-18 13:28:52.795580
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..utils import ExtractorError

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.pop('_type', None)

    class FakeIE(InfoExtractor):
        IE_NAME = 'fake'
        _VALID_URL = r'https?://.+'

        def _real_extract(self, url):
            return FakeInfoDict({
                'id': 'fakeid',
                'url': url,
                'ext': 'mp4',
                'title': 'faketitle',
                'is_live': False,
            })


# Generated at 2022-06-18 13:29:00.535934
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri
    from .external import FFmpegFD
    from .fragment import FragmentFD
    from .dash import DashSegmentsFD
    from .hls import HlsFD
    from .http import HttpFD
    from .ism import IsmFD
    from .m3u8 import M3U8FD
    from .rtsp import RtspFD
    from .smoothstreams import SmoothstreamsFD
    from .f4m import F4mFD
    from .rtmp import RtmpFD
    from .scte35 import Scte35FD
    from .srt import SrtFD
    from .ttml import TtmlFD
    from .wvm import WvmFD

    # Test HlsFD.