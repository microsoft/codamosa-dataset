

# Generated at 2022-06-24 11:52:52.734745
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """
    Note: download method used to test HlsFD.real_download
    is a newly added function to YoutubeDL class used only
    in this unittest. It should not be considered as a part
    of the public API and should not be used outside of
    unittests.
    """
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    IE_NAME = 'Test'
    MANIFEST_URL = 'https://test_manifest_url/'

# Generated at 2022-06-24 11:53:04.397716
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def assert_can_download(manifest, info_dict, expected_return_value, message=None):
        assert HlsFD.can_download(manifest, info_dict) == expected_return_value, message

    assert_can_download(
        '#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\n#EXTINF:1\nhttp://example.com/segment1', {}, False,
        'Encrypted streams are not supported')

    assert_can_download(
        '#EXTM3U\n#EXT-X-BYTERANGE:1\n#EXTINF:1\nhttp://example.com/segment1', {}, False,
        'Playlists composed of byte ranges of media files are not supported')


# Generated at 2022-06-24 11:53:14.408408
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download('#EXTM3U', {})
    assert HlsFD.can_download('', {})
    assert not HlsFD.can_download('#', {})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=NONEXISTENT', {})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=NONEXISTENT', {'_decryption_key_url': ''})
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=NONE', {})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {})

# Generated at 2022-06-24 11:53:24.640871
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    import os.path
    from .test_utils import get_testdata_file

    expected_test_data = (
        get_testdata_file('test.m3u8'),
        get_testdata_file('test.ts'),
    )

    for n in range(1, 3):
        from .test_utils import FakeYDL

        ydl = FakeYDL()
        ydl.add_default_info_extractors()

        with ydl._fake_progress_hooks_ctx():
            download_result = HlsFD.can_download(
                open(expected_test_data[0], 'rb').read().decode('utf-8', 'ignore'),
                {'url': 'http://dummy/',
                 'http_headers': {'Cookie': 'dummy'}})



# Generated at 2022-06-24 11:53:36.101649
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .external import F4mFD
    from .dash import DashSegmentsFD

    class FakeYDL(object):
        def __init__(self):
            self.params = {}

    ydl = FakeYDL()
    info_dict = {
        'url': 'http://example.com',
        'http_headers': {},
        'fragment_base_url': 'http://fragment.example.com',
        'fragment_base_path': '/base/fragment',
        'play_path': 'play.path',
        'ext': 'mp4',
        'is_live': False,
        'protocol': 'm3u8',
        '_type': 'multi_fragment',
    }

    assert HlsFD.FD_NAME in FragmentFD.get_supported_prot

# Generated at 2022-06-24 11:53:41.236832
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import youtube_dl.FileDownloader
    import youtube_dl.version
    from .test_utils import FakeYDL

    class FakeInfoDict(dict):
        pass

    class FakeHook(object):
        def __init__(self):
            self.called = False

        def __call__(self, *args, **kwargs):
            self.called = True


# Generated at 2022-06-24 11:53:53.040623
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import codecs
    import tempfile
    import unittest

    class test_HlsFD_cd(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.TemporaryDirectory()
            self.temp_manifest = os.path.join(self.temp_dir.name, 'index.m3u8')
            with codecs.open(self.temp_manifest, 'w', encoding='utf-8') as f:
                f.write('\n')

        def tearDown(self):
            self.temp_dir.cleanup()

        def test_can_download_empty_manifest(self):
            self.assertEqual(HlsFD.can_download('\n', {}), False)


# Generated at 2022-06-24 11:54:05.151139
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .f4m import F4mFD
    info_dict = {}
    assert not HlsFD.can_download('garbage', info_dict)
    assert not HlsFD.can_download('#EXTM3U', info_dict)
    assert HlsFD.can_download('#EXTM3U\n#EXTINF:10,', info_dict)
    assert not HlsFD.can_download('#EXTM3U\n#EXTINF:10,\n#EXT-X-KEY:METHOD=AES-128,URI="https://priv.example.com/key"\nhttp://example.com/fileSequence2680.ts', info_dict)

# Generated at 2022-06-24 11:54:11.621113
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import unittest
    from http.client import HTTPConnection
    from urllib.parse import quote_plus
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.extractor.common import FileDownloader
    from youtube_dl.utils import sanitize_open

    # Create a temporary directory and set TMPDIR env
    HlsFDTest.tempdir = tempfile.mkdtemp()
    os.environ['TMPDIR'] = HlsFDTest.tempdir


# Generated at 2022-06-24 11:54:17.485682
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from . import sanitize_open
    with sanitize_open(__file__) as f:
        t = f.read()
        hlsFD = HlsFD(None, None)
        assert hlsFD.can_download(t, None)


if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 11:54:27.660592
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import make_fake_info_dict

    info_dict = make_fake_info_dict(
        'http://example.com/media.m3u8',
        http_headers={'Range': 'bytes=0-20'})

    def _download_fragment(ctx, frag_url, info_dict, headers):
        assert frag_url == 'http://example.com/dummy.ts'
        assert info_dict['http_headers'] == {'Range': 'bytes=0-20'}
        return (True, b'content')

    hlsfd = HlsFD(None, {'http_chunk_size': 1})
    hlsfd.test = True
    hlsfd._download_fragment = _download_fragment


# Generated at 2022-06-24 11:54:36.646484
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import get_info_extractor
    from ..extractor.generic import GenericIE
    from ..utils import match_filter_func
    from .common import fake_dl
    from .extractor_eq_bak import YouTubeDL
    # Test that the constructor of HlsFD can be called.
    # The actual functionality cannot be tested without external
    # resources.
    dl = fake_dl(dict(url='url', params={}))
    ie = get_info_extractor(GenericIE, {})(dl, {})
    for provider in ie.get_supported_extractors():
        if match_filter_func({'ie_key': [provider.ie_key]}, {}):
            ie = provider(dl, {})
            fd = HlsFD(dl, {})
            fd_func = fd

# Generated at 2022-06-24 11:54:39.167449
# Unit test for constructor of class HlsFD
def test_HlsFD():
    extractor = HlsFD({'test': True}, {})
    assert extractor.FD_NAME == 'hlsnative'


# Generated at 2022-06-24 11:54:49.685670
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE

    # A native HLS download
    with YoutubeIE() as ie:
        ie.extract('hlsnative:https://www.youtube.com/watch?v=jNQXAC9IVRw')

    # A native HLS download with byterange segments
    with YoutubeIE() as ie:
        ie.extract('hlsnative:https://www.youtube.com/watch?v=w7Gqe5b5VdQ')

    # A native HLS download with AES key
    with YoutubeIE() as ie:
        ie.extract('hlsnative:https://www.youtube.com/watch?v=rI_mAonvFP8')

    # A native HLS download with encrypted byte range segments

# Generated at 2022-06-24 11:55:00.637241
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    hlsfd = HlsFD(None, {})

    with open('tests/hls/playlist.m3u8') as playlist:
        assert hlsfd.can_download(playlist.read(), {})

    with open('tests/hls/playlist.m3u8') as playlist:
        assert hlsfd.can_download(playlist.read(), {'is_live': False})

    with open('tests/hls/playlist_live.m3u8') as playlist:
        assert not hlsfd.can_download(playlist.read(), {})

    with open('tests/hls/playlist_live.m3u8') as playlist:
        assert not hlsfd.can_download(playlist.read(), {'is_live': False})


# Generated at 2022-06-24 11:55:08.436632
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import (
        gen_extractors,
        get_extractor_descriptions,
    )

    # Load extractors
    gen_extractors()

    for ie, description in get_extractor_descriptions().items():
        if description['ie_key'] == 'HlsNative':
            ie = ie()
            assert ie._VALID_URL.match('http://test.se/test/test.m3u8')
            assert ie._VALID_URL.match('https://test.se/test/test.m3u8')
            assert not ie._VALID_URL.match('http://test.se/test/test.txt')
            assert not ie._VALID_URL.match('https://test.se/test/test.txt')

# Generated at 2022-06-24 11:55:20.700868
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..utils import std_headers

# Generated at 2022-06-24 11:55:33.220960
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import re
    from .testutils import FakeYDL
    from .extractor import get_info_extractor
    from .common import InfoExtractor

    # Test that can_download returns True when the URL has hls_base_url
    # which is a feature that HlsFD does not support.
    # https://github.com/ytdl-org/youtube-dl/issues/27365
    extractor = get_info_extractor(InfoExtractor.ie_key('npo'))
    ydl = FakeYDL()
    info_dict = {
        'url': 'https://www.npo.nl/uitzending/20200811/JG_446991/VOETBAL-KNVB-Beker-2020-2021-Seizoen',
    }

# Generated at 2022-06-24 11:55:34.525299
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .__main__ import parseoptest
    parseoptest(HlsFD.can_download)
    parseoptest(HlsFD.download)

# Generated at 2022-06-24 11:55:47.389798
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    manifest = '#EXTM3U'

    info_dict = {}

    assert HlsFD.can_download(manifest, info_dict)

    manifest += '\n#EXT-X-KEY:METHOD=AES-128'
    assert not HlsFD.can_download(manifest, info_dict)

    manifest += '\n#EXT-X-BYTERANGE'
    assert not HlsFD.can_download(manifest, info_dict)

    manifest += '\n#EXT-X-MEDIA-SEQUENCE:1'
    assert HlsFD.can_download(manifest, info_dict)

    info_dict['_decryption_key_url'] = 'test'
    assert not HlsFD.can_download(manifest, info_dict)


# Generated at 2022-06-24 11:55:59.827251
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    from .test import get_test_data, MockYDL

    class HlsFDTest(unittest.TestCase):

        def test_real_download(self):
            self.maxDiff = None
            ydl = MockYDL()
            hls_fd = HlsFD(ydl, {})
            # TODO: We do not download fragments until we have the first decryption key
            # because the first fragment has a different initialization vector from the
            # rest (see https://github.com/ytdl-org/youtube-dl/pull/27731). Determine why this
            # is the case and if we can download the first fragment with the correct initialization
            # vector so we can gain the most coverage for this test.
            hls_fd.max_fragments_to_buffer = 1

            test_filename

# Generated at 2022-06-24 11:56:07.060370
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .fragment import FragmentFD

# Generated at 2022-06-24 11:56:09.340839
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import youtube_dl

    ydl = youtube_dl.YoutubeDL()
    hlsfd = HlsFD(ydl, {'hls_prefer_native': True})
    hlsfd.add_progress_hook('test')


if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 11:56:21.844345
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import sys
    # create a fake YDL object
    class FakeYdl:
        def __init__(self):
            self.params = {}
            self.cache = {}
            self.hooks = {}
        def report_warning(self, msg):
            print('WARNING: ' + msg, file=sys.stderr)
        def report_error(self, msg):
            print('ERROR: ' + msg, file=sys.stderr)
        def report_retry_fragment(self, err, frag_index, count, fragment_retries):
            print('INFO: ' + 'Fragment {} error: {}, retrying ({}/{})'.format(frag_index, err, count, fragment_retries), file=sys.stderr)

# Generated at 2022-06-24 11:56:23.281045
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD is not None

test_HlsFD()

# Generated at 2022-06-24 11:56:30.671511
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=NONE', { } ) == True
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=NONE', { 'is_live' : True } ) == False
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=NONE', { 'is_live' : False } ) == True

    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', { } ) == False
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', { '_decryption_key_url' : 'https://key_url' } ) == False

# Generated at 2022-06-24 11:56:41.281377
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:56:51.579368
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import io
    import os
    import tempfile
    try:
        from pyca import openssl
        has_pyca = True
    except ImportError:
        has_pyca = False
    fragment_count = 2

# Generated at 2022-06-24 11:57:04.076118
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    import os

    def _get_script_path():
        return os.path.dirname(os.path.abspath(__file__))

    sys.path.append(_get_script_path() + '/..')
    from youtube_dl.downloader.external import get_bin_version
    from youtube_dl.version import __version__
    import youtube_dl
    import pytest

    class DummyYoutubeDL:
        def __init__(self, *args, **kwargs):
            pass

        def report_warning(self, *args, **kwargs):
            pass

        def to_screen(self, *args, **kwargs):
            return None

        @staticmethod
        def urlopen(*args, **kwargs):
            import io

# Generated at 2022-06-24 11:57:16.013738
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import tempfile
    import shutil
    import sys

    # Create a test folder
    test_folder = tempfile.mkdtemp()

    # Create dummy manifest file
    _, manifest_file_name = tempfile.mkstemp(
        dir=test_folder, suffix='.m3u8')

    def clean_up():
        # Remove the test folder
        shutil.rmtree(test_folder)

    # Unit test for method can_download of class HlsFD
    def test_method(manifest_content, info_dict, result):
        with open(manifest_file_name, 'w+') as manifest_file:
            manifest_file.write(manifest_content)
        hlsfd = HlsFD(None, {})

# Generated at 2022-06-24 11:57:22.566530
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    hlsFD = HlsFD(YDL({'skip_download': True, 'quiet': True}), {'test': True})

    # Download should be allowed if no unsupported features are detected

# Generated at 2022-06-24 11:57:29.573479
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .testmediaurl import parse_mediaurl
    mediaurl = 'https://fake-url.com/playlist.m3u8'
    media_info = parse_mediaurl(mediaurl, 'hlsnative')
    hls_fd = HlsFD(None, None)
    assert isinstance(hls_fd, HlsFD)
    assert media_info.get('format_id') == 'hlsnative'
    assert HlsFD.can_download(media_info['manifest'], media_info)
# end test_HlsFD

# Generated at 2022-06-24 11:57:41.326663
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..downloader import YoutubeDL
    ydl = YoutubeDL()
    url = "https://devimages-cdn.apple.com/samplecode/avfoundationMedia/AVFoundationQueuePlayer_HLS2/master.m3u8"

# Generated at 2022-06-24 11:57:46.289104
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ydl = object()
    params = object()
    hlsfd = HlsFD(ydl, params)
    assert hlsfd.params is params
    assert hlsfd.ydl is ydl

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 11:57:56.570862
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .extractor.hls import HlsIE
    from .extractor import YoutubeIE

    assert HlsFD.can_download('#EXTM3U\n#EXT-X-STREAM-INF:', {'is_live': True})


# Generated at 2022-06-24 11:58:08.431324
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..url import ParsedURL
    from ..utils import encode_data_uri

    media_sequence = 0

    def content_gen(sequence):
        nonlocal media_sequence
        if media_sequence == sequence:
            media_sequence += 1
            return b'content'
        raise compat_urllib_error.HTTPError(
            ParsedURL('http://www.example.com/'),
            404, 'HTTP Error', {}, None)

    def urlopen_mock(ctx, url, data=None, timeout=None, headers=None):
        if url.host == 'test':
            return ParsedURL('data:' + encode_data_uri(content_gen(media_sequence))), url

# Generated at 2022-06-24 11:58:19.049505
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download("#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:2.160,\nlo000001.ts\n#EXTINF:2.160,\nlo000002.ts\n#EXT-X-ENDLIST", {"url": "test", "is_live": False})
    assert not HlsFD.can_download("#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:2.160,\nlo000001.ts\n#EXTINF:2.160,\nlo000002.ts\n#EXT-X-ENDLIST", {"url": "test", "is_live": True})

# Generated at 2022-06-24 11:58:27.166789
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Test 1: media segments may be appended to the end of event media playlists
    test_input_1 = '''
#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:8
#EXT-X-PLAYLIST-TYPE:EVENT
#EXTINF:7.975,
http://media.example.com/entire.ts
#EXTINF:7.941,
http://media.example.com/entire1.ts
#EXTINF:7.975,
http://media.example.com/entire2.ts
#EXT-X-ENDLIST
    '''
    assert HlsFD.can_download(test_input_1, {})

    # Test 2: playlists composed of byte ranges of media files

# Generated at 2022-06-24 11:58:38.007630
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import pytest

    from .extractor.common import InfoExtractor
    from ..utils import UnsupportedError
    from ..compat import compat_urlparse

    # Tests the can_download method of class HlsFD, using info_dicts
    # produced by different InfoExtractors.

    # REMINDER:
    # HlsFD supports:
    #   - encrypted streams (AES-128)
    #   - media segments not composed of contiguous ranges
    #   - event playlists
    #   - media initialization (only with media segments not composed
    #     of contiguous ranges)
    #   - both absolute and relative urls
    #
    # HlsFD does NOT support:
    #   - encrypted streams (METHOD=NONE, AES-128, )
    #   - media segments composed of contiguous ranges within a media
    #     file


# Generated at 2022-06-24 11:58:45.917731
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:58:51.272099
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest
    import copy
    import ydl_test
    from youtube_dl.extractor import YouTubeIE
    from youtube_dl.options import YoutubeDL
    class HlsFDTester(HlsFD):
        def real_download(self, filename, info_dict):
            return True
    exp_test = HlsFDTester(None, YoutubeDL(ydl_test.params))

# Generated at 2022-06-24 11:59:01.270000
# Unit test for constructor of class HlsFD
def test_HlsFD():
    class DummyYDL():
        def to_screen(self, message):
            pass


# Generated at 2022-06-24 11:59:12.764194
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from datetime import datetime

    class MockYDL(object):
        def __init__(self):
            self.urlopen_calls = []

        def urlopen(self, url):
            self.urlopen_calls.append(url)

            class MockUrlopen(object):
                def read(self):
                    return b''

                def geturl(self):
                    return url

            return MockUrlopen()

    ydl = MockYDL()

# Generated at 2022-06-24 11:59:23.304681
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from io import BytesIO
    from ..utils import (
        compat_urllib_error,
        DownloadError,
    )

    class YDL:
        class params:
            daterange = None
            test = True
            test_source_duration = 3.0
            test_source_size = 1024

        def __init__(self, *args, **kwargs):
            self.params = self.__class__.params()
            self.params.update(kwargs)
            self.test_source_content_len_written = 0
            self.test_source_content_len_read = 0
            self.test_source_content_len_off_read = 0
            self.test_source_content_len_off_written = 0

        def to_screen(self, msg):
            pass


# Generated at 2022-06-24 11:59:31.242265
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def check_can_download(manifest, **kwargs):
        return HlsFD.can_download(manifest, kwargs)

    def can_download_test(test_input, test_output):
        assert check_can_download(test_input['manifest'], **test_input['ydl_kwargs']) == test_output

    yield can_download_test, {'manifest': '#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\n', 'ydl_kwargs': {}}, True
    yield can_download_test, {'manifest': '#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="https://example.com/key.bin"\n', 'ydl_kwargs': {}}, True
    yield can_download_

# Generated at 2022-06-24 11:59:39.631370
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..postprocessor.ffmpeg import FFmpegPostProcessor
    from ..postprocessor.ffmpeg import FFmpegExtractAudioPP
    from ..postprocessor.ffmpeg import FFmpegMetadataPP

    url = 'https://example.com/manifest.m3u8'

    ie = InfoExtractor(FileDownloader())
    ie.add_info_extractor(FFmpegPostProcessor.ie_key())
    ie.add_info_extractor(FFmpegExtractAudioPP.ie_key())
    ie.add_info_extractor(FFmpegMetadataPP.ie_key())
    ie.add_info_extractor(HlsFD.ie_key())


# Generated at 2022-06-24 11:59:49.953696
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import sys

    reload(sys)
    sys.setdefaultencoding('utf8')


# Generated at 2022-06-24 11:59:57.242694
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..compat import compat_urllib_request, compat_urlparse
    from ..utils import url_basename, urljoin

    # HTTP server to test HLS streams
    class TestServerHandler(compat_urllib_request.BaseHTTPRequestHandler):

        def do_GET(self):
            # check if URI matches the test pattern
            url_parts = compat_urlparse.urlparse(self.path)
            url_parts_path = url_parts.path.split('/')
            if len(url_parts_path) < 4:
                self.send_response(400)
                self.end_headers()
                return

# Generated at 2022-06-24 12:00:08.731670
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os.path
    import tempfile
    import youtube_dl.utils
    import json

    class MockYDL():
        def report_error(self, msg, tb=None):
            raise youtube_dl.utils.DownloadError(msg)

        def trouble(self, msg, tb=None):
            raise youtube_dl.utils.DownloadError(msg)

        def report_warning(self, msg):
            print('WARNING: %s' % msg)

        def to_screen(self, msg):
            print(msg)

        def urlopen(self, url, data=None, retries=None, headers={}):
            class MockResponse():
                def __init__(self, text, geturl):
                    self.text = text
                    self.geturl = geturl
                    self.url = geturl()

# Generated at 2022-06-24 12:00:16.953694
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import Downloader
    from .options import Options

    opts = Options()
    opts.logger = None
    opts.proxy = None
    opts.no_check_certificate = True
    opts.hls_prefer_native = True
    opts.hls_prefer_ffmpeg = False
    dl = Downloader(opts)

    # This manifest is intentionally set up to have many unsupported HLS features (see https://github.com/ytdl-org/youtube-dl/pull/27660).

# Generated at 2022-06-24 12:00:25.409364
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """Tests the class with a demo video and checks if the number of fragments
    is correct."""
    import json
    import os
    import sys
    sys.path.append(os.getcwd())

    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.hls import HlsFD

    ydl = YoutubeDL({})

    # load test data
    with open(os.path.join(os.path.dirname(__file__), 'testdata',
                           'hls_test.json'), 'r') as f:
        test_cases = json.load(f)

    for tc in test_cases:
        fd = HlsFD(ydl, {'test': True, 'skip_fragments': True})
        # disable stdout to avoid flooding when running the script multiple times

# Generated at 2022-06-24 12:00:36.804719
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        from Crypto.Cipher import AES
        can_decrypt_frag = True
    except ImportError:
        can_decrypt_frag = False


# Generated at 2022-06-24 12:00:49.557153
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    from .test import get_testdata_files_dir, make_mock_ydl

    @staticmethod
    def _mock_download_fragment(ctx, frag_url, info_dict, http_headers):
        HlsFD_real_download__frag_url = frag_url
        frag_content = open(
            os.path.join(get_testdata_files_dir(), 'hls_frag.ts'), 'rb').read()
        ctx['total_frags'] = 1
        ctx['fragment_index'] = 1
        ctx['filename'] = tempfile.mktemp(dir=os.path.expanduser('~'), suffix='.ts')
        return (True, frag_content)

    ydl = make_mock_ydl()


# Generated at 2022-06-24 12:01:03.932824
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import youtube_dl.YoutubeDL

    # Use the same downloader class instance to make sure that the download_fragment()
    # method is ran exactly once.
    ydl_opts = {
        'skip_download': True,
        'quiet': True,
        'hls_use_mpegts': True,
        'outtmpl': os.path.join(tempfile.gettempdir(), '%(id)s.%(ext)s'),
        'format': 'bestaudio',
    }
    ydl = youtube_dl.YoutubeDL(ydl_opts)

    class MyHlsFD(HlsFD):
        def _prepare_url(self, info_dict, url):
            return url


# Generated at 2022-06-24 12:01:11.485465
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """This method is not a test. It is a harness that can be used to
    test the real_download method of class HlsFD. An alternative to running
    unit tests using PyUnit.
    """
    from .youtube import YoutubeFD
    from ..downloader import YoutubeDL


# Generated at 2022-06-24 12:01:22.475715
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..downloader.common import FileDownloader


# Generated at 2022-06-24 12:01:27.746026
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import io
    foo = io.StringIO()

    # hlsnative can download
    foo.write(u'#EXTM3U\n#EXT-X-TARGETDURATION:10\n'
              u'#EXTINF:10,\nhttps://example.com/video1.ts\n#EXT-X-ENDLIST\n')
    foo.seek(0)
    assert HlsFD.can_download(foo.read(), {'url': 'https://example.com/index.m3u8'}) is True

    # ffmpeg should download
    foo.seek(0)
    foo.truncate()

# Generated at 2022-06-24 12:01:28.775461
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, None)

# Generated at 2022-06-24 12:01:40.630460
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from youtube_dl.downloader.youtube_dl import YoutubeDL
    from youtube_dl.utils import DateRange
    from .external import ExternalFD
    from .fragment import FragmentFD
    assert issubclass(HlsFD, FragmentFD)
    assert not issubclass(HlsFD, ExternalFD)

    # Download hls video
    ydl_opts = {
        'logger': YoutubeDL(ydl_opts={}).logger,
        'skip_download': True,
        'geo_bypass': True,
        'outtmpl': 'test-outtmpl',
        'date': '20160101',
        'time_range': DateRange(None, '12:30'),
        'test': True,
        'keepvideo': True,
        'quiet': True,
    }

   

# Generated at 2022-06-24 12:01:48.829583
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # We need to mock the ytdl object since it's not passed during initialization
    from collections import namedtuple
    from .external import FFmpegFD
    from .fragment import FragmentFD
    from .dash import DashFD
    test_params = {
        'format': 'bestvideo[protocol^=http]+bestaudio[protocol^=http]'
    }
    ytdl = namedtuple('YoutubeDL', ['params'])(test_params)
    test_url = 'http://example.com'
    # FragmentFD asserts that it is not used
    ffmpeg_fd = FFmpegFD(ytdl, test_params)
    fragment_fd = FragmentFD(ytdl, test_params)
    dash_fd = DashFD(ytdl, test_params)
    # Valid HLS stream fragment FD


# Generated at 2022-06-24 12:01:49.877090
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD



# Generated at 2022-06-24 12:01:56.123446
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import YoutubeDL
    from .extractor import YoutubeIE
    import sys

    sys.argv = ['youtube-dl']

    # Make the retries option global
    YoutubeDL.params['fragment_retries'] = 100
    YoutubeDL.params['retries'] = 100
    YoutubeDL.params['test'] = True


# Generated at 2022-06-24 12:02:07.448516
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 12:02:15.213084
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Var:man_url, type:str
    man_url = 'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8'
    # Var:info_dict, type:dict
    info_dict = {'url': man_url}
    # Var:fd, type:HlsFD
    fd = HlsFD(None, {})
    # Var:ret, type:bool
    ret = fd.can_download(info_dict)
    assert(ret == True)
    # Var:ret, type:bool
    ret = fd.real_download('test.ts', info_dict)
    assert(ret == True)
    # Var:ret, type:bool

# Generated at 2022-06-24 12:02:22.878029
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    print('Testing HlsFD.can_download')
    class DummyInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(DummyInfoDict, self).__init__(*args, **kwargs)
            self['is_live'] = False

# Generated at 2022-06-24 12:02:34.971219
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test_downloads import (
        get_testdata_file,
        check_files,
    )
    from .test_downloads import (
        print_test_data,
    )
    from .test_downloads import get_dict_from_url
    import os

    file = get_testdata_file('hls_frag.m3u8')
    url = 'file:' + file
    print
    print_test_data('hls_frag.m3u8', url)
    url_data = get_dict_from_url(url)
    # This is the first fragment so only the first fragment should be downloaded
    url_data['ytdl_options']['test'] = True

    class DummyYDL():
        def __init__(self, params):
            self.params = params

# Generated at 2022-06-24 12:02:42.968810
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import tempfile

    from ..extractor import get_info_extractor
    from ..downloader import get_suitable_downloader
    from ..downloader.http.httpfd import HttpFD
    from ..postprocessor import run_postprocessors

    def _run_downloader(info_dict, params):
        postprocessors = params.get('postprocessors', None)
        if postprocessors is not None:
            params = params.copy()
            del params['postprocessors']

        downloader = get_suitable_downloader(info_dict, params)
        if downloader is None:
            sys.exit(1)