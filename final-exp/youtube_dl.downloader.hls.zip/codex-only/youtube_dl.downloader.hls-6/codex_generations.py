

# Generated at 2022-06-24 11:52:52.412963
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass
    """
    # Preconditions:
    import youtube_dl
    # The following call should succeed (download just the first fragment)
    url = 'https://www.youtube.com/watch?v=NcO414zFkIk'
    result = youtube_dl.YoutubeDL(youtube_dl.utils.std_headers).extract_info(
        url, download=False)
    # Postconditions:
    assert True # should not fail
    """

# Generated at 2022-06-24 11:53:03.582467
# Unit test for constructor of class HlsFD
def test_HlsFD():
    class MockYdl:
        def urlopen(self, url):
            res = url.split('?')[0]
            return MockUrl(res)
    class MockUrl:
        def __init__(self, res):
            self.res = res
        def geturl(self):
            return self.res
        def read(self):
            return {}
    class MockParams:
        def __init__(self):
            self.fragment_retries = 0
            self.skip_unavailable_fragments = True
            self.test = True

    params = MockParams()
    ydl = MockYdl()
    hls = HlsFD(ydl, params)
    assert isinstance(hls, HlsFD)


# Generated at 2022-06-24 11:53:13.843407
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .downloader import get_suitable_downloader
    from .external import FFmpegFD
    url = 'http://videolive.rtl.fr/rtl2/smil:rtl2.smil/playlist.m3u8'
    info_dict = {
        'url': url,
        'title': '[unspecified]',
        'ext': 'mp4',
        'http_headers': {},
        '_type': 'hls',
        'protocol': 'm3u8'
    }
    downloader = get_suitable_downloader(info_dict)
    assert(isinstance(downloader, HlsFD) or isinstance(downloader, FFmpegFD))


# Generated at 2022-06-24 11:53:15.084150
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert isinstance(HlsFD(None, {}), HlsFD)

# Generated at 2022-06-24 11:53:15.751023
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD()

# Generated at 2022-06-24 11:53:25.677510
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Tests with fragments
    can_download_all = True
    manifest = '#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10\nmedia_segment_1.ts\n#EXTINF:10\nmedia_segment_2.ts\n#EXT-X-ENDLIST\n'
    is_aes128_enc = '#EXT-X-KEY:METHOD=AES-128' in manifest
    can_download_all = can_download_all and can_decrypt_frag or not is_aes128_enc
    assert(can_download_all)

    # Tests without fragments
    can_download_all = True

# Generated at 2022-06-24 11:53:37.381876
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Import pytest here to avoid import and package problems
    import pytest

    from ..extractor.common import InfoExtractor

    class MockInfoExtractor(InfoExtractor):
        def get_info(self, url):
            return {
                'url': url,
                '_decryption_key_url': 'http://local.com/key',
                'http_headers': {
                    'Test-Header': 'value',
                },
                'extractor': 'youtube',
            }

    class MockYoutubeDl(object):
        def __init__(self):
            self._ie = None

        def add_info_extractor(self, ie):
            self._ie = ie

        def extract_info(self, url, download=False):
            return self._ie._real_extract(url)


# Generated at 2022-06-24 11:53:49.220533
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.generic import GenericIE
    from .dashsegments import SegmentFD

    FD_NAME = 'dashsegments'


# Generated at 2022-06-24 11:53:57.930207
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..utils import match_filter_func
    from ..downloader import DummyDownloader

    ydl = DummyDownloader()
    ydl.add_info_extractor(YoutubeIE(ydl))
    ydl.params['noplaylist'] = True
    ydl.extract_info('https://www.youtube.com/playlist?list=PLM3SHQv_oj0t89-ZtGljKdYRfRt0nEWzR', download=False)

    # Test that HlsFD can accept a youtube playlist
    hls_formats = match_filter_func('hlsnative', ydl.formats)
    info_dict = ydl.extractor._get_info_extractor()._match_entry(hls_formats[0])
   

# Generated at 2022-06-24 11:54:10.181560
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:54:19.798160
# Unit test for constructor of class HlsFD
def test_HlsFD():
    filename = 'x'
    class FakeYDL:
        def urlopen(self, url):
            class FakeURLH:
                def geturl(self):
                    return url
                def read(self):
                    return ''
            return FakeURLH()

        def report_warning(self, msg):
            pass

        def to_screen(self, msg):
            pass

    hf = HlsFD(FakeYDL(), {'test': True})
    assert hf.real_download(filename, {'url': 'url', 'is_live': False, 'http_headers': {}})

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 11:54:32.800572
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():

    from ..utils import encode_data_uri
    from .testutils import FakeYDL
    import tempfile
    import os
    import re
    from .downloader import get_suitable_downloader

    with tempfile.NamedTemporaryFile(mode='w+') as f:
        ydl = FakeYDL({'noprogress': False, 'quiet': True})
        dl = get_suitable_downloader(ydl, {'url': encode_data_uri('hls', M3U8_MANIFEST), 'test': True})

        dl.real_download(f.name, {'url': ''})

        # The content of the first fragment should be equal to the one in the data URI (see below)
        assert 'abcdef' == open(f.name, 'rb').read()


# Generated at 2022-06-24 11:54:34.559472
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
  # Test some attributes that are present in hls-media-segments.m3u8
  return True


# Generated at 2022-06-24 11:54:36.226295
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # For now just test that it does not crash
    HlsFD(None, {})



# Generated at 2022-06-24 11:54:46.558007
# Unit test for constructor of class HlsFD
def test_HlsFD():
    if __name__ != '__main__':
        return

    from ..downloader import YoutubeDL
    ydl = YoutubeDL({'quiet': True, 'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_progress_hook(lambda d: print(d.get('status', d.get('filename', '')), end=' , '))
    ydl.add_default_info_extractors()
    ydl.process_ie_result(ydl.extract_info(
        'https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_adv_example_hevc/bipbop_adv_example_hevc.m3u8',
        False))

# Generated at 2022-06-24 11:54:57.853362
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    """Unit test for method can_download of class HlsFD."""
    def check_HlsFD_can_download(m3u8, is_live=False, extra_param_to_segment_url=None, _decryption_key_url=None):
        info_dict = {}
        info_dict['url'] = 'video.m3u8'
        info_dict['http_headers'] = {}
        info_dict['is_live'] = is_live
        if extra_param_to_segment_url:
            info_dict['extra_param_to_segment_url'] = extra_param_to_segment_url
        if _decryption_key_url:
            info_dict['_decryption_key_url'] = _decryption_key_url


# Generated at 2022-06-24 11:54:58.300124
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass

# Generated at 2022-06-24 11:55:06.237159
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def can_download(manifest, info_dict, is_live, result):
        class TestInfoDict(dict):
            def __init__(self, is_live):
                self['is_live'] = is_live

        return result == HlsFD.can_download(manifest, TestInfoDict(is_live))
    assert can_download(
        manifest='#EXTM3U\n#EXT-X-KEY:METHOD=NONE\n#EXTINF:10,\nfrag1.ts',
        info_dict=False,
        is_live=False,
        result=True
    )

# Generated at 2022-06-24 11:55:19.183686
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import json
    from .test import get_test_data
    from .common import InfoExtractor
    from .extractor import YoutubeIE

    testdata = get_test_data(YoutubeIE.ie_key(), 'hls')
    info = InfoExtractor().extract_info(YoutubeIE.ie_key(), testdata['id'])

    hlsfd = HlsFD(InfoExtractor({}), {})

    # Test when test=True
    hlsfd.params['test'] = True
    assert hlsfd.real_download('filename', info['formats'][0])

    # Test when test=False
    hlsfd.params['test'] = False
    hlsfd.params['fragment_retries'] = 0
    assert hlsfd.real_download('filename', info['formats'][0])

# Generated at 2022-06-24 11:55:27.372742
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import tempfile
    import unittest
    import youtube_dl.ie

    tmpfd, tmpfn = tempfile.mkstemp(prefix='youtube-dl-test-')

    def do_can_download_test(m3u8_data, info_dict, expected_can_download):
        file_ = os.fdopen(tmpfd, 'w')
        file_.write(m3u8_data)
        file_.close()
        tmp_info_dict = dict(**info_dict)
        tmp_info_dict['url'] = 'file:' + tmpfn
        actual_can_download = youtube_dl.ie.HlsFD.can_download(None, tmp_info_dict)
        os.unlink(tmpfn)
        return actual_can_download == expected_can_download

    info_dict = {}


# Generated at 2022-06-24 11:55:34.105741
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import sys
    import os
    import tempfile
    from urllib.request import urlopen
    from .http import HttpFD

    class TestHlsFD(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.fd = HlsFD(None, {})

        def tearDown(self):
            for f in os.listdir(self.tmpdir):
                os.remove(os.path.join(self.tmpdir, f))
            os.rmdir(self.tmpdir)


# Generated at 2022-06-24 11:55:47.043722
# Unit test for constructor of class HlsFD

# Generated at 2022-06-24 11:55:53.556082
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from . import YoutubeDL
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .downloader.common import FileDownloader
    from .extractor.test_test_youtube_com import FakeYDL

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, youtube_ie):
            self._ie = youtube_ie
            super(FakeInfoExtractor, self).__init__(YoutubeDL(params={}))

        def _real_extract(self, url):
            return self._ie._real_extract(url)


# Generated at 2022-06-24 11:55:55.546907
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD({}, {})

# Generated at 2022-06-24 11:56:04.684391
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def _assert_can_download(s, live, extra_param_to_segment_url, decryption_key_url):
        assert HlsFD.can_download(
            s, {
                'url': '',
                'is_live': live,
                'extra_param_to_segment_url': extra_param_to_segment_url,
                '_decryption_key_url': decryption_key_url,
            })

    # Playlists with these features are not supported.
    # Live streams are not supported.

# Generated at 2022-06-24 11:56:10.124847
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest

    class TestHlsFD_can_download(unittest.TestCase):

        def test_can_download_1(self):
            self.assertTrue(HlsFD.can_download('', {'is_live': False}))

        def test_can_download_2(self):
            self.assertTrue(HlsFD.can_download('#EXT-X-MEDIA-SEQUENCE:0', {'is_live': False}))

        def test_can_download_3(self):
            self.assertFalse(HlsFD.can_download('#EXT-X-TARGETDURATION:60', {'is_live': False}))


# Generated at 2022-06-24 11:56:22.606740
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .external import FFmpegFD
    from .fragment import FragmentFD
    import sys

    class DummyYDL:
        def __init__(self):
            self.params = {}

    class DummyFD(FragmentFD):
        @staticmethod
        def can_download(manifest, info_dict):
            return True

    _, frag_manifest = sys.modules[__name__].__dict__['test__download_fragment'](test=True)
    _, dash_manifest = sys.modules[__name__].__dict__['test__download_fragment'](test=True, dash=True)


# Generated at 2022-06-24 11:56:30.303913
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import sys
    import os
    import json
    from .testutil import TestDownloader
    from .testutil import read_file_as_text

    def create_hls_manifest(lines):
        with open('data/test/hls_fd/manifest.m3u8', 'w') as f:
            f.write('\n'.join(lines))

    def setUp():
        if sys.version_info.major >= 3:
            return
        if not os.path.exists('data/test/hls_fd'):
            os.makedirs('data/test/hls_fd')

    def tearDown():
        if sys.version_info.major >= 3:
            return
        if os.path.exists('data/test/hls_fd'):
            import shutil
            shut

# Generated at 2022-06-24 11:56:31.333444
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD()


# Generated at 2022-06-24 11:56:41.719811
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import nose.tools
    import json

    # Success cases.
    # TODO(VP): Add some real test cases.

    # All conditions are true.
    m3u8_content = '#EXTM3U\nfoo'
    info_dict = {}
    assert HlsFD.can_download(m3u8_content, info_dict)

    # Failure cases.
    # All conditions are false.
    m3u8_content = '#EXT-X-KEY:METHOD=AES-128\n#EXT-X-BYTERANGE:100\nfoo'
    info_dict = {}
    assert not HlsFD.can_download(m3u8_content, info_dict)

    # At least one condition is false.

# Generated at 2022-06-24 11:56:42.629868
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert FFmpegFD(None, [])

# Generated at 2022-06-24 11:56:52.393708
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    class HlsFD_real_download(unittest.TestCase):
        PASSTHROUGH_TESTS = [
            # No need to run these tests on the native implementation.
            'test_extract_non_hls',
            'test_extract_hls_variant',
            'test_extract_hls_variants',
            'test_extract_hls_variant_url',
            'test_extract_hls_live',
            'test_extract_hls_with_netrc',
            'test_extract_hls_with_cookies',
            'test_extract_hls_with_geo_restriction',
            'test_extract_hls_native_encryption',
        ]

# Generated at 2022-06-24 11:56:58.772722
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .http import HttpFD
    from .test import _download_webpage
    from .youtube import YoutubeFD
    from .fragment import FragmentFD
    from .external import FFmpegFD
    from .dash import DashFD

    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    from ..utils import encode_data_uri

    class _HlsFD(HlsFD):
        def _download_fragment(self, ctx, frag_url, info_dict, headers):
            return True, self.ydl.urlopen(
                self._prepare_url(info_dict, frag_url), headers=headers).read()

        def _prepare_frag_download(self, ctx):
            self.downloaded_frags = []
            self.filepath = ctx

# Generated at 2022-06-24 11:57:07.550535
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    HlsFD.can_download(r'#EXTM3U', {'is_live': True}) == False
    HlsFD.can_download(r'#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {'_decryption_key_url': ''}) == True
    HlsFD.can_download(r'#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {}) == False
    HlsFD.can_download(r'#EXTM3U\n#EXT-X-BYTERANGE:121090@912', {}) == False

# Generated at 2022-06-24 11:57:18.088900
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..utils import encode_data_uri
    import json

# Generated at 2022-06-24 11:57:27.881474
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-TARGETDURATION:10\n'
        '#EXT-X-VERSION:3\n'
        '#EXT-X-MEDIA-SEQUENCE:0\n'
        '#EXT-X-PLAYLIST-TYPE:VOD\n'
        '#EXTINF:10,\n'
        'https://example.com/0.ts',
        {
            # 'http_headers': {
            #    'Range': 'bytes=4200-4279',
            # },
        }
    )



# Generated at 2022-06-24 11:57:39.532953
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:57:50.752152
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # This test was created for https://github.com/ytdl-org/youtube-dl/pull/27660.
    # We are testing that the correct data is downloaded to the correct file path.
    class FakeFile(object):
        def __init__(self, filename):
            self.filename = filename
            self.data = []

        def write(self, data):
            self.data.append(data)

        def flush(self):
            pass

    class FakeYDL(object):
        def __init__(self):
            self.subtitles = {}

        def to_screen(self, s):
            pass

        def to_stdout(self, s):
            pass

        def to_stderr(self, s):
            pass


# Generated at 2022-06-24 11:57:59.667458
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .tests import FakeYDL
    from .extractor.generic import GenericIE

    # Create a fake YouTubeDL object
    ydl = FakeYDL()
    ydl.add_info_extractor(GenericIE())

    # Set the parameters for the test
    params = {
        'format': 'bestaudio/best',
        'noplaylist': True,
        'outtmpl': '%(id)s.%(ext)s',
        'quiet': True,
        'skip_download': True,
        'subtitleslangs': 'en',
        'writesubtitles': True,
    }

    # Get the info dict
    url = 'http://www.youtube.com/watch?v=fNMEreo-LUc'
    ie = GenericIE()

# Generated at 2022-06-24 11:58:05.416419
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import sys
    import os

    test_dir = os.path.dirname(sys.argv[0])
    tests_dir = os.path.dirname(test_dir)
    root_dir = os.path.dirname(tests_dir)
    sys.path.append(root_dir)
    from youtube_dl.YoutubeDL import YoutubeDL


# Generated at 2022-06-24 11:58:14.684108
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .common import FakeYDL
    from .extractor.test.test_common import test_can_download
    ydl = FakeYDL()
    ydl.add_info_extractor('hlsnative', HlsFD)
    ydl.add_info_extractor('hlsnative', HlsFD)
    ydl.add_info_extractor('hlsnative', HlsFD)
    ydl.add_info_extractor('hlsnative', HlsFD)
    ydl.add_info_extractor('hlsnative', HlsFD)
    test_can_download(ydl, 'hlsnative')
    test_can_download(ydl, 'hlsnative_file')

# Generated at 2022-06-24 11:58:24.617064
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..utils import same_site_urls
    ie = InfoExtractor("hlsnative-youtube")
    # Youtube VOD
    ie._download_webpage = lambda *a: (None, None)    # Avoid download

# Generated at 2022-06-24 11:58:35.864832
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import io
    import sys
    import os.path
    ydl = HlsFD._create_ytdl_instance()
    ydl.params['simulate'] = True

# Generated at 2022-06-24 11:58:44.317508
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .hls import HlsFD
    # test_can_download
    # test_can_download_m3u8

# Generated at 2022-06-24 11:58:51.426042
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    manifest = (
        '#EXTM3U\n'
        '#EXT-X-PLAYLIST-TYPE:VOD\n'
        '#EXT-X-MEDIA-SEQUENCE:0\n'
        '#EXT-X-VERSION:3\n'
        '#EXT-X-TARGETDURATION:10\n'
        '#EXTINF:10.000000,\n'
        '/hls/SEG0001.ts\n'
        '#EXT-X-ENDLIST\n')

    class InfoDict:
        pass

    info_dict = InfoDict()
    info_dict.is_live = False
    assert HlsFD.can_download(manifest, info_dict) == True

    manifest += ('#EXT-X-KEY:METHOD=NONE\n')
    info

# Generated at 2022-06-24 11:58:57.640358
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def assert_can_download(manifest, expected_result, is_live=False, extra_param_to_segment_url=None,
                            _decryption_key_url=None):
        info_dict = {'is_live': is_live}
        if extra_param_to_segment_url:
            info_dict['extra_param_to_segment_url'] = extra_param_to_segment_url
        if _decryption_key_url:
            info_dict['_decryption_key_url'] = _decryption_key_url
        assert HlsFD.can_download(manifest, info_dict) == expected_result


# Generated at 2022-06-24 11:59:05.090791
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..extractor import YoutubeIE

    class MyInfoExtractor(InfoExtractor):
        _VALID_URL = r''
        IE_NAME = ''

        def __init__(self, ie_name, downloader=None):
            self._downloader = downloader
            InfoExtractor.__init__(self, ie_name)

        @property
        def IE_DESC(self):
            return 'IE_DESC'

        def _real_extract(self, url):
            return

    ie = MyInfoExtractor(YoutubeIE.ie_key())
    ie.extractor._downloader = [
        {'youtube_ie': 'Youtube'},
        {'hlsnative': 'Hls'},
    ]
    ie._downloader = ie.extractor

# Generated at 2022-06-24 11:59:16.364139
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def can_download(manifest, info_dict):
        return HlsFD.can_download(manifest, info_dict)


# Generated at 2022-06-24 11:59:25.600678
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .fake_filesystem_unittest import FakeFilesystemUnitTest
    from .fake_downloader import FakeDownloader
    from ..extractor.http import HttpFD

    downloader = FakeDownloader()


# Generated at 2022-06-24 11:59:36.645314
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .utils import cmd_quote
    from .test_utils import download_media
    from .make_m3u8_test_data import test_unsupported_features, test_supported_features

    for features, expected_result in (
            (test_unsupported_features(), False),
            (test_supported_features(), True),
    ):
        downloader = download_media(
            {
                'url': 'https://example.com/',
                'ext': 'mp4',
                'protocol': 'hls',
            },
            additional_stream_infos=[{'m3u8': features}],
        )
        assert downloader.result['hlsnative']['success'] == expected_result, (
            'Incorrect result when downloading HLS with the following features: %s' % cmd_quote(features))

# Generated at 2022-06-24 11:59:39.572224
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'hls_prefer_native': True})
    fd = HlsFD(ydl, {})
    output = fd.can_download('https://www.example.com/file.m3u8', {})
    assert(output is True)

# Generated at 2022-06-24 11:59:44.338498
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """ Unit test for method real_download of class HlsFD """
    from ..downloader import FileDownloader
    from ..utils import prepend_extension
    from .fragment import FragmentFD

    url = 'https://mnmedias.api.telequebec.tv/m3u8/29880.m3u8'

    params = {
        'format': 'bestvideo+bestaudio/best',
        'ignoreerrors': True,
        'nooverwrites': True,
        'test': True,
    }

    FileDownloader(params).add_info_extractor(lambda ie_id: ie_id == 'HlsFD')

    filename = prepend_extension(params['outtmpl'], 'test_HlsFD_real_download')

# Generated at 2022-06-24 11:59:58.473999
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .utils import make_fake_man
    manifest = make_fake_man()
    manifest['url'] = None
    manifest['hls_info']['is_live'] = False
    assert not HlsFD.can_download(manifest['hls_info']['manifest'], manifest['hls_info'])
    manifest['hls_info']['manifest'] = manifest['hls_info']['manifest'].replace(
        'METHOD=NONE', 'METHOD=AES-128')
    assert not HlsFD.can_download(manifest['hls_info']['manifest'], manifest['hls_info'])

# Generated at 2022-06-24 12:00:08.901441
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os.path
    import unittest
    import warnings

    sys.path.append(os.path.dirname(__file__))
    import test_data

    class Test_HlsFD_real_download(unittest.TestCase):
        def test_real_download_masterplaylist_entry(self):
            # masterplaylist, no EXT-X-KEY, no EXT-X-BYTERANGE, no is_live
            test_url = 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8'
            ydl_opts = {
                'format': 'bestaudio/mp3/m4a/best',
            }

# Generated at 2022-06-24 12:00:17.145369
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import json
    import shutil

    from .test import get_testdata_files_path, get_test_filename, get_temp_filename

    from ..downloader.common import FileDownloader

    from .external import FFmpegFD

    test_filenames = [
        'hls/hls_concat_frags_aes128_g1_0.m3u8',
        'hls/hls01.m3u8',
    ]

    # We use here ffmpegfragment as it is a quick test only requiring
    # the m3u8 to be downloaded and not the fragments
    FFmpegFD.can_download = lambda *args: True

    def _download_and_compare(fd_class, raw_fd, test_filename, tmp_fd, test_info):
        dl

# Generated at 2022-06-24 12:00:22.667987
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    manifest = """
#EXTM3U
#EXT-X-VERSION:3
#EXT-X-MEDIA-SEQUENCE:0
#EXT-X-TARGETDURATION:10
#EXTINF:10.000000,
#EXT-X-KEY:METHOD=AES-128,URI="https://priv.example.com/key.php?r=52"
https://example.com/fileSequence52-1.ts
#EXTINF:10.000000,
https://example.com/fileSequence52-2.ts
#EXTINF:1.000000,
https://example.com/fileSequence52-3.ts"""

    # Testing a manifest with plain-text segments

# Generated at 2022-06-24 12:00:25.167360
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, {})

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 12:00:36.595440
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest

    import tempfile
    import shutil
    import zipfile
    import os.path
    import sys

    class HlsFDTestCase(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_outfile = os.path.join(self.test_dir, 'outfile')

        def tearDown(self):
            shutil.rmtree(self.test_dir)

        def test_non_encrypted(self):
            out_file = self.test_outfile
            with zipfile.ZipFile(
                    'youtube_dl/extractor/data/non_encrypted_fragments_test.zip') as testdata_zip:
                testdata_zip.extractall(self.test_dir)

            sys

# Generated at 2022-06-24 12:00:45.632587
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..compat import compat_unittest
    from ..extractor import youtube_dl
    from .external import FFmpegFD

    from .external_downloader_test import ExternalFDTestMixin, FakeYDL
    from .generic_downloader_test import GenericFDTestMixin

    class TestHlsFD(FakeYDL, GenericFDTestMixin, ExternalFDTestMixin,
                    compat_unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            super(TestHlsFD, cls).setUpClass()
            cls.downloaded_file = cls.temp_ytdl.gettempfilename('downloaded_file')

        def setUp(self):
            super(TestHlsFD, self).setUp()

# Generated at 2022-06-24 12:00:53.950633
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    """
    A limited test that only checks the constraint of AES-128 method.
    """


# Generated at 2022-06-24 12:01:00.442770
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ydl = {}
    params = {
        'noprogress': True,
        'test': True,
    }
    fd = HlsFD(ydl, params)
    for ph in fd._progress_hooks:
        assert ph(1, 2) is None



# Generated at 2022-06-24 12:01:14.240508
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 12:01:22.950839
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .fragment import TestFragmentFD

# Generated at 2022-06-24 12:01:34.754716
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .common import InfoExtractor

    # Note: The test data files have been added from the following pull request:
    # https://github.com/ytdl-org/youtube-dl/pull/27660

    # Media fragments
    test_filename = 'test.mp4'
    # Fragment URLs are with the server name as localhost since github won't allow changing it to localhost
    test_url = 'http://localhost/media_playlist.m3u8'

# Generated at 2022-06-24 12:01:46.513922
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .utils import _extract_info

    info_dict = _extract_info('http://127.0.0.1/fixture/hls-variant-playlist.m3u8', download=False)
    assert HlsFD.can_download(info_dict['url'], info_dict) == True

    info_dict = _extract_info('http://127.0.0.1/fixture/hls-variant-playlist.m3u8', download=False)
    info_dict['is_live'] = True
    assert HlsFD.can_download(info_dict['url'], info_dict) == False


# Generated at 2022-06-24 12:01:51.024055
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    fd = HlsFD({}, None)

    # Test encrypted fragments

# Generated at 2022-06-24 12:02:02.044694
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..downloader import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['skip_unavailable_fragments'] = True
    ydl.add_default_info_extractors()
    downloader = HlsFD(ydl, {'quiet': True})
    info = {'url': 'http://test',
            'http_headers': {'Range': 'bytes=4096-8191'},
            'resolution': 266,
            'requested_formats': ['dash_mpd', 'http_dash_segments', 'hls_mp4_mp4']}
    downloader.real_download('test', info)

# Generated at 2022-06-24 12:02:13.123992
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import FileDownloader
    from ..cache import NoCachedDl; cache = NoCachedDl()
    from ..extractor import YoutubeIE
    from ..postprocessor import FFmpegMergerPP

    # Use an input video with a few fragments to speed up the tests
    input_video = 'https://video-weaver.ingest.cdnlayer.com/hls/live/501634/master.m3u8?hdnea=st=1602577600~exp=1602579400~acl=/hls/live/501634/*~hmac=bae7df88a4d8fae3c9dac16a7b9924c0e8d3e1bb03b31cc8547f11d8e2b9da9e'


# Generated at 2022-06-24 12:02:14.076835
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    HlsFD.can_download('', {})

# Generated at 2022-06-24 12:02:21.753436
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    HlsFD_real_download = HlsFD.real_download
    def new_HlsFD_real_download(self, filename, info_dict):
        assert filename == 'abc'
        assert info_dict == {
            'http_headers': {
                'some': 'headers',
                'range': 'bytes=0-2047',
            },
            'url': 'https://manifest.com',
            '_decryption_key_url': 'https://key.com',
            'manifest_type': 'm3u8',
        }


# Generated at 2022-06-24 12:02:34.065228
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    import json

    if sys.version_info.major == 3:
        def get_monotonic_time():
            return time.monotonic_ns() / 1e9
    else:
        from monotonic import monotonic as get_monotonic_time

    class FakeYoutubeDL:

        def __init__(self, params):
            self.params = params
            self.to_screen_lock = threading.Lock()
            self.to_stderr_lock = threading.Lock()

        def to_screen(self, message, skip_eol=False):
            with self.to_screen_lock:
                print(message, file=sys.stderr if skip_eol else sys.stdout)


# Generated at 2022-06-24 12:02:45.762865
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import urllib.parse
    from youtube_dl.compat import unittest
    from youtube_dl.compat import mock

    class MockFFmpegFD(object):
        pass

    class MockURLOpener(object):
        def __init__(self):
            self.content = None
            self.headers = {}

        def open(self, url, data=None, timeout=None):
            # Only used in _download_fragment
            self.content = '\x01\x02\x03\x04'
            return self

        def geturl(self):
            return ''

        def read(self):
            return self.content

        def info(self):
            return self.headers


# Generated at 2022-06-24 12:02:52.139733
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import os
    import tempfile
    import json
    from .external import ExternalFD
    ydl_opts = {
        'quiet': True,
        'forcejson': True,
        'skip_download': True,
    }

    def check_streams(url):
        OUTPUT_TEMPLATE = json.loads("""
{
    "url": "%s",
    "fragments": [
        {
            "url": "%s",
            "ext": "%s",
            "format": "%s",
            "format_id": "%s",
            "filesize": %d,
            "filesize_approx": %d
        }
    ]
}""")
