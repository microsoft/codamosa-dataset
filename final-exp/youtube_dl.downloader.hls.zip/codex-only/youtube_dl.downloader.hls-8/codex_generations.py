

# Generated at 2022-06-24 11:52:53.050378
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    from youtube_dl.YoutubeDL import YoutubeDL
    # If pycrypto is not installed, we return False
    if not can_decrypt_frag:
        assert not HlsFD.can_download('', {})
    # If ffmpeg is not installed, we return False
    from youtube_dl.utils import (
        executable_version,
    )
    from youtube_dl import FFmpegPostProcessor

    class YDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(YDL, self).__init__(*args, **kwargs)
            self.ffmpeg_pp = None

    ydl = YDL()
    ydl.postprocessor_class = FFmpegPostProcessor

# Generated at 2022-06-24 11:53:04.746970
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import FakeYDL
    import tempfile
    import os

    # This test is a bit more complicated and requires more setup than the others.
    # A dummy InfoExtractor class is created and registered so it can be used in the extractor_info field.
    # A temp directory is created for the files to be downloaded to (make sure test_data.zip is in this folder).
    # The download is started. If the assert statement fails then the test has failed.
    # The files are deleted and the temp directory is removed.
    class DummyIE(InfoExtractor):
        IE_NAME = 'Dummy'
        _VALID_URL = r'.*'

# Generated at 2022-06-24 11:53:14.761226
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    class FakeYDL:
        def __init__(self):
            self.to_screen = print
            self.cache = {}

        def urlopen(self, url):
            class FakeUrlOpen:
                def __init__(self, url):
                    self.url = url
                    self.content = self.cache[url]
                    self.headers = {'content-length': len(self.content)}

                def read(self):
                    return self.content

                def geturl(self):
                    return self.url

            return FakeUrlOpen(url)

    def _prepare_url(self, info_dict, url):
        return url

    class FakeHlsFD(HlsFD):
        def __init__(self):
            self.ydl = FakeYDL()

# Generated at 2022-06-24 11:53:23.042459
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .common import FakeYDL
    ydl = FakeYDL()
    ydl.params['fragment_retries'] = 2
    ydl.add_progress_hook(lambda _: None)
    ydl.params['test'] = True
    ydl.params['skip_unavailable_fragments'] = True
    man_url = 'https://example.com/manifest.m3u8'
    info = {'url': man_url}
    fd = HlsFD(ydl, ydl.params)
    fd.real_download('test.txt', info)

# Generated at 2022-06-24 11:53:27.441366
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ydl = YoutubeDL({})
    fd = HlsFD(ydl, {})
    assert fd.ydl is ydl
    assert fd.params == {}
    assert fd.progress_hooks == []
    assert fd.status == {
        'fragments_downloaded': 0,
        'fragments_total': None,
        'downloaded_bytes': 0
    }

# Generated at 2022-06-24 11:53:28.834530
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """ Test if this class can be instantiated """
    HlsFD(None, None)


# Generated at 2022-06-24 11:53:35.158102
# Unit test for constructor of class HlsFD

# Generated at 2022-06-24 11:53:40.386905
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    """ Helper to test class HlsFD method can_download """

    import os
    import sys
    import unittest

    class HlsFD_can_download_Tester(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None

        def test_HlsFD_can_download_1(self):
            man_url = 'http://www.liveonsat.com/football/england_premier_league.php'
            info_dict = {'url': man_url, 'is_live': True}
            manifest = open(os.path.join(sys.path[0], 'hlsnative_can_download_1.m3u8'), 'rb').read().decode('utf-8')

# Generated at 2022-06-24 11:53:52.692943
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import tempfile
    import sys
    import os
    import shutil
    import subprocess

    tmp_dir = tempfile.mkdtemp(prefix='youtubedl-test_HlsFD_real_download').encode(sys.getfilesystemencoding())
    if sys.platform == 'win32':
        tmp_dir = tmp_dir.decode('mbcs')
    tmp_file = os.path.join(tmp_dir, 'out.ts')
    rc = subprocess.call([
        sys.executable, '-c',
        'from __main__ import HlsFD; HlsFD.test_main("' + tmp_file + '")'])
    with open(tmp_file, 'rb') as f:
        file_bytes = f.read()
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-24 11:54:04.708045
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys

    import test
    import youtube_dl.YoutubeDL as YoutubeDL
    import youtube_dl.utils as youtube_dl_utils
    import youtube_dl.downloader.fragment as fragment_downloader
    import youtube_dl.downloader.external as external_downloader

    from .test_fragment import (
        MockYDL, MockFD, MockFD_start, MockFD_write_header,
        MockFD_write_data, MockFD_finish
    )

    class MockFFmpegFD(external_downloader.FFmpegFD):
        def real_download(self, *args, **kwargs):
            MockFFmpegFD.real_download_called = True


# Generated at 2022-06-24 11:54:16.101717
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert not HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-TARGETDURATION:10\n'
        '#EXTINF:10,\n'
        'http://media.example.com/segment1.ts\n'
        '#EXT-X-ENDLIST\n'
        , {'is_live': False})


# Generated at 2022-06-24 11:54:26.026188
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import ISO_639_1
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..extractor.youtube import YoutubeIE

    # Test on a short video that only has two fragments

# Generated at 2022-06-24 11:54:34.936978
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .test import get_test_data
    from .extractor import YoutubeDL
    from .downloader import FileDownloader
    ydl = YoutubeDL(FileDownloader.params)
    manifest = get_test_data('hls/manifest1.m3u8')
    info_dict = {'url': 'http://www.nasa.gov/multimedia/nasatv/NTV-Public-IPS.m3u8'}
    hls_fd = HlsFD(ydl, FileDownloader.params)
    assert hls_fd.can_download(manifest, info_dict)
    assert HlsFD.can_download(manifest, info_dict)

# Generated at 2022-06-24 11:54:46.032972
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import YoutubeDL
    from ..extractor.youtube import YoutubeIE
    from ..compat import parse_qs

    ydl = YoutubeDL()
    ydl.add_default_info_extractors()

# Generated at 2022-06-24 11:54:48.856934
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Test if this method can download a playlist
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 11:54:59.850464
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """ Test if the real_download method of the HlsFD class works """

    # Test if it works when there is no encryption
    class Ydl:
        urlopen_called = 0
        urlopen_content = '#EXTM3U\n#EXTINF:5,\nhttp://www.test.com/test\n#EXT-X-ENDLIST\n'

        def urlopen(self, _url):
            # Make sure that the URL is the correct one
            assert(_url == 'http://www.test.com/test.m3u8')

            class Urlh:
                url = 'http://www.test.com/test.m3u8'
                def read(self):
                    return Ydl.urlopen_content
                def geturl(self):
                    return self.url

            Ydl.urlopen_

# Generated at 2022-06-24 11:55:08.251998
# Unit test for constructor of class HlsFD

# Generated at 2022-06-24 11:55:20.520257
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import tempfile
    import os
    from ..extractor.common import FileDownloader
    from ..extractor.youtube import YoutubeIE
    from ..utils import encode_data_uri

    # Create a temporary file-like object to store the fragments in
    fd, temp_file = tempfile.mkstemp()
    f = os.fdopen(fd, 'w+b')

    # Download test data (only the first fragment)

# Generated at 2022-06-24 11:55:32.999463
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():

    # Variables initialization
    man_url = 'https://example.org/path/to/manifest.m3u8'

    # Test the method with a HLS playlist with no encryption
    manifest_no_enc = '#EXTM3U\n\n#EXTINF:10,\nmedia_segment1.ts\n\n#EXTINF:10,\nmedia_segment2.ts\n\n#EXT-X-ENDLIST'
    info_dict_no_enc = {}
    assert HlsFD.can_download(manifest_no_enc, info_dict_no_enc)

    # Test the method with a HLS playlist with encryption (no crypto lib installed)

# Generated at 2022-06-24 11:55:37.982600
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Complete constructor with file_desc
    ctx = {'filename': 'TEST.mp4'}
    frag_downloader = HlsFD(None, {})
    frag_downloader._prepare_and_start_frag_download(ctx)
    # Check that default value is set
    assert frag_downloader.ydl.params.get('outtmpl') == '%(id)s-%(playlist_index)s.%(ext)s'
    # Check that it does not override already set value
    frag_downloader.ydl.params['outtmpl'] = 'test/%(id)s-%(playlist_index)s.%(ext)s'
    frag_downloader._prepare_and_start_frag_download(ctx)

# Generated at 2022-06-24 11:55:49.695509
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .http import HttpFD
    from .external import ExternalFD
    from ..downloader import Downloader
    from ..cache import FileCache
    from ..extractor import YoutubeDL

    youtube_dl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})


# Generated at 2022-06-24 11:56:01.596715
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import re

    def HlsFD_can_download_test(manifest, expected_result):
        class info_dict_mock:
            def __init__(self, is_live):
                self.is_live = is_live
        return HlsFD.can_download(manifest, info_dict_mock(False)) == expected_result


# Generated at 2022-06-24 11:56:13.548402
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {'is_live': True}) is False
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {'is_live': False}) is True
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\n#EXT-X-BYTERANGE:10@0', {'is_live': False}) is False

# Generated at 2022-06-24 11:56:20.340987
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import shutil
    import tempfile
    import os
    import requests
    import random
    from ..utils import encode_data_uri

    # Mock urlopen to return a truncated file to ensure that tests don't fail if
    # the file is updated.
    def urlopen(request):
        fd, filename = tempfile.mkstemp()
        with open(filename, 'wb') as f:
            f.write(b'hello world!')
        return os.fdopen(fd, 'rb')

    # Mock download_and_decrypt_fragment to just write the data to disk

# Generated at 2022-06-24 11:56:30.889042
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import youtube_dl
    import os
    import shutil
    import tempfile
    import hashlib
    import json

    from .utils import (
        use_cached_session,
        determine_ext,
        test_online,
        set_settle_down_fn,
        noop_settle_down_fn,
    )

    if not can_decrypt_frag:
        return

    with use_cached_session(Mocker()) as session:
        url = 'http://hlsvod-fra.akamaihd.net/i/videos/tears_for_fears-reel_1_,976,1637,,.mp4.csmil/index_4_av.m3u8?null=0'

        # Remove cached session
        cache_dir = os.path.join

# Generated at 2022-06-24 11:56:41.454086
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:56:46.469228
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data

    test_data = get_test_data()
    test_datadir = test_data.get('test_datadir')

    if test_datadir is None:
        raise Exception('Cannot find test resources directory')

    from ..extractor import gen_extractors, YoutubeIE
    from ..utils import PostProcessingError

    youtube_ie = YoutubeIE()
    for ie in gen_extractors():
        if ie.IE_NAME == 'youtube':
            youtube_ie = ie
            break

    def run_test(test_name):
        test_file = os.path.join(test_datadir, test_name + '.py')
        print('\nRunning %s...' % test_file)

# Generated at 2022-06-24 11:56:51.377922
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    from .external import ExternalFD
    ydl = YoutubeDL({})
    external_fd = ExternalFD(ydl, {})
    hls_fd = HlsFD(ydl, {})
    hls_fd.add_progress_hook(external_fd._hook_progress)
    assert hls_fd.params == external_fd.params

# Generated at 2022-06-24 11:57:03.922900
# Unit test for constructor of class HlsFD
def test_HlsFD():
    class MockYoutubeDL(object):
        def __init__(self):
            self.cache = None
            self.params = {
                'test': True
            }

        def urlopen(self, url):
            class MockUrlOpen(object):
                def __init__(self, url):
                    self.url = url
                    self.geturl = lambda: url
                    self.read = lambda: b'MOCK DATA'
            return MockUrlOpen(url)

        def to_screen(self, msg):
            pass


# Generated at 2022-06-24 11:57:05.297159
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # TODO: implement unit test for constructor of class HlsFD
    pass

# Generated at 2022-06-24 11:57:17.136152
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Empty string
    assert not HlsFD.can_download("", None)
    # Non-HLS content type
    assert not HlsFD.can_download("#EXTM3U\n#EXTINF:0.0,\nhttp://example.com/test.ts", None)
    # AES-128 encryption with EXT-X-KEY method
    assert HlsFD.can_download("#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI=\"https://example.com/test.key\"\n#EXTINF:0.0,\nhttp://example.com/test.ts", None)
    # AES-128 encryption with EXT-X-KEY method and IV

# Generated at 2022-06-24 11:57:28.741881
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """Basic unit test for constructor of class HlsFD"""
    import ytdl_config
    import ytdl_opts

    ydl_opts = {
        'hls_prefer_native': True,
        'logger': ytdl_opts.Logger()
    }

    downloader = ytdl_config.YoutubeDL(ydl_opts)

    info_dict = {
        "url": "http://video.example.com/hls/stream.m3u8",
        "ext": "mp4",
        "http_headers": {"User-Agent": "youtube-dl"},
        "player_url": "http://www.foo.com/player.js"
    }

    fd = HlsFD(downloader, ydl_opts)
    assert fd.real_download

# Generated at 2022-06-24 11:57:40.554617
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import unittest
    from ytdl.YoutubeDL import YoutubeDL
    from ytdl.utils import make_HTTPServer, parse_m3u8_attributes
    from .external import FFmpegFD

    path = os.path.join(os.path.dirname(__file__), 'tests')
    os.chdir(path)

    # Disable encryption for testing
    FFmpegFD.can_download_native = lambda *args, **kwargs: False

    # Mock the youtube_dl/extractor/common.py file as needed for testing
    class MockInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(MockInfoDict, self).__init__(*args, **kwargs)
            self['url'] = 'http://fake_url'



# Generated at 2022-06-24 11:57:51.825800
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def can_download(manifest, info_dict):
        return HlsFD.can_download(manifest, info_dict)
    assert can_download(
        """
#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:10
#EXT-X-MEDIA-SEQUENCE:0
#EXT-X-PLAYLIST-TYPE:VOD
#EXTINF:10,
http://media.example.com/fileSequence1.ts
#EXTINF:10,
http://media.example.com/fileSequence2.ts
#EXTINF:10,
http://media.example.com/fileSequence3.ts
#EXT-X-ENDLIST
""", {'url': 'http://example.com'})

# Generated at 2022-06-24 11:57:54.382376
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .test import get_testdata_stream
    HlsFD(None, {}, get_testdata_stream('hls_segment_template.m3u8'), None)

# Generated at 2022-06-24 11:58:01.662136
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # _get_files_from_playlist method of YouTubeIE uses HlsFD.can_download method
    assert HlsFD.can_download('#EXTM3U', {'id': 'whatever'})
    assert HlsFD._get_files_from_playlist(
        '#EXTM3U', {'id': 'whatever'}, {'url': 'http://example.com/'}, 'http://example.com/')


if __name__ == '__main__':
    test_HlsFD_can_download()

# Generated at 2022-06-24 11:58:11.725124
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .tests.test_download import FakeYDL
    from .tests.test_download import _fake_extractors as fake_extractors
    from .common import FileDownloader

    ydl = FakeYDL()
    info_dict = {'url': 'http://example.com/manifest.m3u8',
                 'http_headers': {'Accept': 'application/x-mpegURL,application/dash+xml'}}
    ydl.add_info_extractors(fake_extractors)
    fd = HlsFD(ydl, {})
    fd.add_info_extractor(fake_extractors[0])
    fd.real_download('test_file_name.ts', info_dict)

# Generated at 2022-06-24 11:58:22.264689
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import os.path
    import shutil
    import sys
    import tempfile
    import unittest

    from . import FakeYDL
    from .extractors.hls import (
        HlsFD,
        _get_aes_decryption_key,
    )

    class HlsFDRealDownloadTest(FakeYDL):
        class MockResponse(object):
            _HEADERS = {'Content-Length': '123456789012345'}

            def __init__(self, url, headers=None):
                self.url = url
                self.headers = headers or self._HEADERS

            def info(self):
                return self.headers

        def _real_extract_wget(self, url):
            assert url == 'http://mock/segment.ts'
            return os

# Generated at 2022-06-24 11:58:34.606500
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import os
    import random
    import shutil
    import tempfile
    from .downloader import FileDownloader
    from .http import HttpFD
    from .http import HEADRequest
    from .external import ExternalFD
    from .fragment import fragment_retries
    from .m3u8 import is_m3u8_url

    class CustomHeadRequest(HEADRequest):
        """
        A minimal HEAD request implementation that only retrieves the content length.
        """

        def _get_response(self, conn, buff_size):
            response = super(CustomHeadRequest, self)._get_response(conn, buff_size)
            response.content_length = int(response.headers.get('content-length', '0'))
            return response


# Generated at 2022-06-24 11:58:43.566222
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import ytdl.extractor.common
    import ytdl.extractor.youtube
    from .tests.test_download import fake_ytdl

    def ytdl_fake_extract_info(self, url, download=False, ie_key=None,
                               extra_info={}, process=None, fatal=True):
        if ie_key is None:
            ie_key = 'Generic'
        ie = ytdl.extractor.common.get_info_extractor(ie_key)
        if ie is None:
            raise Exception('For testing purposes you must provide a valid '
                            'ie_key. See https://github.com/rg3/youtube-dl#embedding')

        ie.extractor = ytdl.extractor.GenericIE(ie.name)
        ie.extractor

# Generated at 2022-06-24 11:58:50.286561
# Unit test for constructor of class HlsFD
def test_HlsFD():
    url = "https://codeload.github.com/ytdl-org/youtube-dl/zip/2020.05.20"
    info_dict = {'url': url}
    youtube_dl = ""
    params = ""

    HlsFD(youtube_dl, params).real_download(
        "youtube-dl-2020.05.20.zip", info_dict)


if __name__ == "__main__":
    test_HlsFD()

# Generated at 2022-06-24 11:58:56.319922
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..downloader import YoutubeDL
    from ..extractor.generic import GenericIE
    ydl = YoutubeDL({'quiet': True})
    hlsfd = HlsFD(ydl, {'hls_use_native': True, 'hls_prefer_native': True})
    assert hlsfd.query == {'hls_use_native': True}
    hlsfd = HlsFD(ydl, {'hls_use_native': True, 'hls_prefer_native': False})
    assert hlsfd.query == {}
    generic = GenericIE(ydl, {})
    generic.query = {'foo': 'bar'}

# Generated at 2022-06-24 11:59:04.404898
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\nhttp://foo/seg1.ts\n#EXT-X-KEY:METHOD=AES-128,URI="https://example.com/key"\nhttp://foo/seg2.ts', {'_type': 'hls', 'is_live': False})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="https://example.com/key"\nhttp://foo/seg1.ts', {'_type': 'hls', 'is_live': False})

# Generated at 2022-06-24 11:59:15.656711
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import FileDownloader
    ydl = FileDownloader({'outtmpl': '%(id)s%(ext)s'}, {'logger': DummyLogger()})
    fd = HlsFD(ydl, {})
    fd.add_progress_hook(DummyHook())
    assert fd.name() == 'hlsnative'
    with open('test/_files/hls/hls-test.m3u8', 'rb') as f:
        body = f.read()
    assert fd.can_download(body, {'url': 'http://test.com/test.m3u8'})
    assert fd.real_download('test.mp4', {'url': 'http://test.com/test.m3u8'})

# Generated at 2022-06-24 11:59:26.870139
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from .common import FakeYDL

    class FakeInfoExtractor(InfoExtractor):
        """A fake InfoExtractor to use for testing HlsFD.real_download()"""
        _WORKING = False

        def _real_extract(self, url):
            info = {
                'url': url,
                'id': '6418',
                'uploader_id': '5368737',
                'extractor': 'test'
            }
            return info

    # Initialize FakeYDL and add our test InfoExtractor class
    ydl = FakeYDL()
    ydl.add_info_extractor(FakeInfoExtractor)

    # Create test fragment downloader object with no private data
    hlsfd = HlsFD(ydl, {'test': True})

   

# Generated at 2022-06-24 11:59:27.397827
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass

# Generated at 2022-06-24 11:59:34.019619
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    print('Downloading a video using method real_download of class HlsFD')
    from .downloader import YoutubeDL
    from .extractor import YoutubeIE
    from .compat import compat_str
    from .utils import *
    from .extractor import *
    from .downloader import *
    from .http import *
    from .extractor.common import InfoExtractor
    from .postprocessor.common import PostProcessor
    from .cache import Cache 
    from .extractor.common import get_element_by_attribute
    from .utils import jsobj_workaround
    import warnings
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', category=CompatPatchWarning)
        warnings.filterwarnings('ignore', category=DeprecationWarning)

# Generated at 2022-06-24 11:59:39.200166
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """ Unit test for method real_download of class HlsFD """
    # TODO(mrs0m30n3): finish the test_HlsFD_real_download
    #  method unit test
    assert False



# Generated at 2022-06-24 11:59:49.585367
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .common import FakeYDL
    from .downloader import Downloader
    from .extractor import gen_extractors
    extractors = gen_extractors()
    ydl = FakeYDL()
    Downloader(ydl, extractors)
    info_dict = {'extractor': 'test'}
    url = 'http://test_url/test.m3u8'
    fragment_retries = 1
    skip_unavailable_fragments = False
    ytdl = ydl.getDownloader(info_dict)
    test_obj = HlsFD(ydl, ytdl, url, info_dict, fragment_retries, skip_unavailable_fragments)

# Generated at 2022-06-24 11:59:59.005710
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # mock the FFmpegFD can_download
    FFmpegFD.can_download = classmethod(lambda *args: True)

    # mock on can_download method
    old = HlsFD.can_download
    HlsFD.can_download = HlsFD.__dict__['can_download']

    # AES-128 encrypted stream
    assert HlsFD.can_download(
        '#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-MEDIA-SEQUENCE:1\
        \n#EXT-X-KEY:METHOD=AES-128,URI="https://priv.example.com/key.php?r=52"\n',
        {'http_headers': {}}) is False
    # encrypted stream with unsupported encryption method

# Generated at 2022-06-24 12:00:09.195907
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    info_dict = {}
    info_dict['is_live'] = False
    # Test with an unsupported playlist (contains #EXT-X-KEY)
    manifest = '#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="https://priv.example.com/key.php?r=52"\n#EXTINF:2.833,\nhttp://media.example.com/fileSequence52-A.ts\n#EXTINF:15.0,\nhttp://media.example.com/fileSequence52-B.ts\n#EXTINF:13.333,\nhttp://media.example.com/fileSequence52-C.ts\n'
    assert not HlsFD.can_download(manifest, info_dict)

    # Test with an unsupported playlist (cont

# Generated at 2022-06-24 12:00:17.362675
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors
    from .common import FakeYDL
    from ..compat import compat_struct_pack

    # Prepare manifest file with no supported feature
    manifest = '#EXTM3U\n'  # Minimum requirement
    manifest += '#EXT-X-KEY:METHOD=AES-128,URI="https://test.key",IV=0x102030405060708090a0b0c0d0e0f110\n'  # Encryption
    manifest += '#EXTINF:10,\n'  # Segment info
    manifest += 'http://example.com/segment.ts\n'  # Segment URL
    manifest += '#EXT-X-ENDLIST'

    # Prepare test extractors
    ydl = FakeYDL()
    ie = gen_extractors

# Generated at 2022-06-24 12:00:26.643303
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..downloader.common import FileDownloader
    from ..extractor.common import InfoExtractor

    def _get_downloader(url):
        ydl = FileDownloader({'hls_use_mpegts': False})
        ydl.add_info_extractor(InfoExtractor({'hls_use_mpegts': False}))
        ydl.params['hls_use_mpegts'] = False
        ydl.params['noprogress'] = True
        ydl.result = {
            'id': '1234',
            'extractor': 'test',
            'extractor_key': 'test',
            'title': 'test',
            'formats': [],
        }

# Generated at 2022-06-24 12:00:28.900135
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .test_fragment import test_HlsFD_can_download
    test_HlsFD_can_download(HlsFD)

# Generated at 2022-06-24 12:00:40.056409
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    from unittest.mock import patch
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({
        'format': 'hls-native',
        'outtmpl': '%(autonumber)s-%(id)s.%(ext)s',
    })


# Generated at 2022-06-24 12:00:40.944664
# Unit test for constructor of class HlsFD
def test_HlsFD():
    print('Hello World!')

# Generated at 2022-06-24 12:00:49.510909
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    features = {
        '#EXT-X-KEY:METHOD=(?!NONE|AES-128)': False,
        '#EXT-X-BYTERANGE': False,
        '#EXT-X-MEDIA-SEQUENCE:(?!0$)': False,
        '#EXT-X-PLAYLIST-TYPE:EVENT': False,
        '#EXT-X-MAP:': False,
    }

    manifest = '#EXTM3U\n' + '\n'.join(k for k, v in features.items() if v) + '\n'
    assert not HlsFD.can_download(manifest, {})

    manifest = '#EXTM3U\n' + '\n'.join(k for k, v in features.items() if not v) + '\n'

# Generated at 2022-06-24 12:01:03.931807
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import shutil
    import sys
    import tempfile
    from .downloader import FakeYDL

    from ..compat import compat_urllib_request

    tmp_dir = tempfile.mkdtemp()

    manifest = """
#EXTM3U
#EXT-X-VERSION:3
#EXT-X-MEDIA-SEQUENCE:0
#EXT-X-PLAYLIST-TYPE:VOD
#EXT-X-TARGETDURATION:9
#EXTINF:9.000000,
first.ts
#EXTINF:9.000000,
second.ts
#EXT-X-ENDLIST
"""

    fragment1 = """
[video-only fragment 1]
"""

    fragment2 = """
[video-only fragment 2]
"""


# Generated at 2022-06-24 12:01:06.287120
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import YoutubeDL
    from .external import ExternalFD
    # ffmpeg global initialization
    ExternalFD._fd_cache[ExternalFD.FD_NAME] = None
    ExternalFD._fd_cache[ExternalFD.FD_NAME] = ExternalFD(YoutubeDL({'quiet': True}), None)

# Generated at 2022-06-24 12:01:20.808470
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    tdir = Path(__file__).parent / 'tests' / 'testdata' / 'hls' / 'hlsnative'
    test_manifests = [
        ('test_hlsnative_encrypted_aes128_no_iv.m3u8', 'test_hlsnative_encrypted_aes128_no_iv.key'),
        ('test_hlsnative_encrypted_aes128_iv.m3u8', 'test_hlsnative_encrypted_aes128_iv.key'),
    ]

    def test_HlsFD_real_download_helper(manifest_fname, key_fname):
        test_manifest_fpath = tdir / manifest_fname
        name = 'test_HlsFD_real_download_%s' % manifest_fname

# Generated at 2022-06-24 12:01:23.128113
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """
    Unit test for constructor of class HlsFD
    """
    HlsFD()

# Generated at 2022-06-24 12:01:34.919980
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.FD_NAME == 'hlsnative'
    assert not HlsFD.can_download('', {'is_live': True})
    assert HlsFD.can_download(
        '#EXT-X-KEY:METHOD=AES-128\n#EXT-X-KEY:METHOD=NONE', {})
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=NONE', {})
    assert not HlsFD.can_download(
        '#EXT-X-KEY:METHOD=AES-128\n#EXT-X-BYTERANGE', {})
    assert HlsFD.can_download('', {'_decryption_key_url': 'foo'})

# Generated at 2022-06-24 12:01:46.516751
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .external import ExternalFD
    from .http import HttpFD
    from .dash import (
        DashSegmentsFD,
        parse_mpd_formats,
    )
    from ..downloader import Downloader
    from ..utils import (
        encode_data_uri,
        sanitize_open,
    )

    def _prepare_test_files(files):
        for path, content in files.items():
            if path.startswith('data:'):
                content = encode_data_uri(content, name=path, mime_type='text/plain')
            sanitize_open(BytesIO(content), 'w').close()


# Generated at 2022-06-24 12:01:53.412029
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import sys
    import os
    import pytest
    from .extractor.common import InfoExtractor
    from .utils import *
    from .downloader.http import HttpFD
    from .downloader.external import ExternalFD
    from .extractor.generic import GenericIE
    from .extractor.youtube import YoutubeIE
    from .downloader.common import FileDownloader
    from .extractor.common import InfoExtractor
    from .compat import compat_str
    import youtube_dl.extractor.iheart

    class TestHlsFD(object):
        def test_can_download(self, tmpdir):

            # Test supported features
            feature_man_f = tmpdir.join('f.m3u8')

# Generated at 2022-06-24 12:02:02.253806
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import shutil
    import os
    import tempfile
    import sys
    from .external import FFmpegFD

    if not (hasattr(sys, 'gettotalrefcount') and hasattr(sys, 'getrefcount')):
        raise unittest.SkipTest('Need debug build of Python for memory leak detection')

    package_directory = os.path.dirname(os.path.abspath(__file__))
    print(package_directory)
    playlist_url = 'file://' + package_directory.replace(os.path.sep, '/') + '/hls-playlist.m3u8'

    external_downloader_installed = (
        'ffmpeg' in sys.modules or 'avconv' in sys.modules)

# Generated at 2022-06-24 12:02:13.290736
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert not HlsFD.can_download('', {})
    assert HlsFD.can_download('#EXTM3U\n', {})
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=NONE', {})
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {'is_live': True})
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:0', {})

# Generated at 2022-06-24 12:02:14.992163
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD(None, None).FD_NAME == 'hlsnative'


# Generated at 2022-06-24 12:02:19.851248
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import os
    import sys
    sys.path.insert(0, os.path.abspath(os.path.join(__file__, os.pardir, os.pardir, 'scripts')))
    from youtube_dl.YoutubeDL import YoutubeDL
    fd = HlsFD(YoutubeDL({}), {})
    assert fd.FD_NAME == 'hlsnative'

# Generated at 2022-06-24 12:02:31.926048
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import datetime
    import sys

    filename = 'sintel.mp4'
    if sys.platform == 'win32':
        filename = filename.replace(':', '_')
    filename = os.path.join(os.getcwd(), filename)
    url = 'http://www.youtube.com/user/Scobleizer#p/u/1/1p3vcRhsYGo'

    ydl = YoutubeDL({'outtmpl': filename})
    ydl.add_default_info_extractors()
    hd = HlsFD(ydl, {'simulate':True})
    hd.real_download(filename, {'url': url})

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 12:02:38.640315
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def files_listing_data(fn):
        with open('downloader/hls_lib/tests/%s' % fn, 'r') as f:
            res = f.read()
        return res

    def can_download_test(m3u8_file_name, info_dict, expected_result):
        data = files_listing_data(m3u8_file_name)
        assert data is not None
        assert HlsFD.can_download(data, info_dict) == expected_result

    # General tests for all features
    can_download_test('test_can_download_master.m3u8', {}, False)
    can_download_test('test_can_download_master.m3u8', {'is_live': True}, False)

# Generated at 2022-06-24 12:02:50.691086
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():

    from .external import ExternalFD
    from .http import HttpFD
    from .test import TESTS_DATA_DIR, FakeYDL
    import os

    def get_common_tests_data_path(file_name):
        return os.path.join(TESTS_DATA_DIR, 'common', file_name)

    class FakeDict(dict):

        def __init__(self, test, *args, **kwargs):
            self.test = test
            super(FakeDict, self).__init__(*args, **kwargs)

        def set(self, *args, **kwargs):
            self.test.fail('FakeDict.set() should not be called')

        def get(self, *args, **kwargs):
            self.test.fail('FakeDict.get() should not be called')

