

# Generated at 2022-06-24 11:52:49.391076
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXTINF:10,\nvideo.mp4\n', {'url': 'https://foo.bar/master.m3u8'})



# Generated at 2022-06-24 11:52:58.718305
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from io import BytesIO
    class InfoDictMock:
        def __init__(self):
            self.url = ''
            self.http_headers = {}
            self.is_live = False
    import unittest
    class TestCase(unittest.TestCase):
        def setUp(self):
            self.InfoDictMock = InfoDictMock
            self.HlsFD = HlsFD
            self.HlsFD.ydl = type('YtdlMock', (object,), {
                'urlopen': lambda self, url: BytesIO(b'foo'),
            })
            self.HlsFD.can_download = HlsFD.can_download


# Generated at 2022-06-24 11:53:08.838482
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Helper functions
    def _get_manifest_from_string(manifest_content):
        assert isinstance(manifest_content, str)
        return manifest_content

    def _get_manifest_from_file(manifest_file_path):
        assert isinstance(manifest_file_path, str)
        manifest_file = open(manifest_file_path, 'r')
        manifest_content = manifest_file.read()
        manifest_file.close()
        return manifest_content

    import unittest
    import os

    class HlsFdCanDownloadTest(unittest.TestCase):
        def setUp(self):
            self.current_directory = os.path.dirname(os.path.realpath(__file__))


# Generated at 2022-06-24 11:53:19.703588
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD._is_valid_url('http://example.com')
    assert not HlsFD._is_valid_url('content:foo')
    assert HlsFD._is_valid_url('https://example.com/content:foo')
    assert HlsFD._is_valid_url('https://example.com/?content:foo')
    assert HlsFD._is_valid_url('https://example.com?content:foo')
    assert HlsFD._is_valid_url('https://example.com/content:foo?foo=bar')
    assert HlsFD._is_valid_url('https://example.com?content:foo&foo=bar')
    assert not HlsFD._is_valid_url('https://example.com?content:foo&foo=bar?bar=baz')
    assert not HlsFD

# Generated at 2022-06-24 11:53:28.276199
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """ Create an instance of the HlsFD class """
    assert HlsFD.can_download('#EXTM3U', {'is_live': False})
    assert HlsFD.can_download('#EXTM3U', {'is_live': True}) is False
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'is_live': False})
    assert not HlsFD.can_download(
        '#EXT-X-KEY:METHOD=AES-128\n#EXT-X-BYTERANGE', {'is_live': False})
    assert not HlsFD.can_download(
        '#EXT-X-KEY:METHOD=AES-128\n#EXT-X-BYTERANGE', {'is_live': False})

# Generated at 2022-06-24 11:53:34.766196
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..utils import SearchInfoExtractor
    from ..compat import compat_urlparse

    def get_url(regex, url):
        m = re.match(regex, url)
        assert m
        return m.group(1)

    def get_url_regex(regex, url):
        m = re.match(regex, url)
        assert m
        return m

    ie = InfoExtractor(params={})
    url = 'https://example.com/media.m3u8'
    # check that feature NOT_SUPPORTED_FEATURES is not implemented
    manifest = '#EXT-X-KEY:METHOD=NONE\r\n https://example.com/media_01.ts\r\n'
    assert not HlsFD.can_download

# Generated at 2022-06-24 11:53:40.022928
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL
    from .m3u8 import M3U8
    from .fragment import FragmentFD

    def open(context, url, *args, **kwargs):
        urlh = compat_urllib_request.Request(url)
        urlh.url = url
        urlh.data = b''
        urlh.headers = []
        return urlh

    # Mock this function to avoid downloading fragment during test
    def _download_fragment(self, ctx, frag_url, info_dict, headers):
        if 'test_data' in frag_url:
            return True, b'fragment_content'
        return True, self.ydl.urlopen(self._prepare_url(info_dict, frag_url)).read()

   

# Generated at 2022-06-24 11:53:52.237090
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..utils import YDLHttpRequestProcessor
    from .mock_server import MockServer
    import urllib.parse
    import urllib.request

    # basic test
    with MockServer(0) as server:
        server.serve_content('#EXTM3U\n#EXTINF:1,\nhttps://example.org/fragment\n')

        req = YDLHttpRequestProcessor({'http_chunk_size': 8192})
        with req.open('%s/media.m3u8' % server.get_url()) as fh:
            fd = HlsFD(req, {})
            assert fd.real_download('filename', {'url': 'http://localhost:%s/media.m3u8' % server.port})

    # bypass test

# Generated at 2022-06-24 11:54:04.036282
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    import os
    import tempfile
    import youtube_dl.YoutubeDL
    import youtube_dl.FileDownloader

    tmp_dir = tempfile.mkdtemp()
    fd, manifest = tempfile.mkstemp(dir=tmp_dir)
    os.close(fd)
    fd, media = tempfile.mkstemp(dir=tmp_dir)
    os.close(fd)
    tmpl = 'https://youtube.com/cc?%s'


# Generated at 2022-06-24 11:54:15.357308
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import ExtractorError
    import sys
    import os

    # mock ydl object
    class MockYdl:
        def __init__(self):
            self.params = {}

        def to_screen(self, str):
            sys.stdout.write(str)

        def trouble(self, str):
            print(str)
            sys.exit(1)

    # mock urlopen of class YDStreamExtractor
    def mock_urlopen(url, *args, **kwargs):
        if url.find('videoplayback') != -1:
            return MockFileObject(url)
        elif url.find('key') != -1:
            return MockFileObject(url)

# Generated at 2022-06-24 11:54:17.267232
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hlsf = HlsFD(None)
    assert hlsf.name

# Generated at 2022-06-24 11:54:19.678132
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ydl = YoutubeDL({'quiet': True, 'noplaylist': True, 'continuedl': True})
    ydl.process_ie_result({}, download_result=True)

# Generated at 2022-06-24 11:54:32.668958
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import os
    import requests
    import shutil
    import tempfile
    from ..utils import (
        encode_compat_str,
        sanitize_open,
    )
    from ..extractor import gen_extractors
    from .dash import DASHFD
    from .http import HttpFD
    from .http import YoutubeDLHttpError
    from .fragment import AudioFragmentFD
    from .fragment import VideoFragmentFD

    directory = tempfile.mkdtemp(prefix="ytdl-test-")
    file_handler = sanitize_open(os.path.join(directory, "test.mp4"), "wb")
    # download media file

# Generated at 2022-06-24 11:54:39.085912
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..downloader import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..extractor.ytdl import YOUTUBE_IE_NAME

    old_if_supported_url = InfoExtractor.if_supported_url
    def new_if_supported_url(self, url):
        return url
    InfoExtractor.if_supported_url = new_if_supported_url


# Generated at 2022-06-24 11:54:42.064540
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from . import YoutubeDL
    ydl = YoutubeDL(params={'noplaylist': True})
    return HlsFD(ydl)

# Generated at 2022-06-24 11:54:51.076284
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Assert that can_download returns True if iptv.orf.at is given through a URL
    from .iptv import IptvFD
    man_url = "http://hls.cms.orf.at/oe24/streams/oe24/20070917/20070917_0945_oe24_videoarchiv.mp4/playlist.m3u8"
    info_dict = {}
    info_dict['url'] = man_url
    assert HlsFD.can_download(man_url, info_dict)

    # Assert that can_download returns True if the example playlist from
    # youtube-dl is given
    info_dict = {}

# Generated at 2022-06-24 11:55:01.382094
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .external import FFmpegFD
    from ..extractor import gen_extractors
    from ..downloader import FakeYDL
    ydl = FakeYDL()
    for ie in gen_extractors():
        try:
            ie.suitable(ydl, 'http://url/')
        except Exception:  # pylint: disable=W0703
            continue
        if ie.ie_key().startswith('generic') or ie.ie_key() == 'googledrive':
            continue
        if ie.ie_key() not in ('cbsnews', 'abcnews', 'adobepass', 'canalplus', 'instagram'):  # end date
            vid_info_test = ie.extract('http://url/')
            if not vid_info_test:
                continue
            ie = type

# Generated at 2022-06-24 11:55:08.779597
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Test for methods with support
    manifest = ('#EXTM3U\n'
                '#EXT-X-KEY:METHOD=AES-128'
                '#EXTINF:5.015,\n'
                'http://example.com/1.ts\n'
                '#EXTINF:5.015,\n'
                'http://example.com/2.ts\n')

    info_dict = {'url': '', 'is_live': False}

    assert HlsFD.can_download(manifest, info_dict) is True

    # Test for methods without support

# Generated at 2022-06-24 11:55:11.378069
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.FD_NAME == 'hlsnative'



# Generated at 2022-06-24 11:55:19.469377
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    info_dict = {}
    filename = ''
    info_dict['url'] = 'https://mnmedias.api.telequebec.tv/m3u8/29880.m3u8'
    assert HlsFD.can_download(
        InfoExtractor._download_webpage(None, info_dict['url'], 'test'), info_dict)
    assert HlsFD(FileDownloader({}), {}).real_download(filename, info_dict)

# Generated at 2022-06-24 11:55:27.549363
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import FakeYDL
    from ..extractor.generic import GenericIE

    def fake_urlopen(url, data=None):
        class FakeUrlOpen(object):
            def __init__(self, url):
                parts = compat_urlparse.urlparse(url)
                query = compat_urlparse.parse_qs(parts.query)
                self.url = url
                self.status = 200
                if parts.netloc == 'example.org':
                    if parts.path == '/private/key':
                        self._content = binascii.unhexlify(query['key'][0])
                    elif parts.path == '/private/index.m3u8':
                        self._content = b'#EXTM3U\n'

# Generated at 2022-06-24 11:55:38.606821
# Unit test for constructor of class HlsFD
def test_HlsFD():
    given_manifest = '#EXTM3U\n#EXT-X-KEY:METHOD=NONE\n#EXTINF:2.2,\n#EXT-X-BYTERANGE:522828@0\nmain.mp4\n#EXT-X-ENDLIST'
    given_info_dict = {'url': 'https://example.org/playlist.m3u8', 'is_live': False, '_decryption_key_url': None, 'extra_param_to_segment_url': None}

    # Test 1: Constructor works as expected
    # Try/except used around since it is not possible to test static methods

# Generated at 2022-06-24 11:55:50.034804
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .helpers import DummyYDL
    from .test_FragmentFD import _FragmentFD_test_cases

# Generated at 2022-06-24 11:56:01.886497
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.httpie import HttpIE

# Generated at 2022-06-24 11:56:13.687439
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import tempfile
    from ..extractor.youtube import YoutubeIE
    from ..downloader import YoutubeDL

    with tempfile.NamedTemporaryFile(delete=False) as stream_file:
        stream_file_name = stream_file.name

    def extract_info(url, download=True, ie=None, **params):
        params.update({
            'logger': YoutubeDL()._downloader.to_screen,
            'progress_hooks': [
                lambda d: None if
                d['status'] == 'finished' else
                stream_file.file.write(d['fragment_content'])],
            'test': True,
        })
        ie = YoutubeIE(YoutubeDL(params))
        return ie.extract(url)


# Generated at 2022-06-24 11:56:25.267108
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def _test_case(manifest, info_dict, expected):
        assert HlsFD.can_download(manifest, info_dict) == expected

    # HLS with AES-128 encryption

# Generated at 2022-06-24 11:56:37.024332
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..utils import encode_data_uri
    import htmldownloader
    ydl = htmldownloader.FakeYdl({})
    hls_fd = HlsFD(ydl, {'test': True})
    hls_fd.real_download('', {
        'url': 'http://www.example.com/',
        # The parameter of 'origin' is required by the urlopen method
        'http_headers': {'origin': 'origin'}
    })


# Generated at 2022-06-24 11:56:48.683428
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def assert_can_download(manifest, info_dict, expected):
        # Do not remove this import here since this test module is not executed
        # if __main__ were to be used.
        from youtube_dl.downloader.hls import HlsFD
        assert HlsFD.can_download(manifest, info_dict) == expected
    # Tests for unsupported features
    assert_can_download('#EXT-X-KEY:METHOD=AES-128', {}, False)
    assert_can_download('#EXT-X-BYTERANGE', {}, False)
    assert_can_download('#EXT-X-MEDIA-SEQUENCE:1', {}, False)
    assert_can_download('#EXT-X-PLAYLIST-TYPE:EVENT', {}, False)

# Generated at 2022-06-24 11:57:02.157613
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # pytest -s -v test_HlsFD.py
    import os
    import tempfile
    from ..downloader import YoutubeDL
    from ..extractor import gen_extractors
    from ..postprocessor import PostProcessor, FFmpegExtractAudioPP

# Generated at 2022-06-24 11:57:14.137637
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from . import YoutubeDL
    from .extractor.common import InfoExtractor

    class HlsInfoExtractor(InfoExtractor):
        IE_NAME = 'test'
        IE_DESC = False
        _VALID_URL = r'https?://(?:www\.)?example\.com/(?:[^/]+/)*(?P<id>[^/]+)'

        def _real_extract(self, url):
            return {
                'id': self._match_id(url),
                'url': url,
                'is_live': self._downloader.params.get('force_live', False),
                'ext': 'mp4',
                'title': 'Example',
                'http_headers': {
                    'X-Test-Header': 'test-header-content',
                },
            }


# Generated at 2022-06-24 11:57:23.947983
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import sys
    import unittest

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.builder = unittest.mock.Mock(
                urlopen = unittest.mock.Mock(side_effect=lambda x, **y: open(x, 'rb')),
                report_warning = unittest.mock.Mock(),
                report_error = unittest.mock.Mock(),
            )
            self.builder.urlopen.return_value.geturl.return_value = 'http://example.com/index.m3u8'
            self.builder.params = {}

# Generated at 2022-06-24 11:57:32.443792
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:57:42.770696
# Unit test for constructor of class HlsFD

# Generated at 2022-06-24 11:57:54.265457
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import os.path
    import tempfile
    import json
    import io

    if not can_decrypt_frag:
        raise unittest.SkipTest('pycrypto not found. Please install it.')

    if not os.path.isfile('test/test.mp4'):
        raise unittest.SkipTest('test data not present')

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.test_file_name = tempfile.mktemp(suffix='.mkv')

# Generated at 2022-06-24 11:58:05.235723
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .testutils import FakeYDL
    from .extractor.http import HlsFD

    ydl = FakeYDL()
    HlsFD.ydl = ydl

    print('Testing HlsFD.can_download method with media_playlist_is_not_variant')
    manifest = ('#EXTM3U\n'
                '#EXT-X-VERSION:3\n'
                '#EXT-X-TARGETDURATION:12\n'
                '#EXT-X-MEDIA-SEQUENCE:0\n'
                '#EXTINF:12.0,\n'
                'fileSequence0.ts\n'
                '#EXT-X-ENDLIST\n')
    info_dict = dict(url='url')


# Generated at 2022-06-24 11:58:15.918936
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download(
        '#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1280000\nmedia.m3u8\n', {})
    assert HlsFD.can_download(
        '#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1280000\nmedia.m3u8\n', {'is_live': False})
    assert not HlsFD.can_download(
        '#EXTM3U\n#EXT-X-PLAYLIST-TYPE:EVENT\n#EXT-X-STREAM-INF:BANDWIDTH=1280000\nmedia.m3u8\n', {})

# Generated at 2022-06-24 11:58:25.322954
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .urllib import urlopen
    from .extractor import YoutubeDL
    from .downloader import DownloadContext
    from .downloader import FileDownloader
    import os
    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    url = 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8'
    res = FileDownloader.test_url_from_test_id(url, ydl, {}, {})
    assert(res == True)
    ctx = downloader.DownloadContext(ydl, {}, {})
    file_d = HlsFD(ydl, {})
    res = file_d.real_download("test_file.mp4", {'url':url})
    print

# Generated at 2022-06-24 11:58:28.206134
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    extractors = gen_extractors()
    assert(HlsFD in extractors.keys())


# Generated at 2022-06-24 11:58:32.778735
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class YtdlMock():
        def __init__(self, extractor):
            self.extractor = extractor
    class InfoDictMock():
        def __init__(self, url, is_live, _decryption_key_url, extra_param_to_segment_url):
            self.url = url
            self.is_live = is_live
            self._decryption_key_url = _decryption_key_url
            self.extra_param_to_segment_url = extra_param_to_segment_url

    class YoutubeDLMock():
        def __init__(self, params):
            self.params = params

    # Test 1: vod

# Generated at 2022-06-24 11:58:43.267597
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    from .external import ExternalFD
    from ..utils import read_json_file

    ffmpeg_fd = ExternalFD(None, {'external_downloader': 'ffmpeg', 'simulate': True})
    hls_fd = HlsFD(None, {'simulate': True})

    manifest_path = os.path.join(
        os.path.dirname(__file__), '..', '..', 'tests', 'data', 'playlists', 'hlsnative_can_download')

    for feature, expected in read_json_file(manifest_path).items():
        assert (hls_fd.can_download(feature, {'url': 'mock_url'})
                is expected['hlsnative_can_download']), feature

# Generated at 2022-06-24 11:58:49.093428
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class FakeInfoDict(dict):
        def __init__(self):
            self.is_live = False
    assert HlsFD.can_download('#EXTM3U', FakeInfoDict())
    assert HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-VERSION:4\n'
        '#EXTINF:5,\n'
        'fileSequence0.ts\n', FakeInfoDict())

# Generated at 2022-06-24 11:58:59.480035
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from . import YoutubeDL
    from .extractor import get_info_extractor

    # Test that the real_download method for the HlsFD class works properly
    ydl = YoutubeDL({})
    info_dict = {
        'id': 'hls',
        'url': 'http://localhost/hls/playlist.m3u8',
        'ext': 'mp4',
        'player_url': 'http://localhost/hls/player.html',
        'player_url_json': 'http://localhost/hls/player.json',
        'protocol': 'm3u8',
        'extractor': 'hls',
    }

    ie = get_info_extractor(info_dict['extractor'])()
    ie.extract_info(info_dict['url'], {}, ydl)



# Generated at 2022-06-24 11:59:10.381006
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import IsolatedAsyncHTTPClient

    class FakeInfoDict(dict):
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.get = super(FakeInfoDict, self).__getitem__

    class FakeYDL(object):
        http_client = IsolatedAsyncHTTPClient

    class FakeParams(dict):
        def __init__(self, *args, **kwargs):
            super(FakeParams, self).__init__(*args, **kwargs)
            self.get = super(FakeParams, self).__getitem__
            self['outtmpl'] = 'dummy.mp4'
            self['quiet'] = True
            self['simulate'] = True

# Generated at 2022-06-24 11:59:21.181973
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    """
    Note: If you update test cases, please run ./youtube-dl/tests/test_download.sh to update the expected output.
    """
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    from .downloader import YoutubeDL
    from .extractor import get_info_extractor

    class DummyYoutubeDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(DummyYoutubeDL, self).__init__(*args, **kwargs)
            self.to_stdout = StringIO()
            self.to_stderr = StringIO()


# Generated at 2022-06-24 11:59:34.988919
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def _assert_can_download(manifest, info_dict, expected_result):
        assert HlsFD.can_download(manifest, info_dict) == expected_result

    manifest_0 = '#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-MEDIA-SEQUENCE:0\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\n/frag/file.ts\n#EXT-X-ENDLIST'
    _assert_can_download(manifest_0, {}, True)


# Generated at 2022-06-24 11:59:46.565940
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import common
    from ..downloader import YoutubeDL

    class FakeInfoDict(object):
        def __init__(self, url, is_live):
            self.url = url
            self.is_live = is_live
    ytdl = YoutubeDL()


# Generated at 2022-06-24 11:59:52.067367
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download(
        """
        #EXTM3U
        #EXT-X-PLAYLIST-TYPE:VOD
        #EXT-X-TARGETDURATION:6
        #EXT-X-VERSION:3
        #EXT-X-MEDIA-SEQUENCE:169640
        #EXTINF:6, no desc
        http://c.brightcove.com/services/mobile/streaming/index/master.m3u8?videoId=3942881388001
        """,
        { 'is_live': False },
    )


# Generated at 2022-06-24 12:00:00.065440
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-PLAYLIST-TYPE:VOD\n#EXTINF:10.0,\n'
        'http://url/to/file.ts\n#EXT-X-ENDLIST\n', {'is_live': False})
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-PLAYLIST-TYPE:VOD\n#EXTINF:10.0,\n'
        'http://url/to/file.ts\n#EXT-X-ENDLIST\n', {'is_live': True})

# Generated at 2022-06-24 12:00:09.666297
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .pytest_utils import FakeYDL
    from ..extractor.common import InfoExtractor
    from .common import FakeHttpServer

    InfoExtractor._download_webpage = lambda *args, **kwargs: (
        '', {})

# Generated at 2022-06-24 12:00:15.128042
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import ExtractorError
    from .common import DownloadTestCase

    close_msg = None
    class TestHlsFD(HlsFD):
        def to_screen(self, msg):
            nonlocal close_msg
            close_msg = msg

    test_result = TestHlsFD(
        TestYoutubeDL({
            'skip_download': True,
            'quiet': True,
            'nooverwrites': True,
            'test': True,
        }), {
            'test_result': True,
        }
    )
    test_result.to_screen = lambda *k: None

    # Test 1: unencrypted fragment
    url = 'https://www.youtube.com/watch?v=MGt25mv4_5s'
    expected_frag

# Generated at 2022-06-24 12:00:24.110906
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import re

# Generated at 2022-06-24 12:00:35.581824
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import warnings
    import traceback

    import pytest
    import youtube_dl.YoutubeDL
    import youtube_dl.FileDownloader
    import youtube_dl.utils
    import tests.extractors
    import tests.downloads
    import tests.test_utils
    from .common import generate_random_string

    def _run_test(test):
        # backup and restore sys.argv:
        argv = sys.argv
        sys.argv = ['youtube-dl', '--no-warnings', '--simulate', '--quiet', '--no-call-home', '--no-color', '--hls-use-mpegts', '--test', '--', test['url']]

# Generated at 2022-06-24 12:00:49.516089
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .http import HttpFD
    from .fragment import FragmentFD
    from .external import FFmpegFD
    from .helpers import FakeYDL
    from .extractor import gen_extractors
    from ..utils import encode_data_uri

    def generate_manifest(num_frags, frag_size, num_ads, ext='mp4', ad_frag_start=False, ad_frag_end=False):
        manifest = (
            '#EXTM3U\n'
            '#EXT-X-MEDIA-SEQUENCE:0\n'
            '#EXT-X-ALLOW-CACHE:YES\n'
            '#EXT-X-TARGETDURATION:8\n'
        )


# Generated at 2022-06-24 12:01:03.932017
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..youtube_dl.YoutubeDL import YoutubeDL
    import os
    from .test_data import test_data_path
    from .http import FakeHttpServer
    from .test import _ytdl_fake_server
    from .extractor import gen_extractors
    server_port = 9191
    server = FakeHttpServer(
        server_port,
        custom_handlers=[(
            r'/hls/(?P<sn>\d{1,6})/(?P<bitrate>\d{1,6})/(?P<id>\d{2,5})/',
            _ytdl_fake_server.handle_manifest_request('hls'))])

# Generated at 2022-06-24 12:01:14.278095
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..test.test_downloader import make_result_object
    res_object = make_result_object('simplest')
    res_object['url'] = 'https://vodhls-uk-live.akamaized.net/wonderwoman/index.m3u8'
    res_object['fragment_retries'] = 10
    res_object['skip_unavailable_fragments'] = True
    res_object['test'] = True
    res_object['_type'] = 'hls'
    res_object['hls_use_mpegts'] = True
    res_object['format'] = '140'
    res_object['protocol'] = 'm3u8_native'
    res_object['http_headers'] = {}
    res_object['http_headers']['User-Agent']

# Generated at 2022-06-24 12:01:17.423765
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(ylad=None, params=None)

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 12:01:24.034622
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import youtube_dl
    import os.path
    import errno
    import tempfile
    import hashlib
    import shutil
    import random
    import string
    import copy
    import socket

    # tests_dir = os.path.dirname(sys.argv[0])
    tests_dir = os.path.dirname(__file__)
    if not tests_dir:
        # We are run from the current dir
        tests_dir = os.path.abspath('.')
    test_file_dir = os.path.join(tests_dir, 'test_files')


# Generated at 2022-06-24 12:01:35.683158
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .extractor.common import InfoExtractor

    # test for simple playlist
    manifest="""#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:5
#EXT-X-MEDIA-SEQUENCE:0
#EXTINF:3,
fileSequence0.ts
#EXTINF:3,
fileSequence1.ts
#EXTINF:3,
fileSequence2.ts"""
    assert HlsFD.can_download(manifest, InfoExtractor({})._match_id(manifest))

    # test for iframe playlist with byte ranges

# Generated at 2022-06-24 12:01:38.609766
# Unit test for constructor of class HlsFD
def test_HlsFD():

    # Check that the constructor does not crash
    hfd = HlsFD({}, None)
    assert hfd



# Generated at 2022-06-24 12:01:47.745395
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 12:01:58.647070
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os.path
    import tempfile
    import unittest

    from .test_common import FakeYDL
    from .downloader_test import FakeDownloader
    from ..compat import compat_urlparse

    class FakeFD(HlsFD):
        def __init__(self, *args, **kwargs):
            HlsFD.__init__(self, *args, **kwargs)
            self._fake_downloader = FakeDownloader()
            self._frag_index = 0
            self._frag_content = [b'Part1', b'Part2']

        def _get_best_downloader(self, *args, **kwargs):
            return self._fake_downloader.downloader

        def _download_fragment(self, ctx, frag_url, info_dict, headers):
            return True

# Generated at 2022-06-24 12:02:10.542074
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    can_download = HlsFD.can_download

    # Live stream is a VOD.
    # This heuristic does not work.
    assert can_download('#EXT-X-MEDIA-SEQUENCE:0', {})

    # AES-128 encrypted media segments.
    # It is not supported yet.
    assert not can_download('#EXT-X-KEY:METHOD=AES-128', {})

    # AES-128 encrypted media segments + media file composed of byte ranges.
    # pycrypto is not installed.
    assert not can_download('#EXT-X-BYTERANGE\n#EXT-X-KEY:METHOD=AES-128', {})

    # pycrypto is installed.

# Generated at 2022-06-24 12:02:23.058047
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    hls_fd = HlsFD()
    assert hls_fd.can_download('#EXTM3U\n#EXT-X-VERSION:3', {})
    assert hls_fd.can_download('#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-BYTERANGE:1', {})
    assert hls_fd.can_download('#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-MEDIA-SEQUENCE:1', {})
    assert hls_fd.can_download('#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-PLAYLIST-TYPE:EVENT', {})

# Generated at 2022-06-24 12:02:35.118560
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    HLS_FEATURES = [
        r'#EXT-X-KEY:METHOD=NONE',  # encrypted streams
        r'#EXT-X-BYTERANGE',  # playlists composed of byte ranges of media files
        r'#EXT-X-MEDIA-SEQUENCE:(?!0$)',  # live streams
        r'#EXT-X-PLAYLIST-TYPE:EVENT',  # media segments may be appended to the end of event media playlists
        r'#EXT-X-MAP',  # media initialization
    ]
    for feature in HLS_FEATURES:
        test_url = 'https://example.com/index.m3u8'
        test_manifest = feature + '\n#EXT-X-TARGETDURATION:1\n#EXT-X-VERSION:3\n' + test_

# Generated at 2022-06-24 12:02:43.093198
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def test_url(url, expected_result, test_info_dict={}):
        """ Test that video url returns expected_result. """
        fake_ydl = type('FakeYdl', (object,), {})()
        test_info_dict['url'] = url
        assert HlsFD.can_download(url, test_info_dict) == expected_result

    def test_info_dict(expected_result, **test_info_dict):
        fake_ydl = type('FakeYdl', (object,), {})()
        assert HlsFD.can_download('', test_info_dict) == expected_result

    test_url('', False)
    test_url('#EXTM3U', True)
    test_url('#EXTM3U\n', True)

# Generated at 2022-06-24 12:02:52.029764
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import os.path

    class HlsTestCase(unittest.TestCase):
        def setUp(self):
            import youtube_dl

            self.params = {
                'fragment_retries': 0,
                'skip_unavailable_fragments': False,
                'test': True,
            }

            self.ydl = youtube_dl.YoutubeDL(self.params)
