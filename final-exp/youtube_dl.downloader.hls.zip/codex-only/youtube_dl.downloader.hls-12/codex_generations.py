

# Generated at 2022-06-24 11:52:55.884394
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import gen_extractors
    from ..utils import match_filter_func
    for ie in gen_extractors():
        if ie.IE_NAME != 'AOL':
            continue
        info_dict = ie._real_extract('https://on.aol.com/video/some-video-title-526465418')
        formats = ie._formats_to_filter(info_dict['formats'])
        formats = match_filter_func(formats)(lambda d: d['format_id'] == 'sd_video')
        if not len(formats):
            continue
        info_dict['formats'] = formats
        info_dict['url'] = formats[0]['url']
        info_dict['protocol'] = formats[0].get('protocol', 'http')
        info_dict

# Generated at 2022-06-24 11:53:07.086186
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    manifest = '\n'.join((
        "#EXTM3U",
        "#EXT-X-VERSION:2",
        "#EXT-X-PLAYLIST-TYPE:VOD",
        "#EXTINF:1.000,no desc",
        "fileSequence0.ts",
        "#EXT-X-KEY:METHOD=NONE",
        "#EXT-X-ENDLIST",
    ))

    # Successful case 1: no encryption
    assert HlsFD.can_download(manifest, {})

    manifest = manifest.replace(
        "#EXT-X-KEY:METHOD=NONE",
        "#EXT-X-KEY:METHOD=AES-128")

    # Successful case 2: no encryption
    assert HlsFD.can_download(manifest, {})

    # Failure case 1: encryption without pycrypto library
   

# Generated at 2022-06-24 11:53:13.372640
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:53:24.212815
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .fragment import FragmentFD
    from .http import HttpFD
    from .external import FFmpegFD
    from .dash import DASHFD

    test_url = 'http://test.m3u8'
    info_dict = {
        'url': test_url,
        'ext': 'mp4',
    }

    def test(manifest, info_dict, expected):
        assert HlsFD.can_download(manifest, info_dict) is expected
        assert FragmentFD.can_download(test_url, info_dict) is True
        assert HttpFD.can_download(test_url, info_dict) is True
        assert FFmpegFD.can_download(test_url, info_dict) is True
        assert DASHFD.can_download(test_url, info_dict) is True

# Generated at 2022-06-24 11:53:31.634578
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    HlsFD.can_download.__globals__['can_decrypt_frag'] = False
    assert HlsFD.can_download('foo', {'url': '', 'is_live': False})
    assert HlsFD.can_download('foo', {'url': '', 'is_live': False, 'extra_param_to_segment_url': ''})
    assert HlsFD.can_download('foo', {'url': '', 'is_live': False, 'extra_param_to_segment_url': '', '_decryption_key_url': ''})
    assert not HlsFD.can_download('foo', {'url': '', 'is_live': True})

# Generated at 2022-06-24 11:53:41.626726
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import tempfile
    from ..extractor.common import InfoExtractor
    from .common import prepare_test, FakeYDL

    class TestHlsDownloader(InfoExtractor):
        def prepare_filename(self, info_dict):
            return prepare_test('test.ts', info_dict)


# Generated at 2022-06-24 11:53:53.312074
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest
    class Test_HlsFD_can_download(unittest.TestCase):
        def setUp(self):
            self.manifest_with_supported_features = (
                '#EXTM3U\n'
                '#EXT-X-MEDIA-SEQUENCE:0\n'
                '#EXTINF:8,\n'
                'http://media.example.com/fileSequence1.ts\n'
                '#EXTINF:7,\n'
                'http://media.example.com/fileSequence2.ts\n'
                '#EXTINF:6,\n'
                'http://media.example.com/fileSequence3.ts\n'
            )

# Generated at 2022-06-24 11:54:00.092930
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:54:11.315890
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest

    class TestHlsFD(unittest.TestCase):
        def test_stream_fmt(self):
            hlsfd = HlsFD(None, None)
            self.assertTrue(hlsfd.can_download("#EXTM3U\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=212000,RESOLUTION=576x324,CODECS=\"avc1.42001e,mp4a.40.2\"\nlowlatency_ld/ld/ld_576x324_h264_130k.m3u8", None))

# Generated at 2022-06-24 11:54:22.112426
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import tempfile

    if sys.version_info < (3, 0):
        import youtube_dl.extractor.common as common
        input = raw_input
        FileIO = file
    else:
        from io import FileIO
        import youtube_dl.extractor.common as common
        input = input

    # Use an arbitrary manifest
    manifest_url = 'http://smoothstreaming.tbs.com/videos/tbs_deadpool_c3/tbs_deadpool_c3.ism/Manifest'
    headers = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36'}

    # Download manifest

# Generated at 2022-06-24 11:54:33.877571
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXT-X-VERSION:3\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:1.0,\nsegment1.ts\n#EXTINF:1.0,\nsegment2.ts\n#EXTINF:1.0,\nsegment3.ts\n#EXT-X-ENDLIST\n', 'hlsvideo') == True

# Generated at 2022-06-24 11:54:37.499335
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.__name__ == 'HlsFD'
    assert HlsFD.__doc__ is not None
    assert HlsFD._HLS_TEST_FILE_MAX_SIZE % 16 == 0
    assert HlsFD.can_download.__doc__ is not None

# Generated at 2022-06-24 11:54:39.680473
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hlsfd = HlsFD({})
    assert hlsfd.params == {}


# Generated at 2022-06-24 11:54:50.043967
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    class hls_manifest:
        def __init__(self, manifest, info = None):
            self.manifest = manifest
            self.info = info

    class FakeYdl:
        def __init__(self):
            self.params = {}

        def to_screen(self, message):
            pass

        def report_error(self, message):
            pass

        def urlopen(self, url):
            url = url.get_full_url()
            query = compat_urlparse.parse_qs(compat_urlparse.urlparse(url).query)
            if 'm3u8' in query:
                m3u8_number = int(query['m3u8'][0])
                return hls_manifest(hls_manifests[m3u8_number])

# Generated at 2022-06-24 11:55:00.974513
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # pylint: disable=protected-access
    # pylint: disable=invalid-name

    def _get_frag_content():
        return b'\x00' * 10

    def _download_fragment(ctx, url, info_dict, headers):
        return True, _get_frag_content()

    class _HlsFD(HlsFD):

        @staticmethod
        def _prepare_url(info_dict, url):
            return url

        def _prepare_and_start_frag_download(self, ctx):
            ctx.update({
                'filename': '',
                'total_frags': 1,
                'ad_frags': 0,
            })


# Generated at 2022-06-24 11:55:03.199538
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.__name__ == "HlsFD"
    assert HlsFD.__module__ == "youtube_dl.downloader.hls"

# Generated at 2022-06-24 11:55:09.993880
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    from .utils import TEST_DATA_DIR


# Generated at 2022-06-24 11:55:15.592544
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    HlsFD = HlsFD()

    # can_download() should return True if manifest has no feature
    assert HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-VERSION:3\n'
        '#EXT-X-TARGETDURATION:4\n'
        '#EXT-X-MEDIA-SEQUENCE:0\n'
        '#EXTINF:3,\n'
        '#EXTINF:3,\n'
        '#EXTINF:3,\n'
        '#EXTINF:4,\n'
        '#EXT-X-ENDLIST\n\n',
        {'url': 'url'}
    )

    # can_download() should return False if manifest has EXT-X-KEY:METHOD=A

# Generated at 2022-06-24 11:55:25.187747
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-VERSION:3\n'
        '#EXT-X-TARGETDURATION:2\n'
        '#EXT-X-MEDIA-SEQUENCE:2680\n'
        '#EXT-X-KEY:METHOD=AES-128,URI="https://priv.example.com/key.php?r=52"\n'
        '#EXTINF:2.833,\n'
        'http://media.example.com/fileSequence52-A.ts\n'
        '#EXTINF:15.0,\n'
        'http://media.example.com/fileSequence52-B.ts\n',
        {}
    ) == False
    assert HlsFD

# Generated at 2022-06-24 11:55:36.553918
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.generic import GenericIE

    info = {
        '_type': 'url_transparent',
        'format': 'mp4',
        'format_id': 'mp4',
        'ext': 'mp4',
        'url': 'http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8',
        'display_id': 'bipbopall-mp4',
        'protocol': 'm3u8_native',
        'protocol_id': 'm3u8_native',
        'http_headers': {},
    }

    # Initialize YoutubeDL object
    ydl = YoutubeDL()
    ydl.simulate = False
    ydl.params['test'] = True


# Generated at 2022-06-24 11:55:49.045440
# Unit test for constructor of class HlsFD
def test_HlsFD():
    class testHlsFD(HlsFD):
        def report_warning(self, msg):
            print(msg)

        def report_error(self, msg):
            print(msg)

    hlsFD = testHlsFD({})
    assert can_decrypt_frag or hlsFD.can_download(
        "#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXT-X-VERSION:4\n#EXT-X-PLAYLIST-TYPE:VOD\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:10,\n#EXT-X-KEY:METHOD=AES-128,URI=\"https://priv.example.com/key.php?r=52\"", {})

# Generated at 2022-06-24 11:55:56.140447
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.generic import GenericIE
    from ..downloader.common import FileDownloader
    url = 'https://example.com/manifest.m3u8'
    info = dict(GenericIE._extract_info(FileDownloader({}), url))
    hls_fd = HlsFD(FileDownloader({}), {})
    assert hls_fd.can_download(info)

# Generated at 2022-06-24 11:56:04.958973
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import youtube_dl.YoutubeDL
    import os
    import time

    temp_file_name = './test/test_media_frags/temp-%f.mp4' % time.time()
    if os.path.exists(temp_file_name):
        os.unlink(temp_file_name)
    ydl_opts = {
        'noplaylist': True,
        'forceurl': True,
        'format': 'best',
        'simulate': True,
        'quiet': True,
        'skip_download': True,
        'outtmpl': temp_file_name,
    }
    ydl = youtube_dl.YoutubeDL(ydl_opts)


# Generated at 2022-06-24 11:56:10.528461
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .http import HttpFD
    from ..extractor import common
    from ..utils import RegexNotFoundError
    from ..downloader import YoutubeDL
    from .external import ExternalFD

    params = {
        'skip_download': True,
        'usenetrc': False,
        'username': 'a',
        'password': 'b',
        'quiet': True,
    }
    ydl = YoutubeDL(params)

    assert isinstance(FragmentFD(ydl, params), FragmentFD)
    info = {
        'url': 'https://example.com/',
        'http_headers': {
            'Range': 'bytes=0-',
        },
    }
    assert isinstance(FragmentFD(ydl, params), FragmentFD)

# Generated at 2022-06-24 11:56:22.759512
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import sys
    import unittest
    import doctest

    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.test
    import youtube_dl.utils
    import youtube_dl.downloader.fragment

    sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'test'))
    from hlsnative_test import _mock_hls_manifest, _mock_fragment

    class TestDownload(object):
        def __init__(self):
            self.to_screen = youtube_dl.utils.std_out_encode
            self.params = {
                'fragment_retries': 0,
                'skip_unavailable_fragments': False,
                'test': True,
            }

       

# Generated at 2022-06-24 11:56:34.740214
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import FakeYDL
    from .test_common import get_testdata_file
    def get_test_file_path():
        test_file = get_testdata_file('test_hls_real_download_success.m3u8')
        assert test_file is not None
        return test_file
    ydl = FakeYDL()
    hls_fd = HlsFD(ydl, {})
    result = hls_fd.real_download(get_test_file_path(), {
        'url': 'https://example.com/test.m3u8',
        '_decryption_key_url': 'https://example.com/key.bin',  # test decryption
        'extra_param_to_segment_url': 'extra-param=1',  # test query addition
    })

# Generated at 2022-06-24 11:56:43.494468
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..compat import compat_etree_fromstring
    from ..utils import sanitize_open

    class FakeInfoExtractor(InfoExtractor):
        def _download_webpage(self, *args, **kargs):
            return ('#EXTM3U\n'
                    '#EXT-X-TARGETDURATION:10\n'
                    '#EXTINF:10,\n'
                    '#EXT-X-ENDLIST\n', {})

        _FILE_TEMPLATE = '%(file)s'

    class FakeYDL():
        def prepare_filename(self, info_dict):
            return info_dict.get('file', 'test.mp4')

        def to_screen(self, msg):
            pass


# Generated at 2022-06-24 11:56:52.684347
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:48\n#EXT-X-MEDIA-SEQUENCE:1\n#EXTINF:48.0,\n', {})
    assert_raises(
        AssertionError,
        HlsFD.can_download,
        '#EXTM3U\n#EXT-X-TARGETDURATION:48\n#EXT-X-MEDIA-SEQUENCE:1\n#EXTINF:48.0,\n', {'is_live': True})

# Generated at 2022-06-24 11:56:59.047083
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    hls_fd = HlsFD(None, None)
    assert hls_fd.can_download(None, {'is_live': True}) == False
    assert hls_fd.can_download(None, {'is_live': False}) == True
    assert hls_fd.can_download("#EXT-X-KEY:METHOD=NONE", {'is_live': False}) == True
    assert hls_fd.can_download("#EXT-X-KEY:METHOD=AES-128", {'is_live': False}) == can_decrypt_frag
    assert hls_fd.can_download("#EXT-X-KEY:METHOD=AES-128\n#EXT-X-BYTERANGE", {'is_live': False}) == False

# Generated at 2022-06-24 11:57:08.583315
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:57:18.756705
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:57:22.365876
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ''' Test the constructor of class HlsFD '''

    # Create a HlsFD instance
    hlsFD = HlsFD({}, {})
    return True


# Generated at 2022-06-24 11:57:31.545977
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import FakeYDL
    # Downloading of m3u8 file

# Generated at 2022-06-24 11:57:42.637378
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class TestInfoDict:
        def __init__(self, is_live):
            self.is_live = is_live

    def test_assertion(manifest, is_live, can_download, can_download_frag):
        info_dict = TestInfoDict(is_live)
        assert HlsFD.can_download(manifest, info_dict) == (can_download and can_download_frag)

    test_assertion('#EXT-X-PLAYLIST-TYPE:EVENT', False, False, True)
    test_assertion('#EXT-X-PLAYLIST-TYPE:EVENT', True, False, True)

    test_assertion('#EXT-X-MEDIA-SEQUENCE:1', False, False, True)

# Generated at 2022-06-24 11:57:48.461199
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..compat import compat_urllib_request
    from ..utils import is_outdated_version
    import youtube_dl
    import unittest

    ydl = youtube_dl.YoutubeDL({})
    if is_outdated_version(ydl._version, '2019.07.16'):
        unittest.SkipTest('This test is only available in youtube-dl version 2019.07.16 and above')

    class MockManifest(str):
        def __init__(self, manifest_str):
            self.manifest_str = manifest_str

        def read(self):
            return self.manifest_str.encode('utf-8')

    def can_download(manifest_str, info_dict):
        return HlsFD.can_download(manifest_str, info_dict)

    # Basic

# Generated at 2022-06-24 11:57:58.259024
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """ Method real_download of class HlsFD is tested """
    import sys
    from .test_downloads import (
        setUp, getInfoDict, getFakeYDL,
        fake_urlretrieve, modify_manifest,
    )

    with setUp(path=sys.modules[__name__].__file__, tdata=[1]):
        ydl = getFakeYDL()
        info_dict = getInfoDict(
            ydl,
            {
                'url': 'http://testurl.com/manifest.m3u8',
                'format': 'hls-0',
            },
            'test_HlsFD_real_download',
        )

    hlsfd = HlsFD(ydl, info_dict)

    # Test without encryption

# Generated at 2022-06-24 11:58:09.421172
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import json
    import os
    import unittest
    import youtube_dl.extractor.common as common

    def can_download(manifest, is_live=False):
        """Helper function to return result of method can_download"""
        try:
            return HlsFD.can_download(manifest, {'is_live': is_live})
        except common.DownloadError as e:
            return False, e.args[0]

    def hls_playlist_test_cases(test_data_filename):
        """Yield test cases with hash as test name and test data as value"""
        test_cases = json.load(open(test_data_filename))
        for test_data_hash, test_data in test_cases.items():
            yield test_data_hash, test_data


# Generated at 2022-06-24 11:58:19.984029
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os.path
    import shutil
    import tempfile
    import time
    import unittest

    from ..extractor import gen_extractors

    class FakeInfoDict(object):
        def __init__(self, url, http_headers):
            self.url = url
            self.http_headers = http_headers

    class FakeYDL(object):
        def __init__(self, tmp_dir, body_map, tests, report_warning, report_error):
            self.tmp_dir = tmp_dir
            self.body_map = body_map
            self.tests = tests
            self.report_warning = report_warning
            self.report_error = report_error

        def download(self, url_list):
            for url in url_list:
                body = self.body_map[url]

# Generated at 2022-06-24 11:58:20.631373
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass

# Generated at 2022-06-24 11:58:23.452064
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    sys.path.append('..')     # for module youtube_dl
    from youtube_dl.downloader.hls import HlsFD
    hlsfd = HlsFD(None, None)

# Generated at 2022-06-24 11:58:35.388199
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os

    os.environ['YOUTUBE_DL_NO_FFMPEG'] = '1'


# Generated at 2022-06-24 11:58:44.037543
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    # Test for audio only stream
    ie = InfoExtractor()
    fake_info_dict = {
        'url': 'http://example.com',
        'playlist': [
            'http://example.com/stream-0.ts',
            'http://example.com/stream-1.ts',
            'http://example.com/stream-2.ts',
            'http://example.com/stream-3.ts',
        ],
    }
    hls_fd = HlsFD(ie, {}, fake_info_dict)
    assert hls_fd.total_frags == 4
    assert hls_fd.fragment_index == 0

    # Test for non-live stream with ad_frags
    ie = InfoExtractor()
    fake_info_

# Generated at 2022-06-24 11:58:51.274110
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Initialize an HlsFD instance
    hlsfd = HlsFD()

    # Testing for live streams, requires pycrypto
    # Tests for live streams are commented out in method can_download to avoid errors
    # Input:
    #   manifest = '#EXTM3U\n'
    #              '#EXT-X-TARGETDURATION:10\n'
    #              '#EXT-X-MEDIA-SEQUENCE:0\n'
    #              '#EXTINF:10,\n'
    #              'bipbop-gear1/prog_index.m3u8\n'
    #              '#EXT-X-ENDLIST'
    #   info_dict = {'is_live': True}
    # Expected output:
    #   False

    # Test 1
    info

# Generated at 2022-06-24 11:58:57.473341
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import gzip
    import os
    import shutil
    import tempfile
    from unittest.mock import MagicMock
    from unittest.mock import patch
    temp_dir = tempfile.mkdtemp(prefix='ytdl-test')
    shutil.rmtree(temp_dir)
    shutil.copytree('test_data/test_HlsFD_real_download', os.path.join(temp_dir, 'td'))
    mock_ydl = MagicMock()
    mock_ydl.params = {'test': True}
    mock_ydl.to_screen = MagicMock()
    mock_ydl.report_warning = MagicMock()
    mock_ydl.report_error = MagicMock()

# Generated at 2022-06-24 11:59:05.068473
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # test if we can download a fragment
    import os
    import sys
    import tempfile
    import shutil

    from ..utils import (
        sanitize_open,
        encodeFilename,
        url_basename,
        DownloadError,
    )

    # temporary directory where test files will be created
    temp_dir = tempfile.mkdtemp(prefix='youtube-dl.test.', suffix='.tmp')

    # insert created temporary directory at the beginning of sys.path
    # in order to force youtube_dl to search for modules there
    sys.path.insert(0, temp_dir)

    src = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'test_data',
        'hls')

# Generated at 2022-06-24 11:59:16.412093
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import FakeYDL
    from ..extractor.youtube import YoutubeIE
    ydl = FakeYDL()
    params = {}
    params['progress_hooks'] = []
    params['test'] = True
    ydl.params = params
    ydl.add_info_extractor(YoutubeIE())
    ydl.prepare_filename({})
    info_dict = ydl.extract_info(
        'https://www.youtube.com/watch?v=u0XQQhv-uHg', download=False)
    info_dict['url'] = info_dict['url_transparent']
    fragment_filename = ydl._prepare_filename(info_dict['requested_formats'][0])
    hls_fd = HlsFD(ydl, params)
    hls_

# Generated at 2022-06-24 11:59:26.948763
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    manifest = '\n'.join((
        '#EXTM3U',
        '#EXT-X-TARGETDURATION:10',
        '#EXT-X-KEY:METHOD=AES-128,URI="https://priv.example.com/key.php?r=52"',
        '#EXTINF:10,',
        'http://media.example.com/fileSequence52-1.ts',
        '#EXTINF:10,',
        'http://media.example.com/fileSequence52-2.ts',
        '#EXT-X-ENDLIST',
    ))

# Generated at 2022-06-24 11:59:33.628138
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import ytdl_class
    from .extractor import YoutubeIE

    ydl_opts = {
        'fragment_retries': 0,
        'skip_unavailable_fragments': False,
        'progress_hooks': [],
        'noprogress': True,
    }
    ydl = ytdl_class('https://www.youtube.com/watch?v=Ik-RsDGPI5Y', ydl_opts)
    ie = YoutubeIE(ydl)
    info = ie.extract('https://www.youtube.com/watch?v=Ik-RsDGPI5Y')
    info_dict = info['entries'][0]
    man_url = info_dict['url']

# Generated at 2022-06-24 11:59:38.113503
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.__name__ == 'HlsFD'
    # There is no constructor but we will make test case for checking whether
    # HlsFD can be constructed without parameters or not.
    HlsFD()

# Generated at 2022-06-24 11:59:48.524267
# Unit test for constructor of class HlsFD
def test_HlsFD():
    if can_decrypt_frag:
        from .fragment import FragmentFD
        from .downloader import YoutubeDL
        from .extractor import Downloader
        from .extractor import YoutubeIE
        from .extractor import YoutubePlaylistIE

        def custom_progress_hook(d):
            if d['status'] == 'downloading':
                print('downloading percentage: %.1f' % (float(d['downloaded_bytes']) / d['total_bytes'] * 100) )

        ydl = YoutubeDL({'logger': Downloader('test')})
        ydl.add_progress_hook(custom_progress_hook)
        ydl.add_default_info_extractors()
        ydl.add_info_extractor(YoutubeIE())

# Generated at 2022-06-24 11:59:56.344348
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.http import YoutubeDLHttpRequest

    def _download_fragment(ctx, frag_url, info_dict, headers):
        """
        Downloads a fragment and returns a tuple of the downloaded
        contents and the fragment's content length (see
        URLOpenProcessor.process() for details)
        """
        ie = YoutubeDLHttpRequest()
        request = YoutubeDLHttpRequest.urlopen(ie, frag_url, headers=headers)
        urlh = request.urlopen
        return (True, urlh.read())

    def _prepare_url(info_dict, url):
        return YoutubeDLHttpRequest.urlopen(YoutubeDLHttpRequest(), url).geturl()

    # Test HlsFD.download with a basic HLS playlist

# Generated at 2022-06-24 12:00:01.802034
# Unit test for constructor of class HlsFD
def test_HlsFD():
    return HlsFD

# Unit tests for HlsFD
from .tests import fd_download_tester
from .tests import downloader_transfer
from .tests import unittest
from .tests import get_test_data_file
import os


# Generated at 2022-06-24 12:00:02.459908
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass



# Generated at 2022-06-24 12:00:10.873073
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 12:00:13.727228
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Prepare arguments
    _manifest = ''
    _info_dict = {}

    # Call the target.
    res = HlsFD.can_download(_manifest, _info_dict)

    # Assert results.
    assert res is True, res



# Generated at 2022-06-24 12:00:23.294405
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..test import get_test_data
    import os.path


# Generated at 2022-06-24 12:00:34.766499
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import os
    from .test_cyberlockers import gettestcases
    from .test_external import get_testcases as get_external_testcases
    from .test_download import get_testcases as get_generic_testcases
    from .test_fragment import get_testcases as get_fragment_testcases

    from ..extractor import gen_extractors

    test_cases = (get_external_testcases() + get_fragment_testcases() +
                  get_generic_testcases() + gettestcases())

    class HlsFDRemoteTest(unittest.TestCase):

        def __init__(self, url, expected_fsize, expected_frags, expected_ad_frags, expected_error):
            self.url = url
            self.expected_f

# Generated at 2022-06-24 12:00:44.677613
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import random
    import hashlib
    import subprocess
    from datetime import datetime

# Generated at 2022-06-24 12:00:53.687847
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import unittest
    from .mock_server import MockServer
    from .urn_mock import UrnMock
    from .seekable_stream import SeekableTestStream
    from .utils_test import TestDownloader
    try:
        from io import BytesIO
    except ImportError:
        from StringIO import StringIO as BytesIO

# Generated at 2022-06-24 12:01:06.717916
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    try:
        from Crypto.Cipher import AES
    except ImportError:
        return
    manifest_url = 'http://fcod.llnwd.net/a792/o30/testing/new_testing.m3u8'
    ydl = FakeYDL()
    dl = HlsFD(ydl=ydl, params={
        'outtmpl': '%(id)s.ts',
        'test': True,
    })
    dl.real_download(
        filename='test',
        info_dict={'url': manifest_url, 'http_headers': {'Cookie': 'token=test'}})
    assert(ydl.method == 'GET')
    assert(ydl.url == manifest_url)
    assert(ydl.headers['Cookie'] == 'token=test')

# Generated at 2022-06-24 12:01:07.799383
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 12:01:20.849682
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Unit test for method real_download of class HlsFD
    import os
    import unittest
    import tempfile
    from .http import HTTPFD
    from ..downloader import YoutubeDL

    class HlsFDTestCase(unittest.TestCase):
        def setUp(self):
            self.testutils_state = {
                'ydl': None,
                'tmpdir': None,
            }

        def tearDown(self):
            YoutubeDL(self.testutils_state['ydl']).cleanup()
            if os.path.exists(self.testutils_state['tmpdir']):
                os.rmdir(self.testutils_state['tmpdir'])


# Generated at 2022-06-24 12:01:26.008673
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD
    assert HlsFD.can_download({}, {}) is False
    assert HlsFD.can_download("#EXTM3U", {}) is True
    assert HlsFD.can_download("#EXT-X-KEY", {'is_live': True}) is False


# Generated at 2022-06-24 12:01:38.384960
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class FakeYdl:
        def __init__(self):
            self.params = {}

    class FakeInfoDict:
        def __init__(self):
            self.get = lambda param: None

    from .fragment import FragmentFD
    FakeYdl.urlopen = lambda *args: None
    FakeInfoDict._decryption_key_url = 'https://example.com/key.bin'

    # Not supported, returns False
    assert not HlsFD.can_download(
        '#EXT-X-KEY:METHOD=FOO', FakeInfoDict())

    FakeInfoDict.get = lambda param: True
    # Live streams are not supported, returns False
    assert not HlsFD.can_download(
        '#EXT-X-KEY:METHOD=NONE', FakeInfoDict())
    # Enc

# Generated at 2022-06-24 12:01:52.641411
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import pytest
    hls_fd = HlsFD(None, None)

    manifest = """
    #EXTM3U
    #EXT-X-MEDIA-SEQUENCE:957
    #EXTINF:10,
    http://media.example.com/fileSequence958.ts
    #EXTINF:10,
    http://media.example.com/fileSequence959.ts
    """
    is_live = {'is_live': False}

    # Live stream detection heuristic does not work
    assert hls_fd.can_download(manifest, is_live)

    # Live stream detection heuristic does work

# Generated at 2022-06-24 12:01:57.891306
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    method = HlsFD.real_download
    # Test various cases
    # Case 1
    manifest = r'''
#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:10
#EXT-X-MEDIA-SEQUENCE:0
#EXT-X-PLAYLIST-TYPE:VOD
#EXTINF:10,
http://media.example.com/first.ts
#EXTINF:10,
http://media.example.com/second.ts
#EXTINF:10,
http://media.example.com/third.ts
#EXT-X-ENDLIST
'''
    assert method(manifest, {}) == True, 'Case 1'



# Generated at 2022-06-24 12:02:09.623824
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    """ Test for method can_download of class HlsFD. """
    HlsFD = HlsFD()
    UNSUPPORTED_FEATURES = (
        r'#EXT-X-KEY:METHOD=(?!NONE|AES-128)',  # encrypted streams [1]
        r'#EXT-X-BYTERANGE',  # playlists composed of byte ranges of media files [2]
        r'#EXT-X-MEDIA-SEQUENCE:(?!0$)',  # live streams [3]
        r'#EXT-X-PLAYLIST-TYPE:EVENT',  # media segments may be appended to the end of
                                        # event media playlists [4]
        r'#EXT-X-MAP:',  # media initialization [5]
    )

# Generated at 2022-06-24 12:02:19.374714
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import itertools
    import youtube_dl.extractor.http as http
    import youtube_dl.extractor.common as common

    try:
        from Crypto.Cipher import AES
        can_decrypt_frag = True
    except ImportError:
        can_decrypt_frag = False

    def gen_m3u8_manifest(lines):
        return '\n'.join(lines) + '\n'

    def gen_m3u8_key_decrypt_info(method, uri, iv=b'\x00' * 16):
        return ('#EXT-X-KEY:METHOD=%s,URI="%s",IV=0x%s\n'
                % (method, uri, iv.hex()))


# Generated at 2022-06-24 12:02:32.078453
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import json

# Generated at 2022-06-24 12:02:40.499245
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..downloader.hls import HlsFD
    from ..downloader.external import FFmpegFD
    from .test_common import (_get_testdata_folder_path, _ytdl_run, _ytdl_test)

    def _test_HlsFD_can_download(file_name, downloader_class):
        file_path = _get_testdata_folder_path() / file_name
        with file_path.open(encoding='utf-8') as man_file:
            manifest = man_file.read()
            info_dict = {
                'url': 'https://example.com/video.m3u8',
                'http_headers': {'User-Agent': 'Test user agent'},
            }

# Generated at 2022-06-24 12:02:50.842928
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Create a new HlsFD object and use it to download an m3u8 playlist
    ydl = YoutubeDL()
    ydl.params['noprogress'] = True
    fd = HlsFD(ydl, {})
    info_dict = {'url': ''}
    man_url = 'https://www.youtube.com/watch?v=kJQP7kiw5Fk'
    urlh = ydl.urlopen(man_url)
    man_url = urlh.geturl()
    info_dict['url'] = man_url