

# Generated at 2022-06-24 11:52:54.363481
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl_opts = {'verbose': True, 'skip_download': True,
                'outtmpl': '%(id)s.f4m', 'quiet': True}
    dl = YoutubeDL(ydl_opts)
    dl.add_info_extractor(HlsFD.ie_key())
    url = 'http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8'
    info = dl.extract_info(url, download=False)
    fd = HlsFD(dl, info['http_headers'])
    assert fd.FD_NAME == 'hlsnative'
    for ph in fd._progress_hooks:
        fd.remove_progress

# Generated at 2022-06-24 11:52:55.389271
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass


# Generated at 2022-06-24 11:53:02.697656
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .http import HttpFD
    from . import YoutubeDLHandler
    from .extractor.common import InfoExtractor
    from .extractor.generic import YoutubeIE
    from .utils import DateRange


# Generated at 2022-06-24 11:53:13.693282
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .extractor.common import InfoExtractor
    from .downloader import FileDownloader
    import json

    url = 'https://bitdash-a.akamaihd.net/content/MI201109210084_1/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8'
    json_path = 'hls.json'
    with open(json_path, 'r') as f:
        info_json = json.load(f)
    ie = InfoExtractor({'test': True})
    ie._real_initialize(url)
    info = ie.extract(url)
    info.update(info_json)

    fd = HlsFD(FileDownloader({'test': True}), info)

# Generated at 2022-06-24 11:53:23.953471
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:53:31.415728
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.generic import FakeYDL  # Avoid circular import
    from ..utils import encode_compat_str

    def _make_info_dict(url, manifest, is_live=False):
        class InfoDict(dict):
            def setdefault(self, *args, **kwargs):
                return dict.setdefault(self, *args, **kwargs)
        info_dict = InfoDict()
        info_dict['url'] = url
        manifest = encode_compat_str(manifest, 'utf-8')
        info_dict['_type'] = 'hls'
        info_dict['ie_key'] = 'HlsFD'
        info_dict['manifest_url'] = url
        info_dict['manifest'] = manifest
        info_dict['is_live'] = is_live
        return

# Generated at 2022-06-24 11:53:41.442761
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import make_HTTPServer
    from .fragment import FileFragmentFD
    import socket
    import threading
    import time
    import os
    import re

    def get_file_duration(file_location):
        if os.path.exists('ffprobe'):
            import subprocess
            out = subprocess.check_output(['ffprobe', file_location])
            duration = re.search('\sDuration: (\d+:\d+:\d+.\d+)', out)
            if duration:
                duration = duration.group(1)
                duration = duration.split(':')
                duration = int(duration[0]) * 3600 + int(duration[1]) * 60 + float(duration[2])
                return duration
            else:
                return 0
        else:
            return 0



# Generated at 2022-06-24 11:53:53.175855
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    from .test_fragments import MockYDL
    from .test_download_common import (
        setUp, setUpMockServer, tearDown,
        get_content_by_url, assert_equal_files,
    )

    setUp()
    setUpMockServer()

    def check_HlsFD_real_download(test_params, hls_manifest, hls_frag_data, expected_content):
        ydl = MockYDL()
        fd = HlsFD(ydl, {'logger': ydl})

        with pytest.raises(RegexMatchError):
            fd.real_download('test.mp4', test_params)


# Generated at 2022-06-24 11:54:05.405712
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\nmedia-00001.ts', {'url': 'https://example.org/index.m3u8'})

# Generated at 2022-06-24 11:54:16.831450
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('', {})
    assert HlsFD.can_download('#EXTM3U', {})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=NON-AES128', {})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {'is_live': True})
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-BYTERANGE', {})

# Generated at 2022-06-24 11:54:25.086320
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # TODO Write unit test for method real_download of class HlsFD
    err_msg = ""
    try:
        from .test import test
    except ImportError:
        err_msg = "test_HlsFD_real_download: 'from .test import test' failed"
        return err_msg
    err_msg = test(HlsFD)
    if err_msg == None:
        print("test_HlsFD_real_download: PASSED")
    else:
        print("test_HlsFD_real_download: FAILED")
    return err_msg

# Generated at 2022-06-24 11:54:25.763567
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass

# Generated at 2022-06-24 11:54:35.779947
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import shutil
    import tempfile
    import youtube_dl.YoutubeDL
    import youtube_dl.utils
    from .test_HlsFD import HlsFD

    # This example manifest can be generated with the command:
    #  youtube-dl -f hls-1440p -g https://www.youtube.com/watch?v=f1gkX2Qhzfs
    # then stripping some lines to make the file smaller.

# Generated at 2022-06-24 11:54:41.064265
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import ydl_opts
    import ydl

    ydl_opts.format_options['hls_use_mpegts'][1] = False
    ydl_opts.format_options['ffmpeg_location'][1] = 'ffmpeg'
    ydl_opts.format_options['hls_prefer_native'][1] = True
    ydl_opts.format_options['hls_segment_filename'][1] = 'test.mp4'

    info_dict = {
        'url': 'http://127.0.0.1:8080/index.m3u8'
    }

    with open('test.m3u8', 'r') as file:
        manifest = file.read()


# Generated at 2022-06-24 11:54:45.255108
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """Test constructor of class HlsFD"""
    from ..YoutubeDL import YoutubeDL
    from .utils import FakeYDL
    fakeydl = FakeYDL()
    hlsfd = HlsFD(fakeydl, {})
    assert hlsfd.ydl == fakeydl

# Generated at 2022-06-24 11:54:57.421911
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .dash import DashFD, can_download_dash
    from .http import HttpFD
    from .fragment import FragmentFD
    from .external import FFmpegFD
    from .wvm import WvmFD, can_download_wvm

    # start with a clean slate
    for name, fd_class in FragmentFD.registered_fd.items():
        del FragmentFD.registered_fd[name]
    FragmentFD.downloader = None

    # class definitions are registered in FragmentFD
    fd_classes = (DashFD, HttpFD, HlsFD, FFmpegFD, WvmFD)
    assert len(FragmentFD.registered_fd) == 0

    # constructor of HlsFD registers classes
    fd = HlsFD({})
    assert fd is not None

# Generated at 2022-06-24 11:55:05.372668
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    from .test_fragment import _test_real_download

    class HlsFD_Test(unittest.TestCase):
        def setUp(self):
            self.fd = HlsFD({'test': True})

# Generated at 2022-06-24 11:55:18.352692
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():

    import sys
    import tempfile
    import unittest
    import youtube_dl.YoutubeDL

    # See https://stackoverflow.com/questions/45729116/python-how-to-make-a-class-represent-its-own-module-in-unittest
    class TestHlsFD(unittest.TestCase):

        def setUp(self):
            self.ydl = youtube_dl.YoutubeDL({
                'hls_prefer_native': True,
                'skip_download': True,
                'quiet': True,
                'logger': self.logger,
                'progress_hooks': [self.progress_hook],
                'fragment_retries': 1,
                'skip_unavailable_fragments': False,
                'test': True,
            })

       

# Generated at 2022-06-24 11:55:26.883548
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from . import YoutubeDL
    ydl = YoutubeDL()

    # Test when no feature is enabled
    manifest1 = """
#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:8
#EXT-X-MEDIA-SEQUENCE:1
#EXTINF:8,
http://media.example.com/fileSequence1.ts
#EXT-X-ENDLIST
"""
    info_dict = {
        'url': 'https://example.com/manifest.m3u8',
    }
    assert HlsFD.can_download(manifest1, info_dict)

    # Test when all features are enabled

# Generated at 2022-06-24 11:55:33.583339
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # We want to test the method HlsFD.can_download that takes an input manifest
    # (as a string) and an info_dict and returns a boolean.
    def can_download(manifest, info_dict={}):
        from .hls import HlsFD
        from ..YoutubeDL import YoutubeDL
        ydl_opts = {'quiet': True, 'skip_download': True}
        ydl = YoutubeDL(ydl_opts)
        hdf = HlsFD(ydl, ydl_opts)
        return hdf.can_download(manifest, info_dict)

    # Test #EXTINF without duration or title

# Generated at 2022-06-24 11:55:46.728832
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .test import get_test_data
    result = HlsFD.can_download(get_test_data(
        'hls-vod.m3u8'), public_attrs={'extractor': None})
    assert result, 'HlsFD should be able to download a VOD stream'
    result = HlsFD.can_download(get_test_data(
        'hls-enc-vod.m3u8'), public_attrs={'extractor': None})
    assert result, 'HlsFD should be able to download a VOD stream with encryption'
    result = HlsFD.can_download(get_test_data('hls-live.m3u8'), public_attrs={'extractor': None})
    assert not result, 'HlsFD should not be able to download a live stream'
   

# Generated at 2022-06-24 11:55:59.684485
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .http import HttpFD
    from .fragment import FragmentFD
    from .external import FFmpegFD
    from .dash import DASHFD
    from .ism import IsmFD
    from .http import HlsFD

    fds_whitelist = [HttpFD, FragmentFD, FFmpegFD, DASHFD, IsmFD]
    class DummyYDL(object):
        def __init__(self):
            self.params = {}
    ydl = DummyYDL()

    fd_classes = [fd_class(ydl, {}) for fd_class in info.FD_CLASSES]

# Generated at 2022-06-24 11:56:07.012642
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """
    This unit test only tests the first fragment because decryption is not supported in tests (see comment
    in the method itself). You can run the tests with this command:
    python -m youtube_dl.postprocessor.ffmpeg -t --download-archive archive.txt \
        --youtube-skip-dash-manifest https://youtu.be/z0gguhEmWiY
    """
    ydl = YoutubeDL({
        'hls_prefer_native': True,
        'quiet': True,
        'test': True,
        'local_vid': 'test.mp4',
        'outtmpl': 'test_out.%(ext)s',
        'geo_bypass_ip_block': False,
    })
    ie = YoutubeIE(ydl)

# Generated at 2022-06-24 11:56:11.800236
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test_utils import FakeYDL
    import tempfile
    import os

    # Fake manifest
    manifest = """
    #EXTM3U
    #EXT-X-VERSION:3
    #EXT-X-TARGETDURATION:8
    #EXT-X-MEDIA-SEQUENCE:1
    #EXT-X-PLAYLIST-TYPE:VOD
    #EXTINF:3,
    http://media.example.com/first.ts
    #EXTINF:3,
    http://media.example.com/second.ts
    #EXTINF:3,
    http://media.example.com/third.ts
    #EXT-X-ENDLIST
    """

    # The fake downloaded fragments (3 of them)
    frag_content = b'abcdefg'

    # Verify that each of the

# Generated at 2022-06-24 11:56:19.443051
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import gen_extractors
    import http.client
    import os.path
    import shutil
    import tempfile
    import unittest
    import urllib.error
    class TestHlsFDRealDownloadTest(unittest.TestCase):
        def _extract_fragment_url(self, manifest):
            return next(l.strip() for l in manifest.splitlines() if l.strip() and not l.startswith('#'))

# Generated at 2022-06-24 11:56:23.328870
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    #assert real_test_HlsFD_real_download() == True, 'test_HlsFD_real_download failed'
    assert True == True, 'test_HlsFD_real_download failed'


# Generated at 2022-06-24 11:56:24.382684
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_FD = HlsFD(None, None)

# Generated at 2022-06-24 11:56:36.723941
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..YoutubeDL import YoutubeDL
    from ..utils import make_HTTPServer
    ydl = YoutubeDL(params={'noplaylist': True})
    with make_HTTPServer(manifest) as httpd:
        info_dict = {}
        info_dict['url'] = 'http://localhost:%d/playlist' % httpd.server_port
        HlsFD.can_download(manifest, info_dict)

if __name__ == '__main__':
    test_HlsFD()

# Manifest containing all lines supported by hlsnative

# Generated at 2022-06-24 11:56:48.634161
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import (
        FakeYDL,
        match_exact_expected,
    )
    from .extractor.generic import GenericIE
    from .extractor.youtube import YoutubeIE

    from io import BytesIO

    BASE_URL = 'https://localhost/'

    def fake_urlopen(url, data=None, headers={}):
        assert url.startswith(BASE_URL)
        video_id = url[len(BASE_URL):]

# Generated at 2022-06-24 11:57:02.157533
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..downloader import common as dl

    info = {
        'url': '',
        'http_headers': {},
        'ext': '',
        'format': '',
        'format_id': '',
        'format_note': '',
        'player_url': '',
        'params': dl.DownloadContext(),
        'skip': False,
        'preference': 0,
        'downloaded': False,
        'folder': None,
        'player_url': '',
    }

    fd = HlsFD(dl.YoutubeDL(), info)

    assert fd.FD_NAME == 'hlsnative'
    assert fd.params == info['params']
    assert fd.ydl == dl.YoutubeDL()
    assert fd.progress_hooks == []
   

# Generated at 2022-06-24 11:57:03.706965
# Unit test for constructor of class HlsFD
def test_HlsFD():
    res = HlsFD.can_download('http://localhost/test', {})
    assert(res == False)

# Generated at 2022-06-24 11:57:08.320807
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ydl = YoutubeDL({})
    hlsfd = HlsFD(ydl=ydl, params={})
    assert hlsfd is not None

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 11:57:09.883031
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-24 11:57:19.494406
# Unit test for constructor of class HlsFD
def test_HlsFD():
    youtube_dl_object = {
        'ydl': 'youtube_dl_object',
        'params': {},
        'to_screen': 'to_screen',
        'report_warning': 'report_warning',
        'report_error': 'report_error',
        '_prepare_url': '_prepare_url',
        '_prepare_and_start_frag_download': '_prepare_and_start_frag_download',
        '_download_fragment': '_download_fragment',
        '_append_fragment': '_append_fragment',
        '_finish_frag_download': '_finish_frag_download',
    }

# Generated at 2022-06-24 11:57:30.224051
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    import tempfile
    import os
    import shutil
    from .dash import DashFD

    class FakeYDL:
        def __init__(self, tmp_dir, url_map=None):
            self.tmp_dir = tmp_dir
            self.url_map = {} if url_map is None else url_map

        def urlopen(self, url):
            if url not in self.url_map:
                raise Exception('Something wrong happened')
            tmp_dir = self.tmp_dir
            if not os.path.exists(tmp_dir):
                os.makedirs(tmp_dir)
            filename = os.path.join(tmp_dir, self.url_map[url])
            return open(filename, 'rb')


# Generated at 2022-06-24 11:57:31.876961
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 11:57:42.655698
# Unit test for constructor of class HlsFD
def test_HlsFD():
    class FakeInfoDict:
        def __init__(self, info):
            self.info = info
    class FakeYDL:
        def __init__(self, info):
            self.info = info
            self.params = {}
            self.params['noprogress'] = True
        def urlopen(self, url):
            self.info[url] = url
            class FakeUrlH:
                def __init__(self, url):
                    self.url = url
                def geturl(self):
                    return self.url
            return FakeUrlH(url)

    hlsfd = HlsFD(FakeYDL(None), {'test': True})
    assert hlsfd.can_download('#EXTM3U\nhttp://testURL\n', FakeInfoDict(None))
    assert not hlsfd

# Generated at 2022-06-24 11:57:47.280880
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import get_info_extractor
    from .common import load_tests_data

    def test_download(self, url, data):
        embed = data['embed']
        info = get_info_extractor(embed['host'])(
            self.yt_dl, {
                'url': embed['url'],
                '_type': 'url',
                'ie_key': embed['host'],
            })
        info_dict = info.extract(embed['url'])
        return HlsFD.real_download(HlsFD(self.yt_dl, {}), None, info_dict)

    results = load_tests_data(HlsFD, ['test_HlsFD_real_download'], test_download)
    assert len(results) == 3
    assert results[0] and results[1]

# Generated at 2022-06-24 11:57:57.349883
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    ie = InfoExtractor()

    hlsfd = ie._downloader.get_suitable_downloader({}, 'http://example.org/foo.m3u8')
    assert isinstance(hlsfd, HlsFD)

    # HLS adaptive live stream that is not supported by HlsFD
    manifest = '''#EXTM3U
#EXT-X-VERSION:5
#EXT-X-PLAYLIST-TYPE:EVENT
#EXT-X-MEDIA-SEQUENCE:0
#EXT-X-TARGETDURATION:6
#EXT-X-DISCONTINUITY
#EXTINF:6,
#EXT-X-BYTERANGE:0@2000000
'''

# Generated at 2022-06-24 11:58:02.568093
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    from . import YoutubeDL
    from .extractor.generic import GenericIE

    sys.argv = ['youtube-dl']
    ydl = YoutubeDL(params= {})
    ydl.add_info_extractor(GenericIE())

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 11:58:12.296349
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import common
    from ..utils import HEADRequest
    from ..compat import compat_urllib_request
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader

    url = 'https://example.com/manifest.m3u8?foo=bar&baz=quux'
    ie = YoutubeIE(params={})
    data = 'test'
    content_length = len(data)
    fd = HlsFD(ie, {})

    # A test case with a single fragment
    class MockParserWithSingleFragment(object):
        def __init__(self, test_case):
            self._test_case = test_case

        def parse(self, s):
            self._test_case.assertTrue(self._test_case.ie.urlopen.called)


# Generated at 2022-06-24 11:58:13.662529
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD({'format': '137+140'}, None)

# Generated at 2022-06-24 11:58:23.869694
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import doctest
    from . import YoutubeDL
    from .test import get_test_file_content, get_test_cases_path

    test_cases = os.path.join(get_test_cases_path(), 'HlsFD_test.txt')
    test_case_inputs = get_test_file_content(test_cases)
    test_case_expected_outputs = get_test_file_content(test_cases, expected=True)

    class HlsFDTest(HlsFD):
        def _download_fragment(self, ctx, url, info_dict, headers):
            return True, b''

    class YoutubeDLOptions:
        params = {}

    # A "real" YoutubeDL instance is required for the download of decryption
    # keys

# Generated at 2022-06-24 11:58:35.566407
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:58:44.162696
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def can_download(manifest):
        info_dict = {}
        return HlsFD.can_download(manifest, info_dict)

    # Tests for encrypted streams

# Generated at 2022-06-24 11:58:51.346869
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:58:57.563510
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """ Verifies that HlsFD can download the first fragment during tests """
    import sys
    import os
    import tempfile
    import subprocess
    import json
    import base64
    import hashlib

    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "../.."))
    from ydl.YoutubeDL import YoutubeDL

    # Download first fragment from the following media, encrypted with iv and key from the uri
    TEST_URL = 'http://download.tsi.telecom-paristech.fr/gpac/DASH_CONFORMANCE/TelecomParisTech/mp4-main-multi-mpd-AV-NBS.mpd'

    # can_download() should return that it can download it

# Generated at 2022-06-24 11:59:08.425949
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    from .test_utils import (
        FakeYDL,
        create_m3u8_manifest,
        create_keyfile,
        create_testfile,
        call_with_files_in_temp_dir,
        get_temp_dir,
        get_testfile_content,
        write_m3u8_testfiles,
    )
    import os

    def verify_real_download_results(filename, info_dict, hls_fragments_content):
        """
        Verify that real_download is working correctly on the files contained in the temporary directory.
        """
        temp_dir = get_temp_dir()
        # Verify expected path
        expected_filename = os.path.join(temp_dir, filename)
        # Verify actual output path

# Generated at 2022-06-24 11:59:19.619673
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    from .test_downloads import test_download_media, get_testcases_from_id
    from .test_downloads import (
        FILE_HLS_HOST, FILE_HLS_PARAM_TO_SEGMENT_URL, FILE_HLS_KEY_URI,
        FILE_HLS_DECRYPTION_KEY, FILE_HLS_CONTENT, FILE_HLS_CONTENT_DECRYPTED,
    )
    from .test_downloads import (
        FILE_HLS_AES128_HOST, FILE_HLS_AES128_KEY_URI, FILE_HLS_AES128_DECRYPTION_KEY,
        FILE_HLS_AES128_CONTENT, FILE_HLS_AES128_CONTENT_DECRYPTED,
    )
   

# Generated at 2022-06-24 11:59:21.144997
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # implementation not integrated yet
    assert False

# Generated at 2022-06-24 11:59:34.990076
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Tested can_download method
    fd = HlsFD({})
    assert fd.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\nindex0.ts\n#EXT-X-ENDLIST', {})
    assert not fd.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\nindex0.ts\n#EXT-X-KEY:METHOD=AES-128,URI="privkey.bin"\n#EXT-X-ENDLIST', {})

# Generated at 2022-06-24 11:59:46.566049
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    from .test_download import _test_download
    from .test_download import _test_fragment_retries
    from .test_download import _test_fragment_retries_unavailable
    from .test_download import _test_fragment_retries_unavailable_skip
    from .test_download import _test_fragment_skip

    # Download mock manifest file and use for testing
    manifest_url = "https://devtests.cyber.msgsec.net/cyber/cyber_manifest.m3u8"
    manifest_local = "mock_manifest.m3u8"
    _test_download(manifest_url, manifest_local)

    # Test HLS download with no encryption
    _test_download(manifest_local)

    # Test HLS download

# Generated at 2022-06-24 11:59:55.089980
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import sys

    try:
        from pytest import warns
    except ImportError:
        from unittest import skip
    else:
        from pytest import skip

    from .test_download import (
        get_testpath,
        get_testdata,
        fake_ydl,
        try_get,
        skip_if_no_network,
    )


# Generated at 2022-06-24 12:00:06.690014
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import io
    import tempfile
    import os.path
    import youtube_dl.YoutubeDL
    import youtube_dl.FileDownloader

    def test_urlretrieve_hook(filename):
        global filename_hook
        filename_hook = filename

    def test_download_hook(status):
        global download_hook_called
        download_hook_called = True

    test_manifest_url = 'http://127.0.0.1:9000/test/manifest.m3u8'
    test_fragment_url = 'http://127.0.0.1:9000/test/fragment.ts'
    test_file = tempfile.NamedTemporaryFile(delete=False)
    test_file.close()
    filename_hook = None
    download_hook_called = False

    test

# Generated at 2022-06-24 12:00:16.776763
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():

    import sys
    import unittest
    import youtube_dl.extractor.youtube
    from .conftest import BaseTest

    class HlsFDTestCase(BaseTest):

        class HlsFDTestFakeYdl(object):
            def __init__(self, params):
                self.params = params

        def setUp(self):
            self.test_params = {
                'dest_dir': False,
                'outtmpl': '%(id)s',
                'writesubtitles': False,
                'writeautomaticsub': False,
                'writeinfojson': False,
                'debug_printtraffic': False,
            }


# Generated at 2022-06-24 12:00:25.255232
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .http_headers import HttpHeadersFD
    from .dash import DASHFD

    from .common import FakeYDL
    from .common import FakeHttpResponseHandler
    import os
    import tempfile
    import shutil

    class DummyInfoDict(object):
        pass

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-24 12:00:36.677635
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import io
    import pytest

    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import common

    with open(common.config_location, 'r') as f:
        passwd = f.readline().rstrip('\n')

    # Test full download
    ydl = YoutubeDL({'username': 'tmoe_test', 'password': passwd, 'noplaylist': True, 'forcejson': True, 'quiet': True})

# Generated at 2022-06-24 12:00:45.762368
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_urls = {
        "HLS with decryption": {
            "url": "http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8",
            "fragments_count": 5,
        },
        "HLS without decryption": {
            "url": "https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8",
            "fragments_count": 16,
        },
    }

    hls_fd = HlsFD(None, None)
    for test_name, test_obj in test_urls.items():
        print(test_name)

# Generated at 2022-06-24 12:00:51.056798
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    url = 'https://d17oy1vhnax1f7.cloudfront.net/'
    url += '0.7.0/examples/hls/apple_master_playlist_no_skip_simple_stream.m3u8'
    hls_fd = HlsFD(None, {})
    assert hls_fd.can_download(hls_fd.ydl.urlopen(url).read().decode('utf-8'), {})
    assert hls_fd.real_download('test.ts', {'url': url})

# Generated at 2022-06-24 12:01:04.855262
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    ydl = None
    # HLS playlist examples from https://developer.apple.com/streaming/examples/advanced.html
    # first_B_segment_1.ts is tvOS.mp4 in the "Advanced Playlist Examples" zip
    # first_B_segment_1.ts is hls-no-encryption.ts in "HLS No Encryption" zip
    # first_B_segment_1.ts is media_b0200.ts in "HLS Media Playlist with Alternate Audio Renditions" zip
    # first_B_segment_1.ts is main-b20000.ts in "HLS Media Playlist with Alternate Audio Renditions" zip
    # first_B_segment_1.ts is first_B_segment_1.ts in "HLS Live Playlist with Segment-by-Seg

# Generated at 2022-06-24 12:01:14.746697
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 12:01:23.159220
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """ Test if method real_download of class hlsnative FD is working properly """

    import tempfile
    import os
    import os.path
    import shutil
    import sys

    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    from .test_utils import (
        FakeYDL,
        FakeFileDownloader,
        get_testdata_dir,
        match_expected_output,
    )

    from ..extractor import gen_extractors

    def set_up_resources(filename):
        """ Set up resources for the test """

        resources_dir = get_testdata_dir()
        test_dir = tempfile.mkdtemp(prefix='youtube-dl-')
        os.chdir(test_dir)

# Generated at 2022-06-24 12:01:34.974925
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor import gen_extractors_by_class
    from ..utils import DeterministicTaskManager

    ie = InfoExtractor(gen_extractors_by_class(InfoExtractor))

    task_manager = DeterministicTaskManager()

    # Uplynk HLS
    HLS_URL = 'https://content.jwplatform.com/manifests/yp34SRmf.m3u8'
    info = {'url': HLS_URL, '_type': 'hls'}
    hls_fd = HlsFD(ie, {}, task_manager=task_manager)
    actual_urls = set()
    actual_ad_urls = set()
    frag_index = 0

# Generated at 2022-06-24 12:01:46.513654
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # test with live stream
    assert not HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-MEDIA-SEQUENCE:337\n'
        '#EXT-X-TARGETDURATION:15\n'
        '#EXTINF:15,\n'
        'http://ip/playlist.m3u8?wowzasessionid=1385663296\n'
        '#EXTINF:15,\n'
        'http://ip/playlist.m3u8?wowzasessionid=1385663296\n',
        {})
    # test with unsupported encryption type

# Generated at 2022-06-24 12:01:53.413352
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    class MyIE(InfoExtractor):
        def _real_extract(self, url):
            pass

    class YDL:
        def __init__(self):
            self.ie = MyIE()
            self.params = {}

        def urlopen(self, url):
            class Response:
                def read(self):
                    return b''
                def geturl(self):
                    return url
            return Response()

    hls_fd = HlsFD(YDL(), {'format': 'mp4'})

# Generated at 2022-06-24 12:02:02.254221
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import Downloader
    import os

    # Starts a downloader and call the HlsFD method real_download.
    # This method should download the file and store it on the disk
    # in the directory provided by path_data.
    downloader = Downloader({
            'format': 'hlsnative',
            'test': True,
            'quiet': True,
            'outtmpl': '',  # Ignore outtmpl in test, save files to path_data instead
            'retries': 0,  # Avoid retry failures in test
            'fragment_retries': 0,
        })
    downloader.path_data = os.path.join(os.path.dirname(__file__), 'data')

# Generated at 2022-06-24 12:02:13.290744
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from .external import FFmpegFD
    ydl = YoutubeIE()
    ydl.params.update({'noprogress': True})
    ydl.add_info_extractor(YoutubeIE.ie_key())

    ydl.params.update({'noprogress': True})

    class FakeInfoDict(object):
        def __init__(self, **kwargs):
            for (attr, value) in kwargs.items():
                setattr(self, attr, value)
    # HlsFD doesn't need to delegate to FFmpegFD

# Generated at 2022-06-24 12:02:21.350566
# Unit test for constructor of class HlsFD
def test_HlsFD():
    '''
    This function test the constructor of class HlsFD.
    '''

# Generated at 2022-06-24 12:02:33.696908
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 12:02:35.292669
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD is not None

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 12:02:43.229742
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    manifest = ''
    manifest += '#EXTM3U\n'
    manifest += '#EXT-X-VERSION:3\n'
    manifest += '#EXT-X-PLAYLIST-TYPE:VOD\n'
    manifest += '#EXT-X-TARGETDURATION:9\n'
    manifest += '#EXT-X-MEDIA-SEQUENCE:0\n'
    manifest += '#EXTINF:6.000000,\n'
    manifest += 'v0.ts\n'
    manifest += '#EXTINF:6.000000,\n'
    manifest += 'v1.ts\n'
    manifest += '#EXTINF:6.000000,\n'
    manifest += 'v2.ts\n'
    manifest += '#EXTINF:6.000000,\n'


# Generated at 2022-06-24 12:02:49.829420
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Test 1: valid m3u8 without encryption and without byteranges
    m3u8_content = '''
#EXTM3U
#EXT-X-TARGETDURATION:10
#EXT-X-VERSION:3
#EXT-X-MEDIA-SEQUENCE:0
#EXTINF:10.000,
http://media1.example.com/first.ts
#EXTINF:10.000,
http://media1.example.com/second.ts
#EXTINF:10.000,
http://media1.example.com/third.ts
#EXT-X-ENDLIST
'''
    manifest = m3u8_content