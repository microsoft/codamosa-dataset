

# Generated at 2022-06-24 11:52:52.265060
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from unittest import TestCase
    from .__main__ import read_m3u8_manifest

    class _HlsFDTests(TestCase):
        """ Test method HlsFD.can_download """

        def setUp(self):
            self.ydl = None
            self.params = {'fragment_retries': -1}
            self.info_dict = {'url': 'https://example.com/stream.m3u8'}

        def test_should_download_with_simple_manifest(self):
            manifest = read_m3u8_manifest('hls/simple.m3u8')
            self.assertTrue(HlsFD.can_download(manifest, self.info_dict))


# Generated at 2022-06-24 11:52:53.308326
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert FFmpegFD(None, None) is not None


# Generated at 2022-06-24 11:53:02.886702
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # test case 1: raise ImportError
    import sys
    import builtins
    orig = sys.modules['Crypto.Cipher.AES']
    sys.modules['Crypto.Cipher.AES'] = None
    try:
        with builtins.__dict__.get('assertRaises')(ImportError):
            HlsFD(None, None)
    finally:
        sys.modules['Crypto.Cipher.AES'] = orig
    # test case 2: otherwise, pass
    hls_fd = HlsFD(None, None)
    assert isinstance(hls_fd, HlsFD)

# Generated at 2022-06-24 11:53:13.731608
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Download fragments of published videos by the channel named "Evolution of Music"
    # which is maintained by Pentatonix
    # https://www.youtube.com/watch?v=9vlijIxBZlM
    # https://www.youtube.com/channel/UCwH1jpmCnRb9X4p_7jmj-vg
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL()

# Generated at 2022-06-24 11:53:23.994620
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import sys
    if sys.version_info > (3,):
        from unittest import mock
    else:
        import mock
    from .test_utils import DummyYDL
    from .test_utils import FakeFileDownloader as FileDownloader

    class HlsFDRealDownloadTest(unittest.TestCase):

        def test_live_stream_is_live(self):
            """ live stream is_live param set true, should fail """
            ydl = DummyYDL()
            dl = FileDownloader(ydl, {'simulate': True})
            dl.add_info_extractor(HlsFD.ie_key())
            dl.params.update({
                'url': 'http://google.com',
                'is_live': True,
            })
            #

# Generated at 2022-06-24 11:53:26.818356
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import SearchInfoExtractor
    ie = InfoExtractor({}, SearchInfoExtractor())
    ie.initialize()
    return HlsFD(ie, {}, {})

# Generated at 2022-06-24 11:53:38.392295
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import pytest
    c_non_supported = (
        (r'#EXT-X-KEY:METHOD=SAMPLE-AES', False),
        (r'#EXT-X-BYTERANGE', False),
        (r'#EXT-X-MEDIA-SEQUENCE:1', False),
        (r'#EXT-X-PLAYLIST-TYPE:EVENT', False),
        (r'#EXT-X-MAP:', False),
    )
    c_supported = (
        (r'#EXT-X-KEY:METHOD=NONE', True),
        (r'#EXT-X-KEY:METHOD=AES-128', True),
    )
    for (arg, expected) in c_non_supported + c_supported:
        assert HlsFD.can_download(arg, {}) == expected

    #

# Generated at 2022-06-24 11:53:44.441893
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import get_suitable_downloader
    dler = get_suitable_downloader({'format': 'bestvideo[ext=mp4]/bestvideo+bestaudio/best'}, {'url': 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8'})
    assert type(dler) == HlsFD



# Generated at 2022-06-24 11:53:55.392199
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import tempfile
    from .common import FakeYDL
    from .extractor.http import HttpFD

    fd = HlsFD(FakeYDL(), {'simulate': True})
    filename = tempfile.mktemp(prefix=__name__ + '-', suffix='.mp4')


# Generated at 2022-06-24 11:54:07.183828
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:54:08.349275
# Unit test for constructor of class HlsFD
def test_HlsFD():
    return HlsFD()


# Generated at 2022-06-24 11:54:18.033902
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors

    ydl = YoutubeDL({})
    for ie in gen_extractors():
        if ie.ie_key() == 'hlsnative':
            ie.set_downloader(ydl)
            break

    info_dict = {
        '_type': 'url',
        'url': 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8',
    }

    if HlsFD.can_download(None, info_dict):
        HlsFD(ydl, info_dict)
        return True
    return False

# Generated at 2022-06-24 11:54:30.509902
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data, fake_urlopen
    from ..compat import str_to_bytes

    # Test AES-128 decryption
    data = get_test_data()
    test_data = data['hls_aes128']
    test_url = 'https://example.com/playlist.m3u8'

    def _mock_urlopen(url, *args, **kwargs):
        if url == test_url:
            return fake_urlopen(str_to_bytes(test_data['playlist']))
        return fake_urlopen(str_to_bytes(test_data[url]))


# Generated at 2022-06-24 11:54:41.220954
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    url = "http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8"
    expected_result = b'#EXTM3U\r\n#EXT-X-PLAYLIST-TYPE:VOD\r\n#EXT-X-TARGETDURATION:8\r\n#EXT-X-VERSION:3\r\n#EXT-X-MEDIA-SEQUENCE:0\r\n#EXTINF:6.640,\r\n#EXT-X-BYTERANGE:522828@0\r\nhls_450k_video.ts\r\n#EXTINF:6.080,\r\n#EXT-X-BYTERANGE:587500@522828\r\nhls_450k_vide'

# Generated at 2022-06-24 11:54:50.681883
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.generic import get_info_extractor
    import pytest

    ie = get_info_extractor(HlsFD.FD_NAME)

    with pytest.raises(ExtractorError):
        ie._real_extract({
            'url': 'https://bitdash-a.akamaihd.net/content/MI201109210084_1/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8',
            'info_dict': {'id': 'videoid'},
            'params': {
                'skip_download': True,
                'test': True,
            }
        })

    # test-m3u8 with encryption

# Generated at 2022-06-24 11:55:01.342050
# Unit test for constructor of class HlsFD
def test_HlsFD():
    '''
    Unit test for constructor of class HlsFD
    '''
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL(params={'nopart': True})
    # First test with some incorrect input
    assert not HlsFD.can_download('This is not a valid m3u8', {})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=INVALID', {})
    # Second test with some valid input (no encryption)
    assert HlsFD.can_download('#EXTM3U', {})
    # Third test with some valid input and some encryption
    # (although encryption is not supported, it should still be
    # able to download it)

# Generated at 2022-06-24 11:55:02.218066
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, {})

# Generated at 2022-06-24 11:55:03.463312
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.FD_NAME == 'hlsnative'


# Generated at 2022-06-24 11:55:04.200328
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass



# Generated at 2022-06-24 11:55:10.881839
# Unit test for constructor of class HlsFD

# Generated at 2022-06-24 11:55:21.671623
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import parse_m3u8_attributes

    class FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_key, ie_url):
            self.ie_key = ie_key
            self.ie_url = ie_url
            self.ie_name = 'FakeInfoExtractor'
            self.ie_id = ie_key

        def _real_extract(self, url):
            return None

    info_extractor = FakeInfoExtractor('info_extractor', 'http://example.com')

# Generated at 2022-06-24 11:55:34.712226
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hfd = HlsFD({})
    # Test can_download(manifest, info_dict)
    assert hfd.can_download('x', {'url': ''})
    assert hfd.can_download('x', {'url': '', 'is_live': True})
    assert not hfd.can_download('#EXT-X-BYTERANGE:1', {'url': ''})
    assert can_decrypt_frag and not hfd.can_download('#EXT-X-KEY:METHOD=AES-128', {'url': ''})
    assert not hfd.can_download('#EXT-X-KEY:METHOD=AES-128#EXT-X-BYTERANGE:1', {'url': ''})

# Generated at 2022-06-24 11:55:36.111973
# Unit test for constructor of class HlsFD
def test_HlsFD():
    t = HlsFD(dict())
    assert t


# Generated at 2022-06-24 11:55:48.766972
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import shutil
    import tempfile

    class FakeYDL(object):
        def __init__(self):
            self.params = {}
            temp_dir = tempfile.mkdtemp()
            self.temp_files = []
            self.temp_dir = temp_dir
            self.to_screen = lambda *args: None

        def urlopen(self, url):
            data = 'test'
            class FakeUrlResponse():
                def read(self):
                    return data
                def geturl(self):
                    return url
            return FakeUrlResponse()
        def report_warning(self, msg):
            print(msg)

    ydl = FakeYDL()
    hls_fd = HlsFD(ydl, ydl.params)
    for i in range(4):
        hls_fd._prepare_and

# Generated at 2022-06-24 11:56:01.329793
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data

    def _test(manifest_content, video_id, expected_chunk_count, expected_chunk_size=None, expected_chunk_content=None,
              expected_frag_count=None, **params):
        import os
        import tempfile
        params['test'] = True

        filename = os.path.join(tempfile.gettempdir(), '%s.mp4' % video_id)
        if os.path.exists(filename):
            os.remove(filename)

        ctx = {
            'filename': filename,
            'total_frags': expected_frag_count,
            'ad_frags': 0,
        }


# Generated at 2022-06-24 11:56:13.399703
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """
    Test if HlsFD downloads the right data when
    downloading a fragment with a decryption method
    and IV (1), and when downloading a fragment that
    requires a byterange in the request headers
    (2).
    1. https://github.com/ytdl-org/youtube-dl/issues/26883
    2. https://github.com/ytdl-org/youtube-dl/issues/26886
    """
    import os
    import tempfile
    import shutil
    import unittest
    try:
        from Crypto.Cipher import AES
    except ImportError:
        raise unittest.SkipTest('pycrypto is needed to run this test')
    from . import F4MFD
    from .external import FFmpegFD
    from .fragment import FragmentFD

# Generated at 2022-06-24 11:56:25.013450
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import get_info_extractor

    # Testing HLS playlists that are supported by HlsFD.

# Generated at 2022-06-24 11:56:29.953648
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    hls_url = 'http://vevoplaylist-live.hls.adaptive.level3.net/vevo/ch2/appleman.m3u8'
    info_dict = {'url': hls_url}
    assert HlsFD.can_download(hls_url, info_dict)

# Generated at 2022-06-24 11:56:32.207266
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader.common import FileDownloader
    return FileDownloader(params = {'format': '140'})


# Generated at 2022-06-24 11:56:42.417024
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile

    from .http import HttpFDTest

    test = HttpFDTest('https://github.com/ytdl-org/youtube-dl/issues/10074')
    test.start()
    (tempfd, tempfn) = tempfile.mkstemp(suffix='.tmp')
    os.close(tempfd)

# Generated at 2022-06-24 11:56:52.363949
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import errno
    import tempfile
    import unittest
    import requests
    from datetime import datetime
    from .downloader import FakeYDL, FakeIE

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.ads_in_manifest = [
                'http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8',
                'http://yt-dash-mse-test.commondatastorage.googleapis.com/media/car-20120827-manifest.mpd',
                'http://content.jwplatform.com/manifests/KbGQhZGY.m3u8',
            ]

# Generated at 2022-06-24 11:57:01.688785
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE # requires youtube_dl
    url = 'https://www.youtube.com/watch?v=L-5l5pF1fCw'
    ie = YoutubeIE()
    info_dict = ie.extract(url)
    hls_url = info_dict['url']
    hls_info_dict = ie._extract_info(hls_url, download=False)
    assert HlsFD.can_download(hls_info_dict['url'], hls_info_dict) == True

# Generated at 2022-06-24 11:57:13.310475
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..utils import prepend_extension
    from ..compat import compat_urllib_request
    from ..downloader.f4m import F4mFD
    class SimpleIE(InfoExtractor):
        IE_NAME = 'SimpleIE'
        _VALID_URL = r'^https?://simple\.com/file\.mp4$'
        _TEST = {
            'url': 'http://simple.com/file.mp4',
            'only_matching': True,
        }


# Generated at 2022-06-24 11:57:21.185132
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testdata_video_url

    def test_probe_size(size):
        # Test manifest download for a video of given size.
        # More than 100 kB, less than 2 MB.
        assert 100 * 2**10 < size < 2 * 2**20
        video_url = get_testdata_video_url('hls_fragmented_mp4')
        extracted_size = 0
        num_frags = 0
        for frag_content in download_video_frags(video_url, size):
            extracted_size += len(frag_content)
            num_frags += 1
            if size > 0:
                assert len(frag_content) > 0
        assert extracted_size == size


# Generated at 2022-06-24 11:57:30.839382
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import FakeYDL
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .compat import compat_urllib_error

    class DummyIE(InfoExtractor):
        IE_NAME = 'dummy'
        IE_DESC = False
        _VALID_URL = r'.*'

    class DummyFD(HttpFD):
        FD_NAME = 'dummy'

        def real_download(self, filename, info_dict):
            pass

    def _test_real_download(test_string, extra_param_to_segment_url=None, http_headers=None, expected_fragment_index=None):
        ydl = FakeYDL()
        ydl.add_info_extractor(DummyIE)
        ydl.add

# Generated at 2022-06-24 11:57:42.286807
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Create an instance of HlsFD
    hlsFD = HlsFD(None, None)

    # Create a manifest with all the features that HlsFD can test for
    manifest = ('#EXTM3U\n'
               '#EXT-X-KEY:METHOD=AES-128\n'
               '#EXT-X-BYTERANGE:121090@526488\n'
               '#EXT-X-MEDIA-SEQUENCE:0\n'
               '#EXT-X-PLAYLIST-TYPE:VOD\n'
               '#EXT-X-MAP:URI="init.mp4"\n'
               'https://priv.example.com/fileSequence52-1.ts\n'
               '#EXT-X-ENDLIST')

    # Create an empty info_dict, which does not contain the live

# Generated at 2022-06-24 11:57:47.404714
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    try:
        unittest.main()
    except Exception as ex:
        log.error('unittest exception: %s', str(ex))

import unittest

from ..extractor.common import InfoExtractor
from ..utils import fake_httpretty_test


# Generated at 2022-06-24 11:57:57.471257
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:58:00.309870
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testcases_for_extractor
    for test_case in get_testcases_for_extractor(HlsFD):
        yield test_case


# Generated at 2022-06-24 11:58:10.958311
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:58:14.054020
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Run a test with the HlsFD
    from .test import _run_generic_test as _run_test
    from .test import HlsFDTest
    test = HlsFDTest()
    _run_test(test)

if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-24 11:58:24.150947
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-24 11:58:35.736334
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:58:44.895376
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import encode_data_uri
    import tempfile


# Generated at 2022-06-24 11:58:55.656086
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import re
    from .test_utils import download_media
    from .test_utils import file_size
    from .test_utils import get_test_data
    from .test_utils import remove_file_on_error
    from .test_utils import get_ephemeral_port
    from .test_utils import launch_server
    from .test_utils import check_video_file
    from .test_utils import get_size_of_file

    url = 'http://127.0.0.1:%d/hls/playlist.m3u8' % get_ephemeral_port()

    server_proc, server_port = launch_server(get_test_data('hls/playlist.m3u8'), port=server_port)


# Generated at 2022-06-24 11:59:01.261944
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # TODO Proper unit tests
    from ..extractor import common as extractor_common
    class TestInfoDict(object):
        def __init__(self, is_live, _decryption_key_url=None):
            self.url = self.original_url = 'http://exnt.me/manifest.m3u8'
            self.is_live = is_live
            self._decryption_key_url = _decryption_key_url

    class TestYDL(object):
        def __init__(self):
            self.params = {
                'hls_prefer_native': True,
                'hls_use_ffmpeg': False,
            }

        def extract_info(self, url, download=True):
            info_dict = TestInfoDict(is_live=False)

# Generated at 2022-06-24 11:59:12.764039
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    from .common import FakeYDL
    import tempfile
    import tkinter
    from http.server import HTTPServer, BaseHTTPRequestHandler

    URL = r'https://example.com/index.m3u8'

    def http_request_handler(request, client_address, server):
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path == '/index.m3u8':
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/x-mpegURL')
                    self.end_headers()

# Generated at 2022-06-24 11:59:23.265273
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .extractor.common import InfoExtractor
    from ..utils import SearchInfoExtractor
    from ..compat import (
        compat_str,
        compat_urllib_parse_unquote,
        compat_urllib_request,
    )

    class MockYDL:
        def __init__(self, params):
            self.params = params

        def add_progress_hook(self, hook):
            pass

        def urlopen(self, url):
            hex_val = compat_urllib_parse_unquote(url.split('algorithm/', 1)[-1])
            return compat_urllib_request.addinfourl(
                compat_str(binascii.unhexlify(hex_val)),
                'mock header', url, 200)


# Generated at 2022-06-24 11:59:31.219438
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import youtube_dl.YoutubeDL

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.ydl = youtube_dl.YoutubeDL({
                'fragment_retries': 0,
            })


# Generated at 2022-06-24 11:59:38.152922
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_fd = HlsFD({}, {'url': 'http://example.com', 'fragment_base_url': 'http://example.com'})

    assert hls_fd.fragment_base_url == 'http://example.com'
    assert hls_fd.protocol == 'm3u8_native'
    assert hls_fd.outtmpl == '-'
    assert hls_fd.noprogress
    assert hls_fd.logger.info == hls_fd.to_screen

test_HlsFD()

# Generated at 2022-06-24 11:59:48.202093
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD.can_download("""#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:5
#EXT-X-MEDIA-SEQUENCE:40
#EXTINF:1.5,
https://example.com/segment.ts
#EXTINF:-0.500,
#EXT-X-KEY:METHOD=AES-128,URI="https://example.com/key.php?r=52"
https://example.com/segment.ts
#EXTINF:1.5,
https://example.com/segment.ts
#EXT-X-ENDLIST
""", {'is_live': False})

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 11:59:56.140145
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Start of HlsFD unit test
    import unittest

    class TestHlsFD(unittest.TestCase):

        def test_can_download_nonexistent_feature(self):
            self.assertTrue(HlsFD.can_download(manifest='#EXTM3U', info_dict={}))

        def test_can_download_common_feature(self):
            manifest_with_common_feature = '#EXTM3U\n#EXT-X-KEY:METHOD=NONE\n#EXTINF:4,\nfileSequence0.ts'
            self.assertTrue(HlsFD.can_download(manifest=manifest_with_common_feature, info_dict={}))


# Generated at 2022-06-24 12:00:05.521712
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hfd = HlsFD(None, {})
    assert hfd.can_download('s', {})
    assert hfd.can_download('#EXT-X-KEY:METHOD=AES-128,URI="https://foo.bar"', {})
    assert not hfd.can_download(
        '#EXT-X-KEY:METHOD=AES-128,URI="https://foo.bar"\n#EXT-X-BYTERANGE', {})
    assert hfd.real_download(None, {'url': 'a'}) is False


# Generated at 2022-06-24 12:00:09.532336
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import YoutubeIE

    manifest_url = ('https://example.com/path/manifest.m3u8?'
                    'example_query=foo&example_query=bar&'
                    'example_query=foo&example_query=bar')

# Generated at 2022-06-24 12:00:11.574136
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hlsfd = HlsFD(None)
    assert hlsfd.FD_NAME == "hlsnative"


# Generated at 2022-06-24 12:00:21.006577
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    info_dict = {'url': 'https://example.com/manifest.m3u8'}
    manifest = (
        '#EXTM3U\n'
        '#EXT-X-STREAM-INF:PROGRAM-ID=111,BANDWIDTH=99999\n'
        'https://example.com/stream.m3u8\n'
        '#EXT-X-STREAM-INF:PROGRAM-ID=222,BANDWIDTH=12345\n'
        'https://example.com/stream2.m3u8\n'
    )
    assert not HlsFD.can_download(manifest, info_dict)


# Generated at 2022-06-24 12:00:22.176289
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 12:00:29.269907
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os.path
    import tempfile
    import unittest

    from ..jsinterp import JSInterpreter
    from ..extractor import gen_extractors

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.testDataDir = os.path.join(
                os.path.dirname(os.path.abspath(__file__)), 'test_data')
            self.testDataDir = os.path.join(self.testDataDir, 'HlsFD')
            self.dummyYdl = DummyYDL()
            self.dummyJsInterpreter = JSInterpreter(self.dummyYdl)
            self.compat_urllib_error = compat_urllib_error
            self.compat_urlparse = compat_urlparse

# Generated at 2022-06-24 12:00:30.925758
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, {'test': 'Does nothing'})

# Generated at 2022-06-24 12:00:44.255232
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import FakeYDL, FakeInfo
    from .external import FFmpegFD

    class FakeHlsFD(HlsFD):
        def __init__(self, ydl, params):
            self.ydl = ydl
            self.params = params


    ydl = FakeYDL()
    ydl.params = {'forceurl': True, 'forcetitle': True, 'quiet': True, 'simulate': True, 'forcejson': True}

    # Manifest

# Generated at 2022-06-24 12:00:49.942039
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_dict = {
        'format': 'best',
        'url': 'http://example.com/test.m3u8',
        'player_url': 'http://example.com/test_player.html',
        'is_live': False,
    }

    test_obj = HlsFD(None, {})
    if not test_obj:
        return False

    if not HlsFD.can_download('http://example.com/test.m3u8', test_dict):
        return False

    return True


# Generated at 2022-06-24 12:00:53.615434
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_fd = HlsFD(None, {'hls_use_mpegts': True})
    hls_fd = HlsFD(None, {'hls_use_mpegts': False})


# Generated at 2022-06-24 12:01:06.676450
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .extractor.common import InfoExtractor
    from .common import FileDownloader
    from .downloader import DownloadContext
    from .downloader.hls import HlsFD
    from .compat import FakeYDL

    def _extract_info(url, ie_key):
        info_extractor = InfoExtractor.get_info_extractors()[ie_key](FakeYDL(), {})
        return info_extractor._real_extract(url)

    def _prepare_options(verbose):
        params = {
            'simulate': True,
            'format': 'bestvideo+bestaudio',
            'logger': FileDownloader(FakeYDL(), {'verbose': verbose, 'simulate': True}).logger,
            'quiet': not verbose or None,
        }
        return Download

# Generated at 2022-06-24 12:01:14.419933
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_fd = HlsFD({'hls_native': True}, None, {})
    for i in range(4):
        hls_fd.real_download("test.mp4", {'url': 'test.mp4', '_type': 'hls_native', 'is_live': True})

# Generated at 2022-06-24 12:01:25.819829
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import sys
    from os.path import exists, join

    class DummyYDL:
        def __init__(self):
            self.params = {}

        def urlopen(self, url):
            this_file_folder = os.path.dirname(os.path.realpath(__file__))
            file_urls = {
                'http://www.youtube.com/get_video_info?video_id=%s' % id:
                    join(this_file_folder, 'hls_playlist', 'url_info_%s.txt' % id)
                for id in ['y5w5C5KjohU', '8hJURZboUnM', 'BgxU6Kq3qfA']
            }

# Generated at 2022-06-24 12:01:29.782968
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="foo.key"\n\n#EXTINF:10,\nfoo.ts', {})


# Generated at 2022-06-24 12:01:32.091812
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        from Crypto.Cipher import AES
    except ImportError:
        True
    else:
        false = True

# Generated at 2022-06-24 12:01:39.949470
# Unit test for constructor of class HlsFD
def test_HlsFD():
    url = 'http://www.streambox.fr/playlists/test_001/stream.m3u8'

    HlsFD.can_download(url, {
        'protocol': 'm3u8_native',
        'ext': 'mp4',
        'title': 'test_001',
        'url': 'http://www.streambox.fr/playlists/test_001/stream.m3u8',
        'webpage_url': 'http://www.streambox.fr/',
        'description': 'test_001'
    })

# Generated at 2022-06-24 12:01:52.867948
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import sys
    def dummy_print_debug(msg, *args, **kwargs):
        print(msg)
    sys.stdout.write = dummy_print_debug
    filename = "http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8"
    info_dict = {}
    info_dict.update({'url': filename})
    try:
        from Crypto.Cipher import AES
        hls = HlsFD(None, None)
        assert hls.can_download(info_dict, info_dict) == True
    except ImportError:
        hls = HlsFD(None, None)
        assert hls.can_download(info_dict, info_dict) == False

test_HlsFD_can_download()

# Generated at 2022-06-24 12:02:01.877049
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .external import ExternalFD
    import os
    import shutil
    import tempfile
    import subprocess
    external_downloader_path = (
        os.path.dirname(os.path.dirname(os.path.dirname(__file__))) + '/bin/youtube-dl'
    )

# Generated at 2022-06-24 12:02:10.023877
# Unit test for constructor of class HlsFD
def test_HlsFD():
    url = 'http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8'
    info_dict = {'url': url}
    hlsFD = HlsFD(None, None)
    return hlsFD.can_download(hlsFD.ydl.urlopen(url).read().decode('utf-8'), info_dict)

if __name__ == "__main__":
    assert(test_HlsFD())

# Generated at 2022-06-24 12:02:19.569789
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from .external import ExternalFD

    ie = InfoExtractor('test')
    ie.add_info_extractor(ExternalFD('test', ie))
    fd = ie._ies[0]._ies[0]
    assert isinstance(fd, HlsFD)
    ie._ies[0] = fd
    fd.add_progress_hook(lambda d: d)
    fd.params = {'test': 1, 'fragment_retries': 10, 'continuedl': False}
    fd._prepare_url = lambda *args: 'http://example.com/'
    fd.report_error = lambda *args: None
    fd.report_warning = lambda *args: None


# Generated at 2022-06-24 12:02:32.374871
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile

    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import encode_compat_str

    manifest_url = 'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8'

# Generated at 2022-06-24 12:02:33.505004
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert can_decrypt_frag

# Generated at 2022-06-24 12:02:35.368077
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # TODO: Make this test work with .update_config() if possible.
    # This test runs too slow when run in parallel with other tests.
    pass


# Generated at 2022-06-24 12:02:39.628034
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from . import YoutubeDL
    ydl = YoutubeDL({})
    ydl.add_info_extractor({
        'R_TESTS_SUCCEEDED': 'HlsFD',
    })
    result = ydl.extract_info('http://foo/bar', download=False)
    assert 'hlsnative' in result['formats'][0]['protocol']

# Generated at 2022-06-24 12:02:50.769054
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def can_download(m3u8_manifest, info_dict):
        def get_bool(v):
            if v:
                return 'YES'
            else:
                return 'NO'
        assert HlsFD.can_download(m3u8_manifest, info_dict) == True, \
            "can_download() should return YES if the stream is supported."
        return True

    # Test all supported features.