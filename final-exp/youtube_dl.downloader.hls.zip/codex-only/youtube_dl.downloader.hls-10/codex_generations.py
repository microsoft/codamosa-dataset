

# Generated at 2022-06-24 11:52:55.839255
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Create test cases
    TestCase = collections.namedtuple(
        'TestCase', ['manifest', 'fd', 'test', 'check_results'])

# Generated at 2022-06-24 11:53:07.084363
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    from ..compat import compat_http_server

    def m3u8_handler(path, data):
        url = data['url'][-1]
        assert isinstance(url, str)
        assert url.endswith('/%s' % path)

        # Return a simple m3u8 file containing a single fragment
        return '''
#EXTM3U
#EXT-X-TARGETDURATION:10
#EXTINF:10,
frag01.ts
#EXT-X-ENDLIST
'''

    def ts_handler(path, data):
        url = data['url'][-1]
        assert isinstance(url, str)
        assert url.endswith('/%s' % path)

        # Return a random binary file
        return os.urandom(100)



# Generated at 2022-06-24 11:53:17.574255
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.http

    class HlsFDTest(HlsFD):
        def __init__(self, ydl, params):
            self.ydl = ydl
            self.params = params
            self.ydl.process = youtube_dl.YoutubeDL.process_video
            self.ydl.process_info = youtube_dl.YoutubeDL.process_video_result
            self.ydl._ies = []
            self.ydl.add_default_info_extractors()


# Generated at 2022-06-24 11:53:26.527143
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Warning -- this unit test most likely should be moved to tests/test_files
    from .downloader import YoutubeDL
    files = (
        ('live_stream_m3u8', False),
        ('live_stream_m3u8_nonzero_sequence', False),
        ('encrypted_stream_m3u8', True),
        ('encrypted_stream_m3u8_bad_key_url', False),
        ('sample_hls_master', True),
        ('sample_hls_master_with_byterange', True),
        ('sample_hls_master_with_query_string', True),
        ('sample_hls_master_with_byterange_and_query_string', True),
    )
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
   

# Generated at 2022-06-24 11:53:38.100925
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Test without pycrypto
    hls_fd = HlsFD({}, {'test': True, 'username': 'test', 'password': 'test', 'http_headers': {'test': 'test'}})
    test_url = 'http://test.com/test.m3u8'
    info_dict = {'url': test_url, 'protocol': 'm3u8'}
    test_filename = 'test_filename'
    assert not hls_fd.can_download('#EXTM3U', info_dict)
    assert not hls_fd.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="http://test"\n#EXT-X-BYTERANGE', info_dict)

# Generated at 2022-06-24 11:53:38.842722
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass

# Generated at 2022-06-24 11:53:50.905795
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .downloader.common import FileDownloader
    from .extractor.youtube_dl.extractor.twitch import TwitchIE

    def test_video_id(id):
        info_dict = {}
        ie = YoutubeIE(InfoExtractor(None, params={'noplaylist': True}))
        ie._real_extract(id, info_dict)
        ie = TwitchIE(InfoExtractor(None, params={'noplaylist': True}))
        ie._real_extract(id, info_dict)
        # Extractor for audio-only streams
        ie = TwitchIE(InfoExtractor(None, params={'noplaylist': True}))
        info_dict['extractor_key'] = 'twitch:audio'

# Generated at 2022-06-24 11:53:58.802717
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # can_download
    info_dict = {}
    manifest = '#EXTM3U\n' + '#EXT-X-KEY:METHOD=NONE\n'
    assert HlsFD.can_download(manifest, info_dict)

    manifest = '#EXTM3U\n' + '#EXT-X-KEY:METHOD=AES-128\n'
    info_dict['_decryption_key_url'] = 'https://foo.bar/decrypt.key'
    assert HlsFD.can_download(manifest, info_dict)

    manifest = '#EXTM3U\n' + '#EXT-X-KEY:METHOD=AES-128\n' + '#EXT-X-BYTERANGE:123512@12310\n'

# Generated at 2022-06-24 11:54:08.830667
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    print('Testing can_download method of HlsFD')
    # Testcase #1
    # Testcase description:
    # Tested pycrypto package is not available
    # Python version = 2.7.17
    # Expected result = False
    # Can download flag = False
    # Expected return value = False
    # Actual return value = False
    # Test result = PASS
    # Uncomment following line to play this testcase
    ###HlsFD.can_download = __test_can_download__
    # Testcase #2
    # Testcase description:
    # Tested pycrypto package is available
    # Manifest is not encrypted
    # Media is not live stream
    # Python version = 2.7.17
    # Expected result = True
    # Can download flag = True
    # Expected return value = True
    #

# Generated at 2022-06-24 11:54:20.004775
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import YoutubeDL
    from ..extractor import gen_extractors
    from .fragment import FragmentFD

    def download_without_file(ydl, *args, **kwargs):
        ydl.prepare_filename(ydl.params)
        return ydl.process_info(kwargs.get('ie_result'))

    # Not using os.path.join because the test could be run in an environment
    # with a different OS than the one used to generate the test data.
    test_manifest_path = 'test/files/hls/manifest.m3u8'
    with open(test_manifest_path) as f:
        test_manifest = f.read()
    test_manifest_url = 'file://' + test_manifest_path

    # We do not want

# Generated at 2022-06-24 11:54:32.971681
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import ydl
    ydl_params = {
        'noplaylist': True,
        'hls_prefer_native': True,
        'verbose': True,
        'progress_hooks': [],
    }
    ydl_obj = ydl.YoutubeDL(ydl_params)

    # Test encrypted stream
    # https://bitdash-a.akamaihd.net/content/MI201109210084_1/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8

# Generated at 2022-06-24 11:54:36.557276
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    _, info_dict = next(gen_extractors(
        {'url': 'https://vimeo.com/169599296'}))
    assert HlsFD.can_download(info_dict['url'], info_dict)

# Generated at 2022-06-24 11:54:41.623499
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .external import ExternalFD
    from .http import HttpFD
    from .dash import DashFD

    # m3u8 manifests

# Generated at 2022-06-24 11:54:50.814410
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import urllib.request
    import urllib.parse
    import urllib.error
    import os.path

    # The test must be executed in a folder containing the file "geometry.mp4"
    test_video_file = "geometry.mp4"
    test_video_url = urllib.parse.urljoin("file:", urllib.request.pathname2url(os.path.abspath(test_video_file)))

    def test_condition(line):
        return line.startswith('#EXTINF')

    # First build the m3u8 file
    m3u8_file = open("test.m3u8", 'w')
    m3u8_file.write("#EXTM3U\n")

# Generated at 2022-06-24 11:54:57.214925
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:54:58.538804
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, {'noprogress': True})


# Generated at 2022-06-24 11:55:03.881132
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """Test real_download method of the HlsFD class"""
    import io
    import tempfile
    from .testutils import create_playlist
    from .testutils import CustomYtdlPostProcessor
    from ..utils import (
        prepend_extension,
        match_filter_func,
        OnProgressFilter,
        LimitFilter,
    )
    from ..extractor.common import InfoExtractor

    fd = HlsFD(CustomYtdlPostProcessor({}), {})

# Generated at 2022-06-24 11:55:10.665464
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    try:
        import youtube_dl.extractor.adobepass
    except ImportError:
        pass

    with youtube_dl.YoutubeDL(params={
        'hls_prefer_native': True,
        'hls_use_mpegts': False,
        'hls_segment_size': 0,
        'hls_playlist_reload_attempts': 0,
        'max_sleep_interval': 0,
        'max_downloads': 1,
        'test': True,
    }) as ydl:
        ydl.add_default_info_extractors()
        ydl.extractor_error_compat = True
        ydl.add_info_extractor(youtube_dl.extractor.adobepass.AdobePassIE())
        info = ydl.extract

# Generated at 2022-06-24 11:55:21.545229
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import requests
    import json

    class MockInfoDict(dict):
        def __init__(self, url, **kwargs):
            super(MockInfoDict, self).__init__(**kwargs)
            self['url'] = url

    for url in [
        'https://www.instagram.com/p/Bc6udN3h6G4/',
        'https://www.instagram.com/p/Bc65l3qhzd2/',
        'https://www.instagram.com/p/Bc7A6jolvfA/',
    ]:
        info_dict = MockInfoDict(url)

# Generated at 2022-06-24 11:55:34.567424
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .testutils import FakeYDL
    from ..extractor import get_info_extractor

    ydl = FakeYDL()
    ydl.add_info_extractor(get_info_extractor('hlsnative'))

    # test non-live playlists that do not contain unsupported features
    # when pycrypto is available to decrypt fragments
    assert ydl.extract_info(
        'https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_16x9/bipbop_16x9_variant.m3u8',
        download=False)

    # test non-live playlists that do not contain unsupported features
    # when pycrypto is not available to decrypt fragments
    with ydl.params:
        ydl.params['hls_prefer_native']

# Generated at 2022-06-24 11:55:47.432452
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import shutil
    from .test_file import TestFD

    # This test only applies to python 2.7
    if sys.version_info[0] != 2:
        return

    # This test only applies if pycrypto is installed
    try:
        from Crypto.Cipher import AES
        cryptodetected = True
    except ImportError:
        cryptodetected = False

    if cryptodetected is False:
        return

    # In order to pass the test, please run the following commands in the directory of this file.
    # Note that you need to have access to the internet, because the test downloads files
    # from an online server.
    #
    # $ wget https://www.nasa.gov/multimedia/nasatv/NTV-Public-IPS.m3u8
   

# Generated at 2022-06-24 11:55:59.872724
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import common
    from ..extractor.common import InfoExtractor
    from .common import HEADRequest
    from .http import HTTPFD
    from .external import FFmpegFD

    class DummyIE(InfoExtractor):

        IE_NAME = 'Dummy'
        IE_DESC = 'Dummy IE for testing'
        _VALID_URL = r'https?://example.com'

        def _real_extract(self, url):
            return {
                'id': '0',
                'display_id': 'example',
                'url': url,
                'title': 'example-title',
            }

    # We are testing HlsFD but we need to know if it fallsback to other class
    # before that need to work as well. FFmpegFD and HTTPFD need to be
    # instantiated so we

# Generated at 2022-06-24 11:56:00.955207
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    HlsFD.can_download('', {})


# Generated at 2022-06-24 11:56:13.145349
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:56:13.793048
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD

# Generated at 2022-06-24 11:56:25.352932
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # HlsFD.real_download(filename, info_dict)
    # It is not necessary to test all cases in hlsnative
    # because for every case where hlsnative is used
    # ffmpeg could be used.
    #
    # Testing HlsFD.real_download serves only to make sure
    # that hlsnative actually works.
    from .common import FakeYdl

    urlh = FakeYdl()
    urlh.add_info_dict({
        'id': 'foobar',
        'ext': 'mp4',
        'title': 'hlsnative test',
    })

    downloader = FakeYdl()

# Generated at 2022-06-24 11:56:37.024420
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import logging
    import tempfile
    from ..downloader import FileDownloader
    from ..extractor import gen_extractors
    from ..utils import find_srt_oformat
    # Modify logging settings for testing
    logging.basicConfig(level=logging.DEBUG, format=(
        '%(asctime)s - %(name)s:%(lineno)s - %(levelname)s - %(message)s'))
    # Disable stdout logging messages
    log_handler, _ = logging.getLogger().handlers
    log_handler.addFilter(lambda record: record.levelno != logging.INFO)

    # URL of an HLS video with multiple audio streams

# Generated at 2022-06-24 11:56:48.681648
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class TestDict:
        def __init__(self, url):
            self.url = url
    from .http import HttpFD

# Generated at 2022-06-24 11:57:02.156636
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U', {'url': '', 'is_live': False})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=SAMPLE-AES', {'url': '', 'is_live': False})
    assert not HlsFD.can_download('#EXT-X-BYTERANGE', {'url': '', 'is_live': False})
    assert not HlsFD.can_download('#EXT-X-MEDIA-SEQUENCE:1', {'url': '', 'is_live': True})
    assert not HlsFD.can_download('#EXT-X-MAP', {'url': '', 'is_live': False})

# Generated at 2022-06-24 11:57:11.621096
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ydl_opts = {'quiet': True, 'format': 'bestaudio/best'}
    ydl_opts['hls_prefer_native'] = True
    # HlsFD is used to download this manifest
    manifest = 'http://hls-vod-test-orange.akamaized.net/test_hls_vod_orange/test_hls_vod_orange/ex1/playlist.m3u8'
    with YoutubeDL(ydl_opts) as ydl:
        ydl.download([manifest])

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 11:57:17.401079
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # live
    assert not HlsFD.can_download('#EXTM3U', {'is_live': True})

    # unsupported key method
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-SAMPLE', {})

    # unsupported playlist type
    assert not HlsFD.can_download('#EXT-X-PLAYLIST-TYPE:EVENT', {})
    assert not HlsFD.can_download(
        '#EXT-X-PLAYLIST-TYPE:EVENT\n'
        '#EXT-X-MEDIA-SEQUENCE:0\n'
        '#EXTINF:10,\n'
        'media-00001.ts\n'
        '#EXT-X-ENDLIST', {})

    # unsupported initialisation
    assert not HlsFD.can

# Generated at 2022-06-24 11:57:28.955965
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:57:40.779707
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # This is a method of class HlsFD
    import tempfile
    import os
    import hashlib
    import sys
    from .downloader import _downloader
    from .external import FFmpegFD

    if not can_decrypt_frag:
        raise unittest.SkipTest("skipping test due to missing 'pycrypto' module")

    url = 'https://video.twimg.com/ext_tw_video/656983779901270016/pu/pl/rFzrVC3OrTtG-u2Q.m3u8'
    ydl = _downloader('youtube-dl', {'noplaylist': True, 'quiet': True, 'ratelimit': 999999, 'no_warnings': True})


# Generated at 2022-06-24 11:57:52.055078
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:58:00.298184
# Unit test for constructor of class HlsFD

# Generated at 2022-06-24 11:58:10.925768
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import common
    from ..utils import HEADRequest
    from .external import ExternalFD
    from .http import HttpFD

    # HlsFD(self, ydl, params):
    ydl = common.FakeYDL()
    params = {'format': 'best'}
    fd = HlsFD(ydl, params)
    assert fd.ydl == ydl
    assert fd.params == params

    # check_binaries(self):
    assert ExternalFD.check_binaries()

    # real_download(self, filename, info_dict):
    # _download_fragment(self, ctx, frag_url, info_dict, headers):
    fd = HlsFD(ydl, params)
    aContext = {}

# Generated at 2022-06-24 11:58:16.928214
# Unit test for constructor of class HlsFD

# Generated at 2022-06-24 11:58:25.949506
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .extractor.youtube import YoutubeIE
    from ..utils import UNKNOWN_ERRORS
    from ..utils import match_filter_func


# Generated at 2022-06-24 11:58:36.976021
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    hls_fd = HlsFD({})

# Generated at 2022-06-24 11:58:38.567669
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('test', {
        'is_live': True,
    })

# Generated at 2022-06-24 11:58:46.335008
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest
    class TestHlsFD_can_download(unittest.TestCase):
        def setUp(self):
            self.hls_fd = HlsFD(None, {})

        # For test function names, the leading 'test_HlsFD_can_download_' will be removed
        # Therefore the function test_HlsFD_can_download_can_download_0 will be seen as test case 'can_download_0'

# Generated at 2022-06-24 11:58:57.983822
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download(open('tests/streams/hls_variant.m3u8', 'r').read(), {'is_live': False})
    assert HlsFD.can_download(open('tests/streams/hls_byteranges.m3u8', 'r').read(), {'is_live': False})
    assert not HlsFD.can_download(open('tests/streams/hls_live.m3u8', 'r').read(), {'is_live': True})
    assert not HlsFD.can_download(open('tests/streams/hls_playlist_type_event.m3u8', 'r').read(), {'is_live': False})

# Generated at 2022-06-24 11:59:08.825335
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.generic import GenericIE
    from ..utils import prepend_extension
    from requests.exceptions import ConnectionError

    # Mock the extractor's urlopen function to simulate a failing connection
    def urlopen_mock(request, *args, **kwargs):
        raise ConnectionError()
    GenericIE._downloader.urlopen = urlopen_mock

    class TestInfoExtractor(GenericIE):
        # No HLS stream
        _TEST = {
            'url': 'https://test.com/test.mp4',
            'info_dict': {
                'id': 'test',
                'ext': 'mp4',
            }
        }

        def _real_extract(self, url):
            self.to_screen('Testing method real_download for class HlsFD')

            extractor = self._

# Generated at 2022-06-24 11:59:15.656044
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import types
    import youtube_dl.downloader.fragment

    result = HlsFD.__new__(HlsFD)
    assert isinstance(
        result,
        youtube_dl.downloader.fragment.FragmentFD)

    assert isinstance(result, types.TypeType)

    assert isinstance(HlsFD.can_download, types.FunctionType)

    assert isinstance(result.real_download, types.MethodType)

# Generated at 2022-06-24 11:59:25.172505
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    sys.path.append('tests/resources/')
    import utils
    utils.downloader_test(
        HlsFD,
        'http://example.com',
        'tests/resources/test_hls.m3u8',
        {'test': True},
        'tests/resources/test_hls.mp4')

    utils.downloader_test(
        HlsFD,
        'http://example.com',
        'tests/resources/test_hls_live.m3u8',
        {'test': True},
        'tests/resources/test_hls_live.ts')


# Generated at 2022-06-24 11:59:31.934039
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import YoutubeDL

    ydl = YoutubeDL({})
    ctx = {
        'ydl': ydl,
        'params': {'external_downloader': 'ffmpeg'},
        'filename': 'video.mp4',
        'total_frags': 3,
        'ad_frags': 1,
    }
    ctx['frag_data'] = []
    ctx['frag_index'] = 0
    ctx['player_url'] = None
    ctx['tmpfilename'] = None
    ctx['retries'] = 0
    ctx['url_transport_socket_timeout'] = None
    with HlsFD._downloader(ctx) as frag_downloader:
        assert(frag_downloader.name == 'ffmpeg')

# Generated at 2022-06-24 11:59:39.934681
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.extractor.test
    import youtube_dl.urlhandler.file

    class TestHlsFD(HlsFD):
        def __init__(self, ydl, params):
            super(TestHlsFD, self).__init__(ydl, params)
            self._fragment_downloader = youtube_dl.urlhandler.file.FileDownloader(ydl, params)


# Generated at 2022-06-24 11:59:49.178660
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-VERSION:3', {'is_live': False})
    # not support encrypted stream
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-KEY:METHOD=AES-128', {'is_live': False})
    # not support live stream
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-MEDIA-SEQUENCE:100', {'is_live': True})


if __name__ == '__main__':
    test_HlsFD_can_download()

# Generated at 2022-06-24 11:59:56.757881
# Unit test for constructor of class HlsFD
def test_HlsFD():
    '''HlsFD constructors should work
    '''
    from ..downloader import YoutubeDL
    ydl = YoutubeDL()
    ydl._prepare_filename = lambda info_dict: ''
    ydl.params = {'hls_prefer_native': True, 'ffmpeg_location': '/some/ffmpeg_location'}

# Generated at 2022-06-24 12:00:08.650864
# Unit test for constructor of class HlsFD

# Generated at 2022-06-24 12:00:19.233889
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    filename = os.path.join(os.path.dirname(__file__), 'test/test.m3u8')
    url = 'http://hostname.com/path/to/file.m3u8'
    ydl = EmptyYDL()
    info_dict = {
        'id': 'test',
        'url': url,
        'http_headers': {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:68.0) Gecko/20100101 Firefox/68.0'
        }
    }
    params = {
        'noprogress': True,
        'test': True
    }

# Generated at 2022-06-24 12:00:30.021055
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import io
    import re
    import sys
    import unittest

    import requests
    # [1] http://ddemidov.spb.ru/misc/hls_decrypt.py
    import hls_decrypt

    from .extractor.common import InfoExtractor
    from .compat import (
        compat_urllib_error,
        compat_urllib_request,
        compat_http_client,
    )

    # We only want to use HlsFD to download a fragment rather than the entire playlist
    # so that the test is not slow.
    class MockYTDLLogger(object):
        def debug(self, *args, **_):
            pass

    class MockYDL(object):
        def __init__(self, *args, **kwargs):
            self.params = kw

# Generated at 2022-06-24 12:00:37.708408
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    hls_fd = HlsFD(None, None)
    result = hls_fd.can_download('test manifest', {})
    expected = True

    assert result == expected


# Generated at 2022-06-24 12:00:49.597178
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import io
    import os
    import tempfile
    import json
    import shutil
    import subprocess
    import sys


# Generated at 2022-06-24 12:00:55.506691
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 12:01:07.253408
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os.path
    import unittest
    import tempfile

    import youtube_dl
    from youtube_dl.utils import DownloadError
    from tests import YoutubeDL
    from tests import get_testcases

    class TestHlsFD(unittest.TestCase):

        def setUp(self):
            self.testcases = get_testcases(
                os.path.splitext(os.path.basename(__file__))[0])

        def test_real_download(self):
            for t in self.testcases:
                if 'hlsnative' not in t.get('params', {}).get('hls_prefer_native', ''):
                    continue

                params = dict(t.get('params', {}))
                params['_test_HlsFD_real_download'] = True

# Generated at 2022-06-24 12:01:20.808916
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import shutil
    from .common import get_testdata_dir
    from .common import temp_name
    from .common import temp_dirs
    from .common import io_wraps_download_error
    from .common import io_wraps_download_error
    from .common import io_wraps_connection_error
    from .common import io_wraps_http_429_error
    from .common import io_wraps_http_503_error
    import pytest
    TEST_DATA_DIR = os.path.join(get_testdata_dir(), 'HlsFD')
    import youtube_dl.YoutubeDL

# Generated at 2022-06-24 12:01:33.083495
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .utils import FakeYDL

    def can_download(manifest, info_dict):
        return HlsFD.can_download(manifest, info_dict)

    # Test for method can_download with case when method does not support
    # #EXT-X-BYTERANGE tag
    assert not can_download(HlsFD, '#EXT-X-KEY:METHOD=AES-128', None)

    # Test for method can_download with case when method does not support
    # #EXT-X-KEY:METHOD=NONE/AES-128/SAMPLE-AES if it also contains
    # #EXT-X-BYTERANGE tag

# Generated at 2022-06-24 12:01:42.572785
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    manifest = ''
    manifest += '#EXTM3U\n'
    manifest += '#EXT-X-TARGETDURATION:8\n'
    manifest += '#EXT-X-VERSION:3\n'
    manifest += '#EXT-X-MEDIA-SEQUENCE:1\n'
    manifest += '#EXT-X-PLAYLIST-TYPE:VOD\n'
    manifest += '#EXTINF:6.640,\n'
    manifest += '001/prog_index.m3u8?null=0\n'
    manifest += '#EXTINF:6.080,\n'
    manifest += '002/prog_index.m3u8?null=0\n'
    manifest += '#EXTINF:6.600,\n'

# Generated at 2022-06-24 12:01:55.014357
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    import re

    # The easiest way to write this test is to patch the class FragmentFD
    class TestFragmentFD(FragmentFD):
        def __init__(self, tester, filename, info_dict, total_frags, params):
            super(TestFragmentFD, self).__init__(None, params)
            self.tester = tester
            self.filename = filename
            self.info_dict = info_dict
            self.total_frags = total_frags
            self.frag_index = 0

            self.fragment_urls = []
            self.fragment_retries = []
            self.fragment_data = []


# Generated at 2022-06-24 12:02:06.474470
# Unit test for constructor of class HlsFD
def test_HlsFD():
    info_dict = {}
    manifest = '#EXT-X-KEY:METHOD=AES-128,URI="key.bin"'
    assert not HlsFD.can_download(manifest, info_dict)
    manifest = '#EXT-X-KEY:METHOD=NONE,URI="key.bin"'
    assert HlsFD.can_download(manifest, info_dict)
    assert HlsFD.can_download('#EXT-X-BYTERANGE:1234', info_dict)
    assert HlsFD.can_download('#EXT-X-BYTERANGE:1234\n#EXT-X-MEDIA-SEQUENCE:559', info_dict)

# Generated at 2022-06-24 12:02:18.226456
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert not HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-KEY:METHOD=AES-128,URI="http://priv.example.com/key.php?r=52"\n'
        '\n'
        '#EXTINF:2.833,\n'
        'http://www.example.com/fileSequence52-1.ts\n'
        '#EXTINF:15.0,\n'
        'http://www.example.com/fileSequence52-2.ts\n'
        '#EXTINF:13.333,\n'
        'http://www.example.com/fileSequence52-3.ts\n',
        {}
    )

# Generated at 2022-06-24 12:02:29.854058
# Unit test for constructor of class HlsFD
def test_HlsFD():
    opts = {}
    url = 'https://www.youtube.com/playlist?list=PLFgquLnL59amxR8Ww1EjKG2HAv7V3v0-W'
    info_dict = {
        'url': url,
        'ext': 'mp4',
        'id': 'bKvbH2s_tgQ',
        'title': "This file's name should be looked up in the manifest"
    }
    # these are required by HlsFD constructor
    opts['format'] = 'bestvideo[ext=mp4,height=720]+bestaudio[ext=m4a,abr<128]/best[ext=mp4,height<=720]/bestvideo+bestaudio/best'

# Generated at 2022-06-24 12:02:37.907428
# Unit test for constructor of class HlsFD

# Generated at 2022-06-24 12:02:46.136539
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import tempfile
    from .utils import fake_http_protocol_resolver, read_file
    from .extractor.youtube import YoutubeIE
    from .extractor.vimeo import VimeoIE

    # disable debug output
    import logging
    logging.basicConfig(level=logging.ERROR)

    # create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # import test resources
    test_resources_dir = os.path.join(os.path.dirname(__file__), 'utils', 'test_resources')
    test_resources = [
        'youtube_hls_live',
        'youtube_hls_live_encrypted',
        'youtube_hls_live_encrypted_with_decryption_key',
        'vimeo_hls_live',
    ]