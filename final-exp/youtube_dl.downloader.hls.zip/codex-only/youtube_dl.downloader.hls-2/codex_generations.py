

# Generated at 2022-06-24 11:52:54.569965
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    import os.path
    import sys
    from .external import FFmpegFD


# Generated at 2022-06-24 11:52:58.823013
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import doctest
    for name, method in doctest.DocTestFinder(HlsFD.__dict__).find(HlsFD.can_download):
        print(name)
        doctest.run_docstring_examples(method, globals())

# Run test for method can_download of class HlsFD
test_HlsFD_can_download()

# Generated at 2022-06-24 11:53:08.949957
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:53:19.774087
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import unittest
    import doctest
    from . import fake_httpserver

    class TestHlsFD(unittest.TestCase):
        def test_HlsFD(self):
            fake_httpserver.start()

            def helper(test_input):
                return HlsFD.can_download(test_input, {'is_live': False})

            # Class variables should have been tested earlier, so we do not
            # bother testing them again.
            self.assertTrue(helper('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="http://example.com/crypto"\n#EXTINF:10,\nhttp://example.com/first'))


# Generated at 2022-06-24 11:53:28.310498
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def test_case(in_manifest, in_info_dict, out_can_download):
        m_cls = HlsFD.__dict__['can_download']
        m_cls_name = 'can_download'
        m_cls_args = [in_manifest, in_info_dict]
        m_cls_kwargs = {}
        return {
            'm_cls': m_cls,
            'm_cls_name': m_cls_name,
            'm_cls_args': m_cls_args,
            'm_cls_kwargs': m_cls_kwargs,
            'm_cls_ret': out_can_download,
        }

    # Test cases

# Generated at 2022-06-24 11:53:34.792120
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import tempfile
    import os

    def run_test_hls(self, info_dict):
        key_url = 'https://example.com/key'
        expected_key = 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
        key_file = tempfile.NamedTemporaryFile(delete=False)
        key_file.write(expected_key)
        key_file.close()


# Generated at 2022-06-24 11:53:44.676393
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .fragment import FragmentFD
    from .external import FFmpegFD
    from .dash import DASHFD
    from .m3u8 import M3U8FD
    def class_can_download(cls, manifest, info_dict):
        instance = cls(None, {})
        return cls.can_download(instance, manifest, info_dict)

    def class_can_download_frag(cls, manifest, info_dict):
        instance = cls(None, {})
        return cls.can_download_frag(instance, manifest, info_dict)

    def test(manifest, info_dict, exp):
        print(manifest.replace('\n', '\\n').replace('\r', '\\r'), info_dict, exp)


# Generated at 2022-06-24 11:53:53.533128
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import test.test_func
    global test_HlsFD_real_download
    test_HlsFD_real_download = test.test_func.test_download_object(
        'HlsFD',
        download_func_name='_download_fragment',
        test_url='https://bitdash-a.akamaihd.net/content/MI201109210084_1/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8')
    test_HlsFD_real_download()

# Generated at 2022-06-24 11:53:58.534107
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..utils import PreparedRequest
    return HlsFD(YoutubeIE(), {'urls': ['https://example.com/index.m3u8']}, PreparedRequest('GET', 'https://example.com/index.m3u8'))

# Generated at 2022-06-24 11:54:08.666546
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """
    Unit test for method real_download of class HlsFD.
    """
    from .__main__ import FakeYDL
    ydl = FakeYDL()
    ydl.add_info_extractor(HlsFD)
    ydl.add_info_extractor(FFmpegFD)
    ydl.add_default_info_extractors()
    ydl.params['hls_prefer_native'] = True

    info = ydl.extract_info(
        'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8',
        download=False)
    assert info['formats'][0]['url'].startswith('https://')
    assert HlsFD

# Generated at 2022-06-24 11:54:19.876623
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert can_decrypt_frag
    from .tests.test_download import _test_real_download_using_file
    from ..downloader import YoutubeDL

    ydl = YoutubeDL({
        'outtmpl': '%(id)s_%(fps)s_%(format_id)s_%(height)s_%(tbr)s.ts',
        'format': 'bestvideo[height<=480]+bestaudio/best[height<=480]',
        'noplaylist': True,
        'hls_prefer_ffmpeg': False,
        'logger': YoutubeDL.make_default_logger(),
        'progress_hooks': [None],
        'test': True,
    })


# Generated at 2022-06-24 11:54:32.889304
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import inspect
    import unittest
    import os
    import sys
    import tempfile
    temp_file_path = tempfile.mkdtemp()
    class_to_test = HlsFD
    file_to_write = os.path.join(temp_file_path, 'test_HlsFD_can_download.py')
    with open(file_to_write, 'w') as f:
        start_line = inspect.getsourcelines(class_to_test)[1]
        f.write(''.join(inspect.getsourcelines(class_to_test)[0][start_line:]))
    sys.path.append(temp_file_path)
    mod = __import__('test_HlsFD_can_download')
    reload(mod)

# Generated at 2022-06-24 11:54:39.493938
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..downloader import YoutubeDL
    from .fragment import FragmentFD

    ydl = YoutubeDL({})
    info_dict = {}
    info_dict['url'] = 'http://www.bok.net/dash/tears_of_steel/cleartext/stream.mpd'

    assert FFmpegFD.can_download(None, info_dict)
    assert not FragmentFD.can_download(None, info_dict)
    assert not HlsFD.can_download(None, info_dict)

# Generated at 2022-06-24 11:54:49.906280
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    downloader = YoutubeDL()
    HlsFD.can_download(None, {'protocol': 'https', 'ext': 'mp4'})

# Generated at 2022-06-24 11:55:00.850831
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class Options:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    global can_decrypt_frag
    can_decrypt_frag = True  # assuming that the Crypto module is installed
    info_dict = {
        'url': 'https://www.example.org',
        'is_live': False,
        'http_headers': {
            'User-Agent': 'test'
        }
    }

    options = Options(test=True)
    hls_fd = HlsFD(options, info_dict)
    # Successful check

# Generated at 2022-06-24 11:55:08.611581
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():

    from .fragment import Manifest

    from ..extractor import get_info_extractor, YoutubeIE
    from ..compat import (
        compat_urllib_request,
    )
    #  Test that extraction does not fail on live streams (https://github.com/ytdl-org/youtube-dl/issues/10769)
    def test_live_streams_extraction(self):
        manifest_url = 'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8'
        info_dict = YoutubeIE._extract_from_m3u8(
            self, manifest_url, 'Video title', 'Video description', 1920, 1080
        )

# Generated at 2022-06-24 11:55:20.790672
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..utils import get_cachedir
    from ..extractor import gen_extractors
    # extractors downloaded from https://github.com/ytdl-org/youtube-dl/blob/master/youtube_dl/extractor/__init__.py
    # on 2017-07-07, version 2017.7.4

# Generated at 2022-06-24 11:55:33.349560
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import pytest

    # Test invalid parameters
    ydl = object()
    with pytest.raises(Exception):
        HlsFD(ydl, None)

    params = {}
    hls_fd = HlsFD(ydl, params)

    # Test get_frag_index with an invalid fragment_index parameter
    ctx = {'filename': 'filename'}
    with pytest.raises(Exception):
        hls_fd._get_frag_index(ctx)

    # Test get_frag_index with a valid fragment_index parameter
    ctx = {'filename': 'filename', 'fragment_index': 1, 'total_frags': 3}
    assert hls_fd._get_frag_index(ctx) == 1
    assert ctx['fragment_index'] == 2

# Generated at 2022-06-24 11:55:46.637889
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():

    # Test case 1
    manifest = (
        "#EXTM3U\n"
        "#EXT-X-VERSION:3\n"
        "#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=1280000\n"
        "index-v1-a1.m3u8\n")
    info_dict = {'url': 'http://example.com/file.m3u8'}
    result = HlsFD.can_download(manifest, info_dict)

    assert(result == True)

    # Test case 2

# Generated at 2022-06-24 11:55:51.159016
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download(
        "#EXTM3U\n"
        "#EXT-X-MEDIA-SEQUENCE:1\n"
        "test/test.ts\n", {})

test_HlsFD()

# Generated at 2022-06-24 11:56:02.527884
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import FakeYDL
    from ..extractor import YoutubeIE

    class FakeInfoDict(dict):
        def __init__(self):
            super(FakeInfoDict, self).__init__()
            self.__dict__ = self
    info_dict = FakeInfoDict()
    info_dict.url = 'http://example.com/index.m3u8'
    info_dict.get = dict.get
    info_dict.update = dict.update
    info_dict.pop = dict.pop
    info_dict['extractor'] = YoutubeIE(FakeYDL())

    # existing m3u8
    # playlist with malformed m3u8
    # malformed url
    # malformed url (fragment only)
    # malformed url (http_headers only)
    # malformed url (

# Generated at 2022-06-24 11:56:14.246291
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor

    class TestIE(InfoExtractor):
        IE_NAME = 'TestIE'
        _VALID_URL = r'https?://(?:www\.)?example\.com/'

        def _real_extract(self, url):
            return {}

    ie = TestIE()

    manifest_url = 'http://example.com/manifest.m3u8'
    manifest = '#EXTM3U\n#EXT-X-VERSION:3\n#EXTINF:2,\nfrag.ts\n'
    info_dict = {'url': manifest_url}
    assert HlsFD.can_download(manifest, info_dict)


# Generated at 2022-06-24 11:56:25.768629
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import FakeYDL
    from .common import add_fake_info_extractor, add_mock_entry

    ydl = FakeYDL()
    add_mock_entry(ydl, 'HlsExtractInfo', {
        'url': 'http://testurl/playlist.m3u8',
        'playlist': 'playlist.m3u8',
        'extractor': 'HlsExtractInfo'
    })

    # Test playlist download
    add_fake_info_extractor(ydl, {
        '_type': 'url_transparent',
        'url': 'http://testurl/playlist.m3u8',
        'ie_key': 'HlsExtractInfo',
        'title': 'test_HlsFD_real_download'
    })

    # Test decryption

# Generated at 2022-06-24 11:56:37.426559
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-24 11:56:49.052924
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Test empty m3u8
    assert HlsFD.can_download('', {})

    # Test m3u8 without any unsupported features

# Generated at 2022-06-24 11:57:02.374662
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    try:
        os.remove('test-HlsFD_real_download.mp4')
    except:
        pass
    from ..YoutubeDL import YoutubeDL
    import uuid

    ydl_opts = {
        'cachedir': False,
        'quiet': True,
        'format': '135',
        'outtmpl': 'test-HlsFD_real_download.mp4',
        'test': True,
        'logger': open(os.devnull, 'w'),
    }
    ydl_opts_aes = ydl_opts.copy()
    ydl_opts_aes['hls_prefer_native'] = True
    ydl_opts_ffmpeg = ydl_opts.copy()

# Generated at 2022-06-24 11:57:14.439912
# Unit test for constructor of class HlsFD
def test_HlsFD():
    manifest = '''
#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:6
#EXT-X-MEDIA-SEQUENCE:24
#EXT-X-INDEPENDENT-SEGMENTS
#EXT-X-KEY:METHOD=AES-128,URI="https://protected.example.com/key"
#EXT-X-PROGRAM-DATE-TIME:2014-08-13T13:36:33+00:00
#EXTINF:5,
http://media.example.com/fileSequence24.ts
#EXTINF:5,
http://media.example.com/fileSequence25.ts
#EXTINF:5,
http://media.example.com/fileSequence26.ts
#EXT-X-ENDLIST
    '''

# Generated at 2022-06-24 11:57:14.944902
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass

# Generated at 2022-06-24 11:57:25.393170
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import json
    import random

    def get_samples_dirs(samples_dir, sample_subdir=''):
        sample_subdirs = []
        for file_name in os.listdir(os.path.join(samples_dir, sample_subdir)):
            if os.path.isdir(os.path.join(samples_dir, sample_subdir, file_name)):
                sample_subdirs.append(os.path.join(sample_subdir, file_name))
        if not sample_subdirs:
            return [sample_subdir]
        else:
            subdirs = []

# Generated at 2022-06-24 11:57:33.124188
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import Downloader
    from .extractor import gen_extractors

    gen_extractors()

    downloader = Downloader('', {})
    downloader.add_info_extractor(HlsFD())


# Generated at 2022-06-24 11:57:42.824423
# Unit test for constructor of class HlsFD
def test_HlsFD():

    # Test if HlsFD is initialized for a manifest that contains
    # unsupported features
    def test_HlsFD_unsupported_features(manifest_content, is_live):
        ydl = {'urlopen': lambda x: manifest_content}
        info_dict = {
            'url': '',
            '_type': 'hls',
            'is_live': is_live,
        }
        assert not HlsFD.can_download(manifest_content, info_dict)

    # Test if HlsFD is initialized for a manifest that does not
    # contain unsupported features
    def test_HlsFD_supported_features(manifest_content, is_live):
        ydl = {'urlopen': lambda x: manifest_content}

# Generated at 2022-06-24 11:57:48.695031
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():

    import os
    import json

    from .extractor.http import HTTPIE

    this_dir = os.path.dirname(os.path.abspath(__file__))
    here = lambda *p: os.path.join(this_dir, *p)

    data_dir = here('hls')
    HlsFD.initialize_options()
    FD_NAME = HlsFD.FD_NAME

    def check_can_download(name, m3u8_data):
        return HlsFD.can_download(
            m3u8_data,
            HTTPIE.process_ie_result(
                {},
                json.loads(m3u8_data),
                name
            )
        )


# Generated at 2022-06-24 11:57:58.412371
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    HlsFD(None, {})
    assert HlsFD.can_download("#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI=\"http://example.com/key\"\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:10,\nhttps://example.com/0.ts",
        {'is_live': False}) is False
    assert HlsFD.can_download("#EXTM3U\n#EXT-X-KEY:METHOD=SAMPLE-AES-CENC,URI=\"http://example.com/key\"\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:10,\nhttps://example.com/0.ts",
        {'is_live': False}) is False
    assert HlsFD

# Generated at 2022-06-24 11:58:09.464432
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
    from ydl.utils import fake_info_dict
    class TestYdl:
        def __init__(self, params):
            self.params = params
        def to_screen(self, msg):
            pass
        def trouble(self, msg, tb):
            raise Exception(msg)
        def to_stderr(self, msg):
            pass
        def report_error(self, msg, tb=None):
            raise Exception(msg)
        def urlopen(self, url):
            from .test_fragments import test_fragment_download
            return test_fragment_download(url, self)


# Generated at 2022-06-24 11:58:11.263291
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import _run_fd_test
    _run_fd_test(HlsFD)

# Generated at 2022-06-24 11:58:21.910357
# Unit test for constructor of class HlsFD

# Generated at 2022-06-24 11:58:34.554534
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class FakeInfoDict:
        def __init__(self, is_live=False):
            self.is_live = is_live

    assert HlsFD.can_download('', FakeInfoDict())
    assert HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-TARGETDURATION:10\n'
        '#EXT-X-MEDIA-SEQUENCE:0\n'
        '#EXTINF:10.000,\n'
        'https://example.com/0\n'
        '#EXTINF:10.000,\n'
        'https://example.com/1\n'
        '#EXT-X-ENDLIST',
        FakeInfoDict())

# Generated at 2022-06-24 11:58:43.529953
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data

    # Download first fragment of test playlist using hlsnative
    ydl_opts = {
        'continuedl': True,
        'noplaylist': True,
        'skip_download': True,
        'quiet': True,
        'simulate': True,
    }
    hls_fd = HlsFD(get_test_data(), ydl_opts)
    info_dict = {
        'id': 'foobar',
        'url': 'http://127.0.0.1:8080/test/playlist.m3u8',
        'title': 'foobar',
        'ext': 'mp4',
        'http_headers': {'User-Agent': 'Foo'},
    }
    filename = 'foobar.mp4'
    result

# Generated at 2022-06-24 11:58:45.105470
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD(None, None).FD_NAME == 'hlsnative'


# Generated at 2022-06-24 11:58:56.016334
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def hls_can_download(manifest, extra_param_to_segment_url=None):
        info_dict = {
            'url': 'http://example.com',
            'http_headers': {},
            '_decryption_key_url': None,
            '_decryption_key': None,
            'extra_param_to_segment_url': extra_param_to_segment_url,
        }
        return HlsFD.can_download(manifest, info_dict)

    assert hls_can_download('#EXTM3U', None)

# Generated at 2022-06-24 11:59:00.589962
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    good_test_manifest = '#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:10.000,\n'
    bad_test_manifest = '#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:0\n#EXT-X-KEY:URI="https://test.com/test.key",METHOD=AES-128\n#EXTINF:10.000,\n'
    assert HlsFD.can_download(good_test_manifest, {})
    assert not HlsFD.can_download(bad_test_manifest, {})

# Generated at 2022-06-24 11:59:05.873852
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({})
    url = 'http://example.com/test.m3u8'
    info_dict = {'manifest_url': url}
    HlsFD(ydl, {'test': True}).real_download('test.m3u8', info_dict)

# Generated at 2022-06-24 11:59:12.349384
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.FD_NAME == 'hlsnative'
    assert HlsFD.can_download(None, None)
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=FOO', None)
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', None)
    assert not HlsFD.can_download('#EXT-X-MAP:URI="foo.ts"', None)
    assert not HlsFD.can_download('#EXT-X-PLAYLIST-TYPE:EVENT', {'is_live': True})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'is_live': True})

# Generated at 2022-06-24 11:59:22.976865
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    from .http import HttpFD
    from .external import FFmpegFD

    class InjectedInfoExtractor(InfoExtractor):
        def __init__(self, ie):
            self.ie = ie
            self.gen_extractors()

        def gen_extractors(self):
            return

        def _real_extract(self, url):
            return self.ie._real_extract(url)

        def _download_webpage_handle(self, *args, **kwargs):
            return self.ie._download_webpage_handle(*args, **kwargs)


# Generated at 2022-06-24 11:59:35.948824
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:59:47.012328
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..downloader.common import FileDownloader
    ydl = FileDownloader({})

    url = 'http://example.com/playlist.m3u8'
    params = {
        'noprogress': True,
        'test': True,
        'format': 'bestaudio/best',
        # Set an arbitrary but unique value for the test.
        'hls_base_url': 'http://example.com/base',
    }
    info_dict = {
        'id': '0',
        'url': url,
        'ext': 'mp4',
        'hls_base_url': 'http://example.com/base',
        'http_headers': {'Youtubedl-no-cookies': True},
    }

    fd = HlsFD(ydl, params)
   

# Generated at 2022-06-24 11:59:58.534556
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest

    class HlsFDTest(unittest.TestCase):
        def test_hlsnative_supported_features(self):
            man_url = 'https://mnmedias.api.telequebec.tv/m3u8/29880.m3u8'
            info_dict = {
                'url': man_url,
                'protocol': 'm3u8_native',
            }
            resp = HlsFD.can_download(None, info_dict)
            self.assertEqual(True, resp)

        def test_hlsnative_unsupported_features(self):
            man_url = 'https://mnmedias.api.telequebec.tv/m3u8/29880.m3u8'

# Generated at 2022-06-24 12:00:04.410160
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import get_info_extractor
    from ..downloader.common import FileDownloader

    # The URL for this clip used for testing contains some AD fragments
    # and the m3u8 file does not contain EXT-X-MEDIA-SEQUENCE so the
    # live stream heuristic fails:
    # http://hls-geo.daserste.de/i/videoportal/Film/c_620000/622873/format,716451,716457,716450,716458,716459,.mp4.csmil/master.m3u8

    HlsFD.can_download('', {})
    HlsFD.can_download('#EXTM3U', {})

# Generated at 2022-06-24 12:00:15.448907
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import youtube

    ydl = youtube.YoutubeDL({})
    HlsFD(ydl, {})
    assert HlsFD.can_download('#EXTM3U8', {'is_live': False})
    assert not HlsFD.can_download('#EXTM3U8', {'is_live': True})
    assert not HlsFD.can_download('#EXT-X-PLAYLIST-TYPE:EVENT', {'is_live': False})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'is_live': False})
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'is_live': False, '_decryption_key_url': 'foo'})

# Generated at 2022-06-24 12:00:24.419553
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def get_test_test(test_case):
        def test(self):
            assert self.can_download(test_case['manifest'], test_case['info_dict']) == test_case['can_download']
        return test

    from .extractor.common import InfoDict

# Generated at 2022-06-24 12:00:35.581677
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """Unit test for method real_download of class HlsFD"""
    from ..extractor import YoutubeIE
    from ..ytdl_url import context_data
    import os
    import shutil
    urlopen = compat_urllib_request.urlopen

# Generated at 2022-06-24 12:00:45.027333
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import subprocess
    import tempfile

    tmp_dir = tempfile.mkdtemp('youtube-dl_HlsFD_real_download')
    playback_file = os.path.join(tmp_dir, 'test.mp4')
    print('Writing to %s' % playback_file)

    assert 0 == subprocess.call([
        'python', '-m', 'youtube_dl.postprocessor.ffmpeg',
        '-i', 'https://www.youtube.com/watch?v=Bf28tB8TZ9Y',
        '-loglevel', 'info',
        '-o', playback_file, '--test',
    ])

    assert os.path.exists(playback_file)
    print('Test for HlsFD.real_download passed')


# Generated at 2022-06-24 12:00:53.716038
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import encode_data_uri

# Generated at 2022-06-24 12:01:06.757938
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import datetime
    import pytest
    import youtube_dl.FileDownloader as ydl_FileDownloader
    import youtube_dl.PostProcessor as ydl_PostProcessor
    import youtube_dl.InfoExtractors.GenericIE as ydl_InfoExtractors_GenericIE
    import youtube_dl.Downloader as ydl_Downloader

    def make_params():
        params = ydl_FileDownloader.FileDownloader.params.copy()

# Generated at 2022-06-24 12:01:12.560968
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from . import YoutubeDL
    from .extractor.common import InfoExtractor
    from .utils import PreparedRequest

    ie = InfoExtractor(YoutubeDL(), 'https://youtu.be/BaW_jenozKc')
    request = PreparedRequest()
    ctx = {}
    fd = HlsFD(ie, ctx, request, {})
    assert fd.total_frags == 0


# Generated at 2022-06-24 12:01:24.470696
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from . import YoutubeDL
    from .extractor.generic import GenericIE

    # Downloading a valid hls url
    url = 'https://www.youtube.com/watch?v=g6IXzc6Hk-4'
    ydl = YoutubeDL(params={'hls_prefer_native': True})
    ydl.add_default_info_extractors()
    result = ydl.extract_info(url, True)
    assert 'formats' in result

    # Check hls format is downloaded with hlsnative
    result_formats = result['formats']
    is_hls_downloaded_with_hlsnative = False
    for format in result_formats:
        if format['format_id'] == 'hls' and format['downloader'] == 'hlsnative':
            is_h

# Generated at 2022-06-24 12:01:35.319848
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """
    Test HlsFD constructor.
    """
    url = 'https://video-http.media-imdb.com/MV5BY2Q2YjY0MjAtMjI3NC00NDI0LTg3MTUtNDMzZTVmYTU4YTg4XkExMV5BbXA0XkFpbWRiLWV0cy10cmFuc2NvZGU@.m3u8'
    ydl = object()
    params = {'test': True}
    fd = HlsFD(ydl, params)
    assert type(fd) == HlsFD
    assert fd._prepare_url(None, url) == url
    assert fd.params == params

# Generated at 2022-06-24 12:01:42.375841
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    import youtube_dl
    sys.argv = ['youtube-dl', '--hls-prefer-native']
    ydl = youtube_dl.YoutubeDL(dict(hls_prefer_native=True))
    ydl.add_info_extractor(HlsFD(ydl, dict(hls_prefer_native=True)))

# Generated at 2022-06-24 12:01:51.586445
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD

    # Constructor of class HlsFD
    HlsFD_tester = HlsFD(HttpFD(), {'noprogress': True, 'quiet': True})

    # Test type of instance HlsFD_tester
    assert isinstance(HlsFD_tester, HlsFD)
    assert isinstance(HlsFD_tester, FragmentFD)
    assert isinstance(HlsFD_tester, InfoExtractor)

# Generated at 2022-06-24 12:02:04.596205
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Importing modules
    import os
    import sys
    import time

    # Adding parent folder to sys.path
    sys.path.append(os.path.realpath(".."))

    # Local import from .pytube import YouTube
    from pytube import YouTube
    from pytube.exceptions import RegexMatchError

    # Test download
    start = time.time()
    test_yt = YouTube('https://youtu.be/9bZkp7q19f0')
    print(test_yt.title)
    test_stream = test_yt.streams.filter(only_audio=True).first()
    start = time.time()
    test_stream.download(output_path='/tmp', filename='test_audio_download')
    print('Download time: ', time.time()-start)

# Generated at 2022-06-24 12:02:15.470283
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """A constructor of HlsFD and its get_fragment_retries method should work."""
    test_ydl = {}
    test_params = {}
    assert HlsFD(test_ydl, test_params).get_fragment_retries() == (0, False)
    test_params['fragment_retries'] = 3
    test_params['skip_unavailable_fragments'] = True
    assert HlsFD(test_ydl, test_params).get_fragment_retries() == (3, True)

# Generated at 2022-06-24 12:02:23.333689
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from youtube_dl.extractor.youtube import YoutubeIE

    info_dict = YoutubeIE()._parse_html5_media_entries(
        'Dummy video', '<script>var ytplayer = {};ytplayer.config = {"args":{"url_encoded_fmt_stream_map":"foo=bar"}};</script>', None, 'Dummy video id')[0]

    HlsFD.can_download('manifest with no unsupported features', info_dict)

    assert not HlsFD.can_download('manifest with unknown method', info_dict)

    # The test is skipped because the heuristic does not work in every case.
    # See the comment in HlsFD.can_download() function.
    # assert not HlsFD.can_download('manifest with live event', info_dict)

    # The test is

# Generated at 2022-06-24 12:02:35.308925
# Unit test for constructor of class HlsFD

# Generated at 2022-06-24 12:02:47.333695
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """Unit test for constructor of class HlsFD"""
    import os
    import pprint
    from ..utils import DateRange
    from ..extractor import YoutubeDL
    from ..downloader.http import HttpFD
    from .m3u8 import M3u8FD
    from .external import FfmpegFD

    def test_HlsFD_download(url, filename, info_dict, params):

        if not os.path.exists(filename):
            with open(filename, 'wb') as f:
                ret = False
                for fd in (FfmpegFD, M3u8FD, HlsFD):
                    try:
                        fd_obj = fd(ydl, params)
                        ret = fd_obj.real_download(filename, info_dict)
                        break
                    except Exception as e:
                        pass