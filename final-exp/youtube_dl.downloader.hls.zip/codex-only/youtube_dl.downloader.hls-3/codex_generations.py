

# Generated at 2022-06-24 11:52:55.969777
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import os
    os.chdir('tests')


# Generated at 2022-06-24 11:53:07.085696
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .youtube import YoutubeFormatsInfoExtractor
    from .common import InfoExtractor
    from .utils import ExtractorError
    from ..compat import compat_urllib_error

    # Test constructor
    HlsFD(YoutubeFormatsInfoExtractor(), {}, params={}).real_download('', {})
    # Test HLS stream with byte range
    HlsFD(YoutubeFormatsInfoExtractor(), {}, params={}).real_download('', {})
    # Test HLS stream with different encryption method
    try:
        HlsFD(YoutubeFormatsInfoExtractor(), {}, params={}).real_download('', {})
    except ExtractorError as e:
        assert 'pycrypto not found' in str(e)
    # Test HLS stream with unavailable fragments

# Generated at 2022-06-24 11:53:09.867134
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, None)

# Generated at 2022-06-24 11:53:20.969942
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    print('Testing method HlsFD.can_download')
    assert(HlsFD.can_download('', {}))
    assert(HlsFD.can_download('#EXTM3U', {}))
    assert(HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXTINF:1,file.mp4\nfile.mp4', {}))
    assert(HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:1\n#EXTINF:1,file.mp4\nhttp://url.file.mp4', {}))

# Generated at 2022-06-24 11:53:29.282812
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    try:
        import pytest
    except ImportError:
        pytest = None

    class ChunkedDownloader:
        def __init__(self, chunks, error_indices=()):
            self.chunks = chunks
            self.error_indices = error_indices
            self.i = 0

        def read(self, count=-1):
            if self.i in self.error_indices:
                self.i += 1
                raise compat_urllib_error.HTTPError('', '', '', '', None)
            self.i += 1
            if self.i > len(self.chunks):
                return b''
            return self.chunks[self.i - 1]

    class TestURLOpener:
        def __init__(self, chunks):
            self.chunks = chunks

       

# Generated at 2022-06-24 11:53:35.504876
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:53:43.731633
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import youtube_dl.YoutubeDL
    from unittest.mock import patch

    class Test_HlsFD(unittest.TestCase):
        def setUp(self):
            self.test_url = 'https://example.com/manifest.m3u8'

# Generated at 2022-06-24 11:53:54.870661
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testdata

    # Test with a Ustream-like HLS from "http://ustream.tv/channel/worldnewstv"
    test_data = get_testdata()
    man_url = 'https://edge-wb.cdn.ustream.tv/ustream-vod/23742213.smil/chunklist.m3u8'
    ydl = MockYDL()
    params = {
        'format': 'hls',
        'test': True,
        'quiet': True,
        'skip_download': True,
        'outtmpl': test_data + '/%(id)s-%(epoch)s.ts',
        'hls_prefer_native': True,
    }
    fd = HlsFD(ydl, params)
    info_dict

# Generated at 2022-06-24 11:54:06.714437
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import json
    from .test import get_test_data

    data = get_test_data('test_hlsnative.m3u8')

    data = json.loads(data.decode('utf-8'))
    name = data["name"]
    url = data["url"]
    fragment_index = data["fragment_index"]
    output = data["output"]
    info_json = data["info_json"]

    info_json['url'] = url

    hls_fd = HlsFD(None, {
        'simulate': True,
        'test': True,
        'fragment_index': fragment_index,
    })
    frag_urls = set()
    frag_url = None
    count = 0
    for line in output.splitlines():
        line = line.strip()
       

# Generated at 2022-06-24 11:54:18.572750
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..utils import SearchInfoExtractor
    from ..extractor.common import InfoExtractor


# Generated at 2022-06-24 11:54:31.663018
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import youtube_dl.YoutubeDL
    ydl = YoutubeDL.YoutubeDL({'verbose': False, 'simulate': True})
    ydl.add_default_info_extractors()
    dl = HlsFD(ydl, {'simulate': True}, {})
    dl.real_download('foo.mp4', {
        'url': 'http://localhost:8080/test/test.m3u8',
        'http_headers': {'Range': 'bytes=0-'},
        'format': '123',
        '_decryption_key_url': 'http://localhost:8080/test/test.key',
        'ext': 'mp4',
        'protocol': 'm3u8_native',
    })

# Generated at 2022-06-24 11:54:38.533580
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U', {'url': ''})
    assert HlsFD.can_download(
        '#EXTM3U\n#EXT-X-KEY:METHOD=NONE\n#EXTINF:5.008,\nmain.mp4\n#EXT-X-ENDLIST', {'url': ''})
    assert not HlsFD.can_download(
        '#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\n#EXTINF:5.008,\nmain.mp4\n#EXT-X-ENDLIST', {'url': ''})

# Generated at 2022-06-24 11:54:49.423393
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    hls_fd = HlsFD(None, {'format': 'best'})
    # Test encrypted streams
    assert not hls_fd.can_download(
        '#EXTM3U\n'
        '#EXT-X-TARGETDURATION:10\n'
        '#EXT-X-MEDIA-SEQUENCE:0\n'
        '#EXT-X-KEY:METHOD=AES-128,URI="https://example.com/key.bin"\n'
        '#EXTINF:10,\n'
        '0.ts\n'
        '#EXT-X-ENDLIST', {}), 'should not be able to download encrypted streams'

    # Test live streams

# Generated at 2022-06-24 11:54:55.658484
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    return HlsFD(None, {'test': True}).real_download('test.ts', {
        'url': 'http://example.com/index.m3u8',
        'ext': 'ts',
        'http_headers': {'User-Agent': 'Test/1.0'},
        '_decryption_key_url': 'http://example.com/decryption.key',
    })

# Generated at 2022-06-24 11:55:01.916586
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # This "test" is just to make sure that HlsFD can be created on its own.
    # See https://github.com/ytdl-org/youtube-dl/pull/27659 for more details. Since
    # FragmentFD uses super(), we can't just create it with "FragmentFD()", so it
    # needs to be created with "HlsFD()" instead.
    fd = HlsFD(None, None)
    # TODO: find a better way to test it

# Generated at 2022-06-24 11:55:04.878074
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import YoutubeDL
    ydl = YoutubeDL()
    u = 'https://example.com/manifest.m3u8'
    HlsFD(ydl, {'url': u, 'duration': 12}).real_download('-', {'url': u})


# Generated at 2022-06-24 11:55:11.286538
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    instance = HlsFD()

    # Test cases:
    #   can_download(manifest, info_dict)

# Generated at 2022-06-24 11:55:22.011540
# Unit test for constructor of class HlsFD

# Generated at 2022-06-24 11:55:34.857401
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .fragment import HlsFD
    from .external import FFmpegFD

    def test_can_download(url, expected_output):
        assert (HlsFD.can_download(url, {}) == expected_output), \
            'Expected "%s" for "%s" got "%s"' % (expected_output, url, HlsFD.can_download(url, {}))

    # Cannot be downloaded with ffmpeg
    test_can_download('#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-MEDIA-SEQUENCE:5\n#EXT-X-TARGETDURATION:5\n#EXTINF:5,\nfileSequence5.ts', False)

# Generated at 2022-06-24 11:55:35.871798
# Unit test for constructor of class HlsFD
def test_HlsFD():
    return HlsFD


# Generated at 2022-06-24 11:55:44.365750
# Unit test for constructor of class HlsFD
def test_HlsFD():
    cfg = {'skip_download': True}
    ydl = YoutubeDL(cfg)
    ydl.add_default_info_extractors()
    info_dict = {}
    url = 'http://example.com/manifest.m3u8'
    HlsFD(ydl, ydl.params).extract_info(url, download, False, info_dict)
    assert info_dict['_type'] == 'hls'


# Generated at 2022-06-24 11:55:52.142363
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import YoutubeDL

    class MyYoutubeDL(YoutubeDL):
        def __init__(self, params={}):
            super(MyYoutubeDL, self).__init__(params)

        def to_screen(self, message, skip_eol=False):
            print(message)

        def report_error(self, message, tb=None):
            print('[error] ' + message)

        def prepare_filename(self, info_dict):
            return info_dict['id']


# Generated at 2022-06-24 11:56:03.103165
# Unit test for constructor of class HlsFD
def test_HlsFD():
    class DummyYDL(object):
        class params(object):
            hls_use_mpegts = True

    # test with an unsupported manifest
    dummy_ydl = DummyYDL()

# Generated at 2022-06-24 11:56:14.752747
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeDL
    dl = YoutubeDL({})
    hlsfd = HlsFD(dl, {'fragment_retries': 10})

    # Test can_download

# Generated at 2022-06-24 11:56:16.480590
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_fd = HlsFD(None, {'format': 'hls'})
    return hls_fd

# Generated at 2022-06-24 11:56:27.694674
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..compat import compat_urlparse

    ie = InfoExtractor('test', {})
    ie._downloader.params.get = lambda name: None
    ie._downloader.post_processing = False
    ie._match_id = lambda info_dict: 'http://example.com/%s' % info_dict.get('id')

# Generated at 2022-06-24 11:56:35.285251
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import json

    test_data = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'HlsFD_can_download.json')
    with open(test_data) as f:
        test_cases = json.load(f)

    for test_case in test_cases:
        assert HlsFD.can_download(test_case['manifest'], {'is_live': test_case['is_live']}) is test_case['result']

# Generated at 2022-06-24 11:56:43.814575
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert can_decrypt_frag is False
    info_dict = {
        'url': 'https://www.example.com/video.m3u8',
        'http_headers': {
            'User-Agent': 'Lavf/56.40.101',
            'Accept': '*/*',
            'Connection': 'close',
            'Icy-MetaData': '1',
            'Range': 'bytes=0-'
        },
        '_decryption_key_url': 'https://www.example.com/key.bin',
        'is_live': False
    }
    from .common import FileDownloader
    ydl = FileDownloader(params={'simulate': True})

# Generated at 2022-06-24 11:56:52.768632
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'is_live': False})
    assert not HlsFD.can_download('#EXT-X-STREAM-INF', {'is_live': False})

    assert HlsFD.can_download('#EXT-X-KEY:METHOD=NONE', {'is_live': False})
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'is_live': False, '_decryption_key_url': 'http://example.com'})
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=NONE', {'is_live': True})

# Generated at 2022-06-24 11:56:59.070788
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.dummy import DummyExtractor
    from ..extractor.youtube import YoutubeIE
    from ..compat import compat_HTTPError

    class FakeYdl(object):
        params = {}

        def to_screen(self, message):
            pass

        def urlopen(self, url):
            return io.BytesIO(b'abc')

        def report_warning(self, message):
            pass

        def report_error(self, message):
            pass

        def download(self, info_dict):
            if 'error' in info_dict:
                raise compat_HTTPError(None, None, None, None, None)
            return info_dict

        def extractor_names(self):
            return []

    class FakeIE(InfoExtractor):
        IE_

# Generated at 2022-06-24 11:57:06.201903
# Unit test for constructor of class HlsFD
def test_HlsFD():
    filename = 'dummy'
    ydl = 'dummy'
    params = {
        'format': 'dummy',
        'fragment_base_url': 'dummy',
        'fragment_retries': 0,
        'skip_unavailable_fragments': False,
        'test': False,
        'http_chunk_size': 10 * 1024 * 1024
    }

    hls = HlsFD(ydl, params)

    assert hls._http_chunk_size == params['http_chunk_size']


# Generated at 2022-06-24 11:57:14.773692
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from time import time
    from ..utils import DateRange
    hls_fd = HlsFD(None, {'hls_use_mpegts': False})
    hls_fd.params['hls_start_offset'] = 0
    hls_fd.params['hls_duration'] = 0
    from_timestamp = int(time()*1000)
    to_timestamp = from_timestamp + 20000
    hls_fd.params['date_range'] = DateRange(from_timestamp, to_timestamp)
    return hls_fd

# Generated at 2022-06-24 11:57:19.644259
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download("#EXT-X-TARGETDURATION:30", {'is_live': False})
    assert not HlsFD.can_download("#EXT-X-KEY:METHOD=AES-128", {'is_live': False})
    assert not HlsFD.can_download("#EXT-X-KEY:METHOD=NONE", {'is_live': True})

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 11:57:24.602733
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .mock import MockYDL
    from .extractor import YoutubeIE
    extractor = YoutubeIE()
    mock_ydl = MockYDL()
    HlsFD.can_download('', extractor._extract_info(mock_ydl, {'url': 'https://example.com/'}))

# Generated at 2022-06-24 11:57:32.801398
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:57:37.487266
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'format': '141/140/251/250/171/249/bestaudio', 'test': True})
    ydl.add_default_info_extractors()
    results = {}
    def test_hook(d):
        if d['status'] == 'finished':
            results['downloaded_bytes'] = d['downloaded_bytes']
            results['total_bytes'] = d['total_bytes']
        elif d['status'] == 'downloading':
            results['fragment_index'] = d['fragment_index']
            results['frags_to_download'] = d['frags_to_download']
    ydl.add_progress_hook(test_hook)

# Generated at 2022-06-24 11:57:48.940982
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import pytest
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.http import HttpFD

    # No video
    youtube_dl_options = {'skip_download': True}
    with YoutubeDL(youtube_dl_options) as ydl:
        with pytest.raises(Exception):
            ydl.download(['https://www.youtube.com/watch?v=pkF0fRX9MCs'])
        info_dict = ydl.extract_info(
            'https://www.youtube.com/watch?v=pkF0fRX9MCs',
            download=False
        )
        assert info_dict['formats'][0]['protocol'] == 'm3u8'

# Generated at 2022-06-24 11:57:50.004836
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    HlsFD.can_download('', {})

# Generated at 2022-06-24 11:57:59.241173
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..downloader.common import FileDownloader
    from ..extractor.common import InfoExtractor
    from ..compat import quote_plus

    import collections
    import os
    import re

    from .fragment import _float_or_none, _parse_m3u8_attributes

    # Some references to help implementing unit tests
    # 1. https://tools.ietf.org/html/draft-pantos-http-live-streaming-17#section-4.3.2.4
    # 2. https://tools.ietf.org/html/draft-pantos-http-live-streaming-17#section-4.3.2.2
    # 3. https://tools.ietf.org/html/draft-pantos-http-live-streaming-17#section-4.3.3.

# Generated at 2022-06-24 11:58:10.114917
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import ydl_mocks as mocks
    m = mocks.MockYDL()
    m.add_info_extractors()
    m.params['verbose'] = True
    m.params['skip_download'] = True
    m.add_default_info_extractors()
    for ie in m.info_extractors:
        ie.download = mocks.MockInfoExtractor.download
    m.to_screen = mocks.MockYDL.to_screen
    m.report_warning = mocks.MockYDL.report_warning
    m.report_error = mocks.MockYDL.report_error
    m.report_retry_fragment = mocks.MockYDL.report_retry_fragment

    # Check that HlsFD is not used when cannot

# Generated at 2022-06-24 11:58:20.671258
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Tested: anvatoworld
    #         dazn
    #         disneynow
    #         espn
    #         twitchvod
    #         wwiitv
    #         xnxx
    url = 'http://video.anvatoworld.com/vod/_definst_/smil:smil/media/20170922/20170922_20170922_20170922_20170922_20170922.smil/playlist.m3u8'

# Generated at 2022-06-24 11:58:28.023916
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import random
    import io
    import unittest
    import tempfile
    import os.path
    import shutil

    # Mock out the FileDownloader so we don't actually download anything
    class HlsFDTest(HlsFD):
        def _download_fragment(self, ctx, fragment_url, info_dict, headers):
            return True, b'["Downloaded Fragment"]'

        def _append_fragment(self, ctx, frag):
            pass

        def _finish_frag_download(self, ctx):
            pass

    rd = random.randint(0, 2**32)
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-24 11:58:34.981631
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hlsfd = HlsFD('http://www.example.com/manifest.m3u8', 'test.mp4', {}, {})
    assert hlsfd.manifest_url == 'http://www.example.com/manifest.m3u8'
    assert hlsfd.filename == 'test.mp4'
    assert hlsfd.params == {}
    assert hlsfd.info_dict == {}
    assert hlsfd.http_headers == {}

# Generated at 2022-06-24 11:58:43.877544
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """ Returns True for pass and False for fail """

    import sys
    import pathlib

    sys.path.append(str(pathlib.Path(__file__).resolve().parent.parent))

    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import sanitize_filename
    from youtube_dl.downloader.common import FileDownloader
    from tests.test_downloader_hls import get_testcases_for_downloader_hls

    result = True
    for test_case in get_testcases_for_downloader_hls(True, False):
        if 'hls' not in test_case['expected_formats']:
            continue
        ydl = YoutubeDL(test_case['params'])
        ydl.add_default_info_extractors()

# Generated at 2022-06-24 11:58:51.169474
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:58:57.382681
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest
    import tempfile
    import os
    import shutil

    def make_manifest_file(tmpdir, manifest_text=''):
        manifest_file = os.path.join(tmpdir, 'manifest.m3u8')
        with open(manifest_file, 'w') as f:
            f.write(manifest_text)
        return manifest_file

    class TestHlsFDCanDownload(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tmpdir)


# Generated at 2022-06-24 11:59:05.017971
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ok = True
    # Check if some unsupported features will be detected
    # Bad fragment encryption
    ok &= not HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-KEY:METHOD=OTHER-ENCRYPTION\n'
        '#EXTINF:2,\n'
        'http://test.org/test.m3u8\n',
        {'is_live': False}
    )

    # Bad fragment encryption + byterange

# Generated at 2022-06-24 11:59:07.714651
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert hasattr(HlsFD, 'FD_NAME')
    assert hasattr(HlsFD, 'real_download')



# Generated at 2022-06-24 11:59:18.920779
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import Downloader
    from ..utils import DateRange, match_filter_func, unescapeHTML

    import os
    import re
    import tempfile
    import unittest

    class MockYDL(object):
        def __init__(self, params):
            self.params = params
            self.progress_hooks = []

        def add_progress_hook(self, hook):
            self.progress_hooks.append(hook)

        def urlopen(self, url, data=None, headers={}):
            self.progress_hooks[0](1, 100, 1)
            return MockResponse(url, self.params, data, headers)


# Generated at 2022-06-24 11:59:29.997977
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.http import HlsIE
    from ..utils import match_filter_func
    from .player import PlayerIE

    download_url = 'https://vod-hls.cdn.dmdentertainment.com/hls/vod/c64ffa31f2d5bcede652eb3a3bb5a5a5/afb5014f10c273b1/master.m3u8'

# Generated at 2022-06-24 11:59:39.091201
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """Test for HlsFD.real_download()"""
    from .common import fake_ydl, FakeYDL
    from .extractors.youtube import YoutubeIE
    from .downloader.external import ExternalFD


# Generated at 2022-06-24 11:59:49.447227
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .httplib2fd import HttpLib2FD
    from ..downloader import FileDownloader


# Generated at 2022-06-24 11:59:58.948650
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    """
    Tests the following cases:
    1. TEST_SUPPORTED_FEATURES: Test that the method can download playlist
        with supported features.
    2. TEST_ENCRYPTED_STREAMS: Test that the method can download encrypted
        playlist via ffmpeg.
    3. TEST_BYTE_RANGES: Test that the method can download playlist with byte
        ranges via ffmpeg.
    4. TEST_LIVE_STREAMS: Test that the method does not download live streams.
    5. TEST_INITIALIZATION: Test that the method does not download playlists
        with initialization.
    6. TEST_BYTE_RANGES_AES_128: Test that the method does not download
        playlists with byte ranges if the playlist is AES-128 encrypted.
    """
    import os
    import tempfile

# Generated at 2022-06-24 12:00:09.164230
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import datetime
    import time
    import unittest
    class TestHlsFD(unittest.TestCase):
        def test_time_left(self):
            hfd = HlsFD()
            #test zero
            self.assertEqual(hfd._time_left(datetime.timedelta(0)),'00:00')
            #test normal
            now = datetime.timedelta(seconds=time.time())
            td = now + datetime.timedelta(seconds=600)
            self.assertEqual(hfd._time_left(td),'10:00')
            #test overflow
            td = now + datetime.timedelta(seconds=99*60+59)
            self.assertEqual(hfd._time_left(td),'99:59')
            td = now + dat

# Generated at 2022-06-24 12:00:17.335615
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\na.ts\n#EXTINF:10,\nb.ts\n#EXTINF:10,\nc.ts', { 'is_live': False })

    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10,\na.ts\n#EXTINF:10,\nb.ts\n#EXTINF:10,\nc.ts', { 'is_live': True })


# Generated at 2022-06-24 12:00:18.980687
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .test import FakeYDL
    ydl = FakeYDL()
    hlsfd = HlsFD(ydl, {})

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 12:00:29.920364
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    manifest = '''
#EXTM3U
#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=65000
s.m3u8
#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=65000
s.m3u8
#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=65000
s.m3u8
'''
    info_dict = {}
    assert HlsFD.can_download(manifest, info_dict)
    info_dict['_decryption_key_url'] = 'anything'
    assert not HlsFD.can_download(manifest, info_dict)
    info_dict['_decryption_key_url'] = None
   

# Generated at 2022-06-24 12:00:34.554811
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass


# Generated at 2022-06-24 12:00:44.459139
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def check_can_download(manifest, info_dict, expected):
        assert HlsFD.can_download(manifest, info_dict) == expected
    info_dict_static = {
        'is_live': False,
        'url': '',
        'format_id': '',
    }


# Generated at 2022-06-24 12:00:53.687861
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..downloader.common import FileDownloader
    from .fragment import FragmentFD
    from .external import FFmpegFD

    assert not FFmpegFD.can_download('#EXTM3U', {})


# Generated at 2022-06-24 12:01:05.343563
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .test import get_test_data
    from ..downloader.common import FileDownloader
    fd = HlsFD(FileDownloader({}), {})
    valid_manifest = get_test_data('hls_aes_128_playlist.m3u8')
    assert fd.can_download(valid_manifest, {})
    # Encryption method is not supported
    not_valid_manifest = get_test_data('hls_aes_playlist.m3u8')
    assert not fd.can_download(not_valid_manifest, {})

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 12:01:12.372794
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    import os
    import tempfile
    import youtube_dl.extractor.common as yt_common
    import youtube_dl.downloader.http as yt_http

    class MockYtdl:
        def __init__(self):
            self.to_screen = print
            self.params = {}
            self.progress_hooks = []
            self.cache = {}
            self.urlopen = self._urlopen

        def add_progress_hook(self, hook):
            self.progress_hooks.append(hook)

        def hook(self, **kwargs):
            for hook in self.progress_hooks:
                hook(**kwargs)

        def report_error(self, msg):
            raise Exception(msg)

        def report_warning(self, msg):
            pass


# Generated at 2022-06-24 12:01:24.280062
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..downloader.http import HttpFD
    from ..utils import SearchInfoExtractor, parse_duration
    from ..compat import match_filter_func
    from ..extractor.youtube import YoutubeIE
    import pytest
    import os

    # HlsFD._download_fragment has been overwritten, so no need to download
    # every fragment
    def _download_fragment(self, ctx, frag_url, info_dict, headers):
        filename = os.path.join(self.temp_name,
                                'fragment-%d' % (self.total_frags + 1))
        self.total_frags += 1

# Generated at 2022-06-24 12:01:35.900420
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import tempfile
    import shutil
    import os
    from ..extractor import YoutubeDL
    from ..utils import encode_compat_str
    try:
        from Crypto.Cipher import AES
    except ImportError:
        AES = None

    class HlsFdTest(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.test_files_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'hlsfd_files')

        def test_real_download(self):
            ydl = YoutubeDL({'hls_use_mpegts': False})


# Generated at 2022-06-24 12:01:46.831166
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download('#EXTM3U', None)
    assert HlsFD.can_download('#EXTM3U\n' + '#EXT-X-KEY:URI="something"', None)
    assert HlsFD.can_download('#EXTM3U\n' + '#EXT-X-KEY:METHOD=AES-128,URI="something"', None)
    assert HlsFD.can_download('#EXTM3U\n' + '#EXT-X-KEY:METHOD=AES-128,URI="something"\n' + '#EXT-X-BYTERANGE:1@5', None)

# Generated at 2022-06-24 12:01:53.693706
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """Test method real_download of class HlsFD."""

    class FakeYDL(object):
        """Fake YoutubeDL class."""
        def to_screen(self, msg):
            """Fake to_screen method."""
            pass

        def report_error(self, msg):
            """Fake report_error method."""
            pass

        def report_warning(self, msg):
            """Fake report_warning method."""
            pass

    class IC(object):
        """Fake InfoExtractors class."""
        def __init__(self, info_dict):
            """Initialize InfoExtractors class."""
            self.info_dict = info_dict

    class FakeIE(object):
        """Fake InfoExtractor class."""

# Generated at 2022-06-24 12:02:02.446400
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import unittest
    test_instance = HlsFD({
        'hls_prefer_native': True,
        'test': True,
    }, {})
    class TestHlsFD(unittest.TestCase):
        def test_can_download_true(self):
            urlh = test_instance.ydl.urlopen(test_instance._prepare_url({}, 'https://github.com/ytdl-org/youtube-dl/blob/master/test/testdata/test.m3u8?raw=true'))
            s = urlh.read().decode('utf-8', 'ignore')
            self.assertTrue(HlsFD.can_download(s, {}))

# Generated at 2022-06-24 12:02:13.415068
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    params = {}
    params['url'] = 'https://zdf0414-a.akamaihd.net/media/de/sample/master.m3u8'
    params['format'] = 'hls-178'
    params['http_chunk_size'] = '1048576'
    params['test'] = True
    params['fragment_retries'] = 1
    params['skip_unavailable_fragments'] = False
    params['keep_fragments'] = True
    params['merge_output_format'] = 'mp4'
    params['outtmpl'] = 'test_output.%(ext)s'
    ydl.process_ie_result(params, download=True)


# Generated at 2022-06-24 12:02:21.431334
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .common import FakeYDL
    import io

    # Downloader for HlsFD
    ydl = FakeYDL()

    # Dummy manifest
    man = io.StringIO()

    # List of sample manifests and expected results

# Generated at 2022-06-24 12:02:33.782874
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    class InfoDict:
        pass
    info_dict = InfoDict()

    class Ydl:
        pass
    ydl = Ydl()

    class UrlOpen:
        def __init__(self, url):
            self.url = url

        def geturl(self):
            return self.url

        def read(self):
            return b''

    ydl.urlopen = UrlOpen

    class Params:
        def get(self, param, default=None):
            if param == 'verbose':
                return False
            elif param == 'fragment_retries':
                return 0
            elif param == 'skip_unavailable_fragments':
                return True
            elif param == 'test':
                return False
            elif param == 'hls_prefer_native':
                return

# Generated at 2022-06-24 12:02:45.265004
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    can_download = HlsFD.can_download
    # These lines should be true.
    ok_lines = [
        '#EXTM3U',
        '#EXT-X-VERSION:3',
        '#EXT-X-MEDIA-SEQUENCE:0',
        '#EXT-X-TARGETDURATION:8',
        '#EXTINF:6.640,{}',
        '#EXT-X-KEY:METHOD=NONE',
        'mp4:a.mp4',
        '#EXT-X-ENDLIST',
        '#EXTINF:6.640,',
        'https://example.com/a.mp4',
    ]
    # These lines should be false.

# Generated at 2022-06-24 12:02:46.205563
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert (HlsFD.__doc__ is not None)