

# Generated at 2022-06-24 11:52:50.955837
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..extractor.generic import GenericIE

    fake_info_dict = {
        'url': get_test_data('test.m3u8'),
    }
    fake_info_dict['http_headers'] = {
        'Referer': get_test_data('test.m3u8')
    }

    hlsfd = HlsFD(None, {'test': True})
    hlsfd.to_screen = lambda *args: None
    hlsfd.real_download(GenericIE._make_result(fake_info_dict)['filename'], fake_info_dict)

# Generated at 2022-06-24 11:53:02.089155
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class dummy_info_dict:
        def __init__(self, url, is_live=False):
            self.url = url
            self.is_live = is_live

    class dummy_ydl:
        def __init__(self):
            self.params = {}

        def to_screen(self, msg, **kwargs):
            pass

        def report_error(self, msg, *args, **kwargs):
            pass

        def urlopen(self, *args, **kwargs):
            return self

        def read(self, *args, **kwargs):
            return self

        def geturl(self):
            return self.url

    class dummy_HlsFD:
        def __init__(self):
            self.ydl = dummy_ydl()


# Generated at 2022-06-24 11:53:10.325925
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import YoutubeIE


# Generated at 2022-06-24 11:53:21.453784
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def assert_can_download_result(manifest_content, is_live, extra_param_to_segment_url, _decryption_key_url, exp_result):
        info = {
            'url': 'http://example.com',
            'is_live': is_live,
            'extra_param_to_segment_url': extra_param_to_segment_url,
            '_decryption_key_url': _decryption_key_url,
        }
        assert HlsFD.can_download(manifest_content, info) == exp_result

    from .fragment import FragmentFD
    # basic usage: hlsnative should support the stream
    assert_can_download_result('#EXTM3U', False, None, None, True)

    # live stream: hlsnative should not support

# Generated at 2022-06-24 11:53:29.374839
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.generic import MatrixIE
    from ..utils import read_batch_urls

    ie = MatrixIE()
    ie.params = {
        'noprogress': True,
        'format': 'bestvideo',
        'test': True,
    }

    for video_id, video_url in read_batch_urls('matrix', ['url', 'id']):
        if video_id == '7370':
            continue
        try:
            info = MatrixIE._real_extract(ie, {
                'url': video_url,
                'ie_key': 'Matrix',
            })
        except Exception:
            pass
        else:
            HlsFD(ie.ydl, ie.params).real_download(None, info)

# Generated at 2022-06-24 11:53:40.564518
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert not HlsFD.can_download(
        '#EXTM3U\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=828000,RESOLUTION=640x360\n', {})
    assert HlsFD.can_download(
        '#EXTM3U\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=828000,RESOLUTION=640x360\n'
        'media.m3u8\n', {})

# Generated at 2022-06-24 11:53:47.326066
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(
        {'format': '5'},
        {'params': {'noprogress': True}, 'outtmpl': '%(id)s%(ext)s'}
    ).real_download(
        'a',
        {'url': 'https://manifest_url', 'http_headers': {'User-Agent': 'test'}}
    )

# Generated at 2022-06-24 11:53:49.075306
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        HlsFD("http://a.com", {})
        return False
    except:
        return True

# Generated at 2022-06-24 11:53:57.840663
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import sys
    import tempfile
    import shutil
    import fnmatch
    import difflib
    import subprocess
    import youtube_dl
    temp_dir = tempfile.mkdtemp()
    test_file_name = os.path.join(temp_dir, 'm3u8_video.mp4')
    test_file_name_w_frag_ext = os.path.join(temp_dir, 'm3u8_video_frag_%d.ts')
    ydl_opts = {'outtmpl': test_file_name, 'fragment_retries': 0, 'skip_unavailable_fragments': False, 'test': True}

# Generated at 2022-06-24 11:54:08.308537
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .extractor import gen_extractors

    def check(hlstest, ext=HlsFD, supp=True):
        for ie in gen_extractors():
            if ie.IE_NAME == ext.FD_NAME:
                ext = ie
                break
        manifest = hlstest.get('manifest')
        if manifest is None:
            manifest = hlstest['url'] if hlstest.get('m3u8') else ''
        ie_result = ext.suitable(manifest)
        test_result = ext.can_download(manifest, hlstest)
        assert test_result == ie_result == supp


# Generated at 2022-06-24 11:54:19.760072
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:54:32.757651
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from .__main__ import FakeYDL

    manifest_url = 'http://example.com/manifest'
    class FakeInfoDict(object):
        def __init__(self, url, is_live, extra_param_to_segment_url, _decryption_key_url):
            self.url = url
            self.is_live = is_live
            self.extra_param_to_segment_url = extra_param_to_segment_url
            self._decryption_key_url = _decryption_key_url


# Generated at 2022-06-24 11:54:43.753927
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download(
        '#EXTM3U\n#EXT-X-PLAYLIST-TYPE:VOD\n\n#EXTINF:10,\nvideo.ts\n\n', {}
    ) is True
    assert HlsFD.can_download(
        '#EXTM3U\n#EXT-X-PLAYLIST-TYPE:VOD\n\n#EXTINF:10,\nvideo.ts\n\n',
        {'extra_param_to_segment_url': 'foo=bar', '_decryption_key_url': 'https://example.com/key.bin'}
    ) is False

# Generated at 2022-06-24 11:54:52.276680
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import get_testdata_files_path
    from ..extractor.common import InfoExtractor
    from ..compat import compat_urllib_request, compat_urllib_parse
    from ..downloader import YoutubeDL

    class HlsFDExtractor(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(HlsFDExtractor, self).__init__(*args, **kwargs)
            self._player_params = None

        def _download_webpage(self, *args, **kwargs):
            data_file_path = get_testdata_files_path()
            page_url = args[0]
            page_url = page_url.replace('https://', 'http://')

# Generated at 2022-06-24 11:54:59.143403
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import json
    import os
    import sys

    # Add tests/pycryptodome_data/ to sys.path
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "pycryptodome_data"))

    from pycryptodome_test_data import hls_manifests, hls_cant_download_manifests, hls_download_info_dicts

    for hls_manifest in hls_manifests:
        for hls_download_info_dict in hls_download_info_dicts:
            assert HlsFD.can_download(hls_manifest, hls_download_info_dict)


# Generated at 2022-06-24 11:55:07.625157
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXTINF:10,\nhttp://f.com/a.ts\n#EXT-X-KEY:METHOD=NONE\n', {'is_live': False})
    assert not HlsFD.can_download('#EXTM3U\n#EXTINF:10,\nhttp://f.com/a.ts\n#EXT-X-KEY:METHOD=AES-128\n', {'is_live': False})
    assert not HlsFD.can_download('#EXTM3U\n#EXTINF:10,\nhttp://f.com/a.ts\n', {'is_live': True})

# Generated at 2022-06-24 11:55:20.213414
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import sys
    from ..utils import FakeYDL
    from ..downloader import Downloader
    downloader = Downloader(FakeYDL())
    sys.modules['pycryptodomex'] = type('pycryptodomex', (), {'Crypto': AES})

    class MyTestCase(unittest.TestCase):
        """
        A test case for method real_download of class HlsFD.
        """
        def test_hlsnative_real_download(self):
            #Given
            info_dict = {
                'id': 'test_id',
                'url': 'test_url',
                'http_headers': {},
                'is_live': False
            }

# Generated at 2022-06-24 11:55:32.649138
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors

    def _get_single_result(query, expected_result):
        results = []
        for ie in gen_extractors():
            res = ie.suitable(query)
            if res is not None:
                results.append((ie, res))
        if len(results) != 1:
            raise ValueError('Unexpected number of results')
        assert results[0][0].IE_NAME == expected_result
        return results[0][0]

    url = 'http://hls-geo.daserste.de/i/videoportal/Film/c_620000/622873/format,516713,516715,516714,516716,516717,.mp4.csmil/master.m3u8'
    # [hls

# Generated at 2022-06-24 11:55:45.848304
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class YDL:
        def __init__(self):
            self.params = {}
    class DummyIE:
        def __init__(self, ydl):
            self.ydl = ydl
            self.params = {}

    # test skip_unavailable_fragments
    ydl = YDL()
    ydl.params = {'skip_unavailable_fragments': True}
    fd = FFmpegFD(ydl, {})
    ie = DummyIE(ydl)
    info = {'skip_unavailable_fragments': False}
    assert not fd.can_download(ie, info)
    info = {'skip_unavailable_fragments': True}
    assert fd.can_download(ie, info)

    # test skip_unavailable_fragments with live stream

# Generated at 2022-06-24 11:55:52.904033
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import pytest
    from .external import FFmpegFD

    def is_available():
        try:
            from Crypto.Cipher import AES
            return True
        except ImportError:
            return False
    pytest.importorskip('Crypto')


# Generated at 2022-06-24 11:55:59.731714
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_dict = {
        'url': 'http://test.com:8080/playlist.m3u8?query=%26',
        'http_headers': {},
        '_decryption_key_url': 'http://test.com:8080/test.key',
    }
    HlsFD.real_download('test', test_dict)
    return True


# Generated at 2022-06-24 11:56:10.875342
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import subprocess
    from ..downloader import YoutubeDL
    def run_test(args):
        sys.stdout.write('Testing HlsFD.real_download: %s\n' % args)
        sys.stdout.flush()
        cmd = ('%s -q -f hlsnative -o - --no-warnings --hls-prefer-native --hls-segment-size 1 '
               '--hls-start-offset 0 --no-resize-buffer --hls-live-edge 1  --hls-use-mpegts '
               'https://www.youtube.com/watch?v=5JC5jSIsH0M hls://%s')
        cmd = cmd % (
            sys.executable, ' '.join(args))

        p = subprocess.P

# Generated at 2022-06-24 11:56:23.092956
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .youtube import YoutubeFD
    from .extractor import get_info_extractor, YoutubeIE
    from .downloader import FileDownloader
    from .common import InfoExtractor
    from .options import Options
    from .extractor import gen_extractors

    opts = Options()
    opts.username = "username"
    opts.password = "password"
    opts.usenetrc = False

    def run_test(url, result):
        ie = get_info_extractor(UrlFD().suitable(url), Downloader=FileDownloader(opts=opts))
        info = ie.extract(url)
        assert info['protocol'] == result

    run_test("http://youtube.com/watch?v=BaW_jenozKc", YoutubeIE.ie_key())
    run_test

# Generated at 2022-06-24 11:56:35.229896
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    new_gen_extractors = gen_extractors()
    ext = None
    for e in new_gen_extractors:
        if e.IE_NAME == 'hlsnative':
            ext = e
            break
    assert ext is not None, "Couldn't find the 'hlsnative' extractor"


# Generated at 2022-06-24 11:56:43.783836
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:56:52.741262
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    info_dict = {}
    manifest = ''
    assert HlsFD.can_download(manifest, info_dict), 'HLS manifest should be downloadable'

    manifest_with_unsupported_feature = '#EXT-X-KEY:METHOD=SAMPLE-AES'
    assert not HlsFD.can_download(manifest_with_unsupported_feature, info_dict), ('HLS manifest with unsupported feature should not be downloadable')

    manifest_with_supported_aes128_encryption = '#EXT-X-KEY:METHOD=AES-128'
    assert HlsFD.can_download(manifest_with_supported_aes128_encryption, info_dict), ('HLS manifest with supported aes128 encryption should be downloadable')


# Generated at 2022-06-24 11:56:54.327811
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download("", {"url": ""})

# Generated at 2022-06-24 11:57:05.627572
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """Test for HlsFD constructor"""
    from .extractor import YoutubeDL
    from .http import HttpFD

    # Test with nothing
    assert not isinstance(HlsFD(YoutubeDL({}), {}), HlsFD)

    # Test with only one of the requirements
    assert not isinstance(HlsFD(YoutubeDL({}), {'url': 'http://test.com'}), HlsFD)

    # Test with only another requirement
    assert not isinstance(HlsFD(YoutubeDL({}), {'http_headers': {}}), HlsFD)

    # Test with all requirements
    assert isinstance(HlsFD(YoutubeDL({}), {'url': 'http://test.com', 'http_headers': {}}), HttpFD)

# Generated at 2022-06-24 11:57:17.427041
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .extractor import gen_extractors

    test_file_path = get_test_data('hlsfd_test_file.m3u8')
    test_file_url = u'file://' + test_file_path
    test_file = open(test_file_path, 'rb')
    test_data = test_file.read().decode('utf-8', 'ignore')
    test_file.close()
    test_info_dict = {
        'url': test_file_url,
        'protocol': 'hls_native',
        '_decryption_key_url': 'https://foo/bar',
        'http_headers': {'foo': 'bar'},
    }

# Generated at 2022-06-24 11:57:28.958795
# Unit test for constructor of class HlsFD
def test_HlsFD():
    url = 'https://www.example.com/vod.m3u8'

# Generated at 2022-06-24 11:57:40.726601
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import YoutubeDL
    ydl = YoutubeDL({'hls_use_mpegts': True, 'nooverwrites': True})
    ydl.params['test'] = True
    ydl.add_default_info_extractors()
    class MockURLopener:
        def __init__(self, ctx):
            self.ctx = ctx
        def open(self, url):
            self.url = url
            return self
        def read(self):
            if not self.url.endswith('master.m3u8'):
                self.ctx['fail'] = 'URL not ending on master.m3u8'
                raise Exception('Fail')

# Generated at 2022-06-24 11:57:52.008720
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert can_decrypt_frag == HlsFD.can_download("""
#EXTM3U
#EXT-X-VERSION:3
#EXT-X-MEDIA-SEQUENCE:0
#EXT-X-ALLOW-CACHE:YES
#EXT-X-KEY:METHOD=NONE,URI=""
#EXT-X-TARGETDURATION:10
#EXTINF:10,
segment1.ts
#EXTINF:10,
segment2.ts
#EXTINF:10,
segment3.ts
""", {})


# Generated at 2022-06-24 11:58:00.280950
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..utils import _parse_m3u8_attributes
    from ..extractor.twitch import TwitchIE
    assert not HlsFD.can_download('', {})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'is_live': True})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'extra_param_to_segment_url': ''})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'_decryption_key_url': ''})

# Generated at 2022-06-24 11:58:10.927634
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():

    class FakeYDL:

        def urlopen(self, url):
            class FakeURL:
                def __init__(self, url):
                    self.url = url
                def read(self):
                    if re.search(r'/aes128\.', self.url):
                        return b'key'
                    else:
                        return b''
            return FakeURL(url)

    class FakeInfoDict:

        def get(self, key):
            if key == 'is_live':
                return self.is_live
            elif key == '_decryption_key_url':
                return self.decryption_url
            else:
                return None

    class FakeFragmentFD:
        def _progress_hooks(self):
            yield None


# Generated at 2022-06-24 11:58:21.597334
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .extractor.InfoExtractor import InfoExtractor
    from .extractor.youtube import YoutubeIE
    YoutubeIE._extract_info = lambda *args: ({}, False, False)
    info_dict = {'url': 'foo', 'http_headers': {}}

    # Test with no errors
    hlsfd = HlsFD(YoutubeIE, info_dict, {}, None)
    assert hlsfd.extra_param_to_segment_url is None
    assert hlsfd._decryption_key_url is None

    # Test with extra_param_to_segment_url passed
    HlsFD.can_download = lambda *args: True
    info_dict['extra_param_to_segment_url'] = 'foo'

# Generated at 2022-06-24 11:58:24.137220
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    pass


if __name__ == '__main__':
    test_HlsFD_can_download()

# Generated at 2022-06-24 11:58:25.249205
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    pass

# Generated at 2022-06-24 11:58:26.550841
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, {})


# Generated at 2022-06-24 11:58:37.360769
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from io import BytesIO
    from collections import namedtuple
    from urllib.parse import parse_qs
    from .downloader import YoutubeDL
    from .external import FFmpegFD

    class FakeHook:

        def __init__(self):
            self.message = ''

        def __call__(self, d):
            if d['status'] == 'finished':
                self.message += 'finished'

    FakeFD = namedtuple('FakeFD', ['real_download'])


# Generated at 2022-06-24 11:58:38.167018
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD

# Generated at 2022-06-24 11:58:39.890288
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # No test of this method is possible because it depends on setup of
    # I/O streams in TestYoutubeDL.
    pass

# Generated at 2022-06-24 11:58:47.243029
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from . import YoutubeDL
    from .extractor.common import InfoExtractor
    from .utils import get_cachedir
    from .cache import disk_cache

    class FakeInfoExtractor(InfoExtractor):
        def _real_initialize(self):
            pass

        def _real_extract(self, url):
            pass

    ie = FakeInfoExtractor({})
    ie.ydl = YoutubeDL({'cachedir': get_cachedir()})
    ie_result = ie.url_result('hls://%2F%2Fexample.com')
    ie_result.add_irrelevant_info_keys()
    ie_result['url'] = 'https://example.com'
    ie_result['_type'] = 'hls'

# Generated at 2022-06-24 11:58:58.463820
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..downloader.http import HttpFD

    # Test for:
    # - HLS version 4 protocol
    # - AES-128 encryption method
    # - encryption key is not specified in master playlist
    # - media playlists do not contain #EXT-X-MAP tag
    # - media playlists contain #EXT-X-BYTERANGE tag
    # - media playlists do not point to media initialization segments
    # - media initialization segments do not contain 'moof' boxes
    # - media segments do not contain 'sidx' boxes

# Generated at 2022-06-24 11:59:06.549792
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .youtube import YoutubeFD
    yd = YoutubeFD()
    yd.params['hls_use_mpegts'] = True
    print('%s: can_download: %s' % (HlsFD.__name__, HlsFD.can_download(
        '#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:2.833,\nmedia-00001.ts\n#EXT-X-ENDLIST\n',
        {'is_live': False})))

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 11:59:08.274663
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hf = HlsFD(None, None)
    assert hf.can_download(None, None)

# Generated at 2022-06-24 11:59:19.481216
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import InfoExtractor
    from .fragment import FragmentFD
    from .external import FFmpegFD

    FD_NAME = 'hlsnative'
    manifest_url = 'https://manifest.url/url.m3u8'
    info_dict = {
        'url': manifest_url,
        'ext': 'mp4',
        'format_id': '0',
        'duration': 10.0,
    }

    def mock_urlopen(url, *args, **kwargs):
        class Value(object):
            def __init__(self, url):
                self.url = url

        return Value(url)

    def mock_pre_download(*args, **kwargs):
        pass

    def mock_post_download(*args, **kwargs):
        pass


# Generated at 2022-06-24 11:59:27.191586
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Tests for feature: #EXT-X-KEY:METHOD=AES-128 (encrypted streams)
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'is_live': False}) == False
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'is_live': True}) == False
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'is_live': False, '_decryption_key_url': 'some_key_url'}) == False

# Generated at 2022-06-24 11:59:33.812001
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import argparse
    import sys
    import utils

    # Create a command line parser and parse the command line arguments
    parser = argparse.ArgumentParser(description='test_HlsFD_real_download')
    parser.add_argument('url', help='URL to test')
    parser.add_argument('-n', '--num-fragments', type=int, default=1,
                        help='number of fragments to download')
    parser.add_argument('-f', '--fragment-index', type=int, default=1,
                        help='index of the first fragment to download')
    parser.add_argument('-r', '--redirect', action='store_true',
                        help='redirect to download URL')

    args = parser.parse_args()

    # Create the downloader, and load the HLS URL


# Generated at 2022-06-24 11:59:46.215854
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # this is a test to verify that the download of 1st fragment is successful

    # import required modules and create some short aliases
    import os
    import shutil
    import tempfile
    import unittest
    import youtube_dl.YoutubeDL as YDL
    from youtube_dl.downloader.http import HlsFD
    from youtube_dl.InfoExtractors import HlsIE

    class TestClass(unittest.TestCase):
        def setUp(self):
            self.ydl = YDL()

        def test_hlsfd_real_download(self):
            # Create a temporary directory
            temp_dir = tempfile.mkdtemp()
            # Create a temporary file
            (handle, temp_file) = tempfile.mkstemp(dir=temp_dir)
            os.close(handle)


# Generated at 2022-06-24 11:59:54.853185
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .http import HttpFD
    from ..extractor import YoutubeIE

    def ytdl_extract_info(ydl, url, download=False, ie_key=None, extra_info={}):
        ie = YoutubeIE(ydl)
        return ie.extract(url)

    HttpFD._real_extract = HttpFD.real_extract
    HttpFD.real_extract = ytdl_extract_info

    ydl = YoutubeDL(params={
        'youtube_include_dash_manifest': True,
        'quiet': True,
        'format': 'bestvideo+bestaudio',
    })
    ie = YoutubeIE(ydl)
    # Tests for video with HLS-only stream

# Generated at 2022-06-24 11:59:55.600101
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass


# Generated at 2022-06-24 12:00:07.343571
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    with pytest.raises(ValueError, match='pycrypto'):
        HlsFD.real_download(None, 'file.ts', {})

# Generated at 2022-06-24 12:00:16.893458
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    manifest = (
        '#EXTM3U\n'
        '#EXT-X-VERSION:3\n'
        '#EXT-X-TARGETDURATION:10\n'
        '#EXT-X-MEDIA-SEQUENCE:0\n'
        '#EXTINF:10.000,\n'
        'http://localhost/segment0.ts\n'
        '#EXT-X-ENDLIST\n'
    )

    class FakeInfoDict:
        pass

    info_dict = FakeInfoDict()
    info_dict.url = 'http://localhost/index.m3u8'
    info_dict.test = True

    class FakeYDL:
        def __init__(self):
            self.urlopen_calls = []


# Generated at 2022-06-24 12:00:25.347344
# Unit test for constructor of class HlsFD
def test_HlsFD():
    print('Testing HlsFD constructor')

    assert HlsFD.can_download('#EXTM3U\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=261126,RESOLUTION=320x180\nmedia.m3u8\n', {
        'protocol': 'm3u8_native',
        'url': '',
        'is_live': False,
        'extractor': 'hlsnative',
    })


# Generated at 2022-06-24 12:00:29.098550
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testcases_from_id, FakeYDL

    for test in get_testcases_from_id('hls-6538'):
        ydl = FakeYDL()
        assert HlsFD.real_download(test, ydl)

    return True

# Generated at 2022-06-24 12:00:40.235030
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # The test data was generated with the youtube-dl tool.
    test_data = [
        ('data/hls/1', False),
        ('data/hls/2', False),
        ('data/hls/3', True),
        ('data/hls/4', True),
        ('data/hls/5', False),
        ('data/hls/6', True),
        ('data/hls/7', True),
        ('data/hls/8', True),
        ('data/hls/9', True),
        ('data/hls/10', False),
        ('data/hls/11', True),
        ('data/hls/12', False),
    ]

    for filename, expected_result in test_data:
        with open(filename, 'r') as f:
            data = f

# Generated at 2022-06-24 12:00:48.892810
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .dashsegments import DASHSegmentsFD
    from .external import YoutubeDL
    manifest = []
    manifest.append('#EXTM3U\n' % {'method': 'NONE'})
    manifest.append('#EXT-X-TARGETDURATION:10\n')
    manifest.append('#EXT-X-VERSION:3\n')
    manifest.append('#EXT-X-PLAYLIST-TYPE:VOD\n')
    manifest.append('#EXT-X-MEDIA-SEQUENCE:0\n')
    manifest.append('#EXT-X-KEY:METHOD=%(method)s,URI="https://priv.example.com/key.php?r=52"\n' % {'method': 'NONE'})
    manifest.append('#EXTINF:10,\n')


# Generated at 2022-06-24 12:00:54.857297
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import pytest


# Generated at 2022-06-24 12:01:07.109762
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 12:01:15.596491
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    class TestHlsFD(HlsFD):
        def _prepare_url(self, info_dict, url):
            return 'https://example.com?%s' % url.split('/')[-1]
    
    hlsFD = TestHlsFD(None, {
        'test': True,
        'fragment_retries': 2,
        'skip_unavailable_fragments': False,
    })
    from .tests.mocks import MockYDL
    hlsFD.ydl = MockYDL()
    hlsFD.ydl.urlopen = lambda url: None

# Generated at 2022-06-24 12:01:16.758138
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass



# Generated at 2022-06-24 12:01:23.673961
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():

    manifest = ('''#EXTM3U
#EXT-X-VERSION:4
#EXT-X-PLAYLIST-TYPE:VOD
#EXT-X-MEDIA-SEQUENCE:0
#EXT-X-TARGETDURATION:6
#EXT-X-KEY:METHOD=AES-128,URI="http://test.uri",IV=0x0
#EXTINF:6.000,
#EXT-X-BYTERANGE:121090@0
frag.ts
#EXT-X-ENDLIST
''')
    info_dict = {'url': "http://test.uri/index.m3u8?extra=param"}

    assert HlsFD.can_download(manifest, info_dict)


# Generated at 2022-06-24 12:01:35.319211
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-24 12:01:42.724161
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert can_decrypt_frag

    hls_fd = HlsFD(py_ytdl(), {'restrictfilenames': False})

    assert hls_fd.FD_NAME == 'hlsnative'
    assert hls_fd._progress_hooks == []
    assert hls_fd.ydl is not None
    assert hls_fd.params is not None



# Generated at 2022-06-24 12:01:55.147259
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    from .utils import FakeYDL
    from .cmdline import _make_cmdline_url_desc
    from .extractor import _build_video_result

    class FakeDownloader:
        def __init__(self, extractor, video_id, video_url):
            self.ydl = FakeYDL()
            self.ydl.add_info_extractor(extractor)
            self.ydl.cache.remove(video_id)
            self.params = {}
            self.result = _build_video_result(video_id, video_url)
            self.result = _make_cmdline_url_desc(self.result)


# Generated at 2022-06-24 12:02:03.298243
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    info_dict = {
        'url': 'https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8',
    }
    filename = 'video.mp4'
    fd = HlsFD(None, None)
    if not fd.can_download(fd.ydl.urlopen(info_dict['url'], None, False).read(), info_dict):
        assert False, 'failed to look up m3u8 manifest'
    assert fd.real_download(filename, info_dict) is True

# Generated at 2022-06-24 12:02:13.776072
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from youtube_dl.utils import download_json_handle
    urls = [
        'https://www.youtube.com/watch?v=LKjf9r-pvcc',
        'https://www.youtube.com/watch?v=AQg2QoEFX28',
        'https://www.youtube.com/watch?v=C4I4sJjKgs4',
        'https://www.youtube.com/watch?v=0jHN0xeCRGo',
    ]
    for url in urls:
        video_info = download_json_handle(url, {'noplaylist': True, 'skip_download': True}, 'youtube')
        fd = HlsFD({'test': True, 'format': video_info['formats'][0]}, {})

# Generated at 2022-06-24 12:02:21.626312
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import common
    manifest_with_key_method_aes128 = b'#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\n#EXT-X-STREAM-INF:PROGRAM-ID=1\n'
    manifest_with_key_method_aes128_and_byterange = b'#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\n#EXT-X-BYTERANGE:123@456\n#EXT-X-STREAM-INF:PROGRAM-ID=1\n'
    manifest_without_key_method_aes128 = b'#EXTM3U\n#EXT-X-STREAM-INF:PROGRAM-ID=1\n'

    # No need for ffmpeg for unencrypted

# Generated at 2022-06-24 12:02:23.010974
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """
    Test HlsFD real_download method.
    """
    pass

# Generated at 2022-06-24 12:02:35.083829
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import HlsFD
    class dummy_info_dict:
        def __init__(self, is_live=False):
            self.is_live = is_live

# Generated at 2022-06-24 12:02:35.940194
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # NOT IMPLEMENTED
    pass

# Generated at 2022-06-24 12:02:43.574523
# Unit test for constructor of class HlsFD
def test_HlsFD():
    class YDL:
        def __init__(self):
            self.params = {
                'test': True,
            }
        def extract_info(self, x):
            return {
                'is_live': False,
                'url': x,
            }
        def report_error(self, x):
            print(x)
        def urlopen(self, x):
            class Object:
                def __init__(self, x):
                    self.url = x
                    self.headers = {'Content-Length': '0'}
                def read(self):
                    return b''
            return Object(x)

    ydl = YDL()
    fd = HlsFD(ydl, {})
    assert fd.can_download('', {'url': 'http://example.com'})
    assert f