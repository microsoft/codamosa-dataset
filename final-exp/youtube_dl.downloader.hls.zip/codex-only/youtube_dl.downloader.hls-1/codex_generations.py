

# Generated at 2022-06-24 11:52:54.125289
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.test.test_download import MockYDL
    import os

    ydl = MockYDL()
    ydl.add_info_extractor(None) # MockIE
    info_dict = {
        'url': 'https://example.com',
        'tr_url': 'https://example.com',
        'm3u8_id': '123456',
        'm3u8_formats': [
            {'width': 426, 'height': 240},
            {'width': 854, 'height': 480},
        ],
    }
    # First, test to make sure real_download will
    # return False on an unsupported stream
    info_dict['m3u8_formats'][0]['url'] = 'unsupported.m3u8'
    assert not HlsFD.real_

# Generated at 2022-06-24 11:53:04.616130
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download(
        """#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:5
#EXTINF:2.00000,
http://fragment_1
#EXTINF:2.00000,
http://fragment_2
#EXTINF:2.00000,
http://fragment_3
#EXTINF:1.00000,
http://fragment_4
#EXT-X-ENDLIST
""", {
            'url': 'http://manifest.m3u8',
            'title': 'title',
        }
    )


# Generated at 2022-06-24 11:53:14.604961
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .common import InfoExtractor
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .utils import ExtractorError
    from .compat import compat_urlparse

    ydl = YoutubeDL(params={
        'format': 'bestaudio/best',
        'nooverwrites': True,
        'outtmpl': '-',
        'test': True,
        'quiet': True,
        'simulate': True,
        'skip_download': True,
    })

    # unit test for: https://github.com/ytdl-org/youtube-dl/issues/26257
    # added on 2020-06-05

# Generated at 2022-06-24 11:53:20.221990
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    from .downloader import YoutubeDLHandler
    ydl = YoutubeDL(YoutubeDLHandler(), {'logger': None})
    ydl.process_ie_result({'_type': 'hls', 'url': 'https://example.com/', 'ext': 'mp4', 'title': 'test'}, download=True)

# Generated at 2022-06-24 11:53:28.730986
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    def is_ad_fragment_start(s):
        return (s.startswith('#ANVATO-SEGMENT-INFO') and 'type=ad' in s or s.startswith('#UPLYNK-SEGMENT') and s.endswith(',ad'))

    def is_ad_fragment_end(s):
        return (s.startswith('#ANVATO-SEGMENT-INFO') and 'type=master' in s or s.startswith('#UPLYNK-SEGMENT') and s.endswith(',segment'))

# Generated at 2022-06-24 11:53:35.081333
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """ Test HlsFD's real_download unit test """
    RETRIES = 3  # Retries to perform

# Generated at 2022-06-24 11:53:43.707479
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-STREAM-INF:BANDWIDTH=458000\n'
        'http://example.com/stream1000.m3u8\n'
        '#EXT-X-STREAM-INF:BANDWIDTH=458000\n'
        'http://example.com/stream2000.m3u8\n'
        '#EXT-X-STREAM-INF:BANDWIDTH=506000\n'
        'http://example.com/stream3000.m3u8\n',
        {'id': 'hlsnative_test'})


# Generated at 2022-06-24 11:53:54.870606
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    import unittest
    sys.path.append('youtube_dl')
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import prepend_extension
    from youtube_dl.extractor.common import InfoExtractor
    import youtube_dl.YoutubeDL

    ydl = YoutubeDL(
        {'writedescription': False, 'writeinfojson': False, 'writethumbnail': False, 'writeautomaticsub': False,
         'simulate': True})

    ie = InfoExtractor(ydl, 'https://www.youtube.com/watch?v=5Id6vdEg1yw')
    success, ie_result = ie.extract(force_generic_extractor=True)
    assert success
    ie_result.pop('formats')

# Generated at 2022-06-24 11:54:06.715925
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download("", {'url': ""}) == False
    assert HlsFD.can_download("a", {'url': "a"}) == False
    assert HlsFD.can_download("#", {'url': "#"}) == False
    assert HlsFD.can_download("##", {'url': "##"}) == False
    assert HlsFD.can_download("##a", {'url': "##a"}) == False
    assert HlsFD.can_download("a##", {'url': "a##"}) == False
    assert HlsFD.can_download("#EXT-X-KEY:METHOD=AES-128", {'url': "#EXT-X-KEY:METHOD=AES-128", '_decryption_key_url': 'pycrypto_not_found'})

# Generated at 2022-06-24 11:54:18.567331
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest

# Generated at 2022-06-24 11:54:31.661191
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.hls import HlsIE
    from .fake_filesystem_unittest import TestCase

    # The test for playlists composed of byte ranges of media files requires byte range support
    # which is not included in the fake file system.
    # Thus the test will be incomplete
    class FakeInfoDict(dict):
        """ A type of dictionary that has is_live property. """
        def __init__(self, *args, **kwargs):
            super(FakeInfoDict, self).__init__(*args, **kwargs)
            self.is_live = False

    class HlsFDTest(TestCase):
        def setUp(self):
            self.ie = InfoExtractor(HlsIE.ie_key())
            self.ie._downloader = object()

# Generated at 2022-06-24 11:54:42.969091
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Test dummy initializations
    HlsFD(None, {})
    HlsFD(None, {'hls_use_mpegts': False})
    HlsFD(None, {'hls_use_mpegts': True})

    # Test real initializations
    from ..extractor.generic import GenericIE
    genie = GenericIE()
    genie.url = 'https://example.com/'
    genie.params = {}
    genie.ydl = None
    HlsFD(genie, {})
    HlsFD(genie, {'hls_use_mpegts': False})
    HlsFD(genie, {'hls_use_mpegts': True})

    # Can_download tests
    import pytest
    with pytest.raises(ValueError):
        HlsFD.can_

# Generated at 2022-06-24 11:54:49.175304
# Unit test for constructor of class HlsFD
def test_HlsFD():
    url = 'https://foo.bar/playlist.m3u8'
    # get_info() will call HlsFD.can_download() which raises AssertionError
    # if no file_obj is passed to URLOpenProcessor constructor
    with open(__file__, 'rb') as file_obj:
        get_info(url, file_obj=file_obj)
        # Does not crash means everything works as expected

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 11:55:00.158622
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import get_info_extractor

    def mock_YDL(url, extractor, *args, **kwargs):
        info_dict = get_info_extractor(extractor)(YDL(), {'url': url})
        return info_dict.news_api_response

    class YDL:
        def __init__(self):
            self.urlopen = mock_YDL


# Generated at 2022-06-24 11:55:08.409270
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:55:17.087280
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_handler
    from .extractor import YoutubeIE
    from .downloader import YoutubeDL

    # Download the m3u8 playlist and the first fragment.
    ydl = YoutubeDL(params={'hls_prefer_native': True, 'test': True})
    with get_test_handler():
        YoutubeIE._real_initialize(ydl)
        ydl.download(['https://www.youtube.com/watch?v=pGR9XNbuV7g'])

# Generated at 2022-06-24 11:55:26.101122
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import json
    def _inner(manifest, is_live, extra_param_to_segment_url, _decryption_key_url,
               expect_success):
        info_dict = {
            'url': 'https://example.com/manifest.m3u8',
            'is_live': is_live,
            'extra_param_to_segment_url': extra_param_to_segment_url,
            '_decryption_key_url': _decryption_key_url,
        }
        assert HlsFD.can_download(manifest, info_dict) is expect_success


# Generated at 2022-06-24 11:55:34.947507
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test_utils import FakeYDL
    from .extractor.twitch import Twitch

    URL = 'https://www.twitch.tv/videos/316656766'
    ydl = FakeYDL()
    extractor = Twitch(ydl, {})
    result = extractor.real_extract(extractor._match_id(URL))
    info_dict = dict(result.get('formats')[0])
    info_dict.update(result)
    hlsfd = HlsFD(ydl, {})
    hlsfd.real_download('/dev/null', info_dict)

# Generated at 2022-06-24 11:55:47.773973
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..utils import determine_ext

    def test_real_download(filename, info_dict):
        '''
        This function is called previously by the unit test
        and all params are available in the global scope
        '''
        extractor = InfoExtractor(YoutubeDL())
        fd = HlsFD(extractor.ydl, extractor.params)
        return fd.real_download(filename, info_dict)

    # Short test
    def run_test(id, start_sequence, expected_nb, expected_ext,
                 expected_initial_data, expected_final_data):
        filename = os.path.join(os.path.dirname(__file__), id + '.m3u8')

# Generated at 2022-06-24 11:56:00.105496
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():

    # Initialize HlsFD object
    hls_fd = HlsFD(None, {})

    # Test 1: unencrypted
    manifest_1 = "#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXTINF:10\nhttps://example.com/segment_1_0.ts\n#EXTINF:10\nhttps://example.com/segment_1_1.ts"
    assert hls_fd.can_download(manifest_1, {})

    # Test 2: AES-128 encryption

# Generated at 2022-06-24 11:56:05.800322
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ydl_handler = YoutubeDLHandler()
    params = {
        'fragment_retries': 10,
        'skip_unavailable_fragments': False,
        'continuedl': True
    }
    hls_handler = HlsFD(ydl_handler, params)
    assert hls_handler.params == params


# Generated at 2022-06-24 11:56:16.346726
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from io import BytesIO
    from .http import HttpFD
    from .utils import DeterministicFD
    from .external import FFmpegFD
    from ..utils import encode_data_uri
    from ..extractor import get_info_extractor
    from ..compat import compat_urlparse
    from ..extractor.common import InfoExtractor
    from ..downloader.postprocessor import PostProcessor

    class FakeInfoDict(dict):
        def __init__(self):
            super(FakeInfoDict, self).__init__()
            self['http_headers'] = {}

    content_frag_extractor_info_dict = {}


# Generated at 2022-06-24 11:56:27.596392
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from .common import FakeYDL
    ydl = FakeYDL()

    extractor = InfoExtractor(ydl=ydl, ie_key='hlsnative')
    i = {'is_live': False}


# Generated at 2022-06-24 11:56:38.671298
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..utils import FakeYDL
    from .fragment import FragmentFD
    import sys

    def check_can_download(case, manifest, info_dict=None, expected=True):
        if info_dict is None:
            info_dict = {}
        ie = InfoExtractor(FakeYDL(), {'skip_download': True})
        url = 'https://fake.url/playlist.m3u8'
        ie.add_info_extractor(lambda i, f: f.set_template(None, i, url))

# Generated at 2022-06-24 11:56:40.857354
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Instantiate object
    HlsFD('url')


# Generated at 2022-06-24 11:56:51.278149
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """
    Make sure that HlsFD.real_download doesn't raise any exceptions
    """
    def _urlopen_side_effect(request, redirect=True):
        class FakeResponse(object):
            def __init__(self, url, content, code=None):
                self.url = url
                self.content = content
                self.code = code


# Generated at 2022-06-24 11:57:03.907223
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from .test_utils import FakeYDL

    # Test extracting initial fragment
    ydl = FakeYDL()
    ie = InfoExtractor('test', ydl)

    # constant input data
    fd = HlsFD(ydl, {'test': True})

# Generated at 2022-06-24 11:57:09.595303
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    print('Running unit test ' + __name__)

    import pytest
    def test_can_download(hls_m3u8, expected):
        # The test hls_m3u8 manifests are in the following format:
        #   1st line: Test name
        #   2nd line: Expected value for method can_download
        #   3rd line and so on: content of hls m3u8 manifest
        import re
        hls_m3u8 = re.split(r'\n', hls_m3u8)
        assert hls_m3u8[0].startswith('Test ')
        assert hls_m3u8[1] == '  ' + expected
        hls_m3u8 = '\n'.join(hls_m3u8[2:])


# Generated at 2022-06-24 11:57:19.343510
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import YoutubeIE

    class FakeYDL():
        def __init__(self):
            self.params = {}
            self.ie_key = 'Youtube'
            self.ies = []

        def add_info_extractor(self, ie):
            self.ies.append(ie)

    def get_info_extractor(ie_key):
        return next((ie for ie in ydl.ies if ie.ie_key() == ie_key), None)

    ydl = FakeYDL()
    YoutubeIE.register_options(ydl)

    ie = get_info_extractor('Youtube')

# Generated at 2022-06-24 11:57:30.123262
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .dash import DashSegmentsFD
    from .fragment import FragmentFD
    from .external import FFmpegFD, FFmpegPostProcessor
    import sys
    import copy

    original_argv = copy.copy(sys.argv)

# Generated at 2022-06-24 11:57:41.782696
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import platform
    system = platform.system()
    if system == 'Windows':
        # Windows doesn't have native AES encryption
        return
    if system == 'Linux':
        if platform.architecture()[0] == '32bit':
            # Crypto.Cipher.AES crashes on x86 with the default key_size
            return
    from .common import FakeYDL 
    from ..extractor import get_info_extractor
    ydl = FakeYDL()
    ie = get_info_extractor('hls')
    info = ie._real_extract(
        'http://devimages.apple.com/iphone/samples/bipbop/gear1/prog_index.m3u8')

# Generated at 2022-06-24 11:57:53.713248
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-24 11:57:56.763714
# Unit test for constructor of class HlsFD
def test_HlsFD():
    class DummyYDL():
        def __init__(self):
            self.params = {}
    ydl = DummyYDL()
    hlsfd = HlsFD(ydl, {'noprogress': 'True'})


if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-24 11:58:08.606106
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .utils import BuildCmd

    query = '?ratebypass=yes&signature=549F6822A4F4F4A440E3BD8B3A9B3459C36F2423.A12A8E59A71F4B4A4A98F3F8A3B9A04A1AB11C18'

# Generated at 2022-06-24 11:58:19.049801
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def test_can_download(data, expected):
        actual = HlsFD.can_download(data, {})
        assert actual == expected, '%r should be %r' % (actual, expected)

    test_can_download('', True)
    test_can_download('#EXT-X-KEY:METHOD=NONE', True)
    test_can_download('#EXT-X-KEY:METHOD=SAMPLE-AES-CENC', False)
    test_can_download('#EXT-X-KEY:METHOD=AES-128', True)
    test_can_download('#EXT-X-KEY:METHOD=AES-128', True)
    test_can_download('#EXT-X-BYTERANGE', False)

# Generated at 2022-06-24 11:58:23.300022
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Method can_download is static, it is not dependent of an object
    hls_fd = HlsFD(None, None)
    # Live
    info_dict = {'is_live': True}
    # Live_MSE

# Generated at 2022-06-24 11:58:35.210639
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U', {})
    assert HlsFD.can_download(
        '#EXTM3U\n#EXT-X-KEY:METHOD=NONE', {})
    assert not HlsFD.can_download(
        '#EXTM3U\n#EXT-X-KEY:METHOD=foo', {})
    assert HlsFD.can_download(
        '#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {})
    assert HlsFD.can_download(
        '#EXTM3U\n#EXT-X-KEY:METHOD=AES-128',
        {'_decryption_key_url': 'http://foo.bar/crypt.key'})
    if can_decrypt_frag:
        assert H

# Generated at 2022-06-24 11:58:44.390059
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Used in tests
    import sys

    def _can_download(url, expected, test_id):
        instance = HlsFD(None, {'geo_bypass': True, 'test': True})

        class YDummy():
            def urlopen(self, url):
                class URLHDummy():
                    def read(self):
                        with open(url, 'r') as f:
                            return f.read().encode('utf-8')

                return URLHDummy()

        instance.ydl = YDummy()

        class InfoDictDummy():
            def __init__(self, test_id):
                self.url = url
                self.test = 'http://example.com/test%d' % test_id
                self.extra_param_to_segment_url = ''
                self._decryption

# Generated at 2022-06-24 11:58:48.329925
# Unit test for constructor of class HlsFD
def test_HlsFD():
    class YtdlFileDownloader():

        def urlopen(url):
            # return read() method of an object
            def read():
                return b'key'
            return read
    hlsFD = HlsFD(YtdlFileDownloader(), {})
    hlsFD.real_download(None, {'_decryption_key_url': 'url'})

# Generated at 2022-06-24 11:58:49.517496
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD is not None

# Generated at 2022-06-24 11:58:59.864574
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # encrypted stream
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {})
    # encrypted stream with key and IV specified
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128,URI="https://example.com/key.bin",IV=0x00000000000000000000000000000000', {})
    # encrypted stream with key specified but not IV
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128,URI="https://example.com/key.bin"', {})
    # live stream. Note that this is not always valid since segments may not be appended to media playlist in all cases.

# Generated at 2022-06-24 11:59:10.860226
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import HEADRequestHandler, MockServerThread
    from .fake_filesystem_unittest import TestCase
    import os
    import sys
    import socket
    import tempfile
    import time

    class FakeYtdlUrlopen(object):
        def __init__(self):
            self.content = None


# Generated at 2022-06-24 11:59:21.576528
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Sample m3u8 manifests used below are of a real YouTube video or a real Twitch video
    # and are modified to contain the additional features listed in the
    # UNSUPPORTED_FEATURES list of the can_download method of class HlsFD
    # above.

    live = {'is_live': True}
    non_live = {'is_live': False}
    no_crypto_ext_reqs = {'extractor_key': 'youtube-nocookie'}
    no_crypto_rest_reqs = {}


# Generated at 2022-06-24 11:59:34.992181
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import youtube_dl.downloader.http
    m3u8_data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'tests', 'm3u8_data')
    manifest_files = ['master.m3u8', 'media.m3u8']
    manifest_data = []
    for manifest_file in manifest_files:
        with open(os.path.join(m3u8_data_path, manifest_file), 'r') as f:
            manifest_data.append(f.read())

    # Can download if method NONE or AES-128
    ydl = youtube_dl.YoutubeDL({'quiet': True, 'simulate': True})

# Generated at 2022-06-24 11:59:42.322861
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    man_url = 'http://www.example.com/master.m3u8'
    manifest = r'''#EXTM3U
#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID="subs",NAME="English",DEFAULT=YES,URI="subtitles/eng/prog_index.m3u8"
    '''

    from ..extractor.youtube import YoutubeIE
    info_dict = {
        'id': '123_456',
        'url': 'http://www.example.com/123_456.m3u8',
        'extractor': YoutubeIE.ie_key(),
        'player_url': 'http://www.example.com/player.js',
        'title': 'test',
    }
    hfd = HlsFD(None, {})
    assert h

# Generated at 2022-06-24 11:59:44.871976
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import common as test_common
    test_common.test_HlsFD_real_download(HlsFD, 'hlsnative')

# Generated at 2022-06-24 11:59:58.473679
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .external import F4mFD
    from .external import ExternalFD
    from .fragment import FragmentFD

    manifest_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'manifests')

# Generated at 2022-06-24 12:00:08.889095
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_manifest = '''
    #EXTM3U
    #EXT-X-VERSION:3
    #EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=640000
    low/video_only.m3u8
    #EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=1200000
    mid/video_only.m3u8
    #EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=3000000
    hi/video_only.m3u8
    #EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=640000
    low/audio_only.m3u8
    '''
    ffmpeg_man

# Generated at 2022-06-24 12:00:17.109625
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    class MockHlsFD(HlsFD):
        def __init__(self, *args, **kwargs):
            self.dl_content = ''
            self.fragment_index = 0

        def _prepare_url(self, *args, **kwargs):
            return args[0].get('url')

        def _download_fragment(self, ctx, frag_url, *args, **kwargs):
            self.dl_content += 'a' * 1024 * 1024 * 1  # 1 MB
            return (True, self.dl_content.encode('utf-8'))

        def _prepare_and_start_frag_download(self, *args, **kwargs):
            self.dl_content += 'b' * 1024 * 1024 * 1  # 1 MB


# Generated at 2022-06-24 12:00:18.020799
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, {})

# Generated at 2022-06-24 12:00:27.976495
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def can_download(man, is_live):
        return HlsFD.can_download(
            man,
            {'url': None, 'http_headers': {}, 'is_live': is_live})

    assert can_download(
        '#EXTM3U\n'
        '#EXT-X-TARGETDURATION:10\n'
        '#EXTINF:10,\n'
        'media-00001.ts\n'
        '#EXTINF:10,\n'
        'media-00002.ts\n'
        '#EXTINF:10,\n'
        'media-00003.ts\n'
        '#EXT-X-ENDLIST\n', False)

# Generated at 2022-06-24 12:00:36.373500
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.youtube import YoutubeIE
    from ..downloader import YoutubeDL

    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(YoutubeIE())
    url = 'https://www.youtube.com/watch?v=8tPnX7OPo0Q'

    info_dict = ydl.extract_info(url, download=False)
    assert HlsFD.can_download(info_dict['url'], info_dict)

# Generated at 2022-06-24 12:00:49.516109
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download("#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:2.000,\nhttp://localhost/seg_0.ts\n#EXTINF:2.000,\nhttp://localhost/seg_1.ts\n#EXTINF:2.000,\nhttp://localhost/seg_2.ts\n#EXT-X-ENDLIST", {})

# Generated at 2022-06-24 12:01:03.931602
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import re
    from .internal import FileDownloader
    HLS_FD = HlsFD(FileDownloader({'noprogress': True, 'simulate': True}))
    from .test import ytdl_test
    from .extractor import gen_extractors
    gen_extractors()

    # Verify that method real_download works correctly with segments that are not
    # divided in blocks of 16 bytes
    # See https://github.com/ytdl-org/youtube-dl/pull/27660
    test_file_dir = os.path.dirname(ytdl_test.__file__)
    test_file_path = os.path.join(test_file_dir, 'hls_frag_not_multiple_of_16.m3u8')

# Generated at 2022-06-24 12:01:08.676692
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import YoutubeIE
    import tempfile
    import os
    from .common import (
        download_fixture_data,
        assertEqual,
        assertIn,
    )
    class DummyYDL:
        params = {}
        def download(self, info_dicts):
            if not info_dicts:
                self.to_screen('no urls')
            for info_dict in info_dicts:
                self.to_screen('[%s] %s: ' % (info_dict['extractor'], info_dict['id']))
                video_url = info_dict['url']
                self.to_screen('\tvideo url: ' + video_url)
                video_title = info_dict['title']

# Generated at 2022-06-24 12:01:20.889756
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    from .native import RtmpFD
    from .fragment import FragmentFD
    from .external import FFmpegFD
    import os
    import hashlib
    class DummyYoutubeDL:
        def __init__(self):
            self.params = {
                'outtmpl': 'test_%(fragment_index)s.ts',
                'continuedl': False,
                'dump_single_json': True,
                'skip_download': True,
                'fragment_retries': 0,
                'test': False,
            }
            self.extractors = {}

        class Cache:
            _cache = {}
            def store(self, key, value):
                self._cache[key] = value

            def retrieve(self, key):
                return self

# Generated at 2022-06-24 12:01:33.192403
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import xml.etree.ElementTree

    test_url_m3u8 = 'https://raw.githubusercontent.com/ytdl-org/youtube-dl/master/youtube_dl/extractor/test/resources/hls_aes128_signature.m3u8'
    test_url_enc_key = 'https://raw.githubusercontent.com/ytdl-org/youtube-dl/master/youtube_dl/extractor/test/resources/hls_aes128_key.bin'
    test_url_enc_frag = 'https://raw.githubusercontent.com/ytdl-org/youtube-dl/master/youtube_dl/extractor/test/resources/hls_aes128_frag.bin'

    from ..YoutubeDL import YoutubeDL


# Generated at 2022-06-24 12:01:42.624596
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .external import ExternalFD
    assert not HlsFD.can_download("Not a real m3u8 contents", {})
    assert not HlsFD.can_download("#EXTM3U\n" + "#EXT-X-KEY:METHOD=FOO\n" + "#EXTINF:0.1\n" + "seg\n", {})
    assert not HlsFD.can_download("#EXTM3U\n" + "#EXT-X-BYTERANGE:0\n" + "#EXTINF:0.1\n" + "seg\n", {})
    assert not HlsFD.can_download("#EXTM3U\n" + "#EXT-X-MEDIA-SEQUENCE:3\n" + "#EXTINF:0.1\n" + "seg\n", {})

# Generated at 2022-06-24 12:01:55.059490
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class TestHlsFD(HlsFD):
        def __init__(self):
            pass


# Generated at 2022-06-24 12:02:01.331784
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .__main__ import parseOpts
    (ydl, params) = parseOpts(['https://www.youtube.com/watch?v=VQr5r5gqf7Y&live_stream=1&feature=youtu.be&t=5'])
    assert params['test']
    ydl.process_ie_result(ydl.extract_info('https://www.youtube.com/watch?v=VQr5r5gqf7Y&live_stream=1&feature=youtu.be&t=5'))

# Generated at 2022-06-24 12:02:12.737531
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest
    from .test_utils import FakeInfoDict
    from .extractor_test import m3u8_playlist

    class TestHlsFD(unittest.TestCase):
        def test_01(self):
            assert HlsFD.can_download(m3u8_playlist, FakeInfoDict({'url':''}))

        def test_02(self):
            assert not HlsFD.can_download(m3u8_playlist, FakeInfoDict({'url':'', 'is_live':True}))

        def test_03(self):
            assert not HlsFD.can_download(m3u8_playlist, FakeInfoDict({'url':'', '_decryption_key_url':'x'}))


# Generated at 2022-06-24 12:02:21.035274
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import ydl_opts
    from ydl.info import InfoExtractor

    ie = InfoExtractor(ydl_opts.YDL(), None)

    if not HlsFD.can_download('#EXT-X-KEY:METHOD=SAMPLE-AES,URI="https://priv.example.com/key.php?r=52",IV=0x9c7db8778570d05c3177c349fd9236aa', {'url': 'https://example.com/index.m3u8', 'http_headers': {'User-Agent': 'Test'}}):
        print('HlsFD.can_download is broken')
        return False


# Generated at 2022-06-24 12:02:23.102471
# Unit test for constructor of class HlsFD
def test_HlsFD():
    fd = HlsFD(None, None)
    assert fd.__class__.__name__ == 'HlsFD'


# Generated at 2022-06-24 12:02:35.151752
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        from youtube_dl.YoutubeDL import YoutubeDL
    except:
        from youtube_dl import YoutubeDL
    from .compat import Mock, patch, ANY
    from .test_common import BaseTest
    import os
    import tempfile
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file.close()

    def _remove_temp_file():
        try:
            os.remove(temp_file.name)
        except:
            pass

    _remove_temp_file()

    class YoutubeDLMock(YoutubeDL):
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-24 12:02:43.123227
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import youtube_dl.extractor.http
    import youtube_dl.extractor.http.hls
    import youtube_dl.utils
    """
    Sample test for HlsFD.can_download()
    """
    def test_can_download(manifest, expected_result, is_live, expected_warning):
        info_dict = youtube_dl.extractor.http.hls.extract_info(youtube_dl.Extractor('hlsnative'), manifest, {})
        info_dict['is_live'] = is_live
        if youtube_dl.utils.can_download_fragments(info_dict):
            result = True
            warning = None
        else:
            result = False
            warning = None
        # TODO: test with long http get url
        # TODO: test with long url in #EXT-X

# Generated at 2022-06-24 12:02:49.705915
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    downloader = YoutubeDL()
    fd_hlsnative = HlsFD(downloader)
    # https://github.com/ytdl-org/youtube-dl/issues/9470
    # https://github.com/ytdl-org/youtube-dl/issues/9473