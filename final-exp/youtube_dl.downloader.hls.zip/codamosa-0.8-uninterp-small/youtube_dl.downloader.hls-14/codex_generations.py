

# Generated at 2022-06-26 11:26:41.958316
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass


# Generated at 2022-06-26 11:26:52.986853
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    url = 'https://example.com/test.m3u8?xyz'
    info_dict = {'url': url}
    expected_result = True
    assert HlsFD.can_download('#EXTM3U', info_dict) == expected_result
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=NONE', info_dict) == expected_result
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', info_dict) == expected_result
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\n#EXT-X-BYTERANGE', info_dict) == expected_result

# Generated at 2022-06-26 11:26:55.060955
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:27:06.421216
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 1642.0
    str_0 = 'md5:1a86a0f3ac54024e419aba97210d959a'
    hls_f_d_0 = HlsFD(float_0, str_0)
    str_1 = 'https://s3-us-west-1.amazonaws.com/92f7a8e/6LgU6d/0.m3u8'
    str_2 = 'https://s3-us-west-1.amazonaws.com/92f7a8e/6LgU6d/0.m3u8'
    dict_0 = {'protocol': 'm3u8', 'format_id': '0'}

# Generated at 2022-06-26 11:27:09.440708
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:27:10.676122
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Test that the given name is actually the class name.

# Generated at 2022-06-26 11:27:12.068421
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()
    print('Test success: constructor of class HlsFD')

# Generated at 2022-06-26 11:27:22.259013
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    media_frags = 3
    ad_frags = 2
    ctx = {
        'filename': 'tmp.ts',
        'total_frags': media_frags,
        'ad_frags': ad_frags,
    }

    def _download_fragment(ctx, frag_url, info_dict, headers):
        success = True
        frag_content = b'0'
        return success, frag_content

    def _append_fragment(ctx, frag_content):
        pass

    def _finish_frag_download(ctx):
        pass

    HlsFD._download_fragment = _download_fragment
    HlsFD._append_fragment = _append_fragment
    HlsFD._finish_frag_download = _finish_frag_download

# Generated at 2022-06-26 11:27:27.327573
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 1642.0
    str_1 = 'md5:1a86a0f3ac54024e419aba97210d959a'
    hls_f_d_1 = HlsFD(float_0, str_1)
    str_2 = 'filename'
    str_3 = ''
    dict_0 = {'title': 'title', 'url': 'url', 'http_headers': {}}
    assert not hls_f_d_1.real_download(str_2, dict_0)

# Generated at 2022-06-26 11:27:37.934573
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # mock _download_fragment for method real_download.
    def mock_fragment_download(ctx, frag_url, info_dict, headers):
        return True, bytes('Hello world!', 'utf-8')

    float_0 = 1642.0
    str_0 = 'md5:1a86a0f3ac54024e419aba97210d959a'
    hls_f_d_0 = HlsFD(float_0, str_0)
    hls_f_d_0._download_fragment = mock_fragment_download
    real_download_result = hls_f_d_0.real_download(str_0, {'test': True})
    assert real_download_result == True


test_case_0()

# Generated at 2022-06-26 11:28:03.494202
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d = HlsFD(None, 'test')
    assert hls_f_d.real_download(None, {'url': 'a', 'include_ads': False})


# Generated at 2022-06-26 11:28:10.213575
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 1641.3149346989621
    str_0 = 'md5:1a86a0f3ac54024e419aba97210d959a'
    hls_f_d_0 = HlsFD(float_0, str_0)
    str_1 = "JD&'O|IaCDyA"
    assert hls_f_d_0.can_download(str_1, str_0)

# Generated at 2022-06-26 11:28:13.847407
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'http://hls-geo.daserste.de/i/videoportal/Film/c_620000/622873/format,716451,716457,716450,716458,716459,.mp4.csmil/index_7_av.m3u8?null=0'
    hls_f_d_0 = HlsFD(str_0)
    str_1 = 'I#p.0khh9'
    bool_0 = hls_f_d_0.real_download(str_0, str_1)

if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:28:18.681154
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD(None, None)
    str_0 = '7oxH36O6X9_{0'
    str_1 = 'tYH|{`eTg"_b*'
    hls_f_d_0.real_download(str_0, str_1)

# Generated at 2022-06-26 11:28:21.023008
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:28:26.961566
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    invalid_manifest = """
#EXTM3U
    """
    info_dict = {'url': 'http://url'}
    hls_fd = HlsFD(1.0, 'md5:1a86a0f3ac54024e419aba97210d959a')
    assert not hls_fd.can_download(invalid_manifest, info_dict)
    assert hls_fd.can_download("#EXTM3U", info_dict)
    assert hls_fd.can_download("#EXTM3U\n#EXTINF:2.000,\nfoo.ts", info_dict)

# Generated at 2022-06-26 11:28:34.560652
# Unit test for constructor of class HlsFD
def test_HlsFD():
    float_0 = 1733.4837867762753
    str_0 = 'md5:f11f4e4e79c4a2a07ed21b1022df061f'
    hls_f_d_0 = HlsFD(float_0, str_0)
    assert(hls_f_d_0._ydl == float_0)
    assert(hls_f_d_0._param == str_0)


# Generated at 2022-06-26 11:28:43.504702
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '/mnt/data/os/Downloads/S02E07.mp4'

# Generated at 2022-06-26 11:28:45.513600
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:28:47.321231
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

test_HlsFD()

# Generated at 2022-06-26 11:29:17.658529
# Unit test for constructor of class HlsFD
def test_HlsFD():
    float_0 = 1642.0
    str_0 = 'md5:1a86a0f3ac54024e419aba97210d959a'
    hls_f_d_0 = HlsFD(float_0, str_0)

# Generated at 2022-06-26 11:29:23.407519
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 1642.0
    str_0 = 'md5:1a86a0f3ac54024e419aba97210d959a'
    hls_f_d_0 = HlsFD(float_0, str_0)
    hls_f_d_0.real_download(str_0, str_0)

# Generated at 2022-06-26 11:29:34.344665
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 1642.0
    str_0 = 'md5:1a86a0f3ac54024e419aba97210d959a'
    str_1 = 'md5:e6c7e6ab5d6c5f6b5d6c5f6b5d6c5f6b5d6c5f6b'
    str_2 = 'md5:4d1e4d1e4d1e4d1e4d1e4d1e4d1e4d1e4d1e4d1e'
    hls_f_d_0 = HlsFD(float_0, str_0)
    t_c_0 = hls_f_d_0.real_download(str_0, str_2)


# Generated at 2022-06-26 11:29:43.921362
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    url = 'http://example.com'
    info = {
        'url': url
    }
    # Need to set _downloader as it is accessed inside _get_fragment_retries
    HlsFD(None, None)._downloader = {
        # Use a non-zero and non-default value to test that it is being
        # correctly used.
        'fragment_retries': 1,
        'skip_unavailable_fragments': True,
        'test': True,
    }
    with open('tests/files/hls/test_0.m3u8') as f:
        manifest = f.read()
        HlsFD(None, None).real_download(None, info)

# Generated at 2022-06-26 11:29:44.843439
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert(HlsFD >= 0)


# Generated at 2022-06-26 11:29:47.525850
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_0 = -1


if __name__ == '__main__':
    test_case_0()
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:29:55.611849
# Unit test for constructor of class HlsFD
def test_HlsFD():
    float_0 = 1592.0
    float_1 = float_0
    str_0 = 'md5:1a86a0f3ac54024e419aba97210d959a'
    str_1 = str_0
    hls_f_d_0 = HlsFD(float_1, str_1)
    # assert str(type(hls_f_d_0)) == "<class 'youtube_dl.extractor.hls.HlsFD'>"
    hls_f_d_0 = HlsFD(float_1, str_1)
    float_2 = float_0
    str_2 = str_0
    hls_f_d_1 = HlsFD(float_2, str_2)
    assert hls_f_d_0 == hls_f_d

# Generated at 2022-06-26 11:30:07.634152
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_1 = 'test.com'
    str_2 = 'md5:1a86a0f3ac54024e419aba97210d959a'
    int_0 = 80000
    dict_0 = {'url': str_1, 'http_headers': {'Referer': str_2}}
    float_0 = 1642.0
    str_3 = 'md5:1a86a0f3ac54024e419aba97210d959a'
    str_4 = 'md5:1a86a0f3ac54024e419aba97210d959a'
    test_HlsFD_real_download_0 = can_download(str_4, dict_0)
    hls_f_d_0 = HlsFD(float_0, str_3)


# Generated at 2022-06-26 11:30:10.975801
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """Test method real_download of class HlsFD"""
    # Tested when downloading a testcase using the hlsnative FD.


if __name__ == '__main__':
    test_case_0()
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:30:20.733437
# Unit test for constructor of class HlsFD
def test_HlsFD():
    float_0 = 1642.0
    str_0 = 'md5:1a86a0f3ac54024e419aba97210d959a'
    hls_f_d_0 = HlsFD(float_0, str_0)
    hls_f_d_1 = HlsFD(float_0, str_0)
    # Create a file for test purpose.
    f = open('test.txt','w')
    f.write('test line 1\ntest line 2\ntest line 3')
    f.close()
    hls_f_d_2 = HlsFD(1234.0, 'test.txt')
    hls_f_d_3 = HlsFD(float_0, '')

# Generated at 2022-06-26 11:31:42.541973
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 1642.0
    str_0 = 'md5:1a86a0f3ac54024e419aba97210d959a'
    hls_f_d_0 = HlsFD(float_0, str_0)
    var_0 = hls_f_d_0.real_download(str_0, str_0)
    if var_0:
        print('Success')
    else:
        print('Failure')

if __name__ == '__main__':
    test_case_0()
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:31:50.612824
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    real_download_args = [
        ["manifest", "info_dict"],
        ["manifest", "info_dict"],
    ]

# Generated at 2022-06-26 11:32:01.715247
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    num_0 = 5
    int_0 = 24
    str_0 = 'adad333'

# Generated at 2022-06-26 11:32:04.844732
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Test downloader for HlsFD
# Test with a sample video and test the video is successfully downloaded
if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:32:14.035717
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 124.0
    str_0 = 'aes-128'
    str_1 = 'http://'
    str_2 = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'

# Generated at 2022-06-26 11:32:22.279545
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'data/verified_cases/test_case_0.txt'
    str_1 = 'md5:1a86a0f3ac54024e419aba97210d959a'
    float_0 = 1642.0
    hls_f_d_0 = HlsFD(float_0, str_1)
    assert(hls_f_d_0.can_download(str_0, str_1))

# Generated at 2022-06-26 11:32:27.528231
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 1642.0
    str_0 = 'md5:1a86a0f3ac54024e419aba97210d959a'
    hls_f_d_0 = HlsFD(float_0, str_0)
    var_0 = hls_f_d_0.real_download(str_0, str_0)
    assert var_0 is False

# Generated at 2022-06-26 11:32:33.867426
# Unit test for constructor of class HlsFD
def test_HlsFD():
    global float_0
    global str_0
    global hls_f_d_0
    global var_0
    float_0 = 1642.0
    str_0 = 'md5:1a86a0f3ac54024e419aba97210d959a'
    hls_f_d_0 = HlsFD(float_0, str_0)
    var_0 = hls_f_d_0.can_download(str_0, str_0)

if __name__ == '__main__':
    test_case_0()
    test_HlsFD()

# Generated at 2022-06-26 11:32:37.135279
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 1642.0
    str_0 = 'md5:1a86a0f3ac54024e419aba97210d959a'
    hls_f_d_0 = HlsFD(float_0, str_0)
    bool_0 = hls_f_d_0.real_download(str_0, str_0)

# Generated at 2022-06-26 11:32:39.009660
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert test_case_0() == None

# Generated at 2022-06-26 11:35:52.150817
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    str_0 = '#EXT-X-KEY:METHOD=AES-128'
    str_1 = '#EXT-X-BYTERANGE'
    # Test 1
    hls_f_d_0 = HlsFD(1568.0, 'md5:ca6b8c7d65ad38cb31ff9792c8a8fce7')
    var_0 = hls_f_d_0.can_download(str_0, str_0)
    # Test 2
    assert not hls_f_d_0.can_download(str_1, str_0)

# Test case executes before line 23.
test_case_0()

# Generated at 2022-06-26 11:35:52.776421
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert True

# Generated at 2022-06-26 11:36:00.707133
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # We are testing to way to generate the file download
    # file fd1.bin is generate by ffmpeg method
    # file fd2.bin is generate by HlsFD method
    url1 = 'https://mnmedias.api.telequebec.tv/m3u8/29880.m3u8'
    url2 = 'https://mnmedias.api.telequebec.tv/m3u8/29880.m3u8?app=website'
    hls_fd1 = HlsFD(0, '')
    hls_fd1._download_fragment = lambda a, b, c, d: (True, b.encode('utf-8'))
    hls_fd1._append_fragment = lambda a, b: None
    hls_fd1.real_download

# Generated at 2022-06-26 11:36:06.358823
# Unit test for constructor of class HlsFD
def test_HlsFD():
    float_0 = 1642.0
    str_0 = 'md5:1a86a0f3ac54024e419aba97210d959a'
    hls_f_d_0 = HlsFD(float_0, str_0)
    # test the floating point a
    assert hls_f_d_0.a == float_0
    # test the string b
    assert hls_f_d_0.b == str_0

# Generated at 2022-06-26 11:36:10.237588
# Unit test for constructor of class HlsFD
def test_HlsFD():
    var_0 = HlsFD(None, None)
    assert(var_0.par_0 == None)
    assert(var_0.par_1 == None)
    var_0 = HlsFD(0, 'test_1')
    assert(var_0.par_0 == 0)
    assert(var_0.par_1 == 'test_1')


# Generated at 2022-06-26 11:36:16.761914
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import flask
    # Test path 1
    # TODO: Add test cases
    # Test path 2
    hls_f_d_0 = HlsFD()
    hls_f_d_0.params['test'] = True
    str_0 = 'http://www.huya.com/loldk/2550923'
    var_0 = hls_f_d_0.real_download(str_0, str_0)
    # Test path 3
    hls_f_d_1 = HlsFD()
    hls_f_d_1.params['test'] = True
    str_1 = 'https://t.co/tRbRtBsiPn'
    var_1 = hls_f_d_1.real_download(str_1, str_1)
    # Test