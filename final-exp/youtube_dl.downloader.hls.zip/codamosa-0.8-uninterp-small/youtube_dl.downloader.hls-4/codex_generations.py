

# Generated at 2022-06-26 11:26:53.156115
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    try:
        hls_f_d_0 = HlsFD(0, 0)
    except:
        print('AssertionError')
    try:
        retval_0 = hls_f_d_0.real_download(0, 0)
    except:
        print('AssertionError')
    try:
        assert (retval_0 == 0)
    except:
        print('AssertionError')

# Generated at 2022-06-26 11:26:55.782037
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:26:59.355595
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # test 0:
    man_url = 'http://google.com'
    info_dict = {'url': 'http://google.com', 'protocol': 'm3u8'}
    fd = HlsFD(None, None)
    assert not fd._real_download(man_url, info_dict)

# Generated at 2022-06-26 11:27:09.681741
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    manifest_url = 'http://dkh-fra-dev.akamaized.net/i/dkh/mediathek_1@388192/master.m3u8'
    hls_f_d_0 = HlsFD()
    info_dict_0 = {'format': 'bestvideo+bestaudio/best', '_type': 'url'}
    hls_f_d_0.real_download('test_dir/output.mp4', info_dict_0)


if __name__ == '__main__':
    test_case_0()
#     test_HlsFD_real_download()

# Generated at 2022-06-26 11:27:15.626434
# Unit test for constructor of class HlsFD
def test_HlsFD():
    program_0 = b'c\xd5\xfdA\tUtZF\xc9M\xdeKg\x93\xb7W+*'
    program_1 = 'Moldova, Republic of'
    assert_equal(HlsFD(program_0, program_1)._program, b'c\xd5\xfdA\tUtZF\xc9M\xdeKg\x93\xb7W+*')
    assert_equal(
        HlsFD(program_0, program_1)._cracked_program,
        'Moldova, Republic of')


# Generated at 2022-06-26 11:27:17.902556
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# HlsFD
if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:27:21.484950
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import pytest
    with pytest.raises(TypeError):
        test_case_0()

if __name__ == '__main__':
    import pytest
    pytest.main(['-k', 'test_HlsFD', __file__])

# Generated at 2022-06-26 11:27:28.664197
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # HlsFD to test
    hls_f_d_0 = HlsFD(b'\xd5\x9b\x83\x0f', 'Kyrgyzstan')
    # location info_dict
    loc_info_dict = {'url': str_0}

    assert hls_f_d_0.can_download(str_0, loc_info_dict) == False

    # call real_download
    try:
        hls_f_d_0.real_download(chr_0, loc_info_dict)
    except Exception as e:
        print('Caught exception: ', type(e), ':', e, file=sys.stderr)
        return
    return

# Script code
if __name__ == '__main__':
    test_case_0()

   

# Generated at 2022-06-26 11:27:38.430790
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-26 11:27:39.997526
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        test_case_0()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-26 11:28:00.767987
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    print(test_HlsFD_real_download.__doc__)

    hls_f_d_0 = HlsFD(0, 0)
    hls_f_d_0.real_download('test', 'test')

# Generated at 2022-06-26 11:28:11.949691
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_0 = -12
    hls_f_d_0 = HlsFD(int_0, int_0)
    manifest = ('#EXTM3U\n'
                '#EXT-X-TARGETDURATION:9\n'
                '#EXT-X-VERSION:3\n'
                '#EXT-X-PLAYLIST-TYPE:VOD\n'
                '#EXT-X-KEY:METHOD=AES-128,URI="https://test.test/key",IV=0x34252342342\n'
                '#EXT-X-BYTERANGE:2000@0\n'
                '#EXTINF:9,\n'
                'http://test.test/f1\n')

# Generated at 2022-06-26 11:28:22.759146
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    man_url_0 = 'https://daserste.hls.ard.de/i/videoportal/Film/c_920000/956565/format,716454,716455,716456,716457,716458,.mp4.csmil/master.m3u8?null=0'
    info_dict = {'url': man_url_0}
    filename = 'test.mp4'
    assert not HlsFD.can_download('', info_dict)

# Generated at 2022-06-26 11:28:25.288964
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD()

if __name__ == '__main__':
    print('Testing HlsFD')
    test_HlsFD()

# Generated at 2022-06-26 11:28:27.193006
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert True  # TODO: implement your test here


# Generated at 2022-06-26 11:28:32.812543
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_0 = -12
    hls_f_d_0 = HlsFD(int_0, int_0)
    str_1 = 'hlsnative'
    bool_0 = hls_f_d_0.can_download(str_1, int_0)
    assert bool_0


# Generated at 2022-06-26 11:28:36.934918
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD(None, None)
    hls_f_d_0.real_download(None, None)


if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:28:37.331258
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert True



# Generated at 2022-06-26 11:28:41.896707
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # TODO:
    # 	1. Construct input arguments (if needed)
    # 	2. Call the method with the constructed arguments
    # 	3. Verify that the result is the expected
    # 	   result.
    hls_f_d_0 = HlsFD(None, None)
    hls_f_d_0.real_download(None, None)


# Generated at 2022-06-26 11:28:44.966921
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()
    print('All tests passed!')

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:29:01.020804
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert_equals(int_0, 0)


# Generated at 2022-06-26 11:29:01.633806
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass

# Generated at 2022-06-26 11:29:07.566268
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():

    # Create an instance of HlsFD
    hls_f_d_0 = HlsFD()

    # Test HlsFD, method can_download
    # The method doesn't raise any exception, the test has been executed
    hls_f_d_0.can_download(hls_f_d_0, hls_f_d_0)



# Generated at 2022-06-26 11:29:11.110035
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_0 = -11
    hls_f_d_0 = HlsFD(int_0, int_0)
    var_0 = hls_f_d_0.real_download(int_0, int_0)


# Generated at 2022-06-26 11:29:16.214042
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # all of these lines should be tested
    def test_0():
        # None as second argument
        hls_f_d = HlsFD(None, None)
        assert hls_f_d.real_download(None, None) == True
    test_0()

if __name__ == '__main__':
    for test in [test_HlsFD]:
        test()

# Generated at 2022-06-26 11:29:16.802216
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass

# Generated at 2022-06-26 11:29:25.613867
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    import sys
    import inspect

    try:
        if sys.argv[1] == '-t':
            frame = inspect.getframeinfo(inspect.currentframe())
            print(frame.filename)
            print(frame.lineno)
            test_HlsFD_real_download()
            sys.exit(0)
    except IndexError:
        pass

    HlsFD().download(sys.argv[1])

# Generated at 2022-06-26 11:29:28.803436
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_0 = -11
    hls_f_d_0 = HlsFD(int_0, int_0)
    var_0 = hls_f_d_0.real_download(int_0, int_0)

# Generated at 2022-06-26 11:29:30.802308
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Test case 0
    test_case_0()

if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:29:33.153912
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_1 = HlsFD(0, 0)
    assert (hls_1.FD_NAME == 'hlsnative')



# Generated at 2022-06-26 11:29:59.553480
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert test_case_0() == None

# Generated at 2022-06-26 11:30:03.115019
# Unit test for constructor of class HlsFD
def test_HlsFD():
    int_0 = -11
    hls_f_d_0 = HlsFD(int_0, int_0)
    assert isinstance(hls_f_d_0, HlsFD)


# Generated at 2022-06-26 11:30:06.046388
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .external import ExternalFD
    ExternalFD.download_info('')
    test_case_0()

test_HlsFD()

# Generated at 2022-06-26 11:30:08.275304
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

if __name__ == "__main__":
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:30:12.734830
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import youtube_dl.YoutubeDL
    int_0 = -13
    hls_f_d_0 = HlsFD(int_0, int_0)
    test_case_0()
    test_case_0()


if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:30:15.375306
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import common_test_HlsFD_real_download
    common_test_HlsFD_real_download(HlsFD)

# Generated at 2022-06-26 11:30:16.485578
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:30:26.770432
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-26 11:30:29.372937
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download('#EXTM3U', {}) is True

# Generated at 2022-06-26 11:30:40.132874
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import sys
    import unittest
    sys.path.append(".")
    import youtube_dl


# Generated at 2022-06-26 11:31:49.796447
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    var_0 = HlsFD.can_download((1, 2), (3, 4))



# Generated at 2022-06-26 11:31:52.321665
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:31:57.362734
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_0 = -11
    hls_f_d_0 = HlsFD(int_0, int_0)
    var_0 = hls_f_d_0.real_download(int_0, int_0)
    assert var_0 == False

# Generated at 2022-06-26 11:31:59.106255
# Unit test for constructor of class HlsFD
def test_HlsFD():
    instance = HlsFD(None, None)
    assert type(instance) == HlsFD



# Generated at 2022-06-26 11:32:01.436979
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    hls_f_d_0 = HlsFD(1, 1)
    assert hls_f_d_0.can_download(1, 1) == 0


# Generated at 2022-06-26 11:32:03.519567
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

if __name__ == "__main__":
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:32:04.857046
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()
    pass

# Generated at 2022-06-26 11:32:11.684377
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    manifest = '''\
#EXTM3U
#EXT-X-VERSION:3
#EXT-X-MEDIA-SEQUENCE:0
#EXT-X-TARGETDURATION:8
#EXTINF:7.975,
http://media.example.com/fileSequence2690.ts
#EXT-X-ENDLIST
'''
    is_live = hls_f_d_0.params.get('is_live')
    assert hls_f_d_0.can_download(manifest, is_live)

# Generated at 2022-06-26 11:32:12.566638
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:32:20.875182
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

if __name__ == "__main__":
    import os

    import sys


    def is_testing_mode():
        return len(sys.argv) > 1 and sys.argv[1] == '--test'


    os.environ['PYTHONPATH'] = os.pathsep.join(sys.path)
    if is_testing_mode():
        test_HlsFD_real_download()
    else:
        main()

# Generated at 2022-06-26 11:35:05.657420
# Unit test for constructor of class HlsFD
def test_HlsFD():
    print("========= Test Case 0 =========")
    test_case_0()

# Generated at 2022-06-26 11:35:08.264880
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:35:10.457110
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        test_case_0()
    except:
        raise AssertionError

# Generated at 2022-06-26 11:35:12.888723
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_fd = HlsFD(None, None)
    assert hls_fd is not None


# Generated at 2022-06-26 11:35:18.407053
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    hls_f_d_0 = HlsFD()
    var_0 = hls_f_d_0.can_download(test_case_0,test_case_0)
    var_1 = False
    assert (var_0 == var_1)


# Generated at 2022-06-26 11:35:19.848500
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD(int_0, int_0)

if __name__ == '__main__':
    test_case_0()
    test_HlsFD()

# Generated at 2022-06-26 11:35:21.037817
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD(None, None)
    hls_f_d_1 = HlsFD(None, None)


# Generated at 2022-06-26 11:35:22.345849
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:35:23.638108
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:35:25.279298
# Unit test for constructor of class HlsFD
def test_HlsFD():
    instance = HlsFD(None, None)
