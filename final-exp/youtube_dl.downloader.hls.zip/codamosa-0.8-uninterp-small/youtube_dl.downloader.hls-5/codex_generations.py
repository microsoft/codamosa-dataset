

# Generated at 2022-06-26 11:26:46.648438
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    list_0 = []
    str_0 = ''
    hls_f_d_0 = HlsFD(list_0, str_0)
    str_1 = ''
    dict_0 = {}
    hls_f_d_0.real_download(str_1, dict_0)


# Generated at 2022-06-26 11:26:50.086809
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD([], '', {}, {})
    assert hls_f_d_0 is not None


# Generated at 2022-06-26 11:26:56.003031
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # In this test, all the parameters of the constructor are valid,
    # and the constructor should work successfully without any exception
    params = {}
    ydl = None
    try:
        test_case_0()
    except Exception as e:
        print('The constructor of class HlsFD got an EXCEPTION: ', type(e), e)
    else:
        print('The constructor of class HlsFD worked OK.')


# Generated at 2022-06-26 11:27:00.094713
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()



# Generated at 2022-06-26 11:27:06.841694
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    url = 'http://example.com'
    info_dict = {'url': url}
    str_0 = ''
    hls_f_d_0 = HlsFD(str_0, str_0)
    hls_f_d_0._prepare_url(info_dict, url)
    hls_f_d_0.real_download(str_0, info_dict)

# Generated at 2022-06-26 11:27:08.997143
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()


# Generated at 2022-06-26 11:27:11.141068
# Unit test for constructor of class HlsFD
def test_HlsFD():
    list_0 = []
    str_0 = ''
    hls_f_d_0 = HlsFD(list_0, str_0)

# Generated at 2022-06-26 11:27:14.869874
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    list_0 = []
    str_0 = ''
    hls_f_d_0 = HlsFD(list_0, str_0)
    assert hls_f_d_0.real_download('filename', {}) == False

# Generated at 2022-06-26 11:27:17.474978
# Unit test for constructor of class HlsFD
def test_HlsFD():
    list_0 = []
    str_0 = ''
    assert HlsFD(list_0, str_0).FD_NAME == 'hlsnative'


# Generated at 2022-06-26 11:27:23.121980
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    list_0 = []
    str_0 = ''
    hls_f_d_0 = HlsFD(list_0, str_0)
    str_0 = 'HlsFD-real_download-1'
    dict_0 = {}
    # hls_f_d_0.real_download('HlsFD-real_download-1',dict_0)
    hls_f_d_0.real_download(str_0,dict_0)


# Generated at 2022-06-26 11:27:38.992199
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    list_0 = []
    str_0 = ''
    hls_f_d_0 = HlsFD(list_0, str_0)
    str_1 = ';hslnative;test_case_0'
    dict_0 = {'url': str_1}
    boolean_0 = hls_f_d_0.real_download(str_1, dict_0)
    assert boolean_0 == True


# Generated at 2022-06-26 11:27:41.719700
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    list_0 = []
    str_0 = ''
    hls_f_d_0 = HlsFD(list_0, str_0)
    str_1 = ''
    dict_0 = {'a': 'b'}
    bool_0 = hls_f_d_0.real_download(str_1, dict_0)


# Generated at 2022-06-26 11:27:50.364431
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    list_0 = []
    str_0 = ''
    list_1 = []
    str_1 = ''
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_0 = {"url": str_0}
    hls_f_d_0 = HlsFD(list_0, str_0)
    hls_f_d_0.real_download(str_1, dict_0)
    hls_f_d_0.real_download(str_1, dict_1)
    hls_f_d_0.real_download(str_1, dict_2)
    hls_f_d_0.real_download(str_1, dict_1)
#     hls_f_d_0.real_download(str_1, dict_2

# Generated at 2022-06-26 11:27:52.357839
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Stub
    """
    HlsFD.real_download(filename, info_dict)
        real_download(self, filename, info_dict)
    """
    pass



# Generated at 2022-06-26 11:27:54.254021
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    test_case_0()
    return True


# Generated at 2022-06-26 11:28:00.389894
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    list_0 = []
    str_0 = ''
    hls_f_d_0 = HlsFD(list_0, str_0)
    dict_0 = dict()
    dict_0['url'] = 'http://giant.gfycat.com/LeadingLimpingHare.m3u8'
    dict_0['is_live'] = False
    dict_0['headers'] = dict()
    bool_0 = hls_f_d_0.real_download('', dict_0)
    return bool_0


# Generated at 2022-06-26 11:28:01.699421
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert True == True


# Generated at 2022-06-26 11:28:05.583031
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        list_0 = []
        str_0 = ''
        hls_f_d_0 = HlsFD(list_0, str_0)
    except NameError:
        assert False
    else:
        assert True


# Generated at 2022-06-26 11:28:16.336530
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    manifest = '''\
#EXTM3U
#EXT-X-VERSION:3
#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=836280,CODECS="mp4a.40.2,avc1.64001f",RESOLUTION=640x360
index_0_av.m3u8?null=0
#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=1248700,CODECS="mp4a.40.2,avc1.64001f",RESOLUTION=848x480
index_1_av.m3u8?null=0
'''
    assert HlsFD.can_download(manifest, {'is_live': False})


# Generated at 2022-06-26 11:28:21.171181
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    list_1 = []
    str_1 = ''
    hls_f_d_1 = HlsFD(list_1, str_1)
    str_2 = ''
    dict_1 = {}
    hls_f_d_1.real_download(str_2, dict_1)


# Generated at 2022-06-26 11:28:39.634136
# Unit test for constructor of class HlsFD
def test_HlsFD():

    list_0 = []
    str_0 = "^;c+Z\x0c\\MJ'{)"
    hls_f_d_0 = HlsFD(list_0, str_0)
    assert hls_f_d_0.params == str_0
    assert hls_f_d_0._progress_hooks == list_0

    list_0 = []
    str_0 = "^;c+Z\x0c\\MJ'{)"
    hls_f_d_1 = HlsFD(list_0, str_0)
    var_0 = hls_f_d_1.real_download(str_0, str_0)
    assert hls_f_d_1.params == str_0

# Generated at 2022-06-26 11:28:41.164608
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:28:47.680156
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    list_0 = []
    str_0 = "^;c+Z\x0c\\MJ'{)"
    hls_f_d_0 = HlsFD(list_0, str_0)
    assert_equals(test_case_0(), True)

test_HlsFD_real_download()

# vim: set ts=4 sw=4 tw=0 et :

# Generated at 2022-06-26 11:28:48.696332
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:28:49.853274
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert test_case_0()

# Generated at 2022-06-26 11:28:54.727571
# Unit test for constructor of class HlsFD
def test_HlsFD():
    list_0 = []
    str_0 = "^;c+Z\x0c\\MJ'{)"
    hls_f_d_0 = HlsFD(list_0, str_0)



# Generated at 2022-06-26 11:28:55.727467
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:28:57.387290
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    try:
        test_case_0()
    except:
        assert False

# Dummy function for expected types

# Generated at 2022-06-26 11:29:02.015318
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD(None, None)
    hls_f_d_0 = HlsFD([], "ytdl")

# test driver for unit tests for HlsFD

# Generated at 2022-06-26 11:29:08.041040
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    list_0 = []
    str_0 = "^;c+Z\x0c\\MJ'{)"
    hls_f_d_0 = HlsFD(list_0, str_0)
    var_0 = hls_f_d_0.can_download(str_0, str_0)
    assert var_0 == True


# Generated at 2022-06-26 11:29:37.256658
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    list_0 = []
    str_0 = "hdwj\x0b\x1f'1\tkq[W\u000f"
    hls_f_d_0 = HlsFD(list_0, str_0)
    assert hls_f_d_0.can_download(str_0, str_0)


# Generated at 2022-06-26 11:29:39.590580
# Unit test for constructor of class HlsFD
def test_HlsFD():
    list_0 = []
    str_0 = ""
    hls_f_d_0 = HlsFD(list_0, str_0)

# Generated at 2022-06-26 11:29:42.914133
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    list_0 = []
    str_0 = ""
    hls_f_d_0 = HlsFD(list_0, str_0)
    var_0 = hls_f_d_0.real_download(str_0, str_0)


# Generated at 2022-06-26 11:29:51.296632
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = ";S.\x17("
    str_1 = "u`"
    list_0 = []
    hls_f_d_0 = HlsFD(list_0, str_0)
    var_0 = hls_f_d_0.add_progress_hook(str_1)
    str_2 = "dX\x0b"
    var_1 = hls_f_d_0.add_progress_hook(str_2)
    str_3 = "  \x0c1"
    var_2 = hls_f_d_0.add_progress_hook(str_3)


# Generated at 2022-06-26 11:29:57.782266
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    list_0 = []
    str_0 = "^;c+Z\x0c\\MJ'{)"
    str_1 = '"uL<8\x7fP\x19\x7f'
    hls_f_d_0 = HlsFD(list_0, str_0)
    var_0 = hls_f_d_0.real_download(str_0, str_1)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 11:30:02.052912
# Unit test for constructor of class HlsFD
def test_HlsFD():

    list_0 = []
    str_0 = "^;c+Z\x0c\\MJ'{)"
    hls_f_d_0 = HlsFD(list_0, str_0)


# Generated at 2022-06-26 11:30:06.045666
# Unit test for constructor of class HlsFD
def test_HlsFD():
    list_0 = []
    str_0 = "^;c+Z\x0c\\MJ'{)"
    hls_f_d_0 = HlsFD(
        list_0, str_0
        )


# Generated at 2022-06-26 11:30:11.502958
# Unit test for constructor of class HlsFD
def test_HlsFD():
    list_0 = [4, 5, 6, 7]
    str_0 = 'C:\\Program Files\\Mozilla Firefox\\firefox.exe'
    hls_f_d_0 = HlsFD(list_0, str_0)
    var_0 = hls_f_d_0.real_download(str_0, str_0)
    print(var_0)


# Generated at 2022-06-26 11:30:16.411252
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    list_0 = []
    str_0 = "^;c+Z\x0c\\MJ'{)"
    hls_f_d_0 = HlsFD(list_0, str_0)
    var_0 = hls_f_d_0.real_download(str_0, str_0)


# Generated at 2022-06-26 11:30:21.753551
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    list_0 = []
    str_0 = "^;c+Z\x0c\\MJ'{)"
    hls_f_d_0 = HlsFD(list_0, str_0)
    var_0 = hls_f_d_0.can_download(str_0, str_0)
    print("Value: " + str(var_0))

if __name__ == "__main__":
    test_case_0()
    test_HlsFD_can_download()

# Generated at 2022-06-26 11:31:44.280520
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # no operation
    assert True

# Generated at 2022-06-26 11:31:49.231192
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'U6#QK6NW%}T)QM8'
    hls_f_d_0 = HlsFD(str_0, 'G{bK58sC1')
    str_0 = 'KUK&_05IzU6'
    int_0 = -14
    var_0 = hls_f_d_0.can_download(str_0, int_0)


# Generated at 2022-06-26 11:31:52.232238
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert test_case_0() == True


if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:32:02.870913
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Initialization
    str_0 = 'xQO{X#UEC'
    int_0 = -1603
    hls_f_d_0 = HlsFD(str_0, int_0)
    str_1 = 'a(OAY'
    dict_0 = {'is_live': True, 'url': str_1}
    str_2 = '|tVy:t&K'
    str_3 = ''
    int_1 = 2
    str_4 = 'EN'
    int_2 = 2
    # AssertionError: AssertionError()
    #hls_f_d_0.real_download(str_2, dict_0)
    # AssertionError: AssertionError()
    #hls_f_d_0.real_download(str_

# Generated at 2022-06-26 11:32:08.834643
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_0 = -1603
    str_0 = 'xQO{X#UEC'
    hls_f_d_0 = HlsFD(str_0, int_0)
    str_1 = 'QYsX(y!aH'
    str_2 = 'ZvjtZ?d_S'
    bool_0 = hls_f_d_0.real_download(str_1, str_2)

# Generated at 2022-06-26 11:32:11.385394
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD('', -1603)
    assert isinstance(hls_f_d_0, HlsFD)


# Generated at 2022-06-26 11:32:13.006219
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:32:13.945564
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()


# Generated at 2022-06-26 11:32:15.384343
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

test_HlsFD()

# Generated at 2022-06-26 11:32:19.480274
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.FD_NAME == 'hlsnative'

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:35:24.137410
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD(None, None)
    try:
        hls_f_d_0.real_download('filename', 'info_dict')
    except:
        pass
    try:
        hls_f_d_0.real_download('filename', 'info_dict')
    except:
        pass
    try:
        hls_f_d_0.real_download('filename', 'info_dict')
    except:
        pass
    try:
        hls_f_d_0.real_download('filename', 'info_dict')
    except:
        pass

# Generated at 2022-06-26 11:35:26.928696
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_1 = HlsFD('https://bit.ly/2wAeQV7', {'format_id': 'bigsportlive'})
    assert hls_f_d_1.FD_NAME == 'hlsnative'


# Generated at 2022-06-26 11:35:29.321127
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Case 1
    str_0 = 'p\ny:ZrzRm'
    hls_f_d_0 = HlsFD(str_0, str_0)
    hls_f_d_0.real_download(str_0, str_0)


# Generated at 2022-06-26 11:35:30.944582
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str1 = 'p\ny:ZrzRm'
    hlsFD = HlsFD(str1, str1)
    hlsFD.real_download('nonexistent', str1)

# Generated at 2022-06-26 11:35:41.438075
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'p\ny:ZrzRm'
    hls_f_d_0 = HlsFD(str_0, str_0)
    i_d_0 = hls_f_d_0
    hls_f_d_0.real_download(str_0, i_d_0)

    str_0 = '1\nG\xB7m\xC1\xE5\xEB\xF6'
    hls_f_d_0 = HlsFD(str_0, str_0)
    i_d_0 = hls_f_d_0
    i_d_0.url = 'https://example.com/manifest.m3u8?q=2'

# Generated at 2022-06-26 11:35:47.380443
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'p\ny:ZrzRm'
    hls_f_d_0 = HlsFD(str_0, str_0)
    try:
        var_0 = hls_f_d_0.real_download(str_0, hls_f_d_0)
    except NotImplementedError:
        var_0 = None
    assert var_0

# Generated at 2022-06-26 11:35:48.955361
# Unit test for constructor of class HlsFD
def test_HlsFD():
    case_0 = test_case_0()


if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:35:55.379968
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert 'hlsnative' in HlsFD.can_download('https://www.facebook.com/ArirangKpop/videos/10153779249506604/', {})
    assert not HlsFD.can_download('https://www.facebook.com/ArirangKpop/videos/10153779249506604/', {'http_headers': 'User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36'})
    assert not HlsFD.can_download('https://www.facebook.com/ArirangKpop/videos/10153779249506604/', {'is_live': True})

# Generated at 2022-06-26 11:36:00.375611
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '6blCpn'
    hls_f_d_0 = HlsFD(str_0, str_0)
    var_0 = hls_f_d_0.real_download(str_0, hls_f_d_0)
    print(var_0)



if __name__ == '__main__':
    test_case_0()
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:36:05.204923
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'p\ny:ZrzRm'
    hls_f_d_0 = HlsFD(str_0, str_0)
    var_0 = hls_f_d_0.can_download(str_0, hls_f_d_0)
    hls_f_d_0.real_download('u', hls_f_d_0)
