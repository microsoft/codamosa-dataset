

# Generated at 2022-06-26 11:26:48.120260
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    hls_f_d_0 = None
    hls_f_d_1 = HlsFD(False, hls_f_d_0)
    hls_f_d_2 = HlsFD(False, hls_f_d_0)
    hls_f_d_3 = HlsFD(False, hls_f_d_0)
    hls_f_d_4 = HlsFD(False, hls_f_d_0)
    hls_f_d_5 = HlsFD(False, hls_f_d_0)
    hls_f_d_6 = HlsFD(False, hls_f_d_0)
    hls_f_d_7 = HlsFD(False, hls_f_d_0)
    hls_f

# Generated at 2022-06-26 11:26:52.321947
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    try:
        result = test_HlsFD_real_download.result
    except AttributeError:
        result = test_HlsFD_real_download.result = True
    assert result, 'Failed test_HlsFD_real_download'


# Generated at 2022-06-26 11:26:54.020401
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:26:55.520450
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:27:06.446858
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    true = True
    false = False
    hls_f_d_0 = HlsFD(true, true)
    hls_f_d_1 = HlsFD(false, true)
    hls_f_d_2 = HlsFD(false, false)
    hls_f_d_3 = HlsFD(true, false)
    hls_f_d_4 = HlsFD(false, false)
    hls_f_d_5 = HlsFD(false, false)
    hls_f_d_6 = HlsFD(true, false)
    hls_f_d_7 = HlsFD(false, false)
    hls_f_d_8 = HlsFD(false, false)
    hls_f_d_9 = HlsFD(false, false)

# Generated at 2022-06-26 11:27:15.634741
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    manifest = u'#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="https://example.com/key"\n#EXTINF:10,\nfileSequence0.ts\n#EXT-X-ENDLIST'
    info_dict = dict()
    info_dict['url'] = u'http://example.com/manifest.m3u8'
    assert HlsFD.can_download(manifest, info_dict)
    assert not HlsFD.can_download(manifest, dict({u'is_live': True}, **info_dict))

# Generated at 2022-06-26 11:27:17.125545
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:27:18.158517
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:27:20.233844
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()


if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:27:27.841499
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    bool_0 = False
    hls_f_d_3 = None
    hls_f_d_2 = HlsFD(bool_0, hls_f_d_3)
    filename_0 = 'plzdownload.mp3'
    info_dict_0 = {}

# Generated at 2022-06-26 11:28:13.208697
# Unit test for constructor of class HlsFD
def test_HlsFD():
    bool_0 = False
    hls_f_d_0 = None
    test_case_0()
    return 0


# Generated at 2022-06-26 11:28:14.421136
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:28:23.211588
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # ARRANGE
    hls_f_d_0 = HlsFD.can_download('#EXTM3U\r\n#EXTINF:10,\r\nhttp://www.example.com\r\n#EXT-X-ENDLIST', False)
    hls_f_d_1 = HlsFD(True, True)

    # ACT
    bool_0 = hls_f_d_1.real_download('filename', 'url=http://www.example.com')

    # ASSERT
    assert bool_0 == True
    assert hls_f_d_0
    assert hls_f_d_1

# Generated at 2022-06-26 11:28:26.025310
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    result = True
    actual_result = False
    try:
        test_case_0()
    except:
        result = False
    if result:
        actual_result = True
    assert actual_result

# Generated at 2022-06-26 11:28:32.104998
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-26 11:28:36.339199
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():

    hls_f_d_0 = HlsFD()
    real_download(hls_f_d_0, "filename", "info_dict")

test_case_0()
test_HlsFD_real_download()

# Generated at 2022-06-26 11:28:37.546812
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()


# Generated at 2022-06-26 11:28:39.608310
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('', {'url': 'https://example.com/'}) == True


# Generated at 2022-06-26 11:28:40.867671
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert True

# Generated at 2022-06-26 11:28:52.584631
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-26 11:29:19.527197
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert False # TODO: implement your test here


# Generated at 2022-06-26 11:29:28.548500
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '8'
    str_1 = 'jhMMYBr'
    str_2 = 'jnk'
    str_3 = 'Bsm_,o'
    str_4 = '7V>@xm'
    hls_f_d_0 = HlsFD(str_2, str_0)
    var_0 = hls_f_d_0.params
    var_1 = var_0['fragment_retries']
    var_2 = hls_f_d_0.real_download(str_4, str_3)



# Generated at 2022-06-26 11:29:38.794596
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'C\\B.5^>%Y@+'
    hls_f_d_0 = HlsFD(str_0, str_0)
    assert hls_f_d_0.FD_NAME == 'hlsnative'
    assert hls_f_d_0.to_screen == str_0
    assert hls_f_d_0.ydl == str_0
    # assert hls_f_d_0._progress_hooks == list()
    # assert hls_f_d_0._frag_index == 0
    # assert hls_f_d_0._fragment_retries == 0
    # assert hls_f_d_0._retry_fragments == True
    # assert hls_f_d_0._skip_unavailable_fr

# Generated at 2022-06-26 11:29:42.628365
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'C\\B.5^>%Y@+'
    hls_f_d_0 = HlsFD(str_0, str_0)
    var_0 = hls_f_d_0.real_download(str_0, str_0)

# Generated at 2022-06-26 11:29:47.525940
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    str_0 = 'C\\B.5^>%Y@+'
    hls_f_d_0 = HlsFD(str_0, str_0)
    var_0 = hls_f_d_0.can_download(str_0, str_0)
    assert var_0 == True

# This function tests the ability of HlsFD to download a valid HLS stream.

# Generated at 2022-06-26 11:29:49.807571
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:29:52.329516
# Unit test for constructor of class HlsFD
def test_HlsFD():
    expected = 'dummy_string'

    hls_fd = HlsFD('dummy_string', 'dummy_string')
    assert expected == hls_fd.fd_name



# Generated at 2022-06-26 11:30:00.929625
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'C\\B.5^>%Y@+'
    hls_f_d_0 = HlsFD(str_0, str_0)
    var_0 = hls_f_d_0.can_download(str_0, str_0)
    var_1 = hls_f_d_0.real_download(str_0, str_0)
    var_2 = hls_f_d_0.real_download(str_0, str_0)
    if var_0:
        print(var_1)
    else:
        print(var_2)

# Generated at 2022-06-26 11:30:05.401846
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD('www.website.com', 'www.website.com')
    # 1. test with file that exists and has a readable format
    success = hls_f_d_0.real_download('filename', 'info_dict')
    assert(success, 'test failed because it returned false when it should have returned true')
    # 2. test with file that exists but has an unreadable format (this won't happen)
    success = hls_f_d_0.real_download('filename', 'info_dict')
    assert(success, 'test failed because it returned false when it should have returned true')
    # 3. test with file that doesn't exist
    success = hls_f_d_0.real_download('filename', 'info_dict')

# Generated at 2022-06-26 11:30:06.485199
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    test_case_0()


# Generated at 2022-06-26 11:31:02.683737
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD(None, {'fragment_retries': 0})
    hls_f_d_0.real_download('test', {'test': True})
    hls_f_d_0._finish_frag_download({'test': True})


# Generated at 2022-06-26 11:31:12.028639
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'C\\B.5^>%Y@+'

# Generated at 2022-06-26 11:31:21.377039
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-26 11:31:24.838401
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD('p*C%\\R', 'http://localhost')
    hls_f_d_0.real_download('3!d^\\J', 'http://localhost')


# Generated at 2022-06-26 11:31:26.233389
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Constructor of class HlsFD
    obj = HlsFD(None, None)


# Generated at 2022-06-26 11:31:32.255358
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # These values are taken from the YouTube player
    test_manifest = (
        '#EXTM3U\n'
        '#EXT-X-VERSION:5\n'
        '#EXT-X-TARGETDURATION:5\n'
        '#EXT-X-MEDIA-SEQUENCE:0\n'
        '#EXT-X-PLAYLIST-TYPE:VOD\n'
        '#EXT-X-MAP:URI="init.mp4",BYTERANGE="616@0"\n'
        '#EXTINF:4.064000,\n'
        '#EXT-X-BYTERANGE:121090@616\n'
        'main.mp4\n'
    )

# Generated at 2022-06-26 11:31:34.849339
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_var_0 = 'C\\B.5^>%Y@+'

    hls_f_d_var_0 = HlsFD(str_var_0, str_var_0)



# Generated at 2022-06-26 11:31:39.472523
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'C\\B.5^>%Y@+'
    hls_f_d_0 = HlsFD(str_0, str_0)
    hls_f_d_0.real_download('C\\B.5^>%Y@+', str_0)

test_case_0()
test_HlsFD_real_download()

# Generated at 2022-06-26 11:31:41.092521
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:31:44.278711
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'C\\B.5^>%Y@+'
    hls_f_d_0 = HlsFD(str_0, str_0)
    var_0 = hls_f_d_0.real_download(str_0, str_0)

# Generated at 2022-06-26 11:34:29.675895
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'C\\B.5^>%Y@+'
    hls_f_d_0 = HlsFD(str_0, str_0)
    str_1 = str_0
    str_2 = str_0
    var_0 = hls_f_d_0.real_download(str_1, str_2)

# Generated at 2022-06-26 11:34:34.106676
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'C\\B.5^>%Y@+'
    hls_f_d_0 = HlsFD(str_0, str_0)
    var_0 = hls_f_d_0.real_download(str_0, str_0)

# Generated at 2022-06-26 11:34:34.908025
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()


# Generated at 2022-06-26 11:34:43.704379
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'C\\B.5^>%Y@+'
    str_1 = 'C\\B.5^>%Y@+'
    str_2 = 'C\\B.5^>%Y@+'
    str_3 = 'C\\B.5^>%Y@+'
    str_4 = 'C\\B.5^>%Y@+'
    hls_f_d_0 = HlsFD(str_0, str_1)
    # Call method real_download of class HlsFD
    hls_f_d_0.real_download(str_2, str_3)
    str_5 = 'C\\B.5^>%Y@+'
    str_6 = 'C\\B.5^>%Y@+'

# Generated at 2022-06-26 11:34:50.002071
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    real_download_expected_0 = True
    try:
        hls_f_d_0 = HlsFD('', '')
        hls_f_d_0.real_download(str_0, str_0)
    except:
        real_download_actual_0 = False
    assert(real_download_expected_0 == real_download_actual_0)


# Generated at 2022-06-26 11:34:51.844499
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert(can_decrypt_frag == True)


# Generated at 2022-06-26 11:34:53.171870
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert True

test_case_0()

# Generated at 2022-06-26 11:34:58.201174
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Test with false argument and no return value
    HlsFD.real_download(False, False)
    # Test with false argument and false return value
    HlsFD.real_download(False, False)
    # Test with false argument and true return value
    HlsFD.real_download(False, True)
    # Test with true argument and no return value
    HlsFD.real_download(True, False)
    # Test with true argument and false return value
    HlsFD.real_download(True, False)
    # Test with true argument and true return value
    HlsFD.real_download(True, True)

# Generated at 2022-06-26 11:35:03.060565
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD(str, str)
    var_0 = hls_f_d_0.real_download(str, str)
    assert var_0 == True

# Generated at 2022-06-26 11:35:06.327737
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'C\\B.5^>%Y@+'
    str_1 = 'C\\B.5^>%Y@+'
    hls_f_d_0 = HlsFD(str_0, str_1)