

# Generated at 2022-06-26 11:26:55.461897
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    bool_0 = True
    str_0 = 'Jh'
    dict_0: dict = dict()
    str_1 = '`o'
    dict_1: dict = dict()
    dict_0['_decryption_key_url'] = str_1
    dict_0['extra_param_to_segment_url'] = 'Yy-3'
    dict_0['_type'] = 'http'
    dict_0['url'] = 'http://71.46.41.128:1935/live/wttw_main/live_2.m3u8'
    dict_0['is_live'] = bool_0
    str_2 = 'e0'
    dict_0['http_headers'] = dict()
    dict_0['http_headers']['User-Agent'] = 'e0'

# Generated at 2022-06-26 11:27:00.050513
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:27:10.321973
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '/tmp/t/youtube-dl/YGtNuV7yCk4/maxresdefault.jpg'
    str_1 = 'YGtNuV7yCk4.f248.mp4'
    bool_0 = True
    hls_f_d_0 = HlsFD(bool_0, str_0)
    dict_0 = {'url': str_1}
    return hls_f_d_0.real_download(str_0, dict_0)

test_case_0()
test_HlsFD_real_download()

# Generated at 2022-06-26 11:27:13.607116
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    instance = test_case_0()
    bool_0 = False
    str_0 = 'Wm_-8'
    dict_0 = {}
    instance._download_fragment(bool_0, str_0, dict_0)

# Generated at 2022-06-26 11:27:15.877740
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, None)

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:27:17.280516
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Testing this method with different sets of arguments
    pass


# Generated at 2022-06-26 11:27:25.957670
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download('', {'url': ''}) == False
    assert HlsFD.can_download('', {'url': '', 'is_live': True}) == False
    assert HlsFD.can_download('', {'url': '', 'extra_param_to_segment_url': ''}) == False
    assert HlsFD.can_download('', {'url': '', '_decryption_key_url': ''}) == False
    assert HlsFD.can_download('', {'url': '',
                                 'is_live': True,
                                 'extra_param_to_segment_url': '',
                                 '_decryption_key_url': ''}) == False

# Generated at 2022-06-26 11:27:30.871312
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD()
    str_0 = 'U6o'
    str_1 = '-TDs'
    bool_0 = hls_f_d_0.real_download(str_0, str_1)



# Generated at 2022-06-26 11:27:31.845875
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()


# Generated at 2022-06-26 11:27:34.680001
# Unit test for constructor of class HlsFD
def test_HlsFD():
    bool_0 = False
    str_0 = 'Y.1'
    hls_f_d_0 = HlsFD(bool_0, str_0)


# Generated at 2022-06-26 11:28:02.190465
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'encrypted'
    int_0 = 1121
    str_1 = 'dummy'
    dict_0 = {str_0: str_1, str_1: str_1}
    str_2 = 'n-*e-*'
    hls_f_d_0 = HlsFD(int_0, str_2)
    str_3 = str_2
    str_4 = 'encrypt'
    dict_0['_decryption_key_url'] = str_1
    dict_0['url'] = str_4
    int_1 = 1
    dict_1 = {'is_live': int_1}
    dict_2 = {'http_headers': dict_1}
    dict_2['url'] = str_4

# Generated at 2022-06-26 11:28:13.030827
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    req_url = 'https://www.youtube.com'
    url = 'https://www.youtube.com'

# Generated at 2022-06-26 11:28:17.081008
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD(None, None)
    hls_f_d_0.real_download(None, None)

if __name__ == '__main__':
    test_case_0()
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:28:27.254806
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'Cd%>TJ0a1'
    str_1 = 'm[e\'"m_sC'
    int_0 = 0
    str_2 = 'Gvw8QxWG^'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    hls_f_d_0 = HlsFD(int_0, str_0)
    var_0 = hls_f_d_0.real_download(str_1, dict_0)
    var_0 = hls_f_d_0.real_download(str_2, dict_0)


test_case_0()
test_HlsFD_real_download()

# Generated at 2022-06-26 11:28:33.762020
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'E"83#HFoYHb?'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    int_0 = 1020
    hls_f_d_0 = HlsFD(int_0, str_0)


# Generated at 2022-06-26 11:28:36.244764
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:28:41.801944
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'E"83#HFoYHb?'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    int_0 = 1020
    hls_f_d_0 = HlsFD(int_0, str_0)
    var_0 = hls_f_d_0.real_download(str_0, dict_0)

# Generated at 2022-06-26 11:28:54.995600
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_fd_0 = HlsFD(None, 'O\xD2\xB2\xEF\xF6\xD0\xBD\xBA')
    if type(hls_fd_0) is not HlsFD:
        raise Exception('Test case failed: Expected type: HlsFD. Actual type: %s' % type(hls_fd_0))
    if hls_fd_0.ydl is not None:
        raise Exception('Test case failed: Expected instance attribute ydl: None. Actual instance attribute ydl: %s' % hls_fd_0.ydl)

# Generated at 2022-06-26 11:29:04.554103
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'E"83#HFoYHb?'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    int_0 = 1020
    hls_f_d_0 = HlsFD(int_0, str_0)
    str_1 = 'E"83#HFoYHb?'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    dict_2 = {'method': 'NONE', 'URI': str_0, 'IV': str_0}
    hls_f_d_0.real_download(str_1, dict_1)

# Generated at 2022-06-26 11:29:11.841170
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
  str_0 = "=g9X8nZW[kvR["
  dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
  int_0 = 2936
  hls_f_d_0 = HlsFD(int_0, str_0)
  var_0 = hls_f_d_0.real_download(str_0, dict_0)

# Generated at 2022-06-26 11:29:39.800339
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass

# Generated at 2022-06-26 11:29:44.375634
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'E#5E)#(p5C%'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    int_0 = 1020
    hls_f_d_0 = HlsFD(int_0, str_0)
    hls_f_d_0.real_download(str_0, dict_0)

# Generated at 2022-06-26 11:29:49.851850
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'E"83#HFoYHb?'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    int_0 = 1020
    hls_f_d_0 = HlsFD(int_0, str_0)


# Generated at 2022-06-26 11:29:51.132566
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Unit test
test_HlsFD()

# Generated at 2022-06-26 11:29:57.068449
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # arguments
    str_0 = 'E"83#HFoYHb?'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    int_0 = 1020
    hls_f_d_0 = HlsFD(int_0, str_0)
    var_0 = hls_f_d_0.real_download(str_0, dict_0)

# Generated at 2022-06-26 11:30:02.666488
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '?'
    int_0 = 0
    hls_f_d_0 = HlsFD(int_0, str_0)
    hls_f_d_0.real_download(str_0, str_0)

test_case_0()
test_HlsFD_real_download()

# Generated at 2022-06-26 11:30:12.561661
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    info_dict = {'url': ''}

    # Testing with unsupported encrypted stream
    manifest = '#EXT-X-KEY:URI="http://key.com",METHOD=AES-128\n'
    assert not HlsFD.can_download(manifest, info_dict)

    # Testing with unsupported live stream
    manifest = '#EXT-X-MEDIA-SEQUENCE:100\n'
    assert not HlsFD.can_download(manifest, info_dict)

    # Testing with supported stream
    manifest = '#EXT-X-KEY:URI="http://key.com",METHOD=NONE\n#EXT-X-MEDIA-SEQUENCE:0\n'
    assert HlsFD.can_download(manifest, info_dict)

# Generated at 2022-06-26 11:30:20.802511
# Unit test for constructor of class HlsFD
def test_HlsFD():
    int_0 = 8
    str_0 = 'lJ^Q#1|"==4X9c%\'x'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    hls_f_d_0 = HlsFD(int_0, str_0)
    assert_equal(dict_0, dict_0)
    assert_equal(str_0, str_0)
    assert_equal(int_0, int_0)

if __name__ == '__main__':
    from nose.tools import assert_equal
    test_HlsFD()

# Generated at 2022-06-26 11:30:24.642518
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():

    hls_f_d_0 = HlsFD();
    dict_0 = {'url': 'url'}
    str_0 = ''
    hls_f_d_0.real_download(str_0, dict_0)


# Generated at 2022-06-26 11:30:32.310518
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'E"83#HFoYHb?'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    int_0 = 1020
    hls_f_d_0 = HlsFD(int_0, str_0)
    var_0 = hls_f_d_0.real_download(str_0, dict_0)


# unit test for class HlsFD

# Generated at 2022-06-26 11:31:53.363946
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    if not can_decrypt_frag:
        return

# Generated at 2022-06-26 11:31:58.933670
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    bytes_0 = b'+\xc9\x85E\xf0\xc7\xcbb'
    str_0 = '1024'
    hls_f_d_0 = HlsFD(bytes_0, str_0)
    var_0 = hls_f_d_0.can_download(str_0, bytes_0)

# Generated at 2022-06-26 11:32:01.885420
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    bytes_0 = b'\x80'
    str_0 = 'oTUMqxrCHwhw'
    bytes_1 = b'\x80'
    bytes_2 = b'\x00'
    hls_f_d_0

# Generated at 2022-06-26 11:32:07.029630
# Unit test for constructor of class HlsFD
def test_HlsFD():
    bytes_0 = b'+\xc9\x85E\xf0\xc7\xcbb'
    str_0 = '1024'
    hls_f_d_0 = HlsFD(bytes_0, str_0)
    assert hls_f_d_0 is not None
    assert hls_f_d_0._real_download is None


# Generated at 2022-06-26 11:32:15.293300
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    try:
        import botocore.session
        botocore_found = True
    except ImportError:
        botocore_found = False
    if botocore_found:
        import botocore.exceptions
        class MockAWSPolicy(object):
            def __init__(self):
                self.policy = {}
                self.policy['Statement'] = []
                statement = {'Action': '', 'Effect': '', 'Resource': ''}
                self.policy['Statement'].append(statement)

            def get_policy(self, bucket_name):
                self.policy['Statement'][0]['Action'] = 's3:GetObject'
                self.policy['Statement'][0]['Effect'] = 'Deny'

# Generated at 2022-06-26 11:32:27.641058
# Unit test for constructor of class HlsFD
def test_HlsFD():
    bytes_0 = b'+\xc9\x85E\xf0\xc7\xcbb'
    str_0 = '1024'
    # Input parameters to the constructor are: (1) string, (2) string
    hls_f_d_1 = HlsFD(bytes_0, str_0)
    # Input parameters to the constructor are: (1) string, (2) string
    hls_f_d_0 = HlsFD(bytes_0, str_0)
    bytes_2 = b'+\xc9\x85E\xf0\xc7\xcbb'
    str_1 = '1024'
    var_0 = hls_f_d_0.can_download(str_0, bytes_0)
    # Deliberately set the 'is_live' property to true to trigger fall

# Generated at 2022-06-26 11:32:35.583950
# Unit test for constructor of class HlsFD
def test_HlsFD():
    bytes_0 = b'Y\x02\x0c\x9b\x97\x82\xf1'
    str_0 = 'some_data'
    hls_f_d_0 = HlsFD(bytes_0, str_0)
    bytes_1 = b'z\xa4\xbc\x87\x9d\x92\x8e\xfb\xd2\xdf\xf2\x8a\xef\xbd'
    str_1 = 'another_data'
    hls_f_d_1 = HlsFD(bytes_1, str_1)
    str_2 = 'my_data'
    hls_f_d_2 = HlsFD(bytes_1, str_2)
    str_3 = 'more_data'
    hls_

# Generated at 2022-06-26 11:32:45.723312
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-26 11:32:47.983739
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert HlsFD.real_download(HlsFD(), 'filename', 'info_dict') != False


# Generated at 2022-06-26 11:32:56.788526
# Unit test for constructor of class HlsFD
def test_HlsFD():
    bytes_1 = b'\x7f\x9a\x7f\xe5\tr\xea\x88\x7f\x03\x07\x9e\xcf\xf3\x04\x11\x87'
    bytes_2 = b'l\x1f\xf1\xd0\xfd\x0e\xb7\x8a\xf6\xab\x81\xed\xa4\x06\xb4\x00'
    bytes_3 = b'\xba\x83\xb3\x11\xa9\xee\xd1\xce\xfb\xeb\x87\xe8\x7f\x03\xf3\x9a'

# Generated at 2022-06-26 11:35:47.731888
# Unit test for constructor of class HlsFD
def test_HlsFD():
    a = 'http://my.example.com/mystream.m3u8'
    b = {'http_headers': {'X-Foo': 'Bar', 'Y-Foo': 'Baz'}}
    test_case_0()

# Note: the ffmpeg compat-code is not implemented (only the native downloader)

# FFmpegFD = lambda *args, **kwargs: None # disable the ffmpeg HLS downloader
# test_HlsFD()

# Generated at 2022-06-26 11:35:54.443801
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # From one of the HLS tests, modified slightly
    # so we can test with pycrypto present and absent.
    hls_url = 'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8'

# Generated at 2022-06-26 11:36:02.894230
# Unit test for constructor of class HlsFD
def test_HlsFD():
    bytes_0 = b'\xab\x90\xbb\x8c\x9e\xfb\x90\xaa\xd6\xab\x07\x80\xdd\x8fN\xc9\xdc\xdc\x83\x01\x8f\x92\x80\xbb\x8c\x9e\xfb\x90\xaa\xd6\xab\x07\x80\xdd\x8fN\xc9\xdc\xdc\x83\x01\x8f\x92'

# Generated at 2022-06-26 11:36:11.179627
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    len_1 = len
    exception_0 = Exception
    class_0 = HlsFD
    bytes_0 = b'123456'
    str_0 = 'abcdef'
    str_1 = 'ghijkl'
    hls_f_d_0 = class_0(bytes_0, str_0)
    hls_f_d_1 = hls_f_d_0.real_download(str_0, str_1)
    var_0 = hls_f_d_0.real_download(str_0, str_1)
    var_1 = len_1(str_0)
    str_2 = '123456'
    list_0 = [str_0, str_1, str_2]

# Generated at 2022-06-26 11:36:15.463535
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    real_download_0 = HlsFD.real_download
    filename_0 = ''
    info_dict_0 = {}
    # AssertionError is expected
    with pytest.raises(AssertionError):
        real_download_0(filename_0, info_dict_0)

if __name__ == '__main__':
    test_case_0()

    # Testing real_download of class HlsFD
    test_HlsFD_real_download()