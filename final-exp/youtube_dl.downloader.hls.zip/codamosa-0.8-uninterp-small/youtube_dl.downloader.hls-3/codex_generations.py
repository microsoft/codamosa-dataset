

# Generated at 2022-06-26 11:26:55.782518
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    bytes_0 = b'\xfd\x95\xbd\r\x98\xa0i\xf3\xad\\\x87\x82'
    float_0 = -28.11
    hls_f_d_0 = HlsFD(bytes_0, float_0)
    str_0 = hls_f_d_0.can_download()
    str_1 = hls_f_d_0.can_download()
    str_2 = hls_f_d_0.can_download()
    str_3 = hls_f_d_0.can_download()


# Generated at 2022-06-26 11:26:57.827524
# Unit test for constructor of class HlsFD
def test_HlsFD():
    string_0 = 'iul'
    string_1 = '7c9'
    value_0 = HlsFD(string_0, string_1)
    assert isinstance(value_0, HlsFD) is True


# Generated at 2022-06-26 11:26:58.679484
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    test_case_0()

# Generated at 2022-06-26 11:27:00.634573
# Unit test for constructor of class HlsFD
def test_HlsFD():
    '''
    # Constructor for class HlsFD
    '''
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:27:07.295898
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    float_0 = -27.998886
    bytes_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    hls_f_d_0 = HlsFD(bytes_0, float_0)
    hls_f_d_0._decode_fragment(bytes_1)
    hls_f_d_0._prepare_url()
    hls_f_d_0._finish

# Generated at 2022-06-26 11:27:09.674371
# Unit test for constructor of class HlsFD
def test_HlsFD():
    bytes_0 = b'\xfd\x95\xbd\r\x98\xa0i\xf3\xad\\\x87\x82'
    float_0 = -28.11
    hls_f_d_0 = HlsFD(bytes_0, float_0)

# Generated at 2022-06-26 11:27:19.679634
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    bytes_0 = b'\xfd\x95\xbd\r\x98\xa0i\xf3\xad\\\x87\x82'
    float_0 = -28.11
    hls_f_d_0 = HlsFD(bytes_0, float_0)
    bytes_1 = b'\xad\xfb6>\xf6\xce\xe3\xf2\x0e\xe7V\x9d\x7f'
    bytes_2 = b'\xfd\x95\xbd\r\x98\xa0i\xf3\xad\\\x87\x82'
    hls_f_d_0.real_download(bytes_1, bytes_2)

test_case_0()

# Generated at 2022-06-26 11:27:21.006427
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Class HlsFD has no constructor
    test_case_0()


# Generated at 2022-06-26 11:27:21.724932
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass


# Generated at 2022-06-26 11:27:28.782818
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """
    Args:
        bytes_0 (bool): a
        float_0 (bool): b

    Returns:
        None

    Raises:
        None
    """
    bytes_0 = b'\xfd\x95\xbd\r\x98\xa0i\xf3\xad\\\x87\x82'
    float_0 = -28.11
    hls_f_d_0 = HlsFD(bytes_0, float_0)

test_case_0()
test_HlsFD()

# Generated at 2022-06-26 11:27:48.894738
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:27:50.862991
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()



# Generated at 2022-06-26 11:27:57.008193
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # This could be done without the need of a temporary file
    filename = 'tmp_hls_file'
    info_dict = {
        'url': 'https://example.com/root_manifest.m3u8',
        'extra_param_to_segment_url': '',
    }
    test_case_0()

if __name__ == '__main__':
    print('Executing unit tests for HlsFD')
    test_HlsFD_real_download()
    print('Tests completed')

# Generated at 2022-06-26 11:28:03.688076
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Test 0:
    #
    # test_case_0()
    #
    # Input:
    #
    # bytes_0 = None
    #
    # float_0 = 1498.3
    #
    # str_0 = "if tuple(len(p) for p in s.split('.')) == %s:\n    return %s\n"
    #
    # tuple_0 = ()
    #
    # Output:
    #
    # hls_f_d_0 = HlsFD(tuple_0, float_0)
    #
    # var_0 = hls_f_d_0.can_download(bytes_0, str_0)
    #
    test_case_0()


# Generated at 2022-06-26 11:28:10.075014
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    tuple_0 = ()
    float_0 = 1498.3
    hls_f_d_0 = HlsFD(tuple_0, float_0)
    str_0 = None
    str_1 = hls_f_d_0.real_download(str_0, tuple_0)
    assert_equal(str_1, False)
    print('Tests passed!')

# Generated at 2022-06-26 11:28:12.242754
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD(None, 0)
    assert hls_f_d_0.can_download() == True

# Generated at 2022-06-26 11:28:14.119759
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        test_case_0()
    except Exception:
        return False
    return True

# Generated at 2022-06-26 11:28:17.627842
# Unit test for constructor of class HlsFD
def test_HlsFD():
    tuple_0 = ()
    float_0 = 1498.3
    hls_f_d_0 = HlsFD(tuple_0, float_0)
    assert hls_f_d_0._prepare_url



# Generated at 2022-06-26 11:28:27.727990
# Unit test for constructor of class HlsFD
def test_HlsFD():
    bytes_0 = str_0 = 'm3u8 manifest'
    float_0 = 1498.3
    tuple_0 = ()
    hls_f_d_0 = HlsFD(tuple_0, float_0)
    assert hls_f_d_0.FD_NAME == 'hlsnative', 'Constructor of class HlsFD initializes attribute FD_NAME incorrectly'
    assert (
        hls_f_d_0.params == {'fragment_retries': 0, 'skip_unavailable_fragments': True, 'test': False}
    ), 'Initializes class HlsFD params incorrectly'
    assert hls_f_d_0.can_download(bytes_0, str_0)

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:28:35.283338
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    bytes_0 = None
    str_0 = "if tuple(len(p) for p in s.split('.')) == %s:\n    return %s\n"
    tuple_0 = ()
    float_0 = 1498.3
    hls_f_d_0 = HlsFD(tuple_0, float_0)
    bytes_1 = bytearray(0)
    hls_f_d_0.real_download(bytes_0, str_0)

# Generated at 2022-06-26 11:28:50.799266
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:29:00.771859
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '\x0c\n\x1b\x1b#\x1a\x1a\x17\x15'
    float_0 = -3486.46
    hls_f_d_0 = HlsFD(float_0, float_0)
    float_1 = -1799.8019
    var_0 = hls_f_d_0.can_download(str_0, float_1)
    float_2 = -2440.29077
    str_1 = '\x1f\x11\x03\x00\x01\x02\x0c\r\x1d'

# Generated at 2022-06-26 11:29:01.794407
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:29:03.887304
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:29:11.627273
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '[^k\n\trZXwf'
    float_0 = -1296.2174
    hls_f_d_0 = HlsFD(float_0, float_0)
    float_1 = -2421.5953848727054
    hls_f_d_0.real_download(float_0, str_0)

if __name__ == '__main__':
    test_case_0()
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:29:16.307570
# Unit test for constructor of class HlsFD
def test_HlsFD():
    float_0 = -1296.2174
    float_1 = -2421.5953848727054
    hls_f_d_0 = HlsFD(float_0, float_1)
    hls_f_d_0.add_progress_hook(test_case_0)

test_HlsFD()


# Generated at 2022-06-26 11:29:19.634141
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        test_case_0()
    except Exception as err:
        print('FAILED TEST CASE: HlsFD ' + str(err))

test_HlsFD()

# Generated at 2022-06-26 11:29:22.151437
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ydl_0 = YoutubeDL(None)
    hls_f_d_0 = HlsFD(ydl_0, {})


# Generated at 2022-06-26 11:29:27.460806
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Default object creation
    hls_f_d_0 = HlsFD()
    assert hls_f_d_0 is not None
    # Creation with default constructor
    # Call to real_download on object hls_f_d_0
    test_case_0()

test_HlsFD()

# Generated at 2022-06-26 11:29:37.794628
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_2 = HlsFD(None, None)

# Generated at 2022-06-26 11:30:14.986401
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # After the constructor of class HlsFD is called, the variable `FD_NAME` should be equal to `hlsnative`.
    hls_fd = HlsFD('test', 'test')
    assert hls_fd.FD_NAME == 'hlsnative'



# Generated at 2022-06-26 11:30:17.145181
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # test_case_0()
    assert True

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:30:21.102333
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD(0, 0)
    assert hls_f_d_0
    assert hls_f_d_0.can_download
    assert hls_f_d_0.real_download

# Generated at 2022-06-26 11:30:24.884827
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d = HlsFD()

# Generated at 2022-06-26 11:30:31.078911
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = "if tuple(len(p) for p in s.split('.')) == %s:\n    return %s\n"
    float_0 = 1498.3
    hls_f_d_0 = HlsFD(float_0, float_0)
    hls_f_d_0.real_download(float_0, str_0)



# Generated at 2022-06-26 11:30:31.998593
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:30:40.386555
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = "if tuple(len(p) for p in s.split('.')) == %s:\n    return %s\n"
    float_0 = 1498.3
    hls_f_d_0 = HlsFD(float_0, float_0)
    assert hls_f_d_0.FR_COUNT == 2
    assert hls_f_d_0.FD_NAME == 'hlsnative'
    assert hls_f_d_0.params == float_0
    assert hls_f_d_0.ydl == float_0


# Generated at 2022-06-26 11:30:41.219892
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:30:42.656401
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:30:44.406873
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert True

if __name__ == '__main__':
    #test_case_0()
    test_HlsFD()

# Generated at 2022-06-26 11:32:19.480657
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:32:20.143882
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:32:21.164085
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()



# Generated at 2022-06-26 11:32:24.453644
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD(0, 0).params is None
    assert HlsFD(0, 0).ydl is None
    assert HlsFD(0, 0)._progress_hooks is not None


# Generated at 2022-06-26 11:32:29.454087
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # hls_f_d = HlsFD(1498.3, 1498.3)
    # hls_f_d.real_download(1498.3, "if tuple(len(p) for p in s.split('.')) == %s:\n    return %s\n")
    test_case_0()

if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:32:33.255918
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert(hasattr(HlsFD, 'real_download'))

    # Test: Check that HlsFD.real_download is callable
    if (callable(HlsFD.real_download)):
        print("Method real_download is callable")
    else:
        print("Method real_download is not callable")


# Generated at 2022-06-26 11:32:39.208208
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_fd_0 = HlsFD
    can_download = hls_fd_0.can_download
    real_download = hls_fd_0.real_download
    str_0 = "if tuple(len(p) for p in s.split('.')) == %s:\n    return %s\n"
    float_0 = 1498.3
    hls_f_d_0 = HlsFD(float_0, float_0)
    var_0 = hls_f_d_0.can_download(str_0, float_0)
    var_1 = hls_f_d_0.real_download(float_0, str_0)


test_case_0()
test_HlsFD()

# Generated at 2022-06-26 11:32:49.149367
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '#EXTM3U\n#EXT-X-VERSION:2\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=254000\nhigh.m3u8\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=139000\nlow.m3u8\n'
    float_0 = 'https://c.brightcove.com/services/mobile/streaming/index/master.m3u8?videoId=5209405705001&pubId=5598237372001&secure=true'
    hls_f_d_0 = HlsFD(float_0, float_0)

# Generated at 2022-06-26 11:32:56.517941
# Unit test for constructor of class HlsFD
def test_HlsFD():
    float_0 = 1498.3
    float_1 = 37.2
    hls_f_d_0 = HlsFD(float_0, float_1)
    assert hls_f_d_0.get_params() == float_1
    assert hls_f_d_0.params == float_1
    assert hls_f_d_0.ydl == float_0
    assert hls_f_d_0.FD_NAME == 'hlsnative'
    assert not hls_f_d_0.finished
    assert hls_f_d_0._progress_hooks == []


# Generated at 2022-06-26 11:32:58.267152
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()