

# Generated at 2022-06-26 11:26:45.024147
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Prepare the test case
    int_0 = 10800
    set_0 = {15.12, 0.62}
    str_0 = "http://www.example.com/test.mp4"
    str_1 = str_0
    str_2 = str_0
    str_3 = str_1
    int_1 = 106
    int_2 = 101
    int_3 = 115
    int_4 = 116
    int_5 = 105
    int_6 = 111
    int_7 = 110
    int_8 = 44
    int_9 = 110
    int_10 = 97
    int_11 = 109
    int_12 = 101
    int_13 = 61
    int_14 = 116
    int_15 = 101
    int_16 = 115
    int_17 = 116
    int_

# Generated at 2022-06-26 11:26:55.602334
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_dummy = 0
    str_dummy = ''
    dict_dummy = {}

# Generated at 2022-06-26 11:27:04.712103
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 74.73
    set_0 = {float_0, float_0}
    int_0 = 10800
    hls_f_d_0 = HlsFD(set_0, int_0)
    result = hls_f_d_0.real_download("test_file_name", {"url_test": "test_url", "http_headers_test": {"test_header_key": "test_header_value"}, "test_test_test": "test_test_test"})
    assert result == True


# Generated at 2022-06-26 11:27:08.996826
# Unit test for constructor of class HlsFD
def test_HlsFD():
    set_0 = {15.16, 9.45}
    int_0 = 22
    hls_f_d_0 = HlsFD(set_0, int_0)


# Generated at 2022-06-26 11:27:11.344783
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Test case 0
    int_0 = -6
    tup_0 = (0, int_0)
    tup_1 = (0, 0)
    hls_f_d_0 = HlsFD(tup_0, tup_1)


# Generated at 2022-06-26 11:27:15.086555
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD({}, 0)
    expected_0 = False
    actual_0 = hls_f_d_0.real_download({}, {})
    assert actual_0 == expected_0
    pass


# Generated at 2022-06-26 11:27:16.944499
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:27:26.295089
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    url = "https://cf-hls-media.sndcdn.com/media/0/0/1/1/1/1/1/1/1/7/0/0/0/7/0/0/1/0/0/1/1/1_1_1_1_1_1_1_1_1_0_0_1_0/media.m3u8"

# Generated at 2022-06-26 11:27:30.029324
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    #print('Testing real_download in HlsFD.py')
    for i in range(0, 100):
        test_case_0()

test_HlsFD_real_download()

# Generated at 2022-06-26 11:27:32.065937
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # We only test the constructor
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:27:51.744302
# Unit test for constructor of class HlsFD
def test_HlsFD():
    print()
    print('In test_HlsFD')
    hlsfd = HlsFD()


# Generated at 2022-06-26 11:27:52.807938
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    HlsFD.real_download(1, 2)


# Generated at 2022-06-26 11:27:54.457031
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()


# Generated at 2022-06-26 11:28:01.148845
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'https://cf-hls-media.sndcdn.com/media/0/0/1/1/1/1/1/1/1/7/0/0/0/7/0/0/1/0/0/1/1/1_1_1_1_1_1_1_1_1_0_0_1_0/media.m3u8'
    bool_0 = HlsFD.can_download()
    print(bool_0)
    print('test')

if __name__ == '__main__':
	test_HlsFD()

# Generated at 2022-06-26 11:28:02.256551
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, None)


# Generated at 2022-06-26 11:28:03.250082
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert False, "No unit tests"



# Generated at 2022-06-26 11:28:14.323160
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hlsfd = HlsFD(None, None)
    ctx = {'filename': 'test.ts', 'total_frags': 2}
    hlsfd._prepare_and_start_frag_download(ctx)
    hlsfd._append_fragment(ctx, b'Hello, World!')
    hlsfd._append_fragment(ctx, b'Hello, World!')
    hlsfd._finish_frag_download(ctx)
    hlsfd._append_fragment(ctx, b'Hello, World!')
    hlsfd._append_fragment(ctx, b'Hello, World!')
    hlsfd._finish_frag_download(ctx)
    hlsfd._append_fragment(ctx, b'Hello, World!')
    hlsfd._append

# Generated at 2022-06-26 11:28:17.081364
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # M3U8 manifest without unsupported feature
    assert HlsFD.can_download(test_case_0(), {})

test_HlsFD_can_download()

# Generated at 2022-06-26 11:28:21.023008
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Download a .m3u8 playlist that points to a .ts
    # It should be downloaded with ffmpeg, not hlsnative.
    return True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:28:29.479509
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hlsfd = HlsFD({'ydl': None, 'params': None})
    assert hlsfd.FD_NAME == 'hlsnative'

# def test_case_1():
#     str_0 = 'https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8'

# def test_case_2():
#     str_0 = 'http://xenia.media.mit.edu/~cwalter/hls-test-streams/hls_variant_bitrate/hls_variant_800k.m3u8'

# def test_case_3():
#     str_0 = 'http://xenia.media.mit.edu/~cwal

# Generated at 2022-06-26 11:28:49.897848
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert True

    # Use keyword-only argument test
    float_0 = 74.73
    set_0 = {float_0, float_0}
    int_0 = 10800
    hls_f_d_0 = HlsFD(set_0, int_0)
    str_0 = '\x0cW'
    var_0 = hls_f_d_0.real_download(str_0, int_0)


# Generated at 2022-06-26 11:28:56.228204
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        float_0 = 74.73
        set_0 = {float_0, float_0}
        int_0 = 10800
        hls_f_d_0 = HlsFD(set_0, int_0)
    except:
        print('Exception raised!')


if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:28:58.806823
# Unit test for constructor of class HlsFD
def test_HlsFD():
    one = set()
    two = {1, 2, 3}
    assert HlsFD(one, two)

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:29:03.195017
# Unit test for constructor of class HlsFD
def test_HlsFD():
    set_0 = set()
    int_0 = 10800
    hls_f_d_0 = HlsFD(set_0, int_0)
    print(hls_f_d_0.fragment_retries)

test_HlsFD()

# Generated at 2022-06-26 11:29:12.139000
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    print('Starting test_HlsFD_real_download')
    float_2 = 74.73
    set_2 = {float_2, float_2}
    int_2 = 10800
    hls_f_d_2 = HlsFD(set_2, int_2)
    str_2 = '\x0cW'
    int_2 = 10800
    str_2 = '\x0cW'
    hls_f_d_2.real_download(str_2, int_2)
    print('Done with test_HlsFD_real_download')


# Generated at 2022-06-26 11:29:16.918397
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 74.73
    set_0 = {float_0, float_0}
    int_0 = 10800
    hls_f_d_0 = HlsFD(set_0, int_0)
    str_0 = '\x0cW'
    int_1 = hls_f_d_0.real_download(str_0, int_0)

# Generated at 2022-06-26 11:29:23.746412
# Unit test for constructor of class HlsFD
def test_HlsFD():
        float_0 = 74.73
        set_0 = {float_0, float_0}
        int_0 = 10800
        hls_f_d_0 = HlsFD(set_0, int_0)
        str_0 = '\x0cW'
        var_0 = hls_f_d_0.can_download(str_0, int_0)
        # self.assertFalse(var_0)

# Generated at 2022-06-26 11:29:34.603913
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # test 1
    int_0 = 10800
    float_0 = 74.73
    set_0 = {float_0, float_0}
    hls_f_d_0 = HlsFD(set_0, int_0)
    str_0 = '2\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    var_0 = hls_f_d_0.can_download(str_0, int_0)
    assert var_0 == False

    # test 2


# Generated at 2022-06-26 11:29:36.416116
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # TODO: Add code here
    raise NotImplementedError("Test not implemented")

# Generated at 2022-06-26 11:29:44.916573
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    set_0 = {'http://www.youtube.com/watch?v=BaW_jenozKc'}
    int_0 = 10800
    hls_f_d_0 = HlsFD(set_0, int_0)
    info_dict_0 = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    str_0 = '\x0cW'
    bool_0 = hls_f_d_0.can_download(str_0, info_dict_0)
    bool_1 = hls_f_d_0.real_download(bool_0, info_dict_0)
    if not bool_1:
        raise RuntimeError

# Run unit tests
if __name__ == '__main__':
    test_case_0()
   

# Generated at 2022-06-26 11:30:16.534524
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 74.73
    set_0 = {float_0, float_0}
    int_0 = 10800
    hls_f_d_0 = HlsFD(set_0, int_0)
    str_0 = '\x0cW'
    var_0 = hls_f_d_0.real_download(str_0, int_0)

# Generated at 2022-06-26 11:30:23.809278
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 106.509
    str_0 = 'v&8\x0e\x10\x1f\x1b'
    hls_f_d_0 = HlsFD({str_0, float_0}, float_0)
    str_1 = '\x1b\x11\x0f\nt'
    info_dict_0 = {
        'http_headers': {'X-Amz-Cf-Id': 'Ylh5_pDtFA5Ftb5QQzvC9JPlxAvb09O26xE5r5Ytpr5m_Sn5_C_m7g=='},
    }
    str_2 = '\x0f\x1b\x1b\x0f\x0e'
    int_0 = 300

# Generated at 2022-06-26 11:30:28.851006
# Unit test for constructor of class HlsFD
def test_HlsFD():
    float_0 = 74.73
    set_0 = {float_0, float_0}
    int_0 = 10800
    hls_f_d_0 = HlsFD(set_0, int_0)
    assert isinstance(hls_f_d_0, HlsFD)


# Generated at 2022-06-26 11:30:31.964704
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = hls_f_d_0 = HlsFD(1, 2)
    assert hls_f_d_0.FD_NAME == 'hlsnative'

# Generated at 2022-06-26 11:30:34.063694
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD({}, {})
    # Add test here



# Generated at 2022-06-26 11:30:39.860977
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 74.73
    set_0 = {float_0, float_0}
    int_0 = 10800
    hls_f_d_0 = HlsFD(set_0, int_0)
    str_0 = '\x0cW'
    # test_0 = hls_f_d_0.real_download(str_0, int_0)

# Generated at 2022-06-26 11:30:40.806464
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()
    pass

# Generated at 2022-06-26 11:30:46.715765
# Unit test for constructor of class HlsFD
def test_HlsFD():
    set_0 = set()
    int_0 = 10800
    list_0 = []
    hls_f_d_0 = HlsFD(set_0, int_0)
    hls_f_d_0.can_download('', int_0)
    hls_f_d_0.real_download('', int_0)
    hls_f_d_0.report_skip_fragment(int_0)
    str_0 = '\x0cW'
    hls_f_d_0.report_error(str_0)
    str_0 = '\x0cW'
    hls_f_d_0.report_warning(str_0)

# Generated at 2022-06-26 11:30:47.641177
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert True



# Generated at 2022-06-26 11:30:52.463097
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    float_0 = 74.73
    set_0 = {float_0, float_0}
    int_0 = 10800
    hls_f_d_0 = HlsFD(set_0, int_0)
    str_0 = '\x0cW'
    var_0 = hls_f_d_0.can_download(str_0, int_0)


# Generated at 2022-06-26 11:32:06.525960
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-26 11:32:07.497354
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert True



# Generated at 2022-06-26 11:32:09.371762
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()


if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:32:16.396310
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_fd_0 = HlsFD('this_is_a_string', b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    assert hls_fd_0.downloader.ydl == 'this_is_a_string'
    assert hls_fd_0.downloader.params == b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'
    assert hls_fd_0.downloader.tmpfilename is None
    assert hls_fd_

# Generated at 2022-06-26 11:32:28.108161
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Test with a string and a bytes-like object
    # Expected result:
    #     True
    # Comment:
    #     Seems like the can_download method returns True all the time?
    downloader = 'youtube-dl'
    params = b'7\x81\x00\x80'
    hls_f_d_0 = HlsFD(downloader, params)
    result = hls_f_d_0.can_download('test_string', {})
    print('Expected result:')
    print('\tTrue')
    print('Actual result:')
    print('\t%s' % result)
    print()

    # Test with another string and another bytes-like object
    # Expected result:
    #     True
    # Comment:
    #     Same result as the previous test,

# Generated at 2022-06-26 11:32:29.937751
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert callable(HlsFD)
    try:
        test_case_0()
    except NameError:
        print('We have a problem')


# Generated at 2022-06-26 11:32:31.621538
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:32:36.601450
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '6ws!=`P`'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    bytes_0 = b'\xe0\xec8\xe3\x90\xf5\xd05c'
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    hls_f_d_0.real_download(str_0, dict_0)


# Generated at 2022-06-26 11:32:47.908866
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Test case 0
    str_0 = '=doM'
    str_1 = '2rD;'
    str_2 = ':1!d'
    str_3 = '0s\t'
    str_4 = ';wI'
    str_5 = '3b1'
    str_6 = '\t+n'
    str_7 = '%[u'
    str_8 = '8>B'
    str_9 = '5]<'
    str_10 = '\x97Z'
    str_11 = 'g\n\\'
    str_12 = '<\x08'
    str_13 = '\x83'
    str_14 = '\x96'
    str_15 = '\xe3'
    str_16 = '\x12'

# Generated at 2022-06-26 11:32:56.732720
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = ')&!7b'
    int_0 = -511913195
    int_1 = 1607329544
    str_1 = 'R\x02\xef\x8af\xcc\x9bB'
    bytes_0 = b'\x01\x10\x12w\xed\x86\x8e\xf6'
    bytes_1 = b'\xdf\xe4\x83n\x07\x8b\xd1\x9b'
    bytes_2 = b'\x0b\xb3\x05\xec\xf6\x98\x9a\xe2'
    bytes_3 = b'\xc7\xdd\x1a\x90\xe9\x9aN\xa0\xbc'
   

# Generated at 2022-06-26 11:35:50.090008
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '6w\n"s!=`P`'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    hls_f_d_0 = HlsFD(str_0, dict_0)
    var_0 = hls_f_d_0.real_download(str_0, dict_0)
    var_0 = hls_f_d_0.real_download(str_0, dict_0)
    var_0 = hls_f_d_0.real_download(str_0, dict_0)
    var_0 = hls_f_d_0.real_download(str_0, dict_0)
    var

# Generated at 2022-06-26 11:35:50.913432
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert test_case_0() is None


# Generated at 2022-06-26 11:35:56.594725
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_test = '6w\n"s!=`P`'
    dict_test = {str_test: str_test, str_test: str_test, str_test: str_test, str_test: str_test, str_test: str_test}
    hls_f_d_test = HlsFD(str_test, dict_test)
    # check whether the HlsFD object is constructed correctly
    assert hls_f_d_test is not None
    # check whether the real_download method is added to the object
    assert hls_f_d_test.real_download is not None


# Generated at 2022-06-26 11:35:59.754831
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()
    test_DownloadErrorProcessor()

if __name__ == '__main__':
    test_HlsFD()



# vi: set expandtab ts=4 sw=4 :

# Generated at 2022-06-26 11:36:05.075375
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '6w\n"s!=`P`'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    hls_f_d_0 = HlsFD(str_0, dict_0)
    var_0 = hls_f_d_0.real_download(str_0, dict_0)

# Generated at 2022-06-26 11:36:12.571360
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    URL = 'http://example.com/video.m3u8'
    M3U8 = '#EXTM3U\n' + '\n'.join([
        '#EXT-X-KEY:METHOD=AES-128,URI="http://example.com/encryption.key",IV=0xdeadbeefdeadbeef',
        '#EXTINF:10,',
        'fileSequence0.ts',
    ])