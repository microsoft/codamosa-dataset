

# Generated at 2022-06-26 11:26:37.176700
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()


if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:26:39.824595
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = '181.0.0.0/12'
    bool_0 = True
    hls_f_d_0 = HlsFD(str_0, bool_0)


# Generated at 2022-06-26 11:26:40.593137
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()


# Generated at 2022-06-26 11:26:47.532492
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '181.0.0.0/12'
    bool_0 = True
    hls_f_d_0 = HlsFD(str_0, bool_0)
    str_0 = ''
    dict_0 = {}
    bool_0 = hls_f_d_0.real_download(str_0, dict_0)

if __name__ == '__main__':
    test_case_0()
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:26:52.449356
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'test_hls.txt'
    str_1 = 'test_hls.txt'
    bool_0 = True
    hls_f_d_0 = HlsFD(str_0, bool_0)
    hls_f_d_0.real_download(str_1, 10)


# Generated at 2022-06-26 11:26:53.410446
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:26:59.356743
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():

    # test variables
    # hls_f_d_0 is instance of HlsFD
    hls_f_d_0 = HlsFD(str_0, bool_0)

    # Call real_download and check if it returns false as expected
    if (hls_f_d_0.real_download(filename_0, info_dict_0) != False):

        # raise exception with message "Method returned unexpected value"
        raise Exception('Method returned unexpected value')



# Generated at 2022-06-26 11:27:00.939317
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:27:05.653395
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD(None, True)
    assert hls_f_d_0.name == 'hlsnative'
    assert hls_f_d_0.is_fragmented == True
    assert hls_f_d_0.supports
    assert hls_f_d_0.params == {}
    assert hls_f_d_0.ydl == None
    assert hls_f_d_0._progress_hooks



# Generated at 2022-06-26 11:27:11.792609
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '170.0.0.0/12'
    str_1 = '79.1.1.2'
    dict_0 = {
        'class' : 'HlsFD',
        'url' : str_1,
    }
    test_HlsFD_real_download_0(str_0, dict_0)


# Generated at 2022-06-26 11:27:36.271156
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Periods of test:
    # 1 - [0, 24]
    # 2 - [24, 35]
    # 3 - [35, ]
    # Test case 0
    # Expectation of assertion error.
    # real_download(*[StaticDownloadContext(None)], **{'info_dict': {'_type': 'hls'}, 'filename': 'test.mp4'})
    # Test case 1-1
    try:
        assert_equal(test_case_0(), 'Method returned unexpected value')
    except AssertionError:
        pass
    finally:
        pass
    # Test case 1-2
    try:
        assert_equal(test_case_0(), 'Method returned unexpected value')
    except AssertionError:
        pass
    finally:
        pass
    # Test case 2-1
   

# Generated at 2022-06-26 11:27:41.559296
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    filename = 'filename'
    info_dict = {}
    ctx = {}
    frag_url = 'frag_url'
    frag_content = 'frag_content'
    method_1 = (
        lambda: test_case_0(),
        lambda: 1
    )
    method_0 = (
        lambda: False,
        method_1[0],
        method_1[1]
    )
    result_0 = method_0[0]()
    method_0[1]()
    assert result_0 == False
    result_1 = method_0[2]()
    assert result_1 == 1


# Generated at 2022-06-26 11:27:48.926615
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-26 11:27:51.743351
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        test_case_0()
    except Exception as var_1:
        assert str(var_1) == str_0

# Generated at 2022-06-26 11:27:54.126460
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        test_case_0()
    except Exception as e:
        print('Exception message: ' + str(e))

# Generated at 2022-06-26 11:28:00.834304
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    print('Testing method real_download of class HlsFD...')
    print('Test case 0...')
    # Error handling
    try:
        obj_0 = HlsFD(None, None)
        obj_0.real_download(None, None)
    except Exception as e:
        assert str_0 == str(e)
    else:
        assert False
    print('Test case 1...')
    # No error handling
    obj_1 = HlsFD(None, None)
    obj_1.real_download(None, None)
    print('Test case completed.')


# Generated at 2022-06-26 11:28:12.048425
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    try:
        start = time.time()
        if condition:
            var_0 = HlsFD
            var_1 = var_0.real_download('test_0', 'test_1')
            var_2 = None
            assert var_1 == var_2, 'Method returned unexpected value'
            test_case_0()
            test_case_1()
            test_case_2()
            test_case_3()
        return '%d tests passed in %.2f seconds' % (4, time.time() - start)
    except Exception as e:
        print('Unhandled Exception:', e)
    return '%d tests failed' % (4,)

## Closing file in IDE may cause Exception "ValueError: I/O operation on closed file"
## Forcefully close the file if it is still open
f.close

# Generated at 2022-06-26 11:28:13.389649
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hlsfd_0 = HlsFD(None)


# Generated at 2022-06-26 11:28:24.316051
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-26 11:28:27.573157
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    str_0 = ''
    str_1 = ''
    dict_0 = dict()
    dict_0 = {'is_live': False}
    bool_0 = HlsFD.can_download(str_0, dict_0)
    assert bool_0 == True


# Generated at 2022-06-26 11:28:41.567397
# Unit test for constructor of class HlsFD
def test_HlsFD():
    val_0 = HlsFD(None, None)


# Generated at 2022-06-26 11:28:42.914564
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass

# Generated at 2022-06-26 11:28:47.864309
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.FD_NAME == 'hlsnative'
    assert HlsFD.can_download('manifest', 'info_dict' == True)
    try:
        str_0 = 'Method returned unexpected value'
        var_0 = Exception(str_0)
    except:
        pass


# Generated at 2022-06-26 11:28:49.446583
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD(None, None) != None


# Generated at 2022-06-26 11:28:59.941562
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    var_0 = HlsFD()
    str_0 = 'filename'
    dict_0 = {}
    dict_0['url'] = 'http://hls-geo.daserste.de/i/videoportal/Film/c_620000/622873/format,716451,716457,716450,716458,716459,.mp4.csmil/index_4_av.m3u8?null=0'
    dict_0['http_headers'] = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36'}

# Generated at 2022-06-26 11:29:11.194626
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os.path, sys, os
    import unittest
    import tempfile
    import json
    import base64
    import hashlib
    import youtube_dl.extractor.common
    from youtube_dl.utils import (
        encodeFilename,
        read_json_file,
        unsmuggle_url,
        write_json_file,
    )

    class TestHlsFD(unittest.TestCase):
        filename = None
        info_dict = {}
        manifest = None


# Generated at 2022-06-26 11:29:17.214309
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    return
    _args = [('dummy_filename', []),
             (['1'], 'dummy_info_dict')]
    info_dict = []
    obj_0 = HlsFD(None, None)
    try:
        obj_0.real_download(**_args[0])
    except Exception as arg_0:
        var_0 = arg_0
    assert test_case_0()

if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:29:18.907328
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass

test_case_0()

# Generated at 2022-06-26 11:29:30.279774
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Test for method real_download of class HlsFD
    # Test for the hlsnative backend
    # Test for method real_download of class HlsFD
    # Test for the hlsnative backend
    var_0 = HlsFD()
    # var_1 = {'protocol': 'm3u8_native', 'url': 'https://example.com/baz.m3u8', 'fragments': []}
    # var_0.real_download('abc', var_1)

    # Test for method real_download of class HlsFD
    # Test for the hlsnative backend
    # 29 Line

# Generated at 2022-06-26 11:29:33.361658
# Unit test for constructor of class HlsFD
def test_HlsFD():
    obj_0 = HlsFD()
    assert getattr(obj_0, 'real_download') is not None, test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:29:55.041642
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '\r181.0.0.0/s2'
    bytes_0 = b'a\xd3\xd2\r\xee\xb1\xc1\xaa\x9cS'
    str_1 = '\x01\xc3@\xa0\x04\xd4\x9c\x7f\xa6'
    str_2 = '\x0b\xcd\xf8\xc7\x9b\xd6\x83\xcb\xae\x85\xfa\x87'
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    hls_f_d_0.can_download(str_0, bytes_0)

# Generated at 2022-06-26 11:29:57.399965
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()


if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:30:07.008097
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    try:
        str_0 = '\r181.0.0.0/s2'
        bytes_0 = b'a\xd3\xd2\r\xee\xb1\xc1\xaa\x9cS'
        hls_f_d_0 = HlsFD(str_0, str_0)
        var_0 = hls_f_d_0.can_download(str_0, bytes_0)
        assert var_0 == False
    except:
        print('Test failed', var_0)
        exit(1)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:30:15.556383
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = '\r181.0.0.0/s2'
    str_1 = '0\t\r181.0.0.0/s2'
    bytes_0 = b'a\xd3\xd2\r\xee\xb1\xc1\xaa\x9cS'
    hls_f_d_0 = HlsFD(str_0, str_0)
    var_0 = hls_f_d_0.can_download(str_0, bytes_0)
    var_1 = hls_f_d_0.real_download(str_1, bytes_0)


# Generated at 2022-06-26 11:30:21.752895
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '\r181.0.0.0/s2'
    bytes_0 = b'a\xd3\xd2\r\xee\xb1\xc1\xaa\x9cS'
    hls_f_d_0 = HlsFD(str_0, str_0)
    var_0 = hls_f_d_0.real_download(str_0, bytes_0)

if __name__ == '__main__':
    test_case_0()
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:30:29.103548
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD('a1gSzd5kHq', 'a1gSzd5kHq')
    hls_f_d_0.real_download('2017-07-15_12.55.26.mp4', 'b8D1_xXnXmG')

if __name__ == '__main__':
    test_case_0()
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:30:31.426812
# Unit test for constructor of class HlsFD
def test_HlsFD():
    #TODO: full test
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:30:35.443807
# Unit test for constructor of class HlsFD
def test_HlsFD():
    xdl_0 = HlsFD('', '')
    assert xdl_0.params == {}
    xdl_1 = HlsFD('', '', {'test': True})
    assert xdl_1.params == {'test': True}


# Generated at 2022-06-26 11:30:38.696941
# Unit test for constructor of class HlsFD
def test_HlsFD():
    print ('Test case 0 (class HlsFD): ')
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:30:44.232274
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    str_0 = 'HlsFD'
    str_1 = 'HlsFD'
    str_2 = '\r181.0.0.0/s2c'
    bytes_0 = b'a\xd3\xd2\r\xee\xb1\xc1\xaa\x9cS'
    hls_f_d_0 = HlsFD(str_0, str_1)
    var_0 = hls_f_d_0.can_download(str_2, bytes_0)
    assert(var_0 == False)


# Generated at 2022-06-26 11:31:29.440767
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD("1", {'md5': '1'})


# Generated at 2022-06-26 11:31:32.637838
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Test Cases for class 'HlsFD'
    # Case 0
    test_case_0()

if __name__ == '__main__':
    # Run unit tests
    test_HlsFD()

# Generated at 2022-06-26 11:31:39.614572
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    response = {
        'manifest_url': 'https://manifest.url',
        'http_headers': {
            'User-Agent': 'UA'},
        'urls': [
            'https://media.frag.ment/0.ts',
            'https://media.frag.ment/1.ts',
            'https://media.frag.ment/2.ts',
            'https://media.frag.ment/3.ts',
        ]
    }
    hls_f_d = HlsFD('', '')
    hls_f_d.real_download('', response)

# Generated at 2022-06-26 11:31:41.832755
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:31:47.537199
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD('\r181.0.0.0/s2', '\r181.0.0.0/s2')
    assert hls_f_d_0.real_download('\r181.0.0.0/s2', '\r181.0.0.0/s2') == False
    assert hls_f_d_0.real_download(None, None) == False


# Generated at 2022-06-26 11:31:55.000076
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '-#zYB!8EHj;w>|'
    str_1 = 'a\xd3\xd2\r\xee\xb1\xc1\xaa\x9cS'
    hls_f_d_0 = HlsFD(str_0, str_0)
    var_0 = hls_f_d_0.real_download(str_0, str_1)

# Generated at 2022-06-26 11:32:05.088805
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import urlparse
    from youtube_dl.utils import url_basename, encodeFilename
    from youtube_dl.YoutubeDL import YoutubeDL
    # Local test HLS
    test_hls_url = 'https://github.com/ytdl-org/youtube-dl/raw/master/test/test-data/index.m3u8'
    parsed_hls_url = urlparse.urlparse(test_hls_url)
    test_out_dir = tempfile.mkdtemp(prefix='youtube-dl-HlsFD')
    test_out_file = os.path.join(test_out_dir, 'test.mp4')
    ydl = YoutubeDL(params={'noplaylist': True, 'test': True})
    ydl.add_default_info_

# Generated at 2022-06-26 11:32:06.953970
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()


if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:32:15.255534
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # The Python unit test library dependency
    import unittest
    # The Python unit test library dependency
    import pytest

    hls_f_d_0 = HlsFD('f', 'f')

    # Verify return of method _download_fragment
    assert hls_f_d_0._download_fragment(None, 'h', None, None) == (False, b'77f79d7c8f8f')

    # Verify return of method _finish_frag_download
    assert hls_f_d_0._finish_frag_download(None) is None

    # Verify return of method _prepare_and_start_frag_download
    assert hls_f_d_0._prepare_and_start_frag_download(None) is None

    # Verify return of method _

# Generated at 2022-06-26 11:32:21.329541
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Testing for
    #     return False
    #     return False
    #     return False
    #     return False
    #     return False
    #     return True
    assert(HlsFD.real_download(0, 0, 0))
    

# Generated at 2022-06-26 11:33:45.990672
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Can download test
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:33:49.390502
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD('/Q2', '/Rn4')
    info_dict_0 = {'category': ''}
    hls_f_d_0.real_download('', info_dict_0)

if __name__ == '__main__':
    test_case_0()
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:33:50.642501
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert HlsFD.real_download(str_0, str_0) == var_0

# Generated at 2022-06-26 11:33:53.162193
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = '\r181.0.0.0/s2'
    hls_f_d_0 = HlsFD(str_0, str_0)
    assert(hls_f_d_0.FD_NAME == 'hlsnative')


# Generated at 2022-06-26 11:34:01.287974
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'pycrypto not found. Please install it'
    new_HlsFD = HlsFD('\x00\x80', '\x00\x80')
    assert new_HlsFD.report_error(str_0) == False
    assert new_HlsFD.real_download(str_0, new_HlsFD) == True
    assert new_HlsFD.can_download(str_0, str_0) == True
    str_1 = '\r181.0.0.0/s2'
    new_HlsFD_1 = HlsFD(str_1, str_1)
    assert new_HlsFD_1.can_download(str_1, new_HlsFD_1) == True

# Generated at 2022-06-26 11:34:10.447079
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    str_0 = '\r181.0.0.0/s2'
    var_0 = 'HlsFD'
    hls_f_d_0 = HlsFD(str_0, str_0)
    hls_f_d_0.FD_NAME = var_0
    str_0 = '\r181.0.0.0/s2'
    var_0 = 'HlsFD'
    hls_f_d_0 = HlsFD(str_0, str_0)
    hls_f_d_0.FD_NAME = var_0
    str_0 = '\r181.0.0.0/s2'
    var_0 = 'HlsFD'
    hls_f_d_0 = HlsFD(str_0, str_0)
   

# Generated at 2022-06-26 11:34:18.469732
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '#EXT-X-KEY:METHOD=AES-128,URI="https://priv.example.com/key.php?r=52"\n#EXTINF:2.833,\nhttp://media.example.com/fileSequence52-A.ts\n#EXTINF:15.0,\nhttp://media.example.com/fileSequence52-B.ts\n#EXTINF:13.333,\nhttp://media.example.com/fileSequence52-C.ts\n'
    hls_f_d_0 = HlsFD(str_0, str_0)
    var_0 = hls_f_d_0.real_download(str_0, hls_f_d_0)

# Generated at 2022-06-26 11:34:23.151684
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Set up the test case
    str_0 = '\r181.0.0.0/s2'
    hls_f_d_0 = HlsFD(str_0, str_0)
    str_1 = 'http://www.baidu.com'
    info_dict_0 = {'url': str_1}
    # Call the method
    result_0 = hls_f_d_0.real_download(str_0, info_dict_0)
    # Check the result
    assert result_0 == False


# Generated at 2022-06-26 11:34:33.427120
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'p'
    str_1 = 'T'
    str_2 = 'a'
    str_3 = 'f'
    str_4 = 'o'
    str_5 = 'l'
    str_6 = 'C'
    str_7 = 'a'
    str_8 = 'h'
    str_9 = 't'
    str_10 = 'I'
    str_11 = 'O'
    str_12 = 'p'
    str_13 = 'a'
    str_14 = 's'
    str_15 = 'S'
    str_16 = '6'
    str_17 = 'g'
    str_18 = 'a'
    str_19 = 'c'
    str_20 = 'G'
    str_21 = 'i'
   

# Generated at 2022-06-26 11:34:38.144980
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_1 = '\r181.0.0.0/s2'
    str_2 = '\r181.0.0.0/s2'
    var_1 = HlsFD(str_1, str_2)
    var_2 = var_1.real_download(str_1, var_1)


# Generated at 2022-06-26 11:36:11.116969
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = '\r181.0.0.0/s2'
    hls_f_d_0 = HlsFD(str_0, str_0)
    assert hls_f_d_0.FD_NAME == 'hlsnative'
