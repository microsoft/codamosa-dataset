

# Generated at 2022-06-26 11:26:47.328611
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # assert the real_download method of class HlsFD exists
    assert hasattr(HlsFD, 'real_download'), 'Missing HlsFD.real_download method'
    # assert the real_download method of class HlsFD is callable
    assert callable(HlsFD.real_download), 'HlsFD.real_download is not callable'


# Generated at 2022-06-26 11:26:57.785555
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download('#EXT-X-TARGETDURATION:1', {'is_live': False})
    assert HlsFD.can_download('#EXT-X-TARGETDURATION:1', {'is_live': True})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=SAMPLE-AES', {})
    assert not HlsFD.can_download('#EXT-X-BYTERANGE', {})
    assert not HlsFD.can_download('#EXT-X-MAP', {})
    assert not HlsFD.can_download('#EXT-X-MEDIA-SEQUENCE:1', {})
    assert not HlsFD.can_download('#EXT-X-PLAYLIST-TYPE:EVENT', {})


# Generated at 2022-06-26 11:27:04.114738
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import inspect
    import tempfile
    urls = []
    urls.append(
        'http://vm2.dashif.org/livesim/testpic_2s/Manifest.mpd')  # normal mpd file
    urls.append(
        'http://vm2.dashif.org/livesim/testpic_2s_with_sap_1/Manifest.mpd')  # permitted SAP
    urls.append('http://cbsnewshd-lh.akamaihd.net/i/CBSNHD_7@199302/master.m3u8')  # normal m3u8 file
    urls.append('http://fes14-vh.akamaihd.net/i/fes14/index_1000_av-p.m3u8')  # AES

# Generated at 2022-06-26 11:27:09.245394
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD(None, None)
    hls_f_d_0.real_download(b'test_file.mp4', b'http://test.com/test_playlist.m3u8')

# Generated at 2022-06-26 11:27:19.634347
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .fragment import FragmentFD
    from .external import FFmpegFD
    from .http import HttpFD
    from .http import HttpQuietDownloader
    from .http import compat_urllib_request
    import os.path
    import sys

    if sys.version_info < (3, ):
        import mock
    else:
        from unittest import mock

    class YtdlHlsFdInstance0(object):
        def __init__(self):
            self.to_screen = mock.MagicMock()
            self.report_error = mock.MagicMock()
            self.report_warning = mock.MagicMock()
            self.report_retry_fragment = mock.MagicMock()
            self.report_skip_fragment = mock.MagicMock()

# Generated at 2022-06-26 11:27:27.480993
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    bytes_0 = b'\x1c\x0e\xd9\xbb\x93\xc8\x16\x11\xd7\x93\x8e\xfb\x9b\x0c\x8f\xbc\x18\x1d\xb1\xaf\x9d\xc9\x9b\x86\x8e\xbe\x14\x0b\x90\x8b\xb2'
    dict_0 = {'http_headers': {'Range': 'bytes=0-32767'}, 'extra_param_to_segment_url': 'bip=0'}

# Generated at 2022-06-26 11:27:29.109043
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:27:31.552941
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    class_0 = HlsFD(bytes, str)
    assert class_0.real_download() == None


# Generated at 2022-06-26 11:27:32.569612
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert test_case_0() == None

# Generated at 2022-06-26 11:27:39.057287
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    bytes_0 = b'L\x00,\xd6\x1a\xb9\x8be\xde'
    str_0 = 'md5:6ddb02b0781c6adf778afea606652e38'
    hls_f_d_0 = HlsFD(bytes_0, str_0)
    str_1 = 'md5:f6e7a55a1ec2c401a58a2a35a095b5bd'
    hls_f_d_0.real_download(str_1)


# Generated at 2022-06-26 11:27:59.733193
# Unit test for constructor of class HlsFD
def test_HlsFD():
    list = []
    fd = HlsFD(list, list)
    assert fd


# Generated at 2022-06-26 11:28:04.029986
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'pE\x04\x0c'
    list_0 = [str_0, str_0]
    bytes_0 = b'\x82\x88'
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    assert_equal(hls_f_d_0.FD_NAME, 'hlsnative')
    assert_equal(hls_f_d_0.real_download(str_0, list_0), True)


# Generated at 2022-06-26 11:28:05.111201
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Test case data
    pass

# Generated at 2022-06-26 11:28:13.521058
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    str_0 = '#EXT-X-KEY:METHOD=AES-128'
    list_0 = ['#EXT-X-BYTERANGE']
    bytes_0 = b'\xa3i'
    hls_f_d_0 = HlsFD('#EXT-X-KEY:METHOD=AES-128', b'\xa3i')
    var_0 = hls_f_d_0.can_download('#EXT-X-KEY:METHOD=AES-128', ['#EXT-X-BYTERANGE'])
    assert var_0

test_case_0()

# Generated at 2022-06-26 11:28:16.330342
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert test_case_0() == None

if __name__ == '__main__':
    HlsFD = HlsFD(None, None)
    test_HlsFD()

# Generated at 2022-06-26 11:28:26.730159
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    list_0 = ["\x10\x80\x04\x08\x04\x08", "", "\x10\x80\x04\x08\x04\x08", "", "", "", "", "", "", ""]
    str_0 = '\x00\x00\x80\x00\x80\x00\x80'
    dict_0 = {"_decryption_key_url": "", "url": str_0}
    bytes_0 = b'\x1a\x1a'
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    hls_f_d_0.can_download(str_0, dict_0)
    hls_f_d_0.params = dict_0
    bool_0 = h

# Generated at 2022-06-26 11:28:35.135728
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '3\x17\x16f'
    bytes_0 = b'\x9d1\xd6'
    list_0 = [str_0, bytes_0]
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    var_0 = hls_f_d_0.real_download(str_0, list_0)

if __name__ == "__main__":
    test_case_0()
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:28:36.848580
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert(test_case_0())

# Generated at 2022-06-26 11:28:44.296914
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Input parameters
    bytes_0 = b'\xac\xd0\x8f\xfc'

# Generated at 2022-06-26 11:28:50.890657
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'K{\r(UXi/vw5E4W?R'
    list_0 = [str_0, str_0]
    bytes_0 = b'\xc8\r'
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    var_0 = hls_f_d_0.real_download(str_0, list_0)
    assert var_0 == True

# Generated at 2022-06-26 11:29:29.972039
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'K{\r(Ui/v5EW?R'
    bytes_0 = b'~\xf1\xb3\n\x97\xea'
    bytes_1 = b'~\xf1\xb3\n\x97\xea'
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    assert hls_f_d_0.real_download(str_0, bytes_0) == True
    assert hls_f_d_0.real_download(bytes_0, bytes_1) == False
    assert hls_f_d_0.real_download(bytes_1, str_0) == False
    assert hls_f_d_0.real_download(bytes_1, bytes_0) == True

# Generated at 2022-06-26 11:29:34.966419
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'K{\r(Ui/v5EW?R'
    bytes_0 = b'~\xf1\xb3\n\x97\xea'
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    assert 'hlsnative' == hls_f_d_0.FD_NAME


# Generated at 2022-06-26 11:29:44.258548
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-26 11:29:53.761834
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'z4]gC0oX9H'
    bytes_0 = b'\xbf\x18\x1b\xa7\x88'
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    var_0 = hls_f_d_0.real_download(str_0, bytes_0)
    print(var_0)

if __name__ == '__main__':
    str_0 = 'z4]gC0oX9H'
    bytes_0 = b'\xbf\x18\x1b\xa7\x88'
    hls_f_d_0 = HlsFD(str_0, bytes_0)

# Generated at 2022-06-26 11:30:00.834605
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'K{\r(Ui/v5EW?R'
    bytes_0 = b'~\xf1\xb3\n\x97\xea'
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    hls_f_d_0.real_download(str_0, bytes_0)

if __name__ == '__main__':
    test_case_0()
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:30:08.988809
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'K{\r(Ui/v5EW?R'
    bytes_0 = b'~\xf1\xb3\n\x97\xea'
    dict_0 = {str_0: bytes_0}
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    str_1 = 'K{\r(Ui/v5EW?R'
    assert hls_f_d_0.real_download(str_1, dict_0)


# Generated at 2022-06-26 11:30:18.097002
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'hlsnative'
    str_1 = '~\xf1\xb3\n\x97\xea'
    str_2 = 'K{\r(Ui/v5EW?R'
    str_3 = 'https://example.com/file.m3u8'
    dict_0 = {'test': True, 'skip_unavailable_fragments': False}
    dict_1 = {'url': 'https://example.com/file.m3u8'}
    hls_f_d_0 = HlsFD(str_0, dict_0)
    hls_f_d_0.real_download(str_1, dict_1)


# Generated at 2022-06-26 11:30:25.369559
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'K{\r(Ui/v5EW?R'
    bytes_0 = b'~\xf1\xb3\n\x97\xea'
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    ret_val_0 = hls_f_d_0.real_download(str_0, bytes_0)
    assert ret_val_0 == False
    assert hls_f_d_0.FD_NAME == 'hlsnative'


# Generated at 2022-06-26 11:30:30.520053
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'K{\r(Ui/v5EW?R'
    bytes_0 = b'~\xf1\xb3\n\x97\xea'
    assert HlsFD(str_0, bytes_0)


# Generated at 2022-06-26 11:30:37.601704
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'K{\r(Ui/v5EW?R'
    bytes_0 = b'~\xf1\xb3\n\x97\xea'
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    str_1 = 'K{\r(Ui/v5EW?R'
    hls_f_d_0.real_download(str_1, bytes_0)


# Generated at 2022-06-26 11:31:37.634590
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Encrypted M3U8
    str_0 = '#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="https://priv.example.com/key.php?r=52"\n#EXTINF:2.833,\nhttp://media.example.com/fileSequence52-A.ts\n#EXTINF:15.0,\nhttp://media.example.com/fileSequence52-B.ts\n#EXTINF:13.333,\nhttp://media.example.com/fileSequence52-C.ts\n'
    bytes_0 = b'\xdf\xd6k\x00\x00'
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    assert hls_f_d_

# Generated at 2022-06-26 11:31:38.493122
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    test_case_0()

# Generated at 2022-06-26 11:31:46.155861
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import unittest

    class Test_HlsFD(unittest.TestCase):
        def test_assertions(self):
            self.assertEqual(HlsFD.FD_NAME, 'hlsnative')
            self.assertRaises(NotImplementedError, HlsFD.real_download)
            self.assertTrue(HlsFD.can_download("", {}))
            self.assertRaises(NotImplementedError, HlsFD._prepare_url)

    unittest.main()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:31:46.970201
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert True


# Generated at 2022-06-26 11:31:48.631977
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert callable(HlsFD.real_download)
    # More tests required.
    test_case_0()


# Generated at 2022-06-26 11:31:50.412107
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass

# Generated at 2022-06-26 11:31:59.457089
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    str_9 = 'K{\r(Ui/v5EW?R'
    bytes_9 = b'~\xf1\xb3\n\x97\xea'
    hls_f_d_9 = HlsFD(str_9, bytes_9)
    var_9 = hls_f_d_9.can_download(str_9, bytes_9)
    if var_9:
        assert True
    else:
        assert False

if __name__ == '__main__':
    test_case_0()
    test_HlsFD_can_download()

# Generated at 2022-06-26 11:32:05.646132
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'K{\r(Ui/v5EW?R'
    bytes_0 = b'~\xf1\xb3\n\x97\xea'

# Generated at 2022-06-26 11:32:12.098443
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'K{\r(Ui/v5EW?R'
    bytes_0 = b'~\xf1\xb3\n\x97\xea'
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    var_0 = hls_f_d_0.real_download(str_0, bytes_0)

if __name__ == '__main__':
    test_case_0()
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:32:24.582656
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'K{\r(Ui/v5EW?R'
    bytes_0 = b'~\xf1\xb3\n\x97\xea'
    # WHEN_CREATED_USING_0
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    # WHEN_CREATED_USING_1
    hls_f_d_1 = HlsFD(str_0, bytes_0, str_0)
    # WHEN_CREATED_USING_2
    hls_f_d_2 = HlsFD(str_0, bytes_0, str_0, bytes_0)
    # WHEN_CREATED_USING_3

# Generated at 2022-06-26 11:34:16.498835
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_arg_0 = b'rtmp\x00\x00\x00\x00'
    str_arg_1 = b'p\x00\x00\x00\x00\x00\x00\x00\x00'
    hls_f_d_0 = HlsFD(str_arg_0, str_arg_1)

    str_arg_2 = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    str_arg_3 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-26 11:34:19.724627
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'K{\r(Ui/v5EW?R'
    bytes_0 = b'~\xf1\xb3\n\x97\xea'
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    hls_f_d_0.real_download(str_0, bytes_0)

# Generated at 2022-06-26 11:34:25.669129
# Unit test for constructor of class HlsFD
def test_HlsFD():
    print(HlsFD(None, None).can_download(None, None))
    print(HlsFD(None, None)._approx_total_size())
    bytes_0 = b'~\xf1\xb3\n\x97\xea'
    print(HlsFD(None, bytes_0)._finish_frag_download(bytes_0))
    bytes_0 = b'~\xf1\xb3\n\x97\xea'
    print(HlsFD(None, bytes_0)._prepare_and_start_frag_download(bytes_0))
    print(HlsFD(None, None)._prepare_url(None, None))
    print(HlsFD(None, None)._append_fragment(None, None))

# Generated at 2022-06-26 11:34:26.541713
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()


# Generated at 2022-06-26 11:34:32.327630
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    try:
        hls_f_d_0 = HlsFD("]N?w0A$H'Rc[a\/9", {})
        hls_f_d_0.real_download("z8w;", {})
    except:
        pass


if __name__ == '__main__':
    test_case_0()
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:34:32.892044
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass

# Generated at 2022-06-26 11:34:38.180537
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'K{\r(Ui/v5EW?R'
    bytes_0 = b'~\xf1\xb3\n\x97\xea'
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    var_0 = hls_f_d_0.real_download(str_0, bytes_0)


# Generated at 2022-06-26 11:34:42.754587
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'K{\r(Ui/v5EW?R'
    bytes_0 = b'~\xf1\xb3\n\x97\xea'
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    assert hls_f_d_0.can_download(str_0, bytes_0) == True


# Generated at 2022-06-26 11:34:50.524662
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'K{\r(Ui/v5EW?R'
    bytes_0 = b'~\xf1\xb3\n\x97\xea'
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    # print(hls_f_d_0)

    var_0 = hls_f_d_0.can_download(str_0, bytes_0)
    # print(var_0)
    assert var_0 == True



# Generated at 2022-06-26 11:34:57.094212
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'K{\r(Ui/v5EW?R'
    bytes_0 = b'~\xf1\xb3\n\x97\xea'
    str_1 = 'K{\r(Ui/v5EW?R'
    bytes_1 = b'~\xf1\xb3\n\x97\xea'
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    var_0 = hls_f_d_0.real_download(str_1, bytes_1)
