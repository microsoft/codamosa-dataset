

# Generated at 2022-06-26 11:26:45.063380
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    hls_f_d_0 = HlsFD(tuple_0, dict_0)
    string_0 = ''
    string_1 = ''
    hls_f_d_0.real_download(string_0, string_1)


# Generated at 2022-06-26 11:26:53.668762
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    HlsFD.is_live = None
    import StringIO
    manifest = StringIO.StringIO('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\nhttps://adap.tv/adap.tv\n')
    dict_0 = {'is_live': False, 'url': manifest, '_decryption_key_url': 'https://adap.tv/adap.tv'}
    hls_f_d_0 = HlsFD(test_case_0, dict_0)
    filename = 'test'
    res = hls_f_d_0.real_download(filename, dict_0)
    assert(res == False)

# Generated at 2022-06-26 11:26:56.976674
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    hls_f_d_0 = HlsFD(tuple_0, dict_0)
    pass



# Generated at 2022-06-26 11:26:58.519593
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:27:03.801952
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    url_h_0 = None
    url_h_1 = None
    try:
        url_h_0 = compat_urllib_request.urlopen('https://example.com/')
        # This is a big amount of data
        assert isinstance(url_h_0.read(100), bytes)
        url_h_1 = compat_urllib_request.urlopen('https://example.com/')
    except compat_urllib_error.HTTPError as err_0:
        pass
    finally:
        if url_h_1:
            url_h_1.close()
        if url_h_0:
            pass


# Generated at 2022-06-26 11:27:09.300827
# Unit test for constructor of class HlsFD
def test_HlsFD():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    hls_f_d_0 = HlsFD(tuple_0, dict_0)

    assert hls_f_d_0.__init__(tuple_0, dict_0)


# Generated at 2022-06-26 11:27:13.334726
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    try:
        hls_f_d_0 = HlsFD(tuple_0, dict_0)
        hls_f_d_0.real_download(tuple_0, dict_0)
    except:
        # TODO add some log
        pass


# Generated at 2022-06-26 11:27:18.413982
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    kwargs_0 = {'filename':'filename_0', 'info_dict': 'info_dict_0'}
    hls_f_d_0 = HlsFD(kwargs_0, kwargs_0)
    hls_f_d_0.real_download('filename_1', 'info_dict_1')


# Generated at 2022-06-26 11:27:20.145303
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:27:27.811324
# Unit test for constructor of class HlsFD
def test_HlsFD():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    hls_f_d_0 = HlsFD(tuple_0, dict_0)
    assert not hls_f_d_0.real_download(tuple_0, dict_0)
    assert hls_f_d_0.can_download('', dict_0)
    assert hls_f_d_0.can_download(
        '#EXT-X-KEY:METHOD=AES-128\n#EXT-X-BYTERANGE',
        dict_0,
    )
    assert hls_f_d_0.can_download(
        '#EXT-X-KEY:METHOD=NONE\n#EXT-X-BYTERANGE',
        dict_0,
    )
    return 0

# Generated at 2022-06-26 11:27:43.071182
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    filename = ''
    info_dict = {}
    hls_f_d = HlsFD(None, None)
    assert hls_f_d.real_download(filename, info_dict) == True



# Generated at 2022-06-26 11:27:45.604075
# Unit test for constructor of class HlsFD
def test_HlsFD():
    tuple_0 = ()
    dict_1 = {tuple_0: tuple_0}
    hls_f_d_0 = HlsFD(tuple_0, dict_1)
    assert hls_f_d_0 != None
    pass



# Generated at 2022-06-26 11:27:50.824297
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    hls_f_d_0 = HlsFD(tuple_0, dict_0)
    assert_equals(hls_f_d_0.real_download(tuple_0, dict_0), False)


# Generated at 2022-06-26 11:27:59.733697
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    manifest = '''
#EXTM3U
#EXT-X-VERSION:4
#EXT-X-TARGETDURATION:4
#EXT-X-MEDIA-SEQUENCE:4775
#EXTINF:4.000000,
http://media.tararatata.com/2016/09/08/JASPER_STEYN_-_Dont_Look_Any_Further.mp3/04775.ts
#EXTINF:4.000000,
http://media.tararatata.com/2016/09/08/JASPER_STEYN_-_Dont_Look_Any_Further.mp3/04776.ts
'''
    info_dict = {}
    result = HlsFD.can_download(manifest, info_dict)
    assert result == True


# Generated at 2022-06-26 11:28:08.388273
# Unit test for constructor of class HlsFD
def test_HlsFD():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    hls_f_d_0 = HlsFD(tuple_0, dict_0)
    tuple_1 = (None,)
    dict_1 = {tuple_0: tuple_0}
    hls_f_d_1 = HlsFD(tuple_1, dict_1)
    dict_2 = {tuple_1: tuple_1}
    hls_f_d_2 = HlsFD(tuple_1, dict_2)


# Generated at 2022-06-26 11:28:12.386347
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # check for the correct return value
    assert HlsFD.real_download(tuple_0, dict_0) == None
    # check for the correct exception thrown
    assert HlsFD.real_download(tuple_0, dict_0) == tuple_0

# Generated at 2022-06-26 11:28:23.210824
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    from .test_utils import TestDownloader
    from .utils import check_executable
    from .extractor import gen_extractors
    from .downloader.external import FFmpegFD
    from .compat import (
        compat_urllib_request,
    )
    def test_real_download():
        test_downloader = TestDownloader()
        url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
        gen_extractors()
        info_dict = test_downloader.ydl.extract_info(
            url, download=False)

# Generated at 2022-06-26 11:28:24.316031
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass


# Generated at 2022-06-26 11:28:34.514539
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    tuple_0 = ()
    dict_0 = {'http_headers': 'application/x-mpegURL'}
    hls_f_d_1 = HlsFD(tuple_0, dict_0)
    str_0 = hls_f_d_1.real_download('#EXT-X-KEY', dict_0)
    str_1 = hls_f_d_1.real_download('test_case_0', dict_0)
    str_2 = hls_f_d_1.real_download('#EXT-X-KEY', dict_0)
    str_3 = hls_f_d_1.real_download('#EXT-X-KEY', dict_0)

# Generated at 2022-06-26 11:28:39.444325
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    hls_f_d_0 = HlsFD(tuple_0, dict_0)
    hls_f_d_0.real_download(tuple_0, dict_0)


# Generated at 2022-06-26 11:28:57.854166
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()
    # How to run:
    # $ python3 -m youtube_dl.downloader.hls_f_d
    #
    # Expected output:
    # test_case_0 : True
    #

# Generated at 2022-06-26 11:29:01.321207
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.__doc__ != None
    assert HlsFD.__init__ != None


# Generated at 2022-06-26 11:29:09.186034
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Test case 0
    str_0 = '1+wsEU'
    bytes_0 = b'\x13\xc9z\x8a\xc3\xb7l\x07C\xab\xf7'
    float_0 = 7449.096
    list_0 = []
    hls_f_d_0 = HlsFD(float_0, list_0)
    var_0 = hls_f_d_0.can_download(str_0, bytes_0)


# Generated at 2022-06-26 11:29:15.155659
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_1 = '1+wsEU'
    bytes_1 = b'\x13\xc9z\x8a\xc3\xb7l\x07C\xab\xf7'
    float_1 = 534.05
    list_1 = []
    hls_f_d_1 = HlsFD(float_1, list_1)
    assert hls_f_d_1 is not None

# Generated at 2022-06-26 11:29:27.288448
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'ir9fj'
    bytes_0 = b'\x00\t\xab\xa7\xad\x04\x1f\x8a\x00\xc3\x95\xa5\x8e\x92\x98/\x9f\x8c\x85\x08\xd4\x1a\x8f\x13\xbc\xee\x9e\x86o\xc7\x1e\x01\x8a\x13\x91\xee\x9e\x8c\x06\x1b\x01z\x8f\x92\x98/\x9f '
    float_0 = 17006.0
    list_0 = []

# Generated at 2022-06-26 11:29:28.211502
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert True


# Generated at 2022-06-26 11:29:38.537393
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '8eU7V'
    str_1 = '\\\x8d\xea\xce'
    str_2 = '\x8d\xea\xce'

# Generated at 2022-06-26 11:29:40.356771
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert test_case_0() == True


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:29:44.942488
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import fake_ydl
    from .source import create_source_from_url
    ydl = fake_ydl()

    source = create_source_from_url(
        'https://www.nasa.gov/multimedia/nasatv/iss_ustream.m3u8', ydl)
    source.download()


if __name__ == "__main__":
    test_case_0()
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:29:54.092084
# Unit test for constructor of class HlsFD
def test_HlsFD():
    float_0 = 9999.0
    list_0 = [8, 8, 7, 5, 1, 3, 9, 5, 3, 0, 'm', 'I', 6, 9, 5, 2]
    hls_f_d_0 = HlsFD(float_0, list_0)
    str_0 = 'X/q'
    bytes_0 = b'\x8a\xd1\xbd\x97\x9e\x9a\xad\x94\x90\x8b\xe8\xd7\x98\x97\x9d\x9a'
    var_0 = hls_f_d_0.can_download(str_0, bytes_0)

if __name__ == '__main__':
    import pdb
    pdb.set_trace

# Generated at 2022-06-26 11:30:26.140055
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    set_0 = {1605.0, 343.834079, 1.3775e-07}
    str_0 = 'do\x05{d\x0e\\\x1cD'
    hls_f_d_0 = HlsFD(set_0, str_0)
    hls_f_d_0.real_download(str_0, str_0)


# Generated at 2022-06-26 11:30:32.782535
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    data_0 = {
        #'extra_param_to_segment_url' : '',
        'http_headers': '',
    }
    hls_f_d_0 = HlsFD(data_0, data_0)
    try:
        hls_f_d_0.real_download(data_0, data_0)
    except:
        pass


# Generated at 2022-06-26 11:30:40.993619
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'f\x0cZ3N+B2~$5DEY3\\&\x0cep'
    float_0 = -2892.699933
    set_0 = {float_0, float_0, float_0}
    hls_f_d_0 = HlsFD(set_0, str_0)
    assert hls_f_d_0.params == set_0
    assert hls_f_d_0.ydl == str_0

if __name__ == '__main__':
    test_case_0()
    test_HlsFD()

# Generated at 2022-06-26 11:30:44.462979
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_1 = '4'
    float_1 = -1939
    set_1 = {float_1, float_1}
    hls_f_d_1 = HlsFD(set_1, str_1)
    assert hls_f_d_1 is not None, "Failed to instantiate an object of class 'HlsFD'"

# Generated at 2022-06-26 11:30:55.292149
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = (
        'Should be overwritten by the real manifest when downloading')
    set_0 = {'https://example.com'}
    dict_0 = {'url': 'https://example.com', 'http_headers': {}}
    hls_f_d_0 = HlsFD(set_0, str_0)
    var_0 = hls_f_d_0.real_download(str_0, dict_0)
    assert var_0 is False

# Generated at 2022-06-26 11:30:56.335816
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()


# Generated at 2022-06-26 11:30:57.323850
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()


# Generated at 2022-06-26 11:31:03.841991
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    global test_executed_0, test_executed_1, test_executed_2, test_executed_3, test_executed_4, test_executed_5
    if test_executed_0:
        return
    test_executed_0 = True
    test_case_0()
    test_case_0()
    test_case_0()
    test_executed_1 = True
    test_executed_2 = True
    test_executed_3 = True
    test_executed_4 = True
    test_executed_5 = True

# Generated at 2022-06-26 11:31:06.095473
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    set_0 = set()
    str_0 = str()
    hls_f_d_0 = HlsFD(set_0, str_0)
    hls_f_d_0.real_download(str_0, str_0)

# Generated at 2022-06-26 11:31:07.180955
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD()


# Generated at 2022-06-26 11:31:52.928852
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD({}, '')

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:31:55.005711
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # TODO: create a unittest
    pass

# Generated at 2022-06-26 11:31:57.232210
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-26 11:32:02.033480
# Unit test for constructor of class HlsFD
def test_HlsFD():
    set_0 = set()
    str_0 = 'Ukljb94^PQHT(rn'
    hls_f_d_0 = HlsFD(set_0, str_0)
    assert hls_f_d_0.FD_NAME == 'hlsnative'
    assert hls_f_d_0.can_download(str_0, str_0) == True


# Generated at 2022-06-26 11:32:09.200894
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    set_0 = set()
    str_0 = 'tzb1ujt26z'
    hls_f_d_0 = HlsFD(set_0, str_0)
    str_1 = ''
    str_2 = '$f6%c9e!4^y4*h3+'
    dict_0 = dict()
    dict_0 = {'is_live': True}
    var_0 = hls_f_d_0.real_download(str_1, dict_0)


# Generated at 2022-06-26 11:32:10.951350
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:32:15.619932
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    set_0 = set()
    str_0 = 'xlohm1bT#a*$'
    str_1 = 'pO9D?xb4%'
    hls_f_d_0 = HlsFD(set_0, str_0)
    var_0 = hls_f_d_0.real_download(str_0, str_1)


# Generated at 2022-06-26 11:32:22.533161
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()
    test_case_1()

""" Tests for case where HlsFD.can_download returns False
# NOTE: FFmpegFD has a method called can_download
# which returns True if it is enabled, False otherwise.
# If the method returns False, the test does nothing,
# otherwise it will actually download the video.
"""

# Generated at 2022-06-26 11:32:24.497640
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert False, "Cause - No test_case found in test_HlsFD_real_download"


# Generated at 2022-06-26 11:32:27.322090
# Unit test for constructor of class HlsFD
def test_HlsFD():
    set_0 = set()
    str_0 = '^b3nqm3(M@$'
    hls_f_d_0 = HlsFD(set_0, str_0)


# Generated at 2022-06-26 11:33:12.322249
# Unit test for constructor of class HlsFD
def test_HlsFD():
    set_0 = set()
    str_0 = 'xlohm1bT#a*$'
    hls_f_d_0 = HlsFD(set_0, str_0)
    assert isinstance(hls_f_d_0, HlsFD)

# Generated at 2022-06-26 11:33:14.473785
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d = HlsFD(set(), str())
    assert(hls_f_d.__class__ == HlsFD)



# Generated at 2022-06-26 11:33:22.255340
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    print("Testing HlsFD real_download")
    # Create test objects
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_3['http_headers'] = dict_4
    dict_3['extra_param_to_segment_url'] = dict_2
    dict_3['is_live'] = dict_2
    dict_1['url'] = dict_2
    dict_1['fatal'] = dict_0
    dict_1['test'] = dict_0
    dict_1['fragment_retries'] = None
    dict_1['skip_unavailable_fragments'] = dict_0
    dict_0['subtitles'] = dict_1

# Generated at 2022-06-26 11:33:24.557053
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    set_0 = set()
    str_0 = 'xlohm1bT#a*$'
    hls_f_d_0 = HlsFD(set_0, str_0)
    hls_f_d_0.real_download(str_0, str_0)


# Generated at 2022-06-26 11:33:26.852682
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    set_2 = set()
    str_2 = 'xlohm1bT#a*$'
    hls_f_d_2 = HlsFD(set_2, str_2)
    b_0 = hls_f_d_2.real_download(str_2, str_2)


# Generated at 2022-06-26 11:33:28.121097
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass

test_HlsFD_real_download()

# Generated at 2022-06-26 11:33:36.653948
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    manifest = '#EXTM3U\n#EXT-X-STREAM-INF:VIDEO="1",FORMAT="mp4_hls_3d"\n1/s1D1GzBYT8X9jYTfRtP65THhf76g8OpL/main.m3u8'

# Generated at 2022-06-26 11:33:41.017365
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Parameter
    set_0 = set()
    str_0 = 'xlohm1bT#a*$'
    hls_f_d_0 = HlsFD(set_0, str_0)
    filename = 'ZLffs@n{de'
    info_dict = {'http_headers':'p=d|-L'}
    hls_f_d_0.real_download(filename, info_dict)

# Generated at 2022-06-26 11:33:48.249894
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pytest.skip('Unsupported')
    hls_fd = HlsFD(None)
    base_url = 'http://example.com/media.m3u8'
    playlist_url = base_url
    info_dict = {
        'id': '1',
        'url': playlist_url,
        'extractor': 'hls',
        'playlist': playlist_url,
        'player_url': 'https://example.com/video-player.js',
        'extractor_key': 'hlsnative',
    }
    with pytest.raises(Exception):
        hls_fd.real_download('media.m3u8', info_dict)

# Generated at 2022-06-26 11:33:51.785788
# Unit test for constructor of class HlsFD
def test_HlsFD():
    set_0 = set()
    str_0 = 'xlohm1bT#a*$'
    hls_f_d_0 = HlsFD(set_0, str_0)
    assert hls_f_d_0.fd_name == 'hlsnative'
    assert hls_f_d_0.params is None


# Generated at 2022-06-26 11:35:40.938281
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    set_0 = set()
    str_0 = 'xlohm1bT#a*$'
    hls_f_d_0 = HlsFD(set_0, str_0)
    var_0 = hls_f_d_0.can_download(str_0, str_0)



# Generated at 2022-06-26 11:35:46.623375
# Unit test for constructor of class HlsFD
def test_HlsFD():
    set_0 = set()
    str_0 = 'xlohm1bT#a*$'
    hls_f_d_0 = HlsFD(set_0, str_0)
    assert hls_f_d_0.params == str_0
    assert hls_f_d_0._progress_hooks == set_0

# Generated at 2022-06-26 11:35:53.462923
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD()
    str_0 = 'r2$g#W?9vB'
    str_1 = 'L-5%5RPSEy'
    dict_0 = {'http_headers': {'accept-language': 'nl-NL,nl;q=0.8,en-US;q=0.6,en;q=0.4'}}

# Generated at 2022-06-26 11:35:58.764953
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    url = 'https://test.url/test.m3u8?'
    info_dict = {'url': url}
    set_0 = set()
    hls_f_d_0 = HlsFD(set_0, str())
    hls_f_d_0.real_download('test', info_dict)
    hls_f_d_0.real_download('test', info_dict)
    hls_f_d_0.real_download('test', info_dict)


# Generated at 2022-06-26 11:35:59.914930
# Unit test for constructor of class HlsFD
def test_HlsFD():
    var_0 = HlsFD(set(), '')


# Generated at 2022-06-26 11:36:08.427291
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    set_0 = set()
    str_0 = '5PKMXwG%#@)KC'
    hls_f_d_0 = HlsFD(set_0, str_0)
    str_1 = 'Y2Q9ZnJlZQ=='
    info_dict_0 = {
        'username': 'avlvnddLhN',
        'thumbnail': 'http://i.ytimg.com/vi/YykmuWwKf0Y/maxresdefault.jpg',
        'http_headers': {
            'If-Modified-Since': 'Thu, 07 Jan 2016 01:32:10 GMT',
        },
        'alt_title': '',
        'url': str_1,
        'upload_date': '20160106'}

# Generated at 2022-06-26 11:36:10.427776
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD(set(), str())
    assert hls_f_d_0.FD_NAME == 'hlsnative'


# Generated at 2022-06-26 11:36:11.635764
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Test disabling of subtitiles downloading
    HlsFD.can_download(None, None)


# Generated at 2022-06-26 11:36:18.033139
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Test case: Simple run-through with the following test cases:
    # - (1) Non-encrypted;
    # - (2) Encrypted.
    #
    # Note: The fragment data is not correct in this test case, but it isn't
    # needed. All that's needed is to ensure the downloads happen and that
    # the proper information is extracted from the manifest.
    manifest_url = 'https://example.com/manifest.m3u8'