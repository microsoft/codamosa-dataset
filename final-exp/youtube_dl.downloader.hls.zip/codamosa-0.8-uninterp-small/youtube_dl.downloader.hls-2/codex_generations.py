

# Generated at 2022-06-26 11:26:40.871309
# Unit test for constructor of class HlsFD
def test_HlsFD():
    print('Testing constructor of class HlsFD')
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:26:44.141684
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_fd_0 = HlsFD(str(), set())
    hls_fd_0.real_download(str(), dict())
# Test if the test suite runs

# Generated at 2022-06-26 11:26:44.837612
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass

# Generated at 2022-06-26 11:26:49.338190
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_1 = HlsFD(str())
    str_1 = '3,.%"{,[Ii('
    set_1 = {str_1, str_1, str_1}
    hls_f_d_1.real_download(str_1, set_1)


# Generated at 2022-06-26 11:26:59.001647
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '3,.%"{,[Ii('
    str_1 = '4,4;#4"K\x7f"4'
    set_0 = {'A[\x1a\x1e', '\x1b\x0f\x1c', '\x1b\x1f\x1c', '\x1a\x1c\x1f'}
    set_1 = {'\x1b\x1f\x1c', '\x1a\x1c\x1f', 'A[\x1a\x1e'}
    set_2 = {'A[\x1a\x1e', '\x1b\x1f\x1c', '\x1a\x1c\x1f'}
    set_3

# Generated at 2022-06-26 11:26:59.701405
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert(HlsFD != None)



# Generated at 2022-06-26 11:27:12.502009
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # 1. First test with a live stream (expect to skip extraction)
    #    (Ref: https://github.com/ytdl-org/youtube-dl/issues/20372)
    class YDL:
        def report_warning(self, msg):
            assert 'hlsnative has detected features it does not support' in msg
            assert 'extraction will be delegated to ffmpeg' in msg
    ydl = YDL()
    class FD:
        FD_NAME = 'test'
        def __init__(self, ydl, params):
            pass
        def real_download(self, filename, info_dict):
            assert filename == 'test_file'
            assert info_dict == {'url': 'test_url',
                                 'is_live': True, }
            return False

# Generated at 2022-06-26 11:27:22.630852
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'https://example.com/manifest.m3u8'

# Generated at 2022-06-26 11:27:24.653971
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_1 = HlsFD(str(), set())
    assert not hls_f_d_1.real_download(str(), {})


# Generated at 2022-06-26 11:27:35.901029
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import mock
    import os
    import youtube_dl.YoutubeDL

    # Prepare the test
    test_case_0()

    # mock urlopen
    urlopen_patcher = mock.patch('youtube_dl.YoutubeDL.urlopen')
    urlopen_patcher.start()

    # mock report error
    report_error_patcher = mock.patch('youtube_dl.downloader.http.FragmentFD.report_error')
    report_error_patcher.start()

    # mock report warning
    report_warning_patcher = mock.patch('youtube_dl.downloader.http.FragmentFD.report_warning')
    report_warning_patcher.start()

    # mock download fragment

# Generated at 2022-06-26 11:27:58.541557
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:27:59.772512
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

test_HlsFD()

# Generated at 2022-06-26 11:28:03.799054
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    print('Testing HlsFD.real_download function.')

    test_case_0()

    print('HlsFD.real_download function tests passed.')


if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:28:04.923687
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:28:06.294005
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:28:11.772905
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_0 = 5177
    int_1 = 5261
    int_2 = 5989
    str_0 = 'B^5H'
    hls_f_d_0 = HlsFD(int_0, str_0)
    var_0 = hls_f_d_0.real_download(int_1, int_2)


# Generated at 2022-06-26 11:28:12.762524
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:28:13.696553
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:28:14.974838
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()


# Generated at 2022-06-26 11:28:20.172083
# Unit test for constructor of class HlsFD
def test_HlsFD():
    int_0 = 1715
    int_1 = -4460
    int_2 = -1843
    str_0 = 'iH"7'
    hls_f_d_0 = HlsFD(int_2, str_0)

    assert hls_f_d_0.FD_NAME == 'hlsnative'

# Generated at 2022-06-26 11:28:58.466815
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = None

# Generated at 2022-06-26 11:29:10.863241
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_0 = 925
    float_0 = 996.9870
    hls_f_d_0 = HlsFD(int_0, float_0)

    assert hls_f_d_0 == hls_f_d_0
    assert hls_f_d_0 != float_0
    assert id(hls_f_d_0) == id(hls_f_d_0)
    assert id(hls_f_d_0) != id(float_0)
    assert float_0 != hls_f_d_0

    str_0 = 'class=["\\\']views["\\\'][^>]*><p>([\\d,.]+)'

# Generated at 2022-06-26 11:29:13.094178
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD(570, 1482.462)

# Unit tests for download() of class HlsFD

# Generated at 2022-06-26 11:29:19.805868
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_0 = 5036
    str_0 = 'mp4'
    str_1 = 'http://example.com/test'
    hls_f_d_0 = HlsFD(int_0, str_0)
    assert not hls_f_d_0.real_download(str_1, str_1)
    #z3.prove(z3.Not(z3.Implies( z3.And(hls_f_d_0.real_download(str_1, str_1) == True), z3.Not(z3.Not(hls_f_d_0.real_download(str_1, str_1))))))


#     Prints the python code for the test case
#     f = open("W:\\fail64.txt", "w")
#     old_stdout

# Generated at 2022-06-26 11:29:25.639326
# Unit test for constructor of class HlsFD
def test_HlsFD():
    int_0 = -7
    float_0 = -3.16
    hls_f_d_0 = HlsFD(int_0, float_0)
    var_0 = hls_f_d_0.can_download(str_0, int_0)


# Generated at 2022-06-26 11:29:26.934985
# Unit test for constructor of class HlsFD
def test_HlsFD():
    int_0 = 0
    float_0 = 5
    hls_f_d_0 = HlsFD(int_0, float_0)


# Generated at 2022-06-26 11:29:34.390611
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Constructor for class HlsFD
    # __init__(self, ydl, params)
    # HlsFD(ydl, params)
    assert 'ydl' in HlsFD.__init__.__code__.co_varnames
    assert 'params' in HlsFD.__init__.__code__.co_varnames
    assert 'self' in HlsFD.__init__.__code__.co_varnames
    hls_f_d_0 = HlsFD(44, 20)
    assert hls_f_d_0 is not None


# Generated at 2022-06-26 11:29:37.260595
# Unit test for constructor of class HlsFD
def test_HlsFD():
    int_0 = 431
    float_0 = 2818.9489
    hls_f_d_0 = HlsFD(int_0, float_0)


# Generated at 2022-06-26 11:29:40.363599
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD(9, 31)
    str_0 = 'class=["\\\']views["\\\'][^>]*><p>([\\d,.]+)'
    int_0 = 83
    int_1 = 985
    float_0 = 2537.6
    hls_f_d_0.real_download(int_1, str_0)
    hls_f_d_0.real_download(int_1, str_0)
    hls_f_d_0.real_download(int_1, str_0)


# Generated at 2022-06-26 11:29:46.791365
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = ('#EXTM3U\n'
             '#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=246567\n'
             'index_0_av.m3u8?null=0\n'
             '#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=684900\n'
             'index_1_av.m3u8?null=0\n')
    json_0 = {"_type": "url", "_duration": 300.039, "_stream_info": {"_duration": 300.039}, "_filename": "index_0_av.m3u8"}
    hls_f_d_0 = HlsFD(1, 1.0)
    assert hls_

# Generated at 2022-06-26 11:30:45.055538
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD(0.90436695091247, 0.822837591171265, 1568199783)
    hls_f_d_0.real_download('/home/student', 1568199783)
    hls_f_d_0.report_error('\x28\x43\x89\x45\x38\x4a\x4c\x43\x48\x4a\x4e\x4e\x4a\x38')


# Generated at 2022-06-26 11:30:46.960513
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert(HlsFD(4, 7))

# Generated at 2022-06-26 11:30:57.219502
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'https://www.instagram.com/p/Bx4P4o_BJio/'
    int_0 = 727
    float_0 = 712.8672
    try:
        from Crypto.Cipher import AES
        can_decrypt_frag = True
    except ImportError:
        can_decrypt_frag = False
    if not can_decrypt_frag:
        return 
    hls_f_d_0 = HlsFD(int_0, float_0)
    hls_f_d_0.real_download(str_0, int_0)
    return hls_f_d_0

if __name__ == "__main__":
    hls_f_d_0 = test_HlsFD()
    hls_f_d

# Generated at 2022-06-26 11:31:00.271192
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD(None, None)
    int_0 = 349
    float_0 = 4.6728
    hls_f_d_0.real_download('filename_0', int_0)


# Generated at 2022-06-26 11:31:02.280383
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    HlsFD.real_download(str, dict)
    #test_case_0()

# Generated at 2022-06-26 11:31:08.607068
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    print("Testing real_download in HlsFD") 
    str_0 = 'class=["\\\']views["\\\'][^>]*><p>([\\d,.]+)'
    int_0 = 431
    float_0 = 2818.9489
    hls_f_d_0 = HlsFD(int_0, float_0)
    var_0 = hls_f_d_0.real_download(str_0, int_0) 
    assert type(var_0) == bool 
    assert var_0 == True 
    # lgtm [py/test/wrong-arguments] False positive: test_case_1() accepts two arguments, but is called with only one argument
    # lgtm [py/test/wrong-arguments] False positive: test_HlsFD_real_download

# Generated at 2022-06-26 11:31:18.689115
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_0 = 652
    float_0 = 495.02
    hls_f_d_0 = HlsFD(int_0, float_0)
    str_0 = 'b'
    str_1 = '#EXT-X-BYTERANGE:470012@0'
    str_2 = 'a'
    str_3 = '#EXTINF:5,'
    str_4 = '#EXT-X-MEDIA-SEQUENCE:0'
    str_5 = '#EXT-X-KEY:METHOD=AES-128,URI="https://priv.example.com/key.php?r=52",IV=0x9c7db8778570d05c3177c349fd9236aa,KEYFORMAT="com.apple.streamingkeydelivery"\n'
    str_6

# Generated at 2022-06-26 11:31:27.265911
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .external import FFmpegFD
    from ..downloader import Downloader
    from ..extractor.common import InfoExtractor
    from ..compat import compat_urllib_request
    from ..downloader.common import FileDownloader
    from ..utils import (
         download_json,
        )
    from ..extractor.generic import GenericIE
    from ..postprocessor import (
         FFmpegExtractAudioPP,
        )

    # Test case #0
    if True:
        str_0 = 'class=["\\\']views["\\\'][^>]*><p>([\\d,.]+)'
        int_0 = 431
        float_0 = 2818.9489
        hls_f_d_0 = HlsFD(int_0, float_0)
        var_0 = hls_f_d

# Generated at 2022-06-26 11:31:37.448436
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'class=["\\\']views["\\\'][^>]*><p>([\\d,.]+)'
    int_0 = 431
    float_0 = 2818.9489
    hls_f_d_0 = HlsFD(int_0, float_0)
    var_0 = hls_f_d_0.real_download(str_0, int_0)
    int_0 = -8199
    float_0 = 4.25209
    int_1 = -2586
    float_1 = 7.4645
    int_2 = 99
    float_2 = 5.5534
    int_3 = -718
    float_3 = -1.142
    int_4 = -6460
    float_4 = 2.5336
    int_5 = 8929

# Generated at 2022-06-26 11:31:38.553819
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert(callable(HlsFD))


# Generated at 2022-06-26 11:34:17.119109
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'class=["\\\']views["\\\'][^>]*><p>([\\d,.]+)'
    int_0 = 431
    float_0 = 2818.9489
    hls_f_d_0 = HlsFD(int_0, float_0)
    str_1 = '&defaultPlaybackUI=1&vpc=1&fmt=18'
    str_2 = '.mp4'
    str_3 = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    str_4 = 'Youtube watch page'

# Generated at 2022-06-26 11:34:23.515034
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    man_url = 'https://example.com/manifest.m3u'

# Generated at 2022-06-26 11:34:29.056189
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Local variable declaration
    str_0 = 'class=["\\\']views["\\\'][^>]*><p>([\\d,.]+)'
    int_0 = 431
    float_0 = 2818.9489
    hls_f_d_0 = HlsFD(int_0, float_0)
    var_0 = hls_f_d_0.real_download(str_0, int_0)

# Generated at 2022-06-26 11:34:32.405985
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Currently, there is no real testing for HlsFD.real_download.
    pass


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:34:34.626424
# Unit test for constructor of class HlsFD
def test_HlsFD():
    int_0 = 67
    float_0 = 7563.32
    hls_f_d_0 = HlsFD(int_0, float_0)


# Generated at 2022-06-26 11:34:41.755772
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '^\\/\\/yt\\-dash-mse-test\\.commondatastorage\\.googleapis\\.com\\/media\\/car-20120827-manifest\\.mpd$'
    int_0 = 439
    float_0 = 882.0
    hls_f_d_0 = HlsFD(int_0, float_0)
    str_1 = hls_f_d_0.real_download(str_0, int_0)


# Generated at 2022-06-26 11:34:43.292890
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    var_0 = HlsFD()
    assert var_0.real_download('test_file', 'test_url') == False

# Generated at 2022-06-26 11:34:49.554885
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '|'
    int_0 = 431
    float_0 = 2818.9489
    int_1 = 52
    float_1 = 8.864
    hls_f_d_0 = HlsFD(int_0, float_0)
    var_0 = hls_f_d_0.real_download(str_0, int_1)

# Generated at 2022-06-26 11:34:50.615096
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass

if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-26 11:34:53.503545
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    var_0 = HlsFD()
    var_1 = '1'
    var_0.real_download(var_1, None)