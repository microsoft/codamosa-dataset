

# Generated at 2022-06-26 11:26:46.227032
# Unit test for constructor of class HlsFD
def test_HlsFD():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    hls_f_d_0 = HlsFD(tuple_0, set_0)

    # Check if attributes were created properly
    assert_true(hasattr(hls_f_d_0, 'ydl'))
    assert_true(hasattr(hls_f_d_0, 'params'))
    assert_true(hasattr(hls_f_d_0, '_progress_hooks'))

    # Check if the HlsFD was initialised correctly
    assert_equals(hls_f_d_0.ydl, tuple_0)
    assert_equals(hls_f_d_0.params, set_0)

# Generated at 2022-06-26 11:26:48.161885
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()


if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:26:51.215668
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Unit tests for the class methods of class HlsFD
if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:27:00.541120
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    hls_f_d_0 = HlsFD(tuple_0, set_0)
    test_string_0 = 'AG2QdxDsxnPl'
    test_string_1 = 'kaeHj5f5P5o5'
    test_string_2 = 'B6U0c6Oqblbr'
    test_string_3 = 'bzdYJdPYbRXr'
    test_string_4 = 'jcbRuh4k4N4h'
    test_string_5 = 't2Sogt8hTULa'
    test_string_6 = 'n8wLnYdYV7lF'
    test_dict_

# Generated at 2022-06-26 11:27:07.249407
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    hls_f_d_0 = HlsFD(tuple_0, set_0)
    dict_0 = {'_enc_key': None, '_decrypt_info': None, '_seekable': None, '_initialization_segment_url': None, '_initialization_segment_size': None, '_initialization_segment_bytes': None}
    dict_1 = {'_enc_key': None, '_decrypt_info': None, '_seekable': None, '_initialization_segment_url': None, '_initialization_segment_size': None, '_initialization_segment_bytes': None}

# Generated at 2022-06-26 11:27:09.675217
# Unit test for constructor of class HlsFD
def test_HlsFD():
    if __name__ == '__main__':
        test_case_0()


# Generated at 2022-06-26 11:27:10.403736
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:27:16.139905
# Unit test for constructor of class HlsFD
def test_HlsFD():
    tuple_0 = ()
    set_0 = {tuple_0, tuple_0, tuple_0}
    hls_f_d_0 = HlsFD(tuple_0, set_0)
    assert isinstance(hls_f_d_0, HlsFD)

if __name__ == '__main__':
    test_case_0()
    test_HlsFD()

# Generated at 2022-06-26 11:27:17.229794
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:27:18.327080
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass


# Generated at 2022-06-26 11:27:36.933375
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_2 = '(o'
    float_0 = 309.6
    tuple_0 = ()
    hls_f_d_0 = None
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0, tuple_0: hls_f_d_0}
    hls_f_d_1 = HlsFD(dict_0, dict_0)
    
    assert(hls_f_d_1.real_download(str_2, float_0) == False)


# Generated at 2022-06-26 11:27:40.061282
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD(HlsFD.FD_NAME, 'http://localhost:8080/test/none.m3u8')
    hls_f_d_0.can_download('#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=1500000', {})

# Generated at 2022-06-26 11:27:42.480613
# Unit test for constructor of class HlsFD
def test_HlsFD():
    dict_0 = {}
    dict_0 = {dict_0: dict_0}
    hls_f_d_0 = HlsFD(dict_0, dict_0)

if __name__ == "__main__":
    test_HlsFD()

# Test case for can_download method

# Generated at 2022-06-26 11:27:45.847161
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = None
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0, tuple_0: hls_f_d_0}
    hls_f_d_1 = HlsFD(dict_0, dict_0)

    assert hls_f_d_1 is not None


# Generated at 2022-06-26 11:27:52.621682
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = '(o'
    float_0 = 309.6
    tuple_0 = ()
    hls_f_d_0 = None
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0, tuple_0: hls_f_d_0}
    hls_f_d_1 = HlsFD(dict_0, dict_0)

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:27:54.254346
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()


# Generated at 2022-06-26 11:27:58.872005
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '9l!y'
    float_0 = 309.6
    tuple_0 = ()
    hls_f_d_0 = None
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0, tuple_0: hls_f_d_0}
    hls_f_d_1 = HlsFD(dict_0, dict_0)
    var_0 = hls_f_d_1.real_download(str_0, float_0)
    assert var_0

###
test_case_0()
test_HlsFD_real_download()

# Generated at 2022-06-26 11:28:03.296369
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = '(o'
    float_0 = 309.6
    tuple_0 = ()
    hls_f_d_0 = None
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0, tuple_0: hls_f_d_0}
    hls_f_d_1 = HlsFD(dict_0, dict_0)
    return hls_f_d_1

# Test whether method FD.can_download can be called without crashing

# Generated at 2022-06-26 11:28:08.523860
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD({}, {})
    assert hls_f_d_0.FD_NAME == 'hlsnative'
    assert hls_f_d_0.real_download({}, {}) == False


test_case_0()
test_HlsFD()
print('Passed all test cases.')

# Generated at 2022-06-26 11:28:17.087431
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    str_0 = '(o'
    float_0 = 309.6
    tuple_0 = ()
    hls_f_d_0 = None
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0, tuple_0: hls_f_d_0}
    hls_f_d_1 = HlsFD(dict_0, dict_0)
    var_0 = hls_f_d_1.can_download(str_0, float_0)
    assert var_0 == True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:28:44.955086
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:28:51.027608
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    filename = "test_filename"
    info_dict = {'url': "test_url", 'urlh': "test_urlh"}
    float_0 = 12.12
    str_0 = "a"
    hls_f_d_0 = HlsFD(float_0, str_0)
    hls_f_d_0.real_download(filename, info_dict)

# Generated at 2022-06-26 11:29:00.917486
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'PZ,Bk8X@s>'
    str_1 = '\t2: .'
    list_0 = [str_1, str_0, str_1, str_1, str_1, str_1, str_0, str_1, str_1, str_0, str_1, str_1, str_1, str_1, str_1, str_0, str_0, str_1, str_1, str_1, str_0, str_1, str_1, str_1, str_1, str_1, str_1, str_0, str_1, str_0, str_1, str_1, str_1, str_1, str_0]
    float_0 = 67.14
    hls_f_d_0 = Hls

# Generated at 2022-06-26 11:29:07.216507
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'isNa#D/V:BBG\\<(_\nT'
    list_0 = None
    tuple_0 = (list_0,)
    float_0 = -104.53
    hls_f_d_0 = HlsFD(float_0, str_0)
    var_0 = hls_f_d_0.real_download(str_0, tuple_0)

# Generated at 2022-06-26 11:29:11.885425
# Unit test for constructor of class HlsFD
def test_HlsFD():
    print('\nTesting HlsFD constructor')
    test_case_0()
    print('\nHlsFD constructor test complete')


if __name__ == '__main__':
    print('\nTesting HlsFD.py\n')
    test_HlsFD()
    print('\nAll tests complete!\n')

# Generated at 2022-06-26 11:29:19.331181
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert True == HlsFD.can_download(
        '#EXTM3U\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=93000\nmedia_w93000.m3u8',
        {'url': 'http://example.com/fileSequence93000.m3u8'})

# Generated at 2022-06-26 11:29:26.269640
# Unit test for constructor of class HlsFD
def test_HlsFD():
    filename_0 = 'I'
    info_dict_0 = {'url': 'I', 'method': 'GET'}
    hls_f_d_0 = HlsFD({'username': 'I', 'forcefilename': filename_0}, filename_0)
    var_0 = hls_f_d_0.real_download(filename_0, info_dict_0)


# Generated at 2022-06-26 11:29:27.200082
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:29:35.878529
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Test Inputs
    float_0 = float('-inf')
    str_0 = '{a}'
    str_1 = '!(a>3Bc'
    list_0 = list()
    tuple_0 = (list_0,)
    hls_f_d_0 = HlsFD(float_0, str_0)
    var_0 = hls_f_d_0.can_download(str_0, tuple_0)
    hls_f_d_1 = HlsFD(0, str_1)
    var_1 = hls_f_d_1.can_download(str_0, tuple_0)



# Generated at 2022-06-26 11:29:42.082860
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'isNa#D/V:BBG\\<(_\nT'
    list_0 = None
    tuple_0 = (list_0,)
    float_0 = -104.53
    str_1 = '%(count)d/%(total)d'
    hls_f_d_0 = HlsFD(float_0, str_0)
    var_0 = hls_f_d_0.real_download(str_1, tuple_0)

# Generated at 2022-06-26 11:30:18.095431
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    str_in = 'uL?iUDr5~,/kB\\:UE'
    float_in = 2035.438
    hls_f_d_0 = HlsFD(float_in, str_in)
    var_0 = hls_f_d_0.can_download(str_in, float_in)
    assert(var_0 == 0)


# Generated at 2022-06-26 11:30:20.915932
# Unit test for constructor of class HlsFD
def test_HlsFD():
    int_0 = 12
    str_0 = 'c%hv~a"F0Y9z*#}k)A'
    hls_f_d_0 = HlsFD(int_0, str_0)


# Generated at 2022-06-26 11:30:25.797839
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'http://dummy.com'
    str_1 = 'uL?iUDr5~,/kB\\:UE'
    hls_f_d_0 = HlsFD(str_1, str_0)
    download(str_0, dict(), hls_f_d_0)


# Generated at 2022-06-26 11:30:31.954308
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_1 = 'C%CrO@a`o"`"<`Pp'
    float_1 = 2771.9293555886587
    hls_f_d_1 = HlsFD(float_1, str_1)
    var_1 = hls_f_d_1.real_download(str_1, float_1)

# Generated at 2022-06-26 11:30:33.020762
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:30:42.964754
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'uL?iUDr5~,/kB\\:UE'
    float_0 = 2035.438
    hls_f_d_0 = HlsFD(float_0, str_0)
    var_0 = hls_f_d_0.can_download(str_0, float_0)
    assert var_0 == True
    str_1 = 'uL?iUDr5~,/kB\\:UE'
    float_1 = 2035.438
    str_2 = 'uL?iUDr5~,/kB\\:UE'
    var_0 = hls_f_d_0.real_download(str_1, float_1, str_2)
    assert var_0 == True

# Generated at 2022-06-26 11:30:44.973764
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    res = HlsFD.real_download("https://example.com/", {"url":"https://example.com/manifest.m3u8"})
    assert res == False, "Wrong return value!"

# Generated at 2022-06-26 11:30:50.695880
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    str_0 = '4>`'
    float_0 = 0.15
    hls_f_d_0 = HlsFD(float_0, str_0)
    str_1 = 'm#0Z'
    float_1 = 0.7
    var_0 = hls_f_d_0.can_download(str_1, float_1)


# Generated at 2022-06-26 11:31:00.303105
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-26 11:31:07.880944
# Unit test for constructor of class HlsFD

# Generated at 2022-06-26 11:32:37.959708
# Unit test for constructor of class HlsFD
def test_HlsFD():
    float_0 = 2035.438
    str_0 = 'uL?iUDr5~,/kB\\:UE'
    float_0 = 2035.438
    str_0 = 'uL?iUDr5~,/kB\\:UE'
    hls_f_d_2 = HlsFD(float_0, str_0)
    hls_f_d_3 = HlsFD(float_0, str_0)
    hls_f_d_4 = HlsFD(float_0, str_0)
    hls_f_d_5 = HlsFD(float_0, str_0)
    hls_f_d_6 = HlsFD(float_0, str_0)

# Generated at 2022-06-26 11:32:41.836525
# Unit test for constructor of class HlsFD
def test_HlsFD():
    #class HlsFD(FragmentFD):

    # This is an independent test case.
    try:
        test_case_0()
    except:
        print('Exception raised during the testing of constructor of class HlsFD')
    else:
        print('Testing of constructor of class HlsFD successful')

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:32:48.631931
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'uL?iUDr5~,/kB\\:UE'
    float_0 = 2035.438
    hls_f_d_0 = HlsFD(float_0, str_0)
    var_0 = hls_f_d_0.can_download(str_0, float_0)
    hls_f_d_0.real_download(float_0, str_0)


# Generated at 2022-06-26 11:32:56.357695
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 29.671499060280697
    str_0 = 'YmY[:o]-yA9e!D_!*:-'
    hls_f_d_0 = HlsFD(float_0, str_0)
    str_0 = '6;%p"Z/U6JqC<Qr0r6d}R:!G'
    str_0 = 'z6;%p"Z/U6JqC<Qr0r6d}R:!G'
    bool_0 = hls_f_d_0.real_download(str_0, str_0)
    assert bool_0 == True



# Generated at 2022-06-26 11:32:58.773126
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # should return False
    assert HlsFD.real_download('filename', 'info_dict') == False

# Generated at 2022-06-26 11:33:02.705981
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'uL?iUDr5~,/kB\\:UE'
    float_0 = 2035.438
    hls_f_d_0 = HlsFD(float_0, str_0)
    bool_0 = hls_f_d_0.real_download(str_0, float_0)
    assert bool_0 == False



# Generated at 2022-06-26 11:33:08.486164
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    print('testing real_download')
    str_0 = 'uL?iUDr5~,/kB\\:UE'
    float_0 = 2035.438
    str_1 = 'uL?iUDr5~,/kB\\:UE'
    hls_f_d_0 = HlsFD(float_0, str_0)
    hls_f_d_0.real_download(str_0, str_1)


if __name__ == '__main__':
    #test_HlsFD_real_download()
    test_case_0()

# Generated at 2022-06-26 11:33:09.322682
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass


# Generated at 2022-06-26 11:33:10.222012
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:33:15.926762
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # different values
    args_0 = 'PI\t|!$'
    kwargs_0 = 'io\tW1'
    # Create HlsFD object
    hls_f_d_0 = HlsFD(**kwargs_0)
    # Call method: HlsFD.real_download
    hls_f_d_0.real_download(*args_0)

test_case_0()
test_HlsFD_real_download()