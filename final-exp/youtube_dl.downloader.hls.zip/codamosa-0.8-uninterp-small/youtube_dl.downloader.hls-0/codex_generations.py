

# Generated at 2022-06-26 11:26:47.581751
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    manifest = '#EXTM3U\n#EXT-X-KEY:METHOD=NONE\nhttp://localhost/segment_1.ts'
    info_dict = {'url': 'http://localhost/master.m3u8'}
    filename = 'test_filename'
    assert HlsFD.can_download(manifest, info_dict)
    hls_fd = HlsFD([], {})
    assert hls_fd.real_download(filename, info_dict) is True

if __name__ == '__main__':
    test_case_0()
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:26:58.035370
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    list_0 = []
    bytes_0 = None
    hls_f_d_0 = HlsFD(list_0, bytes_0)
    assert hls_f_d_0.can_download(None, None)
    assert ~hls_f_d_0.can_download(None, None)
    assert ~hls_f_d_0.can_download(None, None)
    assert hls_f_d_0.can_download(None, None)
    assert ~hls_f_d_0.can_download(None, None)
    assert ~hls_f_d_0.can_download(None, None)
    assert hls_f_d_0.can_download(None, None)

# Generated at 2022-06-26 11:27:03.536714
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    list_0 = []
    bytes_0 = None
    hls_f_d_0 = HlsFD(list_0, bytes_0)
    manifest_0 = ""
    info_dict_0 = dict()
    var_0 = HlsFD.can_download(manifest_0, info_dict_0)
    print(var_0)

    filename = "filename"
    info_dict = dict()
    var_1 = hls_f_d_0.real_download(filename, info_dict)
    print(var_1)

if __name__ == '__main__':
    test_case_0()
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:27:10.188457
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Case 0
    list_0 = []
    bytes_0 = None
    hls_f_d_0 = HlsFD(list_0, bytes_0)
    # Case 1
    list_1 = [1, 2, 3]
    bytes_1 = b'\x01'
    hls_f_d_1 = HlsFD(list_1, bytes_1)


# Generated at 2022-06-26 11:27:13.832909
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Tested Method: real_download
    # Tested Classes: [class HlsFD]
    print('Test case: HlsFD real_download')

    # Tested Method: real_download
    # Tested Classes: [class HlsFD]


# Generated at 2022-06-26 11:27:18.934544
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    list_0 = []
    bytes_0 = None
    hls_f_d_0 = HlsFD(list_0, bytes_0)
    str_0 = ''
    dict_0 = {}
    assert isinstance(hls_f_d_0.can_download(str_0, dict_0), bool)


# Generated at 2022-06-26 11:27:22.046002
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD([], None)
    hls_f_d_0.real_download('', '')


if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:27:26.752598
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    list_0 = []
    bytes_0 = None
    hls_f_d_0 = HlsFD(list_0, bytes_0)
    filename_0 = None
    info_dict_0 = {}
    hls_f_d_0.real_download(filename_0, info_dict_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:27:28.396523
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:27:33.629913
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    list_0 = []
    bytes_0 = None
    hls_f_d_0 = HlsFD(list_0, bytes_0)
    filename_0 = "1lCMG1XHWNiik"
    info_dict_0 = {}
    hls_f_d_0.real_download(filename_0, info_dict_0)

# Generated at 2022-06-26 11:27:52.611155
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()
    print('Test for real_download method')
    print('Test for real_download method is Finished!')



# Generated at 2022-06-26 11:27:54.255126
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hlsfd_0 = HlsFD()


# Generated at 2022-06-26 11:27:56.420574
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hlsFD = HlsFD(None, None)
    assert (hlsFD != None), 'Failed to create HlsFD instance'


# Generated at 2022-06-26 11:28:03.687988
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    var_0 = HlsFD()
    str_0 = 'Test case: HlsFD real_download'
    var_1 = print(str_0)
    str_0 = '\n'
    var_1 = print(str_0)
    str_0 = '\n'
    var_1 = print(str_0)
    str_0 = '\n'
    var_1 = print(str_0)
    str_0 = '\n'
    var_1 = print(str_0)
    str_0 = '\n'
    var_1 = print(str_0)
    str_0 = '\n'
    var_1 = print(str_0)
    str_0 = '\n'
    var_1 = print(str_0)

# Generated at 2022-06-26 11:28:10.027186
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():

    # Test case: HlsFD real_download
    try:
        assert (test_case_0())
    except AssertionError as e:
        print('Fail: test_HlsFD_real_download')
        print(e)
    else:
        print('Success: test_HlsFD_real_download')

if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:28:11.774741
# Unit test for constructor of class HlsFD
def test_HlsFD():
    print('...Test HlsFD')
    # Todo: Case for which test for HlsFD fails


# Generated at 2022-06-26 11:28:13.477736
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    var_0 = assertEqual('Could not pass real_download test case', 1, 1)



# Generated at 2022-06-26 11:28:24.404390
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Setup
    str_0 = 'Test case: HlsFD real_download'
    var_0 = print(str_0)

    # Unit tests
    # TODO: test for real_download of class HlsFD
    # TODO: test for real_download of class HlsFD
    # TODO: test for real_download of class HlsFD
    # TODO: test for real_download of class HlsFD
    # TODO: test for real_download of class HlsFD
    # TODO: test for real_download of class HlsFD
    # TODO: test for real_download of class HlsFD
    # TODO: test for real_download of class HlsFD
    # TODO: test for real_download of class HlsFD
    # TODO: test for real_download of class HlsFD



# Generated at 2022-06-26 11:28:26.358224
# Unit test for constructor of class HlsFD
def test_HlsFD():
    print('Test Complete')
    pass

if __name__ == '__main__':
    test_case_0()
    test_HlsFD()

# Generated at 2022-06-26 11:28:29.458194
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()
    # Create a HlsFD object
    # var_3 = HlsFD(, )
    # real_download(filename, info_dict)

# Generated at 2022-06-26 11:28:41.947545
# Unit test for constructor of class HlsFD
def test_HlsFD():
    print("Unit test for constructor of class HlsFD")


# Generated at 2022-06-26 11:28:52.540578
# Unit test for constructor of class HlsFD
def test_HlsFD():
    url = 'http://example.com/test.m3u8'
    ydl = 'ydl object'
    params = {'youtube_include_dash_manifest': False}
    hls_f_d = HlsFD(ydl, params)
    urlh = hls_f_d.ydl.urlopen(url)
    s = urlh.read().decode('utf-8', 'ignore')
    assert(hls_f_d.can_download(s) == True)
    assert(hls_f_d.manifest_url == url)
    assert(hls_f_d.ydl == ydl)
    assert(hls_f_d.params == params)

# Generated at 2022-06-26 11:28:55.682555
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_1 = HlsFD()  # Constructs class HlsFD


# Generated at 2022-06-26 11:29:02.689771
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hlsfd = HlsFD()
    url = "http://www.streambox.fr/playlists/test_001/stream.m3u8"
    info_dict = {
        "url": url,
        "_decryption_key_url": "http://www.streambox.fr/playlists/test_001/key.bin",
        "http_headers": {"User-Agent": "Mozilla/5.0 (X11; Linux i686; rv:2.0.1) Gecko/20100101 Firefox/4.0.1"}
    }
    filename = "test.ts"
    hlsfd.real_download(filename, info_dict)


if __name__ == "__main__":
    try:
        test_HlsFD_real_download()
    except:
        pass

# Generated at 2022-06-26 11:29:14.656936
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_1 = HlsFD()
    media_frags = 0
    ad_frags = 0
    test_urls = ['https://d2zihajmogu5jn.cloudfront.net/bipbop-advanced/bipbop_16x9_variant.m3u8',
                 'https://d2zihajmogu5jn.cloudfront.net/bipbop-advanced/bipbop_4x3_variant.m3u8',
                 'https://d2zihajmogu5jn.cloudfront.net/bipbop-advanced/bipbop_4x3_variant.m3u8']

# Generated at 2022-06-26 11:29:26.761672
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:1\n#EXT-X-KEY:METHOD=NONE\nfoo.ts\n#EXTINF:1.0\nbar.ts\n#EXT-X-ENDLIST', {})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:1\n#EXT-X-KEY:METHOD=SOMETHING\nfoo.ts\n#EXTINF:1.0\nbar.ts\n#EXT-X-ENDLIST', {})

# Generated at 2022-06-26 11:29:29.562152
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert hls_f_d_0.FD_NAME == 'hlsnative'

if __name__ == '__main__':
    test_case_0()
    test_HlsFD()

# Generated at 2022-06-26 11:29:36.013614
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d = HlsFD()

    # Test set of instance variables
    assert hls_f_d.ydl is None
    assert hls_f_d.params is None
    assert hls_f_d._progress_hooks is None

    # Test set of instance methods
    assert hls_f_d.can_download('', '') is not None
    assert hls_f_d.real_download('', '') is not None


# Generated at 2022-06-26 11:29:38.222361
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_1 = HlsFD()
    assert hls_f_d_1 is not None


# Generated at 2022-06-26 11:29:39.134902
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # No test available
    return True


# Generated at 2022-06-26 11:30:00.176297
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Arguments:
    # - self: object instance
    # - filename: str
    # - info_dict: dict
    # Attributes:
    # - params: dict
    # - ydl: YoutubeDL
    # - FD_NAME: str
    # Application:
    # - return: bool
    # 1. Download the m3u8 manifest
    # 2. Detect whether the fragment download can be delegated to ffmpeg
    # 3. Prepare the context for fragment download
    # 4. Start the fragment download
    # 5. Download the fragments
    # 6. Finish the fragment download
    # 7. Return true
    test_case_0()
    # Test for if (not self.can_download(s, info_dict)):
    test_case_0()
    # Test for if (fragment_retries > 0):
    test

# Generated at 2022-06-26 11:30:04.471087
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_fd_0 = HlsFD(dict(), dict())
    hls_fd_0.real_download(str(), dict())

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:30:05.957762
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

test_HlsFD()

# Generated at 2022-06-26 11:30:06.922107
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:30:08.464913
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert (test_case_0() == True)


# Generated at 2022-06-26 11:30:09.966313
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Unit test of class HlsFD

# Generated at 2022-06-26 11:30:10.976059
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:30:11.957741
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:30:21.463393
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = float('inf')
    float_1 = float('-inf')
    float_2 = float('nan')
    str_0 = str('TKj!_x"')
    str_1 = str()
    str_2 = str('TKj!_x')
    bool_0 = bool()
    bool_1 = bool(0)
    bool_2 = bool(1)
    int_0 = int(57)
    int_1 = int(84)
    dict_0 = dict()
    dict_0[str_2] = float_2
    dict_1 = dict()
    dict_1[str_0] = float_2
    dict_2 = dict()
    dict_2[str_1] = bool_1
    dict_3 = dict()
    dict_4 = dict()

# Generated at 2022-06-26 11:30:23.144552
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()



# Generated at 2022-06-26 11:30:49.862784
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_0 = 47
    str_0 = 'simne'
    bool_0 = True
    hls_f_d_0 = HlsFD(str_0, bool_0)
    hls_f_d_0.can_download(str_0, int_0)

# Generated at 2022-06-26 11:30:51.923939
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_fd = HlsFD("A", True)

    assert(hls_fd.params == {"A" : True})


# Generated at 2022-06-26 11:31:02.427856
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Test 1: The two parameters of the constructor are strings
    hls_f_d_0 = HlsFD('cirmid;', 'cirmid;')
    hls_f_d_0_output = hls_f_d_0.can_download('cirmid;', 29)
    assert hls_f_d_0_output == False

    # Test 2: The first parameter of the constructor is a string and the second is a bool
    hls_f_d_1 = HlsFD('cirmid;', True)
    hls_f_d_1_output = hls_f_d_1.can_download('cirmid;', 29)
    assert hls_f_d_1_output == False

    # Test 3: If the second parameter to the constructor is false, the can_download function

# Generated at 2022-06-26 11:31:05.354417
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_0 = 29
    str_0 = 'cirmid;'
    bool_0 = False
    hls_f_d_0 = HlsFD(str_0, bool_0)
    bool_1 = hls_f_d_0.real_download(str_0, int_0)

# Generated at 2022-06-26 11:31:06.887292
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass


if __name__ == "__main__":
    test_case_0()
    test_HlsFD()

# Generated at 2022-06-26 11:31:14.478261
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_0 = 29
    str_0 = 'cirmid;'
    str_1 = 'cdmwvb;'
    bool_0 = False
    hls_f_d_0 = HlsFD(str_0, bool_0)
    # Check for unexpected exception
    var_0 = hls_f_d_0.real_download(str_0, int_0)

if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:31:18.522567
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_0 = 29
    str_0 = 'cirmid;'
    bool_0 = False
    hls_f_d_0 = HlsFD(str_0, bool_0)
    hls_f_d_0.real_download(str_0, int_0)

# Generated at 2022-06-26 11:31:22.949476
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_0 = 3
    str_0 = 'brdw'
    str_1 = 'gTeV'
    bool_0 = True
    hls_f_d_0 = HlsFD(str_1, bool_0)
    hls_f_d_0.real_download(str_0, int_0)


# Generated at 2022-06-26 11:31:30.159695
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    url = "http://www.youtube.com/watch?v=P-k4YU8z6_s"

# Generated at 2022-06-26 11:31:34.523053
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_0 = 0
    str_0 = '8.8.8.8'
    hls_f_d_0 = HlsFD(str_0, True)
    assert hls_f_d_0.real_download(str_0, int_0) == True


# Generated at 2022-06-26 11:32:30.165898
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD("lq0lw", True)
    assert hls_f_d_0._prepare_url("", "") == "", 'Test for constructor of class HlsFD failed'


# Generated at 2022-06-26 11:32:33.687969
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = '5wDAz/iJ/6'
    bool_0 = True
    hls_f_d_0 = HlsFD(str_0, bool_0)
    assert hls_f_d_0.FD_NAME == 'hlsnative'


# Generated at 2022-06-26 11:32:34.457645
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    test_case_0()


# Generated at 2022-06-26 11:32:40.136372
# Unit test for constructor of class HlsFD
def test_HlsFD():
  from ..YoutubeDL import YoutubeDL
  from ._common import FakeYDL
  from ..extractor import youtube
  from .dash import YoutubeDASHIE
  ydl = FakeYDL()
  ydl.params['nopart'] = True
  ydl.add_info_extractor(youtube.YoutubeIE())
  ydl.add_info_extractor(YoutubeDASHIE(ydl))

# Generated at 2022-06-26 11:32:43.688614
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'cirmid;'
    bool_0 = True
    hls_f_d_1 = HlsFD(str_0, bool_0)
    hls_f_d_1.real_download(str_0, bool_0)


# Generated at 2022-06-26 11:32:48.357557
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'cirmid;'
    bool_0 = True
    hls_f_d_0 = HlsFD(str_0, bool_0)
    hls_f_d_0.real_download(str_0, bool_0)

# Generated at 2022-06-26 11:32:50.880847
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    obj_0 = HlsFD(str_0, bool_0)
    obj_0.real_download(str_0, bool_0)

test_case_0()
test_HlsFD_real_download()

# Generated at 2022-06-26 11:32:55.398654
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    arg_0 = 'njnfid'
    arg_1 = 'cirmid;'
    hls_f_d_0 = HlsFD(arg_0, arg_1)
    var_0 = hls_f_d_0.real_download(arg_0, arg_1)

test_case_0()

# Generated at 2022-06-26 11:32:57.915946
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    str_0 = 'cirmid;'
    bool_0 = True
    hls_f_d_0 = HlsFD(str_0, bool_0)
    var_0 = hls_f_d_0.can_download(str_0, bool_0)


# Generated at 2022-06-26 11:32:59.645712
# Unit test for constructor of class HlsFD
def test_HlsFD():
    obj = HlsFD('cirmid;', True)
    assert obj.can_download('cirmid;', True) == True


# Generated at 2022-06-26 11:36:08.431088
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'cirmid;'
    bool_0 = True
    hls_f_d_0 = HlsFD(str_0, bool_0)
    return hls_f_d_0


# Generated at 2022-06-26 11:36:10.427967
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'cirmid;'
    bool_0 = True
    hls_f_d_0 = HlsFD(str_0, bool_0)
