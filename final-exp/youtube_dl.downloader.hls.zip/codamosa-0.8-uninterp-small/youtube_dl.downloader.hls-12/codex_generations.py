

# Generated at 2022-06-26 11:26:42.598804
# Unit test for constructor of class HlsFD
def test_HlsFD():
    int_0 = -545
    tuple_0 = ()
    hls_f_d_0 = HlsFD(int_0, tuple_0)
    hls_f_d_0.real_download('_tmp.mp4', {'url': 'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/gear3/prog_index.m3u8'})

# Generated at 2022-06-26 11:26:44.674618
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()


# Generated at 2022-06-26 11:26:55.061926
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """HlsFD.real_download(info_dict)"""
    testcase = {
        "args": {
            "filename": "filename",
            "info_dict": {
                "_decryption_key_url": None,
                "f4m_id": "f4m_id",
                "id": "id",
                "is_live": None,
                "playlist": "playlist",
                "playlist_id": "playlist_id",
                "playlist_type": "playlist_type",
                "protocol": "protocol",
                "tbr": None,
                "title": "title",
                "url": "url",
                "urlh": None,
                "webpage_url": "webpage_url",
            },
        },
        "expected_output": True
    }

# Generated at 2022-06-26 11:27:02.219551
# Unit test for constructor of class HlsFD
def test_HlsFD():
    int_0 = 545
    tuple_0 = (5,)
    hls_f_d_0 = HlsFD(int_0, tuple_0)

    assert hls_f_d_0 is not None


# Generated at 2022-06-26 11:27:14.357890
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Create the object
    hls_f_d_0 = HlsFD(29, ())
    manifest = '''#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:6
#EXTINF:6,
/hls-vod/sample1_1500kbps.f4v
#EXTINF:6,
/hls-vod/sample2_1500kbps.f4v
#EXTINF:6,
/hls-vod/sample3_1500kbps.f4v
#EXTINF:6,
/hls-vod/sample4_1500kbps.f4v
#EXT-X-ENDLIST'''

    info_dict = {'url': 'http://example.com/test.m3u8'}

    # Inv

# Generated at 2022-06-26 11:27:24.063585
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    url_0 = "http://localhost/"

# Generated at 2022-06-26 11:27:32.527554
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    url = 'http://www.youtube.com/watch?v=RJHBlZu56jI'
    ydl_opts = {}
    ydl = YoutubeDL(ydl_opts)
    info = ydl.extract_info(url, download=False)
    collection = [info]
    dump_path = 'test.mp4'
    # real_download(self, filename, info_dict):
    hls_f_d_0 = HlsFD(ydl, ydl_opts)
    assert hls_f_d_0.real_download(dump_path, info) == True

# Generated at 2022-06-26 11:27:37.996009
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    file_1 = open('/var/log/syslog', 'r')
    file_2 = open('/var/log/syslog', 'r')
    test_case_0()
    HlsFD.real_download(file_1, file_2)
    file_1.close()
    file_2.close()

if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:27:38.750915
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()
    pass



# Generated at 2022-06-26 11:27:39.799303
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()



# Generated at 2022-06-26 11:28:01.007399
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

test_HlsFD()

# Generated at 2022-06-26 11:28:02.999460
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hlsFD = HlsFD()
    hlsFD.real_download(None, None)



# Generated at 2022-06-26 11:28:03.882809
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:28:06.503241
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass
    # TODO: implement this


if __name__ == '__main__':

    test_HlsFD_real_download()

# Generated at 2022-06-26 11:28:13.478022
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    instance = HlsFD()
    assert (instance.real_download("filename", "info_dict") == False)
    assert (instance.real_download("filename", "info_dict") == False)
    assert (instance.real_download("filename", "info_dict") == True)
    assert (instance.real_download("filename", "info_dict") == False)

if( __name__ == '__main__' ):
    test_case_0()
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:28:24.447567
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    print('Start to test method HlsFD::real_download')
    str_url1 = 'http://localhost/'
    str_url2 = 'http://localhost/'
    dict_info_dict1 = dict()
    dict_info_dict1['url'] = str_url1
    dict_info_dict2 = dict()
    dict_info_dict2['url'] = str_url2
    dict_info_dict1['extra_param_to_segment_url'] = None
    dict_info_dict2['extra_param_to_segment_url'] = None
    dict_info_dict1['_decryption_key_url'] = None
    dict_info_dict2['_decryption_key_url'] = None
    dict_info_dict1['is_live'] = False
    dict_info_dict

# Generated at 2022-06-26 11:28:25.357700
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass


# Generated at 2022-06-26 11:28:27.774304
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'http://localhost/'
    hlsfd = HlsFD(str_0)


# Generated at 2022-06-26 11:28:30.548632
# Unit test for constructor of class HlsFD
def test_HlsFD():
    print('Test HlsFD')
    hls_fd = HlsFD(None, None)
    # Test method real_download
    hls_fd.real_download(None, None)

# Generated at 2022-06-26 11:28:32.582025
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass


# Generated at 2022-06-26 11:28:57.126262
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'E#sh'
    str_1 = 'erN:r`='
    str_2 = 'e|>Q5'
    str_3 = 'H}!tP'
    str_4 = 'H$Oa|'
    str_5 = '5a'
    str_6 = 't'
    str_7 = 'E'
    str_8 = '~-L'
    list_0 = [str_0, str_1, str_2, str_3, str_4, str_5, str_6, str_7, str_8, str_4, str_4, str_4]
    hls_f_d_0 = HlsFD(str_7, list_0)

# Generated at 2022-06-26 11:28:59.047491
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
	pass


# Generated at 2022-06-26 11:29:02.014861
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    method = HlsFD.real_download
    instance = HlsFD('', '')
    method(instance, '', '')

# Generated at 2022-06-26 11:29:03.759429
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert True, "Test could not be implemented, because method can_download of class HlsFD is 'private'"


# Generated at 2022-06-26 11:29:09.399212
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 1991.119874745024
    str_0 = 'YghR dk'
    list_0 = [str_0, str_0]
    hls_f_d_0 = HlsFD(str_0, list_0)
    hls_f_d_0.real_download(str_0, float_0)

# Generated at 2022-06-26 11:29:15.698344
# Unit test for constructor of class HlsFD
def test_HlsFD():
    float_0 = 1994.1477170074703
    str_0 = 'V!xG8Ah<uM7gZN'
    list_0 = [str_0, str_0, float_0]
    hls_f_d_0 = HlsFD(str_0, list_0)
    var_0 = hls_f_d_0.can_download(str_0, float_0)


# Generated at 2022-06-26 11:29:21.502836
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'c%'
    list_0 = [str_0]
    hls_f_d_0 = HlsFD(str_0, list_0)
    str_1 = ':a'
    str_2 = '3qr'
    hls_f_d_0.real_download(str_1, str_2)

# Generated at 2022-06-26 11:29:22.612086
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert test_case_0() == False

# Generated at 2022-06-26 11:29:28.507279
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    float_0 = 1581.817772672401
    str_0 = '00.098.998'
    list_0 = [str_0, str_0]
    hls_f_d_0 = HlsFD(str_0, list_0)
    hls_f_d_0.can_download(str_0, float_0)


# Generated at 2022-06-26 11:29:30.761865
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:30:02.296523
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 1991.119874745024
    str_0 = 'YghR dk'
    list_0 = [str_0, str_0]
    hls_f_d_0 = HlsFD(str_0, list_0)
    str_1 = '1h7wc5o5Ln0I'
    var_0 = hls_f_d_0.real_download(str_1, float_0)

# Generated at 2022-06-26 11:30:07.008612
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'f+Fy^'
    list_0 = ['VDZu', 'VDZu']
    hls_f_d_0 = HlsFD(str_0, list_0)
    assert isinstance(hls_f_d_0, HlsFD)


# Generated at 2022-06-26 11:30:16.795858
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '4'
    float_0 = 1953.8545570821957
    float_1 = 91.37695335317289
    float_2 = 4263.514155081641
    float_3 = 95.59233313171573
    list_0 = ['T', 't']
    list_1 = ['', '', '', '', '']
    hls_f_d_0 = HlsFD(str_0, list_0)
    hls_f_d_0.real_download(float_0, float_1)
    hls_f_d_0.real_download(float_2, float_3)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:30:23.944784
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'DpV'
    str_1 = 'e,WP'
    str_2 = 'KjGX$'
    float_0 = -98.0
    float_1 = -47.0
    float_2 = float_1
    float_3 = 53463.4
    float_4 = -0.1
    float_5 = -0.0
    float_6 = -77.1
    str_3 = 'mG'
    str_4 = 'yf^'
    float_7 = 5.0
    str_5 = 'ZzA'
    float_8 = 246.0
    float_9 = -float_2
    float_10 = 2.0
    float_11 = float_3

# Generated at 2022-06-26 11:30:28.673331
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'rUpi hz'
    dict_0 = {'url': str_0}
    hls_f_d_0 = HlsFD(str_0, None)
    hls_f_d_0.real_download(str_0, dict_0)

# Generated at 2022-06-26 11:30:35.165359
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 1991.119874745024
    str_0 = 'YghR dk'
    list_0 = [str_0, str_0]
    hls_f_d_0 = HlsFD(str_0, list_0)
    assert hls_f_d_0.real_download('test', float_0) is False
    assert hls_f_d_0.real_download('test', float_0) is False


# Generated at 2022-06-26 11:30:39.122022
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD(str_0, list_0)
    var_0 = hls_f_d_0.real_download(str_0, float_0)
    assert var_0 == True

# Generated at 2022-06-26 11:30:41.338541
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        test_case_0()
    except AssertionError as e:
        print("Raised AssertionError: " + str(e))


# Generated at 2022-06-26 11:30:44.712258
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 1991.119874745024
    str_0 = 'YghR dk'
    list_0 = [str_0, str_0]
    hls_f_d_0 = HlsFD(str_0, list_0)
    var_0 = hls_f_d_0.real_download(str_0, float_0)

# Generated at 2022-06-26 11:30:49.672661
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 1991.119874745024
    str_0 = 'YghR dk'
    list_0 = [str_0, str_0]
    hls_f_d_0 = HlsFD(str_0, list_0)
    hls_f_d_0.real_download(str_0, float_0)

# Generated at 2022-06-26 11:32:02.545932
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 1991.119874745024
    str_0 = 'YghR dk'
    list_0 = [str_0, str_0]
    hls_f_d_0 = HlsFD(str_0, list_0)
    var_0 = hls_f_d_0.real_download(str_0, float_0)

# Generated at 2022-06-26 11:32:08.290085
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 1991.119874745024
    str_0 = 'YghR dk'
    list_0 = [str_0, str_0]
    hls_f_d_0 = HlsFD(str_0, list_0)
    bool_0 = hls_f_d_0.real_download(str_0, float_0)
    assert bool_0 == True

# Generated at 2022-06-26 11:32:11.853479
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_1 = 22
    list_0 = [int_1, int_1]
    hls_fd_0 = HlsFD(int_1, list_0)
    hls_fd_0.real_download(int_1, int_1)

# Generated at 2022-06-26 11:32:12.760135
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert True


# Generated at 2022-06-26 11:32:13.799090
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:32:21.552652
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    float_0 = 1991.119874745024
    str_0 = 'YghR dk'
    list_0 = [str_0, str_0]
    hls_f_d_0 = HlsFD(str_0, list_0)
    var_0 = hls_f_d_0.can_download(str_0, float_0)
    assert var_0 == True


# Generated at 2022-06-26 11:32:24.341205
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_1 = HlsFD()

if __name__ == '__main__':
    test_case_0()
    test_HlsFD()

# Generated at 2022-06-26 11:32:28.741089
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'ytxQ jyWB'
    float_0 = 572.131783468633
    str_1 = 'eqjCzs ys'
    hls_f_d_0 = HlsFD(str_0, [str_1])
    hls_f_d_0.real_download(str_1, float_0)

# Generated at 2022-06-26 11:32:32.707454
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'Sx!_'
    str_1 = '~2.H'
    list_0 = [str_0]
    hls_f_d_0 = HlsFD(str_1, list_0)
    hls_f_d_0.real_download(str_0, str_0)

# Generated at 2022-06-26 11:32:34.110630
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert 1 == 1

# Testing purpose only
if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 11:35:23.578194
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Test case for valid input.
    str_0 = 'Xc\\'
    float_0 = 1365.13
    str_1 = '\x00\x00\x81\x9f\xf4\x86\xb8\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    int_0 = 1
    hls_f_d_0 = HlsFD(float_0, float_0)
    hls_f_d_0.real_download(str_1, int_0)
    # Test case for invalid input.
    # Error: RuntimeError: object has no attribute 'can_download'
    # hls_f_d_0.real_download(str_1, str_1)



# Generated at 2022-06-26 11:35:26.152982
# Unit test for constructor of class HlsFD
def test_HlsFD():
    print('Test if this Python file can be run')
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:35:29.267988
# Unit test for constructor of class HlsFD
def test_HlsFD():
    print('Unit test for constructor of class HlsFD')
    float_0 = 1365.13
    hls_f_d_0 = HlsFD(float_0, float_0)
    assert float_0 == hls_f_d_0.params['proxy']
    assert float_0 == hls_f_d_0.params['referrer']
    return


# Generated at 2022-06-26 11:35:35.630744
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '_'
    str_1 = '?g'
    list_0 = []
    int_0 = -671254404
    int_1 = 58887
    dict_0 = {'mime_type': str_0, 'vcodec': str_1, 'fragment_index': list_0, 'tbr': int_0, 'tbr_num': int_0, 'height': int_1, '_decryption_key_url': str_0, 'formats': list_0, 'vbr': int_0, 'fps': int_0}
    list_0 = [dict_0]
    bool_0 = False
    dict_0 = {'can_download': bool_0, 'formats': list_0}
    str_2 = 'Sn=w'
    dict

# Generated at 2022-06-26 11:35:48.400389
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Create an instance of HlsFD
    hls_f_d_0 = HlsFD(None, None)

    # Omit test()

    # Create an instance of HlsFD
    hls_f_d_1 = HlsFD(None, None)

    # Omit test()

    # Create an instance of HlsFD
    hls_f_d_2 = HlsFD(None, None)

    # Omit test()

    # Create an instance of HlsFD
    hls_f_d_3 = HlsFD(None, None)

    # Omit test()

    # Create an instance of HlsFD
    hls_f_d_4 = HlsFD(None, None)

    # Omit test()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:35:53.358569
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'Aq+;=a'
    string_0 = str_0
    int_0 = 45
    dict_0 = {
        'is_live': True,
        '_decryption_key_url': 'https://google.com/',
        'extra_param_to_segment_url': '6h&y6'
    }
    hls_fd_0 = HlsFD(string_0, int_0)
    bool_0 = hls_fd_0.real_download(str_0, dict_0)


# Generated at 2022-06-26 11:36:01.278739
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'D=!C<_'

# Generated at 2022-06-26 11:36:10.120393
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    float_0 = 1365.13
    hls_f_d_0 = HlsFD(float_0, float_0)
    str_0 = 'Xc\\'
    str_1 = 'Xc\\'
    bool_0 = hls_f_d_0.real_download(str_0, str_1)
    assert bool_0 == True

if __name__ == "__main__":
    import sys
    import os
    import inspect
    currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parentdir = os.path.dirname(currentdir)
    sys.path.insert(0, parentdir)

    test_case_0()
    test_HlsFD_real_download()