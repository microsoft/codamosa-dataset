

# Generated at 2022-06-26 11:26:57.397082
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    info_dict_0 = {'url': 'http://example.com/manifest.m3u8'}
    hls_f_d_0 = HlsFD({'filename': 'test.mp4'}, {'test': True})
    hls_f_d_0.real_download('test.mp4', info_dict_0)
    info_dict_0 = {
            'url': 'http://example.com/manifest.m3u8',
            'extra_param_to_segment_url': 'param1=value1&param2=value2'}
    hls_f_d_0.real_download('test.mp4', info_dict_0)

# Generated at 2022-06-26 11:26:58.763405
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD()


# Generated at 2022-06-26 11:26:59.211557
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert True

# Generated at 2022-06-26 11:27:01.583145
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD(int, set)
    filename = str()
    info_dict = dict()
    result = hls_f_d_0.real_download(filename, info_dict)
    assert result

# Generated at 2022-06-26 11:27:02.601937
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:27:05.353554
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_case_0()


if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:27:07.315680
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD(int(), {int()})


# Generated at 2022-06-26 11:27:14.077839
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_0 = 1521
    set_0 = {int_0, int_0, int_0}
    info_dict_0 = {'url': 'https://github.com/ytdl-org/youtube-dl/pull/27660'}
    hls_f_d_0 = HlsFD(int_0, set_0)
    filename_0 = hls_f_d_0.real_download(
        'https://github.com/ytdl-org/youtube-dl/pull/27660',
        {'url': 'https://github.com/ytdl-org/youtube-dl/pull/27660'})
    assert filename_0 == 'https://github.com/ytdl-org/youtube-dl/pull/27660'


# Generated at 2022-06-26 11:27:23.874381
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download("#EXT-X-VERSION:4", "") == False
    assert HlsFD.can_download("#EXT-X-VERSION:4", "") == False
    assert HlsFD.can_download("#EXT-X-KEY:METHOD=AES-128", "") == False
    assert HlsFD.can_download("#EXT-X-KEY:METHOD=NONE", "") == True
    assert HlsFD.can_download("#EXT-X-KEY:METHOD=AES-128", "") == False
    assert HlsFD.can_download("#EXT-X-KEY:METHOD=NONE", "") == True
    assert HlsFD.can_download("#EXT-X-KEY:METHOD=AES-128", "") == False

# Generated at 2022-06-26 11:27:29.759497
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    int_0 = 1819
    set_0 = {int_0, int_0, int_0}
    hls_f_d_0 = HlsFD(int_0, set_0)
    string_0 = "FRG"
    dict_0 = {string_0: string_0}
    bool_0 = dict_0 == dict_0
    assert(bool_0)
    hls_f_d_0.real_download(string_0, dict_0)
    assert(hls_f_d_0.__class__ is HlsFD)
    hls_f_d_0.__class__ = type
    assert(hls_f_d_0.__class__ is type)


# Generated at 2022-06-26 11:27:50.862501
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    print("running test case 0")
    test_case_0()
    print("test case finished")

if __name__ == "__main__":
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:27:54.832913
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'KCTS 9 (KCTS)'
    bool_0 = True
    hls_f_d_0 = HlsFD(bool_0, str_0)
    bool_0 = hls_f_d_0.real_download(str_0, str_0)

# Generated at 2022-06-26 11:27:59.996146
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'https://www.youtube.com/watch?v=h8eHzEWn1DU'
    str_1 = 'h8eHzEWn1DU'
    bool_0 = True
    hls_f_d_0 = HlsFD(bool_0, str_0)
    hls_f_d_0.real_download(str_0, str_1)


# Generated at 2022-06-26 11:28:11.489050
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_4 = 'KCTS 9 (KCTS)'
    str_1 = 'http://192.168.100.214:8080/hls/Gymnastics-WAG/Gymnastics-WAG-2.m3u8'
    dict_0 = {u'url': str_1, u'format': u'17', u'http_headers': {u'User-Agent': u'python-requests/2.11.1', u'Accept-Encoding': u'gzip, deflate', u'Accept': u'*/*', u'Connection': u'keep-alive'}, u'extractor': u'hls', u'extractor_key': u'Hls', u'protocol': u'hls'}
    bool_0 = True
    hls_f_d_0 = Hls

# Generated at 2022-06-26 11:28:22.289928
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # True positive 1: Master playlist with 'NONE' encryption method
    str_0 = 'https://manifest.prod.boltdns.net/manifest/v1/hls/v4/clear/576f789f34444c5eb6c2fb6d0a6a1a6f/us-west-2/profile_0/chunked/index.m3u8'
    bool_0 = True
    str_1 = 'KCTS 9 (KCTS)'
    hls_f_d_0 = HlsFD(bool_0, str_1)

# Generated at 2022-06-26 11:28:27.878478
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Create an instance of the class HlsFD
hls_f_d_0 = HlsFD(True, 'KCTS 9 (KCTS)')

# Call the member function of the class HlsFD with the input string 'KCTS 9 (KCTS)'
var_0 = hls_f_d_0.can_download('KCTS 9 (KCTS)', 'KCTS 9 (KCTS)')

# Generated at 2022-06-26 11:28:28.928680
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert test_case_0() == None



# Generated at 2022-06-26 11:28:34.096322
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    print('test_HlsFD_can_download')
    test_case_0()
    print('test_HlsFD_can_download')
    print('Success')


if __name__ == '__main__':
    test_HlsFD_can_download()

# Generated at 2022-06-26 11:28:37.907337
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'KCTS 9 (KCTS)'
    bool_0 = True
    hls_f_d_0 = HlsFD(bool_0, str_0)


# Generated at 2022-06-26 11:28:46.824059
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # arrange
    str_1 = "TRUE"
    str_2 = "Manifest-url"
    hls_f_d_1 = HlsFD(str_1, str_2)
    bool_1 = True
    str_3 = "m3u8-manifest"
    dict_1 = dict()
    # act
    result = hls_f_d_1.real_download(str_3, dict_1)
    # assert
    assert(result == False)

# Generated at 2022-06-26 11:29:18.415583
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    str_var_0 = 'KCTS 9 (KCTS)'
    bool_var_0 = True
    hls_f_d_var_0 = HlsFD(bool_var_0, str_var_0)
    str_var_1 = str_var_0
    str_var_2 = str_var_0
    var_0 = hls_f_d_var_0.can_download(str_var_1, str_var_2)
    assert var_0 == None # did not return a value


# Generated at 2022-06-26 11:29:22.010622
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'KCTS 9 (KCTS)'
    bool_0 = True
    hls_f_d_0 = HlsFD(bool_0, str_0)


# Generated at 2022-06-26 11:29:26.982713
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_1 = HlsFD(False, False)
    assert hls_f_d_1.ydl == False, "Assert should not throw"
    assert hls_f_d_1.params == False, "Assert should not throw"


# Generated at 2022-06-26 11:29:30.542940
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    #assert False # TODO: implement your test here
    #raise Exception("Test not implemented!")
    hls_f_d_0 = HlsFD(True, "")
    assert hls_f_d_0.real_download("", "")


# Generated at 2022-06-26 11:29:40.869812
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = ''
    str_1 = null
    str_2 = null
    str_3 = null
    str_4 = null
    str_5 = null
    str_6 = null
    str_7 = null
    str_8 = null
    str_9 = null
    str_10 = null
    str_11 = null
    str_12 = null
    str_13 = null
    str_14 = null
    str_15 = null
    str_16 = null
    str_17 = null
    str_18 = null
    str_19 = null
    str_20 = null
    str_21 = null
    str_22 = null
    str_23 = null
    str_24 = null
    str_25 = null
    str_26 = null
    str_27 = null
    str_

# Generated at 2022-06-26 11:29:43.925523
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD(True, '2')
    return hls_f_d_0

if __name__ == '__main__':
    hls_f_d_0 = test_HlsFD()
    test_case_0()

# Generated at 2022-06-26 11:29:53.491005
# Unit test for constructor of class HlsFD
def test_HlsFD():
    bool_0 = True
    str_0 = 'KCTS 9 (KCTS)'
    hls_f_d_0 = HlsFD(bool_0, str_0)
    assert(hls_f_d_0.params == {'ytdl_format': 'best', 'format': 'best', 'test': False, 'debug_printtraffic': False, 'skip_download': False, 'hls_prefer_native': True})
    assert(hls_f_d_0._progress_hooks == [])
    assert(hls_f_d_0.ydl == bool_0)

# Generated at 2022-06-26 11:29:56.176520
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()
    print('Unit tests for class HlsFD passed successfully')

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:30:01.835239
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'KCTS 9 (KCTS)'
    bool_0 = True
    str_1 = 'KCTS 9 (KCTS)'
    hls_f_d_0 = HlsFD(bool_0, str_0)
    # Failed when creating an object of HlsFD class
    assert False


# Generated at 2022-06-26 11:30:02.799189
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:31:10.604044
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert test_case_0() is True

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:31:12.204562
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()


if __name__ == "__main__":
    test_HlsFD()

# Generated at 2022-06-26 11:31:21.548125
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_1 = "http://www.example.com/"
    hls_f_d_1 = HlsFD(str_1, str_1)
    str_2 = "http://www.example.com/?a=b&c=d"
    hls_f_d_2 = HlsFD(str_2, str_2)
    str_3 = "http://www.example.com/?a=b&c=d&a=e"
    hls_f_d_3 = HlsFD(str_3, str_3)
    str_4 = "http://www.example.com/?a=b&c=d&a=e&c=f"
    hls_f_d_4 = HlsFD(str_4, str_4)

# Generated at 2022-06-26 11:31:23.476711
# Unit test for constructor of class HlsFD
def test_HlsFD():
    construct_0 = HlsFD(None, None)


# Generated at 2022-06-26 11:31:26.056606
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'yL#?T*#jN[=n3q^r%f\'p`H\\9'
    hls_f_d_0 = HlsFD(str_0, str_0)


# Generated at 2022-06-26 11:31:26.905793
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Test case 0
    test_case_0()

# Generated at 2022-06-26 11:31:29.958141
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Test with normal input
    str_0 = "YCTS 9(KCS)"
    str_1 = "YTCTS 9(KCS)"
    hls_f_d_0 = HlsFD(str_0, str_1)
    assert hls_f_d_0.FD_NAME == "hlsnative"


# Generated at 2022-06-26 11:31:31.898387
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Trivial test case
    test_case_0()

# Generated at 2022-06-26 11:31:39.511376
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # 1. Declare arguments
    str_0 = 'BKLN 8)G[N'
    str_1 = 'QKQG 2(#M9'
    str_2 = 'TJ[F %&C%Z'
    hls_f_d_0 = HlsFD(str_0, str_0)
    # 2. Invoke method
    (bool_0, int_0, str_3) = hls_f_d_0.real_download(str_1, str_2)
    # 3. Assert the output value
    assert int_0 == -1
    assert str_3 == 'TIUW 0#U;'


# Generated at 2022-06-26 11:31:48.885932
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    print(__name__)

    hls_f_d = HlsFD(None, {})
    assert hls_f_d.can_download('#EXTM3U', {})
    assert not hls_f_d.can_download('#EXTM3U', {'is_live': True})

    assert hls_f_d.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=NONE', {})
    assert not hls_f_d.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {})
    assert not hls_f_d.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\n#EXT-X-BYTERANGE', {})


# Generated at 2022-06-26 11:34:36.459487
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'dDt7 3J2W'
    hls_f_d_0 = HlsFD(str_0, str_0)
    var_0 = hls_f_d_0.can_download(str_0, str_0)

if __name__ == '__main__':
    test_case_0()

    str_0 = 'dDt7 3J2W'
    hls_f_d_0 = HlsFD(str_0, str_0)
    var_0 = hls_f_d_0.can_download(str_0, str_0)

    test_HlsFD()

# Generated at 2022-06-26 11:34:42.017598
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_1 = 'eDxCx'
    str_2 = 'H4Z(3'
    hls_f_d_1 = HlsFD(str_1, str_2)
    assert ((hls_f_d_1.FD_NAME == str_2) and
            (hls_f_d_1.ydl == str_1) and
            (hls_f_d_1.params == str_2))


# Generated at 2022-06-26 11:34:45.956111
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = 'YCTS 9(KCS)'
    hls_f_d_0 = HlsFD(str_0, str_0)
    assert hls_f_d_0.FD_NAME == 'hlsnative'

if __name__ == '__main__':
    test_case_0()
    test_HlsFD()

# Generated at 2022-06-26 11:34:47.265104
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()


# Generated at 2022-06-26 11:34:49.559379
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:34:51.955344
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD('', '')
    try:
        method_1 = hls_f_d_0.real_download
        method_1('', '\n')
    except (IOError, ValueError) as var_0:
        pass


# Generated at 2022-06-26 11:34:55.993939
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_1 = 'z:\\../../../..\\'
    hls_f_d_1 = HlsFD(str_1, str_1)
    var_1 = 'HlsFD'
    assert hls_f_d_1.FD_NAME == var_1


# Generated at 2022-06-26 11:34:58.842749
# Unit test for constructor of class HlsFD
def test_HlsFD():
    instance0 = HlsFD(None, None)
    instance1 = HlsFD(None, None)

# Generated at 2022-06-26 11:35:08.663076
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    var_0 = HlsFD(None, None, None)
    var_0.real_download('filename', {'url': 'man_url'})
    var_1 = HlsFD(None, None, None)
    var_2 = {'url': 'http://hlslive.lcdn.une.net.co/v1/AUTH_HLSLIVE/TELMEX/tu-cuento.m3u8'}
    var_1.real_download('filename', var_2)
    var_3 = HlsFD(None, None, None)
    var_4 = {'url': 'https://hls.goodgame.ru/hls/6580360.m3u8'}
    var_3.real_download('filename', var_4)

# Generated at 2022-06-26 11:35:10.327305
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()