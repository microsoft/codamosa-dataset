

# Generated at 2022-06-26 11:26:40.399294
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    case_0 = test_case_0()

if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:26:51.173624
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    parsed_url = compat_urlparse.urlparse('https://github.com/ytdl-org/youtube-dl/blob/master/README.md')
    info_dict = {'url': 'https://github.com/ytdl-org/youtube-dl/blob/master/README.md'}

    assert not HlsFD.can_download('', {'url': ''})
    assert HlsFD.can_download('#EXTM3U', info_dict)
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=NONE', info_dict)
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-BYTERANGE', info_dict)

# Generated at 2022-06-26 11:27:00.554498
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    bytes_0 = b'\xe1\x9eq\xd3\xe7fQ\xe5\x98\xdc$I\xcd;\x86\x01\xba\x9b'
    str_0 = 'Sz\xb4\xbc\xf3\x9f\x0f\x1e\xe0'
    str_1 = 'B\xe8\x08\x0f\x9e\xb1\x01\xda\xf0\x14\x1a\xe8<'
    str_2 = 'http://no-rule.com/'
    str_3 = 'hls-live/livepkgr/mp4:hls/chunklist_b848000.m3u8'

# Generated at 2022-06-26 11:27:01.816566
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()


# Generated at 2022-06-26 11:27:13.654558
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-26 11:27:16.335549
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

if __name__ == '__main__':
    # test_HlsFD()
    pass

# Generated at 2022-06-26 11:27:25.337222
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    bytes_0 = b'\xbd\xe3fX\x17>4\xd1sO\xf6\xde\x11b\x82\x8c\x10'
    int_0 = 723671766
    dict_0 = {}
    bytes_1 = b'{\x1d\x1a\xa5\x8f\x8c\x82 \x91~\xbe\x16\t_\x9a\xe5\x82\xcec\xaa\xdb\x16\xc0\x1c\xdc\x9a\x1a\x07\x84\xfe\xeb\x95\x03\xec]\x9fj\x95\x05\xe1\x89'

# Generated at 2022-06-26 11:27:27.371299
# Unit test for constructor of class HlsFD
def test_HlsFD():
    print('Testing HlsFD()...')
    test_case_0()
    print('Done testing HlsFD()')

# Generated at 2022-06-26 11:27:30.573146
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # This test case is left empty on purpose
    # Some unit tests are already present in 'test_fragment.py'
    pass

# Generated at 2022-06-26 11:27:32.654803
# Unit test for constructor of class HlsFD
def test_HlsFD():
    print('Testing constructor of HlsFD')
    test_case_0()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-26 11:28:02.077101
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_f_d_0 = HlsFD(None, None)
    assert hls_f_d_0
    assert hls_f_d_0.params == {}
    assert hls_f_d_0.ydl == None
    assert hls_f_d_0.progress_hooks == []
    assert hls_f_d_0.num_downloads == 0


# Generated at 2022-06-26 11:28:03.756464
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # No parameters,  returns None
    assert HlsFD.can_download('', b'') is None


# Generated at 2022-06-26 11:28:14.916751
# Unit test for constructor of class HlsFD

# Generated at 2022-06-26 11:28:16.329789
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    print('Testing can_download')
    test_case_0()



# Generated at 2022-06-26 11:28:26.729971
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    list_0 = [b'\x95\xe5\x8e\xf7\xe7\x85\nn7\x882Y\x9cQ`\xa9\xfa?', b'\x95\xe5\x8e\xf7\xe7\x85\nn7\x882Y\x9cQ`\xa9\xfa?']
    dict_0 = {'real_download': '\x95\xe5\x8e\xf7\xe7\x85\nn7\x882Y\x9cQ`\xa9\xfa?', 'mime_type': '\x95\xe5\x8e\xf7\xe7\x85\nn7\x882Y\x9cQ`\xa9\xfa-'}
    hls_f_d_

# Generated at 2022-06-26 11:28:36.618558
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '*IU3\x0bZ72,/05P^;8(e2'
    bytes_0 = b'\x95\xe5\x8e\xf7\xe7\x85\nn7\x882Y\x9cQ`\xa9\xfa?'
    list_0 = [str_0, str_0]
    dict_0 = {}
    hls_f_d_0 = HlsFD(list_0, dict_0)
    hls_f_d_0.real_download(str_0, bytes_0)


# Generated at 2022-06-26 11:28:37.816952
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert True

# Generated at 2022-06-26 11:28:50.521188
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_1 = 'b\xdd\x00\x16\x00_E\xc5\x15\x17\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00  D!\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-26 11:28:59.910064
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    arg_0 = '859dced6e72c2f3035502e3b286532'
    arg_1 = {
        'url': 'http://media.example.com/entire.ts',
        'extra_param_to_segment_url': '',
        '_decryption_key_url': '',
        'is_live': ''
    }
    list_0 = [arg_0, arg_0]
    dict_0 = {}
    hls_f_d_0 = HlsFD(list_0, dict_0)
    var_0 = hls_f_d_0.real_download(arg_0, arg_1)


# Generated at 2022-06-26 11:29:08.382926
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = '\x9b\x99\xa6\xcb\xb1\xa5\xc2\x8d\xcaG\xfb\xa7'
    list_1 = [str_0, str_0]
    dict_0 = {}
    hls_f_d_0 = HlsFD(list_1, dict_0)
    hls_f_d_0.real_download(str_0, str_0)
    test_case_0()


if __name__ == "__main__":
    test_HlsFD()

# Generated at 2022-06-26 11:29:31.493867
# Unit test for constructor of class HlsFD
def test_HlsFD():
    str_0 = '*IU3\x0bZ72,/05P^;8(e2'
    bytes_0 = b'\x95\xe5\x8e\xf7\xe7\x85\nn7\x882Y\x9cQ`\xa9\xfa?'
    list_0 = [bytes_0, str_0, str_0, str_0]
    hls_f_d_0 = HlsFD(bytes_0, list_0)
    hls_f_d_0.real_download(str_0, bytes_0)
    var_0 = hls_f_d_0.can_download(str_0, bytes_0)

# Generated at 2022-06-26 11:29:32.794270
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD is not None


# Generated at 2022-06-26 11:29:42.710583
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .dash import DASHIE
    from .fragment import FragmentFD
    str_0 = '*IU3\x0bZ72,/05P^;8(e2'
    bytes_0 = b'\x95\xe5\x8e\xf7\xe7\x85\nn7\x882Y\x9cQ`\xa9\xfa?'
    list_0 = [bytes_0, str_0, str_0, str_0]
    hls_f_d_0 = HlsFD(bytes_0, list_0)
    hls_f_d_0.params['username'] = 'Uw_#G'
    hls_f_d_0.params['password'] = 'Y/_I'

# Generated at 2022-06-26 11:29:50.027817
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    if (HlsFD.can_download(str_0, bytes_0)):
        str_0 = '*IU3\x0bZ72,/05P^;8(e2'
        list_0 = [str_0, bytes_0, str_0]
        hls_f_d_0 = HlsFD(str_0, list_0)
        hls_f_d_0.real_download(str_0, bytes_0)

# Unit test method for HlsFD.__init__(self, ydl, params)

# Generated at 2022-06-26 11:29:56.445089
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '*IU3\x0bZ72,/05P^;8(e2'
    bytes_0 = b'\x95\xe5\x8e\xf7\xe7\x85\nn7\x882Y\x9cQ`\xa9\xfa?'
    list_0 = [bytes_0, str_0, str_0, str_0]
    hls_f_d_0 = HlsFD(bytes_0, list_0)
    str_1 = '\xbbF\xf00\xb9\x84\x8a_\x11\x0c\x16 1\xdb\x80\x14\x9f\xd8\x8a'

# Generated at 2022-06-26 11:30:06.209825
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '*IU3\x0bZ72,/05P^;8(e2'
    bytes_0 = b'\x95\xe5\x8e\xf7\xe7\x85\nn7\x882Y\x9cQ`\xa9\xfa?'
    list_0 = [bytes_0, str_0, str_0, str_0]
    hls_f_d_0 = HlsFD(bytes_0, list_0)
    var_0 = hls_f_d_0.real_download(str_0, bytes_0)
    assert var_0 == False

# Generated at 2022-06-26 11:30:08.149366
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert test_case_0() == None, 'Failed at: test_case_0()'


# Generated at 2022-06-26 11:30:18.350328
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    str_0 = '\x90\x87{\x1a\xce\xbe\xd0\x1fl\xac\xbf\x19\t\x0f\x82'
    bytes_0 = b'\x12\x93\xaa\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    list_0 = [str_0, str_0, str_0, bytes_0]
    hls_f_d_1 = HlsFD(str_0, list_0)

# Generated at 2022-06-26 11:30:29.728504
# Unit test for constructor of class HlsFD
def test_HlsFD():
    bytes_0 = b'\xe1\xe8D\xcc\n\x18\x95\xa8\xb0\x97\xb0\xab@?\xc5\xd0\x0e\x06\xa3\xce\xea\x80'
    str_0 = '8cMX\x19\xdf\xec\x9e'
    list_0 = [str_0]
    hls_f_d_0 = HlsFD(str_0, list_0)

    hls_f_d_0 = HlsFD(str_0, list_0)
    str_0 = '\x12"\xba\xad\xba\xad'
    list_0 = [str_0, str_0, str_0]
    hls_f_

# Generated at 2022-06-26 11:30:40.428224
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = "Ln$`\x0b\x7fr#\x0b\x95\xe5G\x7fW8\xfd\x19\xadY\xcb\x8c\x89\x01\x1d\xb4N~A\xc4\x81\x9b\xe1:%\x92\xd1\xdbA\xa5\x8c*\xcc\x9a"
    bytes_0 = b'\x95\xe5\x8e\xf7\xe7\x85\nn7\x882Y\x9cQ`\xa9\xfa?'
    list_0 = [bytes_0, str_0, str_0, str_0]

# Generated at 2022-06-26 11:31:25.462389
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '*IU3\x0bZ72,/05P^;8(e2'
    bytes_0 = b'\x95\xe5\x8e\xf7\xe7\x85\nn7\x882Y\x9cQ`\xa9\xfa?'
    list_0 = [bytes_0, str_0, str_0, str_0]
    hls_f_d_0 = HlsFD(bytes_0, list_0)
    var_1 = hls_f_d_0.real_download(str_0, bytes_0)
    if var_1 != False:
        raise AssertionError("Error expected: <False>")



# Generated at 2022-06-26 11:31:31.817431
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    hls_f_d_0 = HlsFD("youtube.com", {})

    mock_can_download = MagicMock(return_value=True)
    hls_f_d_0.can_download = mock_can_download

    mock_real_download_impl = MagicMock(return_value=True)
    hls_f_d_0._real_download_impl = mock_real_download_impl

    hls_f_d_0.real_download("/home/user/Desktop/youtube-dl/README.md", "/home/user/Desktop/youtube-dl/README.md")
    mock_can_download.assert_called_once_with("/home/user/Desktop/youtube-dl/README.md", "/home/user/Desktop/youtube-dl/README.md")
   

# Generated at 2022-06-26 11:31:41.463255
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-26 11:31:49.855881
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'Q\xc4\x92\xa1s\xf4\r~\xcc\x9d\x7f\xbe\x82\xb1\x8b\xdf\xdc\xd5\x86\xb8\x85\xca\x1by\x1a\xaa\x0f5|\x94t\x98\x16\x02.\x97\xfb\xfa\xe5\x1e\x931A'
    bytes_0 = b'\x95\xe5\x8e\xf7\xe7\x85\nn7\x882Y\x9cQ`\xa9\xfa?'
    list_0 = [bytes_0, str_0, str_0, str_0]
    hls_f_d

# Generated at 2022-06-26 11:31:50.967413
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert(True == True)

# Generated at 2022-06-26 11:32:01.958905
# Unit test for constructor of class HlsFD
def test_HlsFD():
    global media_frags
    global ad_frags
    global ad_frag_next

# Generated at 2022-06-26 11:32:09.955051
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert can_decrypt_frag
    assert not '#EXT-X-KEY:METHOD=(?!NONE|AES-128)'
    assert not '#EXT-X-BYTERANGE'
    assert not '#EXT-X-MEDIA-SEQUENCE:(?!0$)'
    assert not '#EXT-X-PLAYLIST-TYPE:EVENT'
    assert not '#EXT-X-MAP:'

    # TODO
    # Add unit tests for method real_download of class HlsFD
    # assert hasattr(hls_f_d_1, 'real_download')


# Generated at 2022-06-26 11:32:16.575517
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    print('Testing method real_download of class HlsFD')
    str_0 = '#EXTM3U\n#EXT-X-KEY:METHOD=NONE\nhttp://example.com/segment1.ts\n#EXT-X-ENDLIST\n'
    str_1 = '*IU3\x0bZ72,/05P^;8(e2'
    bytes_0 = b'\x95\xe5\x8e\xf7\xe7\x85\nn7\x882Y\x9cQ`\xa9\xfa?'
    list_0 = [bytes_0, str_0, str_0, str_0]

# Generated at 2022-06-26 11:32:21.163822
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert hls_f_d_0.real_download(bytes_0, var_0)
    assert hls_f_d_0.real_download(bytes_0, var_0)

# Generated at 2022-06-26 11:32:30.515434
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # HlsFD is a FragmentFD so we need an info dict with url
    info_dict = {
        'url': 'https://example.com/'
    }
    # Set up a HlsFD object
    hls_f_d = HlsFD(None, None)
    
    # Assert that the Manifest cannot be downloaded (Wrong URL)
    assert not hls_f_d.real_download('/dev/null', info_dict), 'Failed to test a wrong URL'

    # Set up a correct HLS manifest

# Generated at 2022-06-26 11:33:48.004971
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import copy
    import sys
    import unittest

    class TestHlsFD(unittest.TestCase):
        OBJ_0 = None
        OBJ_1 = None
        OBJ_2 = None
        OBJ_3 = None

        def setUp(self):
            self.OBJ_0 = HlsFD('str_0', 'bytes_0')
            self.OBJ_1 = HlsFD('str_1', 'bytes_1')
            self.OBJ_2 = HlsFD('str_2', 'bytes_2')
            self.OBJ_3 = HlsFD('str_3', 'bytes_3')

        def tearDown(self):
            pass

        def test_can_download(self):
            str_0 = '!?AHBfCnr?U|#an5'


# Generated at 2022-06-26 11:33:49.454482
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert True

if __name__ == '__main__':
    test_case_0()
    test_HlsFD_real_download()

# Generated at 2022-06-26 11:33:56.950683
# Unit test for constructor of class HlsFD

# Generated at 2022-06-26 11:33:57.782703
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Test cases
    test_case_0()

# Generated at 2022-06-26 11:33:58.962935
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_case_0()

# Generated at 2022-06-26 11:34:08.071701
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = 'aRJ9Xo4vA8'

# Generated at 2022-06-26 11:34:16.737166
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '!?AHBfCnr?U|#an5'
    bytes_0 = b'\x95\xe5\x8e\xf7\nn72Y\x9cQ`\xa9\xfa?'
    str_1 = '!\xc7\x8c\x1bb2\xaa\xe3\x15\xc3\xb3\xe1\xab\xc5,\x9b\xea\x98\x0e\xb8\x18\x97\xba\x1f$9\x96'
    var_0 = str_1
    var_1 = HlsFD(str_0, bytes_0)

# Generated at 2022-06-26 11:34:23.181423
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    str_0 = '!?AHBfCnr?U|#an5'
    bytes_0 = b'\x95\xe5\x8e\xf7\nn72Y\x9cQ`\xa9\xfa?'
    hls_f_d_0 = HlsFD(str_0, bytes_0)
    str_1 = '1!X2y\x16D?\x94\x07\xf8\xdf\x97'
    str_2 = str_1
    dict_0 = {str_0: str_2}

# Generated at 2022-06-26 11:34:33.424982
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-26 11:34:35.038855
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert hls_f_d_0.real_download(str_0, bytes_0)
