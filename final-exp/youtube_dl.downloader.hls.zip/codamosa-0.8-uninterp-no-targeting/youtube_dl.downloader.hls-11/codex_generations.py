

# Generated at 2022-06-22 07:03:42.697025
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    from .testutils import MockYDL
    from .playlist import BasePlaylistIE

    class MockYDL(MockYDL):

        def _real_extract(self, url):
            return {
                '_type': 'url',
                'url': url,
                'ie_key': 'HlsFD',
            }

    class TestHlsFD(unittest.TestCase):

        def setUp(self):
            self.ydl = MockYDL()

        def test_download(self):
            """ Simple HLS playlist download test """
            url = 'http://devimages.apple.com/iphone/samples/bipbop/gear1/prog_index.m3u8'
            info = self.ydl.extract_info(url, download=True)
           

# Generated at 2022-06-22 07:03:54.638648
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .extractor.common import InfoExtractor
    from .utils import SearchInfoExtractor
    import tempfile
    import shutil
    import os
    from .extractor.youtube import YoutubeIE

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    class TestHlsFD(HlsFD):
        def _prepare_url(self, info_dict, url):  # pylint: disable=unused-argument
            return url

    # Test to download a few bytes of the first fragment of a normal stream
    def test_normal_stream(temp_dir):
        ie = YoutubeIE(SearchInfoExtractor())
        extractor_info = ie.extract('https://youtu.be/BaW_jenozKc')
        info_dict = extractor_info.get('entries')[0]


# Generated at 2022-06-22 07:04:03.496477
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    """
    Testing method HlsFD can_download
    """

# Generated at 2022-06-22 07:04:14.157065
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .tests_real_download import check_real_download_use_external
    from .utils import prepend_extension
    from .options import OptionValues
    from .extractor.common import InfoExtractor
    from .compat import compat_urlparse
    opts = OptionValues()

# Generated at 2022-06-22 07:04:26.720376
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import json

    def test_case(test, methods):
        for method in methods:
            test[method] = True
        yield test

    # Prepare False test cases
    tests = [{}]
    tests += test_case(
        {'name': 'Non-AES-128 protected stream'},
        (
            r'#EXT-X-KEY:METHOD=SAMPLE-AES-CENC',
            r'#EXT-X-KEY:METHOD=SAMPLE-AES-CTR',
            r'#EXT-X-KEY:METHOD=SAMPLE-AES-CBC',
        )
    )

# Generated at 2022-06-22 07:04:32.572501
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    test_instance = HlsFD() # create an instance of HlsFD to test
    # Call method to test
    test_instance.real_download('test_filename', {'url': 'test_url'})

if __name__ == '__main__':
    # Call unit test
    test_HlsFD_real_download()

# Generated at 2022-06-22 07:04:45.548042
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:04:56.925611
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    fd = HlsFD()
    assert fd.can_download('#EXTM3U', {}) is True
    assert fd.can_download('#EXT-X-KEY:METHOD=NONE', {}) is True
    assert fd.can_download('#EXT-X-KEY:METHOD=AES-128', {}) is True
    assert fd.can_download('#EXT-X-KEY:METHOD=AES-128', {'extra_param_to_segment_url': '', '_decryption_key_url': ''}) is True
    assert fd.can_download('#EXT-X-KEY:METHOD=NONE', {'_decryption_key_url': ''}) is True

# Generated at 2022-06-22 07:05:02.390309
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    from .test import ytdl_test

    ytdl_test(HlsFD, sys.argv[1:])

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-22 07:05:12.376272
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import TestDownloadManager
    from .extractor import get_info_extractor
    from .downloader import get_suitable_downloader

    # Get the suitable downloader
    info_dict = get_info_extractor('https://www.youtube.com/watch?v=nPt8bK2gbaU')[0](url='https://www.youtube.com/watch?v=nPt8bK2gbaU', downloader=TestDownloadManager())
    downloader = get_suitable_downloader(info_dict)
    assert downloader.__class__ == HlsFD
    assert downloader._prepare_url(info_dict, None) == 'https://www.youtube.com/watch?v=nPt8bK2gbaU'
    # Test the real_download method
    assert download

# Generated at 2022-06-22 07:05:35.848661
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import re
    import sys

    assert sys.version_info >= (2, 6)

    m3u8_hls_path = os.path.join(
        os.path.dirname(__file__), 'hls_m3u8_manifest.m3u8')

    with open(m3u8_hls_path, 'r') as m3u8_hls_fd:
        hls_m3u8_manifest = m3u8_hls_fd.read()

    info_dict = {'url': 'file://' + m3u8_hls_path}
    can_download = HlsFD.can_download(hls_m3u8_manifest, info_dict)
    assert can_download

    # Uncomment to test a failure case
   

# Generated at 2022-06-22 07:05:48.630446
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.http import HlsFD
    fd = HlsFD(None, None)
    assert(fd.FD_NAME == 'hlsnative')
    assert(fd.can_download('#EXTM3U', {}))
    assert(fd.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=NONE', {}))
    assert(fd.can_download('#EXTM3U\n#EXT-X-BYTERANGE:1234@5678', {}))
    assert(fd.can_download('#EXTM3U\n#EXT-X-BYTERANGE:1234@5678', {}))
    assert(fd.can_download('#EXTM3U\n#EXT-X-PLAYLIST-TYPE:EVENT', {}))

# Generated at 2022-06-22 07:05:59.606873
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:06:11.494322
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:06:24.076105
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import ssl
    import os
    import sys
    import uuid
    import shutil
    import tempfile
    import unittest

    if hasattr(ssl, '_create_unverified_context'):
        ssl._create_default_https_context = ssl._create_unverified_context

    def _main():
        pass

    def _real_extract(self, url):
        """ Return an extractor """
        ie = self._download_webpage(url, url, 'Downloading webpage')
        info_dict = {}
        info_dict['url'] = url

# Generated at 2022-06-22 07:06:26.458588
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD()


# Generated at 2022-06-22 07:06:36.626962
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from . import YoutubeDL
    from .extractor.youtube import YoutubeIE
    ydl = YoutubeDL()
    ydl.add_info_extractor(YoutubeIE())
    ydl.params.update({
        'usenetrc': False,
        'username': '',
        'password': '',
        'video_password': '',
        'videopassword': '',
        'ap_mso': '',
        'ap_username': '',
        'ap_password': '',
        'ap_password_transient': False,
    })
    ydl.conf.postprocessors = []
    ydl.conf.update({
        'format': 'best',
        'outtmpl': '%(id)s.%(ext)s',
    })


# Generated at 2022-06-22 07:06:48.025897
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.http import HTTPIE_DOWNLOAD_ARGS
    class MockYTDLSamples(object):
        def __init__(self):
            self.samples = []

# Generated at 2022-06-22 07:07:00.065690
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:07:03.772689
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import youtube_dl.YoutubeDL
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({'progress_hooks': []})
    fd_hls = HlsFD(ydl)
    assert fd_hls.FD_NAME == 'hlsnative'

# Generated at 2022-06-22 07:07:17.394060
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass

# Generated at 2022-06-22 07:07:29.363169
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor

    def _prepare_url(self, _, url):
        return url

    InfoExtractor._prepare_url = _prepare_url
    # Test with a real media fragment

# Generated at 2022-06-22 07:07:40.262373
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """
    Test for HlsFd and also serves as a test for can_download.
    """
    from youtube_dl.YoutubeDL import YoutubeDL

    ydl = YoutubeDL()
    ydl.params['noplaylist'] = True
    hls_fd = HlsFD(ydl, {'hls_use_mpegts': True})

    # Manifest with unsupported features

# Generated at 2022-06-22 07:07:53.148014
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import youtube_dl.YoutubeDL
    import youtube_dl.downloader

# Generated at 2022-06-22 07:08:04.321859
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..downloader import get_suitable_downloader
    from ..utils import prepend_extension

    import tempfile

    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        axt = YoutubeIE(get_suitable_downloader(YoutubeIE.ie_key(), 'hlsnative'))
        axt.report_download_webpage('https://www.youtube.com/watch?v=lYmZrD1pk9E')
        axt.report_extraction("TEST")
        info_dict = axt.result['entries'][0]
        assert HlsFD.can_download(info_dict['url'], info_dict)

# Generated at 2022-06-22 07:08:13.287804
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Set the following environment variable to 1 to turn on the tests
    if int(os.environ.get("TEST_HLSNATIVE", 0)):
        import sys
        import os.path
        import tempfile
        sys.path.append(os.path.dirname(os.path.realpath(__file__)))
        import test_utils
        import youtube_dl

        def test_real_download(ydl, playlist, options, expected_files):
            print("Testing playlist %s" % playlist)
            sys.stdout.flush()
            with tempfile.NamedTemporaryFile() as t:
                t.close()
                ydl.add_default_info_extractors()
                ydl.add_info_extractor(youtube_dl.extractor.generic.GenericIE())
                ydl.add_info

# Generated at 2022-06-22 07:08:25.003559
# Unit test for constructor of class HlsFD

# Generated at 2022-06-22 07:08:35.142059
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Basic test
    yield (
        HlsFD.can_download,
        (b'', {}),
        None,
        True,
    )
    # Test for method can_download of class HlsFD: presence of '#EXT-X-KEY:METHOD=NONE'
    yield (
        HlsFD.can_download,
        (b'', {}),
        b'#EXT-X-KEY:METHOD=NONE',
        True,
    )
    # Test for method can_download of class HlsFD: presence of '#EXT-X-KEY:METHOD=AES-128'
    yield (
        HlsFD.can_download,
        (b'', {}),
        b'#EXT-X-KEY:METHOD=AES-128',
        True,
    )
    # Test for method can_

# Generated at 2022-06-22 07:08:47.990645
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('', {'url': ''})
    assert not HlsFD.can_download(
        '#EXT-X-KEY:METHOD=SAMPLE-AES', {'url': ''})
    assert HlsFD.can_download(
        '#EXT-X-KEY:METHOD=NONE', {'url': ''})
    assert not HlsFD.can_download(
        '#EXT-X-BYTERANGE:001', {'url': ''})

    # HlsFD can not download live streams
    assert not HlsFD.can_download(
        '#EXT-X-MEDIA-SEQUENCE:4660', {'url': '', 'is_live': True})

# Generated at 2022-06-22 07:08:58.272090
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():

    from .test_frags import _test_downloader
    from .test_frags import _test_player

    def _run_test(case, data_func, expected_lengths):
        dl, info_dict = _test_downloader(HlsFD, case, data_func)
        _test_player(dl, info_dict, expected_lengths, case)

    live_playlist = '''#EXTM3U
#EXT-X-VERSION:3
#EXT-X-PLAYLIST-TYPE:EVENT
#EXT-X-TARGETDURATION:11
#EXT-X-MEDIA-SEQUENCE:0
#EXTINF:10.0,
fileSequence0.ts
#EXTINF:1.0,
fileSequence1.ts
#EXT-X-ENDLIST'''

   

# Generated at 2022-06-22 07:09:24.699518
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import doctest
    doctest.testmod(HlsFD)

# Generated at 2022-06-22 07:09:30.470231
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # return
    print("""test_m3u8_real_download: start""")
    m3u8_real_download("https://mnmedias.api.telequebec.tv/m3u8/29880.m3u8", "testHlsFD_real_download.mp4")
    print("""test_m3u8_real_download: end""")



# Generated at 2022-06-22 07:09:42.185808
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .dash import DashSegmentsFD
    from .external import YoutubeDL
    from .options import Options
    from .extractor import ListExtractor

    opts = Options()

    ydl = YoutubeDL(opts)
    dash_segments_extractor = ListExtractor(ydl, [
            'https://video-dev.github.io/streams/x36xhzz/x36xhzz.m3u8'
    ])


# Generated at 2022-06-22 07:09:53.533083
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import random
    import shutil
    import tempfile

    from ..utils import sanitize_open

    with tempfile.NamedTemporaryFile(delete=False) as f:
        output_path = f.name


# Generated at 2022-06-22 07:10:04.709062
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    HlsFD.download = lambda self, *args, **kargs: 42
    # Test can_download()
    class YDL:
        def __init__(self):
            self.params = {}  # Not used
    ydl = YDL()
    ydl.params = {}
    #
    # Playlist composed of byte ranges of media files (EXT-X-BYTERANGE)
    #
    hls = '#EXTM3U\n'
    hls += '#EXT-X-VERSION:4\n'
    hls += '#EXT-X-TARGETDURATION:8\n'
    hls += '#EXT-X-MEDIA-SEQUENCE:1\n'
    hls += '#EXT-X-BYTERANGE:522828@0\n'

# Generated at 2022-06-22 07:10:16.172372
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    import unittest
    import shutil
    from contextlib import contextmanager
    import tempfile
    from ..utils import encode_compat_str

    @contextmanager
    def make_temp_directory():
        path = tempfile.mkdtemp()
        try:
            yield path
        finally:
            shutil.rmtree(path)

    @contextmanager
    def override_std_streams():
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        sys.stdout = open(os.devnull, 'w')
        sys.stderr = open(os.devnull, 'w')
        try:
            yield
        finally:
            sys.stdout.close()
            sys.stderr.close()
            sys.stdout = old

# Generated at 2022-06-22 07:10:26.824577
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    requires_crypto = not can_decrypt_frag
    # These tests assume that the manifest has not been tampered with (i.e. it contains
    # the correct information).

# Generated at 2022-06-22 07:10:29.264980
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD is not None

if __name__ == "__main__":
    test_HlsFD()

# Generated at 2022-06-22 07:10:38.704609
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download('#EXTM3U', {'is_live': True}) == False
    assert HlsFD.can_download('#EXTM3U', {})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="http://example.com/key"', {})
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="http://example.com/key"', {'_decryption_key_url':'http://example.com/key'})

# Generated at 2022-06-22 07:10:50.568457
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class SampleManifestFD(HlsFD):
        pass

    class FakeInfoDict:
        pass

    fd = SampleManifestFD(None, None)
    assert fd.can_download('', FakeInfoDict()) is True
    for feature in HlsFD.can_download.__func__.__doc__[1:-1].split(')'):
        if '[' in feature:
            feature, _ = feature.strip().rsplit('[', 1)
        else:
            _, feature = feature.strip().rsplit(')', 1)
        assert fd.can_download('#' + feature, FakeInfoDict()) is True
        assert fd.can_download('#' + feature + '\n', FakeInfoDict()) is False

# Generated at 2022-06-22 07:12:19.820988
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    info_dict = {'url': ''}
    # Live stream
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:5', info_dict)
    # Appended segments
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-PLAYLIST-TYPE:EVENT', info_dict)
    # Encrypted segment stream
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', info_dict)
    # Unsupported encryption method
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=UNSUPPORTED', info_dict)
    # Non-encrypted segment stream
    assert HlsFD.can

# Generated at 2022-06-22 07:12:25.199060
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..utils import bogus_ytdl_object
    import tempfile
    ydl = bogus_ytdl_object()
    fd = HlsFD(ydl, {})
    assert fd.real_download(tempfile.NamedTemporaryFile().name, {'url': ''}) == False

# Generated at 2022-06-22 07:12:35.844828
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from unittest import TestCase
    import io
    import tempfile
    import yaml
    import threading
    import youtube_dl.FileDownloader
    import youtube_dl.extractor.common
    class TestCaseHlsFD_real_download(TestCase):
        @classmethod
        def setUpClass(cls):
            cls.lock = threading.Lock()
            youtube_dl.extractor.common.lock = cls.lock

        def setUp(self):
            self.log = []
            self.hls_fd = HlsFD(youtube_dl.FileDownloader({'logger': self}))

        def info(self, msg):
            self.log.append(msg)

        def warning(self, msg):
            self.info('[warn] %s' % msg)


# Generated at 2022-06-22 07:12:46.951436
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-VERSION:3\n'
        '#EXT-X-STREAM-INF:BANDWIDTH=128000,RESOLUTION=320x240\n'
        '/hls-live/livepkgr/_definst_/livestream.m3u8',
        {
            'url': 'https://someurl',
        },
    )

# Generated at 2022-06-22 07:12:48.270512
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # This test is done by test_fragment.py
    pass

# Generated at 2022-06-22 07:12:58.497506
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Adjust constants to avoid conflicting with other unittests.
    HlsFD.FD_NAME = 'hlsnative'
    HlsFD.FRAGMENT_RE = re.compile('^#EXTINF:(?P<duration>[0-9.]+)')

    assert(HlsFD.can_download("#EXTM3U\n#EXT-X-KEY:METHOD=NONE\n#EXTINF:4.0\nuri\n", {}))
    assert(not HlsFD.can_download("#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\n#EXTINF:4.0\nuri\n", {}))

# Generated at 2022-06-22 07:13:08.158485
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import youtube_dl.extractor.http as http

    # Supported features
    assert HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-VERSION:3\n'
        '#EXT-X-MEDIA-SEQUENCE:0\n'
        '#EXT-X-ALLOW-CACHE:YES\n'
        '#EXT-X-TARGETDURATION:11\n'
        '#EXTINF:10,\n'
        '0.ts\n'
        '#EXTINF:10,\n'
        '1.ts\n'
        '#EXT-X-ENDLIST\n', {
            'url': 'whatever',
            'http_headers': {},
        }
    )

    # Unsupported features