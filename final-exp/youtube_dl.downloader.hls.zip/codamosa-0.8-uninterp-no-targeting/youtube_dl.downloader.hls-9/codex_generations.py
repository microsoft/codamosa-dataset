

# Generated at 2022-06-22 07:03:43.972411
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    print('beginning test')
    from .extractor.common import InfoExtractor, FileDownloader
    from .downloader import HlsFD
    import json
    import os
    import shutil
    import tempfile
    import threading
    import time
    import unittest
    import urllib
    import urllib.request
    try:
        from Crypto.Cipher import AES
    except Exception:
        print('pycrypto not found. Please install it.')
        exit()

    # Temporary directory with files needed for the tests
    tmp_dir = tempfile.mkdtemp()

    # This is a manifest with no encryption scheme included since pycrypto is not included in Travis builds

# Generated at 2022-06-22 07:03:55.881501
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    from ..utils import encode_data_uri
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..postprocessor import FFmpegMetadataPP
    from .m3u8_native import M3u8FD, test_M3u8FD_real_download

    def _download_via_ie(url, params=None, check_video_id=None, check_video_filename=None):
        if params is None:
            params = {}
        params.setdefault('format', 'best')
        params.setdefault('outtmpl', '%(id)s.%(ext)s')
        params.setdefault('noprogress', True)
        params.setdefault('ignoreerrors', True)
        ie = InfoExtractor(params)


# Generated at 2022-06-22 07:04:04.643801
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download(
        """#EXTM3U
#EXT-X-VERSION:3
#EXT-X-MEDIA-SEQUENCE:0
#EXT-X-PLAYLIST-TYPE:VOD
#EXTINF:3, no desc
media.ts
#EXT-X-ENDLIST
""",
        {'url': '', 'protocol': 'm3u8'},)

# Generated at 2022-06-22 07:04:17.398639
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ydl_opts = {
        'skip_download': True,
        'quiet': True,
        'noprogress': True,
        'nocheckcertificate': True,
        'playlistend': 1,
    }


# Generated at 2022-06-22 07:04:27.086815
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:04:30.732362
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, {'force_generic_extractor': '1', 'format': 'bestvideo[protocol^=http][height>=720]+bestaudio[protocol^=http]/best'})

# Generated at 2022-06-22 07:04:44.285716
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors
    from ..compat import is_py2

    _RealHlsFDClass = HlsFD
    _HlsFDClass = gen_extractors()['hlsnative']

    def _can_download(hls_manifest, info_dict):
        return (_HlsFDClass.can_download(hls_manifest, info_dict)
                if is_py2 else _HlsFDClass.can_download(hls_manifest, info_dict, {}))

    def _is_fragment_encrypted(hls_manifest):
        return '#EXT-X-KEY' in hls_manifest


# Generated at 2022-06-22 07:04:49.388060
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    hls_fd = HlsFD(None, None)
    # Manifest is not a live stream.
    manifest = '#EXT-X-VERSION:4\n#EXT-X-TARGETDURATION:3\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:3.000000,\n0.ts\n#EXTINF:3.000000,\n1.ts\n#EXTINF:3.000000,\n2.ts\n#EXTINF:3.000000,\n3.ts\n#EXT-X-ENDLIST'
    # Manifest is not encrypted, but has byteranges.

# Generated at 2022-06-22 07:04:59.697405
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import datetime_str, prepend_extension
    from ..compat import (
        compat_cookielib,
        compat_urllib_parse_urlencode,
    )
    from io import BytesIO

    def urlopen_side_effect(request):
        url = request.full_url
        query = compat_urlparse.parse_qs(compat_urlparse.urlparse(url).query)
        try:
            service = query['service'][0]
        except KeyError:
            service = query['confirm'][0]

# Generated at 2022-06-22 07:05:10.631148
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Assert: HlsFD can not download live stream.
    assert not HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-MEDIA-SEQUENCE:0\n'
        '#EXT-X-TARGETDURATION:3\n'
        '#EXTINF:3,\n'
        '#EXT-X-PLAYLIST-TYPE:VOD',
        {'is_live': True})
    # Assert: HlsFD can not download streams protected with AES-128.

# Generated at 2022-06-22 07:05:35.517379
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Test non-encrypted playlists
    assert HlsFD.can_download('#EXTM3U', {})
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1280000', {})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-VERSION:3', {})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="http://foo.bar/key"', {})

# Generated at 2022-06-22 07:05:48.465855
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import _get_testdata_folder

    # First test that hlsnative is used when available
    manifest = _get_testdata_folder() + '/hls/non_aes_manifest.m3u8'
    with open(manifest, 'rb') as fp:
        assert HlsFD._is_usable_manifest(fp.read().decode(), {})

    # Now test that hlsnative is not used for more complex manifests
    manifest = _get_testdata_folder() + '/hls/aes_manifest.m3u8'
    with open(manifest, 'rb') as fp:
        assert not HlsFD._is_usable_manifest(fp.read().decode(), {})

if __name__ == '__main__':
    test_HlsFD_real_download

# Generated at 2022-06-22 07:05:53.273624
# Unit test for constructor of class HlsFD
def test_HlsFD():
    output = dict()
    runner = HlsFD(None);
    assert(runner.FD_NAME == 'hlsnative')
    runner.real_download(output, dict(url = 'VIDEO_URL', num_frags = 4))

# Generated at 2022-06-22 07:06:04.826725
# Unit test for constructor of class HlsFD
def test_HlsFD():
    #TODO: make it work without ffmpeg, or use ffmpeg if pycrypto is not present
    import youtube_dl.extractor.generic

    class MockInfoDict(dict):
        def __init__(self, url, urlh):
            self.__setitem__('url', url)
            self.__setitem__('urlh', urlh)

    youtube_dl.extractor.generic.InfoExtractor = MockInfoDict
    info_dict = {
        'url': 'https://example.com/hls.m3u8',
        'urlh': 'https://example.com/hls.m3u8',
        'http_headers': {
        },
    }

    fd = HlsFD(None, {'restrictfilenames': True})

# Generated at 2022-06-22 07:06:16.917208
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from dotenv import load_dotenv
    load_dotenv(verbose=True)

    import os
    from .youtube_dl.extractor import youtube
    from .youtube_dl.postprocessor import FFmpegMetadataPP
    from .youtube_dl.YoutubeDL import YoutubeDL
    from .youtube_dl.YoutubeDL import _prepare_format_dict
    import json

    # Get URL to test
    url_live_mux_hls_dfxp = 'https://live-mux-hls.unicorn.ai/video/ch2/20200303/ch2_20200303_1815.ism/ch2_20200303_1815.ism.m3u8'

# Generated at 2022-06-22 07:06:29.063824
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'hls_prefer_native': True})
    info = {
        'url': 'http://example.com/index.m3u8',
        '_type': 'hls',
        'http_headers': {},
    }

    hlsfd = HlsFD(ydl, {})
    hlsfd.real_download('filename', info)

    assert hlsfd.fd is None
    assert hlsfd.frag_index == 0
    assert hlsfd.total_frags == 0
    assert hlsfd.frag_size == 0
    assert hlsfd.ytdl == ydl
    assert hlsfd.params == {}

    hlsfd.on_info(info)
    hlsfd.on_ex

# Generated at 2022-06-22 07:06:38.734636
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    assert HlsFD.real_download.__doc__
    if not can_decrypt_frag:
        return True
    manifest = u"""
    #EXTM3U
    #EXT-X-TARGETDURATION:10
    #EXT-X-VERSION:3
    #EXT-X-MEDIA-SEQUENCE:1
    #EXT-X-KEY:METHOD=AES-128,URI="https://key_url",IV=0x33333222111000ffeeddccbbaa998877
    #EXTINF:10,
    https://frag/1.ts
    #EXTINF:10,
    https://frag/2.ts
    #EXTINF:10,
    https://frag/3.ts
    #EXT-X-ENDLIST"""

   

# Generated at 2022-06-22 07:06:51.187578
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import sys

    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    import YoutubeDL


# Generated at 2022-06-22 07:07:01.597130
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Test feature: encrypted streams
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=NONE', None)
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', None)
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-CENC', None)

    # Test feature: playlists composed of byte ranges of media files
    assert HlsFD.can_download('#EXTINF:0.04', None)
    assert HlsFD.can_download('#EXT-X-BYTERANGE:2048@0', None)
    assert not HlsFD.can_download('#EXT-X-BYTERANGE:5120@0', None)

    # Test feature: live streams

# Generated at 2022-06-22 07:07:03.829683
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # TODO: Write unit test for method real_download of class HlsFD
    pass

# Generated at 2022-06-22 07:07:39.907030
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:07:52.767515
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os, sys
    print('Testing HlsFD.can_download')
    # read test manifests from directory
    # directory name is the expected result
    # file name is the description of the manifest
    result_dir = './test_hls'
    failed_manifests = []
    for root, subFolders, files in os.walk(result_dir):
        for file in files:
            filePath = os.path.join(root, file)
            expected_result = filePath.split('/')[-2]
            with open(filePath, 'r') as f:
                test_manifest = f.read()
            try:
                success = HlsFD.can_download(test_manifest, {})
            except Exception as e:
                success = False
            # print expected result and the result found
           

# Generated at 2022-06-22 07:08:01.692369
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # This test requires "pycrypto"
    # pip3 install pycrypto
    # See: https://pypi.org/project/pycrypto/
    if not can_decrypt_frag:
        return

    import os
    import random
    import re
    import shutil
    from .html import FakeYDL
    from ..utils import encodeFilename

    def write_to_file(filename, data):
        with open(filename, 'wb') as f:
            f.write(data)

    def fragment_content(i, test_id):
        assert i < 100
        return (
            b'I am the fragment number ' + hex(i)[2:].zfill(2).encode('ascii') +
            b', test=' + test_id.encode('ascii')
        )


# Generated at 2022-06-22 07:08:13.899057
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    class TestIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'url': url,
                'is_live': False,
                'http_headers': {},
            }

    ydl = YoutubeDL({})
    ie = TestIE(ydl)

# Generated at 2022-06-22 07:08:25.545054
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..downloader.common import InfoExtractor
    from ..extractor.common import FileDownloader

    def get_HlsNativeFD_can_download(manifest):
        class HlsNativeFD_can_download(HlsFD):
            def __init__(self, ydl):
                HlsFD.__init__(self, ydl, {})

            def can_download(self, manifest, info_dict):
                return HlsFD.can_download(self, manifest, info_dict)

        ydl = FileDownloader({'hls_use_mpegts': True})
        ydl.add_info_extractor(InfoExtractor('video', 'test', {}))
        ydl.report_warning = lambda msg: msg
        ydl.add_default_info_extractors()

# Generated at 2022-06-22 07:08:33.115251
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import YoutubeDL

    # normal case
    manifest_url = 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8'
    ydl = YoutubeDL({})
    info_dict = {'url': manifest_url, 'ext': 'mp4'}
    manifest = ydl.urlopen(manifest_url).read().decode('utf-8', 'ignore')
    assert(HlsFD.can_download(manifest, info_dict))

    # encrypted (AES-128) case
    manifest_url = 'https://bitmovin-a.akamaihd.net/content/playhouse-vr/m3u8s/105560.m3u8'
    ydl = YoutubeDL({})

# Generated at 2022-06-22 07:08:45.320624
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:08:46.280173
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD('youtube-dl', {})

# Generated at 2022-06-22 07:08:50.268107
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    assert HlsFD.can_download('', {'url': sys.argv[1]})

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-22 07:08:58.751234
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.youtube import YoutubeIE
    from ..utils import DateRange
    from ..downloader.common import FileDownloader

    url = 'https://mnmedias.api.telequebec.tv/m3u8/29880.m3u8'
    ie = YoutubeIE(dict(ydl=FileDownloader()))
    info_dict = ie._real_extract(url)
    assert HlsFD.can_download(info_dict['url'], info_dict) == True
    assert info_dict['protocol'] == 'm3u8'
    assert info_dict['ext'] == 'mp4'


# Generated at 2022-06-22 07:10:03.812406
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download('', {'is_live': False}) is False
    assert HlsFD.can_download('', {'is_live': True}) is False

    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'is_live': False}) is True
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'is_live': True}) is False

    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'extra_param_to_segment_url': 'key=value'}) is True

# Generated at 2022-06-22 07:10:11.081497
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .http import HttpFD
    from .test import TESTS
    from ..utils import urljoin


# Generated at 2022-06-22 07:10:22.528081
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .external import ExternalFD
    from ..utils import HEADRequest
    import json
    import requests
    import sys
    import tempfile
    import pytest
    import os
    import shutil
    import time

    class YDL():
        def __init__(self, params):
            self.params = params
            self.to_screen = lambda *_, **__: None
            self.report_error = lambda *_, **__: None

        def _prepare_url(self, info_dict, url):
            return url

        def urlopen(self, url):
            req = HEADRequest(url)
            if self.params.get('http_chunk_size'):
                req.headers['Range'] = 'bytes=0-%d' % self.params['http_chunk_size']

# Generated at 2022-06-22 07:10:33.047769
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .downloader import FileDownloader
    from .downloader.http import HeadRequest
    from .extractor.youtube import YoutubeIE
    from .compat import compat_http_server
    from .utils import prepend_extension
    import socket
    import threading
    import tempfile
    import time
    import os
    import functools
    from .compat import urllib_request, compat_urllib_error, bytes_to_str, str_to_bytes, compat_str, compat_struct_pack
    from .embedthumb import (
        embed_image_in_tag,
    )
    from ..extractor.utils import (
        NO_DEFAULT,
    )

    # variables to be used in the

# Generated at 2022-06-22 07:10:44.817267
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-22 07:10:55.671232
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors
    from ..postprocessor import FFmpegMetadataPP

    ext_dict = gen_extractors()
    def get_manifest(url):
        ie = ext_dict[url]
        info = ie.extract(url)
        return info['entries'][0]['url']

    manifest = get_manifest('http://www.tvc.ru/news/show/id/912688')
    info_dict = {'url': manifest}
    with open(FFmpegMetadataPP.META_TEMPLATE) as meta_f:
        info_dict['http_headers'] = {'User-Agent': meta_f.read()}

    return HlsFD.can_download(manifest, info_dict)



# Generated at 2022-06-22 07:10:57.674965
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_fd = HlsFD(None, None)
    assert hls_fd.FD_NAME == 'hls'

# Generated at 2022-06-22 07:11:08.775280
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:11:14.755191
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    info_dict = {'url' : 'http://vjs.zencdn.net/v/oceans.mp4'}
    filename = tmpfile_path()
    hls = HlsFD(None, None)
    hls.real_download(filename, info_dict)
    assert os.path.isfile(filename)
    os.remove(filename)

# Generated at 2022-06-22 07:11:15.833400
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD is not None