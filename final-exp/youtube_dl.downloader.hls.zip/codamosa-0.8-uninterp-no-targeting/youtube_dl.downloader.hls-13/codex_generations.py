

# Generated at 2022-06-22 07:03:42.483405
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.generic import DownloadError
    from .http import HttpFD
    from .external import FFmpegFD


# Generated at 2022-06-22 07:03:54.418299
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-22 07:03:55.989466
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # ToDo: Write Unit Test
    return


# Unit Test for download_fragment of class HlsFD

# Generated at 2022-06-22 07:04:05.058411
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import youtube
    from ..downloader import YoutubeDL

# Generated at 2022-06-22 07:04:17.821984
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import YoutubeIE
    from ..downloader import BaseDownloader
    ydl = BaseDownloader(params={})
    ydl.add_info_extractor(YoutubeIE.ie_key())

    # HLS_NATIVE
    # playlist with audio-only
    url = 'https://www.youtube.com/watch?v=2mIYmXR8uFU'
    ie = YoutubeIE._real_extract(ydl, {'url': url})[0]
    assert HlsFD.can_download(ie['manifest_url'], ie)

    # playlist with video only
    url = 'https://www.youtube.com/watch?v=2mIYmXR8uFU'

# Generated at 2022-06-22 07:04:30.061022
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.http import HttpFD
    tests = [
        {'url': 'http://tv.nrk.no/serie/trolljenta/MUHH48000314/sesong-1/episode-2#stream/1'},
        {'url': 'http://tv.nrk.no/serie/trolljenta/MUHH48000314/sesong-1/episode-2', 'skip': True},
    ]
    for t in tests:
        ie = InfoExtractor('test', ie_key='HlsFD', ie_py_ver=3)
        ie.add_info_extractor(HlsFD)
        if t.get('skip', False):
            ie._downloader.params.update({'noplaylist': True})
       

# Generated at 2022-06-22 07:04:43.791546
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """ Tests HlsFD.real_download with an on-demand playlist """
    from .http import HttpFD
    from ..extractor import LocalExtractor

    # Download an HLS video with no ads and no encryption.
    video_id = 'wMbQQvZhCnU'

# Generated at 2022-06-22 07:04:45.420660
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hlsfd = HlsFD()
    assert hlsfd == HlsFD

# Generated at 2022-06-22 07:04:56.927451
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def assert_can_download(manifest, info_dict, expected):
        assert HlsFD.can_download(manifest, info_dict) == expected
    # create a mock info_dict
    info_dict = {
        'url': '',  # doesn't matter here
    }
    # Test a playlist
    manifest = r'''
#EXTM3U
#EXT-X-TARGETDURATION:10
#EXTINF:9.009,
http://media.example.com/first.ts
#EXTINF:9.009,
http://media.example.com/second.ts
#EXTINF:3.003,
http://media.example.com/third.ts
#EXT-X-ENDLIST
    '''
    assert_can_download(manifest, info_dict, True)

    #

# Generated at 2022-06-22 07:05:09.728459
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from .fragment import FragmentFD

    assert YoutubeIE.can_handle_url('https://foo.bar/baz/master.m3u8')

    # test missing pycrypto
    hlsfd = HlsFD({}, {})
    assert hlsfd.can_download('#EXT-X-KEY:METHOD=AES-128', {})
    assert not hlsfd.can_download('#EXT-X-KEY:METHOD=AES-128', {})

    hlsfd = HlsFD(None, None)
    hlsfd.ydl = {
        'urlopen': lambda url: {'status': 200},
    }
    hlsfd.report_error = lambda msg: None
    hlsfd.report_warning = lambda msg: None
    # test fragment download

# Generated at 2022-06-22 07:05:45.126864
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testdata_file
    info_dict = {
        'url': 'http://example.org/index.m3u8', # can be a playlist
        '_decryption_key_url': 'http://example.org/key.key',
        'http_headers': {'Test': 'Header'},
        'requested_formats': [
            {
                'format_id': '720',
                'cipher': {
                    'IV': '0x1234',
                    'uri': 'http://example.org/crypto.key'
                }
            }
        ],
        'is_live': True,
        '_total_bytes': 100
    }
    filename = get_testdata_file('index.m3u8')

# Generated at 2022-06-22 07:05:57.149203
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # pylint: disable=protected-access
    from .fragment import FragmentFD
    from .external import FFmpegFD
    from .hls_native import HlsFD

    from ..compat import (
        compat_urllib_request,
        compat_urllib_error,
    )

    import unittest

    class FakeYtdl(object):
        class FakeUrlopen(object):
            def __init__(self, url):
                self.url = url

            def read(self):
                return compat_urllib_request.urlopen(self.url).read()

            def geturl(self):
                return self.url

            def close(self):
                pass

        def __init__(self, params):
            self.params = params

        def urlopen(self, url):
            return

# Generated at 2022-06-22 07:06:03.526727
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import unittest
    import tempfile
    import shutil
    import youtube_dl.FileDownloader
    from youtube_dl.utils import compat_struct_pack
    from tests.test_downloader_http import mock_http_server_port
    from tests.test_downloader_http import setup_mock_http_server
    from tests.test_downloader_http import stop_mock_http_server

    def hls_base64_decrypt(key, data, iv, padding=True):
        cipher = AES.new(key, AES.MODE_CBC, iv)
        # Do we need to pad the data?
        if padding and len(data) % cipher.block_size != 0:
            padding_length = cipher.block_size - (len(data) % cipher.block_size)

# Generated at 2022-06-22 07:06:15.833307
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .fragment import FragFD
    from .external import FFmpegFD
    from ..utils import FakeYDL
    myydl = FakeYDL()

    fd = FragFD(myydl, {})
    assert not fd.can_download({}, {})
    assert not fd.can_download({'ext': 'm3u8'}, {})
    assert not fd.can_download({'ext': 'm3u8', 'is_live': True}, {})
    assert not fd.can_download({'ext': 'm3u8', 'protocol': 'm3u8_native'}, {})
    assert not fd.can_download({'ext': 'm3u8', 'protocol': 'm3u8_native', 'is_live': True}, {})

# Generated at 2022-06-22 07:06:22.863235
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .fragment import FragmentFD
    from .external import FFmpegFD
    from ..utils import FakeYDL

    ydl = FakeYDL()

    # no ffmpeg (checking first feature)
    fd = HlsFD(ydl, {})
    assert fd.can_download(
        '#EXTM3U\n'
        '#EXT-X-TARGETDURATION:10\n'
        '#EXT-X-VERSION:3\n'
        '#EXT-X-KEY:METHOD=AES-128,URI="https://priv.example.com/key.php?r=52"\n'
        '#EXT-X-KEY:METHOD=NONE',
        {'url': 'http://some_url.com/404.m3u8'})

    # no ffmpeg, py

# Generated at 2022-06-22 07:06:32.202101
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # METHOD != NONE
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=XXX', None)

    # METHOD == NONE
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=NONE', None)
    # METHOD == AES-128 with no pycrypto
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', None)
    # METHOD == AES-128 with pycrypto
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', None, pycrypto=True)

    # EXT-X-BYTERANGE with METHOD == AES-128

# Generated at 2022-06-22 07:06:45.086342
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .smoothstreams import SmoothStreamsFD

# Generated at 2022-06-22 07:06:54.152989
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .utils import FakeYDL
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader

    url = "https://vod.llnw.cdn.level3.net/72/36/14/a22ca1d0e5e24ab9afac939768f8/46c65b78e6874b07a8dd0ba1cde0/DAS_POWERBOOTCAMP_HD_VON_MARIA_HINDERER-1.mp4.csmil/master.m3u8"
    ie = InfoExtractor({'outtmpl': '%(id)s'})
    ie.add_info_extractor(HlsFD)
    ie.consider_evaluation_tmp_file = False
    ie.extract(url)
    info

# Generated at 2022-06-22 07:07:06.216654
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .external import FFmpegFD
    from . import YoutubeDL
    from .extractor.common import InfoExtractor
    from mock import MagicMock

    class MockInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'mocked',
                'url': url,
                'is_live': False,
                'title': 'mocked'
            }
    orig_FFmpegFD_real_download = FFmpegFD.real_download

    def mock_FFmpegFD_real_download(self, *args, **kwargs):
        return 0

# Generated at 2022-06-22 07:07:19.320779
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os.path
    import json


# Generated at 2022-06-22 07:07:53.103337
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Creating test objects
    info_dict = {
        'hls_entry_protocol': 'absolute'
    }
    hd = HlsFD(None, {})

    # Testing is_aes_128 encryption with non-absolute m3u8
    info_dict['hls_entry_protocol'] = 'relative'
    manifest = '#EXTM3U\n' \
                '#EXT-X-TARGETDURATION:10\n' \
                '#EXT-X-KEY:METHOD=AES-128,URI="my_key_url"\n' \
                '#EXTINF:9.009,\n' \
                'media-00001.ts\n' \
                '#EXT-X-ENDLIST\n'

# Generated at 2022-06-22 07:08:04.254929
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def can_download_test(in_value, out_value):
        info_dict = {}
        print('in value: %s' % in_value)
        print('out value: %s' % out_value)
        assert HlsFD.can_download(in_value, info_dict) == out_value
        print('passed')


# Generated at 2022-06-22 07:08:06.101875
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD(object)


# Generated at 2022-06-22 07:08:17.450785
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """Unit test function for HlsFD.real_download"""
    import sys
    import tempfile
    import unittest
    from io import BytesIO

    from ..utils import FakeYDL


# Generated at 2022-06-22 07:08:28.505375
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import get_info_extractor
    HlsFD.can_download(
        '#EXTM3U\n#EXT-X-KEY:METHOD=NONE\n#EXTINF:5,\nfrag1\n#EXTINF:5,\nfrag2',
        get_info_extractor(
            'https://example.com/video.m3u8').extract(
                'https://example.com/video.m3u8'))
    # No crash for AES-128 encrypted stream

# Generated at 2022-06-22 07:08:34.153222
# Unit test for constructor of class HlsFD
def test_HlsFD():
  assert HlsFD.can_download("#EXTM3U\n#EXT-X-STREAM-INF:PROGRAM-ID=1, BANDWIDTH=200000\nmedia.m3u8\n", {'is_live': False, 'url': 'http://media.net/media.m3u8'}) == True

# Generated at 2022-06-22 07:08:44.610534
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .utils import FakeYDL

    ydl = FakeYDL()
    ydl.params['continuedl'] = True
    inst = HlsFD(ydl, {})
    assert inst.can_download('#EXTM3U\n#EXTINF:4.3,\nindex-v1-a1.ts\n', {'url': 'http://test.com'})
    assert not inst.can_download('#EXTM3U\n#EXTINF:4.3,\nindex-v1-a1.ts\n#EXT-X-KEY:METHOD=NONE\n', {'url': 'http://test.com'})

# Generated at 2022-06-22 07:08:56.050542
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    sys.modules['pycrypto'] = None
    # Certificate problem: unable to get local issuer certificate
    # https://github.com/ytdl-org/youtube-dl/issues/12665
    # > The only way to circumvent this problem is to disable HTTPS
    # > verification or use the system's default trust store
    # https://urllib3.readthedocs.io/en/latest/advanced-usage.html#ssl-warnings
    try:
        from urllib3.connectionpool import VerifiedHTTPSConnection
        VerifiedHTTPSConnection.cert_reqs = 'CERT_NONE'
    except ImportError:
        pass
    import youtube_dl
    assert HlsFD.can_download(open('tests/testdata/test.m3u8', 'r').read(), {})


# Generated at 2022-06-22 07:08:57.358943
# Unit test for constructor of class HlsFD
def test_HlsFD():
    fd = HlsFD(None, None)
    return True

# Generated at 2022-06-22 07:09:05.038998
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    import random
    import shutil
    import os.path
    BASE_URL = 'http://test.test/'
    MANIFEST_URL = BASE_URL + 'manifest.m3u8'
    BASE_PLAYLIST = (
        '#EXTM3U\n'
        '#EXT-X-VERSION:3\n'
        '#EXT-X-TARGETDURATION:1\n'
        '#EXT-X-MEDIA-SEQUENCE:0\n'
    )

# Generated at 2022-06-22 07:10:16.579462
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..utils import make_HTTPServer
    import threading
    import subprocess

    class TestHlsFD(HlsFD):
        def _download_fragment(s, ctx, frag_url, info_dict, headers):
            try:
                with s.ydl.urlopen(s._prepare_url(info_dict, frag_url), headers=headers) as urlh:
                    data = urlh.read()
            except:
                return False, None
            return True, data

    def run(hls_url, expected_url_qt_segments, expected_first_qt_segment_content, output_file_path):
        hls_manifest = YoutubeIE()._download_webpage(hls_url, None, 'Downloading the hls manifest')
       

# Generated at 2022-06-22 07:10:21.010402
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import sys
    import os
    from .downloader import make_YDLDummyLogger
    from .extractor import YoutubeIE

    class TestHlsFD(unittest.TestCase):
        def setUp(self):
            self.hlsfd = HlsFD(None, {'test': True})
            self.hlsfd.report_warning = lambda msg: sys.stderr.write('WARNING: ' + msg + '\n')
            self.ytdl = YoutubeIE(make_YDLDummyLogger('ERROR'))
            self.test_dir = os.path.join(os.path.dirname(__file__), 'test')

# Generated at 2022-06-22 07:10:32.613325
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    import os
    import pdb
    from ..compat import compat_str
    class YDL:
        class params:
            http_chunk_size = 1048576
            test = True
            dump_single_json = False
            force_generic_extractor = False
            get_filename = False
            skip_download = True
            noplaylist = False
            outtmpl = 'test.%(ext)s'
            write_description = False
            write_info_json = False
            write_annotations = False
            write_all_thumbnails = False
            write_thumbnail = False
            print_traffic = False
            geo_bypass = False
            geo_bypass_country = None
            geo_bypass_ip_block = None
            geo_bypass_only = False
            merge_

# Generated at 2022-06-22 07:10:44.661452
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('', {'url': 'https://example.com/foo.m3u8'})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'url': 'https://example.com/foo.m3u8'})
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'url': 'https://example.com/foo.m3u8', '_decryption_key_url': 'https://example.com/key.key'})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'url': 'https://example.com/foo.m3u8', 'is_live': True})
    assert not HlsFD.can

# Generated at 2022-06-22 07:10:55.613401
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil

    if can_decrypt_frag:
        test_dir_rel = 'test/files/hlsnative'
    else:
        test_dir_rel = 'test/files/hlsnative_without_decrypt'
    test_dir = os.path.normpath(os.path.join(os.path.dirname(__file__), test_dir_rel))
    temp_dir = tempfile.mkdtemp()

    # Run all tests, one by one
    for test_name in os.listdir(test_dir):
        test_dir_path = os.path.join(test_dir, test_name)
        test_media_path = os.path.join(test_dir_path, 'media')

# Generated at 2022-06-22 07:11:04.748523
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Test path_hls_download_1280x720m3u8_mixed_iv_and_no_iv
    url = 'http://127.0.0.1:8080/hls_download/1280x720m3u8_mixed_iv_and_no_iv/index.m3u8'
    temp_youtube_dl_instance = YoutubeDL({'quiet': True, 'skip_download': True})
    temp_hls_fd = HlsFD(temp_youtube_dl_instance, {'quiet': True, 'skip_download': True})
    assert temp_hls_fd.can_download(temp_youtube_dl_instance.urlopen(url).read().decode('utf-8', 'ignore'), {})

    # Test path_hls_download_1280x720m3u8_

# Generated at 2022-06-22 07:11:14.428412
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import re
    import json

    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    import youtube_dl
    from youtube_dl.utils import _set_writable
    from .utils import YoutubeDLHandler
    from .extractor import gen_extractors
    from .downloader import gen_openers

    _set_writable(os.path.join(os.path.dirname(__file__), '..', 'test', 'files'))
    filename = os.path.join(os.path.dirname(__file__), '..', 'test', 'files', 'hls_test.ts')
    os.remove(filename)

# Generated at 2022-06-22 07:11:24.653996
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data, get_test_handler
    from ..downloader.common import FileDownloader
    from ..extractor import YoutubeIE
    ydl = FileDownloader({'noprogress': True, 'quiet': True})
    ydl.add_info_extractor(YoutubeIE(ydl))

    # single non-encryped fragment

# Generated at 2022-06-22 07:11:30.073813
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    ie = InfoExtractor(YoutubeIE.ie_key())
    ie.extract('http://www.youtube.com/watch?v=BaW_jenozKc')
    assert HlsFD

# Generated at 2022-06-22 07:11:41.558483
# Unit test for constructor of class HlsFD
def test_HlsFD():
    class YDL:
        def __init__(self):
            self.params = {'hls_prefer_ffmpeg': False}

        def report_warning(self, msg):
            print('WARNING: ' + msg)

        def report_error(self, msg):
            print('ERROR: ' + msg)

        def urlopen(self, url):
            return FakeUrlOpen(url)

    class FakeUrlOpen:
        def __init__(self, url):
            self.url = url

        def read(self):
            with open(self.url[7:]) as f:
                return f.read()

        def geturl(self):
            return self.url

    class FakeInfoDict:
        def __init__(self, url, is_live=False):
            self.url = url