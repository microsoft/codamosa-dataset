

# Generated at 2022-06-22 07:03:41.285990
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .extractor import gen_extractors

    def get_info_dict(extractor):
        return {
            'extractor': extractor.IE_NAME,
            'webpage_url': 'http://ie.url.com/',
            '_type': 'url',
            'url': 'http://ie.url.com/',
            'ie_key': extractor.ie_key(),
        }

    def get_manifest(extractor):
        return extractor._download_webpage(extractor._WORKING_URL, None, False).get('manifest')

    def assert_can_download(expected, ie, info_dict, manifest):
        assert HlsFD.can_download(manifest, dict(info_dict, is_live=False)) == expected


# Generated at 2022-06-22 07:03:46.188032
# Unit test for constructor of class HlsFD
def test_HlsFD():
    url = b'https://host.com/playlist.m3u8'
    ydl = None
    params = {}
    hls = HlsFD(ydl, params)
    assert hls.params == params
    assert hls.ydl == ydl


# Generated at 2022-06-22 07:03:58.267790
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import pytest
    import datetime
    from .fragment import FragmentFD
    from .external import FFmpegFD

    # This test is not expected to work on Windows, because it doesn't have
    # a working way to download files to the filesystem.
    if sys.platform == 'win32':
        pytest.skip('This test needs the filesystem to work')

    # This test needs to know what requests are sent, so we mock the URL open
    # function.
    ffmpeg_data = 'ffmpeg data'
    def hook_open(context, url, *args, **kwargs):
        assert url == 'https://example.org/file.hls'
        assert kwargs['http_headers']['Range'] == 'bytes=0-'
        context['ffmpeg_download'] = True
       

# Generated at 2022-06-22 07:04:11.536386
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import pytest
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import get_filesystem_encoding
    from .utils import FakeYDL as YDL
    from .utils import FakeHttpServer as HttpServer

    with HttpServer() as server:
        server.set_response_content(b'\x01\x00')
        server.set_response_content(b'\x02\x00')
        server.set_response_content(b'\x03\x00')


# Generated at 2022-06-22 07:04:24.625965
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:04:30.362662
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import test_download, assertRegex
    ydl_opts = {
        'format': 'hlsnative',
        'outtmpl': '-',
        'nooverwrites': True,
        'quiet': True,
        'logger': None,
    }

    # Test that pycrypto is necessary to decrypt with HlsFD
    dash_test_opts = dict(ydl_opts)
    dash_test_opts['test'] = True
    dash_test_opts['forceurl'] = True
    url = 'https://issues.adblockplus.org/raw-attachment/ticket/5236/index.m3u8'
    dash_test_result = test_download(__name__, dash_test_opts, url)

# Generated at 2022-06-22 07:04:36.514021
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_dict = {'url': 'www.url.com'}
    d = HlsFD({'quiet': True}, test_dict)
    assert d.FD_NAME == 'hlsnative'
    assert d.params == {'quiet': True}
    assert d.info_dict == test_dict


# Generated at 2022-06-22 07:04:47.949332
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Get the content of the media segment at the given index.
    #
    # This method assumes that the playlist contains only one media sequence
    # and that its content matches what the playlist describes (i.e. the given
    # content is the one that would be downloaded by this extractor if one
    # were to download that particular segment).
    def get_media_segment_content(playlist, fragment_index):
        media_segment_url = None
        for line in playlist.split('\n'):
            if line.startswith('#EXT-X-MEDIA-SEQUENCE'):
                fragment_index += int(line[22:])
            elif line.startswith('#EXT-X-KEY'):
                pass
            elif line.startswith('#'):
                pass

# Generated at 2022-06-22 07:04:58.854235
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U', {})
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=NONE', {})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\n#EXT-X-BYTERANGE', {})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\n#EXT-X-BYTERANGE', {'_decryption_key_url': ''})

# Generated at 2022-06-22 07:05:10.192350
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    class FakeIE(InfoExtractor):
        def __init__(self, manifest, info_dict):
            InfoExtractor.__init__(self, None)
            self.manifest = manifest
            self.info_dict = info_dict

# Generated at 2022-06-22 07:05:33.874803
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    import os
    import tempfile
    import shutil
    
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Check if non-native has been delegated
    non_native_error_msg = 'hlsnative has detected features it does not support'
    sys.argv = [sys.argv[0], 'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_16x9/bipbop_16x9_variant.m3u8']
    os.chdir(tmpdir)
    try:
        HlsFD().run(test = True)
    except Exception as e:
        assert str(e) == non_native_error_msg

    # Check if native has not been delegated

# Generated at 2022-06-22 07:05:39.317132
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .dash import DashFD
    from .http import HTTPFD
    from .external import ExternalFD

    fd_list = (
        HlsFD,
        DashFD,
        HTTPFD,
        ExternalFD,
    )


# Generated at 2022-06-22 07:05:51.750502
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """ Run the constructor of HlsFD """
    class Options:
        """ Fake options for test """
        params = {}
        verbose = True
    class YDL:
        """ Fake YDL for test """
        params = {}
        def __init__(self):
            """ Fake init for test """
            self.params = {}
            self.to_screen = print
        def report_warning(self, msg):
            """ Fake report_warning for test """
            print(msg)
        def urlopen(self, url):
            """ Fake urlopen for test """
            class Response:
                """ Fake response for test """
                def __init__(self):
                    """ Fake init for test """
                    urlp = compat_urlparse.urlparse(url)
                    self.geturl = compat_urlparse.urlunparse(urlp)
           

# Generated at 2022-06-22 07:06:03.554268
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .dash import DashFD
    assert HlsFD.real_download(None, '',
        {'url': "http://example.com/file.m3u8",
         'http_headers': '',
         '_decryption_key_url': "http://example.com/enc.key",
         'extra_param_to_segment_url': '',
         'encoding': ''}) == False
    assert HlsFD.real_download(None, '',
        {'url': "http://example.com/file.m3u8",
         'http_headers': '',
         '_decryption_key_url': "http://example.com/enc.key",
         'extra_param_to_segment_url': '',
         'encoding': ''}) == False
    assert HlsFD.real

# Generated at 2022-06-22 07:06:15.833147
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    invalid_manifest = """
#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:12
#EXT-X-KEY:METHOD=SAMPLE-AES,URI="https://priv.example.com/key.php?r=52"
#EXT-X-STREAM-INF:BANDWIDTH=670000,AVERAGE-BANDWIDTH=650000,CODECS="mp4a.40.5,avc1.42e01e",RESOLUTION=848x480,FRAME-RATE=23.976,CLOSED-CAPTIONS=NONE
https://priv.example.com/fileSequence52-1.ts
#EXT-X-ENDLIST
"""

# Generated at 2022-06-22 07:06:28.122079
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """
    Unittest of HlsFD class
    """

    assert HlsFD.can_download('', {}) is True
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=NONE', {}) is True
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {}) is True
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128,URI="key.bin"', {}) is True
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128,URI="key.bin",IV=0x0bdc9c59bc2a66e9decec18a179a4935', {}) is True

# Generated at 2022-06-22 07:06:38.179830
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os.path
    import tempfile
    import subprocess

    import youtube_dl.FileDownloader
    filename = os.path.join(tempfile.gettempdir(), 'test-video')

# Generated at 2022-06-22 07:06:44.071789
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile

    HlsFD.real_download(
        None,
        {
            'url': 'url',
            'http_headers': {
                'user-agent': 'user-agent',
                'referer': 'referer',
            }
        },
        os.path.join(tempfile.gettempdir(), 'file.ts'),
    )

# Generated at 2022-06-22 07:06:53.715788
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    HlsFD_test = HlsFD({})

    # Test not encrypted stream
    not_encrypted_manifest = """
    #EXTM3U
    #EXT-X-TARGETDURATION:10
    #EXTINF:10,
    http://media.example.com/first.ts
    #EXTINF:10,
    http://media.example.com/second.ts
    #EXTINF:10,
    http://media.example.com/third.ts
    #EXT-X-ENDLIST
    """
    assert HlsFD_test.can_download(not_encrypted_manifest, {})

    # Test encrypted stream with unsupported encryption

# Generated at 2022-06-22 07:06:55.688097
# Unit test for constructor of class HlsFD
def test_HlsFD():
    "Test class HlsFD"

    # HlsFD(ydl, params)
    assert True

# Generated at 2022-06-22 07:07:33.618126
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    def _get_info_dict(url):
        return {
            'url': url,
            'protocol': 'hls_native',
            'ext': 'mp4',
            'format_id': 'high',
            'http_headers': {
                'Referer': 'https://www.youtube.com/watch?v=Zu-LHcpEoK8',
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0',
            },
            '_decryption_key_url': 'https://s.ytimg.com/yts/key/main.mp4.enc',
            'is_live': False,
            'filesize': 520091,
        }

    # Test downloading

# Generated at 2022-06-22 07:07:41.837248
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import get_info_extractor

    class MockYtdl(object):
        def __init__(self, params):
            self.params = params

        def urlopen(self, url):
            url_s = url.get_full_url()
            if url_s.endswith('key_url'):
                return MockYtdlFile('iv0iv1iv2iv3iv4iv5iv6iv7iv8iv9iv10iv11iv12iv13iv14iv15', 'key_url')
            elif url_s.endswith('key'):
                return MockYtdlFile('key', 'key')
            elif url_s.endswith('fragment'):
                return MockYtdlFile('fragment', 'fragment')

# Generated at 2022-06-22 07:07:54.732837
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import tempfile
    import json
    import shutil
    import unittest

    class HlsFD_can_download(unittest.TestCase):
        def setUp(self):
            import youtube_dl.extractor.common
            self.test_dir = tempfile.mkdtemp()
            self.downloader = youtube_dl.extractor.common.FakeYDL({
                'logger': youtube_dl.extractor.common.FakeLogger(),
                'cachedir': False,
                'noprogress': True,
            })
            self.HlsFD = HlsFD(self.downloader, {'noprogress': True})
            self.manifests_dir = os.path.join(self.test_dir, 'manifests')

# Generated at 2022-06-22 07:08:05.722308
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    from ..extractor.youtube import YoutubeIE
    from ..utils import _download_json

    # Check if HlsFD can be initialized
    ie = YoutubeIE()
    url = 'https://www.youtube.com/watch?v=9pEhzD26y4A'  # A DASH-only youtube video
    info = _download_json(
        ie._request_webpage(url, None), url,
        ie.video_id(url) + '_info')
    assert HlsFD.can_download(info['formats'][-1]['manifest_url'], info['formats'][-1])
    fd = HlsFD(ie.ydl, {'skip_download': True})

# Generated at 2022-06-22 07:08:17.039228
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """
    This test method can be invoked by
    `python -m youtube_dl.downloader.hls -- HlsFD_real_download`
    """
    from .http import HttpFD
    from ..utils import prepend_extension, remove_filename_parameter

    from .external import FFmpegFD
    from .fragment import FileFragmentFD
    from .common import FileDownloader

    import os
    import shutil
    import tempfile

    # Create a directory to store downloaded files
    test_dir = tempfile.mkdtemp()
    # Downloader is a subclass of FileDownloader
    # Info dict is used to construct the downloader

# Generated at 2022-06-22 07:08:25.400178
# Unit test for constructor of class HlsFD
def test_HlsFD():
    manifest_url = "http://www.staff.science.uu.nl/~gent0113/youtube/hls/redbulltv/index.m3u8?__gda__=1479609824_f25c1ae2d6163edf898b9dcc9d33e2fd"
    ydl = YoutubeDL({})
    hfd = HlsFD(ydl, {})
    assert hfd.can_download(ydl.urlopen(manifest_url).read().decode('utf-8'), {})

# Generated at 2022-06-22 07:08:35.237476
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:08:36.712374
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, {}, None)

# Generated at 2022-06-22 07:08:49.332216
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():

    # creates a test class with methods of HlsFD as attributes
    class HlsFD_for_testing(HlsFD):
        pass

    HlsFD_for_testing_object = HlsFD_for_testing()

    # test case: video with no encrypted segments and the video is not live

# Generated at 2022-06-22 07:08:59.444431
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest
    class HlsFDTestCase(unittest.TestCase):
        def test_HlsFD_can_download(self):
            import youtube_dl
            from collections import namedtuple
            info_dict = namedtuple('InfoDict', [])
            # ie_name = 'hls'
            # info_dict.ie_key = ie_name
            # info_dict.is_live = False
            # info_dict.url = ...
            # info_dict.extra_param_to_segment_url = ''
            # info_dict._decryption_key_url = ''

# Generated at 2022-06-22 07:10:07.716843
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .fragment import parse_fragment_base_url
    from .http import HttpFD
    from ..extractor import gen_extractors
    for ie in gen_extractors():
        if ie.suitable(ie.ie_key()) and ie.ie_key() != 'hlsnative':
            continue


# Generated at 2022-06-22 07:10:19.186334
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class YDL_Fake:
        def urlopen(self, url):
            urlh = compat_urllib_request.urlopen(url)
            urlh.geturl = lambda: url
            return urlh
    ydl = YDL_Fake()
    params = {'test': True, 'ignoreerrors': True, 'quiet': True, 'nooverwrites': True, 'format': 'best', 'encoding': 'utf-8'}
    fd = HlsFD(ydl, params)

    # Not encrypted

# Generated at 2022-06-22 07:10:30.302832
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import pytest
    from ..extractor.youtube import YoutubeIE
    from ..compat import compat_str
    from ..utils import std_headers
    from ..extractor import gen_extractors
    from .common import FakeYDL

    def check_can_download(ydl, manifest_url, manifest, info_dict):
        youtube_info_dict = {
            'url': manifest_url,
            'http_headers': std_headers,
            'http_chunk_size': 10485760,
            'player_url': None,
            '_type': 'url',
            'extractor': YoutubeIE.ie_key(),
            'webpage_url': manifest_url,
            'playlist_id': None,
        }
        youtube_info_dict.update(info_dict)

# Generated at 2022-06-22 07:10:33.778236
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL(params={'usenetrc':False})
    fd = HlsFD(ydl,'https://example.com/hls.m3u8')
    assert fd.ydl is ydl


# Generated at 2022-06-22 07:10:45.599405
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..utils import encode_data_uri

# Generated at 2022-06-22 07:10:55.106532
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:11:06.304176
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..test.test_downloader import get_testcases, get_result

    # The test YouTube videos are:
    videos = [
        'https://www.youtube.com/watch?v=XBW6L2jhQZo',  # 35s dash video
        'https://www.youtube.com/watch?v=XBW6L2jhQZo&live_event=livenow',  # live dash video
    ]
    for video in videos:
        info_dict = get_testcases(
            video,
            download=False,
            process=False,
            extra_params=[],
            formats=['hlsnative', 'hls'])
        assert HlsFD.can_download(get_result(video, info_dict, 'url'), info_dict) is True

# Generated at 2022-06-22 07:11:17.723120
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """Function to unit test execution of constructor of class HlsFD"""

    def _test_error(message = 'hlsnative has detected features it does not support, extraction will be delegated to ffmpeg'):
        assert message in str(err.value)

    # Test case with unsupported file

# Generated at 2022-06-22 07:11:28.955462
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hlsfd = HlsFD()
    assert hlsfd.FD_NAME == 'hlsnative'
    assert hlsfd.can_download('', {'is_live': True}) == False
    assert hlsfd.can_download('#EXT-X-KEY:METHOD=NONE', {'is_live': True}) == True
    assert hlsfd.can_download('#EXT-X-KEY:METHOD=AES-128', {'is_live': True}) == False
    assert hlsfd.can_download('#EXT-X-KEY:METHOD=AES-128', {'is_live': True, '_decryption_key_url': None}) == False
    assert hlsfd.can_download('#EXT-X-KEY:METHOD=NONE', {'is_live': True}) == True
    assert hls

# Generated at 2022-06-22 07:11:39.393726
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .tests.test_downloader import MockYDL
    ydl = MockYDL()
    ydl.params.update({
        'noprogress': True,
        'dump_single_json': True,
    })
    info_dict = {
        'id': 'foo',
        'url': 'https://example.com/index.m3u8',
        'ext': 'm3u8',
    }