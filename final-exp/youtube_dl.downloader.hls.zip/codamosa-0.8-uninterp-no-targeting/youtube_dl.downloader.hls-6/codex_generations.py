

# Generated at 2022-06-22 07:03:30.836022
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data, get_test_file
    from .extractor.common import InfoExtractor
    from ..utils import encode_data_uri

    url = 'hlsnative://http%3A%2F%2Ffoo.bar%2Fmaster.m3u8'
    path = get_test_file('test.mp4')
    ie = InfoExtractor('hlsnative:%s' % url, {
        'ytdl_from_url': encode_data_uri(get_test_data(path, 'test.mp4'), 'video/mp4'),
        'http_headers': {
            'Accept': 'application/vnd.apple.mpegurl, application/x-mpegurl',
        },
    })

# Generated at 2022-06-22 07:03:39.308786
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.youtube import YoutubeIE
    youtube = YoutubeIE({})
    info_dict = youtube._real_extract('PLBB2350F17B1EB27F')
    info_dict['http_headers'] = {'X-Forwarded-For': '74.125.224.72'}
    HlsFD({}, info_dict)
    HlsFD({'skip_unavailable_fragments': True}, info_dict)

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-22 07:03:45.566143
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # hlsnative can download
    info_dict = {'url': 'https://foo/bar/baz.m3u8'}

# Generated at 2022-06-22 07:03:57.260539
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import os.path
    import random
    import shutil
    import tempfile
    from .http import HttpFD
    from .http import HttpQuietDownloader

    HLS_MANIFEST_TEMPLATE = """#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:5
#EXT-X-MEDIA-SEQUENCE:0
%s
#EXT-X-ENDLIST
"""

    HLS_SEGMENT_TEMPLATE = '#EXTINF:5,\n%s'

    TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
    CHUNKS_DIR = os.path.join(TESTS_DIR, 'hlschunks')


# Generated at 2022-06-22 07:04:01.863373
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors

    exts = gen_extractors()
    for ext in exts:
        if ext.IE_NAME in ['hlsnative', 'hls']:
            url = ext.working_ie.VALID_URL
            hlsfd = HlsFD(None, {}, {})
            assert hlsfd.can_download(url, {})

# Generated at 2022-06-22 07:04:13.306822
# Unit test for constructor of class HlsFD

# Generated at 2022-06-22 07:04:18.139140
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    def fake_urlopen(ctx, url, info_dict, headers=None):
        if url.startswith('http://127.0.0.1:12345'):
            return (True, b'#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-MEDIA-SEQUENCE:5\n#EXT-X-TARGETDURATION:8\n#EXTINF:6.004000,{}\nhttp://127.0.0.1:12345/b801346c46e3e41ea9d9fcff88e2c837_0.ts?id=xxx\n#EXT-X-KEY:METHOD=AES-128,URI="https://key.com/key.key"\n#EXT-X-ENDLIST\n'.format(ctx['ident']))


# Generated at 2022-06-22 07:04:30.260963
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.http import HlsFD
    can_download_ = HlsFD.can_download
    # To add a new test create a list with the first item being
    # the test to be run as a string and the second item as a
    # dictionary with keys being pattern and value being the result

# Generated at 2022-06-22 07:04:34.284392
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # No input is provided hence an error is expected
    assert HlsFD.real_download("", "") == False

# Test for method can_download of class HlsFD

# Generated at 2022-06-22 07:04:45.936606
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import re
    import pytest

    def _test_can_download(method, test_name, method_ref, result_ref, **kwargs):
        result = method(**kwargs)
        if result_ref != result:
            print("\n{}: {}({})\nExpected: {}\nReturned: {}\n".format(method.__name__, test_name, str(kwargs), str(result_ref), str(result)))
        return method_ref(result) == result_ref

    def _test_ev_lives_mismatch(method, test_name, method_ref, result_ref, **kwargs):
        live_component = '#EXT-X-PLAYLIST-TYPE:EVENT'
        result = method(**kwargs)

# Generated at 2022-06-22 07:05:11.156920
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from . import FFmpegFD
    from ..downloader import YoutubeDL
    assert YoutubeDL.urlopen('https://google.com/')
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=NONE', {'is_live': True})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=SAMPLE', {})
    assert not HlsFD.can_download('#EXT-X-PLAYLIST-TYPE:EVENT', {})
    assert not HlsFD.can_download('#EXT-X-MAP:', {})
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=NONE', {})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=SAMPLE', {})
    assert HlsFD.can_

# Generated at 2022-06-22 07:05:21.135052
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    root_dir = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
    test_files_dir = os.path.join(root_dir, 'test', 'test_files')

    # vod file with multi bitrate
    path = os.path.join(test_files_dir, 'hls_vod.m3u8')
    with open(path, 'rb') as test_file:
        Manifest = test_file.read().decode('utf-8', 'ignore')
    assert HlsFD.can_download(Manifest, {'url':'http://www.test.com/test.m3u8'})

    # live file

# Generated at 2022-06-22 07:05:30.774938
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .external import FFmpegFD
    from .hls import HlsFD

    # examples of unsupported m3u8 files and expected result

# Generated at 2022-06-22 07:05:32.437723
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(object, dict())

# Generated at 2022-06-22 07:05:44.912694
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import download_with_ytdl
    from ..extractor.youtube import YoutubeIE
    # Check that when can_download returns False, HlsFD is not used
    info_dict = download_with_ytdl(YoutubeIE().ie_key(), {
        'url': 'https://www.youtube.com/watch?v=Yh-7LgplumM',
        'force_generic_extractor': True,
    })
    assert info_dict['extractor'] == 'generic' and info_dict['protocol'] == 'm3u8'
    HlsFD.can_download(info_dict['manifest_url'], info_dict)

    # Check that when can_download returns True, HlsFD is used

# Generated at 2022-06-22 07:05:56.944467
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    from .test_downloads import test_download
    from .test_http_server import HttpServerTestCase
    from .test_m3u8 import test_m3u8_data
    # Block the real download method from HlsFD class so that we can test the real_download method.

    def raise_NotImplementedError(*args, **kwargs):
        raise NotImplementedError('This method has not been implemented.')
    HlsFD.real_download = raise_NotImplementedError
    HlsFD.add_extra_info = raise_NotImplementedError

    def _download(url, params, options):
        test_download(url, params, options)

    class TestHlsFD(HttpServerTestCase):
        def runTest(self):
            test_data = test_m3

# Generated at 2022-06-22 07:06:03.338801
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..utils import sanitize_open

    for name, ie in gen_extractors(['http://hls-vod.daserste.de/i/videoportal/Film/c_620000/622873/format,716451,716457,716450,716458,716459,.mp4.csmil/index_4_av.m3u8']):
        with sanitize_open(ie.downloader.cache.load('request', name)) as f:
            hls_fd = HlsFD(ie.downloader, {'test': True}, ie, name)
            hls_fd.read = f.read

# Generated at 2022-06-22 07:06:16.034650
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import pytest

    # Python 2.6 compatibility
    if not hasattr(pytest, 'raises'):
        pytest.raises = pytest.assert_raises

    hls_fd = HlsFD({})

# Generated at 2022-06-22 07:06:28.275801
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert hasattr(HlsFD, "can_download")
    assert not any(HlsFD.can_download(None, {'url': ""}))
    assert HlsFD.can_download(
        "foo\n#EXT-X-PLAYLIST-TYPE:EVENT\nbar\n",
        {'url': ""})
    assert not any(HlsFD.can_download(
        "foo\n#EXT-X-PLAYLIST-TYPE:EVENT\nbar\n",
        {'url': "", 'is_live': True}))
    assert not any(HlsFD.can_download(
        "foo\n#EXT-X-KEY:METHOD=NONE\nbar\n",
        {'url': ""}))

# Generated at 2022-06-22 07:06:38.324284
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class InfoDictMock:
        def __init__(self, is_live):
            self._info_dict = { 'is_live': is_live }

        def __getitem__(self, key):
            return self._info_dict[key]

        def get(self, key, default=None):
            return self._info_dict.get(key, default)

    class YDLMock:
        def __init__(self):
            self._match_idx = 0
            self._match_list = [ None, None, None, None, None ]

        def urlopen(self, url):
            content = None

# Generated at 2022-06-22 07:07:15.008405
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os.path

    import pytest

    from ..compat import compat_urllib_request
    from ..utils import make_HTTPServer

    from .fragment import _test_exec
    from .external import test_FFmpegFD_real_download

    from .test_external import get_testcases

    def testcase(test_case, *args):
        info_dict = {
            'id': 'test',
            'ext': 'mp4',
            'title': 'test',
            'url': test_case[0],
            'format': 'http_dash_segments',
            'http_template': 'http://localhost:%d/%s',
        }
        TESTSERVER_PORT = 8888

# Generated at 2022-06-22 07:07:27.455018
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os.path
    import tempfile

    initial_dir = os.getcwd()
    download_path = os.path.join(tempfile.mkdtemp(), 'test.mp4')
    os.chdir(tempfile.mkdtemp())

# Generated at 2022-06-22 07:07:38.337718
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .extractor import gen_extractors

# Generated at 2022-06-22 07:07:51.060378
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .test_utils import FakeYDL
    import os.path
    from .extractor.generic import get_entry_info


# Generated at 2022-06-22 07:08:00.974393
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ....compat import (
        compat_HTTPError,
        compat_str,
        compat_urllib_request,
    )
    from .test_utils import FakeYDL

    class MockRequest(object):
        def __init__(self, url_map):
            self.url_map = url_map

        def open(self, req):
            url = req.get_full_url()
            if url not in self.url_map:
                raise compat_HTTPError(url, 404, 'not found', {}, None)
            return compat_urllib_request.urlopen(req)

    ydl = FakeYDL()

    class FakeOpener:
        def __init__(self, url_map):
            self.url_map = url_map


# Generated at 2022-06-22 07:08:13.116045
# Unit test for constructor of class HlsFD
def test_HlsFD():

    # Test to try to instantiate a HlsFD object
    ydl = YoutubeDL({})
    hlsfd1 = HlsFD(ydl, {'fragment_retries': 2})
    assert isinstance(hlsfd1, HlsFD)

    # Test to confirm that constructor of HlsFD raises an exception if
    # no YoutubeDL object is passed
    try:
        hlsfd2 = HlsFD({}, {'fragment_retries': 2})
    except:
        hlsfd2 = None
    assert hlsfd2 is None

    # Test to confirm that constructor of HlsFD raises an exception if
    # no params object is passed
    try:
        hlsfd3 = HlsFD(ydl, None)
    except:
        hlsfd3 = None

# Generated at 2022-06-22 07:08:24.851878
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import re
    import tempfile

    from .utils import iso639_to_eng

    from ..compat import (
        compat_urllib_error,
        compat_urlparse,
    )

    from ..extractor import YoutubeIE
    from ..extractor.common import InfoExtractor
    from ..downloader.common import FileDownloader
    from ..compat import (
        compat_urllib_parse_urlparse,
    )
    from ..utils import (
        encodeFilename,
        prepend_extension,
        remove_end,
    )
    IE_NAME = 'Youtube'

# Generated at 2022-06-22 07:08:35.016744
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import io
    from .http_test import MockUrlopen


# Generated at 2022-06-22 07:08:47.876793
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    class DummyYdl(object):
        def __init__(self):
            self.http_headers = {}

        def urlopen(self, req_url):
            class DummyUrlHandle:
                def read(self):
                    return '''
                        #EXTM3U
                        #EXT-X-KEY:METHOD=AES-128,URI="https://priv.example.com/key.php?r=52"
                        #EXTINF:2.833,
                        http://media.example.com/first.ts
                        #EXTINF:15.0,
                        http://media.example.com/second.ts?custom=whatever
                        #EXT-X-ENDLIST
                    '''.encode('utf-8')
            return DummyUrlHandle()


# Generated at 2022-06-22 07:08:58.114867
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class _ytdl_mock:
        def __init__(self, urlopen_return):
            self.urlopen_return = urlopen_return
        def urlopen(self, url):
            return self.urlopen_return

    class _info_dict_mock:
        is_live = False

    class _params_mock:
        fragment_retries = 0
        skip_unavailable_fragments = True
        test = False

    class _HlsFD(_HlsFD_mock):
        def __init__(self, params):
            self.params = params
        def real_download(self, filename, info_dict):
            return True

    # Test that #EXT-X-KEY:METHOD=AES-128 causes an error if pycrypto not installed
    _ytdl = _ytdl_

# Generated at 2022-06-22 07:09:57.420420
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DownloadError
    from . import FakeYDL

    # Test not existent manifest
    info_dict = {
        'url': 'not existent',
        'num_fragments': 1,
        '_duration': 1.0,
        'is_live': False,
    }

    # Test with not supported features
    info_dict['url'] = 'https://someserver.com/some.m3u8'
    ydl = FakeYDL()
    ydl.add_info_dict(info_dict, force_generic_extractor=False)
    fd = HlsFD(ydl, {})

# Generated at 2022-06-22 07:10:09.618895
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from io import StringIO
    from .test import test_download_media, get_testcase_data

    m3u8_data = get_testcase_data("hls_fragments.m3u8")
    fragment_data = get_testcase_data("hls_fragment_0.ts")
    man_url = 'http://example.com/test.m3u8'
    fragment_url = 'http://example.com/test_%d.ts'
    info_dict = {
        'id': 'test',
        'url': man_url,
        'title': 'test video',
        'thumbnail': 'http://example.com/thumb.jpg',
        'http_headers': {'Referer': 'http://example.com/'},
    }


# Generated at 2022-06-22 07:10:21.190695
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    fn_video_url = 'http://example.com/video.mp4'
    ydl_params = {'outtmpl': fn_video_url}
    hls_fd = HlsFD(None, ydl_params)
    # test with non-encrypted m3u8 content

# Generated at 2022-06-22 07:10:32.721113
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:10:44.660079
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """
    Test download of an HLS stream containing a single fragment.
    """
    try:
        from unittest import mock
    except ImportError:
        import mock
    from six import BytesIO

    # Create a mock for a test downloader.
    ydl = mock.MagicMock()
    ydl.params = {}
    ydl.urlopen = mock.MagicMock(return_value=BytesIO(b''))
    ydl.report_error = mock.MagicMock()

    # Download an HLS stream containing a single fragment.
    filename = 'test.ts'
    info_dict = {'url': 'http://example.com/index.m3u8'}
    hlsfd = HlsFD(ydl, ydl.params)

# Generated at 2022-06-22 07:10:50.190874
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import io
    import tempfile
    import shutil

    pool = io.BytesIO()

# Generated at 2022-06-22 07:10:59.281096
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..downloader import Downloader
    from ..extractor import YoutubeDL
    from .fragment import FragmentFD
    from .external import FFmpegFD
    # try:
    #     from Crypto.Cipher import AES
    # except ImportError:
    #     can_decrypt_frag = False
    # Assume that a pycrypto is installed
    can_decrypt_frag = True
    ydl = YoutubeDL(params={'simulate': True, 'quiet': True, 'noplaylist': True})
    d = Downloader(ydl)
    url = 'http://url.m3u8'
    mimetype = 'm3u8'
    info = {}
    info['url'] = url
    info['ext'] = mimetype

# Generated at 2022-06-22 07:11:10.326829
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    from ..downloader import YoutubeDL


# Generated at 2022-06-22 07:11:19.485078
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:11:30.742495
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    manifest = (
        '#EXTM3U\n'
        '#EXT-X-KEY:METHOD=AES-128,URI="http://server/key"\n'
        '#EXT-X-TARGETDURATION:10\n'
        '#EXTINF:10,\n'
        'segment.ts\n'
        '#EXTINF:10,\n'
        '#EXT-X-BYTERANGE:522828@0\n'
        'segment.ts\n'
        '#EXT-X-ENDLIST\n'
    )

    assert HlsFD.can_download(manifest, {}) is False


# Generated at 2022-06-22 07:12:57.563227
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """Just instantiate the class to check that everything is ok"""
    HlsFD()

# Generated at 2022-06-22 07:13:03.400342
# Unit test for constructor of class HlsFD
def test_HlsFD():
    response_ = {
        'url': 'https://www.example.com/manifest.m3u8',
        'http_headers': {}
    }
    hlsfd = HlsFD(None, response_)
    return hlsfd.__class__.__name__ == 'HlsFD'