

# Generated at 2022-06-22 07:03:24.594147
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        assert(can_decrypt_frag == False)
    except:
        print("Error: can_decrypt_frag not set to False")
    try:
        assert(FFmpegFD == HlsFD.FD_NAME)
    except:
        print("Error: FD_NAME not set to FFmpegFD")
    try:
        assert(FragmentFD == HlsFD.FD_NAME)
    except:
        print("Error: FD_NAME not set to FragmentFD")
    try:
        assert(AES == HlsFD.FD_NAME)
    except:
        print("Error: FD_NAME not set to AES")

# Generated at 2022-06-22 07:03:31.109382
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Test method real_download of class HlsFD
    def test_real_download(url, result):
        info_dict = {
            'url': url,
            '_decryption_key_url': 'http://localhost/key',
        }
        ydl = YDL()
        ydl.params = {
            'test': True,
        }
        hls_fd = HlsFD(ydl, ydl.params)
        assert hls_fd.real_download('test.ts', info_dict) == result

    # Test AES-128 encrypted stream
    test_real_download(
        'https://sample-videos.com/encrypted-stream/hls/master.m3u8',
        True)

    # Test HTTP 302 redirect for last fragment

# Generated at 2022-06-22 07:03:36.741136
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ydl = FakeYDL()
    ydl.params = {}
    ydl.params['test'] = True
    ydl.params['fixup'] = 'detect_or_warn'
    hls_fd = HlsFD(ydl, ydl.params)
    assert hls_fd


# Generated at 2022-06-22 07:03:38.576933
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # TODO: write test
    pass

# Generated at 2022-06-22 07:03:45.132023
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    from .test_downloads import (
        DownloaderForTestWithEncryptedContent,
        DownloaderForTest
    )

    class HlsFDTest(unittest.TestCase):
        def test_hlsnative_download_with_preprocessing_finished_stream(self):
            """ Test hlsnative download with pre-processing for a finished Twitch stream"""
            dl = DownloaderForTestWithEncryptedContent(params={'outtmpl': '%(id)s.%(ext)s'})

# Generated at 2022-06-22 07:03:45.730829
# Unit test for constructor of class HlsFD
def test_HlsFD():
    return HlsFD

# Generated at 2022-06-22 07:03:57.634668
# Unit test for constructor of class HlsFD
def test_HlsFD():
    filename = 'index.mp4'

# Generated at 2022-06-22 07:04:07.200855
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import test
    import os
    import sys
    import copy

    class MockYDL():
        def __init__(self):
            self.params = {}
            self.cache = {}
            self.pm = test.MockPlayerManager()

        def urlopen(self, url):
            urlh = test.MockUrlOpen()
            urlh.url = url
            urlh.info = {'content-type': 'application/x-mpegURL'}
            urlh.read = lambda: b''
            return urlh

        def to_screen(self, str):
            pass

        def report_error(self, str):
            pass

        def report_warning(self, str):
            pass

        def to_stderr(self, message):
            pass


# Generated at 2022-06-22 07:04:20.032453
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..utils import http_head
    import os.path
    import tempfile

    header = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36'}
    info_dict = {'url': 'https://v.cdn.vine.co/r/videos/AA3C120C521177175800441692160_38f2cbd1ffb.1.5.13763579289575020226.mp4?versionId=hbXDP_r8tvw.KUQeXvuIBoNGK8SQ5iSv', 'http_headers': header}

    #

# Generated at 2022-06-22 07:04:31.557906
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def parse_manifest(manifest):
        return re.findall(r'^#EXT-X-KEY:METHOD=(\w+)', manifest, re.MULTILINE)
    # Tests that hlsnative can download pcm_s8e streams
    # https://github.com/ytdl-org/youtube-dl/pull/28540
    assert HlsFD.can_download('#EXT-X-PLAYLIST-TYPE:VOD\n', {})
    assert HlsFD.can_download('#EXT-X-PLAYLIST-TYPE:VOD\n#EXT-X-KEY:METHOD=NONE\n', {})

# Generated at 2022-06-22 07:04:58.854658
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download(
        "",
        {"url": ""}
    )
    assert not HlsFD.can_download(
        "#EXT-X-VERSION:2",
        {"url": ""}
    )
    assert not HlsFD.can_download(
        "#EXT-X-VERSION:1\n#EXT-X-KEY:METHOD=AES-128",
        {"url": ""}
    )
    assert not HlsFD.can_download(
        "#EXT-X-VERSION:1\n#EXT-X-KEY:METHOD=AES-128\n"
        "#EXT-X-BYTERANGE:8911@0\n#EXT-X-BYTERANGE:819@8911\n",
        {"url": ""}
    )

# Generated at 2022-06-22 07:05:10.191200
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import json


# Generated at 2022-06-22 07:05:21.986755
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    url = 'http://localhost/index.m3u8'
    playlist = '''
#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:25
#EXT-X-MEDIA-SEQUENCE:0
#EXTINF:20.000000,
segment-1.ts
#EXTINF:20.000000,
segment-2.ts
#EXTINF:20.000000,
segment-3.ts
#EXT-X-ENDLIST
'''
    ie = InfoExtractor({'url': url, 'playlistend': 3})
    ie.add_info_extractor(HlsFD)
    ydl = ie._ydl
    ydl.params['hls_use_mpegts'] = True


# Generated at 2022-06-22 07:05:32.984237
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Test data
    manifest = """#EXTM3U
#EXT-X-VERSION:3
#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=69111
720p/chunklist_w1543037485.m3u8
#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=348287
1080p/chunklist_w1543037485.m3u8
#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=65455
480p/chunklist_w1543037485.m3u8
"""

# Generated at 2022-06-22 07:05:45.500534
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import tempfile
    import subprocess
    import test_suites.test_fragments
    from .fragment import FragmentFD
    from .ffmpeg import FFmpegFD
    import youtube_dl

    class HlsFD_Test(HlsFD):
        def __init__(self, params, **kwargs):
            self.ydl = kwargs['ytdl']
            self.params = params

        def _prepare_url(self, info_dict, url):
            return self.ydl._prepare_url(url)

    def _download_fragment(self, ctx, frag_url, info_dict, headers):
        return self.ydl._download_fragment(ctx, frag_url, info_dict, headers)


# Generated at 2022-06-22 07:05:52.743760
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """
    Constructor for the HlsFD class.
    """
    from .extractor import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['nooverwrites'] = True
    ydl.process_ie_result(
        {'id': 'test', 'url': 'http://example.org/test.m3u8', 'extractor': 'test'},
        download=False)


# Generated at 2022-06-22 07:06:04.398820
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..downloader import YoutubeDL
    from .dashsegments import prepare_url
    from .dashmanifest import DashManifestFD
    from .fragment import FragmentFD
    from .external import FFmpegFD
    from .http import HttpFD
    import os
    import shutil
    import tempfile

    ydl = YoutubeDL({})

    # Create a m3u8 and a directory to download the segments
    fd, m3u8_filename = tempfile.mkstemp()
    os.close(fd)
    dir, dirname = tempfile.mkdtemp()

    # Prepare a fragment, by downloading a 2 seconds mp4 fragment
    url = 'https://dash.akamaized.net/akamai/bbb_30fps/bbb_30fps.mp4'

# Generated at 2022-06-22 07:06:12.218090
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    ie = InfoExtractor(YoutubeIE.ie_key(), YoutubeIE.working_webpage('https://www.youtube.com/watch?v=aSaPJDI-POM', 'test'))
    info_dict = ie._real_extract(ie._WORKING_URL)
    t_fd = HlsFD(ie.ydl, ie.params)
    assert t_fd.can_download(info_dict['_type']) == True

# Generated at 2022-06-22 07:06:24.696756
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..utils import make_HTTPServer
    from ..extractor import gen_extractors
    httpd = None

    def setup_module():
        global httpd
        server_address = ('127.0.0.1', 0)
        httpd = make_HTTPServer(server_address)

# Generated at 2022-06-22 07:06:35.880150
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import json
    import tempfile
    import hashlib
    import shutil
    from .test import get_testdata_files_dir
    from ..utils import encodeFilename

    def _test_HlsFD_real_download(m3u8_file, md5_sum):
        tmp_dir = tempfile.mkdtemp(prefix='youtubedl-test-HlsFD_real_download-tmp-')

# Generated at 2022-06-22 07:07:14.500047
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest
    import youtube_dl.extractor.common as common
    class TestHlsFd(common.Extractor):
        def __init__(self, *args, **kwargs):
            self.manifest_url = ''
            self.params = {
                'http_headers': {},
                'prefer_ffmpeg': False,
                'test': True,
            }
        def get_info(self, url):
            info_dict = {
                'url': url,
                'is_live': False,
                'extra_param_to_segment_url': '',
                '_decryption_key_url': '',
            }
            return info_dict

# Generated at 2022-06-22 07:07:27.521953
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from .test import get_test_infolist

    import sys
    import os
    import tempfile
    import functools

    def test_downloader(ydl, params, filename, manifest, method, fragment_index, info_dict, expected_results):
        @functools.wraps(method)
        def side_effect(self, filename, info_dict):
            return method(self, filename, info_dict)

        ydl.report_warning = functools.partial(ydl.report_warning, expected_results['warnings'])
        ydl.report_error = functools.partial(ydl.report_error, expected_results['errors'])

# Generated at 2022-06-22 07:07:38.414280
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """Unit test for method real_download of class HlsFD"""

    import os
    import sys
    import tempfile

    from .extractor.common import InfoExtractor
    from .compat import (
        compat_urllib_error,
        compat_urllib_parse_urlparse,
        compat_urlparse,
    )
    from .downloader.http import HttpFD
    from .downloader.common import FileDownloader

    # Get the class we want to test.
    # This also handles importing and setup
    fd_name = 'hlsnative'
    if fd_name not in FileDownloader.meta_fd_names:
        FileDownloader.meta_setup()
    FDClass = FileDownloader.meta_fd_names[fd_name]
    assert issubclass(FDClass, HlsFD)

# Generated at 2022-06-22 07:07:45.622846
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    try:
        from Crypto.Cipher import AES
    except ImportError:
        pytest.skip('pycrypto not found. Please install it.')
    from .test_fragments import TestFD
    url = 'http://media.w3.org/2010/05/sintel/trailer.m3u8'
    tfd = TestFD(HlsFD())
    tfd.real_download(url)
    # Test live stream (see https://github.com/ytdl-org/youtube-dl/issues/10807)

# Generated at 2022-06-22 07:07:52.084109
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:08:01.420478
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:08:03.753608
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('', {'url': '', 'is_live': False})


# Unit tests for constructor of class HlsFD

# Generated at 2022-06-22 07:08:16.084567
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:08:27.394519
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import FakeYDL
    from .external import FFmpegFD
    from .utils import devnull_fd
    from test_fragment import FakeProcessor
    import tempfile
    import os
    import shutil
    import youtube_dl.downloader.hls

    test_dir = tempfile.mkdtemp(prefix='youtube-dl-test-')
    ext_dir = os.path.dirname(__file__)

# Generated at 2022-06-22 07:08:36.248977
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import unittest
    import sys

    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common as common
    from youtube_dl.downloader.fragment import FragmentFD
    from youtube_dl.extractor import HlsFD

    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    # Suppress stderr for unit tests
    sys.stderr = sys.stdout

    plugins = youtube_dl.YoutubeDL(
        {'nopart': True, 'logger': common.FakeLogger(), 'restrictfilenames': True,
         'simulate': True, 'quiet': True})._get_available_extractors()

    class MockExtractor(object):
        IE_

# Generated at 2022-06-22 07:09:46.235735
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download(
        '#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXT-X-VERSION:3\n#EXT-X-MEDIA-SEQUENCE:0', {})
    assert HlsFD.can_download(
        '#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXT-X-VERSION:3\n'
        '#EXT-X-MEDIA-SEQUENCE:0\n#EXT-X-PLAYLIST-TYPE:VOD', {})

# Generated at 2022-06-22 07:09:58.931464
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .extractor import gen_extractors
    from ..utils import _VIEW_COUNT_RE
    class YDummy(object):

        def __init__(self):
            self.extractors = gen_extractors()
            self.cache = {}
            self.params = {}

    ydl = YDummy()

    class DummyIE(object):

        def __init__(self, manifest, info_dict):
            self.manifest = manifest
            self.info_dict = info_dict

        def get_real_downloader(self, ydl):
            return HlsFD(ydl, self.info_dict)

    # Test can_download on all playable formats

# Generated at 2022-06-22 07:10:10.989600
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import FakeYDL
    from ..extractor.common import InfoExtractor
    from ..compat import str_or_none
    fragment_url = 'http://fragment_data_url'
    fragment_data = b'http://fragment_data_url'
    dec_key_url = 'http://dec_key_url'
    dec_key = b'http://dec_key_url'
    decrypt_method = {'URI': dec_key_url, 'METHOD': 'AES-128', 'IV': '0x00000000000000000000000000000001'}

# Generated at 2022-06-22 07:10:18.744924
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:10:30.180902
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .http import HttpFD
    from .http import UrlFD
    from ..utils import parse_filesize
    from ..extractor.hls import HlsIE
    from ..extractor.hls import HlsNativeIE
    from ..extractor.generic import GenericIE
    from ..extractor.youtube import YoutubeIE
    from ..extractor import SearchInfoExtractor

    # create fake downloader
    ydl = YoutubeIE(params={'simulate': True})
    class FakeDownloader(object):
        params = {}
        params['noprogress'] = True
        params['quiet'] = True
        params['logger'] = ydl

    ydl.downloader = FakeDownloader()
    ydl.report_warning = lambda msg: None
    ydl.report_error = lambda msg, video_id: None
    ydl

# Generated at 2022-06-22 07:10:39.044378
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest

    from . import FakeYDL
    from .test_downloader import BaseTestDownloader

    class TestHlsFD(BaseTestDownloader):
        def test_playlist_with_key(self):
            def _test_playlist_with_key(key, uri, key_uri, iv, ad_fragments, expected_fragments, expected_key_downloads):
                info_dict = {
                    'url': 'http://test.com/test.m3u8',
                    'http_headers': {},
                    'is_live': False,
                    '_decryption_key_url': uri,
                    'extra_param_to_segment_url': '',
                }

# Generated at 2022-06-22 07:10:50.930271
# Unit test for constructor of class HlsFD
def test_HlsFD():
    url = 'http://example.com/m3u8'
    params = {'test': True, 'outtmpl': 'test.ts'}
    ydl = {'urlopen': lambda url: None, 'params': params}
    hlsfd = HlsFD(ydl, params)
    assert(hlsfd._prepare_url({}, url) == url)
    assert(hlsfd._prepare_url({'http_headers': {'User-Agent': 'test'}}, url) == url)
    assert(hlsfd._prepare_url({'http_headers': {'User-Agent': 'test'},
                               'http_proxy': 'proxy'}, url) == url)

    params = {'test': True, 'outtmpl': 'test.ts', 'http_proxy': 'proxy'}


# Generated at 2022-06-22 07:11:01.457166
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .downloader import FakeYDL
    from .extractor import gen_extractors
    from .__main__ import parseOpts
    from .utils import fake_urlopen

    opts = {
        'usenetrc': '',
        'password': '',
        'username': '',
        'ap_mso': '',
        'ap_username': '',
        'ap_password': '',
        'usenetrc': '',
        'quiet': True,
        'simulate': True,
        'skip_download': True,
        'format': 'bestvideo+bestaudio',
        'outtmpl': '%(id)s.%(ext)s',
        'noplaylist': True,
        'prefer_free_formats': True,
    }
    args = parseOpts

# Generated at 2022-06-22 07:11:02.373599
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass  # TODO

# Generated at 2022-06-22 07:11:13.687111
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    #TODO Add some more cases
    manifest = """
#EXTM3U
#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=200000
http://example.com/stream.m3u8
    """
    info_dict = {'url': 'http://example.com/stream.m3u8'}
    assert HlsFD.can_download(manifest, info_dict) == True
    manifest2 = """
#EXTM3U
#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=200000
http://example.com/stream.m3u8
#EXT-X-PLAYLIST-TYPE:VOD
    """
    assert HlsFD.can_download(manifest2, info_dict) == True
   