

# Generated at 2022-06-22 07:03:30.477100
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    import json
    import subprocess
    import random

    import pytest

    from ..downloader import YoutubeDL
    from ..extractor import gen_extractors

    class HdlDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(HdlDL, self).__init__(*args, **kwargs)
            self._hdl_dl_meta = {}

        def report_warning(self, *args, **kwargs):
            pass

        def report_error(self, *args, **kwargs):
            pass

        def to_screen(self, *args, **kwargs):
            pass

        def to_stderr(self, *args, **kwargs):
            pass


# Generated at 2022-06-22 07:03:41.864078
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    def _test_download_file(m3u8_manifest, expected):
        m3u8_manifest = m3u8_manifest.encode('utf-8')
        expected = expected.encode('utf-8')
        from .test import FakeYDL
        from .extractor.common import InfoExtractor
        from .utils import DEFAULT_OUTTMPL
        info = InfoExtractor({'outtmpl': DEFAULT_OUTTMPL})._real_extract({
            'url': 'http://example.com/test.m3u8',
            'ie_key': 'HlsNative',
        })
        info['url'] = 'http://example.com/test.m3u8'
        info['http_headers'] = {'Referer': 'http://example.com'}

# Generated at 2022-06-22 07:03:54.251999
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    from .testutils import FakeYdl, FakeUrlOpen
    from .extractor.test_hls import test_manifests
    from testutils import dict_contains, dict_diff

    class HlsFd_test(HlsFD):
        def _download_fragment(self, ctx, frag_url, info_dict, headers):
            data = [
                dict_contains({"frag_index": 1, "total_frags": 2, "filename": "whatever"}, ctx),
                frag_url == "https://example.com/segment1",
                dict_contains({"_downloader": "HlsFD"}, info_dict),
                dict_contains({"Range": "bytes=0-49999"}, headers)
            ]

# Generated at 2022-06-22 07:04:03.147104
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-22 07:04:13.987801
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
  from . import YoutubeDL
  youtube_dl = YoutubeDL({'quiet': True})
  manifest = '''
    #EXTM3U
    #EXT-X-PLAYLIST-TYPE:VOD
    #EXT-X-TARGETDURATION:12
    #EXT-X-VERSION:3
    #EXT-X-MEDIA-SEQUENCE:0
    #EXT-X-KEY:METHOD=AES-128,URI="key",IV=0x00000000000000000000000000000000
    #EXTINF:9
    url.ts
    #EXTINF:9
    url.ts
    #EXTINF:9
    url.ts
  '''

# Generated at 2022-06-22 07:04:19.416478
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """
    This test verifies if the HlsFD can be constructed without errors
    """
    HlsFD('test_url')

if __name__ == "__main__":
    test_HlsFD()

# Generated at 2022-06-22 07:04:31.252567
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download(
        '#EXTM3U\n#EXT-X-BYTERANGE:121090@8021\n'
        'main.mp4\n#EXTINF:10,\n#EXT-X-BYTERANGE:14745@2021\n'
        'main.mp4\n#EXTINF:10,\n#EXT-X-BYTERANGE:121090@0\n'
        'main.mp4',
        {'_decryption_key_url': 'https://e1.cdn.cricinfo.com/ci/content/player/',
         'url': 'https://e1.cdn.cricinfo.com/ci/content/player/192968.m3u8'}) is False

# Generated at 2022-06-22 07:04:44.407985
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Test HlsFD.can_download()

    # test can_download() returns False if there is unsupported features in the manifest
    manifest = '#EXT-X-KEY:METHOD=AES-128'
    manifest += '#EXT-X-MEDIA-SEQUENCE:1'
    manifest += '#EXT-X-BYTERANGE:522828@0\n'
    manifest += 'main.mp4'
    info_dict = {
        'url': 'foo',
        'http_headers':None,
        'is_live':False,
        'extra_param_to_segment_url':None,
        '_decryption_key_url':None,
        }
    assert not HlsFD.can_download(manifest, info_dict)

    # test can_download() returns True if there is no unsupported features

# Generated at 2022-06-22 07:04:56.147450
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import encode_compat_str
    from .external import FFmpegFD

    manifest_url = 'https://www.example.com/live/live.m3u8'

# Generated at 2022-06-22 07:05:06.423112
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def can_download_assertion(manifest, is_live, expected_result):
        class MockInfoDict:
            def __init__(self, is_live):
                self.is_live = is_live

        assert HlsFD.can_download(manifest, MockInfoDict(is_live)) == expected_result

    # HLS Native is only supported as long as these conditions are true:
    # * The manifest does not have unsupported features [1]
    # * Pycrypto is found [2]
    # * If manifest is AES-128 encrypted, then it doesn't have the BYTERANGE attribute [3]
    # * Manifest is not live [4]
    def can_download_assertion_supported(manifest, is_live):
        can_download_assertion(manifest, is_live, True)


# Generated at 2022-06-22 07:05:30.383571
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import shutil
    import tempfile
    from .extractor.common import InfoExtractor
    from .downloader.fakedl import FakeYDL
    from .compat import file_str
    from .utils import encode_data_uri

    class IE(InfoExtractor):
        _VALID_URL = r'.*'


# Generated at 2022-06-22 07:05:43.073837
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def urlopen(url):
        _UNSUPPORTED_FEATURES = [
            r'#EXT-X-KEY:METHOD=(?!NONE|AES-128)',
            r'#EXT-X-MEDIA-SEQUENCE:(?!0$)',
            r'#EXT-X-PLAYLIST-TYPE:EVENT',
            r'#EXT-X-MAP:',
        ]
        _SUPPORTED_FEATURES = [
            r'#EXT-X-KEY:METHOD=NONE',
            r'#EXT-X-MEDIA-SEQUENCE:0$',
            r'#EXT-X-PLAYLIST-TYPE:VOD',
        ]

# Generated at 2022-06-22 07:05:49.646646
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    import youtube_dl.extractor.common as ydl_common
    import youtube_dl.utils as ydl_utils
    import sys
    # mock return value of ydl.urlopen
    class ResponseMock:
        def __init__(self, text, url):
            self._text = text
            self._url = url
        def read(self):
            if self._text is None:
                self._text = open(self._url, 'rb').read()
            return self._text
        def info(self):
            return {'Content-Type': 'application/vnd.apple.mpegurl'}
        def geturl(self):
            return self._url
    # mock hls downloader
    class YDL:
        def __init__(self):
            self._urlopen_calls = None


# Generated at 2022-06-22 07:06:00.105683
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()

    class MyHlsFD(HlsFD):
        def __init__(self, params):
            super(MyHlsFD, self).__init__(ydl, {})

        def _download_fragment(self, *args, **kwargs):
            return True, b'MYHLS'

        def _append_fragment(self, ctx, frag):
            assert ctx['filename'] == 'dummy.mp4'
            assert ctx['total_frags'] == 1
            assert ctx['ad_frags'] == 0

            with open(ctx['filename'], 'ab') as f:
                f.write(b'MYHLS')


# Generated at 2022-06-22 07:06:03.693679
# Unit test for constructor of class HlsFD
def test_HlsFD():
    url = 'http://example.org/playlist.m3u8'
    desc = {'url': url}
    hfd_instance = HlsFD(None, None)
    assert hfd_instance.real_download('', desc)

# Generated at 2022-06-22 07:06:05.572635
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD is not None

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-22 07:06:18.488519
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import json
    import random

    from ..downloader import YoutubeDL

    import tests.test_utils

    tests.test_utils.create_test_opts_file()

    ydl = YoutubeDL(params={
        'noprogress': True,
        'outtmpl': '%(id)s.%(ext)s',
        'merge_output_format': 'ts',
        'hls_use_ffmpeg': False,
        'hls_prefer_native': True,
    })

    manifest = ydl.urlopen(
        'https://hls.ted.com/talks/75.m3u8'
    ).read().decode('utf-8')


# Generated at 2022-06-22 07:06:30.490478
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download(): # pylint: disable=missing-docstring
    import sys
    import tempfile
    from io import BytesIO
    import json

    import tstutils

    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common

    def make_YDL(**kwargs):
        kwargs = youtube_dl.extractor.common.merge_dicts(
            {
                'logger': YoutubeDLHandler(),
                'progress_hooks': [],
                'params': {
                    'test': True,  # make sure we only download a single fragment
                    'verbose': True,
                },
            },
            kwargs,
        )
        return youtube_dl.YoutubeDL(kwargs)


# Generated at 2022-06-22 07:06:43.327584
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def _make_manifest(features):
        return '\n'.join('#' + feature for feature in features) + '\n'

    def _assert(features, info_dict, expected_result):
        manifest = _make_manifest(features)
        result = HlsFD.can_download(manifest, info_dict)
        assert result == expected_result, ('got wrong can_download result for manifest "%s" and info_dict "%s"' % (
            manifest, info_dict))

    def _test(features, **info_dict):
        _assert(features, info_dict, True)
        _assert(features + ['EXT-X-KEY:METHOD=AES-128'],
                info_dict, True)

# Generated at 2022-06-22 07:06:53.452076
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    import unittest
    # Note: you may want to run the following command to install libav-tools:
    # pip install --user -U git+https://github.com/ytdl-org/youtube-dl.git@dev/test/requirements/system/libav-tools#egg=libav-tools
    if 'youtube_dl.extractor.test' in sys.modules:
        from ..compat import compat_get_testdata_files_path
        from ...compat import compat_urllib_request, compat_urlparse, compat_http_client
        from ...utils import sanitize_open

        def _mock_urlopen(req):
            assert isinstance(req, compat_urllib_request.Request)

# Generated at 2022-06-22 07:07:10.493714
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Nothing to test
    pass

# Generated at 2022-06-22 07:07:23.306602
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import unittest
    import sys
    import contextlib
    from collections import namedtuple
    from ..utils import FakeYDL
    from io import StringIO
    #from ..compat import compat_http_client
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_str
    from ..compat import compat_urllib_request
    from .fragment import FragmentFD
    from .external import FFmpegFD
    from .fragment import _close_frag_stream
    from .fragment import _open_frag_stream
    #from ..downloader.common import handle_http_error
    from ..extractor import common
    from .external import FFmpegFD
    from .fragment import FragmentFD
    from .hls import HlsFD

# Generated at 2022-06-22 07:07:24.968228
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD({}, {})
    HlsFD({}, {'live': True})

# Generated at 2022-06-22 07:07:36.565136
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    from ..downloader import Downloader
    from ..YoutubeDL import YoutubeDL

    dl = Downloader()
    dl.add_info_extractor(gen_extractors())

    dl.params['hls_use_mpegts'] = True

    dl.params.update({'username': 'foo', 'password': 'bar', 'videopassword': 'foobar'})


# Generated at 2022-06-22 07:07:44.613274
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import os
    import tempfile

    from .fragment import FragmentFD
    from .external import FFmpegFD
    from ..utils import encodeFilename

    def lambda_proceed(filename, *args):
        return filename
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-22 07:07:57.425880
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .external import FFmpegDownloader
    from ..extractor import get_info_extractor
    from ..compat import compat_urllib_request

    # Patch the _prepare_url method of the FFmpegDownloader so that it always
    # returns the url without doing anything
    def _prepare_url(self, info_dict, url):
        return url
    FFmpegDownloader._prepare_url = _prepare_url

    # Patch the _download_fragment method of the HlsFD so that it always
    # returns the fragment content
    def _download_fragment(self, ctx, frag_url, info_dict, headers):
        frag_request = compat_urllib_request.Request(frag_url, headers=headers)

# Generated at 2022-06-22 07:08:01.434225
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .extractor.common import InfoExtractor
    from .common import FakeYDL
    from .extractor.http import HlsIE
    from .socks import SocksProxyConnection
    import sys
    import os
    import time

    proxies = {'http': 'socks5://127.0.0.1:9050', 'https': 'socks5://127.0.0.1:9050'}
    ydl = FakeYDL()
    ydl.add_info_extractor(HlsIE())

    args = ['-v', '--proxy', '127.0.0.1:9050']
    outside_tor = ['--no-proxy', '--no-socks-proxy']


# Generated at 2022-06-22 07:08:13.793604
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # When ytdl detects a hls playlist, it creates an info_dict, url and
    # passes it to fragment downloader(s).

    # ytdl's parser can't parse the byterange info, so we don't have it
    # https://github.com/ytdl-org/youtube-dl/issues/6736
    info_dict = {'url': 'http://example.com/playlist.m3u8', 'is_live': False}

    # not encrypted
    assert HlsFD.can_download('#EXTM3U', info_dict) == True

    # encrypted with aes-128
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', info_dict) == True
    # and has a byterange
    assert H

# Generated at 2022-06-22 07:08:25.499837
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    if sys.version_info < (3, 0):
        sys.exit("Please run under Python 3")
    import os
    import json
    import shutil

    def get_testcases():
        testcases = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'HlsFD_real_download')
        testcases = [f for f in os.listdir(testcases) if f.endswith('json')]
        testcases = [os.path.join(testcases, f) for f in testcases]
        return testcases

    def get_frag_size(filename):
        with open(filename, 'rb') as f:
            frag = f.read()
        return len(frag)


# Generated at 2022-06-22 07:08:26.300181
# Unit test for constructor of class HlsFD
def test_HlsFD():
    return HlsFD

# Generated at 2022-06-22 07:09:01.958478
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    class MockYdl:
        def __init__(self):
            self.http_headers = {'User-Agent': 'Test-Agent'}
        def report_error(self, msg, tb):
            pass
        def report_retry_fragment(self, err, frag_index, count, fragment_retries):
            pass
        def report_skip_fragment(self, frag_index):
            pass

# Generated at 2022-06-22 07:09:03.406573
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    assert HlsFD.real_download(None, None, None)

# Generated at 2022-06-22 07:09:15.625827
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def _assert(manifest, expected, result):
        assert expected == result, 'Expected %s but got %s for manifest %s' % (
            expected, result, manifest)
    is_live = False
    info_dict = {
        # These two fields are not used yet, thus they are set to dummy values
        'extra_param_to_segment_url': '',
        '_decryption_key_url': '',
        'is_live': is_live,
    }
    _assert('#EXT-X-KEY:METHOD=NONE', True, HlsFD.can_download('#EXT-X-KEY:METHOD=NONE', info_dict))

# Generated at 2022-06-22 07:09:27.410230
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:09:38.582273
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import io

    # The following example is taken from https://tools.ietf.org/html/draft-pantos-http-live-streaming-17#section-3.3.10
    manifest = io.StringIO(u'''#EXTM3U
    #EXT-X-TARGETDURATION:10
    #EXT-X-MEDIA-SEQUENCE:0
    #EXTINF:10,
    media-00001.ts
    #EXTINF:10,
    media-00002.ts
    #EXTINF:10,
    media-00003.ts
    #EXTINF:10,
    media-00004.ts
    #EXT-X-ENDLIST''')

    # Test 1.0: Same as above except #EXT-X-KEY is added in second line
    manifest_1_

# Generated at 2022-06-22 07:09:50.496110
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .downloader import HlsFD
    from .extractor.http import YoutubeIE
    from .compat import compat_urlparse, compat_parse_qs

    # ffmpeg won't download this stream
    manifest_url = 'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_16x9/bipbop_16x9_variant.m3u8'


# Generated at 2022-06-22 07:10:02.347673
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import re
    from .test import get_test_data
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .downloader.external import ExternalFD

    # set up test environment
    ie = InfoExtractor(downloader=FileDownloader())
    ie._setup_downloader()
    ie._match_entry(r'https://example.com/url(.*)', {'_type': 'url_transparent'})
    ie._match_entry(r'https://example.com/url_transparent(.*)', {'_type': 'url_transparent'})
    ie._match_entry(r'https://example.com/url_ignoretests(.*)')
    ie._match_entry(r'https://example.com/url_false(.*)', False)


# Generated at 2022-06-22 07:10:04.816850
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .tests.test_HlsFD import hlstest
    hlstest()



# Generated at 2022-06-22 07:10:16.279419
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def can_download(manifest, info_dict):
        return HlsFD.can_download(manifest, info_dict)

    # A simple manifest, should return true
    assert can_download(
        """
#EXTM3U
#EXT-X-DEFINITION-URL:http://test.test
#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=4280000
http://test.test/test/test.m3u8
""", {})

    # Playlist composed of byte range of media files, should return false

# Generated at 2022-06-22 07:10:26.900101
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testdata
    from .extractor.common import read_batch_urls
    from .downloader import _extract_info

    # There are two tests included in this function.
    # 1) test for valid hls stream
    # 2) test for decryption
    # 3) Skip unavailable fragments test

    hlsfd = HlsFD({})
    stream_url = read_batch_urls(get_testdata('hls/hls1.txt'))[0]
    stream_url2 = read_batch_urls(get_testdata('hls/hls1_enc.txt'))[0]
    stream_url3 = read_batch_urls(get_testdata('hls/hls1_skip_unavailable.txt'))[0]

    # Test for valid hls stream

# Generated at 2022-06-22 07:11:42.319663
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-TARGETDURATION:10\n'
        '#EXTINF:10,\n'
        'media-00000.ts\n'
        '#EXT-X-ENDLIST\n',
        {'is_live': False}
    )
    assert not HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-PLAYLIST-TYPE:EVENT\n'
        '#EXT-X-TARGETDURATION:10\n'
        '#EXTINF:10,\n'
        'media-00000.ts\n'
        '#EXT-X-ENDLIST\n',
        {'is_live': False}
    )


# Generated at 2022-06-22 07:11:52.034310
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    # valid manifest
    manifest = '''
#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:10
#EXTINF:7.916,
http://media.example.com/entire.ts
#EXT-X-ENDLIST
'''
    ie = InfoExtractor()
    ie.add_info_extractor(YoutubeIE())
    fd = HlsFD(ie, {})
    assert fd.can_download(manifest, {'url':'http://media.example.com/entire.m3u8'})
    # manifest with unsupported features

# Generated at 2022-06-22 07:11:53.497622
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, None)

# Generated at 2022-06-22 07:12:04.378331
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def _test(manifest, info_dict_is_live, expected_rv):
        assert (HlsFD.can_download(manifest, {'is_live': info_dict_is_live})
                is expected_rv)
    # Base-case
    _test('#EXTM3U', False, True)
    _test('#EXTM3U', True, False)
    # #EXT-X-KEY:METHOD
    _test('#EXT-X-KEY:METHOD=NONE', False, True)
    _test('#EXT-X-KEY:METHOD=NONE', True, False)
    _test('#EXT-X-KEY:METHOD=AES-128', False, can_decrypt_frag)
    _test('#EXT-X-KEY:METHOD=AES-128', True, False)

# Generated at 2022-06-22 07:12:10.681732
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest

    # Encrypted stream

# Generated at 2022-06-22 07:12:19.937202
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # function to generate a m3u8 manifest
    def gen_manifest(f_list):
        m3u8_str = ''
        for f in f_list:
            m3u8_str += '{0}\n'.format(f)
        return m3u8_str
    # list of supported features

# Generated at 2022-06-22 07:12:31.855143
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from io import BytesIO
    from ..extractor import common
    from .fragment import FragmentFD
    from ..downloader.common import FileDownloader
    from ..compat import compat_urllib_request


# Generated at 2022-06-22 07:12:42.864953
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest
    import os

    class TestHlsFD_can_download(unittest.TestCase):
        def test_aes_128_stream_not_supported(self):
            self.assertFalse(HlsFD.can_download(
                r'#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {}))

        def test_live_stream_not_supported(self):
            self.assertFalse(HlsFD.can_download(
                r'#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:3', {'is_live': True}))


# Generated at 2022-06-22 07:12:52.537909
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import (
        get_info_extractor,
        InfoExtractor,
    )
    from ..utils import (
        ExtractorError,
        match_filter_func,
        orderedSet,
    )
    from ..compat import (
        compat_urllib_request,
        compat_str,
    )

    (os_name, os_version, os_id) = compat_str(sys.platform).lower().split('-', 2)
    if os_name == 'win':
        os_name = 'windows'


# Generated at 2022-06-22 07:13:02.759856
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import sys
    import tempfile
    import shutil
    import json
    import pytest
    from .common import FakeYDL

    from .test_fragment import MockFragmentFD

    from ..extractor import gen_extractors
    from ..extractor.common import InfoExtractor

    class MockInfoExtractor(InfoExtractor):
        def _real_initialize(self):
            self.manifest_url = 'https://example.com/manifest.m3u8'
            self.info_dict = {
                'id': 'test',
                'title': 'test',
                'formats': [],
            }

        def _real_extract(self, url):
            assert url == self.manifest_url