

# Generated at 2022-06-22 07:03:27.940782
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors
    dict_info = {'info_dict': {'id': '63207919001', 'ext': 'mp4'}, 'params': {'quiet': True}}
    extractors = gen_extractors()
    for i in extractors:
        if i.IE_NAME == 'BrightcoveLegacy':
            dict_info['ie'] = i
            break
    hls_fd = HlsFD(dict_info, params={'quiet': True})
    assert hls_fd._real_initialize() is None

# Generated at 2022-06-22 07:03:39.877056
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    manifest = '#EXTM3U\n'\
    '#EXT-X-VERSION:3\n'\
    '#EXT-X-MEDIA-SEQUENCE:0\n'\
    '#EXT-X-PLAYLIST-TYPE:VOD\n'\
    '#EXTINF:5.0,\n'\
    'https://www.example.com/0.ts\n'\
    '#EXT-X-ENDLIST'
    info_dict = {'is_live': False}
    if not HlsFD.can_download(manifest, info_dict):
        print('Unit test for method can_download of class HlsFD failed')
        exit(1)
test_HlsFD_can_download()

# Generated at 2022-06-22 07:03:45.842427
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data

    class FakeYDL():
        def __init__(self):
            self.params = {
                'fragment_retries': 0,
                'test': True,
                'noprogress': True,
            }

        def urlopen(self, url):
            class FakeUrlHandle():
                def __init__(self):
                    self.url = url

                def read(self):
                    return get_test_data(url.split('/')[-1])

            return FakeUrlHandle()


# Generated at 2022-06-22 07:03:57.738890
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download('#EXTM3U', {'is_live': False, 'url': ''}) is True
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=NONE', {'is_live': False, 'url': ''}) is True
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {'is_live': False, 'url': ''}) is True
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {'is_live': False, 'url': '', '_decryption_key_url': ''}) is True

# Generated at 2022-06-22 07:04:07.309029
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    class MockYDL:
        def urlopen(self, url):
            assert url == 'http://example.com/1/index.m3u8?foo=bar'
            return self


# Generated at 2022-06-22 07:04:20.094916
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:04:23.751710
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        hs = HlsFD({}, {})
        assert(hs != None)
    except:
        print("Error while creating class")
        raise

# Generated at 2022-06-22 07:04:33.743280
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .concat import ConcatFD
    import youtube_dl
    import json
    import os

    manifest = os.path.join(
        os.path.dirname(__file__),
        'test_data',
        'hls-vd-variable.m3u8')
    with open(manifest) as f:
        manifest_data = f.read()

    def my_hook(d):
        if d['status'] == 'finished':
            print('Done downloading, now converting ...')


# Generated at 2022-06-22 07:04:46.581560
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Test for unsupported features
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=SAMPLE-AES', {})
    assert not HlsFD.can_download('#EXT-X-BYTERANGE', {})
    assert not HlsFD.can_download('#EXT-X-PLAYLIST-TYPE:EVENT', {})
    assert not HlsFD.can_download('#EXT-X-MAP', {})

    # Test for supported features
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=NONE', {})
    assert HlsFD.can_download('#EXT-X-PLAYLIST-TYPE:VOD', {})

# Generated at 2022-06-22 07:04:58.129152
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # This test will only work if HlsFD is being called from the command line
    import os, sys
    # Get the directory containing youtube_dl/YoutubeDL.py
    root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    # Add the youtube_dl directory to the search path
    sys.path.append(root_dir)
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'simulate':True, 'quiet':True, 'logger':False, 'no_warnings':True, 'forceurl':True, 'forcetitle':True, 'forceid':True, 'forcethumbnail':True, 'forceduration':True})
    ydl.add_

# Generated at 2022-06-22 07:05:24.736710
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    class FakeIE(InfoExtractor):
        _VALID_URL = r'https?://fake\.url'

        def _real_extract(self, url):
            return {
                'url': url,
                'is_live': False,
                '_decryption_key_url': None,
            }
    ie = FakeIE({})

    class FakeHlsFD(HlsFD):
        @staticmethod
        def can_download(manifest, info_dict):
            return True

    hls_fd = FakeHlsFD(ie, {})

    # Testing a manifest of too many features for native HLS downloader
    manifest = '#EXT-X-KEY:METHOD=AES-128\n#EXT-X-BYTERANGE:121090@0\n'

# Generated at 2022-06-22 07:05:27.803093
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """
    No arguments were passed, so we don't expect the test to pass here
    """
    fragment = HlsFD()


if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-22 07:05:36.210038
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import re
    import os
    import tempfile
    import unittest
    from youtube_dl.YoutubeDL import YoutubeDL

    regexes = ['test_hls', 'test_hls_fragment_retries', 'test_hls_fragment_skip', 'test_hls_fragment_retries_skip']


# Generated at 2022-06-22 07:05:48.687257
# Unit test for constructor of class HlsFD
def test_HlsFD():
    '''
    Unit test for HlsFD

    TODO: Test that the right error is produced when pycrypto is not available
    and a manifest with EXT-X-KEY:METHOD=AES-128 is passed
    '''
    import youtube_dl as ydl

    class Fake_YDL:
        def __init__(self):
            self.params = {
                'hls_use_mpegts': 'True',
            }

        def prepend_extension(self, filename, ext):
            return filename + ext

        def urlopen(self, url, *args, **kwargs):
            class Fake_UrlRetrieve:
                def __init__(self, content):
                    self.content = content
                def read(self):
                    return self.content


# Generated at 2022-06-22 07:05:59.712445
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import youtube_dl.YoutubeDL
    from youtube_dl.extractor import get_info_extractor

    # Test for handling multiple consecutive EXT-X-KEY attributes
    # For example, in https://github.com/ytdl-org/youtube-dl/issues/12448
    ie = get_info_extractor('hlsnative')
    url = 'http://playertest.longtailvideo.com/adaptive/oceans_aes/oceans_aes.m3u8'
    url += '?s=a4f4e88a9c9f5725e2c2fa2e93b94331&do_not_sign=True'

# Generated at 2022-06-22 07:06:11.656775
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .hls import HlsFD
    manifest = open('test/test_data/test_hls_manifest.m3u8', 'r').read()

    assert HlsFD.can_download(manifest, {'is_live': False})

    manifest = open('test/test_data/test_hls_manifest_with_crypto.m3u8', 'r').read()
    assert not HlsFD.can_download(manifest, {'is_live': False})

    manifest = open('test/test_data/test_hls_manifest_with_byte_range.m3u8', 'r').read()
    assert not HlsFD.can_download(manifest, {'is_live': False})


# Generated at 2022-06-22 07:06:24.249768
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import re
    import errno
    import difflib
    import md5
    import traceback
    import subprocess
    import platform
    import random
    import hashlib
    import random
    import string

    # The code of this unit test is heavily inspired from
    # https://github.com/ytdl-org/youtube-dl/blob/master/test/test_download.py

    def fake_time_sleep(secs):
        if secs > 3600:
            # Needed for the test to work on systems with more than 3600s of uptime
            raise AssertionError('Too big sleep: %f' % secs)

    def fake_urlopen_exception(self, req, **kwargs):
        raise compat_urllib

# Generated at 2022-06-22 07:06:35.818704
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .fragment import FragmentFD
    from .external import FFmpegFD
    import mock
    import test_utils
    parser = test_utils.MockYtdl({'hls_fragment_retries': 0})
    l = lambda s: s
    m = mock.MagicMock()
    m.geturl.return_value = 'http://m3u8.url/'
    f = FragmentFD(parser, l)
    ff = FFmpegFD(parser, l)
    # test_n_1: encrypted streams
    m.read.return_value = b'#EXTM3U\n#EXT-X-KEY:METHOD=AES-128'
    assert not HlsFD.can_download(m.read(), {})
    # test_n_2: playlists composed of byte ranges of media

# Generated at 2022-06-22 07:06:47.413934
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from youtube_dl.downloader.hls import HlsFD
    from .testutils import FakeYDL
    from .testutils import FakeInfoDict

    class CanDownloadTests(unittest.TestCase):
        def check_can_download_query_string(self, test_input, expected):
            ctx = {
                'url': 'http://example.com/manifest.m3u8?%s' % test_input,
                'ydl': FakeYDL(),
                'info_dict': FakeInfoDict({'url': "http://example.com/manifest.m3u8?%s" % test_input}),
            }
            self.assertEqual(expected, HlsFD.can_download(ctx['url'], ctx['info_dict']))


# Generated at 2022-06-22 07:06:59.474720
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import io
    from .utils import (
        prepared_fakehttpd,
        get_testdata_files_directory,
        assertRegexpMatches,
        read_files_frag_content,
    )

    test_files_directory = get_testdata_files_directory()
    test_files = read_files_frag_content(test_files_directory, 'HlsFD', 'fragment-')

    with prepared_fakehttpd(test_files) as httpd:
        base_url = 'http://localhost:%d/' % httpd.port
        manifest_url = base_url + 'manifest.m3u8'

        class FakeYDL:
            def __init__(self):
                self._http_headers = {}


# Generated at 2022-06-22 07:07:38.391517
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    # Use simple test for feature test
    test_result = True
    ydl = Downloader({
        'outtmpl': 'test.mp4',
    })
    url = 'http://dai.google.com/linear/hls_vod/gear2/gear2_sd.m3u8'
    # Open the file and get the content
    with YoutubeIE(ydl)._real_extract(url) as ie:
        if ie is not None:
            info_dict = ie.extract(url)
            fd = HlsFD(ydl=ydl, params={})
            test_result = fd.real_download('test.mp4', info_dict)
    assert test_result


# Generated at 2022-06-22 07:07:51.105307
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .test_utils import FakeYDL
    from .extractor.common import InfoExtractor
    from .extractor import gen_extractor_classes
    class FakeIE(InfoExtractor):
        IE_NAME = 'FakeIE'
        _VALID_URL = ''
        _TEST = {
            'url': '',
            'info_dict': {
                'id': '',
                'title': '',
            },
        }
    for ie in gen_extractor_classes():
        if ie != FakeIE:
            break
    ydl = FakeYDL({})

# Generated at 2022-06-22 07:07:55.539590
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .test import get_test_data
    from .common import warning
    from .extractor.generic import GenericIE

    for manifest in get_test_data("hlsnative_manifests", []):
        print("-" * 70)
        print("name: " + manifest)
        # Test the availability of HlsFD
        with open(manifest, "r") as f:
            m3u8_manifest = f.read()
        info_dict = GenericIE._extract_info(GenericIE(), {'url': ''})
        print("available: " + str(HlsFD.can_download(m3u8_manifest, info_dict)))
        # Test the warning message
        with warning(True):
            HlsFD.can_download(m3u8_manifest, info_dict)

# Generated at 2022-06-22 07:08:06.659039
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """
    This function is a unit test for method real_download of class HlsFD.

    Results are checked manually.
    """
    import io
    import os
    import shutil
    import tempfile
    from .common import FakeYDL
    from .external import FFmpegFD

    from ..utils import make_HTTPServer

    man_url = 'http://example.com/playlist.m3u8'

# Generated at 2022-06-22 07:08:19.092045
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest
    class HlsFD_can_download_Test(unittest.TestCase):
        def test_unknown_parameter(self):
            manifest = '#EXTM3U\n#EXT-X-FOO:BAR'
            manifest_info_dict = {'url': 'http://foo/bar'}
            is_expected_result = False
            assert(HlsFD.can_download(manifest, manifest_info_dict) == is_expected_result)

        def test_encrypted_stream_not_supported_method(self):
            manifest = '#EXTM3U\n#EXT-X-KEY:METHOD=BAR'
            manifest_info_dict = {'url': 'http://foo/bar'}
            is_expected_result = False

# Generated at 2022-06-22 07:08:21.617258
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .smoke.test_generic_downloader import do_generic_download_test
    return do_generic_download_test('hlsnative', HlsFD)

# Generated at 2022-06-22 07:08:33.537902
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .test_utils import FakeYDL
    ydl = FakeYDL()
    ydl.params['hls_prefer_native'] = True
    ydl.params['hls_use_mpegts'] = False

    # Test features that are not supported by hlsnative
    test_url = 'http://example.com/'

    # Non-native AES-128 decryption is supported
    test_manifest = '#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="key.bin"\n%s' % test_url
    info_dict = {'url': test_url}
    res = HlsFD.can_download(test_manifest, info_dict)
    assert res == True

    # Method other than AES-128 is not supported

# Generated at 2022-06-22 07:08:44.443244
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.generic import GenericIE
    from ..compat import compat_str
    ydl = object()
    params = {
        'hls_use_mpegts': 'false',
        'hls_segment_filename': '%(segment_id)s',
        'hls_base_url': '',
    }
    extractor = GenericIE(ydl, params)
    fd = HlsFD(extractor, params)
    assert fd.params == params
    assert fd.ydl == ydl
    assert fd.base_url == ''
    assert fd.format_id == ''
    assert fd.use_mpegts is False


# Generated at 2022-06-22 07:08:55.905237
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from textwrap import dedent
    from ..extractor import YoutubeDL
    from ..utils import _TEST_FILE_CONTENT

    ydl = YoutubeDL()
    ydl.params['quiet'] = True
    ydl.params['skip_download'] = True
    ydl.params['noplaylist'] = True
    ydl.params['nocheckcertificate'] = True

    fake_url = 'file://' + _TEST_FILE_CONTENT[0]
    info_dict = ydl.extract_info(
        fake_url, download=False, process=False)

    # Non AES-128 encrypted

# Generated at 2022-06-22 07:09:04.111413
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import unittest
    from .test_files import TestFiles as TF

    # Mock urlopen to return the content of file. The urlopen method
    # is used to download the manifest
    def urlopen(request, *args, **kwargs):
        BASE_PATH = os.path.join(os.path.dirname(__file__), 'test_files')
        url_components = request.get_full_url().split('/')
        filename = next((comp for comp in url_components if comp.endswith('.m3u8')),
                        next((comp for comp in url_components if comp.endswith('.mpd')), ''))
        path_to_file = os.path.join(BASE_PATH, filename)

# Generated at 2022-06-22 07:10:15.608778
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import MockYDL
    from .extractor import gen_extractors
    from .downloader import gen_ydl
    from .options import YoutubeDLOptions
    from .constants import HLS_PHRASE

    def _extract_urls(filename):
        # Open and parse the file contents of filename, then return the set of URLs
        # downloaded as found in the file.
        with open(filename, 'rb') as fp:
            contents = fp.read()
        return set(re.findall(br'url="[^"]+', contents))


# Generated at 2022-06-22 07:10:25.397358
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    sys.path.append('/home/quan/youtube-dl-hls/bin')
    import youtube_dl
    url = 'https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_16x9/bipbop_16x9_variant.m3u8'
    ydl = youtube_dl.YoutubeDL({'verbose': True})
    ydl.add_default_info_extractors()
    info_dict = ydl.extract_info(url, download=False)
    HlsFD.can_download(info_dict['formats'][1]['manifest_url'], info_dict)

# Generated at 2022-06-22 07:10:28.429291
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ydl = YoutubeDL({})
    hlsfd = HlsFD(ydl, {'test': True})

test_HlsFD()

# Generated at 2022-06-22 07:10:31.498591
# Unit test for constructor of class HlsFD
def test_HlsFD():
    ydl = MockYDL()
    params = {'format': 'm3u8'}
    HlsFD(ydl, params)


if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-22 07:10:34.204441
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # TODO: Test if this method works
    print('Method HlsFD real_download not tested yet')

# Generated at 2022-06-22 07:10:46.230577
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest

    # test strings non-live
    manifest_nl_1 = "#EXTM3U\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=1\nhlsp://a.com/a.m3u8"
    manifest_nl_2 = "#EXTM3U\n#EXT-X-KEY:METHOD=NONE\n#EXT-X-BYTERANGE:10@20\n#EXT-X-MEDIA-SEQUENCE:3\n#EXT-X-PLAYLIST-TYPE:EVENT\nmedia_segment_1\nmedia_segment_2\n"

# Generated at 2022-06-22 07:10:49.035935
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    _test_real_download_of_FD(HlsFD)

if __name__ == '__main__':
    test_HlsFD_real_download()

# Generated at 2022-06-22 07:10:56.884659
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\nhttps://example.com/path/to/video.ts', {'is_live': True, '_decryption_key_url': 'http://example.com/path/to/key/uri'})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\nhttps://example.com/path/to/video.ts', {'is_live': True, '_decryption_key_url': 'http://example.com/path/to/key/uri'})

# Generated at 2022-06-22 07:11:08.369894
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors
    from ..extractor.common import InfoExtractor
    from ..utils import SearchInfoExtractor
    from .fragment import FragmentFD

    def _test_ie(ie, urls, expected_results):
        for url, expected in zip(urls, expected_results):
            info_dict = {
                'url': url,
                'protocol': 'm3u8_native',
            }
            res = ie.extract_info(
                SearchInfoExtractor(), url, downloader=FakeYDL({}))
            fd, res = FragmentFD.get_fragment_retriever(ie, res)
            if isinstance(fd, HlsFD):
                manifest = ydl_opener.open(url, urlh=URLHandler()).read().decode

# Generated at 2022-06-22 07:11:19.688891
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .testutil import FakeYdl, setup_test_dir
    setup_test_dir()
    if can_decrypt_frag:
        ydl = FakeYdl(params={'test': True})
        ydl.add_info_extractor(HlsFD())
        ydl.download(['https://bitdash-a.akamaihd.net/content/MI201109210084_1/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8'])
        assert ydl.ydl_info_dicts[-1]['url']
        assert len(ydl.ydl_opened_urls) == 1