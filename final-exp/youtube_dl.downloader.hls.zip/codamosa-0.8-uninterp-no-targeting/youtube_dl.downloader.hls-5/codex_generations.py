

# Generated at 2022-06-22 07:03:30.834847
# Unit test for constructor of class HlsFD
def test_HlsFD():
    info_dict = {}
    HlsFD(None, None).real_download('dummy_filename.mp4', info_dict)


# Generated at 2022-06-22 07:03:41.962069
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():

    from .http import HttpFD
    from .external import ExternalFD
    from ..utils import encodeFilename, prepend_extension

    n = HlsFD.__name__
    _, config_dir = HlsFD.get_base_data_dirs(__name__)
    data_dir = os.path.join(config_dir, 'HlsFD')
    if not os.path.exists(data_dir):
        os.mkdir(data_dir)
    HttpFD.data_dir = data_dir
    HttpFD._set_config(n)
    ExternalFD._set_config(n)


# Generated at 2022-06-22 07:03:46.927897
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.youtube import YoutubeIE
    from ..downloader import YoutubeDL
    from ..utils import encode_data_uri

    # Simulate yt extractor output

# Generated at 2022-06-22 07:03:58.254769
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXT-X-VERSION:3\n#EXT-X-MEDIA-SEQUENCE:1\n#EXT-X-PLAYLIST-TYPE:VOD\n#EXTINF:10,\nmedia-00001.ts\n',
                              {'is_live': False, 'url': ''})

# Generated at 2022-06-22 07:04:07.538728
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os

# Generated at 2022-06-22 07:04:20.215101
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import ydl_info
    info_dict = {
        'url': 'http://videohost.com/hls/stream.m3u8',
        'http_headers': {
            'User-Agent': ydl_info.USER_AGENT
        }
    }

    info_dict2 = {
        'url': 'http://videohost.com/hls/stream.m3u8',
        'http_headers': {
            'User-Agent': ydl_info.USER_AGENT
        },
        'extra_param_to_segment_url': 'key=value',
        '_decryption_key_url': 'key_url'
    }

    try:
        from Crypto.Cipher import AES
        test_decrypt = True
    except ImportError:
        test_decrypt

# Generated at 2022-06-22 07:04:31.674719
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .utils import make_YDL
    from .extractor import gen_extractors
    ydl = make_YDL()
    gen_extractors(ydl)
    hls_info = {'url': r'https://www.youtube.com/s/GPdZWtFkeF0/v/b/jgIAIocp_N/hls-vod-cms-token-token=i3k-ddH/',
                'http_headers': {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'}}
    hlsFD = HlsFD(ydl.params, ydl)
    hlsFD.can

# Generated at 2022-06-22 07:04:43.146909
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=NONEXISTENT', {})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=NONE', {})
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'_decryption_key_url': 'http://'})
    assert HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'extra_param_to_segment_url': 'http://'})

# Generated at 2022-06-22 07:04:44.085941
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, None)

# Generated at 2022-06-22 07:04:55.996750
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from youtube_dl.extractor import DummyExtractor

    class _HlsTestExtractor(DummyExtractor):
        def _real_extract(self, url):
            return {
                '_type': 'url',
                'url': 'https://www.youtube.com/watch?v=iwGFalTRHDA',
                '_extra_param_to_segment_url': '&foo=bar',
                '_decryption_key_url': 'https://foo.com',
                '_initial_fragment_index': 1,
            }

    data = HlsFD.can_download('', {})
    assert data == True
    data = HlsFD.can_download('#EXT-X-KEY:METHOD=NONE', {})
    assert data == True
    data = HlsFD.can_download

# Generated at 2022-06-22 07:05:11.039784
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'noprogress': True})
    x = HlsFD(ydl, {})
    return x is not None

# Generated at 2022-06-22 07:05:22.942388
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .fragment import FragmentFD
    from .external import FFmpegFD
    FragmentFD.FD_NAME = 'hlsnative'
    FFmpegFD.FD_NAME = 'ffmpeg'
    import os.path
    working_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.join(working_dir, '..')
    manifest_file = os.path.join(parent_dir, 'test', 'manifest_urls.txt')
    manifest_file = os.path.normpath(manifest_file)
    manifest_urls_file = open(manifest_file, 'r', encoding='utf-8')
    manifest_urls = manifest_urls_file.read().splitlines()
    manifest_urls_file.close()

# Generated at 2022-06-22 07:05:33.402237
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import YoutubeDL

    ydl = YoutubeDL(params={
            'hls_use_mpegts': True,
            'hls_fragment_retries': 0,
            'hls_skip_unavailable_fragments': True,
            'format': '127',
            'test': True,
            'verbose': True,
        })
    fd = HlsFD(ydl, params={})

# Generated at 2022-06-22 07:05:45.774068
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import get_info_extractor

    def test_can_download(ie_name, manifest):
        ie = get_info_extractor(ie_name)
        info = ie._real_extract('DUMMY', {'url': 'http://dummy/' + ie_name})
        return HlsFD.can_download(manifest, info)

    # can_download_hls_manifest_aes128 is True

# Generated at 2022-06-22 07:05:57.626308
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from collections import namedtuple
    TestCase = namedtuple('TestCase', ['manifest', 'info_dict', 'expected'])

    # Tested features:
    #   - encryption methods (AES-128 and NONE)
    #   - byte range (starts with #EXT-X-BYTERANGE)
    #   - live streams (starts with #EXT-X-MEDIA-SEQUENCE)
    #   - media segments appending (ends with #EXT-X-PLAYLIST-TYPE:EVENT)
    #   - media initialization (starts with #EXT-X-MAP)


# Generated at 2022-06-22 07:06:03.898635
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:06:16.105707
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:06:28.379626
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ydl.extractor import YoutubeIE
    from ydl.utils import DateRange
    youtube_ie = YoutubeIE(params=dict(
        start_date=DateRange('20070101'), end_date=DateRange('20070131')
    ))
    info_dict = youtube_ie.extract('6cjU6AZnSQM')
    filename = 'test_HlsFD_real_download.m4a'
    manifest_url = 'https://mnmedia.atlantasports.org/player/cache/hls.m3u8'
    info_dict['url'] = manifest_url
    return HlsFD(None, dict()).real_download(filename, info_dict)

if __name__ == '__main__':
    import sys

# Generated at 2022-06-22 07:06:38.379208
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import tempfile
    import sys

    if sys.version_info < (3,):
        import mock
        # mock.patch doesn't work with unicode_literals
        HlsFD = mock.MagicMock()
    else:
        from unittest import mock
    from .external import ExternalFD


# Generated at 2022-06-22 07:06:50.452707
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from io import BytesIO
    from .http import HttpFD
    from .external import ExternalFD
    from ..downloader import Downloader
    from ..extractor import DummyIE
    from ..utils import prepare_filename
    from ..compat import compat_str


# Generated at 2022-06-22 07:07:18.954438
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .utils import build_fake_extractors
    from .extractor import YoutubeIE
    req = YoutubeIE(build_fake_extractors())._request_webpage
    fd = HlsFD({}, req)
    return fd

# Generated at 2022-06-22 07:07:30.658711
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .utils import FakeYDL
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_urlparse

    ydl = FakeYDL()
    ydl.params['test'] = True
    ydl.add_info_extractor(InfoExtractor('test'))
    fd = HlsFD(ydl, ydl.params)
    fd.add_progress_hook(ydl.hooks['progress'])

# Generated at 2022-06-22 07:07:40.673478
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import common
    from .fragment import FragmentFD
    from .external import FFmpegFD
    from .hls import HlsFD

    for ext in FFmpegFD.available():
        assert ext in HlsFD.available(), "FFmpegFD can_download should be a subset of HlsFD"

    # example.com media
    hls_url = "http://www.example.com/media.m3u8"

    # Some examples copied from https://tools.ietf.org/html/draft-pantos-http-live-streaming-23

# Generated at 2022-06-22 07:07:53.581503
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-22 07:08:04.823672
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import unittest
    from ..compat import unittest, compat_urllib_request
    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            pass
        def tearDown(self):
            pass
        def test_yaml(self):
            # this manifest contains features that hlsnative does not support
            manifest = """
#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:4
#EXT-X-MEDIA-SEQUENCE:0
#EXT-X-KEY:METHOD=NONE
#EXTINF:3,
http://techslides.com/demos/sample-videos/small.mp4
#EXT-X-ENDLIST
"""

# Generated at 2022-06-22 07:08:13.918984
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import FakeYDL

    filename = 'test.mp4'
    info_dict = {
        'url': 'http://example.com/index.m3u8',
        'http_headers': {'Referer':'http://example.com/referer'},

        '_decryption_key_url': 'http://example.com/decryption_key',
        'extra_param_to_segment_url': 'extra_param=1234',
    }

# Generated at 2022-06-22 07:08:25.589167
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..__main__ import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..downloader.external import ExternalFD
    from ..downloader.http import HttpFD
    ydl = YoutubeDL({})

# Generated at 2022-06-22 07:08:35.325966
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractionError

    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            raise ExtractionError

    # Put setup code here
    ie = FakeInfoExtractor({})
    ie.suitable = True

    # Put most used attributes into a dictionary
    attr = {}
    attr['ie'] = ie
    attr['manifest'] = ''


# Generated at 2022-06-22 07:08:48.162352
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    hlsfd = HlsFD(ydl, {'hls_use_mpegts': True})
    assert hlsfd.fd_name() == 'hlsnative'
    assert hlsfd.params['use_mpegts']
    assert hlsfd.FD_NAME == 'hlsnative'

# Generated at 2022-06-22 07:08:50.172465
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import doctest
    doctest.testmod()

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-22 07:09:50.682645
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..compat import mock
    from ..downloader.http.httpfd import HttpFD
    from ..downloader.rtmp import RTMPFD

    HlsFD()

    url = 'invalid_url'
    ie = InfoExtractor(HlsFD(), downloader=mock.Mock())
    info_dict = {'_type': 'hls', 'url': 'hlsnative://' + url}

    # mock HttpFD's can_download method

# Generated at 2022-06-22 07:10:02.547231
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest

    class TestHlsFD(HlsFD):

        def __init__(self, params):
            super(TestHlsFD, self).__init__(params)
            self.result_can_download = None

        def report_warning(self, msg):
            pass

    class HlsFDTest(unittest.TestCase):
        def run_test(self, manifest, info_dict, should_succeed=True):
            fd = TestHlsFD(params={})
            result = fd.can_download(manifest, info_dict)
            self.assertEqual(result, should_succeed)


# Generated at 2022-06-22 07:10:14.546612
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import pytest
    m3u8 = '''
#EXTM3U
#EXT-X-VERSION:3
#EXT-X-MEDIA-SEQUENCE:0
#EXT-X-TARGETDURATION:10
#EXTINF:10,
http://media.example.com/first.ts
#EXTINF:10,
http://media.example.com/second.ts
#EXTINF:10,
http://media.example.com/third.ts
#EXT-X-ENDLIST
'''
    def test_can_download_with_no_features(features=[]):
        for feature in features:
            assert feature not in m3u8, 'Test should not contain features %s' % features
        assert HlsFD.can_download(m3u8, {'is_live': False})


# Generated at 2022-06-22 07:10:25.640879
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:10:32.316140
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD(None).extract_fragment_info_extractors() == (
        (r'playlist_type', 'HLS'),
        (r'url', 'must be set'),
        (r'fragments', 'must be set'),
        (r'fragment_index', 'must be set'),
        (r'extra_param_to_segment_url', 'optional'),
    )


# Generated at 2022-06-22 07:10:44.608514
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os

    from . import FileDownloader
    from .external import ExternalFD
    from .fragment import FragmentFD

    from ..compat import (
        compat_urllib_request,
        compat_urllib_error,
        compat_urlparse,
        compat_struct_pack,
        compat_str,
    )
    from ..utils import (
        parse_m3u8_attributes,
    )
    from ..downloader.common import FileDownloader
    from ..downloader.external import FFmpegFD
    from ..downloader.fragment import FragmentFD

    class YTLDummyFileDownloader(FileDownloader):
        def __init__(self, ydl):
            self.ydl = ydl
            self.params = self.ydl.params

# Generated at 2022-06-22 07:10:55.582029
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .common import fake_ydl
    ydl = fake_ydl()
    info_dict = {
        'url': 'https://example.com',
        'ext': 'mp4',
        'http_headers': {
            'User-Agent': 'foobar',
        },
    }

    # check if HlsFD can download a live stream
    info_dict['is_live'] = True

# Generated at 2022-06-22 07:11:04.675565
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:11:16.306058
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """Test the method real_download of the class HlsFD."""
    import os
    import random
    import subprocess
    import sys
    import unittest
    import youtube_dl
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.downloader.fragment import FragmentFD
    from youtube_dl.utils import (
        encode_compat_str,
    )

    def get_test_data_folder():
        """
        Return the folder of the test module.
        It is assumed that the current folder is the one where the module
        is located.
        """
        return os.path.join(os.path.dirname(__file__), os.pardir, 'test',
                            'data', 'downloader')


# Generated at 2022-06-22 07:11:25.197074
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():

    # coverage test
    from .youtube import YoutubeFD
    class Ydl(object):
        def report_error(self, msg, tb=None):
            pass
        def report_warning(self, msg):
            pass
        def to_screen(self, msg, skip_eol=False):
            pass
        def urlopen(self, url):
            class Urlh(object):
                def geturl(self):
                    return url
                def read(self):
                    return 'blah'
            return Urlh()

    ydl = Ydl()
    ydl.params = {}
    info_dict = {
        'url': 'https://example.com/manifest.m3u8',
        'http_headers': {
            'Range': 'bytes=0-9'
        }
    }