

# Generated at 2022-06-22 07:03:40.158314
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testdata_file
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .downloader.external import ExternalFD
    from .downloader.fragment import FragmentFD
    from .utils import USER_AGENT
    import yaml
    import os
    import io
    import tempfile
    import sys
    import atexit


# Generated at 2022-06-22 07:03:52.031485
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """ Test download of hls fragments using method real_download of class HlsFD """
    from youtube_dl.YoutubeDL import YoutubeDL
    import os
    import shutil
    import tempfile
    import sys
    import time
    from tests.helper import MockYDL

    test_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'hls_test.m3u8')
    with open(test_file, 'rb') as f:
        m3u8 = f.read().decode('utf-8', 'replace')
    tmp_dir = tempfile.mkdtemp(prefix='ydltest_')

# Generated at 2022-06-22 07:04:02.852354
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def test(manifest, expected_result, is_live=False):
        class DummyInfoDict(dict):
            def __init__(self):
                super(DummyInfoDict, self).__init__()
                self['is_live'] = is_live

        class DummyYtdl(object):
            params = {}

        ytdl = DummyYtdl()
        ytdl.params['hls_use_mpegts'] = False
        info_dict = DummyInfoDict()

        result = HlsFD.can_download(manifest, info_dict)

        assert result == expected_result, 'expected %s but got %s' % (expected_result, result)

    # Tests for unsupported features
    test('#EXT-X-KEY:METHOD=SAMPLE-AES', False)
    test

# Generated at 2022-06-22 07:04:13.955706
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .utils import TestDownloader
    d = TestDownloader()
    d.add_info_extractor(HlsFD)

    url = 'http://hls-geo.daserste.de/i/videoportal/Film/c_620000/622873/format,716451,716457,716450,716458,716459,.mp4.csmil/master.m3u8?null=0'
    ext = HlsFD.suitable(d.ydl, {})(url, d.ydl.cache.get(url, {}))
    ext.add_progress_hook(lambda *a, **k: None)

# Generated at 2022-06-22 07:04:26.721319
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import __test_download
    from .http import HttpFD

    class FakeYDL:

        def __init__(self):
            self.params = {}
            self.to_screen = lambda *_: None
            self.report_warning = lambda *_: None

        def urlopen(self, req):
            return HttpFD()._download_webpage_handle(
                req.url, req.headers, None, None, None, False)

    ydl = FakeYDL()
    ydl.params = {'proxy': None, 'test': True, 'outtmpl': '-'}

    info_dict = {}

    # Test case: http://hls-geo.daserste.de/i/videoportal/Film/c_620000/622873/format,716451,716

# Generated at 2022-06-22 07:04:28.028107
# Unit test for constructor of class HlsFD
def test_HlsFD():
    return HlsFD({'test': True}, {}, None)

# Generated at 2022-06-22 07:04:42.362132
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import HlsIE
    from ..extractor.common import InfoExtractor
    from ..utils import SearchInfoExtractor

    def get_IE(url):
        ie = InfoExtractor(params={})
        ie._downloader = Dummy()
        ie.add_info_extractor(SearchInfoExtractor(ie))
        ie.add_info_extractor(HlsIE(ie))
        ie.url = url
        return ie

    def get_IE_and_manifest(url, **kwargs):
        ie = get_IE(url)
        return ie, ie._real_extract(ie._real_extract(url, **kwargs))

    # Live stream with geo restriction for Germany

# Generated at 2022-06-22 07:04:54.362605
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Test with test.m3u8
    test_file = os.path.join(os.path.dirname(__file__), "test.m3u8")
    with open(test_file, 'rb') as f:
        hlstest = HlsFD(None, None, None)
        assert hlstest.can_download(f.read().decode('utf-8', 'ignore'), {})
    # Test with test_live.m3u8
    test_file = os.path.join(os.path.dirname(__file__), "test_live.m3u8")
    with open(test_file, 'rb') as f:
        hlstest = HlsFD(None, None, None)

# Generated at 2022-06-22 07:05:04.741698
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # pylint: disable=redefined-outer-name
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import urlparse
    from .test_utils import FakeYDL


# Generated at 2022-06-22 07:05:09.080450
# Unit test for constructor of class HlsFD
def test_HlsFD():
    class DummyYDL:
        params = {}

    ydl = DummyYDL()
    fd = HlsFD(ydl, ydl.params)
    assert fd.FD_NAME == 'hlsnative'

# If a stream is composed of fragments containing audio, video and subtitles,
# check that only the next available fragment is downloaded.

# Generated at 2022-06-22 07:05:30.017980
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from tests.tst_dl import FakeYdl
    ydl = FakeYdl()
    hls_fd = HlsFD(ydl, {})
    hls_fd.real_download('file.mp4', {
        'url': 'http://c.brightcove.com/services/mobile/streaming/index/master.m3u8?videoId=sdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdf'
    })
    assert ydl.frags == 1

# Generated at 2022-06-22 07:05:42.846708
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest

    class TestHlsFD(object):
        def __init__(self, params):
            self.params = params

        def urlopen(self, url):
            class FakeUrlHandle(object):
                def __init__(self, url):
                    self.url = url
                    self.data = url

                def geturl(self):
                    return self.url

                def read(self):
                    return self.data

            return FakeUrlHandle(url)

    def get_url_handle(url, extra_query=None, http_headers=None, params=None):
        if params.get('test'):
            return FakeUrlHandle('%s%s' % (url, extra_query))

    class FakeUrlHandle(object):
        def __init__(self, data):
            self.data = data

       

# Generated at 2022-06-22 07:05:48.446060
# Unit test for constructor of class HlsFD
def test_HlsFD():
    filename = 'myfilename'
    url = 'http://myurl.com/'
    info_dict = { 'url': url, 'start_time': 1, 'end_time': 2 }
    fd = HlsFD(None, {})
    assert fd.FD_NAME == 'hlsnative'
    assert fd.real_download(filename, info_dict) == False
    assert fd.to_screen('[%s] Downloading m3u8 manifest' % fd.FD_NAME) == None

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-22 07:05:59.427854
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .dash import DashFD
    from .http import HttpFD
    from .smoothstream import SmoothStreamsFD
    from .m3u8 import M3u8FD
    fd_class_list = [HlsFD, DashFD, HttpFD, M3u8FD, SmoothStreamsFD]
    fd_class_can_download_list = [fd_class.can_download for fd_class in fd_class_list]

# Generated at 2022-06-22 07:06:11.151000
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download('', {'protocol': 'hls'})
    assert not HlsFD.can_download(
        '#EXT-X-KEY:METHOD=AES-128', {'protocol': 'hls'})
    assert HlsFD.can_download(
        '#EXT-X-KEY:METHOD=AES-128', {'protocol': 'hls', '_decryption_key_url': 'ignore'})
    assert not HlsFD.can_download(
        '#EXT-X-KEY:METHOD=AES-128\n#EXT-X-BYTERANGE:100@100', {'protocol': 'hls'})

# Generated at 2022-06-22 07:06:23.393783
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
   # Test the HlsFD method with test data and the youtube URL
   params = {'format': '141'}
   ydl = YoutubeDL(params)
   url = 'https://www.youtube.com/watch?v=FnCdOQsX5kc'
   info_dict = ydl.extract_info(url, download=False)
   assert HlsFD.can_download(ydl,info_dict)
   ydl.params.update({'outtmpl': '%(id)s.%(ext)s'})
   ydl.download([url])
   assert os.path.exists('FnCdOQsX5kc.m4a')
   os.remove('FnCdOQsX5kc.m4a')

# Generated at 2022-06-22 07:06:35.693467
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Test basic download of an HLS stream
    stream = HlsFD().real_download('',
        {'url': 'https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8'})
    assert stream is True
    # Test download of an HLS stream with a byterange in the first fragment
    stream = HlsFD().real_download('',
        {'url': 'https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_16x9/bipbop_16x9_variant.m3u8'})
    assert stream is True
    # Test download of an HLS stream with AES-128 encryption (requires pycrypto)
    stream

# Generated at 2022-06-22 07:06:47.361912
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor import common
    import tempfile
    # test_live_stream() is used as an input data
    ydl = common.YoutubeDL()
    url = 'http://example.com/live_stream.m3u8'
    info_dict = {
        'url': url,
        'http_headers': {
            # The total length is 2989 bytes, each fragment is 512 bytes
            # thus there are 6 fragments in the playlist.
            'Content-Length': '2989',
            'Range': 'bytes=%d-%d' % (0, 511),
        },
        'id': 'live_stream',
        'title': 'Live Stream Title',
    }
    fd = HlsFD(ydl, {})
    fd.add_progress_hook()
    tf = tempfile.N

# Generated at 2022-06-22 07:06:59.422852
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class YDL(object):
        def urlopen(self, url):
            class URLH(object):
                def __init__(self, r):
                    self.r = r
                def read(self):
                    return self.r
            if url == 'https://example.com/man':
                return URLH(man)

        def error(self, message):
            print(message)

    info_dict = {'url': 'https://example.com/man'}
    ydl = YDL()

    HlsFD.can_download(man, info_dict)
    # no test output, no error raised

    # [1]
    man = '#EXT-X-KEY:METHOD=OTHER'

# Generated at 2022-06-22 07:07:08.780760
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_test_data
    from ..extractor.generic import YoutubeIE
    from ..utils import encodeArgument

    youtubeel_url = 'TIy3n2b7V9k'
    youtubeel_id = 'TIy3n2b7V9k'

# Generated at 2022-06-22 07:07:32.118199
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import sys
    import os
    import tempfile
    import shutil

    def load_m3u8(name):
        with open(os.path.join(m3u8_dir, name), 'rb') as f:
            return f.read().decode('utf-8')

    def load_info_dict(name):
        with open(os.path.join(info_dict_dir, name), 'rb') as f:
            return eval(f.read().decode('utf-8'))

    class DummyYTDLLogger:
        def report_warning(self, _):
            pass

    class DummyYTDL:
        def __init__(self):
            self.logger = DummyYTDLLogger()


# Generated at 2022-06-22 07:07:41.001867
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.http import HttpIE
    from ..compat import urljoin

    class TestIE(HttpIE):
        def _real_initialize(self):
            self.FOOBAR_URL = 'http://localhost/foobar'

# Generated at 2022-06-22 07:07:53.885904
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE
    from .utils import make_fake_info_dict

    youtube_ie = YoutubeIE(None)
    youtube_ie.extract = lambda url: make_fake_info_dict(
        url, m3u8_url=url,
        is_live=True,
        http_headers={
            'Referer': 'https://example.com',
        },
    )

    info_dict = youtube_ie._real_extract('https://example.com')
    hls_fd = HlsFD(YoutubeIE(None), {})

# Generated at 2022-06-22 07:08:05.064206
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    import youtube_dl.YoutubeDL
    args = sys.argv
    from .downloader import _parseOpts
    from .extractor import gen_extractors
    downloader = youtube_dl.YoutubeDL.YoutubeDL(_parseOpts(args))
    downloader.add_default_info_extractors()
    gen_extractors(downloader)
    fd = HlsFD(downloader, {})
    assert fd.FD_NAME == 'hlsnative'
    assert isinstance(fd, FragmentFD)
    assert not fd.can_download('', {'url': 'http://fake.url'})

# Generated at 2022-06-22 07:08:14.202194
# Unit test for constructor of class HlsFD
def test_HlsFD():
    url = "https://example.com/test.m3u8"
    manifest = "#EXTM3U\n#EXT-X-VERSION:1\n#EXT-X-TARGETDURATION:2\n#EXTINF:2,\ntest1.ts\n#EXTINF:2,\ntest2.ts\n#EXTINF:2,\ntest3.ts\n#EXT-X-KEY:METHOD=AES-128,URI=\"key.bin\",IV=0X10ef8f758ca555115584bb5b3c687f52\n#EXTINF:2,\ntest4.ts\n"
    ydl = DummyYoutubeDl()
    ydl.urlopen(url).read.return_value = manifest

# Generated at 2022-06-22 07:08:24.887023
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import tempfile
    from .utils import FakeYDL
    from .extractor.common import InfoExtractor
    # Set debug level
    InfoExtractor.ie_key_map['hls'] = 'HlsFD'
    InfoExtractor.ie_key_map['hls_native'] = 'HlsFD'
    # Save previous stdout
    old_stdout = sys.stdout
    # Create a temporary directory to store all the downloaded files
    temp_dir = tempfile.TemporaryDirectory()
    temp_file = temp_dir.name + '/test.ts'
    # Create a fake ydl object
    ydl = FakeYDL()
    # Set options for HlsFD

# Generated at 2022-06-22 07:08:35.048551
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:08:47.875396
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-22 07:08:58.114511
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import YoutubeDL
    from ..extractor import get_info_extractor
    from ..utils import encode_compat_str

    # Create test Youtubedl object
    ydl = YoutubeDL({})

    # Extractor for m3u8 manifest
    class TestIE(object):
        def __init__(self, ydl):
            self.ydl = ydl

        @staticmethod
        def suitable(url):
            return True

        def _real_extract(self, url):
            return {
                'id': 'test_id',
                'url': url,
                'ext': 'mp4',
                'title': 'test_title',
            }

    ie = TestIE(ydl)
    get_info_extractor('test_ie')(ydl, ie)

    # Create test

# Generated at 2022-06-22 07:09:05.510857
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    ie = YoutubeIE(params={})

# Generated at 2022-06-22 07:09:31.973007
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import youtube_dl
    ydl = youtube_dl.YoutubeDL(youtube_dl.params.parse())
    HlsFD(ydl, ydl.params)

# Generated at 2022-06-22 07:09:40.055331
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():

    from io import BytesIO
    from time import time
    from json import loads
    from os.path import isfile
    from hashlib import md5
    from shutil import rmtree
    from tempfile import mkdtemp
    from .external import FFmpegFD
    from .options import Options

    from ..utils import (
        encodeFilename,
        USER_AGENT,
    )

    from ..extractor.anvato import AnvatoIE
    from ..extractor.aol import AolIE
    from ..extractor.ooyala import OoyalaIE
    from ..extractor.wwe import WWEIE
    from ..extractor.twitch import TwitchIE
    from ..extractor.vimeo import VimeoIE
    from ..extractor.mgtv import MGTvIE


# Generated at 2022-06-22 07:09:52.001334
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import io
    import json
    import os
    import shutil
    import tempfile
    import unittest
    from contextlib import contextmanager
    from .test_fragment import (
        FakeYDL, FakeYDLUrlOpen, FakeYDLUrlRead, FakeInfoDict, FragFDTestCase,
        FakeInfoDict_frag_index, FakeInfoDict_frag_retries,
        FakeInfoDict_frag_skip_unavailable_fragments,
    )
    from ..compat import compat_str
    from ..extractor import get_info_extractor

    @contextmanager
    def make_temp_dir():
        temp_dir = tempfile.mkdtemp()
        try:
            yield temp_dir
        finally:
            shutil.rmtree(temp_dir)


# Generated at 2022-06-22 07:10:03.693817
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import get_info_extractor
    from ..options import OptionParser
    opt = OptionParser().parse()
    opt.test = True
    opt.quiet = True
    opt.debug_printtraffic = False
    opt.format = 'best'
    opt.hls_use_mpegts = False
    opt.simulate = True
    opt.no_overwrites = True
    opt.outtmpl = 'temp/outtmpl.%(id)s'
    opt.ignoreerrors = True
    opt.no_warnings = True
    opt.skip_download = True
    opt.nocheckcertificate = True
    opt.nopart = True

    ie = get_info_extractor('dummy', opt)
    ie._downloader = HlsFD(opt)

# Generated at 2022-06-22 07:10:15.609802
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # check_tests() will raise an exception if tests are not
    # available.  In that case we can't run the tests below
    # either.
    import os
    if not os.path.isfile('test/files/manifest.m3u8'):
        return False

    # Mock ydl object
    class MockYdl:
        def __init__(self):
            self.logger = lambda *args, **kw: None
            self.params = {
                'hls_prefer_native': True,
                'skip_unavailable_fragments': True,
                'test': False
            }
            self.get_logger = lambda name: self.logger
            self.report_warning = lambda *args, **kw: None

        def to_screen(self, *args, **kw):
            pass



# Generated at 2022-06-22 07:10:16.552385
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD(None, {})


# Generated at 2022-06-22 07:10:27.343291
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    import tempfile
    sys.path.insert(1, os.path.join(os.path.dirname(__file__), '..'))  # noqa
    sys.path.insert(1, os.path.join(os.path.dirname(__file__), '..', '..'))  # noqa
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import match_filter_func

    with YoutubeDL(params={'dumpym3u8': True}) as ydl:
        ydl.add_default_info_extractors()

        def test_yt(yt_url, file_format, expected_result):
            """Function to unit test downloader"""
            ydl.params['format'] = file_format

# Generated at 2022-06-22 07:10:39.166729
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import sys
    import os
    from .downloader import YoutubeDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urlparse

    def my_hook(d):
        if d['status'] == 'downloading':
            sys.stdout.write('\r\033[K')
            sys.stdout.write(d['_percent_str'])
            sys.stdout.flush()
        elif d['status'] == 'finished':
            print('')
    fd_name = os.path.splitext(os.path.basename(__file__))[0]

# Generated at 2022-06-22 07:10:51.030268
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    hls = HlsFD(None, {'fragment_retries': 0, 'skip_unavailable_fragments': False})

# Generated at 2022-06-22 07:11:01.553994
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class FakeInfoDict(dict):
        def __getitem__(self, key):
            if key == 'live':
                return False
            return dict.__getitem__(self, key)


# Generated at 2022-06-22 07:12:30.555994
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None, None)

# Generated at 2022-06-22 07:12:41.495054
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .extractor.common import InfoExtractor
    from ..compat import compat_struct_unpack, compat_urlparse

    # Mock downloader
    # and videosums.com's HLS link
    video_url = 'http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8'

# Generated at 2022-06-22 07:12:52.776142
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    """ Test for HlsFD.can_download() """

    class FakeInfoDict:
        def __init__(self, is_live, extra_param_to_segment_url, _decryption_key_url):
            self.is_live = is_live
            self.extra_param_to_segment_url = extra_param_to_segment_url
            self._decryption_key_url = _decryption_key_url

    fake_info_dict = FakeInfoDict(False, '', '')
    # we should support everything when ffmpeg is not used

# Generated at 2022-06-22 07:13:02.970139
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    try:
        from ..downloader.common import FileDownloader
        from ..extractor.common import InfoExtractor
        from ..compat import compat_urllib_request
    except:
        try:
            from youtube_dl.downloader.common import FileDownloader
            from youtube_dl.extractor.common import InfoExtractor
            from youtube_dl.compat import compat_urllib_request
        except:
            import sys
            sys.exit('Please run this test from inside the youtube_dl source folder!')

    def _http_req(self, *args, **kwargs):
        return compat_urllib_request.Request(*args, **kwargs)
