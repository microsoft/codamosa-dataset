

# Generated at 2022-06-22 07:03:29.308264
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Arrange
    manifest = '''#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:11\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:10.008,\n0.ts\n#EXTINF:10.009,\n1.ts\n#EXTINF:10.01,\n2.ts\n#EXTINF:10.01,\n3.ts\n#EXTINF:10.01,\n4.ts\n#EXTINF:10.01,\n5.ts\n#EXTINF:10.01,\n6.ts\n#EXT-X-KEY:METHOD=NONE\n#EXT-X-ENDLIST'''
    # Act
    can_down

# Generated at 2022-06-22 07:03:41.286457
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .common import get_testdata_files, setUpModule
    from ..utils import encodeFilename

    def unit_test_download_fragment_mock(ydl_obj, url, extra_info=None, headers=None):
        if url != 'http://example.com/fragment_with_key.ts':
            assert False, 'Fragment url is incorrect'
        assert extra_info != None, 'Fragment extra_info is none'
        extra_info['filename'] = encodeFilename(extra_info['filename'])
        key_url = extra_info.get('_decryption_key_url')
        if key_url:
            key_url += '/key_enc1.key'

# Generated at 2022-06-22 07:03:53.839288
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.http import HlsIE
    from ..downloader.common import FileDownloader

    url = 'http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8'
    fd = HlsFD(FileDownloader({}), {'outtmpl': 'test.mp4'})
    man_url = next(
        item['url']
        for item in HlsIE()._real_extract({'url': url})['formats']
        if item['format_id'] == 'hls-96k')
    info_dict = {'url': man_url, 'http_headers': {'Referer': 'http://www.apple.com/'}}
    res = fd.real_download('test.mp4', info_dict)
   

# Generated at 2022-06-22 07:03:54.969329
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from test import _common_test_hls as _common

# Generated at 2022-06-22 07:04:04.684088
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from . import _real_extract
    import tempfile

    # Test for live stream
    info_dict = {
        'url': 'http://hls-geo.daserste.de/i/videoportal/Film/c_620000/622873/format,716451,716457,716450,716458,716459,.mp4.csmil/master.m3u8',
        '_type': 'hls',
        'is_live': True,
        }
    actual = HlsFD.can_download(None, info_dict)
    assert actual == False

    # Test for live stream

# Generated at 2022-06-22 07:04:17.451908
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest

# Generated at 2022-06-22 07:04:29.767385
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .external import FFmpegFD
    from .common import FileDownloader
    from .extractor import gen_extractors
    from ..utils import match_filter_func
    youtube_dl_dir_path = os.path.dirname(os.path.abspath(__file__))
    loglevel = int(os.environ.get('YOUTUBEDL_TEST_LOGLEVEL', '0'))
    ydl_opts = {
        'quiet': loglevel,
        'skip_download': True,
        'simulate': True,
        'match_filter': match_filter_func('hlsnative,yes_hlsnative'),
        'test': True,
        'youtube_include_dash_manifest': True,
        'extractors': gen_extractors(),
    }

    dat

# Generated at 2022-06-22 07:04:43.692805
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """Basic unit tests for HlsFD"""
    def test_runHlsFD(url, can_download, test=False, **params):
        """Performs a run of HlsFD with url and params, checks if can_download is as expected"""
        ydl = YDL()
        ydl.params.update(params)
        info_dict = {'url': url, 'ext': 'mp4', 'http_headers': {}}
        get_fdfd = lambda params: HlsFD(ydl, params)
        result = run_ytdl_with_get_fdfd(ydl, get_fdfd, url, {}, test, True, fd_name='hlsnative')
        assert isinstance(result, bool)
        assert result is can_download
        return result


# Generated at 2022-06-22 07:04:55.697783
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .youtube import YoutubeIE
    ydl = YoutubeIE()
    info_dict = {'ie_key': 'Youtube'}

# Generated at 2022-06-22 07:05:05.899855
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import gen_extractors
    from .common import FileDownloader
    from .extractor import gen_extractor_classes
    for ie_result in gen_extractor_classes():
        ie = ie_result['ie']
        if ie.IE_NAME == 'hlsnative':
            # Test that HlsFD constructor doesn't raise an exception
            fd = ie(FileDownloader({'noprogress': True}))
            assert(fd.FD_NAME == 'hlsnative')
            return
    assert(False)

# Generated at 2022-06-22 07:05:30.850915
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:05:43.708622
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import unittest
    import tempfile


# Generated at 2022-06-22 07:05:55.741158
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .utils import fake_urlopen
    import collections

    def fake_urlopen_side_effect(r):
        class FakeUrl(object):
            def __init__(self, content):
                self.content = content

            @staticmethod
            def geturl():
                return ''

        if r == 'manifest':
            return FakeUrl('manifest')
        elif r == 'fallback':
            return FakeUrl('fallback')
        raise ValueError(r)

    # create a new FD object
    ydl = collections.namedtuple('YDL', ['params'])
    ydl.params = {}
    hls_fd = HlsFD(ydl, ydl.params)

    # mock urlopen
    urlopen_mock = fake_urlopen()
    urlopen_mock.side_effect = fake_

# Generated at 2022-06-22 07:06:02.079968
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from .extractor.generic import GenericIE
    from .postprocessor.ffmpeg import FFmpegPostProcessor
    from .postprocessor.xattrpp import XAttrMetadataPP
    from .postprocessor import PostProcessor
    import tempfile
    import shutil
    import random
    import string
    import os.path
    import hashlib
    import jsonschema

# Generated at 2022-06-22 07:06:05.801818
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert isinstance(HlsFD(DummyYDL(), {}), HlsFD)

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-22 07:06:17.492960
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .dash import DashFD
    from ..utils import make_HTTPServer
    from ..extractor.common import InfoExtractor
    from ..downloader.postprocessor import FFmpegMetadataPP
    from ..compat import urlparse

    class ydl(object):
        def __init__(self, send_frag):
            self.send_frag = send_frag
            self.params = {
                'test': True,
                'skip_unavailable_fragments': True,
                'keepvideo': True,
                'fragment_retries': 10,
            }

        def urlopen(self, url):
            return makeHTTPServer(self.send_frag)

        def to_screen(self, message):
            pass

        def to_stderr(self, message):
            pass


# Generated at 2022-06-22 07:06:29.632992
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .tests import get_testdata_file, get_test_data

    # HLS streams that HlsFD can download
    manifests_can_download = [
        'hls/manifest_mixed_segments.m3u8',
    ]

    # HLS streams that HlsFD cannot download

# Generated at 2022-06-22 07:06:38.891387
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors

    ytdl = gen_extractors()['youtube']("")

    # Test case 1: Unsupported features listed in class docstring
    is_supported = HlsFD.can_download(
        '#EXT-X-KEY:METHOD=SAMPLE-AES', ytdl.extract_info("", download=False))
    assert not is_supported

    is_supported = HlsFD.can_download(
        '#EXT-X-MEDIA-SEQUENCE:10', ytdl.extract_info("", download=False))
    assert not is_supported

    is_supported = HlsFD.can_download(
        '#EXT-X-PLAYLIST-TYPE:VOD', ytdl.extract_info("", download=False))
    assert not is_supported

# Generated at 2022-06-22 07:06:51.288341
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test.test_downloader import fake_urlopen

    lines = [
        '#EXTM3U',
        '#EXT-X-KEY:METHOD=AES-128,URI="https://test.test/test.key"',
        '#EXTINF:10,',
        'http://test.test/2.ts',
        '#EXTINF:10,',
        'http://test.test/3.ts',
        '#EXT-X-KEY:METHOD=NONE',
        '#EXTINF:10,',
        'http://test.test/4.ts',
        '#EXT-X-ENDLIST',
    ]

    manifest_url = 'https://test.test/test.m3u8'
    manifest_content = '\n'.join(lines)

    # With `test

# Generated at 2022-06-22 07:07:01.627237
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..downloader import YoutubeDL

    def test_can_download(url, features, result):
        ydl = YoutubeDL({'hls_use_mpegts': True})
        res = HlsFD.can_download(features, {
            'url': url,
            'http_headers': {},
            'player_url': None,
        })
        if res is True:
            res = 'YES'
        elif res is False:
            res = 'NO'
        else:
            res = 'N/A'
        assert result == res
    test_can_download('', '', 'YES')
    test_can_download('', '#EXT-X-KEY:METHOD=AES-128', 'YES')

# Generated at 2022-06-22 07:07:40.263269
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:07:46.426064
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.dash import DashIE
    from ..extractor.youtube import YoutubeIE

    _downloader = InfoExtractor(None)


# Generated at 2022-06-22 07:07:57.830490
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from . import InfoExtractor
    from .common import FileDownloader, extractor_for_url
    class MockInfoExtractor(InfoExtractor):
        IE_NAME = 'test_ie'
        _VALID_URL = r'https?://(?:www\.)?example\.com/%s'
        def __init__(self, ie_urls, ie_key=None):
            super(MockInfoExtractor, self).__init__()
            self._ies = ie_urls
            self._ie_key = ie_key
        def _real_initialize(self):
            pass
        def _real_extract(self, url):
            return {
                'id': self._ie_key,
                'url': url,
            }
        @classmethod
        def suitable(cls, url):
            return

# Generated at 2022-06-22 07:08:01.845108
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Sanity check for HlsFD constructor
    assert hasattr(HlsFD, '__init__')

# Generated at 2022-06-22 07:08:14.003360
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import Downloader
    from .options import Options

    # Test for a non-encrypted stream
    url1 = 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8'
    ydl_opts = {'hls_prefer_native': True, 'quiet': True, 'skip_download': True, 'simulate': True, 'forceurl': True, 'forcetitle': True, 'noplaylist': True}
    ydl = Downloader(ydl_opts)

    (ext, info) = ydl.extract_info(url1, download=True)
    (ext, info) = ydl.extract_info(url1, download=True)
    assert ext == 'm3u8'
    assert info['url']

# Generated at 2022-06-22 07:08:22.445544
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        from ytdl.YoutubeDL import YoutubeDL
        from ytdl.extractor import YoutubeIE
    except ImportError:
        from youtube_dl.YoutubeDL import YoutubeDL
        from youtube_dl.extractor import YoutubeIE
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    ie = YoutubeIE(ydl)
    assert ie.suitable(HlsFD.can_download, 'http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-22 07:08:31.857197
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    """Unit test for function HlsFD.can_download"""
    ydl = FakeYDL()
    ydl.params = {
        'noplaylist': True,
        'continuedl': True,
        'quiet': True,
        'simulate': True,
    }

    # 1.1.1.1
    manifest = """
#EXTM3U
#EXT-X-VERSION:6
    """
    info_dict = {}
    assert HlsFD.can_download(manifest, info_dict)

    # 1.1.1.2
    manifest = """
#EXTM3U
#EXT-X-VERSION:5
    """
    info_dict = {}
    assert HlsFD.can_download(manifest, info_dict)

    # 1.1.1.3

# Generated at 2022-06-22 07:08:42.234146
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor.common import InfoExtractor
    import youtube_dl

    class FakeIE(InfoExtractor):
        pass

    info = {'url': 'http://wwww.example.com/path/to/video.m3u8'}
    ie = FakeIE(youtube_dl.YoutubeDL(), {'preferredcodec': None})
    ie._downloader = youtube_dl.YoutubeDL(params={'preferredcodec': None})
    ie._downloader.cache.remove()

    fd = HlsFD(ie._downloader, ie.params)
    fd.real_download('unused', info)

# Generated at 2022-06-22 07:08:53.649368
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    from .common import SimpleTestCase

    class HlsFDDummyYDL(object):
        def report_warning(self, msg):
            pass

        def to_screen(self, msg):
            pass

        def trouble(self, msg, tb):
            pass

        def urlopen(self, url, data=None, headers=None):
            if url.endswith('manifest.m3u8'):
                return open('tests/testdata/manifest.m3u8', 'rb')
            if url.endswith('key.bin'):
                return open('tests/testdata/key.bin', 'rb')
            if url.endswith('seg-enc-1.ts'):
                return open('tests/testdata/seg-enc-1.ts', 'rb')
           

# Generated at 2022-06-22 07:08:55.116941
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('', {})
    HlsFD('', {})

# Generated at 2022-06-22 07:10:09.567117
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import sys
    import warnings
    if not can_decrypt_frag:
        return
    if sys.version_info < (3, 4):
        # Boring warning with old Python when importing this file
        warnings.filterwarnings('ignore', category=DeprecationWarning)
    from ..extractor.common import InfoExtractor
    from ..downloader.http import HttpFD
    from .fragment import FragmentFD

    class TestIE(InfoExtractor):
        def _real_extract(self, url):
            ie = self.tracker[url]['ie']
            info = ie.extract(url)
            fd = HttpFD(ie.ydl, ie.params)
            for ph in fd._progress_hooks:
                fd.remove_progress_hook(ph)

# Generated at 2022-06-22 07:10:12.578868
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import _run_test_real_download, _test_downloader
    _test_downloader(HlsFD, _run_test_real_download)


# Generated at 2022-06-22 07:10:14.598254
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hlsfd = HlsFD(None, None)


test_HlsFD()

# Generated at 2022-06-22 07:10:25.693449
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import yaml
    from .downloader import Downloader
    from .extractor import get_info_extractor

    class TestingDownloader(Downloader):
        def __init__(self, params):
            self.params = params
            self.params['default_search'] = 'auto'
            self.params['noprogress'] = True
            self.params['quiet'] = True
            self.params['simulate'] = True

    url_list = []

# Generated at 2022-06-22 07:10:35.199451
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import copy
    sys.path.append('../../')

    from youtube_dl.YoutubeDL import YoutubeDL
    sys.modules['pycryptodome'] = None

    ydl_opts = {
        'format': 'best',
        'outtmpl': '%(id)s.%(ext)s',
        'writesubtitles': True,
        'writeautomaticsub': True,
        'logger': YoutubeDL().logger,
        'quiet': False,
        'simulate': True,
        'skip_download': True,
        'writethumbnail': True,
    }


# Generated at 2022-06-22 07:10:37.172070
# Unit test for constructor of class HlsFD
def test_HlsFD():
    return HlsFD(None, {})

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-22 07:10:42.952059
# Unit test for constructor of class HlsFD
def test_HlsFD():
    """
      Test description: Test HlsFD constructor
    """
    from .test import get_test_suite
    test_suite = get_test_suite()
    video_info = test_suite.get_video_info()
    hls_fd = HlsFD(video_info)

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-22 07:10:54.382728
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """ Unit test for method real_download of class HlsFD """
    from ..extractor import YoutubeDL
    from .http import HttpFD
    import os

    YDL = YoutubeDL({ 'simulate': True })
    # Set to True to show HTTP requests and responses
    YDL.params['verbose'] = False
    YDL.params['dump_intermediate_pages'] = False

    def _http_fetch(url):
        # Intercept the downloaded fragments
        YDL.params['test'] = True
        YDL.params['nooverwrites'] = True
        with open('test.ts', 'wb') as test_fh:
            # Set to True to show the HTTP requests and responses
            HTTP_FD = HttpFD(YDL, { 'verbose': False })
            # Set to True to to show the progress bar


# Generated at 2022-06-22 07:11:02.009989
# Unit test for constructor of class HlsFD
def test_HlsFD():
    url = 'http://test.com'
    ydl = {'urlopen': lambda *args: {'geturl': url}}
    params = {'ydl': ydl, 'extra_param_to_segment_url': 'foo=bar'}
    hls_fd = HlsFD(params, params)
    assert hls_fd.params['ydl'] == ydl
    assert hls_fd.url == url
    assert hls_fd.extra_query == {'foo': 'bar'}

# Generated at 2022-06-22 07:11:12.626721
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import types

    hlsfd = HlsFD(None, {'hls_prefer_native': True})
    assert hasattr(HlsFD, "can_download") and hasattr(hlsfd.can_download, "__call__")
    assert hlsfd.can_download is not types.MethodType(HlsFD.can_download, hlsfd)
    # Using hlsnative