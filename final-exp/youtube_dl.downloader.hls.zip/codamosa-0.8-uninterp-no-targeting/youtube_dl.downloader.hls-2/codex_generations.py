

# Generated at 2022-06-22 07:03:42.452844
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def check_feature(content, info_dict, expected_result):
        """
        Check if HlsFD method can_download() works as expected
        """
        # info_dict parameters are the same as in extractor_download() of YoutubeDL
        assert HlsFD.can_download(content, info_dict) == expected_result

    info_dict = {
        'url': 'http://example.com/'
    }

    # Test encrypted streams
    # ----------------------------------------
    # Method is not AES-128
    check_feature('#EXT-X-KEY:METHOD=AES', info_dict, False)
    check_feature('#EXT-X-KEY:METHOD=SAMPLE-AES', info_dict, False)

    # Test live streams
    # ----------------------------------------
    info_dict['is_live'] = True
    check_

# Generated at 2022-06-22 07:03:54.363480
# Unit test for constructor of class HlsFD
def test_HlsFD():
    "Unit test for HlsFD"
    import sys
    import json
    import time
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL(
        {'simulate': True, 'quiet': True, 'format': 'best', 'noplaylist': True})
    ydl.add_info_extractor(HlsFD)

    def assert_correct_info(ydl):
        assert "hlsnative" in ydl.extractors, "HlsFD must be in extractors"
        assert "hls" in ydl.extractors, "HlsFD must be in extractors"
        assert "hls" in ydl.extractor_descriptions, "HlsFD must be in extractors description"

# Generated at 2022-06-22 07:04:03.263087
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..utils import determine_ext
    from ..cache import DiskCache
    from .dash import DASHFD
    from .fragment import frag_cache
    from .external import F4MFD, YoutubeDL
    from urllib.parse import urlparse, parse_qs
    import os
    import time

    # The URL for the m3u8 playlist used for testing
    M3U8_PLAYLIST_URL = 'https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8'
    # The URL for the video fragment used in the playlist URL

# Generated at 2022-06-22 07:04:15.414427
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class Options:
        fragment_retries = 0
    class YDL:
        class params:
            fragment_retries = 0
    ydl = YDL()
    ydl.params = Options()
    fd = HlsFD(ydl, ydl.params)


# Generated at 2022-06-22 07:04:27.806546
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import mimetypes
    import shutil
    from ..utils import encode_compat_str

    # create directory with test files
    tmp_dir = tempfile.mkdtemp()

    tmp_file = os.path.join(tmp_dir, 'test_file')
    example_data = b'foobar'
    with open(tmp_file, 'wb') as f:
        f.write(example_data)

    # create a m3u8 file for test_file

# Generated at 2022-06-22 07:04:35.627603
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:04:47.623497
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    manifest = (
        b'#EXTM3U\n'
        b'#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=500000,CODECS="foo,bar"\n'
        b'http://example.com/media.m3u8\n'
    )

    # stream is live
    info_dict = {}
    info_dict['is_live'] = True

    assert not HlsFD.can_download(manifest, info_dict)

    # stream is not live
    info_dict['is_live'] = False

    assert HlsFD.can_download(manifest, info_dict)

    # stream is not live but method is not none or aes-128

# Generated at 2022-06-22 07:04:58.525104
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:05:09.972101
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .downloader import YoutubeDL
    from .extractor import get_info_extractor
    from .postprocessor import run_postprocessors
    dl = YoutubeDL({})
    ie = get_info_extractor('https://www.youtube.com/watch?v=0t5Y_HVd5fE')
    info = ie._real_extract(dl, '0t5Y_HVd5fE')
    hls_url = info['url']
    hls_fd = HlsFD(dl, {'test': True})
    hls_fd.real_download(None, {'url': hls_url, 'info_dict': info})

# Generated at 2022-06-22 07:05:21.777811
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .common import FakeYDL
    import os.path
    import sys
    import unittest

    try:
        from Crypto.Cipher import AES
    except ImportError:
        print('Crypto.Cipher.AES not found, skipping HlsFD.can_download tests')
        return

    def get_playlist_path(playlist):
        return os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'hls_fds', 'can_download', playlist)

    class HlsFdCanDownloadTest(unittest.TestCase):
        def setUp(self):
            self.ydl = FakeYDL()
            self.hfd = HlsFD(self.ydl, {'test': True})


# Generated at 2022-06-22 07:05:48.575439
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    info_dict = {}

    # "master playlist" with multiple alternate streams (Apple HLS example)

# Generated at 2022-06-22 07:05:59.517875
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .fd import _download_webpage, _write_annotations, _write_video_id
    from ..compat import compat_urlparse, compat_str, compat_urllib_error
    from ..utils import encode_data_uri

    import os
    import shutil
    import tempfile

    import json
    import re
    import uuid
    import unittest
    import urllib.request
    import urllib.parse

    class TestHlsFD(unittest.TestCase):
        def test_HlsFD(self):
            def new_urlopen(request):
                args = request.get_full_url().split('/')[3:]

# Generated at 2022-06-22 07:06:11.207705
# Unit test for constructor of class HlsFD
def test_HlsFD():
    manifest = '#EXTM3U\n' + \
               '#EXT-X-VERSION:3\n' + \
               '#EXT-X-TARGETDURATION:10\n' + \
               '#EXT-X-MEDIA-SEQUENCE:1\n' + \
               '#EXT-X-KEY:METHOD=NONE\n' + \
               '#EXTINF:10.000,\n' + \
               'http://example.com/fileSequence1.ts\n' + \
               '#EXTINF:10.000,\n' + \
               'http://example.com/fileSequence2.ts\n' + \
               '#EXTINF:10.000,\n' + \
               'http://example.com/fileSequence3.ts\n'

# Generated at 2022-06-22 07:06:21.372587
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import os.path
    import StringIO
    import tempfile
    import shutil
    import json
    import subprocess
    import urllib2
    from contextlib import closing

    from .external import FFmpegFD

    sys.path.insert(0, os.path.abspath(os.path.join(os.pardir, 'tests')))
    from test_utils import (
        FakeYDL, FakeLogger, FakeFD, CookieTestCase, EXPECTED_FORMATS,
        add_ns, add_params, set_dirs_to_none,
        remove_dirs, list_dir, get_default_args,
    )
    sys.path.pop(0)


# Generated at 2022-06-22 07:06:24.974411
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import pytest
    import tempfile
    with tempfile.NamedTemporaryFile() as f:
        with pytest.raises(ValueError):
            HlsFD.can_download(f.name, None)

# Generated at 2022-06-22 07:06:32.992764
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from collections import namedtuple
    from .test import MyYDL
    from .downloader import YoutubeDL
    TestCase = namedtuple('TestCase', ['manifest', 'expected_can_download'])

# Generated at 2022-06-22 07:06:45.760975
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Has a decryption key
    assert HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-KEY:METHOD=AES-128,URI="https://key",IV=0xabcdefabcdefabcdefabcdefabcdefab\n',
        {'is_live': False})
    # Is live with a non-zero media sequence
    assert not HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-MEDIA-SEQUENCE:10\n',
        {'is_live': True})
    # Is live with an event type

# Generated at 2022-06-22 07:06:55.477185
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .__main__ import parseOpts
    from .common import FileDownloader
    ydl = FileDownloader(parseOpts())

    is_aes128_enc = '#EXT-X-KEY:METHOD=AES-128'
    is_byterange = '#EXT-X-BYTERANGE'
    is_live = '#EXT-X-MEDIA-SEQUENCE:(?!0$)'
    can_be_appended = '#EXT-X-PLAYLIST-TYPE:EVENT'
    has_map = '#EXT-X-MAP:'

    manifest = '#EXTM3U\n#EXT-X-VERSION:4\n'
    assert HlsFD.can_download(manifest, {})


# Generated at 2022-06-22 07:07:03.531182
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .external import FFmpegFD

    class FakeDict:
        pass
    fake_info_dict = FakeDict()
    fake_info_dict.is_live = False
    fake_info_dict.extra_param_to_segment_url = ''
    fake_info_dict._decryption_key_url = ''

# Generated at 2022-06-22 07:07:16.341964
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from . import test_util as U
    from . import Opts


# Generated at 2022-06-22 07:07:54.683312
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.http import HttpFD
    import tempfile
    import shutil
    import os
    import json

    def _test_real_download(params):
        ydl = youtube_dl.YoutubeDL(params)
        dest_dir = tempfile.mkdtemp(prefix='youtube-dl-test-hlsnative-')

# Generated at 2022-06-22 07:08:05.647580
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .extractor import YoutubeDL
    from .utils import _build_default_extractor_list
    ydl = YoutubeDL(_build_default_extractor_list())
    methods = []
    for m in (can_download for can_download in globals().values() if hasattr(can_download, '__call__')):
        if m.__code__.co_argcount > 0:
            methods.append(m)
    assert HlsFD.can_download in methods

    assert not HlsFD.can_download('', {})
    assert HlsFD.can_download('#EXTM3U', {})
    assert not HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=SAMPLE-AES', {})

# Generated at 2022-06-22 07:08:16.986501
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .external import ExternalFD
    from ..utils import (
        match_filter_func,
        sanitize_open,
    )
    from ..compat import (
        compat_str,
    )
    from io import BytesIO
    from ..downloader.common import FileDownloader
    from .common import (
        parseOpts,
        setUpFD,
    )
    from .utils import (
        make_HTTPServer,
    )
    from ..compat import (
        compat_urlopen,
    )
    from ..postprocessor.ffmpeg import FFmpegPostProcessor
    mp4_len = 1024
    mp4_content = compat_str(bytearray(x % 2 for x in range(mp4_len)))

# Generated at 2022-06-22 07:08:28.123375
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import FakeYDL
    from ..extractor import gen_extractors
    from ..compat import is_win32
    from ..utils import get_cachedir, get_temp_filename

    class Context(object):
        pass

    downloader = FakeYDL()
    downloader.params = {'skip_download': True}
    downloader.add_info_extractor(gen_extractors(downloader, None, None)[0])
    # HlsFD is the last extractor in gen_extractors
    # Return the last extractor in gen_extractors
    hlsfd = downloader.get_info_extractor(
        gen_extractors(downloader, None, None)[-1].IE_NAME)


# Generated at 2022-06-22 07:08:36.275733
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        from Crypto.Cipher import AES
    except ImportError:
        print("Crypto.Cipher is missing")
        return
    from .external import FFmpegFD
    from .http import HttpFD
    from .http import HttpsFD
    from .http import HttpIE
    from .http import HttpsIE
    from .http import HttpPD
    from .http import HttpsPD
    from .http import HttpS
    from .http import HttpsS
    from .http import HttpSE
    from .http import HttpsSE

    from ..extractor import gen_extractors

    from ..utils import (
        parse_m3u8_attributes,
        update_url_query,
    )

    ydl = gen_extractors()[0].ydl
    ydl

# Generated at 2022-06-22 07:08:48.894220
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest

    from .test_fragment import TestFragmentFD

    class TestHlsFD(TestFragmentFD):
        def _get_test_suite(self):
            class HlsFDTestCase(TestFragmentFD.FragmentFDTestCase):
                def setUp(self):
                    self.test_filename = self.get_test_filename('testvideo.ts')
                    self.test_manifest = self.get_test_filename('testmanifest.m3u8')
                    self.test_manifest_url = self.get_test_url('testmanifest.m3u8')
                    self.test_fragment_url = self.get_test_url('testvideo1.ts')


# Generated at 2022-06-22 07:08:59.396990
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import os.path
    import tempfile
    import sys
    import shutil
    import urllib.request
    from ytdl.FileDownloader import FileDownloader

    def hls_fd_real_download(info_dict, manifest):
        hlsfd = HlsFD(FileDownloader({'outtmpl': os.devnull}), None)
        hlsfd.to_screen = lambda *args, **kargs: None
        hlsfd.report_error = lambda *args, **kargs: None
        hlsfd.add_progress_hook = lambda *args, **kargs: None
        hlsfd.report_skip_fragment = lambda *args, **kargs: None
        hlsfd.report_retry_fragment = lambda *args, **kargs: None


# Generated at 2022-06-22 07:09:11.950555
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import re
    from ..utils import unified_strdate

    def fail():
        return 'somethings is wrong'

    # Test for m3u8 v4 playlists that do not contain decryption key url
    from .extractor.francetv import FranceTvInfoExtractor
    test_extractor = FranceTvInfoExtractor(FranceTvInfoExtractor._build_url_result('', ''))

# Generated at 2022-06-22 07:09:22.786540
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.utils import determine_ext
    from .common import FileDownloader
    from .external import ExternalFD
    from .fragment import FragmentFD
    file_downloader = FileDownloader({
        'format': '720p',
        'outtmpl': 'test_%(ext)s',
        'quiet': True,
        'nocheckcertificate': True,
        'noprogress': True,
        'test': True,
        'forcefileextension': True,
    })

    # Case 1: audio only

# Generated at 2022-06-22 07:09:33.209277
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:10:33.686428
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    # pylint: disable=too-many-locals

    import subprocess
    import unittest
    import xml.etree.ElementTree as ET

    from . import YoutubeDL
    from .common import InfoExtractor
    from .compat import (
        compat_urllib_request,
        compat_http_client,
    )

    (major, minor) = sys.version_info[0:2]
    if major < 3 or (major == 3 and minor < 3):
        raise unittest.SkipTest('Requires Python 3.3 or above.')

    # Workaround for #27660: only download the first fragment during the test.
    class TestHlsFD(HlsFD):
        def _download_fragment(self, ctx, frag_url, info_dict, headers):
            return super

# Generated at 2022-06-22 07:10:45.546282
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os.path

    import mock
    import pytest

    sys.modules['Crypto'] = mock.Mock()
    sys.modules['Crypto.Cipher'] = mock.Mock()
    sys.modules['Crypto.Cipher.AES'] = mock.Mock()
    from .hls_fd import HlsFD

    # This test is base on two inputs:
    # - playlist file (in folder test_data/ad_fragments)
    # - decrypt file if encrypted (in folder test_data/ad_fragments)

# Generated at 2022-06-22 07:10:55.105761
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def check_results(m3u8_content, info_dict, exp_return):
        hls_fd = HlsFD(None, None)
        return hls_fd.can_download(m3u8_content, info_dict) == exp_return

    assert check_results('', {}, True)
    assert check_results('#EXT-X-KEY:METHOD=AES-128', {}, True)
    assert check_results('#', {}, True)

    assert check_results('#EXT-X-KEY:METHOD=AES-128', { 'is_live': True }, False)

    assert check_results('#EXT-X-KEY:METHOD=NONE', {}, True)
    assert check_results('#EXT-X-KEY:METHOD=DES', {}, False)

# Generated at 2022-06-22 07:10:56.787831
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.__name__ == "HlsFD"

# Generated at 2022-06-22 07:11:01.650063
# Unit test for constructor of class HlsFD
def test_HlsFD():
    test_dict = {
        'url': '0.ts',
        'format': 'ts',
        'http_headers': {},
        'manifest_url': '0.ts',
    }
    hlsFD = HlsFD.can_download('', test_dict)
    assert hlsFD != False

# Generated at 2022-06-22 07:11:12.375065
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testdata_file

    from ..extractor import YoutubeIE
    from ..utils import (
        encode_compat_str,
        prepend_extension,
    )

    def get_result_data(downloaded_file):
        with open(downloaded_file, 'rb') as f:
            data = f.read()
        return data


# Generated at 2022-06-22 07:11:23.658229
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..cache import Cache
    import os
    import os.path
    cache = Cache('.tmp')
    if not os.path.exists(cache.basedir):
        os.makedirs(cache.basedir)
    fh_manifest_bad = cache.store('_manifest_bad', '#EXTM3U\n#EXT-X-KEY:METHOD=NONE\n')
    fh_manifest_ok = cache.store('_manifest_ok', '#EXTM3U\n#EXT-X-KEY:METHOD=NONE\nhttp://test/')
    result = HlsFD.can_download(cache.load(fh_manifest_bad), {'url': 'http://test/'})
    assert result == False

# Generated at 2022-06-22 07:11:35.135221
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import youtube_dl.YoutubeDL
    import os
    import shutil
    import hashlib
    import tempfile

    ydl = youtube_dl.YoutubeDL({'outtmpl': '%(id)s', 'quiet':True, 'format':'best'})
    # create a temporary directory and cd into that directory
    tmpdir = tempfile.mkdtemp(prefix='ytdl_')
    curdir = os.getcwd()
    os.chdir(tmpdir)
    # run the test
    expected_hash = '8b9d0ece1ec92b2377f038ea4e304f4b'

# Generated at 2022-06-22 07:11:47.050946
# Unit test for constructor of class HlsFD

# Generated at 2022-06-22 07:11:54.180593
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import get_testdata_file

    def run_test(ytdl, filename, expected_filename, expected_fragments_count, expected_fragments_ad_count, params=None):
        ytdl.params.update(params or {})
        test_filename = get_testdata_file(filename, 'dl_test')
        manifest = open(test_filename, 'rb').read().decode('utf-8')
        info_dict = {
            'url': 'https://FOO_STREAM_URL',
            'ext': 'fmp4',
            'http_headers': {},
            'is_live': False,
        }

        fd = HlsFD(ytdl, params)
        fd.real_download(get_testdata_file(expected_filename), info_dict)