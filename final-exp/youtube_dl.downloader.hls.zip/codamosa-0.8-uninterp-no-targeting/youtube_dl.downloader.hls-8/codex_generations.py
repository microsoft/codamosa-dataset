

# Generated at 2022-06-22 07:03:21.817858
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls_fd = HlsFD(None, None)
    assert hls_fd is not None

# Generated at 2022-06-22 07:03:28.490812
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import gen_extractors
    # Open builtin youtube-dl extractors list
    for ie in gen_extractors():
        # Only extractors listed in ie_key are used
        ie_key = ie.IE_NAME.lower()
        if ie_key in ['hlsnative', 'hls', 'httpdashsegments']:
            #print('Extractor %s' % ie_key)
            # Download the manifest
            man_url = 'https://video-dev.github.io/streams/x36xhzz/x36xhzz.m3u8'
            urlh = ie._download_webpage(man_url, None, 'Downloading m3u8 manifest')
            man_url = urlh.geturl()
            # Open and read the file
            s = urlh.open().read

# Generated at 2022-06-22 07:03:40.833545
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    func_ = HlsFD.can_download

# Generated at 2022-06-22 07:03:41.373980
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD

# Generated at 2022-06-22 07:03:53.958908
# Unit test for constructor of class HlsFD
def test_HlsFD():
    h = HlsFD({})
    assert h.FD_NAME == 'hlsnative'
    assert h.can_download('', {'url':'http://example.com/index.m3u8'})
    assert not h.can_download('', {'url':'http://example.com/index.m3u8', 'is_live': True})
    assert h.can_download('', {'url':'http://example.com/index.m3u8',})
    assert not h.can_download('#EXT-X-KEY:METHOD=FOO', {'url':'http://example.com/index.m3u8'})
    assert h.can_download('#EXT-X-KEY:METHOD=AES-128', {'url':'http://example.com/index.m3u8'})

# Generated at 2022-06-22 07:04:04.064425
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..downloader import YoutubeDL
    from .dashsegments import DashSegmentsFD
    from .m3u8 import M3U8FD
    ydl = YoutubeDL({})

    class MockInfoDict(object):
        @property
        def get(self):
            return {
                'url': r'http://www.example.com/video.m3u8',
                'is_live': False,
                'http_headers': {'Foo': 'bar'},
            }.get

    class MockManifest(object):
        def __init__(self, fragment_size):
            self.fragment_size = fragment_size

        def __len__(self):
            return self.fragment_size * 2
    manifest = MockManifest(8192)

    info_dict = MockInfoDict()


# Generated at 2022-06-22 07:04:14.407273
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Note: In this test it is assumed that the frag_downloader attribute
    # is of type HlsFD. This is a safe assumption if HlsFD is the only
    # supported non-ffmpeg downloader and the ext attribute has been set
    # correctly (see YoutubeDL.process_ie_result).
    ie = YoutubeDL(params={'fragment_retries': 0})
    ie.process_IE([
        {
            '_type': 'url',
            'url': 'https://example.com/manifest.m3u8',
            'ie_key': 'HlsNative',
            'ext': 'mp4',
        },
    ])
    frag_downloader = ie._ies[0].frag_downloader
    # The following assertions are based on the source code comments of
    # HlsFD.can_download

# Generated at 2022-06-22 07:04:26.753943
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:04:28.645765
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Constructor of class HlsFD
    HlsFD(None, None)


# Generated at 2022-06-22 07:04:42.616006
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .utils import FakeYDL
    from .downloader import ExternalFD

    ydl = FakeYDL()
    ydl.params['hls_use_mpegts'] = True
    fd = HlsFD(ydl)
    assert isinstance(fd, HlsFD)
    assert fd.use_mpegts
    ydl.params['hls_use_mpegts'] = False
    fd = HlsFD(ydl)
    assert isinstance(fd, HlsFD)
    assert not fd.use_mpegts
    ydl.params.pop('hls_use_mpegts')
    fd = HlsFD(ydl)
    assert isinstance(fd, HlsFD)
    assert not fd.use_mpegts

    assert HlsFD.can_download('', {})

# Generated at 2022-06-22 07:05:06.084841
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Values for run test
    import pytest
    def can_download(url, expected):
        # Get test URL
        import os
        test_path = os.path.join(
            os.path.dirname(os.path.realpath(__file__)),
            'data',
            url)
        with open(test_path, 'r') as f:
            content = f.read()
        # Test can_download method
        assert HlsFD.can_download(content, {}) == expected

    # Test with a non-encrypted playlist that is not a live stream.
    can_download('hls_sample_playlist.m3u8', True)

    # Test with a non-encrypted playlist that is a live stream.
    can_download('m3u8_live_stream.m3u8', False)

   

# Generated at 2022-06-22 07:05:16.580804
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor import get_info_extractor

    def _can_download(url, ie_key, expected_result):
        info_dict = get_info_extractor(ie_key)({})._real_extract(url)
        if info_dict.get('is_live'):
            return
        info_dict['url'] = info_dict['url'] + '?test'
        assert HlsFD.can_download(info_dict['url'], info_dict) == expected_result

    # YouTube videos
    _can_download('https://www.youtube.com/watch?v=0KYI_YdYiOA', 'youtube', False)
    _can_download('https://www.youtube.com/watch?v=0KYI_YdYiOA', 'youtube:live', True)

    #

# Generated at 2022-06-22 07:05:28.252809
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download('#EXTM3U\n', {})
    assert not HlsFD.can_download(
        '#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {})
    assert not HlsFD.can_download(
        '#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\n#EXT-X-BYTERANGE:1000@0', {})
    assert not HlsFD.can_download(
        '#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:0', {'is_live': True})
    assert not HlsFD.can_download(
        '#EXTM3U\n#EXT-X-PLAYLIST-TYPE:EVENT', {})

# Generated at 2022-06-22 07:05:30.506336
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import gen_extractors, list_extractors
    return gen_extractors(list_extractors())['hlsnative'] != HlsFD

# Generated at 2022-06-22 07:05:43.240667
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os.path
    import json
    import random

    # Get the absolute path of test directory
    test_dir = os.path.dirname(os.path.realpath(__file__))

    # Load test hls manifests
    test_hls_manifests = []
    with open(os.path.join(test_dir, 'test_hls_manifests.json'), 'r') as f:
        test_hls_manifests = json.load(f)

    # Generate a random test youtube url
    test_yt_url = 'https://youtube.com/watch?v=%s' % ''.join(
        random.choice('0123456789ABCDEF') for i in range(0, 11))

    # Test if can_download returns the expected result

# Generated at 2022-06-22 07:05:49.666842
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import io
    import tempfile
    import unittest

    import youtube_dl.extractor.common as common
    from youtube_dl.YoutubeDL import YoutubeDL

    def build_info_dict(playlist_url, extra_param_to_segment_url=None, **kwargs):
        info_dict = {
            'url': playlist_url,
            'id': 'video_id',
            'title': 'video_title',
            'ext': 'mp4',
            'duration': 20,
            'http_headers': {'User-Agent': 'youtube-dl test'},
            '_type': 'hls',
            'extractor': 'dummy',
            'playlist': playlist_url,
            'playlist_index': 0,
        }

# Generated at 2022-06-22 07:06:00.137370
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Can download AES-128 method NONE key format
    from ..extractor import HlsPlaylistIE
    assert HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-VERSION:3\n'
        '#EXT-X-TARGETDURATION:11\n'
        '#EXT-X-MEDIA-SEQUENCE:0\n'
        '#EXTINF:11,\n'
        'fileSequence0.ts\n'
        '#EXT-X-ENDLIST\n',
        {'protocol': 'm3u8_native', 'url': '', '_type': 'url'},
        None,
        HlsPlaylistIE
    )
    # Cannot download AES-128 method NONE key format because URL is not absolute

# Generated at 2022-06-22 07:06:02.883968
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hlsfd = HlsFD(None)
    assert hlsfd is not None

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-22 07:06:15.554045
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.youtube import YoutubeIE
    from ..downloader import Downloader
    from ..utils import encode_data_uri
    dl = Downloader()
    ie = YoutubeIE(dl)

# Generated at 2022-06-22 07:06:18.518388
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD(None, None)._progress_hooks == []
    assert HlsFD(None, None)._downloader == None
    assert HlsFD(None, None)._params == None
    assert HlsFD(None, None)._tmpfilename == None


# Generated at 2022-06-22 07:06:51.396804
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest

    class HlsFDTest(unittest.TestCase):
        def setUp(self):
            self.HlsFD = HlsFD({})

        def test_can_download_all_features(self):
            manifest = '#EXTM3U\n' \
                       '#EXT-X-TARGETDURATION:10\n' \
                       '#EXT-X-VERSION:3\n' \
                       '#EXT-X-MEDIA-SEQUENCE:0\n' \
                       '#EXT-X-PLAYLIST-TYPE:VOD\n' \
                       '#EXTINF:10,\n' \
                       'https://example.org/video/000.ts\n' \
                       '#EXT-X-ENDLIST'


# Generated at 2022-06-22 07:07:01.715840
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.generic import YoutubeIE
    from ..utils import ExtractorError
    import io
    import sys
    import unittest
    import warnings

    class MockYDL(object):
        def urlopen(self, url):
            return io.BytesIO(b'A' * 1024)
        def to_screen(self, message, *args):
            print(message % args)
        def trouble(self, message, tb=None):
            raise ExtractorError(message)
        def report_warning(self, message):
            warnings.warn(message)
        def report_error(self, message):
            self.trouble(message)

    class MockInfoDict(object):
        def __init__(self, *args, **kwargs):
            self.__dict__.update(kwargs)


# Generated at 2022-06-22 07:07:14.500642
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import os
    import sys
    import tempfile
    tmp_mdir = tempfile.mkdtemp()

# Generated at 2022-06-22 07:07:19.436300
# Unit test for constructor of class HlsFD
def test_HlsFD():
    fd = HlsFD(None, {
            'fragment_retries': 3,
            'skip_unavailable_fragments': True,
            'test': True,
        })

if __name__ == "__main__":
    test_HlsFD()

# Generated at 2022-06-22 07:07:31.028798
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        import Crypto.Cipher
    except ImportError:
        return
    urlh = open_for_test('test_HlsFD.m3u8')
    s = 'http://test.com/test.m3u8'
    m3u8_url = urlh.geturl()
    s_m3u8 = urlh.read().decode('utf-8', 'ignore')
    info_dict = {'url': s, 'http_headers': {}}
    fd = HlsFD(None, {})

    assert fd.can_download(s_m3u8, info_dict)
    assert fd.real_download('test_HlsFD.ts', info_dict)

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-22 07:07:40.730845
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # We don't want to download any real fragment
    class DummyHlsFD(HlsFD):
        def real_download(self, filename, info_dict):
            return False

    # We don't want to verify ssl certificates for testing purpose
    def urlopen_noverifycert(url):
        import ssl
        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE
        return compat_urllib_request.urlopen(url, context=ssl_context)

    # We don't want to use socket.create_connection as it is not provided in
    # Jython
    def create_connection(address, timeout=None, source_address=None):
        host, port = address


# Generated at 2022-06-22 07:07:41.797517
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    HlsFD.real_download("test","test")

# Generated at 2022-06-22 07:07:54.681358
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .utils import make_progress_hook
    from .downloader import YoutubeDL
    from .extractor import get_info_extractor


# Generated at 2022-06-22 07:08:05.647885
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import YoutubeIE
    from ..utils import get_case_insensitive_regexp_match

    url = 'https://example.com/video.m3u8'

# Generated at 2022-06-22 07:08:12.091673
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD('https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
          {'http_chunk_size': '1048576', 'http_headers': {'User-Agent': 'python-requests/2.9.1'},
           'fragment_retries': '10',
           'skip_unavailable_fragments': 'yes'})



# Generated at 2022-06-22 07:08:49.866429
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.generic import FakeYDL
    import os
    import sys
    import tempfile
    from .external import ExternalFD
    from .ffmpegmux import FFmpegMuxFD
    from .fragment import FragmentFD
    from .http import HttpFD

    _, manifest_file = tempfile.mkstemp()
    with open(manifest_file, 'w') as manifest:
        manifest.write('#EXTM3U\n')
        manifest.write('#EXT-X-MEDIA-SEQUENCE:0\n')
        manifest.write('#EXT-X-TARGETDURATION:10\n')
        manifest.write('#EXTINF:10\n')
        manifest.write('http://example.org/seg1.ts\n')

# Generated at 2022-06-22 07:09:00.030264
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .helpers import _FakeYDL, _FakeInfoDict, _FakeUrlOpen
    from .common import fake_args, check_mpd_download, check_mpd_content
    import os

    # Get the test data directory
    test_dir = os.path.dirname(os.path.abspath(__file__))
    hls_mpd_file = os.path.join(test_dir, 'hls_mpd_files', 'master.m3u8')

    # Check example m3u8 file
    ydl = _FakeYDL()
    args = fake_args([hls_mpd_file], {
        'hls_use_mpegts': False,
        'prefer_insecure': False,
        'test': True,
    })
    info_dict = _FakeInfoD

# Generated at 2022-06-22 07:09:12.673578
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .extractor.common import InfoExtractor
    from .downloader.common import FileDownloader
    from .compat import compat_str
    from .utils import sanitize_open
    from io import BytesIO
    testdata_dir = os.path.join(os.path.dirname(__file__), 'test', 'data')
    class InfoExtractorFake(InfoExtractor):
        def _real_extract(self, url):
            key_url = compat_urlparse.urljoin(url, 'ytdl_key')
            ytdl_headers = {'Cookie': 'ytdl_cookie=test'}

# Generated at 2022-06-22 07:09:22.630838
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import tempfile
    import os
    import shutil
    import io
    import base64
    import json
    import hashlib
    import string

    def gen_random_string(length):
        return ''.join(random.SystemRandom().choice(string.ascii_letters) for _ in range(length))

    def save_test_json(test_json_dir, test_json_data):
        with open(os.path.join(
                test_json_dir, 'test_HlsFD_real_download.json'), 'w') as f:
            json.dump(test_json_data, f, indent=2, sort_keys=True, ensure_ascii=False)



# Generated at 2022-06-22 07:09:33.117276
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..tests.test_download import TestDownload
    from ..downloader.common import FileDownloader
    from ..config import readOptions
    from ..utils import encode_data_uri

    # Run the real_download method of class HlsFD
    # on a m3u8 manifest containing one media fragment
    fd = HlsFD(FileDownloader({}))
    res = fd._do_real_download(TestDownload(), encode_data_uri('''
        #EXTM3U
        #EXT-X-VERSION:3
        #EXT-X-MEDIA-SEQUENCE:0
        #EXT-X-TARGETDURATION:5
        #EXTINF:5.0,
        /media/media.ts
        #EXT-X-ENDLIST
    '''))

    assert res == True

    # Run the

# Generated at 2022-06-22 07:09:43.518855
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # more unit tests included in the test_FragmentFD class
    from ..downloader import YoutubeDL
    import tempfile
    tmp = tempfile.NamedTemporaryFile()
    ydl = YoutubeDL(params={'logger': None, 'continuedl': True})
    hlsfd = HlsFD(ydl, {'test': True})
    info = {'manifest_url': 'https://mnmedias.api.telequebec.tv/m3u8/29880.m3u8'}
    # Download should succeed without an ffmpeg warning
    assert hlsfd.real_download(tmp.name, info)

# Generated at 2022-06-22 07:09:55.332369
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .extractor.hls import Hls82IE
    from .extractor.generic import GenericIE
    from .extractor.youtube import YoutubeIE
    from .downloader import YoutubeDL

    class FakeInfoDict(dict):
        pass

    url = 'https://www.youtube.com/watch?v=PxXgav5QVmc&list=PLd7cHg56qMk8Vq3ypjyD7HxrdMYR1C8nN'
    list_id = 'PLd7cHg56qMk8Vq3ypjyD7HxrdMYR1C8nN'
    webpage = YoutubeDL().urlopen(url).read().decode('utf-8')

# Generated at 2022-06-22 07:10:06.854096
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:10:17.024675
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..extractor.common import InfoExtractor
    from ..downloader.http import HttpFD

    ies = [ie for ie in InfoExtractor._ies if ie.ie_key() not in ['generic', 'http']]

    def _get_url(url):
        return 'http://example.com/manifest.m3u8', {'ie_key': 'HlsFD'}

    def _get_manifest(url):
        return HttpFD().urlopen(url).read().decode('utf-8')

    # test unsupported streams
    for ie in ies:
        if ie.ie_key() in ['twitch']:
            continue
        for test in ie._TESTS:
            if test.get('playlist'):
                continue

# Generated at 2022-06-22 07:10:27.768318
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .common import FakeYDL
    check_results = []
    ydl = FakeYDL()
    check_results.append(HlsFD.can_download('#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXT-X-VERSION:3\n#EXT-X-MEDIA-SEQUENCE:1\n#EXTINF:10,\nhttps://example.com/media_w1280231280_1.ts\n#EXT-X-KEY:METHOD=NONE\n#EXTINF:10,\nhttps://example.com/media_w1280231280_2.ts\n#EXT-X-ENDLIST', {'url': ''}))

# Generated at 2022-06-22 07:11:25.261069
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hls = HlsFD(None, {'fragment_retries': 1})
    assert hls.__dict__ == {
        'params': {'fragment_retries': 1},
        'ydl': None,
        '_total_frags': 0,
        '_progress_hooks': [],
    }

    hls = HlsFD(None, {'fragment_retries': 1}, 1)
    assert hls.__dict__ == {
        'params': {'fragment_retries': 1},
        'ydl': None,
        '_total_frags': 1,
        '_progress_hooks': [],
    }


# Generated at 2022-06-22 07:11:27.457504
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass


if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-22 07:11:37.890496
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest

    class TestCase(unittest.TestCase):
        def test_case(self):
            HlsFD.can_download("""
                #EXTM3U
                #EXTINF:5
                http://example.com/segment.ts
            """, {'is_live': False})  # download

            HlsFD.can_download("""
                #EXTM3U
                #EXT-X-KEY:METHOD=NONE,URI="http://example.com/key.bin"
                #EXTINF:5
                http://example.com/segment.ts
            """, {'is_live': False})  # download


# Generated at 2022-06-22 07:11:49.496322
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest
    import tempfile

    def run_test_case(test_case):
        """ Run a test case on a test wrapper

            :param test_case: The test case object.
        """
        hlsfd_fd = HlsFD(None, None)
        ydl_info_dict = {'is_live': False}
        success = hlsfd_fd.can_download(test_case.input_manifest, ydl_info_dict)
        if test_case.is_success:
            assert success
        else:
            assert not success

    class TestCase(unittest.TestCase):
        """ A class representing a single test case.

            :param input_manifest: The input manifest.
            :param is_success: True if the test should succeed, False if it should fail.
        """


# Generated at 2022-06-22 07:11:59.662184
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    """ The purpose of this unit test is to test a method of
    http://github.com/ytdl-org/youtube-dl/blob/master/youtube_dl/downloader/hls.py
    that downloads a video that uses HLS technology. The method tested is
    real_download from class HlsFD
    """

    import os
    import tempfile
    from .test_utils import (
        get_testfile_url,
        remove_tempfile,
    )

    # Obtain a temporary file name
    (fd, filename) = tempfile.mkstemp('.mp4')
    os.close(fd)

    ydl = {}
    params = {'test': True, 'simulate': True, 'quiet': True}
    # Test with a simple sample

# Generated at 2022-06-22 07:12:11.591715
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .manifest import Manifest
    from .fragment import FragmentFD
    from .external import FFmpegFD
    from ..utils import get_signature_codecs
    from ..compat import compat_urllib_request
    manifest_url = 'https://www.youtube.com/watch?v=W8r-tXRLazs'
    video_id = 'W8r-tXRLazs'
    manifest = Manifest.fetch(manifest_url, video_id)
    video_info = manifest.video_info
    # we need to construct the info_dict manually in order to prevent another
    # network request to get the video info, which is already done above

# Generated at 2022-06-22 07:12:18.300971
# Unit test for constructor of class HlsFD
def test_HlsFD():
    class YDL:
        def __init__(self):
            self.params = {}
        def urlopen(self, url):
            return compat_urllib_error.HTTPError(
                url, 404, 'Error', {}, None)
    info_dict = {
        'url': 'url',
        '_decryption_key_url': 'key_url',
        'http_headers': {'header': 'value'},
    }
    HlsFD(YDL(), info_dict).real_download('filename', info_dict)

# Generated at 2022-06-22 07:12:23.870416
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .tests import test_utils

    resolution_length = {
        240: 10,
        360: 10,
        480: 10,
        720: 10,
        1080: 10,
    }

    ret = test_utils.test_real_download('hlsnative')

    for res in resolution_length:
        prefix = '[' + str(res) + 'p] '
        assert(prefix + 'hw_encode_hardware_encoder_used.mp4' in ret)
        assert(prefix + 'hw_encode_bitrate.mp4' in ret)
        assert(prefix + 'hw_encode_resolution.mp4' in ret)
        assert(prefix + 'hw_encode_fps.mp4' in ret)
        assert(prefix + 'hw_encode_frames.mp4' in ret)



# Generated at 2022-06-22 07:12:34.816747
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    '''
    This unit test aims to download live streams, it won't fail if they become unavailable.
    If a stream fails to download, it won't be included in the expected results.
    This test is not a definitive test for the HlsFD because of the number of possible HLS variants,
    it's just an indicative test for the library.
    '''
    from youtube_dl.YoutubeDL import YoutubeDL
    import sys
    import json
    import os.path
    # on Windows, os.path.join does not work well with unicode characters
    from os import path

    # This list will be updated with more tests

# Generated at 2022-06-22 07:12:37.117626
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Test constructor of class HlsFD
    hls_fd = HlsFD(None, {})

    return 0
