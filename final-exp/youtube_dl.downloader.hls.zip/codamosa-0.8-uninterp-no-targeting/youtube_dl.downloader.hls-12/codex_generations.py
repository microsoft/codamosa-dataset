

# Generated at 2022-06-22 07:03:38.377495
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import youtube_dl

    class MockYDL:
        def __init__(self, params, *args, **kwargs):
            self.params = params
            self.to_screen = lambda opt, msg: None

    params = {'fragment_base_url': 'http://url/frag'}
    ctx = MockYDL(params)
    hlsFD = HlsFD(ctx, params)
    assert hlsFD.params == params
    assert hlsFD.fd is None

# Generated at 2022-06-22 07:03:50.349118
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    def can_download(hls, info_dict, expected_result):
        assert (HlsFD.can_download(hls, info_dict) == expected_result)
        if not expected_result:
            info_dict.update({
                'extra_param_to_segment_url': '',
                '_decryption_key_url': '',
            })
            assert (HlsFD.can_download(hls, info_dict) == True)

    info_dict = {
        'is_live': False,
    }

# Generated at 2022-06-22 07:04:01.438475
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    hls_fd = HlsFD(None, None)

    # Streams that hlsfd can download
    # None of the unsupported features
    hls_fd.manifest = (
        '#EXTM3U\n'
        '#EXT-X-VERSION:3\n'
        '#EXT-X-MEDIA-SEQUENCE:0\n'
        '#EXT-X-TARGETDURATION:10\n'
        '#EXTINF:10.000,\n'
        '0/0/0.ts\n'
        '#EXTINF:10.000,\n'
        '0/0/1.ts\n'
        '#EXT-X-ENDLIST\n')
    hls_fd.info_dict = {'is_live': False}
    assert hls

# Generated at 2022-06-22 07:04:12.930737
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import unittest
    import youtube_dl.utils
    import youtube_dl.extractor.common
    from mock import MagicMock, patch

    class MockInfoDict:
        pass

    class MockYDL:
        pass
        # class params:
        #     fragment_retries = 0;

    class MockUrlOpen:
        class geturl:
            pass

        def read(self):
            return

    class TestHlsFD(HlsFD):
        def report_error(self, message):
            raise AssertionError('report_error: ' + message)

        def report_warning(self, message):
            raise AssertionError('report_warning: ' + message)

        def to_screen(self, message):
            raise AssertionError('to_screen: ' + message)


# Generated at 2022-06-22 07:04:25.809134
# Unit test for constructor of class HlsFD
def test_HlsFD():
    try:
        from Crypto.Cipher import AES
        can_decrypt_frag = True
    except ImportError:
        can_decrypt_frag = False

    # example 1

# Generated at 2022-06-22 07:04:39.631759
# Unit test for method real_download of class HlsFD

# Generated at 2022-06-22 07:04:52.380090
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class FakeYtdl():
        def urlopen(self, url):
            return url

    class FakeInfoDict():
        def __init__(self, is_live):
            self.is_live = is_live

        def get(self, key):
            return None

    ydl = FakeYtdl()
    fake_info_dict = FakeInfoDict(False)

    # test all features in UNSUPPORTED_FEATURES

# Generated at 2022-06-22 07:05:01.488556
# Unit test for constructor of class HlsFD
def test_HlsFD():
    manifest_url = 'https://devstreaming-cdn.apple.com/videos/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8'
    hls_fd = HlsFD(None, {'test': True})
    assert hls_fd.can_download(hls_fd.ydl.urlopen(manifest_url).read().decode(), {})
    assert not hls_fd.can_download(hls_fd.ydl.urlopen(manifest_url.replace('variant', 'master')).read().decode(), {'is_live': True})


if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-22 07:05:11.554406
# Unit test for constructor of class HlsFD
def test_HlsFD():
    constructor_test_cases = [
        {
            'url': 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8',
            'expected': True,
        },
        {
            'url': 'https://www.youtube.com/watch?v=7_u6ZwKV7xU',
            'expected': False,
        },
        {
            'url': 'http://adaptive.level3.net/dash/live/Pops_6023/qual.mpd',
            'expected': False,
        },
    ]
    for test_case in constructor_test_cases:
        url = test_case['url']
        expected = test_case['expected']
        result = HlsFD.can_download_url(url)

# Generated at 2022-06-22 07:05:21.491875
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.FileDownloader
    import youtube_dl.utils

    def _real_extract(self, url):
        url = url.replace('www.youtube.com', 'www.youtube-nocookie.com')

# Generated at 2022-06-22 07:05:46.214916
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest
    import re
    # We need to simulate earlier unittest versions where setUpClass
    # and tearDownClass were not available.
    import sys
    if sys.version_info[:2] <= (2, 6):
        unittest.TestCase.setUp = unittest.TestCase.setUpClass
        unittest.TestCase.tearDown = unittest.TestCase.tearDownClass
    if sys.version_info[:2] <= (2, 7):
        unittest.TestCase.assertIn = unittest.TestCase.assertTrue
        unittest.TestCase.assertNotIn = unittest.TestCase.assertFalse
        unittest.TestCase.assertIsNone = unittest.TestCase.assertTrue
        unittest.TestCase.assertIsNot

# Generated at 2022-06-22 07:05:58.033720
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import os
    import pytest
    import tempfile

    # pytest-pythonpath sets PYTHONPATH before importing tests so that youtube_dl imports work
    # See https://github.com/pytest-dev/pytest-pythonpath
    try:
        import youtube_dl
    except ImportError as err:
        pytest.skip('youtube_dl needs to be installed to test HlsFD: %s' % str(err))

    # On Python 2.6, __file__ is relative to the working directory and not to the test file so we get the real path.
    test_file_path = os.path.realpath(__file__)

    # Load test case data from the YAML file

# Generated at 2022-06-22 07:06:08.723629
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    from ..extractor.generic import YoutubeIE
    from ..utils import FakeYDL
    from .fragment import FragmentFD

    video_id = 'W_bD_DB_zgk'
    ies = YoutubeIE._extract_info(FakeYDL(), 'http://youtu.be/%s' % video_id, download=False)
    ydl = FakeYDL()
    ies[0]['url'] = 'http://fragments.cdn.vodafone.it/out/v1/e2d2ee8b0c0244e1b7d5b6fefe03cbbd/index.m3u8'
    fd = HlsFD(ydl, {})
    fd.real_download(video_id, ies[0])

    fd

# Generated at 2022-06-22 07:06:21.434212
# Unit test for constructor of class HlsFD
def test_HlsFD():
    class TestInfo():
        url = 'http://example.com'
        is_live = False
    from .downloader import YoutubeDL
    assert HlsFD.can_download('#EXTM3U', TestInfo())
    assert HlsFD.can_download('#EXTM3U\n#EXTINF:1.00,', TestInfo())
    assert HlsFD.can_download('#EXTM3U\n#EXTINF:1.00,\n', TestInfo())
    assert HlsFD.can_download('#EXTM3U\n#EXTINF:1.00,\n/foo/bar.mp4', TestInfo())

# Generated at 2022-06-22 07:06:31.657512
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import pytest
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.http import HttpFD
    HttpFD._retrieve_data = lambda self, *args: (True, b'\x00' * 16 * 1024 * 1024)
    ydl = YoutubeDL(params={'hls_use_mpegts': True})
    info_dict = {
        'url': 'http://manifest.url/playlist.m3u8',
        '_decryption_key_url': 'http://manifest.url/key',
    }
    hlsfd = HlsFD(ydl, {})
    hlsfd.to_screen = lambda s: None
    hlsfd._download_fragment = lambda *args: (True, b'\x00' * 16 * 1024)
   

# Generated at 2022-06-22 07:06:44.555218
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from ..post import PostProcessor
    import os
    from .external import ExternalFD

    def _can_download(url):
        from ..extractor import gen_extractors
        ie = gen_extractors(PostProcessor(None), [url])[0]
        ydl = ie._ydl
        ydl.params.update({
            'hls_use_ffmpeg': False,
        })

# Generated at 2022-06-22 07:06:53.745928
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from collections import namedtuple
    from .common import InfoDict
    from .common import urlhandle_test

    ManifestInfo = namedtuple('ManifestInfo', 'manifest is_live')
    TestCase = namedtuple('TestCase', 'name expected_value manifest_info')

# Generated at 2022-06-22 07:07:02.378624
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import json
    from .test.test_DASH import read_fixture
    from .downloader import YoutubeDL
    testdata = json.loads(read_fixture('hls'))
    d = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    for t in testdata:
        d.params['hls_use_mpegts'] = t['use_mpegts']
        d.process_ie_result(t['result'], download=True)

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-22 07:07:11.727517
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.youtube import YoutubeIE
    import pytest

    ydl = YoutubeIE(params={'test': True}, downloader=None)
    fd = HlsFD(ydl, params={'test': True})
    fd.real_download('./test_video.ts', {
        'url': 'testurl.m3u8',
        'http_headers': {},
    })

    with open('./test_video.ts', 'r') as f:
        assert f.read() == b'\x00' * 16 * 1024 * 1024

# Generated at 2022-06-22 07:07:23.876214
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..test import get_test_data
    filename = 'test.m3u8'
    manifest = get_test_data(filename)
    info_dict = {
        'id': 'test',
        'url': filename,
        'http_headers': {
            'User-Agent': "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0",
            'Accept': "*/*"
        }
    }
    hls = HlsFD(None, None)
    ret = hls.real_download(filename, info_dict)
    with open(filename, 'w') as fd:
        fd.write(ret.encode('utf-8'))

# Generated at 2022-06-22 07:07:49.195842
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .downloader import FakeYDL
    from .extractor.youtube import YoutubeIE
    import os.path
    import tempfile

    test_video_id = 'FIFn6dX9_rk'
    video_info = YoutubeIE().extract('https://www.youtube.com/watch?v=' + test_video_id)
    ydl = FakeYDL()
    fd = HlsFD(ydl, {})

    assert fd.can_download(video_info['url'], video_info)

    with tempfile.NamedTemporaryFile() as temp_out_file:
        assert fd.real_download(temp_out_file.name, video_info)

        # We only download the first fragment
        expected_size = 13230

# Generated at 2022-06-22 07:07:50.367556
# Unit test for constructor of class HlsFD
def test_HlsFD():
    HlsFD(None)

# Generated at 2022-06-22 07:08:00.495898
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .extractor.common import InfoExtractor
    from .downloader.external import ExternalFD
    from .downloader.f4m import F4mFD
    from .downloader.hls import HlsFD
    from .downloader.http import HttpFD
    from .downloader.dash import (
        DashSegmentsFD,
        check_executable,
    )
    from .downloader.fragment import (
        FragmentFD,
        FragmentsFD,
    )

    class MockInfoDict(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    def can_download_mock(ie, info_dict):
        # Set up mocking conditions
        if ie.IE_NAME == 'twitch:vod':
            return False

# Generated at 2022-06-22 07:08:08.077130
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    """
    Unit test for method _HlsFD.can_download of class HlsFD
    """
    from ..extractor.common import InfoExtractor
    from ..utils import MockYDL
    from ..compat import compat_str

    manifest = manifest_pp = """
#EXTM3U
#EXT-X-TARGETDURATION:10
#EXT-X-MEDIA-SEQUENCE:2680

#EXTINF:10,
http://media.example.com/segment1.ts
#EXTINF:10,
http://media.example.com/segment2.ts
#EXTINF:10,
http://media.example.com/segment3.ts
"""

    ie = InfoExtractor(MockYDL(), {})

    def _update_url_query(url, query):
        url

# Generated at 2022-06-22 07:08:20.266153
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    hlsFD = HlsFD({
        'http_headers': {},
        '_request_connection_to_host': lambda x: True,
        'params': {'test': True}
    })
    assert hlsFD.can_download(r'Some plain text', {})
    assert not hlsFD.can_download(r'#EXT-X-KEY:METHOD=SAMPLE-AES', {})
    assert hlsFD.can_download(r'#EXT-X-KEY:METHOD=NONE', {})
    assert hlsFD.can_download(r'#EXT-X-KEY:METHOD=AES-128', {})
    assert not hlsFD.can_download(r'#EXT-X-BYTERANGE', {})

# Generated at 2022-06-22 07:08:32.409329
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .http import HttpFD

    # Test features supported by HlsFD
    assert HlsFD.can_download(
        '#EXTM3U\n'
        '#EXT-X-KEY:METHOD=NONE\n'
        '#EXT-X-TARGETDURATION:3\n'
        '#EXTINF:3, no desc\n'
        '/no/desc.ts\n'
        '#EXT-X-ENDLIST\n',
        {'url': 'manifest.m3u8'}
    )

    # Test features supported by HttpFD

# Generated at 2022-06-22 07:08:36.810700
# Unit test for constructor of class HlsFD
def test_HlsFD():
    if not can_decrypt_frag:
        return
    class DummyYDL():
        def to_screen(*k):
            pass
    info_dict = {
        'url': 'm3u8_url',
        '_decryption_key_url': 'http://decryption_key_url',
        'http_headers': {}
    }
    hls_fd = HlsFD(DummyYDL(), {})
    hls_fd.real_download('file_name', info_dict)

# Generated at 2022-06-22 07:08:49.386459
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    hls_fd = HlsFD({
        'hls_playlist': True,
        'fragment_retries': 0,
    })
    _info_dict = {}

    def _test_case(manifest, expected_result):
        assert hls_fd.can_download(manifest, _info_dict) == expected_result

    _test_case('', True)
    _test_case('#EXT-X-KEY:METHOD=NONE', True)

    _test_case('#EXT-X-KEY:METHOD=AES-128', can_decrypt_frag)
    _test_case('#EXT-X-KEY:METHOD=AES-128', not can_decrypt_frag)

    _test_case('#EXT-X-KEY:METHOD=SAMPLE-AES', False)

   

# Generated at 2022-06-22 07:08:59.738416
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..extractor import EmbedExtractor
    from ..utils import FakeYDL
    from ..downloader.http import HttpFD
    ydl = FakeYDL()
    info_dict = {
        'url': 'http://video.foo.bar/baz.m3u8',
        '_type': 'hls',
        'http_headers': {'User-Agent': 'foobar'},
    }
    # Test constructor without base class
    hls_fd = HlsFD(ydl, info_dict)
    assert hls_fd._prepare_url(info_dict, info_dict['url']) == info_dict['url']
    assert hls_fd.ydl == ydl
    assert hls_fd._progress_hooks == []

# Generated at 2022-06-22 07:09:12.399290
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import youtube_dl
    import sys
    import os

    class DummyYTDL(object):
        def to_screen(self, message, skip_eol=False):
            sys.stderr.write(message + ('\n' if not skip_eol else ''))

        class FileDownloader(object):
            params = {'test': True, 'outtmpl': '-'}

        def prepare_filename(self, info_dict):
            return info_dict['url'].split('/')[-1] + '.ts'

        def urlopen(self, url):
            return youtube_dl.FileDownloader.urlopen(self, url)

    class DummyFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

       

# Generated at 2022-06-22 07:09:49.369408
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from tests.test_utils import FakeYDL
    from .external import FFmpegFD


# Generated at 2022-06-22 07:09:58.899308
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # import HlsFD to let the function run when test_HlsFD is not executed.
    # This also helps to check if HlsFD.can_download is able to import Crypto.Cipher
    from .hls_fd import HlsFD

    def can_download(manifest, info_dict):
        return HlsFD.can_download(manifest, info_dict)

    # 1. this is a dynamic playlist, HlsFD should not handle it
    m = '#EXTM3U\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=541364\nch1/ch1.m3u8\n'
    info_dict = {'url': 'http://www.example.com/foo/master.m3u8'}

# Generated at 2022-06-22 07:10:10.989263
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class YtdlUrlOpenMock:
        def __init__(self, url):
            self.url = url
        def geturl(self):
            return self.url
        # pylint: disable=no-self-use
        def read(self):
            return '#EXTM3U\n#EXT-X-BYTERANGE:1\n#EXTINF:1.234\nhttp://test.url/test-file'

    class MatchObjectMock:
        # pylint: disable=unused-argument
        def __init__(self, pattern, string):
            pass
        # pylint: disable=no-self-use
        def search(self, pattern):
            return True

    class YtdlMock:
        def __init__(self, params):
            self.params = params
       

# Generated at 2022-06-22 07:10:22.420211
# Unit test for constructor of class HlsFD
def test_HlsFD():
    assert HlsFD.can_download('#EXTM3U', {'url': 'test'})
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128', {'url': 'test'})
    assert not HlsFD.can_download(
        '#EXTM3U\n#EXT-X-KEY:METHOD=AES-128\n#EXT-X-BYTERANGE:121090@0', {'url': 'test'})
    assert HlsFD._prepare_url({}, 'http://www.example.com') == 'http://www.example.com'

# Generated at 2022-06-22 07:10:33.048979
# Unit test for constructor of class HlsFD
def test_HlsFD():
    import unittest
    from .http_fd import HttpFD

    video_id = 'NKW_anI_fhY'

# Generated at 2022-06-22 07:10:44.884889
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:10:55.723305
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os, shutil
    from .test import parse_url_result
    from ..cache import Cache
    cache = Cache(os.path.join(os.getcwd(), '__downloads__'))

    url_result = parse_url_result('https://youtu.be/X-2Wj0xhvGc')

# Generated at 2022-06-22 07:11:07.404279
# Unit test for method can_download of class HlsFD

# Generated at 2022-06-22 07:11:18.837909
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    class DummyClass():
        @staticmethod
        def params(name):
            return False

    import os
    from .extractor import get_info_extractor

    def get_url_and_manifest(path):
        class FakeYdl:
            def urlopen(self, url):
                class FakeUrlopen:
                    def __init__(self, url):
                        self.url = url
                    def geturl(self):
                        return self.url
                    def read(self):
                        with open(os.path.join(path, 'manifest.m3u8'), 'r') as f:
                            return f.read()
                return FakeUrlopen(url)

        ydl = FakeYdl()


# Generated at 2022-06-22 07:11:30.070025
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest
    class TestHlsFD_can_download(unittest.TestCase):
        def test_1(self):
            manifest = '#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:14\n#EXT-X-MEDIA-SEQUENCE:1\n#EXTINF:14,\nhttp://media.example.com/first.ts\n#EXTINF:12,\nhttp://media.example.com/second.ts\n#EXTINF:13,no desc\nhttp://media.example.com/third.ts\n#EXTINF:15,\nhttp://media.example.com/fourth.ts\n#EXT-X-ENDLIST\n'
            info_dict = {}

# Generated at 2022-06-22 07:13:08.904148
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import create_test_fds_dict
    from ..test.test_download import (
        BaseTestDownload,
        NO_DEFAULT,
        setUpTestDownload,
        get_test_cases,
    )
    fds_dict = create_test_fds_dict(HlsFD)
    test_cases = get_test_cases()