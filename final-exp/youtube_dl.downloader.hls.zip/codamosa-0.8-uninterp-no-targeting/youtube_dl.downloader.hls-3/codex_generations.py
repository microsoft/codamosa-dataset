

# Generated at 2022-06-22 07:03:32.244617
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    assert HlsFD.can_download('#EXTM3U', {}) is True
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:1\n#EXTINF:6.003,\nfoo-000.ts', {}) is True
    assert HlsFD.can_download('#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:1\n#EXT-X-KEY:METHOD=NONE\n#EXTINF:6.003,\nfoo-000.ts', {}) is True

# Generated at 2022-06-22 07:03:42.452854
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    from ..downloader.f4m import F4mFD
    class FakeYoutubeDl(InfoExtractor):

        @staticmethod
        def suitable(url):
            return False

        @staticmethod
        def extract_info(url, download=True):
            return {
                'id': '1111',
                'url': url,
                'extractor': 'fake',
                'title': 'fake video',
                'description': 'fake video',
                'thumbnail': 'http://domain.tld/thumbnail.jpg',
                'uploader': 'fake uploader',
                'upload_date': '20130101',
            }

    # Check HlsFD can work if it's suitable for all URLs
    HlsFD.suitable

# Generated at 2022-06-22 07:03:55.699327
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # Live streams heuristic does not always work
    assert HlsFD.can_download('#EXT-X-MEDIA-SEQUENCE:17', {})
    assert not HlsFD.can_download('#EXT-X-MEDIA-SEQUENCE:0', {})

    assert HlsFD.can_download('#EXT-X-KEY:METHOD=NONE', {})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {})
    assert not HlsFD.can_download('#EXT-X-KEY:METHOD=AES-128', {'_decryption_key_url': 'k'})

# Generated at 2022-06-22 07:04:04.510096
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import FakeYDL
    from ..extractor import YoutubeIE
    from ..utils import encodeFilename
    import shutil
    import tempfile
    import os
    import random

    temp_dir = tempfile.mkdtemp()
    ydl = FakeYDL()
    url = 'https://video-dev.github.io/streams/x36xhzz/x36xhzz.m3u8'
    ie = YoutubeIE()

# Generated at 2022-06-22 07:04:17.297812
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test_downloads import FakeYDL
    from .test_downloads import _save_url
    from .test_downloads import _set_cookies
    from .extractor import get_info_extractor
    import os
    import tempfile

    ie = get_info_extractor(
        'akamaihd')
    ie._WORKAROUND = 'force-generic'
    ie.ydl = FakeYDL()
    ie.params['test'] = True
    filename = None

# Generated at 2022-06-22 07:04:29.605202
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import os
    import re
    # regression test for https://github.com/ytdl-org/youtube-dl/issues/14009
    test_manifest_URLs = [
        'https://edge.api.brightcove.com/playback/v1/accounts/1962198409001/videos/5957131785001/master.m3u8',
        'https://edge.api.brightcove.com/playback/v1/accounts/1962198409001/videos/6077699751001/master.m3u8'
    ]

# Generated at 2022-06-22 07:04:39.337758
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..downloader.common import FileDownloader
    #Initialize downloader with _FakeYoutubeDl instance
    f_d = FileDownloader(params={},
                    ydl=_FakeYoutubeDl())
    assert(isinstance(f_d, FileDownloader))
    #Initialize hls object of class HlsFD
    hls = HlsFD(f_d, {})
    assert(hls.params == {})
    assert(hls.fd == f_d)

# Fake class for testing constructor of HlsFD class

# Generated at 2022-06-22 07:04:51.402161
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import re
    import shutil
    import tempfile
    import textwrap
    import unittest
    import xml.etree.ElementTree as ET
    import youtube_dl.downloader.external
    import youtube_dl.downloader.fragment
    import youtube_dl.downloader.hls
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_http_client
    from youtube_dl.extractor.youtube import YoutubeIE

    # YoutubeDL object to be used for downloading
    ydl = YoutubeDL(params={'noprogress': True})

    # M3U8 playlist to be used for tests

# Generated at 2022-06-22 07:04:56.014681
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .test import ydl, t
    import time
    import math

    # So the unit test will run in a reasonable amount of time
    # this seems to be related to frag_retries (if any)
    # regardless of the number of frags, we need to download the
    # same amount of data
    t.params['noprogress'] = True
    t.params['test'] = True
    t.params['fragment_retries'] = 0

    # This Url has only 8 frags
    test_url = 'http://hlslive.lcdn.une.net.co/v1/AUTH_HLSLIVE/TELMEX/tu_cuenta.m3u8'

# Generated at 2022-06-22 07:05:06.291682
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .hls import HlsFD
    from .external import FFmpegFD

    def can_download(manifest, info_dict):
        try:
            return HlsFD.can_download(manifest, info_dict)
        except ImportError:
            return FFmpegFD.can_download(manifest, info_dict)


# Generated at 2022-06-22 07:05:31.121225
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from .youtube import YoutubeFD
    from .extractor.common import InfoExtractor
    from .downloader import SearchInfoExtractor
    from .extractor.youtube import YoutubeSearchIE
    from .downloader import YoutubeDL
    from .compat import compat_urllib_parse_urlencode
    from io import BytesIO

    def _build_info_dict(url, query, video_id):
        urlh = compat_urllib_parse_urlencode({'url': url, 'query': query})
        ie = InfoExtractor(YoutubeDL(), urlh)
        return ie.extract(video_id)

    def _build_downloader(post_processors):
        return YoutubeDL(params={'postprocessors': post_processors})


# Generated at 2022-06-22 07:05:44.032794
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from .options import Options
    from .extractor import YoutubeIE
    file_option = Options()
    extractor = YoutubeIE(file_option)

# Generated at 2022-06-22 07:05:56.121596
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    # import sys
    # sys.path.append('tests')
    from .test_download import FakeYDL
    ydl = FakeYDL()


# Generated at 2022-06-22 07:05:57.879773
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    pass


# Generated at 2022-06-22 07:06:08.494667
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    from ..utils import MatchRe
    import os
    import os.path as osp

    ydl = Downloader()
    ydl.add_info_extractor(YoutubeIE)

    # Download the test video for the following URLs:
    # - https://www.youtube.com/watch?v=A1jC7bOKlEQ
    # - https://www.youtube.com/watch?v=ofCiP3qb5ms
    # - https://www.youtube.com/watch?v=_NXzYnbaMj8

# Generated at 2022-06-22 07:06:21.266689
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    url = 'https://example.com/hls/hls-audio-only.m3u8'

    def _download_fragment(ctx, frag_url, info_dict, headers):
        return True, 'fragment content'

    def _append_fragment(ctx, frag_content):
        assert frag_content == 'fragment content'

    ctx = {
        'frag_url': 'test/test',
        '_download_fragment': _download_fragment,
        '_append_fragment': _append_fragment,
        'filename': 'test/test',
        'total_frags': 1,
        'ad_frags': 0,
    }
    info_dict = {
        'url': url,
    }

    # Test AES decryption
   

# Generated at 2022-06-22 07:06:31.579969
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest
    import tempfile
    try:
        from Crypto.Cipher import AES
    except ImportError:
        has_pycrypto = False
    else:
        has_pycrypto = True

# Generated at 2022-06-22 07:06:44.448877
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .common import FakeYDL
    from .extractor import get_info_extractor

    # Test that HlsFD.can_download() method does not reject
    # these features.
    # 1. https://github.com/ytdl-org/youtube-dl/issues/8756
    # 2. https://github.com/ytdl-org/youtube-dl/issues/8783
    # 3. https://github.com/ytdl-org/youtube-dl/issues/8817
    # 4. https://github.com/ytdl-org/youtube-dl/issues/8818
    # 5. https://github.com/ytdl-org/youtube-dl/issues/8819
    # 6. https://github.com/ytdl-org/youtube-dl/issues/10448
    # 7.

# Generated at 2022-06-22 07:06:55.528042
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..downloader import YoutubeDL
    from ..extractor import (
        get_info_extractor,
        gen_extractors,
        list_extractors,
    )
    ie = get_info_extractor(
        'https://example.com/test_hls_fd', list_extractors())
    fd = HlsFD(YoutubeDL({'quiet': True}), ie._AVAILABLE_OPTIONS)
    assert fd.ydl is not None
    assert fd.params == {}
    assert fd.fd is None
    assert fd.progress_hooks == []
    assert fd.info_dict == {}
    assert fd.resume_len == 0
    return fd

# Generated at 2022-06-22 07:07:06.770955
# Unit test for constructor of class HlsFD
def test_HlsFD():
    extractor = HlsFD({}, None)
    assert extractor.can_download("choice1\nchoice2\nchoice3\n",{}) == False
    assert extractor.can_download("#EXTM3U\n#EXTINF:10\nchoice1\nchoice2\nchoice3\n",{}) == True
    assert extractor.can_download("#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI=\"enckey\"\n#EXTINF:10\nchoice1\nchoice2\nchoice3\n",{}) == False

# Generated at 2022-06-22 07:07:44.452115
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import test_download
    test_download.main(
        ['https://bitdash-a.akamaihd.net/content/MI201109210084_1/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8',
         '-f', 'hlsnative'],
        expected_status='finished',
        expected_data_function=lambda d: b'#EXTINF:10,\n' not in d,
        skip_fragments_tests=True,  # The urls are different as the query has changed
    )
test_HlsFD_real_download.test = True

# Generated at 2022-06-22 07:07:57.289049
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from .hls import HlsFD
    from ..extractor import youtube
    class DummyInfoDict(dict):
        def __init__(self):
            self.url = 'url'
            self.http_headers = None
            self.is_live = False
            self.get = self.__getitem__
        def setdefault(self, *args):
            pass
    ydl = youtube.YoutubeDL(None)
    info_dict = DummyInfoDict()
    fd = HlsFD(ydl, None)

    # Test for supported features

# Generated at 2022-06-22 07:08:00.757659
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass

# Generated at 2022-06-22 07:08:08.205199
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor, InAdvancePagedList
    from .external import ExternalFD
    from .utils import PreparedRequest, FakeFile
    from .f4m import F4mFD
    import os
    import shutil
    import tempfile
    import urllib.request

    def call_real_download(real_download_to_test, manifest_url, opts):
        # Start a fake YDL session and inject manifest_url and opts
        ydl = YoutubeDL(opts)
        ydl.cache.remove()
        ies = [InfoExtractor(ydl, manifest_url)]

# Generated at 2022-06-22 07:08:20.372544
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    from . import YoutubeDL
    from .extractor.common import InfoExtractor
    from .extractor.youtube import YoutubeIE

    ydl = YoutubeDL({'quiet': True})
    assert HlsFD.can_download(
        '#EXTM3U\n#EXT-X-TARGETDURATION:10\n'
        '#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:9.000,1.ts\n#EXTINF:9.000,2.ts\n',
        {'_type': 'hls', 'url': 'http://manifest.m3u8'})

# Generated at 2022-06-22 07:08:32.586392
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Create a TestYoutubeDL object
    from .extractor.common import YoutubeDL
    from .utils import DateRange
    from .downloader.common import FileDownloader
    from .downloader.hls import HlsFD
    from .extractor.http import HttpIE
    info = {
        'format': 'bestvideo[protocol^=http]+bestaudio[protocol^=http]/best',
        'protocol': 'http',
        'http_headers': 'Accept-Language: en-US',
        'cookies': 'qualityFilter=240p',
    }
    ydl = YoutubeDL({'outtmpl': '%(id)s%(ext)s', 'merge_output_format': 'mp4'})
    ydl.add_info_extractor(HttpIE(ydl, 'test', info))

# Generated at 2022-06-22 07:08:45.102016
# Unit test for constructor of class HlsFD
def test_HlsFD():
    # Test 1
    import os
    import shutil
    from ..utils import encodeFilename
    from ..extractor import gen_extractors

    def get_testfd_names():
        return [fd_name for fd_name, fd in gen_extractors() if 'test' == fd.IE_NAME]

    test_path = './'
    test_video_id = '4WGx2'
    test_url = 'https://www.facebook.com/video.php?v=' + test_video_id

    test_filename = encodeFilename(test_video_id) + '.m4a'
    test_outtmpl = os.path.join(test_path, test_filename)

    # Cleanup

# Generated at 2022-06-22 07:08:56.168897
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'forcejson': True, 'quiet': True})
    hlsfd = HlsFD(ydl, {})

    # Not supported by hlsnative
    manifest = '#EXT-X-KEY:METHOD=SAMPLE-AES,URI="test"'
    assert not hlsfd.can_download(manifest, {})

    # Supported by hlsnative
    manifest = '#EXT-X-KEY:METHOD=AES-128,URI="test"'
    assert hlsfd.can_download(manifest, {})

    # Not supported by hlsnative
    manifest = '#EXT-X-KEY:METHOD=AES-128,URI="test"\n#EXT-X-BYTERANGE:1234'

# Generated at 2022-06-22 07:09:03.379922
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    # Allows for easy for testing the HlsFD.
    # To test, run `python -m youtube_dl.extractor.hls --test "https://example.com/m3u8_file"`

    import sys
    import tempfile
    import os
    import shutil

    if len(sys.argv) != 3 or sys.argv[1] != '--test':
        print('This is a unit test, not a script. ' +
              'Please run it via the python interpreter, with "-m"')
        sys.exit(1)

    class MockInfoDict({}):
        # Assume all segments are not encrypted
        def __init__(self, manifest_url):
            manifest = compat_urllib_request.urlopen(manifest_url).read().decode('utf-8')

# Generated at 2022-06-22 07:09:15.573591
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    try:
        from Crypto.Cipher import AES
    except ImportError:
        can_decrypt_frag = False
    def test_HlsFD_can_download(self, manifest, info_dict, expected_result):
        self.assertEqual(HlsFD.can_download(manifest, info_dict), expected_result)

# Generated at 2022-06-22 07:10:20.560899
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import sys
    import tempfile
    import os.path
    import re
    import random
    import string
    import shutil
    import collections

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import (
        gen_extractors,
        list_extractors,
        get_info_extractor,
        youtube_dl,
    )

    from .test_fragment import TestFragmentFD

    # Tested with python 2.7.18 and python 3.8.6

    class TestHlsFD(TestFragmentFD):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.params

# Generated at 2022-06-22 07:10:22.525624
# Unit test for constructor of class HlsFD
def test_HlsFD():
    hlsfd = HlsFD(None, None)
    assert hlsfd.FD_NAME == 'hlsnative'

# Generated at 2022-06-22 07:10:30.004038
# Unit test for constructor of class HlsFD
def test_HlsFD():
    info_dict = {'url': 'http://xxx/yyy.m3u8', '_decryption_key_url': 'http://xxx/decryption_key', 'is_live': False}
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({})
    fd = HlsFD(ydl, {}, info_dict=info_dict)
    assert fd.params['test'] == False

if __name__ == '__main__':
    test_HlsFD()

# Generated at 2022-06-22 07:10:42.036301
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():

    def param_assert(manifest, info_dict, expected, message):
        print('manifest: "%s"\ninfo_dict: %s' % (manifest, info_dict))
        assert HlsFD.can_download(manifest, info_dict) == expected, message

    manifest = \
        '#EXTM3U\n' \
        '#EXT-X-VERSION:2\n' \
        '#EXT-X-PLAYLIST-TYPE:EVENT\n' \
        '#EXT-X-TARGETDURATION:11\n' \
        '#EXT-X-MEDIA-SEQUENCE:0\n' \
        '#EXTINF:10.0,\n' \
        'http://localhost/0.ts\n' \
        '#EXT-X-ENDLIST'


# Generated at 2022-06-22 07:10:42.746680
# Unit test for constructor of class HlsFD
def test_HlsFD():
    pass

# Generated at 2022-06-22 07:10:54.130099
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import shutil
    import os
    import re
    from ..downloader import YoutubeDL

    def _test(url, extra_config, expected_output):
        def _test_hook(d):
            if d['status'] == 'finished':
                assert expected_output == open(d['filename']).read()
                os.unlink(d['filename'])
            if d['status'] == 'error':
                assert False

# Generated at 2022-06-22 07:11:02.166945
# Unit test for constructor of class HlsFD
def test_HlsFD():
    from ..downloader import YoutubeDL
    ydl = YoutubeDL({})
    ydl.add_default_info_extractors()
    url = 'https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8'
    provider = ydl.getInfoExtractor(url)
    info = provider._real_extract({'url': url})
    test = HlsFD(ydl, {})
    assert test.can_download(info['url'], info) is True

# Generated at 2022-06-22 07:11:12.876217
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    import os
    import tempfile
    import shutil
    from ..utils import urlopen
    from ..extractor.http import HttpFD
    from ..compat import compat_bytes

    class FakeInfoDict(object):
        def __init__(self, url, http_headers=None, _decryption_key_url=None, extra_param_to_segment_url=None):
            self.url = url
            self.http_headers = http_headers or {}
            self._decryption_key_url = _decryption_key_url
            self.extra_param_to_segment_url = extra_param_to_segment_url

    class FakeYDL(object):
        def __init__(self, test=True):
            self._progress_hooks = []
            self.test = test


# Generated at 2022-06-22 07:11:23.818003
# Unit test for method can_download of class HlsFD
def test_HlsFD_can_download():
    import unittest
    from .common import FakeYDL, FakeInfoDict
    from .m3u8 import M3U8FD
    from .f4m import F4mFD
    from .external import FFmpegFD
    
    def has_unsupported_feature(man):
        return HlsFD.can_download(man, FakeInfoDict())
    
    class HlsCanDownloadTest(unittest.TestCase):
        '''unit test for method can_download of class HlsFD'''
        def setUp(self):
            self.ydl = FakeYDL()
            self.ydl.params['hls_prefer_native'] = True
        
        def tearDown(self):
            pass
    

# Generated at 2022-06-22 07:11:35.447128
# Unit test for method real_download of class HlsFD
def test_HlsFD_real_download():
    from io import BytesIO
    from .test_fragment import FragmentTestBase
    from .test_fragment import MockUrlOpenTestBase

    # Test for method real_download of class HlsFD
    class TestRealDownload(FragmentTestBase, MockUrlOpenTestBase):
        def setUp(self):
            self._setup_mock_ydl()
            super(TestRealDownload, self).setUp()
            self._setup_mock_urlopen()
            self.fd = HlsFD(self.ydl, {})
            self.addCleanup(self.tearDown)