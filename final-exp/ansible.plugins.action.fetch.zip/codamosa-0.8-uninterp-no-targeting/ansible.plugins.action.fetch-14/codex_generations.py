

# Generated at 2022-06-21 02:06:02.833444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:06:03.689005
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()


# Generated at 2022-06-21 02:06:05.127600
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-21 02:06:06.465243
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test(s)
    pass

# Generated at 2022-06-21 02:06:17.678667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest

    from ansible.playbook_tests.six import StringIO

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.connection.local import Connection
    from ansible.executor.task_result import TaskResult
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionLegacy
    from ansible.module_utils.facts.system.distribution import DistributionRedHat
    from ansible.module_utils.facts.system.distribution import DistributionSUSE
    from ansible.module_utils.facts.system.distribution import DistributionSystem

# Generated at 2022-06-21 02:06:18.760799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Write unit test for `ActionModule.run`."""

    return None

# Generated at 2022-06-21 02:06:23.456108
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.fetch import ActionModule
    import os

    actionModule = ActionModule(task=dict(args=dict(src=os.path.join("test", "data", "test_file"), dest='/tmp/test_file')), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert actionModule is not None

# Generated at 2022-06-21 02:06:25.135268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Since the constructor of ActionModule is called implicitly,
    # nothing we can do in the unit test
    pass

# Generated at 2022-06-21 02:06:37.776522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile

    tmp = tempfile.mkdtemp()

    # Create the source file
    source = os.path.join(tmp, 'source')
    with open(source, 'w') as s:
        s.write('content')

    # Setup configuration
    class Options:
        connection = 'smart'
        module_path = []
        forks = 100
        become = False
        become_method = 'sudo'
        become_user = ''
        check = False
        diff = False
        remote_user = 'user'
        timeout = 10

    class RunnerOptions:
        module_path = []
        module_name = 'file'
        library = None
        pattern = '*'
        forks = 10
        become = False
        become_method = 'sudo'
        become_user = ''
        check

# Generated at 2022-06-21 02:06:48.618969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor import task_executor

    task_executor._shared_loader_obj = None
    task_executor._shared_loader_obj = _create_fake_loader()

    action_module = ActionModule()
    action_module.set_loader(task_executor._shared_loader_obj)

    source = './test_action_module_fetch_src/file'
    dest = './test_action_module_fetch_dest/'
    flat = False
    fail_on_missing = True
    validate_checksum = True
    action_module._task.args = dict(src=source, dest=dest, flat=flat, fail_on_missing=fail_on_missing, validate_checksum=validate_checksum)

    action_module._connection = _create_fake_connection()
   

# Generated at 2022-06-21 02:07:18.090963
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.plugins import pkg_finder, PluginLoader
    from ansible.plugins.loader import action_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    class Host(object):
        def get_vars(self):
            return dict()
    context = PlayContext()
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')

    host = Host()

# Generated at 2022-06-21 02:07:28.112470
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    d = dict()
    d['shell_executable'] = '/bin/sh'
    d['display'] = Display()
    d['stdin'] = ''
    d['stdin_add_newline'] = True
    d['potential_client_keys'] = None
    d['become'] = False
    d['become_method'] = None
    d['become_user'] = None
    d['become_ask_pass'] = False
    d['remote_addr'] = None
    d['transport'] = 'smart'
    d['preserve_repo_files'] = True
    d['check'] = False
    d['force_handlers'] = False
    d['no_log'] = False
    d['verbosity'] = 0
    d['check_mode'] = False

# Generated at 2022-06-21 02:07:39.384483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins import action_loader
    import pytest

    # prepare the mocks
    class MockTask(object):
        pass

    class MockConnection(object):
        pass

    class MockConnectionOptions(object):
        pass

    class MockShell(object):
        pass

    class MockLoader(object):
        pass

    class MockTaskVars(dict):
        pass

    # create the dummy objects
    action = action_loader.get('fetch', MockTask(), MockConnection(MockConnectionOptions()), MockShell(), '', '', '', '', '', MockLoader())
    action.tmp = ''
    action.connection._shell.join_path = lambda x,y: '/'.join([x,y])
    action.connection._shell.tmpdir = ''


# Generated at 2022-06-21 02:07:40.194468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:07:49.478461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    action_module.ActionModule is a constructor for class ActionModule
    '''
    def _create_task(args):
        '''
        Mock Task()
        '''
        return type('Task', (object,), dict(args=args))

    def _create_play_context(check_mode=None, remote_addr=None):
        '''
        Mock PlayContext()
        '''
        return type('PlayContext', (object,), dict(check_mode=check_mode, remote_addr=remote_addr))

    def _create_loader():
        '''
        Mock loader()
        '''
        return type('Loader', (object,), dict(path_dwim=lambda dest: dest))

    def _create_connection():
        '''
        Mock Connection()
        '''

# Generated at 2022-06-21 02:07:57.563771
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
        task=dict(action=dict(module_name='fetch', src='src', dest='dest', flat=True, fail_on_missing=False, validate_checksum=False)),
        connection=dict(transport='connection_transport', become_method='become_method', become_user='become_user', become_password='become_password'),
        play_context=dict(remote_addr='remote_addr', remote_user='remote_user', port='port', password='password', become='become', become_user='become_user')
    )

    import ansible.playbook.task_include
    assert isinstance(am._task, ansible.playbook.task_include.TaskInclude)

# Generated at 2022-06-21 02:08:08.372556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up test data
    tmp = None
    task_vars = None
    # Instantiate ActionModule
    ActionModuleObj = ActionModule(tmp, task_vars)
    # Call run
    result = ActionModuleObj.run(tmp=tmp, task_vars=task_vars)
    # Check result is not None
    assert result is not None
    # Check error with invalid type supplied for source option, it must be a string
    with pytest.raises(AnsibleActionFail) as excinfo:
        # Set up test data
        tmp = None
        task_vars = None
        # Instantiate ActionModule
        ActionModuleObj = ActionModule(tmp, task_vars)
        # Call run
        result = ActionModuleObj.run(tmp=tmp, task_vars=task_vars)
    # Check

# Generated at 2022-06-21 02:08:17.802424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test: test_ActionModule_run"""
    template = """
---
- hosts: localhost
  tasks:
    - test:
        src: "{{ src }}"
        dest: "{{ dest }}"
        flat: "{{ flat }}"
"""

    # test_ActionModule_run: test run method of class ActionModule
    # Create a temporary directory, adds a test file,
    # runs ansible and deletes temporary directory,
    # ensures that the test_file has been created.

    def test_run(scenario):
        """Test: test a specific scenario"""

        from ansible.parsing.dataloader import DataLoader
        from ansible.vars import VariableManager
        from ansible.inventory import Inventory
        from ansible.playbook.play import Play

# Generated at 2022-06-21 02:08:25.723519
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Use empty vars and empty setup in play
    # FIXME: This is not a valid test of the base class constructor.
    #        The constructor of the base class manipulates a few args,
    #        but that's all.
    action_mod = ActionModule(dict(), './test/fetch.yml', dict(ANSIBLE_REMOTE_TMP='./test/', ANSIBLE_REMOTE_USER='root'), False, '/test', False, False, False, 'all')
    assert action_mod is not None


# Generated at 2022-06-21 02:08:32.839091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert m is not None
    assert m._task is None
    assert m._connection is None
    assert m._play_context is None
    assert m._loader is None
    assert m._templar is None
    assert m._shared_loader_obj is None


# Generated at 2022-06-21 02:09:08.797314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:09:12.309084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-21 02:09:13.659063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:09:25.816311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    # debug = True
    debug = False
    if debug:
        fp = '/tmp/test_ActionModule_run.log'
        sys.stdout = open(fp, 'w+')
        sys.stderr = open(fp, 'w+')

    from ansible.plugins.action.fetch import ActionModule
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor import playbook_executor


# Generated at 2022-06-21 02:09:33.621164
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    ActionModule unit tests
    '''
    from ansible import context
    context._init_global_context(load_plugins=False)

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager

    from ansible.parsing.dataloader import DataLoader

    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.module_utils.common.text.converters import to_bytes
    #from ansible.playbook.block import Block

    loader = DataLoader()
    loader._set_vault_password(password='password')
    # create inventory, use path to host conf file as source or hosts

# Generated at 2022-06-21 02:09:39.202955
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(None, {})
    result = am.run(task_vars={})    
    assert result['failed'] is True
    assert result['msg'] == "src and dest are required.a"

# Generated at 2022-06-21 02:09:46.834435
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    # create our play object
    play = Play()

    # create our task object
    task = Task()

    # create our ActionModule object
    am = ActionModule(task, play, module_implementation_preferences=['foo', 'bar'])

    # assert that our ActionModule object is an ActionBase
    assert isinstance(am, ActionBase)

    # assert that the module_implementation_preferences was set
    assert am._module_implementation_preferences == ['foo', 'bar']

# Generated at 2022-06-21 02:09:47.367629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am 

# Generated at 2022-06-21 02:09:56.799557
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.module_utils.basic as basic
    import ansible.module_utils.parsing.convert_bool as convert_bool
    import ansible.plugins.action.action_fetch as fetch
    import ansible.utils.crypto as crypto
    import ansible.plugins.action.copy as copy
    from ansible.module_utils._text import to_text
    from ansible.utils.path import makedirs_safe
    from ansible.utils.hashing import checksum, secure_hash
    from unittest import TestCase

    class MockModule(basic.AnsibleModule):
        def __init__(self):
            self.params = {}
            self.check_mode = False

        def _execute_module(self, func, *args, **kwargs):
            pass


# Generated at 2022-06-21 02:10:00.775795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a is not None

# Generated at 2022-06-21 02:11:18.479990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule = ActionModule()
    assert not actionmodule.run()

# Generated at 2022-06-21 02:11:28.918916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor with no action name
    actionModule = ActionModule(None, None)
    assert actionModule.action_name is None
    assert actionModule._task is None
    assert actionModule._connection is None
    assert actionModule._play_context is None
    assert actionModule._loader is None
    assert actionModule._templar is None
    assert actionModule._shared_loader_obj is None
    assert len(actionModule._task_vars) == 0
    assert actionModule._task_vars_tmp is None

# Generated at 2022-06-21 02:11:29.782711
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()

# Generated at 2022-06-21 02:11:41.331027
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Replicate the test method in integration/targets/module_utils/fetch.ps1
    # One thing not replicated is skipping fetch due to check_mode
    def _task(action):
        return {
            "args": {
                "src": "${tmp}/test.txt",
                "dest": "/tmp/fetch_works",
                "flat": "yes"
            },
            "action": action
        }

    def _task_and_connection(action):
        task = _task(action)
        connection = {}
        connection['_shell'] = MockConnectionShell()
        connection['become'] = False
        connection['_execute_remote_stat'] = _execute_remote_stat
        connection['_execute_module'] = _execute_module
        connection['_fetch_file'] = _fetch_file


# Generated at 2022-06-21 02:11:42.608380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 0

# Generated at 2022-06-21 02:11:52.000928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins import module_loader
    from ansible.module_utils.common.text.converters import to_bytes
    import json

    mock_connection = MockConnection()
    mock_module_loader = MockModuleLoader()
    module_instance = module_loader.get('fetch', connection=mock_connection)
    module_instance._find_needle = MockModuleFinder()
    module_instance._connection._shell.join_path = lambda *a: '/'.join(a)

    def _remove_tmp_path(self, path):
        pass

    module_instance._remove_tmp_path = _remove_tmp_path

    assert module_instance.run() == dict(
        failed=True,
        msg="src and dest are required",
    )


# Generated at 2022-06-21 02:11:54.427000
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(ActionModule(connection=None, task=None).__dict__)

# Generated at 2022-06-21 02:11:56.950387
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None

# Unit tests for method run of class ActionModule

# Generated at 2022-06-21 02:11:58.925809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None)
    assert action

# Generated at 2022-06-21 02:12:04.880072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import ansible
    # Set an environment variable to be used when instantiating the host class
    os.environ['ANSIBLE_HOST_PATTERN_MISMATCH'] = 'True'
    target = ansible.inventory.host.Host(name="test")
    (action, connection, tmp, task_vars) = (None, None, None, dict())
    # Instantiate the action class
    am = ActionModule(task=None, connection=connection, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Set up some basic parameters needed by the run method
    am.task_vars = task_vars
    am.tmp = tmp
    am.task = None
    am._play_context = None
    am._loader = None
    am._templ

# Generated at 2022-06-21 02:15:40.231960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = dict()
    run_data = dict(changed=False, md5sum=None
                   , file=None, dest=None, checksum=None)
    result.update(run_data)

    # TODO: Add unit test for this method
    return result

# Generated at 2022-06-21 02:15:48.341223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    import tempfile
    import os
    import shutil
    import sys
    import json

    # Here we create a mock connection which just returns some data.
    # Note that ActionBase uses the connection to do file tranfers and
    # connection specific things.
    class Connection(object):
        def __init__(self, *args, **kwargs):
            self._shell = None
            self._display = Display()

        # We override this because the original implementation would try to
        # create the tmp dir and upload the file to the remote end.