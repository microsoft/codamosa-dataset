

# Generated at 2022-06-21 02:06:08.351276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins import module_loader
    loader = DataLoader()
    module_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../lib/ansible/plugins/action/modules'))
    inventory = InventoryManager(loader=loader, sources="")
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-21 02:06:15.174980
# Unit test for constructor of class ActionModule
def test_ActionModule():
    null_connection = connection.Connection(play_context=play_context.PlayContext())
    null_task = task.Task(action=dict(), play_context=play_context.PlayContext(), connection=null_connection)
    null_action_module = ActionModule(task=null_task, connection=null_connection, play_context=null_task.play_context, loader=None, templar=None, shared_loader_obj=None)

    assert isinstance(
        null_action_module,
        ActionModule
    )

    del(null_connection)
    del(null_task)
    del(null_action_module)

# Generated at 2022-06-21 02:06:18.610405
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Set the arguments that would be passed to the module
    module_args = dict(
        src='/path/to/src',
        dest='/path/to/dest'
    )

    # Initialize the action plugin
    action = ActionModule(None, module_args, None)
    assert action

# Generated at 2022-06-21 02:06:24.125515
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am._task.args.get('src', None) is None
    assert am._task.args.get('dest', None) is None
    assert am._task.args.get('flat', False) == False
    assert am._task.args.get('fail_on_missing', False) == False
    assert am._task.args.get('validate_checksum', False) == False
    return True

# Generated at 2022-06-21 02:06:25.048314
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, "run")

# Generated at 2022-06-21 02:06:31.396392
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(runner=None, action=None, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(a, ActionModule)

# Generated at 2022-06-21 02:06:33.892354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    action_module._remote_expand_user('/abc')
    

# Generated at 2022-06-21 02:06:42.047957
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    fake_connection = type('FakeConnection', (), dict())
    fake_connection._shell = type('FakeShell', (), dict())
    fake_connection._shell.tmpdir = '/tmp/ansible_test'
    fake_connection._shell.join_path = os.path.join
    fake_connection._shell._unquote = lambda x: x
    fake_connection._shell._unquote.__doc__ = None
    fake_connection._shell._unquote.__name__ = None

    fake_connection._remote_expand_user = lambda x: x
    fake_connection._remote_expand_user.__doc__ = None
    fake_connection._remote_expand_user.__name__ = None

    class FakePlayContext(object):
        def __init__(self):
            self.check_mode = False

# Generated at 2022-06-21 02:06:50.296177
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock

    # Monkey patch _execute_remote_stat and _execute_module methods
    def _execute_remote_stat(self, path, all_vars, follow):
        return {'exists': True, 'isdir': False, 'checksum': '5d41402abc4b2a76b9719d911017c592'}

    def _execute_module(self, module_name, module_args, task_vars):
        return {'failed': False}

    ActionModule._execute_remote_stat = _execute_remote_stat
    ActionModule._execute_module = _execute_module


    # Build a temporary connection
    from ansible.plugins.connection.local import Connection
    from ansible.playbook.play_context import PlayContext

    c = Connection(PlayContext())

# Generated at 2022-06-21 02:06:51.191822
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return None

# Generated at 2022-06-21 02:07:12.487940
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    pass

# Generated at 2022-06-21 02:07:21.450538
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    msg = ''
    class Object(object):
        def __init__(self, msg=''):
            self.msg = msg
    class ModuleFailException(Exception):
        pass

    class AnsibleActionFail(AnsibleError):
        def __init__(self, msg='', exception=None):
            self.msg = msg
            self.exception = exception
        def __str__(self):
            return self.msg
        def __repr__(self):
            return self.msg

    ActionBase.run = None
    class ActionBase():
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._play_context = play_context
            self._task.args['dest'] = 'local'

# Generated at 2022-06-21 02:07:23.483054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()


# Generated at 2022-06-21 02:07:25.145391
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    am = ActionModule()
    assert(isinstance(am, ActionModule))

# Generated at 2022-06-21 02:07:26.284848
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-21 02:07:38.538980
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockConnection:
        def __init__(self):
            self._shell = None
            self.become = None

        def set_shell(self, shell):
            self._shell = shell

        def become_method(self):
            return self.become

    class MockPlayContext:
        def __init__(self):
            self.connection = 'local'
            self.remote_addr = '127.0.0.1'

    class MockLoader:
        def __init__(self):
            pass

        def path_dwim(self, path):
            return path

    action_module = ActionModule()
    action_module._connection = MockConnection()
    action_module._play_context = MockPlayContext()
    action_module._loader = MockLoader()

    return action_module

# Generated at 2022-06-21 02:07:48.732273
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestActionModule(ActionModule):
        def __init__(self):
            self.tmpdir = 'tmpdir'

    class TestConnection:
        def __init__(self):
            self.become = False

    class TestPlayContext:
        def __init__(self):
            self.check_mode = False

    class TestLoader:
        def __init__(self):
            self.path_dwim = lambda x: 'path_dwim/' + x
            self.path_exists = lambda x: x == 'path_dwim/valid_path'

    class TestTask:
        def __init__(self):
            self.args = dict(
                src='src',
                dest='valid_path',
            )


# Generated at 2022-06-21 02:07:56.183695
# Unit test for method run of class ActionModule
def test_ActionModule_run(): 
    # 1. @param tmp=None, task_vars=None, task_vars=None
    from ansible.plugins.action.fetch import ActionModule
    # 1.1 create object
    action_module = ActionModule(load_callback_plugins=True)
    # 1.2 set attribute, return false    
    action_module.display = Display()
    # 1.3 run, task_vars=None
    result = action_module.run(tmp=None, task_vars=None)

    # 2. @param tmp=None, task_vars=dict()
    # 2.1 create object
    action_module = ActionModule(load_callback_plugins=True)
    # 2.2 set attribute, return true    
    action_module.display = Display()
    action_module.become = True
    action

# Generated at 2022-06-21 02:07:58.087427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-21 02:08:04.725876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.utils.path
    tmp = ansible.utils.path.tmpdir()
    task_vars = {'inventory_hostname': 'localhost'}
    task_args = {'src': 'tests/unit/module_utils/fetch_test.txt', 'dest': '/tmp/test.txt'}
    action = ActionModule()
    action.set_loader('.')
    action.set_connection('./test/ansible_conn.py')
    action.set_module_name('module')
    action.set_module_path('../ansible')
    action.set_remote_user('root')
    action.set_play_context('/play.yml')
    action.set_task_vars({'inventory_hostname': 'localhost'})

# Generated at 2022-06-21 02:08:28.520424
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    am.run({'tmp': None, 'task_vars': None})

# Generated at 2022-06-21 02:08:30.083189
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # FIXME: Add tests here
    pass

# Generated at 2022-06-21 02:08:36.284362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.fetch
    import ansible.module_utils.shell

    connection = ansible.module_utils.shell.Connection()
    connection._shell = ansible.module_utils.shell.Shell()
    connection._shell.join_path = lambda path: path
    connection._shell._unquote = lambda path: path

    task_vars = {'inventory_hostname': 'host1'}

    action = ansible.plugins.action.fetch.ActionModule(
        {},
        connection=connection,
        task_vars=task_vars,
        loader=None
    )


# Generated at 2022-06-21 02:08:40.645414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test constructor
    action = ActionModule(u'dummy', u'dummy', False, False, False, False, False)
    assert action._shared_loader_obj == None
    assert isinstance(action._display, Display)

# Generated at 2022-06-21 02:08:46.584884
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This function tests the constructor of class ActionModule
    """
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.vault import VaultLib

    task_ds = dict(name='test',
                   action=dict(module='test', args=dict(src='test')))

    action_mod = ActionModule(task=ImmutableDict(task_ds), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert action_mod.action == 'test'
    assert action_mod.action_name == 'test'
    assert action_mod.action_loader is None
    assert action_mod._debug_task is False
    assert action_mod._debug_msg == []
    assert action_mod._att

# Generated at 2022-06-21 02:08:48.801066
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Test for method run of class ActionModule '''
    pass

# Generated at 2022-06-21 02:08:55.103903
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import ansible.plugins.action
    #from ansible.plugins.action.fetch import ActionModule
    am = ansible.plugins.action.ActionModule
    print(json.dumps(am.run(tmp=None, task_vars=None), indent=4))

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:08:56.882906
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-21 02:08:58.232965
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'

# Generated at 2022-06-21 02:09:09.301057
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    class Task:
        def __init__(self, args):
            self.args = args

    class PlayContext:
        check_mode = False
        remote_addr = '127.0.0.1'

    class Connection:
        _shell = None

        def __init__(self, remote_addr):
            self.remote_addr = remote_addr

        def become(self):
            return False

    class Shell:
        def __init__(self, tmpdir='/tmp/'):
            self.tmpdir = tmpdir
            self.join_path = os.path.join
            self._unquote = os.path.expanduser


# Generated at 2022-06-21 02:09:50.171059
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:09:57.441591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create args
    args = dict()
    args['src'] = '/home/toto'
    args['dest'] = '/home/tata'
    args['flat'] = True
    # Missing fail_on_missing
    args['validate_checksum'] = True

    # Create a MockRemote connection
    connection = MockRemote()

    # Create a MockTask
    task = MockTask()
    task._conn = connection
    task._task = dict()
    task._task['args'] = args

    # Create a MockLoader
    class MockLoader:
        def path_dwim(self, dest):
            return dest
    loader = MockLoader()

    # Create a MockTemplar
    class MockTemplar:
        def template(self):
            return 'test'
    templar = MockTemplar()

   

# Generated at 2022-06-21 02:10:06.146137
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeActionModule(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(FakeActionModule, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)

        def _execute_module(self, *args, **kwargs):
            pass

    fake_action = FakeActionModule(dict(), dict(), dict(), dict(), dict(), dict())
    assert fake_action is not None, 'test_ActionModule failed to create a new FakeActionModule object'

# Generated at 2022-06-21 02:10:10.111570
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionBase)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 02:10:18.627574
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json

    test_task = {
        'args': {'src': '/hello/world/test.txt', 'dest': '/hello/world/test.txt'},
        'name': 'fetch',
    }
    test_task_json = json.dumps(test_task)
    action = ActionModule(test_task_json,
                          {'loader': 'test_loader', 'no_log': ['test'], 'connection': 'test_connection', 'module_name': '_test_module'})

    assert action.action == '/hello/world/test.txt'
    assert action.args == {'src': '/hello/world/test.txt', 'dest': '/hello/world/test.txt'}
    assert action.module_name == '_test_module'

# Generated at 2022-06-21 02:10:19.666549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:10:27.346399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Test for run method of ActionModule class.
    Test procedure: create a mock object of ActionModule.
    Test for expected results.
    """
    # Initialize
    dummy_self = ActionModule()
    # Test for change detection
    assert dummy_self.run(tmp=None, task_vars=None) == {'changed': False}
    # Test for return if checksum is calculated in remote
    assert dummy_self.run(tmp=None, task_vars={'ansible_check_mode': None}) == {'changed': False}

# Generated at 2022-06-21 02:10:29.422666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # We don't really have information about the action plugin, so just testing the constructor
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action, ActionModule)

# Generated at 2022-06-21 02:10:36.647102
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule('action_module', 'ansible', {'module_name': 'fetch'}, 'ansible')
    assert action_module.module_name == 'fetch'
    assert action_module.action_name == 'legacy.fetch'
    assert action_module.action_type == 'legacy'
    assert action_module.task_name == 'action_module'

# Generated at 2022-06-21 02:10:38.443484
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert True


# Generated at 2022-06-21 02:12:01.216002
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:12:09.345662
# Unit test for constructor of class ActionModule
def test_ActionModule():
   # Construct a task
   task = Task()
   
   # Construct an action module
   am = ActionModule(
      connection=connection,
      task=task,
      play_context=play_context,
      loader=loader,
      templar=None,
      shared_loader_obj=None)

   # Shows the content of action module
   print(am)

# Calls the unit test
if __name__ == '__main__':
   test_ActionModule()

# Generated at 2022-06-21 02:12:21.966428
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_result import TaskResult
    from ansible.plugins import ActionModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    task = Task()
    task_result = TaskResult(host=inventory.get_host('127.0.0.1'))


# Generated at 2022-06-21 02:12:24.336241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-21 02:12:35.629795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock module
    am = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock task
    at = ActionModule.Task(action=dict())

    # Test with empty task
    result = am.run(task_vars=dict())
    assert result.get('failed', False)

    # Test with empty src
    at.args = dict(src=None, dest='/root/action_download/')
    result = am.run(task_vars=dict(), tmp='/some/path', task=at)
    assert result.get('failed', False)

    # Test with empty dest
    at.args = dict(src='/etc/passwd', dest=None)

# Generated at 2022-06-21 02:12:39.657764
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, {})   # module, display, task
    assert am is not None
    assert am.get_bin_path('ls') is not None

# Generated at 2022-06-21 02:12:50.933235
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import sys
    sys.path.append("/home/ansible/ansible/test/lib")
    import gc
    import unittest
    sys.path.append("/home/ansible/ansible/test/lib")
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.connection import Connection
    from ansible.plugins.cache import FactCache
    from ansible.plugins.loader import module_loader, action_loader
    #from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.inventory.manager import InventoryManager
   

# Generated at 2022-06-21 02:13:03.335822
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import playbook_context
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult

    # The following is needed to instantiate ActionModule
    pb_ctx = playbook_context.PlaybookContext()
    pb_ctx._tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback='default',
        run_additional_callbacks=False,
        run_tree=False,
    )

   

# Generated at 2022-06-21 02:13:04.711185
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")
    pass

# Generated at 2022-06-21 02:13:12.323298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up a mock object
    class MockConnection:
        def __init__(self, become=False):
            self.become = become

        def _shell(self):
            class MockShell:
                def _unquote(self, blah):
                    return blah
                def join_path(self, blah, blah2):
                    return blah

            return MockShell()

    # test fetching a file
    class MockTask:
        def __init__(self):
            self.args = {'src': 'testfile', 'dest': 'tmp/dest/', 'validate_checksum': False}

    class MockModule:
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir
            self.params = {'encoding': 'base64'}
