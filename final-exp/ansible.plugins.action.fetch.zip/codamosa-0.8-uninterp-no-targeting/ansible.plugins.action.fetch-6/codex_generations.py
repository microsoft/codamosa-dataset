

# Generated at 2022-06-21 02:06:01.845792
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(module_name='copy', src='/path/to/a/file', dest='/path/to/b/file')) is not None


if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-21 02:06:08.508727
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(action=dict(module_name='fetch', args=dict(src='test_src', dest='test_dest'))),
        connection=dict(play_context=dict(check_mode=False, remote_addr='test_remote_addr', become=False)),
        shell=dict(env_string=''),
        _remove_tmp_path=lambda x: None,
        )
    assert module._play_context == dict(check_mode=False, remote_addr='test_remote_addr', become=False)
    assert module._task == dict(action=dict(module_name='fetch', args=dict(src='test_src', dest='test_dest')))

# Generated at 2022-06-21 02:06:09.275793
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError

# Generated at 2022-06-21 02:06:18.965600
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(args=dict(src='a', dest='b', flat='True', fail_on_missing='True',
             validate_checksum='True'),
            _uses_shell=False),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert module.task['args']['src'] == 'a'
    assert module.task['args']['dest'] == 'b'
    assert module.task['args']['flat'] == 'True'
    assert module.task['args']['fail_on_missing'] == 'True'
    assert module.task['args']['validate_checksum'] == 'True'


# Generated at 2022-06-21 02:06:27.953156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    am = ActionModule()

    # Create an instance of class Task
    task = Task()
    task.args = {}
    am._task = task

    # Create an instance of class PlayContext
    pc = PlayContext()
    am._play_context = pc

    # Create an instance of class Connection
    c = Connection()
    am._connection = c

    # Create an instance of class Loader
    l = Loader()
    am._loader = l

    # set default values of variables required during _execute_remote_stat
    task.args['fail_on_missing'] = False
    task.args['validate_checksum'] = False

    # set value of variable self._connection._shell.join_path
    am._connection._shell.join_path = "join_path"

    # set value of

# Generated at 2022-06-21 02:06:38.230078
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with a single file transfer
    # For now, there's only one test and it's for the basic case

    # Create the action module to test
    am = ActionModule(None, None)

    # Create the Ansible options
    ansible_options = {'connection': 'local'}

    # Create the Ansible play context
    play_context = PlayContext()

    # Set the Ansible play context attributes
    play_context.remote_addr = 'localhost'
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.verbosity = 4

    # Create the Ansible connection
    connection = Connection(ansible_options)

    # Set the Ansible connection attributes

# Generated at 2022-06-21 02:06:38.713371
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:06:39.401801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None)
    assert module.run

# Generated at 2022-06-21 02:06:40.100951
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, {}, {}, None)

# Generated at 2022-06-21 02:06:40.555362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:06:58.126669
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:07:05.729996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.six import b, PY3
    from ansible.plugins.action import ActionBase
    from ansible.utils.display import Display
    from ansible.utils.hashing import checksum, checksum_s, md5, secure_hash
    from ansible.utils.path import makedirs_safe, is_subpath
    import os
    import base64
    import shutil
    import tempfile
    import pytest
    from ansible.utils.path import unfrackpath
    test_root = unfrackpath("/tmp/ansible_test_root")
    if os.path.exists(test_root):
        shutil.rmtree(test_root)

# Generated at 2022-06-21 02:07:17.774680
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test module run

    AnsibleActionFail: If source and destination are not strings,
                       If source or destination is not supplied,
                       If the remote file does not exist, not transferring, ignored.
                       If the path ends with "/", we'll use the source filename as the destination filename
                                              , use a trailing slash if you want to fetch src into that directory
                                              , use a trailing slash if you want to fetch src into that directory
                       If dest does not start with "/", we'll assume a relative path
    AnsibleActionSkip: If check mode not (yet) supported for this module
    AnsibleError:     If remote file is a directory, fetch cannot work on directories
    """
    action = ActionModule()
    action._connection = MockConnection()
    action._connection._shell = MockShell()
    action._loader = MockTask()
    action._play

# Generated at 2022-06-21 02:07:21.504963
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module

# Generated at 2022-06-21 02:07:29.284501
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_obj = ActionModule()
    source = "source"
    dest = "destination"
    flat = True
    fail_on_missing = True
    validate_checksum = True

    setattr(test_obj, '_connection', AnsibleActionModule)
    setattr(test_obj, '_task', AnsibleActionModule)
    setattr(test_obj, '_play_context', AnsibleActionModule)
    setattr(test_obj, '_loader', AnsibleActionModule)

    # When remote_checksum is not in the values specified, then the result should be successful
    task_vars = dict(remote_stat='md5')
    setattr(test_obj, '_task', AnsibleActionModule)

# Generated at 2022-06-21 02:07:33.102979
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-21 02:07:37.902145
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # No exception expected
    # No exception expected
    # No exception expected
    try:
        my_action = ActionModule()
        my_action.run()
    except Exception as err:
        raise AssertionError(err)

    # No exception expected
    try:
        my_action = ActionModule()
        my_action.run()
    except Exception as err:
        raise AssertionError(err)

# Generated at 2022-06-21 02:07:43.981483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(connection=None, task_vars=None, tmp=None, loader=None, play_context=None, shared_loader_obj=None, variable_manager=None)

    assert am.name == 'fetch'
    assert am.action == 'copy'
    assert am.connection == None
    assert am.task_vars == None
    assert am.tmp == None
    assert am.loader == None
    assert am.play_context == None
    assert am.shared_loader_obj == None
    assert am.variable_manager == None


# Generated at 2022-06-21 02:07:53.446892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global module_args
    module_args = dict()
    module_args['src'] = 'dummy_source'
    module_args['dest'] = 'dummy_destinations'
    module_args['validate_checksum'] = 'true'
    module_args['fail_on_missing'] = 'false'
    module_args['flat'] = 'true'
    tmp_result = ActionModule.run(ActionModule, 'dummy_tmp', 'dummy_task_vars')
    assert tmp_result == None

# Generated at 2022-06-21 02:08:06.335822
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import tempfile
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.action import ActionBase

    class ActionModuleTest(ActionModule):
        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()

# Generated at 2022-06-21 02:08:39.109806
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:08:42.221766
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule
    """
    module = ActionModule()
    assert(module is not None)

# Generated at 2022-06-21 02:08:42.952505
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:08:54.817517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = '127.0.0.1'
    transport = 'local'
    port = 1234
    connection = AnsibleConnection(host, port, transport)

    play_context = PlayContext()
    play_context.perform_step = False
    play_context.check_mode = True
    play_context.remote_addr = host

    task = dict(action='fetch', args=dict(src='/abc/def', dest='/tmp'))
    action_module = ActionModule()

# Generated at 2022-06-21 02:09:07.019400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test throws an exception if the source file does not exist
    module_args = dict(src='/foo/bar', dest='/baz/qux')
    tmp = None
    task_vars = {}

    am = ActionModule(None, tmp, task_vars, module_args)
    am._execute_remote_stat = lambda x, all_vars, **kwargs: dict(exists=False)
    result = am.run(tmp, task_vars)

    assert result['failed'] is True
    assert result['msg'] == 'the remote file does not exist, not transferring, ignored'
    assert result['file'] == '/foo/bar'

    # Test if the file does not exist locally but exists remotely
    module_args = dict(src='/foo/bar', dest='/baz/qux')

# Generated at 2022-06-21 02:09:09.459325
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # (p_module, p_connection)
    module = ActionModule("", "")
    assert module is not None

# Generated at 2022-06-21 02:09:18.155818
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # In this testcase, we consider the following task as input
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    task = Task()
    task._role = None
    task.args = {'src': '~/test.txt', 'dest': '~/res.txt'}
    task.name = "action-name"

    # Create a valid play context object to populate the connection fields of ActionModule
    play_context = PlayContext()
    # Populate the connection fields of ActionModule
    play_context.connection = 'local'
    play_context.network_os = 'Default'
    play_context.remote_addr = 'localhost'
    play_context.remote_user = 'ansible'
    play_context.port = 22
    play_context.become_

# Generated at 2022-06-21 02:09:25.138073
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role.task import Task as RoleTask
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.conditional import Conditional

# Generated at 2022-06-21 02:09:36.308548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common import read_config
    from ansible.module_utils.network.common.utils import transform_commands
    from ansible.module_utils import basic
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.netcli import Conditional
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.connection.network_cli import Connection as NetworkCli
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-21 02:09:46.263447
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.utils.state import AnsibleState
    from ansible.plugins.loader import action_loader

    class ConnectionTest(object):
        def __init__(self):
            self.become = False
            self._shell_type = None
            self._shell = ShellModuleTest()

        def set_become(self, val):
            self.become = val

        def set_shell_type(self, val):
            self._shell_type = val


# Generated at 2022-06-21 02:10:56.201321
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError()

# Generated at 2022-06-21 02:10:59.535229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    cmd = ActionModule(
        in_data=dict(),
        task_vars=dict()
    )
    if isinstance(cmd, ActionModule) is False:
        print("test_ActionModule: ERROR - returned object is not of type ActionModule!")
    else:
        print("test_ActionModule: SUCCESS - returned object is of type ActionModule!")


# Generated at 2022-06-21 02:11:11.276363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.action.fetch import get_tmp_path
    from ansible.module_utils.parsing.convert_bool import boolean
    import os.path
    import shutil
    import tempfile

    # Create temporary directory to store files for testing
    tmpdir = tempfile.mkdtemp()
    testfile = os.path.join(tmpdir, 'testfile')
    testfile2 = os.path.join(tmpdir, 'testfile2')

# Generated at 2022-06-21 02:11:18.220744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connect = None
    m_task = None
    m_shared_loader_obj = None
    c_play_context = None
    c_connection = None
    m_loader = None
    action_module = ActionModule(m_task, m_shared_loader_obj, c_play_context, c_connection, m_loader)
    assert action_module is not None


# Generated at 2022-06-21 02:11:31.305641
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Run ActionModule:run with no error
    """
    # Test if the correct module is loaded.
    assert ActionModule._load_action_plugins() == ActionModule._action_plugins

    # Create an instance of the test class
    testobj = ActionModule(None)
    assert testobj is not None

    # Create the test variables
    testobj._task_vars = {'hostvars': {'localhost': '127.0.0.1'}}
    testobj._play_context = {'remote_user': None, 'forks': 1, 'port': 22}
    testobj._connection = {'become': False, 'tmpdir': '/tmp'}
    testobj.set_loader({'path': '/path/to/somewhere'})

# Generated at 2022-06-21 02:11:41.725196
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.connection import Connection
    task_vars = dict()
    localhost = {'hostname': 'localhost', 'ipv4': {'address': '127.0.0.1'}, 'port': 22}
    localhost['ansible_ssh_host'] = localhost['ipv4']['address']
    task_vars['inventory_hostname'] = 'localhost'
    task_vars['inventory_hostname_short'] = 'localhost'
    # Can't initialize a Display() object if DISPLAY environment variable is not set
    display_default = os.environ.get('DISPLAY')
    os.environ['DISPLAY'] = ':0'
    display = Display()
    if display_default:
        os.environ['DISPLAY'] = display_default

# Generated at 2022-06-21 02:11:43.559613
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:11:46.618984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am

# Generated at 2022-06-21 02:11:48.048365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    # TODO: no test case yet

# Generated at 2022-06-21 02:11:48.871910
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:14:54.950139
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:15:06.421642
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("TEST: ActionModule_run")

    result = {'failed': True, 'msg': '', 'changed': False}
    #
    # empty:
    #

    #
    # args with wrong type
    #
    args = dict(src=None, dest=None)

    a = ActionModule(task=dict(action=dict(module="fetch", args=args)), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    r = a.run()
    assert r['failed']

    #
    # args with no 'src' and 'dest'
    #
    args = dict()


# Generated at 2022-06-21 02:15:10.361773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # use the mock class instead of creating a new file
    import ansible.plugins.action.fetch
    f = ansible.plugins.action.fetch.ActionModule(None, None, None, None)
    assert f

# Generated at 2022-06-21 02:15:11.404685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_Host = ActionModule()
    assert test_Host

# Generated at 2022-06-21 02:15:12.470602
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None)

# Generated at 2022-06-21 02:15:17.559556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization
    action_module = ActionModule()

    # Invoke the run method
    result = action_module.run()

    # Check the result
    assert result is not None



# Generated at 2022-06-21 02:15:24.769648
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action

    # First instance of ActionModule is in fetch.py
    obj = ansible.plugins.action.ActionModule(
        {'name': 'test_action_plugin'},
        {},
        {},
        '/path/to/ansible_module'
    )

    assert obj
    assert obj._task.action == 'test_action_plugin'
    assert obj._shared_loader_obj
    assert obj._connection
    assert obj._shell
    assert obj._play_context
    assert obj._loader

# Generated at 2022-06-21 02:15:34.613953
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    mytask = dict(
        action=dict(module='fetch', args=dict(src='~/.bashrc', dest='/tmp/bashrc', validate_checksum=True))
    )

    pc = PlayContext()
    am = ActionModule(pc, mytask.copy(), TaskQueueManager())
    result = am.run(task_vars={})
    print(result)


if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-21 02:15:42.015098
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
        task=dict(
            args=dict(
                src = 'file',
                dest = 'filepath'
            )
        )
    )

    assert am is not None
    assert 'file' == am._task.args['src']
    assert os.path.abspath('filepath') == am._loader.path_dwim('filepath')