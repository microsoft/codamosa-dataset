

# Generated at 2022-06-21 02:06:01.861708
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

# Generated at 2022-06-21 02:06:09.341279
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.connection.local import Connection
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Create a mock connection object
    mock_connection = Connection()

    # Create a mock context object
    mock_context = PlayContext()

    # Create a temporary file for a playbook
    playbook = open('test_playbook', 'w')
    playbook.write('---\n- hosts: localhost\n  tasks:\n    - name: test this\n      ping:\n')
    playbook.close()

    # Create a mock playbook executor object

# Generated at 2022-06-21 02:06:17.530178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(Connection)

    # Generate fake task with action module
    action_module = dict(
        args=dict(src='/home/user1/testing_action_module_01.png', dest='/home/user2/testing_action_module_01.png')
    )
    task = dict(
        action=action_module
    )

    # Set variables to execute run
    task_vars = dict()
    task_vars['ansible_connection'] = 'local'
    task_vars['ansible_python_interpreter'] = '/usr/bin/python'
    task_vars['ansible_playbook_python'] = '/usr/bin/python'
    task_vars['playbook_dir'] = '/home/user2/testing_ansible_playbook_01'
    task

# Generated at 2022-06-21 02:06:24.184263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    x = [1]
    def _execute_remote_stat(source, all_vars, follow):
        x[0] = x[0] + 1
        if x[0] == 1:
            if sys.version_info.major >= 3:
                raise AnsibleError("")
            else:
                raise Exception("")
        file_dict = {
            "path": "file1",
            "mode": "0600",
            "size": 12345,
            "uid": 1000,
            "gid": 1000,
            "mtime": 1469453330,
        }
        return file_dict

# Generated at 2022-06-21 02:06:32.483549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create play_context without callback plugin
    #play_context = PlayContext()
    #play_context.network_os='default'
    #play_context.become=False
    #play_context.become_method='default'
    #play_context.become_user='default'
    #play_context.check_mode=False

# Generated at 2022-06-21 02:06:33.897775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor doesn't take any parameters
    action = ActionModule()
    assert hasattr(action, '_execute_module')

# Generated at 2022-06-21 02:06:36.134934
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule().run({'src': '/path/to/source', 'dest': '/path/to/dest'})

# Generated at 2022-06-21 02:06:39.389495
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(load_args_from_file=False, task=None);

# Generated at 2022-06-21 02:06:40.317809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule(None, None, None, None)



# Generated at 2022-06-21 02:06:47.494216
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    connection = MockConnection()

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(default=None, type='str'),
            dest=dict(default=None, type='str'),
            flat=dict(default=0, type='bool'),
            # validate_checksum=dict(default=0, type='bool'),
            # fail_on_missing=dict(default=0, type='bool'),
            # original_basename=dict(default=0, type='bool'),
            # follow=dict(default=0, type='bool'),
        ),
        supports_check_mode=True
    )


# Generated at 2022-06-21 02:07:05.629280
# Unit test for constructor of class ActionModule
def test_ActionModule():
    conn = Connection(None)
    m = ActionModule(conn, None, None)
    pass



# Generated at 2022-06-21 02:07:10.364626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_instance = ActionModule()
    print(test_instance.run())


if __name__ == '__main__':
    # Unit test for class ActionModule
    test_ActionModule_run()

# Generated at 2022-06-21 02:07:15.614002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.common.text.converters import to_bytes
    testobj = ActionModule(None, {'charge': 'ampere'})
    assert testobj.charge == 'ampere'
    assert testobj._task.args == {'charge': 'ampere'}

# Generated at 2022-06-21 02:07:26.181401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.fetch as namespace_class
    actionplugin_class = namespace_class.ActionModule
    actionplugin_object = actionplugin_class()
    # Default values of params - Empty.
    assert actionplugin_object._connection == None
    assert actionplugin_object._task == None
    assert actionplugin_object._play_context == None
    assert actionplugin_object._loader == None
    assert actionplugin_object._templar == None
    assert actionplugin_object._shared_loader_obj == None
    assert actionplugin_object._task_vars == None
    assert actionplugin_object._loader_cache == None

# Generated at 2022-06-21 02:07:38.014077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    # As we do not use the modeules/__init__.py we need to create a mock for ActionBase.run
    def _run(self, tmp=None, task_vars=None):
        return {'tmp': tmp, 'task_vars': task_vars}
    module._run = _run

    # We also need a display() method for the success
    def display(self, msg):
        print (msg)

    display.display = display

    assert module.run(1, 2) == {'tmp': 1, 'task_vars': 2}


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 02:07:42.702172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import utils
    from ansible.utils import template
    from ansible.utils import plugins
    from ansible.utils import module_finder
    from ansible.plugins import action
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars

    # Initialize Action plugin class
    A = ActionModule(
        task=dict(action='fetch', args=dict(
            src='test.log', dest='test.log'
        )),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=template.Templar(loader=None),
        shared_loader_obj=None
    )
    A._remove_tmp_path = lambda: None # Do nothing
    A._

# Generated at 2022-06-21 02:07:50.605694
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.utils.path import makedirs_safe
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleActionFail, AnsibleActionSkip

# Generated at 2022-06-21 02:07:53.734519
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None, None, None)
    module.run()

# Generated at 2022-06-21 02:07:54.984852
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:08:00.728346
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = ActionModule.ActionModule().run({}, {})
    expected_result = {}
    assert expected_result == result, "ActionModule.ActionModule().run({}, {}) = %s, expected %s" % ((result), expected_result)

# Generated at 2022-06-21 02:08:46.206762
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.fetch import ActionModule
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.listify import listify_lookup_plugin_terms

    loader = DataLoader() # Takes care of finding and reading yaml, json and ini files
    passwords = dict() # dict containing connection info on a per host basis

    inventory = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-21 02:08:58.010122
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class ActionModule_mock(ActionModule):

        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._shared_loader_obj = shared_loader_obj

        def _remove_tmp_path(self, tmp_path):
            pass

        def _execute_remote_stat(self, **kwargs):
            fake_remote_stat = dict()
            fake_remote_stat['isdir'] = False
            fake_remote_stat['exists'] = True
            fake_remote_stat['checksum'] = 'FAKE_REMOTE_CHECKSUM'
            return fake_remote_stat


# Generated at 2022-06-21 02:09:01.641294
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(connection=None, task=None, loader=None, play_context=None, new_stdin=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:09:04.617939
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None

# Generated at 2022-06-21 02:09:07.351260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
            task=dict(),
            connection=dict(),
            play_context=dict(),
            loader=None,
            templar=None,
            shared_loader_obj=None)

    assert am is not None

# Generated at 2022-06-21 02:09:17.100023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleError
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    _template_fields = ['src']
    class ActionModule(object):

        def __init__(self):
            self._connection = None
            self._play_context = None
            self._task = None
            self._loader = None
            self._templar = None
            self._shared_loader_obj = None

    am = ActionModule()
    am._connection = object()
    am._play_context = PlayContext()
    am._loader = object()
    am._shared_loader_obj = object()

    play

# Generated at 2022-06-21 02:09:23.451614
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:09:25.213913
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

# Generated at 2022-06-21 02:09:26.512872
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()

# Generated at 2022-06-21 02:09:31.426641
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test simple get
    module = AnsibleActionModule('localhost', '/dummy', 'root', 'test')
    assert module.run() == {'changed': False, 'dest': '/dummy', 'file': '/dummy'}


# Generated at 2022-06-21 02:10:51.118672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.cli import CLI
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel

    display = Display()
    play_context = PlayContext()
    play_context.become = None
    play_context._set_pwd = lambda x: os.chdir(x)


# Generated at 2022-06-21 02:10:51.616386
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()

# Generated at 2022-06-21 02:10:55.032638
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing the constructor of ActionModule")
    print("Testing if all the members are initialized correctly")
    am = ActionModule()
    assert(am != None)

# Generated at 2022-06-21 02:11:01.643111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.common.text.converters import to_text
    from ansible.utils.hashing import checksum, checksum_s, md5, secure_hash

    # Assume that a file is present on remote location
    remote_file_path = 'test/remote.txt'
    remote_checksum = checksum(remote_file_path)
    remote_md5 = md5(remote_file_path)

    # Assume that this file doesn't exist locally
    dest_file_path = 'test/tmp/action_module_unit/local.txt'

    mock_task_args = dict(src=remote_file_path, dest=dest_file_path, validate_checksum=True)

    # Setup ActionModule object
    action_module = Action

# Generated at 2022-06-21 02:11:03.754837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule()
    assert t is not None

# Generated at 2022-06-21 02:11:12.290111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import shutil
    import tempfile
    import glob
    import sys

    # This class uses a lot of logging config.  It will also check for
    # the presence of any methods it needs for a test and skip the test
    # if they aren't there.
    from ansible.plugins.action import ActionBase
    from ansible.utils.hashing import checksum, checksum_s, checksum_s, secure_hash

    if getattr(ActionBase, "_execute_module", False):
        SKIP_MSG = "Test uses _execute_module, which has been removed from Ansible 2.8"
        raise unittest.SkipTest(SKIP_MSG)

    #sys.stderr.write("Workdir: %s\n" % os.getcwd())
    tempdir = tempfile.mkd

# Generated at 2022-06-21 02:11:18.806517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize connection._shell and shell with required params
    from ansible.connection.connection import Connection
    from ansible.plugins.shell.powershell import ShellModule as PowerShell
    from ansible.plugins.shell.cmd import ShellModule as Cmd
    connection = Connection(module_name="fetch", module_args={})
    if connection._shell is None:
        if connection.remote_addr.startswith("win"):
            connection._shell = PowerShell(connection)
            ansible.module_utils.connection.powershell.HAS_JSON = True
        else:
            connection._shell = Cmd(connection)
    shell = connection._shell
    # Initialize ActionModule
    module = ActionModule(connection=connection, shell=shell)
    # Initialize task._ds
    import ansible.plugins.action.fetch
    action = ans

# Generated at 2022-06-21 02:11:23.024782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Ensures that the action module can be instantiated and deleted
    :return:
    '''
    am = ActionModule()
    del am

# Generated at 2022-06-21 02:11:33.280454
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common import remove_values
    import ansible.module_utils.parsing.convert_bool as convert_bool
    import json

    # Create a mock connection
    class MyMockConnection():
        class MyMockShell():
            tmpdir = "/tmp/mytmpdir"

            def _unquote(self, path):
                return path

            def join_path(self, a, b):
                return "/".join([a, b])

        _shell = MyMockShell()
        become = False

        def fetch_file(self, src, dest):
            pass

    # Create a mock remote_stat
    class MyMockRemoteStat():
        def __init__(self):
            self.checksum

# Generated at 2022-06-21 02:11:38.561624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # import the class that is going to tested
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.connection.local import Connection
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    import ansible.constants as C
    from ansible.executor.stats import AggregateStats

    # Initialize needed objects
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=[loader], sources=C.DEFAULT_HOST_LIST)

# Generated at 2022-06-21 02:14:59.465749
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.compat.tests import unittest
    import os
    os.chdir("/Users/mikael/Documents/ansible-source/hacking/testsuite")

    class TestActionModule(ActionModule):
        """ Basic test class for ActionModule"""

        def __init__(self, *args, **kwargs):
            super(TestActionModule, self).__init__(*args, **kwargs)

        def run(self, *args, **kwargs):
            print("Got through run")
            return super(TestActionModule, self).run(*args, **kwargs)

        def _execute_module(self, *args, **kwargs):
            return super(TestActionModule, self)._execute_module(*args, **kwargs)


# Generated at 2022-06-21 02:15:04.814292
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test the run method of class ActionModule
    # Create a simple task
    task = {'connection': 'local', 'action': 'mqtt_publish', 'module_name': 'mqtt', 'args': {'topic': 'test/topic', 'payload': 'payload', 'tls_ca_cert': 'tls_ca_cert', 'tls_cert': 'tls_cert', 'tls_key': 'tls_key', 'tls_version': 'tls_version', 'tls_insecure': False, 'broker': 'broker'}}
    # Create a connection

# Generated at 2022-06-21 02:15:14.563104
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = dict(
        ansible_host='example.com',
        ansible_user='test',
        ansible_ansible_host='example.com',
        ansible_ansible_user='test',
        ansible_ansible_pass='test',
    )
    connection = dict(
        ansible_host='example.com',
        ansible_user='test',
        ansible_ansible_host='example.com',
        ansible_ansible_user='test',
        ansible_ansible_pass='test',
        ansible_fetch_timeout=120,
        ansible_fetch_free_space_threshold=2,
    )
    task_vars = dict()

# Generated at 2022-06-21 02:15:25.419093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.executor.task_queue_manager as task_queue_manager
    import ansible.plugins.connection.local as connection_local

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager()
    variable_manager.set_inventory(inventory)
    host = inventory.add_host('localhost')
    task = Task()
    task.set_loader(loader)
    task.action = 'fetch'
    task.args = { 'src': 'readme', 'dest': '/tmp/readme' }

# Generated at 2022-06-21 02:15:29.738705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(am, ActionModule)

# Generated at 2022-06-21 02:15:31.908272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None)
    assert a is not None

# Generated at 2022-06-21 02:15:38.342584
# Unit test for constructor of class ActionModule
def test_ActionModule():
	mock_shell = mock_action_module = None
	mock_task = mock_connection = None

	mock_task = mock.Mock()
	mock_task._role = None
	mock_task.args = {}
	mock_task.action = 'fetch'
	mock_task.args = {'dest': 'dest', 'src': 'src'}
	mock_task.async_val = 15
	mock_task.notify = []
	mock_task.run_once = False
	mock_task.delegate_to = None
	mock_task.environment = {}

	# From module "ansible.plugins.action.copy.ActionModule"
	mock_action_module = mock.Mock()

# Generated at 2022-06-21 02:15:42.768742
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Constructor of ActionModule class should not raise any exception """
    action_module = ActionModule(None, None, None, None, None)
    assert action_module is not None
