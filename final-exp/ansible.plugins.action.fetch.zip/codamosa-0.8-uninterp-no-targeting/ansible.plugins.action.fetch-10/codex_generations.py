

# Generated at 2022-06-21 02:06:03.380629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:06:11.061300
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  from ansible.executor import TaskExecutor
  from ansible.executor.task_queue_manager import TaskQueueManager
  from ansible.inventory import Inventory
  from ansible.parsing.dataloader import DataLoader
  from ansible.playbook.play import Play
  from ansible.playbook.task import Task

  from ansible.vars.manager import VariableManager

  result = dict(msg="", rc=0)

  loader = DataLoader()
  inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='localhost,')
  variable_manager = VariableManager(loader=loader, inventory=inventory)

  play_source = dict(
    name = 'test'
  )

  play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
  qm

# Generated at 2022-06-21 02:06:18.936698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path'),
            dest=dict(type='path'),
        ),
    )
    # Prepare the data.
    test_path = os.path.abspath("tests/fetch")
    inventory_file = os.path.join(test_path, "inventory_get")
    play_source = os.path.join(test_path, "ansible_get.yml")
    play_dest = os.path.join(test_path, "ansible_get_result.yml")
    module_utils = os.path.join(test_path, "module_utils.py")

# Generated at 2022-06-21 02:06:19.476016
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:06:28.457337
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.utils import module_compression
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import PluginLoader

    am = ActionModule(task=dict(action=dict(args=dict(src='test1.sh', dest='test1.sh'))))

    # test _execute_remote_stat method
    assert isinstance(am._execute_remote_stat('test1.sh'), dict)
    # test _execute_module method
    assert am._execute_module(module_name='ansible.legacy.slurp', module_args={'src': 'test1.sh'}) is not None
    # test _remote_expand

# Generated at 2022-06-21 02:06:37.551055
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(loader=None, connection=None, play_context=None,
                          new_stdin=None)

    # test fields initialized
    assert action.task_vars == {}, "task_vars not initialized to empty dict"
    assert action.noop_task_vars == {}, "noop_task_vars not initialized to empty dict"
    assert action.loader == None, "loader not initialized to None"
    assert action.connection == None, "connection not initialized to None"
    assert action.play_context == None, "play_context not initialized to None"
    assert action._new_stdin == None, "_new_stdin not initialized to None"
    assert action.tmp == None, "tmp not initialized to None"

# unit test for _execute_module
#def test__execute_module():
   

# Generated at 2022-06-21 02:06:48.499682
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given
    # Simple implementation for AnsibleActionSkip, AnsibleActionFail, ActionBase, all others simply raise not implemented
    class MyActionBase(ActionBase):
        class MyAnsibleActionFail(AnsibleActionFail):
            pass
        class MyAnsibleActionSkip(AnsibleActionSkip):
            pass

        def __init__(self, task_vars, check_mode):
            self._task = None
            self._play_context = None
            self._connection = None
            self._loader = None
            self._task_vars = task_vars
            self._check_mode = check_mode
        def _execute_remote_stat(self, *args, **kwargs):
            if 'fail' in kwargs:
                if kwargs['fail']:
                    raise MyActionBase.MyAnsible

# Generated at 2022-06-21 02:06:49.927885
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #Try to remote connect as a test
    pass

# Generated at 2022-06-21 02:06:53.877495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # ActionModule.run()
    # Currently not available due to bug
    # https://github.com/ansible/ansible/issues/18086
    pass

# Generated at 2022-06-21 02:07:02.500851
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class MyActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(MyActionModule, self).run(tmp, task_vars)

    result = {
        'failed': False,
        'msg': ''
    }

    task_vars = {
        'remote_addr': '',
        'inventory_hostname': '',
        'ansible_python_interpreter': '',
        'ansible_playbook_python': ''
    }

    test_args = {
        'src': 'files/bot.png',
        'dest': 'files',
        'validate_checksum': False,
        'fail_on_missing': False
    }

    test_task = {
        'args': test_args
    }


# Generated at 2022-06-21 02:07:28.994104
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a test module for testing run method of class ActionModule
    class ActionModuleTest(ActionModule):
        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()

            result = super(ActionModuleTest, self).run(tmp, task_vars)
            del tmp  # tmp no longer has any effect


# Generated at 2022-06-21 02:07:32.090604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    cache_file = mock_open.return_value
    module = ActionModule._get_dynamic_module_class('fetch')(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict())
    module.run()

# Generated at 2022-06-21 02:07:39.454947
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(connection="connection", play_context="play context", loader="loader", templar="templar", shared_loader_obj=None)
    assert module.connection == "connection", "Action module constructor failed to assign connection"
    assert module.play_context == "play context", "Action module constructor failed to assign play context"
    assert module.loader == "loader", "Action module constructor failed to assign loader"
    assert module.templar == "templar", "Action module constructor failed to assign templar"
    assert module.shared_loader_obj == None, "Action module constructor failed to assign shared_loader_obj"

# Generated at 2022-06-21 02:07:49.095907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # In this test the md5 function will return None because FIPS is enabled.
    args_fips_enabled = {'src': '/path/to/file', 'dest': '/path/to/dest', 'flat': 'no'}
    # The default values of flat and fail_on_missing are used when they are not specified in the task
    args_fail_on_missing_True = {'src': '/path/to/file', 'dest': '/path/to/dest'}
    args_fail_on_missing_False = {'src': '/path/to/file', 'dest': '/path/to/dest', 'fail_on_missing': 'no'}
    # Validate checksum is used when it is not specified in the task

# Generated at 2022-06-21 02:07:57.475206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.compat.tests import unittest

    a = ActionModule('test_action_module_run', {}, {}, {}, 'the_uni')
    a.connection = object()
    a.connection._shell = object()
    a.connection._shell.join_path = lambda x,y: x + y

    # Create _ansible_module_sourcedir for test
    tempdir = os.path.dirname(os.path.dirname(__file__))
    ModulesBaseDir = os.path.join(tempdir, 'ansible')
    ModuleUtilsBaseDir = os.path.join(tempdir, 'ansible', 'module_utils')
    LegacyModulesBaseDir = os.path.join(tempdir, 'ansible', 'modules')
   

# Generated at 2022-06-21 02:07:59.503807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Assert for the constructor of class ActionModule
    assert True

# Generated at 2022-06-21 02:08:01.635779
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(FakePlayContext())
    assert am._connection == 'local'

# Generated at 2022-06-21 02:08:03.128524
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None)


# Generated at 2022-06-21 02:08:04.078483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-21 02:08:09.469968
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create test object without "super".
    test_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert test_obj is not None

# Generated at 2022-06-21 02:08:46.681442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:08:58.239560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.path import makedirs_safe
    from ansible.utils.unicode import to_bytes
    from ansible.utils.hashing import checksum
    from ansible.module_utils.six import StringIO
    from ansible.plugins.action.copy import ActionModule

    test_action = ActionModule(connection=None,
                               task_vars=dict(inventory_hostname='test-host'),
                               loader=None,
                               templar=None,
                               shared_loader_obj=None)

    test_source = "test-source"
    test_dest = "test-dest"
    test_data = "test-data"

# Generated at 2022-06-21 02:09:05.991860
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestActionModule(ActionModule):
        def __init__(self, action_name, connection, task, task_vars):
            self._task = task
            self._play_context = task.play
            self._connection = connection
            self._task_vars = task_vars
    class TempModule(ActionModule):
        def __init__(self, action_name, connection, task, task_vars):
            self._task = task
            self._play_context = task.play
            self._connection = connection
            self._task_vars = task_vars
    class TestConnection:
        def __init__(self):
            self.become = False
    class TestPlay:
        def __init__(self):
            self.remote_addr = 'localhost'

# Generated at 2022-06-21 02:09:16.372247
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def test_validate_checksum_with_missing_local_file(monkeypatch):
        def join_path_mock(a, b):
            return "/tmp/ansible/source"

        def path_dwim_mock(a):
            return "/tmp/ansible/dest/source"

        monkeypatch.setattr(ActionModule, '_remote_stat', lambda self, source, all_vars, follow=False:
                             {'checksum': 'remote_checksum', 'size': 42, 'exists': True})
        monkeypatch.setattr(ActionModule, '_execute_module', lambda self, module_name, module_args, task_vars: {'failed': True})
        monkeypatch.setattr(ActionModule._connection._shell, 'join_path', join_path_mock)
        monkeypatch

# Generated at 2022-06-21 02:09:19.289633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=None)
    try:
        result = module.run()
    except Exception as e:
        result = e

    print("result: ")
    print(result)


# Generated at 2022-06-21 02:09:30.882732
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play

    context = PlayContext()
    queue_manager = TaskQueueManager(inventory=None, variable_manager=None, loader=None, options=None, passwords=None, stdout_callback=None)
    play = Play.load(dict(name = 'Test Play', hosts = 'localhost', gather_facts = 'no', tasks = [dict(action='fetch', register='local_result')]), variable_manager=None, loader=None)


# Generated at 2022-06-21 02:09:36.493009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""

    # Create an empty ActionModule class
    action_module = ActionModule(connection=connection, play_context=play_context, loader=loader,
        templar=templar, shared_loader_obj=shared_loader_obj)

    # Assert that the method run returns a dict containing 'src' and 'dest'
    result = action_module.run()

    assert type(result) == dict
    assert 'src' in result
    assert 'dest' in result


# Generated at 2022-06-21 02:09:38.345289
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:09:39.006104
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:09:40.039689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    pass



# Generated at 2022-06-21 02:10:59.447120
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    am = ActionModule(
        task=dict(action=dict(module='fetch')),
        connection=None,
        play_context=PlayContext(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert am

# Generated at 2022-06-21 02:11:04.993992
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import ansible.plugins.action
    action_result = ansible.plugins.action.ActionModule(None, None, None)
    assert isinstance(action_result, ansible.plugins.action.ActionBase)

# Generated at 2022-06-21 02:11:05.878985
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:11:06.690062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:11:07.566300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

# Generated at 2022-06-21 02:11:08.941583
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # pylint: disable=deprecated-method
    assert ActionModule._shared_loader_obj is True
    assert ActionModule._uses_shell is True

# Generated at 2022-06-21 02:11:10.989116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule(None, None)

# Generated at 2022-06-21 02:11:14.566736
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.fetch import ActionModule

    at = ActionModule(load_name='ansible.plugins.action.fetch', action_name='fetch', task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # test for exception  AnsibleActionFail
    at.run(tmp=None, task_vars=None)

# Generated at 2022-06-21 02:11:20.111398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible import callbacks
    from ansible import utils
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.included import InventoryFileInclude
    from ansible.inventory.included import InventoryDirectoryInclude
    from ansible.inventory.included import Include
    from ansible.inventory.included import IncludedFile
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
   

# Generated at 2022-06-21 02:11:32.163437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.module_utils.connection import Connection
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.plugins.callback import CallbackBase
    import os

    module = action_loader.get('fetch', class_only=True)
    assert isinstance(module, ActionModule)

    play_context = PlayContext()
    play_context.check_mode = False


# Generated at 2022-06-21 02:14:51.459409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if None:
        import ansible.plugins.action.fetch
        a=ansible.plugins.action.fetch.ActionModule(None, None, None, None, None, None, None)
        a.run()

# Generated at 2022-06-21 02:14:59.186023
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    play_context = dict(
        port=22,
        remote_user='vagrant',
        connection='ssh',
        network_os='default',
        become=False,
        become_method='sudo',
        become_user='root',
        check=False
    )

    play = Play().load({
        'name': 'test play',
        'hosts': 'testhost',
        'gather_facts': 'no',
        'tasks': [
            dict(action=dict(module='fetch', args=dict(src='/tmp/sourcefile', dest='/tmp/destfile')), register='output')
        ]
    }, variable_manager=None, loader=None)

    t = Task()

# Generated at 2022-06-21 02:14:59.982325
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1

# Generated at 2022-06-21 02:15:07.776482
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # raise exception if not isinstance(action, ActionBase)

    # raise exception if not isinstance(action._result, dict)

    # raise exception if not isinstance(action._loader, DataLoader)

    # raise exception if not isinstance(action._templar, Templar)

    # raise exception if not isinstance(action._shared_loader_obj, SharedPluginLoaderObj)

    # raise exception if not isinstance(action._shared_loader_obj._name, str)

    # raise exception if not isinstance(action._connection, Connection)

    # raise exception if not isinstance(action.display, Display)

    # raise exception if not isinstance(action._task, Task)
    pass

# Generated at 2022-06-21 02:15:17.901423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """
    class MockConnection(object):
        def __init__(self, become=False):
            self.become = become

        def fetch_file(self, source, dest):
            pass

        def _shell(self):
            class MShell(object):
                def join_path(self, path, *paths):
                    return path

                def _unquote(self, path):
                    return path
            return MShell

    class MockLoader(object):
        def path_dwim(self, path):
            return path

    class MockTask(object):
        def __init__(self, module_args):
            self.args = module_args


# Generated at 2022-06-21 02:15:26.447378
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.module_common import ModuleResult
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.manager import InventoryManager

    class TestActionModule(ActionModule):
        def _execute_module(self, module_name, module_args=None, task_vars=None, wrap_async=None):
            class FakeModuleResult(ModuleResult):
                def __init__(self):
                    self.return_values = dict(changed=False, file='fake-file', src='fake-file')

                def to_json(self):
                    return self.return_values
            return FakeModuleResult()


# Generated at 2022-06-21 02:15:28.080689
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case 1
    assert True


# Generated at 2022-06-21 02:15:35.575140
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for constructor of class ActionModule'''

    # Test empty constructor
    my_obj = ActionModule()
    assert my_obj.__dict__ == {}

    # Test constructor with args
    my_obj = ActionModule('test1', 'test2', 'test3')
    assert my_obj.__dict__['_arg1'] == 'test1'
    assert my_obj.__dict__['_arg2'] == 'test2'
    assert my_obj.__dict__['_arg3'] == 'test3'


# Generated at 2022-06-21 02:15:43.812262
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_constructor = ActionModule(u'/ansible/action/library_root', u'library_path', u'action_name',
                                             dict(), dict(), dict(), u'/ansible/connection/connection_plugin',
                                             dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(),
                                             dict(), dict(), dict(), dict(), dict())
    assert action_module_constructor is not None

# Generated at 2022-06-21 02:15:55.426370
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=DataLoader(), sources=None)
    variable_manager = VariableManager(loader=DataLoader())
    loader = DataLoader()
    play_context = PlayContext()
    task_queue_manager = TaskQueueManager(
            inventory=inventory,
            variable_manager=variable_manager,
            loader=loader,
            play_context=play_context,
            hosts=None,
        )

    task = Task()