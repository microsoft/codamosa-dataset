

# Generated at 2022-06-21 02:06:00.380388
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule("test.yml")

# Generated at 2022-06-21 02:06:03.443713
# Unit test for constructor of class ActionModule
def test_ActionModule():

    result = {}
    task_vars = {}
    play_context = {}

    module = ActionModule(task=None, connection=None, play_context=play_context, loader=None, templar=None, shared_loader_obj=None)
    module.run(result, task_vars)

# Generated at 2022-06-21 02:06:11.096297
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # import modules used by ActionModule on init
    import os
    import sys
    import tempfile
    import unittest
    import shutil
    import filecmp

    # Preparing test objects
    host = "test_host"
    task_name = "test_task"
    play_context = PlayContext()

    # Preparing test fixtures
    sourcedata = "This is a test"
    sourcedata2 = "This is another test"
    sourcedata3 = "This is yet another test"

    # Preparing tempdir, srcfile and dstfile
    testdirectory = tempfile.gettempdir()
    srcfile = os.path.join(testdirectory,'srcfile')
    dstfile1 = os.path.join(testdirectory,'d1')

# Generated at 2022-06-21 02:06:13.354404
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'
    assert ActionModule.__doc__ == 'Base action plugin class for fetch actions'

# Generated at 2022-06-21 02:06:25.905726
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test ActionModule with valid parameters
    # Test case 1
    src_valid_1 = '~/.ssh/id_rsa.pub'
    dest_valid_1 = '/tmp'
    args_valid_1 = dict(src=src_valid_1, dest=dest_valid_1)
    action_module_mock_1 = ActionModule()
    task_vars_mock_1 = dict(ansible_connection='ssh')
    result_valid_1 = action_module_mock_1.run(task_vars=task_vars_mock_1, **args_valid_1)

# Generated at 2022-06-21 02:06:31.005775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.common.text.converters import to_text
    action = ActionModule(None, {'foo': 'bar'}, None, None)
    assert action._task.action == 'foo'
    assert action._task.args == {'foo': 'bar'}
    assert action._task.module_name == 'foo'
    assert action._play_context.remote_addr is None
    assert action._play_context.connection == 'local'
    assert to_bytes(action._loader.path_dwim('foo')) == b'/tmp/ansible_foo_payload/foo'
    assert action._remove_tmp_path('foo') is None
    assert action._display.display('foo', 'debug') is None
    assert action._display.vv('foo') is None
    assert action._display.v

# Generated at 2022-06-21 02:06:31.826107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:06:40.662380
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:06:46.269316
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    import shutil
    import random
    import string
    import subprocess

    # Use the old method of setting C.DEFAULT_REMOTE_TMP for the tempdir path, because the code
    # under test does not let us set alternate paths for remote_tmp
    tempdir = tempfile.mkdtemp()
    saved_cwd = os.getcwd()


# Generated at 2022-06-21 02:06:52.334498
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(runner = None,
                          connection = None,
                          play_context = None,
                          loader = None,
                          templar = None,
                          shared_loader_obj = None)
    assert module

# Generated at 2022-06-21 02:07:19.237322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins import plugin_loader
    from ansible.vars.manager import VariableManager

    plugin_loader.add_directory('./plugins')

    host = 'localhost'
    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    play_context = PlayContext(remote_addr='127.0.0.1')

# Generated at 2022-06-21 02:07:28.547279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup environment for testing.
    from ansible.plugins.action import ActionModule
    from ansible.utils.path import makedirs_safe
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager._extra_vars = {'ansible_ssh_user': 'ansible', 'ansible_ssh_pass': 'ansible'}
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    # Create local directories to be used in fetch action.
    makedirs_safe('/tmp/test/test')

# Generated at 2022-06-21 02:07:35.985632
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.executor.task_queue_manager import TaskQueueManager

    myPlay = Play()
    playRole = Role()
    myPlay.post_validate()
    myPlay.main()
    myPlay.run()
    myPlay.serialize()

# Generated at 2022-06-21 02:07:39.792545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(loader=None,
                          connection=None,
                          play_context=None,
                          new_stdin=None)
    assert module is not None

# Generated at 2022-06-21 02:07:49.291413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from unittest import TestCase
    from ansible.plugins.action import ActionBase
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import connection_loader
    from ansible.errors import AnsibleActionFail, AnsibleActionSkip
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

# Generated at 2022-06-21 02:07:51.668738
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import Play
    from ansible.playbook import PlayContext

    play_context = PlayContext()
    play = Play.load({}, variable_manager={}, loader=None, play_context=play_context)
    ActionModule(play=play)

# Generated at 2022-06-21 02:07:54.057047
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(tmp='/tmp', task_vars=None)
    assert am.module_name == ''
    

# Generated at 2022-06-21 02:07:56.067002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)


# Generated at 2022-06-21 02:07:58.011880
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-21 02:07:58.914386
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

# Generated at 2022-06-21 02:08:33.097398
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-21 02:08:38.536520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("testing constructor of ActionModule class")
    # TODO: check that the class doesn't throw an exception with bad params
    # the values used here don't matter since it's the constructor
    ActionModule(play_context={}, connection={})


# Generated at 2022-06-21 02:08:39.393030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:08:41.102908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.fetch as action_fetch

    # Ensure that 'ansible.plugins.action.fetch.ActionModule' is a class
    action_fetch.ActionModule.__class__

# Generated at 2022-06-21 02:08:46.559294
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_source = dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(name="copy default config to remote", action=dict(module="copy", src="~/src", dest="~/dest"))
            ]
        )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    tqm

# Generated at 2022-06-21 02:08:58.162380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_host = 'testhost'
    test_path = '/test/path'
    test_dest = '/test/dest'
    test_file = 'test.txt'
    test_file_path = '{0}{1}{2}'.format(test_path, os.sep, test_file)

    module_exec_results = {
        'failed': False,
        'msg': '',
        'content': base64.b64encode(b'Test file contents'),
        'encoding': 'base64'
    }

    def _create_module_exec_side_effect(module, args):
        if module == 'ansible.legacy.slurp':
            # TODO: This needs to be added to the mock function, as currently it is hard-coded
            assert args['src'] == test_file_path

# Generated at 2022-06-21 02:09:09.265419
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 1: source is None and dest is None
    # Expectation: failed
    source = None
    dest = None
    actionModule = ActionModule()
    # source and dest are required
    msg = "src and dest are required"
    assert_exception(source, dest, actionModule, msg)

    # Test case 2: source is None
    # Expectation: failed
    source = None
    dest = "sample_path"
    actionModule = ActionModule()
    msg = "Invalid type supplied for source option, it must be a string"
    assert_exception(source, dest, actionModule, msg)

    # Test case 3: dest is None
    # Expectation: failed
    source = "sample_path"
    dest = None
    actionModule = ActionModule()

# Generated at 2022-06-21 02:09:18.061322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # (a) Set up: create needed mocks and initialize ActionModule
    am = ActionModule(task=None, runner=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # (b) Set up: set the return values of the needed mocks
    # (b.1) _remove_tmp_path
    am._remove_tmp_path = _remove_tmp_path
    def _remove_tmp_path(tmp_path):
        return
    # (b.2) _execute_remote_stat
    am._execute_remote_stat = _execute_remote_stat
    def _execute_remote_stat(source, all_vars, follow):
        return {'exists': True, 'isdir': False}
    # (b.3) _execute

# Generated at 2022-06-21 02:09:18.923587
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None)
    del action_module

# Generated at 2022-06-21 02:09:20.996539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(runner=None)
    assert a != None

# Generated at 2022-06-21 02:10:33.120242
# Unit test for constructor of class ActionModule
def test_ActionModule():

    for cls in ActionModule.__subclasses__():
        obj = cls(task=dict(vars=dict()), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:10:40.526678
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C

    class TestConnectionPlugin:
        def __init__(self):
            self.var = 0
            self.tmpdir = '/tmp/test'

        def set_options(self, options):
            pass


# Generated at 2022-06-21 02:10:44.762490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None, None, None)
    a._play_context = None
    a._task = None
    assert a.run() is None



# Generated at 2022-06-21 02:10:46.880973
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:10:47.686952
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:10:59.658772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    # test the validation of source and dest strings
    assert 'type supplied for source option' in module.run(task_vars = {}, tmp = None)['msg']
    assert 'type supplied for dest option' in module.run(task_vars = {'src': 'Hello'}, tmp = None)['msg']
    assert 'src and dest are required' in module.run(task_vars = {'dest': 'Hello'}, tmp = None)['msg']
    # Test flat
    assert 'dest is an existing directory' in module.run(task_vars = {'src': 'Hello', 'dest': '.', 'flat': 'True'}, tmp = None)['msg']

# Generated at 2022-06-21 02:11:02.217392
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-21 02:11:10.409679
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    play_context = PlayContext()
    play_context.remote_addr = 'foo.example.org'
    task = Task()
    task.args = dict(src='/tmp/test', dest='/tmp/foo')
    am = ActionModule(task, play_context, '/path/to/ansible/local')
    assert am._remote_checksum == '/path/to/ansible/local/lib/ansible/modules/files/fetch.py'

# Generated at 2022-06-21 02:11:16.009828
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This is expected to succeed
    test_obj = ActionModule(None, None, None, None)
    assert test_obj is not None

    # This is expected to fail
    # test_obj2 = ActionModule(None, None, None)


# Generated at 2022-06-21 02:11:16.835179
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run()

# Generated at 2022-06-21 02:14:26.980443
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:14:32.916956
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Create an instance of ActionModule and return it
    """

    # create mock for ansible.plugins.action.ActionBase
    mock_ActionBase = MagicMock(spec=ActionBase)

    am = ActionModule(mock_ActionBase)

    return am


# Generated at 2022-06-21 02:14:39.217918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = AnsibleModule(
        argument_spec = dict(
            src = dict(required=True, type='str'),
            dest = dict(required=True, type='str'),
            flat = dict(required=False, type='bool', default=False),
            fail_on_missing = dict(required=False, type='bool', default=True),
            validate_checksum = dict(required=False, type='bool', default=True)
        )
    )

    am.run()
    assert am.result == dict(
        msg="a"
    )


# Generated at 2022-06-21 02:14:48.395990
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Check if all the required arguments work
    args_dict = dict(
        src="src.txt",
        dest="dest.txt",
        flat=True,
        remote_user="user",
        )
    obj = ActionModule(**args_dict)
    assert obj.module_name == 'fetch'
    assert obj._connection == None

    # Check if all the non required arguments work
    args_dict = dict(
        src=None,
        dest=None,
        flat=False,
        remote_user=None,
        )
    obj = ActionModule(**args_dict)
    assert obj.module_name == 'fetch'
    assert obj._connection == None

# Generated at 2022-06-21 02:14:57.320925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Uses the unittest.mock package to test the constructor of the ActionModule class.
    
    Returns:
        None
    """

    from unittest.mock import Mock
    # Mock imports needed for the constructor
    import ansible.plugins.action.normal
    import ansible.plugins.connection.ssh
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    ansible_connection = ansible.plugins.connection.ssh.Connection('localhost', Mock())
    mock_task = TaskQueueManager(ansible_connection,'localhost')
    mock_task._play_context = Mock
    mock_task._play_context._play = Mock
    mock_task._play_context

# Generated at 2022-06-21 02:14:59.232630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(connection='connection')
    assert module._connection == 'connection'

# Generated at 2022-06-21 02:15:04.518333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert type(action._display) is Display
    assert type(action._task) is dict
    assert type(action._connection) is Connection
    assert type(action._play_context) is PlayContext
    assert type(action._loader) is DataLoader
    assert type(action._templar) is Templar

# Generated at 2022-06-21 02:15:05.310139
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert True

# Generated at 2022-06-21 02:15:09.894542
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.fetch import ActionModule as AModule
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    results_callback = ResultCallback()

    inventory = InventoryManager(loader=loader, sources=['localhost,', 'otherhost,'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()

# Generated at 2022-06-21 02:15:18.907674
# Unit test for method run of class ActionModule