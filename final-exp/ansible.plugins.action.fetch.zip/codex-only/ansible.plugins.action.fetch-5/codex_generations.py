

# Generated at 2022-06-23 07:47:37.558709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.plugins.action.fetch import ActionModule

    assert isinstance(ActionModule.run, object)

    Failed = False
    module_args = dict(
        dest=to_text('~/user/tests/junkfile.txt'),
        src=to_text('/etc/ansible/junkfile.txt'),
        validate_checksum=to_text('False'),
        flat=to_text('True')
    )

    display.verbosity = 4
    tmp = None

# Generated at 2022-06-23 07:47:41.574203
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(runner=0, task=0, ignore_conditions=0, connection=0, play_context=0, loader=0, templar=0, shared_loader_obj=0)
    module.run(tmp='test', task_vars='test')


# Generated at 2022-06-23 07:47:44.671866
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert isinstance(am, ActionModule)
    assert isinstance(am._play_context, ActionModule._play_context)
    assert am._display is not None

# Generated at 2022-06-23 07:47:45.996433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("testing ActionModule constructor.")


# Generated at 2022-06-23 07:47:47.370584
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule()
    except TypeError:
        assert False

# Generated at 2022-06-23 07:47:52.667565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext

    tc = TaskInclude(play=dict(name='play 1'))
    pc = PlayContext()

    action_module = ActionModule(task=tc, connection=None, play_context=pc, loader=None, templar=None, shared_loader_obj=None)

    assert action_module is not None

# Generated at 2022-06-23 07:48:02.407214
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule.
    '''

    # Test parameters
    task_vars = dict()

    # Test response
    response = dict(failed=False, changed=False, md5sum='32d10c7b8cf96570ca04d7b98633cb13', file='/home/nonroot/u01/app/oracle/.db_profile', dest='/home/nonroot/u01/app/oracle/.db_profile', remote_md5sum=None, checksum='86d94b6493c74e5aa9d5d5a5b5a40b95', checksum_src=None, remote_checksum=None)

    real_response = ansible.plugins.action.fetch.ActionModule(None, None).run(None, task_vars)

# Generated at 2022-06-23 07:48:11.768164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(
        argument_spec = dict(
            src = dict(type='path',required=False),
            dest = dict(type='path',required=False),
            flat = dict(type='bool',required=False),
            fail_on_missing = dict(type='bool',required=False),
            validate_checksum = dict(type='bool',required=False),
        ),
        supports_check_mode=True
    )

    module.exit_json(foo=module.params['src'])

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-23 07:48:19.389198
# Unit test for constructor of class ActionModule
def test_ActionModule():

    _task = dict(
        action=dict(
            module_name="fetch",
            module_args=dict(
                src="source",
                dest="dest",
                fail_on_missing=True,
                validate_checksum=True,
            ),
        )
    )

    _task_vars = dict()
    _tmp = "/tmp"

    am = ActionModule(_task, _task_vars, _tmp)

    assert am._task == _task
    assert am._task_vars == _task_vars
    assert am._tmp == _tmp

    return am


# Generated at 2022-06-23 07:48:27.663636
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.core import ActionModule as m
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    host = Host(name="localhost")
    inventory._inventory.add_host(host)
    play_context = PlayContext()
    connection = 'local'
    play_context.network_os = 'default'
    play_

# Generated at 2022-06-23 07:48:33.272213
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    action = os.path.join(os.getcwd(), 'lib/ansible/modules/extras/monitoring/nagios/check_dummy.py')
    module._task.args['src'] = action
    module._task.args['dest'] = '/tmp/check_dummy.py'
    module.run()

# Generated at 2022-06-23 07:48:39.566760
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import logging
    import os
    import sys
    import unittest

    sys.path.insert(0, os.path.join(os.getcwd(), 'lib'))

    if "ANSIBLE_LOG_PATH" in os.environ:
        logging.basicConfig(filename=os.environ["ANSIBLE_LOG_PATH"], level=logging.DEBUG)

    print("SUCCESS")


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 07:48:46.577190
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(loader=None, connection=None, play_context=None)

    # check if attributes are initialized to None
    assert action.runner is None
    assert action.loader is None
    assert action.templar is None
    assert action.shared_loader_obj is None
    assert action.variable_manager is None
    assert action.connection is None
    assert action.play_context is None
    assert action.search_paths is None

# Generated at 2022-06-23 07:48:56.722410
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test action module to fetch a file from a remote node.
    '''
    Test setup
    '''
    # Test action module to fetch a file from a remote node.
    #Test for action module with non-existing source file.
    def test_run_action_module_with_source_does_not_exist(self):
        '''
        Test run action module
        :return:
        '''
        self.assertEqual(result, {'failed': True, 'file': 'test_file'})

    # Test action module to fetch a file from a remote node.
    # Test for action module with existing source file.
    def test_run_action_module_with_source_exists(self):
        '''
        Test run action module
        :return:
        '''

# Generated at 2022-06-23 07:48:59.682621
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule({}, {})
    result = action.run(None, {})
    assert result.get('failed', None)

# Generated at 2022-06-23 07:49:08.144550
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import constants as C
    from ansible.plugins.action.fetch import ActionModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.playbook_tests import ansible_playbook_executor

    class Options(object):
        verbosity = 3
        syntax = True
        connection = 'local'
        module_path = None
        forks = 100
        remote_user = None
        private_key_file = None
        ssh_common_args = None
        ssh_extra_args = None

# Generated at 2022-06-23 07:49:19.971499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock

    # Set up class
    action = ActionModule()
    action._display = mock.Mock()
    action._task = mock.Mock()
    action._task.args = {'dest': None, 'fail_on_missing': True, 'validate_checksum': True, 'src': None, 'flat': False}
    action._connection = mock.Mock()
    action._connection._shell = mock.Mock()

    action._play_context = mock.Mock()
    action._play_context.check_mode = False

    action._loader = mock.Mock()

    # Set up action._remote_expand_user
    mock_available = mock.Mock()
    mock_available.return_value = True
    action._remote_expand_user = mock_available

    # Set up action._execute_

# Generated at 2022-06-23 07:49:20.496269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 07:49:22.440019
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None

# Generated at 2022-06-23 07:49:25.327971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test for method run of the class ActionModule
    '''
    # TODO: It is necessary to complete the test
    pass

# Generated at 2022-06-23 07:49:34.209158
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

    # Create a task
    task = {
        'action': {
            'args': {
                'src': '/path/to/name_of_local_file',
                'dest': 'destination_directory',
                'flat': False,
                'fail_on_missing': False,
                'validate_checksum': False
            },
            'module': 'fetch.py'},
        'delegate_to': None,
        'register': 'myvar'
    }
    module._task = task

    # Create a play context
    play_context = {
        'check_mode': None,
        'remote_addr': '127.0.0.1'
    }
    module._play_context = play_context

    # Create a connection
    connection = {}
    module._connection

# Generated at 2022-06-23 07:49:46.689123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action

    connection = ansible.plugins.action.ActionBase._shared_loader_obj.connection_loader.get('local', None)
    host_list = [ansible.inventory.host.Host(name='testhost', port=1234)]
    variable_manager = ansible.plugins.action.ActionBase._shared_loader_obj.variable_manager
    variable_manager.set_inventory(ansible.inventory.Inventory(host_list))

    # Create shared mock object for the ActionModule class
    am_obj = ansible.plugins.action.ActionBase._shared_loader_obj.action_loader.get('fetch', connection=connection, variable_manager=variable_manager, loader=ansible.plugins.action.ActionBase._shared_loader_obj)

    # Create instance of ActionModule class
    am = am_

# Generated at 2022-06-23 07:49:49.086601
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-23 07:49:59.636719
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # play_context.check_mode set to true causes AnsibleActionSkip exception to be raised
    action_module = ActionModule(play_context=object)
    action_module.play_context.check_mode = True

    with pytest.raises(AnsibleActionSkip):
        action_module.run(task_vars={})

    # No exception is raised when play_context.check_mode is set to false
    action_module = ActionModule(play_context=object)
    action_module.play_context.check_mode = False
    assert action_module.run(task_vars={}) is not None

    # test AnsibleActionSkip exception when remote_checksum is not defined
    task_vars = {'inventory_hostname': 'localhost'}
    class Mock_connection:
        become = False

# Generated at 2022-06-23 07:50:01.308807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    display = Display()
    assert isinstance(display, Display)

# Generated at 2022-06-23 07:50:04.011064
# Unit test for constructor of class ActionModule
def test_ActionModule():
    display.vvvv = True
    module = ActionModule(display=display, runner=None)
    assert module

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 07:50:07.070211
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.fetch import ActionModule
    a = ActionModule(None, None, None, None)
    assert(a)

# Generated at 2022-06-23 07:50:08.543673
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert(action is not None)

# Generated at 2022-06-23 07:50:23.685531
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up a task.
    mytask = dict(
        action=dict(
            module='get_url', args=dict(url='http://foo.com/index.html', dest='index.html') ),
        register='mytask',
    )
    mytask.update(connection='local')

    # Create the ansible context.
    myargs = dict(
        module_path='mylibrary',
        forks=10,
        remote_user='testuser',
        remote_pass='password',
        remote_port=10022,
        private_key_file='testpk',
        LOG_PATH=os.devnull,
    )
    pc = PlayContext(**myargs)

    myloader = DataLoader()
    myvarmanager = VariableManager()

# Generated at 2022-06-23 07:50:35.512515
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    '''
    Unit test for method run of class ActionModule. This method fetches a file from
    the remote system to the local system.
    '''
    # set up
    import os
    import tempfile
    from ansible.utils import template

    from ansible.plugins.action.fetch import ActionModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager


    # Get the pathname of the temporary file that test_app2.py created in test_app1.py

# Generated at 2022-06-23 07:50:47.153154
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inv_manager = InventoryManager('/tests/fixtures/hosts')
    loader = DataLoader()
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.remote_addr = '192.168.0.1'
    play_context.connection = 'network_cli'
    play_context.port = 22
    play_context.remote_user = 'test'
    play_context.become = False
    play_context.become_method = ''
    play_context.become_user = ''


# Generated at 2022-06-23 07:50:53.621182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.fetch
    import ansible.plugins.action.copy
    import ansible.plugins.action.file
    import ansible.plugins.loader
    import ansible.plugins.connection.local
    import ansible.playbook.play_context
    import ansible.playbook.play
    import ansible.executor.task_queue_manager
    import ansible.executor.playbook_executor
    import ansible.playbook.role.role
    import ansible.playbook.block

    # Get defaut ansible.cfg
    import ansible.constants
    ansible_cfg = ansible.constants.Config()

    # Setup display
    from ansible.utils import display
    display.verbosity = 3
    display.columns = 80

    # Create connection for ansible
    connection

# Generated at 2022-06-23 07:51:04.410021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # 1. Create a fake connection
    class MyConnection(object):
        class MyShell(object):
            def join_path(self, *args, **kwargs):
                return 'fake_path/src/file'
        _shell = MyShell()
        def __init__(self):
            self.become = True
    connection = MyConnection()

    # 2. Create a fake task
    class MyTask(object):
        class MyArgs(object):
            src = None
            dest = None
            flat = None
            fail_on_missing = None
            validate_checksum = None
        args = MyArgs()
    task = MyTask()

    # 3.  Create a fake play_context
    class MyPlayContext(object):
        check_mode = False
        remote_addr = 'fake_host'
    play_context

# Generated at 2022-06-23 07:51:11.941581
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class FakeTask:
        def __init__(self):
            pass

    class FakeLoader:
        def __init__(self):
            pass

    class FakePlayContext:
        def __init__(self):
            pass

    def fake_remote_stat(self, *args, **kwargs):
        return args, kwargs

    def fake_remote_expand_user(self, *args, **kwargs):
        return args, kwargs

    def fake_execute_module(self, *args, **kwargs):
        return args, kwargs

    def fake_execute_remote_stat(self, *args, **kwargs):
        return args, kwargs

    def fake_remove_tmp_path(self, *args, **kwargs):
        return args, kwargs


# Generated at 2022-06-23 07:51:23.890200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import StringIO
    from ansible.plugins import action
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError, AnsibleActionSkip, AnsibleActionFail
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    import sys

    # Set up our arguments for the module
    module_args = dict(src="/etc/hosts", dest=".")

# Generated at 2022-06-23 07:51:27.043088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Passing script to base.run causes:
  #   ERROR! this module must be run on a remote host
  # So we skip it for now. (run_script is tested in unit tests)
  pass

# Generated at 2022-06-23 07:51:34.982329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._remove_tmp_path = lambda x: None
    # this is for test code only, so we ignore the fact we aren't using the
    # superclass's constructor or calling it at all
    # pylint: disable=W0231
    class connection:
        class _shell:
            tmpdir = 'tmp'
            def _unquote(self, x):
                return x
            def join_path(self, x, y):
                return '%s/%s' % (x, y)
        become = False
        def fetch_file(self, x, y):
            pass
        def _execute_remote_stat(self, x, all_vars, follow):
            return dict(exists=True, isdir=False)

# Generated at 2022-06-23 07:51:41.465051
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # FIXME: should mock all the imports
    import ansible.plugins.action
    import ansible.utils
    import ansible.module_utils.common.text
    aa_module = ansible.plugins.action.ActionModule(dict(), {"dest":"src"}, False, None)
    assert aa_module.__class__.__name__ == "ActionModule"

# Generated at 2022-06-23 07:51:43.089838
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement function _assert_not_in to replace assert_false
    assert False

# Generated at 2022-06-23 07:51:55.669191
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock objects
    class mock_play_context(object):
        check_mode = False
    mock_play_context_instance = mock_play_context()
    mock_play_context_instance.remote_addr = "127.0.0.1"
    class mock_task(object):
        args = {'dest': 'destination'}
    mock_task_instance = mock_task()
    class mock_connection(object):
        connected = False
        def _shell_escape_unsafe(self, path):
            return path
        def connect(self):
            pass
        def close(self):
            pass
        def _shell(self):
            return self
        def join_path(self, path1, path2):
            return path1 + "/" + path2

# Generated at 2022-06-23 07:51:57.772876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(connection=(), play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a is not None

# Generated at 2022-06-23 07:52:07.717645
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Constructor arguments:
    # - task: ansible.parsing.task.Task
    # - connection: ansible.plugins.connection.ConnectionBase
    # - play_context: ansible.playbook.play_context.PlayContext
    # - loader: ansible.parsing.dataloader.DataLoader
    # - templar: ansible.template.Templar
    # - shared_loader_obj: loader or ansible.parsing.dataloader.DataLoader
    # Instantiation of the ActionModule class:
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    # Instatiates the run method
    action_module

# Generated at 2022-06-23 07:52:20.561629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization
    class OptionsModule:
        def __init__(self):
            pass

        def __getitem__(self, key):
            if key == "base_dir":
                return "base_dir"
            else:
                return "default"

    class TaskVarsModule:
        def __init__(self):
            self.module_default_args = OptionsModule()
            self.automation_complex_args = {"task_vars": "task_vars"}
            self.automation_args = {"task_vars": "task_vars"}
            self.automation_is_complex_args = True

    class PlayContextModule:
        def __init__(self):
            self.connection = "local"
            self.remote_addr = "127.0.0.1"

# Generated at 2022-06-23 07:52:23.873499
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule()

    assert type(action_module) == ActionModule, "ActionModule object not created by constructor."

test_ActionModule()

# Generated at 2022-06-23 07:52:25.045916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 07:52:27.222711
# Unit test for constructor of class ActionModule
def test_ActionModule():
    u = ActionModule()
    assert u

# unit test for run function of class ActionModule

# Generated at 2022-06-23 07:52:28.188023
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-23 07:52:28.817374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:52:39.017556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Total code coverage of method:
    # run is too complex. Only the path that fails and needs to return an error is tested here
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    inventory = Inventory(loader, variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    t = dict(
        _ansible_no_log=False,
        ansible_no_log=False
    )
    host = Host(name="test")
    play_context = PlayContext(remote_user='root', become=True, become_method='sudo',
                               become_user='root', check_mode=False,
                               diff=False)
    tqm = None

    connection = ConnectionForTest(host, tqm, play_context, loader, variable_manager, None)

# Generated at 2022-06-23 07:52:49.066824
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(action=dict(module='fetch', src='test', dest='test'))
    play_context = dict(become=True, become_user='test', become_method='test')
    connection = "my_conn"
    loader = "my_loader"
    tmp = "my_tmp"
    shared_loader_obj = "my_shared_loader_obj"
    variable_manager = "my_variable_manager"

    fetch_mod = ActionModule(
        task=task,
        connection=connection,
        play_context=play_context,
        loader=loader,
        tmp=tmp,
        shared_loader_obj=shared_loader_obj,
        variable_manager=variable_manager
    )

    assert fetch_mod._task == task
    assert fetch_mod._play_context == play_context


# Generated at 2022-06-23 07:52:50.721690
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test constructor of ActionModule
    '''
    module = ActionModule()

    assert module is not None

# Generated at 2022-06-23 07:52:52.167461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()


# Generated at 2022-06-23 07:52:54.403875
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_instance = ActionModule(None, None, None)
    assert isinstance(test_instance, ActionModule)

# Generated at 2022-06-23 07:53:05.834654
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test case for class ActionModule
    """

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    my_play_context = PlayContext()
    my_play_context.remote_addr = '127.0.0.1'
    my_play_context.connection = 'local'
    my_play_context.become = False
    my_play_context.become_method = 'sudo'
    my_play_context.become_user = 'root'

    my_task = Task()
    my_task.args = {"dest":"/tmp/fetch.out"}

    my_play = Play()
    my_play.become = 'True'

# Generated at 2022-06-23 07:53:06.672124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "Test not implemented"



# Generated at 2022-06-23 07:53:18.973840
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_name = 'ansible.legacy'
    module_args = "{'src': '/etc/motd', 'dest': '/tmp'}"
    task_vars = dict()
    tmp = None
    connection = None
    task = None
    loader = None
    play_context = None

    # Positive test case
    am = ActionModule(module_name, module_args, loader=loader, play_context=play_context,
                      connection=connection, task=task, loader=loader)
    result = am.run(tmp, task_vars)
    assert result['changed'] is False, 'Action module run did not return False'
    assert result['dest'] == "/tmp", 'Destination path incorrect'

    # Negative testcase when source file is not found
    module_name = 'ansible.legacy'
    module_args

# Generated at 2022-06-23 07:53:21.140953
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(connection=dict(), play_context=dict())
    assert m is not None


# Generated at 2022-06-23 07:53:29.612905
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(connection='connection', play_context='play_context', loader='loader', templar='templar', shared_loader_obj='shared_loader_obj')
    assert am._connection == 'connection'
    assert am._play_context == 'play_context'
    assert am._loader == 'loader'
    assert am._templar == 'templar'
    assert am._shared_loader_obj == 'shared_loader_obj'



# Generated at 2022-06-23 07:53:41.206317
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.fetch import ActionModule as ActionModule_fetch
    from ansible.plugins.connection.local import Connection as Connection_local
    from ansible.plugins.loader import connection_loader

    results = []

    def test_fetch(self, tmp=None, task_vars=None):
        results.insert(0, self._task.args)
        return test_fetch.result

    test_fetch.result = dict(changed=True, md5sum=None, file='/home/username/foo.yml',
                             dest='/tmp/username/foo.yml', checksum='d41d8cd98f00b204e9800998ecf8427e')

    ActionModule_fetch.run = test_fetch
    Connection_local.become_method = 'sudo'


# Generated at 2022-06-23 07:53:41.748298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:53:43.542974
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    print(action.run())


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-23 07:53:50.046467
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test = dict()
    test['src'] = '/tmp/test.tgz'
    test['dest'] = '/tmp/test/'
    test['flat'] = True

    task_vars = dict()

    # TODO: Need to provide a _execute_module mock instead of ansible.legacy.slurp
    ret = {}

    ret['encoding'] = 'base64'
    ret['content'] = 'test_content'

    module = ActionModule(None, None)

    with patch('ansible.plugins.action.fetch.ActionModule._execute_module') as mock_execute:
        mock_execute.side_effect = lambda *args, **kwargs: ret
        result = module.run(None, task_vars)
    
    assert result['checksum'] is not None

# Generated at 2022-06-23 07:54:00.050905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock

    class MockActionModule(ActionModule):
        def _remote_expand_user(self, path):
            return path
        def _execute_remote_stat(self, path, all_vars, follow):
            return {'exists': True, 'isdir': False, 'checksum': ''}
        def _execute_module(self, module_name, module_args, task_vars):
            return {'failed': False, 'encoding': 'base64', 'content': '123'}
        def _remove_tmp_path(self, path):
            pass

    tmp = None
    task_vars = {'inventory_hostname': 'localhost'}
    connection = mock.MagicMock()
    tmpdir = '/tmp'
    connection.become = False
    connection._shell.tmpdir = tmpdir

# Generated at 2022-06-23 07:54:05.074079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)
    assert isinstance(am, ActionBase)
    assert isinstance(am, object)
    assert hasattr(am, 'run')
    assert callable(am.run)
    assert hasattr(am, '_display')
    assert isinstance(am._display, Display)

# Generated at 2022-06-23 07:54:06.516464
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmod = ActionModule()
    assert actionmod._task.action == 'fetch'

# Generated at 2022-06-23 07:54:14.036917
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.fetch import ActionModule
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    arguments = {'src': 'dir/file.txt', 'dest': 'local/dir/'}
    task = AnsibleConstructor.construct_yaml_object('fetch', arguments)
    display = Display()
    action_plugin = ActionModule(task, display)

    assert action_plugin.run() == {'changed': False, 'file': 'dir/file.txt', 'dest': 'local/dir/file.txt'}

# Generated at 2022-06-23 07:54:15.624595
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(None, None, None)
    assert x is not None

# Generated at 2022-06-23 07:54:20.954795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=10, connection=20, play_context=30, loader=40, templar=50)
    assert module._task == 10
    assert module._connection == 20
    assert module._play_context == 30
    assert module._loader == 40
    assert module._templar == 50


# Generated at 2022-06-23 07:54:31.511494
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test 1
    task_vars_mock = dict(inventory_hostname='test', ansible_ssh_host='test')

    tmp_mock = '/tmp/ansible-tmp-1477165129.26-87850129243800'
    source_mock = '/tmp/shell.py'
    remote_data_mock = None # We'll use the remote file which hash is the same as the local file
    dest_mock = '/tmp/shell.py'

    # first, create source_mock_path
    f = open(to_bytes(source_mock, errors='surrogate_or_strict'), 'wb')
    f.write(b'#/usr/bin/env python\nimport sys,os\nprint (os.getcwd())\n')
    f.close()


# Generated at 2022-06-23 07:54:40.238049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dest = '/data/'
    src = 'data.json'
    module_args = dict(dest=dest, src=src)
    module_args1 = dict(dest=dest, src=src, validate_checksum=False)
    module_args2 = dict(dest=dest, src=src, validate_checksum=True)

    # test by handling exceptions
    # no exception
    local_checksum = checksum(dest)
    remote_data = b"a string of data"
    remote_checksum = checksum_s(remote_data)
    remote_stat = dict(checksum=remote_checksum, exists=True, isdir=False)

# Generated at 2022-06-23 07:54:42.422532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO:
    # make this a function that gets fed test data
    # and then calls the run method for each test
    # (essentially a wrapper for running tests)
    return {}

# Generated at 2022-06-23 07:54:50.106410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleActionFail
    from ansible.plugins.action import ActionBase
    from ansible.utils.hashing import checksum
    from ansible.utils.path import makedirs_safe
    import tempfile

    # Create a temporary file
    temp_dir = tempfile.mkdtemp()
    dummy_file = os.path.join(temp_dir, 'dummy.txt')
    with open(dummy_file, 'w') as dummy:
        dummy.write('Dummy')

    action_module = ActionModule(None, None)
    action_module._connection = None
    action_module._task = None
    action_module._play_context = None
    action_module._display = Display()
    action_module._loader = None

    # Mocking methods

# Generated at 2022-06-23 07:54:54.553017
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.fetch
    a = ansible.plugins.action.fetch.ActionModule(None, None, None, None)
    assert(isinstance(a, ansible.plugins.action.ActionBase))

# Generated at 2022-06-23 07:55:05.796046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a new instance of ActionModule
    actionModule = ActionModule(load=lambda x,y,z: dict(verbosity=4),
                                task_vars=dict(ansible_verbosity=3),
                                connection=dict(become=False, _shell=dict(_unquote=lambda x: x, join_path=lambda x,y: y)))
    actionModule._add_cleanup_task = lambda x:0 # Fake out a cleanup task
    actionModule._execute_remote_stat = lambda src, all_vars, follow, return_data=False: dict(exists=True, isdir=False, checksum="123")
    actionModule.run(task_vars=dict(ansible_verbosity=4))
    actionModule.run(task_vars=dict(ansible_verbosity=5))

# Generated at 2022-06-23 07:55:14.424348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = DummyActionModule()

    a.run()
    assert a.result.get('changed') == False
    assert a.result.get('md5sum') == '78e731027d8fd50ed642340b7c9a63b3'
    assert a.result.get('file') == 'source_file'
    assert a.result.get('dest') == 'dest_file'
    assert a.result.get('checksum') == '78e731027d8fd50ed642340b7c9a63b3'

# Generated at 2022-06-23 07:55:21.720820
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins import module_loader
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    source = '/tmp/source'
    dest = '/tmp/dest'
    host = Host(name="out")
    t = ActionModule(host, dict(src=source, dest=dest))
    assert t._connection._shell.join_path(source) == "/tmp/source"
    assert t.run() == dict(failed=True, msg="src and dest are required")

# Generated at 2022-06-23 07:55:22.283311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 07:55:24.443288
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(Display())
    if am is not None:
        print(True)
    else:
        print(False)


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 07:55:26.422684
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(action=None, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module.run(tmp=None, task_vars=None)

# Generated at 2022-06-23 07:55:29.696654
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ac = ActionModule(ActionModule.__name__, None, )
    assert isinstance(ac, ActionModule)

# Generated at 2022-06-23 07:55:31.648427
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Ensures __name__ is defined
    assert True 


# Generated at 2022-06-23 07:55:41.680977
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.fetch import ActionModule

    am = ActionModule()

    am._args = dict(src="/src/file.txt", dest="/dest/file.txt")
    am._task = dict(args=am._args)
    am._task_vars = dict(ansible_check_mode=True)

    res = am.run(None, None)
    assert 'msg' in res
    assert res['msg'] == 'check mode not (yet) supported for this module'

    am._task_vars = dict()
    am._play_context = dict(check_mode=False)
    am._remote_checksum = '1'

    am._connection = dict(become='false')

# Generated at 2022-06-23 07:55:51.500702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_dir = 'tests/unit/plugins/modules/test_copy/copy_test'

    module_path = os.path.join(test_dir, 'action_plugins/fetch.py')

    module = ActionModule.load(module_path, None, None, 'fetch', None)
    module._options = {'_ansible_check_mode': True}
    module._play_context = 'play_context'
    module._task = {'args': {'src': 'source', 'dest': 'destination'}}
    module._connection = 'connection'

    result = module.run('tmp', 'task_vars')

    assert result['failed'] is True
    assert result['msg'] == 'check mode not (yet) supported for this module'

# Generated at 2022-06-23 07:55:52.315953
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 07:55:52.803899
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 07:55:54.711838
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    print("Start of tests of test_ActionModule")
    """


# Generated at 2022-06-23 07:55:56.556017
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "Postponed: method run of class ActionModule is not implemented yet"

# Generated at 2022-06-23 07:56:03.419030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule."""
    # Setup
    action_module_object = ActionModule(
        {'name': 'some_name',
         'action': 'some_action',
         'args': {'src': 'some_src',
                  'dest': 'some_dest'}},
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    action_module_object._task = {
        'args': {'src': 'some_src',
                 'dest': 'some_dest'},
        'action': 'some_action',
        'name': 'some_name'
    }

    # Exercise
    action_module_object.run()

    # Verify
    #

# Generated at 2022-06-23 07:56:04.853164
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_class = ActionModule()
    assert my_class

# Generated at 2022-06-23 07:56:05.990497
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-23 07:56:08.263462
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ac = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert ac is not None

# Generated at 2022-06-23 07:56:17.069408
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_object=dict())

    module._connection._shell.join_path('a', 'b')
    module._remote_expand_user('user')
    module._execute_remote_stat('user', dict(), True)
    module._execute_module('module', dict())
    module._connection.fetch_file('s', 'd')
    module._remove_tmp_path('tmpdir')

    # test return values of run() method
    # expected error: action plugin does not support running in check_mode
    assert(module.run(tmp=None, task_vars=None)['failed'] == True)

    # expected error: the remote file does not

# Generated at 2022-06-23 07:56:20.682590
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test for class ActionModule
    module = ansible.modules.core.action.ActionModule()
    module.run()

# Generated at 2022-06-23 07:56:31.649304
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import constants as C
    C.HOST_KEY_CHECKING = False

    # Arrange
    from unit.mock.loader import DictDataLoader
    from unit.mock.conn_mock import ConnectionMock

    # TODO: Arrange more
    task_mock = dict(
        action = dict(module_args = dict(
            src = None,
            dest = None,
        ))
    )
    loader_mock = DictDataLoader({})
    connection_mock = ConnectionMock()

    # Act
    import tempfile
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 07:56:41.050382
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def remote_expand_user(path):
        return path

    def join_path(path1, path2):
        """This method is needed because the private methods of class ShellModule have to be used"""
        if path1 is None:
            return path2
        elif path2 is None:
            return path1
        else:
            return path1 + '/' + path2

    def unquote(path):
        return path

    def normalize_path(self, path, prefix):
        return path

    def copy_file(self, in_path, out_path):
        """This method is needed because the private methods of class ShellModule have to be used"""
        pass

    class TestActionBase(ActionBase):
        def __init__(self):
            self._shell = TestShellModule()


# Generated at 2022-06-23 07:56:53.220788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    
    # Make module available within Ansible
    sys.path.append("/usr/share/ansible")

    # Create a mock-action plugin
    class MockActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(MockActionModule, self).run(tmp, task_vars)

    module = MockActionModule(
        task=dict(action=dict(module='fetch', src="/tmp/foo.txt", dest="/tmp/bar.txt")),
        connection=dict(
            transport='local',
            becomes=False),
        play_context=dict(
            check_mode=False),
        loader=None,
        templar=None,
        shared_loader_obj=None)


# Generated at 2022-06-23 07:57:00.831092
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    __tracebackhide__ = True
    # test for issue-31432
    with pytest.raises(AnsibleActionFail, match="Detected directory traversal, expected to be contained in 'dest' but got '../a/b'"):
        ActionModule.run(dict(
            _task=dict(args=dict(
                src=None,
                dest="../a/b",
            )),
            _connection=dict(
                _shell=dict(
                    _unquote=lambda x: x,
                ),
            ),
            _loader=dict(
                path_dwim=lambda x: x,
            ),
        ))

# Generated at 2022-06-23 07:57:11.523238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # test with only mandatory parameter and flat is False
    #
    task_vars = dict()
    src = "hello.txt"
    dest = "/tmp"
    flat = False
    args = dict(src=src, dest=dest)
    connection = MockConnection()
    action = ActionModule(connection, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action.run(None, task_vars=task_vars, name=None, args=args)
    assert result['src'] == src
    assert result['dest'] == "/home/testuser/hello.txt"
    assert result['changed'] == False
    assert result['md5sum'] == "5d41402abc4b2a76b9719d911017c592"
    assert result

# Generated at 2022-06-23 07:57:20.377111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    # This unit test requires a valid connection.
    # To create a valid connection, you must provide the following items:
    # - A fake inventory with a valid host (e.g. myhost.example.com)
    # - A fake ansible.cfg
    # - A fake ~/.ansible.cfg
    # - A valid action plugin (e.g. library/unit_test_module.py)
    # If you don't want to test all methods of the action plugin, you must override the
    # ActionBase.run() method and return an empty dictionary.
    action_module = ActionModule()
    result = action_module.run()
    assert result == {}

# Generated at 2022-06-23 07:57:22.627539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None).name() == 'common.fetch'

# Generated at 2022-06-23 07:57:33.275966
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from unittest import TestCase
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import ActionModuleLoader, connection_loader

    host_name = 'localhost'
    play_context = PlayContext()
    play_context.remote_addr = host_name
    loader = ActionModuleLoader(play_context)
    connection = connection_loader.get('local', play_context)
    action_module = ActionModule(loader, connection)
    # Play context
    play_context = PlayContext()
    play_context.check_mode = False
    # Task variables
    task_variable = dict()
    # Task arguments
    task_argument = dict()
    task_argument['src'] = 'foo'
    task_argument['dest'] = 'bar'
    task_argument['flat'] = True
   