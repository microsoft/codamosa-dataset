

# Generated at 2022-06-23 07:47:29.491722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_module = ActionModule('test_module')
    assert test_module._task.action == 'test_module'
    assert test_module._task.args.get('src') == None
    assert test_module._task.args.get('dest') == None

# Generated at 2022-06-23 07:47:31.166567
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_mod = ActionModule()

    assert action_mod.run() == dict()

# Generated at 2022-06-23 07:47:41.731991
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.fetch import ActionModule

    source_path = '~/path/to/source'
    dest_path = 'dest/path'
    flat = False

    task = {}
    task['args'] = {'src': source_path, 'dest': dest_path, 'flat': flat}

    tmp = 'tmp'
    task_vars = {'ansible_version': {'full': '2.3.0.0'}}

    am = ActionModule(task, tmp, task_vars)

    # Uncomment to enable test
    #res = am.run(tmp, task_vars)
    #print(res)

# Generated at 2022-06-23 07:47:47.863747
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(action_plugin = None, task = None, connection = None, play_context = None, loader = None, templar = None, shared_loader_obj = None)
    assert action.action_plugin == None
    assert action.task == None
    assert action.connection == None
    assert action.play_context == None
    assert action.loader == None
    assert action.templar == None
    assert action.shared_loader_obj == None

# Generated at 2022-06-23 07:47:49.296784
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 07:48:00.044767
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # NOTE: if content is not Base 64 encoded, slurp will fail
    class FakeModule:
        def __init__(self, result):
            self.result = result
        def run(self, **kwargs):
            return self.result

    # NOTE: this class is not working, it has been mocked above
    class FakeSlurpModule:
        def __init__(self, result):
            self.result = result
        def run(self, **kwargs):
            return self.result

    class FakeConnection:

        def __init__(self, become, checksum):
            self._shell = FakeShell()
            self.become = become
            self.checksum = checksum

        def fetch_file(self, src, dst):
            pass

    class FakeShell:
        def __init__(self):
            self.tmp

# Generated at 2022-06-23 07:48:06.666627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader, module_loader

    source = 'foo'
    dest = 'bar'
    args = dict(src=source, dest=dest)

    pc = PlayContext()

    source_mock = connection_loader.get('local')()
    source_mock._shell.join_path = lambda x: x
    source_mock._shell.join_path = lambda x: x
    source_mock._shell._unquote = lambda x: x

    host = {'name': 'test', 'address': 'localhost'}
    hostvars = dict()

    module_mock = module_loader.get('copy')()


# Generated at 2022-06-23 07:48:16.032959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.plugins.connection.local import Connection as LocalConnection
    from ansible.plugins.connection.ssh import Connection as SSHConnection
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.cli import CLI
    from ansible.inventory.host import Host

# Generated at 2022-06-23 07:48:27.868863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import os
    import tempfile

    class Test_ActionModule_run(unittest.TestCase):

        def setUp(self):
            class Mock_Task_exec(ActionBase):
                def __init__(self):
                    self.args = 'Mock_Task_exec'
            class Mock_Task_fail(ActionBase):
                def __init__(self):
                    self.args = 'Mock_Task_fail'
            class Mock_Task_remote_expand_user(ActionBase):
                def __init__(self):
                    self.args = 'Mock_Task_remote_expand_user'
            class Mock_Task_get_connection(ActionBase):
                def __init__(self):
                    self.args = 'Mock_Task_get_connection'

# Generated at 2022-06-23 07:48:34.481978
# Unit test for constructor of class ActionModule
def test_ActionModule():

    a = ActionModule(
        task = { 'args': {'src':'./','dest':'./','flat':'yes'}},
        connection = None,
        play_context = None,
        loader = None,
        templar = None,
        shared_loader_obj = None
    )

    assert a._task.args['src'] == './'
    assert a._task.args['dest'] == './'
    assert a._task.args['flat'] == 'yes'

# Generated at 2022-06-23 07:48:45.188278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = dict(
        dest='/tmp/fetch_result',
        src='/home/somefile.txt',
        validate_checksum=False,
        flat=True,
        fail_on_missing=False,
    )

    tmp = None

    from ansible.plugins.connection.local import Connection

    pc = DummyVars()
    pc.connection = 'local'
    pc.remote_addr = None
    pc.become = False

    task_ds = dict(
        name='fetch test',
        become_user='someuser',
        become_method='su',
        become_flags='-H -S',
        args=args,
    )

    pm = DummyModule()
    pm.check_mode = False
    pm.no_log = False


# Generated at 2022-06-23 07:48:46.427024
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor test
    """
    pass

# Generated at 2022-06-23 07:48:48.383227
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    print(action_module)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 07:48:58.425155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule
    """
    source = "https://raw.githubusercontent.com/ansible/ansible/devel/test/sanity/group_vars"
    dest = "./test/sanity/group_vars"

    import ansible.plugins.action as action

# Generated at 2022-06-23 07:49:05.461712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    
    a = ActionModule(None, None)
    a.display = Display()
    
    # test dest directory
    a._task.args = {
        'dest': '/tmp'
    }
    result = a.run()
    assert result['failed']
    
    # test file in the dest directory
    src = '/tmp/src'
    open(src, 'w').close()
    
    a._task.args = {
        'src': src,
        'dest': '/tmp'
    }
    result = a.run()
    os.remove(src)
    assert result['failed']
    
    # test file in the dest directory and flat is true
    src = '/tmp/src'
    open(src, 'w').close()
    

# Generated at 2022-06-23 07:49:12.139926
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # TODO: Make it a unit test
    import ansible.playbook.task_include
    import ansible.utils.template
    from ansible.utils.vars import combine_vars

    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    var_manager = VariableManager()
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}

    filename = 'test_action_module.yaml'
    variable_manager.set_inventory(loader.load_from_file('test_action_module.yaml'))

# Generated at 2022-06-23 07:49:17.201836
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize class
    action_module = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Check existence of class method
    assert action_module.run != None

# Generated at 2022-06-23 07:49:28.903374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess

    play_context = PlayContext()
    play_context.connection = 'local'
    play_context.remote_addr = 'test-remote-addr'
    play_context.port = 22

    worker_proc = WorkerProcess(0, 0)
    worker_proc._initialize_process_dependencies(play_context, None)

    action = ActionModule(worker_proc)
    action._play_context = play_context
    action._task_vars = []
    action.task.args = dict(src="/test-source", dest="/test-dest")

    result = action.run(task_vars=None)

    assert result

# Generated at 2022-06-23 07:49:36.183883
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json

    # test constructor of class ActionModule
    mod = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(mod, ActionModule)

    # test params of class ActionModule
    task = dict(action=dict(__ansible_module__='test'))
    tmp = None
    new_stdin = '{"hostvars": {"localhost": {"inventory_hostname": "localhost", "group_names": ["ungrouped"], "groups": {"all": [], "ungrouped": [], "ungrouped|local": ["localhost"]}, "inventory_dir": "/vagrant/ansible/inventory", "inventory_file": "/vagrant/ansible/inventory/hosts"}}}'  # noqa
    display.debug

# Generated at 2022-06-23 07:49:45.274910
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(connection=None)
    a._task = 'test_fetch'
    a._task_vars = { 'inventory_hostname': 'ansible.example.com' }
    a._tmp = '/tmp'
    a._connection = { '_shell': { 'join_path': lambda x,y: '/'.join([x,y]) } }

    # test that the run method returns a dictionary
    assert type(a.run(tmp='/tmp', task_vars=a._task_vars)) == dict, "Result is not a dictionary, method run failed"

# Generated at 2022-06-23 07:49:46.287028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    constructor_test_action_module=ActionModule()

# Generated at 2022-06-23 07:49:58.773308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """
    from ansible.plugins.connection.ssh import Connection
    from ansible.module_utils.ansible_release import __version__
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    vault_password = None

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()
    connection = Connection(play_context, new_stdin=None)


# Generated at 2022-06-23 07:50:03.352576
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    display = Display()
    # Actual action
    action_module = ActionModule(None, None, {})
    result = action_module.run(None, dict())
    # Check that it returned an empty dict
    display.display(result)
    assert result == {}

# Generated at 2022-06-23 07:50:18.841989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing with flat option true
    ansible_object = ActionModule()
    ansible_object._task = dict()
    ansible_object._task['args'] = dict()
    ansible_object._task['args']['src'] = 'source_file'
    ansible_object._task['args']['dest'] = 'dest_path'
    ansible_object._task['args']['flat'] = True
    try:
        result = ansible_object.run(None)
        assert result['msg'] == "Detected directory traversal, expected to be contained in 'dest_path' but got '..'"
    except AnsibleActionFail as e:
        assert  e.message == "Detected directory traversal, expected to be contained in 'dest_path' but got '..'"

# Generated at 2022-06-23 07:50:28.603917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    fd, path = tempfile.mkstemp(dir=tmpdir)
    with os.fdopen(fd, 'w') as f:
        f.write("""
[defaults]
roles_path = %s
action_plugins = ./action_plugins
""" % tmpdir)
    os.environ['ANSIBLE_CONFIG'] = path
    os.mkdir(os.path.join(tmpdir, 'action_plugins'))
    fd, path = tempfile.mkstemp(dir=os.path.join(tmpdir, 'action_plugins'), prefix='action_', suffix='.py')
    with os.fdopen(fd, 'w') as f:
        f

# Generated at 2022-06-23 07:50:29.627563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule()

# Generated at 2022-06-23 07:50:31.226952
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 07:50:44.358494
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestConnection:
        def __init__(self):
            self.become = False
            self.become_method = None

        def _shell_plugin_load(self):
            return None

        def _connect(self):
            return None

        def exec_command(self, cmd, tmp_path, sudo_user=None, sudoable=False, executable='/bin/sh', in_data=None, su=None, su_user=None):
            return ''

        def put_file(self, in_path, out_path):
            pass

        def fetch_file(self, in_path, out_path):
            pass

        def close(self):
            pass


# Generated at 2022-06-23 07:50:44.981137
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:50:51.341410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    import uuid
    import os
    import shutil
    import tempfile
    import ansible.plugins.action.copy

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 07:51:01.727609
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 07:51:03.906090
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(ActionModule(None, None, None, '')) == ActionModule

# Generated at 2022-06-23 07:51:07.641720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This method is not called, it is only included here to allow Ansible's
    # unit tests to run this module.  It is not considered good practice to
    # include code that is not used in a module.  So, this function is here
    # strictly for the benefit of Ansible's unit tests.
    return 0

# Generated at 2022-06-23 07:51:08.606073
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    return module

# Generated at 2022-06-23 07:51:20.900321
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule

    a = ActionModule(
        connection=None,
        task_vars=dict(ansible_user='a_user', inventory_hostname='host_hostname'),
        play_context=dict(check_mode=False, remote_addr='127.0.0.1'),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    a._remove_tmp_path = lambda x: x
    a._connection = dict(
        _shell=dict(
            _unquote=lambda x: x,
            tmpdir='/tmp',
            join_path=lambda x, y: x + '/' + y
        ),
        become=True,
        fetch_file=lambda x, y: x,
    )
    a._execute

# Generated at 2022-06-23 07:51:29.844943
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(
        action = dict(
            module = 'copy',
            args   = dict(
                src = '/etc/hosts',
                dest = '/tmp/hosts',
            )
        ),
    )
    task_vars = dict(
        ansible_use_shell=True,
    )
    am = ActionModule(task, task_vars=task_vars)
    assert am.args['dest'] == '/tmp/hosts'
    assert isinstance(am.args['src'], string_types) # FIXME: test src is absolute path
    assert isinstance(am.args['dest'], string_types) # FIXME: test dest is absolute path

# Generated at 2022-06-23 07:51:32.779821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(
        task=None,
        connection='smart',
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert actionModule is not None

# Generated at 2022-06-23 07:51:40.296094
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None)
    # Checks to see if action_module is an instance of ActionBase
    assert isinstance(action_module, ActionBase)
    # Checks to see if run method is overridden
    assert ActionModule.run != ActionBase.run
    # Checks to see if the doc is updated
    assert 'Saves files from remote nodes' in ActionModule.__doc__

# Generated at 2022-06-23 07:51:48.038998
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit test for method run of class ActionModule. '''
    from ansible.plugins.action import ActionModule
    from ansible.plugins.strategy import StrategyBase

    source = 'test source'
    dest = 'test destination'
    flat = 'test flat'

    class TestActionModule(ActionModule):
        ''' Unit test ActionModule class. '''
        def run(self, tmp=None, task_vars=None):
            ''' Test run method of ActionModule class. '''
            return super(TestActionModule, self).run(tmp=tmp, task_vars=task_vars)

    class TestStrategyBase(StrategyBase):
        ''' Unit test StrategyBase class. '''
        def run(self, iterator):
            ''' Test run method of StrategyBase class. '''

# Generated at 2022-06-23 07:51:48.846162
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 07:51:50.801187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None)
    assert type(action) == ActionModule

# Generated at 2022-06-23 07:52:02.300157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Returns list of 2-tuples with unit test for method ActionModule.run
       First value in tuple is test description, second one is exception
       raised by action or None if test passed.
       Method is not tested against remote server, only arguments are checked.
       Additional parameters:
          _task -- task with parameters relevant to action
    '''
    action = ActionModule(task=dict())
    # Create temporary directories for testing
    tmpdir = tempfile.mkdtemp(dir='/tmp')
    testdir = tempfile.mkdtemp(dir=tmpdir)
    os.chmod(tmpdir, stat.S_IRWXU)  # rwx for owner
    os.chmod(testdir, stat.S_IRWXU)  # rwx for owner
    # Make sure testdir does not exist remotely
    action._execute_

# Generated at 2022-06-23 07:52:05.976502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' test_ActionModule: validate that the action module can be instantiated '''

    PluginClass = ActionModule(None, None, None, None, None)
    assert PluginClass is not None

# Generated at 2022-06-23 07:52:08.578524
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    test_object = None
    task_vars = {}
    result = module.run(test_object, task_vars)
    assert 'changed' in result
    assert 'failed' in result
    assert 'file' in result

# Generated at 2022-06-23 07:52:11.130937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    pass



# Generated at 2022-06-23 07:52:13.804217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule(dict(src=None, dest=None), object())
    m.run(dict(), dict())

# Generated at 2022-06-23 07:52:24.392058
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import __main__
    import sys

    # Construct the class without calling run
    a = ActionModule(
        task=dict(action='fetch', args=dict(src='/tmp/source', dest='/tmp/destination')),
        connection=dict(host='localhost', port=22, user='foobar', password='password', ssh_executable='/usr/bin/ssh', scp_executable='/usr/bin/scp'),
        play_context=dict(become=False, become_user='root', become_method='sudo', verbosity=5),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # Make sure the class was initialized correctly
    assert isinstance(a, ActionModule)

    # Assign the _loader
    a._loader = dict()



# Generated at 2022-06-23 07:52:25.103448
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 07:52:35.418246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action.fetch import ActionModule

    tmp = '/tmp'
    source = 'fetch_file.py'
    dest = '/tmp/fetch_file.py'
    os.remove(dest)

    # mock _execute_module
    with mock.patch('ansible.plugins.action.fetch.ActionBase._execute_module') as mock_execute_module:
        mock_execute_module.return_value = dict(
            encoding='base64',
            content=base64.b64encode('#!/usr/bin/python')
        )

        # mock display

# Generated at 2022-06-23 07:52:47.114673
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import copy

    task = dict(action=dict(module='fetch', args=dict(src='/path/to/file', dest='/tmp/other/file')))

    display = Display()
    play_context = PlayContext(None, None, None, None, None, None)
    new_stdin = None

    connection = dict(connection_plugins=dict(connection='local'))
    shared_loader_obj = DictDataLoader({})
    shared_action_obj = ActionBase()
    new_stdin = None

    task_copy = copy.deepcopy(task)

# Generated at 2022-06-23 07:52:48.294123
# Unit test for constructor of class ActionModule
def test_ActionModule():

    am = ActionModule()


# Generated at 2022-06-23 07:52:57.914195
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import re
    import json
    module_name = 'ansible.legacy.fetch'
    module_args = dict(
        dest="/tmp/fetch_test/test_file.txt",
        src="/test_file.txt",
    )
    mock_task_vars = dict(
        ansible_user="ansible",
        ansible_become_user="root",
        ansible_become=True,
    )
    class Mock_Data(object):
        def __init__(self):
            self.content = "test-file-content"
            self.encoding = "base64"
    class Mock_get_bin_path(object):
        def __init__(self):
            self.bin_path = "path"

# Generated at 2022-06-23 07:53:07.423852
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  task = dict(dest = "/tmp/some/dir")
  fileParams = dict(src = "some/file/path", dest = "/tmp/some/dir")
  task['args'] = fileParams
  shell = FakeShell({"module_name":"ansible.legacy.slurp"})
  connection = FakeConnection(shell)
  task_vars = dict()

  actionModule = ActionModule(task, connection, task_vars)
  result = actionModule.run(None, task_vars)
  assert not result['failed']
  assert result['changed']
  assert result['checksum'] == shell.slurpReturn['checksum']
  assert result['remote_checksum'] == shell.slurpReturn['checksum']
  assert result['dest'] == fileParams['dest']

# Generated at 2022-06-23 07:53:19.246537
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    from ansible.plugins.action import ActionBase
    host_address = os.environ.get('ANSIBLE_REMOTE_TMP','/tmp')
    result = dict()
    # Host not reachable when true, so no need to test
    # test_ActionModule_run.test_Run_Host_not_reachable
    # def test_Run_Host_not_reachable(self):
    # def test_Run_No_host_file_and_host_not_reachable(self):
    # def test_Run_Host_not_reachable(self):
    # file Reachable ssh
    # def test_Run_Host_reachable_ssh(self):
    # def test_Run_Host_reachable_no_host_file(self):
    # test_ActionModule_run.test_Run_

# Generated at 2022-06-23 07:53:21.399329
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    TestModule constructor
    '''
    a = ActionModule()
    assert a


# Generated at 2022-06-23 07:53:32.822992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # ActionModule(connection, task, play_context, loader, templar, shared_loader_obj)
    # Note: templar and shared_loader_obj are automatically created by Ansible based on the context and cannot be simply instantiated.
    from ansible.plugins.connection.local import Connection
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.template.template import AnsibleBaseTemplar
    from ansible.template.safe_eval import SafeEval
    from ansible.template.template import AnsibleVars

    a = PlayContext()
    b = Connection('/bin/sh')
    c = Task()
    d = AnsibleVars()

# Generated at 2022-06-23 07:53:43.534756
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.compat.six.moves.builtins
    ansible.compat.six.moves.builtins = __import__('__builtin__')

    from ansible.plugins.action.fetch import ActionModule
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.plugins.connection.ssh import Connection

    dest_dir, source_file = "results/temp_fetch_dest/subdir/subsubdir/", "ansible/test/fetch_source_file.txt"
    remote_url = "https://raw.githubusercontent.com/ansible/ansible/devel/examples/"
    remote_url += "%s" % source_file

    action_module = ActionModule(Connection(), task={"action": "fetch"})
   

# Generated at 2022-06-23 07:53:47.937417
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a._shared_loader_obj is not None
    assert a._connection is not None
    assert a._task is not None
    assert isinstance(a._loader, object)
    assert isinstance(a._templar, object)
    assert isinstance(a._display, object)
    assert a._play_context is not None
    assert a._task_vars is not None


# Generated at 2022-06-23 07:53:48.630959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 07:53:50.025921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Create a unit test
    pass

# Generated at 2022-06-23 07:53:50.995059
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module

# Generated at 2022-06-23 07:53:53.094212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None)
    assert isinstance(am, ActionModule)

# Generated at 2022-06-23 07:53:55.193004
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #test_module = ActionModule(None, None, None, None)
    pass

# Generated at 2022-06-23 07:53:56.119322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    pass

# Generated at 2022-06-23 07:53:57.994087
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    assert 1 == 1

# Generated at 2022-06-23 07:54:06.429355
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.fetch import ActionModule

    am = ActionModule()
    am.setup()
    am._display.verbosity = 4
    am.set_play_context(play_context=dict(
        remote_addr = '127.0.0.1',
        basedir = '.',
        remote_user = 'root',
    ))
    am.set_loader(dict())
    am.set_task(dict(args=dict(
        src = 'action_plugins/test/test.txt',
        dest = '/tmp/dest/',
        flat = True,
        validate_checksum = True,
    )))
    am.set_connection(dict())
    print(am.run())
    am.cleanup()

# Generated at 2022-06-23 07:54:15.705552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule
    """
    import ansible.playbook.play_context
    import ansible.playbook.play
    import ansible.inventory.host
    from ansible.plugins.action import ActionBase

    path = 'ansible/plugins/action'
    args = dict(src='/test', dest='/tmp/test')
    task_vars = dict()
    tmp = None

    host = ansible.inventory.host.Host(name='test')
    play_context = ansible.playbook.play_context.PlayContext()
    play = ansible.playbook.play.Play().load(dict(name='test', hosts=[]), variable_manager=None, loader=None)

# Generated at 2022-06-23 07:54:21.287187
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule, for the method run
    test_fixtures_module = ActionModule()
    # Set the display.verbosity = 4
    display.verbosity = 4
    # Access the method run, through instance test_fixtures_module,
    # passing parameters as named arguments
    test_fixtures_module.run(tmp=None, task_vars=None)

# Generated at 2022-06-23 07:54:26.346420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create instance of MockConnection
    conn = MockConnection()
    # Create instance of ActionModule
    action = ActionModule(conn)
    # Create instance of MockTask
    task = MockTask()
    # Initialize needed attributes of the task
    task.args = dict()
    task.args['src'] = 'source1'
    task.args['dest'] = 'destination1'
    task.args['flat'] = True
    task.args['fail_on_missing'] = False
    task.args['validate_checksum'] = False
    # Call method run of ActionModule class
    res = action.run(None, None)
    # Check if correct values are returned
    assert res['changed'] == False
    assert res['checksum'] == '1'
    assert res['dest'] == 'destination1'

# Generated at 2022-06-23 07:54:27.712836
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()

# Generated at 2022-06-23 07:54:37.972744
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import os
    import subprocess
    import tempfile
    from ansible.plugins.action.fetch import ActionModule

    test_file = None
    tmpdir = None

# Generated at 2022-06-23 07:54:49.714804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Make the test be self contained
    # We will mock the used attribute of the AnsibleVars object that is returned by '__getattr__'
    class MockTask:
        def __init__(self, args):
            self.args = args
            self.name = 'fetch'
            self.dep_chain = None
            self.tags = ['always']
            self.action = 'fetch'
            self.role = None
            self.role_name = None

    class MockPlayContext:
        def __init__(self):
            self.check_mode = True
            self.remote_addr = '127.0.0.1'

    class MockCollection:
        def __init__(self):
            self.name = 'test_module'
            self.root = '/tmp'
            self.paths = []

   

# Generated at 2022-06-23 07:54:59.923247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.module_utils.connection import Connection

    module_args = {"src": "test.txt", "dest": "/tmp"}
    task_vars = {
        'tmpdir': '/tmp',
    }
    tmpdir = '/tmp'



# Generated at 2022-06-23 07:55:09.502025
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Called in test_action.py
    module = 'fetch'
    source = '/etc/a'
    dest = '/etc/b'
    flat = False
    fail_on_missing = True
    validate_checksum = True
    md5check = 'd41d8cd98f00b204e9800998ecf8427e'
    # prepare
    am = ActionModule()

# Generated at 2022-06-23 07:55:20.172702
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    If a test module is available, provide a constructor test to
    ensure that the module is constructed correctly
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_

# Generated at 2022-06-23 07:55:23.903990
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create args and kwargs for the method
    args = {}
    kwargs = {}

    # Construct the object and call the method
    obj = ActionModule()
    obj.run(*args, **kwargs)

# Generated at 2022-06-23 07:55:24.535423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:55:26.021499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Running ActionModule.run()")

# Generated at 2022-06-23 07:55:37.162931
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 07:55:48.412495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.utils.hashing import checksum, checksum_s, md5, secure_hash
    from ansible.plugins.action import ActionBase
    from ansible.utils.path import makedirs_safe
    from settings import PLUGINS_PATH
    from ansible import constants as C
    import imp, os

    test_path = os.path.join(PLUGINS_PATH, 'action', 'test_action.py')
    action_module = imp.load_source('test_action', test_path)
    test_module = action_module.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    test_module

# Generated at 2022-06-23 07:55:50.003614
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action as action_module
    action_module.ActionModule()

# Generated at 2022-06-23 07:55:59.871728
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Connect to remote host
    def connect(self, module_name, args, inject, complex_args=None, **kwargs):
        # TODO: test_ActionModule
        #print module_name, args, inject, complex_args, kwargs

        if module_name == 'ansible.legacy.slurp':
            # slurping will be called if file does not exist on remote host
            return dict(content='', encoding='base64')
        else:
            raise AnsibleError('this method is not implemented')

    # Copy file to remote host
    def fetch_file(self, in_path, out_path):
        # TODO: test_ActionModule
        #print in_path, out_path

        raise AnsibleError('this method is not implemented')


# Generated at 2022-06-23 07:56:04.386396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    values = dict(
        src='/my/src',
        dest='/my/dest',
        flat=True,
        fail_on_missing=False,
        validate_checksum=False,
    )
    # TODO: write tests for the module
    # FIXME: test for privileged user
    # FIXME: test for unprivileged user
    pass

# Generated at 2022-06-23 07:56:07.427192
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a is not None

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 07:56:16.755143
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.plugins.loader import connection_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    import operator
    from ansible.utils.path import makedirs_safe, is_subpath

# Generated at 2022-06-23 07:56:21.966591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing test
    module = None
    # Currently fails because it requires an object of type 'Connection'. Therefore
    # module cannot be initialized and test fails.
    """
    module = AnsibleModule(
        argument_spec = dict(
            src=dict(),
            dest=dict(),
            flat=dict(),
            fail_on_missing=dict(),
            validate_checksum=dict()
        ),
        supports_check_mode=False,
        required_one_of=[['src', 'dest']],
        add_file_common_args=True
    )

    # Test execution
    result = module.run()
    assert result is not None
    """
    return

# Generated at 2022-06-23 07:56:33.354683
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import module_utils.basic
    import ansible.playbook.play_context
    import ansible.utils.vars
    import ansible.utils.path
    import ansible.vars.manager
    import ansible.plugins.loader
    import ansible.inventory.manager
    import ansible.utils.plugin_docs
    import ansible.utils.display
    import connections.ssh

    display = ansible.utils.display.Display()
    task_vars = ansible.vars.manager.VariableManager()
    play_context = ansible.playbook.play_context.PlayContext()
    loader = ansible.plugins.loader.ActionModuleLoader(None, '/nonexistent/path', '', play_context, None, None, display)
    connection = connections.ssh.Connection(play_context)
    action_module = Action

# Generated at 2022-06-23 07:56:37.118607
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ac_module = ActionModule(dispatcher=None, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert ac_module is not None

# Generated at 2022-06-23 07:56:44.195142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock.
    class MockConnection(object):
        class MockShell(object):
            def __init__(self):
                self.tmpdir = None

        def __init__(self):
            self._shell = None
            self.become = None

        def _shell_plugin(self):
            return self.MockShell()

        def _execute_remote_stat(self, source, all_vars=None, follow=None):
            pass

        def fetch_file(self, source, dest):
            pass

    conn = MockConnection()

    class MockLoader(object):
        def __init__(self):
            self.path_dwim = None

    class MockTask(object):
        def __init__(self):
            self.args = {}


# Generated at 2022-06-23 07:56:56.771518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    text = "my message"
    text_b64 = base64.b64encode(to_bytes(text))
    remote_checksum = checksum_s(text)
    source = "src.txt"
    dest = os.getcwd()

    temp_file = open(source, "w")
    temp_file.write(text)
    temp_file.close()

    temp_file = open(source, "r")
    local_checksum = checksum(source)
    temp_file.close()

    loader, tmpdir = init_loader()

# Generated at 2022-06-23 07:56:58.783736
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """
    # There is not enough context necessary to implement this unit test
    pass

# Generated at 2022-06-23 07:57:09.688261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import os
    import shutil
    import sys
    import tempfile
    import textwrap
    import time

    import pytest

    # disable collection of test's result
    pytest.disable_test_result_collection()

    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.plugins.action import ActionBase
    from ansible.utils.hashing import checksum, checksum_s, md5, secure_hash

    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            print("TestActionModule")

# Generated at 2022-06-23 07:57:17.164286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    assert a.run() == dict(msg="src and dest are required")
    assert a.run(tmp='/tmp', task_vars=dict(src=1, dest=2)) == dict(msg="Invalid type supplied for source option, it must be a string")
    assert a.run(tmp='/tmp', task_vars=dict(src=1, dest=2)) == dict(msg="Invalid type supplied for source option, it must be a string")

# Generated at 2022-06-23 07:57:17.673915
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:57:23.200328
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test case for method run of class ActionModule
    """
    connection = Connection(module_name='copy', module_args={'src': "", "dest": ""})
    task = Task(action=dict(module='copy', src="", dest=""))
    action_module = ActionModule(connection=connection, task=task, play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)
    try:
        action_module.run()
    except Exception:
        return False
    return True

# Generated at 2022-06-23 07:57:31.030311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(
        action=dict(
            module='fetch',
            args=dict(
                flat=False,
                src='http://example.host/path/to/file',
                dest='/dest/dir',
            ),
        ),
        register='result',
    )

    import ansible.plugins.action.fetch

    action_plugin = ansible.plugins.action.fetch.ActionModule(task, None)
    result = action_plugin.run(None, None)
    assert result['changed'] == True