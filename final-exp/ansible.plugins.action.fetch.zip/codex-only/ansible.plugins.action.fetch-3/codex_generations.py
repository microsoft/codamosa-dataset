

# Generated at 2022-06-23 07:47:41.970615
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.fetch import fetch_action


# Generated at 2022-06-23 07:47:47.158750
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(action=dict(module_name='copy')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )

    assert isinstance(module, ActionModule)



# Generated at 2022-06-23 07:47:49.760783
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # this is a constructor test, and does not need to test the functionality
    # as it is inherited from ActionBase
    assert ActionModule is ActionBase

# Generated at 2022-06-23 07:47:51.285333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule(None, None, None)

# Generated at 2022-06-23 07:48:01.260305
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Get a test task
    task = dict(action=dict(module='fetch',
                          src='/tmp/test.txt',
                          dest='/tmp/test.txt'))
    # Get a test play context
    p = dict(remote_addr='ec2-52-207-40-71.compute-1.amazonaws.com',
             connection='local')
    pc = PlayContext(p)
    # Get a test connection
    conn = {'connection': 'ssh',
            'module_name': 'test',
            'module_args': 'test',
            'timeout': 5}
    # Set up the test ActionModule
    am = ActionModule(task, pc, conn)
    am.setup()

    # Execute the test
    am.run(task_vars=dict())

# Generated at 2022-06-23 07:48:12.687507
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.utils.module_docs as doc
    from ansible.errors import AnsibleActionFail

    module = doc.get_docstring(ActionModule, verbose=None)

    task_vars = {'inventory_hostname':'host1'}

    display.verbosity = 1
    # dest does not exist
    proxy = ActionModule(
        task=dict(args=dict(src='source_file', dest='source_path/dest_dir')),
        connection=doc.get_docstring(ActionBase, verbose=None))
    proxy.run(task_vars=task_vars)

    # source exists, dest does not, dest_is_dir=True

# Generated at 2022-06-23 07:48:22.137281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.__class__.__name__ == 'ActionModule'
    assert am._task.__class__.__name__ == 'Task'
    assert am._loader.__class__.__name__ == 'DataLoader'
    assert am._templar.__class__.__name__ == 'Templar'
    assert am._shared_loader_obj.__class__.__name__ == 'DataLoader'
    assert am._connection.__class__.__name__ == 'Connection'
    assert am._play_context.__class__.__name__ == 'PlayContext'
    assert am._loader_name == 'loader'
    assert am._shared_loader_name == 'loader'
    assert am._connection_name == 'local'
    assert am._play_context_name == 'play'

# Generated at 2022-06-23 07:48:23.152244
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 07:48:24.532007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule.run")

# Generated at 2022-06-23 07:48:27.195694
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule("task", None)
    assert ActionModule("task", { "foo": "bar"})
    assert ActionModule("task", { "foo": "bar", "tmp": "mnt" })

# Generated at 2022-06-23 07:48:28.886942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-23 07:48:37.701605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.connection import Connection
    from ansible.errors import AnsibleParserError
    import os
    import shutil

    class TestPlaybook():

        def load(self, ds, variable_manager=None, loader=None):
            pass

    class TestPlay():

        def __init__(self, play_context, variable_manager):
            self.play_context = play_context

# Generated at 2022-06-23 07:48:41.562829
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # make a fake obj to test constructor.
    action = ActionModule('test', '10.0.0.1', '22', 'root', 'PASSWORD', 'FAKE_NAME', 'FAKE_MASTER')
    assert action.name == 'test', "ActionModule constructor failed"

# Generated at 2022-06-23 07:48:45.011585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:48:48.422458
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit tests for return values of function run of class ActionModule
    # For valid input parameters, check if the return value is correct
    # For invalid input parameters, check if an exception is raised (For all the input parameters)
    assert True

# Generated at 2022-06-23 07:48:58.506474
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_host_info = {"ansible_ssh_pass": "pass",
                      "ansible_ssh_user": "user",
                      "ansible_ssh_host": "test_host_name",
                      "ansible_ssh_port": 22,
                      "ansible_ssh_private_key_file": "/path/to/private_key",
                      "ansible_python_interpreter": "/usr/bin/python"}

    test_task = {"action": {"__name__": "action_module_name", "args": {"arg1": "val1"}}}

    test_loader = None

    test_var_manager = None

    test_play_context = None

    test_shared_loader_obj = None

    test_connection = None


# Generated at 2022-06-23 07:49:03.763926
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(None, {}, Display())

    task_vars = {
        'ansible_fetch_nonlocal': False,
        'ansible_fetch_local_kwarg': {
            'paths': 'test_file.txt'
        }
    }

    try:
        action_module.run(task_vars=task_vars)
    except AnsibleActionFail as aaf:
        assert 'src and dest are required' in aaf.message

# Generated at 2022-06-23 07:49:04.988665
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.get_name() == '_fetch'


# Generated at 2022-06-23 07:49:05.924277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 07:49:09.856203
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Define a dict which is passed to the constructor of
    the class under test.
    '''
    task_vars = {}

    from ansible.plugins.action.fetch import ActionModule
    fetch = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    fetch.run(None, task_vars)

# Generated at 2022-06-23 07:49:15.020805
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule
    """
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a is not None

# Generated at 2022-06-23 07:49:24.117687
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import pdb
    pdb.Pdb(stdout=sys.__stdout__).set_trace()

    # Initialize the class
    action_module = ActionModule()

    # Initialize the loader and runner
    loader = action_module._loader
    runner = action_module._shared_loader_obj.runner

    # Initialize the play_context
    play_context = action_module._play_context
    play_context.become = True

    # Initialize the connection
    connection = action_module._connection
    connection.become = True

    # Initialize the task
    action_module._task.args = {'src': 'test.py', 'dest': '/tmp'}

    # Execute the run method
    pdb.Pdb(stdout=sys.__stdout__).set_trace()


# Generated at 2022-06-23 07:49:28.474685
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fm = ActionModule(dict(src='/path/to/src', dest='/path/to/dest'), dict(action='fetch'))
    res = fm.run()
    assert res['changed'] == False
    assert 'checksum' in res
    assert 'checksum_type' not in res

# Generated at 2022-06-23 07:49:31.912676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(action=dict(module_name='fetch')), connection=dict(module_name='fetch'), runner_queue=dict(module_name='fetch'))
    module.run(tmp=None, task_vars=None)

# Generated at 2022-06-23 07:49:43.619367
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    runner_args = {'host': 'localhost', 'transport': 'local'}
    runner = Runner(**runner_args)
    task_args = {'src': '/path/to/src', 'dest': '/path/to/dest'}
    task_vars = {}
    runner._tqm._data_loader.set_basedir('/path/to/basedir')
    runner._tqm._nonpersistent_fact_cache = {}
    runner._under_executor = False
    task = Task()
    task.args = task_args
    runner._tqm._final_q = queue.Queue()
    runner._tqm._workers = []
    runner._tqm.send_callback('v2_runner_on_ok', runner._result, task)
    result = runner._result

# Generated at 2022-06-23 07:49:44.272627
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 07:49:47.322702
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule
    """
    action = ActionModule()
    if not isinstance(action, ActionModule):
        raise AssertionError("Constructor of class ActionModule failed")

# Generated at 2022-06-23 07:49:59.039039
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_task = dict(action=dict(module='fetch', args=dict(src='/tmp/foo', dest='/tmp/bar'), register='x'))
    test_play_context = dict(basedir='.', remote_addr='127.0.0.1', password='pass', port='8088', become_pass='become_pass', connection='local', become='false')
    test_task_vars=dict(ansible_job_id='123', ansible_ssh_pass='pass')
    am = ActionModule(task=test_task, play_context=test_play_context, new_stdin=None)
    print(am.run(task_vars=test_task_vars))

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 07:50:03.553746
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    action_module = ansible.plugins.action.ActionModule(task=dict(), connection='local', play_context=dict(), loader='', templar='', shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-23 07:50:08.228856
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(a, ActionModule)
    assert hasattr(a, 'run')


# Generated at 2022-06-23 07:50:08.818898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-23 07:50:11.138040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule('localhost', 1, 2, 3), ActionModule)

# Generated at 2022-06-23 07:50:25.403300
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from unittest.mock import patch, Mock
    from ansible.errors import AnsibleError
    from ansible.plugins.action import ActionBase
    from ansible.utils.hashing import checksum

    class ActionModuleMock(ActionModule):
        def _execute_module(self, *args, **kwargs):
            if args[1].get('src') == 'mocked_fail':
                return dict(failed=True)
            else:
                return dict(content=base64.b64encode(b'test data'), encoding='base64')

        def _execute_remote_stat(self, *args, **kwargs):
            if args[0] == 'mocked_fail':
                raise AnsibleError('mocked_fail')

# Generated at 2022-06-23 07:50:31.727447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import tempfile
    from ansible.utils.remote_tmp import RemoteTmp
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.fetch import ActionModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')

# Generated at 2022-06-23 07:50:39.626611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    module_utils_path = os.path.join(os.path.dirname(__file__), os.pardir, os.pardir)
    module_utils_path = os.path.abspath(module_utils_path)
    tmpdir = os.path.join(module_utils_path, "tmp")
    makedirs_safe(tmpdir)
    source = tmpdir
    destination = os.path.join(tmpdir, "destdir")
    makedirs_safe(destination)
    task_vars = {"inventory_hostname":"localhost"}
    _connection = Connection()
    _play_context = PlayContext()
    _task = Task()
    _loader = DataLoader()
    _play_context.network_os = 'Test'

# Generated at 2022-06-23 07:50:45.216724
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule(mock.Mock(), mock.Mock(), dict(action='copy', src='./test/a', dest='./test/b'))
    assert act.runner.action == 'copy'
    assert act._action == 'copy'

# Generated at 2022-06-23 07:50:47.444892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None

# Generated at 2022-06-23 07:50:51.430275
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #action = ActionModule({"dest": "test_fetch_to_var"}, "/tmp", "test_connection")
    action = ActionModule(dict(), "/tmp", "test_connection")
    assert action._task.args["dest"] == "test_fetch_to_var"
    assert action._loader.path_basedir == "/tmp"
    assert action._connection.__class__.__name__ == "Connection"

# Generated at 2022-06-23 07:50:56.844727
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader

    tqm = None


# Generated at 2022-06-23 07:51:07.564619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    class test_ActionModule_run_case(unittest.TestCase):
        class ActionModule_test_mock(ActionModule):
            def __init__(self, *args, **kwargs):
                super(test_ActionModule_run_case.ActionModule_test_mock, self).__init__(*args, **kwargs)
                self._execute_remote_stat_cache = dict()
            def _execute_remote_stat(self, source, all_vars=dict(), follow=True):
                if source not in self._execute_remote_stat_cache:
                    raise AnsibleError('expected item not found: %s' % source)
                else:
                    return self._execute_remote_stat_cache[source]
            def _remote_expand_user(self, source):
                return source


# Generated at 2022-06-23 07:51:09.784155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod._task.action == 'fetch', \
        "Error: Failed to initialize ActionModule class"

# Generated at 2022-06-23 07:51:10.973646
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, dict())

    return None

# Generated at 2022-06-23 07:51:12.168732
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-23 07:51:13.151971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-23 07:51:14.944050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Test
    pass

# Generated at 2022-06-23 07:51:15.994786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:51:26.925543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Use to test the results of run.
    This can be used for testing for both success and failures.
    """
    display.verbosity = 2
    ansible = AnsibleModule(
        argument_spec = dict(
            src = dict(required=True, type='path'),
            dest = dict(required=True, type='path'),
            flat = dict(default=False, type='bool'),
            validate_checksum = dict(default=True, type='bool'),
            fail_on_missing = dict(default=True, type='bool')
        ),
        supports_check_mode=True,
        required_one_of=[['path', 'content']],
        bypass_checks=False,
    )
    module = make_mock_action_module(ansible)
    module.run()



# Generated at 2022-06-23 07:51:27.478923
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1

# Generated at 2022-06-23 07:51:31.379606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestConnection(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir
            self.become = False

        def _shell_quote(self, string):
            return "'%s'" % string

        def _shell_unsafe_quote(self, string):
            return "'%s'" % string

        def _shell_safe_quoted(self, string):
            return "'%s'" % string

        def _is_original_shell_safe_quote(self):
            return True

        def _shell_expand_user(self, string):
            return string

        def _get_remote_tmp_dir(self):
            return self.tmpdir

        def _execute_remote_stat(self, *args, **kwargs):
            return dict()


# Generated at 2022-06-23 07:51:33.142877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = AnsibleModule()
    assert module is not None

# Generated at 2022-06-23 07:51:33.897164
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 07:51:34.446725
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 07:51:43.731363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    conn = FakeConnection("fakehost")
    context = FakeContext("fake_action")
    task = FakeTask("fake_action")
    connection = None
    ansible_connection = "local"
    ansible_module_name = "fake_module"
    try:
        am = ActionModule(connection, context, task, ansible_connection, ansible_module_name)
    except Exception as e:
        raise Exception("Got exception when instantiated {0}, exception is: {1}".format(am.__class__.__name__, e))
    else:
        am.run(None, task_vars=None)

# Generated at 2022-06-23 07:51:45.351046
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('', {}, '', '', '')

# Generated at 2022-06-23 07:51:57.537916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ##################################
    # Test scenario 1 - fetch module
    ##################################
    mock_task_vars = dict()
    mock_task_vars['inventory_hostname'] = 'Test'
    mock_task_vars['connection_host'] = 'TestHost'
    mock_task_vars['ansible_check_mode'] = False
    mock_task_vars['ansible_ssh_common_args'] = "-o BatchMode=yes -o StrictHostKeyChacking=no"
    mock_task_vars['ansible_architecture'] = 3
    mock_task_vars['ansible_ssh_pass'] = u'password'
    mock_task_vars['ansible_user'] = u'User'
    mock_task_vars['ansible_connection'] = 'winrm'
   

# Generated at 2022-06-23 07:52:00.244405
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModules = ActionModule(None, None, None, None, None, None)
    print("%s" % actionModules)

# Generated at 2022-06-23 07:52:08.958545
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # For now we just test the provided example in the docstring
    class MockConnection:
        @staticmethod
        def _shell_escape(arg):
            return '"{}"'.format(arg.replace('"', '\\"'))
        @staticmethod
        def _executor_type():
            return "basic"
        def _shell_expand_user(self, path):
            return path
        def _shell_quote(self, path):
            return path
        def fetch_file(self, src, dest):
            pass

    class MockLoader:
        @staticmethod
        def path_dwim(path):
            return path

    connection = MockConnection()
    loader = MockLoader()
    action_module = ActionModule(connection, loader)
    tmp = None
    task_vars = {}


# Generated at 2022-06-23 07:52:21.223374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(None)

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    module_args = dict(src='/dev/null', dest='/tmp/test_actionmodule', flat=True, fail_on_missing=True, validate_checksum=True)
    check_mode = True
    tmp = '/tmp/test_actionmodule'
    source = '/dev/null'
    task_vars = dict(inventory_hostname='foobar')


# Generated at 2022-06-23 07:52:32.448148
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """This is a unit test for the constructor of ActionModule class
        It checks if the object is initialized properly or not."""
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.connection.connection_loader import ConnectionLoader

    task = Task()
    task_vars = dict()
    play_context = PlayContext()
    connection_loader = ConnectionLoader()
    inventory = InventoryManager(loader=None, sources='')
    variable_manager = None
    loader = None

# Generated at 2022-06-23 07:52:40.409419
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = 'ansible.plugins.action.fetch.ActionModule'
    b = '/tmp/ansible_fetch_payload_WbwNIi'

# Generated at 2022-06-23 07:52:43.418964
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 07:52:44.306278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-23 07:52:50.138307
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
        Testcase:
            Function: run
            @param tmp
            @param task_vars
        Expected:
            AnsibleActionFail
    '''
    mod = ActionModule()
    task = AnsibleActionSkip('check mode not (yet) supported for this module')

    try:
        mod.run(task)
    except AnsibleActionFail as ae:
        assert str(ae).startswith('check mode not (yet) supported for this module')

# Generated at 2022-06-23 07:53:00.333811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import sys
    import os

    # set up necessary objects
    results = dict()
    results['localhost'] = dict()
    results['localhost']['unreachable'] = 0
    results['localhost']['skipped'] = 0
    results['localhost']['ok'] = 1
    results['localhost']['changed'] = 0
    results['localhost']['failures'] = 0

    play_context = dict()
    play_context['remote_addr'] = "192.168.100.100"
    play_context['remote_user'] = "root"
    setattr(play_context, 'connection', 'local')
    setattr(play_context, 'become_user', 'root')
    setattr(play_context, 'become', True)

    play_source = dict()
    play_

# Generated at 2022-06-23 07:53:08.917161
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # setup for test
    class Task(object):
        pass
    task = Task()
    task.args = dict()
    task.args['src'] = '/etc/hosts'
    task.args['dest'] = '/tmp/hosts'

    class Connection(object):
        pass
    connection = Connection()
    connection._shell = dict()
    connection._shell.tmpdir = '/tmp'
    connection._shell.join_path = lambda path, *paths: "/tmp/ansible_test"

    class PlayContext(object):
        pass
    play_context = PlayContext()

    # constructor test
    am = ActionModule(task, connection, play_context, loader=None, templar=None, shared_loader_obj=None)
    assert len(am._loader_temps) == 0

# Generated at 2022-06-23 07:53:17.542760
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This test is to test the constructor of class ActionModule.
    """
    # AnsibleModule is the constructor of class AnsibleModule.
    # create a AnsibleModule object to call ActionModule constructor
    module = AnsibleModule(argument_spec={'foo': {'required': False, 'type': 'str'}})
    # create action module object
    fetch_module = ActionModule(module, None)
    # test if the construction is correct.
    assert fetch_module.name == 'fetch', "fetch module construction failed"


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 07:53:27.435617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set module
    module = AnsibleModule(
        argument_spec = dict(
            src = dict(required=True, type='str'),
            dest = dict(required=True, type='str'),
            flat = dict(required=False, type='bool', default=False),
            fail_on_missing = dict(required=False, type='bool', default=True),
        ),
        add_file_common_args=True
    )

    # set connection
    connection = Connection(module._socket_path)

    # set action plugin
    action = module.action
    del module.action

    # set task
    task = Task()
    task.module_args = module.params

    # set Main playbook

# Generated at 2022-06-23 07:53:31.681253
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 07:53:32.994500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:53:36.090761
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test = ActionModule()
    assert test is not None


# Generated at 2022-06-23 07:53:46.142963
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # some basic AnsibleModule unit tests...

    # test require
    module = AnsibleModule({'src': '/tmp/a', 'dest': 1}, 'a')
    assert module.fail_json['msg'] == 'value of src must be a string'
    module = AnsibleModule({'src': '/tmp/a', 'dest': ''}, 'a')
    assert module.fail_json['msg'] == 'value of dest must be a string'
    module = AnsibleModule({'src': '/tmp/a'}, 'a')
    assert module.fail_json['msg'] == 'src and dest are required'

    # test default values
    module = AnsibleModule({'src': '/tmp/a', 'dest': ''}, 'a')
    assert module.params['flat'] == False

# Generated at 2022-06-23 07:53:57.235273
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from collections import namedtuple
    from ansible.executor.task_result import TaskResult

    class TestDisplay:
        def __init__(self):
            self.display = []

        def display(self, msg, *args, **kwargs):
            self.display.append(msg)

    class TestConnection:
        def __init__(self):
            self._shell = TestShell()
            self.become = False

        def _shell_escape(self, path):
            return "".join(["\\%s" % c if c in ["$", "`"] else c for c in path])

        def _shell_expand_path(self, path):
            return "%s%s%s" % ("./test_data/", path, "")


# Generated at 2022-06-23 07:54:01.724591
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test constructor of class ActionModule
    """
    try:
        a = ActionModule()
        assert False
    except Exception:
        assert True


# Generated at 2022-06-23 07:54:09.770986
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import copy
    import mock
    import os.path

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 07:54:10.374269
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    print(actionModule)

# Generated at 2022-06-23 07:54:18.673693
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class TestConnection:
        def __init__(self, become=False):
            self.become = become
            self.tmpdir = '/tmp'

        def fetch_file(self, src, dest):
            return True

    class TestTask:
        def __init__(self, args):
            self.args = args

    class TestPlayContext:
        def __init__(self, check_mode=False):
            self.check_mode = check_mode
            self.remote_addr = 'localhost'

    class TestSrc:
        def __init__(self, path):
            self.path = path

        def join_path(self, src):
            return self.join_path(src)

        def _unquote(self, src):
            return src


# Generated at 2022-06-23 07:54:29.247769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.action.copy import ActionModule
    # mock class for testing
    class MockConnection(object):
        def __init__(self):
            self.become = True
            self.processed_to_remote = False
            self.tmpdir = 'tmp_dwim_path'

        def _shell_expand_path(self, path):
            return path

        def _shell_expand_user(self, user):
            return user

        def fetch_file(self, source, dest):
            self.processed_to_remote = True
            self.source = source
            self.dest = dest


# Generated at 2022-06-23 07:54:30.287706
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None

# Generated at 2022-06-23 07:54:38.699503
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    path = os.path.join(os.path.dirname(__file__), 'fetch.py')
    m = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    test_host = {
        'ansible_connection': 'test_connection',
        'ansible_inventory': '{ "test_host": { "hosts": { "test_host": { "ansible_port": 42 } } } }',
        'ansible_host': 'test_host',
        'ansible_ssh_host': 'test_host',
    }

    # test if file exists on remote host

# Generated at 2022-06-23 07:54:48.908440
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(dict(connection= '', play_context='', loader='', variable_manager='', _task='' ))
    assert a is not None
    # set_options called from __init__; calling again prints error message
    #a.set_options()
    assert a.noop_on_check(task_vars=dict(ansible_check_mode=True))
    assert a.noop_on_check() == False
    assert a.noop_on_check(task_vars=dict(ansible_check_mode=False)) == False
    assert a.noop_on_check(task_vars=dict(ansible_check_mode=False, ansible_no_log=False)) == False

# Generated at 2022-06-23 07:54:58.478775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.fetch import ActionModule

    # Create instance of class ActionModule for test
    action_module = ActionModule(
        task=dict(
            args=dict(src=None, dest=None)
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # Asserting the method run()
    result = action_module.run(tmp=None, task_vars=None)
    assert result.get('failed')
    assert result['failed'] is True
    assert result['msg'] == 'src and dest are required'

# Generated at 2022-06-23 07:54:59.080772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 07:55:09.421463
# Unit test for constructor of class ActionModule
def test_ActionModule():
    src = '~/src/ansible'
    dest = '~/dest/ansible'
    flat = True
    fail_on_missing = False
    validate_checksum = True
    task = dict(src=src, dest=dest, flat=flat, fail_on_missing=fail_on_missing, validate_checksum=validate_checksum)
    am = ActionModule(task=task)
    assert am._task.args['src'] == src
    assert am._task.args['dest'] == dest
    assert am._task.args['flat'] == flat
    assert am._task.args['fail_on_missing'] == fail_on_missing
    assert am._task.args['validate_checksum'] == validate_checksum

# Generated at 2022-06-23 07:55:12.774318
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None

# Generated at 2022-06-23 07:55:13.534075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:55:19.086148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = type('MockTask', (object,), {'args': {'src': '.', 'dest': '.'}})()
    mock_task.args = {'src': 'file_src', 'dest': 'file_dest'}
    mock_play_context = type('MockPlayContext', (object,), {'check_mode': False})()
    mock_connection = type('MockConnection', (object,), {'become': False})()
    mock_connection._shell = type('MockShell', (object,), {'join_path': str, '_unquote': str, 'tmpdir': str})()
    mock_loader = type('MockLoader', (object,), {'path_dwim': str})()
    

# Generated at 2022-06-23 07:55:21.813859
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.execute_module = lambda x, y, z, q=None: {}
    assert module.run(tmp='/tmp', task_vars={}) is not None

# Generated at 2022-06-23 07:55:25.501684
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Fetch instance variables
    tmp = None
    task_vars = None

    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp, task_vars)

    # Make sure result is an instance of dict
    assert isinstance(result, dict)

# Generated at 2022-06-23 07:55:35.698535
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing ActionModule constructor")
    connection = 'localhost'
    play_context = 'some play context'
    loader = 'loader object'
    templar = 'templar object'
    shared_loader_obj = 'shared loader object'

    action_module = ActionModule(connection=connection, play_context=play_context, loader=loader, templar=templar, shared_loader_obj=shared_loader_obj)

    assert action_module._connection == connection
    assert action_module._play_context == play_context
    assert action_module._loader == loader
    assert action_module._templar == templar
    assert action_module._shared_loader_obj == shared_loader_obj

# Generated at 2022-06-23 07:55:37.219002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am

# Generated at 2022-06-23 07:55:44.286794
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # First initialize some objects that the method under test need
    test_class = ActionModule(Connection())

    # Set class attributes
    test_class._task = { 'args': { 'src': '*', 'dest': '/tmp/' } }
    test_class._loader = mock_loader()

    with pytest.raises(AnsibleActionFail):
        # Test for case when dest is a directory and does not end with a /
        test_class.run()

    # Set class attributes
    test_class._task = { 'args': {
        'src': '*',
        'dest': '/tmp/',
        'validate_checksum': True,
        'fail_on_missing': True
    } }

    display.verbosity = 4

# Generated at 2022-06-23 07:55:48.247337
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    test ActionModule
    '''
    am = ActionModule(None, None, None, None, None)
    assert am is not None

# Generated at 2022-06-23 07:55:49.837139
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None)
    assert a is not None

# Generated at 2022-06-23 07:55:50.569587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 07:55:51.332672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-23 07:55:52.136553
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule() is not None

# Generated at 2022-06-23 07:56:01.042337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    # Source: __init__.py of module ansible.plugins.action
    # Source: __init__.py of module ansible.errors
    try:
        from ansible.plugins.action import ActionModule
        from ansible.errors import AnsibleActionFail
    except ImportError:
        return 77
    import sys

    # Source: __init__.py of module ansible.utils.display
    # Source: __init__.py of module configparser
    # Source: __init__.py of module ansible.module_utils.common
    # Source: __init__.py of module ansible.module_utils.common.text.converters
    # Source: __init__.py of module ansible.utils.hashing
    # Source: __init__

# Generated at 2022-06-23 07:56:12.982150
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C

    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'zip_fetch.yml')
    display.verbosity = 3

    # Patch playbook path into args, as required by TaskQueueManager
    C.DEFAULT_LOAD_CALLBACK_PLUGINS = True
    C.DEFAULT_LOAD_TASK_PLUGINS = True

    pb = Playbook.load(fixture_path, variable_manager=VariableManager(), loader=DataLoader())

# Generated at 2022-06-23 07:56:16.644737
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule


# Generated at 2022-06-23 07:56:29.214845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action.normal import ActionModule as ActionModule_normal
    from ansible.plugins.connection.local import Connection as Connection_local
    from ansible.plugins.vars.hashivault import ActionModule as ActionModule_hashivault
    from ansible.plugins.strategy.linear import StrategyModule as StrategyModule_linear

# Generated at 2022-06-23 07:56:30.676798
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_plugin = ActionModule()
    assert(action_plugin.check_mode is False)

# Generated at 2022-06-23 07:56:39.687414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.module_utils.basic
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.playbook.role.task
    import ansible.parsing.yaml.objects

    # Create mock objects
    task = ansible.playbook.task.Task()
    #task._role = ansible.playbook.role.Role()
    task._role = ansible.parsing.yaml.objects.AnsibleRole()
    task._role._task = ansible.playbook.role.task.RoleTask()
    task._role._task.role = task._role
    task._role._task.block = ansible.parsing.yaml.objects.AnsibleSequence()
    task._role._task.block.role

# Generated at 2022-06-23 07:56:50.654672
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_executor import TaskExecutor
    loader = connection_loader.get("local")
    pc = PlayContext()
    pc.connection = "local"
    task = dict(action=dict(module="copy", args=dict(src="src", dest="dest")))
    tqm = TaskQueueManager(pc, loader, passwords=dict(), strategy='free')
    te = TaskExecutor(tqm, pc, "localhost", task)
    am = ActionModule(te, tqm._shared_loader_obj, pc, '/tmp')

# Generated at 2022-06-23 07:56:51.705721
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule()
  print(dir(am))

# Generated at 2022-06-23 07:56:52.319164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:56:52.904225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:57:01.799084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager

    host = Host('testhost')
    group = Group('testgroup')
    group.add_host(host)
    inventory = Inventory(loader=None)
    inventory.add_group(group)
    inventory.add_host(host)


# Generated at 2022-06-23 07:57:09.802267
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=dict(args=dict(src="test/path/to/src", dest="test/path/to/dest", flat=False, validate_checksum=True,
                                          fail_on_missing=True)),
                      connection=dict(host="test_host", user="test_user",
                                      become=True, become_method=None, become_user="become_user"),
                      task_vars=dict(inventory_hostname="test_inventory_hostname"),
                      loaders=[])
    assert am.run(None, None)

# Generated at 2022-06-23 07:57:11.284634
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:57:13.117187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-23 07:57:21.845031
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(
            args=dict(
                dest='/tmp/some_dest',
                src='some_src',
            ),
            action=dict(
                module='fetch'
            )
        ),
        connection=object,
        play_context=object,
        loader=object,
        templar=object,
        shared_loader_obj=object
    )

    assert module._task == dict(
            args=dict(
                dest='/tmp/some_dest',
                src='some_src',
            ),
            action=dict(
                module='fetch'
            )
        )

    assert module._connection == object
    assert module._play_context == object
    assert module._loader == object
    assert module._templar == object
    assert module._shared_loader

# Generated at 2022-06-23 07:57:28.340570
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import os
    import json
    import re
    import unittest
    import ansible.constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.six import iteritems
    from ansible.module_utils import basic
    from ansible.utils.vars import combine_vars
    from units.mock.loader import DictDataLoader
    from units.mock.path import MockPath
    from units.mock.connection import Connection

    # This is a hack to get around the fact that the action plugins
    # load their subclasses dynamicall, which makes it hard to
    # mock.  So we just mock things at the instance level so that we
    # don't have to find the class and mock it

# Generated at 2022-06-23 07:57:35.494425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ActionModule_test(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(ActionModule_test, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)

        def _execute_remote_stat(self, source, all_vars=None, follow=False):
            return dict(checksum=None, exists=True)

    class Task_test():
        def __init__(self):
            self.args = dict(src='source', dest='dest')

    class Connection_test():
        def __init__(self):
            self.tmpdir = None
            self.become = False

        def _shell_expand_user(self, path):
            return path
