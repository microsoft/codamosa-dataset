

# Generated at 2022-06-23 07:47:31.995099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(argument_spec={})
    module.fail_json = lambda: None
    module.set_options = lambda: None
    module.check_mode = None
    module.run_command = lambda: (1, '', '')
    module.no_log = lambda: None

    a = ActionModule(module)
    a.run()

# Generated at 2022-06-23 07:47:34.241121
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert obj is not None

# Generated at 2022-06-23 07:47:42.214329
# Unit test for constructor of class ActionModule
def test_ActionModule():
    remote_module = ActionModule(
        task=dict(action='copy', module_name='copy'),
        connection=dict(user='ritesh', password='abc', host='10.12.0.167'),
        play_context=dict(become=True, become_user='ritesh', become_method='sudo',
                          become_flags=['-H', '-S'], no_log=True, check_mode=True),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    print(remote_module)

# Generated at 2022-06-23 07:47:51.676610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ make sure ansible.legacy.fetch module works as expected """
    host = 'testhost'
    dest = '/home/testhost/src'
    module_name = 'ansible.legacy.fetch'
    module_args = dict(src='/home/testhost/src', dest='/home/testhost/src', flat=False)
    display.verbosity = 3

    def execute_remote_stat(self, path, all_vars=None, follow=False):
        return dict(exists=True, mtime=123, size=123, isdir=False, checksum=None)

    class MockFetchModule(object):
        pass

    class Connection(object):
        def __init__(self, become=None):
            self.become = become
            self._shell = MockFetchModule()


# Generated at 2022-06-23 07:47:52.593201
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-23 07:47:54.046299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(1, 2)
    assert a._play_context == 1
    assert a._task == 2

# Generated at 2022-06-23 07:48:00.207170
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' this isn't a real test, as nothing gets asserted.  It just makes sure nothing crashes '''

    from ansible import context
    from ansible.utils.vars import merge_hash
    from ansible.vars.manager import VariableManager
    import ansible.constants as C
    context._init_global_context(C)
    context.CLIARGS = lambda: None
    context.CLIARGS.verbosity = 3
    context.CLIARGS.connection = 'local'
    context.CLIARGS.module_path = None
    context.CLIARGS.forks = 10
    context.CLIARGS.check = False
    context.CLIARGS.become = None
    context.CLIARGS.become_method = None
    context.CLIARGS.become_user

# Generated at 2022-06-23 07:48:05.991944
# Unit test for constructor of class ActionModule
def test_ActionModule():
    hostname = 'my_host'
    port = 22
    path = '/home/ansible_user'
    task = {
        'action': 'fetch',
        'args': {
            'src': 'some source',
            'dest': 'some destination'
        }
    }
    action_plugin = ActionModule(task, None, connection=None)

    # Test attributes
    assert isinstance(action_plugin, ActionBase)
    assert action_plugin._task == task
    assert action_plugin._connection == None

    # Test methods
    try:
        action_plugin.run()
    except AnsibleActionFail as e:
        pass
    else:
        assert False

# Generated at 2022-06-23 07:48:06.571415
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-23 07:48:07.462114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError

# Generated at 2022-06-23 07:48:09.979228
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')
    assert isinstance(ActionModule, type)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 07:48:20.092977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    test_task = Task()
    test_task.action = 'test_task'
    test_task.args = {}
    test_task.set_loader(None)

    # If a builtin ActionModule is specified, we should be able to create it
    fail_test = False

    # Create an ActionModule object for our test
    test_action_module = ActionModule(task=test_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    if not isinstance(test_action_module, ActionModule):
        fail_test = True

    assert fail_test != True, 'ActionModule() class constructor should return an instance of ActionModule'

# Generated at 2022-06-23 07:48:27.431323
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Returns True if new instance of ActionModule'''
    module = ActionModule(
        {},
        {},
        '127.0.0.1',
        'regular',
        'root',
        'michael',
        'passw0rd',
        '22',
        '/home/michael/ansible',
        'localhost',
        True,
        False,
        'accelerate',
        False,
        False,
        False,
        '0.0.0.0',
        False,
        '',
        '',
        False,
        10,
        '1.1.1'
    )
    if not isinstance(module, ActionModule):
        return False
    return True

# Generated at 2022-06-23 07:48:37.164136
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 07:48:46.587981
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    connection = MockConnection()
    tmp = tempfile.mkdtemp()
    src = '/path/to/source'
    dest = '/path/to/dest'
    task_vars = {'inventory_hostname': 'host'}

    task_vars_no_hostname = {}

    # test success
    result = ActionModule(MockTask({'src': src, 'dest': dest}), connection, tmp, task_vars).run()
    assert os.path.exists(dest)
    assert result.get('md5sum') == '123'
    assert result.get('remote_md5sum') == '123'
    assert result.get('checksum') == '123'
    assert result.get('remote_checksum') == '123'
    assert result.get('changed') is True

    # test fail


# Generated at 2022-06-23 07:48:54.930515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(connection = None, play_context = None, loader = None, templar = None, shared_loader_obj = None)
    action_module._task.args['src'] = 'test.txt'
    action_module._task.args['dest'] = 'dest.txt'
    result = action_module.run()
    assert result['msg'] == "src and dest are required"

    action_module._task.args['src'] = 'test.txt'
    action_module._task.args['dest'] = 'dest.txt'
    action_module._task.args['flat'] = 'True'
    action_module._task.args['fail_on_missing'] = 'True'
    action_module._task.args['validate_checksum'] = 'True'

# Generated at 2022-06-23 07:49:01.191500
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            pass

    try:
        am = TestActionModule(task=dict(args=dict(before='before', after='after')))
        assert am.args['before'] == 'before'
        assert am.args['after'] == 'after'
    except Exception as e:
        raise e

# Generated at 2022-06-23 07:49:02.209018
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule()
    assert type(actionmodule) is ActionModule

# Generated at 2022-06-23 07:49:04.210510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:49:06.719458
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module

# Generated at 2022-06-23 07:49:12.679410
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.executor.process.connection import Connection
    import ansible.constants as C

    play_context = PlayContext()
    connection = Connection(play_context)

    play_context.network_os = 'ios'
    play_context.become = True
    play_context.become_method = 'enable'
    play_context.become_user = 'roxor'

    task = Task()
    task._role = None
    task.action = 'fetch'

# Generated at 2022-06-23 07:49:17.759469
# Unit test for constructor of class ActionModule
def test_ActionModule():
    conn = None
    am = ActionModule(conn, 'task', {}, '/path/to/basedir')
    assert am._task.action == 'task'
    assert am._task.args == {}
    assert am._loader.get_basedir() == '/path/to/basedir'

# Generated at 2022-06-23 07:49:29.120936
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackBase

    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.connection import Connection

    from argparse import Names

# Generated at 2022-06-23 07:49:36.230328
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def execute_remote_stat(cmd, task_vars=None, tmp=None):
        try:
            from ansible.module_utils.remote_management.netapp.eseries import open_url
            import yaml
            try:
                raw = open_url(cmd)
            except Exception as e:
                raise AnsibleActionSkip("Problem fetching info: %s" % e)

            # parse the yaml
            try:
                return yaml.safe_load(to_text(raw, errors='surrogate_or_replace'))
            except yaml.scanner.ScannerError as e:
                raise AnsibleActionFail("Problem parsing info: %s" % to_text(e))
        except Exception as e:
            return dict(exists=False)


# Generated at 2022-06-23 07:49:38.044548
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-23 07:49:39.257727
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()


# Generated at 2022-06-23 07:49:48.605335
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test for valid object creation
    module = ActionModule(
        task=dict(args=dict(src=None, dest=None)),
        connection=dict(),
        play_context=dict(become=False),
        loader=dict(),
        templar=None,
        shared_loader_obj=None)

    # test for invalid object creation
    try:
        module = ActionModule(
            task=dict(),
            connection=dict(),
            play_context=dict(),
            loader=dict(),
            templar=None,
            shared_loader_obj=None)
        raise Exception("ActionModule error: failed to raise ActionBaseError with empty arguments")
    except (AnsibleError, Exception) as e:
        pass

# Generated at 2022-06-23 07:49:54.716113
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule._create_action(dict(
        module_name='fetch',
        module_args=dict(src='/tmp/foo.txt', dest='/tmp/bar.txt', flat=True),
        task_vars=dict(inventory_hostname='host01'),
        connection='local'
    ), play_context=dict(remote_addr='localhost'))

    assert action.__class__.__name__ == 'ActionModule'

    assert action._task.args.get('src') == '/tmp/foo.txt'
    assert action._task.args.get('dest') == '/tmp/bar.txt'
    assert action._task.args.get('flat') is True
    assert action._play_context.remote_addr == 'localhost'

# Generated at 2022-06-23 07:49:55.882315
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:50:06.800794
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of ActionModule
    '''
    # mocks for _execute_module, _execute_remote_stat
    def _execute_module(self, *args, **kwargs):
        return dict(changed=True)

    def _execute_remote_stat(self, *args, **kwargs):
        return dict(exists=True, isdir=False)

    display.verbosity = 3
    module_args = dict(
        src='src',
        dest='dest'
    )

    task_vars = dict(
        inventory_hostname='localhost'
    )
    tmp = '/tmp'
    connection = ActionBase._shared_loader_obj.connection_loader.get('local')
    # set mocks
    connection._execute_module = _execute_module
    connection._execute_remote_

# Generated at 2022-06-23 07:50:11.885928
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: Pass in a mock object inplace of a connection object
    am = ActionModule('ansible.legacy.fetch.ActionModule', {}, None)
    try:
        am.run()
    except AnsibleActionFail as e:
        assert e
    except AnsibleActionSkip as e:
        assert e

# Generated at 2022-06-23 07:50:19.183087
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # TODO: mock a self._task.args, self._play_context and a task_vars
    # and test if expected results are returned. Also test if every method
    # of self._connection is called with the expected parameters
    pass


__all__ = ['ActionModule']

# Generated at 2022-06-23 07:50:19.761476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:50:29.163091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.fetch import ActionModule
    am = ActionModule()
    class Task:
        args = {}
    class PlayContext:
        def __init__(self):
            self.remote_addr = ''
            self.become = False
            self.become_method = 'sudo'
            self.become_user = None
            self.verbosity = 0
            self.check_mode = False
            self.diff = False
            self.no_log = False
    class Connection:
        def __init__(self):
            self.host = 'localhost'
            self.port = 22
            self.user = 'ansible'
            self.become_user = 'ansible_become_user'
            self.become_password = 'ansible_become_password'
            self.bec

# Generated at 2022-06-23 07:50:30.562239
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert type(module) == ActionModule

# Generated at 2022-06-23 07:50:39.061363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if os.name == 'nt':
        # Not valid in Windows
        return

    import tempfile, shutil, json

    my_vars = dict(inventory_hostname='fake_host')
    my_args = dict(dest='/tmp/fake_file', flat=True, fail_on_missing=True, validate_checksum=True)

    # Test for 'the remote file does not exist, not transferring, ignored' result
    my_result = dict(failed=False, msg='the remote file does not exist, not transferring, ignored', file='/does_not_exist', changed=False)

    fake_mod = tempfile.mkdtemp()
    fake_shell = os.path.join(fake_mod, 'ansible_shell_result.txt')

# Generated at 2022-06-23 07:50:48.652091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.connection import ConnectionError
    from ansible.module_utils.connection import ConnectorError
    from ansible.module_utils.network.common.ssl import CertificateError
    from ansible.module_utils.network.common.utils import dict_merge
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.plugins.action import ActionBase
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.path import makedirs_safe

# Generated at 2022-06-23 07:51:00.064369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import imp
    import ansible.parsing.dataloader
    import ansible.vars.manager
    import ansible.inventory.manager
    import ansible.playbook.play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.utils.display import Display

    display = Display()
    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.manager.VariableManager()
    inventory = ansible.inventory.manager.Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost,')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-23 07:51:09.199774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    ansible.plugins.action.fetch UnitTest
    '''
    from ansible.plugins.action import ActionModule
    from ansible.plugins.connection.local import Connection
    from ansible.plugins.loader import ModuleLoader
    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader

    args = dict(src='source/path', dest='destination/path', flat=False)

    cli = CLI(args)
    display.verbosity = 4
    connection = Connection(cli)
    loader = DataLoader()
    extras_vars = dict()
    module_loader = ModuleLoader()
    ActionModule(connection, loader, extras_vars, module_loader)

# Generated at 2022-06-23 07:51:21.542577
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Initialize.
    actionModule = ActionModule(
        (os.path.realpath(__file__)).strip('tests').strip('/') + '/ansible/plugins/action/fetch.py',
        dict(dest='/home/user/ansible/results/', src='file.txt', fail_on_missing=False),
        dict(playbook_dir='/home/user/ansible'))

    # Assert equal.

# Generated at 2022-06-23 07:51:31.640579
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.plugins import module_loader, action_loader

    pb = Play()
    pb.role = Role()
    h = Host(name="testhost")
    t = Task()
    t.action

# Generated at 2022-06-23 07:51:35.543207
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule(None, None)
    assert module.run(tmp=None, task_vars=None)


# Generated at 2022-06-23 07:51:45.557194
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.connection import ConnectionBase
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Test with valid arguments
    mock_connection = ConnectionBase(PlayContext())
    test_task = Task()
    test_task.args = dict(src='/test/test.txt', dest='test/test')
    test_task.action = 'fetch'
    test_task.delegate_to = 'testhost'
    test_

# Generated at 2022-06-23 07:51:57.647808
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()
            result = super(TestActionModule, self).run(tmp, task_vars)
            if os.path.exists("/tmp/acitest"):
                os.remove("/tmp/acitest")
            open("/tmp/acitest", 'a').close()
            return result

    testActionModule = TestActionModule(dict(action=dict(module_name="file", module_args=dict(path=to_bytes("/tmp/acitest", errors='surrogate_or_strict')))))
    testActionModule.run()
    testActionModule.cleanup()

# Generated at 2022-06-23 07:52:02.426188
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test ActionModule constructor")
    am = ActionModule(play=None, connection=None, new_stdin=None, loader=None, module_name=None, module_args=None, task_vars=None, tmp=None)
    assert am.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-23 07:52:06.885730
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = dict(name='Test', action='action_module', host='localhost', port=22, user='user', password='password')
    task = MockTask(args)
    connection = MockConnection(args)
    play_context = MockPlayContext(args)
    action_module = MockActionModule(task, connection, play_context)
    assert not action_module is None

# Generated at 2022-06-23 07:52:09.915380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('-------')
    print('Testing ActionModule.run')
    print('-------')
    # We can't test this yet.  This action module has not been fully implemented yet.

# Generated at 2022-06-23 07:52:15.962463
# Unit test for constructor of class ActionModule
def test_ActionModule():
    os.environ['ANSIBLE_ROLES_PATH'] = "/etc/ansible/roles"
    os.environ['ANSIBLE_LIBRARY'] = "/usr/share/ansible"
    var = { 'inventory_hostname': 'localhost' }
    modul = ActionModule()
    modul.run(task_vars=var)

# Generated at 2022-06-23 07:52:16.951632
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None

# Generated at 2022-06-23 07:52:22.948212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.VALID_ARGS == ['create', 'directory_mode', 'follow', 'mode', 'owner', 'regexp', 'remote_src', 'selevel', 'serole', 'setype', 'seuser', 'src']
    assert action_module.RUN_ON_LINUX == True

# Generated at 2022-06-23 07:52:33.725291
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test creating ActionModule
    """
    connection_info = dict()
    connection_info['host'] = 'localhost'
    connection_info['port'] = '1234'
    connection_info['user'] = 'ansible'
    connection_info['pass'] = 'ansible'

    test_args = dict()
    test_args['src'] = 'test_src'
    test_args['dest'] = 'test_dest'

    task_vars = dict()
    task_vars['ansible_ssh_host'] = 'localhost'
    task_vars['ansible_ssh_port'] = '1234'
    task_vars['ansible_ssh_user'] = 'ansible'
    task_vars['ansible_ssh_pass'] = 'ansible'

# Generated at 2022-06-23 07:52:34.979605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module = ActionModule()
    except Exception:
        pass

# Generated at 2022-06-23 07:52:39.250953
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(connection=None, play_context=None, loader=None, temper=None, shared_loader_obj=None)

# Generated at 2022-06-23 07:52:49.226059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task = Object()
    action_module._task.args = {'src': 'test.txt', 'dest':'test.txt', 'fail_on_missing':False, 'validate_checksum':True}
    action_module._play_context = Object()
    action_module._play_context.remote_addr = '127.0.0.1'
    action_module._loader = Object()
    action_module._loader.path_dwim = lambda x:x
    action_module._connection = Object()
    action_module._connection._shell = Object()
    action_module._connection._shell.tmpdir = '/tmp'
    action_module._connection._shell.join_path = lambda x, y:str(x) + str(y)
    action_module._connection

# Generated at 2022-06-23 07:52:58.580496
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This method tests run() method of class ActionModule
    """
    from ansible.plugins.action.copy import ActionModule as copy
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

# Generated at 2022-06-23 07:53:01.722111
# Unit test for constructor of class ActionModule
def test_ActionModule():
    source = '/var/log/messages'
    dest = '/tmp/logs'
    flat = False
    act = ActionModule(source, dest, flat)
    assert act is not None


# Generated at 2022-06-23 07:53:17.197674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task=dict(args=dict(src='/etc/hosts', dest='/tmp/file', flat=True)),
        connection=dict(tmp='/tmp', host='localhost'),
        play_context=dict(remote_addr='localhost')
    )
    assert module.run() == {
        'changed': False,
        'checksum': '54c1e91eec6373c1e2d37f98c02d7caa',
        'md5sum': '50f9cd7f0b4c8b8e2479f4d4b43e47a1',
        'dest': '/tmp/hosts',
        'remote_md5sum': None,
        'remote_checksum': None,
        'file': '/etc/hosts'
    }


# Generated at 2022-06-23 07:53:20.641683
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None)
    assert type(action) == ActionModule

# Generated at 2022-06-23 07:53:31.265858
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, {})
    assert isinstance(action, ActionModule)

    action = ActionModule("play1","play1-host",{'hostvars':{'play1-host':{'ansible_port':22, 'ansible_host':'test_host'}}, 'callback':None})
    assert isinstance(action, ActionModule)
    assert action.name == 'play1'
    assert action.host == 'play1-host'
    assert action.task_vars == {'hostvars':{'play1-host':{'ansible_port':22, 'ansible_host':'test_host'}}, 'callback':None}

# Generated at 2022-06-23 07:53:42.665112
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup unit test
    arguments = dict(
        src = 'foo/bar/baz'
    )
    task_vars = dict(
        inventory_hostname = 'local'
    )
    tmp=None
    result = dict(
        file = 'foo/bar/baz'
    )

    # Instantiate the action plugin
    action_plugin = ActionModule()
    action_plugin._task = dict()
    action_plugin._task.args = dict()

    # Run unit test
    result = action_plugin.run(tmp, task_vars)

    # Verify results
    assert result['changed'] == True
    assert result['dest'] == '/home/foo/bar/baz'

    # Verify setup
    assert tmp is None
    assert type(task_vars) is dict

# Generated at 2022-06-23 07:53:49.246234
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    print("Calling ActionModule.run()")

    # Create a task that executes the module fetch
    task = Task("fetch")

    # Create a module argument dictionary
    module_args = {
            'src': '/etc/resolv.conf',
            'dest': '/tmp',
            'flat': 'yes'
    }

    # Create a module that executes the copy module
    module = ActionModule(task, module_args)

    # Create a valid connection to the local system
    connection = Connection("local")

    # Execute the run method on the module
    result = module.run(connection=connection)

    # Display the result
    print("Result: %s" % result)

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-23 07:53:59.471104
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This is invoked by the test script (e.g. for test/runner/action_plugin/fetch.yml)
    # It basically invokes the run method to test if it works.
    # The script creates and passes the objects below, so this code is a simplified version
    # of how Ansible invokes the run method.
    # You can run the test like this: ansible-playbook -i inventory --connection=local test/integration/targets/action_plugin/fetch.yml
    # You can run this particular test's debug like this: ansible-playbook -i inventory --connection=local -vvvv test/integration/targets/action_plugin/fetch.yml

    # Modules needed for test
    from ansible.module_utils.six import PY2

    # Objects passed from the test script
   

# Generated at 2022-06-23 07:54:09.074664
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # create mock object
    mock_task = MagicMock()
    mock_task.async_val=2

    mock_play_context = MagicMock()
    mock_play_context.check_mode = False
    mock_play_context.become = False
    mock_play_context.become_user = None
    mock_play_context.remote_addr = "1.2.3.4"
    mock_play_context.connection = "ssh"

    # create instance of ActionModule and call method run
    action_module = ActionModule(mock_task, mock_play_context)
    action_module.run(tmp=None, task_vars=None)

# Generated at 2022-06-23 07:54:11.286999
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:54:19.202587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    spec = dict(
        src=dict(type='path'),
        dest=dict(type='path'),
        flat=dict(type='bool', default=False),
        validate_checksum=dict(type='bool', default=True),
        fail_on_missing=dict(type='bool', default=True),
    )

    # Create a temporary directory to store the temporary files that are created during the tests.
    import pytest
    tmpdir = pytest.ensuretemp("test_ActionModule_run")
    fake_loader = DictDataLoader({tmpdir: {}})
    inventory = InventoryManager(loader=fake_loader, sources='localhost,')
    variable_manager = VariableManager(loader=fake_loader, inventory=inventory)

# Generated at 2022-06-23 07:54:29.926324
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    class TestActionModule(unittest.TestCase):

        def setUp(self):
            self._task = MagicMock(name='task', args={})
            self._connection = MagicMock(name='connection', become=True, become_user=None, become_method=None, become_exe=None)
            self._play_context = MagicMock(name='play_context', check_mode=False)
            self._loader = MagicMock(name='loader')
            self._tmp_path = MagicMock(name='tmp_path')
            self._shared_loader_obj = None

# Generated at 2022-06-23 07:54:31.586852
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run()

# Generated at 2022-06-23 07:54:34.326602
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action import ActionModule
    from ansible.errors import AnsibleError, AnsibleActionFail, AnsibleActionSkip

    assert(True)
    return True

# Generated at 2022-06-23 07:54:37.689306
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(), connection='', play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

# Generated at 2022-06-23 07:54:42.549183
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    display.display("Test ActionModule.run")

# Generated at 2022-06-23 07:54:43.253944
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None)
    assert a != None

# Generated at 2022-06-23 07:54:50.327269
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.connection import ConnectionBase
    from ansible.plugins.strategy.linear import StrategyModule

    connection = ConnectionBase(None, None)
    strategy = StrategyModule(None)
    task_vars = dict()
    display = Display()
    play_context = PlayContext(play=None,options=None,variables={})

    tmp = None

# Generated at 2022-06-23 07:55:00.191299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.fetch import ActionModule
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.connection.local import Connection
    from ansible.inventory.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    import os
    import tempfile
    import shutil

    tmp_dir = tempfile.mkdtemp()
    open(os.path.join(tmp_dir, "dummy"), "w+")
    open(os.path.join(tmp_dir, "dummy2"), "w+")

# Generated at 2022-06-23 07:55:02.313589
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule(None, None)
  assert isinstance(am,ActionModule)
  assert hasattr(am, "run")


# Generated at 2022-06-23 07:55:06.660180
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    module = module.run()
    assert module is not None

# Generated at 2022-06-23 07:55:07.671432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('running test_ActionModule_run')
    # TODO


# Generated at 2022-06-23 07:55:09.696915
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins import action

    am = action.ActionModule(None, None, None, None, None)

    assert am is not None


# Generated at 2022-06-23 07:55:11.154063
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Unit tests for methods of class ActionModule

# Generated at 2022-06-23 07:55:21.924176
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.plugins.loader import connection_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost', 'otherhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    connection = connection_loader.get('local', play_context, loader=loader, variable_manager=variable_manager)
    tqm = None
    host = Host(name='localhost')
   

# Generated at 2022-06-23 07:55:34.199678
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.fetch import ActionModule
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    # Arguments
    tmp = None
    task_vars = {}
    source = "source_file"
    dest = "dest_file"
    flat = True
    fail_on_missing = True
    validate_checksum = True

    # Mock objects
    # task mock object

# Generated at 2022-06-23 07:55:39.749079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test setup
    to_bytes = lambda x: x.encode('utf-8')
    to_text = lambda x: x.decode('utf-8')
    mock = __import__('mock')
    action_module_class = __import__('ansible.plugins.action.fetch').action.fetch.ActionModule
    tmp_b = '/tmp/test_fetch'
    remote_stat_return = {'exists': True, 'isdir': False}
    # test data
    task_vars_data = {'ansible_facts': {'ansible_distribution': 'Gentoo'}}
    # test setup
    tmp = mock.MagicMock(name='tmp', spec=tmp_b, autospec=True)

# Generated at 2022-06-23 07:55:51.241795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins import ActionBase

    # Setup a dummy play
    play_context = PlayContext()
    play_context.connection = 'local'
    play_context.remote_addr = '127.0.0.1'

    # Setup a dummy task

# Generated at 2022-06-23 07:55:51.946856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 07:55:53.864799
# Unit test for constructor of class ActionModule
def test_ActionModule():
    
    a = ActionModule()
    assert a.__class__.__name__ == 'ActionModule'


# Generated at 2022-06-23 07:56:01.908999
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    s = '''
"foo":
  fetch:
    src: foo.txt
    dest: /home/myuser/playbooks
    validate_checksum: no
"bar":
  fetch:
    src: bar.txt
    dest: /home/myuser/playbooks

'''

    import sys
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import become_loader, module_loader
    from ansible.plugins.loader import connection_loader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    variable_manager

# Generated at 2022-06-23 07:56:13.597842
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import mock
    import ansible.playbook.play_context
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.inventory.manager
    import ansible.vars.manager

    class Host(ansible.inventory.host.Host):
        def __init__(self, name):
            self.name = name
            self.groups = []

    class Group(ansible.inventory.group.Group):
        def __init__(self, name):
            self.name = name
            self.hosts = {}

    class Inventory(ansible.inventory.manager.InventoryManager):
        def __init__(self):
            self.hosts = {}


# Generated at 2022-06-23 07:56:21.354146
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    p = PlayContext()
    t = Task()
    q = TaskQueueManager(p, None, None)
    i = InventoryManager(loader=DataLoader(), sources='')
    v = VariableManager(loader=DataLoader(), inventory=i)

    a = ActionModule(t, q, i, v)
    assert a is not None

# Generated at 2022-06-23 07:56:22.765890
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Can't test this, because it depends on remote
    pass

# Generated at 2022-06-23 07:56:33.715538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule({"url_username": "admin", "url_password": "cisco", "url": "http://172.16.0.1/restconf/config/ietf-interfaces:interfaces/interface=GigabitEthernet1"}, Display())
    assert am.name == "uri"
    assert am.args == {"force": False, "url": "http://172.16.0.1/restconf/config/ietf-interfaces:interfaces/interface=GigabitEthernet1", "backup": False, "url_username": "admin", "url_password": "cisco"}
    assert am.action == "get"
    assert am._task.args == am.args
    assert am.task_vars == {}
    assert type(am.play_context) == type

# Generated at 2022-06-23 07:56:42.558328
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Dummy result to return
    result = {
            'foo': 'bar',
            'ansible_facts': {
                'file_facts': {},
                '_ansible_no_log': True
            },
            'msg': 'All files were fetched successfully.'
        }

    # Dummy task to pass to method run
    task = {
        'args': {
            'dest': '/home/test/test_module',
            'validate_checksum': True,
            'fail_on_missing': False,
            'flat': True,
            'src': 'test_module'
        }
    }

    # Dummy task_vars to pass to method run

# Generated at 2022-06-23 07:56:52.299609
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    task = dict()

    task['dest'] = '.'
    task['src'] = 'foo.txt'

    source = 'foo.txt'
    dest = '.'

    # create a test ActionModule
    am = ActionModule(task=task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # create a test connection
    class FakeConnection():

        @staticmethod
        def fetch_file(source=None, destination=None):
            destination = source

        @staticmethod
        def _shell():

            return _shell

        @staticmethod
        def become():
            if os.name != 'nt':
                return False
            else:
                return True


# Generated at 2022-06-23 07:56:57.675909
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import io
    import tempfile
    import shutil
    from ansible.plugins.action import ActionModule
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.utils.vars import combine_vars

    class FetchingConnection(object):
        def __init__(self, tmpdir, become=False):
            self.tmpdir = tmpdir
            self.bec

# Generated at 2022-06-23 07:57:08.234226
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_loader = 'mock_loader'
    mock_templar = 'mock_templar'
    mock_shared_loader_obj = 'mock_shared_loader_obj'
    mock_action_base = 'mock_action_base'
    mock_play_context = 'mock_play_context'
    mock_connection = 'mock_connection'

    ActionModule(
        loader=mock_loader,
        templar=mock_templar,
        shared_loader_obj=mock_shared_loader_obj,
        action_plugin=mock_action_base,
        play_context=mock_play_context,
        connection=mock_connection,
        task=mock_action_base
    )

# Generated at 2022-06-23 07:57:08.878760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:57:20.237165
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.fetch as fetch
    import ansible.parsing.dataloader as dataloader
    import ansible.playbook.play as play

    loader = dataloader.DataLoader()
    variable_manager = play.VariableManager()

    class PlayContext(object):
        def __init__(self):
            self.connection = 'local'
            self.remote_addr = '127.0.0.1'
            self.remote_user = 'test'
            self.port = 22
            self.become = False
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.become_pass = '123'
            self.passwords = dict(conn_pass='123', become_pass='123')
            self.check_

# Generated at 2022-06-23 07:57:20.742637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 07:57:32.333039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    conn = Connection('http://localhost')
    act = ActionModule(conn,{}, '','/tmp','')
    assert act.run() == {'failed': True, 'msg': 'src and dest are required'}
    
    conn._shell.join_path = lambda x, y: str(x)+'\\'+str(y)
    conn._shell._unquote = lambda x: x.replace('\\', '/')
    act = ActionModule(conn,{}, '','/tmp','')
    assert act.run(task_vars={'a':'xxx', 'b':'yyy'}) == {'failed': True, 'msg': 'src and dest are required'}
    
    conn = Connection('http://localhost')
    conn._shell.join_path = lambda x, y: str(x)+'\\'+str