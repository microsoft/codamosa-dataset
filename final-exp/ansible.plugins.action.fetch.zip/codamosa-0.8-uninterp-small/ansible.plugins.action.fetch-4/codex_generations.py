

# Generated at 2022-06-25 06:47:30.097394
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 429
    str_0 = '$&*}upL'
    bool_0 = True
    float_0 = -369.54
    bool_1 = False

    # call the constructor
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_0, str_0, bool_1)

if __name__ == '__main__':
    print("Running tests...")
    print("Unit test of constructor")
    test_ActionModule()
    print("Successful test")

# Generated at 2022-06-25 06:47:37.045457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input parameters
    int_0 = 28
    str_0 = "mFsB%c"
    bool_0 = True
    float_0 = -9.83
    float_1 = -282.34
    str_1 = ";jDtR"
    bool_1 = True
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_1, bool_1)

    dict_0 = dict()
    dict_0['0'] = int_0
    dict_0['1'] = float_1
    dict_0['2'] = str_0
    dict_0['3'] = float_0
    dict_0['4'] = float_0
    dict_0['5'] = float_0
    dict_0['6'] = float_0


# Generated at 2022-06-25 06:47:45.073716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        # Setup
        int_0 = 429
        str_0 = '$&*}upL'
        bool_0 = True
        float_0 = -369.54
        bool_1 = False
        action_module_0 = ActionModule(str_0, bool_0, float_0, float_0, str_0, bool_1)
        tmp = None
        task_vars = None

        # Testing
        action_module_0.run(tmp, task_vars)

        # Teardown
    except Exception as e:
        pass

# Generated at 2022-06-25 06:47:55.212665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 27
    str_0 = 'U6'
    bool_0 = True
    float_0 = 8.83
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_0, str_0, bool_1)
    tmp_0 = None
    task_vars_0 = None
    result = action_module_0.run(tmp_0, task_vars_0)
    str_1 = 'tmp'
    str_2 = 'task_vars'
    int_1 = 7
    int_2 = -9
    str_3 = 'the remote file does not exist, not transferring, ignored'
    str_4 = 'changed'
    str_5 = 'remote file is a directory, fetch cannot work on directories'
   

# Generated at 2022-06-25 06:47:56.436827
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test the following call
    # result = action_module_0.run(tmp, task_vars)
    pass


# Generated at 2022-06-25 06:47:57.698630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Call test_constructor_0
    test_case_0()


# Generated at 2022-06-25 06:48:00.803380
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 06:48:10.431549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 429
    str_0 = '$&*}upL'
    bool_0 = True
    float_0 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_0, str_0, bool_1)
    action_module_0._execute_module = MagicMock(name='_execute_module')
    action_module_0._connection._shell.join_path = MagicMock(name='_connection._shell.join_path')
    action_module_0._connection._shell.join_path.return_value = 'join_path'
    action_module_0._remote_expand_user = MagicMock(name='_remote_expand_user')
    action_module_0._remote_expand

# Generated at 2022-06-25 06:48:11.972912
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 06:48:18.771697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We need a tmp directory for the remote server to save the file
    int_0 = 429
    str_0 = '$&*}upL'
    bool_0 = True
    float_0 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_0, str_0, bool_1)
    tmp = None
    task_vars = dict()
    test_case_0()
    test_case_0()
    test_case_0()

    # Call method run of class ActionModule and check the returned result
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:48:38.004824
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
# vim: set noet ts=4 sw=4 ft=python :

# Generated at 2022-06-25 06:48:45.609654
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 429
    str_0 = '$&*}upL'
    bool_0 = True
    float_1 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)
    action_module_1 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)
    action_module_1 = ActionModule(dict_0, dict_0, int_0, action_module_0, action_module_0, dict_0)

# Generated at 2022-06-25 06:48:57.160917
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # number of calls
    var_0 = 1
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 429
    str_0 = '$&*}upL'
    bool_0 = True
    float_1 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)
    action_module_1 = ActionModule(dict_0, dict_0, int_0, action_module_0, action_module_0, dict_0)
    var_1 = action_module_1.run()
    assert var_0 == 1


# Generated at 2022-06-25 06:49:05.529762
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six import StringIO
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import combine_vars
    from ansible.utils.unicode import to_bytes
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0}
    str_0 = '$&*}upL'
    bool_0 = True
    str_1 = '3qw6U%0'
    float_1 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)

# Generated at 2022-06-25 06:49:15.682976
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 429
    str_0 = '$&*}upL'
    bool_0 = True
    float_1 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)
    assert isinstance(action_module_0._task, Task)
    assert isinstance(action_module_0._play_context, PlayContext)
    assert isinstance(action_module_0._loader, DataLoader)
    assert isinstance(action_module_0._templar, Templar)

# Generated at 2022-06-25 06:49:16.771825
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:49:22.776485
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 429
    str_0 = '$&*}upL'
    bool_0 = True
    float_1 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)
    action_module_1 = ActionModule(dict_0, dict_0, int_0, action_module_0, action_module_0, dict_0)

# Generated at 2022-06-25 06:49:33.989736
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 429
    str_0 = '$&*}upL'
    bool_0 = True
    float_1 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)
    action_module_1 = ActionModule(dict_0, dict_0, int_0, action_module_0, action_module_0, dict_0)
    var_0 = action_module_1.run()
    if var_0:
        print('test_ActionModule_run executed correctly')
    else:
        print('Test failed. Incorrect value returned')

# Generated at 2022-06-25 06:49:41.324120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 429
    str_0 = '$&*}upL'
    bool_0 = True
    float_1 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)
    action_module_1 = ActionModule(dict_0, dict_0, int_0, action_module_0, action_module_0, dict_0)
    if True:
        var_0 = action_module_1.run()
    else:
        var_0 = action_module_1.run()


# Generated at 2022-06-25 06:49:46.721996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 429
    str_0 = '$&*}upL'
    bool_0 = True
    float_1 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)
    action_module_1 = ActionModule(dict_0, dict_0, int_0, action_module_0, action_module_0, dict_0)
    var_0 = action_module_1.run()

# Generated at 2022-06-25 06:50:30.620330
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -67.41
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 429
    str_0 = '$&*}upL'
    bool_0 = True
    float_1 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)
    action_module_1 = ActionModule(dict_0, dict_0, int_0, action_module_0, action_module_0, dict_0)



# Generated at 2022-06-25 06:50:39.051353
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 429
    str_0 = '$&*}upL'
    bool_0 = True
    float_1 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)
    action_module_1 = ActionModule(dict_0, dict_0, int_0, action_module_0, action_module_0, dict_0)
    # unit test for ActionModule.run()
    var_0 = action_module_1.run()


test_case_0()
#test_ActionModule()

# Generated at 2022-06-25 06:50:48.329661
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:50:55.389915
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '>0bR}&'
    bool_0 = True
    float_0 = -3.68
    float_1 = -899.76
    str_1 = '^,Q*k[C'
    bool_1 = True
    dict_0 = {str_1: bool_0, float_0: str_0, str_0: str_0, str_0: float_1, float_1: bool_0, float_0: str_1}
    dict_1 = {float_1: dict_0, float_1: float_0, float_1: float_1, float_1: float_1, float_1: float_1}
    int_0 = 918

# Generated at 2022-06-25 06:51:02.260036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 412
    str_0 = '$^0ogh=4'
    float_0 = 469.68
    action_module_0 = ActionModule(int_0, str_0, float_0, str_0, str_0, str_0)
    action_module_0.run()


# Generated at 2022-06-25 06:51:11.604451
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 429
    str_0 = '$&*}upL'
    bool_0 = True
    float_1 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)
    action_module_1 = ActionModule(dict_0, dict_0, int_0, action_module_0, action_module_0, dict_0)
    var_0 = action_module_1.run()
    del action_module_1
    assert str_0 in var_0
    del bool_1
    del action_module_0
    del int_

# Generated at 2022-06-25 06:51:13.053586
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == None

# Unit tests for class AnsibleActionSkip

# Generated at 2022-06-25 06:51:22.698552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 429
    str_0 = '$&*}upL'
    bool_0 = True
    float_1 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)
    action_module_1 = ActionModule(dict_0, dict_0, int_0, action_module_0, action_module_0, dict_0)
    var_0 = action_module_1.run()

if __name__ == '__main__':
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 06:51:29.086202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -0.10
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 429
    str_0 = '&@P'
    bool_0 = True
    float_1 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)
    action_module_1 = ActionModule(dict_0, dict_0, int_0, action_module_0, action_module_0, dict_0)
    var_0 = action_module_1.run()

test_ActionModule_run()
test_case_0()

# Generated at 2022-06-25 06:51:40.480259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -703.6
    dict_0 = {}
    int_0 = -549
    str_0 = 'yA3'
    bool_0 = True
    dict_1 = {int_0: dict_0, int_0: str_0, int_0: dict_0}
    float_1 = -187.22
    str_1 = '{|}l'
    dict_2 = {}
    dict_3 = {str_1: dict_1, str_1: dict_2, str_1: dict_1, str_1: dict_1}
    action_module_0 = ActionModule(dict_0, dict_3, dict_1, dict_0, dict_0, dict_3, dict_3)

# Generated at 2022-06-25 06:52:50.715659
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 06:52:59.999958
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 827
    str_0 = '\x1c'
    bool_0 = True
    float_1 = -730.45
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)
    action_module_1 = ActionModule(dict_0, dict_0, int_0, action_module_0, action_module_0, dict_0)

# Generated at 2022-06-25 06:53:06.528435
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 429
    str_0 = '$&*}upL'
    bool_0 = True
    float_1 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)
    action_module_1 = ActionModule(dict_0, dict_0, int_0, action_module_0, action_module_0, dict_0)
    var_0 = action_module_1.run()
    check_0 = var_0
    assert type(check_0) == dict
    assert check_0 == {'failed': False}


# Generated at 2022-06-25 06:53:15.079971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 429
    str_0 = '$&*}upL'
    bool_0 = True
    float_1 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)
    action_module_1 = ActionModule(dict_0, dict_0, int_0, action_module_0, action_module_0, dict_0)
    var_0 = action_module_1.run()


# Generated at 2022-06-25 06:53:26.092007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 429
    str_0 = '$&*}upL'
    bool_0 = True
    float_1 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)
    action_module_1 = ActionModule(dict_0, dict_0, int_0, action_module_0, action_module_0, dict_0)
    var_0 = action_module_1.run()

if __name__ == '__main__':
    try:
        test_case_0()
    except AnsibleActionSkip as e:
        raise

# Generated at 2022-06-25 06:53:32.885089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # noinspection PyUnusedLocal
    def test_inner(self, tmp, task_vars):
        # TODO: Implement unit test for method run of class ActionModule
        pass
    ActionModule.run = test_inner



# Generated at 2022-06-25 06:53:41.484677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 429
    str_0 = '$&*}upL'
    bool_0 = True
    float_1 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)
    action_module_1 = ActionModule(dict_0, dict_0, int_0, action_module_0, action_module_0, dict_0)
    action_module_3 = action_module_1.run()



# Generated at 2022-06-25 06:53:43.028855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        actionmodule_run_0()
    except Exception:
        print('An exception is raised')
        raise


# Generated at 2022-06-25 06:53:51.295392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 429
    str_0 = '$&*}upL'
    bool_0 = True
    float_1 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)
    action_module_1 = ActionModule(dict_0, dict_0, int_0, action_module_0, action_module_0, dict_0)
    var_0 = action_module_1.run()



# Generated at 2022-06-25 06:53:55.325853
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = None
    dict_0 = {float_0: float_0, float_0: float_0}
    int_0 = 429
    str_0 = '$&*}upL'
    bool_0 = True
    float_1 = -369.54
    bool_1 = False
    action_module_0 = ActionModule(str_0, bool_0, float_0, float_1, str_0, bool_1)