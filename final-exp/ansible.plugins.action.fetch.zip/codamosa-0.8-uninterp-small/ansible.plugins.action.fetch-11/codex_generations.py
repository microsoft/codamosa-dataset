

# Generated at 2022-06-25 06:47:23.806362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'gf>Z=\x1fS`'
    int_0 = 0
    str_1 = '{1`%'
    str_2 = 'Z$l=w'
    str_3 = '9X'
    str_4 = ';b'
    str_5 = 'Pf'
    str_6 = 'LH'
    str_7 = '0c'
    str_8 = 'N'


# Generated at 2022-06-25 06:47:34.122508
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:47:41.918000
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        ansible.module_utils.six.moves.queue.Queue()
    except NameError:
        ansible.module_utils.six.moves.queue = ansible.utils.unsafe_proxy.UnsafeProxy('ansible.module_utils.six.moves.queue')
    try:
        ansible.module_utils.six.moves.copyreg.copy_reg()
    except NameError:
        ansible.module_utils.six.moves.copyreg = ansible.utils.unsafe_proxy.UnsafeProxy('ansible.module_utils.six.moves.copyreg')
    try:
        ansible.module_utils.six.moves._thread.allocate_lock()
    except NameError:
        ansible.module_utils.six.moves._thread = ansible.utils

# Generated at 2022-06-25 06:47:46.171217
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test action module
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()



# Generated at 2022-06-25 06:47:48.264433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('\tUnit test ActionModule constructor')
    obj_0 = ActionModule()


# Generated at 2022-06-25 06:47:52.332715
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  tmp = None
  task_vars = None
  tmp = None
  task_vars = None
  tmp = None
  task_vars = None
  tmp = None
  task_vars = None
  tmp = None
  task_vars = None
  tmp = None
  task_vars = None
  tmp = None
  task_vars = None
  tmp = None
  task_vars = None
  tmp = None
  task_vars = None
  tmp = None
  task_vars = None
  tmp = None
  task_vars = None
  tmp = None
  tas

# Generated at 2022-06-25 06:47:59.955962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_0 = {'fail_on_missing': False, 'validate_checksum': False, 'flat': False, 'dest': False, 'src': 'string'}
    tmp_0 = None
    task_vars_0 = {'integer': 'integer', 'boolean': True, 'none': None, 'string': 'string', '@CO{GA&b\\Diy+fv\x0cE]': '@CO{GA&b\\Diy+fv\x0cE]'}

# Generated at 2022-06-25 06:48:09.955492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case for instance variable dest of class ActionModule
    str_0 = '&X3tq@D'
    dict_0 = {str_0: str_0}
    str_1 = 'Vh9yq+vk\x0cw'
    set_0 = {dict_0, dict_0, str_1}
    ActionModule_0 = ActionModule()
    ActionModule_0.dest = dict_0
    # Test case for instance variable source of class ActionModule
    str_2 = '/<lAm72'
    dict_1 = {str_2: str_2}
    str_3 = 'Gm8^.R&kcp'
    set_1 = {dict_1, dict_1, str_3}
    ActionModule_1 = ActionModule()

# Generated at 2022-06-25 06:48:11.018145
# Unit test for constructor of class ActionModule
def test_ActionModule():
  ActionModule()


# Generated at 2022-06-25 06:48:11.795073
# Unit test for constructor of class ActionModule
def test_ActionModule():
    c = ActionModule()


# Generated at 2022-06-25 06:48:31.896304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    action_module = ActionModule()


# Generated at 2022-06-25 06:48:35.673152
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:48:37.474852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:48:43.309276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with pytest.raises(AnsibleActionFail) as exception_info:
        test_case_0()
    assert str(exception_info) == 'AnsibleActionFail'

# Generated at 2022-06-25 06:48:51.024803
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This tests just the constructor of class ActionModule.
    # Don't add tests specific to your plugin.
    action_module_0 = ActionModule()
    action_module_1 = ActionModule()
    assert(action_module_0.__class__ == ActionModule)
    assert(action_module_0.__class__ == action_module_1.__class__)
    this_file = os.path.abspath(__file__)
    if 'module_utils' in this_file:
        this_file = this_file.replace('module_utils', 'modules')
    if 'module_utils' in this_file:
        this_file = this_file.replace('module_utils', 'modules')

# Generated at 2022-06-25 06:48:54.895137
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module = ActionModule()
    except Exception as e:
        print("Exception in constructor of class ActionModule:",e)
        assert False
    assert True


# Generated at 2022-06-25 06:48:57.291216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run(tmp=None, task_vars=None)

# Generated at 2022-06-25 06:49:00.847542
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    tmp = None
    task_vars = {'test_variable': 'test_value'}
    expected = {}
    actual = action_module.run(tmp, task_vars)
    assert expected == actual

test_case_0()

# Generated at 2022-06-25 06:49:09.947142
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # We won't call __init__() method in this test

    # Dummy tests for class methods
    action_module_1 = ActionModule()
    action_module_1.run(tmp=None, task_vars=None)
    action_module_1.run(tmp=None, task_vars=None)
    action_module_1.run(tmp=None, task_vars=None)
    action_module_1.run(tmp=None, task_vars=None)
    action_module_1.run(tmp=None, task_vars=None)
    action_module_1.run(tmp=None, task_vars=None)

# Generated at 2022-06-25 06:49:12.345946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = "/tmp"
    task_vars_0 = dict()
    result_0 = action_module_0.run(tmp=tmp_0, task_vars=task_vars_0)
    assert result_0 == dict(changed=False)

# Generated at 2022-06-25 06:49:48.955200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# vim: set et ts=4 sw=4 : See Vim, :help 'modeline'

# Generated at 2022-06-25 06:50:00.685180
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_play_context = mock(PlayContext)
    mock_play_context.connection = 'smart'
    mock_play_context.remote_user = 'me'
    mock_play_context.remote_addr = 'localhost'
    mock_play_context.become = False
    mock_play_context.become_method = 'sudo'
    mock_play_context.become_user = 'root'

    mock_module_name = 'fetch'
    mock_module_args = dict(
        src = 'somefile.txt'
        )

    mock_loader = mock(DataLoader)
    mock_tmp_path = '/tmp/fetch'
    mock_task_vars = dict()


# Generated at 2022-06-25 06:50:02.089861
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()



# Generated at 2022-06-25 06:50:09.856061
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    print("TestCase 0")
    # construct object of the class
    action_module_0 = ActionModule()

    # set class member variables
    action_module_0._play_context = None
    action_module_0._task = None

    # test the method with invalid parameters
    result = action_module_0.run("tmp", "task_vars")

    # verify the result
    assert result == ('changed', 'failed', 'file', 'msg', 'remote_md5sum', 'remote_stat'), "The result is invalid"

# Generated at 2022-06-25 06:50:16.917358
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    tmp = None
    task_vars = dict()
    result = dict()
    setattr(action_module._play_context, 'check_mode', True)
    result = action_module.run(tmp, task_vars)
    assert 'msg' in result
    assert result['msg'] == 'check mode not (yet) supported for this module'
    assert result['skipped'] == True
    assert result['changed'] == False
    assert result['failed'] == False
    assert result['skip_reason'] == 'check mode not (yet) supported for this module'

    result = dict()
    setattr(action_module._play_context, 'check_mode', False)
    result = action_module.run(tmp, task_vars)
    assert 'msg' in result

# Generated at 2022-06-25 06:50:20.435895
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test if class initialized properly
    action_module = ActionModule()
    assert isinstance(action_module, object)

# Generated at 2022-06-25 06:50:24.408872
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:50:26.472513
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    x = ActionModule()
    x.run()


# Generated at 2022-06-25 06:50:27.957169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:50:29.177729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module != None



# Generated at 2022-06-25 06:51:14.185389
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Get the values of all the variables declared in the class
    bytes_0 = b'M`Y\xdc\xd5zF&\x8e\xc0\x86dr'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    int_0 = -1214
    dict_0 = {}
    float_0 = 1.0
    action_module_0 = ActionModule(set_0, int_0, int_0, dict_0, dict_0, float_0)
    # Set the values for the variables declared in the class
    action_module_0.action_name = 'fetch'
    action_module_0.action_exec_id = '\x13\xa6\x15\x8c'

# Generated at 2022-06-25 06:51:23.631452
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = {b'\x15\xf9\x9f\x0e\x84\x01\xcd\x8e\xc5\x10\x1d\x9b\x8e\xec', b'5\x0e\xb3\xec+\x0b\xa3\xd9\xe4,\xeb', b'G\xbe\x8b\xdd\xf0\xed\x9a\xfc\x11\x1e\x07\xab'}
    int_0 = -2533
    int_1 = -4355
    dict_0 = {}
    dict_1 = {}
    float_0 = 1.0

# Generated at 2022-06-25 06:51:28.102584
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:51:29.719373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    dict_0 = dict()
    var_0 = action_module_0.run(dict_0)

# Generated at 2022-06-25 06:51:40.562035
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'M`Y\xdc\xd5zF&\x8e\xc0\x86dr'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    int_0 = -1214
    dict_0 = {}
    float_0 = 1.0
    action_module_0 = ActionModule(set_0, int_0, int_0, dict_0, dict_0, float_0)

# Generated at 2022-06-25 06:51:46.594597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_cases = [test_case_0, test_case_0, test_case_0, test_case_0, test_case_0, test_case_0, test_case_0]
    for test_case in test_cases:
        try:
            test_case()
        except:
            print("Error running test case: " + test_case.__name__)

# Generated at 2022-06-25 06:51:47.908720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.action_run()

# Generated at 2022-06-25 06:51:54.857499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'M`Y\xdc\xd5zF&\x8e\xc0\x86dr'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    int_0 = -1214
    dict_0 = {}
    float_0 = 1.0
    action_module_0 = ActionModule(set_0, int_0, int_0, dict_0, dict_0, float_0)
    str_0 = 'AnsibleError'
    try:
        action_run()
    except AnsibleError as ansible_error_0:
        str_1 = ansible_error_0.__class__.__name__
        assert str_1 == str_0

# Generated at 2022-06-25 06:51:59.894034
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_0 = -2046
    dict_0 = {}
    str_0 = 'Test'
    float_0 = -486473.13
    action_module_0 = ActionModule(set_0, int_0, int_0, dict_0, dict_0, float_0)
    var_0 = action_module_0.run(str_0)
    assert var_0 == None

# Generated at 2022-06-25 06:52:03.459399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module_0.__class__.__name__ == 'ActionModule'


# Generated at 2022-06-25 06:53:20.261064
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\f\x16\x0f\x08'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    int_0 = -1214
    dict_0 = {}
    float_0 = 1.0
    action_module_0 = ActionModule(set_0, int_0, int_0, dict_0, dict_0, float_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:53:23.613753
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 06:53:30.044519
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {'', '', '', ''}
    int_0 = -1214
    int_1 = -1214
    dict_0 = {}
    dict_1 = {}
    float_0 = 1.0
    action_module_0 = ActionModule(set_0, int_0, int_1, dict_0, dict_1, float_0)
    action_module_0.tmp = None
    action_module_0.task_vars = None
    var_0 = action_module_0.run(None, None)
    if var_0 is None:
        print("var_0 is None")
    else:
        print("var_0 is not None")

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:53:36.065905
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'M`Y\xdc\xd5zF&\x8e\xc0\x86dr'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    int_0 = -1214
    dict_0 = {}
    float_0 = 1.0
    action_module_0 = ActionModule(set_0, int_0, int_0, dict_0, dict_0, float_0)


# Generated at 2022-06-25 06:53:42.329142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xc5\xfb\xe5\xdc\x19<\xa4\xa7\xfd\xe9\x1e\x10\x90T'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    int_0 = -1713
    int_1 = -2350
    dict_0 = {}
    dict_1 = {}
    float_0 = 1.0
    action_module_0 = ActionModule(set_0, int_0, int_1, dict_0, dict_1, float_0)
    action_module_0.run()

# Generated at 2022-06-25 06:53:43.095582
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:53:44.055445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-25 06:53:45.938875
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:53:53.839266
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'M`Y\xdc\xd5zF&\x8e\xc0\x86dr'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    int_0 = -1214
    dict_0 = {}
    float_0 = 1.0
    action_module_0 = ActionModule(set_0, int_0, int_0, dict_0, dict_0, float_0)
    assert action_module_0.action_loader is set_0
    assert action_module_0.connection is int_0
    assert action_module_0.task_id is int_0
    assert action_module_0.loader is dict_0
    assert action_module_0.templar is dict_0

# Generated at 2022-06-25 06:53:58.141498
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule("action_module", "action_module", "action_module", "action_module", "action_module", "action_module")