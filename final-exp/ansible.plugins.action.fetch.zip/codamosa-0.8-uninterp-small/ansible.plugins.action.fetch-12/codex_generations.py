

# Generated at 2022-06-25 06:47:27.005549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.9334444
    set_0 = {float_0, float_0, float_0, float_0, float_0, float_0, float_0}
    str_0 = 'jT,OV'
    action_module_0 = ActionModule(float_0, set_0, str_0, float_0, str_0, float_0)
    str_1 = '+'
    int_0 = action_module_0.run(str_1, )
    assert int_0 == 0


# Generated at 2022-06-25 06:47:36.752484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -454.9
    set_0 = {float_0, float_0, float_0, float_0, float_0, float_0, float_0}
    action_module_0 = None
    str_0 = 'l7,KFSFf,liQL'
    action_module_1 = ActionModule(float_0, set_0, str_0, action_module_0, str_0, action_module_0)
    tmp_0 = None
    task_vars_0 = None
    action_module_2 = action_module_1.run(tmp_0, task_vars_0)
    assert type(action_module_2) is dict

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:47:45.277005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing method run of class ActionModule')
    from ansible.plugins.action.fetch import ActionModule
    tmp_0 = None
    task_vars_0 = {}
    action_module_0 = ActionModule(None, None, None, None, None, None)
    result_0 = action_module_0.run(tmp_0, task_vars_0)
    assert result_0 == {'dest': None, 'checksum': None, 'remote_checksum': None, 'md5sum': None, 'remote_md5sum': None, 'file': None, 'changed': False}


# Generated at 2022-06-25 06:47:46.368822
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:47:52.409888
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -26.71
    str_0 = '8rM&'
    str_1 = 'e!x'
    action_module_2 = ActionModule(float_0, str_0, str_0, str_1, str_1, str_1)
    tmp_0 = None
    dict_0 = None
    result = action_module_2.run(tmp_0, dict_0)
    assert result == None

# Generated at 2022-06-25 06:47:53.086589
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

test_ActionModule_run()

# Generated at 2022-06-25 06:47:55.386511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_2 = ActionModule(-890.0, {-890.0, -890.0, -890.0}, '2ZE1<R,\x7f&', None, '2ZE1<R,\x7f&', None)
    action_module_2.run()

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 06:48:01.904414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('')
    print('=== Testing run of ActionModule class')

    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

# Unit Test Main method

# Generated at 2022-06-25 06:48:04.309913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:48:13.013808
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def __init__(self, data, file_vars, task_vars, new_stdin, new_stdout, new_stderr):
        float_0 = -454.9
        set_0 = {float_0, float_0, float_0, float_0, float_0, float_0, float_0}
        action_module_0 = None
        str_0 = 'l7,KFSFf,liQL'
        action_module_1 = ActionModule(float_0, set_0, str_0, action_module_0, str_0, action_module_0)


# Generated at 2022-06-25 06:48:32.164616
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:48:41.971100
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # task_vars = None
    bool_0 = False
    bytes_0 = b'\xa0\x03\x99L\x05^\xd9F\x0e\x14u\xfa'
    str_0 = '[\x0cC+(d~PH10|W+O^'
    list_0 = [str_0, bytes_0]
    bytes_1 = b'@Y\xff\xca\x7fr#a\xcc\xe8\xe9V\x12/'
    action_module_0 = ActionModule(bool_0, bytes_0, str_0, list_0, bytes_1, bool_0)
    var_0 = action_module_0.run(None, None)

# Generated at 2022-06-25 06:48:47.271480
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bytes_0 = b'\xa0\x03\x99L\x05^\xd9F\x0e\x14u\xfa'
    str_0 = '[\x0cC+(d~PH10|W+O^'
    list_0 = [str_0, bytes_0]
    bytes_1 = b'@Y\xff\xca\x7fr#a\xcc\xe8\xe9V\x12/'
    action_module_0 = ActionModule(bool_0, bytes_0, str_0, list_0, bytes_1, bool_0)

# Generated at 2022-06-25 06:48:59.487098
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bytes_0 = b'\xf9\xa9\x0c\x84_\x89\xa8\xaa\x1e'
    str_0 = '[E\x11-\xba\xbd\x89\xed\x91\x03\xcb'
    list_0 = [bytes(0)]
    bytes_1 = b'@W8\x18\x19\x93\xb2\x92D\x933\x1f'
    action_module_0 = ActionModule(bytes_1, str_0, bytes_0, list_0, bool_0, bool_0)
    assert action_module_0._connection==None
    assert action_module_0._loader==None
    assert action_module_0._play_context==None

# Generated at 2022-06-25 06:49:11.305300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bytes_0 = b'\xfe\xc8\xae\x1f\xa1\x4a\x0c\xc9\x83\x0c\xae\x9e'
    str_0 = '[\x0cO+O(q\xe0\x13\x98\xf4\x9a\x1c|^\x1c'
    list_0 = [bool_0, bytes_0, str_0]
    bytes_1 = b'\xe6\x84'
    action_module_0 = ActionModule(bool_0, bytes_0, str_0, list_0, bytes_1, bool_0)
    assert action_module_0 is not None
    assert action_module_0._module_implementation is True
    assert action_

# Generated at 2022-06-25 06:49:20.207398
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bytes_0 = b'\xae\x90\x8c\x1d'
    str_0 = 'o6\x0b0Q\x17\xfb\xd59%'
    list_0 = ['b|\x02\x01\x8d', '\x1c\x1cD>\x8aP', '\xd3\x01\x8e\x95\xee\xfc\xbb\xcaW8']
    bytes_1 = b'\xe9\x06\xc1\xee\x95\x90\xb1\xd8\x19\xe6\x9e'
    bytes_2 = b'd\x92\xdd\xe8\xe0'

# Generated at 2022-06-25 06:49:23.181582
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:49:28.861088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None, None, None, None, None, None)
    
    # Test exception raise of not implemented method run
    with pytest.raises(NotImplementedError) as excinfo:
        module.run()

# Generated at 2022-06-25 06:49:37.456350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'\x07\xcb$\x1c\xf8\x10\x12\xdb\x9e\x8f\xf3\xa0\x02\x81\xeb\x8f\x85\xbf\x01\xe1\xa1\xe4\x91#\xbb\x14\x06\xce\xe5\x01\x9f\xf5\xcf\x17\x93'

# Generated at 2022-06-25 06:49:47.306951
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bytes_0 = b'\xa0\x03\x99L\x05^\xd9F\x0e\x14u\xfa'
    str_0 = '[\x0cC+(d~PH10|W+O^'
    list_0 = [str_0, bytes_0]
    bytes_1 = b'@Y\xff\xca\x7fr#a\xcc\xe8\xe9V\x12/'
    action_module_0 = ActionModule(bool_0, bytes_0, str_0, list_0, bytes_1, bool_0)
    assert action_module_0._play_context == bool_0
    assert action_module_0._loader == bytes_0
    assert action_module_0._templar == str_0

# Generated at 2022-06-25 06:50:30.900061
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bytes_0 = b'\xa0\x03\x99L\x05^\xd9F\x0e\x14u\xfa'
    str_0 = '[\x0cC+(d~PH10|W+O^'
    list_0 = [str_0, bytes_0]
    bytes_1 = b'@Y\xff\xca\x7fr#a\xcc\xe8\xe9V\x12/'
    action_module_0 = ActionModule(bool_0, bytes_0, str_0, list_0, bytes_1, bool_0)
    test_case_0()

# Generated at 2022-06-25 06:50:38.903983
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bytes_0 = b'\xa0\x03\x99L\x05^\xd9F\x0e\x14u\xfa'
    str_0 = '[\x0cC+(d~PH10|W+O^'
    list_0 = [str_0, bytes_0]
    bytes_1 = b'@Y\xff\xca\x7fr#a\xcc\xe8\xe9V\x12/'
    action_module_0 = ActionModule(bool_0, bytes_0, str_0, list_0, bytes_1, bool_0)
    var_0 = action_run(bytes_1, list_0)
    print(var_0)

# Generated at 2022-06-25 06:50:40.581979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This test runs without fail

    # This test runs without fail
    pass


# Generated at 2022-06-25 06:50:49.649657
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print ("[*] Executing test " + str(test_case_0.__name__) + "...")
    try:
        test_case_0()
        print ("[+] " + str(test_case_0.__name__) + " test passed!")
    except Exception as e:
        print ("[-] " + str(test_case_0.__name__) + " test failed!")
        print ("[-] Exception raised: " + str(e))

# Generated at 2022-06-25 06:50:59.634714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = False
    bytes_0 = b'\xa0\x03\x99L\x05^\xd9F\x0e\x14u\xfa'
    str_0 = '[\x0cC+(d~PH10|W+O^'
    list_0 = [str_0, bytes_0]
    bytes_1 = b'@Y\xff\xca\x7fr#a\xcc\xe8\xe9V\x12/'
    action_module_0 = ActionModule(var_0, bytes_0, str_0, list_0, bytes_1, var_0)
    var_1 = action_run()

# Generated at 2022-06-25 06:51:00.283133
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 06:51:09.875986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Try with the following parameters:
    # bool_0 = False,
    # bytes_0 = b'\xa0\x03\x99L\x05^\xd9F\x0e\x14u\xfa',
    # str_0 = '[\x0cC+(d~PH10|W+O^',
    # list_0 = [str_0, bytes_0],
    # bytes_1 = b'@Y\xff\xca\x7fr#a\xcc\xe8\xe9V\x12/',
    # bool_1 = False
    bool_0 = False
    bytes_0 = b'\xa0\x03\x99L\x05^\xd9F\x0e\x14u\xfa'

# Generated at 2022-06-25 06:51:13.917259
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #this is just a mockup testcase
    assert True

# Generated at 2022-06-25 06:51:15.644505
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Add test cases
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:51:25.544197
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bytes_0 = b'\xa0\x03\x99L\x05^\xd9F\x0e\x14u\xfa'
    str_0 = '[\x0cC+(d~PH10|W+O^'
    list_0 = [str_0, bytes_0]
    bytes_1 = b'@Y\xff\xca\x7fr#a\xcc\xe8\xe9V\x12/'
    action_module_0 = ActionModule(bool_0, bytes_0, str_0, list_0, bytes_1, bool_0)
    assert action_module_0.tmp is None
    assert action_module_0._play_context is bool_0
    assert action_module_0._task is bytes_0
    assert action

# Generated at 2022-06-25 06:52:40.122287
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bytes_0 = b'\xa0\x03\x99L\x05^\xd9F\x0e\x14u\xfa'
    str_0 = '[\x0cC+(d~PH10|W+O^'
    list_0 = [str_0, bytes_0]
    bytes_1 = b'@Y\xff\xca\x7fr#a\xcc\xe8\xe9V\x12/'
    action_module_0 = ActionModule(bool_0, bytes_0, str_0, list_0, bytes_1, bool_0)
    assert(action_module_0._connection == bool_0)
    assert(action_module_0._task == bytes_0)

# Generated at 2022-06-25 06:52:44.186486
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # when
    module = dict(
        src="/tmp/somefile.txt",
        dest="/tmp/somefile.txt"
    )
    action = ActionModule(boolean=False, connection_info={}, task_uuid=None, task_vars=None, tem_path=None, diff=None, task_action=module)

    #then
    assert action is not None

# Generated at 2022-06-25 06:52:52.539668
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_1 = False

# Generated at 2022-06-25 06:52:54.069092
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case for a basic constructor
    test_case_0()


# Generated at 2022-06-25 06:53:02.400159
# Unit test for constructor of class ActionModule
def test_ActionModule():
  bool_0 = False
  bytes_0 = b'\xa0\x03\x99L\x05^\xd9F\x0e\x14u\xfa'
  str_0 = '[\x0cC+(d~PH10|W+O^'
  list_0 = [str_0, bytes_0]
  bytes_1 = b'@Y\xff\xca\x7fr#a\xcc\xe8\xe9V\x12/'
  action_module_0 = ActionModule(bool_0, bytes_0, str_0, list_0, bytes_1, bool_0)
  return action_module_0

# Generated at 2022-06-25 06:53:03.995267
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('test_ActionModule')
    test_case_0()


# Generated at 2022-06-25 06:53:04.893734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 06:53:14.969639
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bytes_0 = b'\x9da\x8d\x10/\x14{G\x08\x17\xf8\xafp\xee'
    str_0 = 'G\xdf4\x1e\xd4@\xb4\x9f\x94%\xc6\x8b\xbf'
    list_0 = [str_0, bytes_0]
    bytes_1 = b'\xea\xcb\x16\xba\x80\xe2\xac\xf6\xf1\xab\x9e\xe8\xdc\xd7\x80\xa7'
    type_0 = type(bytes_1)

# Generated at 2022-06-25 06:53:21.236312
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mock object
    class MockActionBase(object):
        def __init__(self, tmp=None, task_vars=None):
            self.tmp = tmp
            self.task_vars = task_vars

        @staticmethod
        def run(tmp, task_vars):
            raise AssertionError('Method run() not mocked')

    class MockActionModule(object):
        def __init__(self):
            self._play_context = MockActionBase()
            self._task = MockActionBase()
            self._task.args = {'dest': 'dest', 'src': 'src', 'validate_checksum': 'validate_checksum',
                               'fail_on_missing': 'fail_on_missing', 'flat': 'flat'}
            self._connection = MockActionBase()


# Generated at 2022-06-25 06:53:33.122315
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bytes_0 = b'\r\x00\x00'
    int_0 = 0
    str_0 = "L-\x00\x00\x00\x00\x00\x00\x00\x00"
    list_0 = []
    bytes_1 = b'\xe3\x00\x00'
    action_module_0 = ActionModule(bool_0, bytes_0, int_0, str_0, list_0, bytes_1, bool_0)
    assert action_module_0._connection is None, "Constructor of ActionModule does not work"
    assert action_module_0._task is None, "Constructor of ActionModule does not work"

# Generated at 2022-06-25 06:56:42.635236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 06:56:45.494394
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:56:46.516924
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # FIXME: Write unit test
    assert True == True


# Generated at 2022-06-25 06:56:50.138537
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)


# Generated at 2022-06-25 06:57:00.958078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bytes_0 = b'w\xe5.\xa0\x93\xb5\xb0\x9e\x1e\x8c\x94p]\x1e\xf7\x08\x0f\x9b\x14\x88\xf0\x98'
    str_0 = '\x0c\x1d\x0c\x19\x1c\x14\x15\x0c\x19\x1d\x1c\x0f\x0f\x11\x14\x14\x0b\n\x02\x1f\x0b\x1c\x14\x0e\x0f\x16\x1e\x0f'

# Generated at 2022-06-25 06:57:08.467770
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bytes_0 = b'\xa0\x03\x99L\x05^\xd9F\x0e\x14u\xfa'
    str_0 = '[\x0cC+(d~PH10|W+O^'
    list_0 = [str_0, bytes_0]
    bytes_1 = b'@Y\xff\xca\x7fr#a\xcc\xe8\xe9V\x12/'
    action_module_0 = ActionModule(bool_0, bytes_0, str_0, list_0, bytes_1, bool_0)
