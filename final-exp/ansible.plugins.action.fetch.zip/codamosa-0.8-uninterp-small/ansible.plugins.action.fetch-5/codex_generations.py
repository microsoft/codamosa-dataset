

# Generated at 2022-06-25 06:47:20.930706
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:47:28.294394
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Generate test for constructor.
    # Remember, there should be no statements outside constructor.
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    dict_1 = {bool_0: bool_0, bool_0: dict_0}
    set_0 = {bool_0, bool_0, dict_1}


# Generated at 2022-06-25 06:47:32.538234
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiation of class ActionModule
    actionModule_instance = ActionModule()
    # Call of method run
    actionModule_instance.run(tmp, task_vars)
    # Verification of attribute: task_vars
    assert isinstance(actionModule_instance.task_vars, dict)


# Generated at 2022-06-25 06:47:35.864156
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {bool_0: set_0, bool_0: bool_0, bool_0: bool_0, bool_0: set_0}
    # Constructor of ActionModule
    test_case_0()


# Generated at 2022-06-25 06:47:37.213085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:47:48.302261
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    dict_1 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = '{'
    str_1 = '%s' % bool_0
    str_2 = '2Zjt'
    str_3 = 'sdhw'
    str_4 = '4XC,:B'
    str_5 = 't32'
    str_6 = '^x'
    str_7 = 'D5'
    str_8 = 'q(`'

# Generated at 2022-06-25 06:47:49.402298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if not hasattr(test_ActionModule_run, "executed"):
        ActionModule_run(False)
        test_ActionModule_run.executed = True



# Generated at 2022-06-25 06:47:50.432077
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-25 06:47:52.925254
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(name='ansible.v1.ActionModule')
    test_case_0()


if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 06:47:55.255622
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:48:17.363442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass # test case not implemented

if __name__ == '__main__':
    test_case_0()
    # test_ActionModule_run()

# Generated at 2022-06-25 06:48:18.122202
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    pass


# Generated at 2022-06-25 06:48:22.997869
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1= ActionModule()
    assert action_module_1._shared_loader_obj is None


# Generated at 2022-06-25 06:48:24.792040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 06:48:29.282182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # test case 1:
    # run() is not implemented because the fetch module has uses the AnsibleConnection plugin
    # this is just a placeholder test to get code coverage on run()
    try:
        action_module_0.run()
        assert False
    except NotImplementedError as e:
        assert True

# Generated at 2022-06-25 06:48:35.097164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    result_0 = action_module_0.run(tmp_0, task_vars_0)

    assert result_0['msg'] == 'src and dest are required'
    assert result_0['changed'] == False

if __name__ == "__main__":
    import nose
    nose.run(defaultTest=__name__)

# Generated at 2022-06-25 06:48:37.396788
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_2 = ActionModule()
    assert(isinstance(action_module_2, ActionModule))


# Generated at 2022-06-25 06:48:38.986309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.name == 'Fetch'



# Generated at 2022-06-25 06:48:45.821892
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    tmp = "{'a': '1'}"
    task_vars = "{'a': '1'}"
    try:
        print("Unit test for method run of class ActionModule")
        print("Param:tmp = " + tmp)
        print("Param:task_vars = " + task_vars)
        res = action_module.run(tmp, task_vars)
        print("Return value:" + str(res))
        print("Unit test for method run of class ActionModule over")
    except Exception as e:
        print("Exception when testing method run of class ActionModule:")
        print(str(e))


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:48:57.813183
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(action_module_0 is not None)
    assert(action_module_0._connection._shell is not None)
    assert(action_module_0._display is not None)
    assert(action_module_0._loader is not None)
    assert(action_module_0._task is not None)
    assert(action_module_0._templar is not None)

    assert(action_module_0._play_context is not None)
    assert(action_module_0._play_context._active_connection is not None)
    assert(action_module_0._play_context.become is False)
    assert(action_module_0._play_context.become_pass is None)
    assert(action_module_0._play_context.become_user is None)

# Generated at 2022-06-25 06:49:26.214858
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x0eo\xdbrh\xe8\xea\xa9\xca2\x0f\x0e\x1f\x16\x04\x1cR\x1e'
    float_0 = -4034.680969464805
    tuple_0 = ()
    str_0 = ''
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, float_0, float_0, tuple_0, str_0, bool_0)
    action_module_0._execute_remote_stat()
    var_0 = action_run(float_0)

# Generated at 2022-06-25 06:49:34.430000
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x0eo\xdbrh\xe8\xea\xa9\xca2\x0f\x0e\x1f\x16\x04\x1cR\x1e'
    float_0 = -4034.680969464805
    float_1 = -4034.680969464805
    tuple_0 = ()
    str_0 = ''
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, float_0, float_0, tuple_0, str_0, bool_0)


# Generated at 2022-06-25 06:49:41.229021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x0eo\xdbrh\xe8\xea\xa9\xca2\x0f\x0e\x1f\x16\x04\x1cR\x1e'
    float_0 = -4034.680969464805
    tuple_0 = ()
    str_0 = ''
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, float_0, float_0, tuple_0, str_0, bool_0)
    var_0 = test_case_0()

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-25 06:49:46.168193
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x0eo\xdbrh\xe8\xea\xa9\xca2\x0f\x0e\x1f\x16\x04\x1cR\x1e'
    float_0 = -4034.680969464805
    tuple_0 = ()
    str_0 = ''
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, float_0, float_0, tuple_0, str_0, bool_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:49:52.953574
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x0eo\xdbrh\xe8\xea\xa9\xca2\x0f\x0e\x1f\x16\x04\x1cR\x1e'
    float_0 = -4034.680969464805
    tuple_0 = ()
    str_0 = ''
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, float_0, float_0, tuple_0, str_0, bool_0)


# Generated at 2022-06-25 06:50:02.508419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'_\x9b\xeb\x84\x8f\xab\xa3\xd0\x1d\xee\x9b\x01\x10\x04\x1d\x1c\xf0\xde\xd7\x8a'
    float_0 = -1214.4460498657257
    float_1 = 4070.613652788482
    tuple_0 = ()
    str_0 = '{0}'
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, float_0, float_0, tuple_0, str_0, bool_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 06:50:11.562458
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x0eo\xdbrh\xe8\xea\xa9\xca2\x0f\x0e\x1f\x16\x04\x1cR\x1e'
    float_0 = -4034.680969464805
    tuple_0 = ()
    str_0 = ''
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, float_0, float_0, tuple_0, str_0, bool_0)
    try:
        test_case_0()
        test_case_1()
    except:
        print('Exception raised:')
    else:
        print('No exception raised in test_case_2')


# Generated at 2022-06-25 06:50:18.720314
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x0eo\xdbrh\xe8\xea\xa9\xca2\x0f\x0e\x1f\x16\x04\x1cR\x1e'
    float_0 = -4034.680969464805
    tuple_0 = ()
    str_0 = ''
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, float_0, float_0, tuple_0, str_0, bool_0)
    action_module_1 = ActionModule(bytes_0, float_0, float_0, tuple_0, str_0, bool_0)


# Generated at 2022-06-25 06:50:26.257727
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x0eo\xdbrh\xe8\xea\xa9\xca2\x0f\x0e\x1f\x16\x04\x1cR\x1e'
    float_0 = -4034.680969464805
    float_1 = -4034.680969464805
    tuple_0 = ()
    str_0 = ''
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, float_0, float_1, tuple_0, str_0, bool_0)
    assert action_module_0.action_name == ''
    assert action_module_0.connection == 'local'
    assert action_module_0.delegate_to == 'localhost'
    assert action_module_0.module_

# Generated at 2022-06-25 06:50:37.103610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'<x\x1e\x1ccKh\xb6\x04\x0f\x19\xfb\xef\xe4"H\x12\xb8\x06\x80\xcd\x0b\x8bv'
    float_0 = -72411.90702957702
    float_0 = -72411.90702957702
    tuple_0 = ()
    str_0 = ''
    bool_0 = False
    action_module_0 = ActionModule(bytes_0,float_0,float_0,tuple_0,str_0,bool_0)
    var_0 = action_module_0.run()
    print(var_0)

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:51:26.484741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x0eo\xdbrh\xe8\xea\xa9\xca2\x0f\x0e\x1f\x16\x04\x1cR\x1e'
    float_0 = -4034.680969464805
    float_1 = -4034.680969464805
    tuple_0 = ()
    str_0 = ''
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, float_0, float_1, tuple_0, str_0, bool_0)


# Generated at 2022-06-25 06:51:27.654212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('test_ActionModule')
    # test_case_0()

# unit test for method run()

# Generated at 2022-06-25 06:51:28.344856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:51:33.943574
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x0eo\xdbrh\xe8\xea\xa9\xca2\x0f\x0e\x1f\x16\x04\x1cR\x1e'
    float_0 = -4034.680969464805
    tuple_0 = ()
    str_0 = ''
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, float_0, float_0, tuple_0, str_0, bool_0)
    var_0 = action_module_0.run(tmp=None, task_vars=None)
    str_1 = action_module_0.get_name()
    print("Unit test for constructor of class ActionModule")
    print("name:", str_1)


# Generated at 2022-06-25 06:51:41.227742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_0 = {}
    float_0 = 1.0
    assertion_error_0 = None
    try:
        action_module_0 = ActionModule(dict_0, dict_0, float_0, dict_0, dict_0, dict_0)
        var_0 = action_module_0.run(dict_0, dict_0)
        if (len(var_0) != 0):
            raise AssertionError("length(%s) != 0" % var_0)
        if (len(var_0) != 0):
            raise AssertionError("length(%s) != 0" % var_0)
    except AssertionError as e:
        assertion_error_0 = e
    assert (assertion_error_0 is None)


# Generated at 2022-06-25 06:51:48.617574
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'E\x8a\x9e\xca\xb5\xf1\xde\xc1\xf6\xc4\x13b\xa2\x9a\x94\xfe'
    float_0 = -9743.639648437499
    float_1 = 8.599913616172046
    var_0 = ()
    str_0 = ''
    bool_0 = False

    var_1 = ActionModule(var_0, float_0, float_1, var_0, str_0, bool_0)


# Test function for method run

# Generated at 2022-06-25 06:51:58.603267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x0eo\xdbrh\xe8\xea\xa9\xca2\x0f\x0e\x1f\x16\x04\x1cR\x1e'
    float_0 = -4034.680969464805
    float_1 = -4034.680969464805
    tuple_0 = ()
    str_0 = ''
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, float_0, float_1, tuple_0, str_0, bool_0)
    action_module_0.run(tuple_0, tuple_0)
    test_case_0()

# Generated at 2022-06-25 06:52:03.332005
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: Rename "source" to "src"
    source = None
    # TODO: Rename "dest" to "destination"
    dest = None
    action_module_0 = ActionModule(source, dest, True, False)
    # TODO: Rename "source" to "src"
    source = 'source'
    # TODO: Rename "dest" to "destination"
    dest = 'dest'
    action_module_0 = ActionModule(source, dest, True, False)


# Generated at 2022-06-25 06:52:12.125072
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x0eo\xdbrh\xe8\xea\xa9\xca2\x0f\x0e\x1f\x16\x04\x1cR\x1e'
    float_0 = -4034.680969464805
    tuple_0 = ()
    str_0 = ''
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, float_0, float_0, tuple_0, str_0, bool_0)


# Generated at 2022-06-25 06:52:22.733230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x0eo\xdbrh\xe8\xea\xa9\xca2\x0f\x0e\x1f\x16\x04\x1cR\x1e'
    float_0 = -4034.680969464805
    tuple_0 = ()
    str_0 = ''
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, float_0, float_0, tuple_0, str_0, bool_0)
    action_run_0 = action_run(float_0)
    var_0 = action_module_0.run(action_run_0)


# Generated at 2022-06-25 06:53:52.075118
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None


# Generated at 2022-06-25 06:53:58.097075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert not ActionModule.run.__doc__
    assert False

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:54:08.504740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x0eo\xdbrh\xe8\xea\xa9\xca2\x0f\x0e\x1f\x16\x04\x1cR\x1e'
    float_0 = -4034.680969464805
    float_1 = -4034.680969464805
    tuple_0 = ()
    str_0 = ''
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, float_0, float_1, tuple_0, str_0, bool_0)
    try:
        ActionModule(None, None, None, None, None, None)
    except TypeError as e:
        assert True


# Generated at 2022-06-25 06:54:18.307113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xe4\x90\x19\xa9\xbc\xdd\x81\xee\xbc\xd3\x1f\xc7\xac\x83\x12\x07\xb3\x07Z\xab\xd8\x80\xc0\xbd\xf1d\x81\x8e\xd7\xdd\x96\x0c\x873\xa5'
    float_0 = -13277.475254188012
    float_1 = 13148.10454618537
    tuple_0 = (9803.091608692334, )
    str_0 = ''
    bool_0 = False

# Generated at 2022-06-25 06:54:21.898570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with mock.patch('ansible.plugins.action.fetch.ActionModule.run', return_value=True):
        fetch.ActionModule.run(tmp=None, task_vars=None)


# Generated at 2022-06-25 06:54:23.500926
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:54:28.233109
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x0eo\xdbrh\xe8\xea\xa9\xca2\x0f\x0e\x1f\x16\x04\x1cR\x1e'
    float_0 = -4034.680969464805
    tuple_0 = ()
    str_0 = ''
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, float_0, float_0, tuple_0, str_0, bool_0)


# Generated at 2022-06-25 06:54:38.249233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleError, AnsibleActionFail, AnsibleActionSkip
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.utils.display import Display
    from ansible.utils.hashing import checksum, checksum_s, md5, secure_hash
    from ansible.utils.path import makedirs_safe, is_subpath
    display = Display()
    result = super(ActionModule, self).run(tmp, task_vars)
    del tmp  # tmp no longer has any effect

# Generated at 2022-06-25 06:54:44.994426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x0eo\xdbrh\xe8\xea\xa9\xca2\x0f\x0e\x1f\x16\x04\x1cR\x1e'
    float_0 = 16010.59384768889
    float_1 = -4056.80746629664
    tuple_0 = ()
    str_0 = ''
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, float_0, float_0, tuple_0, str_0, bool_0)
    var_0 = action_run(float_0)


# Generated at 2022-06-25 06:54:49.472502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xb6>r\xaf|\xc5\x01F\x01\xe5w\xa5\x04\x12\xf2\x9e\x9fi\xa2'
    float_0 = -29.2773
    tuple_0 = ()
    str_0 = ''
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, float_0, float_0, tuple_0, str_0, bool_0)
