

# Generated at 2022-06-25 06:47:28.029324
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:47:29.280784
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:47:36.629969
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dest = 'test/test/test'
    dest_dir = '/test/test'
    source = 'test/test/test/'
    try:
        test_case_0()
    except (AnsibleActionFail, AnsibleActionSkip, AnsibleError) as e:
        assert 'Detected directory traversal, expected to be contained in' in to_text(e)
        assert not is_subpath(dest, dest_dir)
    else:
        raise AssertionError
    try:
        ActionModule(dest, dest_dir, source, False, True)
    except (AnsibleActionFail, AnsibleActionSkip, AnsibleError) as e:
        assert 'Detected directory traversal, expected to be contained in' in to_text(e)
        assert not is_subpath(dest, dest_dir)
   

# Generated at 2022-06-25 06:47:42.517373
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x88\xeeC\x0e'
    int_0 = 1968
    dict_0 = {bytes_0: int_0, int_0: bytes_0}
    list_0 = []
    action_module_0 = ActionModule(bytes_0, int_0, dict_0, list_0, list_0, dict_0)


# Generated at 2022-06-25 06:47:53.154474
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1404
    bytes_0 = b'a3\x8d,\xc4x\xc6\xfc'
    dict_0 = {}
    list_0 = []
    dict_1 = {bytes_0: bytes_0}
    dict_2 = {}
    dict_2['msg'] = dict_1
    dict_2['ansible_facts'] = dict_1
    dict_2['ansible_module_name'] = 'ansible.legacy.slurp'
    dict_2['invocation'] = dict_1
    dict_2['ansible_facts'] = dict_1
    dict_2['failed'] = 1
    dict_2['ansible_syslog_facility'] = dict_1
    dict_2['ansible_facts'] = dict_1

# Generated at 2022-06-25 06:47:56.328441
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3393
    bytes_0 = b'\x8f\xbdi\x0c\xe4\x8f\xcb\xe1\xaf\xa0\x8d\xac'
    dict_0 = {int_0: int_0, bytes_0: bytes_0}
    list_0 = []
    action_module_0 = ActionModule(bytes_0, int_0, dict_0, list_0, list_0, dict_0)


# Generated at 2022-06-25 06:48:02.618959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1
    dict_0 = {int_0: int_0}
    list_0 = [int_0]
    action_module_0 = ActionModule(None, None, dict_0, list_0, dict_0, dict_0)
    action_module_0.run()


# Generated at 2022-06-25 06:48:05.428089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1404
    bytes_0 = b'a3\x8d,\xc4x\xc6\xfc'
    dict_0 = {int_0: int_0, bytes_0: bytes_0}
    list_0 = []
    action_module_0 = ActionModule(bytes_0, int_0, dict_0, list_0, list_0, dict_0)
    action_module_0.run()

# Generated at 2022-06-25 06:48:13.787099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 181
    int_1 = 207
    bytes_0 = b'jV\x8eD\x9d\x1e'
    dict_0 = {bytes_0: bytes_0, int_0: int_0, 'src': bytes_0, int_1: int_0}
    list_0 = []
    action_module_0 = ActionModule(bytes_0, int_0, dict_0, list_0, list_0, dict_0)
    dict_1 = {}
    dict_2 = action_module_0.run(None, dict_1)
    assert isinstance(dict_2['file'] == bytes_0)
    assert dict_2['changed'] is True


# Generated at 2022-06-25 06:48:15.870472
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-25 06:48:42.582389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0  = -4135
    int_1  =  4135
    int_2  = -4139
    int_3  =  4139
    int_4  = -4143
    int_5  =  4143
    int_6  = -4147
    int_7  =  4147
    int_8  = -4151
    int_9  =  4151
    int_10 = -4155
    int_11 =  4155
    int_12 = -4159
    int_13 =  4159
    int_14 = -4163
    int_15 =  4163
    int_16 = -4167
    int_17 =  4167
    int_18 = -4171
    int_19 =  4171
    int_20 = -4175


# Generated at 2022-06-25 06:48:48.300820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1
    action_module_0 = ActionModule(None, int_0, int_0, int_0, int_0, int_0)
    tmp_0 = '/O'
    task_vars_0 = None

    # Call method run with args tmp_0 and task_vars_0
    result = action_module_0.run(tmp_0, task_vars_0)
    assert result == None


# Generated at 2022-06-25 06:48:50.524444
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for environment in which constructor fails and throws an exception
    # Test case number: 0

    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    assert "argument " in str(excinfo.value)

# Generated at 2022-06-25 06:48:53.167803
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception:
        return False

    return True

# Generated at 2022-06-25 06:48:58.511073
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3393
    bytes_0 = b'\x8f\xbdi\x0c\xe4\x8f\xcb\xe1\xaf\xa0\x8d\xac'
    action_module_0 = ActionModule(bytes_0, int_0, int_0, int_0, int_0, int_0)


# Generated at 2022-06-25 06:49:03.522971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Test constructor of class ActionModule')
    int_1 = 3187
    bytes_1 = b'\x9fj\xa0H\x0e\xdf\xdc\x15.\x0c\x0f\x08'
    action_module_1 = ActionModule(bytes_1, int_1, int_1, int_1, int_1, int_1)


# Generated at 2022-06-25 06:49:07.288270
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:49:16.045764
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3393
    bytes_0 = b'\x8f\xbdi\x0c\xe4\x8f\xcb\xe1\xaf\xa0\x8d\xac'
    action_module_0 = ActionModule(bytes_0, int_0, int_0, int_0, int_0, int_0)

    assert action_module_0 is not None
    str_0 = 'Undefined'
    assert str_0 == action_module_0._task.action
    dict_0 = dict()
    assert dict_0 == action_module_0._task.args
    assert bytes_0 is action_module_0._connection



# Generated at 2022-06-25 06:49:19.833499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3393
    bytes_0 = b'\x8f\xbdi\x0c\xe4\x8f\xcb\xe1\xaf\xa0\x8d\xac'
    action_module_0 = ActionModule(bytes_0, int_0, int_0, int_0, int_0, int_0)


# Generated at 2022-06-25 06:49:23.143579
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:49:46.596338
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod != None


# Generated at 2022-06-25 06:49:49.005632
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    arg_0 = None
    arg_1 = None
    arg_2 = None
    class_0 = ActionModule()
    if bool_0 and class_0.run(arg_0, arg_1, arg_2) == False:
        bool_0 = False
    return True


test_case_0()

# Generated at 2022-06-25 06:49:56.255306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


if __name__ == '__main__':
    import os
    import sys
    import unittest
    import tempfile

    # Run tests with: python -m pytest ./test.py
    # Run coverage with: python -m pytest --cov ./test.py
    test_loader = unittest.TestLoader()
    test_names = test_loader.getTestCaseNames(test_ActionModule_run)
    suite = unittest.TestSuite()

    for test_name in test_names:
        suite.addTest(test_ActionModule_run(test_name))

    result = unittest.TextTestRunner().run(suite)
    sys.exit(not result.wasSuccessful())

    # Run coverage with: python -m pytest --cov ./test.py


# Generated at 2022-06-25 06:49:59.676074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert actionModule_0 is not None


# Generated at 2022-06-25 06:50:01.073206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    param_0 = None
    param_1 = None
    m.run(param_0, param_1)



# Generated at 2022-06-25 06:50:05.121469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
    except Exception as ex:
        print(ex)


# Generated at 2022-06-25 06:50:06.728795
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    f = action.ActionModule()
    f.run(tmp=None, task_vars=None)



# Generated at 2022-06-25 06:50:09.778181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    result_0 = action_module_0.run()


# Generated at 2022-06-25 06:50:19.156906
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # this is a meta action module
    # has_run()
    string_1 = 'dummy'
    bool_1 = test_case_0()
    bool_2 = True
    dict_1 = {}
    # _execute_module()
    dict_1 = {}
    dict_1 = ActionModule(string_1, bool_1, bool_2, dict_1).run()
    string_2 = 'file'
    string_3 = dict_1.get(string_2)
    string_4 = '/etc/hosts'
    assert string_3 == string_4
    string_5 = 'md5sum'
    string_6 = dict_1.get(string_5)

# Generated at 2022-06-25 06:50:26.517797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.fetch import ActionModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    options = ['-i', '/path/to/inventory', '/path/to/playbook.yml']

    loader = DataLoader()

    # Initialize needed objects
    inventory = InventoryManager(loader=loader, sources=options[1])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context

# Generated at 2022-06-25 06:50:56.775516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ac_mod_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    try:
        ac_mod_0.run()
    except SystemError:
        assert False
    else:
        assert True


# Generated at 2022-06-25 06:50:59.648218
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data = test_case_0()

    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-25 06:51:01.902947
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    myactionmodule = ActionModule()
    bool_0 = True
    myactionmodule.run(bool_0)


# Generated at 2022-06-25 06:51:06.332902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(play_context=play_context, new_stdin=StringIO.StringIO('new_stdin'))
    result = action_module.run(tmp=None, task_vars=None)
    print(result)

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 06:51:07.674905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fixture = ActionModule()
    fixture.run()


test_case_0()

# Generated at 2022-06-25 06:51:08.945772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule({}, {}, {}, {})



# Generated at 2022-06-25 06:51:11.560705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = None
    str_1 = None
    test_case_0()
    test_case = ActionModule(str_0, str_1)

# Generated at 2022-06-25 06:51:15.407808
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule_0 = ActionModule('actionModule_1', 'actionModule_2')
    assert actionModule_0 != None
    assert actionModule_0._display != None


# Generated at 2022-06-25 06:51:20.865277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        tmp = None
        task_vars = dict()
        action_module = ActionModule(tmp=tmp, task_vars=task_vars)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 06:51:26.333277
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # Test case for function constructor of class ActionModule
  # Action module for fetching files from remote nodes
  test_case_0()

if __name__ == '__main__':
  # If a command line argument is provided, call test_case_0 for that argument
  if len(sys.argv) > 1:
    test_case_0(sys.argv[1])
  else:
    # Run all unit tests
    test_ActionModule()

# Generated at 2022-06-25 06:52:17.137553
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("\n\nIn test_ActionModule")
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:52:17.983824
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule_0 = ActionModule()


# Generated at 2022-06-25 06:52:19.916751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fetch = ActionModule(connection=None)


# Generated at 2022-06-25 06:52:29.557539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('arg_0', 'arg_1', True)
    assert_equal(action_module_0.DEFAULT_CHUNK_SIZE, 65536)
    assert_equal(action_module_0.DEFAULT_DIRECTORY_MODE, 448)
    assert_equal(action_module_0.DEFAULT_PATH_MODE, 448)
    assert_equal(action_module_0.DEFAULT_TRANS_CHUNKSIZE, 65536)
    assert_equal(action_module_0.DEFAULT_FILE_MODE, 420)
    assert_equal(action_module_0.VALID_TRANSFERS, ['git', 'rsync', 'scp', 'sftp'])

# Generated at 2022-06-25 06:52:30.405225
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:52:33.830455
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule_0 = ActionModule()
    pytest.test_case_0()
    assert not actionmodule_0._remove_tmp_path(actionmodule_0._connection._shell.tmpdir)
    assert actionmodule_0.run(tmp=None, task_vars=None)

# Generated at 2022-06-25 06:52:35.543480
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Unit test for: test_ActionModule")

    # test case 0
    print("Test case 0")


# Generated at 2022-06-25 06:52:46.785282
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_arguments_0 = {}
    module_arguments_0['src'] = 'src'
    module_arguments_0['validate_checksum'] = False
    module_arguments_0['dest'] = 'dest'
    module_arguments_0['fail_on_missing'] = True
    module_arguments_0['flat'] = False
    dict_0 = {}
    dict_0['action'] = 'action'
    dict_0['become_user'] = 'become_user'
    dict_0['become'] = False
    dict_0['delegate_to'] = 'delegate_to'
    dict_0['async'] = 42
    dict_0['register'] = 'register'
    dict_0['remote_user'] = 'remote_user'
    module_0 = ActionModule

# Generated at 2022-06-25 06:52:50.860557
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.parsing.yaml.constructor
    import ansible.parsing.yaml.objects
    ansible.parsing.yaml.constructor.BaseConstructor.construct_yaml_bool = test_case_0
    action_module_0 = ActionModule()
    try:
        action_module_0.run()
    except:
        pass
    return 0

test_case_0()

# Generated at 2022-06-25 06:53:00.786202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # unit test for method run of class ActionModule

    assert type(bool_0) == bool
    assert type(str_0) == str
    assert type(str_1) == str

    # call method run of class ActionModule with args:
    # None, None
    assert type(str_2) == str
    run_args_0 = None # value: None
    run_args_1 = None # value: None
    ActionModule_instance_0 = ActionModule(
        run_args_0,
        run_args_1
    )
    ActionModule_instance_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:54:46.841561
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    actionmodule_0 = ActionModule()
    # test __init__
    bool_0 = bool_0


test_ActionModule()
test_case_0()
if __name__ == '__main__':
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 06:54:50.470167
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    test_case_0()

# Creation of an instance of the class for the test
test_instance_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-25 06:54:57.224709
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_0 = None
    connection_0 = None
    play_context_0 = None
    loader_0 = None
    templar_0 = None
    shared_loader_obj = None
    test_case_0()
    test_obj = ActionModule(task_0, connection_0, play_context_0, loader_0, templar_0, shared_loader_obj)
    assert test_obj is not None


# Generated at 2022-06-25 06:55:03.636051
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_1 = False
    str_0 = '''
        src: /tmp/file.txt
        dest: /home/user/file.txt
    '''
    dict_0 = dict()
    dict_0['msg'] = 'File already exists on the remote filesystem'
    dict_0['file'] = 'file.txt'
    dict_0['changed'] = bool_1
    dict_0['invocation'] = dict()
    dict_0['invocation']['module_args'] = str_0
    dict_1 = dict()
    dict_1['msg'] = 'File not found is the remote filesystem'
    dict_1['file'] = 'file.txt'
    dict_1['changed'] = bool_1
    dict_1['invocation'] = dict()

# Generated at 2022-06-25 06:55:13.952777
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = { }
    args = { 'src': 'a', 'dest': 'a' }
    tmp = 'a'

    # Attempt 1. Setup (No exception expected)
    _play_context = ActionBase._play_context
    _task = ActionBase._task
    _connection = ActionBase._connection
    _loader = ActionBase._loader
    _templar = ActionBase._templar
    _shared_loader_obj = ActionBase._shared_loader_obj
    display = ActionBase._display
    _task_vars = ActionModule._task_vars
    ActionBase._play_context = play_context
    ActionBase._task = task
    ActionBase._connection = connection
    ActionBase._loader = loader
    ActionBase._templar = templar
    ActionBase._shared_loader_obj = shared_

# Generated at 2022-06-25 06:55:16.757489
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:55:21.553562
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = {'src': 'src', 'dest': 'dest'}
    connection = 'connection'
    action_m = ActionModule('task', 'play_context', connection, args)
    if action_m._task.args.get('src') != 'src' or action_m._task.args.get('dest') != 'dest':
        raise Exception('ActionModule setup fail!')
    if action_m._connection != 'connection':
        raise Exception('ActionModule setup fail!')

test_case_0()
test_ActionModule()

# Generated at 2022-06-25 06:55:28.433681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    data = dict(
        ansible_ssh_user='vagrant',
        ansible_ssh_pass='vagrant',
        ansible_become=True,
        ansible_become_method='sudo',
        ansible_become_user='root',
        ansible_ssh_port=2222,
        ansible_host= 'localhost',
        src = '/etc/hosts',
        dest = '~/ansible/test'
    )
    with Connection('localhost:2222', 'vagrant', 'vagrant') as conn:
        conn.connect()
        conn.fetch_file('/etc/hosts', '~/ansible/test')


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 06:55:29.940958
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a second module_util.Default ans instance
    action_module_0 = ActionModule()

    # Mark this
    bool_0 = True

if __name__ == '__main__':
    pass

# Generated at 2022-06-25 06:55:40.618379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dest_value = "./test_dir/test_case_0"
    dest_permission = False
    if not os.path.exists(dest_value):
        os.makedirs(dest_value)
        dest_permission = True
    elif not os.access(dest_value, os.W_OK):
        dest_permission = True

    tmp_value = None
    if (dest_permission == True):
        os.chmod(dest_value, stat.S_IWRITE)

    source_value = "./test_dir/test_case_0/http_components-client-4.5.2-bin.tar.gz"
    if not os.path.exists(source_value):
        os.makedirs(source_value)

    test_run = ActionModule()
   