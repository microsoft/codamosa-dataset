

# Generated at 2022-06-25 06:47:16.921897
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:47:19.399817
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(test_case_0.__name__)
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:47:20.890510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Calling the test case 0.
    test_case_0()


# Generated at 2022-06-25 06:47:32.614727
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_0['first_key'] = dict_0
    dict_0['second_key'] = 200
    dict_0['third_key'] = False
    dict_0['fourth_key'] = 'qX'
    dict_0['fifth_key'] = 'ModuleUtil'
    dict_0['sixth_key'] = 'ModuleUtil'
    dict_0['seventh_key'] = 'qX'
    dict_0['eighth_key'] = None
    dict_0['ninth_key'] = 'ModuleUtil'
    dict_0['tenth_key'] = 'ModuleUtil'
    dict_0['eleventh_key'] = 'ModuleUtil'
    dict_0['twelfth_key'] = 'ModuleUtil'

# Generated at 2022-06-25 06:47:33.785352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:47:41.709110
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ';'
    list_0 = None
    int_0 = 204
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, int_0, list_0, int_0, bool_0)

    tmp = None
    task_vars = None

    try:
        result = action_module_0.run(tmp, task_vars)
    except AnsibleActionFail as e:
        assert False
    except AnsibleActionSkip as e:
        assert False
    else:
        assert True

    tmp = None
    task_vars = None

    try:
        result = action_module_0.run(tmp, task_vars)
    except AnsibleActionFail as e:
        assert False

# Generated at 2022-06-25 06:47:43.894618
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Call the method
    try:
        result = action_module_0.run()

    except Exception as e:
        # print error message
        print("Unhandled exception returned: %s" % e)
    # Test result
    assert result == None

# Generated at 2022-06-25 06:47:45.073629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:47:48.302740
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'f<'
    list_0 = None
    int_0 = 101
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, int_0, list_0, int_0, bool_0)
    str_1 = 'V'
    dict_0 = {}
    result = action_module_0.run(str_1, dict_0)
    assert result is None

test_ActionModule_run()

# Generated at 2022-06-25 06:47:50.956032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except:
        print('Expected: exception')


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:48:16.450338
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict
    var_1 = dict
    var_2 = string_types
    var_2 = "string_types"
    var_3 = string_types
    var_3 = "string_types"
    var_4 = "source and dest are required"
    var_5 = string_types
    var_5 = "string_types"
    var_6 = "invalid type supplied for source option, it must be a string"
    var_7 = string_types
    var_7 = "string_types"

    # Do not run the test if the parameters are wrong
    if var_0 is None or var_1 is None or var_2 is None or var_3 is None or var_4 is None or var_5 is None or var_6 is None or var_7 is None:
        return
    var_0

# Generated at 2022-06-25 06:48:20.477686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_0 = AnsibleModule(argument_spec=dict(validate_checksum=dict(type='bool', required=False), fail_on_missing=dict(type='bool', required=False), dest=dict(type='str', required=True), flat=dict(type='bool', required=False), src=dict(type='str', required=True)))
    var_0 = module_0.params
    var_0['dest'] = '/tmp/ansible_test_dest'
    var_0['src'] = __file__
    var_0['validate_checksum'] = True
    var_0['fail_on_missing'] = True
    var_0['flat'] = True
    ActionModule.run(var_0)

# Generated at 2022-06-25 06:48:24.385626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_0 = ()
    ActionModule_instance_0 = ActionModule()
    ActionModule_instance_0.run(var_0, var_0)


# Generated at 2022-06-25 06:48:26.538286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing ActionsBase class
    test_obj = ActionModule()
    # Calling run() method
    test_obj.run(var_0)
    return

# Generated at 2022-06-25 06:48:27.955080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action.run(tmp='var_0')


# Generated at 2022-06-25 06:48:35.085640
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()
    var_dumb_0 = ActionModule(var_0)
    dest = "Dest"
    flat = False
    fail_on_missing = True
    remote_data = "Remote_data"
    var_dumb_1 = ActionModule(var_0, dest, flat, fail_on_missing, remote_data)

    assert(var_dumb_0 is not None)
    assert(var_dumb_1 is not None)


# Generated at 2022-06-25 06:48:43.549047
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source = dict()
    var_1 = dict(a=1,b=2)
    task_vars = dict(a=1,b=2)
    tmp = dict(a=1,b=2)
    dest = dict(a=1,b=2)
    result = dict(a=1,b=2)
    remote_stat = dict()
    remote_checksum = dict()
    msg = dict()
    string_types = dict()
    remote_data = dict()
    slurpres = dict(a=1,b=2)
    source_local = dict(a=1,b=2)
    base = dict(a=1,b=2)
    target_name = dict(a=1,b=2)
    local_checksum = dict(a=1,b=2)
   

# Generated at 2022-06-25 06:48:48.945930
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Some sample tests.
#
# These are not included in the standard test framework because they rely
# on the ability to run ansible modules. We should look at adding some
# sort of tests like this to the framework at some point.

from ansible.inventory.host import Host
from ansible.playbook.play import Play
from ansible.playbook.play_context import PlayContext
from ansible.playbook.task import Task
from ansible.vars.manager import VariableManager


# Generated at 2022-06-25 06:49:00.560258
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = dict()
    # missing from setUp method
    # ActionModule_run possibly has unwanted side effects on tmp.
    var_0 = None
    var_1 = dict()
    arg_0 = var_0
    arg_1 = var_1
    action_module_obj = ActionModule()
    action_module_obj._task = Mock()
    action_module_obj._task.args = dict()
    action_module_obj._task.args['fail_on_missing'] = False
    action_module_obj._task.args['validate_checksum'] = True
    action_module_obj._task.args['src'] = '/home/vagrant/test_file.txt'
    action_module_obj._task.args['dest'] = '/tmp/dest'
    action_module_obj._task.args['flat']

# Generated at 2022-06-25 06:49:03.393870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_1 = ActionModule(var_0)
    var_2 = tmp = None
    var_3 = dict()
    var_1.run(var_2, var_3)

# Generated at 2022-06-25 06:49:22.732003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()


# Generated at 2022-06-25 06:49:23.748686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:49:34.811751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    var_4 = dict()
    var_5 = dict()

    var_1['_play_context'] = var_3
    var_1['_task'] = var_4
    var_1['_loader'] = var_5
    var_1['_connection'] = var_2
    var_1['_task_vars'] = var_0
    var_1['_tmp_path'] = var_0['_tmp_path']
    var_1['_shared_paths'] = var_0['_shared_paths']

    obj_1 = ActionModule(var_1)
    obj_1.run()


# Generated at 2022-06-25 06:49:39.431798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_0 = dict()
    var_1 = None
    var_1 = ActionModule(var_0)
    var_2 = None
    var_2 = tmp()
    var_2 = tmp()
    var_3 = None
    var_3 = task_vars()
    var_3 = task_vars()
    var_4 = None
    var_4 = var_1.run(var_2, var_3)

# Generated at 2022-06-25 06:49:40.506061
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None)


# Generated at 2022-06-25 06:49:42.749493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    var_1 = ActionModule()

    # Run unit tests for method run of class ActionModule

    # Call method run of class ActionModule
    var_1.run()

# Generated at 2022-06-25 06:49:50.014704
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except NameError as err:
        assert False , err.args[0]

if __name__ == '__main__':
    import sys
    import pytest
    testname = sys.argv[1].split('=')[0].split('.')[-1]
    globals()['test_%s' % testname]()
    print("Done")

# Generated at 2022-06-25 06:50:00.762899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Verify the returned value
    var_0 = dict()
    action_module = ActionModule(task=None, connection='', play_context=var_0, loader=None, templar=None, shared_loader_obj=None)
    var_1 = action_module._task = None
    var_2 = 'Test Host'
    var_3 = {}
    var_1.args = {'src': var_2, 'dest': var_3}
    var_1.args = {'src': var_2, 'dest': var_3}
    var_1.args = {'src': var_2, 'dest': var_3}
    var_1.args = {'src': var_2, 'dest': var_3}
    var_4 = None

# Generated at 2022-06-25 06:50:05.497307
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    ansible_0 = ActionModule(task_vars=var_0)
    print(ansible_0.run())


# Generated at 2022-06-25 06:50:12.595023
# Unit test for constructor of class ActionModule
def test_ActionModule():
    _connection = dict()
    _play_context = dict()
    _loader = dict()
    _templar = dict()
    _task_vars = dict()
    am = ActionModule(_connection, _play_context, _loader, _templar, _task_vars)
    del am
    del _connection
    del _play_context
    del _loader
    del _templar
    del _task_vars

# Generated at 2022-06-25 06:50:53.605592
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_1 = dict()


    DEBUG = True if os.environ.get('DEBUG', False) else False
    if DEBUG:
        print(test_case_0.__doc__)
    if DEBUG:
        print('Running test_case_0()...')
    test_case_0()


# Local Variables:
# # tab-width:4
# # indent-tabs-mode:nil
# # End:
# vim: set syntax=python expandtab tabstop=4 shiftwidth=4:

# Generated at 2022-06-25 06:50:55.369547
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule("ansible.legacy.fetch", None, None, None, None)


# Generated at 2022-06-25 06:51:07.533906
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_h6 = dict()
    var_h5 = "self._connection._shell.tmpdir"
    var_h4 = dict()
    var_h3 = "AnsibleActionSkip('check mode not (yet) supported for this module')"
    var_h2 = "self._play_context.check_mode"
    var_h1 = "if"

    if test_case_0():
        var_h8 = "self._connection.become"
        var_h7 = "self._connection._shell.join_path('a', '')"
        var_h0 = "os.path.sep not in"

# Generated at 2022-06-25 06:51:16.319860
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup (this test case is incomplete)
    var_0 = dict()
    var_0['ansible'] = dict()
    var_0['ansible']['version'] = dict()
    var_0['ansible']['config'] = dict()
    var_0['ansible']['config']['action_plugins'] = dict()
    var_0['ansible']['config']['action_plugins']['path'] = dict()
    var_0['ansible']['config']['roles_path'] = dict()
    var_0['ansible']['facts'] = dict()
    var_0['ansible']['module_name'] = '__main__'
    var_0['ansible']['version']['full'] = 'v2.5.5'
    var

# Generated at 2022-06-25 06:51:19.250549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == True

# Generated at 2022-06-25 06:51:24.347371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()
    ActionModule_obj = ActionModule(var_0) #
    assert ActionModule_obj is not None, 'Failed to create object of class ActionModule'

    # Test instance_method run is called and returns
    try:
        ActionModule_obj.run(var_0) #
        assert False, 'Expected exception'
    except AnsibleActionSkip as ae:
        assert True
    except Exception as e:
        assert False, 'Expected AnsibleActionSkip. Got an exception of type: ' + str(type(e)) + '; message: ' + to_text(e)


# Generated at 2022-06-25 06:51:29.811824
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except AnsibleActionFail as ae:
        display.display(ae)
    else:
        display.display("Success")

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 06:51:33.393889
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:51:34.558152
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-25 06:51:36.531383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()
    res_0 = ActionModule(var_0)
    return res_0


# Generated at 2022-06-25 06:52:25.586886
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '</>'
    tuple_0 = ()
    list_0 = None
    tuple_1 = (tuple_0, list_0)
    set_0 = set()
    int_0 = 130
    bytes_0 = b'\x9b6\xa5\x1f\x1e\x0f\xb1\x8c\x99B'
    str_1 = ';G'
    action_module_0 = ActionModule(str_0, tuple_1, set_0, int_0, bytes_0, str_1)
    assert action_module_0 != None


if __name__ == '__main__':
    test_case_0()
    test_ActionModule()
    print('Finished')

# Generated at 2022-06-25 06:52:33.023212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'tW,</?5'
    tuple_0 = ()
    list_0 = None
    tuple_1 = (tuple_0, list_0)
    set_0 = set()
    int_0 = 442
    bytes_0 = b'\x9b6\xa5\x1f\x1e\x0f\xb1\x8c\x99B'
    str_1 = ';G'
    action_module_0 = ActionModule(str_0, tuple_1, set_0, int_0, bytes_0, str_1)


# Generated at 2022-06-25 06:52:37.618553
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  try:
    # Import module containing the function to be tested
    import action.action_module
    
    # Bot up module class and pass arguments
    action_module_0 = action.action_module.ActionModule(str_0, tuple_1, set_0, int_0, bytes_0, str_1)
    
    # Call the method using arguments
    var_0 = action_module_0.run()

  except:
    raise


# Generated at 2022-06-25 06:52:45.662981
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ''
    tuple_0 = ()
    list_0 = None
    tuple_1 = (tuple_0, list_0)
    set_0 = set()
    int_0 = 111
    bytes_0 = b'\x84\xc1\xee\xbf\x1e\x02\xca\x00\xfe\x17'
    str_1 = ''
    action_module_0 = ActionModule(str_0, tuple_1, set_0, int_0, bytes_0, str_1)
    assert action_module_0 is not None


# Generated at 2022-06-25 06:52:51.696734
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'tW,</?5'
    tuple_0 = ()
    list_0 = None
    tuple_1 = (tuple_0, list_0)
    set_0 = set()
    int_0 = 442
    bytes_0 = b'\x9b6\xa5\x1f\x1e\x0f\xb1\x8c\x99B'
    str_1 = ';G'
    action_module_0 = ActionModule(str_0, tuple_1, set_0, int_0, bytes_0, str_1)
    var_0 = action_run()

# Generated at 2022-06-25 06:52:53.586612
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:53:02.705075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'tW,</?5'
    tuple_0 = ()
    list_0 = None
    tuple_1 = (tuple_0, list_0)
    set_0 = set()
    int_0 = 442
    bytes_0 = b'\x9b6\xa5\x1f\x1e\x0f\xb1\x8c\x99B'
    str_1 = ';G'
    action_module_0 = ActionModule(str_0, tuple_1, set_0, int_0, bytes_0, str_1)
    tuple_2 = (None, None)
    var_0 = action_module_0.run(tuple_2)
    assert var_0 is None

# Generated at 2022-06-25 06:53:11.475281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'tW,</?5'
    tuple_0 = ()
    list_0 = None
    tuple_1 = (tuple_0, list_0)
    set_0 = set()
    int_0 = 442
    bytes_0 = b'\x9b6\xa5\x1f\x1e\x0f\xb1\x8c\x99B'
    str_1 = ';G'
    action_module_0 = ActionModule(str_0, tuple_1, set_0, int_0, bytes_0, str_1)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:53:18.937826
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'tW,</?5'
    tuple_0 = ()
    list_0 = None
    tuple_1 = (tuple_0, list_0)
    set_0 = set()
    int_0 = 442
    bytes_0 = b'\x9b6\xa5\x1f\x1e\x0f\xb1\x8c\x99B'
    str_1 = ';G'
    action_module_0 = ActionModule(str_0, tuple_1, set_0, int_0, bytes_0, str_1)
    var_0 = action_module_0.run()

if __name__ == '__main__':
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 06:53:28.774031
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'K8\x10\x83\x9b\x86\x8c\xf0>V'
    tuple_0 = ()
    list_0 = None
    tuple_1 = (tuple_0, list_0)
    set_0 = set()
    int_0 = -2
    bytes_0 = b'\xe8\xf8\xe7\x0e\x1b\x8b\x1c\xd9'
    str_1 = '%c'
    action_module_0 = ActionModule(str_0, tuple_1, set_0, int_0, bytes_0, str_1)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:55:14.724435
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Setup
    str_0 = 'tW,</?5'
    tuple_0 = ()
    list_0 = None
    tuple_1 = (tuple_0, list_0)
    set_0 = set()
    int_0 = 442
    bytes_0 = b'\x9b6\xa5\x1f\x1e\x0f\xb1\x8c\x99B'
    str_1 = ';G'
    # Exercise
    action_module_0 = ActionModule(str_0, tuple_1, set_0, int_0, bytes_0, str_1)
    # Verify
    assert(isinstance(action_module_0.run(), dict))


# Generated at 2022-06-25 06:55:19.790281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Init a tmp directory because the constructor calls to _remove_tmp_path
    # Create the tmp directory
    if os.path.exists('tmp'):
        # Join the tmp to a full path
        tmp_path = os.path.join(os.getcwd(), 'tmp')
        # Delete the tmp directory
        os.removedirs(tmp_path)

# Generated at 2022-06-25 06:55:28.293050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '!n\xac\xd6\xc7\xaf'
    tuple_0 = ()
    list_0 = None
    tuple_1 = (tuple_0, list_0)
    set_0 = set()
    int_0 = 455
    bytes_0 = b'\x9c\x8d\x0el\xe7;\xc1\x8f\x10\xa1\x85\xd9\x8a\x001}'
    str_1 = 'c%+\xad\xbdaF\x1b\xe9'
    action_module_0 = ActionModule(str_0, tuple_1, set_0, int_0, bytes_0, str_1)

# Generated at 2022-06-25 06:55:37.129970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '3'
    tuple_0 = ()
    list_0 = None
    tuple_1 = (tuple_0, list_0)
    set_0 = set()
    int_0 = 0
    bytes_0 = b'\x1d5\x1c\x9f\xab\x13\xe0\xeb\xd1\x15\xad'
    str_1 = '9'
    action_module_0 = ActionModule(str_0, tuple_1, set_0, int_0, bytes_0, str_1)
    assert action_module_0 != None

# Generated at 2022-06-25 06:55:44.839247
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '@\xf0'
    tuple_1 = None
    set_0 = set()
    int_0 = 143
    bytes_0 = b'q\x07\xb3\xaeP\x01\xa3v\x19\xef\xba\xec\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 06:55:52.157439
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'tW,</?5'
    tuple_0 = ()
    list_0 = None
    tuple_1 = (tuple_0, list_0)
    set_0 = set()
    int_0 = 442
    bytes_0 = b'\x9b6\xa5\x1f\x1e\x0f\xb1\x8c\x99B'
    str_1 = ';G'
    action_module_0 = ActionModule(str_0, tuple_1, set_0, int_0, bytes_0, str_1)
    assert action_module_0.play_context is None
    assert action_module_0.connection is None
    assert action_module_0._loader is None
    assert action_module_0._templar is None

# Generated at 2022-06-25 06:55:53.267609
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Test constructor()')
# End of test for constructor of class ActionModule


# Generated at 2022-06-25 06:56:00.237343
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'tW,</?5'
    tuple_0 = ()
    list_0 = None
    tuple_1 = (tuple_0, list_0)
    set_0 = set()
    int_0 = 442
    bytes_0 = b'\x9b6\xa5\x1f\x1e\x0f\xb1\x8c\x99B'
    str_1 = ';G'
    str_2 = '<'
    bytes_1 = b'\xef\x94'
    dict_0 = {}
    str_3 = 'U'
    dict_0[str_3] = dict_1
    dict_1 = {}
    str_4 = 'eB%'
    dict_1[str_4] = str_5
    str_

# Generated at 2022-06-25 06:56:06.254066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'tW,</?5'
    tuple_0 = ()
    list_0 = None
    tuple_1 = (tuple_0, list_0)
    set_0 = set()
    int_0 = 442
    bytes_0 = b'\x9b6\xa5\x1f\x1e\x0f\xb1\x8c\x99B'
    str_1 = ';G'
    action_module_0 = ActionModule(str_0, tuple_1, set_0, int_0, bytes_0, str_1)


# Generated at 2022-06-25 06:56:08.133138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run() == var_0
