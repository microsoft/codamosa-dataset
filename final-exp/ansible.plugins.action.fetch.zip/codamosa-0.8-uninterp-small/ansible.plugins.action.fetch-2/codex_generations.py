

# Generated at 2022-06-25 06:47:17.215197
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:47:18.999055
# Unit test for constructor of class ActionModule
def test_ActionModule():
    target_0 = ActionModule(set_1)
    bool_0 = target_0.run()

# Generated at 2022-06-25 06:47:21.523728
# Unit test for constructor of class ActionModule
def test_ActionModule():
    testActionModule_0 = ActionModule()
    assert(testActionModule_0.display.verbosity == 2)

# Unit test to test if run() method works as expected

# Generated at 2022-06-25 06:47:33.089348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()

# Generated at 2022-06-25 06:47:34.059525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_0 = ActionModule()



# Generated at 2022-06-25 06:47:35.003578
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule()
    test_case_0()

# Generated at 2022-06-25 06:47:41.990269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    str_0 = "/tmp/ansible_fetch_payload_tfvyXb"
    dict_0 = {}
    dest = action_module_0.run(str_0, dict_0)
    assert dest == "Failed to fetch the file: [Errno 2] No such file or directory: '/tmp/ansible_fetch_payload_tfvyXb'"


# Generated at 2022-06-25 06:47:46.311900
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock connection object
    mock_connection_object = DummyConnection()
    # Create mock task object
    mock_task_object = DummyTask()
    # Create mock loader object
    mock_loader_object = DummyLoader()
    # Create mock display object
    mock_display_object = DummyDisplay()
    # Create mock console object
    mock_console_object = DummyConsole()
    # Create mock play context object
    mock_play_context_object = DummyPlayContext()
    # Create temp dir
    tmp = '/tmp/tmpFklr2x'
    # Create temp file
    tmp_file = '/tmp/tmpFklr2x/dest'

    # Create mock remote stat object
    mock_remote_stat_object = DummyRemoteStat()
    # Create mock module object

# Generated at 2022-06-25 06:47:56.200906
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize an instance of class ActionModule
    action_module_obj = ActionModule()
    # Set the following attributes of class ActionModule
    action_module_obj.action = "ActionModule"
    action_module_obj.display = "Display"
    action_module_obj.name = "ActionModule"
    action_module_obj.args = "ActionModule"
    action_module_obj.action_loader = None
    action_module_obj.module_name = "ActionModule"
    action_module_obj.module_args = "ActionModule"
    action_module_obj.playbook = "ActionModule"
    action_module_obj.connection = "ActionModule"
    action_module_obj.task = "ActionModule"
    action_module_obj.task_vars = "ActionModule"
    action_module_obj

# Generated at 2022-06-25 06:48:05.760479
# Unit test for constructor of class ActionModule
def test_ActionModule():
    source = "source"
    original_dest = dest = "dest"
    flat = boolean("true", strict=False)
    fail_on_missing = boolean("true", strict=False)
    validate_checksum = boolean("true", strict=False)
    actionModule = ActionModule(source=source, original_dest=original_dest, dest=dest, flat=flat, fail_on_missing=fail_on_missing, validate_checksum=validate_checksum)
    assert isinstance(actionModule, ActionModule)
    actionModule.run(tmp=None, task_vars=None)


# Generated at 2022-06-25 06:48:27.103684
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Now it will throw exception, as in order to test run method we need to
    # make the following attributes to be assigned with some value.
    action_module = ActionModule()
    action_module.run()

# Generated at 2022-06-25 06:48:28.146134
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # make sure class constructor is called
    test_case_0()

# Generated at 2022-06-25 06:48:31.122428
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

test_ActionModule_run()

# Generated at 2022-06-25 06:48:32.568402
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:48:38.215796
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Add your test here
    action_module_0 = ActionModule()

    tmp = None
    task_vars = None

    try:
        action_module_0.run(tmp, task_vars)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 06:48:39.437309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert_raises(TypeError, ActionModule)


# Generated at 2022-06-25 06:48:40.834732
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # TODO: Implement unit test
    pass


# Generated at 2022-06-25 06:48:41.590858
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 06:48:43.237710
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(">> Start test_ActionModule")
    action_module = ActionModule()
    print(">> End test_ActionModule")


# Generated at 2022-06-25 06:48:48.159208
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:49:14.467322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 8478
    list_0 = [int_0]
    str_0 = 'uRgpO_co>'
    tuple_0 = None
    action_module_0 = ActionModule(int_0, list_0, str_0, list_0, int_0, tuple_0)
    bool_0 = False
    answer_1 = action_module_0.run(bool_0)
    answer_2 = {'failed': False, 'changed': False}
    assert answer_1 == answer_2


# Generated at 2022-06-25 06:49:20.923441
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        int_0 = 3695
        list_0 = [int_0]
        str_0 = 'uRgpO_co>'
        tuple_0 = None
        action_module_0 = ActionModule(int_0, list_0, str_0, list_0, int_0, tuple_0)
        #implicit __init__ call
        #__init__ call with True as arg
        #__init__ call with True and False as args
    except BaseException as error0:
        print('Exception caught: ', error0)


# Generated at 2022-06-25 06:49:25.408365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3695
    list_0 = [int_0]
    str_0 = 'uRgpO_co>'
    tuple_0 = None
    action_module_0 = ActionModule(int_0, list_0, str_0, list_0, int_0, tuple_0)
    bool_0 = False
    var_0 = action_module_0.run(bool_0)


# Generated at 2022-06-25 06:49:27.899702
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test: 0
    _run(test_case_0)


# Generated at 2022-06-25 06:49:36.083993
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for the default value of constructor
    int_0 = 3231
    list_0 = [int_0]
    str_0 = '+n|LqXz\\b'
    tuple_0 = None
    action_module_0 = ActionModule(int_0, list_0, str_0, list_0, int_0, tuple_0)
    # Test for user-provided values of constructor
    int_0 = 8137
    list_0 = [int_0]
    str_0 = '1^`yL$}aN'
    tuple_0 = None
    action_module_0 = ActionModule(int_0, list_0, str_0, list_0, int_0, tuple_0)


# Generated at 2022-06-25 06:49:40.579072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '4'
    list_0 = ['4']
    str_1 = '5'
    list_1 = ['5']
    int_0 = 4
    tuple_0 = None
    action_module_0 = ActionModule(int_0, list_0, str_0, list_1, int_0, tuple_0)
    dict_0 = dict()
    action_module_0.run(dict_0, dict_0)


# Generated at 2022-06-25 06:49:43.877468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 5409
    list_0 = [int_0]
    str_0 = 'MSm,VP:B'
    tuple_0 = None
    action_module_0 = ActionModule(int_0, list_0, str_0, list_0, int_0, tuple_0)
    action_module_0.run()

# Generated at 2022-06-25 06:49:50.813855
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
        print('\033[32mTestcase[0]')
    except:
        raise Exception('\033[31mException in testcase[0]!!!')
    try:
        test_case_1()
        print('\033[32mTestcase[1]')
    except:
        raise Exception('\033[31mException in testcase[1]!!!')


# Generated at 2022-06-25 06:50:00.813050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for ActionModule.run
    action_module_0 = ActionModule()
    assert action_module_0.run() == ''
    assert action_module_0.run() == ''
    assert action_module_0.run() == ''
    assert action_module_0.run() == ''
    assert action_module_0.run() == ''
    assert action_module_0.run() == ''
    assert action_module_0.run() == ''
    assert action_module_0.run() == ''
    assert action_module_0.run() == ''
    assert action_module_0.run() == ''
    assert action_module_0.run() == ''
    assert action_module_0.run() == ''
    assert action_module_0.run() == ''
    assert action_module_0.run

# Generated at 2022-06-25 06:50:02.545692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Case 0
    test_case_0()


# Generated at 2022-06-25 06:50:40.840485
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 06:50:44.977172
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3695
    list_0 = [int_0]
    str_0 = 'uRgpO_co>'
    tuple_0 = None
    action_module_0 = ActionModule(int_0, list_0, str_0, list_0, int_0, tuple_0)
    assert action_module_0 is not None

# Generated at 2022-06-25 06:50:49.496336
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 6976
    list_0 = [int_0]
    str_0 = ')MkwS<Q='
    tuple_0 = [int_0]
    action_module_0 = ActionModule(int_0, list_0, str_0, list_0, int_0, tuple_0)
    bool_0 = True
    assert bool_0


# Generated at 2022-06-25 06:50:56.945474
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3695
    list_0 = [int_0]
    str_0 = 'uRgpO_co>'
    tuple_0 = None
    action_module_0 = ActionModule(int_0, list_0, str_0, list_0, int_0, tuple_0)
    assert action_module_0 != False



# Generated at 2022-06-25 06:51:03.651269
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 6659
    list_0 = [int_0]
    str_0 = '=9Pwex4De'
    tuple_0 = None
    try:
        # Construct action module object
        action_module_0 = ActionModule(int_0, list_0, str_0, list_0, int_0, tuple_0)
    except Exception:
        print("Exception when constructing object of class ActionModule")


# Generated at 2022-06-25 06:51:07.629267
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for test_case_0
    # Tests for the case where the user does not provide any arguments
    # A tuple with the int 0, list 0 and string 0 are passed to the constructor
    # All of these arguments should be initialized correctly and the instance should be created
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:51:12.238797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 5094
    list_0 = [int_0]
    str_0 = 'iqpBb0#GY'
    tuple_0 = None
    action_module_0 = ActionModule(int_0, list_0, str_0, list_0, int_0, tuple_0)
    bool_0 = False
    action_module_0.run(var_0)


# Generated at 2022-06-25 06:51:14.222925
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        assert False
    except:
        print("Unhandled exception")


# Generated at 2022-06-25 06:51:19.415858
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Calling method run of class ActionModule')
    int_0 = 81
    list_0 = [int_0]
    str_0 = '&j6^'
    tuple_0 = None
    action_module_0 = ActionModule(int_0, list_0, str_0, list_0, int_0, tuple_0)
    bool_0 = True
    var_0 = action_module_0.run(bool_0)
    print('var_0 is:', var_0)


# Generated at 2022-06-25 06:51:28.658824
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # First test case - init class and run method

    # Case 1 - check if is instance of ActionModule

    int_1 = 55955
    list_0 = [int_1]
    str_1 = 'x?b~*F'
    tuple_1 = (None, None, [])
    action_module_1 = ActionModule(int_1, list_0, str_1, list_0, int_1, tuple_1)
    tmp = None

# Generated at 2022-06-25 06:52:43.238541
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ( action_module_0, bool_0, var_0 ) = test_ActionModule_var_0()
    assert ( isinstance(action_module_0, ActionModule) )
    assert ( isinstance(var_0, dict) )
    assert ( bool_0 )


# Generated at 2022-06-25 06:52:49.666133
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    int_0 = 3695
    list_0 = [int_0]
    str_0 = 'uRgpO_co>'
    tuple_0 = None
    action_module_0 = ActionModule(int_0, list_0, str_0, list_0, int_0, tuple_0)

    bool_0 = False
    var_0 = action_module_0.run(bool_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 06:52:53.210527
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 3695
    list_0 = [int_0]
    str_0 = 'uRgpO_co>'
    tuple_0 = None
    action_module_0 = ActionModule(int_0, list_0, str_0, list_0, int_0, tuple_0)
    bool_0 = False
    var_0 = action_module_0.run(bool_0)
    assert var_0 == False

# Generated at 2022-06-25 06:52:54.122114
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:52:56.712600
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule('src', 'dest')
    except Exception as e:
        print(e)


# Generated at 2022-06-25 06:53:04.866411
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 0
    list_0 = list()
    str_0 = 'Bn8V=+'
    tuple_0 = tuple()
    action_module_0 = ActionModule(int_0, list_0, str_0, list_0, int_0, tuple_0)
    assert action_module_0._play_context.check_mode is False
    assert action_module_0._task.args.get('src', None) is None
    assert action_module_0._task.args.get('dest', None) is None
    assert action_module_0._task.args.get('flat', None) is None
    assert action_module_0._task.args.get('fail_on_missing', True) is True

# Generated at 2022-06-25 06:53:11.718099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with valid values
    int_0 = 3695
    list_0 = [int_0]
    str_0 = 'uRgpO_co>'
    tuple_0 = None
    action_module_0 = ActionModule(int_0, list_0, str_0, list_0, int_0, tuple_0)
    tmp = None
    task_vars = None
    res = action_module_0.run(tmp, task_vars)
    assert res == 0


# Generated at 2022-06-25 06:53:19.351323
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '8WSlM'
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    # test_case_0()
    # test_case_0()
    # test_case_0()
    # test_case_0()
    # test_case_0()
    # test_case_0()
    # test_case_0()
    # test_case_0()
    # test_case_0()
    # test_case_0()
   

# Generated at 2022-06-25 06:53:27.145342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 3695
    list_0 = [int_0]
    str_0 = 'uRgpO_co>'
    tuple_0 = None
    action_module_0 = ActionModule(int_0, list_0, str_0, list_0, int_0, tuple_0)
    bool_0 = False
    var_0 = action_module_0.run(bool_0)
    test_case_0()


# Generated at 2022-06-25 06:53:29.335776
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == "__main__":
    try:
        test_ActionModule()
    except Exception as e:
        print(e)

# Generated at 2022-06-25 06:56:56.718781
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3695
    list_0 = [int_0]
    str_0 = 'uRgpO_co>'
    tuple_0 = None
    action_module_0 = ActionModule(int_0, list_0, str_0, list_0, int_0, tuple_0)
    assert action_module_0._task == int_0
    assert action_module_0._connection == list_0
    assert action_module_0._play_context == str_0
    assert action_module_0.loader == list_0
    assert action_module_0._templar == int_0
    assert action_module_0.shared_loader_obj == tuple_0


# Generated at 2022-06-25 06:57:02.394753
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3695
    list_0 = [int_0]
    str_0 = 'uRgpO_co>'
    tuple_0 = None
    action_module_0 = ActionModule(int_0, list_0, str_0, list_0, int_0, tuple_0)
    assert action_module_0.should_retry == False
    assert action_module_0.always_run == False
    assert action_module_0.connection == 3695
    assert action_module_0.become_method == None
    assert action_module_0.async_val == 0
    assert action_module_0.sudo is False
    assert action_module_0.sudo_user == None
    assert action_module_0.remote_user == None
    assert action_module_0.module_name