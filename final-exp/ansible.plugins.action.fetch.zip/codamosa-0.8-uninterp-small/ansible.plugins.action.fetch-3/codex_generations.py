

# Generated at 2022-06-25 06:47:23.972525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 't'
    list_0 = [str_0]
    bool_0 = True
    action_module_0 = ActionModule(str_0, list_0, bool_0, list_0, list_0, set('n'))
    action_module_0.run()


# Generated at 2022-06-25 06:47:34.209907
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'vdsk}` '
    list_0 = [str_0, str_0]
    bool_0 = True
    set_0 = {list_0, bool_0, list_0}
    action_module_0 = ActionModule(str_0, list_0, bool_0, list_0, list_0, set_0)
    str_1 = '   '
    dict_0 = {str_1, str_1}
    dict_1 = dict_0
    ansible_action_fail_0 = AnsibleActionFail(str_1, dict_1)
    list_1 = [str_0, str_0]
    ansible_action_skip_0 = AnsibleActionSkip(list_1)
    str_2 = '   '
    dict_2 = dict_1
   

# Generated at 2022-06-25 06:47:41.982597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'vfqw.i'
    str_1 = '#Qv'
    str_2 = '-mailbox-name'
    str_3 = '@QId'
    str_4 = '-mailbox-inactive'
    str_5 = 'xu'
    str_6 = '-mailbox-greeting'
    str_7 = 'u'
    str_8 = '-mailbox-password'
    str_9 = 'ld'
    str_10 = '-mailbox-options'
    str_11 = '-F'
    str_12 = '-mailbox-order'


# Generated at 2022-06-25 06:47:52.834599
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'tZN'
    list_0 = [str_0, str_0]
    bool_0 = False
    set_0 = {list_0, bool_0, list_0}
    action_module_2 = ActionModule(str_0, list_0, bool_0, list_0, list_0, set_0)
    assert action_module_2._task.action == str_0
    assert action_module_2._task.args == list_0
    assert action_module_2._task.delegate_to == bool_0
    assert action_module_2._task.delegate_facts == list_0
    assert action_module_2._task.notify == list_0
    assert action_module_2._task.tags == set_0


# Generated at 2022-06-25 06:47:57.631678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'user'
    list_0 = [str_0, str_0]
    str_1 = 'bogus'
    list_1 = ['n3o', 'n3o', str_0, 'n3o']
    set_0 = {'n3o'}
    action_module_0 = ActionModule(str_0, list_0, str_1, list_1, list_1, set_0)



# Generated at 2022-06-25 06:48:03.952467
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Source to fetch, dest is where to save it, flat will change its
    # final location to just be the basename in dest.
    action_module_0 = ActionModule()
    action_module_0.run('src', 'dest', False)


# Generated at 2022-06-25 06:48:04.864545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # No test available
    assert True


# Generated at 2022-06-25 06:48:09.663267
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('\nUnit test for constructor of class ActionModule')
    test_case_0()
    print('Unit test for constructor of class ActionModule done')

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 06:48:17.239037
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with argument str_0, list_0, bool_0, list_0, list_0, set_0
    # Tests with non-default values of args
    str_0 = 'vdsk}` '
    list_0 = [str_0, str_0]
    bool_0 = True
    set_0 = {list_0, bool_0, list_0}
    action_module_0 = ActionModule(str_0, list_0, bool_0, list_0, list_0, set_0)
    # Test member variables are set correctly
    assert action_module_0._display.verbosity == 2
    assert action_module_0._options == {}
    assert action_module_0._connection == 'local'
    assert action_module_0._task.name == 'vdsk}` '

# Generated at 2022-06-25 06:48:20.577250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'vdsk}` '
    list_0 = [str_0, str_0]
    bool_0 = True
    set_0 = {list_0, bool_0, list_0}
    action_module_0 = ActionModule(str_0, list_0, bool_0, list_0, list_0, set_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 06:48:42.636510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize tmp, task_vars to None
    tmp = None
    task_vars = None
    # Call constructor with tmp and task_vars as None
    action_module_0 = ActionModule(tmp, task_vars)
    # Call constructor with tmp as an int and task_vars as a string
    action_module_1 = ActionModule(tmp, task_vars)
    # Call constructor with tmp as a dict and task_vars as a list
    action_module_2 = ActionModule(tmp, task_vars)


# Generated at 2022-06-25 06:48:43.420942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:48:48.304257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    str_0 = str(dict_0)
    str_1 = str(dict_0)
    str_2 = str(dict_0)
    str_3 = str(dict_0)
    str_4 = str(dict_0)
    str_5 = str(dict_0)
    str_6 = str(dict_0)
    dict_1 = dict()
    str_7 = str(dict_0)
    str_8 = str(dict_0)
    str_9 = str(dict_0)
    str_10 = str(dict_0)
    dict_2 = dict()
    str_11 = str(dict_0)
    str_12 = str(dict_0)
    str_13 = str(dict_0)

# Generated at 2022-06-25 06:48:49.524902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(ActionModule.run())


# Generated at 2022-06-25 06:48:51.366351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize the object
    test_case_0()

# Generated at 2022-06-25 06:49:02.053603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x17\xbd\xf7\xad\x83'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = True
    bytes_1 = b'\xe9\x0b'
    str_0 = '*\x0b#QtF-}O\\e8\n|x'
    str_1 = "E?C'}?\x0c"
    action_module_0 = ActionModule(bytes_0, dict_0, bool_0, bytes_1, str_0, str_1)
    action_module_0.run()


# Generated at 2022-06-25 06:49:07.779423
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {'x1': '8', 'x2': '7'}
    action_module_0 = ActionModule('hk', dict_0, True, 'f', '6', 'y')
    assert action_module_0._task.args == {'src': 'hk', 'dest': 'y', 'fail_on_missing': '6', 'flat': 'f', 'validate_checksum': None}
    assert action_module_0._task == 'y'
    assert action_module_0._connection == 'f'
    assert action_module_0._play_context.become == True
    assert action_module_0._play_context.become_user == '6'
    assert action_module_0._play_context.remote_addr == 'hk'
    assert action_module_0._play

# Generated at 2022-06-25 06:49:10.150958
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 06:49:18.542077
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = True
    bytes_1 = b'\xe9\x0b'
    str_0 = '*\x0b#QtF-}O\\e8\n|x'
    str_1 = "E?C'}?\x0c"
    action_module_0 = ActionModule(bytes_0, dict_0, bool_0, bytes_1, str_0, str_1)
    action_module_0.run()


# Generated at 2022-06-25 06:49:26.924506
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'RH/\x0c\x1e\x14'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = True
    bytes_1 = b'\'\n\n\x11'
    str_0 = '3\x06'
    str_1 = '\r\r\r\r\r\r\r\r'
    action_module_0 = ActionModule(bytes_0, dict_0, bool_0, bytes_1, str_0, str_1)
    assert action_module_0 is not None


# Generated at 2022-06-25 06:50:05.101490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing method constructor of ActionModule')
    bytes_0 = b''
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = True
    bytes_1 = b'\xe9\x0b'
    str_0 = '*\x0b#QtF-}O\\e8\n|x'
    str_1 = "E?C'}?\x0c"
    action_module_0 = ActionModule(bytes_0, dict_0, bool_0, bytes_1, str_0, str_1)


# Generated at 2022-06-25 06:50:12.301476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x03d'
    dict_0 = {}
    bool_0 = False
    bytes_1 = b'\x1a\x1a\x1a\x1aj\x1a\x1a\x1a\x1a'
    str_0 = "r\x1c\x1c\x1c\x1c\x1b\x1c\x1c\x1c\x1c"
    str_1 = "c\x1c\x1c\x1c\x1cy\x1c\x1c\x1c\x1c"
    action_module_0 = ActionModule(bytes_0, dict_0, bool_0, bytes_1, str_0, str_1)
    var_0 = action_run()

# Generated at 2022-06-25 06:50:19.026289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = True
    bytes_1 = b'\xe9\x0b'
    str_0 = '*\x0b#QtF-}O\\e8\n|x'
    str_1 = "E?C'}?\x0c"
    assert_equals(ActionModule(bytes_0, dict_0, bool_0, bytes_1, str_0, str_1)._task, bytes_0)
    assert_equals(ActionModule(bytes_0, dict_0, bool_0, bytes_1, str_0, str_1)._connection, dict_0)

# Generated at 2022-06-25 06:50:26.454181
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = True
    bytes_1 = b'\xe9\x0b'
    str_0 = '*\x0b#QtF-}O\\e8\n|x'
    str_1 = "E?C'}?\x0c"
    action_module_0 = ActionModule(bytes_0, dict_0, bool_0, bytes_1, str_0, str_1)
    assert_equal(action_module_0.task_vars, dict_0)
    assert_equal(action_module_0.connection, None)

# Generated at 2022-06-25 06:50:37.144654
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = True
    bytes_1 = b'\xe9\x0b'
    str_0 = '*\x0b#QtF-}O\\e8\n|x'
    str_1 = "E?C'}?\x0c"
    action_module_1 = ActionModule(bytes_0, dict_0, bool_0, bytes_1, str_0, str_1)
    dict_1 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}

# Generated at 2022-06-25 06:50:46.616788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_2 = b'\xa3\x1c!\xdd\xff\x13\xd5\xde\xb1\x04\x82\x0e\x9c\x1e\xf9'
    dict_1 = {bytes_2: bytes_2}
    bool_1 = True
    bytes_3 = b'\x82v/\x8b8o\xf4\x10\x13\xb8\xe7\x89\xaa\x17'
    str_2 = 'A^\xfcV\xeb\x8a\xea!\xec', '\xef\x9d\xad\x0b'
    action_module_1 = ActionModule(bytes_2, dict_1, bool_1, bytes_3, str_2, str_2)

# Generated at 2022-06-25 06:50:53.563206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = True
    bytes_1 = b'\xe9\x0b'
    str_0 = '*\x0b#QtF-}O\\e8\n|x'
    str_1 = "E?C'}?\x0c"
    action_module_0 = ActionModule(bytes_0, dict_0, bool_0, bytes_1, str_0, str_1)
    action_module_0.get_file_size_remote(action_module_0)


# Generated at 2022-06-25 06:51:00.853061
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'Q\x1f;l\x0b\x19'
    dict_0 = {}
    bool_0 = True
    bytes_1 = b'Y\x7f'
    str_0 = '\x17\x0f\x07^\x1e\x1f'
    str_1 = '\x17\x0f\x07^\x1e\x1f'
    action_module_0 = ActionModule(bytes_0, dict_0, bool_0, bytes_1, str_0, str_1)
    var_0 = action_module_0.run(dict_0, dict_0)

    # Test if statement returns false

# Generated at 2022-06-25 06:51:08.742562
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = True
    bytes_1 = b'\xe9\x0b'
    str_0 = '*\x0b#QtF-}O\\e8\n|x'
    str_1 = "E?C'}?\x0c"
    action_module_0 = ActionModule(bytes_0, dict_0, bool_0, bytes_1, str_0, str_1)


# Generated at 2022-06-25 06:51:17.268544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x1a\x0e\x00\x06\n/\x1a\x0e\x12\n\x04\x04N\x14\x12\x02\x04\x04'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = True
    bytes_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 06:52:32.023142
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xb0\x1a\xce'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = True
    bytes_1 = b'\xe9\x0b'
    str_0 = '*\x0b#QtF-}O\\e8\n|x'
    str_1 = "E?C'}?\x0c"
    action_module_0 = ActionModule(bytes_0, dict_0, bool_0, bytes_1, str_0, str_1)
    assert action_module_0.dest == "E?C'}?\x0c"

# Generated at 2022-06-25 06:52:32.868346
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('test ActionModule')



# Generated at 2022-06-25 06:52:40.008769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x07\xf7\x0c<\x0e\xb1`n\xb3wp'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = False

# Generated at 2022-06-25 06:52:47.592518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x1f\xa4\xfb$'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = True
    bytes_1 = b'\xb6\x0f\x18\xc7\x06\t'
    str_0 = ')\xa2\xcd\xae{\x16'
    str_1 = "G{l?#\x1a\xbf\x16\x75\xa6\x82"
    action_module_0 = ActionModule(bytes_0, dict_0, bool_0, bytes_1, str_0, str_1)
    with raises(NotImplementedError) as excinfo:
        action_module

# Generated at 2022-06-25 06:52:55.771346
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xe3\x8d'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = True
    bytes_1 = b'\xe9\x0b'
    str_0 = '*\x0b#QtF-}O\\e8\n|x'
    str_1 = "E?C'}?\x0c"
    action_module_0 = ActionModule(bytes_0, dict_0, bool_0, bytes_1, str_0, str_1)
    var_0 = action_run()


# Generated at 2022-06-25 06:52:57.662347
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('test_ActionModule_run()')


# Generated at 2022-06-25 06:53:05.474569
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = True
    bytes_1 = b'\xe9\x0b'
    str_0 = '*\x0b#QtF-}O\\e8\n|x'
    str_1 = "E;C'}?\x0c"
    action_module_0 = ActionModule(bytes_0, dict_0, bool_0, bytes_1, str_0, str_1)
    var_0 = action_run()
    assert isinstance(var_0, dict)
    if (var_0):
        assert var_0.get("changed") is False

# Generated at 2022-06-25 06:53:15.445405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x9dD\xa0\x0b\xb6\xfd\x94\x1d\x1b+\xba\x9e.\xe2\xcc\xf2\xa1\x14y\xde\x03\xfc\x9c\x8a'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = True
    bytes_1 = b'\xe9\x0b'
    str_0 = '*\x0b#QtF-}O\\e8\n|x'
    str_1 = "E?C'}?\x0c"

# Generated at 2022-06-25 06:53:26.151951
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert len(action_module_0._connection.conn_path) != 0
    assert len(action_module_0._connection.remote_user) != 0
    assert len(action_module_0._connection.private_key_file) != 0
    assert len(action_module_0._connection.become_method) != 0
    assert len(action_module_0._connection.become) != 0
    assert len(action_module_0._connection.become_user) != 0
    assert len(action_module_0._connection.become_pass) != 0
    assert len(action_module_0._connection._shell) != 0
    assert len(action_module_0._task.delegate_to) != 0
    assert len(action_module_0._task.loop)

# Generated at 2022-06-25 06:53:27.840576
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 06:56:25.552420
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 06:56:29.751589
# Unit test for constructor of class ActionModule
def test_ActionModule():
    i = 0
    while i <= 0:
        test_case_0()
        i += 1

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 06:56:39.055701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = True
    bytes_1 = b'\xe9\x0b'
    str_0 = '*\x0b#QtF-}O\\e8\n|x'
    str_1 = "E?C'}?\x0c"
    action_module_0 = ActionModule(bytes_0, dict_0, bool_0, bytes_1, str_0, str_1)
    var_0 = action_run()

# Generated at 2022-06-25 06:56:50.326596
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''
    dict_0 = {}
    bool_0 = True
    bytes_1 = b'\xe9\x0b'
    str_0 = '*\x0b#QtF-}O\\e8\n|x'
    str_1 = "E?C'}?\x0c"
    action_module_0 = ActionModule(bytes_0, dict_0, bool_0, bytes_1, str_0, str_1)
    dict_0 = {'dest': 'b\x19\x13U\x1f\x1a', 'src': '\x0bs\x0b>\x1a'}
    test_case_0()



# Generated at 2022-06-25 06:56:57.838858
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = True
    bytes_1 = b'\xe9\x0b'
    str_0 = '*\x0b#QtF-}O\\e8\n|x'
    str_1 = "E?C'}?\x0c"
    action_module_0 = ActionModule(bytes_0, dict_0, bool_0, bytes_1, str_0, str_1)
# This function is only accessible to ActionModule, the function is not accessible to other packages

# Generated at 2022-06-25 06:57:00.391692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Calls the constructor of ActionModule
    # Assigning the return value of the object instance to a variable
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:57:09.790695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''