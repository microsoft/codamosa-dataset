

# Generated at 2022-06-25 06:47:15.561852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:47:26.857813
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'QO^k8Wq'
    float_0 = 0.5618203347452534
    bool_0 = True
    bool_1 = 1

# Generated at 2022-06-25 06:47:35.452091
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:47:36.988367
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:47:47.925924
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'DYM'
    float_0 = 0.909896991679
    bool_0 = True
    bool_1 = False
    bytes_0 = b'{'
    str_1 = 'T'
    action_module_0 = ActionModule(str_0, float_0, bool_0, bool_1, bytes_0, str_1)
    action_module_1 = ActionModule(str_1, float_0, bool_0, bool_1, bytes_0, str_1)
    action_module_2 = ActionModule(str_0, float_0, bool_1, bool_1, bytes_0, str_0)
    action_module_3 = ActionModule(str_0, float_0, bool_1, bool_0, bytes_0, str_0)
    action

# Generated at 2022-06-25 06:47:57.295984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_1 = True
    bytes_2 = b'eTIr'
    int_1 = test_case_0()
    test_case_0()
    # params is a dict of {'a': 'b'}, so access params['a'] and test if it is 'b'
    assert action_module_0.params['a'] == 'b'
    action_module_0.set_action_plugin()
    action_module_0.get_action_plugin()
    action_module_0.setup()
    action_module_0.exception_handler()
    action_module_0._executor()
    action_module_0._load_params()
    action_module_0._low_level_execute_command()
    action_module_0._low_level_run_command()
    action_module_0._

# Generated at 2022-06-25 06:47:59.834792
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:48:00.982959
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:48:03.999986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:48:14.209896
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        str_0 = "Invalid become method specified, could not find matching plugin: '%s'. Use `ansible-doc -t become -l` to list available plugins."
        float_0 = 0.5
        bool_0 = False
        bool_1 = False
        bytes_0 = b'='
        str_1 = "Invalid become method specified, could not find matching plugin: '%s'. Use `ansible-doc -t become -l` to list available plugins."
        action_module_0 = ActionModule(str_0, float_0, bool_0, bool_1, bytes_0, str_0)
        action_module_0.run()
    except Exception as exception_0:
        print(exception_0)


# Generated at 2022-06-25 06:48:42.404774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    _mock_executor = MockExecutor()
    display = Display()

    task = Task()
    task.args = {"dest": "/home/user1/test3.txt", "src": "/home/user1/test1.txt", "validate_checksum": "no", "flat": "false"}
    setattr(task, '_host', {"name": "test_host"})

    task_vars = {"connection": "Mock", "ansible_check_mode": "False"}

    tmp_path = '/home/user1/ansible-temp/ansible-tmp-1573041307.79-82426284918990/source'
    setattr(task, '_connection', _mock_executor)

    action_module = ActionModule()
    setattr(action_module, "_task", task)

# Generated at 2022-06-25 06:48:43.168869
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 06:48:44.685464
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert type(x) == ActionModule
    #assert x.str == 'test string'


# Generated at 2022-06-25 06:48:48.938614
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('src', 'dest', 'flat', 'validate_checksum')
    assert action_module_0.run() == dict(
        _ansible_no_log=None,
        _ansible_parsed=True,
        _ansible_verbose_always=True,
        changed=False,
        checksum='d41d8cd98f00b204e9800998ecf8427e',
        dest='dest',
        file='src',
        md5sum=None), "ActionModule.run() returned unexpected value"



# Generated at 2022-06-25 06:48:51.992391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # check for output of run function,
    # assert run function's output matches the file content
    pass

# Generated at 2022-06-25 06:48:53.659391
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module != None

# Generated at 2022-06-25 06:49:03.644590
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        # setup action module
        action_module = ActionModule()
        action_module.set_loader(DictDataLoader({
                      "fetch.yaml": "# action: rawdata here"
                  }))

        # test with valid input
        result = action_module.run({'foo': 'bar'})
        assert result == {'rawdata': '', 'stdout': '', 'stdout_lines': []}, "action_module run failed with valid input."

        # test with invalid input
        result = action_module.run({'foo': {}})
        assert result == {'rawdata': '', 'stdout': '', 'stdout_lines': []}, "action_module run failed with invalid input."

    except Exception as ex:
        assert False, "unexpected exception %s" % ex

import unittest

# Generated at 2022-06-25 06:49:08.082180
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    source = 'ansible_test.txt'
    dest = 'ansible_test.txt'

# Generated at 2022-06-25 06:49:18.900989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    action_module_0._play_context = None
    action_module_0.get_bin_path = MagicMock()
    action_module_0.get_bin_path.return_value = '/bin/foo'
    action_module_0._remote_expand_user = MagicMock()
    action_module_0._remote_expand_user.return_value = 'foo'
    action_module_0._execute_remote_stat = MagicMock()
    action_module_0._execute_remote_stat.return_value = 'foo'
    action_module_0._execute_module = MagicMock()
    action_module_0._execute_module.return_value = 'foo'
    action

# Generated at 2022-06-25 06:49:24.707087
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    
    action_module_0 = ActionModule()
    copy_module_0 = copy.copy(action_module_0)
    copy_module_1 = copy.deepcopy(action_module_0)



# Generated at 2022-06-25 06:49:54.012084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = None
    float_0 = -683.854404
    float_1 = None
    float_2 = -1127.0
    dict_0 = {float_1: action_module_0, action_module_0: float_2}
    int_0 = 126
    action_module_1 = ActionModule(action_module_0, float_0, float_1, action_module_0, dict_0, int_0)
    action_module_1.run()
    bytes_0 = b'\xc3\xf0\x0b\x00\x9f'
    str_0 = 'No package {0} available.'
    tuple_0 = ()
    int_1 = 1182
    list_0 = [int_1, int_1, int_1]
    action_

# Generated at 2022-06-25 06:50:01.574233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    float_0 = -683.854404
    float_1 = None
    float_2 = -1127.0
    dict_0 = {float_1: action_module_0, action_module_0: float_2}
    int_0 = 126
    action_module_1 = ActionModule(action_module_0, float_0, float_1, action_module_0, dict_0, int_0)
    action_module_2 = None
    bool_0 = action_module_1.run(action_module_2)
    bool_1 = False
    assert bool_1 == bool_0
    action_module_0 = None
    float_0 = -683.854404
    float_1 = None
    float_2 = -1127.0
    dict

# Generated at 2022-06-25 06:50:11.432459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    float_0 = -683.854404
    float_1 = None
    float_2 = -1127.0
    dict_0 = {float_1: action_module_0, action_module_0: float_2}
    int_0 = 126
    action_module_1 = ActionModule(action_module_0, float_0, float_1, action_module_0, dict_0, int_0)
    bytes_0 = b'\xc3\xf0\x0b\x00\x9f'
    str_0 = 'No package {0} available.'
    tuple_0 = ()
    int_1 = 1182
    list_0 = [int_1, int_1, int_1]

# Generated at 2022-06-25 06:50:13.890990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 06:50:14.867619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME: test this
    pass

# Generated at 2022-06-25 06:50:24.973059
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = None
    float_0 = -683.854404
    float_1 = None
    float_2 = -1127.0
    dict_0 = {float_1: action_module_0, action_module_0: float_2}
    int_0 = 126
    action_module_1 = ActionModule(action_module_0, float_0, float_1, action_module_0, dict_0, int_0)
    try:
        raise ValueError
    except ValueError:
        str_0 = "%(this_is_a_var)s"
    action_module_2 = ActionModule(str_0)


# Generated at 2022-06-25 06:50:28.527305
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 06:50:38.207941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    float_0 = -683.854404
    float_1 = None
    float_2 = -1127.0
    dict_0 = {float_1: action_module_0, action_module_0: float_2}
    int_0 = 126
    action_module_1 = ActionModule(action_module_0, float_0, float_1, action_module_0, dict_0, int_0)
    bytes_0 = b'\xc3\xf0\x0b\x00\x9f'
    str_0 = 'No package {0} available.'
    tuple_0 = ()
    int_1 = 1182
    list_0 = [int_1, int_1, int_1]

# Generated at 2022-06-25 06:50:39.063413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:50:40.005083
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:51:24.958326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    str_0 = '4\x7f\x1c\x7f\x06\x13\xe6\xe5\x7f'
    str_1 = "text'\n"
    dict_0 = None
    dict_1 = {str_0: str_1, str_1: dict_0}
    int_0 = -14.9
    int_1 = 0
    int_2 = -18
    action_module_1 = ActionModule(action_module_0, dict_0, int_0, dict_1, int_1, int_2)
    list_0 = []
    action_module_1.run(list_0)

# Generated at 2022-06-25 06:51:28.587858
# Unit test for constructor of class ActionModule
def test_ActionModule():
  pass


# Generated at 2022-06-25 06:51:30.098219
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    # Unit test for constructor of class ActionModule
    test_ActionModule()

# Generated at 2022-06-25 06:51:35.835607
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import io
    import sys
    import unittest

    global display
    display = Display()
    display.verbosity = 1
    test_case_0()

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 06:51:40.313247
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = None
    float_0 = 703.46747817
    float_1 = None
    float_2 = None
    dict_0 = {float_1: action_module_0, action_module_0: float_2}
    int_0 = 180
    action_module_1 = ActionModule(action_module_0, float_0, float_1, action_module_0, dict_0, int_0)


# Generated at 2022-06-25 06:51:50.441752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    float_0 = -683.854404
    float_1 = None
    float_2 = -1127.0
    dict_0 = {float_1: action_module_0, action_module_0: float_2}
    int_0 = 126
    action_module_1 = ActionModule(action_module_0, float_0, float_1, action_module_0, dict_0, int_0)
    bytes_0 = b'\xc3\xf0\x0b\x00\x9f'
    str_0 = 'No package {0} available.'
    tuple_0 = ()
    int_1 = 1182
    list_0 = [int_1, int_1, int_1]

# Generated at 2022-06-25 06:51:53.061771
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:52:01.382641
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_3 = None
    float_3 = -123.83875
    float_4 = None
    float_5 = -1631.0
    dict_2 = {float_4: action_module_3, action_module_3: float_5}
    int_3 = 116
    action_module_4 = ActionModule(action_module_3, float_3, float_4, action_module_3, dict_2, int_3)
    bytes_1 = b'\x9a\x9d\xce\xe6\xac'
    str_1 = 'No package {0} available.'
    tuple_1 = ()
    int_4 = 1210
    list_1 = [int_4, int_4, int_4]

# Generated at 2022-06-25 06:52:04.221224
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # type_0 = AnsibleActionSkip(str_0, bytes_0, list_0, action_module_0)
    action_module_1 = ActionModule(str_0, bytes_0, list_0, action_module_0)


# Generated at 2022-06-25 06:52:14.457181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    float_0 = -683.854404
    float_1 = None
    float_2 = -1127.0
    dict_0 = {float_1: action_module_0, action_module_0: float_2}
    int_0 = 126
    action_module_1 = ActionModule(action_module_0, float_0, float_1, action_module_0, dict_0, int_0)
    bytes_0 = b'\xc3\xf0\x0b\x00\x9f'
    str_0 = 'No package {0} available.'
    tuple_0 = ()
    int_1 = 1182
    list_0 = [int_1, int_1, int_1]

# Generated at 2022-06-25 06:53:37.199617
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_3 = None
    float_3 = -639.70493
    float_4 = None
    float_5 = -1670.0
    dict_1 = {float_4: action_module_3, action_module_3: float_5}
    int_2 = 314
    action_module_4 = ActionModule(action_module_3, float_3, float_4, action_module_3, dict_1, int_2)
    bytes_1 = b'\xc3\xf0\x0b\x00\x9f'
    str_1 = 'No package {0} available.'
    tuple_1 = ()
    int_3 = 1182
    list_1 = [int_3, int_3, int_3]

# Generated at 2022-06-25 06:53:42.606181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    float_0 = -683.854404
    float_1 = None
    float_2 = -1127.0
    dict_0 = {float_1: action_module_0, action_module_0: float_2}
    int_0 = 126
    action_module_1 = ActionModule(action_module_0, float_0, float_1, action_module_0, dict_0, int_0)
    bytes_0 = b'\xc3\xf0\x0b\x00\x9f'
    str_0 = 'No package {0} available.'
    tuple_0 = ()
    int_1 = 1182
    list_0 = [int_1, int_1, int_1]

# Generated at 2022-06-25 06:53:52.084833
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    float_0 = -683.854404
    float_1 = None
    float_2 = -1127.0
    dict_0 = {float_1: action_module_0, action_module_0: float_2}
    int_0 = 126
    action_module_1 = ActionModule(action_module_0, float_0, float_1, action_module_0, dict_0, int_0)
    action_module_0 = False
    bytes_0 = b'\xc3\xf0\x0b\x00\x9f'
    str_0 = 'No package {0} available.'
    tuple_0 = ()
    int_1 = 1182
    list_0 = [int_1, int_1, int_1]
    action_module

# Generated at 2022-06-25 06:53:58.639325
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #
    # output = dict(
    #     md5sum = None,
    #     dest = os.path.join(dest, target_name, source_local),
    #     checksum = 'sha1$b895f2cbf7967b7d3e09ddad8edc888a971e988d',
    #     remote_checksum = 'sha1$b895f2cbf7967b7d3e09ddad8edc888a971e988d',
    #     changed = False,
    #     file = source,

    action_module_0 = None
    float_0 = -683.854404
    float_1 = None
    float_2 = -1127.0

# Generated at 2022-06-25 06:54:09.013131
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    float_0 = -683.854404
    float_1 = None
    float_2 = -1127.0
    dict_0 = {float_1: action_module_0, action_module_0: float_2}
    int_0 = 126
    action_module_1 = ActionModule(action_module_0, float_0, float_1, action_module_0, dict_0, int_0)
    bytes_0 = b'\xc3\xf0\x0b\x00\x9f'
    str_0 = 'No package {0} available.'
    tuple_0 = ()
    int_1 = 1182
    list_0 = [int_1, int_1, int_1]

# Generated at 2022-06-25 06:54:19.219553
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_3 = None
    float_3 = -683.854404
    float_4 = None
    float_5 = -1127.0
    dict_1 = {float_4: action_module_3, action_module_3: float_5}
    int_2 = 126
    action_module_4 = ActionModule(action_module_3, float_3, float_4, action_module_3, dict_1, int_2)
    bytes_1 = b'\xc3\xf0\x0b\x00\x9f'
    str_1 = 'No package {0} available.'
    tuple_1 = ()
    int_3 = 1182
    list_1 = [int_3, int_3, int_3]

# Generated at 2022-06-25 06:54:27.062843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = None
    float_0 = -683.854404
    float_1 = None
    float_2 = -1127.0
    dict_0 = {float_1: action_module_0, action_module_0: float_2}
    int_0 = 126
    action_module_1 = ActionModule(action_module_0, float_0, float_1, action_module_0, dict_0, int_0)
    bytes_0 = b'\xc3\xf0\x0b\x00\x9f'
    str_0 = 'No package {0} available.'
    tuple_0 = ()
    int_1 = 1182
    list_0 = [int_1, int_1, int_1]

# Generated at 2022-06-25 06:54:37.115686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    float_0 = -683.854404
    float_1 = None
    float_2 = -1127.0
    dict_0 = {float_1: action_module_0, action_module_0: float_2}
    int_0 = 126
    action_module_2 = ActionModule(action_module_0, float_0, float_1, action_module_0, dict_0, int_0)
    bytes_0 = b'\xc3\xf0\x0b\x00\x9f'
    str_0 = 'No package {0} available.'
    tuple_0 = ()
    int_1 = 1182
    list_0 = [int_1, int_1, int_1]

# Generated at 2022-06-25 06:54:40.042919
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 06:54:49.999035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    float_0 = -683.854404
    float_1 = None
    float_2 = -1127.0
    dict_0 = {float_1: action_module_0, action_module_0: float_2}
    int_0 = 126
    action_module_1 = ActionModule(action_module_0, float_0, float_1, action_module_0, dict_0, int_0)
    bytes_0 = b'\xc3\xf0\x0b\x00\x9f'
    str_0 = 'No package {0} available.'
    tuple_0 = ()
    int_1 = 1182
    list_0 = [int_1, int_1, int_1]