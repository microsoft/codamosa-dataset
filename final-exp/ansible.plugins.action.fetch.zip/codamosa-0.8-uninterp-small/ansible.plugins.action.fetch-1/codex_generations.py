

# Generated at 2022-06-25 06:47:19.663079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing if raises error on accessing read-only attribute dest
    # This is needed for backwards compatibility reasons
    try:
        action_module_0 = ActionModule(None, {}, {}, 0, 0, 0)
        action_module_0.dest
        assert False
    except RuntimeError as exception:
        assert str(exception) == "Attempted to access protected member 'dest' of ActionModule object"
        assert True
    test_case_0()


# Generated at 2022-06-25 06:47:31.754066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create mock for the class 'ActionBase' and parameters 'loader', 'connection'
    # and 'templar'
    action_base_0 = ActionBase(None, None, None)
    # Create mock for the class 'ComplexModule' and its method 'run'
    complex_module_0 = mock.Mock(spec=ComplexModule)
    complex_module_0.run.return_value = None
    # Create the object instance
    action_module_0 = ActionModule(action_base_0, complex_module_0, None, display)
    # Create mock for the class 'TaskExecutor' and its method 'run'
    task_executor_0 = mock.Mock(spec=TaskExecutor)
    task_executor_0.run.return_value = None
    # Process the run function for the object instance


# Generated at 2022-06-25 06:47:40.988771
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    int_0 = None
    float_0 = -875.9
    action_module_0 = ActionModule(complex_0, dict_0, dict_0, int_0, float_0, int_0)
    str_0 = '&{+yq'
    dict_1 = {str_0: str_0}
    # self.assertRaises(AnsibleActionFail, action_module_0.run, str_0, str_0)
    # self.assertRaises(AnsibleActionFail, action_module_0.run, str_0, str_0, str_0)
    # self.assertRaises(AnsibleActionFail, action_module_0.run, str

# Generated at 2022-06-25 06:47:42.034522
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:47:42.524546
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 1 == 1

# Generated at 2022-06-25 06:47:48.554209
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    int_0 = None
    float_0 = -875.9
    action_module_0 = ActionModule(complex_0, dict_0, dict_0, int_0, float_0, int_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 06:47:50.813003
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(True, {}, {}, {}, {}, 8)
    action_module_0.run()


# Generated at 2022-06-25 06:47:55.044136
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    dict_0 = {complex_0: complex_0, complex_0: complex_0}
    int_0 = None
    float_0 = -875.9
    action_module_0 = ActionModule(complex_0, dict_0, dict_0, int_0, float_0, int_0)


# Generated at 2022-06-25 06:48:06.215069
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:48:12.979555
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global dict_0, list_0, float_0, int_0, bool_0
    global complex_0

    # Test initializes
    complex_0 = complex(-0, -0)
    dict_0 = {}
    list_0 = [bool_0, bool_0, bool_0]
    float_0 = 6.539796071568339
    int_0 = -1
    bool_0 = False

    # Call test_case_0
    test_case_0()

    # Test for execption
    try:
        pass
    except:
        assert False


# Generated at 2022-06-25 06:48:38.676158
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing constructor")
    # Test with default args
    complex_1 = None
    bytes_1 = b't'
    bool_1 = True
    dict_1 = {bool_1: bool_1, complex_1: bool_1}
    tuple_1 = (complex_1, bytes_1, bool_1, dict_1)
    set_1 = {bytes_1}
    float_1 = 669.1
    int_1 = -1570
    action_module_1 = ActionModule(tuple_1, set_1, set_1, tuple_1, float_1, int_1)
    # Test with custom args
    complex_3 = int_1
    bytes_3 = b"\x82\x9e\xa9X"
    bool_2 = False

# Generated at 2022-06-25 06:48:45.080186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    bytes_0 = b'E"\x9d-w\xa6'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -3677.88597
    int_0 = 1583
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)
    var_0 = action_run()


# Generated at 2022-06-25 06:48:50.392622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test data
    tmp = None
    task_vars = None
    complex_0 = None
    bytes_0 = b'E"\x9d-w\xa6'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -3677.88597
    int_0 = 1583
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)
    var_0 = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:49:00.422671
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    bytes_0 = b'E"\x9d-w\xa6'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -3677.88597
    int_0 = 1583
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)

    assert(isinstance(action_module_0, ActionModule))


# Generated at 2022-06-25 06:49:06.359443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    bytes_0 = b'E"\x9d-w\xa6'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -3677.88597
    int_0 = 1583
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:49:15.715741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    bytes_0 = b'E"\x9d-w\xa6'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -3677.88597
    int_0 = 1583
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)
    assert (action_module_0.run() != None)

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 06:49:21.988647
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    bytes_0 = b'\x8cQ\xc1\x9c'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -2667.382524
    int_0 = 925
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:49:28.078293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test data
    complex_1 = None
    bytes_1 = b'E"\x9d-w\xa6'
    bool_1 = True
    dict_1 = {bool_1: bool_1, complex_1: bool_1}
    tuple_1 = (complex_1, bytes_1, bool_1, dict_1)
    set_1 = {bytes_1}
    float_1 = -3677.88597
    int_1 = 1583
    action_module_1 = ActionModule(tuple_1, set_1, set_1, tuple_1, float_1, int_1)
    set_2 = set_1
    action_module_1.run(tmp, task_vars)
    assert tmp == set_2

# Generated at 2022-06-25 06:49:36.798727
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    bytes_0 = b'E"\x9d-w\xa6'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -3677.88597
    int_0 = 1583
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)
    dict_0 = dict()
    dict_1 = {'src': None, 'dest': None}
    var_0 = action_module_0.run(dict_0, dict_1)

# Generated at 2022-06-25 06:49:43.866264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('test_ActionModule_run:')
    complex_0 = None
    bytes_0 = b"\x1F\x1A\x8C\x0A\x0E\xE7\x8A<'\xE5\xC2\xADF\xD5\xEC\x9F\x17\x8D\x05\xB4x\xD4\x8D\x1E\x97\xE3\xB8\x5E\xA3\x08\xB2\xC8\xB9\xAA\x1F\xC7\x1A\x04"
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}

# Generated at 2022-06-25 06:50:20.730773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    bytes_0 = b'E"\x9d-w\xa6'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -3677.88597
    int_0 = 1583
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)
    # assert action_module_0
    tmp = None
    task_vars = None
    assert (action_module_0.run(tmp, task_vars) != None)


# Generated at 2022-06-25 06:50:27.917754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # default, no args
    ActionModule()

    # args: tuple_0, set_0, set_0, tuple_0, float_0, int_0
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)


# Generated at 2022-06-25 06:50:37.340941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = 3 - 8j
    bytes_0 = b'\x91\x17\x8b\xe4\x0e\x0f\x9b\xda\xa3\xed\x02\xee\xdc\xb3\xcc.\x9b&\xe8\xcf\xd2\xf6'
    bool_0 = False
    dict_0 = {bool_0: complex_0, complex_0: complex_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -6.1687217783
    int_0 = 35

# Generated at 2022-06-25 06:50:45.166713
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    bytes_0 = b'E"\x9d-w\xa6'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -3677.88597
    int_0 = 1583
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)
    assert action_module_0


# Generated at 2022-06-25 06:50:47.666353
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        assert True
    except AssertionError as e:
        print(e)
        print(e.__traceback__)
    finally:
        pass


# Generated at 2022-06-25 06:50:50.099495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case available
    if isinstance(action, ActionModule):
        # Test case available
        if True:
            action.run()
    else:
        # Test case not available
        assert False

# Generated at 2022-06-25 06:50:58.957111
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(action_module_0) == ActionModule
    assert isinstance(action_module_0, ActionBase) == True
    assert action_module_0.task_vars == set_0
    assert action_module_0.task_vars == set_0
    assert action_module_0.tmp == tuple_0
    assert action_module_0.task_name == tuple_0
    assert action_module_0.play_context.diff_mode == bool_0
    assert action_module_0.play_context.remote_addr == int_0


# Generated at 2022-06-25 06:51:03.470472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_0 = None
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(module_0, tmp_0, task_vars_0)
    result_0 = action_module_0.run(tmp_0, task_vars_0)

    assert result_0


# Generated at 2022-06-25 06:51:10.755780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    bytes_0 = b'E"\x9d-w\xa6'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -3677.88597
    int_0 = 1583

    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:51:18.698737
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    bytes_0 = b'E"\x9d-w\xa6'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -3677.88597
    int_0 = 1583
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)
    var_0 = action_run()



# Generated at 2022-06-25 06:52:29.557855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    bytes_0 = b'\x04\x0f\x8bx\x85'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -3677.88597
    int_0 = 1583
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)
    var_0 = action_run(fail_on_missing=False)
    var_0 = action_run()
    var_0 = action_run(tmp=None, task_vars=None)

# Generated at 2022-06-25 06:52:33.909036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    param_0 = None
    param_1 = None
    action_module_0 = ActionModule(param_0, param_0, param_0, param_0, param_0, param_0)
    param_2 = None
    param_3 = None
    var_0 = action_module_0.run(param_2, param_3)



# Generated at 2022-06-25 06:52:38.413074
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    bytes_0 = b'E"\x9d-w\xa6'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -3677.88597
    int_0 = 1583
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)
    var_0 = action_module_0.run(tmp=None, task_vars=None)
    assert var_0 == None


if __name__ == "__main__":
    test_ActionModule_run

# Generated at 2022-06-25 06:52:42.862885
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    bytes_0 = b'E"\x9d-w\xa6'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -3677.88597
    int_0 = 1583
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)
    action_run()


# Generated at 2022-06-25 06:52:51.870227
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    bytes_0 = b'E"\x9d-w\xa6'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -3677.88597
    int_0 = 1583
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)
    var_0 = action_run(dict)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:53:00.909142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    bytes_0 = b'E"\x9d-w\xa6'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -3677.88597
    int_0 = 1583
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)
    str_0 = action_module_0.run()

# Generated at 2022-06-25 06:53:09.157827
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ('src', 'dest')
    set_0 = {True}
    set_1 = {'src'}
    tuple_1 = ()
    float_0 = 0.2429091934052094
    int_0 = -97
    action_module_0 = ActionModule(tuple_0, set_0, set_1, tuple_1, float_0, int_0)
    var_0 = action_module_0.run()
    assert var_0 is None


# Generated at 2022-06-25 06:53:13.300851
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    command = "cat /etc/passwd"
    c = Connection("localhost", port=2201)
    c.connect()
    # TODO: capture_stdout?
    out = c.exec_command("/usr/bin/python", stdin=command)
    c.close()
    print(out)

# Generated at 2022-06-25 06:53:18.472688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run() == False

# Generated at 2022-06-25 06:53:28.857661
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = (None, b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00', False, {})

# Generated at 2022-06-25 06:56:15.536369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    bytes_0 = b'E"\x9d-w\xa6'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -3677.88597
    int_0 = 1583
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:56:24.303238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    bytes_0 = b'i\x81\xec\x0b\x13\xb7\x0b\xcc\x9b'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -45.4
    int_0 = 25
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 06:56:31.152472
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    bytes_0 = b'E"\x9d-w\xa6'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -3677.88597
    int_0 = 1583
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)


# Generated at 2022-06-25 06:56:40.725834
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    bytes_0 = b'E"\x9d-w\xa6'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -3677.88597
    int_0 = 1583
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)

# Generated at 2022-06-25 06:56:46.648084
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialise mock objects
    tmp = None
    task_vars = None

    # Call the run method of the class with the mock objects.
    result = action_module_0.run(tmp, task_vars)
    # Check if the methods were called as expected.
    assert(1 == 1)

# Generated at 2022-06-25 06:56:54.921220
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    bytes_0 = b'E"\x9d-w\xa6'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -3677.88597
    int_0 = 1583
    action_module_0 = ActionModule(tuple_0, set_0, set_0, tuple_0, float_0, int_0)


# Generated at 2022-06-25 06:57:01.764369
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    bytes_0 = b'\x89\xb5\x8f\xfd\xa9\xfc\x80\xe0\x8f\x87\x89\x8d\x8c\x9b\x9e\xbd\x8d\xac\xfc\x94\x84\x8d\xf9\x9b\xe6\xaf\xaf\xbc\x87\xb6\x8c\xc7\xe9'
    bool_0 = True
    dict_0 = {bool_0: bool_0, complex_0: bool_0}
    tuple_0 = (complex_0, bytes_0, bool_0, dict_0)
    set_0 = {bytes_0}
    float_0 = -3677.88