

# Generated at 2022-06-25 06:47:29.792359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = 2249.916
    set_0 = {dict_0}
    bytes_0 = b'\x85\xeb\x17SX\x18\x13y\xc0\xcf\x87\x95\x04}\x98\xab\xcbJMf'
    action_module_0 = ActionModule(dict_0, float_0, set_0, dict_0, bytes_0, dict_0)
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_2['task_vars'] = dict_3
    dict_2['cache'] = dict_4

# Generated at 2022-06-25 06:47:34.925571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = 2249.916
    set_0 = {dict_0}
    bytes_0 = b'\x85\xeb\x17SX\x18\x13y\xc0\xcf\x87\x95\x04}\x98\xab\xcbJMf'
    action_module_0 = ActionModule(dict_0, float_0, set_0, dict_0, bytes_0, dict_0)
    assert action_module_0


# Generated at 2022-06-25 06:47:42.458748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = 2249.916
    set_0 = {dict_0}
    bytes_0 = b'\x85\xeb\x17SX\x18\x13y\xc0\xcf\x87\x95\x04}\x98\xab\xcbJMf'
    action_module_0 = ActionModule(dict_0, float_0, set_0, dict_0, bytes_0, dict_0)
    tmp = ''
    task_vars = {'dest': 'src', 'src': 'src', 'flat': 'flat'}
    var_0 = action_module_0.run(tmp, task_vars)
    var_1 = var_0
    print(var_1)


# Generated at 2022-06-25 06:47:50.480206
# Unit test for constructor of class ActionModule
def test_ActionModule():
  dict_0 = {}
  float_0 = 2249.916
  set_0 = {dict_0}
  bytes_0 = b'\x85\xeb\x17SX\x18\x13y\xc0\xcf\x87\x95\x04}\x98\xab\xcbJMf'
  action_module_0 = ActionModule(dict_0, float_0, set_0, dict_0, bytes_0, dict_0)

if __name__ == '__main__':
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 06:47:56.992796
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = 2249.916
    set_0 = {dict_0}
    bytes_0 = b'\x85\xeb\x17SX\x18\x13y\xc0\xcf\x87\x95\x04}\x98\xab\xcbJMf'
    action_module_0 = ActionModule(dict_0, float_0, set_0, dict_0, bytes_0, dict_0)
    var_0 = action_module_0.run()
    assert var_0 == None

# Generated at 2022-06-25 06:48:00.931364
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = 2249.916
    set_0 = {dict_0}
    bytes_0 = b'\x85\xeb\x17SX\x18\x13y\xc0\xcf\x87\x95\x04}\x98\xab\xcbJMf'
    action_module_0 = ActionModule(dict_0, float_0, set_0, dict_0, bytes_0, dict_0)


# Generated at 2022-06-25 06:48:10.518411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    float_0 = 6652.25371877
    set_0 = {dict_0}
    bytes_0 = b'\xd6\xce\xc1\xc2\x8c\x06\x9e\x7f\xf0\x83L\xce\xed\x0b\x8f\x89\xa9\x84\x06\x8a\xd2\x1c%\xc1\x9f\x1f'
    action_module_0 = ActionModule(dict_0, float_0, set_0, dict_0, bytes_0, dict_0)

# Generated at 2022-06-25 06:48:16.455502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    float_0 = 2249.916
    set_0 = {dict_0}
    bytes_0 = b'\x85\xeb\x17SX\x18\x13y\xc0\xcf\x87\x95\x04}\x98\xab\xcbJMf'
    action_module_0 = ActionModule(dict_0, float_0, set_0, dict_0, bytes_0, dict_0)


# Generated at 2022-06-25 06:48:17.100670
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    utils.test_case_0()

test_ActionModule_run()

# Generated at 2022-06-25 06:48:17.584299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return 0

# Generated at 2022-06-25 06:48:36.505968
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:48:37.620575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_0 = ActionModule()


# Generated at 2022-06-25 06:48:39.135248
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:48:40.550779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    test_case_0()



# Generated at 2022-06-25 06:48:41.925774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    # Not called with _do_setup
    #print(module)


# Generated at 2022-06-25 06:48:42.440077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0

# Generated at 2022-06-25 06:48:45.040037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create new instance of ActionModule class
    obj_instance = ActionModule()



# Generated at 2022-06-25 06:48:47.581908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # case
    actionmodule.run(tmp=None, task_vars=None)

# Generated at 2022-06-25 06:48:49.658058
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:48:53.610214
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-25 06:49:15.724486
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:49:23.215970
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    str_1 = 'str_1'
    str_2 = 'str_2'
    ansible_action_fail_3 = AnsibleActionFail('ansibleactionfail_3')
    ansible_error_4 = AnsibleError('ansibleerror_4')
    dict_5 = dict()
    str_6 = 'str_6'
    boolean_7 = boolean('bool_7')
    ansible_action_skip_8 = AnsibleActionSkip('ansibleactionskip_8')

# Generated at 2022-06-25 06:49:26.995832
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    return


# Generated at 2022-06-25 06:49:32.257653
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with empty input
    module = ActionModule()

    # Test with empty string variables
    str_var = ""
    module = ActionModule(str_var)

    # Test with string variables
    str_var = "test"
    module = ActionModule(str_var)

    # Test with integer variables
    int_var = 0
    module = ActionModule(int_var)

    # Test with boolean variables
    bool_var = True
    module = ActionModule(bool_var)

# Generated at 2022-06-25 06:49:33.205721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:49:34.944187
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    action_module_run = ActionModule().run(task_vars)

    assert action_module_run is not None

# Generated at 2022-06-25 06:49:36.009205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 0
    test_case_0()



# Generated at 2022-06-25 06:49:38.071763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    temp_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-25 06:49:43.115247
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''constructor of class ActionModule'''
    ActionModule()


# Generated at 2022-06-25 06:49:54.266649
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:50:34.609193
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:50:36.347417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_instance = ActionModule()
    action_module_instance.run()


# Generated at 2022-06-25 06:50:37.878945
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    test_case_0()

# Generated at 2022-06-25 06:50:38.717201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()
# end of run

# Generated at 2022-06-25 06:50:42.082331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    source = "src"
    tmp = None
    task_vars = dict(a="b")
    result = dict(c="d")

    am = ActionModule()
    am.run(source, tmp, task_vars)


# Generated at 2022-06-25 06:50:43.768865
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        # setup
        test_ActionModule = ActionModule()

        # execution
        test_ActionModule.run()

        # testing
        assert True
    except:
        assert False


# Generated at 2022-06-25 06:50:52.114197
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # setup
    actionmodule = ActionModule();
    actionmodule._task.args = dict(src = 'src', dest = 'dest', fail_on_missing = True, validate_checksum = True)
    actionmodule._task.action = 'fetch'

    actionmodule._play_context.check_mode = False
    actionmodule._connection.become = False
    remote_checksum = '22'
    remote_stat = dict()
    remote_stat['checksum'] = remote_checksum
    remote_stat['exists'] = True
    remote_stat['isdir'] = True

    expected_result = dict(failed = True, changed = False, msg = 'remote file is a directory, fetch cannot work on directories', file = 'src', dest = None)

    # action

# Generated at 2022-06-25 06:50:56.358563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dest = "dest"
    source = "source"
    flat = "flat"
    fail_on_missing = "fail_on_missing"
    validate_checksum = "validate_checksum"
    # test
    int_0 = 0


# Generated at 2022-06-25 06:51:03.563085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test = ActionModule()
    assert test.run(tmp=None, task_vars=None) == {'remote_checksum': None, 'md5sum': None, 'dest': 'C:/Ansible/ansible/common/fetch.py', 'file': 'fetch.py', 'changed': False, 'checksum': '0ae8e7c43e57ac33f923c2cc1a2bfc90'}


# Generated at 2022-06-25 06:51:12.608593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # Check that function is present
    try:
        assert hasattr(ActionModule, 'run')
    except AssertionError as e:
        raise AssertionError("Method 'run' not found on class ActionModule")
    else:
        pass
    
    # Check if run can be called
    try:
        assert callable(ActionModule.run)
    except AssertionError as e:
        raise AssertionError("Function 'run' on class ActionModule not callable")
    else:
        pass
    
    # Check if call without any arguments raises exception
    try:
        ActionModule.run()
    except TypeError as e:
        pass
    else:
        raise Exception("Function 'run' on class ActionModule accepts no arguments")
        
    # Check if call with correct arguments does not raise exception

# Generated at 2022-06-25 06:52:26.512919
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:52:34.408520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4
    int_5 = 5
    int = int_1 + int_2 + int_3 + int_4 + int_5
    int_6 = 6
    int_7 = 7
    int_8 = 8
    int_9 = 9
    if int_6 < int_7:
        if int_6 < int_8:
            int_0 = test_case_0(int_8, int_5, int_2)
        else:
            int_0 = test_case_0(int_9, int_0, int_1)


# Generated at 2022-06-25 06:52:40.987137
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_list = [{'tmp': None, 'task_vars': None}]
    test_case_list[0]['tmp'] = None
    test_case_list[0]['task_vars'] = None
    test_case_list.append({'tmp': None, 'task_vars': None})
    test_case_list[1]['tmp'] = None
    test_case_list[1]['task_vars'] = None
    test_case_list.append({'tmp': None, 'task_vars': None})
    test_case_list[2]['tmp'] = None
    test_case_list[2]['task_vars'] = None
    test_case_list.append({'tmp': None, 'task_vars': None})

# Generated at 2022-06-25 06:52:48.346837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.fetch
    fetch_0 = ansible.plugins.action.fetch.ActionModule(connection='connection', play_context='play_context', new_stdin='new_stdin', loader='loader', templar='templar', shared_loader_obj='shared_loader_obj')
    int_0 = 0


# Generated at 2022-06-25 06:52:49.274050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    test_case_0()
    return True

# Generated at 2022-06-25 06:52:50.848134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    # Test case for method run of class ActionModule
    # case 0
    result = action_module.run((0,))

# Generated at 2022-06-25 06:52:55.975212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("TEST: test_ActionModule")
    int_0 = 0
    dict_0 = dict()
    dict_1 = dict()
    obj_0 = ActionModule(int_0, dict_0, dict_1)
    assert obj_0 != None, "TEST: ActionModule object was not created!"

# Generated at 2022-06-25 06:53:04.747894
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule_0 = ActionModule()
    if actionmodule_0.__class__.__name__ != "ActionModule":
        err_msg = "Unit test for constructor of class ActionModule"
        err_msg += " Method Name: " + sys._getframe().f_code.co_name
        raise Exception(err_msg)
    else:
        if  actionmodule_0.__class__.__name__ != "ActionModule":
            err_msg = "Unit test for constructor of class ActionModule"
            err_msg += " Method Name: " + sys._getframe().f_code.co_name
            raise Exception(err_msg)
        else:
            test_case_0()
            return 

if __name__ == '__main__':
    import sys
    sys.exit(test_ActionModule())

# Generated at 2022-06-25 06:53:06.103501
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing constructor of ActionModule")
    int_0 = 0


# Generated at 2022-06-25 06:53:11.390035
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule()
    print("In test_ActionModule")
    t.run("/tmp", "Ansible")
    t.run("\", \"Ansible", "Ansible")
    t.run("/tmp", "\"Ansible")

if __name__ == "__main__":
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 06:56:30.584670
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 0
    try:
        ActionModule()
    except Exception as err:
        print(str(err))
        assert 0
    finally:
        print('test finished successfully')



# Generated at 2022-06-25 06:56:33.066122
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test_case_0
    int_0 = 0
    str_0 = '0'
    # test_case_0:case_0
    int_0 = 0
    str_0 = '0'
    str_1 = '0'
    bool_0 = False


# Generated at 2022-06-25 06:56:41.653491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define the testing input
    params = {"validate_checksum": True, "src": "src_parm_0", "dest": "dest_parm_1", "flat": False,
              "fail_on_missing": True}

    # Define the expected result
    expected = {"md5sum": None, "file": "src_parm_0", "checksum": "-1234567890", "remote_checksum": "-1234567890",
                "dest": "/tmp/ansible_testcase_0/host_0/src_parm_0", "changed": False, "remote_md5sum": None}

    # Create the object of class ActionModule
    ActionModule_object = ActionModule(params, {}, {}, {}, {})

    # run the run method of ActionModule class and get actual result
    result

# Generated at 2022-06-25 06:56:48.650002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        int_0 = 0
        str_0 = '0'
        str_1 = '1'
        str_2 = '2'

        action_module = ActionModule()

        action_module._execute_module(module_name = str_0, module_args = {}, task_vars = {'0': int_0})
    except Exception as e:
        assert False, str(e)



# Generated at 2022-06-25 06:56:51.987576
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (ActionModule(connection="connection",
                        play_context="play_context",
                        loader="loader",
                        templar="templar",
                        shared_loader_obj="shared_loader_obj"))
    # assert test_case_0()



# Generated at 2022-06-25 06:56:58.960802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule()
    result = action_module_obj.run(tmp=None, task_vars=None)
    assert result is None, "When a potential bug was fixed this test may start failing as a side effect. In such case please check the failure reason. Possible reasons: 1. ActionModule.run() call is changed and this test assumes that the changed method would not return anything. 2. ActionModule.run() returned None because of another bug. "


# Generated at 2022-06-25 06:57:07.454154
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test without fail_when_source_missing and source exists
    with patch("ia_ansible_fetch.ActionModule._connection.fetch_file") as fetch_file_mock:
        with patch("ia_ansible_fetch.ActionModule._execute_remote_stat") as remote_stat_mock:
            with patch("ia_ansible_fetch.ActionModule._loader.path_dwim") as path_dwim_mock:
                with patch("ia_ansible_fetch.ActionModule._execute_module") as execute_module_mock:
                    with patch("ia_ansible_fetch.makedirs_safe") as makedirs_mock:
                        execute_module_mock.return_value = {'encoding': 'base64', 'content': "dGVzdA=="}
                       