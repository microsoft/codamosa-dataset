

# Generated at 2022-06-25 06:47:30.097390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    str_0 = 'skZ\nQ-'
    bool_0 = True
    action_module_0 = ActionModule(int_0, int_0, bool_0, str_0, int_0, bool_0)

    # Arguments for the run method
    # tmp - Type: None
    # task_vars - Type: dict
    test_run_0 = dict()

    # Stub method call of the run method
    def test_run_mock(tmp, task_vars):
        return test_run_0
    ActionModule.run = test_run_mock
    results_0 = action_module_0.run(int_0, test_run_0)

    # TODO: verify results



# Generated at 2022-06-25 06:47:31.125871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_case_0 :
    test_case_0()

# Generated at 2022-06-25 06:47:35.500477
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = None
    str_0 = 'skZ\nQ-'
    bool_0 = True
    action_module_0 = ActionModule(int_0, int_0, bool_0, str_0, int_0, bool_0)


# Generated at 2022-06-25 06:47:45.738620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    str_0 = 'skZ\nQ-'
    bool_0 = True
    action_module_0 = ActionModule(int_0, int_0, bool_0, str_0, int_0, bool_0)
    str_1 = 'k_'
    dict_0 = dict()
    dict_0.clear()
    dict_1 = dict(str_1='zXt')
    dict_2 = dict()
    dict_2.clear()
    dict_2['str_1'] = 'zXt'

    dict_0['str_1'] = 'zXt'
    dict_0['str_1'] = 'zXt'


# Generated at 2022-06-25 06:47:46.992801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule.run")
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 06:47:48.648673
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Call test_case_0
    test_case_0()


# Generated at 2022-06-25 06:47:52.410213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    str_0 = '7'
    bool_0 = True
    action_module_0 = ActionModule(int_0, int_0, bool_0, str_0, int_0, bool_0)
    action_module_0.run()

# Generated at 2022-06-25 06:47:54.055715
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = None
    str_0 = 'n'
    bool_0 = True
    action_module_0 = ActionModule(int_0, int_0, bool_0, str_0, int_0, bool_0)

# Generated at 2022-06-25 06:47:57.223093
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = None
    str_0 = 'skZ\nQ-'
    bool_0 = True
    action_module_0 = ActionModule(int_0, int_0, bool_0, str_0, int_0, bool_0)


# Generated at 2022-06-25 06:47:59.835852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:48:27.950332
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "'_GqWlW~@|\n"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)
    test_case_0()
    test_case_1()    
    

# Generated at 2022-06-25 06:48:35.653819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "'_GqWlW~@|\n"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)


# Generated at 2022-06-25 06:48:42.275272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "'_GqWlW~@|\n"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)
    assert action_module_1



# Generated at 2022-06-25 06:48:48.505654
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x01`\x01<\x01\xab\x04\xa7\x9f\x19\x9d\x1b\x97\xce\xbe\x02'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = '\x01`\x01<\x01\xab\x04\xa7\x9f\x19\x9d\x1b\x97\xce\xbe\x02'
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)
    float_0 = -2750.0
    var_0 = action_module_1

# Generated at 2022-06-25 06:49:00.264390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "'_GqWlW~@|\n"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)
    bool_2 = True
    var_3 = action_module_1.run(bool_2)
    # Validate var_3 is of type dict
    assert isinstance(var_3, dict)
    # Validate if var_3 has the keys['msg', 'failed', 'changed', 'file']
   

# Generated at 2022-06-25 06:49:09.906135
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    str_0 = ''
    task_vars_0 = dict(
        bytes_0=str_0
    )
    bool_0 = True
    action_module_0 = ActionModule(list_0, list_0, bool_0, bool_0, str_0, list_0)
    var_0 = action_module_0.run(list_0, task_vars_0)
    dict_0 = dict(
        file='src',
        failed=True,
        msg='src and dest are required'
    )
    dict_1 = var_0
    assert dict_1 == dict_0


# Generated at 2022-06-25 06:49:13.200668
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "'_GqWlW~@|\n"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)

# Generated at 2022-06-25 06:49:16.172646
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test environment
    setup()
    test_case_0()


# Generated at 2022-06-25 06:49:23.995040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "'_GqWlW~@|\n"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)

    assert isinstance(action_module_1, ActionModule)

    assert hasattr(action_module_1, "run")
    assert callable(getattr(action_module_1, "run"))
    assert hasattr(action_module_1, "check_mode")

# Generated at 2022-06-25 06:49:33.391549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "'_GqWlW~@|\n"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)
    float_0 = -2750.0
    var_0 = action_module_1.run(float_0)

# Generated at 2022-06-25 06:50:13.488990
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'Y<\xbb2\xdd\xe5\x0e\xfc\xac\x00\xb5\xe2\x1d\xe1\xe8\x9e'
    list_0 = []
    bool_0 = False
    bool_1 = True
    str_0 = "c'\xeb\xe1\x0f\xa2\xf2\xe0\x10J\x8d\xfb!\x1a"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)

# Generated at 2022-06-25 06:50:18.940264
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "'_GqWlW~@|\n"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)
    assert action_module_1.run(float) == None, 'test_ActionModule FAILED!'


# Generated at 2022-06-25 06:50:24.641565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "'_GqWlW~@|\n"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)


# Generated at 2022-06-25 06:50:31.463504
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "'_GqWlW~@|\n"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)
    assert type(action_module_1) == ActionModule


# Generated at 2022-06-25 06:50:41.312032
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "'_GqWlW~@|\n"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)
    float_0 = -2750.0
    var_0 = action_module_1.run(float_0)

# Test for method run of class ActionModule
# Calling run() with arguments float_1 = float_0, float_2 = float_1
# raises exception: AnsibleActionFailure
# with message

# Generated at 2022-06-25 06:50:46.013132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = '\t\xff\x0e\xf9\x9b\\\x8f\xc0\x1f'
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)
    float_0 = -2750.0
    var_0 = action_module_1.run(float_0)


# Generated at 2022-06-25 06:50:53.321220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"?\x89\x0eT9\x92\x84\xe1\x1d\xde\xbc\x1c\x12\xbc\x18"
    list_0 = []
    bool_0 = True
    str_0 = ":-\x88\x94\x8a\xc1\xeb\x83\xd2h\x83~\x9f\xa5\xef"
    float_0 = -715.25
    action_module_0 = ActionModule(b'/\x98\x97', list_0, bool_0, bool_0, str_0, action_module_0)
    var_0 = action_module_0.run(float_0)

# Generated at 2022-06-25 06:50:59.805685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test_ActionModule")
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "'_GqWlW~@|\n"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)

# Generated at 2022-06-25 06:51:09.561214
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:51:17.865798
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'r\xc6\x1a\xbd\xa2\xe2\xfc\xa7\x9c\x8eoW\xda\xe1\x02\xdaU\xe6\xce\x81\x9f\xf8\x86\x84\xdb\xb8'
    list_0 = []
    bool_0 = False
    bool_1 = False
    str_0 = "src"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)

# Generated at 2022-06-25 06:52:34.824049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "'_GqWlW~@|\n"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)
    float_0 = -2750.0
    assert isinstance(action_module_1.run(float_0), dict)

if __name__ == '__main__':
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 06:52:39.079239
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "'_GqWlW~@|\n"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)
    float_0 = -2750.0
    var_0 = action_module_1.run(float_0)

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:52:47.839780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "'_GqWlW~@|\n"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)
    float_0 = -2750.0
    var_0 = action_module_1.run(float_0)

# Generated at 2022-06-25 06:52:54.230589
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "'_GqWlW~@|\n"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)



# Generated at 2022-06-25 06:53:03.084182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "'_GqWlW~@|\n"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)
    float_0 = -2750.0
    try:
        action_module_1.run(float_0)
    except AnsibleActionFail as result:
        assert True
    else:
        assert False
#Test for class ActionModule

# Generated at 2022-06-25 06:53:13.812262
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = b"1\n"
    list_0 = []
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)


# Generated at 2022-06-25 06:53:22.745980
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "'_GqWlW~@|\n"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)
    assert isinstance(action_module_1, ActionModule) == True
    assert action_module_1.action_loader is not None
    assert action_module_1.connection is not None
    assert action_module_1.playbook is not None
    assert action_module_1.playbook._loader is not None

# Generated at 2022-06-25 06:53:33.254886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # source of the file
    src = "/home/ubuntu/test"
    # destination of the file
    dest = "/home/ubuntu/test2"
    # creating test objects
    bytes_0 = b'\xc1\x80\xae\x81\x95\\\x8a/\xa5\xd7\n\xbe\x8f'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "8~\x80\xd0\x91\x0f`\x91\x0e\x8e\x16\xd1"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)
    float_

# Generated at 2022-06-25 06:53:41.704216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "'_GqWlW~@|\n"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)
    action_module_1.action_name
    action_module_1.action_wrappers
    action_module_1.action_loader
    action_module_1.task_vars
    action_module_1.task_name
    action_module_1.task
    action_module_1.play

# Generated at 2022-06-25 06:53:51.059216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x84\x83\xb0\x08\x88\xbf\xfb\x0e\xf8\x99\xf6\xa0\xa1f\x95\xbd\x94\x88\x8c$\x8a\xe9\xef\xcbn\x8f\xdc\x16\x13\x8d\xed\xe5\xe3\xe5\'\xf5\x8c\x96^\x9f\xe8\x1f\x1a\x16&\x05\x8c\xbe\xc2\xdb\x01\x8f\xdd\xca\x99\xcb\x8c\xaa\x07\x1f\xa8\x07'
    list_0

# Generated at 2022-06-25 06:57:08.498739
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x89\xc2\x82y \x02\xbfkW\x9b\x0fK\xaf'
    list_0 = []
    bool_0 = True
    bool_1 = True
    str_0 = "'_GqWlW~@|\n"
    action_module_0 = None
    action_module_1 = ActionModule(bytes_0, list_0, bool_0, bool_1, str_0, action_module_0)
    float_0 = -2750.0
    var_0 = action_module_1.run(float_0)