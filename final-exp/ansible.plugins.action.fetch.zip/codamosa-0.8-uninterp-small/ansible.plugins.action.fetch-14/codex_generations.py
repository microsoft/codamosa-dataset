

# Generated at 2022-06-25 06:47:18.759119
# Unit test for constructor of class ActionModule
def test_ActionModule():
  test_case_0()

# Unit tests for functions of class ActionModule

# Generated at 2022-06-25 06:47:30.616177
# Unit test for constructor of class ActionModule
def test_ActionModule():
    path_0 = os.path.normpath('/usr/lib/python2.7/site-packages/ansible/modules/core/copy.py')
    path_1 = os.path.normpath('/usr/lib/python2.7/site-packages/ansible/modules/core/stat.py')
    path_2 = os.path.normpath('/usr/lib/python2.7/site-packages/ansible/plugins/action/copy.py')
    path_3 = os.path.normpath('/usr/lib/python2.7/site-packages/ansible/plugins/action/stat.py')
    path_4 = os.path.normpath('/usr/lib/python2.7/site-packages/ansible/plugins/connection/connection_loader.py')

# Generated at 2022-06-25 06:47:33.711714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        ActionModule_instance = ActionModule(dict(), dict())
        ActionModule_instance.run()
    except RuntimeError:
        print('RuntimeError')


# Generated at 2022-06-25 06:47:35.702404
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule()
    except:
        assert False

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 06:47:36.670154
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 06:47:44.291087
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -2628
    dict_0 = {int_0: int_0, int_0: int_0}
    list_0 = [dict_0]
    bytes_0 = b'\x9a\xddO\n\xcb!\x9d\xc0\x8a~h\x16\xb5'
    set_0 = {list_0}
    tuple_0 = (dict_0,)
    AM1 = ActionModule()
    AM2 = ActionModule(dict_0)


# Generated at 2022-06-25 06:47:54.612112
# Unit test for constructor of class ActionModule
def test_ActionModule():

    print('start')
    ActionModule(u'7', u'vx')
    ActionModule(u'h', u'0p')
    ActionModule(u'2', u'0')
    ActionModule(u'z', u'2')
    ActionModule(u'y', u'i')
    ActionModule(u'', u'r')
    ActionModule(u'H', u'j')
    ActionModule(u'o', u'j')
    ActionModule(u'r', u'0')
    ActionModule(u'l', u'g')
    ActionModule(u'', u'0')
    ActionModule(u'1', u'3')
    ActionModule(u'I', u'A')
    ActionModule(u'b', u'J')

# Generated at 2022-06-25 06:47:55.189451
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj = ActionModule()

# Generated at 2022-06-25 06:47:59.290826
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    int_1 = 0
    action_module_0 = ActionModule()
    dict_0 = {}
    dict_0 = {}
    dict_1 = {'int_1': int_1}
    action_module_0.run(dict_0, dict_1)

# Generated at 2022-06-25 06:48:02.236301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule_0 = ActionModule(display, {}, {}, {}, {}, '', '', '', '', '', '', '')


# Generated at 2022-06-25 06:48:27.181341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create the object
    action_module_0 = ActionModule(list_2, list_2, str_0, str_0, tuple_0, tuple_0)
    # Call the method run and extract the results in a dictionary
    # Return value is a dictionary
    dict_0 = action_module_0.run()
    # Check if the method returns a dict
    if not isinstance(dict_0, dict):
        raise AssertionError("Expected True, but got False for test case 0")


# Generated at 2022-06-25 06:48:35.460074
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'Cn\x01:\r\\6\x9d\x01\\\x9f\x8b'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    str_0 = 'w\x0c\nNuPz,c\rky'
    tuple_0 = ()
    action_module_0 = ActionModule(list_0, list_0, str_0, str_0, tuple_0, tuple_0)
    var_0 = action_run()
    assert var_0 is not None

# Generated at 2022-06-25 06:48:43.069593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare variables
    bytes_0 = b'Cn\x01:\r\\6\x9d\x01\\\x9f\x8b'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    str_0 = 'w\x0c\nNuPz,c\rky'
    tuple_0 = ()
    action_module_0 = ActionModule(list_0, list_0, str_0, str_0, tuple_0, tuple_0)
    var_0 = action_run()
    # Test method run of class ActionModule
    test_case_0()

if __name__ == '__main__':
    # We are going to test the function
    test_ActionModule_run()

# Generated at 2022-06-25 06:48:49.374631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_1 = b'Cn\x01:\r\\6\x9d\x01\\\x9f\x8b'
    list_1 = [bytes_1, bytes_1, bytes_1, bytes_1]
    str_1 = 'w\x0c\nNuPz,c\rky'
    tuple_1 = ()
    action_module_1 = ActionModule(list_1, list_1, str_1, str_1, tuple_1, tuple_1)

test_case_0()
test_ActionModule()

# Generated at 2022-06-25 06:48:59.315852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'x\x0b\x00\x1f\x1aT\x80\x1a\xfe\x9a'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    str_0 = '\x00\x1c}\x8d\xcd\x06\xf7\xba'
    tuple_0 = ()
    action_module_0 = ActionModule(list_0, list_0, str_0, str_0, tuple_0, tuple_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 06:49:07.116843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'Cn\x01:\r\\6\x9d\x01\\\x9f\x8b'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    str_0 = 'w\x0c\nNuPz,c\rky'
    tuple_0 = ()
    action_module_0 = ActionModule(list_0, list_0, str_0, str_0, tuple_0, tuple_0)
    var_0 = action_module_0.run()
    return var_0

# Generated at 2022-06-25 06:49:14.250676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test for ActionModule
    list_0 = []
    list_1 = []
    str_0 = ''
    str_1 = ''
    tuple_0 = ()
    tuple_1 = ()
    action_module_0 = ActionModule(list_0, list_1, str_0, str_1, tuple_0, tuple_1)
    # test for action_run()
    action_module_0.action_run(action_module_0)

test_ActionModule()
test_case_0()

# Generated at 2022-06-25 06:49:20.565115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'Cn\x01:\r\\6\x9d\x01\\\x9f\x8b'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    str_0 = 'w\x0c\nNuPz,c\rky'
    tuple_0 = ()
    action_module_0 = ActionModule(list_0, list_0, str_0, str_0, tuple_0, tuple_0)
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 06:49:27.806363
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = [b'\x02\x1c\x1c', b'', b'\x01\x12>\x19', b'', b'\x01\x16\x08\x03', b'p\x0b']
    list_1 = [b'\x1aH\x0b', b"g\x1cM'\x1c\x1c", b'', b'\x12\x0f-\x10', b'', b'\x07\x1b']
    str_0 = ''
    str_1 = '\x0c\x03\x1a\x00\x0f\x1c\x12\x1a'
    tuple_0 = ()
    tuple_1 = ()

# Generated at 2022-06-25 06:49:36.612524
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:50:16.571174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = ()
    str_0 = ''
    tuple_0 = (str_0, list_0)
    action_module_0 = ActionModule(list_0, list_0, str_0, str_0, tuple_0, tuple_0)
    print("test_ActionModule:'%s'" % action_module_0)


# Generated at 2022-06-25 06:50:19.738005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert (not test_case_0)


# Generated at 2022-06-25 06:50:31.877043
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test cases for ActionModule run() method

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    import os

    # Test case no: 1
    # Test with only source being specified
    action_module_1 = ActionModule([], [], "", "", (), ())
    var_1 = action_module_1.run()
    assert var_1.get('failed') == True

    # Test case no: 2
    # Test with only source and dest being specified
    action_module_2 = ActionModule([], [], "src", "", (), ())
    var_2 = action_module_2.run()
    assert var_2.get('failed') == True

    # Test case no: 3
    # Test with only source and flat being specified
    action_module

# Generated at 2022-06-25 06:50:35.142272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    test_case_0()


# Generated at 2022-06-25 06:50:42.240583
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'Cn\x01:\r\\6\x9d\x01\\\x9f\x8b'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    str_0 = '<\x0c\nNuPz,c\rky'
    tuple_0 = ()
    action_module_0 = ActionModule(list_0, list_0, str_0, str_0, tuple_0, tuple_0)
    assert isinstance(action_module_0, ActionModule)



# Generated at 2022-06-25 06:50:50.824192
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'Cn\x01:\r\\6\x9d\x01\\\x9f\x8b'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    str_0 = 'w\x0c\nNuPz,c\rky'
    tuple_0 = ()
    action_module_0 = ActionModule(list_0, list_0, str_0, str_0, tuple_0, tuple_0)
    var_1 = action_run(None, None)
    var_2 = action_run(b'|5\x95\x1a\x8d', None)
    var_3 = action_run(b'', None)
    var_4 = action_run(None, dict())

# Generated at 2022-06-25 06:50:59.939463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'Cn\x01:\r\\6\x9d\x01\\\x9f\x8b'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    str_0 = 'w\x0c\nNuPz,c\rky'
    tuple_0 = ()
    action_module_0 = ActionModule(list_0, list_0, str_0, str_0, tuple_0, tuple_0)
    task_vars_0 = {}
    tmp_0 = None
    var_0 = action_module_0.run(tmp_0, task_vars_0)
    print(var_0)

# Generated at 2022-06-25 06:51:03.874672
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(list_0, list_0, str_0, str_0, tuple_0, tuple_0)
    assert isinstance(ActionModule(list_0, list_0, str_0, str_0, tuple_0, tuple_0), ActionModule)

# Generated at 2022-06-25 06:51:10.183600
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'Cn\x01:\r\\6\x9d\x01\\\x9f\x8b'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    str_0 = 'w\x0c\nNuPz,c\rky'
    tuple_0 = ()
    action_module_0 = ActionModule(list_0, list_0, str_0, str_0, tuple_0, tuple_0)


# Generated at 2022-06-25 06:51:14.701665
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('test_ActionModule started')
    test_case_0()
    print('test_ActionModule completed')

test_ActionModule()

# Generated at 2022-06-25 06:52:23.407201
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test case 0
    assert test_case_0() == None
    return

# Generated at 2022-06-25 06:52:30.366850
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'Cn\x01:\r\\6\x9d\x01\\\x9f\x8b'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    str_0 = 'w\x0c\nNuPz,c\rky'
    tuple_0 = ()
    action_module_0 = ActionModule(list_0, list_0, str_0, str_0, tuple_0, tuple_0)
    action_module_0.run()

# Generated at 2022-06-25 06:52:31.570300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass



# Generated at 2022-06-25 06:52:38.991562
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test for constructor of class ActionModule
    """
    connection_0 = None
    loader_0 = None
    templar_0 = None
    shared_loader_obj_0 = None
    play_context_0 = None
    action_base_0 = ActionBase(connection_0, loader_0, templar_0, shared_loader_obj_0, play_context_0, None)
    task_0 = None
    action_module_0 = ActionModule(connection_0, loader_0, templar_0, shared_loader_obj_0, play_context_0, task_0, None)
    ansible_action_skip_0 = AnsibleActionSkip()
    ansible_error_0 = AnsibleError()
    ansible_action_fail_0 = AnsibleActionFail()
    ansible

# Generated at 2022-06-25 06:52:47.112737
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'Cn\x01:\r\\6\x9d\x01\\\x9f\x8b'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    str_0 = 'w\x0c\nNuPz,c\rky'
    tuple_0 = ()
    action_module_0 = ActionModule(list_0, list_0, str_0, str_0, tuple_0, tuple_0)
    TestCase.assertEqual(action_module_0.__name__, 'ActionModule')
    TestCase.assertEqual(action_module_0.__doc__, ' handler for fetch operations ')

# Generated at 2022-06-25 06:52:54.806927
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'Cn\x01:\r\\6\x9d\x01\\\x9f\x8b'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    str_0 = 'w\x0c\nNuPz,c\rky'
    tuple_0 = ()
    action_module_0 = ActionModule(list_0, list_0, str_0, str_0, tuple_0, tuple_0)
    # Set tmp to None
    # Set task_vars to None
    # Invoke method
    result = action_module_0.run(None, None)




# Generated at 2022-06-25 06:53:01.935788
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'Cn\x01:\r\\6\x9d\x01\\\x9f\x8b'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    str_0 = 'w\x0c\nNuPz,c\rky'
    tuple_0 = ()
    action_module_0 = ActionModule(list_0, list_0, str_0, str_0, tuple_0, tuple_0)


# Generated at 2022-06-25 06:53:12.765911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'm\x1a'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    str_0 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    tuple_0 = (2, 3)

# Generated at 2022-06-25 06:53:22.727607
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module0 = ActionModule(str, str, str, str, str, str)

# Generated at 2022-06-25 06:53:26.181447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    d = dict()
    d['a'] = 1
    d['b'] = 2
    d['c'] = 3
    a = ActionModule(d, d, 'string1', 'string2', (1, 2, 3), (4, 5, 6))



# Generated at 2022-06-25 06:56:24.755618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-25 06:56:31.665574
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'Cn\x01:\r\\6\x9d\x01\\\x9f\x8b'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    str_0 = 'w\x0c\nNuPz,c\rky'
    tuple_0 = ()
    # Create an object of class ActionModule
    action_module_0 = ActionModule(list_0, list_0, str_0, str_0, tuple_0, tuple_0)
    # This is the test case
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 06:56:37.291465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'Cn\x01:\r\\6\x9d\x01\\\x9f\x8b'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    str_0 = 'w\x0c\nNuPz,c\rky'
    tuple_0 = ()
    action_module_0 = ActionModule(list_0, list_0, str_0, str_0, tuple_0, tuple_0)



# Generated at 2022-06-25 06:56:40.029483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule()
    except TypeError:
        assert True


# Generated at 2022-06-25 06:56:50.775840
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule([], [], str(), str(), (), ())
    var_1 = var_0.run()
    assert var_1.get_changed() == None
    assert var_1.get_checksum() == None
    assert var_1.get_dest() == to_text()
    assert var_1.get_failed() == None
    assert var_1.get_exception() == AnsibleError()
    assert var_1.get_file() == to_text()
    assert var_1.get_md5sum() == None
    assert var_1.get_msg() == None
    assert var_1.get_parsed() == None
    assert var_1.get_remote_checksum() == None
    assert var_1.get_remote_md5sum() == None
    assert var_

# Generated at 2022-06-25 06:56:54.666094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == None


# Generated at 2022-06-25 06:57:01.640347
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import io
    import os
    import sys