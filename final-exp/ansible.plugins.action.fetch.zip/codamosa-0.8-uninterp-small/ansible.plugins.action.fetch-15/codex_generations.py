

# Generated at 2022-06-25 06:47:18.284251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 06:47:26.956892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x16\x13\x18\xaf\xbf=\xb8g\x1c\xe2\xc6n\xd8\xcc?\xa0\x18\xcb\x01'
    dict_0 = {bytes_0: bytes_0}
    tuple_0 = ()
    int_0 = 2715
    obj_0 = ActionModule(bytes_0, dict_0, tuple_0, int_0, tuple_0, tuple_0)
    assert isinstance(obj_0, ActionModule)


# Generated at 2022-06-25 06:47:36.784104
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x16\x13\x18\xaf\xbf=\xb8g\x1c\xe2\xc6n\xd8\xcc?\xa0\x18\xcb\x01'
    dict_0 = {bytes_0: bytes_0}
    tuple_0 = ()
    int_0 = 2715
    action_module_0 = ActionModule(bytes_0, dict_0, tuple_0, int_0, tuple_0, tuple_0)

# Generated at 2022-06-25 06:47:38.767791
# Unit test for constructor of class ActionModule
def test_ActionModule():
  try:
    test_case_0()
  except:
    raise AssertionError('Action Exception')

# Generated at 2022-06-25 06:47:40.264863
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated test cases for ActionModule.run


# Generated at 2022-06-25 06:47:43.612106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        assert False == True
    except AssertionError:
        Display.error('AssertionErrorException!', traceback.format_exc())
        Display.error('Caught exception')


# Generated at 2022-06-25 06:47:48.253243
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as err:
        print("Caught error in constructor of class ActionModule")
        print("Error type:", type(err))
        print("Error:", err)

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 06:47:56.239253
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x16\x13\x18\xaf\xbf=\xb8g\x1c\xe2\xc6n\xd8\xcc?\xa0\x18\xcb\x01'
    dict_0 = {bytes_0: bytes_0}
    tuple_0 = ()
    int_0 = 2715
    action_module_0 = ActionModule(bytes_0, dict_0, tuple_0, int_0, tuple_0, tuple_0)
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:48:08.298763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # check if the method raises the expected exceptions
    bytes_0 = b'\x16\x13\x18\xaf\xbf=\xb8g\x1c\xe2\xc6n\xd8\xcc?\xa0\x18\xcb\x01'
    dict_0 = {bytes_0: bytes_0}
    tuple_0 = ()
    int_0 = 2715
    action_module_0 = ActionModule(bytes_0, dict_0, tuple_0, int_0, tuple_0, tuple_0)
    dict_1 = {bytes_0: bytes_0}
    dict_2 = {}
    dict_3 = {}
    dict_3 = {}
    dict_3 = {}
    dict_3 = {}
    dict_3 = {}
    dict_4 = {}


# Generated at 2022-06-25 06:48:13.260742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x90z\xbd\xbe\x9e\x108\xa3\xfb\xcc\xab\x18\xc7\xd0\xcf'

# Generated at 2022-06-25 06:48:41.525685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = '\n{[$PU}D\x0c0h1>\x0bo'
    set_0 = {str_0, str_0}
    bool_0 = True
    bytes_0 = b'\xecp$Y\xc4\xf8\x81\xe01\x1baav\x9c\x83'
    dict_0 = {str_0: bytes_0}
    tuple_0 = (dict_0,)
    int_0 = 500
    action_module_0 = ActionModule(bool_0, bytes_0, tuple_0, set_0, bytes_0, int_0)
    float_0 = 2474.29
    bool_1 = True
    float_1 = 1899.0162
    action_module_1 = Action

# Generated at 2022-06-25 06:48:47.988266
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Default constructor
    action_module_0 = ActionModule()
    complex_0 = None
    str_0 = '\n{[$PU}D\x0c0hl>\x0bj'
    set_0 = {str_0, str_0}
    bool_0 = True
    bytes_0 = b'\xecp$Y\xc4\xf8\x81\xe0\x1e\x1b\xaav\x9c\x83'
    dict_0 = {str_0: bytes_0}
    tuple_0 = (dict_0,)
    int_0 = 500
    # Constructor with parameters
    action_module_1 = ActionModule(bool_0, bytes_0, tuple_0, set_0, bytes_0, int_0)
    var_0 = action_

# Generated at 2022-06-25 06:48:51.315085
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
    except Exception as exc:
        print(str(exc))
        assert False


# Generated at 2022-06-25 06:49:02.460749
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 06:49:13.534071
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = '\n{[$PU}D\x0c0hl>\x0bj'
    set_0 = {str_0, str_0}
    bool_0 = True
    bytes_0 = b'\xecp$Y\xc4\xf8\x81\xe0\x1e\x1b\xaav\x9c\x83'
    dict_0 = {str_0: bytes_0}
    tuple_0 = (dict_0,)
    int_0 = 500
    action_module_0 = ActionModule(bool_0, bytes_0, tuple_0, set_0, bytes_0, int_0)
    float_0 = 2474.29
    bool_1 = True
    float_1 = 1899.0162
    action_

# Generated at 2022-06-25 06:49:22.883252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    str_0 = '\n{[$PU}D\x0c0hl>\x0bj'
    set_0 = {str_0, str_0}
    bool_0 = True
    bytes_0 = b'\xecp$Y\xc4\xf8\x81\xe0\x1e\x1b\xaav\x9c\x83'
    dict_0 = {str_0: bytes_0}
    tuple_0 = (dict_0,)
    int_0 = 500
    action_module_0 = ActionModule(bool_0, bytes_0, tuple_0, set_0, bytes_0, int_0)
    float_0 = 2474.29
    bool_1 = True
    float_1 = 1899.0162
    action_

# Generated at 2022-06-25 06:49:34.063204
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = '\n{[$PU}D\x0c0hl>\x0bj'
    set_0 = {str_0, str_0}
    bool_0 = True
    bytes_0 = b'\xecp$Y\xc4\xf8\x81\xe0\x1e\x1b\xaav\x9c\x83'
    dict_0 = {str_0: bytes_0}
    tuple_0 = (dict_0,)
    int_0 = 500
    action_module_0 = ActionModule(bool_0, bytes_0, tuple_0, set_0, bytes_0, int_0)
    float_0 = 2474.29
    bool_1 = True
    float_1 = 1899.0162
    action_

# Generated at 2022-06-25 06:49:42.018049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Check if the function raises the expected exceptions
    bool_0 = True
    bytes_0 = b'\xecp$Y\xc4\xf8\x81\xe0\x1e\x1b\xaav\x9c\x83'
    tuple_0 = ({},)
    set_0 = {dict(), tuple_0}
    bytes_1 = b'\xb1\x93\x0f\xef6\xf4\x02\x9e,\xf8\x14\xc2'
    int_0 = -1
    str_0 = '\xabV\x9a\xf8\x1b\xfe\x84'
    bool_1 = False


# Generated at 2022-06-25 06:49:52.838036
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = '\n{[$PU}D\x0c0hl>\x0bj'
    set_0 = {str_0, str_0}
    bool_0 = True
    bytes_0 = b'\xecp$Y\xc4\xf8\x81\xe0\x1e\x1b\xaav\x9c\x83'
    dict_0 = {str_0: bytes_0}
    tuple_0 = (dict_0,)
    int_0 = 500
    action_module_0 = ActionModule(bool_0, bytes_0, tuple_0, set_0, bytes_0, int_0)
    float_0 = 2474.29
    bool_1 = True
    float_1 = 1899.0162
    action_

# Generated at 2022-06-25 06:50:01.192904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = 'rE\x00N\x9b'
    set_0 = {str_0, str_0}
    bool_0 = False
    bytes_0 = b'd\xad\xf4\xef\x14\x86x\xb7\xd8\xa3\x89\x9a\xdb'
    dict_0 = {str_0: bytes_0}
    tuple_0 = (dict_0,)
    int_0 = 500
    action_module_0 = ActionModule(bool_0, bytes_0, tuple_0, set_0, bytes_0, int_0)
    float_0 = 2474.29
    bool_1 = False
    float_1 = 1899.0162

# Generated at 2022-06-25 06:50:38.006877
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {str_0, str_0}
    action_module_1 = ActionModule(set_0, action_module_0, float_0, bool_1, float_1, str_0)
    assert action_module_1.run(complex_0) == var_0

# Generated at 2022-06-25 06:50:47.105843
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:50:54.312910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = '\n{[$PU}D\x0c0hl>\x0bj'
    set_0 = {str_0, str_0}
    bool_0 = True
    bytes_0 = b'\xecp$Y\xc4\xf8\x81\xe0\x1e\x1b\xaav\x9c\x83'
    dict_0 = {str_0: bytes_0}
    tuple_0 = (dict_0,)
    int_0 = 500
    action_module_0 = ActionModule(bool_0, bytes_0, tuple_0, set_0, bytes_0, int_0)
    float_0 = 2474.29
    bool_1 = True
    float_1 = 1899.0162
    action_

# Generated at 2022-06-25 06:50:59.938329
# Unit test for constructor of class ActionModule
def test_ActionModule():
  complex_0 = None
  str_0 = '\n{[$PU}D\x0c0hl>\x0bj'
  set_0 = {str_0, str_0}
  bool_0 = True
  bytes_0 = b'\xecp$Y\xc4\xf8\x81\xe0\x1e\x1b\xaav\x9c\x83'
  dict_0 = {str_0: bytes_0}
  tuple_0 = (dict_0,)
  test_case_0()


# Generated at 2022-06-25 06:51:09.681703
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 06:51:19.513502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = '\n{[$PU}D\x0c0hl>\x0bj'
    set_0 = {str_0, str_0}
    bool_0 = True
    bytes_0 = b'\xecp$Y\xc4\xf8\x81\xe0\x1e\x1b\xaav\x9c\x83'
    dict_0 = {str_0: bytes_0}
    tuple_0 = (dict_0,)
    int_0 = 500
    action_module_0 = ActionModule(bool_0, bytes_0, tuple_0, set_0, bytes_0, int_0)
    float_0 = 2474.29
    bool_1 = True
    float_1 = 1899.0162
    action_

# Generated at 2022-06-25 06:51:28.722503
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # complex_0 = None  # Type: Optional[Complex]
    str_0 = '\n{[$PU}D\x0c0hl>\x0bj'  # Type: AnyStr
    set_0 = {str_0, str_0}  # Type: Set[AnyStr]
    bool_0 = True  # Type: bool
    bytes_0 = b'\xecp$Y\xc4\xf8\x81\xe0\x1e\x1b\xaav\x9c\x83'  # Type: bytes
    dict_0 = {str_0: bytes_0}  # Type: Dict[AnyStr, bytes]
    tuple_0 = (dict_0,)  # Type: Tuple[Dict[AnyStr, bytes]]
    int_0 = 500  # Type:

# Generated at 2022-06-25 06:51:29.474149
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:51:40.535272
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_1 = None
    str_1 = '\n{[$PU}D\x0c0hl>\x0bj'
    set_1 = {str_1, str_1}
    bool_2 = True
    bytes_1 = b'\xecp$Y\xc4\xf8\x81\xe0\x1e\x1b\xaav\x9c\x83'
    dict_1 = {str_1: bytes_1}
    tuple_1 = (dict_1,)
    int_1 = 500
    action_module_2 = ActionModule(bool_2, bytes_1, tuple_1, set_1, bytes_1, int_1)
    float_2 = 2474.29
    bool_3 = True
    float_3 = 1899.0162
    action_

# Generated at 2022-06-25 06:51:50.569558
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = {'\x8d\x1c\xca\x9b\x1e>\xa3\xaa\xe7\x05\xf8\x92\xec\x9d\x13e\xfd\xec\xaf\xd7\xb2': ':y\x83\x86\x9a\xdc\xd8\xef\x1b\xc4\xd4\xfa\xf4\xde\x9d\xaa'}

# Generated at 2022-06-25 06:53:05.979522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    str_0 = '\n{[$PU}D\x0c0hl>\x0bj'
    set_0 = {str_0, str_0}
    bool_0 = True
    bytes_0 = b'\xecp$Y\xc4\xf8\x81\xe0\x1e\x1b\xaav\x9c\x83'
    dict_0 = {str_0: bytes_0}
    tuple_0 = (dict_0,)
    int_0 = 500
    action_module_0 = ActionModule(bool_0, bytes_0, tuple_0, set_0, bytes_0, int_0)
    set_1 = set()

# Generated at 2022-06-25 06:53:15.778129
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    str_0 = '\n{[$PU}D\x0c0hl>\x0bj'
    set_0 = {str_0, str_0}
    bool_0 = True
    bytes_0 = b'\xecp$Y\xc4\xf8\x81\xe0\x1e\x1b\xaav\x9c\x83'
    dict_0 = {str_0: bytes_0}
    tuple_0 = (dict_0,)
    int_0 = 500
    action_module_0 = ActionModule(bool_0, bytes_0, tuple_0, set_0, bytes_0, int_0)
    float_0 = 2474.29
    bool_1 = True
    float_1 = 1899.0162
    action_

# Generated at 2022-06-25 06:53:16.548580
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    case_0()
    case_1()


# Generated at 2022-06-25 06:53:22.344583
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = '\n{[$PU}D\x0c0hl>\x0bj'
    set_0 = {str_0, str_0}
    bool_0 = True
    bytes_0 = b'\xecp$Y\xc4\xf8\x81\xe0\x1e\x1b\xaav\x9c\x83'
    dict_0 = {str_0: bytes_0}
    tuple_0 = (dict_0,)
    int_0 = 500
    action_module_0 = ActionModule(bool_0, bytes_0, tuple_0, set_0, bytes_0, int_0)
    float_0 = 2474.29
    bool_1 = True
    float_1 = 1899.0162
    action_

# Generated at 2022-06-25 06:53:32.091714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    complex_0 = None
    str_0 = '\x0et\x7f'
    set_0 = {str_0}
    bool_0 = True
    bytes_0 = b'\xfdS\x87\xde\x1f'
    dict_0 = {str_0: bytes_0}
    tuple_0 = (dict_0, dict_0)
    int_0 = 500
    action_module_0 = ActionModule(bool_0, bytes_0, tuple_0, set_0, bytes_0, int_0)
    test_case_0()
    var_0 = action_module_0.run(complex_0)

# Generated at 2022-06-25 06:53:37.258874
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import random
    import pytest
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.utils.hashing import checksum, checksum_s, md5, secure_hash
    from ansible.utils.path import makedirs_safe
    from ansible.utils.display import Display
    from ansible.playbook.play_context import PlayContext
    from ansible.errors import AnsibleError, AnsibleActionFail, AnsibleActionSkip
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.six import string_types
    from ansible.module_utils.parsing.convert_bool import boolean

    display = Display()
    play_context = PlayContext()
    tmp = None
    task_vars = dict()

    set

# Generated at 2022-06-25 06:53:38.491918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
    except TypeError as e:
        print(e)

# Generated at 2022-06-25 06:53:49.164681
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = '\n{[$PU}D\x0c0hl>\x0bj'
    set_0 = {str_0, str_0}
    bool_0 = True
    bytes_0 = b'\xecp$Y\xc4\xf8\x81\xe0\x1e\x1b\xaav\x9c\x83'
    dict_0 = {str_0: bytes_0}
    tuple_0 = (dict_0,)
    int_0 = 500
    float_0 = 2474.29
    float_1 = 1899.0162
    action_module_0 = ActionModule(set_0, action_module_0, float_0, bool_0, float_1, str_0)
# Testing initialization of class ActionModule


# Generated at 2022-06-25 06:53:56.330262
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    make_0 = {'\x1c4\x1b\xc6\xaa\xe5\r\xa3\x8e\xe5\x06\xbc\x03':b'\xc8\xbc\xbe\x9e\xbe\x8d\xef\xe5\x90\xfb\x8d\xce\xe5\xd3\x8d\xbf+\xda\xd7\x04\x8d'}

# Generated at 2022-06-25 06:54:03.150127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = None
    str_0 = '\n{[$PU}D\x0c0hl>\x0bj'
    set_0 = {str_0, str_0}
    bool_0 = True
    bytes_0 = b'\xecp$Y\xc4\xf8\x81\xe0\x1e\x1b\xaav\x9c\x83'
    dict_0 = {str_0: bytes_0}
    tuple_0 = (dict_0,)
    int_0 = 500
    action_module_0 = ActionModule(bool_0, bytes_0, tuple_0, set_0, bytes_0, int_0)
    assert action_module_0.tmp is None
    float_0 = 2474.29
    bool_1 = True
   