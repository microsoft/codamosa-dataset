

# Generated at 2022-06-25 06:47:29.636873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = 'f\x84\xcc\xcb\xb3\xd7t\x8d\xa7'
    int_0 = 535000
    bytes_0 = b'('
    action_module_test_case_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    bytes_0 = b'o'
    str_0 = '\x88\x89\x93\xb6U\x0f\xf6\xeb\x93\xa9\x9a\xac'
    list_0 = ['unit test 0']
    bytes_0 = b'f\x84\xcc\xcb\xb3\xd7t\x8d\xa7'
    int_0

# Generated at 2022-06-25 06:47:36.603828
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    action_module_0.run()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:47:47.666267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_name = 'action.abstract.action_module.ActionModule'

# Generated at 2022-06-25 06:47:50.908704
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except:
        print('FAILED: test_ActionModule')
        raise


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:47:57.597714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = ";.N\x16\xda\xf9"
    int_0 = 523000
    bytes_0 = b'C\rQ\x87\xcc\xbf\x80\xa4\x17,\x0e\x1c\xa7S'
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:47:59.315491
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    import cProfile

    cProfile.run('test_ActionModule()', sort='time')

# Generated at 2022-06-25 06:48:09.596429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    set_0 = set()
    str_0 = '\x13\x12\x93\xec\x9c\x08\x1b\xe8\x94\xfd\xfb\xfd\x9a\x9f\x14'
    int_0 = 535000

# Generated at 2022-06-25 06:48:17.954463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    tmp_0 = '\x89.\x1d\x8a\xc9\xcc\xa7\xa9\xcdD\xd2\x1d\xde\x88\x98'
    result = action_module_0.run(tmp_0)

# Generated at 2022-06-25 06:48:18.642926
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:48:23.097558
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print( " # Unit test for method run of class ActionModule")
    assert True # TODO: implement your test here


# Generated at 2022-06-25 06:48:46.790488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'action.abstract.action_module.ActionModule'
    test_case_0()
    test = ActionModule()
    # no test here because the constructor is empty


# Generated at 2022-06-25 06:48:48.681453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'action.abstract.action_module.ActionModule'

    # TODO: (DONE) need to implement ActionModule.run()
    pass


# Generated at 2022-06-25 06:48:53.527782
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    param_test_case_0 = [
        'action.abstract.action_module.ActionModule',
        None,
        'michael.dehaan@gmail.com',
        'for failed',
        False,
        True,
    ]
    param_test_case_0.insert(0, ActionModule())
    param_test_case_0[1] = None
    param_test_case_0[2] = None
    param_test_case_0[4] = None
    param_test_case_0[5] = None

    # assert try:
    # assert val == "action.abstract.action_module.ActionModule"
    pass # no assert



# Generated at 2022-06-25 06:48:56.553987
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    test_case_0()

# These two tests do not really do anything, but they will raise exceptions if there are problems.
test_ActionModule()

# Generated at 2022-06-25 06:49:05.241728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import utils
    from ansible import errors
    from ansible.plugins.action import ActionBase
    from ansible.utils.path import makedirs_safe, is_subpath
    tmp, task_vars = None, {}
    action_module_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_base_0 = ActionBase(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_base_0.run(tmp, task_vars)
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 06:49:06.463027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
#
#

# Generated at 2022-06-25 06:49:16.289246
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # FIXME: this test is not finished

    action_module = ActionModule()

    p = argparse.ArgumentParser(description='action plugin tests')
    p.add_argument('--connection', default=None, choices=C.CONNECTION_PLUGIN_CHOICES,
                   help='connection plugin to use')
    p.add_argument('--shell', default=None, choices=C.SHELL_PLUGIN_CHOICES,
                   help='shell plugin to use')
    p.add_argument('--vagrant', action='store_true', help='test running against a Vagrant VM')

    args = p.parse_args()

    if args.vagrant:
        if args.connection is not None:
            p.error('--vagrant and --connection are mutually exclusive')
        action_module.connection = 'vagrant'
   

# Generated at 2022-06-25 06:49:23.549992
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile

# Generated at 2022-06-25 06:49:34.510546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = {}
    args['tmp'] = None
    args['task_vars'] = None
    retobj = {}
    retobj['failed'] = True
    retobj['changed'] = True
    retobj['checked'] = True
    retobj['msg'] = {}
    retobj['changed'] = True
    retobj['error_dic'] = {}
    retobj['warnings'] = [{}]
    retobj['rc'] = True
    retobj['stdout'] = True
    retobj['stderr'] = True
    retobj['stdout_lines'] = [{}]
    retobj['stderr_lines'] = [{}]
    retobj['results'] = [{}]
    retobj['assertions'] = [{}]
    retobj['warnings'] = [{}]


# Generated at 2022-06-25 06:49:36.872367
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    return

if(__name__ == '__main__'):
    test_ActionModule()

# Generated at 2022-06-25 06:50:03.461603
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    float_0 = 0.308177376075
    action_module_0 = ActionModule(set_0, str_0, float_0, set_0, str_0, b'')
    str_1 = 'The module executed successfully, but you may wish to check the output'
    action_module_0.action_run()
    print(action_module_0.action_run())
    if (str_0 != str_1):
        print('str_0')
        print('str_1')
    print(action_module_0.action_run())
    print(action_module_0.action_run())
    print(action_module_0.action_run())

# Generated at 2022-06-25 06:50:09.240751
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = 'Only fully qualified hostnames or IP addresses are accepted as target hosts:'
    int_0 = 567000
    bytes_0 = b'('
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    action_module_0.run()



# Generated at 2022-06-25 06:50:14.639895
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    return action_module_0.run(tmp=None, task_vars=None)

# Generated at 2022-06-25 06:50:23.780945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 06:50:32.309482
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    assert isinstance(action_module_0, ActionModule)
    assert action_module_0.argspec == 'Unknown container type encountered when removing private values from keys'
    assert action_module_0.fail_on_missing == 535000

# Generated at 2022-06-25 06:50:42.399803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    var_1 = '\x0f\xa1\xb6\x0b'

# Generated at 2022-06-25 06:50:50.966317
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    assert action_module_0._task.args.get('src', None) is None
    assert action_module_0._task.args.get('validate_checksum', True)
    assert action_module_0._task.args.get('dest', None) is None
    assert action_module_0._task.args.get('fail_on_missing', True)
    assert action

# Generated at 2022-06-25 06:50:58.780200
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    assert action_module_0.task
    assert action_module_0.connection

# Generated at 2022-06-25 06:51:00.463625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as e:
        raise Exception(str(e))

# Generated at 2022-06-25 06:51:01.517523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 06:51:50.411801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()

# Generated at 2022-06-25 06:51:56.873894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    var_0 = action_run()

# Generated at 2022-06-25 06:52:03.514899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    assert action_module_0.run() == None


# Generated at 2022-06-25 06:52:09.210360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()
    print('All test cases passed!')

# Generated at 2022-06-25 06:52:12.665577
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Example use
    action_module_0 = ActionModule()
    var_0 = action_run(tmp=None, task_vars=None)

# Generated at 2022-06-25 06:52:23.333069
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    map_0 = {}
    var_0 = action_module_0.run(map_0, map_0)
    assert (len(var_0) == 4 or len(var_0) == 5)
    assert (var_0.get('changed') == False or var_0.get('changed') == True)

# Generated at 2022-06-25 06:52:30.329657
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    var_0 = action_module_0.run()
    assert not var_0


# Generated at 2022-06-25 06:52:38.245892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    str_0 = '\x96\xbf\xfb\x06\x8b\x97\xd4\xcf\x10\x8d\x07\x9a\x1c\x1a\xbc\x84\xad\n\xa5\xc0\x8b' \
            '\x19\x93\xd6\xbd\xb2\x19\x93\xd6\xbd\xb2\x19\x93\xd6\xbd\xb2\x19\x93\xd6\xbd\xb2\x19' \
            '\x93\xd6\xbd\xb2\x19\x93\xd6\xbd\xb2'
    int_0 = 5350
    bytes_0

# Generated at 2022-06-25 06:52:47.064977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    assert isinstance(action_module_0, ActionModule)
    assert hasattr(action_module_0, 'module_vars')
    assert not hasattr(action_module_0, 'module_vars')
    assert isinstance(action_module_0.module_vars, set)
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 06:52:50.771843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_1 = set()
    str_1 = '_xxx'
    bytes_1 = b'Unknown module'
    action_module_1 = ActionModule(set_1, str_1, int(), set_1, str_1, bytes_1)
    var_0 = action_run()


if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 06:54:18.244218
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    print(id(action_module_0))

# Generated at 2022-06-25 06:54:24.064168
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)



# Generated at 2022-06-25 06:54:28.485745
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    var_0 = action_run()
    assert var_0 is false

# Generated at 2022-06-25 06:54:34.079820
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    var_0 = action_module_0.run(set_0, set_0)


# Generated at 2022-06-25 06:54:42.609417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 792499
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    var_0 = action_module_0.run()
    str_1 = ';'
    assert var_0 == str_1

if __name__ == "__main__":
    test_ActionModule_run()
    test_case_0()

# Generated at 2022-06-25 06:54:47.132612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    action_module_0.run()

test_case_0()

# Generated at 2022-06-25 06:54:51.527231
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)


# Generated at 2022-06-25 06:54:57.950180
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_1 = set()
    str_1 = 'Unknown container type encountered when removing private values from keys'
    int_1 = 535000
    bytes_1 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_1 = ActionModule(set_1, str_1, int_1, set_1, str_1, bytes_1)


# Generated at 2022-06-25 06:54:58.669769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print( 'Test run not found')


# Generated at 2022-06-25 06:55:04.908531
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    str_0 = 'Unknown container type encountered when removing private values from keys'
    int_0 = 535000
    bytes_0 = b'("\xac\xbe.\t\x9b\xc0\x18\xf1\xc6\xa1='
    action_module_0 = ActionModule(set_0, str_0, int_0, set_0, str_0, bytes_0)
    assert(action_module_0.set_0 == {})
    assert(action_module_0.str_0 == 'Unknown container type encountered when removing private values from keys')
    assert(action_module_0.int_0 == 535000)
    assert(action_module_0.set_1 == {})