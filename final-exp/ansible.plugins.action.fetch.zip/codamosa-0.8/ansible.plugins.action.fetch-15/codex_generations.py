

# Generated at 2022-06-11 11:42:36.972781
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' action.py:ActionModule

    constructor
    '''

    import ansible.plugins.action
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    action = ansible.plugins.action.ActionModule('args',
                   task_queue_manager=TaskQueueManager(inventory=None, variable_manager=VariableManager(), loader=DataLoader()),
                   connection=None, play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)

    assert action.run() == {}

# Generated at 2022-06-11 11:42:37.965774
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:42:48.434127
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create and initialize an object of class ActionModule with a stub for the connection class
    module = ActionModule()

    # test when task_vars is None
    # Check that the method run returns an object of class dict.
    # The keys of this object are
    # - changed
    # - _ansible_parsed
    # - _ansible_no_log
    # - _ansible_item_result
    # - failed
    # - file
    # - msg
    # The first four keys are expected to have the value None, the last two the value False
    assert isinstance(module.run(), dict)
    assert module.run()['changed'] == None
    assert module.run()['_ansible_parsed'] == None
    assert module.run()['_ansible_no_log'] == None

# Generated at 2022-06-11 11:42:59.906077
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import action_loader

    play_context = PlayContext()
    play_context.check_mode = True
    play_context.network_os = 'ios'
    connection = connection_loader.get('network_cli', class_args=(play_context,))

    class Task():
        def __init__(self):
            self.args = dict(src='test1', dest='test2')
        def __getitem__(self, item):
            return self.args[item]

    task = Task()

    am = ActionModule(task, connection, play_context, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 11:43:11.583200
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import mock
    class MockTask():
        def __init__(self):
            self.args = {'src': 'foo', 'dest': 'bar'}
    class MockPlayContext():
        def __init__(self):
            self.check_mode = False
            self.remote_addr = '127.0.0.1'
    class MockConnection():
        def __init__(self):
            self.become = False
    class MockLoader():
        def __init__(self):
            class Mock_path_dwim():
                def __init__(self):
                    self.return_value = 'a/b/c'
            self.path_dwim = Mock_path_dwim()

# Generated at 2022-06-11 11:43:19.609664
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_tempdir = tmpdir.mkdir("test_ActionModule")
    # touch file
    my_tempdir.join('.dir').ensure(dir=True)
    source = my_tempdir.join('source.txt')
    dest = my_tempdir.join('dest')
    source.write('1')
    my_task = lambda: None
    setattr(my_task, 'args', dict(
        src='source.txt', 
        dest=dest, 
        validate_checksum=False,
        flat=True
    ))
    # call action
    result = ActionModule.run(my_task, dict())
    print(result)



# Generated at 2022-06-11 11:43:29.830532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    ActionModule.run() Test Plan:
        - create a temp directory for testing
        - create a file in the tmp dir with content: Foo
        - create a ansible variable file with content: foo
        - run the fetch module with the following args:
            - dest: <tmpdir>
            - src: test_file
        - the result from the run() should be 'dest' (the local file) and:
            - exists: True
            - md5sum: d3b07384d113edec49eaa6238ad5ff00
            - src: test_file
            - changed: False
            - failed: False
            - file: test_file
            - checksum: d3b07384d113edec49eaa6238ad5ff00
    :return:
    """

    import tempfile
    import shutil

# Generated at 2022-06-11 11:43:33.837397
# Unit test for constructor of class ActionModule
def test_ActionModule():
    _task = {
        'args': {
            'src': 'test',
            'dest': 'test'
        }
    }
    action_module = ActionModule(_task, connection='connection')

# Generated at 2022-06-11 11:43:42.055707
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 11:43:42.640967
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule()

# Generated at 2022-06-11 11:44:10.136362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
        This test case is used to test the constructor of class ActionModule
    """
    task_vars = dict(
        test='ok'
    )
    def test_task_vars(self, task_vars):
        return task_vars
    # mock to execute _execute_module()
    import ansible
    am = ActionModule(
        task=dict(
            args=dict()
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    am._remove_tmp_path = lambda x: None
    am._execute_module = test_task_vars
    
    # test run()
    os.mkdir('testdata')

# Generated at 2022-06-11 11:44:11.567833
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert isinstance(am, ActionModule)

# Generated at 2022-06-11 11:44:12.351583
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:44:15.363826
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    data = open("/home/craig/projects/ansible/test/sanity/fetch/data.json", "r")
    result = json.load(data)
    print(result)

# Generated at 2022-06-11 11:44:16.267002
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    pass


# Generated at 2022-06-11 11:44:22.485660
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import os
    from ansible.plugins.action.fetch import ActionModule

    #test if method run works without error
    result = ActionModule(None, None).run(None, None)
    assert 'msg' in result
    assert result.get('msg') == 'Please specify src and dest'

    #test if method run works when build-in function makedirs_safe generates error
    def side_effect(path):
        raise OSError('error')
    ActionModule.makedirs_safe = side_effect
    result = ActionModule(None, None).run(None, None)
    assert 'failed' in result
    assert result.get('failed')

    #test if method run works when build-in function checksum generates error
    def side_effect_2(path):
        raise ValueError('ValueError')

# Generated at 2022-06-11 11:44:30.902187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import fixture_loader
    from ansible.plugins.action.fetch import ActionModule

    t = fixture_loader.load_fixture('/fetch/tasks.yml', 'tasks.yml')
    tqm = None
    play = t['playbooks'][0]['plays'][0]
    task = play['tasks'][0]
    task_vars = dict(magicvar='magic')
    runner = ActionModule(task, tqm, task_vars=task_vars)

    assert runner is not None

# Generated at 2022-06-11 11:44:34.597966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
        Unit test for get_action_plugin
    """
    action = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None

# Generated at 2022-06-11 11:44:38.967365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    # Test method run, with the '/etc/hosts' located in the ansible.cfg file, then with a specific value
    try:
        tmp = module.run(None, None)
    except SystemExit:
        tmp = None

    assert(tmp is None)

# Generated at 2022-06-11 11:44:41.910739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a class object of type "ActionModule"
    actionmodule_obj = ActionModule()

    # Check if the object created is of type "ActionModule"
    assert(type(actionmodule_obj) == ActionModule)


# Generated at 2022-06-11 11:45:25.930083
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = '127.0.0.1'
    connection = 'local'
    play_context = PlayContext()
    _loader = TestLoader()
    _tqm = TestTaskQueueManager()
    _shared_loader_obj = TestLoaderModule()
    _variable_manager = TestVariableManager()
    _task = Task()
    _task.args = {'src': 'path_src', 'dest': 'path_dest'}
    action_module = ActionModule(host, connection, play_context, _loader, _tqm, _shared_loader_obj, _variable_manager, _task)
    action_module.get_tmp_path = lambda: '/tmp'

    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-11 11:45:33.794321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Construction of ActionModule class
    '''
    am = ActionModule(
        task=dict(action=dict(module_name='fetch',
                              module_args=dict(src='foo', dest='bar'))),
        connection=dict(transport='ssh', user='test'),
        play_context=dict(),
        loader=None,
        variable_manager=None,
        loader_cache=dict()
    )
    assert am

# Generated at 2022-06-11 11:45:39.432893
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)
    assert module._task is None
    assert module._connection is None
    assert module._play_context is None
    assert module._loader is None
    assert module._templar is None
    assert module._shared_loader_obj is None
    assert module._loaded_file_names is None
    assert module._task_vars is None
    assert module._inject is None

# Generated at 2022-06-11 11:45:40.858500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
# vim: set et ts=4 sw=4 :

# Generated at 2022-06-11 11:45:43.998549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 11:45:46.196629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmodule = ActionModule()
    result = actionmodule.run()
    assert result == dict()  # TOOD: Test actual method

# Generated at 2022-06-11 11:45:53.148962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(connection=None,
                      play_context=None,
                      new_stdin=None)
    am._loader = None
    source = os.path.realpath(__file__)
    dest = '/tmp/123'
    result = am.run(task_vars=dict(),
                    tmp=None,
                    **{'src': source, 'dest': dest})
    print(result)
    assert result == {'changed': False,
                      'checksum': '0a0a9f2a6772942557ab5355d76af442f8f65e01',
                      'dest': '/tmp/123/%s' % source,
                      'file': source,
                      'md5sum': 'd41d8cd98f00b204e9800998ecf8427e'}

# Generated at 2022-06-11 11:45:53.755127
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:46:00.390080
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule('test_play_context', dict(), 'test_loader', 'test_templar', 'test_shared_loader_obj')
    assert action._play_context is 'test_play_context'
    assert action._task.action == 'test_ActionModule'
    assert action._loader is 'test_loader'
    assert action._templar is 'test_templar'
    assert action._shared_loader_obj is 'test_shared_loader_obj'

# Generated at 2022-06-11 11:46:11.381675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    validate the run method of fetch module works as expected
    '''
    import sys, os, shutil
    # set up the infrastructure need to test the method
    # stdout, stderr, stdin
    import StringIO

    # mock return values of external dependencies on the module
    def fake_execute_remote_stat(self, source, all_vars=None, follow=True):
        '''
        mock for the method _execute_remote_stat of the module
        '''
        class remote_stat():
            pass
        fake_remote_stat = remote_stat()
        fake_remote_stat.checksum = "fake_remote_stat"
        fake_remote_stat.exists = True
        fake_remote_stat.isdir = False
        return fake_remote_stat


# Generated at 2022-06-11 11:47:25.404902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 11:47:32.743227
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    src = "test/test"
    dest = "hoge/foo"
    ansible_vars = {
        'ansible_inventory_hostname': 'localhost'
    }
    task_vars = {
        'inventory_hostname': 'localhost'
    }
    self = ActionModule()
    self._remove_tmp_path("/tmp/ansible")

    self.run(dest=dest, src=src, task_vars=task_vars)
    print("hoge".split("/"))


if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-11 11:47:35.776521
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    return a

# Generated at 2022-06-11 11:47:37.399911
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None) is not None

# Generated at 2022-06-11 11:47:41.047461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert module is not None

# Generated at 2022-06-11 11:47:41.946746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: How do we test this?
    pass

# Generated at 2022-06-11 11:47:49.396476
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(action='',
                        task=dict(args={}),
                        connection='',
                        play_context=dict(become=False, become_method=None, become_user=None, check_mode=False,
                                          diff_mode=False, new_vault_password_file=None, passwords=None, remote_addr='',
                                          remote_user='', shell=None, sudo_exe=None, sudo_flags=None, sudo_pass=None,
                                          sudoable=False, su=False, su_pass=None),
                        loader=None,
                        templar=None,
                        shared_loader_obj=None)




# Generated at 2022-06-11 11:47:58.998875
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    import builtins
    import sys
    import importlib
    import unittest
    import xmlrunner

    import ansible.plugins.action

    runner = xmlrunner.XMLTestRunner(output='target/test-reports')
    loader = unittest.TestLoader()

    # We are currently extending the modules ansible.plugins.action.ActionBase
    # and ansible.plugins.action.ActionBase.run of class ActionBase
    # We need to mock methods and members of class ActionBase

    # The class ActionBase has the following members
    # .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .

# Generated at 2022-06-11 11:48:08.360939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from unittest import TestCase
    from ansible.plugins.action.fetch import ActionModule

    class FakeModule(object):
        def _execute_module(self):
            pass

        def _execute_remote_stat(self):
            pass

        def fetch_file(self):
            pass

        def _remove_tmp_path(self):
            pass

    class FakeContext(object):
        def __init__(self):
            self._shell = FakeModule()
            self.remote_addr = '127.0.0.1'

    class FakeTask(object):
        def __init__(self):
            self._task_vars = {'test_key': 'test_value'}
            self._play_context = FakeContext()

    class FakeConnection(object):
        def __init__(self):
            self._

# Generated at 2022-06-11 11:48:17.989258
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import unittest
    import sys
    import uuid

    class ActionModule_runTestCase(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None

        def tearDown(self):
            del self.maxDiff

        def test_validate_checksum(self):

            # Test if method validate_checksum returns False if the value is
            # not Boolean
            test_module = ActionModule()
            source = str(uuid.uuid1())
            dest = str(uuid.uuid1())

            parameters = {"src":source, "dest":dest, "validate_checksum":None}
            test_module.set_options(parameters)
            test_result = test_module.validate_checksum()
            expected_result = False

# Generated at 2022-06-11 11:51:56.858496
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins
    from ansible.plugins.action.fetch import ActionModule
    from ansible.utils import context_objects as co
    from ansible.parsing.dataloader import DataLoader

    # Initialize context manager
    c = co.ActionContext(config=dict(config_file='ansible.cfg'))
    c._shell = None
    c.connection = None
    c.play = None
    c.task_vars = dict()
    conn = ansible.plugins.connection.local.Connection(c)
    c.connection = conn

    d = DataLoader()
    c.loader = d
    c.variable_manager = ansible.vars.VariableManager()
    c.variable_manager.extra_vars = dict()
    c.variable_manager.options_vars = dict()



# Generated at 2022-06-11 11:52:04.390358
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    buf = {'results': [{'stdout': '', 'changed': False}, {'stdout': '', 'changed': False}]}
    TestActionModule = ActionModule()
    TestActionModule.args = {'src': 'Test.txt', 'dest': 'Test.txt'}
    TestActionModule._task = "fetch"

# Generated at 2022-06-11 11:52:06.624776
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This function is used to do unit test of the method run of class ActionModule.
    """
    pass

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 11:52:13.341235
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
