

# Generated at 2022-06-11 11:42:31.626234
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_action_module = ActionModule('test_task', 'test_connection', 'test_play_context', 'test_loader', 'test_templar', 'test_shared_loader_obj')
    assert isinstance(test_action_module, ActionModule)

# Generated at 2022-06-11 11:42:34.180982
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    myaction = ActionModule({})
    result = myaction.run({'connection': 'local'})
    assert type(result) is dict
    assert result.get('changed') is False
    assert result.get('failed') is False

# Generated at 2022-06-11 11:42:34.951819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 11:42:46.492218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    c1 = dict(name="localhost",
              host="127.0.0.1",
              port=10001,
              user="ansible",
              passwd="passwd",
              priv="priv",
              timeout=1,
              become_pass=None,
              become=True,
              become_method="su")
    c1["connection_plugin"] = "local"

    c = dict(
        task=dict(vars=dict()),
        play_context=dict(
            remote_port=10001,
            become=False,
            become_user="ansible",
            become_pass=None,
            become_method="su",
        ),
    )


# Generated at 2022-06-11 11:42:47.742083
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None)
    assert am is not None

# Generated at 2022-06-11 11:42:58.996777
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule.
    """
    import os
    import tempfile

    def touch():
        """
        Emulate 'touch' shell command
        """
        with tempfile.NamedTemporaryFile(delete=False) as f:
            f.write(os.urandom(1024))
            return f.name

    def rm(name):
        os.remove(name)

    def norm(path):
        return os.path.normpath(path)

    class Conn(object):
        def __init__(self):
            self._shell = Shell()
            self.become = None

        def fetch_file(self, source, dest):
            rm(dest)
            os.rename(source, dest)

    class Shell(object):
        def __init__(self):
            self.tmp

# Generated at 2022-06-11 11:43:10.806766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create test data for method run of class ActionModule
    data = dict()
    data['tmp'] = None
    data['task_vars'] = dict()
    data['connection'] = dict()
    data['connection']['module_implementation_preferences'] = ['smart']
    data['connection']['_shell'] = dict()
    data['connection']['_shell']['join_path'] = lambda x,y: y
    data['connection']['_shell']['_unquote'] = lambda x: x
    data['connection']['_execute_module'] = lambda x,y,z,: dict(failed=False, encoding='base64', content='RVhQTA==')
    data['connection']['fetch_file'] = lambda x,y: None

# Generated at 2022-06-11 11:43:14.492397
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(display, {}, "/tmp", False, None)
    assert am.display == display
    assert am._shared_loader_obj == {}
    assert am._task.args == {}
    assert am._connection.tmpdir == "/tmp"


# Generated at 2022-06-11 11:43:25.638197
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # use file /etc/hosts as we know it exists on all OSes
    test_arguments = dict(src='/etc/hosts', dest='/tmp/fetch_test_temp')

    # create a valid connection and task_vars
    mock_tqm = MagicMock()
    mock_tqm.hostvars = dict()

    test_host_connection = Connection(mock_tqm)
    test_task_vars = dict()

    # create an instance of ActionModule
    test_instance = ActionModule(
        task=MagicMock(),
        connection=test_host_connection,
        play_context=PlayContext(),
        loader=MagicMock(),
        templar=MagicMock(),
        shared_loader_obj=None
    )

    # run result = test_instance.run

# Generated at 2022-06-11 11:43:36.692731
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = {
        'host': 'myhost',
        'user': 'myuser',
        'port': 'myport',
        'password': 'mypassword',
        }
    task_vars = {
        }
    result = {}
    src = 'source'
    dest = 'destination'
    flat = 'false'
    fail_on_missing = 'false'
    validate_checksum = 'false'
    args = {
        'src': src,
        'dest': dest,
        'flat': flat,
        'fail_on_missing': fail_on_missing,
        'validate_checksum': validate_checksum,
        }

# Generated at 2022-06-11 11:43:53.020177
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None)

# Generated at 2022-06-11 11:44:02.383487
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Pass
    a = dict(a=1)
    actionmodule = ActionModule(a, dict())
    assert isinstance(actionmodule, ActionModule)
    actionmodule.run(None, None)
    assert isinstance(actionmodule, ActionModule)
    
    # Fail
    try:
        actionmodule = ActionModule(None, None)
    except AttributeError as e:
        assert isinstance(e, AttributeError)

# Execute unit test if we are being executed as a stand-alone script
if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-11 11:44:03.952184
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule('test', None, '/', {}, {}))


# Generated at 2022-06-11 11:44:14.923338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import mock

    import ansible.executor.task_result
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role_path import RolePath
    from ansible.playbook.block import Block
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-11 11:44:19.121096
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not bool(ActionModule({}, {}, {},
                                 task_vars={},
                                 connection='connection',
                                 task_executor='task_executor',
                                 loader='loader',
                                 play_context='play_context',
                                 shared_loader_obj='shared_loader_obj',
                                 variable_manager='variable_manager',
                                 templar='templar'
                                 )
                   )


# Generated at 2022-06-11 11:44:20.154000
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module

# Generated at 2022-06-11 11:44:22.859298
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module

# Generated at 2022-06-11 11:44:34.345202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.ftos.ftos import ftos_argument_spec
    from ansible.module_utils.network.ftos.ftos import ftos_parse_banner

    source = '/etc/motd'
    dest = '/home/user/ansible_test_dir'

    task_vars = dict()

    argspec = ftos_argument_spec()
    connection = Connection(ftos_parse_banner, argument_spec=argspec)


# Generated at 2022-06-11 11:44:35.349454
# Unit test for constructor of class ActionModule
def test_ActionModule():
    sut = ActionModule()

# Generated at 2022-06-11 11:44:36.524273
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am

# Generated at 2022-06-11 11:45:12.177572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return ActionModule(connection=None, play_context=None, new_stdin=None)

# Generated at 2022-06-11 11:45:13.595234
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:45:16.070943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None, None, {}, 'action', 'module', None, None, None, None, None)
    # Add code here


# Generated at 2022-06-11 11:45:17.528608
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, {}, {}, None, 'localhost', None, None, {})

# Generated at 2022-06-11 11:45:22.343630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(connection=None,
            task_uuid=None,
            loaders=[None],
            variable_manager=[None],
            loader=None,
            templar=None,
            shared_loader_obj=None)
    assert am is not None


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-11 11:45:23.038654
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, 'TODO: write this'

# Generated at 2022-06-11 11:45:23.524343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:45:36.095035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = dict()
    m = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    m._remove_tmp_path = lambda x: None
    m._execute_remote_stat = lambda src, all_vars, follow: dict(checksum=None, exists=False, isdir=False)
    m._execute_module = lambda name, args, task_vars: dict()
    m._connection = dict(become=True)
    m._loader = dict(path_dwim=lambda x: x)
    m._play_context = dict(remote_addr='127.0.0.1')

# Generated at 2022-06-11 11:45:36.800729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 11:45:37.874798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  assert True # FIXME: implement your test here

# Generated at 2022-06-11 11:46:54.327426
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    source_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))
    source_dir += "/lib/ansible/playbooks/"

# Generated at 2022-06-11 11:46:55.512320
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)


# Generated at 2022-06-11 11:47:03.798393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import __builtin__
    setattr(__builtin__, '__ansible_module_mocks__', {})
    __builtin__.__ansible_module_mocks__['ansible.utils.hashing'] = {'checksum': 'checksum',
                                                                     'checksum_s': 'checksum_s',
                                                                     'md5': 'md5',
                                                                     'secure_hash': 'secure_hash'}

    import ansible.plugins.action.copy as copy_module
    import ansible.plugins.action.fetch as fetch_module

    setattr(__builtin__, '__ansible_module_mocks__', {})

# Generated at 2022-06-11 11:47:15.829620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action._connection = FakeConnection()
    task_vars = dict()
    args = dict(src='file1', dest='/tmp/file1', flat=False, validate_checksum=True)
    res = action.run(None, task_vars, args)
    assert res['changed'] == True
    assert res['file'] == args['src']
    assert res['md5sum'] is None
    assert res['remote_md5sum'] is None
    assert res['checksum'] == '6b21c2e68e0c13d90f04a3e3e3b3a80a829fbe44'

# Generated at 2022-06-11 11:47:23.431617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.connection.test import test_connection
    connection = test_connection()
    action_module = ActionModule(connection=connection, task=None, play_context=None)
    assert action_module._play_context.connection == 'local'
    assert action_module._task.action == 'fetch'
    action_module._task.args = {'src': 'src', 'dest': 'dest'}
    action_module.run(tmp=None, task_vars=None)
    assert_result = dict(changed=False, dest='dest', file='src')
    action_module._task.args = {'src': 'src', 'dest': 'dest', 'flat': True}
    action_module.run(tmp=None, task_vars=None)

# Generated at 2022-06-11 11:47:24.504864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule


# Generated at 2022-06-11 11:47:34.340340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = u'test_ActionModule_run'
    tmpdir = ('/home/user')
    task_vars = dict(test_dict=dict(test=1, test_list=[1,1], test_dict=dict(test=True)))
    src = u'test'
    dest = u'test'
    flat = False
    fail_on_missing = True
    validate_checksum = False
    remote_checksum = u'#SAVED_CHECKSUM'
    remote_md5 = u'#SAVED_MD5'
    remote_data = None
    remote = dict(checksum=remote_checksum, md5sum=remote_md5, data=remote_data)
    _shell = MagicMock()
    _shell._unquote.return_value = src
    _shell.join_path

# Generated at 2022-06-11 11:47:36.252325
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME: we should properly mock this out, but we need to change how
    #        ActionBase.run works
    pass

# Generated at 2022-06-11 11:47:38.832371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    a = ActionModule()

    # Check if the instance is an instance of ActionBase
    assert isinstance(a, ActionBase)

# Generated at 2022-06-11 11:47:41.855474
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None)
    assert action_module is not None
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-11 11:50:46.321070
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import collections  # import is needed here to create ordered dict

    # Create instance of class ActionModule
    moduleObj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create instance of class ActionBase
    actionBaseObj = ActionBase(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create instance of class AnsibleActionFail
    ansibleActionFailObj = AnsibleActionFail("ansible_action_fail")

    # Create instance of class AnsibleActionSkip
    ansibleActionSkipObj = AnsibleActionSkip("ansible_action_skip")

    # Create instance of class AnsibleError

# Generated at 2022-06-11 11:50:54.131220
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # In order to test ActionModule(), we need to create an instance of the
    # class. However it requires the __init__() method to be invokeable,
    # which involves some parameters.
    # First we create an instance of the class Task that is required for
    # the constructor of ActionModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = Inventory

# Generated at 2022-06-11 11:50:56.057486
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test class creation
    am = ActionModule()
    assert am is not None
# end of test_ActionModule

# Generated at 2022-06-11 11:51:04.570027
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:51:05.197712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 11:51:08.104275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    connection = Mock()
    connection._shell = Mock()
    
    action_module = ActionModule(self=None, task=None, connection=connection, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    
    action_module.run()

# Generated at 2022-06-11 11:51:09.818533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, None, None, None)
    assert isinstance(am, ActionModule)

# Generated at 2022-06-11 11:51:11.307860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(None, None, None, None), ActionModule)

# Generated at 2022-06-11 11:51:19.204025
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    action_module = ansible.plugins.action.ActionModule(
        task=dict(
            args=dict(
                path='/fake/system_path',
                mode='0644'
            ),
        ),
        connection=None,
        _play_context=dict(
            basedir='/fake/basedir',
            remote_addr='127.0.0.1',
        ),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

# Generated at 2022-06-11 11:51:27.332565
# Unit test for constructor of class ActionModule