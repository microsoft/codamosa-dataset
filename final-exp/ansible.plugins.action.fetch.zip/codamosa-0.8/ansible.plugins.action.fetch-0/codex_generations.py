

# Generated at 2022-06-11 11:42:30.948986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.utils.path import unfrackpath

    cwd = unfrackpath('.')
    result = dict(cwd=cwd)
    m = ActionModule(None, None, result=result)
    assert m.cwd == cwd

# Generated at 2022-06-11 11:42:37.869832
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 11:42:39.414498
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement test
    return True

# Generated at 2022-06-11 11:42:47.487860
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest

    try:
        from unittest.mock import MagicMock
    except:
        from mock import MagicMock

    # An instance of class ActionModule
    obj = MagicMock()

    # Methods of obj
    obj._play_context = MagicMock()
    obj._task.args = {'src': '/test', 'dest': '/test/test'}
    obj._connection = MagicMock()

    # Test function run
    assert ActionModule.run(obj, tmp='/test1', task_vars='/task_vars') == {'error': 'The requested operation does not exist on the target system.'}

# Generated at 2022-06-11 11:42:53.686371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule.
    '''

    from ansible.playbook.task import Task

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.inventory.manager import InventoryManager

    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader

    from ansible.utils.display import Display

    display = Display()
    Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff'])

# Generated at 2022-06-11 11:43:05.070328
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from datetime import datetime
    source = '/etc/hosts'
    original_dest = dest = '/tmp'
    flat = boolean(False, strict=False)
    fail_on_missing = boolean(True, strict=False)
    a = ActionModule(None, None, None, None, None, None, None, datetime.now(), None, None, None, None, None, None, None,
        source=source, dest=original_dest, flat=flat, fail_on_missing=fail_on_missing)
    assert a.flat == flat, 'ActionModule.flat not set correctly'
    assert a.fail_on_missing == fail_on_missing, 'ActionModule.fail_on_missing not set correctly'
    assert a.source == source, 'ActionModule.source not set correctly'

# Generated at 2022-06-11 11:43:15.629796
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.connection.local import Connection

    from ansible.parsing.dataloader import DataLoader

    from ansible.playbook.play_context import PlayContext

    from ansible.module_utils.common.collections import ImmutableDict

    from ansible.vars.manager import VariableManager

    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.inventory.manager import InventoryManager

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    task_vars = {
        'inventory_hostname': 'localhost',
        'hostvars': {
            'localhost': {
                'inventory_hostname': 'localhost',
            }
        }
    }


# Generated at 2022-06-11 11:43:17.796826
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule()
    assert action_mod is not None

# Generated at 2022-06-11 11:43:27.995190
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Setup
    host = MagicMock()
    play_context = MagicMock()
    new_stdin = MagicMock()
    loader = MagicMock()
    templar = MagicMock()
    shared_loader_obj = None
    # Mocking a class within a class
    class MockConnection():
        class MockShell():
            def __init__(self):
                self.tmpdir = None
                self.join_path = lambda x,y: x + y
        def __init__(self):
            self._shell = MockConnection.MockShell()
        def become(self):
            return False
        def fetch_file(x,y):
            pass
    connection = MockConnection()
    task_vars = {}
    wrap_async = MagicMock()

# Generated at 2022-06-11 11:43:34.370670
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    print("Function test_ActionModule_run")

    # Initialize the test object
    am = ActionModule()

    # Create the test object
    am = ActionModule()

    # Initialize the test variables
    # There can not be a test for this function because it interacts with the file system
    # The function is not tested
    print("End of function test_ActionModule_run")


# Generated at 2022-06-11 11:44:05.628844
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.action import ActionModule
    from ansible.parsing.task_parser import TaskParser
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.init import Inventory
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.errors import AnsibleActionFail, AnsibleActionSkip
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.utils.display import Display

# Generated at 2022-06-11 11:44:07.143225
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None, None, None)

# Generated at 2022-06-11 11:44:17.388850
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test what happens when the destination file does not exist
    actionModule = ActionModule()
    task_vars = dict()
    source = "test/test.txt"
    dest = "dest"
    flat = False

    # Initialize the class with default values
    result = actionModule.run(tmp=None, task_vars=task_vars)

    # test what happens when the directory traversal is detected
    actionModule = ActionModule()
    task_vars = dict()
    source = "test/test.txt"
    dest = "/../dest"
    flat = False

    # Initialize the class with default values
    result = actionModule.run(tmp=None, task_vars=task_vars)

    # test what happens when the source file does not exist
    actionModule = ActionModule()
    task_vars

# Generated at 2022-06-11 11:44:24.932487
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    source = 'tests/test_docs/test_docs_inventory.yml'
    dest = 'tests/test_docs/test_docs_inventory.yml'
    task = dict(src = source, dest = dest)
    task_vars = dict()
    tmp = '/tmp'
    p = None
    result = a.run(tmp, task_vars)
    assert result['failed'] is False
    assert result['dest'] == dest
    assert result['file'] == source

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 11:44:36.525337
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 11:44:45.513834
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import base64
    import random, string

    # Generate test input:
    # create the containing directories
    makedirs_safe(os.path.dirname(dest))
    # fetch the file and check for changes
    with open(to_bytes(dest, errors='surrogate_or_strict'), 'wb') as f:
        f.write(remote_data)
    new_checksum = secure_hash(dest)
    # For backwards compatibility. We'll return None on FIPS enabled systems
    try:
        new_md5 = md5(dest)
    except ValueError:
        new_md5 = None

    # Run test
    am = ActionModule()
    am.tmpdir = tempfile.mkdtemp()

    # Check correct behaviour

# Generated at 2022-06-11 11:44:54.059855
# Unit test for constructor of class ActionModule
def test_ActionModule():
    conn = {}
    connection = type('connection', (object,), conn)
    play_context_data = {
        'become': False,
        'become_method': '',
        'become_user': '',
        'connection': '',
        'diff': False,
        'remote_addr': '192.168.1.1',
        'remote_user': '',
        'shell': type('MockAnsibleShell', (object,), {'join_path': lambda self, x: x})(),
        'user': ''
    }
    play_context = type('play_context', (object,), play_context_data)
    play_context.check_mode = False
    play_context._shell = play_context.shell

# Generated at 2022-06-11 11:45:03.378399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    import ansible.playbook.play_context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible import context
    import os

    # set up context
    context.CLIARGS = ansible.utils.context.CLIARGS
    playbook_path = os.path.join(os.path.dirname(__file__), '../../../examples/ansible.cfg')
    c = ansible.playbook.play_context.PlayContext(playbook=playbook_path)
    c.loader = ansible.parsing.datal

# Generated at 2022-06-11 11:45:14.018787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleError, AnsibleActionFail, AnsibleActionSkip
    from ansible.utils.display import Display
    display = Display()
    src = 'path\src'
    dest = 'path\dest'
    fail_on_missing = True
    validate_checksum = True
    task_vars = dict()
    flat = False
    actionBase = ActionBase()
    actionBase._display = display
    actionBase._task = dict()
    actionBase._task.args = dict()
    actionBase._task.args['src'] = src
    actionBase._task.args['dest'] = dest
    actionBase._task.args['flat'] = flat
    actionBase._task.args['fail_on_missing'] = fail_on_missing
    actionBase._task.args['validate_checksum'] = validate

# Generated at 2022-06-11 11:45:15.336551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test constructor of class ActionModule
    """
    assert ActionModule is not None

# Generated at 2022-06-11 11:45:37.828340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit test for method run of class ActionModule'''
    ActionModule = _get_ActionModule_class_mock()
    am = ActionModule()
    am.run()



# Generated at 2022-06-11 11:45:42.244321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.fetch as fetch
    with open('/etc/ansible/hosts', 'rb') as f:
        host_info = f.read()
    test_result = fetch.ActionModule(host_info)
    assert test_result is not None


# Generated at 2022-06-11 11:45:48.979904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arguments = dict(
        src="/tmp/test",
        dest="/tmp/test/test",
        flat=True,
        fail_on_missing=True,
        validate_checksum=False
    )
    test1 = ActionModule(dict(
        task=dict(args=arguments)
        )
    )
    assert test1._task.args == arguments
    assert test1._play_context == None
    assert test1._loader == None
    assert test1._connection == None

# Generated at 2022-06-11 11:45:50.675869
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule(None,None)
    assert action_module_obj.run() == None

# Generated at 2022-06-11 11:46:01.262412
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager

    inventory = dict(hostvars=dict(sbx_nxos_lc_701_1=dict(ansible_host="1.1.1.1")))
    play_context = PlayContext(remote_addr="127.0.0.1", connection='local', become=False, become_method='sudo', become_user='admin', verbosity=0)
    task = Task().load(dict(action=dict(module="copy", src="/tmp/test_file", dest="/tmp/ansible_fetch_test"), register=dict(result='my_result')))

# Generated at 2022-06-11 11:46:12.187920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor import task_result
    from ansible.executor.task_result import TaskResult
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.task_executor import TaskExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.included_file import IncludedFile

# Generated at 2022-06-11 11:46:13.574142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    try:
        action.run()
    except Exception:
        pass
    assert True

# Generated at 2022-06-11 11:46:24.365389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")

    from modules.testing.selftest_module import AnsibleModuleStub
    from ansible.plugins.action import ActionBase
    import ansible.plugins.action.fetch as fetch
    import os

    tmpdir = os.path.join(os.path.expanduser('~'), '.ansible/test')
    if not os.path.exists(tmpdir):
        os.mkdir(tmpdir)

    test_file = os.path.join(tmpdir, 'test_file')
    open(test_file, 'w').write('This is a test')


# Generated at 2022-06-11 11:46:25.382224
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert(isinstance(ActionModule.run, object))

# Generated at 2022-06-11 11:46:25.978658
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action=ActionModule()

# Generated at 2022-06-11 11:47:17.197007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None)
    assert action.name.startswith('include_')

# Generated at 2022-06-11 11:47:22.251672
# Unit test for constructor of class ActionModule
def test_ActionModule():
    display = Display()
    config = dict(DEFAULT_MODULE_UTILS="test/module_utils",SUDO_EXE="sudo", ANSIBLE_FORCE_COLOR="True")
    pm = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Test ActionModule.setup()
# Test ActionModule.run()
# Test ActionModule.post_validate()
# Test ActionModule.dump_results()

# Generated at 2022-06-11 11:47:23.266059
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None


# Generated at 2022-06-11 11:47:24.054091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:47:24.592331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:47:34.434826
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """

    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.task_executor import TaskExecutor

    display = Display()
    loader = DataLoader()
    results_callback = CallbackBase()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager

# Generated at 2022-06-11 11:47:44.526971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.builtins import range
    import random
    import tempfile
    fd, tmp_file = tempfile.mkstemp(suffix='nose-ansible')
    os.close(fd)
    os.remove(tmp_file)
    tmp_file = to_bytes(tmp_file)
    original_file = tmp_file + to_bytes(".original")
    if PY2:
        original_md5 = 'd41d8cd98f00b204e9800998ecf8427e'

# Generated at 2022-06-11 11:47:48.913227
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test variables
    test_task_vars = dict()
    test_args = dict(
        src='test_src',
        dest='test_dest',
        flat=True,
        fail_on_missing=True,
        validate_checksum=True,
    )
    test_tmp = '/test/path'

    # Temporary action module item
    test_action = ActionModule()

    # Read test variables
    test_action.task_vars = test_task_vars
    test_action.task = dict(args=test_args)
    test_action._connection = dict(become=False)
    test_action._play_context = dict(check_mode=False)
    test_action._task.action = 'ansible.legacy.actions.fetch'

# Generated at 2022-06-11 11:47:49.491581
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 11:47:54.301735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Create ActionModule instance with invalid parameters
    """
    import datetime
    my_time = datetime.datetime.now()
    try:
        a = ActionModule(my_time, my_time, my_time)
        assert(False)
    except Exception as e:
        print("Passed - " + str(e))

# Generated at 2022-06-11 11:49:51.273330
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import sys
    import ast
    from copy import copy
    from ..action.ActionModule import ActionModule
    from ansible.config.manager import ensure_type
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.become import Become
    from ansible.playbook.role.include import IncludeRole
    from ansible.plugins.action.fetch import ActionModule
    from ansible.template import Templar
    from ansible.inventory.group import Group

# Generated at 2022-06-11 11:49:59.842854
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock the module arguments to use when testing the run method
    args = dict(
        src='/etc/passwd',
        dest='/tmp/passwd',
        flat='yes',
        fail_on_missing='yes',
        validate_checksum='yes'
    )

    task = dict(action=dict(module='fetch', args=args))

    # A class that simulates the object returned by the executor
    # run() method
    class AnsibleResult:
        def __init__(self, task):
            self.task = task

    # AnsibleResult object
    ansible_result = AnsibleResult(task)

    # Execute the code that we want to test
    action_module = ActionModule()

    # Execute the run method, using the mocked arguments

# Generated at 2022-06-11 11:50:00.944278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule("module_name")
    assert isinstance(module, ActionModule)

# Generated at 2022-06-11 11:50:10.190387
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MyTask:
        def __init__(self):
            self.args = {}

    class MyLoader:
        def __init__(self):
            self.path_dwim_result = None

        def path_dwim(self, x):
            return self.path_dwim_result

    class MyConnection:
        class MyShell:
            def __init__(self):
                self.tmpdir = 'tmpdir'
                self.join_path_result = None

            def join_path(self, x):
                return self.join_path_result

    class MyDisplay:
        def __init__(self):
            self.display_dict = {}

        def display(self, x, *args, **kwargs):
            self.display_dict = x


# Generated at 2022-06-11 11:50:19.221388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ConnectionMock:
        @classmethod
        def _remote_expand_user(cls, path):
            return path

    class TaskMock:
        @classmethod
        def __init__(self):
            self._task = {'args': {'src': '/a/b', 'dest': '/a/b'}}

    am = ActionModule()

    am._execute_remote_stat = lambda path, all_vars, follow: {'exists': True}
    am._connection = ConnectionMock()
    am._connection._shell = ConnectionMock()
    am._connection._shell.tmpdir = 'tmpdir'
    am._connection._shell._unquote = lambda path: path
    am._connection._shell.join_path = lambda a, b: '/'.join([a, b])
    am._connection.fetch

# Generated at 2022-06-11 11:50:20.791144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for run() method of ActionModule class """
    pass  # placeholder - implemented on a case by case basis

# Generated at 2022-06-11 11:50:21.319616
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:50:28.995260
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test method ActionModule.run
    '''
    from ansible.utils.vars import merge_hash
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import UnparseableVaultSecret
    from ansible.parsing.vault import AnsibleVaultError
    import sys

    #TODO: Test other paths
    sys.path.append('tests/unit/')
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    import json



# Generated at 2022-06-11 11:50:30.413333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(connection=None, runner=None, task=None)
    assert(am)

# Generated at 2022-06-11 11:50:32.489605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #Initialize
    #Test

    #Assert

    pass