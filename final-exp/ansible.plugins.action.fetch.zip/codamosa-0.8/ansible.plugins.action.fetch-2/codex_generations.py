

# Generated at 2022-06-11 11:42:28.920130
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None, None, None)

# Generated at 2022-06-11 11:42:29.704322
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-11 11:42:35.432266
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # create an instance of a test object
    test_object = AnsibleActionSkip('foo')
    assert test_object.message == 'foo'

    test_object = AnsibleError('bar')
    assert test_object.message == 'bar'

    test_object = AnsibleActionFail('baz')
    assert test_object.message == 'baz'

    # create an instance of a ActionModule object
    test_object = ActionModule()
    assert hasattr(test_object, "run")
    assert hasattr(test_object, "_execute_module")
    assert hasattr(test_object, "_execute_remote_stat")

# Generated at 2022-06-11 11:42:46.583848
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.utils.hashing import checksum
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    import json

    import tempfile
    import os

    source = 'example.txt'
    contents = b'foo bar baz'

    tmp = tempfile.mkdtemp()
    open(os.path.join(tmp, source), 'w').write(to_bytes(contents))

    # This is a bit of a hack, but seems to be the easiest way to test the class.
    # It would be better to use TestCase, but that seems to be too hard.
    #pylint: disable=R0903

# Generated at 2022-06-11 11:42:49.437824
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    success = isinstance(action, ActionModule)
    assert success


# Generated at 2022-06-11 11:43:00.931589
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile
    from ansible.cli import CLI
    import ansible.constants as C

    # Setup connection plugin implementation
    Connection = ConnectionBase.get_plugin('local')
    connection

# Generated at 2022-06-11 11:43:04.748424
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule( { 'src':'xxx', 'dest':'yyy' } )
    assert a._task.args.get('src') == 'xxx'
    assert a._task.args.get('dest') == 'yyy'


# Generated at 2022-06-11 11:43:15.420276
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Tests
    ###########################################################################

    # TODO: fix test_fetch
    import pytest
    pytest.skip("Test skipped: The fetch module cannot be mocked, this test is not reliable")
    ###########################################################################

    # Setup
    ###########################################################################

    # Get test data/objects
    t_data = ActionModuleData(ActionModuleData.fetch_1)
    t_task = AnsibleTask(t_data.task_1)

    # Get test environment
    import ansible.utils.hashing
    from ansible.utils.hashing import _md5, _md5_for_file
    original_checksum = ansible.utils.hashing.checksum
    original_md5 = ansible.utils.hashing.md5
    original_md5_for_file = ansible.utils

# Generated at 2022-06-11 11:43:26.524447
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class MyActionModule(ActionModule):
        def __init__(self):
            pass

        def _execute_remote_stat(self, source, all_vars, follow=None):
            return {
                'stat': {
                    'exists': True,
                    'isdir': False
                }
            }

        def _execute_module(self, module_name, module_args, task_vars):
            return {
                'encoding': 'base64',
                'content': "SGVsbG8="
            }

        def _remove_tmp_path(self, tmp):
            pass

        def _remote_expand_user(self, path):
            return path

    am = MyActionModule()
    # Should not explode, it just fails
    assert not am.run(task_vars={})['failed']



# Generated at 2022-06-11 11:43:37.477108
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    source = 'test_source'
    dest = 'test_dest'
    flat = 'test_flat'
    fail_on_missing = 'test_fail_on_missing'
    validate_checksum = 'test_validate_checksum'
    tmp = 'test_tmp'
    task_vars = dict()
    args = dict(src=source, dest=dest, flat=flat, fail_on_missing=fail_on_missing, validate_checksum=validate_checksum)
    loader = None

    pc = PlayContext()
    pc.remote_addr = '127.0.0.1'
    pc.become = True

# Generated at 2022-06-11 11:44:00.165009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    handler = ActionModule()
    tmp = None
    task_vars = {'foo': 'bar'}
    result = handler.run(tmp, task_vars)
    assert result['failed'] == True
    assert result['msg'] == 'src and dest are required'
    assert result['file'] == 'src'

# Generated at 2022-06-11 11:44:11.209136
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule._remove_tmp_path = lambda self, tmp: None
    ActionModule._execute_module = lambda self, module_name, module_args, task_vars: dict(
        encoding='base64',
        content='ImFub255bW91cyBmaWxlIg=='
    )


# Generated at 2022-06-11 11:44:17.953316
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = 'host'
    port = 2222
    user = 'user'
    password = 'password'
    connection = Connection(host, port, user, password)
    play_context = PlayContext()
    task = Task()
    loader = None
    templar = None
    shared_loader_obj = None
    action_module = ActionModule(connection, play_context, task, loader, templar, shared_loader_obj)
    assert action_module is not None

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 11:44:28.542856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def check(tmp=None, task_vars=None, connection=None):
        print("tmp=%s, task_vars=%s" % (tmp, task_vars))
        a = ActionModule(tmp, task_vars, connection)
        return a.run()

    class Connection():
        def __init__(self):
            self._shell = Shell()
            self.become = False
        def fetch_file(self, source, dest):
            pass

    class Shell():
        def __init__(self):
            self.join_path = lambda x, y: os.path.join(x, y)
            self.tmpdir = "/tmp/ansible_tmp"

    class Loader():
        def path_dwim(self, path):
            return path


# Generated at 2022-06-11 11:44:29.185782
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:44:31.455090
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with empty constructor
    am = ActionModule()
    assert am is not None
    del am

# Generated at 2022-06-11 11:44:41.951916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six.moves import builtins
    import errno
    import os
    import shutil

    import ansible.plugins.action.fetch
    from ansible.inventory.host import Host
    import ansible.utils.path
    import ansible.utils.template
    import ansible.vars.hostvars
    import tests

    # TODO: specify `task_vars` and `tmp` arguments
    module_obj = ansible.plugins.action.fetch.ActionModule(
        {'connection': None},
        {'src': None, 'dest': None, 'flat': None, 'validate_checksum': None},
        tests.get_config_obj(),
    )

    # TODO: setup `self._play_context`
    module_obj._play_context = tests.get

# Generated at 2022-06-11 11:44:42.521954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 11:44:50.532483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(ActionModule)
    print(ActionModule.__dict__)
    print(ActionModule.__doc__)
    print(ActionModule.__name__)
    print(ActionModule.__module__)
    print(ActionModule.__bases__)
    print(ActionModule.__class__)
    print(ActionModule.__class__.__name__)
    print(ActionModule.__class__.__doc__)
    # print(ActionModule._ActionModule__class__.__name__)
    # print(ActionModule._ActionModule__class__.__doc__)
    print(ActionModule._ActionModule__class__.__module__)
    print(ActionModule._ActionModule__class__.__bases__)
    print(ActionModule._ActionModule__class__.__dict__)


# Generated at 2022-06-11 11:44:59.484459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task = dict(args=dict(src='src', dest='dest', validate_checksum=True))
    module._connection = MockConnection()
    module._remove_tmp_path = MagicMock()
    module._execute_module = MagicMock(side_effect=lambda *args, **kwargs: dict(changed=True))
    module._execute_remote_stat = MagicMock(side_effect=lambda *args, **kwargs: dict(checksum='123'))
    module._play_context = MockPlayContext()
    module._remote_expand_user = MagicMock()
    module._loader = MockLoader()

    assert module.run() == dict(changed=True, checksum='123', remote_checksum='123', dest='dest', file='src', md5sum=None)

#

# Generated at 2022-06-11 11:45:47.383838
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    module._remove_tmp_path = lambda x: x
    module._execute_module = lambda x,y,z: x
    module._execute_remote_stat = lambda x,y,z: x
    module._connection._shell.join_path = lambda x, y: x
    module._connection._shell._unquote = lambda x: x
    module._connection._shell.tmpdir = '/tmp'
    module._connection.become = 'Yes'
    module._connection.fetch_file = lambda x, y: x
    module._play_context.check_mode = 'my_check_mode'

# Generated at 2022-06-11 11:45:59.293921
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import constants as C
    from ansible.utils.path import makedirs_safe
    from ansible.plugins.action.fetch import ActionModule

    # prepare for test
    test_dir = "/tmp/fetch"
    makedirs_safe(test_dir)
    result = {}

    # constructor test
    context = {"connection": "local", "port": 22}
    connection = {"name": "local"}
    play_context = {}
    new_stdin = None

    # create a fetch class
    task = {"action": {"__ansible_module__": "fetch"}, "args": {"src": "mock.file", "dest": test_dir}}

# Generated at 2022-06-11 11:46:01.604372
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert x is not None

# Generated at 2022-06-11 11:46:02.201388
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_in = ActionModule()
    return

# Generated at 2022-06-11 11:46:12.996313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert not ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)._connection
    assert not ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)._task
    assert not ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)._play_context

# Generated at 2022-06-11 11:46:23.448770
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    # SRC:
    # case 1: source is a directory
    source = "somepath/file1.txt"
    # case 2: source is a file
    source = "file2.txt"
    # case 3: src is not provided
    source = None
    temp = "file.txt"
    # case 4: source is not a string
    source = 12345
    source = source + " "

    # DEST:
    # case 1: dest is a directory
    dest = "somepath/file1.txt"
    # case 2: dest is a file
    dest = "file2.txt"
    # case 3: dest is not provided
    dest = None
    temp = "file.txt"
    # case 4: dest is not a string
    dest = 12345
    dest = dest

# Generated at 2022-06-11 11:46:27.605576
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit test to validate the method ActionModule.run
    '''
    print('Testing run')
    test = ActionModule()
    print(test)
    #print(test.run())

if __name__ == '__main__':
    print('Testing ActionModule')
    #test_ActionModule_run()

# Generated at 2022-06-11 11:46:28.123565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 11:46:36.926138
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #Create the class
    actionModule = ActionModule()

    #Set the return value of do_checksum
    actionModule.do_checksum = lambda x: "fakemd5"

    #Set the return value of do_copy
    actionModule.do_copy = lambda x, y: None

    #Set the return value of do_slurp
    actionModule.do_slurp = lambda x: "something"

    #Set the return value of do_recursive_directory_delete
    actionModule.do_recursive_directory_delete = lambda x: None

    #Set the return value of do_tempfile
    actionModule.do_tempfile = lambda x: "something"

    #Set the return value of do_getcwd
    actionModule.do_getcwd = lambda x: "something"

    #Set the return value of

# Generated at 2022-06-11 11:46:42.202809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert_false = False
    assert_true = True
    data =  {'args': {'src': 'README.md', 'dest': '/root', 'flat': assert_true, 'validate_checksum': assert_false}, 'failed': assert_false, 'msg': ''}
    action_module = ActionModule(data, 'localhost', '/a/b/c', 'user', 'pass', 'sudo', 'su', 'private_key', '22', False, False)
    assert action_module != None


# Generated at 2022-06-11 11:47:57.833083
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(None, None, None)
    assert x is not None

# Generated at 2022-06-11 11:47:58.359948
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert ActionModule()

# Generated at 2022-06-11 11:48:00.251786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test ActionModule constructor
    res = ActionModule()
    assert bool(res) is True



# Generated at 2022-06-11 11:48:09.331333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.copy
    from ansible.modules.copy import ActionModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost, '])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source = dict(
            name="Ansible Play",
            hosts='localhost',
            gather_facts='no',
            tasks=[
                dict(action=dict(module='copy', args=dict(src='/etc/hosts', dest='/tmp/z')))
             ]
        )

# Generated at 2022-06-11 11:48:10.195065
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "TODO"

# Generated at 2022-06-11 11:48:19.792289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    conn = Connection()
    play = Play()
    play.serial = 42
    task = Task()
    task_vars = dict(foo='bar')
    action = dict(src='/tmp/foo', dest='/tmp/bar', flat='yes')
    play.add_task(task)
    play.set_loader(DictDataLoader({}))
    play_context = play.set_connection('local')
    play_context._connection = conn
    task._role = None
    task._task = task
    task._play_context = play_context
    task._loader = DataLoader()
    task._tqm = None
    task._task = task
    task._task_vars = task_vars
    task._unreachable_hosts = dict()
    task._args = action
    actionmod = ActionModule

# Generated at 2022-06-11 11:48:28.660007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Set up arguments needed by ActionModule constructor
    args = {}
    args['task'] = {}
    args['task']['args'] = {'src': 'src', 'dest': 'dest'}
    args['task']['action'] = 'test_action'
    args['task']['args'] = {}
    args['task']['args']['src'] = 'src'
    args['task']['args']['dest'] = 'dest'
    args['task']['action_plugins'] = '/path/to/action_plugins'
    args['task']['module_name'] = 'test_module'
    args['task']['delegate_to'] = 'delegate_to'
    args['task']['async'] = 'async'

# Generated at 2022-06-11 11:48:36.499126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    from ansible.module_utils.parsing.convert_bool import boolean

    task_vars = dict()
    mock_ansible_module = mock.MagicMock()
    mock_ansible_module.mock_add_spec(['exit_json'])
    mock_ansible_module.module.params = {
        'src': 'foo',
        'dest': 'bar',
        'flat': False,
        'fail_on_missing': True,
        'validate_checksum': True
    }

    # Successfully fetched
    fetch_result = {'dest': 'bar', 'md5sum': 'a'}
    shd = mock.MagicMock()
    shd.join_path.return_value = 'foo_concat_path'
    shd.path_ex

# Generated at 2022-06-11 11:48:44.248760
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.plugins.action.fetch import ActionModule
    from ansible.utils.path import makedirs_safe
    import os
    import tempfile
    import shutil

    # create objects for test
    _module = None
    _connection = None
    _play_context = None
    _loader = None
    _tempcwd = tempfile.mkdtemp()
    _temp_path = os.path.join(_tempcwd, 'testfile')
    makedirs_safe(os.path.dirname(_temp_path))
    _loader = None


# Generated at 2022-06-11 11:48:44.920519
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass