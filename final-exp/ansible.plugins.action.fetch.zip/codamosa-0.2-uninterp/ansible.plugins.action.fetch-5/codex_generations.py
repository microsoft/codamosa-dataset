

# Generated at 2022-06-17 08:59:38.149844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import tempfile
    import shutil
    import unittest
    import mock
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.utils.display import Display
    from ansible.utils.hashing import checksum, checksum_s, md5, secure_hash
    from ansible.utils.path import makedirs_safe, is_subpath
    from ansible.errors import AnsibleError, AnsibleActionFail, AnsibleActionSkip
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import StringIO

# Generated at 2022-06-17 08:59:39.702447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 08:59:50.777335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import shutil
    import tempfile
    import unittest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.plugins.action import ActionModule
    from ansible.utils.display import Display
    from ansible.utils.hashing import checksum, checksum_s, md5, secure_hash

    display = Display()


# Generated at 2022-06-17 08:59:51.322155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 08:59:58.297946
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid action
    action = ActionModule(None, dict(action='fetch'))
    assert action is not None

    # Test with an invalid action
    try:
        action = ActionModule(None, dict(action='invalid'))
        assert False
    except AnsibleError:
        assert True

# Generated at 2022-06-17 09:00:00.290260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 09:00:01.609151
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:00:10.354502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_

# Generated at 2022-06-17 09:00:11.157179
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:00:24.961731
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:00:46.594031
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:00:48.795017
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:00:58.458768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    import shutil
    import sys
    import json
    import textwrap
    import unittest
    import ansible.plugins.action.fetch as fetch
    import ansible.plugins.action.copy as copy
    import ansible.plugins.action.slurp as slurp
    import ansible.plugins.action.stat as stat
    import ansible.plugins.loader as loader
    import ansible.plugins.connection.local as local
    import ansible.plugins.connection.ssh as ssh
    import ansible.plugins.connection.paramiko_ssh as paramiko_ssh
    import ansible.plugins.connection.winrm as winrm
    import ansible.plugins.connection.docker as docker
    import ansible.plugins.connection.docker_unix as docker_unix

# Generated at 2022-06-17 09:01:03.793642
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock connection
    connection = MockConnection()

    # Create a mock task
    task = MockTask()

    # Create a mock play
    play = MockPlay()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock variable manager
    variable_manager = MockVariableManager()

    # Create a mock display
    display = MockDisplay()

    # Create a mock options
    options = MockOptions()

    # Create a mock inventory
    inventory = MockInventory()

    # Create a mock context
    context = MockContext()

    # Create a mock shell
    shell = MockShell()

    # Create a mock action module
    action_module = ActionModule(connection, task, play, loader, variable_manager, display, options, inventory, context, shell)

    # Create a mock remote_stat
    remote_stat = Mock

# Generated at 2022-06-17 09:01:14.988595
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = dict(
        action=dict(
            module='fetch',
            args=dict(
                src='/tmp/test.txt',
                dest='/tmp/test.txt'
            )
        )
    )

    # Create a mock connection
    connection = dict(
        _shell=dict(
            tmpdir='/tmp/test.txt',
            join_path=lambda a, b: '/tmp/test.txt'
        ),
        become=False,
        become_user=None,
        become_method=None,
        remote_addr='127.0.0.1'
    )

    # Create a mock play context
    play_context = dict(
        check_mode=False,
        remote_addr='127.0.0.1'
    )

    # Create

# Generated at 2022-06-17 09:01:17.954588
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid parameters
    action_module = ActionModule(None, None, None)
    assert action_module is not None
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-17 09:01:32.278720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with a valid source and destination
    action_module = ActionModule(task=dict(action=dict(module_name='fetch', args=dict(src='/tmp/test_file', dest='/tmp/test_file_dest'))))
    action_module._connection = MockConnection()
    action_module._connection._shell = MockShell()
    action_module._connection._shell.join_path = lambda x, y: x + y
    action_module._connection._shell.tmpdir = '/tmp/test_file_dest'
    action_module._connection._shell._unquote = lambda x: x
    action_module._loader = MockLoader()
    action_module._loader.path_dwim = lambda x: x
    action_module._task_vars = dict()

# Generated at 2022-06-17 09:01:43.021738
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:01:52.951250
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        action=dict(
            module_name='fetch',
            module_args=dict(
                src='/etc/passwd',
                dest='/tmp/passwd',
                flat=True,
                validate_checksum=False,
                fail_on_missing=False
            )
        )
    )

    # Create a mock connection
    class MockConnection(object):
        def __init__(self):
            self.become = False
            self.become_user = None
            self.become_method = None
            self.become_pass = None
            self.no_log = False
            self.remote_addr = '127.0.0.1'
            self.transport = 'local'
            self.host = 'localhost'

# Generated at 2022-06-17 09:02:00.019464
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:02:44.994931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with a valid source and destination
    action_module = ActionModule()
    action_module._task = dict(args=dict(src='/tmp/source', dest='/tmp/destination'))
    action_module._connection = dict()
    action_module._connection._shell = dict()
    action_module._connection._shell.join_path = lambda x, y: x + y
    action_module._connection._shell._unquote = lambda x: x
    action_module._connection._shell.tmpdir = '/tmp'
    action_module._connection.become = False
    action_module._connection.fetch_file = lambda x, y: None
    action_module._connection.execute_module = lambda x, y, z: dict(failed=False, changed=False)
    action_module._loader = dict()
    action_

# Generated at 2022-06-17 09:02:56.900774
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        action=dict(
            module_name='fetch',
            module_args=dict(
                src='/tmp/test_file',
                dest='/tmp/test_file_dest',
                flat=False,
                validate_checksum=False
            )
        )
    )
    # Create a mock play context
    play_context = dict(
        remote_addr='127.0.0.1',
        check_mode=False
    )
    # Create a mock connection

# Generated at 2022-06-17 09:02:58.750528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:02:59.708791
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    pass

# Generated at 2022-06-17 09:03:00.641063
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:03:01.565171
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:03:07.026935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid parameters
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

    # Test with invalid parameters
    try:
        action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None)
        assert action_module is not None
    except TypeError:
        pass

# Generated at 2022-06-17 09:03:18.436582
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no src or dest
    task_args = dict()
    task_vars = dict()
    tmp = None
    play_context = dict()
    connection = dict()
    loader = dict()
    templar = dict()
    shared_loader_obj = dict()
    action_module = ActionModule(task=task_args,
                                 connection=connection,
                                 play_context=play_context,
                                 loader=loader,
                                 templar=templar,
                                 shared_loader_obj=shared_loader_obj)
    result = action_module.run(tmp, task_vars)
    assert result['failed'] == True
    assert result['msg'] == 'src and dest are required'

    # Test with no dest
    task_args = dict(src='/tmp/test_file')

# Generated at 2022-06-17 09:03:23.915672
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    am = ActionModule(None, None)
    assert am is not None

    # Test with parameters
    am = ActionModule(None, None, task_vars=dict())
    assert am is not None

# Generated at 2022-06-17 09:03:34.224283
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock connection
    connection = MockConnection()

    # Create a mock task
    task = MockTask()

    # Create a mock play
    play = MockPlay()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock variable manager
    variable_manager = MockVariableManager()

    # Create a mock display
    display = MockDisplay()

    # Create a mock options
    options = MockOptions()

    # Create a mock inventory
    inventory = MockInventory()

    # Create a mock context
    context = MockContext()

    # Create a mock ansible module
    ansible_module = MockAnsibleModule()

    # Create a mock ansible module
    ansible_module = MockAnsibleModule()

    # Create a mock ansible module
    ansible_module = MockAnsibleModule()

    #

# Generated at 2022-06-17 09:05:00.532260
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:05:08.567800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra

# Generated at 2022-06-17 09:05:09.281543
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None)

# Generated at 2022-06-17 09:05:10.835561
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:05:11.689018
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    assert False

# Generated at 2022-06-17 09:05:17.756399
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:05:18.742231
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:05:32.006822
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.action.copy import ActionModule as copy_action
    from ansible.plugins.action.slurp import ActionModule as slurp_action
    from ansible.plugins.connection.local import Connection as LocalConnection
    from ansible.plugins.connection.ssh import Connection as SSHConnection
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor

# Generated at 2022-06-17 09:05:42.642526
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.action.fetch import ActionModule

# Generated at 2022-06-17 09:05:48.083479
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid values
    action = ActionModule(
        task=dict(action=dict(module_name='fetch', module_args=dict(src='/tmp/test', dest='/tmp/test'))),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action is not None

    # Test with invalid values