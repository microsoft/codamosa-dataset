

# Generated at 2022-06-17 08:59:29.076215
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 08:59:41.461111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.plugins.action.fetch import ActionModule as fetch
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six import StringIO

# Generated at 2022-06-17 08:59:51.947336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.connection.local import Connection
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 08:59:54.848283
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:00:05.139578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.action.fetch import ActionBase
    from ansible.plugins.action.fetch import display
    from ansible.plugins.action.fetch import checksum
    from ansible.plugins.action.fetch import checksum_s
    from ansible.plugins.action.fetch import md5
    from ansible.plugins.action.fetch import secure_hash
    from ansible.plugins.action.fetch import os
    from ansible.plugins.action.fetch import string_types
    from ansible.plugins.action.fetch import makedirs_safe
    from ansible.plugins.action.fetch import is_subpath
    from ansible.plugins.action.fetch import to_bytes

# Generated at 2022-06-17 09:00:06.431685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:00:13.490647
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        action=dict(
            module_name='fetch',
            module_args=dict(
                src='/tmp/foo',
                dest='/tmp/bar',
                flat=True,
                validate_checksum=True,
                fail_on_missing=True
            )
        )
    )

    # Create a mock connection
    connection = dict(
        _shell=dict(
            tmpdir='/tmp/ansible-tmp-12345',
            join_path=lambda *args: '/'.join(args),
            _unquote=lambda x: x
        ),
        become=False,
        fetch_file=lambda src, dest: None
    )

    # Create a mock loader

# Generated at 2022-06-17 09:00:15.604640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:00:16.656297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:00:17.578461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:00:37.165876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:00:38.707022
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    a = ActionModule(None, None, None, None, None)
    assert a is not None

# Generated at 2022-06-17 09:00:40.251380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:00:50.908082
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:01:02.203044
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor of class ActionModule
    # Create a mock task
    mock_task = dict(action=dict(module_name='fetch', module_args=dict(src='/path/to/src', dest='/path/to/dest')))
    # Create a mock play_context
    mock_play_context = dict(remote_addr='127.0.0.1', connection='local', port=22, remote_user='user', become=False, become_method='sudo', become_user='root', check_mode=False, diff=False)
    # Create a mock loader
    mock_loader = dict(path_dwim=lambda x: x)
    # Create a mock templar
    mock_templar = dict()
    # Create a mock shared_loader_obj
    mock_shared_loader_obj = dict()


# Generated at 2022-06-17 09:01:05.373155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:01:07.255765
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-17 09:01:18.718180
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.fetch import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 09:01:20.427613
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:01:33.097830
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:02:07.424542
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:02:09.200304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:02:19.683336
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:02:24.306290
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:02:36.559791
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.fetch import ActionModule
    from ansible.plugins.action.fetch import md5
    from ansible.plugins.action.fetch import checksum
    from ansible.plugins.action.fetch import checksum_s
    from ansible.plugins.action.fetch import secure_hash
    from ansible.plugins.action.fetch import makedirs_safe
    from ansible.plugins.action.fetch import is_subpath
    from ansible.plugins.action.fetch import to_bytes
    from ansible.plugins.action.fetch import to_text
    from ansible.plugins.action.fetch import base64
    from ansible.plugins.action.fetch import os
    from ansible.plugins.action.fetch import string_types

# Generated at 2022-06-17 09:02:37.661001
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement this test
    pass

# Generated at 2022-06-17 09:02:39.506664
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:02:50.514585
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:02:53.861720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:02:54.843926
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:04:32.129804
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:04:32.682512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    return

# Generated at 2022-06-17 09:04:33.287192
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:04:37.826910
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:04:45.057226
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra

# Generated at 2022-06-17 09:04:47.784318
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert action is not None

# Generated at 2022-06-17 09:04:54.566581
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='fetch', module_args=dict(src='/tmp/test.txt', dest='/tmp/test.txt'))),
        connection=dict(host='localhost', port=22, user='root', password='password'),
        play_context=dict(remote_addr='localhost', port=22, remote_user='root', password='password', become=False, become_method='sudo', become_user='root', check_mode=False, diff=False),
        loader=None,
        templar=None,
        shared_loader_obj=None)

    assert action_module._task.action.module_name == 'fetch'
    assert action_module._task.action.module_args.get('src') == '/tmp/test.txt'
   

# Generated at 2022-06-17 09:04:55.172670
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:04:59.699998
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am is not None


# Generated at 2022-06-17 09:05:01.903822
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:08:02.869922
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:08:13.914120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock connection
    connection = MockConnection()

    # Create a mock module
    module = MockModule()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock task
    task = MockTask()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action module
    action_module = ActionModule(connection, loader, play_context, task, task_vars, display)

    # Create a mock tmp
    tmp = MockTmp()

    # Test the run method
    action_module.run(tmp, task_vars)

    # Test the run method with a failed task

# Generated at 2022-06-17 09:08:23.889614
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.connection.local import Connection
    from ansible.plugins.loader import action_loader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

# Generated at 2022-06-17 09:08:26.326259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:08:28.577912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Add unit tests for ActionModule.run()
    pass

# Generated at 2022-06-17 09:08:35.668190
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:08:47.781790
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task and connection
    task = dict(action=dict(module_name='fetch', module_args=dict(src='/path/to/file', dest='/path/to/dest')))
    connection = dict(host='localhost', port=22, user='test', password='test')

    # Create a mock AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

    # Create a mock PlayContext
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()

    # Create a mock loader
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    # Create a mock variable manager
    from ansible.vars.manager import VariableManager
    variable_manager

# Generated at 2022-06-17 09:08:51.080472
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:08:52.672354
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:09:03.080002
# Unit test for constructor of class ActionModule