

# Generated at 2022-06-11 10:08:10.246732
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True

# Generated at 2022-06-11 10:08:22.960479
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.base import Base
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 5

    inventory = InventoryManager(loader='/etc/ansible/hosts')
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # Create Play and PlayContext

# Generated at 2022-06-11 10:08:34.719247
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.constants import DEFAULT_MODULE_NAME, DEFAULT_MODULE_ARGS, DEFAULT_MODULE_KWARGS

# Generated at 2022-06-11 10:08:36.268376
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # test with list of the objects
    # test with dictionary of the objects

    pass

# Generated at 2022-06-11 10:08:43.321895
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    #we import here to prevent a circular dependency with imports
    import ansible.playbook.play
    import ansible.playbook.role

    pb =  ansible.playbook.play.Play()
    r = ansible.playbook.role.Role()
    ds = [dict(action = 'test_action')]

    #test that task was loaded
    task_list = load_list_of_tasks(ds, pb)
    assert task_list
    assert task_list[0]
    assert task_list[0].action == 'test_action'

    #test that role was loaded
    ds = [dict(action = 'include_role', name = 'test_role')]
    task_list = load_list_of_tasks(ds, pb, role = r)
    assert task_list


# Generated at 2022-06-11 10:08:55.037044
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

# Generated at 2022-06-11 10:09:06.388186
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible.errors
    import ansible.playbook.role_include
    import ansible.playbook.task
    import ansible.playbook.task_include
    from ansible.template import Templar
    from ansible.vars import VariableManager


# Generated at 2022-06-11 10:09:12.762837
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # import necessary modules
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import filter_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager

    # create host, group, inventory and variable manager objects
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)


# Generated at 2022-06-11 10:09:25.444678
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    localhost = inventory_hostname

    # Set some global ansible variables, so that we can run the playbook with
    # the same effects as when running it from the command line
    variable_manager = VariableManager()
    variable_manager.extra_vars = load_extra_vars(loader=DataLoader(), options=None)
    variable_manager.options_vars = load_options_vars(loader=DataLoader(), options=None)
    hosts = InventoryManager(loader=DataLoader(), sources='localhost,')

# Generated at 2022-06-11 10:09:31.746905
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import plugin_loader
    from ansible.executor.task_queue_manager import TaskQueueManager


    class MockOptions(object):
        def __init__(self, verbosity=None, extra_vars=None, inventory=None):
            self._verbosity = verbosity
            self._inventory = inventory
            self._extra_vars = extra_vars

        @property
        def verbosity(self):
            return self._verbosity

        @property
        def inventory(self):
            return self._inventory


# Generated at 2022-06-11 10:09:57.702623
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Test load_list_of_tasks function
    '''
    import ast
    import ansible.playbook.role_include
    import ansible.playbook.task_include
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.playbook.handler

    ds = ast.literal_eval("['A', 'B', {'block': ['C', {'block': 'D'}]}]")
    play = TaskListLoader()
    (block, block_vars) = play.load_list_of_tasks(ds)
    try:
        blocks = [b for b in block.block]
    except AttributeError:
        blocks = [b for b in block]

# Generated at 2022-06-11 10:10:09.627808
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    load_list_of_tasks function testing
    :return: no return
    '''
    test_block = [
        {
            "block": [
                {
                    "set_fact": {
                        "sample_variable": [
                            "some_value"
                        ]
                    },
                    "block": [
                        {
                            "when": "sample_variable == some_value"
                        }
                    ],
                    "task_include": "some_file.yml",
                    "rescue": [
                        {
                            "debug": {
                                "msg": "This is rescue block"
                            }
                        }
                    ]
                }
            ]
        }
    ]

# Generated at 2022-06-11 10:10:22.009004
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    with open(os.path.join(os.getcwd(), 'test_support/tasks.yml'), 'r') as task_file:
        tasks_data = task_file.read()
        tasks_data = yaml.safe_load(tasks_data)

    loader = DataLoader()
    variable_manager = VariableManager()
    my_play = Play()
    my_play.playbook = PlaybookFile()

    my_tasks = load_list_of_tasks(tasks_data, my_play, variable_manager=variable_manager)

    assert isinstance(my_tasks, list)
    assert len(my_tasks) == 6
    assert my_tasks[0].name == 'test_task1'
    assert my_tasks[0].action == 'test_test1'

# Generated at 2022-06-11 10:10:22.621692
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert False

# Generated at 2022-06-11 10:10:28.218575
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    load_list_of_blocks:
    '''

    # We need to mock the objects used by the function so we can test it,
    # but it's too painful to try to set these up for real, so we'll mock them.
    class MockPlay(object):
        pass

    mock_play = MockPlay()

    class MockParent(object):
        pass

    mock_parent = MockParent()

    class MockRole(object):
        pass

    mock_role = MockRole()

    class MockTask(object):
        def __init__(self, msg):
            self.args = dict()
            self.args['name'] = msg

    class MockBlock(object):
        def __init__(self, msg):
            self.tasks = [MockTask(str(msg))]
            self.parent_block

# Generated at 2022-06-11 10:10:41.346590
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    from vvv import Display

    from collections import namedtuple


# Generated at 2022-06-11 10:10:47.363230
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        ds = [
            {'meta': 'test'},
            {'name': 'test'},
        ]
        result = load_list_of_tasks(ds, None)
        assert result != None
    except Exception as e:
        assert False, "Fail with exception: {}".format(e)
    return "Success"


# Generated at 2022-06-11 10:10:56.704464
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude


# Generated at 2022-06-11 10:11:08.989732
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = DataLoader()
    results_callback = TaskQueueManager._unused_task_fields_callback
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

# Generated at 2022-06-11 10:11:09.995283
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    #We need to mock
    pass

# Generated at 2022-06-11 10:11:52.182658
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader

    t = Task()
    t.vars = {}
    t.register = {}
    t.action = "setup"
    context = PlayContext()
    context.play = None
    context.variable_manager = None
    context.loader = DataLoader()
    t.set_loader(context.loader)
    t.load(load_list_of_blocks([{'action': {'setup': 'get remote IP'}}, {'action': {'debug': 'wtf'}}, {'action': {'debug': 'ummm'}}], context, variable_manager=None, loader=context.loader))
    assert t.name == 'setup'



# Generated at 2022-06-11 10:12:03.543578
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.plugins.loader import action_loader
    action_loader.add_directory(os.path.join(C.DEFAULT_MODULE_PATH, 'core'))
    action_loader.add_directory(os.path.join(C.DEFAULT_MODULE_PATH, 'cloud'))
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-11 10:12:12.750271
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import unittest

    class TestModuleArgsParser(unittest.TestCase):
        ds = [{'include': 'defaults/main', 'name': 'setup_config_dir'}, {'include': 'defaults/main.yml'},
              {'block': [{'include': 'vars/main.yml'}]}, {'block': [{'include': 'vars/main.yml'}]}]

        def test_type(self):
            from ansible.playbook.playbook import Playbook
            from ansible.inventory.manager import InventoryManager
            from ansible.vars.manager import VariableManager
            from ansible.parsing.dataloader import DataLoader

            # mock objects
            display = Display()
            loader = DataLoader()
            variable_manager = VariableManager()
           

# Generated at 2022-06-11 10:12:13.382684
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True

# Generated at 2022-06-11 10:12:25.923704
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # (1) Test load_list_of_roles when using lookup
    test_role_1 = {
        'name': 'testing_role',
        'hosts': 'localhost',
        'roles': [
            {'lookup': 'lookup_name'},
            'testing_role_1'
        ]
    }
    test_play = dict2obj({'vars': dict(), 'roles': test_role_1})
    test_role_defs = test_play.roles.load_list_of_roles(test_play.roles, test_play)
    assert(isinstance(test_role_defs[0], RoleInclude))
    assert(test_role_defs[0]._role_name == 'lookup_name')

# Generated at 2022-06-11 10:12:36.307455
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:12:37.188551
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks

# Generated at 2022-06-11 10:12:47.819353
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test 2 tasks, make sure they are loaded into a list
    ds = [
        {'action': 'setup'},
        {'action': 'command', 'args': {'_raw_params': 'whoami', 'chdir': '/tmp'}}
    ]
    task_list = load_list_of_tasks(ds,play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert(isinstance(task_list, list))
    assert(len(task_list) == 2)
    assert(task_list[0].action == 'setup')
    assert(task_list[1].args['_raw_params'] == 'whoami')
    assert(task_list[1].args['chdir'] == '/tmp')



# Generated at 2022-06-11 10:12:48.535923
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:12:49.260777
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:13:13.709173
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inventory = InventoryManager(loader=loader,sources=['localhost,127.0.0.1,foo'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    #playbook = Playbook()

# Generated at 2022-06-11 10:13:22.825069
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Unit on test for load_list_of_roles
    """
    from ansible.playbook import Play
    from ansible.playbook.role.include import RoleInclude
    play = Play()
    role_def = [{"role": "apache"}, {"role": "tomcat"}]
    result = load_list_of_roles(role_def, play)
    assert isinstance(result, list)
    assert isinstance(result[0], RoleInclude)
    assert isinstance(result[1], RoleInclude)
    assert result[0].role_name == "apache"
    assert result[1].role_name == "tomcat"



# Generated at 2022-06-11 10:13:34.949321
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # When:
    ds = []
    # Then:
    assert load_list_of_tasks(ds, None, None, None, None, False, None, None) == []
    # When:
    ds = None
    # Then:
    assert load_list_of_tasks(ds, None, None, None, None, False, None, None) == []
    # When:
    ds = 'not-a-list'.split()
    # Then:
    with pytest.raises(AnsibleAssertionError) as e:
        load_list_of_tasks(ds, None, None, None, None, False, None, None)
    assert 'should be a list but was a' in e.value.message
    assert 'not-a-list' in e.value.message
    #

# Generated at 2022-06-11 10:13:36.664786
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO: Create a unit test
    pass

# Generated at 2022-06-11 10:13:40.758443
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-11 10:13:48.155724
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.vault import VaultSecret
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext

    # This method tests the functions: load_list_of_tasks
    # Ensure the proper exception is raised when a role is imported, but the role is not installed
    # Ensure the proper exception is raised when a role is imported, but the path is not found
    inventory = InventoryManager(loader=DictDataLoader({'group': {'hosts': ['127.0.0.1']}}), sources=['localhost'])

    # Create a valid Play to

# Generated at 2022-06-11 10:13:57.197673
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
     from ansible.playbook.task import Task
     from ansible.playbook.task_include import TaskInclude
     from ansible.playbook.role_include import IncludeRole
     ds = [{'include_role': {'name': 'role2'}}]
     loader = None
     play = None
     block = None
     role = None
     task_include = None
     use_handlers = None
     variable_manager = None
     task_list = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
     assert isinstance(task_list[0], IncludeRole)

# Generated at 2022-06-11 10:14:06.261880
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_list = []
    task_ds = dict()
    play = dict()
    block = dict()
    role = dict()
    task_include = dict()
    use_handlers = False
    variable_manager = dict()
    loader = dict()
    load_list_of_tasks(task_list, play, block, role, task_include, use_handlers, variable_manager, loader)


# Borrowed from ansible/playbook/role/meta/main.yml

# Generated at 2022-06-11 10:14:14.945428
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Unit test function: ansible.playbook.helpers.load_list_of_tasks
    '''

    def _get_task(ds):
        return load_list_of_tasks(ds, None, None, None, None, None, None)[0]

    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    data = [{'block': []},
            {'task-a': '1'},
            {'task-b': '2'},
            ]
    tasks = load_list_of_tasks(data, None, None, None, None, False, None)
    assert len(tasks) == 4
    assert isinstance(tasks[0], Block)
    assert isinstance(tasks[1], Task)

# Generated at 2022-06-11 10:14:22.599039
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # Test empty ds
    result = load_list_of_blocks(ds=[], play=None, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert result is not None

    # Test invalid ds
    with open(os.path.join(C.DEFAULT_LOCAL_TMP, 'test_load_list_of_blocks.yml'), 'w') as fd:
        ds = """
        - tasks:
            - name: foo
            - block:
                - name: foo
        - tasks:
            - block:
                - name: foo
        """
        fd.write(ds)

# Generated at 2022-06-11 10:14:52.225829
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    task_list = load_list_of_tasks(ds, play, parent_block=None, role=None, task_include=None, variable_manager=None, loader=None)
    assert isinstance(task_list, list) and len(task_list) == 1
    assert all(isinstance(task, Task) for task in task_list)
    assert next(iter(task_list))._parent is None
    assert all(task.playbook is None for task in task_list)

    task_list = load_list_of_tasks(ds, play, parent_block=block_implicit, role=role, task_include=task_include, variable_manager=None, loader=None)

# Generated at 2022-06-11 10:15:03.370352
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    task_ds = [{'name': 'task1', 'action': 'action1'},
               {'name': 'task2', 'action': 'action2'},
               {'name': 'task3', 'action': 'action3'},
               {'name': 'task5', 'action': 'action5', 'block': [
                   {'name': 'task5.1', 'action': 'action5.1'},
                   {'name': 'task5.2', 'action': 'action5.2'},
                   {'name': 'task5.3', 'action': 'action5.3'}
               ]},
               {'name': 'task4', 'action': 'action4'}]
    block = []
   

# Generated at 2022-06-11 10:15:13.239969
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    pb = Play().load({}, loader=DataLoader())
    vm = VariableManager()
    tasks = load_list_of_tasks(ds=["task: 1"], play=pb, block=None, role=None, task_include=None, use_handlers=False, variable_manager=vm, loader=DataLoader())
    assert tasks == []


# Generated at 2022-06-11 10:15:24.119046
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.parsing.mod_args import ModuleArgsParser

    display = Display()
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    play = Play()

    # test a simple list with just one task
    ds = [{"hosts": "127.0.0.1", "tasks": {"shell": "ls"}}]
    block_list = load_list_of_blocks(ds, play=play, variable_manager=variable_manager, loader=loader)

    assert len(block_list) == 1
    assert isinstance(block_list[0], Block)
    assert block_list[0].has_tasks()

# Generated at 2022-06-11 10:15:38.483291
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.helpers import load_list_of_tasks
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Load the yaml file containing a list of tasks
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-11 10:15:49.955912
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    playbook_name = 'load_list_of_tasks_test'

# Generated at 2022-06-11 10:15:59.441481
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
        {
            'action': 'shell',
            'args': {
                'chdir': '/tmp',
                'executable': '/bin/sh',
                '_raw_params': 'ls -al',
            },
        },
        {
            'action': 'shell',
            'args': {
                'chdir': '/tmp',
                'executable': '/bin/sh',
                '_raw_params': 'ls -al',
            },
        },
    ]

    task_list = load_list_of_tasks(ds=ds)

    assert task_list[0].action == 'shell'
    assert task_list[1].action == 'shell'

# Generated at 2022-06-11 10:16:10.909773
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    duan zhengchun <zhengchun.duan@gmail.com>
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.base import load_list_of_roles
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.errors import AnsibleError
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    import os

# Generated at 2022-06-11 10:16:21.291730
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:16:27.932784
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.loader import get_all_plugin_loaders

    # find the include role plugin
    p = get_all_plugin_loaders()['connection']()['include_role']
    orig_getattr = p.getattr

    class MockedGetAttr:
        def getattr(self, result, attrname, *args, **kwargs):
            if attrname == '_load_role':
                return mocked_load_role
            else:
                return orig_getattr(result, attrname)

    p.getattr

# Generated at 2022-06-11 10:17:11.772598
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.executor.task_queue_manager import TaskQueueManager
    #from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.plugins import callback_loader

    fake_ds = [
        {'name': 'first block'},
        {'name': 'second block'}
    ]

    fake_play = Play().load({
        'name': 'fake play',
        'hosts': 'hosts'
    }, variable_manager=VariableManager(), loader=None)


# Generated at 2022-06-11 10:17:20.021458
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Basic test of loading a single task
    ds = [{
        'include_tasks': 'test_static_include.yml',
    }]
    task_list = load_list_of_tasks(ds, None, None, None, True)
    assert len(task_list) == 1

    # Basic test of loading a single handler
    ds = [{
        'include_tasks': 'test_static_include.yml',
    }]
    task_list = load_list_of_tasks(ds, None, None, None, False)
    assert len(task_list) == 1

    # Basic test of loading multiple tasks as a list

# Generated at 2022-06-11 10:17:31.078753
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Base object to test load_list_of_tasks function
    ds = [{'name': 'copy-file'}, {'name': 'copy-file'}, {'name': 'copy-file'}]
    play = Play.load('/tmp/test.yml', 'Test')
    inventory = InventoryManager(loader=None, sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    play_context = PlayContext()
    block = None
    role = None
    task_include = None
    use_handlers = False
    loader

# Generated at 2022-06-11 10:17:36.874402
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    list_of_tasks = [
        {'hosts': 'localhost', 'name': 'test1'},
        {'hosts': 'localhost', 'name': 'test2'}
    ]
    task_list = load_list_of_tasks(list_of_tasks, None, None, None, None, False, {})
    assert len(task_list) == 2
