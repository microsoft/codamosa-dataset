

# Generated at 2022-06-11 10:08:04.933302
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test loading a list of tasks
    task1 = dict(
        action=dict(
            module='command',
            args=dict(
                command='true',
                foo='2'
            )
        )
    )
    task2 = dict(
        action=dict(
            module='command',
            args=dict(
                command='true',
                foo='2'
            )
        )
    )


    ds = [task1, task2]
    from ansible.playbook.play import Play
    play = Play()
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager

    task1 = Task()

# Generated at 2022-06-11 10:08:10.357258
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    assert isinstance(load_list_of_blocks([{'block':['tasks', ['debug']]}], play=Play()), list)


# Generated at 2022-06-11 10:08:23.116616
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    This function is used to test load_list_of_tasks function
    :return: unittest.TestSuite()
    '''
    from ansible.playbook.block import Task
    import ansible.playbook.block as task
    import ansible.playbook.play as play
    import ansible.playbook.task_include as task_include

    class Test_task(Task):
        pass

    class Test_task_include(task_include.TaskInclude):
        pass

    class Test_Play(play.Play):
        pass


# Generated at 2022-06-11 10:08:24.246451
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert __load_list_of_tasks__ is True

# Generated at 2022-06-11 10:08:35.984171
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play

    p = Play()
    task_ds = [
        {'action': {'module': 'setup'}},
        {'action': {'module': 'shell', 'args': 'cat /etc/passwd'}}
    ]
    task_list = load_list_of_tasks(task_ds, p)
    assert len(task_list) == 2
    assert isinstance(task_list[0], Task)
    assert isinstance(task_list[1], Task)
    assert task_list[0].action['module_name'] == 'setup'
    assert task_list[1].action['module_name'] == 'shell'
    assert task_list[1].args == 'cat /etc/passwd'


# Generated at 2022-06-11 10:08:36.390080
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass


# Generated at 2022-06-11 10:08:47.111962
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    play = Play().load({
        'name': 'Ansible Play 1',
        'hosts': 'localhost',
        'tasks': [
            {'shell': 'ls /tmp'},
            {'name': 'Shell test 2', 'shell': 'ls'},
            {'debug': 'msg="{{ inventory_hostname }}"'},
        ]
    }, variable_manager=dict())
    loader, inventory, variable_manager = C.get_dependencies('/etc/ansible/hosts')
    tasks = load_list_of_tasks(play.tasks, play, variable_manager=variable_manager, loader=loader)
    assert len(tasks) == 3


# Generated at 2022-06-11 10:08:50.041719
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:09:01.602263
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    play_context = PlayContext()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # If this test worked, it is OK

# Generated at 2022-06-11 10:09:09.953660
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    task_data = [
        {'debug': {'msg': 'do things'}}, # Task object
        {'block': [{'debug': {'msg': 'do things'}}]} # Block object
    ]
    # Validation of the Task object
    for t in load_list_of_tasks(task_data, None):
        assert isinstance(t, (Task, Block))
    # Validation of the Block object
    assert isinstance(load_list_of_tasks(task_data, None)[1], Block)

# Generated at 2022-06-11 10:09:32.950977
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        from types import SimpleNamespace as Namespace
        from unittest.mock import Mock
        from ansible.plugins.loader import action_loader
    except ImportError:
        from ansible.utils.tests import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, mock
        from ansible.module_utils import basic

        from ansible.module_utils import basic
        from ansible.plugins.loader import action_loader

    from ansible.module_utils.six import string_types


# Generated at 2022-06-11 10:09:33.626696
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert 0 == 1

# Generated at 2022-06-11 10:09:35.087637
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert callable(load_list_of_tasks)



# Generated at 2022-06-11 10:09:46.061321
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.playbook.play
    import ansible.playbook.task
    play = ansible.playbook.play.Play()
    ds = [
        {
            'name': "Example Play",
            'hosts': 'localhosts',
            'gather_facts': 'no',
            'tasks': [
                {
                    'action': {
                        'module': 'example',
                        'args': '',
                    },
                    'name': "Example Task",
                },
                {
                    'block': [
                        {
                            'action': {
                                'module': 'example',
                                'args': '',
                                },
                            'name': "Example Task2",
                            },
                        ],
                    'name': "Example Block",
                    },
                ],
            },
        ]
   

# Generated at 2022-06-11 10:09:55.822496
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert 1==1
test_load_list_of_tasks()

# import module snippets
from ansible.module_utils.basic import *

# start of module code

#
# @copyright: 2020 Red Hat Inc.
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
#

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'network'}


# Generated at 2022-06-11 10:10:06.404956
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible.playbook.play


# Generated at 2022-06-11 10:10:20.242224
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.role_include import IncludeRole
    import ansible.playbook.task_include as task_include
    ################################################################################
    #
    # test_load_list_of_tasks_with_empty_list_as_input
    #
    ################################################################################
    ds = []
    play = "the play"
    role = None
    task_include_ = None
    use_handlers = False

    task_list = load_list_of_tasks(ds, play, None, role, task_include_, use_handlers)

    # FIXME: make task_list an iterable
    assert (len(task_list) == 0)
    ################################################################################
    #
    # test_load

# Generated at 2022-06-11 10:10:27.568631
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
  from ansible.parsing.yaml.objects import AnsibleUnicode
  from ansible.errors import AnsibleParserError
  from ansible.parsing.dataloader import DataLoader
  from ansible.vars import VariableManager
  import tempfile

  temp_dir = tempfile.mkdtemp(prefix='ansible_test_load_list_of_tasks')
  fd, dummy_playbook = tempfile.mkstemp(dir=temp_dir)
  fd2, dummy_playbook2 = tempfile.mkstemp(dir=temp_dir)

# Generated at 2022-06-11 10:10:40.908167
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # We create some data for use in testing the function
    # with the following assumed structure:
    # {
    #     'tasks': [
    #         {'task_name': 'TaskA'},
    #         {'block': {'block_name': 'BlockName'}},
    #         {'task_name': 'task_B'}
    #     ]
    # }
    data_structure = [
        {'task_name': 'TaskA'},
        {'block': {'block_name': 'BlockName'}},
        {'task_name': 'TaskB'}
    ]
    # We create a fake loader to pass to the function
    loader = FakeLoader()
    # We create a fake block to pass to the function
    block = FakeBlock()
    # We create a fake role to pass

# Generated at 2022-06-11 10:10:51.667460
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible.playbook
    ds = [{
        'name': 'task1',
        'action': 'shell',
        'args': 'echo task1'
    }, {
        'block': [{
            'name': 'subblock1',
            'task': [{
                'name': 'subtask1',
                'action': 'command',
                'args': 'echo subtask1'
            }],
        }]
    }, {
        'name': 'task2',
        'action': 'ping',
        'loop': [{
            'host': 'localhost',
            'port': 22
        }]
    }]
    task_list = load_list_of_tasks(ds, ansible.playbook.PlayBook(), None, None, False)

# Generated at 2022-06-11 10:11:37.561438
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.play import Play

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar

    # We do not have all the logic in this unit test yet, it is a work in progress.

    # Setup play
    play_ds = [{'name': 'cowsay'}]
    play_count = iter(range(len(play_ds)))

# Generated at 2022-06-11 10:11:39.317218
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # TODO: create test for load_list_of_roles function
    pass


# Generated at 2022-06-11 10:11:45.970031
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.add_vars(loader=loader, host_list='pluto', group_vars=dict(), add_host_vars=False)

    fake_inventory = InventoryManager(loader=loader, sources=[])
    assert len(load_list_of_tasks(None,
                                  FakePlaybook(
                                      variable_manager=variable_manager,
                                      loader=loader,
                                      inventory=fake_inventory
                                  ),
                                  variable_manager=variable_manager,
                                  loader=loader
                                  )) == 0


# Generated at 2022-06-11 10:11:57.093728
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.module_utils.common._collections_compat import OrderedDict
    play = OrderedDict()
    play['hosts'] = 'localhost'
    play['name'] = 'Unit test'

    list_yaml = [
        {"block": [{"task_name":"task1", "test": "test1"}]},
        {"action": "test2"},
        {"action": "test3"},
        {"include": "include.yaml"},
        {"block": [{"include": "include.yaml"}, {"action": "test1"}, {"action": "test2"}]}
    ]
    #play = {'hosts': 'localhost', 'name': 'Unit test'}
    test = load_list_of_tasks(list_yaml, play)
    print(test[0])

# Generated at 2022-06-11 10:12:08.165896
# Unit test for function load_list_of_roles

# Generated at 2022-06-11 10:12:18.409531
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:12:31.380977
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # To test this function we are going to use the following playbook.yml
    # ---
    # - hosts: all
    #   tasks:
    #     - name: make a directory
    #       file:
    #         path: /some/path/here
    #         state: directory
    #       tags:
    #         - test

    # This playbook has a list of tasks, with only one task in it,
    # it is used to test the function load_list_of_tasks()

    # import nedded functions
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    # load the playbook
    loader = AnsibleLoader(None, False)

# Generated at 2022-06-11 10:12:38.939186
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    playbook_dir = os.path.dirname(os.path.realpath(__file__)) + "/../../../playbooks"
    playbook_dir = playbook_dir + "/" + "../playbooks"

    # test load_list_of_tasks

    input_list_of_tasks = [{'block': [{'include_role': {'name': 'test'}}],
                            'any_errors_fatal': True,
                            'always_run': ['test_playbook_task']}]
    # load_list_of_tasks(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None):

    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

# Generated at 2022-06-11 10:12:49.985562
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    block_ds = {
        'block': [
            {
                'include_role': {
                    'name': 'foo'
                }
            }
        ],
        'tasks': [
            {
                'name': 'foo'
            },
            {
                'name': 'bar'
            }
        ]
    }

    play = "include_role"
    parent_block = "tasks"
    role = "bar"
    task_include = "bar"
    use_handlers = False,
    variable_manager = VariableManager
    loader = "loader"


# Generated at 2022-06-11 10:13:01.314594
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Create a role and test the load_list_of_roles function
    """

    # Create a role
    role = Role()

    # Create a list of dictionaries of roles
    ds = [{'role': 'A'},
          {'role': 'B'},
          {'role': 'C'}]

    # Create a play to pass to role_include
    play = Play().load({'name': 'test_play'}, variable_manager=VariableManager(), loader=None)

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a loader
    loader = DataLoader()

    # Test the load_list_of_roles function

# Generated at 2022-06-11 10:13:55.096651
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook import Play
    from ansible.collection_loader import AnsibleCollectionLoader
    #from ansible.playbook.play_context import PlayContext

    collection_loader = AnsibleCollectionLoader


# Generated at 2022-06-11 10:14:05.016872
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # pylint: disable=protected-access
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    mock_loader = MagicMock()
    mock_loader.load_from_file = MagicMock()
    mock_loader.path_dwim = MagicMock()
    mock_loader.path_dwim_relative = MagicMock()
    mock_loader.get_basedir = MagicMock()

    mock_variable_manager = MagicMock()
    mock_variable_manager.get_vars = MagicMock()
    mock_variable_manager.get_vars.return_value = {}

    mock_block = MagicMock()
    mock_block.task_include = MagicMock()

    # The following are mocked classes

# Generated at 2022-06-11 10:14:13.849585
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import IncludeRole

    ds =[
        {"include": "test1.yaml"},
        { "test" : "test" }
    ]
    display = Display()
    task_list = load_list_of_tasks(ds, None, None, None, None, False, None, None)
    assert isinstance(task_list[0], TaskInclude)
    assert isinstance(task_list[1], Block)

    task_list = load_list_of_tasks

# Generated at 2022-06-11 10:14:20.877032
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """
    Returning a list of task include objects when a list of tasks are passed as the argument

    :return: list of tasks
    """
    C = AnsibleConfig()
    # Creating a dynamic task without a block
    task_ds = {'include_tasks': 'dynamic_task_include.yml'}
    # Creating a static task without a block
    task_ds1 = {'include_tasks': 'static_task_include.yml', 'static':'yes'}
    # Creating a static task with a blocks
    task_ds2 = {'block':{'include_tasks': 'static_task_include.yml', 'static':'yes', 'block':{'include_tasks': 'static_task_include.yml', 'static':'yes'}}}
    # Creating a dynamic task with a blocks
   

# Generated at 2022-06-11 10:14:26.446223
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Create a dict with list of tasks
    task_list = [
        {'debug': {
            'msg': 'Test task 1'}},
        {'debug': {
            'msg': 'Test task 2'}}]
    # Call function through try except clause
    try:
        load_list_of_tasks(task_list)
    except:
        assert False, 'Function load_list_of_tasks did not work'
    assert True



# Generated at 2022-06-11 10:14:28.792941
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    ds = [{'include': 'task.yaml'}]

    assert load_list_of_tasks(ds) == [{'include': 'task.yaml'}]

# Generated at 2022-06-11 10:14:39.861176
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:14:51.688983
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    b_def = dict(
        name='test',
        hosts=['test'],
        roles=['test_role'],
        pre_tasks=[
            dict(name='test1', debug=dict(msg='test1')),
            dict(name='test2', debug=dict(msg='test2')),
        ],
        tasks=[
            dict(name='test3', debug=dict(msg='test3')),
            dict(name='test4', debug=dict(msg='test4')),
        ]
    )
    b = Block.load(b_def, task_include=None, variable_manager=None, loader=None)
    assert len(b.block) == 4


# Generated at 2022-06-11 10:14:59.932148
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.role.include import RoleInclude

    # return an empty list for an empty input
    assert load_list_of_roles([], None) == []

    # return an empty list for a None input
    assert load_list_of_roles(None, None) == []

    # return an empty list for a single empty role definition
    assert load_list_of_roles([{}], None) == []

    # create a valid role definition
    ds = {}
    ds['name'] = 'test_role'

    # return a list with a RoleInclude object for a single valid role definition
    assert isinstance(load_list_of_roles([ds], None)[0], RoleInclude)

    # return a list with a RoleInclude object

# Generated at 2022-06-11 10:15:14.623335
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:16:00.660418
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO: How to test this?
    pass



# Generated at 2022-06-11 10:16:12.477665
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from copy import deepcopy

    # Create task_ds
    task_ds = {}
    task_ds['block'] = None
    task_ds['name'] = 'a_task'
    task_ds['action'] = {}
    task_ds['action']['module'] = 'a_module'
    task_ds['when'] = 'a_when'
    task_ds['async'] = 1
    task_ds['async_poll_interval'] = 1
    task_ds['any_errors_fatal'] = True
    task_ds['failed_when'] = 'a_failed_when'
    task_ds['always_run'] = True
    task_ds['register'] = 'a_register'
    task_ds['ignore_errors'] = True

# Generated at 2022-06-11 10:16:22.174027
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:16:32.235809
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Mock data
    import ansible.plugins.action
    mock_action = ansible.plugins.action.ActionModule(None)
    mock_action.GATHER_TIMEOUT = 10
    mock_action._config._ansible_verbosity = 3
    mock_action._config.bin_ansible_callbacks = False

    mock_display = Display()

    mock_loader = DataLoader()
    mock_inventory = InventoryManager(mock_loader)

    mock_variable_manager = VariableManager()

    mock_all_vars = mock_variable_manager.get_vars()

    mock_loader = DataLoader()
    mock_variable_manager = VariableManager()

    # Mock Playbook
    mock_playbook = Playbook.load('test.yml', variable_manager=mock_variable_manager, loader=mock_loader)

# Generated at 2022-06-11 10:16:42.384005
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
          {
            "name": "",
            "register": "",
            "gather_facts": "yes"
          },
          {
            "name": "",
            "action": {
              "module": "",
              "args": ""
            }
          },
          {
            "name": "",
            "action": {
              "module": "",
              "args": ""
            }
          }
        ]
    play = 'play'
    block = ''
    role = ''
    task_include = ''
    use_handlers = False 
    #variable_manager = ''
    loader = ''

# Generated at 2022-06-11 10:16:52.738582
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """
    load_list_of_tasks: Given a list of task datastructures (parsed from YAML),
    return a list of Task() or TaskInclude() objects.
    YAML:
    - name: foo
      debug: var=foo
    - name: bar
      debug: var=bar
    - block:
      - name: baz
        debug: var=baz
      - name: qux
        debug: var=qux
    """
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-11 10:17:04.444283
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.plugins import module_loader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    task_ds = [{"include": "foo"}]
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    assert load_list_of_tasks(task_ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=variable_manager, loader=loader)
   

# Generated at 2022-06-11 10:17:13.156999
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible.plugins.loader

    def test_load_list_of_tasks_with_role_include(task_ds, role_name, action, import_playbook):
        # Mock the TaskInclude class
        class MockTaskInclude():
            was_replicated = None
            replicated_task = None

            # Mock the TaskInclude.load method to return the object itself
            @staticmethod
            def load(self, block=None, role=None, task_include=None, variable_manager=None, loader=None):
                return self

            # Mock the TaskInclude.get_parent_attribute method to return the object itself
            def get_parent_attribute(self, attribute_name):
                return self

            # Mock the TaskInclude.copy method to return the object itself

# Generated at 2022-06-11 10:17:15.180603
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    roles = load_list_of_roles([
        {"name": "role1"},
        {"name": "role2"}
    ], None, None, None)
    assert(roles[0].role_name == "role1")
    assert(roles[1].role_name == "role2")



# Generated at 2022-06-11 10:17:16.065576
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert False, 'unimplemented'