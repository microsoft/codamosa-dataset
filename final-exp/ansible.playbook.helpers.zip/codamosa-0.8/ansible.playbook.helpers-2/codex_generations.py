

# Generated at 2022-06-11 10:08:03.831432
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
 
    class AnsiblePlaybook:
        def __init__(self, variable_manager):
            self.variable_manager = variable_manager


    variable_manager = VariableManager()
    variable_manager.extra_vars['test_var'] = 'test_value'

    mock_loader = MagicMock()
    mock_loader.path_dwim.return_value = '/mocked_path'
    mock_loader.get_basedir.return_value = '/mocked_basedir'
    mock_loader.get_real_file.return_value = '/mocked_basedir'

    ds = [{'include': 'test_var', 'static': 'yes'}]

# Generated at 2022-06-11 10:08:12.152256
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    class AnsiblePlaybookModule:
        def __init__(self, args):
            self.args = args

    class AnsiblePlaybookTask:
        def __init__(self, args):
            self.args = args

    class AnsiblePlaybookRole:
        def __init__(self, args):
            self.args = args

    class VariableManager:
        def __init__(self, all_vars):
            self.all_vars = all_vars

        def get_vars(self):
            return self.all_vars

    class AnsiblePlaybook:
        def __init__(self, args):
            self.args = args

    class AnsiblePlaybookBlock:
        def __init__(self, args, parent_block):
            self.args = args
            self.parent_block = parent_

# Generated at 2022-06-11 10:08:24.342028
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Simplest test
    test_data = [
        {
            'name': 'simple_task',
            'action': 'include_role',
            'static': True,
            'args': {
                'name': 'test_task'
            }
        }
    ]
    test_play = Play()
    test_task = load_list_of_tasks(
        test_data,
        test_play,
        block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=None,
        loader=None
    )[0]
    assert test_task.name == 'simple_task'
    assert isinstance(test_task, IncludeRole)
    assert test_task.statically_loaded == True


# Generated at 2022-06-11 10:08:27.988787
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ''' Test case for function load_list_of_tasks.
    '''
    for test in load_list_of_tasks_test_cases:
        yield _run_test_case, test


# Generated at 2022-06-11 10:08:38.757407
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    #from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.executor.playbook_executor import PlaybookExecutor
    print("Testing load_list_of_tasks()...")
    # Setup
    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-11 10:08:50.734864
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.task import Task
    import tempfile
    import os

    # create a test task file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yml') as temp_file:
        temp_file.write('- name: test')
        temp_file.flush()
        task_file = temp_file.name

    # create mock variables for role and loader
    role = 'test'
    absolute_task_path = os.path.abspath(task_file)
    loader = DictDataLoader({'templates':{}})

    # create mock variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {}

    # create mock play
    play = Play()

    # create test task

# Generated at 2022-06-11 10:08:52.734659
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    display.deprecated("2.9")
    assert False  # removed in 2.9


# Generated at 2022-06-11 10:09:04.713606
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DictDataLoader({})
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=['']))
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)
    variable_manager.extra_vars = {}


# Generated at 2022-06-11 10:09:08.588007
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks([{'block': [{'block': [{'include_role': {'name': 'a_role'}}]}]}]) == load_list_of_tasks(
        [
            {'block': [
                {'block': [
                    {'include_role': {'name': 'a_role'}}
                ]}
            ]}
        ]
    )



# Generated at 2022-06-11 10:09:21.485119
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    block = {
        'tasks': [
            {
                'name': 'My Task',
                'action': 'my_action'
            }, {
                'name': 'My Task2',
                'action': 'my_action2'
            }
        ]
    }
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play


# Generated at 2022-06-11 10:09:47.640279
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_block import RoleBlock
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.six import binary_type

# Generated at 2022-06-11 10:09:54.029205
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Test the load_list_of_tasks with a valid dictionary.
    '''
    ds = dict(action='shell', args='ifconfig eth0')
    assert isinstance(ds, dict)
    assert load_list_of_tasks(ds, 'play', 'block', 'role', 'task_include', False, 'variable_manager', 'loader') == [
        {
            'action': 'shell',
            'args': 'ifconfig eth0'
        }
    ]


# Generated at 2022-06-11 10:10:03.705985
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks(ds=None, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None) == None
    assert load_list_of_tasks(ds=5, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None) == None
    ds = [{'name': 'run_me_first'}, {'block': [{'name': 'and_me_too'}]}]
    # play = Play().load(ds, loader=None, variable_manager=VariableManager())
    # assert load_list_of_tasks(ds=ds, play=play, block=None, role=None, task_include=None,

# Generated at 2022-06-11 10:10:18.244935
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible.playbook
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.task_include
    import ansible.playbook.handler_task_include
    import ansible.playbook.handler
    import ansible.playbook.role_include
    import ansible.playbook.play

    class TasksMock(object):
        def __init__(self):
            self.blocks = []

    class VarMock(object):
        def __init__(self):
            self.static_loaded = []
            self.is_static = []

    class TaskIncludeMock(object):
        def __init__(self, obj, role=None, task_include=None, variable_manager=None, loader=None):
            self.args = obj
            self

# Generated at 2022-06-11 10:10:18.650713
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass

# Generated at 2022-06-11 10:10:26.804083
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    loader = None
    variable_manager = None

# Generated at 2022-06-11 10:10:40.355477
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    tasks = [
        {
            'block': 'test block',
            'name': 'test task'
        },
        {
            'include': 'test include',
            'name': 'test task'
        },
        {
            'import_tasks': 'test include',
            'name': 'test task'
        },
        {
            'import_role': 'test include',
            'name': 'test task'
        }
    ]
    display = Display()
    play = Play()
    loader = DataLoader()
    variable_manager = VariableManager()
    result = load_list_of_tasks(tasks, play, block=None, loader=loader, use_handlers=False, variable_manager=variable_manager)
    assert len(result) == 4
    assert isinstance(result[0], Block)


# Generated at 2022-06-11 10:10:51.270168
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
        {
            'block': {'name': 'Include a role', 'rescue': ['some task', 'some other task'], 'always': ['some task']},
            'include_role': {'name': 'test'},
        },
        {'include_role': {'name': 'test1'}},
        {'include_role': {'name': 'test2', 'static': 'yes'}},
    ]

    display_args = {}
    display_args.update(CLIARGS._get_kwargs())
    display = Display()
    display.verbosity = display_args.get('verbosity', 0)

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost'])

# Generated at 2022-06-11 10:11:03.165722
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    # FIXME: mock play_context.connection
    templar = Templar(loader=loader, variables=variable_manager.get_vars())

    # mock play
    play_context.become = None
    play_context.become_user = None
    play_context.check_mode = False
    play_context.diff = False
    play_context.force_handlers = False
    play_context.new_vars = dict()
    play_context.no_log = False
    play

# Generated at 2022-06-11 10:11:09.075987
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    tasks = [{'test': 'aa'}, {'test': 'bb'}]
    assert len(load_list_of_tasks(tasks, None, None, None, None, False, None, None)) == 2
    assert len(load_list_of_tasks(tasks, None, None, None, None, True, None, None)) == 2



# Generated at 2022-06-11 10:11:36.763030
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    try:
        load_list_of_roles(ds=[{'a': 'b'}, {'c': 'd'}])
    except AnsibleAssertionError:
        pass
    try:
        load_list_of_roles(ds=['a', 'b'])
    except AnsibleAssertionError:
        pass



# Generated at 2022-06-11 10:11:44.797171
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test with list of multiple tasks
    ds = [{'include': 'tasks1', 'depends_on': 'tasks3'},
          {'include': 'tasks2'},
          {'name': 'tasks3', 'action': 'debug', 'debug': 'msg=hi', 'when': '1==1'},
          {'name': 'tasks4', 'action': 'debug', 'debug': 'msg=hi', 'when': '1==1'},
          {'include': 'tasks1'}]
    task_list = load_list_of_tasks(ds, None, None, None, None, False, None, None)
    assert len(task_list) == 4
    assert task_list[0].action == 'include'

# Generated at 2022-06-11 10:11:54.209779
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks([], None) == []
    assert load_list_of_tasks(None, None) == []
    with pytest.raises(AnsibleAssertionError) as excinfo:
        load_list_of_tasks(1, None)
    assert 'should be a list' in to_text(excinfo.value)

    with pytest.raises(AnsibleAssertionError) as excinfo:
        load_list_of_tasks([{'block': []}], None)
    assert 'should be a dict' in to_text(excinfo.value)


# Generated at 2022-06-11 10:12:05.168982
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins import module_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Initialize variables
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Load a play

# Generated at 2022-06-11 10:12:13.611349
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    ds1 = {'include': 'test'}
    ds2 = {'block': 'test'}
    ds3 = {'block': 'test', 'test': 2}
    ds4 = {'test': 2}
    ds5 = 1234
    assert [type(item) for item in load_list_of_tasks([ds1, ds2, ds3])] == [TaskInclude, Task, Task]
    assert [type(item) for item in load_list_of_tasks([ds1, ds2, ds3, ds4])] == [TaskInclude, Task, Task]

# Generated at 2022-06-11 10:12:14.262262
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:12:26.996409
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import callback_loader


# Generated at 2022-06-11 10:12:36.871048
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars
    host_vars = HostVars(dict())
    variable_manager = VariableManager()
    variable_manager._extra_vars = {'foo': 'bar'}

# Generated at 2022-06-11 10:12:47.245812
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    pass
    # loader = DataLoader()
    # inventory = InventoryManager(loader=loader, sources=['localhost'])
    # variable_manager = VariableManager(loader=loader, inventory=inventory)
    # data = [
    #         {'include': './test1.yml'}
    #     ]
    # actual = load_list_of_tasks(data, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=variable_manager, loader=loader)
    # assert len(actual) == 1
    # assert actual[0]._role_name == './test1.yml

# Generated at 2022-06-11 10:12:52.825065
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import json

    yaml_1 = """
    - name: first task
      ping:
    - name: second task
      ping:
    """
    data = yaml.load(yaml_1)
    assert load_list_of_tasks(data) == load_list_of_tasks(json.loads(json.dumps(data)))



# Generated at 2022-06-11 10:13:13.922324
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    yaml = open("test_load_list_of_tasks.yml", 'r')
    yaml_data = yaml.read();

    ds = yaml.load(yaml_data)
    task_list = load_list_of_tasks(ds, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)

    assert task_list[0].action == "shell"
    assert task_list[0].args["_raw_params"] == "echo hello"
    assert task_list[0].args["chdir"] == "/tmp"
    assert task_list[0].args["creates"] == "/tmp/a"

    assert task_list[1].action == "command"
    assert task_list[1].args

# Generated at 2022-06-11 10:13:24.634026
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ''' function load_list_of_tasks '''
    print('*** Testing Unit function load_list_of_tasks ***')
    # Test Valid Inputs
    test_data = {'ds': [{'include': "foo"}]}
    print('Test Valid Inputs')
    display.deprecated = lambda *args, **kwargs: None
    args_parser = ModuleArgsParser({'static': 'yes', 'include': "foo"})
    args_parser.parse(skip_action_validation=True)
    block = Block()
    role = Role()
    task_include = TaskInclude()
    use_handlers = False
    display.verbosity = 1
    print('Test load_list_of_tasks with Valid Inputs')

# Generated at 2022-06-11 10:13:36.930912
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    def test(ds, expected_output):
        # FIXME: better way to do this teardown
        from ansible.playbook.task_include import TaskInclude

        play = Play()
        variable_manager = VariableManager()
        loader = DataLoader()
        display = Display()
        ds_obj = load_list_of_tasks(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=variable_manager, loader=loader)

        for i,x in enumerate(expected_output):
            assert expected_output[i] == ds_obj[i]._role, 'Expected output is {} and actual output is {}'.format(expected_output[i], ds_obj[i]._role)
        return ds_obj

    # Output should be a

# Generated at 2022-06-11 10:13:37.659256
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    return True


# Generated at 2022-06-11 10:13:46.281210
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Create the test objects
    host_vars = dict()
    host_vars['name'] = 'TEST1'
    host_vars['ansible_network_os'] = 'eos'
    host_vars['ansible_connection'] = 'network_cli'
    host_vars['ansible_become_method'] = 'enable'
    host_vars['ansible_become_pass'] = 'secret'
    host_vars['ansible_user'] = 'ansible'
    host_vars['ansible_ssh_pass'] = 'secret'
    host_vars['ansible_ssh_user'] = 'ansible'
    host_vars['ansible_ssh_port'] = 22


# Generated at 2022-06-11 10:13:56.028556
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:13:57.402210
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert callable(load_list_of_tasks)

# Generated at 2022-06-11 10:14:06.412231
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    def assert_variable_manager(manager, variable_manager=None):
        # variable_manager parameter exists for test purposes
        if variable_manager is None:
            variable_manager = MockVariableManager()
        assert isinstance(manager, VariableManager)
        assert manager is variable_manager

    def assert_task(task, use_handlers=False, variable_manager=None, task_include=None, loader=None):
        if use_handlers:
            assert isinstance(task, Handler)
        else:
            assert isinstance(task, Task)

        if isinstance(task, TaskInclude):
            # TaskInclude.include_tasks can be None if TaskInclude.static is True
            assert task_include is None or task.include_tasks is task_include


# Generated at 2022-06-11 10:14:08.118278
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Function load_list_of_tasks unit test
    '''
    pass

# Generated at 2022-06-11 10:14:16.387838
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    argument_spec = {
        "arg1": {"default": 1, "type": "int"},
        "arg2": {"default": 2, "type": "str"},
        "arg3": {"default": 7, "type": "int"},
        "arg4": {"default": ["a", "b"], "type": "list"},
    }
    module = AnsibleModule(argument_spec=argument_spec)
    assert isinstance(load_list_of_tasks([{"action1": {"arg1": 42, "arg2": "blah"}}, {"action2": 42}], None)[0], Task)
    assert isinstance(load_list_of_tasks([{"action1": {"arg1": 42, "arg2": "blah"}}, {"action2": 42}], None)[1], Task)

# Generated at 2022-06-11 10:14:52.226085
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
        # define ds
        block_1 = {
            'block': [
                {
                    'name': 'Import a task from the same file.',
                    'ignore_errors': True,
                    'import_playbook': 'load_list_of_tasks.yml'
                }
            ]
        }
        block_2= {'block': [{'local_action': {'module': 'shell', 'args': 'echo "block 2"'}}]}
        ds = [block_2]

        # define variable_manager, loader
        variable_manager = VariableManager()
        variable_manager.extra_vars = {'var1': 'foo'}
        loader = DataLoader()
        loader.set_basedir('./')
        # define play

# Generated at 2022-06-11 10:15:00.239085
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, sources=['localhost'])

    host = inventory_manager.get_host('localhost')
    host.set_variable('ansible_connection', 'local')
    variable_manager.set_inventory(inventory_manager)

    play_source

# Generated at 2022-06-11 10:15:01.768364
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks is not None

# Generated at 2022-06-11 10:15:06.173617
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ''' test load_list_of_roles '''
    ds = [
        {'role': 'test'},
        {'role': 'test1'}
    ]
    assert load_list_of_roles(ds, None) == ['test', 'test1']

    ds = [
        {'role': 'test', 'task': 'testtask'}
    ]
    load_list_of_roles(ds, None)

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-11 10:15:19.809890
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test Standard tasks
    playbook = os.path.join(test_dir, 'test_playbook.yml')
    loader = DataLoader()
    variable_manager = VariableManager()

    tasks = load_list_of_tasks([{
        'block': 'block_ds',
        'play': 'play_ds',
        'parent_block': 'parent_block_ds',
        'role': 'role_ds',
        'use_handlers': 'use_handlers_ds',
    }],
        playbook,
        block='block',
        role='role',
        task_include='task_include',
        use_handlers=False,
        variable_manager='variable_manager',
        loader=loader,
    )
    assert len(tasks) == 1

    # Test with path to test file

# Generated at 2022-06-11 10:15:20.484423
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True

# Generated at 2022-06-11 10:15:26.598580
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # test that the implicit block creation works correctly

    yaml_str = u'''
    - name: task 1
    - name: task 2
    - name: task 3
      no_log: True
    - name: task 4
    '''
    ds = yaml.safe_load(yaml_str)
    tl = load_list_of_tasks(ds, None, None, None)
    assert len(tl) == 3
    assert tl[0].name == "task 1"
    assert tl[1].name == "task 2"
    assert tl[2].name == "task 3"
    assert tl[2].no_log == True

# Generated at 2022-06-11 10:15:39.557541
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    loader = AnsibleLoader(dict(), variable_manager=VariableManager())
    variable_manager = VariableManager()


# Generated at 2022-06-11 10:15:50.926226
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """
    This is testing a private function. If there is a need to test again this
    function, please check the PR at https://github.com/ansible/ansible/pull/42781
    """
    # pylint: disable=too-many-locals,unused-argument
    def _create_fake_loader(base_dir, path, content):
        # pylint: disable=missing-docstring
        class FakeLoader(object):
            def __init__(self, path):
                self.base_dir = base_dir
                self.path = path

            def get_basedir(self):
                return self.base_dir

            def get_dir_list(self, path):
                raise Exception(
                    "[FAKE] this function should be mocked in tests: %s" % path
                )


# Generated at 2022-06-11 10:16:01.089486
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar

# Generated at 2022-06-11 10:16:52.707943
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # a random fake task to test loading tasks
    fake_task = dict(foo=dict(world='task_world'))
    task_list = load_list_of_tasks([fake_task])
    assert len(task_list) == 1



# Generated at 2022-06-11 10:17:04.442562
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext

    def test_validate_utils(tasks):
        for task in tasks:
            assert isinstance(task, Task) or isinstance(task, TaskInclude) or isinstance(task, Block)

    p = Play()
    with open(os.path.join(fixtures_path, 'test_block.yml'), 'r') as f:
        block_yaml = yaml.safe_load(f)

    with open(os.path.join(fixtures_path, 'test_task_include_params.yml'), 'r') as f:
        task_include_params_yaml = yaml.safe_load(f)


# Generated at 2022-06-11 10:17:13.167058
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import os
    import sys
    import ansible
    import ansible.constants as C
    import ansible.utils.display
    from ansible.errors import AnsibleAssertionError, AnsibleError
    from ansible.cli.playbook import PlaybookCLI
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook import Playbook

    # Hacky method to load the test data
    global test_data
    test_data

# Generated at 2022-06-11 10:17:21.508906
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-11 10:17:33.104630
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # we initialize a playbook without the datastructure
    playbook = Play.load({})
    # define a task
    task_ds = {'action': 'test', 'name': 'test'}
    # load a task using load_list_of_tasks
    result = load_list_of_tasks([task_ds], playbook)
    # the result should be a task