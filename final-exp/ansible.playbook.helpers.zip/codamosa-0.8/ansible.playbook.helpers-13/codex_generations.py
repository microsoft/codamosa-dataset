

# Generated at 2022-06-11 10:08:12.331949
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.clean import clean_facts
    from ansible.module_utils._text import to_bytes
    import ansible.constants as C
    import os
    import tempfile
    import yaml
    import sys

    if not sys.version_info >= (2, 7):
        print('SKIPPING TEST, NEEDS PYTHON 2.7+')
        return

    hosts = InventoryManager(loader=None, sources='localhost,')

# Generated at 2022-06-11 10:08:24.443070
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    import os
    import sys
    import yaml
    from ansible.playbook.play import Play
    #from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    # PLAYBOOK STUFF
    pb_dir = os.path.join(os.path.dirname(__file__), '..', 'utils', 'test_playbooks')
    pb = Play.load(os.path.join(pb_dir, 'playbook.yml'), variable_manager=None, loader=DataLoader())

    # test_playbook_tasks.yml

# Generated at 2022-06-11 10:08:36.174793
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    ds = [{'include': 'test_include.yml'}, {'package': 's3cmd'}]
    output = load_list_of_tasks(ds, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert isinstance(output[0], Task)
    assert isinstance(output[1], Task)
    ds = [{'include_vars': 'test_include.yml'}, {'package': 's3cmd'}]
    output = load_list_of_tasks(ds, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)


# Generated at 2022-06-11 10:08:39.800040
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds=None
    #check if there is no block in the playbook raise assertion error
    try:
        load_list_of_blocks(ds,None,None,None,None,None,None,None)
    except AnsibleAssertionError:
        #Test passed
        pass

# Generated at 2022-06-11 10:08:51.718959
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    # test data

# Generated at 2022-06-11 10:09:03.590507
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import collections
    import os
    import sys

    from ansible.cli.playbook import PlaybookCLI
    from ansible.errors import AnsibleParserError
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar

    display = Display()

    # ansible-playbook uses these to control the running of the code
    # so we set them to valid values here

# Generated at 2022-06-11 10:09:05.867060
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds_list = load_list_of_blocks(['A','B'],play=None,parent_block=None)



# Generated at 2022-06-11 10:09:17.267483
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role_include import IncludeRole
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_ds = {
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [
            {'action': {'module': 'debug', 'args': 'var=hostvars[inventory_hostname]'}}
        ]
    }

# Generated at 2022-06-11 10:09:29.095717
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    #TODO: Replace with a mock version of module_utils
    my_module = types.ModuleType("ansible.module_utils")
    sys.modules["ansible.module_utils"] = my_module

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.plugins.loader import module_loader
    from ansible.plugins import module_loader

    variable_manager = VariableManager()
    inventory = Inventory(variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

    variable_manager.set_host_variable("127.0.0.1", "ansible_connection", "local")

    a = {
        "name": "my_first_play",
    }

# Generated at 2022-06-11 10:09:36.021976
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    load_list_of_tasks
    '''

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import lookup_loader

    class Dummy_Task():

        def __init__(self, name):
            self.action = name
            self.args = {}
            self.name = name

        def copy(self, exclude_parent=False):
            return self

    class Dummy_Play():

        class Dummy_Play_Context():

            def __init__(self):
                self.prompt = {}

        def __init__(self):
            self.connection = 'local'
            self.force_handlers = False
            self.deprecate_tags = False
            self.force_vars = False
            self.serial = 1
            self.vars

# Generated at 2022-06-11 10:09:50.901724
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass



# Generated at 2022-06-11 10:10:00.649872
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    play_context = PlayContext()
    play = Play.load(
        dict(
            name="Ansible Play",
            hosts='all',
            gather_facts='no',
            tasks=[]
        ),
        loader=None,
        variable_manager=None
    )

    # Uses from_ds to create new datastructure
    tasks = load_list_of_tasks(ds=[{'name': 'test'}], play=play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)

# Generated at 2022-06-11 10:10:01.498074
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:10:04.767297
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert 1 == 1
    # assert 2 == 3
    #throw exception
    # assert 2 == 2


################################################################################
# ModuleArgsParser
################################################################################

__all__ = ['ModuleArgsParser'] # TODO: this is unused?



# Generated at 2022-06-11 10:10:19.406590
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    play = Play.load(dict(name='test', hosts=['localhost'], gather_facts='no', tasks=[dict(action=dict(module='debug', args=dict(msg='{{not_existing_var}}')))]), loader=None, variable_manager=None)
    roles = load_list_of_roles([{'role': 'some_role'}], play=play, current_role_path='some_path', variable_manager=None, loader=None, collection_search_list=None)
    assert roles[0].role_name == 'some_role'
    assert roles[0]._role_path == 'some_role'
    assert roles[0].current_role_path == 'some_path'

# Generated at 2022-06-11 10:10:24.178605
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.parsing import ModuleArgsParser
    from ansible.errors import AnsibleAssertionError, AnsibleParserError, AnsibleUndefinedVariable
    
    
    
    
    
    
    
    
    



# Generated at 2022-06-11 10:10:37.465156
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayClass
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-11 10:10:38.180902
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:10:49.561562
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar


# Generated at 2022-06-11 10:10:50.105100
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass


# Generated at 2022-06-11 10:11:28.046361
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Arrange
    loader = None
    variable_manager = None
    use_handlers = False
    task_include = None
    role = None
    block = None
    play = None


# Generated at 2022-06-11 10:11:29.052214
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO: Implement this
    assert True

# Generated at 2022-06-11 10:11:29.791992
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass


# Generated at 2022-06-11 10:11:41.304835
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # tests for issue https://github.com/ansible/ansible/issues/19563
    # and https://github.com/ansible/ansible/issues/19527

    from ansible.playbook.task import Task

    ds = dict(
        name="{{ item }}",
        debug=dict(msg="{{ item }}")
    )
    t = Task.load(ds)
    assert t.name == "{{ item }}"
    assert t.action == "debug"
    assert t.args == dict(msg="{{ item }}")

    ds = dict(
        debug=dict(msg="{{ item }}")
    )
    t = Task.load(ds)
    assert t.name == None
    assert t.action == "debug"
    assert t.args == dict(msg="{{ item }}")

    # tests

# Generated at 2022-06-11 10:11:53.643256
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test with valid arguments
    block_mock = Mock()
    task_include_mock = Mock()
    loader_mock = Mock()
    variable_manager_mock = Mock()


# Generated at 2022-06-11 10:12:04.494142
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import shutil
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

# Generated at 2022-06-11 10:12:13.327714
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.inventory.manager import InventoryManager

    parser = Parser()
    loader = DictDataLoader({
        "test_inventory": """
    [test_host]
    localhost
    """
    })
    inventory = InventoryManager(loader=loader, sources=["test_inventory"])

    group = inventory.groups["test_host"]

    host = group.get_hosts()[0]
    host.set_variable("ansible_connection", "local")

    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 10:12:13.928354
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass



# Generated at 2022-06-11 10:12:15.810226
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # TODO: implement load_list_of_tasks unit test
    raise NotImplementedError


# Generated at 2022-06-11 10:12:28.905976
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    from utils import ModuleArgsParser

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=['localhost']))
    # variable_manager.set_inventory(InventoryManager(loader=loader, sources='localhost,somewhere'))


# Generated at 2022-06-11 10:12:57.952731
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext

    pb = Play.load(dict(
        name="pb",
        hosts='localhost',
        gather_facts='no',
        vars=dict(a='first_var'),
        tasks=[dict(action=dict(module='debug', args=dict(msg='first_task'))), dict(action=dict(module='debug', args=dict(msg='second_task')))],
    ), loader=None, variable_manager=None)
    pc = PlayContext(pb)
    assert len(pb._tasks) == 2



# Generated at 2022-06-11 10:13:07.669152
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.module_utils.six import StringIO

    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackModule
    from ansible.plugins.callback.default import CallbackModule as CallbackModule_default

# Generated at 2022-06-11 10:13:08.321682
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass



# Generated at 2022-06-11 10:13:18.340864
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    import ansible.constants as C
    test_display = Display()

    test_action_plugin_loader = action_loader.ActionModuleLoader(C.DEFAULT_ACTION_PLUGIN_PATH, C.DEFAULT_ACTION_PLUGINS_PATH)

# Generated at 2022-06-11 10:13:19.197471
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:13:29.680801
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    
    playbook = Playbook.load()
    block = Block()
    role = Role()
    task_include = TaskInclude()
    variable_manager = VariableManager()
    loader = DataLoader()
    
    data_structure = [{"block": "test_block"}]
    assert block == load_list_of_tasks(data_structure, playbook, block, role, task_include, False, variable_manager, loader)[0]
    
    data_structure = [{"tasks": ["tasks"]}]
    assert load_list_of_tasks(data_structure, playbook, block, role, task_include, False, variable_manager, loader)[0]["tasks"] == ["tasks"]
    
    data_structure = [{"tasks": {"test_key": "test_value"}}]


# Generated at 2022-06-11 10:13:41.841125
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.module_utils.common._collections_compat import Mapping
    import sys
    import yaml
    from ansible.errors import AnsibleParserError
    from ansible.playbook.task import Task, TaskInclude
    from ansible.plugins.action.normal import ActionModule
    from ansible.plugins.action import ActionBase
    from ansible.plugins import action_loader
    from ansible.template import Templar
    from ansible.module_utils._text import to_text
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.parsing.convert_bool import boolean

    # Mock some simple modules, so we can test if tasks were correctly created.

# Generated at 2022-06-11 10:13:48.698296
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_

# Generated at 2022-06-11 10:13:59.277588
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    ds = [{'name': 'asdf'},
          {'block': [{'name': 'qwer'}]},
          {'include_tasks': 'zxcv'}
          ]

    play = MagicMock()
    block = MagicMock()
    role = MagicMock()
    task_include = MagicMock()
    variable_manager = MagicMock()
    loader = MagicMock()

    results = load_list_of_tasks(ds, play, block, role, task_include, variable_manager, loader)

    assert isinstance(results, list)
    assert len(results) == 3
    assert isinstance(results[0], Task)

# Generated at 2022-06-11 10:13:59.834184
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass



# Generated at 2022-06-11 10:14:58.084320
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible import constants as C
    from ansible.config.manager import ConfigManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    config_manager = ConfigManager()
    display.verbosity = 4

    role_exists = os.path.exists(os.path.join(C.DEFAULT_ROLES_PATH, 'role_with_vars'))

    # if the role doesn't exist, we can't do the ut
    if not role_exists:
        raise AnsibleSkipTest("unable to locate role_with_vars in %s" % C.DEFAULT_ROLES_PATH)

   

# Generated at 2022-06-11 10:15:11.493393
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.utils.vars import combine_vars

    # Test Hook
    def load_list_of_tasks_with_hook(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None):
        task_list = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)


# Generated at 2022-06-11 10:15:23.339138
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Ensure that load_list_of_tasks returns a list of Task objects.
    '''

    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    play = DummyPlay()
    loader = DummyLoader()
    variable_manager = DummyVariableManager()

    # task_ds with no option
    task_ds = {'name': 'test_task'}
    task_list = load_list_of_tasks([task_ds], play, loader=loader, variable_manager=variable_manager)
    assert isinstance(task_list[0], Task)

# Generated at 2022-06-11 10:15:37.386953
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import shared_loader_obj as plugin_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.role.meta import RoleMetadata


# Generated at 2022-06-11 10:15:48.983995
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader 
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task

    play_context = PlayContext()
    variable_manager = VariableManager()

    loader = DataLoader()


# Generated at 2022-06-11 10:15:58.824078
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Case 1: regular task and block
    display.current_display = display.Display()
    ds = [{"action": {"module": "command", "args": "hostname"}}, {"block": [{"action": {"module": "command", "args": "uname"}}]}]
    play = {}
    assert(compare_result(1, ansible.playbook.helpers.load_list_of_tasks(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)))

    # Case 2: regular task, block and include
    display.current_display = display.Display()

# Generated at 2022-06-11 10:16:10.099535
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            {'action': {'module': 'shell', 'args': 'ls'}},
            {'action': {'module': 'debug', 'args': {'msg': '{{shell_out.stdout}}'}}},
        ]
    )
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=DataLoader(), variable_manager=variable_manager, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

    tasks = load_list_of_tasks

# Generated at 2022-06-11 10:16:20.772265
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:16:21.641883
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    #TODO
    pass

# Generated at 2022-06-11 10:16:29.617851
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = \
        [
            {
                "debug": "msg={{inventory_hostname}}"
            },
            {
                "block": [
                    {
                        "debug": "msg={{inventory_hostname}}"
                    }
                ]
            },
            {
                "block": [
                    {
                        "debug": "msg={{inventory_hostname}}"
                    }
                ]
            }
        ]
    task_list = load_list_of_tasks(ds, None, None, None, None, False, None)
    assert task_list[1].block[0].args['msg'] == "{{inventory_hostname}}"

# Generated at 2022-06-11 10:17:35.769544
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Import needed to prevent circular dependency
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    # Task test
    ds = dict(action='debug', msg='{{ a }}')
    task = Task.load(
        ds,
        block=None,
        role=None,
        task_include=None
    )
    assert task.hashname == 'debug_name'

    # Block test
    ds = dict(block=['one', 'two'])
    block = Block.load(
        ds,
        play=None,
        parent_block=None,
        role=None,
        task_include=None,
        use_handlers=False
    )