

# Generated at 2022-06-11 10:08:26.775286
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude
    role_name = 'role_name'
    role_path = '/role/path'
    role_path_list = [role_path]
    role_ds_name_only = [{'role': role_name}]
    role_ds_path_only = [{'role': role_path}]
    role_ds_path_list = [{'role': role_path_list}]
    old_roles_path = C.DEFAULT_ROLES_PATH
    C.DEFAULT_ROLES_PATH = '/foo:/bar'

    def get_roles_path():
        return C.DEFAULT_ROLES_PATH

    def get_roles_path_list():
        return C.DEFAULT_ROLES_PATH.split

# Generated at 2022-06-11 10:08:38.008219
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    raw_data_str='''
- debug:
    msg: 'This is block 1'
- debug:
    msg: 'This is block 2'
- include: some_file
- import_tasks: some_other_file
- import_tasks:
    file: some_third_file
'''
    raw_data=yaml.load(raw_data_str)
    task_list=load_list_of_tasks(raw_data,None)
    assert isinstance(task_list[0], Block)


# Generated at 2022-06-11 10:08:50.096088
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    playbook_path = 'test/unit/fixtures/playbook.yml'
    playbook_path2 = 'test/unit/fixtures/playbook2.yml'

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)

    # Case 1

# Generated at 2022-06-11 10:09:01.653337
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert type(load_list_of_tasks([{'include_tasks': 'foo.yml'}], None)) == list
    assert type(load_list_of_tasks([{'block': [{'block': [{'block': {'tasks': [{'debug': ''}]}}]}]}], None)) == list
    assert type(load_list_of_tasks([{'block': [{'block': [{'block': {'rescue': {'tasks': [{'debug': ''}]}}}]}]}], None)) == list
    assert type(load_list_of_tasks([{'block': [{'block': [{'block': {'always': {'tasks': [{'debug': ''}]}}}]}]}], None)) == list

# Generated at 2022-06-11 10:09:06.072000
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.plugins.loader import action_loader


# Generated at 2022-06-11 10:09:17.701539
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    #Create Playbook and Play
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])

# Generated at 2022-06-11 10:09:29.501855
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    module_path = os.path.join(os.getcwd(), '../../lib/ansible/modules/packaging')
    module_path = os.path.abspath(module_path)
    localhost = '127.0.0.1'
    options = Options()
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[localhost])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 10:09:30.499129
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO
    pass

# Generated at 2022-06-11 10:09:31.131531
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:09:32.077804
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # TODO: implement test
    pass

# Generated at 2022-06-11 10:09:57.487116
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    module_loader = AnsibleModuleLoader(None)
    collection_loader = SharedPluginLoaderObj(module_utils=['defaults'])
    collection_search_path = [f'test/unit/data/collections/ansible_collections/test_namespace/test_collection/roles']

    mock_C = MagicMock()
    mock_C.config.get_config_value.return_value = False
    mock_C.config.DEFAULT_ROLES_PATH = []
    mock_C.config.DEFAULT_ROLES_PATH.extend(collection_search_path)

    with patch('ansible.config.constants', mock_C):
        loader_obj = AnsibleCollectionRefResolver(collection_search_path, collection_loader, module_loader)

    variable_manager = VariableManager()
    variable

# Generated at 2022-06-11 10:10:04.585441
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    loader = DictDataLoader({
        "/etc/ansible/roles/test/tasks/main.yml": """
        - name: test-task
    """
    })
    variable_manager = VariableManager()
    play = Play()
    play.loader = loader
    play.variable_manager = variable_manager
    task_ds = []
    load_list_of_tasks(task_ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    pass

# Generated at 2022-06-11 10:10:19.189035
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils import context_objects as co


# Generated at 2022-06-11 10:10:19.900734
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:10:27.404729
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Task, Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    block = Block(play=None)
    def create_task(name):
        ds = {
            'name': name,
            'action': 'ping'
        }
        return Task.load(ds, block=block, variable_manager=variable_manager,loader=loader)

    task1 = create_task('task1')
    task2 = create_task('task2')
    ds1 = {
        'block': [task1, task2]
    }

# Generated at 2022-06-11 10:10:30.021443
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{'meta': 'foo'}]
    assert load_list_of_tasks(ds) == []

# Generated at 2022-06-11 10:10:31.390804
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # ToDo: Implement
    pass

# Generated at 2022-06-11 10:10:43.995881
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Load a role via its fully qualified name
    role_list = load_list_of_roles([{'role': 'foo'}], None, None, None, None)
    assert isinstance(role_list[0], RoleInclude)
    assert role_list[0].role == 'foo'
    assert role_list[0].name == 'foo'
    assert role_list[0].collections is None

    # Load a role via a qualified name with a collections path
    role_list = load_list_of_roles([{'role': 'foo', 'collections': ['bar']}], None, None, None, None)
    assert isinstance(role_list[0], RoleInclude)
    assert role_list[0].role == 'foo'
    assert role_list[0].name == 'foo'

# Generated at 2022-06-11 10:10:50.200054
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    templar = Templar(loader=None, variables={})

    def get_one_role_by_name(name):
        return {'name': name, 'path': 'roles/' + name}
    loader = Mock()
    loader.list_directory.return_value = ['test_role_1', 'test_role_2', 'test_role_3']
    loader.get_one_role_by_name.side_effect = get_one_role_by_name
    loader.path_dwim_relative.return_value = 'roles/test_role_1/tasks/main.yml'
    loader.load_from_file.return_value = [{'block': None, 'include': 'some_task.yml'}]

    variable_manager = Mock()
    variable_manager.get_

# Generated at 2022-06-11 10:11:02.175385
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    h = '''
    hosts:
    - admin
    - intranet
    tasks:
      - name: copy file to admin
        copy:
          src: /srv/myfiles/foo.conf
          dest: /etc/foo.conf
      - name: copy file to intranet
        copy:
          src: /srv/myfiles/foo.conf
          dest: /etc/foo.conf
    variables:
    - key: value
    '''
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    d = AnsibleMapping.load(h)
    play = Play.load(d, '', '')
    l = load_list_of_tasks(play.tasks, play)
    print(l)

# Generated at 2022-06-11 10:11:41.451159
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """
    Test load_list_of_tasks function
    """
    # define test input
    ds = dict(
        action="get_ip_address",
        register="{{ ip_address }}",
        delegate_to="localhost",
    )

    # define test output

# Generated at 2022-06-11 10:11:51.746428
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_include = None
    role = None
    block = None
    use_handlers = False
    with open('tasks_data.yaml') as myfile:
        data = yaml.load(myfile, Loader=yaml.FullLoader)
    tasks = load_list_of_tasks(data, None, block=block, role=role, task_include=task_include, use_handlers=use_handlers, variable_manager=None, loader=None)
    assert isinstance(tasks[0], Task)
    assert isinstance(tasks[1], Task)
    assert isinstance(tasks[2], IncludeRole)


# Generated at 2022-06-11 10:11:54.043742
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{'block': []}]
    load_list_of_tasks(ds=ds)


# Generated at 2022-06-11 10:12:04.942334
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
        {
            'block': [
                {'include': 'tasks/A.yml'},
                {
                    'block': [
                        {'include': 'tasks/B.yml'},
                        {'include': 'tasks/C.yml'},
                    ],
                    'block': [
                        {'include': 'tasks/D.yml'},
                        {'include': 'tasks/E.yml'},
                    ]
                },
                {'include': 'tasks/F.yml'}
            ]
        }
    ]
    ret = load_list_of_tasks(ds, None, None, None, None, False, None, None)
    print(len(ret))
    print(ret)
    #Set task_list to hold the task list of

# Generated at 2022-06-11 10:12:13.514983
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import IncludeRole

    my_play = Play().load(
        dict(
            hosts='localhost',
            roles=['my_role'],
            vars=dict(
                foo=10,
                bar=5,
            ),
        ),
        variable_manager=VariableManager(),
        loader=DataLoader(),
    )

    # 1. test load  a list of blocks with a list of task

# Generated at 2022-06-11 10:12:26.024716
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list=['localhost']))
    # action == ping
    task_ds = [{'ping': ''}]
    play = Play().load(
        task_ds,
        variable_manager=variable_manager,
        loader=loader,
    )
    results = load_list_of_tasks(
        task_ds,
        play=play,
        block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=variable_manager,
        loader=loader,
    )
    assert len(results) == 1
    assert results[0].action == 'ping'
    # action

# Generated at 2022-06-11 10:12:26.442053
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:12:36.610344
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
   pass
   # ds_list=yaml.load(open(r'/home/shubham/my_modules/ansible/lib/ansible/playbook/base.py'))
   # ds_dict=ds_list[1]
   # print(type(ds_dict))
   # #print(yaml.dump(ds_dict))
   # print(ds_dict)
   # print(ds_dict.keys())
   # print(ds_dict.values())
   # test_obj=load_list_of_tasks(ds=ds_dict,play='test',block=None,role=None,task_include=None,use_handlers=False,variable_manager='test',loader='test')
   # print(test_obj)
   # print(type(test_obj))
   # print(len

# Generated at 2022-06-11 10:12:46.877871
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    playbook_path = 'tests'
    loader = DataLoader()
    variable_manager = VariableManager()

    module_finder = ModuleFinder(loader=loader)
    module_finder._add_directory(os.path.join(C.DEFAULT_MODULE_PATH, 'core'))
    module_finder._add_directory(os.path.join(C.DEFAULT_MODULE_PATH, 'extras'))

    variable_manager.extra_vars = {
        'example_var': 'Example variable'
    }

    pb_data = load_playbook_file(playbook_path, variable_manager=variable_manager)
    handler_data = pb_data['handlers']

    tasks = load_list_of_tasks(handler_data, None, None, None, None, True, variable_manager, loader)

# Generated at 2022-06-11 10:12:58.467683
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{
        "become": "false",
        "hosts": "all",
        "tasks": [
            {
                "block": [
                    {
                        "block": [],
                        "when": "False"
                    }
                ],
                "name": "test"
            },
            {
                "arguments": {
                    "_raw_params": "{{ var }}",
                    "var": 1
                },
                "include_tasks": "simple.yml"
            },
            {
                "block": [],
                "name": "second test"
            }
        ]
    }]

# Generated at 2022-06-11 10:13:20.962134
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass



# Generated at 2022-06-11 10:13:32.392728
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.errors import AnsibleUndefinedVariable
    role_name = 'test_role'
    role_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data/roles/%s' % role_name)
    loader = DataLoader()

# Generated at 2022-06-11 10:13:43.206025
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play

    loader = get_loader('/path/to/datastores')
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list=['1.2.3.4']))
    play = Play.load(dict(
        name = "Ansible Play",
        hosts = "all",
        gather_facts = "no",
        tasks = [
            dict(action=dict(module="debug", args=dict(msg="Hello, world!")))
        ]),
        variable_manager=variable_manager,
        loader=loader
    )
    task_list = []

# Generated at 2022-06-11 10:13:52.823879
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = {'action': {'module': 'shell',
                          'args': 'ls',
                          'when': 'ansible_check_mode'},
               'name': 'foo'}
    task_list = load_list_of_tasks([task_ds], None, None, None, False, None, None)
    assert task_list[0].module_vars["action"] == {'args': 'ls', 'module': 'shell', 'when': 'ansible_check_mode'}
    assert task_list[0].module_vars["name"] == 'foo'
    assert task_list[0].action == 'shell'
    assert task_list[0].args == 'ls'
    assert task_list[0].when == 'ansible_check_mode'



# Generated at 2022-06-11 10:14:02.919789
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play

    play_ds = dict(
        name="test",
        hosts='all',
        gather_facts="yes",
        roles=['salt'],
        tasks=[
            {'action': {'module': 'setup'}},
            {'action': {'module': 'shell', 'args': 'ls'}},
        ],
    )
    _play = Play.load(play_ds, variable_manager=None, loader=None)
    # Create list of blocks
    _test_list_of_blocks = load_list_of_blocks(_play.compile(), play=_play, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert len(_test_list_of_blocks)

# Generated at 2022-06-11 10:14:07.079989
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.plugins import module_loader
    from ansible.parsing.dataloader import DataLoader

    def reset_module_loader():
        module_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../../plugins/action'))
        module_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../../plugins/cache'))
        module_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../../plugins/callback'))
        module_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../../plugins/cliconf'))

# Generated at 2022-06-11 10:14:15.605896
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import yaml
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    if not hasattr(yaml, 'CSafeLoader'):
        raise SkipTest("YAML is not safe, cannot run test_load_list_of_blocks. "
                       "Install libyaml systemwide to run this test")


# Generated at 2022-06-11 10:14:23.757696
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    task = {'action': 'ping'}
    assert type(load_list_of_tasks([task], play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)[0]) == Task

    task_vars = {'hosts': 'localhost'}
    assert type(load_list_of_tasks([task_vars], play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)[0]) == Task

    task_include = {'include': 'tasks.yml'}

# Generated at 2022-06-11 10:14:33.368556
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.strategy import StrategyBase
    import ansible.constants as C

    class TestCallbackModule(CallbackBase):
        """
        Test callback module
        """
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'aggregate'


# Generated at 2022-06-11 10:14:44.954985
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Build a testcase

    # Build a TaskMeta with a TaskInclude
    task_ds = {
        'action': 'include_tasks',
        'loop': 'loop_var',
        'static': False,
        '_params': 'params',
        'loop_control': {
            'loop_var': 'secret_var',
        },
    }
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    task_include = TaskInclude.load(
        task_ds,
        block=None,
        role=None,
        task_include=None,
        variable_manager=variable_manager,
        loader=loader,
    )
    # Build a Block with a TaskMeta
    block = Block()
    block.block = [task_include]
    # Build a Play with a

# Generated at 2022-06-11 10:15:07.368565
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert_equal(load_list_of_tasks([], None, None), [])

# Generated at 2022-06-11 10:15:20.745569
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:15:24.980214
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_list = [{'block': 'test'}]
    play = {}
    block = {}
    role = {}
    task_include = {}
    use_handlers = False
    variable_manager = {}
    loader = {}
    a = load_list_of_tasks(task_list, play, block, role, task_include, use_handlers, variable_manager, loader)
    print(a)

# Generated at 2022-06-11 10:15:39.005822
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop as mock_unfrackpath
    from units.mock.vars import VariableManager
    from units.mock.vm import MockTask, MockRole

    #######################################################################################
    #
    #   parameters and objects
    #
    #######################################################################################
    ds_list_tasks = [
        dict(block=[]),
        dict(block=[]),
    ]

    ds_empty_list = [
    ]


# Generated at 2022-06-11 10:15:50.438132
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.module_utils._text import to_bytes
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    ds_list = yaml.safe_load(to_bytes("""
    - shell: test
    - include: test-include
    - include_role: test-role-include
    - import_playbook: test-playbook-import
    - meta: test-meta
    """))

    # we have to set up the block parent because Task.load() will call
    # the parents get_vars and get_type_

# Generated at 2022-06-11 10:16:00.945154
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    test load_list_of_tasks() function
    :return:
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.task_queue_manager import TaskQueueManager

    callbacks = [CallbackBase()]
    variable_manager = VariableManager()
    loader = DataLoader()

    # Create dummy host and inventory
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])

# Generated at 2022-06-11 10:16:12.932005
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    # init objects for test
    ds = dict(
        name='test_task',
        local_action=dict(
            module='shell',
            args='ls /',
        ),
    )
    templar = Templar(loader=None, variables=dict())
    var_manager = VariableManager()
    task_include = TaskInclude()
    block = 'block'
    role = Role

# Generated at 2022-06-11 10:16:22.348184
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:16:32.476015
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    class VarsModule(object):

        def __init__(self, ds):
            self.ds = ds

        def vars(self):
            return self.ds

        def run(self, *args, **kwargs):
            return self.vars()

    variable_manager = VariableManager()
    variable_manager._fact_cache = dict()

    variable_manager.extra_vars = dict(
        foo='foo',
        bar='bar',
        baz='baz',
    )


    loader = DataLoader

# Generated at 2022-06-11 10:16:39.352219
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    data = [
        {'hosts': '{{ inventory_hostname }}',
            'tasks': [
                {'include': None}
            ]
        }
    ]
    try:
        load_list_of_tasks(data, None, None, None)
    except:
        print('test_load_list_of_tasks')
        print('This function will try to raise exception: AnsibleParserError')

if __name__ == '__main__':
    test_load_list_of_tasks()