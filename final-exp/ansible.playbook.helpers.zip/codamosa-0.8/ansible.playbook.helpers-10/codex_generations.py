

# Generated at 2022-06-11 10:08:13.137905
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    pass
    # def test_load_list_of_tasks(self):
    #     ds = [
    #         {'name': 'bacon', 'action': 'break_glass'},
    #         {'name': 'egg', 'action': 'prompt'},
    #         {'action': 'prompt'},
    #     ]
    #     tasks = load_list_of_tasks(ds, play=None, block=None, role=None, task_include=None)
    #     assert len(tasks) == 3
    #     for task in tasks:
    #         assert isinstance(task, Task)
    #     assert tasks[0].action == 'break_glass'
    #     # the prompt module is the default if one isn't provided
    #     assert tasks[1].action == 'prompt

# Generated at 2022-06-11 10:08:25.121013
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved
    from ansible.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars


# Generated at 2022-06-11 10:08:36.831973
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import json
    import os
    import tempfile
    filepath = os.path.join(os.path.dirname(__file__), 'lib/unit_test_tasks.json')
    with open(filepath, 'r') as f:
        test_cases = json.load(f)
    tc_msg = 'test case: {}'
    def _get_result_from_file(filepath):
        result = None
        with open(filepath, 'r') as f:
            result = json.load(f)
        return result
    for tc in test_cases:
        msg = tc_msg.format(tc['description'])

# Generated at 2022-06-11 10:08:48.787696
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    template_vars = VariableManager()._template_vars
    for fact_collector in DistributionFactCollector.get_collectors():
        template_vars.update(fact_collector.get_facts())
    templar = Templar(loader=None, variables=template_vars)

# Generated at 2022-06-11 10:09:00.341153
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    # => setup
    ds_list_of_task_dicts = [
        {'include': 'path/to/my/include/file'},
        {'meta': 'meta data'},
        {'when': 'some condition'},
        {'include': 'another/vars/file', 'static': True},
        {'action': 'copy', 'args': {'src': 'some src', 'dest': 'some dest'}},
    ]

    # => run

# Generated at 2022-06-11 10:09:10.045748
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar

    if not isinstance(ds, list):
        raise AnsibleAssertionError('The ds (%s) should be a list but was a %s' % (ds, type(ds)))

    task_list = []

# Generated at 2022-06-11 10:09:18.859860
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    dir = os.path.dirname(__file__)
    path = os.path.join(dir, 'test_load_list_of_tasks.yml')
    ds = [1,2,3]
    with open(path, 'w') as f:
        yaml.dump(ds, f)
    play = Play()
    variable_manager = VariableManager()
    loader = DataLoader()
    tmp = load_list_of_tasks(ds, play, variable_manager=variable_manager, loader=loader)
    assert(tmp == ds)

# Generated at 2022-06-11 10:09:30.591209
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.plugins.loader import action_loader
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.vars import combine_vars
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, use_task_vars=True, variable_manager=None)

# Generated at 2022-06-11 10:09:39.879173
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block


# Generated at 2022-06-11 10:09:50.611452
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    ds = [
        {'action': 'setup', 'register': 'st'},
        {'include_tasks': 'common_tasks.yml'},
        {'include_tasks': 'not_exists.yml'},
        {'include_tasks': 'not_exists.yml', 'ignore_errors': True},
        {'include_role': {'name': 'web', 'static': True}},
        {'include_role': 'web', 'static': True}
    ]
    play = Mock()
    block = Mock()
    role = Mock()
    task_include = None
    use_handlers = False
    variable_manager = Mock()
    loader = Mock()

# Generated at 2022-06-11 10:10:25.902173
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.base import Base
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar

    ds = []
    play = Base()
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None

    module = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert module == []


# Generated at 2022-06-11 10:10:39.446424
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert callable(load_list_of_tasks)
    test_case = [
        {'hosts': 'localhost', 'gather_facts': 'no',
         'tasks': [
                     {'name': 'test', 'action': {'module': 'command', 'args': 'uname -a'}}
                 ]
        }
    ]
    play = Play().load(test_case, variable_manager=VariableManager(), loader=DataLoader())
    test_case_tasks = load_list_of_tasks(play.tasks, play=play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=play._variable_manager, loader=play._loader)
    #print(test_case_tasks)
    assert test_case_tasks[0]._parent

# Generated at 2022-06-11 10:10:50.560486
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.plugins.loader import plugin_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.compat.tests.mock import MagicMock

    mock_file = MagicMock()
    mock_file.read.return_value = '{}'

    mock_open = MagicMock()
    mock_open.return_value = mock_file

    mock_cli = MagicMock()
    mock_cli.options = {'connection': 'local'}

    mock_cli.ansible_connection = 'local'

    with patch('__builtin__.open', mock_open, create=True):
        # Setup the fake environment
        collection_search_list = ['/foo/bar/roles']
        lookup_loader._list = collection_search_

# Generated at 2022-06-11 10:11:02.577157
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    # Create a play with a single task
    ds = [
        dict(
            name="test 1",
            debug=dict(msg="first task!"),
        ),
        dict(
            name="test 2",
            debug=dict(msg="second task!"),
        ),
    ]
    play = Play.load(dict(name="test", hosts="all", gather_facts="no", tasks=ds))

# Generated at 2022-06-11 10:11:11.731177
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks(ds=None, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None) == []
    assert load_list_of_tasks(ds=[], play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None) == []
    assert load_list_of_tasks(ds=[None], play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None) == []


# Generated at 2022-06-11 10:11:22.786755
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # The purpose of this function is to create a dictionary object which
    # will be used by the function load_list_of_tasks to load a task.
    # This function is used to load a block.

    # We import here to prevent a circular dependency with imports
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager

    fake_loader = DictDataLoader({
        '/etc/ansible/roles/fake_role/tasks/main.yml': """
- block:
    - import_tasks: task1.yml
        static: true

- block:
    - import_tasks: task2.yml
        static: true
"""
    })

    fake_variable_manager

# Generated at 2022-06-11 10:11:33.259180
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar

# Generated at 2022-06-11 10:11:37.199735
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# import module snippets.  This are required
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 10:11:40.716139
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_list = [{"action": {"module": "ping", "args": "test"}}, {"action": {"module": "test", "args": ""}}]
    load_list_of_tasks(task_list)
    # TODO: add failure cases



# Generated at 2022-06-11 10:11:46.614609
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:12:11.497175
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.block import BlockInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import ansible.constants as C

    # Necessary modules to build our tasks and blocks


# Generated at 2022-06-11 10:12:23.177247
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    This is a unit test for the load_list_of_tasks function.
    Tutorial code from: https://chriswarrick.com/blog/2014/09/15/python-apps-the-right-way-entry_points-and-scripts/
    '''
    # set up the test cases
    ds_00 = "string"
    ds_01 = 42
    ds_02 = [1,2,3]
    ds_03 = [{'action': 'copy', 'copy': {'src': 'files/foo.txt', 'dest': '/tmp/foo.txt'}}]
    ds_04 = {'action': 'copy', 'copy': {'src': 'files/foo.txt', 'dest': '/tmp/foo.txt'}}

# Generated at 2022-06-11 10:12:23.946716
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass


# Generated at 2022-06-11 10:12:35.299818
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    assert load_list_of_tasks(
        ds=[{"include" : "roles"}],
        play=None,
        block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=None,
        loader=None,
        ) == [{"include" : "roles"}]


# Generated at 2022-06-11 10:12:44.882225
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible.playbook.task

    class MockPlay(object):
        pass

    class MockBlock(object):
        pass

    class MockRole(object):
        pass

    class MockTaskInclude(object):
        pass

    class MockVariableManager(object):
        def get_vars(self, play, task):
            return {}

    class MockLoader(object):
        def load_from_file(self, *args, **kwargs):
            pass

        def list_directory(self, *args, **kwargs):
            return []

        def path_exists(self, *args, **kwargs):
            return False


# Generated at 2022-06-11 10:12:46.448895
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Unit test for function load_list_of_tasks
    pass

# Generated at 2022-06-11 10:12:51.688188
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks([{'shell': 'ls'}], None)
    assert load_list_of_tasks([{'shell': 'ls'}, {'shell': 'ddos'}], None)
    assert not load_list_of_tasks([{'block' : 'ls'}], None)

# Generated at 2022-06-11 10:13:03.068115
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import yaml
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.reserved import reserved_var_names
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.playbook.play import Play
    # FIXME: loader/vars set up can be shared
    loader = DataLoader()
    inventory = Inventory(loader, host_list=[Host(name='localhost')])
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)
    variable_manager._extra

# Generated at 2022-06-11 10:13:12.035081
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:13:22.726734
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:13:47.747302
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    test function - load_list_of_roles
    """
    collection_search_list = [{"name": "apache"}, {"name": "foo"}]
    ds = [{"role": "apache", "foo": "bar"}, {"role": "foo"}]

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.include import RoleInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play = Play().load({}, variable_manager=VariableManager(), loader=None)
    play._role_paths = ['/etc/ansible/roles']
    play._variable_manager = VariableManager()

# Generated at 2022-06-11 10:13:58.359564
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-11 10:14:07.185607
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    task_ds = [
        {'action': 'setup'},
        {'include': ''},
        {'include_tasks': ''},
        {'import_tasks': ''},
        {'import_role': ''},
        {'include_role': ''},
    ]
    # use_handlers = False
    task_list = load_list_of_tasks(task_ds, None, False)
    assert isinstance(task_list[0], Task)

# Generated at 2022-06-11 10:14:15.741120
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
  # load_list_of_tasks requires dictionary and list arguments
  # else, it will raise AnsibleAssertionError
  ds = dict()
  ds = list(ds)

  # If the ds is not a list, it will raise AnsibleAssertionError
  ds = dict()
  args_parser = ModuleArgsParser(ds)
  try:
    (action, args, delegate_to) = args_parser.parse(skip_action_validation=True)
  except AnsibleParserError as e:
    if e.obj:
      raise
    raise AnsibleParserError(to_native(e), obj=ds, orig_exc=e)
  except AnsibleAssertionError as e:
    print("Failure: " + str(e))
    return

  # If not all of the elements in ds

# Generated at 2022-06-11 10:14:23.943667
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.role_dependency import RoleDependency
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor


    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=('localhost,',))
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-11 10:14:33.580181
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    r = load_list_of_tasks('abc', 'def', block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    print(r)

    # Test parameter 'task_ds' is not a list
    ds = 123
    try:
        r = load_list_of_tasks(ds, 'def', block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
        print(r)
    except AssertionError as e:
        print(e)
    else:
        raise Exception('Unexpected')

    # Test parameter 'task_ds' is list but include invalid type
    ds = [123]

# Generated at 2022-06-11 10:14:45.385168
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {
        'var1': 'foo',
        'var2': 'bar'
    }
    play = Play.load({
        'name': 'TEST',
        'hosts': ['all'],
        'gather_facts': False,
        'tasks': [
            {'debug': 'msg="{{ var1 }}"'},
            {'debug': 'msg="{{ var2 }}"'},
        ],
    }, variable_manager=variable_manager, loader=loader)
    result = load_list_of

# Generated at 2022-06-11 10:14:46.296269
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert True

# Generated at 2022-06-11 10:14:57.250959
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    # Create a test PlaybookExecutor to get a test Playbook and the task_vars
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 10:15:10.447764
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import module_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback.default import CallbackModule
    from ansible.playbook.block import Block
    #from ansible.playbook.play_context import PlayContext
    from ansible.playbook.handler import Handler

# Generated at 2022-06-11 10:15:37.652296
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    parser = configparser.ConfigParser()
    parser.read("test/units/test_utils/test.cfg")
    # Use the test-config file to specify the directory for the test files
    test_dir = parser.get("default", "test_dir")
    template_dir = test_dir + "/templates"
    template_dir_2 = test_dir + "/templates2"
    C.DEFAULT_ROLES_PATH = test_dir + "/roles"

    class Play():
        def __init__(self):
            self.vars = dict()
            self.vars['var'] = 'val'
            self.vars['var1'] = 'val1'
            self.vars['var2'] = 'val2'

    class Block():
        def __init__(self):
            self.vars

# Generated at 2022-06-11 10:15:49.255465
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from io import StringIO
    from collections import namedtuple


# Generated at 2022-06-11 10:15:55.729274
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # test that a list of tasks are returned as expected
    ds = [{'debug': {'msg': "hello world"}}]
    assert len(load_list_of_tasks(ds=ds, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)) == 1

    # test that if non-list is passed in that exception is raised
    ds = {}
    try:
        load_list_of_tasks(ds=ds, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
        assert False
    except AnsibleAssertionError:
        assert True

    # test that if list is passed and one element not dict that exception is raised

# Generated at 2022-06-11 10:15:56.395968
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:16:07.102655
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    def _get_variable_manager(loader=None, inventory=None):
        '''
        Create a variable manager
        '''
        if loader is None:
            loader = Data

# Generated at 2022-06-11 10:16:18.751264
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_list = []
    task_ds = {}
    task_ds["block"] = []
    task_ds["block"].append({"name":"test"})
    task_ds["block"].append({"name":"test1"})
    task_ds["block"].append({"name":"test2"})
    task_ds["block"].append({"name":"test3"})
    task_ds["block"].append({"name":"test4"})
    task_ds["block"].append({"name":"test5"})
    task_ds["block"].append({"name":"test6"})


# Generated at 2022-06-11 10:16:26.618197
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader

    variable_manager = VariableManager()
    loader = DataLoader()
    options = PlayContext()
    display = Display()
    inventory = InventoryManager(loader=loader, sources='ansible/test/functional/inventory')
    variable_manager.set_inventory(inventory)
    # variable

# Generated at 2022-06-11 10:16:28.548464
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass
if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-11 10:16:29.192491
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass



# Generated at 2022-06-11 10:16:39.510272
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar
    from ansible.vars import VariableManager

    # setup
    variable_manager = VariableManager()
    templar = Templar(loader=None, variables=variable_manager)
    play_context = PlayContext()
    play_context.connection = 'local'
    play_context.network_os = 'ios'
    play_context.remote_addr = '127.0.0.1'
    play_context.become = False

# Generated at 2022-06-11 10:17:07.056088
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    host_list = [{"hostname": "test"}]
    inventory = InventoryManager(loader=loader, sources=host_list)
    variable_manager = VariableManager(loader=loader, inventory=inventory)


    task_ds = [{"action": "copy", "args": {"path": "/tmp/test.txt"}, "name": "test"}]
    task_list = load_list_of_tasks(task_ds, {"name": "test"})
    assert len(task_list) == 1

# Generated at 2022-06-11 10:17:15.538674
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    import json
    v = VariableManager()
    i = InventoryManager(loader=DataLoader())
    i.clear_pattern_cache()

# Generated at 2022-06-11 10:17:16.129310
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert load_list_of_roles


# Generated at 2022-06-11 10:17:24.765355
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-11 10:17:36.718976
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    ds_list = [{'block': 'foo'}, {'name': 'bar'}, None, {'include_tasks': 'baz'}]
    play = Play()
    play.variable_manager = variable_manager
    task_list = load_list_of_tasks(ds_list, play, variable_manager=variable_manager, loader=loader)
    assert isinstance(task_list, list)
    assert len(task_list) == 4
    assert task_list[0].args == {'block': 'foo'}