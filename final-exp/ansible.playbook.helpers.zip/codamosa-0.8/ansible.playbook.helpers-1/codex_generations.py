

# Generated at 2022-06-11 10:08:36.403960
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole

    # Assign values
    ds = [{"name": "foo", "action": "fail"}, {"name": "bar", "action": "debug", "block": [{"name": "baz", "action": "debug"}]}]
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None


# Generated at 2022-06-11 10:08:37.111429
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO
    pass


# Generated at 2022-06-11 10:08:49.322741
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    tasks = load_list_of_tasks([{
        'block': [],
        'otherwise': [],
        'rescue': [],
    },{
        'action': 'include',
        'args': {'name': '/home/ivan/work/ansible/playbooks/roles/s1/tasks/main.yml'}
    }], None, None, None, None, None, None)
    assert isinstance(tasks[0], Block)
    assert isinstance(tasks[1], TaskInclude)


# Generated at 2022-06-11 10:09:00.846156
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ast
    import pprint
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.vars.clean import module_response_deepcopy
    from ansible.executor import task_result
    from ansible.utils.vars import combine_vars
    # construct the class mock
    variable_manager = VariableManager()
    variable_manager.__class__ = class_mock()
    variable_manager._fact_cache = {}

    loader = DataLoader()

    display = Display()

# Generated at 2022-06-11 10:09:06.476356
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = ds_from_yaml('''
        - stat:
            path: /etc/sudoers
            register: usr_sudo
        - debug:
            var: usr_sudo
    ''')

    task_list = load_list_of_tasks(ds)
    assert task_list[0].action == 'stat'


# Generated at 2022-06-11 10:09:07.129364
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass



# Generated at 2022-06-11 10:09:19.104701
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import StringIO
    if not C.DEFAULT_KEEP_REMOTE_FILES:
        print("--- NOTE: The C.DEFAULT_KEEP_REMOTE_FILES option is currently disabled in this test, so some of the tests will not work")

    print("--- test_load_list_of_blocks: pure implicit blocks")
    s = '''  - shell: echo "1"
      ignore_errors: True

  - shell: echo "2"
      ignore_errors: True
    '''
    ds = []

    ds = load_list_of_blocks(ds=ds, play=None)
    assert ds == [], ds

    ds = load_list_of_blocks(ds=ds, play=None, loader=DictDataLoader())
    assert ds == [], ds

    ds

# Generated at 2022-06-11 10:09:30.723359
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar


# Generated at 2022-06-11 10:09:40.088544
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    import json

    display = Display()
    options = Options()
    options.connection = 'smart'
    options.module_path = os.path.dirname(os.path.dirname(__file__)) + '/lib'
    options.forks = 100
    options.private_key_file = None
    options.ssh_common_args = ''
    options.ssh_extra_args = ''
    options.sftp_extra_args = ''
    options.scp_extra_args = ''
    options.become = False
    options.become_method = 'sudo'
    options.become_user = 'root'
    options.verbosity = 0
    options.check = False
    options.listhosts = False
    options.listtasks = False
    options.listtags = False
    options.syntax

# Generated at 2022-06-11 10:09:41.246668
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass


# Generated at 2022-06-11 10:10:17.034159
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{
        u'broadcast': u'all',
        u'command': u'echo hi'
    }, {
        u'include': u'include.yml'
    }]
    assert load_list_of_tasks(ds, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)

# Generated at 2022-06-11 10:10:18.242788
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert callable(load_list_of_tasks)

# Generated at 2022-06-11 10:10:20.633862
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """
    Test function load_list_of_tasks

    Covers

    setup_for_task_run
    """
    pass



# Generated at 2022-06-11 10:10:21.111974
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass



# Generated at 2022-06-11 10:10:22.283262
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Note: task_loader_test.py has a full test of this, this just exercises the most important parts.
    pass

# Generated at 2022-06-11 10:10:22.843272
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass


# Generated at 2022-06-11 10:10:35.237886
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    play = mock.MagicMock()
    block = mock.MagicMock()
    role = mock.MagicMock()
    task_include = mock.MagicMock()
    variable_manager = mock.MagicMock()
    loader = mock.MagicMock()
    use_handlers = False
    result = load_list_of_tasks([{'include': 'role'}], play, block, role, task_include, use_handlers, variable_manager, loader)
    assert len(result) == 1
    assert isinstance(result[0], IncludeRole)


# Generated at 2022-06-11 10:10:47.459558
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    mock_play = MagicMock()
    mock_play._entries = []
    mock_play.tasks = []

    # Test case where ds is a list but role definition is bad
    ds = ['str', {'name': 'role1', 'list': ['task1']}]
    variable_manager = MagicMock()
    variable_manager.get_vars.return_value = {}
    loader = DictDataLoader({})
    collection_search_list = ['ns1.collection1']
    with pytest.raises(AnsibleAssertionError) as excinfo:
        load_list_of_roles(ds, mock_play, variable_manager=variable_manager, loader=loader, collection_search_list=collection_search_list)

# Generated at 2022-06-11 10:10:53.092969
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    unit test for load_list_of_roles
    '''
    play = {}
    current_role_path = 'path/to/role'
    variable_manager = {}
    loader = {}
    collection_search_list = {}
    # Prepare the ds list
    ds = [{'name': 'test1'}, {'name': 'test2', 'foo': 'bar'}]

    return load_list_of_roles(ds, play, current_role_path, variable_manager, loader, collection_search_list)

# Generated at 2022-06-11 10:11:06.325435
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks(ds=[{'name':"test"}], play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None) == [
        {'name': "test"}
    ]
    assert load_list_of_tasks(ds=["test"], play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None) == [
        "test"
    ]
    # assert assert_raises(AnsibleAssertionError, load_list_of_tasks, ds=None, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)


# Generated at 2022-06-11 10:11:54.454645
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO: not worth pushing into github right now
    pass

# Generated at 2022-06-11 10:11:58.860154
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Tests the load_list_of_tasks method for correctness.
    '''
    # TODO: write unit test
    pass
# Function: load_list_of_tasks

# Function: load_list_of_tasks

# Function: load_list_of_blocks

# Generated at 2022-06-11 10:12:09.572397
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/lib/ansible/inventory/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    options = PlaybookCLI(connection='local', module_path=None, forks=1, become=False, become_method=None, become_user=None, check=False, verbosity=1)

    play_context = PlayContext(play=Play())
   

# Generated at 2022-06-11 10:12:20.594935
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    play = {}
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader=None


# Generated at 2022-06-11 10:12:25.517436
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
	assert load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader) == result

if __name__ == '__main__':
	test_load_list_of_tasks()

# Generated at 2022-06-11 10:12:36.055747
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """Validating load_list_of_roles function"""
    test_loader = DictDataLoader({
        '/etc/ansible/roles/my_role/meta/main.yml': """
        ---
        dependencies:
          - { role: other_role }
          - { role: yet_another_role, some_parameter: foo }
        """,

        '/etc/ansible/roles/other_role/meta/main.yml': """
        ---
        dependencies:
          - { role: third_role }
        """
    })
    test_var_manager = VariableManager()

# Generated at 2022-06-11 10:12:46.080254
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    fname = './test_load_list_of_roles_role_definitions.yml'
    ds = [{'role': 'foo'}, {'name': 'bar', 'role': 'baz'}]
    play = Play()
    play.vars = {}
    role_defs = load_list_of_roles(ds, play)
    assert 2 == len(role_defs)
    assert 2 == len(play._role_handlers)

# Generated at 2022-06-11 10:12:57.466158
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.plugins import module_loader

    def _module(name):
        return module_loader._find_plugin(name)

    def _task_from_ds(ds):
        return load_list_of_tasks(ds, mock.Mock())[0]

    with mock.patch.dict(module_loader._module_cache, {'copy': _module('copy')}):
        assert _task_from_ds({'copy': 'src=x dest=y'}).action == 'copy'
        assert _task_from_ds({'copy': 'src: x dest: y'}).action == 'copy'
        assert _task_from_ds({'copy': 'src: x dest: y'}).action == 'copy'

# Generated at 2022-06-11 10:12:58.366984
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:13:07.918012
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    block = None
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    play = Play.load(dict(name='test'), loader=loader, variable_manager=variable_manager, use_handlers=True)

    task1 = {
        'name': 'first task',
        'debug': 'msg={{ "hi" }}'
    }
    task2 = {
        'name': 'second task',
        'command': 'echo {{ "hi" }}'
    }
    task3 = {
        'name': 'third task',
        'include': '{{ "tasks/test.yml" }}'
    }
    task4 = {
        'name': 'fourth task',
        'import_role': '{{ "test" }}'
    }

# Generated at 2022-06-11 10:14:10.483154
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    host_list = [
        'test_host',
        'test_host2',
        'test_host3',
        'localhost',
    ]

    inventory_manager = InventoryManager(loader=None, sources=host_list)

    variable_manager = VariableManager(loader=None, inventory=inventory_manager)

    ds = []
    for i in host_list:
        data = [
            {
                'hosts': i,
                'tasks': [
                    {
                        'name': 'test_task',
                        'debug': 'var={{ test_var }}',
                    },
                ],
            },
        ]
        ds.extend(data)

    task_list = load_list_of_

# Generated at 2022-06-11 10:14:17.908298
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayObj
    from ansible.playbook.role import Role
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])

# Generated at 2022-06-11 10:14:18.542464
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True

# Generated at 2022-06-11 10:14:27.515935
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    variable_manager = VariableManager()
    target_host = Host('127.0.0.1')
    loader.set_basedir('tests/lib/ansible')
    inventory= InventoryManager(loader=loader, sources='tests/lib/ansible/inventory/inventory_dev')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 10:14:37.941105
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    variable_manager.options_vars = {'baz': 'quux'}
    loader = DataLoader()
    block_ds = {'block': 'test'}
    play = Play().load(ds=block_ds, variable_manager=variable_manager, loader=loader)
    result = load_list_of_blocks(block_ds, play, parent_block=None,
                                role=None, task_include=None, use_handlers=False,
                                variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-11 10:14:51.089504
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-11 10:14:56.757236
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # This is a stub unit test. It's not actually testing anything. But it will give
    # you a 100% test coverage by running python -m pytest -v
    assert load_list_of_tasks([{'block': True}], 'play')
    assert load_list_of_tasks([{'include': 'x'}], 'play')
    assert load_list_of_tasks([{'name': 'x'}], 'play')


# Generated at 2022-06-11 10:14:59.501445
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{'name': 'some task'}, {'block': ['some block']}]
    assert load_list_of_tasks(ds, None) == ds



# Generated at 2022-06-11 10:15:13.659220
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    display = Display()
    loader = DataLoader()
    playbooks = ['./test/unit/fixtures/playbook_tests/new_playbook_syntax/load_list_of_blocks.yml']

    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 10:15:15.231116
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert True


# *****************************************************



# Generated at 2022-06-11 10:15:57.287546
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    # TODO
    pass

# Generated at 2022-06-11 10:16:07.922124
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    import ansible.playbook
    import ansible.inventory.host
    import ansible.vars.manager
    import ansible.parsing.dataloader
    import ansible.playbook.play

    myhost = ansible.inventory.host.Host(name="myhost")
    variable_manager = ansible.vars.manager.VariableManager()
    loader = ansible.parsing.dataloader.DataLoader()
    play_context = ansible

# Generated at 2022-06-11 10:16:09.922470
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # test that the right types of objects are returned.
    assert False


# Generated at 2022-06-11 10:16:20.610265
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.errors import AnsibleError

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    context = PlayContext()
    context._variable_manager=variable_manager

# Generated at 2022-06-11 10:16:27.598339
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from units.mock.loader import DictDataLoader

    # Test when ds is not a list
    for d in [None, 0, 'a', {}, ()]:
        with pytest.raises(AnsibleAssertionError):
            load_list_of_roles(d, play=None)

    # Test when play is not a Play object
    for d in [None, 0, 'a', {}, ()]:
        with pytest.raises(AnsibleAssertionError):
            load_list_of_roles([{}], play=d)

    # Test when role_def is not a dict

# Generated at 2022-06-11 10:16:34.571173
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    ds = [{'action': {'module': 'test_module'}}]

    task_list = load_list_of_tasks(ds, play=Play(), block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    task = task_list[0]
    assert isinstance(task, Task)
    assert task.action == 'test_module'

# Generated at 2022-06-11 10:16:41.136312
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
# load_list_of_tasks(ds, play, block=none, role=none, task_include=none, use_handlers=false, variable_manager=none, loader=none)
    passed = True
    try:
        testVal = load_list_of_tasks([1])
    except AnsibleAssertionError as e:
        passed = True
    assert passed
    if __name__ == '__main__':
        test_load_list_of_tasks()

# Generated at 2022-06-11 10:16:51.582650
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    A Playbook() has a list of roles.
    '''
    # we import here to prevent a circular dependency with imports
    #from ansible.playbook.play import Play
    #from ansible.playbook.role import Role
    #from ansible.playbook.role_include import IncludeRole
    #from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    #for a in C._ACTION_INCLUDE_TASKS:
    #    for b in C._ACTION_ALL_PROPER_INCLUDE_IMPORT_ROLES:
    #        print(a)
    #        print(b)
    roles = [
        'foo',
        'bar'
    ]
    print(roles)
    #print(Play()._

# Generated at 2022-06-11 10:17:03.031932
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Tests for function:
      load_list_of_tasks

    all non-vars things should be in fixtures
    '''
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # this is used to create a fake plugin loader class
    # that always returns the same module, in this case, the
    # return value of the get_connection function
    class FakePluginLoader():
        def get(self, module_name, class_only=False):
            return get_connection

    # since we always return the same connection,
    # this is it, and it returns a bunch of "unknown"
    # attributes, but they're not needed
    def get_connection():
        class FakeConnection():
            def __init__(self):
                self.shell = None


# Generated at 2022-06-11 10:17:11.956558
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible
    from ansible.errors import AnsibleAssertionError
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import Include
    from ansible.template import Templar

    mapping = dict(name='test_block', connection='local', hosts='all')
    block = Block.load({'tasks': [dict(action=dict(module='test_mod', args={'message': 'foo'}))]},
                       play=Play().load(mapping, [], templar=Templar(), loader=None),
                       loader=None, variable_manager=None)
    assert block.block[0].name == 'tasks'