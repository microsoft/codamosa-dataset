

# Generated at 2022-06-11 10:08:21.644606
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    # Note: Task Include is not being tested here. Task Include is being tested separately.
    # Note: Include Role is not being tested here. Include Role is being tested separately.
    # Note: Handler is not being tested here. Handler is being tested separately.


# Generated at 2022-06-11 10:08:33.422982
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert_raises(AnsibleAssertionError, load_list_of_tasks, '', '')
    assert_raises(AnsibleAssertionError, load_list_of_tasks, [''], '')
    assert_raises(AnsibleAssertionError, load_list_of_tasks, [{'': ''}], '')
    assert load_list_of_tasks([{'block': ''}], '')
    assert load_list_of_tasks([{'include': ''}], '')
    assert load_list_of_tasks([{'include_role': ''}], '')
    assert load_list_of_tasks([{'import_role': ''}], '')

# Generated at 2022-06-11 10:08:42.154554
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.connection.local import Connection
    from ansible.vars import VariableManager
    module_utils_path = os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'module_utils')
    handler_path = os.path.join(module_utils_path, 'handlers')
    distribution_path = os.path.join(module_utils_path, 'distribution')
    system_path = os.path.join(module_utils_path, 'system')

# Generated at 2022-06-11 10:08:53.685813
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    module_utils_loader = AnsibleModuleUtilsLoader()
    config_loader = AnsibleConfig()
    fact_cache = FactCache(config_loader)

# Generated at 2022-06-11 10:09:05.458551
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # NOTE: not a unit test, but a test of functionality
    # ansible.playbook._load.load_list_of_tasks.test_load_list_of_tasks()
    collections = {}
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=loader, host_list='/dev/null'))

    class obj(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    task = obj()
    task2 = obj()
    task3 = obj()
    role = obj()


# Generated at 2022-06-11 10:09:16.368111
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    host_list = [
            {
                'hostname': 'localhost',
                'ip': '127.0.0.1',
                'port': 22,
                'group': 'test',
                'username': 'test',
                'password': 'test',
                'private_key_file': '/root/.ssh/id_rsa',
                'become': True,
                'become_method': 'sudo',
                'become_user': 'root',
                'vars': {'var1': 'test'}
            }
        ]
    host_list = load_list_of_hosts(host_list)


# Generated at 2022-06-11 10:09:28.276103
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{'action': 'debug'}, {'action': 'debug'}]
    assert len(load_list_of_tasks(ds, None, None, None, None, None, None, None)) == 2

    ds = [{'action': 'include'}]
    assert len(load_list_of_tasks(ds, None, None, None, None, None, None, None)) == 1

    ds = [{'action': 'include', 'loop': '1'}]
    with pytest.raises(AnsibleUndefinedVariable):
        assert len(load_list_of_tasks(ds, None, None, None, None, None, None, None)) == 1

    ds = [{'action': 'include_tasks'}]

# Generated at 2022-06-11 10:09:35.678984
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    loader = DictDataLoader({
        "/etc/ansible/roles/foo/tasks/main.yml": """
        - name: Test1
          action: module args=value
        - name: Test2
          include: bar.yml
        """
    })

    variable_manager = VariableManager()

    ds = [
        {'block': [
            {'action': "module", 'args': "value"},
            {'include': "bar.yml"}
        ]}
    ]


# Generated at 2022-06-11 10:09:46.632268
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import role_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader

    class Foo():
        loader = DataLoader()
        variable_manager = VariableManager()
        variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager))
        variable_manager.set_variable_manager(variable_manager)

# Generated at 2022-06-11 10:09:56.299258
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.playbook.play
    import ansible.playbook.block

    def _play(play_name='play1', play_ds=None):
        if play_ds is None:
            play_ds = {}
        play_ds['name'] = play_name
        return ansible.playbook.play.Play().load(play_ds=play_ds)

    def _block(play_name='play1', block_name='block1', block_ds=None, parent_block=None, role=None, task_include=None, use_handlers=False):
        if block_ds is None:
            block_ds = {}
        block_ds['block'] = block_name

# Generated at 2022-06-11 10:10:21.923637
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    test_play_ds = dict(
        name="play1",
        hosts="testhost",
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='Hello World')))
        ]
    )

    manager = Playbook._load_playbook_data(test_play_ds)
    play = manager.get_plays()[0]
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    ds = test_play_ds['tasks']

    print(ds)


# Generated at 2022-06-11 10:10:33.746719
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks(ds=[]) == []
    assert load_list_of_tasks(ds=[{'block': 'block'}]) == []
    assert load_list_of_tasks(ds=[{'block': 'block'}, {'block': 'block'}]) == []
    assert load_list_of_tasks(ds=[{'block': 'block'}, {'block': 'block'}, {'block': 'block'}]) == []
    assert load_list_of_tasks(ds=[{'do_something': 'action'}]) == []
    assert load_list_of_tasks(ds=[{'do_something': 'action'}, {'do_something': 'action'}]) == []

# Generated at 2022-06-11 10:10:46.062064
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import IncludeRole

    task_list=[]

    ds1 = dict(
        action=dict(
            module='shell',
            args='/bin/false',
        ),
    )

    ds2 = dict(
        block=dict(
            tasks=[
                dict(
                    action=dict(
                        module='shell',
                        args="echo 'Hello World!'",
                    ),
                ),
            ],
            rescue=None,
            always=None,
        ),
    )

    # Create task object for a action and a block


# Generated at 2022-06-11 10:10:54.169775
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # noinspection PyPackageRequirements
    import pytest

    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.path import unfrackpath

    from ansible_collections.ansible.builtin import unittest_runner

    add_all_plugin_dirs()
    loader = AnsibleCollectionLoader()
    unittest_collection = loader.load_collection(unittest_runner.collection_name)
    units_under_test_path = unfrackpath(
        os.path.dirname(unittest_collection._get_file_path('lib/ansible/playbook/role/__init__.py'))
    )


# Generated at 2022-06-11 10:11:07.104014
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
  # test case 1:
  ds =[{'block': 'block', 'set_fact': {'lala': 'lala'}}, {'action': 'include', 'args': {'_raw_params': 'test.yml'}}]
  play = {'hosts': 'all', 'name': 'base'}
  block = None
  role = None
  task_include = None
  use_handlers = False
  variable_manager = {}
  loader = {}

  # expect to get a list of 2 elements
  result = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
  #assert(len(result), 2)
  print('load_list_of_tasks passed')



# Generated at 2022-06-11 10:11:15.821116
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = [
        {'action_test': 'echo "Zoey"',},
        {'block':{'name':"Zoey",'tasks':[
        {'action_test': 'echo "Zoey"',},]}},
        {'handler_test': 'echo "Zoey"',},
        {'block_name':'Zoey', 'block':{'tasks':[
        {'action_test': 'echo "Zoey"',},]}},
        {'action': 'include_tasks', 'args': {'_raw_params': 'tasks/main.yml'}},
        {'include_role': {'name': 'logstash', 'tasks_from': 'main.yml', 'vars': {'var': 'var'}}},
    ]



# Generated at 2022-06-11 10:11:26.878108
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Tests against function ``load_list_of_roles``
    """
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.role.include import RoleInclude
    from ansible.utils.vars import combine_vars
    play = Play().load({
        'name': 'my play',
        'hosts': 'localhost',
        'gather_facts': 'no',
        'roles': ['foo', 'bar', 'baz']
    }, variable_manager=combine_vars(loader=None, inventory=Inventory(Loader())))

    # test against ds with list element containing a role definition that has neither a name or a role

# Generated at 2022-06-11 10:11:38.838804
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:11:39.328039
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass



# Generated at 2022-06-11 10:11:42.676785
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    1.
    Tasks need to be in a list.
    task_ds is a list.
    '''

    return True


# Generated at 2022-06-11 10:12:02.564145
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO:
    #   test all action_types
    #   test handlers

    loader = DataLoader()

    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list=[]))


# Generated at 2022-06-11 10:12:12.170370
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
            dict(
                block=dict(
                    name='block ds 1',
                    tasks=[
                        dict(
                            name='task ds 1',
                            foo='bar'
                        )
                    ]
                )
            ),
            dict(
                block=dict(
                    name='block ds 2',
                    tasks=[
                        dict(
                            name='task ds 2',
                            foo='bar'
                        )
                    ]
                )
            ),
            dict(
                block=dict(
                    name='block ds 3',
                    tasks=[
                        dict(
                            name='task ds 3',
                            foo='bar'
                        )
                    ]
                )
            ),
            dict(
                name='task ds 4',
                foo='bar'
            ),
        ]


# Generated at 2022-06-11 10:12:23.875250
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    def task_loader(ds, block, role, task_include, loader, use_handlers):
        '''
        Load a list of tasks, given a datastructure that has been parsed from YAML.
        This enforces some common options for loading the tasks, common to both
        playbooks and task includes.
        '''
        if not isinstance(ds, list):
            raise AnsibleParserError("'tasks' is not defined as a list", obj=ds)
        return load_list_of_tasks(ds, block=block, role=role, task_include=task_include, loader=loader, use_handlers=use_handlers)

    # assert examples for load_list_of_tasks

# Generated at 2022-06-11 10:12:35.300336
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Function load_list_of_tasks is a unit test
    :return:
    '''
    ds = 'When a function starts with test_, nose discovers it and executes it as a test case'
    #ds=[]
    ds=['When a function starts with test_, nose discovers it and executes it as a test case']
    play=['When a function starts with test_, nose discovers it and executes it as a test case']
    block=['When a function starts with test_, nose discovers it and executes it as a test case']
    role=['When a function starts with test_, nose discovers it and executes it as a test case']
    task_include=['When a function starts with test_, nose discovers it and executes it as a test case']

# Generated at 2022-06-11 10:12:44.828372
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager


# Generated at 2022-06-11 10:12:56.248739
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    display.display("Loading list of tasks")

    # Setup data sets
    play_ds = dict()
    block_ds = dict()
    block_ds["block"] = dict()
    block_ds["block"][0] = dict()
    block_ds["block"][0]["block"] = dict()
    block_ds["block"][0]["block"][0] = dict()
    block_ds["block"][0]["block"][0]["name"] = "test"
    block_ds["block"][0]["block"][0]["block"] = dict()
    block_ds["block"][0]["block"][0]["block"][0] = dict()
    block_ds["block"][0]["block"][0]["block"][0]["name"] = "test2"


# Generated at 2022-06-11 10:13:06.629662
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    ds = [{},{},{}]
    play = Play()
    block = Block.load(ds, parent_block=None, task_include=None)
    role = Role()

# Generated at 2022-06-11 10:13:14.564505
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.role_include import IncludeRole
    assert load_list_of_tasks([{'block': {'block': 'dummy', 'tasks': []}}])[0]._parent
    assert load_list_of_tasks([{'include': 'dummy', 'static': True}])[0].statically_loaded
    assert load_list_of_tasks([{'include_role': 'dummy', 'static': True}])[0].statically_loaded
    assert load_list_of_tasks([{'include_role': 'dummy', 'static': False}])[0].is_static



# Generated at 2022-06-11 10:13:25.290051
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    ds = [
        {'name': 'task1'},
        {'name': 'task2'},
        {'block': {'name': 'block1',
                   'block': [{'name': 'task3'}]}}
    ]
    play = MagicMock()
    block = MagicMock()
    role = MagicMock()
    task_include = MagicMock()
    use_handlers = True
    variable_manager = MagicMock()
    loader = MagicMock()
    task_list = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert isinstance(task_list[0], Task)

# Generated at 2022-06-11 10:13:26.728582
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO: Implement unit test for code
    assert True == True



# Generated at 2022-06-11 10:14:01.834743
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:14:03.615089
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Tested in test_playbook/test_play_ds_include.py
    pass



# Generated at 2022-06-11 10:14:12.349723
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import IncludeRole

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.loader.loader import DataLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Play
    from ansible.plugins.loader import action_loader, cache_loader, callback_loader, connection_loader

# Generated at 2022-06-11 10:14:19.130797
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = {'block': 'raw2', 'hosts': 'host_list', 'tasks': [
        {'name': 'Get OS Type', 'action': 'set_fact', 'args': {'ansible_os_family': '{{ ansible_distribution }}'}}]}
    ds = [task_ds]
    play = Play()
    print(load_list_of_tasks(ds, play))
    # Output: [<ansible.playbook.task.Task object at 0x7f2a2d72b828>]

# if __name__ = '__main__':
#     test_load_list_of_tasks()
#     print('Test load_list_of_tasks Successful')
##########################################################################
#
# MODULE DOCSTRING
#
##########################################################################



# Generated at 2022-06-11 10:14:21.843747
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    display.warning('This is a test warning')
    raise AnsibleUndefinedVariable('This is a test error')
    assert False
    # FIXME: write unit tests for load_list_of_tasks

# Generated at 2022-06-11 10:14:30.852150
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{ "name": "Test", "include": "Hello" }]
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    role = None
    task_include = TaskInclude()
    use_handlers = False
    task_list = load_list_of_tasks(ds, play, role=role, task_include=task_include, use_handlers=use_handlers, variable_manager=variable_manager, loader=loader)
    print("task:")
    print(task_list[0].name)
    print("role:")
    print(task_list[0]._role)
    assert task_list[0].name == "Test"
    assert task_list[0]._role is None



# Generated at 2022-06-11 10:14:42.209559
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        import __main__ as main
    except ImportError:
        main = {}

    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-11 10:14:43.852514
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO: implement and test this function
    pass



# Generated at 2022-06-11 10:14:55.796509
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import sys
    import os
    import shutil
    sys.path.insert(0,"..")
    #setup_module(self)
    #setup()
    #setUpModule()
    #setUp()

    # Setup test directory
    test_dir = '/tmp/ansible-test-structure/playbook'
    # remove old test directory if exists
    if os.path.exists(test_dir):
        shutil.rmtree(test_dir)
    # create new test directory
    os.makedirs(test_dir)

    # Setup test files

# Generated at 2022-06-11 10:15:09.072584
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    loader = DataLoader()
    include_paths = ':'.join(ANSIBLE_LIB_PATH)
    role_paths = ':'.join(ANSIBLE_TEST_DATA_ROLE_PATHS)
    collections_paths = ':'.join(COLLECTIONS_PATHS)
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create an empty playbook
    play_ds = dict(
        hosts='all',
        gather_facts='no',
        any_errors_fatal=True,
        roles=[],
    )
    play = Play().load(play_ds, variable_manager=variable_manager, loader=loader)
    play._invalidate_hosts()

    # create a task that includes another task
   

# Generated at 2022-06-11 10:16:04.153067
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Arrange
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    ds = [{'block': 'roles'}]
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None

    # Act
    result = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)

    # Assert
    assert isinstance(result[0], Block)
    assert result[0].block == 'roles'
    assert result[0].statically_loaded is True

    # Arrange
    ds = [{'debug': 'msg=hi'}]
    play = None
    block

# Generated at 2022-06-11 10:16:16.193325
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test 1.
    ds = {
        'block': [
            {
                'block': [
                    {'rescue': []},
                    {'ignore_errors': 'yes'},
                ],
                'always': [],
                'name': 'foo',
            },
            {
                'block': [
                    {'rescue': []},
                    {'ignore_errors': 'yes'},
                ],
                'always': [],
                'name': 'foo',
            },
        ],
    }

    # Test 2.

# Generated at 2022-06-11 10:16:23.587113
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()


# Generated at 2022-06-11 10:16:32.943165
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task

    ds = [
        {'name': 'test 1'},
        {'name': 'test 2', 'block': []},
        {'name': 'test 3', 'block': []},
        {'name': 'test 4'},
    ]
    results = load_list_of_tasks(ds, None, Block(), None)
    assert len(results) == 4
    assert isinstance(results[0], Task)
    assert isinstance(results[1], Block)
    assert isinstance(results[2], Block)
    assert isinstance(results[3], Task)

# Generated at 2022-06-11 10:16:43.056707
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole

    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

    from ansible.vars.manager import VariableManager

    display.verbosity = 3

    inventory_

# Generated at 2022-06-11 10:16:47.829224
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    
    res=load_list_of_tasks([
        {'name': 'task3'},
        {'include': 't1', 'static': True},
        {'block':[
            {'name': 'task1'},
            {'name': 'task2'}
        ]}
    ])
    print(res)

test_load_list_of_tasks()


# Generated at 2022-06-11 10:17:00.724199
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import os
    import tempfile
    from ansible.cli import CLI

    cli = CLI(args=['--vault-password-file=/tmp/doesnotexist'])
    display = Display()
    options = cli.parse()

    inventory = Inventory(loader=CLI.setup_inventory_loader(options, cli.parser), variable_manager=VariableManager())

    # the file we will use for the test
    fd, path = tempfile.mkstemp()
    fh = os.fdopen(fd, 'w')

    # some tasks that we will use in the list
    task1 = {'action': 'setup', 'register': 'result'}
    task2 = {'include': 'somefile.yml'}

# Generated at 2022-06-11 10:17:09.705496
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Load modules
    module_loader = C.get_config(C.p, C.DEFAULTS, 'DEFAULT_MODULE_PATH', '', value_type='list')
    module_loader.extend(C.get_config(C.p, C.DEFAULTS, 'LIBRARY', '', value_type='list'))

    # Load plugins
    plugin_loader = PluginLoader(C.get_config(C.p, C.DEFAULTS, 'DEFAULT_INVENTORY_PLUGINS', '', value_type='list'),
                                 os.path.dirname(__file__), '', 'inventory')

# Generated at 2022-06-11 10:17:18.204593
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.task_include

    play1 = ansible.playbook.play.Play()
    play1.vars = 'test1'
    task1 = ansible.playbook.task.Task()
    task1.vars = 'test2'
    task2 = ansible.playbook.task_include.TaskInclude()
    task2.vars = 'test3'
    task3 = ansible.playbook.task.Task()
    task3.vars = 'test4'

    block1 = [task1, task2, task3]
    block2 = [task1, task2, task3]
    block1_task = ansible.playbook.task.Task()

# Generated at 2022-06-11 10:17:28.047809
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    def check_load_list_of_tasks(tasks, expected_task_list):
        # To check the result of load_list_of_tasks,
        # check that the task list contains the expected tasks.
        # Return value of load_list_of_tasks is always an object list.

        # Loop through all tasks in the expected task list and
        # check if the task is found in the actual task list
        # (return value of load_list_of_tasks()).
        # If the task is not found in the actual task list,
        # assert a False value and the name of the expected task.
        for task in expected_task_list:
            if task not in [t.get_name() for t in tasks]:
                assert False, "Expected task %s not found in actual task list" % task

    # Test