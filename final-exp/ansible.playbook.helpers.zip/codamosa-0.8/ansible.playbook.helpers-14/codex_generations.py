

# Generated at 2022-06-11 10:07:59.404567
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert False, "FIXME"


# Generated at 2022-06-11 10:08:00.140641
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:08:08.825911
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Returns a fake var manager
    '''
    def get_var_manager():
        class fake_var_manager:
            '''
            Fake var manager
            '''
            def get_vars(self, play, task):
                return {}
        return fake_var_manager()
    var_manager = get_var_manager()
    # Test simple load
    ds = [
        {
            'meta': 'meta',
            'action': 'action',
            'local_action': 'local_action',
            'loop_control': 'loop_control',
            'tags': 'tags',
            'when': 'when',
            'register': 'register'
        }
    ]

# Generated at 2022-06-11 10:08:10.566861
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert False, "TODO: Write me"



# Generated at 2022-06-11 10:08:23.405181
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
	from ansible.playbook.play import Play
	from ansible.playbook.role_include import IncludeRole
	from ansible.playbook.task import Task
	from ansible.playbook.task_include import TaskInclude

	block = Play()
	tasks = [{'action':'shell', 'module':'echo'}, {'action': 'include', 'module':'test'}]

	ass = load_list_of_tasks(tasks, block)
	assert len(ass) == 2
	assert isinstance(ass[0], Task)
	assert isinstance(ass[1], TaskInclude)

	tasks = [{'action':'shell', 'module':'echo'}, {'action': 'include_role', 'module':'test'}]


# Generated at 2022-06-11 10:08:24.115597
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:08:35.016482
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Initialize
    test_ds = [{'include_role': {'name': 'foo'}}, {'include_tasks': 'bar.yml'}]
    test_play = 'test'
    test_block = 'test'
    test_role = 'test'
    test_task_include = 'test'
    test_use_handlers = True
    test_variable_manager = 'test'
    test_loader = 'test'

    # Call function
    result = load_list_of_tasks(test_ds, test_play, test_block, test_role, test_task_include, test_use_handlers, test_variable_manager, test_loader)
    # TODO: need assert



# Generated at 2022-06-11 10:08:35.726947
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:08:39.393548
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    result = load_list_of_tasks([{}, {'block': [{}]}], 'test_play', block='test_block', role='test_role', task_include='test_task_include', use_handlers='test_use_handlers')
    assert isinstance(result, list)

# Generated at 2022-06-11 10:08:40.066711
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:09:06.119259
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role import Role
    
    path = 'test_data/'
    loader = DataLoader()
    role_path = 'test_data/roles/test_role/'
    role = Role.load(role_path, loader)
    variable_manager = VariableManager(loader=loader, inventory=None)
    variable_manager._extra_vars = {'role_path': role_path}
    templar = Templar(loader=loader, variables=variable_manager)
    
    # Test 1
    # Test with a list of task datastructures with all the tags

# Generated at 2022-06-11 10:09:17.948775
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Create a custom role for testing
    role = CustomRole("TestRole")

    test_task = Task("test_task", 1)
    test_task.block = load_list_of_blocks([
        {
            "include": "file.yml",
            "_line_number": 1
        }
    ], play=1, parent_block=1, role=role, task_include=1, use_handlers=False, variable_manager=1, loader=1)

# Generated at 2022-06-11 10:09:20.605885
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """
    Tests for function load_list_of_tasks.
    """
    # FIXME: Add tests
    pass

# Generated at 2022-06-11 10:09:31.335224
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    class TestCallbackModule(CallbackBase):
        def __init__(self, *args, **kwargs):
            super(TestCallbackModule, self).__init__(*args, **kwargs)
            self.events = []


# Generated at 2022-06-11 10:09:40.193864
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.loader import collection_loader
    myCollections = collection_loader.all(collections_paths=['/tmp/ansible_collections/'])
    roles = load_list_of_roles(
        [{
            u'role': u'ceph-ansible.ceph-osd',
            u'collection': u'ceph-ansible',
        }],
        None,
        current_role_path=None,
        variable_manager=None,
        loader=None,
        collection_search_list=myCollections
    )
    assert len(roles) == 1
    assert isinstance(roles[0], RoleInclude)

# Generated at 2022-06-11 10:09:50.888998
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import copy
    options = cli.action_parse(['playbook.py', '--connection=local',
                           '--inventory-file', 'hosts',
                           '--extra-vars', 'version=1.23.45'])
    options.tags = ['all']
    options.skip_tags = ['never']
    options.listhosts = None
    options.syntax = None
    options.ask_pass = None
    options.module_path = None
    options.forks = 5
    options.private_key_file = None
    options.ssh_common_args = None
    options.ssh_extra_args = None
    options.sftp_extra_args = None
    options.scp_extra_args = None
    options.become = None
    options.become_method = None


# Generated at 2022-06-11 10:09:55.023591
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_list = load_list_of_tasks([{'include': 'test'},{'include': 'test2'}])
    assert task_list[0].args['_raw_params'] == 'test'
    assert task_list[1].args['_raw_params'] == 'test2'

# Generated at 2022-06-11 10:10:02.128797
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    # TASKS
    # TASKS BLOCK
    # HANDLERS
    # HANDLERS BLOCK
    # STATIC INCLUDE
    # DYNAMIC INCLUDE
    # TEMPLATED INCLUDE
    # INCLUDED TASKS
    # STATIC IMPORT_TASKS
    # STATIC IMPORT_ROLE
    # DYNAMIC IMPORT_ROLE
    # TEMPLATED IMPORT_ROLE
    # INCLUDED ROLE
    pass

# Generated at 2022-06-11 10:10:16.189723
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar


# Generated at 2022-06-11 10:10:25.527886
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    test_play_context = PlayContext()
    test_play = Play().load(name="test_play", play_context=PlayContext(), variable_manager=VariableManager(), loader=None)
    test_block = None
    test_role = None
    test_task_include = None
    test_use_handlers = True
    test_variable_manager = VariableManager()
    test_loader = None

    ds = {}
    # test use_handlers is True
    ds["block"] = {}
    ds["block"]["tasks"] = []

# Generated at 2022-06-11 10:10:48.471491
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    loader = DataLoader()
    task_vars = dict()
    variable_manager = VariableManager(loader=loader, variables=task_vars)
    play = dict()
    role = dict()
    task_include = dict()
    use_handlers = False
    loader = dict()
    ds = dict()

    # try case without 'block'
    ds['action'] = dict()
    load_list_of_tasks(ds, play, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)

    # try case with 'block'
    ds['block'] = dict()
    load_list_of_tasks(ds, play, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)



# Generated at 2022-06-11 10:10:59.258703
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    yaml_data = """
    - hosts: localhost
      tasks:
      - name: test task
      - action: debug msg={{ item }}
        with_items:
        - "1"
        - "2"
      pre_tasks:
      - name: test pre task
      - name: test task 2
      - name: test task 3
      post_tasks:
      - name: test post task
    """

    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-11 10:11:07.869960
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    def fake_task(self, ds):
        self.action = ds['action']

    # monkey patch Task to load
    Task.load = fake_task

    ds = [{'action': 'one'}, {'action': 'two'}]
    tl = load_list_of_tasks(ds, None, None, None, None, False, None, None)
    assert len(tl) == 2
    assert tl[0].action == 'one'
    assert tl[1].action == 'two'



# Generated at 2022-06-11 10:11:11.608416
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    list_of_tasks = load_list_of_tasks([{'name': 'test', 'action': 'test1'}])
    assert isinstance(list_of_tasks[0], Task)
    assert list_of_tasks[0].action == 'test1'


# Generated at 2022-06-11 10:11:17.546954
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole

    ds = dict(shell="echo hello")

    task_list = load_list_of_tasks(
        ds,
        play=None,
        block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=None,
        loader=None
    )

    assert isinstance(task_list, list)
    assert isinstance(task_list[0], Task)


# Generated at 2022-06-11 10:11:28.427969
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # input data set

# Generated at 2022-06-11 10:11:40.330756
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    for action in C._ACTION_ALL_PROPER_INCLUDE_IMPORT_ROLES:
        # Test -1: Does IncludeRole.load return an object of type IncludeRole
        ds = {'include_role': 'the_role'}
        obj = IncludeRole.load(ds)
        assert isinstance(obj,IncludeRole)

        # Test -2: Does TaskInclude.load return an object of type TaskInclude
        ds = {'include_tasks': 'the_task'}
        obj = TaskInclude.load(ds)
        assert isinstance(obj,TaskInclude)

        # Test -3: Does Task

# Generated at 2022-06-11 10:11:40.966927
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass


# Generated at 2022-06-11 10:11:53.266705
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    block_ds = {
        "block": [
            {
                "with_items": [
                    "{{ groups[\"db\"] }}"
                ],
                "name": "add host to {{ item }} group",
                "block": [
                    {
                        "with_items": [
                            "{{ groups[\"db\"] }}"
                        ],
                        "name": "add host to {{ item }} group",
                        "block": [
                            {
                                "name": "test_task"
                            }
                        ]
                    }
                ]
            }
        ]
    }

# Generated at 2022-06-11 10:12:04.191869
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    from ansible.playbook.play import Play

    play_context = PlayContext()
    play_source = dict(
        name="Ansible Play 0",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'),
                 register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
    play

# Generated at 2022-06-11 10:12:33.428145
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
        ds = [
            {'name': 'test0'},
            {'name': 'test1'},
            {'name': 'test2'},
        ]
        task_list = load_list_of_tasks(ds, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
        print(task_list)
    '''
    ds = [
        {'name': 'test0'},
        {'name': 'test1'},
        {'name': 'test2'},
    ]

# Generated at 2022-06-11 10:12:41.148212
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    parser = ConfigParser.SafeConfigParser()
    parser.read(['/Users/moyan/Projects/env/ansible/ansible/lib/ansible/config.cfg', os.path.expanduser('/Users/moyan/Projects/env/ansible/ansible/ansible.cfg')])
    defaults = dict(parser.items('defaults'))
    C = SettingsLoader(defaults=defaults, use_config_file=False)
    module_loader = ModuleLoader()
    task_loader = TaskLoader(c=C)
    variable_manager = VariableManager()
    tasks_path = '/Users/moyan/Projects/env/ansible/ansible/lib/ansible/playbook/tasks'

# Generated at 2022-06-11 10:12:52.449049
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook import Playbook
    from ansible.template import Templar
    TASKS_YAML = """
    - include: thing1
    - include_tasks: thing2 static=true
    - name: thing3
      shell: echo {{ z }}
    - block:
        - name: thing4
          command: ls

    - name: thing5
      include_role:
        name: myrole
        static: false
    - name: thing6
      include_role:
        name: myrole
        static: true
    - import_role:
        name: myrole
    """

    #NOTE: We need to use the actual playbook parsing for this to work, since
    #      the code we want to test is actually inside the Playbook class.
    #     

# Generated at 2022-06-11 10:13:03.722772
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    fake_loader, playbook_path, inventory, variable_manager = TEST_UTIL_LOADER_PATH_INVENTORY_VARIABLES()
    task = {'action': 'shell', 'args': 'echo test'}
    task_list = load_list_of_tasks(task, "playbook", None, None, None, False, variable_manager, fake_loader)
    assert task_list[0].action == 'shell'
    assert task_list[0].args == 'echo test'
    # also test without setting the args
    task = {'action': 'shell'}
    task_list = load_list_of_tasks(task, "playbook", None, None, None, False, variable_manager, fake_loader)
    assert task_list[0].action == 'shell'
    assert task_list

# Generated at 2022-06-11 10:13:05.600163
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # noinspection PyUnresolvedReferences
    '''
    :return:
    '''

    raise NotImplementedError()

# Generated at 2022-06-11 10:13:15.247900
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.scripts.runme_ansible_playbook import CLI
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    pb = CLI(args=None)
    pb.base_parser = CLI.base_parser
    pb.options, args = pb.base_parser.parse_known_args()
    display.verbosity = pb.options.verbosity
    options, args = pb.parser.parse_args(args=[
        'playbook/play_file.yaml',
        '-i', 'playbook/inventory',
        '-vvvv'
    ])
    loader = DataLoader()

# Generated at 2022-06-11 10:13:25.985320
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:13:38.355509
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # import here to prevent circular imports
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.template import Templar
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # prep
    loader = DataLoader()
    variable_manager = VariableManager()
    # define some fake tasks
    t1 = dict(
        name='fake task',
        include='dummy.yml',
        when='{{ true }}',
        tags=['fake_tag'],
        delegate_to='localhost',
    )

# Generated at 2022-06-11 10:13:46.755003
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Tests whether basic role loading works
    """
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play import Play
    play = Play()
    loader = DictDataLoader({
        'roles/basic.role': """
        - name: basic
          tasks:
            - name: task1
            - name: task2
        """,
        'roles/nested/nested.role': """
        - name: nested
          tasks:
            - name: task1
            - name: task2
        """,
    })
    loader.set_basedir('/etc/ansible/roles')

# Generated at 2022-06-11 10:13:57.065289
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor import task_result
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in.
        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin.
        """

# Generated at 2022-06-11 10:14:41.178680
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    ds = [{'include': 'file', 'static': True}]
    task_list = load_list_of_tasks(ds, play=None)
    assert isinstance(task_list[0], TaskInclude)
    assert task_list[0].statically_loaded == True
    handler_list = load_list_of_tasks(ds, play=None, use_handlers=True)
    assert isinstance(handler_list[0], HandlerTaskInclude)
    assert handler_list[0].statically_loaded == True

# Generated at 2022-06-11 10:14:53.781537
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task.task_include import TaskInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    import ansible.constants as C
    import os

# Generated at 2022-06-11 10:14:54.625664
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert 1 == 1

# Generated at 2022-06-11 10:15:02.301541
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    test for loading a list of task ds
    '''
    from ansible.vars.unsafe_proxy import UnsafeProxy

    ds = [dict(action=UnsafeProxy({'module': 'debug', 'args':{'msg': 'your message here'}}))]
    print("ds=%s" % ds)
    print("load_list_of_tasks: %s" % load_list_of_tasks(ds, None, None))



# Generated at 2022-06-11 10:15:02.726508
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass


# Generated at 2022-06-11 10:15:17.233184
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.basic import AnsibleModule
    from ansible.inventory.manager import InventoryManager
    
    loader = DataLoader()
    variable_manager = VariableManager()
    # Set the inventory
    inventory = InventoryManager(loader=loader, sources=['/home/centos/ansible-project/conf/example-static-inventory'])
    variable_manager.set_inventory(inventory)

    context = PlayContext()
    connection_plugin

# Generated at 2022-06-11 10:15:18.124491
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:15:26.143405
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    test_load_list_of_tasks 
    '''
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader
    from ansible.config.manager import ConfigManager
    from ansible.utils.display import Display
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    display = Display()
    config_manager = ConfigManager()
    config_manager.add_config_file('ansible.cfg')
    play = Play.load({}, loader=DataLoader(), variable_manager=VariableManager(), config_manager=config_manager, display=display)
    role = Role()
    task_list = load

# Generated at 2022-06-11 10:15:29.095606
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass
# Integrations test for function load_list_of_tasks

# Generated at 2022-06-11 10:15:40.927721
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import load_extra_vars
    from ansible.executor.playbook_executor import PlaybookExecutor
    args = dict(
        playbook='/home/src/ansible/lib/ansible/playbooks/assign_user_roles.yml',
        extra_vars=dict(
            app_users='ansible',
            user_roles='deployer',
        )
    )
    loader = DataLoader()

# Generated at 2022-06-11 10:16:17.947072
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import os 

    from ansible import context
    from ansible.cli.playbook import PlaybookCLI
    from ansible.cli import CLI
    from ansible.errors import AnsibleOptionsError, AnsibleError
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.callback.default import CallbackModule
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)


# Generated at 2022-06-11 10:16:25.172641
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # setup test case
    ds = [
        {
            'action': { 'module': 'ping', 'args': {} }
        },
        {
            'action': { 'module': 'command', 'args': { '_raw_params': 'ls' } }
        }
    ]
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None

    # check results
    assert load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)

# Generated at 2022-06-11 10:16:35.235733
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Prepare
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    import ansible.constants as C
    import tempfile
    import os
    import json

    display = Display()
    results_callback = ResultCallback()
    loader = DataLoader()
    variables = VariableManager()

# Generated at 2022-06-11 10:16:45.463768
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # with open('/Users/yangjie/Projects/ansible-big-data/bigdata-collection-ansible/test_data/test_load_list_of_tasks.yml', 'r') as f:
    #     ds = yaml.load(f)
    # Load test data from test_data/test_load_list_of_tasks_data.yml
    test_data = load_data_file("test_load_list_of_tasks.yml")
    ds = test_data['ds']
    play = test_data['play']
    block = test_data['block']
    role = test_data['role']
    task_include = test_data['task_include']
    use_handlers = test_data['use_handlers']
    variable_manager = test_

# Generated at 2022-06-11 10:16:49.639300
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    This method is used to unit test the class method load_list_of_roles.
    :return: 
    '''

# Generated at 2022-06-11 10:17:01.773041
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager

    my_task = Task()
    my_task.action = 'include'
    my_task.args['_raw_params'] = 'some/path.yml'
    my_task.module_args = '/tmp'
    my_task.args['some'] = 'some'

    my_include = TaskInclude()
    my_include.block = 3
    my_include.action = 'include'
    my_include.args['_raw_params'] = 'some/path.yml'
    my_include.module_args = '/tmp'
    my_include.args['some'] = 'some'

    # Test with list containing

# Generated at 2022-06-11 10:17:10.667367
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play

    # create some fake vars
    vars = {'foo': 'bar'}

    # create a fake inventory
    inventory = FakeInventory()

    # create a play that includes the vars and inventory
    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        vars=vars,
        tasks=[
            dict(action=dict(foo='bar')),
            dict(action=dict(foo='bar')),
        ]
    )
    play = Play().load(play_ds, variable_manager=VariableManager(), loader=DictDataLoader())

    # create a task list from the play
    tl = load_list_of_tasks(play_ds['tasks'], play=play)

   

# Generated at 2022-06-11 10:17:19.107674
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import os
    import sys
    import tempfile

    # (Re)create directory to use as base dir for tests
    test_dir = os.path.realpath(tempfile.mkdtemp())
    sys.path.insert(0, test_dir)  # For finding files
    fd, inventory_file = tempfile.mkstemp(dir=test_dir)

    # Make play with basic tasks
    ds = [{"hosts": "all", "tasks": [{"name": "task1", "local_action": "ping"},
                                     {"name": "task2", "local_action": "ping"}]}]

    # Create test inventory file

# Generated at 2022-06-11 10:17:23.261432
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    pl = Play()
    roles = load_list_of_roles(ds=["roles"],play=pl)
    assert isinstance(roles[0], RoleInclude)
    # Verify that it's only one element in the list
    assert len(roles) == 1
    assert roles[0]._role_name_in_current_dep is None
    assert roles[0]._role_name == 'roles'
    assert roles[0]._play == pl
    assert roles[0]._role_name_in_current_dep is None
    assert roles[0]._current_role_path is None
    # Make sure there's no variable manager
    assert roles[0]._variable_manager is None
   

# Generated at 2022-06-11 10:17:35.811061
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ansible_vars = dict(
        ansible_ssh_user='ansible',
        ansible_connection='ssh',
        ansible_ssh_pass='ansible',
        ansible_sudo=True,
    )

    # Create a fake play
    play_ds = dict(
        name="Ansible Play",
        hosts=['localhost', 'otherhost'],
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='Hello World 1'))),
            dict(action=dict(module='debug', args=dict(msg='Hello World 2'))),
        ]
    )

    fake_loader = DictDataLoader({
        '/etc/ansible/roles/foo': None
    })

    variable_manager = VariableManager()