

# Generated at 2022-06-11 10:08:07.017097
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks()

# Generated at 2022-06-11 10:08:20.376727
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ds = [{'name': 'role1'}, {'name':'role2'}]
    result = load_list_of_roles(ds, None)
    assert isinstance(result, list)
    for i in result:
        assert isinstance(i, RoleInclude)
    ds = [{'name': 'role1'}]
    result = load_list_of_roles(ds, None)
    assert isinstance(result, list)
    assert isinstance(result[0], RoleInclude)
    ds = {'name': 'role1'}
    result = load_list_of_roles(ds, None)
    assert isinstance(result[0], RoleInclude)



# Generated at 2022-06-11 10:08:32.019981
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # nothing
    ds = []
    task_ds = []
    block_ds = []
    block_list = load_list_of_blocks(ds, task_ds, block_ds)
    assert block_list == []

    # single task with no block
    ds = [dict(Task.task_from_datastruct(task_ds))]
    task_ds = [dict(action=dict(module='foo', args=dict(a='b')))]
    block_ds = []
    block_list = load_list_of_blocks(ds, task_ds, block_ds)
    assert len(block_list) == 1

# Generated at 2022-06-11 10:08:41.351441
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude

    p = Play()
    class MockLoader(object):
        def get_basedir(self):
            return '.'
    loader = MockLoader()
    ds = [
        {'name': 'foo'},
        {'name': 'bar', 'tasks': [{'debug': 'msg=bar-task'}]}
    ]

    r = load_list_of_roles(ds, p, loader=loader)
    assert len(r) == 2 and isinstance(r[0], RoleInclude) and isinstance(r[1], RoleInclude)
    assert r[0]._role_name == 'foo'
    assert r[1]._role_name == 'bar'


# Generated at 2022-06-11 10:08:47.583950
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds = [{'block':'tasks','tasks':[{'shell':'echo test'}]}]
    play = 'test_play'
    block_list = load_list_of_blocks(ds, play)
    assert len(block_list) == 1
    assert block_list[0]._parent_block is None
    assert block_list[0].block == 'tasks'



# Generated at 2022-06-11 10:08:58.259494
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # initialize vars and other objects
    ds = [{'hello':'world'}, {'ping': 'pong'}]

    # I don't want to mock everything, so I just don't use the objects
    play = None
    block = None
    role = None
    task_include = None
    variable_manager = None
    loader = None

    # run the function of interest
    retv = load_list_of_tasks(ds, play, block, role, task_include, variable_manager, loader)

    # assert on expected output
    assert(retv[0].action == 'hello')
    assert(retv[1].action == 'ping')

# Test for function load_list_of_blocks

# Generated at 2022-06-11 10:09:08.767385
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    class Options(object):
        def __init__(self):
            self.connection = 'local'
            self.module_path = None
            self.forks = 10
            self.private_key_file = None
            self.ssh_common_args = None
            self.ssh_extra_args = None
            self.sftp_extra_args = None
            self

# Generated at 2022-06-11 10:09:21.733448
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleSequence

    # Non-empty list of tasks
    ds = [
        {'debug': {'msg': 'foo'}},
        'name: bar'
    ]
    task_list = load_list_of_tasks(ds, play='test play')
    assert len(task_list) == 2

# Generated at 2022-06-11 10:09:22.450131
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:09:25.907418
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Function load_list_of_tasks
    '''

    print("test_load_list_of_tasks")
    print("TODO : write unit test")
    pass



# Generated at 2022-06-11 10:10:00.508888
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # given:
    # ds as a list of 2 dictionaries of "tasks"
    ds = {
        "tasks": [
            {
                "name": "this is the first task",
                "action": "debug",
                "debug": {
                    "msg": "this is a test"
                }
            },
            {
                "name": "this is the second task",
                "action": "debug",
                "debug": {
                    "msg": "this is a test"
                }
            }
        ]
    }
    loader = DictDataLoader({})
    variable_manager = VariableManager(loader=loader)
    task_include = None
    use_handlers = False
    role = None
    block = None

# Generated at 2022-06-11 10:10:13.845254
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory
    #from ansible.vars.manager import VariableManager
    #from ansible.plugins.loader import PluginLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    #loader.set_vault_password('secret')
    inventory = Inventory(loader=loader, variable_manager=VariableManager())

    #vars_manager = VariableManager(loader=loader, inventory=inventory)
    play = Play().load('', loader=loader, variable_manager=VariableManager(), use_handlers=True, task_include='all')
    #play = Play().load(play_ds, loader=loader, variable_manager=VariableManager(), use_handlers=True, task

# Generated at 2022-06-11 10:10:21.529046
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
        {'include': 'myinclude', 'static': True},
    ]
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    result = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert result[0].statically_loaded is True


# Generated at 2022-06-11 10:10:28.175116
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory("localhost,")
    variable_manager.set_inventory(inventory)

    # test_all_static
    data = [
        {'include_tasks': 'static.yaml', 'loop': '{{ static_tasks }}'},
        {'include_tasks': 'static2.yaml'},
    ]
    play = Play().load({'name': 'task-test', 'hosts': 'all', 'gather_facts': 'no', 'tasks': data}, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-11 10:10:36.908998
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    data = [{'debug': {'msg': 'toto'}}, {'debug': {'msg': 'tata'}}, {'debug': {'msg': 'titi'}}]
    task_list = load_list_of_tasks(data, None, None)
    assert len(data) == len(task_list)

    for i in range(len(task_list)):
        assert data[i] == task_list[i]._ds

# Generated at 2022-06-11 10:10:41.725145
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    task_list = load_list_of_tasks(ds=[{'block': 'init'}], play={}, block={}, role={}, task_include={}, use_handlers=False, variable_manager={}, loader={})
    assert type(task_list[0]) == 'Block'


# Generated at 2022-06-11 10:10:52.238814
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # this is here because this is a dynamic import.  For the unit test, the
    # line above doesn't trigger the import
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.cleaner import YamlCleaner
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_unicode
    from ansible.plugins.loader import filter_loader, lookup_loader
    from ansible.plugins.loader import module_loader, test_loader
    from ansible.plugins.inventory import InventoryDirectory
    from ansible.plugins.callback import CallbackBase



# Generated at 2022-06-11 10:11:05.098587
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # We need to make sure we are not getting the real display output
    display.verbosity = 3
    root_dir = os.getcwd()
    play_path = './test/units/playbook/play_load_list_of_tasks.yml'
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)
    inventory.clear_pattern_cache()

    with open(play_path, 'rb') as pb_file:
        play_ds = yaml.safe_load(pb_file)
        for key in play_ds:
            if key == 'tasks':
                task_ds = play_ds[key]

# Generated at 2022-06-11 10:11:12.709119
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    a, b, c = 0, 0, 0
    d = dict()

    # Test load_list_of_tasks with valid ds, play, block and variable_manager
    # ds is a list of data structure

# Generated at 2022-06-11 10:11:23.949152
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import time
    import json
    ds = [
        {
            'include': 'foo.yml'
        },
        {
            'block1': [
                {
                    'include': 'foo.yml'
                },
                {
                    'block2': [
                        {
                            'include': 'foo.yml'
                        }
                    ]
                }
            ]
        }
    ]
    play = {}
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = {}
    loader = {}
    start = time.time()
    print(load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader))
    end = time.time()

# Generated at 2022-06-11 10:11:50.476579
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{'block': 'block1'}, {'block': 'block2', 'rescue': None}, {'debug': {'msg': 'xxx'}}, {'debug': {'msg': 'xxx'}}]
    ds2 = [{'include_tasks': 'xxx1.yaml'}, {'include_tasks': 'xxx2.yaml'}, {'debug': {'msg': 'xxx'}}, {'debug': {'msg': 'xxx'}}]
    play = lambda:0
    play.serial = 0
    play.connection = 'local'
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {}
    variable_manager.options_vars = {}
    variable_manager.options_vars['nocolor'] = True
   

# Generated at 2022-06-11 10:12:01.132217
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ds = [
        {
            'include': 'content',
            'role': 'test'
        },
        {
            'include': 'content1',
            'role': 'test1'
        }
    ]

    roles = load_list_of_roles(ds=ds,
                               play=None,
                               current_role_path=None,
                               variable_manager=None,
                               loader=None,
                               collection_search_list=None)
    assert len(roles) == 2
    assert roles[0].role_name == 'test'
    assert roles[1].role_name == 'test1'
    assert roles[0].include_role == 'content'
    assert roles[1].include_role == 'content1'

# Generated at 2022-06-11 10:12:02.813124
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO: write unit tests for this function
    pass


# Generated at 2022-06-11 10:12:12.293221
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    block_ds = dict(
        block=dict(
            tasks=dict(
                action=dict(
                    module="copy",
                    args=dict(
                        content="content",
                        dest="dest",
                    ),
                ),
            ),
        ),
        rescue=dict(
            tasks=dict(
                module="service",
                args=dict(
                    name="service_name",
                    state="restarted",
                ),
            ),
        ),
        always=dict(
            tasks=dict(
                module="git",
                args=dict(
                    repo="repo",
                    dest="dest",
                ),
            ),
        ),
    )
    task_list = load_list_of_tasks(block_ds)
    assert isinstance(task_list, list)

    block_list = load_list_

# Generated at 2022-06-11 10:12:24.341190
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    # Declare play
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

# Generated at 2022-06-11 10:12:35.339244
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_playbook = [
        {
            'include': 'role1',
            'static': True,
            'loop': 'list1'
        },
        {
            'include': 'role2',
            'static': False,
            'loop': 'list2'
        }
    ]

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole

    task_list = load_list_of_tasks(test_playbook, None, None, None, None, False, None, None)
    assert len(task_list) == 2
    assert isinstance(task_list[0], IncludeRole)

# Generated at 2022-06-11 10:12:44.987015
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks([
        {
            'local_action': 'debug',
            'args': {
                'msg': 'test message',
            }
        }
    ]) == [
        Task({
            'local_action': 'debug',
            'args': {
                'msg': 'test message',
            }
        })
    ]
    assert load_list_of_tasks([ {'include': 'tasks/main.yml'} ]) == [
        TaskInclude({
            'include': 'tasks/main.yml',
        })
    ]
    assert load_list_of_tasks([ {'include_role': {'name': 'test.yml'}} ]) == [
        IncludeRole({
            'name': 'test.yml',
        })
    ]
   

# Generated at 2022-06-11 10:12:56.470364
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    variable_manager = VariableManager()
    variable_manager.extra_vars = load_extra_vars(loader=None, options=None)
    variable_manager.options_vars = load_options_vars(variable_manager, loader=None, options=None)

    loader = DataLoader()

    # FIXME: this needs a more complete test

# Generated at 2022-06-11 10:13:06.812655
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
   ds = [
        {'block': {
            'block': {
                'name': 'test2',
                'task':
                    {'name': 'test2',
                     'shell': 'hello2'},
            },
            'name': 'test1',
            'task': {
                'name': 'test1',
                'shell': 'hello'}
        }},
        'echo testing'
        ]
   role = {'name': 'test_role', 'role_path': 'test/test_role'}
   task_include = {'include': {'name': 'test_task_include', '_role': role, '_parent': 'block'}}
   loader = {'get_basedir': 'test'}
   use_handlers = False
   display = {'warning': 'test'}
  

# Generated at 2022-06-11 10:13:07.909191
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    load_list_of_tasks()


# Generated at 2022-06-11 10:13:38.066357
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play

    pb = Play.load(
        dict(
            name="play1",
            hosts='127.0.0.1',
            gather_facts='no',
            connection='local',
            tasks=[
                dict(action=dict(module='setup'), register='setup_result'),
                dict(action=dict(module='echo', args=dict(msg='this is a task'))),
            ]
        ),
        variable_manager=None,
        loader=None,
        finalize_callback=None,
        journey_loader=None,
    )

    load_list_of_tasks(ds=pb.tasks, play=pb, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)

# Generated at 2022-06-11 10:13:43.163221
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
        dict(
            action=dict(
                module="shell",
                args="ls"
            )
        ),
        dict(
            action=dict(
                module="shell",
                args="ls"
            )
        )
    ]
    load_list_of_tasks(ds, None, None, None)
    # TODO: actually assert something



# Generated at 2022-06-11 10:13:52.780141
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ver = sys.version_info
    if ver[0] == 2 and ver[1] < 7:
        raise unittest.SkipTest("Require Python2.7 to run these tests!")

    import ansible.playbook.block as block
    import ansible.playbook.role_include as role_include
    import ansible.playbook.task as task
    import ansible.playbook.task_include as task_include
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.template import Templar

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
   

# Generated at 2022-06-11 10:14:02.959614
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Play, Playbook
    from ansible.constants import DEFAULT_HANDLER_NAME
    from ansible.vars.manager import VariableManager

    inventory = Inventory('localhost,127.0.0.1')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    playbook = Playbook.load('/tmp/test/roles/testrole/meta/main.yml', variable_manager=variable_manager, loader=None)
    assert playbook.get_plays()[0].get_all_roles_and_tasks()[0][1][0].name == '/bin/foo'
    assert playbook.get_plays()[0].get_all_roles_and_tasks()[0][1][1].name == '/bin/bar'
    assert playbook.get_plays()

# Generated at 2022-06-11 10:14:11.712078
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    # A fake task dictionary

# Generated at 2022-06-11 10:14:18.741327
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    play_context = PlayContext()
    play_context.connection = 'local'
    play_context.network_os = 'ios'

    inv = InventoryManager(loader=loader, sources=['hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inv)
    ds = [{'import_tasks': 'foo.yml'}]

# Generated at 2022-06-11 10:14:27.726751
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = [
        {
            'meta': 'this is meta',
            'action': {
                'module': 'ping'
            },
            'name': 'test-ping',
            'block': [
                {
                    'meta': 'this is meta',
                    'action': {
                        'module': 'shell',
                        'args': 'whoami'
                    },
                    'name': 'test-whoami',
                    'block': [
                        {
                            'meta': 'this is meta',
                            'action': {
                                'module': 'shell',
                                'args': 'pwd'
                            },
                            'name': 'test-pwd',
                        }
                    ]
                }
            ]
        }
    ]

# Generated at 2022-06-11 10:14:38.403130
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
  from ansible.playbook.block import Block
  
  ds = [{'block': {'tasks': [{'command': 'echo hello', 'register': 'b'}, {'debug': 'msg={{ b.stdout_lines }}'}]}}, {'block': {'vars': {'a': 'hi'}, 'tasks': [{'debug': 'msg={{ a }}'}]}}, {'debug': 'msg=hello world'}]

# Generated at 2022-06-11 10:14:39.211772
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:14:52.318358
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import sys
    import os
    import types
    import ansible.parsing
    import ansible.playbook.block
    import ansible.playbook.role
    import ansible.vars
    from ansible.constants import DEFAULTS
    from ansible.errors import AnsibleError
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory, Host, Group
    from ansible.module_utils.six import string_types
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.plugins import callback_loader
    from ansible.template import Templar
    from ansible.utils import context_objects as co
    from ansible.utils.boolean import boolean
    from ansible.utils.display import Display

# Generated at 2022-06-11 10:15:19.156812
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks([]) == []

# Generated at 2022-06-11 10:15:26.700432
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():    
    ds=[{'action': 'copy', 'args': {'content': '#!/bin/bash\n\necho  "hi"', 'dest': '/tmp/hello'}, 'delegate_to': 'localhost'}, {'action': 'shell', 'args': {'chdir': None, 'creates': None, 'executable': None, 'removes': None, 'warn': True}, 'delegate_to': 'localhost'}]
    args_parser=ModuleArgsParser(ds)

    try:
        (action, args, delegate_to) = args_parser.parse(skip_action_validation=True)
    except AnsibleParserError as e:
        print(to_native(e))
       


# Generated at 2022-06-11 10:15:39.559277
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{'block': {'name': 'first', 'tasks': []}}, {'name': 'second', 'local_action': 'command'}, {'include': 'third', 'static': True}]
    play = Mock()
    block = Mock()
    role = Mock()
    task_include = Mock()
    use_handlers = False
    variable_manager = Mock()
    loader = Mock()
    task_list = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert not isinstance(task_list[0], Task)
    assert task_list[0].name == 'first'
    assert task_list[1].args == {'name': 'second', 'local_action': 'command'}
    assert isinstance

# Generated at 2022-06-11 10:15:50.925832
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()

# Generated at 2022-06-11 10:16:01.083682
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    def setup_module():
        print("")  # this is to get a newline after the dots
        global playbook_path
        global all_vars
        global loader
        global variable_manager
        global display
        global options
        global play

        playbook_path = "/home/xin/ansible/ansible/test/playbook.yaml"

        basedir = os.path.dirname(playbook_path)
        loader = DataLoader()
        variable_manager = VariableManager()
        inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=None)

        # create the playbook object, based on the path to the playbook yaml file
        pb = Playbook.load(playbook_path, variable_manager=variable_manager, loader=loader, inventory=inventory)
        play = pb.get_

# Generated at 2022-06-11 10:16:12.999741
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible import constants as C
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost,"])
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    )

    # Create play object, playbook objects use .load instead

# Generated at 2022-06-11 10:16:14.268193
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO
    pass

# Generated at 2022-06-11 10:16:23.981093
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Test load_list_of_tasks function
    '''

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.template import Templar

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager

    # Create a test directory, and temp file
    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_dir_file.yml')
    open

# Generated at 2022-06-11 10:16:34.403631
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    ds = [
            dict(action='action_1', args='args_1'),
            dict(include='include_1', include_args='include_args_1'),
            dict(notify='notify_1', delegate_to='delegate_to_1'),
            dict(action='action_2', args='args_2'),
            dict(include='include_2', include_args='include_args_2'),
            dict(block=[]),
        ]

    #
    # expected_task_list:
   

# Generated at 2022-06-11 10:16:44.695704
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    class A:
        def __init__(self):
            pass
    a = A()

    class B:
        def __init__(self):
            pass
    b = B()

    b.play = a
    b._parent = a
    b._role = a
    
    str_data_not_list = '{"block": "block"}'
    not_list_data = json.loads(str_data_not_list)
    try:
        load_list_of_tasks(not_list_data, b, b, b, b, True, a, a)
    except AnsibleAssertionError as e:
        pass

    str_data_error = '[{"block": "block", "action": "action"}]'
    error_data = json.loads(str_data_error)