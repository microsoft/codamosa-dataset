

# Generated at 2022-06-11 10:08:27.163564
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    ds1 = dict(
        action='ansible.builtin.command',
        args=dict(
            _raw_params='ls',
            chdir='/etc'
        )
    )
    ds2 = dict(
        block='block1'
    )

# Generated at 2022-06-11 10:08:38.135437
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role import Role
    import ansible.constants as C
    import ansible.playbook
    import ansible.template
    play = ansible.playbook.Play()
    loader = ansible.cli.CLI.setup_loader()
    templar = ansible.template.Templar(loader=loader, variables={'test': 'fake'})

    #===================================================================
    #   Test Task.load
    #===================================================================

# Generated at 2022-06-11 10:08:50.202221
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Loader object using the mock basedir
    loader = DataLoader()

    # Construct a dummy inventory object
    # hosts with 1 vars each.
    inventory = Inventory("/some/path")

    # Construct a dummy variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Construct a dummy play object
    play = Play.load({}, variable_manager=variable_manager, loader=loader)

    # Construct a dummy block object
    block = Block(play=play)

    # Construct a dummy role object
    role = Role()

    # Construct a dummy task include object
    task_include = TaskInclude()

    # Construct a dummy task
    task_1 = Task()
    task_1._role = role
    task_1._task_include = task_include
    task_1._play = play
   

# Generated at 2022-06-11 10:08:55.603963
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{"block": [], "name": "Create the logs directory", "block": [
        {"block": []},
        {"block": []}]}]
    play = Play.load(ds)
    task_list = load_list_of_tasks(ds=ds, play=play)
    assert len(task_list) == 3

# Generated at 2022-06-11 10:09:06.839988
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import json
    import os
    import sys
    import unittest
    import tempfile

    test_dir = os.path.dirname(os.path.dirname(__file__))
    sys.modules['ansible'] = imp.new_module('ansible')

    # Add the library to the module path
    sys.modules['ansible.module_utils'] = imp.new_module('module_utils')
    sys.modules['ansible.module_utils.basic'] = imp.new_module('basic')
    sys.modules['ansible.module_utils.basic'].AnsibleModule = unittest.mock.Mock()
    sys.modules['ansible.module_utils.basic'].AnsibleModule.params = dict()
    sys.modules['ansible.module_utils.basic'].AnsibleModule

# Generated at 2022-06-11 10:09:18.763801
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook import PlayBook
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources="localhost,")
    playbook = PlayBook.load("test/ansible/cli/playbook.yml", loader=loader, inventory=inventory)
    play = playbook.get_plays()[0]
    variable_manager = VariableManager()
    parent_block = play.get_strategy()
    role = None
    task_include = None
    use_handlers = False

# Generated at 2022-06-11 10:09:30.501267
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Task 1 (static include of tasks)
    ds1 = [{'include': './test_static_include.yml', 'static': True}]
    ds2 = [{'include_tasks': './test_static_include.yml'}]
    ds3 = [{'import_tasks': './test_static_include.yml'}]
    ds4 = [{'include': './test_static_include.yml', 'loop': "{{ host_list }}"}]
    ds5 = [{'include_tasks': './test_static_include.yml', 'loop': "{{ host_list }}"}]
    ds6 = [{'import_tasks': './test_static_include.yml', 'loop': "{{ host_list }}"}]
   

# Generated at 2022-06-11 10:09:39.737202
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext

    class Options(object):
        def __init__(self, tags, skip_tags):
            self.tags = tags
            self.skip_tags = skip_tags

    class FakeVarManager(object):
        def get_vars(self, play=None, task=None):
            self.play = play
            self.task = task
            return dict()

    options = Options(tags=['tag1'], skip_tags=['tag2'])
    ds = [{'action': 'copy', 'args': 'src=a dest=b', 'tags': ['tag1', 'tag3']}]
    play = Play()
    play._variable_manager = FakeVarManager()

# Generated at 2022-06-11 10:09:40.434011
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True

# Generated at 2022-06-11 10:09:42.049274
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert False, 'This function has no unit test.'


# Generated at 2022-06-11 10:10:19.737654
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    hosts = set(['localhost'])
    variable_manager = VariableManager()
    loader = DataLoader()
    options = Options()
    variable_manager.set_inventory(Inventory(loader=loader, host_list=hosts, variable_manager=variable_manager))

    # Create Play w/ default play settings
    pb = Playbook.load('../../../test/integration/playbooks/test_parser.yml', loader=loader, variable_manager=variable_manager, options=options)
    play = pb.get_plays()[0]

    # Create Task
    ds1 = dict(
        action='asdf'
    )

    ds2 = dict(
        block=[]
    )

    ds3 = dict(
        name='test_name'
    )

    task_list = load_list_

# Generated at 2022-06-11 10:10:27.286262
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = """
    - include_tasks: tasks/main.yml
      tags: ['tags1']
    - name: Test task
      debug:
        msg: Test msg
    - name: Test task2
      debug:
        msg: Test msg
    - include_role:
        name: include_test
      static: yes
      tags: ['tags2']
    """
    play_ds = dict(
        name="Ansible Play",
        hosts="all",
        gather_facts="no",
        tasks=task_ds
    )
    loader, inventory, variable_manager = TestPlaybookExecution.PlaybookExecutionHelper.prepare_playbook_execution(play_ds)

# Generated at 2022-06-11 10:10:40.704828
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager.extra_vars = {'foo': 'bar'}
    play_context = PlayContext

# Generated at 2022-06-11 10:10:48.745746
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    abc = load_list_of_tasks(
        ds=[
           {'action': 'include', 'static': 'yes', 'args': {'_raw_params': '../common.yml'}}
        ],
        play=None,
        block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=None,
        loader=None
    )
    print(abc)
    assert abc is not None and len(abc) > 0


# Generated at 2022-06-11 10:10:59.724551
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar

    task_list = []
    for task_ds in ds:
        if not isinstance(task_ds, dict):
            raise AnsibleAssertionError('The ds (%s) should be a dict but was a %s' % (ds, type(ds)))


# Generated at 2022-06-11 10:11:00.469932
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True

# Generated at 2022-06-11 10:11:11.566802
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import sys
    import os
    import yaml
    from collections import namedtuple
    from ansible.module_utils._text import to_bytes, to_text

    # Make a namedtuple for the configuration class
    C = namedtuple('C', ['DEFAULT_MODULE_PATH', 'DEFAULT_ROLES_PATH', 'DEFAULT_PLAYBOOK_PATH'])

    # Create a configuration object
    c = C('/usr/share/ansible', '/etc/ansible/roles', '/etc/ansible/playbooks')

    # Create a connection plugin dictionary
    conn = {}

    # Create a loader object
    loader = DataLoader()

    # Create a variable manager object
    variable_manager = VariableManager()

    # Create a template object

# Generated at 2022-06-11 10:11:22.689155
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{'block': {}}]
    play = {}
    block = {}
    role = {}
    task_include = {}
    use_handlers = False
    variable_manager = {}
    loader = {}
    load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert ds == [{'block': {}}]
    assert play == {}
    assert block == {}
    assert role == {}
    assert task_include == {}
    assert use_handlers == False
    assert variable_manager == {}
    assert loader == {}
    ds = [{'include': {'include_path': 'tasks/testtasks.yml', 'static': 'yes'}}]

# Generated at 2022-06-11 10:11:33.181540
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-11 10:11:35.358408
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    def T():
        pass
    print(type(T()))

# Generated at 2022-06-11 10:12:10.916134
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext

    testdata = dict(
        name = 'test',
        hosts = ['all'],
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    )

    play_context = PlayContext()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variables = VariableManager(loader=loader, inventory=inventory)
    play = Play.load(testdata, variable_manager=variables, loader=loader)
    task_list = load_list_of_tasks

# Generated at 2022-06-11 10:12:22.500769
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

    # Load Ansible 2.9 handler file to test load_list_of_tasks
    # TODO: move to test data dir

# Generated at 2022-06-11 10:12:34.430838
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        def v2_runner_on_ok(self, result, **kwargs):
            host = result._host
            print(json.dumps({host.name: result._result}, indent=4))


# Generated at 2022-06-11 10:12:35.379426
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass



# Generated at 2022-06-11 10:12:45.041226
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    fake_vars = {'key1': 'value1'}
    includes = """\
- name: include task file
  include_tasks: "file.yml"
  loop: "{{ key1 }}"
"""
    play = dict(
        name='fake_play',
        hosts='all',
        vars=fake_vars,
        tasks=yaml.safe_load(includes)
    )
    block = Block.load(play, play=play)
    block.post_validate(templar=Templar(loader=None))

# Generated at 2022-06-11 10:12:56.469778
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    ensure we can load a list of tasks, and that include
    tasks do not have loop set to true.
    '''

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

    class FakeLoader(object):
        def get_basedir(self):
            return '.'

    class FakeVariables(object):
        def get_vars(self, play=None, task=None, host=None):
            return dict(omg="hi")

    task_ds = dict(action='include', loop='True', omg='{{ omg }}')
    t = TaskInclude()

# Generated at 2022-06-11 10:13:06.811486
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar

    ansible.utils.plugin_docs.listclass.__globals__['__builtins__']['_'] = lambda x: x
    class EmptyTask:
        def __init__(self, name):
            self._name = name
            self._role_name = None
            self.action = 'meta'
            self.args = {}
            self.statically_loaded = False
            self._role = None
            self.tags = []
            self.loop

# Generated at 2022-06-11 10:13:16.731870
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
  '''Your function call should look something like this:
    load_list_of_tasks(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
  '''
  # Test 1
  ds = [{'name': 'test1'}, {'block': {'name': 'test2'}}]
  play = None
  block = None
  role = None
  task_include = None
  use_handlers = False
  variable_manager = None
  loader = None
  load_list_of_tasks(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
  # Test 2
  ds = None

# Generated at 2022-06-11 10:13:27.500725
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    task_ds = [{'action':'debug', 'args':{'msg': 'hello ansible'}},
               {'action':'include_tasks', 'args':{'tasks': 'tasks/main.yml'}},
               {'action':'include_role', 'args':{'name': 'common'}}]
    task_list = load_list_of_tasks(task_ds)
    assert(len(task_list) == 3)
    assert(isinstance(task_list[0], Task))
    assert(isinstance(task_list[1], TaskInclude))

# Generated at 2022-06-11 10:13:39.902090
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.executor import module_common
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    variable_manager.extra_vars = {'test_var': [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}], 'nested_test_var': {'x': {'y': 'value'}}}
    variable_manager._extra_vars = variable_manager.get_vars()


# Generated at 2022-06-11 10:13:59.830941
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    load_list_of_tasks(ds=Play.load({'hosts': 'localhost', 'name': 'Test', 'tasks':[]}), play=None, block=None, role=None, task_include=TaskInclude(), use_handlers=False, variable_manager=None, loader=None)

# Generated at 2022-06-11 10:14:08.679047
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.task import Task
    from ansible.template import Templar

    task_source = [
        {'action': 'shell', 'args': 'echo hi'},
        {'action': 'shell', 'args': 'echo hello'},
        {'action': 'shell', 'args': 'echo hola'},
    ]

    task_source_with_implicit_block = [
        {'action': 'shell', 'args': 'echo hi'},
        [
            {'action': 'shell', 'args': 'echo hello'},
            {'action': 'shell', 'args': 'echo hola'},
        ],
    ]

    task_source_with_implicit_block_and_nested_implicit_block

# Generated at 2022-06-11 10:14:16.812584
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Testing that load_list_of_tasks returns Task() or TaskInclude() when task_ds is a list of dictionaries
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars

    context = PlayContext()
    myplay = Play().load(dict(
        name="Ansible Play",
        hosts=['all'],
        become=True,
    ), variable_manager=VariableManager(), loader=DataLoader())

    variable_manager = VariableManager()


# Generated at 2022-06-11 10:14:25.554128
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    host_variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["/home/suik/Documents/ansible/inventory/inventory"])
    host = Host('localhost')
    group = Group('group')
    group.add_host(host)
    inventory.add_group(group)
    inventory.add_host(host)
    host_variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 10:14:35.307524
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar

# Generated at 2022-06-11 10:14:48.048080
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    def gen_playbook(code):
        return {
            "name": "blah",
            "hosts": "localhost",
            "gather_facts": "no",
            "tasks": [
                code
            ]
        }

    a = load_list_of_tasks([gen_playbook("shell: python -c 'print(\"hello world\")'")], None, None)
    assert len(a) == 1

    b = load_list_of_tasks([gen_playbook("non_existent_action: python -c 'print(\"hello world\")'")], None, None)
    assert len(b) == 0

    c = load_list_of_tasks([gen_playbook("import_tasks: this_is_not_here.yml")], None, None)
    assert len

# Generated at 2022-06-11 10:14:58.148815
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # We have to have a playbook_dir set because
    # we are going to be loading roles that may
    # have role dependencies
    pb_dir = os.path.join(os.path.dirname(__file__), 'test_loader/fake_playbooks/')
    loader = DataLoader()
    variable_manager = VariableManager()

    # Test a simple play with just tasks
    play_source =  dict(
        name = "Test play 0",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='shell', args='whoami'))
        ]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-11 10:15:11.662470
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayObj
    from ansible.template import Templar
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.vars.file_variable_manager import FileVariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import callback_loader
    from ansible.executor.task_queue_manager import TaskQueueManager

    class TestCallbackModule(object):

        def __init__(self, *args, **kwargs):
            pass

        def v2_on_any(self, *args, **kwargs):
            pass


# Generated at 2022-06-11 10:15:23.415030
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    import mock

    # Mock AnsibleModule for module_args_parser
    mock_module = mock.Mock()
    mock_module.params = {}

    def mocked_run_command(cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        """Mocked response for run_command"""
        class CmdRes:
            """Mock class for cmd response"""

# Generated at 2022-06-11 10:15:37.474774
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.network_os = 'default'
    play_context.remote_addr = '0.0.0.0'
    variable_manager.set_play_context(play_context)


# Generated at 2022-06-11 10:16:08.744777
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert False, "No test for load_list_of_tasks"

# Generated at 2022-06-11 10:16:20.074162
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    expected_tasks = [
        {
            'action': 'include',
            'args': {
                '_raw_params': '{{ foo }}',
            },
        },
        {
            'action': 'include',
            'args': {
                '_raw_params': 'static.yml',
            },
            'static': 'yes',
        }
    ]
    task_list = [
        {
            'block': [
                {
                    'action': 'include',
                    'args': {
                        '_raw_params': 'static.yml',
                    },
                    'static': 'yes',
                },
            ],
        },
        {
            'action': 'include',
            'args': {
                '_raw_params': '{{ foo }}',
            },
        },
    ]
   

# Generated at 2022-06-11 10:16:29.225613
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # create temporary file
    import tempfile
    fd, path = tempfile.mkstemp()
    with open(path, 'w') as f:
        f.write('''
        - name: send test_block_to_play
          block:
            - name: task1
              debug: msg="task1"
            - name: task2
              debug: msg="task2"
          rescue:
            - name: task3
              debug: msg="task3"
            - name: task4
              debug: msg="task4"
          always:
            - name: task5
              debug: msg="task5"
            - name: task6
              debug: msg="task6"
        ''')
    from ansible import context
    from ansible.cli.adhoc import AdHocCLI as AdHoc


# Generated at 2022-06-11 10:16:33.615558
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.role.meta import RoleMeta
    from ansible.playbook.role.definition import RoleDefinition
    collection_search_list = []
    play = Play.load({
        'name': 'test',
        'hosts': 'all',
        'roles': '',
        'tasks': [],
        'collections': [],
    }, variable_manager=None, loader=None, collection_list=collection_search_list)
    # import here to prevent circular dependency
    from ansible.vars.manager import VariableManager
    from ansible.models.vault import VaultSecret
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.cli.arguments import CLIArg

# Generated at 2022-06-11 10:16:37.693575
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # arrange
    ds = []

    # act
    result = load_list_of_tasks(ds, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)

    # assert
    assert result == []



# Generated at 2022-06-11 10:16:39.015046
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert False, "Test Not Implemented"

# Generated at 2022-06-11 10:16:49.032389
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
        {
          "block": [
            {
              "block|debug": [
                {
                  "fail": {
                    "msg": "a failing task"
                  }
                },
                {
                  "debug": {
                    "msg": "show all the things"
                  }
                }
              ],
              "when": "ansible_os_family == 'RedHat'"
            }
          ],
          "hosts": "all"
        }
    '''

# Generated at 2022-06-11 10:16:57.084421
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # First test case
    test_task_list = [{"name": "Ansible", "local_action": "setup", "register": "setup_output"}]
    temp_play = Mock()
    temp_block = Mock()
    res = load_list_of_tasks(test_task_list, temp_play, temp_block, False)
    assert len(res) == 1
    # Second test case
    assert load_list_of_tasks(None, temp_play, temp_block, False) == []

# Generated at 2022-06-11 10:16:57.825298
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:16:59.324263
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # this is just smoke test
    assert True

