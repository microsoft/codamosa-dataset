

# Generated at 2022-06-11 10:08:02.278772
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    x = [{u'when': u'ansible_os_family == "RedHat"', 'debug': {'msg': u'{{ ansible_os_family }}'}}]
    assert isinstance(load_list_of_tasks(x, None, None, None, None, False, None, None), list)


# Generated at 2022-06-11 10:08:02.856006
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True

# Generated at 2022-06-11 10:08:11.339811
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    :return:
    '''
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole

    # setup test data
    block_data = [
        {
            'name': 'test_role',
            'include_role': {
                'name': 'include_role_test',
                'tasks_from': 'foo'
            }
        }
    ]

    task_data = [
        {
            'name': 'test_task',
            'include': 'test'
        }
    ]

    # create task list
    task_list = load_list_of_tasks(task_data, None, None, None, None, False, None, None)
    assert len(task_list) == 1

# Generated at 2022-06-11 10:08:23.520855
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Testing module_util load_list_of_tasks and test format of the list
    # - Create a fixture that represents a temporary data structure.
    # - Use the tmpdir fixture, which provides a unique temporary directory
    #   path for each test function.
    ds = [{'module': 'assert', 'msg': 'hello'}, {'module': 'debug', 'var': {'myvar': 'myvalue'}}]
    assert isinstance(ds, list)
    assert isinstance(ds[0], dict)
    assert isinstance(ds[1], dict)
    # - Testing if the data structure has correct keys and values
    for task_ds in ds:
        assert 'module' in task_ds
        assert 'msg' in task_ds or 'var' in task_ds

# Generated at 2022-06-11 10:08:35.226250
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    display = Display()
    #playbook.yml文件
    ds = [{'name': 'include_role', 'include_role': {'name': 'LAMP'}}]
    #play对象
    play = Play().load(ds, variable_manager=VariableManager(), loader=DataLoader())
    #block对象
    block = Block().load(ds, play=play, parent_block=play, role=None, task_include=None, use_handlers=False, variable_manager=VariableManager(), loader=DataLoader())
    #role对象
    role = Role().load(ds, play=play, parent_block=play, role_params=None, variable_manager=VariableManager(), loader=DataLoader())
    #TaskInclude对象
    task_include

# Generated at 2022-06-11 10:08:45.261555
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler

    task_list = [{'action': 'include', 'args': {'_raw_params': 'foo.yaml', 'static': True}}, {'action': 'ping', 'args': {'_raw_params': 'foo.yaml'}}]
    use_handlers=False
    result = load_list_of_tasks(task_list, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)

# Generated at 2022-06-11 10:08:46.030735
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:08:57.567313
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import json
    from ansible.plugins.action import ActionModule
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils._text import to_text

    from .testutil import TestModule

    def action_load(*_, **__):
        return TestActionModuleClass()

    def get_action_class(action):
        class TestActionClass:
            def __init__(self):
                self.has_run = False
                self.action = action
                self.args = None

            def run(self, connection, play_context):
                self.has_run = True
                self.args = self.task_args.copy()
                if isinstance(self.args, dict):
                    self.args.pop('_ansible_parsed', None)

# Generated at 2022-06-11 10:09:08.375379
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Unit test for function load_list_of_tasks
    '''

    # Setup arguments
    ds = [{
        'action': 'include_tasks',
        'static': 'yes',
        'args': {
            '_raw_params': '/etc/ansible/vars/include_tasks.yml'
        }
    }, {
        'action': 'include_tasks',
        'static': 'no',
        'args': {
            '_raw_params': '/etc/ansible/vars/include_tasks2.yml'
        }
    }]

    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    loader = None
    variable_manager = None

    # Setup return value
    ret

# Generated at 2022-06-11 10:09:09.133344
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert False

# Generated at 2022-06-11 10:09:44.569558
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.copy import ActionModule as CopyActionModule
    from ansible.plugins.action.template import ActionModule as TemplateActionModule

    # Mock the module action handlers to ensure that we load the correct tasks
    def _get_action_handler(self, name):
        return name

    @staticmethod
    def register_as_handler(name, *args, **kwargs):
        copy_handler = name == 'copy'
        template_handler = name == 'template'

        if copy_handler or template_handler:
            ActionBase._get_action_handler = _get_action_handler

        if copy_handler:
            return (lambda *args, **kwargs: CopyActionModule(*args, **kwargs))

# Generated at 2022-06-11 10:09:54.311325
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Playbook
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible import context
    import os

    playbook_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'load_mixed_tasks.yaml')
    inventory_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'hosts')
    context.CLIARGS = ImmutableDict(connection='smart', module_path=None, forks=10, become=None,
                                    become_method=None, become_user=None, check=False, diff=False)


# Generated at 2022-06-11 10:09:59.783504
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{'include': 'test'}, {'debug': 'msg=test2'}]
    play = []
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)

# Generated at 2022-06-11 10:10:12.418384
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        load_list_of_tasks(['fstab'], None, None, None, None, None, None)
    except AnsibleAssertionError as e:
        assert "should be a dict but was a <class 'str'>" in to_native(e)
    try:
        load_list_of_tasks({"block": "fstab"}, None, None, None, None, None, None)
    except AnsibleAssertionError as e:
        assert "should be a list but was a <class 'dict'>" in to_native(e)
    # FIXME: we should un-skip this test
    #try:
    #    load_list_of_tasks([{"block": "fstab", "when": "test"}], None, None, None, None, None, None)
    #except Ans

# Generated at 2022-06-11 10:10:23.919027
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """
    Tests for general load_list_of_tasks function
    """
    loader, inventory, variable_manager = mock_loader()
    play = Play.load(dict(
        name="test play",
        hosts="all",
        gather_facts="yes",
        roles="test_role",
    ), variable_manager=variable_manager, loader=loader)
    role_name = 'test_role'
    role_path = os.path.join(os.path.dirname(__file__), 'data', 'roles', role_name)
    role = Role.load(role_name, role_path)
    play.roles.append(role)
    role._set_parent_play(play)

# Generated at 2022-06-11 10:10:37.282603
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from copy import deepcopy
    import yaml
    from ansible.plugins.action.normal import ActionModule
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    loader = DataLoader()

# Generated at 2022-06-11 10:10:48.838343
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._extra_vars = {
        'test1_var1': u'value1'
    }
    variable_manager._options_vars = {
        'test1_var2': u'value2'
    }
    variable_manager._fact_cache = {
        'test1_var3': u'value3'
    }


# Generated at 2022-06-11 10:10:59.780361
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor import task_queue_manager
    from ansible.utils.display import Display

    loader = DataLoader()
    display = Display()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=C.DEFAULT_HOST_LIST)
    variable_manager = VariableManager()

# Generated at 2022-06-11 10:11:11.063115
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test: Scenario 1: run include tasks
    # This test runs include tasks as there are no restrictions in this case
    ds = [{'include_tasks': 'tasks_5.yml'}]
    play = "test_play"
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = ""
    loader = ""
    result = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    expected = [TaskInclude]
    for item in result:
        assert type(item) in expected

    # Test: Scenario 2: run import tasks
    # This test runs import tasks as there are no restrictions in this case

# Generated at 2022-06-11 10:11:22.106681
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader

    from collections import namedtuple

    FakeLoader = namedtuple('FakeLoader', ['list_basedirs'])

    # Empty list
    ds = []
    display.verbosity = 4
    play = Play()
    play.name = 'play-name'
    play.post_validate()
    play.force_handlers = True
    loader = FakeLoader([])
    try:
        load_list_of_tasks(ds, play, task_include=None, use_handlers=True, loader=loader)
    except AnsibleAssertionError:
        pass
    else:
        raise AssertionError()

    # Invalid task
    ds = [{'invalid': 'task'}]

# Generated at 2022-06-11 10:11:42.668247
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    import ansible.constants as C

    # load the test tasks
    task_list = load_list_of_tasks(task_data, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert len(task_list) == 31
    assert task_list

# Generated at 2022-06-11 10:11:54.575378
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import io
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Generate a list of task ds with one block d
    block1 = {'block': [{'local_action': {'module': 'debug', 'args': {'msg': 'hello_world'}}}]}

# Generated at 2022-06-11 10:11:58.968207
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds1 = dict(name='foder')
    task_ds2 = dict(name='foder')

    ds = [task_ds1, task_ds2]
    assert(load_list_of_tasks(ds, None, None, None, None, None, None) == None)

# Generated at 2022-06-11 10:12:04.940853
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    yaml_data = [{
        "shell": "echo hello"
    }]
    block = Block()
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    task_list = load_list_of_tasks(yaml_data, None, None, None, None, False, variable_manager, loader)

    assert isinstance(task_list[0], Task)



# Generated at 2022-06-11 10:12:13.488829
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.task import Task
    data = [
        {'block': 'name', 'hosts': 'hosts', 'results': {'results': 'results1'}, 'tasks': [{'task': 'task1'}], 'block_args': {'block_args': 'block_args1'}},
        {'task': 'task2', 'args': {'args': 'args2'}},
        {'block': 'name2', 'hosts': 'hosts', 'results': {'results': 'results3'}, 'tasks': [{'task': 'task3'}], 'block_args': {'block_args': 'block_args3'}},
    ]

    # make bokks of block
    books = load_list_of_blocks(data, None, None)

    #

# Generated at 2022-06-11 10:12:25.972032
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import IncludeRole

    # Test with empty list
    ds = []
    task_list = load_list_of_tasks(ds)
    assert len(task_list) == 0

    # Test with a bad value
    ds = 1
    with pytest.raises(AnsibleAssertionError):
        load_list_of_tasks(ds)

    # Test with a dict
    ds = {'name': 'test task'}

# Generated at 2022-06-11 10:12:30.447557
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    block_list = load_list_of_blocks([{'block': 'this'}], None)
    assert isinstance(block_list, list)
    assert len(block_list) == 1
    assert isinstance(block_list[0], Block)



# Generated at 2022-06-11 10:12:39.349135
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    p = Play().load({
        'hosts': 'localhost',
        'name': 'test',
        'gather_facts': 'no',
        'tasks': [
            {'action': {'module': 'shell', 'args': 'whoami', 'register': 'shell_out'}},
            {'action': {'module': 'debug', 'args': 'msg={{shell_out.stdout}}'}}
        ]
    }, variable_manager=VariableManager(), loader=DataLoader())
    tqm = None
    pc = PlayContext(play=p)

# Generated at 2022-06-11 10:12:40.470463
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True


# Generated at 2022-06-11 10:12:51.633790
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.task_include import TaskInclude
    from ansible.parsing.vault import VaultLib
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import os


# Generated at 2022-06-11 10:13:10.571083
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import os
    import sys
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    ds = [
        {'include_role': {'name': 'role'}}, 
        {'include': 'include.yml'}, 
        {'include_tasks': 'include_tasks.yml'}, 
        {'import_tasks': 'import_tasks.yml'},
        {'import_role': {'name': 'role'}}
    ]
    # Block.load()
    assert True == Block.is_block(ds[0])
    assert False == Block.is_block(ds[1])
    assert False == Block.is_block(ds[2])
   

# Generated at 2022-06-11 10:13:20.995919
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude

    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    from ansible.playbook.block import Block

    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    from units.mock.loader import DictDataLoader


# Generated at 2022-06-11 10:13:32.393031
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    yaml_loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=yaml_loader, variable_manager=variable_manager, host_list='tests/inventory'))
    p = Play().load({}, variable_manager=variable_manager, loader=yaml_loader)

# Generated at 2022-06-11 10:13:36.619374
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import find_plugin
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.hostvars import HostVars
    class MockRole(Role):
        def __init__(self, *a, **kw):
            pass

    class MockTask(Task):
        def __init__(self):
            pass

    class MockTaskInclude(TaskInclude):
        def __init__(self):
            pass


# Generated at 2022-06-11 10:13:37.746787
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    return NotImplemented



# Generated at 2022-06-11 10:13:38.411292
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True

# Generated at 2022-06-11 10:13:46.754698
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    import ansible.playbook.play as play
    import ansible.playbook.task as task
    import ansible.playbook.block as block


# Generated at 2022-06-11 10:13:57.019549
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    class FakeLoader:
        def __init__(self):
            pass
        def path_dwim(self, given_path):
            return given_path

    class FakePlay:
        def __init__(self):
            pass

    class FakeVariableManager:
        def __init__(self):
            self._vars = {}
        def get_vars(self, play=None, task=None):
            return self._vars

    # test with using templates, using handlers
    ds = [{'action': 'include', 'args': {'_raw_params': '{{ a }}', 'a': 'b'}}]
    play = FakePlay()
    loader = FakeLoader()
    variable_manager = FakeVariableManager()
    variable_manager._vars = {'a': 'b'}
    blocks = load_list

# Generated at 2022-06-11 10:13:57.689047
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    pass



# Generated at 2022-06-11 10:13:58.752448
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert callable(load_list_of_tasks)

# Generated at 2022-06-11 10:14:35.214551
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Only run unit test if the env variable TOWER_UNIT_TEST is set.
    if not os.environ.get("TOWER_UNIT_TEST") == "true":
        return

    # define the test data
    # test_data = dict(
    test_data = {
        "name": "Ansible Playbook",
        "hosts": "all",
        "gather_facts": True,
        "vars": {
            "ansible_connection": "local",
            "ansible_python_interpreter": "/usr/bin/python"
        },
        "tasks": [
            {
                "name": "Print date",
                "debug": {
                    "msg": "Hello from {{ inventory_hostname }}"
                }
            }
        ]
    }

    # set up

# Generated at 2022-06-11 10:14:47.899558
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    play_context = PlayContext()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_var_1': '123', 'test_var_2': '456' }
    task_ds_1 = {'test_action': 'test_task_1', 'test_arguments': 'test_arguments_1'}
    task_ds_2 = {'test_action': 'test_task_2', 'test_arguments': 'test_arguments_2'}
    task_ds_3 = {'test_action': 'test_task_3', 'test_arguments': 'test_arguments_3'}

# Generated at 2022-06-11 10:14:58.083839
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    hosts_file = "/etc/ansible/hosts"
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=hosts_file)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play = Play.load(
        dict(
            name="Ansible Play",
            hosts="all",
            gather_facts="no",
            tasks=[
                dict(action=dict(module="shell", args="ls"), register="shell_out"),
                dict(action=dict(module="debug", args=dict(msg="{{shell_out.stdout}}")),
                     when="shell_out.rc == 0")
            ]
        ),
        variable_manager=variable_manager, loader=loader
    )

# Generated at 2022-06-11 10:15:11.492319
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
  '''
  This is a test skeleton to help validate functionality of the load_list_of_tasks function
  '''

  ds = {'name': 'Load Lorem Ipsum File',
      'action': 'lorem_ipsum',
      'args': { 'src': 'file.txt',
                'dest': '/tmp/lorem-ipsum.txt' },
      'register': 'loaded_file',
      'tags': [ 'example', 'tutorial' ]}   

  play = None
  block = None
  role = None
  task_include = None
  use_handlers = False
  variable_manager = None
  loader = None

  load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)


# Generated at 2022-06-11 10:15:23.344576
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """Testing load_list_of_tasks with a basic task list."""
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.playbook.task import Task

    class MockPbExecutor:
        def __init__(self, loader, inventory, variables, verbosity):
            self.loader = loader
            self.inventory = inventory
            self.variables = variables

# Generated at 2022-06-11 10:15:31.541971
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [dict(action='include_tasks'), dict(action='include_tasks')]
    play = dict()
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)

# Generated at 2022-06-11 10:15:34.738902
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert isinstance(load_list_of_tasks(None, None, None, None, None, None, None, None), list)



# Generated at 2022-06-11 10:15:45.549530
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:15:54.339360
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:16:04.754309
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import os
    import io

    here = os.path.dirname(os.path.realpath(__file__))
    # create a dummy inventory
    test_inventory_path = os.path.join(here, '..', '..', 'inventory', 'test_inventory.yml')
    inventory = InventoryManager(loader=DataLoader(), sources=[test_inventory_path])

    # setup a simple playbook with one task