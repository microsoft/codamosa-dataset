

# Generated at 2022-06-11 10:08:13.692059
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    class FakeVariableManager:
        def get_vars(self, play=None, task=None):
            return {}
    # FIXME: include_role is failing because it is calling path_dwim_relative,
    #        which is not available in this environment

    TASKS_DATA_1 = [
        {
            'action': 'command',
            'name': 'echo "hello from task 1"'
        },
        {
            'action': 'include_tasks',
            'name': '../other_tasks.yml',
            'static': False
        },
        {
            'action': 'include_role',
            'name': '../role_foo',
            'static': False
        }
    ]

# Generated at 2022-06-11 10:08:25.656503
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import os
    import inspect
    import json
    import types
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor

    target_host = "host_to_run"
    # A simple playbook to run tasks in localhost
    playbook_path = "./playbooks/test_playbook/hello.yml"

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='localhost')
    variable_manager = VariableManager()
    play = Play.load(playbook_path, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-11 10:08:33.798101
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.parsing.yaml.objects

    # FIXME: implemet tests

    # TODO: create unit tests with
    #        ansible.parsing.yaml.objects.AnsibleBaseYAMLObject.from_yaml()
    #        ansible.parsing.dataloader.DataLoader.load_from_file()
    #        ansible.parsing.mod_args.ModuleArgsParser.parse()
    #        ansible.playbook.block.Block.load()

    pass


# Generated at 2022-06-11 10:08:42.308881
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    class TestPlay():

        class TestBasedir():

            def __init__(self, string):
                self._basedir = string

            def __str__(self):
                return self._basedir

        def __init__(self, basedir):
            self._basedir = TestPlay.TestBasedir(basedir)

    class TestLoader():

        def __init__(self, basedir):
            self._basedir = basedir

        def get_basedir(self):
            return self._basedir

        def path_dwim(self, string):
            return os.path.join(self._basedir, string)

        def path_dwim_relative(self, string1, string2, string3):
            return os.path.join(self._basedir, string1, string2, string3)


# Generated at 2022-06-11 10:08:43.113389
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass



# Generated at 2022-06-11 10:08:54.544556
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    #Test "include"
    #Should return TaskInclude object
    test1 = load_list_of_tasks([{"include": "test1.yml"}])
    assert(isinstance(test1[0], TaskInclude))
    #Should return a list containing a TaskInclude if there are other tasks
    test2 = load_list_of_tasks([{"include": "test2.yml"}, {"not": "include"}])
    assert(isinstance(test2[0], TaskInclude))
    assert(isinstance(test2[1], Task))
    #Should return a list containing a TaskInclude when the list is nested
    test3 = load_list_of_tasks([[{"include": "test3.yml"}]])
    assert(isinstance(test3[0], TaskInclude))
    #Should return

# Generated at 2022-06-11 10:09:06.165712
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.playbook.task import Task
    from ansible.utils.display import Display
    global display
    display = Display()
    task_list = load_list_of_tasks([None])
    assert isinstance(task_list, list), "Should return a list"
    assert len(task_list) == 0, "Should return an empty list"
    data = [{'name': 'a', 'b': 'c'}, {'name': 'd', 'e': 'f'}]
    task_list = load_list_of_tasks(data)
    assert isinstance(task_list, list), "Should return a list of objects"

# Generated at 2022-06-11 10:09:17.948888
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    # C.DEFAULT_HANDLER_EXECUTION_ROUTINE = 'run_once'

    variable_manager = VariableManager()
    loader = DataLoader()

    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ls')),
                dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
            ]
        )
    play = Play.load(play_source, variable_manager=variable_manager, loader=loader)
    task_

# Generated at 2022-06-11 10:09:29.709686
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    dl = DataLoader()
    inventory = InventoryManager(loader=dl, sources=[])
    play_context = PlayContext()
    vm = VariableManager(loader=dl, inventory=inventory, play_context=play_context)

    tokens = [
        RoleInclude(name="apache"),
        RoleInclude(name="tomcat"),
    ]


# Generated at 2022-06-11 10:09:36.275957
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    import json
    import ansible.utils.template as template
    import ansible.utils.path as path


# Generated at 2022-06-11 10:09:50.842608
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    display = Display()
    display.display("Hi!")


# Generated at 2022-06-11 10:10:00.601014
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.manager import DefaultVars
    from ansible.cli.playbook import PlaybookCLI
    from ansible.playbook.play import Play
    from ansible.errors import AnsibleParserError
    from ansible.plugins.loader import action_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    # AnsibleContext has

# Generated at 2022-06-11 10:10:14.135621
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
        {"hosts": "all", "tags": 2},
        {"hosts": "all", "tags": [1, 2, 3]},
    ]

    class Loader:
        pass

    class Play:
        pass

    class Block:
        pass

    class VariableManager:
        def get_vars(self, play, task):
            return {'test': 'success'}

    class Task:
        pass

    class TaskInclude:
        pass

    class Handler:
        pass

    loader = Loader()
    play = Play()
    play.variable_manager = VariableManager()
    block = Block()
    role = 'role'
    task_include = TaskInclude()
    variable_manager = VariableManager()


# Generated at 2022-06-11 10:10:24.509657
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display

    display = Display()
    inventory = InventoryManager(loader=DataLoader(), sources='/test/ansible/hosts')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

# Generated at 2022-06-11 10:10:37.465455
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''Test load_list_of_tasks function'''
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block

    ds = [{'include_role': {'name': 'test'}}]

    role = 'test'
    task_include = False
    use_handlers = False
    variable_manager = True
    loader = True

    result = load_list_of_tasks(ds, None, None, role, task_include, use_handlers, variable_manager, loader)
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.role_include import IncludeRole

    assert(isinstance(result, list))
    assert(isinstance(result[0], IncludeRole))

# Generated at 2022-06-11 10:10:42.328735
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # These are tests for the function load_list_of_tasks.  They are broken
    # into two parts and the second part depends on the results of the first
    # part to be completely correct.  The first part tests creation of
    # each task type and the second part tests validation of the arguments
    # for each task.  The second part tests both that the task got created
    # correctly by the first part and also that the validation of the arguments
    # is done correctly.

    #########################################################################
    # The following is part one of the test.  It verifies the correct
    # creation of the tasks.
    #########################################################################

    # Load module_utils/basic.py.  This is needed for parsing of the
    # arguments for most tasks.
    import ansible.module_utils.basic

    # Fake a play

# Generated at 2022-06-11 10:10:52.527519
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible.playbook.task
    import ansible.playbook.task_include
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping


# Generated at 2022-06-11 10:11:04.274499
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole

    context = PlayContext()
    play = Play().load({}, variable_manager=None, loader=None)
    list_of_tasks = load_list_of_tasks([{}, {'block': {}}], play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert isinstance(list_of_tasks, list)
    assert len(list_of_tasks) == 2
    assert isinstance(list_of_tasks[1], IncludeRole)



# Generated at 2022-06-11 10:11:13.652472
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from __main__ import display
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.handler import Handler
    from ansible.playbook.role_include import IncludeRole

    fake_loader = DictDataLoader({})

    fake_inventory = InventoryManager(loader=fake_loader, sources=[])


# Generated at 2022-06-11 10:11:24.858345
# Unit test for function load_list_of_roles

# Generated at 2022-06-11 10:11:53.846267
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task_include import TaskInclude

    ds = [{
        'include_tasks': {
            'name': 'test.yml',
            'static': True
        }
    }]

    mock_loader = MagicMock()
    mock_loader.path_dwim.return_value = 'test.yml'
    mock_loader.list_directory.return_value = 'test.yml'
    mock_loader.load_from_file.return_value = [{'debug': 'test'}]
    mock_play = MagicMock()

    variable_manager = Variable

# Generated at 2022-06-11 10:12:04.765270
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    _test_data = [
        {'include_tasks': 'hello_world.yml'},
        {'include_role': {'name': 'webservers'}},
        {'name': 'this is a task'},
        {'import_tasks': 'hello_world.yml'},
        {'import_role': {'name': 'webservers'}}
    ]

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    # load the data, passing in test=True to bypass actually loading the data,
    # as it is not needed for this unit test

    ds = AnsibleLoader(None, variable_manager=None, loader=None).load(_test_data)

# Generated at 2022-06-11 10:12:13.442139
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    data = [{"name": "test_task"}]
    class fakeObj(object):
        def __init__(self, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None):
            self.play = play
            self.block = block
            self.role = role
            self.task_include = task_include
            self.use_handlers = use_handlers
            self.variable_manager = variable_manager
            self.loader = loader
        def load(self):
            return self
    # create a fake class to load
    Task = fakeObj
    # test good data and see if the output is good

# Generated at 2022-06-11 10:12:25.972590
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    parser = argparse.ArgumentParser(description='Process some integers.')
    parser.add_argument('--debug', dest='debug', action='store_true', help='enable debug output')
    parser.add_argument('--diff', dest='diff', action='store_true', help='enable diff output')
    (args, remaining_args) = parser.parse_known_args()

    loaders = []

    '''
    FIXME: need to add tests for this... see #1595
    if args.connection:
        if args.connection != 'local':
            loaders.append(DataLoader())
    '''

    # create the variable manager, which will be shared throughout
    # the code, ensuring a consistent view of global variables
    variable_manager = VariableManager()

# Generated at 2022-06-11 10:12:36.338672
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
     from ansible.playbook.task import Task
     from ansible.playbook.role_include import IncludeRole
     from ansible.playbook.handler import Handler
     from ansible.playbook.play_context import PlayContext

     ds_list = []
     for ds_type in (Task, IncludeRole, Handler):
         ds_list.append({'action': ds_type.__name__.lower(), 'name':
                        'foo'})
 
     task_list = load_list_of_tasks(ds_list, play=None, block=None,
                                    role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
     
     assert len(task_list) == 3
     for task_object in task_list:
         assert task_object._

# Generated at 2022-06-11 10:12:46.505901
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    host_list = [
        {
            'hostname': '133.133.135.13',
            'port': '22',
            'username': 'root',
            'password': '123456'
        },
        {
            'hostname': '133.133.135.14',
            'port': '22',
            'username': 'root',
            'password': '123456'
        },
        {
            'hostname': '133.133.135.15',
            'port': '22',
            'username': 'root',
            'password': '123456'
        },
    ]

# Generated at 2022-06-11 10:12:58.061325
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=[]))

    play_context = PlayContext()
    play_context._task_vars = {}
    variable_manager.set_play_context(play_context)


# Generated at 2022-06-11 10:13:07.731273
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C


# Generated at 2022-06-11 10:13:17.612319
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')

    variable_manager = VariableManager()

    variable_manager.set_inventory(inventory)

    block_list = [{
        'block': [{
            'name': 'test1',
            'connection': 'local',
            'hosts': 'localhost',
            'any_errors_fatal': 'yes',
            'gather_facts': 'no'
        },
        {
            '_hostname': 'test1',
            'include_tasks': {
                'static': True,
                '_raw_params': 'test.yml'
            }
        }]
    }]


# Generated at 2022-06-11 10:13:28.405816
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # some basic tests here, could be expanded further
    ds = yaml.load("""
    - debug: msg="hello world"
    - debug: msg="hello world"
    """)
    assert(not isinstance(load_list_of_tasks(ds, play=None, block=None, role=None, task_include=None)[0], TaskInclude))
    assert(not isinstance(load_list_of_tasks(ds, play=None, block=None, role=None, task_include=None)[1], TaskInclude))

    ds = yaml.load("""
    - include: stuff
    - debug: msg="hello world"
    """)

# Generated at 2022-06-11 10:14:05.169718
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    set_loader()
    set_project_library()
    set_inventory()
    set_playbook_path()
    set_builtin_library()
    set_action_plugin_path()
    set_lookup_plugin_path()
    set_filter_plugin_path()
    set_test_module_path()
    set_module_utils_path()
    set_connection_plugin_path()
    set_shell_plugin_path()
    set_callback_plugin_path()
    set_vars_plugins_path()
    set_action_plugins_path()
    set_cache_plugin_path()
    set_filter_plugins_path()
    set_terminal_plugin_path()
    set_test_paths()
    set_deprecation_warnings()
    set_log_path()


# Generated at 2022-06-11 10:14:13.919017
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole

    class FakeInput(object):
        class FakeOptions(object):
            def __init__(self, run_handlers):
                self.run_handlers = run_handlers

        def __init__(self, run_handlers=True):
            self.options = self.FakeOptions(run_handlers)

        class FakeLoadedData(object):
            def __init__(self, data):
                self.data = data


# Generated at 2022-06-11 10:14:14.366130
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass



# Generated at 2022-06-11 10:14:19.757391
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    tasks = [{'name':'task1'}, {'name':'task2'}]
    play = {"name": "testing one"}
    role = {"name": "testing two"}
    task_include = {"name": "testing three"}
    use_handlers = True
    variable_manager={"name": "testing four"}
    loader = {"name": "testing five"}
    block = {"name": "testing six"}

    assert isinstance(load_list_of_tasks(tasks, play, block, role, task_include, use_handlers, variable_manager, loader), object)

# Generated at 2022-06-11 10:14:28.793165
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play

    # TODO: how to test this method with no input value?

# Generated at 2022-06-11 10:14:39.862474
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    class FakeAnsibleOptions:
        def __init__(self, connection='local', forks=10, become=False, become_user=''):
            self.connection = connection
            self.forks = forks
            self.become = become
            self.become_user = become_user

    fake_opts = FakeAnsibleOptions()
    fake_play = Play()
    fake_play.name = "fake_play"
    fake_play.connection = "local"
    fake_play.become = False
    fake_play.become_user = "root"
    fake_play.no_log = False
    fake_play.force_handlers = False
    fake_play.serial = 1

    # Generate the list of roles to load

# Generated at 2022-06-11 10:14:52.858470
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    play = None
    loader = None
    variable_manager = None

    def mock_return_value(*args, **kwargs):
        return [object()]


# Generated at 2022-06-11 10:15:00.597271
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import os
    import sys
    import tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackBase
    from ansible.errors import AnsibleParserError

    inventory = InventoryManager(Loader=DataLoader())

    dummy_args = object()

# Generated at 2022-06-11 10:15:04.998169
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Tests that load_list_of_roles() works properly
    """


# Generated at 2022-06-11 10:15:19.156873
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    ansible_config_path = "../test/units/ansible.cfg"
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._fact_cache = dict()
    variable_manager._extra_vars = dict()
    variable_manager._vars_cache = {
        "playbook_dir": os.getcwd(),
        "inventory_dir": os.getcwd(),
        "inventory_dirname": os.getcwd(),
    }
    variable_manager._options_vars = dict()
    variable_manager._

# Generated at 2022-06-11 10:16:21.523783
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Inputs
    data_structure = {'name': 'Say Hello', 'action': {'module': 'shell', 'args': 'echo Hello'}}

    # Mock objects
    play = mock.MagicMock()
    block = mock.MagicMock()
    role = mock.MagicMock()
    task_include = mock.MagicMock()
    use_handlers = mock.MagicMock()
    variable_manager = mock.MagicMock()
    loader = mock.MagicMock()

    # Actual call
    rtn_task_list = load_list_of_tasks([data_structure],
                                       play,
                                       block,
                                       role,
                                       task_include,
                                       use_handlers,
                                       variable_manager,
                                       loader)

    # Assertions

# Generated at 2022-06-11 10:16:30.720458
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
  # Load yaml file
  file = open('test.yaml', encoding='utf-8')
  filecontent = file.read()
  file.close()
  data = yaml.load(filecontent)

  # Initialize
  play = ansible.playbook.play.Play.load(data, variable_manager=ansible.vars.VariableManager())
  role=None
  task_include=None
  use_handlers=False
  variable_manager=vars.VariableManager()
  loader=None
  block=None

  # Load list
  load_list_of_tasks(data, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=vars.VariableManager(), loader=None)



# Generated at 2022-06-11 10:16:41.186871
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    assert isinstance(load_list_of_tasks([{u'block': [{u'local_action': {u'args': {u'_raw_params': u'test', u'_uses_shell': False}, u'module': u'command'}}, {u'local_action': {u'args': {u'_raw_params': u'test2', u'_uses_shell': False}, u'module': u'command'}}], u'block': [{u'local_action': {u'args': {u'_raw_params': u'test', u'_uses_shell': False}, u'module': u'command'}}]}], None, None), list)

# Generated at 2022-06-11 10:16:51.641601
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import unittest
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.executor.playbook_executor import PlaybookExecutor

    class TestInventoryManager(InventoryManager):
        pass

    class TestLoader(DataLoader):
        pass

    class TestVariableManager(VariableManager):
        pass

    class TestActionLoader(action_loader.ActionModuleLoader):
        pass


# Generated at 2022-06-11 10:17:03.295433
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:17:06.787888
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    blocks = [{'block':['task3', 'task4']}, {'block':['task1', 'task2']}]
    blocks = load_list_of_blocks(blocks, 'play')
    print(blocks[0].block)


# Generated at 2022-06-11 10:17:07.818834
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # https://docs.python.org/2/library/unittest.html#unittest.TestCase.assertRaises
    pass

# Generated at 2022-06-11 10:17:09.363361
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Unit test for function load_list_of_tasks
    '''
    pass

# Generated at 2022-06-11 10:17:14.813979
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    display.verbosity = 3

    plugin_loader = C.load_plugin_loader()
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])


# Generated at 2022-06-11 10:17:23.164850
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler

    role1 = Role.load({'name': 'role1'}, variable_manager=dict(), loader=dict())
    role2 = Role.load({'name': 'role2'}, variable_manager=dict(), loader=dict())
