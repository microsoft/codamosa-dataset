

# Generated at 2022-06-11 10:08:41.197755
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Basic test of function load_list_of_tasks
    '''
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.six import StringIO
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole

# Generated at 2022-06-11 10:08:52.787297
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_playbook_path = os.path.join(os.getcwd(), 'test/unit/fixtures/test_playbook.yml')
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=test_playbook_path)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-11 10:08:55.604059
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    ansible.playbook.play_context.PlayContext unit test stubs
    '''
    pass



# Generated at 2022-06-11 10:09:06.840032
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:09:07.706300
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Placeholder for future unit test
    pass



# Generated at 2022-06-11 10:09:08.713319
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass



# Generated at 2022-06-11 10:09:21.675761
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass
#    #import yaml
#    #from ansible.playbook.play_context import PlayContext
#    #from ansible.playbook.play import Play
#    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
#
#    data = {
#        'variables': dict(
#            var1=1,
#            var2='string',
#        ),
#    }
#    play_context = PlayContext()
#    play_context.become = True
#    play_context.become_user = 'user'
#    play_context.port = 1
#    play_context.remote_user = 'remote'
#    play_context.remote_addr = 'remote_addr'
#    play_context.connection = 'connection'
#    play_

# Generated at 2022-06-11 10:09:31.996553
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.clean import cleanup_needs_template
    from ansible.vars.clean import get_exclude_params
    from ansible.vars.clean import strip_internal_keys
    use_handlers = False

# Generated at 2022-06-11 10:09:41.996607
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_dir = os.path.dirname(os.path.dirname(__file__))
    test_file_path = os.path.join(test_dir, "test_data/test_load_list_of_tasks_data.yml")
    # Read the test data file
    variables = {"inventory_hostname": "localhost"}
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=DataLoader()))
    variable_manager.set_nonpersistent_facts({"test_var": "test_var"})
    variable_manager.extra_vars = {"test_extra_var": "test_extra_var"}
    variable_manager.set_host_variable(Host("localhost"), "test_host_var", "test_host_var")
    variable_manager.set_

# Generated at 2022-06-11 10:09:52.609979
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import yaml
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {}
    variable_manager.options_vars = {}

    play_context = PlayContext()
    play = {}
    block = {}


# Generated at 2022-06-11 10:10:21.835481
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    import ansible.constants as C
    # NOTE: The list of tasks or blocks to create is returned in order.
    ds = [dict(action='action', args={'hello': 'world'}),
          dict(block=dict(tasks=[dict(action='action2', args={'brah': 'ma'})]))]
    play = None
    block = None
    role = None
    task_include = None
   

# Generated at 2022-06-11 10:10:33.519851
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # the playbook data structure
    ds = [
      { "block": [
          {"local_action": {'module': 'test', 'args': {'_test_arg': 1}}},
          {"local_action": {'module': 'test', 'args': {'_test_arg': 2}}}
        ]}
    ]
    # the playbook object
    play = Play().load({}, variable_manager=VariableManager(), loader=DictDataLoader())
    assert play
    # Test with block and role set to None
    tl = load_list_of_tasks(ds, play=play, block=None, role=None, task_include=None,
                            use_handlers=None, variable_manager=VariableManager(), loader=DictDataLoader())
    # Check that returned list is equal to the list

# Generated at 2022-06-11 10:10:45.842085
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # We need to mock up the key objects that load_list_of_tasks uses, so
    # we'll create them and patch them in

    play_block = mock.Mock(spec=Block)
    role_block = mock.Mock(spec=Role)

    # We also need to mock up a TaskInclude object, so we'll use a MagicMock
    # to do so:
    task_include = mock.MagicMock(spec=TaskInclude)
    task_include.statically_loaded = False
    task_include.all_parents_static = mock.Mock(return_value=True)
    task_include.tags = []


# Generated at 2022-06-11 10:10:54.084463
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # I've copied the method, so I need to trick the method to think it's running from a playbook
    class DummyPlay:
        def __init__(self):
            self.hosts = "all"
            self.post_validate = lambda x: x

        class _variable_manager:
            def __init__(self):
                self.extra_vars=None

            def get_vars(self, play=None, task=None, include_hostvars=True, include_delegate_to=True):
                return dict()

    # this is the raw data before it's been loaded by the function

# Generated at 2022-06-11 10:11:07.011729
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import json
    import sys
    import ansible.constants
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.task_include
    import ansible.playbook.block

    from ansible.compat import PY3

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    if PY3:
        unicode = str

    display.verbosity = 3

    res = load_list_of_blocks([], play=None, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert res == []


# Generated at 2022-06-11 10:11:15.733104
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Input DS
    ds = [{'action': 'test', 'register': 'test_result'}]

    # Mock Variables
    display = MagicMock()
    display.deprecated = MagicMock()
    display.warning = MagicMock()
    display.vv = MagicMock()

    class TestModuleArgsParser():
        def __init__(self):
            self.action = 'test'
            self.param = '1'
            self.delegate_to = None

        def parse(self, *args, **kwargs):
            return self.action, self.param, self.delegate_to


    class TestTaskInclude():
        def __init__(self, static=True):
            self.all_parents_static = MagicMock(return_value=static)

# Generated at 2022-06-11 10:11:26.788056
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager = VariableManager(loader=loader, inventory=inventory_manager)
    task_list = load_list_of_tasks(
        [
            {
                'include_role': {
                    'import_playbook': 'deploy_config_apps.yml',
                    'import_playbook_role': 'apps'
                }
            }
        ],
        loader=loader, variable_manager=variable_manager)
    assert len(task_list) == 1, "This should be a list of length 1"
    task = task_list[0]

# Generated at 2022-06-11 10:11:38.747898
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # because these are executed in the same context, they can't be in the same file
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # NOTE: This test parses the raw YAML representation of the tasks
    #       It does not test any of the logic inside the parsing modules themselves

    # This is the same data to test for for each task type, set in lists for iterating.
    # tag_name: [include_comment, task_list, expected_results]
    # expected_results is a tuple of (expected_result, expected_module)

# Generated at 2022-06-11 10:11:45.690739
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    display.verbosity = 2

    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role import Role
    ds = dict(
        name = 'test_playbook_loading',
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(
                include_role = dict(
                    name = 'include',
                ),
                static = 'yes',
            ),
        ],
    )

# Generated at 2022-06-11 10:11:56.926444
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude


# Generated at 2022-06-11 10:12:33.015698
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C

    variable_manager = VariableManager()
    loader = DataLoader()
    play_context = PlayContext()
    inventory = InventoryManager(loader=loader, sources=[C.DEFAULT_HOST_LIST])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    ds = """
    - name: Testing list of tasks
      hosts: localhost
      tasks:
        - name: display a message
          debug:
            msg: Greetings from Ansible!
        - name: do something
          copy:
            src: file1
            dest: /tmp/file2
    """
    ds = yaml.safe

# Generated at 2022-06-11 10:12:40.149068
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    def _task_ds_factory(block=False, use_handlers=False, raw_params=None, delegate_to=None, loop=None, loop_with=None, until=None, retries=None, register=None, ignore_errors=None,
                         only_if=None, when=None, async_=None, async_poll=None, poll=None, action=None, tags=None, when_file=None, changed_when=None, failed_when=None,
                         include_role=None, import_role=None, import_tasks=None, include_tasks=None, role=None, role_path=None, run_once=None, role_name=None):
        task_ds = dict()

        if block:
            task_ds['block'] = 'block_body'


# Generated at 2022-06-11 10:12:51.368619
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    def assert_tasks(tasks,assert_tasks_list):
        assert_task_list=[]
        for task in tasks:
            assert_task_list.append(task.action)
        assert assert_task_list == assert_tasks_list

    example_tasks=[]
    example_tasks.append({'block':[{'debug':{'msg':'test'}}]})
    example_tasks.append({'import_role': {'name': 'test'}})
    example_tasks.append({'include_role': {'name': 'test'}})
    example_tasks.append({'set_fact': {'error_msg': 'test'}})
    example_tasks.append({'fail': {'msg': '{{ error_msg }}'}})

    #assert Block load

# Generated at 2022-06-11 10:13:02.781716
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """
    run test cases for load_list_of_tasks
    """

    # TODO: Create valid data structures for testing instead of None
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None


# Generated at 2022-06-11 10:13:10.010805
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # load_list_of_tasks(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    # this function need at least argument ds
    # ds should be a list of task datastructures (parsed from YAML)
    import ansible
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    from ansible.playbook import Play, Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block


# Generated at 2022-06-11 10:13:20.352395
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role

    vars = dict(
        foo=dict(
            bar='baz'
        )
    )

    play_source = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls')),
            dict(action=dict(module='shell', args='whoami')),
        ]
    )

    play = Play().load(play_source, variable_manager=None, loader=None)
    blocks = load_list_of_blocks(play_source.get('tasks'), play=play, parent_block=None, role=Role(), variable_manager=None, loader=None)
    assert len(blocks)

# Generated at 2022-06-11 10:13:31.612648
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from collections import namedtuple
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.vars import combine_vars

    ds = [{'block': [{'set_fact': {'x': 'y'}}]},
          {'block': [{'set_fact': {'a': 'b'}}]},
          {'include_role': {'name': 'foo'}, 'static': True},
          {'include_tasks': 'bar'}]

    task_list = load_list_of_tasks(ds)
    assert len(task_list) == 4

    assert isinstance(task_list[0], Task)

# Generated at 2022-06-11 10:13:42.778373
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # test case 1:
    # create task dict and block dict
    block_ds = dict(block=dict(rescue=[dict(action=dict(module="noop")), dict(action=dict(module="noop"))]))
    task_ds = dict(action=dict(module="noop"))
    ds = [block_ds, task_ds]

    # create a play and variable manager

    try:
        variable_manager = VariableManager()
        variable_manager.extra_vars = load_extra_vars(loader=None, options=None)

    except:
        pass


# Generated at 2022-06-11 10:13:43.975260
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # FIXME: Need to add a unit test or remove the function
    pass


# Generated at 2022-06-11 10:13:46.681759
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # test for pre checks.
    assert load_list_of_tasks(None, None, block=None, role=None, task_include=None, use_handlers=None, variable_manager=None, loader=None) == None



# Generated at 2022-06-11 10:14:59.516452
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Unit test for function load_list_of_tasks
    '''
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    # Basic test, not handling any include type
    yaml_text = '''
    - ping:
    '''
    task_ds = yaml.safe_load(yaml_text)
    task_list = load_list_of_tasks([task_ds], None, None, None, None, False, None, None)
    assert isinstance(task_list[0], Task)
    assert task_list[0].action == 'ping'
    assert task_list[0].args == {}


# Generated at 2022-06-11 10:15:13.764007
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    play_source = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'),
                 register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    )
    loader = DictDataLoader({"/etc/ansible/roles/role_under_test/tasks/main.yml":
                                yaml.dump(play_source)})
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 10:15:24.379175
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    # Create test inventory

# Generated at 2022-06-11 10:15:25.559557
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True



# Generated at 2022-06-11 10:15:39.372344
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    ds = [
        {'block': 'block_name',
        'tasks': [
            {},
            {},
            ]
        },
        {'dummy': 'dummy1'},
        {'dummy': 'dummy3'},
    ]

    task_list = load_list_of_tasks(ds, 'play_obj', 'block_obj', 'role_obj', 'task_include_obj', False, None, None)
    assert isinstance(task_list, list)
    assert len(task_list) == 1
    assert isinstance(task_list[0], TaskInclude)

    task_list = load_list

# Generated at 2022-06-11 10:15:44.819622
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # FIXME: probably not the best way to unit test this, but it's better than nothing
    from collections import namedtuple
    Task = namedtuple('Task', ['action'])
    tasks = load_list_of_tasks([Task('ping')], None)

    assert len(tasks) == 1
    assert tasks[0].action == 'ping'



# Generated at 2022-06-11 10:15:47.716126
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    (ds, play, block) = (None, None, None)
    print(load_list_of_tasks(ds, play, block))


# Generated at 2022-06-11 10:15:48.289094
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass


# Generated at 2022-06-11 10:15:57.556930
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    def test(list_of_tasks, expected_result):
        try:
            actual_result = load_list_of_tasks(list_of_tasks)
        except Exception as e:
            actual_result = str(e)
            print('Exception:')
            traceback.print_exc()
        if type(expected_result) is str:
            assert type(actual_result) is str
            assert actual_result == expected_result
        else:
            assert type(actual_result) is list
            for i in range(len(actual_result)):
                assert type(actual_result[i]) is expected_result[i]

    failed_message = 'list of task'

    # test with empty list
    test([], [])

    # test with a list having only one task

# Generated at 2022-06-11 10:16:08.104822
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.color import stringc
