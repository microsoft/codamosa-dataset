

# Generated at 2022-06-11 10:08:09.714673
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert False, "This function hasn't been tested yet"

# Generated at 2022-06-11 10:08:22.481183
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    import ansible.playbook.play
    from ansible.playbook.role import Role
    from ansible.utils.vars import load_extra_vars
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.context import CLIContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.errors import AnsibleError

    loader = AnsibleLoader(None, true_sentinels=True, file_loader_cls=None)
    tqm = None

# Generated at 2022-06-11 10:08:34.121463
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    ds = [{'name': 'test', 'debug': 'msg={{test}}'}]
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._extra_vars = combine_vars(loader=loader, variables=(), templar=variable_manager._templar)
    variable_manager.get_vars()

# Generated at 2022-06-11 10:08:42.463108
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    con = ConfigParser()
    con.read('ansible.cfg')
    ds = con.items('defaults')

# Generated at 2022-06-11 10:08:43.224243
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:08:54.651934
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
        {"include_tasks": "file"},
        {"shell": "echo hello"},
        {"include_tasks": "other_file"},
        {"block": [
            {"include_tasks": "nested_file"},
            {"include_role": "file"},
            {"include_role": "other_role"}
        ]},
        {"include_role": "another_other_role"},
        {"include_role": "yet_another_other_role"},
        {"include_tasks": "yet_another_file"}
    ]

    #def load_list_of_tasks(ds, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None):

    block = None
    role = None
    task_include = None
    use_

# Generated at 2022-06-11 10:09:06.209847
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    class Sample():
        def __init__(self, name=None, action=None, args=None, delegate_to=None, delegate_facts=None, ignore_errors=None, loop_control=None, no_log=None, notify=None, async_val=None, poll=None, until=None, retries=None, register=None):
            self.name = name
            self.action = action
            self.args = args
            self.delegate_to = delegate_to
            self.delegate_facts = delegate_facts
            self.ignore_errors = ignore_errors
            self.loop_control = loop_control
            self.no_log = no_log
            self.notify = notify

# Generated at 2022-06-11 10:09:18.002171
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:09:20.685423
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks([dict(action='test'), dict(action='test')], None, None, None)

# Generated at 2022-06-11 10:09:22.827835
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    if __name__ == '__main__':
        unittest.main()

import unittest


# Generated at 2022-06-11 10:09:44.800843
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars


    loader = DataLoader()

# Generated at 2022-06-11 10:09:54.523774
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Here, if the function throws an exception, the test will fail.
    # If the function does not throw any exceptions, the test is considered a success.
    # This example shows an exception being thrown, but it is not the only way to handle testing.
    test_function = load_list_of_tasks
    # define test input

# Generated at 2022-06-11 10:09:57.787553
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    try:
        load_list_of_blocks()
    except TypeError as e:
        assert 'missing 5 required positional arguments:' in to_native(e)
    print("load_list_of_blocks appears to work")


# Generated at 2022-06-11 10:10:09.710688
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Play, Task
    from ansible.inventory import Inventory
    loader = DictDataLoader({
        '/etc/ansible/roles/test_role/tasks/main.yml': yaml.safe_dump(
            dict(
                tasks=[
                    dict(action=dict(module='debug', args=dict(msg='I am a debug message'))),
                ],
            ),
            default_flow_style=False,
        )
    })
    task_ds = [
        dict(
            include=dict(
                module='role',
                name='test_role',
                tasks_from='main.yml'
            ),
        ),
    ]
    inventory = Inventory(loader=loader, host_list=[])

# Generated at 2022-06-11 10:10:22.053764
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import ansible.constants as C

    test_dir = os.path.dirname(os.path.realpath(__file__))
    dslist = [
        {'role': 'mytestcollect.mytestrole1', 'name': 'test1'},
        {'role': 'mytestcollect.mytestrole2', 'name': 'test2'},
        {'role': 'mytestrole3', 'name': 'test3'}
    ]
    loader = DataLoader()
    collection_search_list = C.COLLECTIONS_PATHS + [os.path.join(test_dir, 'test_roles')]

# Generated at 2022-06-11 10:10:33.966517
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext

    # prepare test data
    ds = [
        dict(
            name='task_1',
            include='task_1.yml',
            block=dict(
                name='task_2',
                include='task_2.yml',
                block=dict(
                    name='task_3',
                    include='task_3.yml'
                )
            )
        ),
    ]
    play = Play().load({})
    play._role = Role()
    play._dependent_role = Role()
    play.vars_prompt = dict()
    play.vars_files = list()
    play.vars_from_files = list()
    play._variable_manager = VariableManager()
   

# Generated at 2022-06-11 10:10:41.011325
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = [
        {
            "action": {
                "block": "TODO",
            }
        },
        {
            "action": {
                "block": "TODO",
            }
        },
        {
            "action": {
                "not_block": "TODO",
            }
        },
    ]
    assert(load_list_of_tasks(task_ds))



# Generated at 2022-06-11 10:10:51.740305
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.playbook.playbook_include import IncludeRole

    ds1 = [
        {
            'include': 'some.yaml',
            'loop_control': {'loop_var': 'item'},
            'static': True},
        {'include': 'some.yaml',
         'loop_control': {'loop_var': 'item'},
         'static': False},
        {'include': 'some.yaml'},
        {'block': [{'include': 'some.yaml'}]},
        {'include': 'some.yaml',
         'loop_control': {'loop_var': 'item'}}]

# Generated at 2022-06-11 10:11:04.198105
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from collections import namedtuple
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    
    Block = namedtuple("Block", ["name", "tasks", "handlers", "rescue", "always"])
    Params = namedtuple("Params", ["roles", "tasks", "handlers", "block"])
    

# Generated at 2022-06-11 10:11:10.214170
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
        {'block': [
            {'tasks': [
                {'debug': {'msg': 'test'}}
            ]}
        ]},
        {'debug': {'msg': 'test2'}},
        {'debug': {'msg': 'test3'}}
    ]
    assert len(load_list_of_tasks(ds, None, None, None, None, False, None, None)) == 3

# Generated at 2022-06-11 10:11:33.665386
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Test load_list_of_tasks
    '''
    task_ds = [
        {
             "name": "test_load_list_of_tasks_name",
             "action": {
                 "module": "test_load_list_of_tasks_module",
                 "args": "test_load_list_of_tasks_args"
             }
        },
    ]
    play = None
    block = None
    role = 'role'
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None


# Generated at 2022-06-11 10:11:39.735507
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks(
        ds=[
            {'action': 'shell', 'args': {}}
        ],
        play='play',
        block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=None,
        loader=None,
    ) is not None

# Generated at 2022-06-11 10:11:40.715776
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    #TODO
    pass



# Generated at 2022-06-11 10:11:52.992806
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    import ansible.playbook.block
    import ansible.playbook.include
    import ansible.playbook.task
    import ansible.vars.template
    # Create a mock object to stand-in for the ansible.vars.template.AnsibleTemplate
    # object. Use the mock_AnsibleTemplate_cls to create a mock without calling __init__.
    mock_AnsibleTemplate = mock.Mock(spec=ansible.vars.template.AnsibleTemplate)
    mock_AnsibleTemplate.template.return_value = "foo"
    mock_AnsibleTemplate_cls = mock.Mock(spec=ansible.vars.template.AnsibleTemplate, return_value=mock_AnsibleTemplate)

    # To prevent

# Generated at 2022-06-11 10:12:04.011261
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    from ansible.playbook.block import Block

    ds = []

# Generated at 2022-06-11 10:12:13.047063
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    class MockLoader:
        class MockCollection:
            pass
        class MockPlay:
            class MockCollectionSearchList:
                pass
        @staticmethod
        def path_dwim_relative(b, r, t):
            return ''
    d = load_list_of_roles([
        { 'name': 'local' },
        { 'name': 'somewhere_else', 'some_option': 'set' },
        { 'some_option': 'set' }
    ], MockLoader.MockPlay.MockCollectionSearchList)

    assert isinstance(d, list)
    assert isinstance(d[0], RoleInclude)
    assert isinstance(d[1], RoleInclude)
    assert isinstance(d[2], RoleInclude)
    d[0]._validate()
    d[1]._

# Generated at 2022-06-11 10:12:25.462614
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Unit test for function load_list_of_tasks
    '''
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar

    def test_load_list_of_tasks_initializer(self):
        '''
        Test function for load_list_of_tasks class initializer.
        '''
        pass


# Generated at 2022-06-11 10:12:35.042834
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

    ds = [{'include_tasks': 'name'}, {'include_tasks': 'name2', 'static': True}, {'include_role': 'name', 'static': True}, {'notify': 'name'}]

    task_list = load_list_of_tasks(ds, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert len(task_list) == 4

    for task in task_list:
        assert isinstance(task, Block) or isinstance(task, Handler)


# Generated at 2022-06-11 10:12:44.451059
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import vars_loader
    from ansible.template import Templar

    collection_search_list = []

    # Test case with calling play, current_role and variable manager
    role_das = [{"name": "Test-Role", "role1": "role2", "roles": "roles3"}]
    pc = PlayContext()
    vm = VariableManager()
    templar = Templar(loader=None, variables=vm)
    loader = AnsibleFileLoader(None, variable_manager=vm)
    role_list = load_list_of_roles(role_das, pc, current_role_path=None, variable_manager=vm, loader=loader, collection_search_list=collection_search_list)

# Generated at 2022-06-11 10:12:51.423809
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ds = ['myrole']
    play = ansible.playbook.play.Play()
    current_role_path = os.path.join(os.path.expanduser("~"), "tests", "test_playbook", "test.yml")
    variable_manager = ''
    loader = ''
    role_list = load_list_of_roles(ds, play, current_role_path, variable_manager, loader)
    assert len(role_list) == 1



# Generated at 2022-06-11 10:13:12.840492
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    vm = VariableManager()
    display = Display()
    play_context = dict(
        port=2222,
        remote_user='root',
        become=False,
        become_method='sudo',
        become_user='root',
        become_ask_pass=False,
        check=False,
        diff=False,
        verbosity=4,
        tags=['all'],
    )

    # Plays

# Generated at 2022-06-11 10:13:23.649036
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    # Tests that a Block is created when a block is found in the list and that
    # the iterator is advanced in the right place
    tmp_ds = [
        {
            "block": [],
        },
        {
            "block": [],
            "test": "task",
        },
    ]
    class TestPlay:
        pass
    test_play = TestPlay()

# Generated at 2022-06-11 10:13:35.679789
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test with simple task
    task_list = load_list_of_tasks([{'name': 'test name', 'action': 'test action'}], None, None, None, None, False, None, None)
    # check task list
    assert len(task_list) == 1
    assert task_list[0].args['name'] == 'test name'
    assert task_list[0].action == 'test action'

    # Test with simple task with extra spaces
    task_list = load_list_of_tasks([{'name ': 'test name', ' action  ': 'test action'}], None, None, None, None, False, None, None)
    # check task list
    assert len(task_list) == 1
    assert task_list[0].args['name'] == 'test name'

# Generated at 2022-06-11 10:13:39.811158
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    fieldstest = [{"block": "block1", "block2": "block2"}]
    taskstest = [{"action": "action1", "args": "args1"}]
    assert(load_list_of_tasks(fieldstest).length == 1)


# Generated at 2022-06-11 10:13:47.609812
# Unit test for function load_list_of_tasks

# Generated at 2022-06-11 10:13:54.387076
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext

    class MockPlay(object):
        context = PlayContext()

    class MockVariableManager(object):
        def get_vars(self, play=None, task=None, include_hostvars=False, include_delegate_to=False):
            return dict()

    assert load_list_of_tasks([{'include_tasks': 'foo.yml'}], MockPlay(), MockVariableManager(), None) == [{'include_tasks': 'foo.yml'}]



# Generated at 2022-06-11 10:13:56.181482
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """
    Unit test for function load_list_of_tasks

    """
    pass

# Generated at 2022-06-11 10:14:05.637708
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-11 10:14:14.364308
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    def get_vars(self, play=None, task=None):
        return {}

    variable_manager = VariableManager()
    variable_manager.get_vars = types.MethodType(get_vars, variable_manager)
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')

# Generated at 2022-06-11 10:14:20.229103
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources="localhost")
    variable_manager.set_inventory(inventory)
    context = PlayContext()
    play = Play.load(
        dict(
            name="foobar",
            hosts="localhost",
            gather_facts=False,
            tasks=[{"action": {"module": "shell", "args": "ls"}}],
        ),
        variable_manager=variable_manager,
        loader=loader,
    )
    tasks = load

# Generated at 2022-06-11 10:14:53.476717
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    loader = DictDataLoader({
        "roles/tasks/foo.yaml": """
        - debug:
            msg: test task
        """,
        "roles/tasks/bar.yaml": """
        - debug:
            msg: test task
        """,
        "roles/tasks/baz.yaml": """
        - debug:
            msg: test task
        """
    })
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager, host_list=['hostname']))

# Generated at 2022-06-11 10:15:00.905680
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # FIXME: this should be in a unit test framework
    # test import of a list of roles
    # FIXME: this should be in a unit test framework
    # test import of a list of roles
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins import plugin_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    variable_manager._extra_vars = {'test': 100}
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=''))

    play_context = PlayContext()
    play_

# Generated at 2022-06-11 10:15:01.784070
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-11 10:15:15.994937
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    import os
    import sys
    sys.path.append(os.getcwd())
    with open("test/test_vars.yml", "r") as stream:
        try:
            ds = yaml.safe_load(stream)
        except yaml.YAMLError as exc:
            print(exc)
            return
    new_ds=[]
    new_ds.append(ds)
    # data structure
    play = {}
    block = None
    role = None
    task_include = None
    use_handlers=False
    # Load template is set to False because "var_files" config is not present in template

# Generated at 2022-06-11 10:15:21.276142
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    import pytest

    with pytest.raises(AnsibleAssertionError):
        load_list_of_blocks({}, False, None, None, None, False)

    with pytest.raises(AnsibleAssertionError):
        load_list_of_blocks("", False, None, None, None, False)



# Generated at 2022-06-11 10:15:32.862018
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True == load_list_of_tasks(None, None)
    assert False == load_list_of_tasks(None, None)[0].is_static
    assert False == load_list_of_tasks(None, None)[0]._use_handlers
    assert False == load_list_of_tasks(None, None)[0]._evaluate_tags
    assert False == load_list_of_tasks(None, None)[0]._ignore_errors
    assert False == load_list_of_tasks(None, None)[0].always_run
    assert False == load_list_of_tasks(None, None)[0].auto_remove
    assert False == load_list_of_tasks(None, None)[0].become

# Generated at 2022-06-11 10:15:43.634613
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import sys
    sys.path.append('..')
    from modules.setup_module import SetupModule
    from constants import C

    task_ds = {"block": [
        {'block': [{'debug': {'msg': 'something'}}]},
        {'block': [{'debug': {'msg': 'something'}}]},
        {'block': [{'debug': {'msg': 'something'}}]},
    ]}
    # Given a list of task datastructures (parsed from YAML),
    # return a list of Task() or TaskInclude() objects.

    # We import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task

# Generated at 2022-06-11 10:15:53.407417
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = AnsibleLoader(None, None)
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_name = 'play1'

# Generated at 2022-06-11 10:16:03.713863
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Test the data structure returned by load_list_of_tasks() method
    '''

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler


# Generated at 2022-06-11 10:16:15.894731
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole


# Generated at 2022-06-11 10:16:57.643287
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Functionality test for the function load_list_of_tasks
    '''

    # Importing the classes required for testing
    import os
    import inspect

    from ansible.playbook.task import Task

    # Load the class to be tested
    class_to_test = 'load_list_of_tasks'
    module_to_test = __import__('ansible.playbook')
    the_class = getattr(module_to_test, class_to_test)

    # Extract various needed attribute
    test_dir = os.path.dirname(__file__)
    play_data = os.path.join(test_dir, 'test_playbook.yml')

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-11 10:17:07.663770
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    play_context = PlayContext()
    inventory = InventoryManager(loader=DataLoader(), sources="localhost")
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    loader = DataLoader()

    ds = [{'name': 'test', 'debug': 'msg=foo'}]
    play = {}
    block = None
    role = None
    task_include = None
    use_handlers = False
    assert isinstance(load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader), list)

# Generated at 2022-06-11 10:17:08.885892
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks(ds=1, play=None) is None

# Generated at 2022-06-11 10:17:09.778251
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    
    #TODO
    pass

# Generated at 2022-06-11 10:17:16.717180
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # FIXME: the below code does not actually test the function
    import ansible.playbook.play
    import ansible.playbook.role
    from ansible.playbook.task import Task

    p = ansible.playbook.play.Play.load({'name': 'foo', 'hosts': 'all'})
    r = ansible.playbook.role.Role()
    assert load_list_of_tasks([{'action': {'module': 'setup', 'args': ''}}, {'action': {'module': 'debug', 'args': 'msg="{{foo}}"'}}], p, r) == [Task(), Task()]



# Generated at 2022-06-11 10:17:25.882501
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleSequence
    from ansible.playbook.role.definition import RoleDefinition

    loader = DataLoader()
    inventory = Inventory(loader, 'hosts')
    inventory.add_host(Host('host1'))


# Generated at 2022-06-11 10:17:37.455190
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible import constants as C
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template import Templar

    from .fixtures import fixture_loader
    from .fixtures import mock_execute_task
    from .fixtures import mock_unreachable_host

    def test_action_in_all_include_tasks():
        play_source = dict(
            name="Ansible Play",
            hosts='all',
            gather_facts='no',
            tasks=[
                dict(include='/test/test.yml'),
            ],
        )

        play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

        assert play._included_files == ['/test/test.yml']
