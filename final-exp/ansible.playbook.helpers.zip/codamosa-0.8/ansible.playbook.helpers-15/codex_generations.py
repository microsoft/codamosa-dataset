

# Generated at 2022-06-11 10:08:21.436268
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {"greeting": "hello world"}

# Generated at 2022-06-11 10:08:24.341582
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{'include': 'foo'}]
    play = Play()
    block = Block()
    load_list_of_tasks(ds, play, block)

# Generated at 2022-06-11 10:08:36.084613
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    import yaml


# Generated at 2022-06-11 10:08:47.266846
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    ds = dict(
        name='Test Play',
        hosts='hosts',
        vars_files=['file1', 'file2'],
        vars=dict(
            key1='value1',
            key2='value2',
        ),
    )
    play = Play().load(ds, variable_manager=None, loader=None)
    task1 = Task()
    task1.action = 'shell echo task1'
    task2 = Task()
    task2.action = 'shell echo task2'
    task3 = Task()

# Generated at 2022-06-11 10:08:52.734548
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    block_list = load_list_of_blocks([])
    assert not block_list
    block_list = load_list_of_blocks({})
    assert not block_list
    block_list = load_list_of_blocks(Block.load({'foo': 'bar'}))
    assert not block_list


# Generated at 2022-06-11 10:08:56.433631
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    import pytest
    # FIXME: not sure how to reliably test this stuff
    return True



# Generated at 2022-06-11 10:09:07.471182
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    loader = DataLoader()
    hostrecord = Host()

    ds = [{'action': 'ping'}, {'action': 'ping'}]
    task_list = load_list_of_tasks(ds, None, block=None, role=None, task_include=None, use_handlers=False,
                                   variable_manager=VariableManager(loader=loader, host_inventory=Inventory(hosts_list=[hostrecord])))
    assert len(task_list) == 2

    ds = [{'action': 'ping'}, {'action': 'ping'}]

# Generated at 2022-06-11 10:09:20.370685
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    play = Play()
    block = Block()

    # Test an empty ds
    task_ds = []
    res_task_list = load_list_of_tasks(task_ds, play, block, None, None, False, variable_manager, loader)
    assert len(res_task_list) == 0

    # Test a bare task
    task_ds = [{'name': 'test_task', 'action': 'test_action'}]
    res_task_list = load_list_of_tasks(task_ds, play, block, None, None, False, variable_manager, loader)
    assert len(res_task_list) == 1
    assert len(res_task_list[0]._parent) == 1

# Generated at 2022-06-11 10:09:31.207821
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.task_queue_manager import TaskQueueManager

    results = []

    def _record_results(res):
        results.append(res)

    pb = Playbook.load('tests/test_utils/test_load_list_of_tasks', loader=DictDataLoader())
    pb.set_loader(DictDataLoader())
    play = pb.get_plays()[0]

    def _make_callback(task):
        def _inner_callback(*args, **kwargs):
            _record_results(task.get_name())
        return _inner_callback


# Generated at 2022-06-11 10:09:40.816225
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # test_load_list_of_tasks
    from ansible.playbook.play import Play
    # template task
    task_ds = [{'test_module': 'include_role', 'name': 'test_name', 'static': '{{ test_var }}', 'tags': ['test_tag'], 'loop': True}]
    play = Play().load(None, play_ds=None)
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    display.verbosity = 4
    load_list_of_tasks(task_ds, play, block, role, task_include, use_handlers, variable_manager, loader)


# Generated at 2022-06-11 10:10:04.143059
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude


# Generated at 2022-06-11 10:10:18.723123
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible.playbook.role_include
    import ansible.playbook.task_include

    list_tasks = [{"action": "shell", "args": "ls /home"}]
    try:
        load_list_of_tasks(list_tasks, None, None, None, None, None, None, None)
    except AnsibleAssertionError as e:
        assert str(e) == "The ds ([{'action': 'shell', 'args': 'ls /home'}]) should be a list but was a <type 'list'>"
    else:
        raise AssertionError("Should raise AnsibleAssertionError")

    list_tasks = [
        {"action": "shell", "args": "ls /home"},
        {"action": "shell", "args": "pwd"}
    ]


# Generated at 2022-06-11 10:10:26.833331
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{u'block': 0, u'include': u'roles/foo'}, {'block': 5, u'debug': {u'msg': u'test'}}]
    play = Play()
    try:
        load_list_of_tasks(ds, play)
        assert(False)
    except AnsibleAssertionError:
        pass

    ds = ['foo']
    try:
        load_list_of_tasks(ds, play)
        assert(False)
    except AnsibleAssertionError:
        pass

    ds = [{u'include': u'roles/foo'}, {u'debug': {u'msg': u'test'}}]
    tasks = load_list_of_tasks(ds, play)

# Generated at 2022-06-11 10:10:36.908145
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # assert load_list_of_tasks(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    task_list = load_list_of_tasks(ds=None, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert isinstance(task_list, list)
    assert len(task_list) == 0


# Generated at 2022-06-11 10:10:48.516988
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Playbook
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars

    ### Configure the playbook executor ###
    # Specify the inventory
    manager = InventoryManager(loader=DataLoader(), sources=['./hosts'])

    # Specify the variable manager
    variable_manager = VariableManager(loader=DataLoader(), inventory=manager)

    # Set some variables (these would be read in normally from the command line)
    variable_manager.extra_vars = {'hosts': 'webservers'}

    # Create the playbook executor, but don

# Generated at 2022-06-11 10:10:52.157435
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    data = """
- action: test
  args:
    test: value
"""

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.handler import Handler

    results = load_list_of_tasks(data, False)
    assert isinstance(results[0], Handler)



# Generated at 2022-06-11 10:11:04.941687
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.base import Base
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C

    display = Display()
    display.verbosity = 3
    options = ImmutableDict()
    options.connection = 'local'
    options.module_path = None
    options.forks = C.DEFAULT_FORKS
    options.become = False
    options.become_method = 'sudo'
    options.become_user = 'root'
    options.check = False
    options.diff

# Generated at 2022-06-11 10:11:07.225969
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks([]) == []
    assert load_list_of_tasks([{'include': 'blah.yml'}]) == [{'include': 'blah.yml'}]



# Generated at 2022-06-11 10:11:10.680978
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    block = Block(parent_block=None, role=None, task_include=None, use_handlers=False)
    task_list = "[{'block':'hoge'},{'block':'huga'}]"
    load_list_of_tasks(task_list, None, block)
    pass
    return task_list

# Generated at 2022-06-11 10:11:21.294064
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    ds = [{
        'block': [{
            'block': [{
                            'block': [{'ignore_errors': True,
                                       'debug': {'msg': '{{ item }}', 'var': 'item'},
                                       'name': 'first_debug',
                                       'loop': '{{ inner_list }}',
                                       'when': 'foo'}],
                            'name': 'inner_block',
                            'when': 'bar'}],
            'debug': {'msg': '{{ outer_item }}', 'var': 'outer_item'},
            'loop': '{{ outer_list }}',
            'name': 'outer_block',
            'when': 'baz'}]}]
   

# Generated at 2022-06-11 10:11:57.136305
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    #fixtures
    ds = [{'block': '', '_line_number': 2}, {'include_tasks': '', 'loop': '', 'async': '', 'poll': '', 'static': '', 'register': '', 'ignore_errors': '', 'delegate_to': '', 'any_errors_fatal': '', '_line_number': 3}, {'import_role': '', 'loop': '', 'static': '', 'any_errors_fatal': '', 'when': '', 'with_first_found': '', '_line_number': 4}]
    play = object()
    block = object()
    role = object()
    task_include = object()
    use_handlers = False
    variable_manager = object()
    loader = object()

    # do the test
   

# Generated at 2022-06-11 10:11:58.413514
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # FIXME: need tests
    pass

# Generated at 2022-06-11 10:12:09.227707
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role import define_role
    from ansible.plugins.loader import plugin_loader

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import lookup_loader

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    display.verbosity = 3
    current_role_path = '/tmp/test_roles'
    ds = [{'name': 'test-role'}]
    fake_loader = DictDataLoader({})
    # fake_loader = plugin_loader
    fake_inventory = InventoryManager(loader=fake_loader, sources='localhost,')

# Generated at 2022-06-11 10:12:13.241055
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Unit test for function load_list_of_tasks
    '''
    output = load_list_of_tasks(TASK_LIST, TASK_BLOCK)
    assert(len(output) == len(TASK_LIST))



# Generated at 2022-06-11 10:12:25.628888
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    import ansible.parsing.yaml.objects

    # Case 1(no block):
    # Given:
    ds = [
        {'include': 'some_role'},
        {'include': 'some_role'},
        {'include': 'some_role'},
        {'include': 'some_role'},
        {'include': 'some_role'},
        {'include': 'some_role'},
        {'include': 'some_role'},
    ]

    # When:

# Generated at 2022-06-11 10:12:36.131378
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    play_ds = dict(
        name='test_play',
        hosts=['192.168.1.1'],
    )
    variable_manager = VariableManager()
    p = Play().load(play_ds, variable_manager=variable_manager)
    loader = DictDataLoader({})
    localhost = Host(name='localhost')

    task_ds = [
        {'action': 'include', 'static': False, 'args': 'test_task1.yml'},
        {'action': 'import', 'static': True, 'args': 'test_task1.yml'}
    ]

    task_ds_2 = []

# Generated at 2022-06-11 10:12:46.236330
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop


# Generated at 2022-06-11 10:12:57.615006
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # populate the cache (this is normally done by the cli and not unit tests)
    C._ANSIBLE_CACHE = cache.DataCache()
    C._ANSIBLE_CACHE.REMOVE_CACHE = False

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    class FakeLoader(object):
        def __init__(self):
            self.basedir = './'


# Generated at 2022-06-11 10:12:59.285438
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Testing the function load_list_of_tasks
    pass



# Generated at 2022-06-11 10:13:08.366898
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    module = AnsibleModule(
        argument_spec = dict(
            _raw_params = dict(type='list', required=True),
            _uses_handlers = dict(type='bool', required=False, default=False),
            # _parent_block = dict(type='list', required=False),
            # _role = dict(type='list', required=False),
            # _task_include = dict(type='list', required=False),
        ),
        supports_check_mode=True
    )
    test_host = Mock()
    test_host.get_vars = dict()

    play = Play()

    ds = module.params['_raw_params']
    play = play
    use_handlers = module.params['_uses_handlers']
    variable_manager = VariableManager()
    loader = DataLoader

# Generated at 2022-06-11 10:14:25.022602
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
            {
                'action': 'shell',
                'args': 'echo hello',
                'loop': 'item',
                'loop_control': {
                    'loop_var': 'item'
                },
                'register': 'result'
            },
            {
                'action': 'shell',
                'args': 'echo {{ item }}',
                'loop': '{{ result.results }}',
                'loop_control': {
                    'loop_var': 'item'
                },
                'register': 'result'
            }
         ]
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None


# Generated at 2022-06-11 10:14:25.983509
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass


# Generated at 2022-06-11 10:14:28.958357
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    data_struct = {'include_tasks': {'name': 'foo/include.yaml'}}
    t = load_list_of_tasks(data_struct)
    assert t[0].action == 'include_tasks'



# Generated at 2022-06-11 10:14:40.068004
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts import Facts
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.cli import CLI

    action_paths = [
        os.path.join(os.path.dirname(action_loader.__file__), 'actions')
    ]
    action_loader._add_directory(action_paths)


# Generated at 2022-06-11 10:14:53.034435
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    if __name__ =='__main__':
        try:
            from ansible.playbook.play_context import PlayContext
            from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedString
            from ansible.vars.manager import VariableManager
            from ansible.errors import AnsibleParserError
            from ansible.constants import load_extra_vars
            from ansible.inventory.manager import InventoryManager
            from ansible.inventory.host import Host

        except Exception as e:
            raise Exception("To import function load_list_of_tasks, error: %s" % e)

        # TODO: generate test data, especially for blocks
        self.ds = []
        self.ds.append({'name': 'test task'})

# Generated at 2022-06-11 10:15:00.687716
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    play = Play()
    ds1 = dict(action='this_is_a_task')
    ds2 = dict(action='this_is_a_task')
    ds3 = dict(action='this_is_an_include')
    ds4 = dict(action='this_is_a_role_include')
    ds5 = dict(action='this_is_a_role_import')
    ds6 = dict(action='This_should_error')

    def create_list_task():
        task_list = list()
        task_list.append(ds1)


# Generated at 2022-06-11 10:15:08.694768
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    ds = [{'action': 'debug', 'registered': 'reg'}, {'action': 'fail', 'when': "true"}]
    play = {}
    task_list = load_list_of_tasks(ds, play=play)
    print(task_list)
    assert isinstance(task_list[0], Task)
    assert len(task_list) == 2

# Generated at 2022-06-11 10:15:21.628447
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks([]) == []

    # Test with a list of tasks
    assert load_list_of_tasks([{'local_action': {'module': 'debug', 'msg': 'This is a message'}}]) == [{'local_action': {'module': 'debug', 'msg': 'This is a message'}}]

    # Test with a list of tasks and a block (using a list for the block)

# Generated at 2022-06-11 10:15:22.591916
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    data = []
    assert load_list_of_tasks(data, None, None) is not None


# Generated at 2022-06-11 10:15:35.939801
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Loads a list of tasks
    import pytest
    from ansible.inventory.host import Host
    from ansible.inventory.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.template import Templar
    import ansible.constants as C

    # Setup
    C.DEFAULT_LOAD_CALLBACK_PLUGINS = ['dynamic_inventory_test.callback_plugins.test_callback']
    C.DEFAULT_INVENTORY_PLUGINS = ['dynamic_inventory_test.inventory_plugins.test_inventory']
    results = []

# Generated at 2022-06-11 10:16:26.704032
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks.__doc__ == '''
        Given a list of task datastructures (parsed from YAML),
        return a list of Task() or TaskInclude() objects.
        '''

# Generated at 2022-06-11 10:16:34.491602
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
        {"block": "block1", "block_items": []},
        {"name": "task2", "dostuff": "foo"},
        {"name": "task3", "dootherstuff": "bar"}
    ]

    test_list = [{"block": "block1", "block_items": []},
                 {"name": "task2", "dostuff": "foo"},
                 {"name": "task3", "dootherstuff": "bar"}]

    assert load_list_of_tasks(ds, None, None, None, None, None, None, None) == test_list

# Generated at 2022-06-11 10:16:40.622191
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    ds1 = {'include_tasks':'test.yml'}
    ds2 = {'block':[{'block':[{'include_tasks':'test.yml'}]}]}
    ds3 = {'block':[{'include_tasks':'test.yml'}]}
    tasklist = load_list_of_tasks([ds1, ds2, ds3])

# Generated at 2022-06-11 10:16:51.034290
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    class dummy_object(object):
        pass

    ds = [
        {'raw': 'include_tasks: foo.yml', 'action': 'include_tasks', 'args': {'_raw_params': 'foo.yml'}},
        {'raw': 'import_tasks: foo.yml', 'action': 'import_tasks', 'args': {'_raw_params': 'foo.yml'}},
    ]
    play = dummy_object()
    block = dummy_object()
    role = dummy_object()
    task_include = dummy_object()
    use_handlers = False
    variable_manager = dummy_object()
    loader = dummy_object()


# Generated at 2022-06-11 10:16:52.090504
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass


# Generated at 2022-06-11 10:16:54.974049
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print ('Testing function load_list_of_tasks')
    # TODO: Write test for function load_list_of_tasks
    assert 0

# Generated at 2022-06-11 10:16:55.752768
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass



# Generated at 2022-06-11 10:17:06.413888
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # The data structures we expect to be returned by the tasks
    # Note: remove keys added by ansible, like _uuid, etc
    ds_1 = {'include_tasks': 'foo.yaml'}
    ds_2 = {'import_tasks': 'bar.yaml'}
    ds_3 = {'name': 'task',
            'action': {'module': 'shell', 'args': 'echo hi'}}
    ds_4 = {'block': [ds_3]}

    # Fixtures

# Generated at 2022-06-11 10:17:14.901293
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    #import ansible.playbook.task as task
    #import ansible.playbook.handler as handler
    #import ansible.playbook.task_include as task_include
    #import ansible.playbook.role_include as role_include
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.errors import AnsibleParserError
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template import Templar


# Generated at 2022-06-11 10:17:23.239507
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins import module_loader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    import os
    import yaml
    context = PlayContext()
    module_loader.add_directory(os.path.join(os.path.dirname(__file__), '..', '..'))