

# Generated at 2022-06-25 05:14:01.129730
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    # FIXME: This test is not reproducible.
    return

    test_case_0()

# Generated at 2022-06-25 05:14:03.262384
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = list_0 = None
    int_0 = 2048
    var_0 = load_list_of_tasks(float_0, int_0)


# Generated at 2022-06-25 05:14:05.695813
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
  display = Display()
  # print('dictionary is: %s' % str(format_variable('dictionary')))
  # dictionary = load_list_of_tasks(format_variable('dictionary'), format_variable('play'), format_variable('block'), format_variable('role'), format_variable('task_include'), format_variable('use_handlers'), format_variable('variable_manager'), format_variable('loader'))



# Generated at 2022-06-25 05:14:15.186658
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Task empty list
    ds = list()
    task_list = load_list_of_tasks(ds, None, None, None, None, False, None, None)
    assert [] == task_list

    # Task list with one task
    ds = [
        {
            "include_tasks": {
                "name": "include_tasks_name",
                "tags": "include_tasks_tags",
                "when": "include_tasks_when",
                "files": "include_tasks_files"
            }
        }
    ]
    task_list = load_list_of_tasks(ds, None, None, None, None, False, None, None)
    assert [] == task_list

    # Task list with two tasks

# Generated at 2022-06-25 05:14:23.527692
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    play_0 = mock.MagicMock()
    loader_0 = mock.MagicMock()
    variable_manager_0 = mock.MagicMock()
    block_0 = mock.MagicMock()
    role_0 = mock.MagicMock()
    task_include_0 = mock.MagicMock()
    use_handlers_0 = False
    ds_0 = [mock.MagicMock()]
    var_0 = load_list_of_tasks(ds_0, play_0, block_0, role_0, task_include_0, use_handlers_0, 
        variable_manager_0, loader_0)
    assert isinstance(var_0, list)
    assert var_0 == [mock.NonCallableMock()]


# Generated at 2022-06-25 05:14:25.681223
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = None
    int_0 = 2048
    var_0 = load_list_of_tasks(float_0, int_0)

# Generated at 2022-06-25 05:14:30.107307
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    float_0 = None
    int_0 = 2048
    try:
      var_0 = load_list_of_roles(float_0, int_0)
    except AssertionError as e:
      var_0 = e
    except Exception as e:
      print(e)
    assert isinstance(var_0, AnsibleAssertionError)



# Generated at 2022-06-25 05:14:34.527742
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = None
    str_0 = 'The quick brown fox jumps over the lazy dog.'
    list_0 = ['The quick brown fox jumps over the lazy dog.', 'The quick brown fox jumps over the lazy dog.']
    int_1 = 2048
    int_2 = 0
    float_0 = None
    load_list_of_tasks(list_0, int_1, float_0, int_0, int_2, int_0)


# Generated at 2022-06-25 05:14:44.990056
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    list_0 = [
        2048,
        2048
    ]
    dict_0 = {
        'task_include': 4096,
        'block': 2048,
        'task_include': 4096,
        'all_parents_static': True,
        'play': 2048,
        'loop_args': [
            2048,
            ['a', 'b', 'c', 'd']
        ]
    }
    dict_1 = {
        'task_include': 4096,
        'block': 2048,
        'task_include': 4096,
        'play': 2048,
        'loop_args': [
            2048,
            ['a', 'b', 'c', 'd']
        ]
    }

# Generated at 2022-06-25 05:14:50.291600
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = dict(action='role', args=dict(name='my_role'))
    ds = [ds]
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)



# Generated at 2022-06-25 05:15:14.256862
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test cases
    tests = [
        # tuple of
        # (object, expected)
        # testcase 0
        (dict(
            template = '{{ vars["var"] }}',
            vars = dict( var = True ),
        ), True ),
    ]

    for test_case in enumerate(tests):
        test_case_0()


# Generated at 2022-06-25 05:15:16.097819
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("Testing function load_list_of_tasks")
    test_case_0()

test_load_list_of_tasks()

# Generated at 2022-06-25 05:15:17.773324
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
    except:
        print('Exception caught')



if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:15:28.968564
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pb_0 = Playbook()
    b_0 = Block()
    b_1 = Block()
    r_0 = Role()
    r_1 = Role()
    t_0 = Task()
    t_1 = Task()
    ti_0 = TaskInclude()
    ti_1 = TaskInclude()
    hti_0 = HandlerTaskInclude()
    hti_1 = HandlerTaskInclude()
    ir_0 = IncludeRole()
    ir_1 = IncludeRole()
    vm_0 = VariableManager()
    vm_1 = VariableManager()
    l_0 = DataLoader()
    l_1 = DataLoader()
    ds_0 = []
    play = pb_0
    block = b_0
    role = r_0
    task_include = ti_0
    use_hand

# Generated at 2022-06-25 05:15:33.695504
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = None
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    assert load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader) == []

    ds = []
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    assert load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader) == []


# Generated at 2022-06-25 05:15:43.708519
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # With path arg
    with pytest.raises(TypeError):
        load_list_of_roles(None)

    # With non-existent path arg
    with pytest.raises(IOError):
        load_list_of_roles('/a/b/c')

    # With non-existent path arg and ignore_errors=False
    with pytest.raises(IOError):
        load_list_of_roles('/a/b/c', ignore_errors = False)

    # With non-existent path arg and ignore_errors=True
    try:
        load_list_of_roles('/a/b/c', ignore_errors = True)
    except Exception:
        pytest.fail('Exception incorrectly raised')

    # With a simple play

# Generated at 2022-06-25 05:15:54.152951
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    class AnsibleMock:
        module_utils = None
    class AnsiblePlaybookMock(AnsibleMock):
        class playbook:
            class Play:
                hosts = None
                name = None
                roles = None
                handlers = None
                tasks = None
            class Role:
                name = None
        playbook = Playbook

    obj_0 = AnsiblePlaybookMock()
    obj_1 = AnsiblePlaybookMock.playbook.Play()
    obj_2 = AnsiblePlaybookMock.playbook.Role()


# Generated at 2022-06-25 05:16:03.025024
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    parser = ConfigParser.ConfigParser()
    parser.read("ansible.cfg")
    config = ConfigManager(parser)

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=config.settings["inventory"])


    variable_manager = VariableManager(loader=loader, inventory=inventory, version_info=CLI.version_info(gitinfo=False))

    ds = []
    play = None
    current_role_path = None
    variable_manager = None
    loader = None
    collection_search_list = None
    actual = load_list_of_roles(ds, play, current_role_path, variable_manager, loader, collection_search_list)


# Generated at 2022-06-25 05:16:06.143105
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # No need for testing
    return


# Generated at 2022-06-25 05:16:11.965881
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ansible_options = {'config_file': 'ansible.cfg', 'roles_path': 'ansible/roles:/etc/ansible/roles:/usr/share/ansible/roles'}
    loader_0 = DataLoader()
    variable_manager_0 = VariableManager()
    test_case_0()

    # All variables below must be set in test_case_1
    ds = []
    play = None
    current_role_path = None
    expected_results = []

    results = load_list_of_roles(ds, play, current_role_path, variable_manager_0, loader_0)
    assert results == None,'Should return None.'

    # Test with the following values:
    ds = None
    play = None
    current_role_path = None

# Generated at 2022-06-25 05:16:30.895573
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    
    from ansible.inventory.manager import InventoryManager
    
    variable_manager = VariableManager()
    loader = DataLoader()
    options = Options()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-25 05:16:39.425946
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.role.include import RoleInclude
    # load_list_of_blocks is called with arguments (MockA, MockA, MockA, MockA, MockA), but the MockA class does not have the following methods: __reduce__, __reduce_ex__
    with patch('ansible.executor.task_result.TaskResult.__init__', lambda self, *args, **kwargs: None):
        load_list_of_blocks(MockA(), MockA(), MockA(), MockA(), MockA())
    # load_list_of_roles is called with arguments (MockA, MockA, MockA, MockA), but the MockA class does not have the following methods: __reduce__, __reduce_ex__

# Generated at 2022-06-25 05:16:42.645196
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_0 = load_list_of_tasks('list_0', 'block_0', 'task_include_0', 2578, True, var_0)
    task_1 = load_list_of_tasks('list_0', 'block_0', 'task_include_0', 2578, True, var_1)

if __name__ == '__main__':
    test_case_0()
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:16:50.788880
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 157.93
    list_0 = [float_0, float_0]
    list = [float_0, float_0, float_0]
    dict_0 = dict()
    str_0 = 'a'
    var_0 = load_list_of_tasks((), float_0, float_0, dict_0, dict_0, dict_0, dict_0)
    var_1 = load_list_of_tasks(list, float_0, list_0, dict_0, dict_0, dict_0, dict_0)
    var_2 = load_list_of_tasks(dict_0, float_0, float_0, dict_0, dict_0, dict_0, dict_0)

# Generated at 2022-06-25 05:17:01.303147
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    f = open(tmpdir + "/var_file.yml", "w")
    # Write data to the file
    f.write("- hosts: localhost \n  tasks: \n  - debug: msg=\"Hello World\"")
    # Close the file
    f.close()
    # Create AnsibleFileLoader and AnsibleTaskInclude
    ansible_file_loader = AnsibleFileLoader(None)
    ansible_task_include = AnsibleTaskInclude(None, None, None)
    # Get the path of the loaded file
    path = ansible_file_loader._get_path('var_file.yml', 'tasks', [tmpdir])
    # Create a AnsibleTaskInclude object with

# Generated at 2022-06-25 05:17:06.961211
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Arrange
    import sys
    sys.path.append("..")

    # Act & Assert
    float_0 = 1549.1803
    list_0 = [float_0, float_0]
    load_list_of_tasks(float_0, list_0, 1.0)

# Generated at 2022-06-25 05:17:15.048835
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    For assertion of  load_list_of_tasks
    '''
        
    list_0 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50]
    list_1 = []
    for idx_0 in range(0, 49, 1):
        list_1.append(list_0[idx_0])
    int_0 = len(list_0)
    int_1 = int(int_0 * 0.6)


# Generated at 2022-06-25 05:17:21.852579
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 265.9476
    list_0 = [float_0, float_0, float_0]
    var_0 = load_list_of_tasks([float_0, float_0, float_0, float_0], float_0, float_0, float_0, float_0, float_0)

    float_0 = 40.327
    list_0 = [float_0, float_0, float_0]
    var_0 = load_list_of_tasks(list_0, list_0, float_0, float_0, float_0, float_0, float_0)

# Generated at 2022-06-25 05:17:33.133910
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:17:34.627054
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    try:
        test_case_0()
    except Exception as e:
        display.error(str(e))
        sys.exit(1)

test_load_list_of_blocks()

# Generated at 2022-06-25 05:18:00.563090
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 1549.1803
    list_0 = []
    var_0 = load_list_of_tasks(float_0, list_0)


# Generated at 2022-06-25 05:18:10.339226
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 1549.1803
    list_0 = [float_0, float_0]
    var_0 = load_list_of_blocks(float_0, list_0)
    int_0 = 17
    list_1 = ['select', float_0, float_0, int_0, float_0]
    var_1 = load_list_of_tasks(list_1, list_1, list_0, var_0)
    return var_1

# print(test_load_list_of_tasks())

# Generated at 2022-06-25 05:18:14.306072
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 1549.1803
    list_0 = [float_0, float_0]
    load_list_of_tasks(float_0, list_0)
    # assert (float_0 == var_0)


# Generated at 2022-06-25 05:18:23.847228
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    args_parser = ModuleArgsParser(None)
    float_0 = 1549.1803
    list_0 = [float_0, float_0]
    var_0 = load_list_of_tasks(float_0, list_0)
    # print(var_0)
    # var_0 = load_list_of_tasks(float_0, list_0)
    # print(var_0)
    # var_0 = load_list_of_tasks(float_0, list_0)
    # print(var_0)
    # var_0 = load_list_of_tasks(float_0, list_0)
    # print(var_0)
    # var_0 = load_list_of_tasks(float_0, list_0)
    # print(var_

# Generated at 2022-06-25 05:18:29.996138
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 1549.1803
    list_0 = [float_0, float_0]
    var_0 = load_list_of_tasks(float_0, list_0)
    var_1 = load_list_of_tasks(float_0, list_0)
    #print(var_1)
    assert var_0 == var_1


# Generated at 2022-06-25 05:18:34.969437
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    ds = [{'block': {}}]
    t = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)


if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:18:42.528370
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    src_0 = [('[ERROR]: task includes must be a list of tasks'), float()]
    dst_0 = "The ds (%s) should be a list but was a %s"
    # Call function
    #   list, str -> list
    def test_load_list_of_tasks_0():
        src = [False]
        dst = "The ds (%s) should be a dict but was a %s"
        # Call function
        try:
            load_list_of_tasks(src, "", "", "", "", "", "")
        except AnsibleAssertionError as e:
            assert(dst == str(e))
    #   str, str -> AnsibleParserError

# Generated at 2022-06-25 05:18:52.976503
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # No parameter test
    assert load_list_of_tasks() == None
    # One parameter test
    assert load_list_of_tasks(2) == None
    # Two parameters test
    
    # Three parameters test
    
    # Four parameters test
    
    # Five parameters test
    
    # Six parameters test
    
    # Seven parameters test
    assert load_list_of_tasks(5, 4, 3, 2, 1, param6=6, param7=7) == None
    # Eight parameters test
    
    # Nine parameters test
    
    # Ten parameters test
    
    # Eleven parameters test
    
    # Twelve parameters test
    
    # Thirteen parameters test
    
    # Fourteen parameters test
    
    # Fifteen parameters test
    display.info = lambda msg: msg


test

# Generated at 2022-06-25 05:19:00.095684
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block

    # Generate arguments to pass to the test function
    float_0 = 1549.1803
    list_0 = [float_0, float_0]
    role_0 = IncludeRole()
    task_include_0 = TaskInclude()
    task_0 = Task()
    block_0 = Block(task_list = [task_0], role = role_0, task_include = task_include_0, use_handlers = False)

# Generated at 2022-06-25 05:19:09.334109
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Unit test for function load_list_of_tasks
    '''

    # Mock class function: load_list_of_blocks
    def mock_load_list_of_blocks(ds, play, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None):
        mock_list_0 = ['B', 'O', 'B', 'S']
        return mock_list_0

    # Mock class function: load
    def mock_load(ds, play, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None):
        mock_string_0 = "foo"
        return mock_string_0

    # Mock class function: path_dwim

# Generated at 2022-06-25 05:19:41.507822
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Load list of tasks
    # AssertionError: Unexpected exception
    try:
        load_list_of_tasks(1549.1803, [1549.1803, 1549.1803])
    except Exception as exception:
        assert isinstance(exception, AssertionError)
        assert exception.args[0] == "The ds (1549.1803) should be a list but was a <class 'float'>"

    # Load list of tasks
    # AssertionError: Unexpected exception
    try:
        load_list_of_tasks([{'block': 'block', '_line_number': 0}], [{'block': 'block', '_line_number': 0}])
    except Exception as exception:
        assert isinstance(exception, AnsibleParserError)
        assert exception.args

# Generated at 2022-06-25 05:19:48.050205
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("test_load_list_of_tasks")
    list_0 = [1549.1803, 1549.1803]
    float_0 = 1549.1803
    tuple_0 = (float_0, float_0)
    load_list_of_tasks(list_0, tuple_0, tuple_0, tuple_0, tuple_0, tuple_0, tuple_0)
    print("Done.")


# Generated at 2022-06-25 05:19:51.187235
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 1549.1803
    str_0 = 'SdUsfV{x$'
    list_0 = [float_0, str_0]
    list_1 = [float_0]
    var_0 = load_list_of_blocks(float_0, list_0)


# Generated at 2022-06-25 05:19:59.628841
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 1549.1803
    list_0 = [float_0, float_0, float_0]
    var_0 = load_list_of_tasks(float_0, list_0)

if __name__ == '__main__':
    print("Testing load_list_of_blocks")
    test_case_0()
    print("Testing load_list_of_tasks")
    test_load_list_of_tasks()
    print("Done testing.")

# Generated at 2022-06-25 05:20:09.662307
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:20:20.148232
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 1549.1803
    list_0 = [float_0, float_0]
    var_0 = load_list_of_tasks(float_0, list_0)

    var_0 = load_list_of_tasks(float_0, list_0)

    var_0 = load_list_of_tasks(float_0, list_0)

    list_1 = [float_0, float_0]
    var_1 = load_list_of_tasks(float_0, list_1)

    list_1 = [float_0, float_0]
    var_1 = load_list_of_tasks(float_0, list_1)

    var_1 = load_list_of_tasks(float_0, list_1)


# Generated at 2022-06-25 05:20:30.522794
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Create a fake Play to pass to our method.
    play = Play().load({})
    assert load_list_of_tasks([], play) == []
    assert load_list_of_tasks(None, play) is None
    assert load_list_of_tasks([{
        'loop': '{{ list }}'
    }], play) == []
    assert load_list_of_tasks([
        {
            'loop_control': {
                'label': 'foo'
            }
        },
        {
            'loop_control': {
                'label': 'foo'
            }
        }
    ], play) == []
    assert load_list_of_tasks([
        {
            'include': '{{ foo }}'
        }
    ], play) == []
    assert load_list_of

# Generated at 2022-06-25 05:20:38.459308
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # This test case used to generate a list of Task objects
    # based on the provided YAML list.
    # Since I don't want to do any functional testing
    # I am just testing on a random YAML list generated from the
    # server or something.
    import yaml

# Generated at 2022-06-25 05:20:39.800890
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    float_0 = 1549.1803
    list_0 = [float_0, float_0]
    var_0 = load_list_of_roles(float_0, list_0)


# Generated at 2022-06-25 05:20:46.521803
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    play_0 = Play()
    block_0 = Block()
    task_include_0 = Task()
    str_0 = 'NnSfpjNItwHcEm'
    bool_0 = False
    bool_1 = False

    list_0 = load_list_of_tasks(str_0, play_0, block_0, task_include_0, bool_0, bool_1)

# Generated at 2022-06-25 05:21:40.415823
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    test_case_0()

# Generated at 2022-06-25 05:21:49.057168
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_case_0()

if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.facts


# Generated at 2022-06-25 05:21:55.054383
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    var = [("1549.1803"),("1549.1803")]
    assert var == load_list_of_blocks(1549.1803, var)

# Generated at 2022-06-25 05:22:01.082764
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    blocks = [{'block': [{'include': 'test01.yml'}, {'include': 'test01.yml'}, {'include': 'test01.yml'}]}]
    play = 'play'
    role = 'role'
    task_include = 'include'
    use_handlers = True
    variable_manager = 'variable_manager'
    loader = 'loader'

    with pytest.raises(AnsibleParserError) as excinfo:
        load_list_of_tasks(blocks, play, role, task_include, use_handlers, variable_manager, loader)
    assert 'included task files must contain a list of tasks' in str(excinfo.value)


# Generated at 2022-06-25 05:22:11.701326
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = {
        'foo': 'bar',
        'name': 'test'
    }

    class Play(object):
        pass

    play = Play()
    play.name = "test"
    play.__repr__ = lambda x: "test"

    class Role(object):
        name = "test"

    block = Role()

    class TaskInclude(object):
        pass

    task_include = TaskInclude()

    class VariableManager(object):
        pass

    variable_manager = VariableManager()

    class Loader(object):
        pass

    loader = Loader()


    results = load_list_of_tasks([ds], play, block, play.name, task_include, False, variable_manager, loader)

# Generated at 2022-06-25 05:22:17.441620
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test case
    float_0 = 1549.1803
    list_0 = [float_0, float_0]
    var_0 = load_list_of_blocks(float_0, list_0)
    float_0 = float_0
    list_0 = [float_0, float_0]
    var_0 = load_list_of_tasks(float_0, list_0)

# Generated at 2022-06-25 05:22:18.737581
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Unit test for function load_list_of_tasks
    return None


# Generated at 2022-06-25 05:22:23.673245
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        int_0 = int(input("Input an integer: "))
    except:
        int_0 = 4
    try:
        float_0 = float(input("Input a float: "))
    except:
        float_0 = 2.576
    try:
        str_0 = str(input("Input a string: "))
    except:
        str_0 = "Hello"
    list_0 = [float_0, float_0]
    load_list_of_tasks(int_0, list_0)


# Generated at 2022-06-25 05:22:25.667698
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    try:
        test_case_0()
    except Exception as ex:
        display.error('Caught exception in test case 0')
        raise

if __name__ == '__main__':
    # Run the test case
    test_load_list_of_blocks()

# Generated at 2022-06-25 05:22:32.646251
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block

    list_0 = [Block()]
    list_1 = [Block()]
    list_2 = [Block()]
    list_3 = [Block()]
    list_4 = [Block()]
    list_5 = [Block()]
    list_6 = [Block()]
    list_7 = [Block()]
    list_8 = [Block()]
    list_9 = [Block()]
    list_10 = [Block()]
    list_11 = [Block()]
    list_12 = [Block()]
    list_13 = [Block()]
    list_14 = [Block()]
    list_15 = [Block()]
    list_16 = [Block()]
    list_17 = [Block()]