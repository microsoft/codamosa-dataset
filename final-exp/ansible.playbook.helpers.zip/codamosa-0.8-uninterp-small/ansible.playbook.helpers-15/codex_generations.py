

# Generated at 2022-06-25 05:14:10.740057
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test YAML with literal block scalar style
    yaml_0 = '''
    ---
    - name: "Task 1"
      action: "ping"

    - name: "Task 2"
      action: "setup"
    '''
    # Expected result
    expected_result_0 = [{
        'action': 'ping',
        'name': 'Task 1'
    }, {
        'action': 'setup',
        'name': 'Task 2'
    }]

    # Test YAML with folded block scalar style

# Generated at 2022-06-25 05:14:15.036562
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = '4#3&qfBQ]D'
    list_0 = [str_0]
    list_1 = [str_0]
    tuple_0 = (list_0, list_1)
    int_0 = 890
    var_0 = load_list_of_tasks(str_0, tuple_0, int_0)


if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:14:18.175862
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = ["abc", "xyz"]
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    # Call function
    load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)


# Generated at 2022-06-25 05:14:22.103563
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True

    # TODO: Test the below
    # 1: list_0 = [str_0, str_1]
    # 2: tuple_0 = (str_0, str_1)
    # 3: int_0 = 963
    # 4: var_0 = load_list_of_tasks(list_0, tuple_0, int_0)


# Generated at 2022-06-25 05:14:31.498384
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    class MyTask:
        def load():
            pass

    class MyBlock:
        def load():
            pass

    class MyRole:
        def load():
            pass

    class MyTaskInclude:
        def load():
            pass
    class MyHandler:
        def load():
            pass
    class MyHandlerTaskInclude:
        def load():
            pass
    class MyIncludeRole:
        def load():
            pass

    class MyModuleArgsParser:
        def parse():
            pass

    class MyTemplar:
        def is_template():
            return False

    class MyLoader:
        def get_basedir():
            return "test_dir"

    class MyPlay:
        pass

    class MyVariableManager:
        def get_vars():
            return {}


# Generated at 2022-06-25 05:14:42.998337
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Default resources
    os.environ['ANSIBLE_ROLES_PATH'] = '/usr/share/maggie/ansible-maggie/playbooks/maggie_playbook_roles'
    os.environ['ANSIBLE_HOST_KEY_CHECKING'] = 'False'
    os.environ['ANSIBLE_PIPELINING'] = 'False'
    os.environ['ANSIBLE_RETRY_FILES_ENABLED'] = 'False'
    os.environ['ANSIBLE_SSH_RETRIES'] = '5'
    os.environ['ANSIBLE_DEPRECATION_WARNINGS'] = 'False'
    os.environ['ANSIBLE_LOG_PATH'] = 'None'
    os.environ['ANSIBLE_DEBUG'] = 'False'

# Generated at 2022-06-25 05:14:44.761835
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    try:
        test_case_0()
    except Exception as err:
        print('test 0 failed: ' + str(err))
        return

    print('test passed')

test_load_list_of_roles()

# Generated at 2022-06-25 05:14:53.815061
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:14:59.463143
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # The following line will be uncommented after the module is completely implemented
    #assert load_list_of_tasks()

    # The following line will be uncommented after the module is completely implemented
    #try:
    #    load_list_of_tasks()
    #except Exception as e:
    #    if e.error_code != AnsilbeExitJson.PARAM:
    #        assert False
    #    else:
    #        assert True
    #else:
    #    assert False
    assert True

# Generated at 2022-06-25 05:15:06.108337
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # name is one of the parameter so can not be mocked
    str_0 = '7:"~lQEZfD>r'
    list_0 = [str_0]
    tuple_0 = ()
    int_0 = 837
    var_0 = load_list_of_roles(str_0, list_0, tuple_0, int_0)
    assert var_0 == None


# Generated at 2022-06-25 05:15:34.141773
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # This test is intended to be run on a system where the variable
    # 'ansible_version' is defined.
    ans_ver = ansible_version = get_version()
    assert ans_ver.startswith('2.6')

    # This test is also intended to be run on a system with python 2.6

    # Load a list of tasks
    ds = [ dict(action=dict(module='shell',
            args='ls /etc')) ]

    our_play = Play()
    task_list = load_list_of_tasks(ds, our_play)

    assert task_list[0].action == 'shell'
    assert task_list[0].args['_raw_params'] == 'ls /etc'
    assert task_list[0].block is None
    assert task_list[0].delegate_

# Generated at 2022-06-25 05:15:37.715053
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 1005
    str_0 = '28\tu\rB!<\\`!Z=j'
    float_0 = None
    float_1 = -1550.1
    var_0 = load_list_of_tasks(int_0, str_0, float_0, float_1)


# Generated at 2022-06-25 05:15:44.553796
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_1 = -1550.1
    int_0 = 1005
    str_0 = '28\tu\rB!<\\`!Z=j'
    float_0 = None
    var_0 = load_list_of_tasks(int_0, str_0, float_0, float_1)


# Generated at 2022-06-25 05:15:54.410122
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    print('Testing load_list_of_tasks()')
    int_2 = 3
    float_2 = 0.9
    int_3 = 1
    float_3 = 0.8
    int_4 = 1
    float_4 = 0.9
    int_5 = 3
    float_5 = 0.8
    int_6 = 1
    float_6 = 0.9
    int_7 = 3
    float_7 = 0.8
    float_8 = 0.0
    int_8 = 0
    float_9 = 0.0
    int_9 = 0
    float_10 = -1950.5
    int_10 = 1
    str_1 = '6=\t\\xB\x84'
    int_11 = 1
    float_11 = 0.0

# Generated at 2022-06-25 05:16:01.566198
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = -48
    str_0 = 'RV"eG!<Dn+H'
    float_0 = None
    float_1 = -2.718281828459045
    float_2 = -7.38905609893065
    float_3 = None
    float_4 = None
    var_0 = load_list_of_tasks(int_0, str_0, float_0, float_1, float_2, float_3, float_4)
    return var_0


# Generated at 2022-06-25 05:16:07.821428
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = ';Ln`>Y5:.E46'
    play = 'MBla(='
    block = 'mz1\r40'
    role = 'SS2QF>9'
    task_include = -871994975
    use_handlers = 'qj@0|P'
    variable_manager = '^2_0F'
    loader = '`\t`)aQ'
    var_0 = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)

# Generated at 2022-06-25 05:16:16.675733
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = -28
    float_0 = -1550.1
    int_1 = 1005
    str_0 = '28\tu\rB!<\\`!Z=j'
    str_1 = '28\tu\rB!<\\`!Z=j'
    var_0 = load_list_of_tasks(int_0, float_0, int_1, str_0, str_1)


###########################################
# Boiler plate
###########################################


# Generated at 2022-06-25 05:16:27.874796
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Setup
    int_0 = str_0 = float_0 = float_1 = None
    var_0 = load_list_of_tasks(int_0, str_0, float_0, float_1)

    # Testing if it raises the expected exception
    with pytest.raises(AnsibleAssertionError) as ex:
        load_list_of_tasks(int_0, str_0, float_0, float_1)

    # Testing if exception message is as expected
    assert ex.type == AnsibleAssertionError
    assert 'The ds (%s) should be a list but was a %s' % (int_0, float_1) in ex.value.args[0]

    # Testing if it raises the expected exception

# Generated at 2022-06-25 05:16:35.024132
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:16:43.937911
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    variables = {
        'inventory_hostname': 'localhost', 
        'group_names': ['ungrouped'], 
        'omit': '__omit_place_holder__d41d8cd98f00b204e9800998ecf8427e', 
        'play_hosts': [
            'localhost'
        ], 
        'groups': {
            'ungrouped': {}
        }
    }

    tasks = [{'block': [], 'include': 'something'}]

    result = load_list_of_tasks(tasks, fake_type(), None, None, False, VariableManager(loader=None, host_vars=variables), DummyLoader())



# Generated at 2022-06-25 05:17:16.527061
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    int_0 = None
    int_1 = None
    int_2 = None
    float_0 = None
    dict_0 = {}
    dict_0['role_name'] = '0\n\t\n\tK\t\t\t\n\t{@\tK\t\t\n\t"\t\t\n\t'
    dict_0['tasks'] = '1'
    dict_0['handlers'] = '0'
    dict_0['vars'] = '0'
    dict_0['defaults'] = 0
    dict_0['meta'] = '1'
    dict_0['library'] = 0
    dict_0['module_utils'] = 0
    dict_0['filter_plugins'] = '1'

# Generated at 2022-06-25 05:17:24.714116
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    string_0 = 'blurple'
    float_0 = float(-25.9)
    float_1 = float(-0.36)
    float_2 = float(-1.8)
    int_0 = -6601
    int_1 = -8520
    int_2 = -626
    int_3 = -25
    int_4 = -1
    int_5 = -2
    str_0 = 'V\\o-m'
    str_1 = 'S|gA'
    str_2 = 'P'
    str_3 = 'G'
    str_4 = '\\'
    str_5 = '\\m'
    str_6 = 'w\\5'
    str_7 = '{'
    str_8 = '_'
    str_9 = ';'
    str

# Generated at 2022-06-25 05:17:31.929360
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 1005
    str_0 = '28\tu\rB!<\\`!Z=j'
    float_0 = None
    float_1 = -1550.1
    var_0 = load_list_of_tasks(int_0, str_0, float_0, float_1)


# Generated at 2022-06-25 05:17:35.822138
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass



# Generated at 2022-06-25 05:17:36.752250
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    load_list_of_tasks()

# Generated at 2022-06-25 05:17:47.433996
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 1005
    str_0 = '28\tu\rB!<\\`!Z=j'
    float_0 = None
    float_1 = -1550.1

    # Uncomment to test basic storage format
    # args_parser = ModuleArgsParser({'name': float_1, 'action': int_0})
    # try:
    #     (action, args, delegate_to) = args_parser.parse(skip_action_validation=False)
    #     print(action)
    #     print(args)
    #     print(delegate_to)
    # except AnsibleParserError as e:
    #     print(e)
    # except AnsibleUndefinedVariable as e:
    #     print(e)
    # except AnsibleInternalError as e:
    #     print(

# Generated at 2022-06-25 05:17:55.273807
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 1216
    str_0 = ')5$1"Q/\\`c%1nQ'
    float_0 = None
    float_1 = -1550.1
    var_0 = load_list_of_tasks(int_0, str_0, float_0, float_1)

if __name__ == '__main__':
    test_case_0()
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:17:56.701474
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass



# Generated at 2022-06-25 05:18:04.137650
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 1005
    str_0 = '28\tu\rB!<\\`!Z=j'
    float_0 = None
    float_1 = -1550.1
    str_1 = 'domain'
    var_1 = load_list_of_tasks(int_0, str_0, float_0, str_1, float_1)
    assert var_1 == int_0


# Generated at 2022-06-25 05:18:08.865269
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    int_0 = 1005
    str_0 = '28\tu\rB!<\\`!Z=j'
    float_0 = None
    float_1 = -1550.1

    result = load_list_of_blocks(int_0, str_0, float_0, float_1)

    assert result == 1005

# Generated at 2022-06-25 05:19:07.389350
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 1005
    str_0 = '28\tu\rB!<\\`!Z=j'
    float_0 = None
    float_1 = -1550.1
    var_0 = load_list_of_tasks(int_0, str_0, float_0, float_1)
    var_1 = load_list_of_tasks(int_0, str_0, float_0, float_0)
    var_2 = load_list_of_tasks(int_0, str_0, float_0, float_0)
    var_3 = load_list_of_tasks(int_0, str_0, float_0, float_0)

# Generated at 2022-06-25 05:19:13.758759
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 1005
    str_0 = '28\tu\rB!<\\`!Z=j'
    float_0 = None
    float_1 = -1550.1
    var_0 = load_list_of_tasks(int_0, str_0, float_0, float_1)


# Generated at 2022-06-25 05:19:23.670631
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:19:24.723217
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_case_0()

# Test load_list_of_tasks()

# Generated at 2022-06-25 05:19:32.215375
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Initializing variables
    ds_0 = [{'action': {'__ansible_arguments__': ['date', 4, '-i'], '__ansible_module__': 'command', '__ansible_no_log__': False}, 'async': 0, 'delegate_to': None, 'maybe_add_host': True, 'poll': 0, 'register': 'date', 'retries': 0, 'root': False, 'until': None, 'when': True}]

# Generated at 2022-06-25 05:19:41.225141
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    none = None
    str_0 = '8o!}4x{a'
    dict_0 = dict()
    dict_1 = {
        str_0: none,
    }
    list_0 = [
        dict_0,
        none,
    ]
    var_0 = load_list_of_tasks(list_0, none, none, dict_1, dict_0)
    str_1 = 'Yt&'
    dict_2 = {
        str_1: dict_0,
    }
    var_1 = load_list_of_tasks(dict_2, dict_2, dict_0, dict_2, dict_0)
    dict_3 = {
        str_1: var_1,
    }

# Generated at 2022-06-25 05:19:49.956836
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 9261
    int_1 = 9498
    str_0 = 'f\\'
    str_1 = '9'
    float_0 = -1.2
    float_1 = -1.5
    float_2 = 0.0
    float_3 = 1.5
    float_4 = 3
    float_5 = 4.0
    float_6 = 5

    var_0 = load_list_of_tasks(int_0, int_1, str_0, str_1, float_0, float_1, float_2, float_3, float_4, float_5, float_6)


test_case_0()
test_load_list_of_tasks()

# Generated at 2022-06-25 05:19:59.025223
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Initialize test values for function load_list_of_tasks
    int_0 = -0
    str_0 = 'd|5l5\n)tZ`Om'
    float_0 = None
    float_1 = None
    float_2 = 0.0
    load_list_of_tasks(int_0, str_0, float_0, float_1, float_2)


# Generated at 2022-06-25 05:20:10.379332
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'wY%'
    dict_0 = dict()
    dict_0['a'] = str_0
    dict_0['b'] = 'wY%'
    dict_0['c'] = 'wY%'
    dict_0['d'] = str_0
    dict_0['f'] = 'wY%'
    dict_0['g'] = 'wY%'
    dict_1 = dict()
    dict_1['c'] = -2033351219
    dict_1['d'] = -2033351219
    dict_1['a'] = -2033351219
    dict_1['b'] = -2033351219
    dict_1['e'] = -2033351219
    dict_1['f'] = -2033351219
    dict

# Generated at 2022-06-25 05:20:13.906124
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass
    # TODO: Write unit tests for function.


# Generated at 2022-06-25 05:21:11.814826
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = '6\tU\x1f!#z\x05\f'
    data_struct = {
        'hosts': str_0,
        'name': 'test',
        'roles': [],
        'tasks': [{
            'action': {
                'module': 'test',
                'args': {
                    'name': 'test',
                },
            },
            'name': 'test name',
            'register': 'register',
        }],
        'tags': [],
        'vars': {
            'vars': 'var',
        },
        'vars_files': [],
    }


# Generated at 2022-06-25 05:21:21.500867
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{'block': 'block', 'block': {}}]
    play = 'play'
    block = 'block'
    role = 'role'
    task_include = 'task_include'
    use_handlers = 'use_handlers'
    variable_manager = 'variable_manager'
    loader = 'loader'
    result = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert result == [None]

    ds = [{'block': 'block', 'block': {}}]
    play = 'play'
    block = 'block'
    role = 'role'
    task_include = 'task_include'
    use_handlers = 'use_handlers'

# Generated at 2022-06-25 05:21:29.887622
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # First, create a mock "play" object.  We can use this to test that
    # the play object is passed through to the task.
    class MockPlay(object):
        def start(self):
            pass
        def run(self):
            pass
        def cleanup(self):
            pass
        def get_vars(self, d=0, task=None):
            return {}
    play = MockPlay()

    ds_of_lists = [{'task': 'foo', 'action': 'bar'},
                   None,
                   {'block': 'foo', 'action': 'bar'}]
    assert load_list_of_tasks(ds_of_lists, play) == []
    assert load_list_of_tasks(ds_of_lists, play, use_handlers=True) == []

    d

# Generated at 2022-06-25 05:21:37.754506
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = -6.896
    float_0 = 0.34745
    tuple_0 = (None, 2.6)

# Generated at 2022-06-25 05:21:46.665094
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 's'
    str_1 = 'y-P'
    str_2 = ')'
    str_3 = '\x10z\b'
    str_4 = '<'
    str_5 = '\x0bCm\x0c\x7f'
    str_6 = '\r'
    str_7 = '\x06\x06\x06\x06'
    int_0 = -1036

# Generated at 2022-06-25 05:21:49.153668
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 1005
    str_0 = '28\tu\rB!<\\`!Z=j'
    float_0 = None
    float_1 = -1550.1
    var_0 = load_list_of_tasks(int_0, str_0, float_0, float_1)

# Generated at 2022-06-25 05:21:57.226896
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # load_list_of_tasks() example
    list_0 = [str(x) for x in range(10)]
    str_0 = '\xA0@'
    float_0 = 0.082598
    int_0 = 1001
    var_0 = load_list_of_tasks(list_0, str_0, float_0, int_0)
    print(var_0)


# Generated at 2022-06-25 05:22:04.781249
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    list_0 = [{'block': 'block', 'when': 'when'}]
    str_0 = 'F(r\x9c\x8a\x1c\xebE\xa1\x8b\xf0Eo\xad\x9f\x8a\x91y'
    float_0 = 376.7
    int_0 = -7
    str_1 = '_l\x9c\x10\xcc\x82\xe8\x02\xd5\xc4\x9b\xc8\x03'
    var_0 = load_list_of_tasks(list_0, str_0, float_0, int_0, str_1)

# Generated at 2022-06-25 05:22:09.207489
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 471
    str_0 = 'wQOUc8U6#'
    float_0 = None
    float_1 = -3100.4
    var_0 = load_list_of_tasks(int_0, str_0, float_0, float_1)
    assert var_0 == 'sNNhZa{Juk)$'

# Generated at 2022-06-25 05:22:18.681767
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 0
    str_0 = 'M=tOlz(C?kDWJ'
    float_0 = None
    float_1 = -737.024
    float_2 = -729.2
    float_3 = -950.35
    float_4 = -717.4
    float_5 = -822.2
    float_6 = -948.5
    float_7 = -705.1
    float_8 = -385.5
    float_9 = -712.2
    var_0 = load_list_of_tasks(int_0, str_0, float_0, float_1, float_2, float_3, float_4, float_5, float_6, float_7, float_8, float_9)


# Generated at 2022-06-25 05:23:42.219539
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    load_list_of_tasks(None, "abc", None, None, None, None, None)

if __name__ == "__main__":
    test_load_list_of_tasks()
    #     test_case_0()