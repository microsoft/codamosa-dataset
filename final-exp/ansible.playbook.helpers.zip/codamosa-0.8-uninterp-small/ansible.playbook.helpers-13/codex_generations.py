

# Generated at 2022-06-25 05:14:13.675171
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        # Test with a first argument of type NoneType
        NoneType_0 = type(None)
        test_case_0(NoneType_0, NoneType_0)
    except Exception:
        print('Exception raised expected')
        pass
    try:
        # Test with a second argument of type NoneType
        NoneType_1 = type(None)
        test_case_0(NoneType_1, str_0)
    except Exception:
        print('Exception raised expected')
        pass


# Generated at 2022-06-25 05:14:17.516280
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Get rid of all cached data
    # show_data(load_list_of_tasks(data_0))
    assert False


# Generated at 2022-06-25 05:14:25.122413
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    host_list = [{"hostname": "localhost", "ip": "127.0.0.1", "port": 22}]
    group_list = [{"group_name": "local", "hosts": ["localhost"]}]
    variable_manager = VariableManager(loader=DataLoader(), inventory=Inventory(host_list=host_list, group_list=group_list))
    variable_manager.extra_vars = {"ansible_ssh_pass": "pass"}
    load_list_of_tasks(True, None, None, None, None, False, variable_manager, True)
    load_list_of_tasks(False, None, None, None, None, True, variable_manager, True)
    load_list_of_tasks(None, None, None, None, None, False, variable_manager, True)

# Generated at 2022-06-25 05:14:33.616279
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    class AnsibleError(Exception):
        def __init__(self, message):
            super(Exception, self).__init__(message)

    class AnsibleParserError(Exception):
        def __init__(self, message):
            super(Exception, self).__init__(message)

    class AnsibleUndefinedVariable(Exception):
        def __init__(self, message):
            super(Exception, self).__init__(message)

    class AnsibleAssertionError(Exception):
        def __init__(self, message):
            super(Exception, self).__init__(message)

    class AnsibleFileNotFound(Exception):
        def __init__(self, message):
            super(Exception, self).__init__(message)


# Generated at 2022-06-25 05:14:44.420327
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = {'action': 'command', 'args':{'_raw_params': '/bin/true', 'warn': True}, 'delegate_to': {'_ansible_variables': {'ansible_playbook_python': '/usr/bin/python'}, '_ansible_version': '2.6.1'}}
    play = {'file_name': 'test.yml', '_ds': {'action': 'command', 'args':{'_raw_params': '/bin/true', 'warn': True}, 'delegate_to': {'_ansible_variables': {'ansible_playbook_python': '/usr/bin/python'}, '_ansible_version': '2.6.1'}}}
    block = file_name = 'test.yml'

# Generated at 2022-06-25 05:14:53.572427
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Initialization
    ds = [{'playbook': {'{http://blah.com/ns/blah}foo': 'boo'}}, {'playbook': {'{http://blah.com/ns/blah}foo': 'boo'}}, {'playbook': {'{http://blah.com/ns/blah}foo': 'boo'}}]
    # Call function to be tested
    p = load_list_of_tasks(ds)
    # Assertions

# Generated at 2022-06-25 05:14:58.493704
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print('Test load_list_of_tasks()')
    bool_0 = True
    bytes_0 = b''
    # load_list_of_tasks(bytes_0, bool_0)
    # FIXME: The play, block, and task_include are all required by this function, but the argument parser can't parse them.
    var_0 = load_list_of_tasks(bytes_0, bool_0)


# Generated at 2022-06-25 05:15:08.550826
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    class Test(object):
        @staticmethod
        def load(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None):
            assert ds == True
            assert play == 'ansible.playbook.play.Play'
            assert block == 'block'
            assert role == 'role'
            assert task_include == 'task'
            assert use_handlers == True
            assert variable_manager == 'ansible.vars.manager.VariableManager'
            assert loader == 'ansible.parsing.dataloader.DataLoader'

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task


# Generated at 2022-06-25 05:15:13.134509
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    bool_0 = True
    bytes_0 = b''
    var_0 = load_list_of_blocks(bool_0, bytes_0)
    assert var_0 is None
    bool_0 = True
    bytes_0 = b''
    var_0 = load_list_of_blocks(bool_0, bytes_0)
    assert var_0 is None

# Fake function for load_list_of_roles

# Generated at 2022-06-25 05:15:20.091510
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    task_vars = dict()
    task_vars['item'] = 0
    task_vars['ansible_module_generated'] = 1322213084.816598
    task_vars['var_1'] = 'var'
    play_context = PlayContext()
    play_context.network_os = 'junos'
    play_context.remote_addr = '172.26.47.21'
    play_context.port = 22
    play_context.remote_user = 'root'
    play_context.password = 'password'
    play_context.connection = 'network_cli'
    play_context.become = True
    play_context.become_method = 'enable'
    play_context.bec

# Generated at 2022-06-25 05:15:40.563734
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
 
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-25 05:15:50.966604
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    import ansible.playbook.block as module_0

    list_0 = None
    str_0 = None
    list_1 = None
    bool_0 = None
    list_3 = None
    list_4 = None
    list_5 = None
    bool_1 = None
    list_6 = None
    list_7 = None
    list_8 = None
    list_9 = None
    list_10 = None
    bool_2 = None
    list_11 = None
    list_12 = None
    list_13 = None
    bool_3 = None
    list_14 = None
    list_15 = None
    list_16 = None
    bool_4 = None
    list_17 = None
    list_18 = None
    list_19 = None
    bool_5 = None
    list_

# Generated at 2022-06-25 05:16:02.123209
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    args_0 = {'block': None, 'role': None, 'use_handlers': False, 'task_include': None, 'play': None, 'variable_manager': None, 'loader': None}
    list_0 = []
    args_0[0] = list_0
    dict_0 = {}
    dict_0[0] = dict_0
    list_0.append(dict_0)
    list_1 = []
    args_0[0] = list_1
    dict_1 = {}
    dict_1[0] = dict_1
    list_1.append(dict_1)
    args_0[0] = list_1
    args_0[0] = list_0
    args_0[0] = list_1
    args_0[0] = list_0
    test

# Generated at 2022-06-25 05:16:11.990788
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:16:15.138113
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    display_0 = module_0.Display()
    str_0 = None
    str_1 = None
    var_0 = load_list_of_tasks(str_0, str_1, display_0)


# Generated at 2022-06-25 05:16:18.741513
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    list_0 = [bytearray('dict')]
    class_0 = module_0.Display()
    var_0 = load_list_of_tasks(list_0, class_0)

# Generated at 2022-06-25 05:16:24.489804
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    list_0 = None
    display_0 = module_0.Display()
    var_0 = None
    var_1 = load_list_of_tasks(list_0, display_0)

import ansible.playbook.handler as module_6


# Generated at 2022-06-25 05:16:31.538233
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar

    # =================
    # Test case #1
    # =================
    # str -> list
    str_0 = ['list']
    display_0 = module_0.Display()
    var_0 = load_list_of_blocks(str_0, display_0)
    # TODO:  add to list
    # var_0.append(Block.load())
    # =================
    # Test case #2
    # =================
    #

# Generated at 2022-06-25 05:16:34.797624
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    try:
        test_case_0()
    except Exception as e:
        print("test_load_list_of_blocks error")

if __name__ == '__main__':
    print("Unit test for function load_list_of_blocks")
    test_load_list_of_blocks()

# Generated at 2022-06-25 05:16:40.497174
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:17:00.434128
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        ds = None
        play = None
        block = None
        role = None
        task_include = None
        use_handlers = False
        variable_manager = None
        loader = None

        # AssertionError expected.
        load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    except AssertionError:
        pass


# Generated at 2022-06-25 05:17:04.685004
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        pass
    except:
        pass
    else:
        pass


# Generated at 2022-06-25 05:17:11.361681
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Operations performed:
    #   1. Load an object with a list of roles
    str_0 = None
    str_1 = None
    display_0 = module_0.Display()
    var_0 = load_list_of_roles(str_0, str_1, display_0)


# Generated at 2022-06-25 05:17:13.700060
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = None
    display_0 = module_0.Display()
    var_0 = load_list_of_tasks(str_0, display_0)

# Generated at 2022-06-25 05:17:15.699601
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        load_list_of_tasks(None, None, None, None, None, None, None, None)
    except AnsibleAssertionError:
        pass


# Generated at 2022-06-25 05:17:17.018338
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 05:17:20.419335
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block

    if not isinstance(ds, (list, type(None))):
        raise AnsibleAssertionError('%s should be a list or None but is %s' % (ds, type(ds)))

# Generated at 2022-06-25 05:17:32.474755
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:17:37.126716
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = None
    display_0 = module_0.Display()
    var_0 = load_list_of_tasks(str_0, display_0)


# Generated at 2022-06-25 05:17:41.000643
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True == True
import types


# Generated at 2022-06-25 05:18:12.457412
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.utils.display import Display
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    test_list = [
        {'include': 'some_file.yml'},
        {'include_tasks': 'some_file.yml'},
        {'import_playbook': 'some_file.yml'},
        {'import_tasks': 'some_file.yml'},
        {'import_playbook': 'some_file.yml', 'loop': '{{ range(1, 10) }}'},
        {'import_tasks': 'some_file.yml', 'loop': '{{ range(1, 10) }}'},
        {'name': 'Some name'},
    ]


# Generated at 2022-06-25 05:18:20.581221
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # Create an empty array
    array_0 = []

    # Pass array_0, display_0, None, None, None and None as arguments
    load_list_of_blocks(array_0, display, None, None, None, None)


# TODO: Refactor remaining tests to not use MagicMock

######
#
# Tests for filter_leading_non_json_lines
#
######

try:
    from unittest.mock import MagicMock
except ImportError:
    from mock import MagicMock

import ansible.parsing.dataloader as module_1
import ansible.template as module_2


# Generated at 2022-06-25 05:18:30.873321
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Try a basic load
    ds = [
        {
            'name': 'foobar',
            'action': 'debug',
            'args': {'msg': 'This is a debug message'}
        },
        {
            'block': [
                {
                    'action': 'debug',
                    'args': {'msg': 'first block in list'}
                },
                {
                    'action': 'debug',
                    'args': {'msg': 'second block in list'}
                }
            ]
        }
    ]
    play = object()
    task_list = load_list_of_tasks(ds, play=play)
    assert(len(task_list)) == 2
    assert(isinstance(task_list[0], Task))
    assert(isinstance(task_list[1], Block))

# Generated at 2022-06-25 05:18:32.919618
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # No asserts called on load_list_of_blocks
    pass


# Generated at 2022-06-25 05:18:36.522002
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = None
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = None
    variable_manager = None
    loader = None
    # Retrieve function return value to check
    returned = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert returned == None

# Generated at 2022-06-25 05:18:43.977065
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Load the arguments
    ds = ['task']
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None

    # Set up a mock task
    from ansible.playbook.task import Task
    class MockTask(Task):
        def __init__(self):
            pass

        def copy(self, exclude_parent=False):
            return MockTask()

    # Set up the mock objects to be used by the function
    class MockAction(object):
        module_response = {
            'invocation': {
                'module_args': ''
            }
        }


# Generated at 2022-06-25 05:18:47.101017
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Case 0
    str_0 = None
    display_0 = module_0.Display()
    var_0 = load_list_of_tasks(str_0, display_0)


# Generated at 2022-06-25 05:18:56.577664
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    list_0 = ['var_0', 'var_1', 'var_2']
    str_0 = None
    str_1 = None
    str_2 = None
    str_3 = None
    str_4 = None
    str_5 = None
    str_6 = None
    dict_0 = { 'foo': 'var_0', 'bar': 'var_1' }
    module_0 = load_list_of_blocks(dict_0)
    module_1 = load_list_of_tasks(dict_0, module_0, str_0, str_1, str_2, str_3, str_4, str_5, str_6)
    var_0 = load_list_of_blocks(dict_0)

# Generated at 2022-06-25 05:19:05.979478
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:19:13.844888
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # block = None
    # ds = {'test', 'task'}
    # loader = None
    # play = None
    # role = None
    # task_include = None
    # use_handlers = None
    # variable_manager = None

    # t = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    # assert t == None

    assert True

# Generated at 2022-06-25 05:19:43.681986
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # We need to setup the loader and variable manager, which we did globally
    # so we can call yaml.load() safely and cleanly here
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    # FIXME: action/task_vars parsing/merging is not yet implemented
    #        in the new playbook API, so we must initialize them to
    #        empty dicts to prevent errors

    # a task
    data = {
        'action': 'copy',
        'mykey': 'myval',
    }

# Generated at 2022-06-25 05:19:47.425480
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
  pass


if __name__ == "__main__":
    print("Module test for load_block_list")
    test_case_0()

# Generated at 2022-06-25 05:19:48.938482
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        load_list_of_tasks(None, None)
    except:
        pass

# Generated at 2022-06-25 05:19:58.308649
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Set up mock variables
    display_0 = ansible.utils.display.Display()
    task_ds_0 = 'task_ds_0'
    block_1 = mock.Mock()
    block_1.get.return_value = 'role_4'
    role_0 = 'role_0'
    task_include_0 = None
    use_handlers_2 = True
    variable_manager_0 = mock.Mock()
    variable_manager_0.get_vars.return_value = 'block_1'
    loader_0 = mock.Mock()
    loader_0.get_basedir.return_value = 'role_4'
    args_parser_0 = ansible.module_utils.basic.ModuleArgsParser()

# Generated at 2022-06-25 05:20:10.322103
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("Test: load_list_of_tasks")
    # Test for function load_list_of_tasks
    # Test for function load_list_of_tasks
    # Test for function load_list_of_tasks
    # Test for function load_list_of_tasks
    # Test for function load_list_of_tasks
    # Test for function load_list_of_tasks
    # Test for function load_list_of_tasks
    # Test for function load_list_of_tasks
    # Test for function load_list_of_tasks
    # Test for function load_list_of_tasks
    # Test for function load_list_of_tasks
    # Test for function load_list_of_tasks
    # Test for function load_list_of_tasks
    #

# Generated at 2022-06-25 05:20:18.839507
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Assert defaults
    assert load_list_of_tasks(['a:b:c']) == '12345'

    # Assert that the function returns None when the argument is None
    assert load_list_of_tasks(None) is None

    # Assert that the function raises an exception when the argument is an object of the wrong type
    with pytest.raises(AnsibleAssertionError) as e_info:
        load_list_of_tasks(Exception('This is an exception object that raises an AnsibleAssertionError.'))

# Unit tests for class load_list_of_blocks

# Generated at 2022-06-25 05:20:27.514986
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Instance of Blocks()
    block = Blocks()

    # Instance of RoleInclude()
    role = RoleInclude()

    # Instance of TaskInclude()
    task_include = TaskInclude()

    # Instance of VariableManager()
    variable_manager = VariableManager()

    # Instance of DataLoader()
    loader = DataLoader()

    # Instance of Play()
    play = Play()

    # Test YAML file to obtain the list of task
    data_file = load_fixture('/playbooks/play.yml')

    # The list of task datastructures (parsed from YAML)
    ds = data_file['tasks']


# Generated at 2022-06-25 05:20:31.091121
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass


# Generated at 2022-06-25 05:20:35.446721
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Test case with passing args
    str_1 = None
    display_1 = module_0.Display()
    var_1 = load_list_of_tasks(str_1, display_1)

    # Test case with passing args
    str_2 = None
    display_2 = module_0.Display()
    var_2 = load_list_of_tasks(str_2, display_2)

# Generated at 2022-06-25 05:20:39.686070
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Variables
    ds = None
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = None
    variable_manager = None
    loader = None
    
    test_load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    

# Generated at 2022-06-25 05:21:30.015376
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:21:38.070069
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    module_0.Display.verbosity = 0
    test_case_0()
    module_0.Display.verbosity = 0

import ansible.parsing.dataloader as module_1
import ansible.parsing.mod_args as module_2
from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
import ansible.utils.display as module_4
from ansible.parsing.yaml.objects import AnsibleMapping
import ansible.errors as module_6
from ansible.playbook.task import Task
import ansible.parsing.yaml.constructor as module_8
import ansible.utils.path as module_9
from ansible.playbook.play_context import PlayContext
import ansible.playbook.task_include as module_11

# Generated at 2022-06-25 05:21:44.066879
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # module_0 = ansible.utils.display
    # str_0 = None
    # display_0 = module_0.Display()
    # var_0 = load_list_of_tasks(ds=str_0, play=display_0)
    assert False

import ansible.utils.display as module_1


# Generated at 2022-06-25 05:21:50.689807
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks(str, str, None, None, None, False, None, None) == None
    assert load_list_of_tasks(list, list, None, None, None, False, None, None) == None
    assert load_list_of_tasks(list, list, str, None, None, False, None, None) == None


# Generated at 2022-06-25 05:21:58.340709
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds_0 = ["str"]
    play_0 = "str"
    block_0 = "str"
    role_0 = "str"
    task_include_0 = "str"
    use_handlers_0 = "str"
    variable_manager_0 = "str"
    loader_0 = "str"
    test_load_list_of_tasks_0(ds_0, play_0, block_0, role_0, task_include_0, use_handlers_0, variable_manager_0, loader_0)


# Generated at 2022-06-25 05:22:05.297395
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # FIXME: these tests should test more than just loading, load() should have its own tests
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    # test loading blocks
    ds = [dict(block=dict(tasks=[dict(action=dict(module='ping'))]))]
    blocks = load_list_of_blocks(ds, None)
    assert isinstance(blocks[0], Block)

    # test loading tasks
    ds = [dict(action=dict(module='ping'))]
    tasks = load_list_of_tasks(ds, None)
    assert isinstance(tasks[0], Task)

    # test loading handlers
    d

# Generated at 2022-06-25 05:22:07.244144
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # FIXME: add tests for load_list_of_tasks
    pass



# Generated at 2022-06-25 05:22:09.280062
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = None
    display_0 = module_0.Display()
    var_0 = load_list_of_tasks(str_0, display_0)


# Generated at 2022-06-25 05:22:15.558546
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    ds = [{'action': 'debug', '_ansible_verbose_always': True, 'msg': 'test'}]
    play = []
    block = []
    role = []
    task_include = []

    task_list = [Task(block=block, role=role, task_include=task_include, load_from_file=False)]

    assert load_list_of_tasks(ds, play, block, role, task_include, False, False, False) == task_list

# Generated at 2022-06-25 05:22:22.614998
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:23:29.338755
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar

    display = Display()

    var_0 = {}
    var_1 = 'handlers'
    var_2 = Block(None, None, None, None, None, None)
    var_3 = 'tasks'
    var_4 = Task(None, None, None, None, None, None, None)
    var_5 = 'tasks'
    var_6 = []
    var_7 = None

# Generated at 2022-06-25 05:23:36.224056
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Generate a test list of dictionaries to pass to load_list_of_tasks.
    # Pass this list to a function that will call load_list_of_tasks and
    # return the results.  Then double-check the results with a test
    # function to ensure the results are what you would expect.

    var_list = []
    var_list.append({ 'hosts': 'localhost', 'become': True })
    var_list.append({ 'hosts': 'localhost', 'become': True, 'roles': [] })
    var_list.append({ 'hosts': 'localhost', 'become': True, 'roles': 'role1' })
    var_list.append({ 'hosts': 'localhost', 'become': True, 'roles': 'role1', 'become_user': 'root' })
