

# Generated at 2022-06-25 05:14:02.559536
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Note that the following test runs will fail because the function 
    # load_list_of_tasks was modified a lot. In the future, we will add 
    # more test cases to cover the new functions.

    # Check if the type of the first input parameter is list
    try:
        load_list_of_tasks(1, 0, 0, 0, 0, 0, 0, 0)
    except AnsibleAssertionError as e:
        pass
    else:
        print('The function load_list_of_tasks does not work correctly')

    # If the input parameter is an empty list, the function should return None
    var_0 = []
    var_1 = load_list_of_tasks(var_0, 0, 0, 0, 0, 0, 0, 0)

# Generated at 2022-06-25 05:14:08.785699
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 687.19354
    var_0 = load_list_of_blocks(float_0, float_0, float_0)
    assert('var_0_0' not in locals())
    test_case_0()
    assert('var_0_0' not in globals())

# Encodes a test case that tests the following:
#    1. There is a global variable of float_0
#    2. float_0 is assigned


# Generated at 2022-06-25 05:14:11.453639
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 606.14075
    var_0 = load_list_of_tasks(float_0, float_0, float_0)


if __name__ == "__main__":
    test_load_list_of_tasks()
    test_case_0()

# Generated at 2022-06-25 05:14:16.319497
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Declare function inputs
    float_0 = float(1913.28383)
    float_1 = float(1466.3)
    float_2 = float(1672.91)
    float_3 = float(1878.59055)
    float_4 = float(958.05)
    float_5 = float(1362.67)

    # Call function
    var_0 = load_list_of_tasks(float_0, float_1, float_2, float_3, float_4,
                               float_5)


# Generated at 2022-06-25 05:14:18.862338
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    try:
        test_case_0()
    except Exception as e:
        raise Exception(e)

    print("load_list_of_blocks was successful")



# Generated at 2022-06-25 05:14:26.281980
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:14:34.227133
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
  file_path = "c:\\users\\william\\appdata\\local\\temp\\tmp_0"
  task_0 = (file_path, file_path, file_path)
  list_0 = ["\\", "c:\\users\\william\\appdata\\local\\temp\\tmp_0", "ANSI"]
  list_1 = ['W', 'c:\\users\\william\\appdata\\local\\temp\\tmp_0', "%s"]
  list_2 = ['T', 'c:\\users\\william\\appdata\\local\\temp\\tmp_0', "%s"]
  list_3 = ['W', 'c:\\users\\william\\appdata\\local\\temp\\tmp_0', "%s"]

# Generated at 2022-06-25 05:14:38.723930
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Settings up arguments.
    ds = []

    # Testing function.
    var_0 = load_list_of_tasks(ds)
    if var_0 != []:
        print("Test case 1: Failed")
    else:
        print("Test case 1: Passed")


# Generated at 2022-06-25 05:14:48.892044
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 = ''
    var_1 = '#'
    var_2 = '$'
    float_0 = 687.19354
    dict_0 = dict(a=float_0, b=var_0, c=float_0, d=var_0, e=float_0, f=var_1, g=float_0, h=var_2)
    var_3 = dict_0
    list_0 = dict_0
    dict_1 = dict(a=var_0, b=float_0, c=var_3, d=float_0, e=var_3, f=var_0, g=float_0, h=var_3, i=float_0, j=var_3)

# Generated at 2022-06-25 05:14:52.806523
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # if this fails its likely because the yaml files for ansible were moved
    # so we need to update the path properly
    assert(os.path.join(C.DEFAULT_MODULE_PATH[0], 'ping.py') == '/usr/lib/python2.7/dist-packages/ansible/modules/networking/ping.py')


# Generated at 2022-06-25 05:15:16.615405
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    var_1 = []
    var_2 = []
    var_3 = load_list_of_roles(var_1, var_2)


# Generated at 2022-06-25 05:15:21.685404
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    global display
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    #from ansible.vars.hostvars import HostVars
    #from ansible.vars.hostvars import HostVarsVars
    #from ansible.vars.groupvars import GroupVarsVars
    #from ansible.vars.groupvars import GroupVars
    #from ansible.vars.

# Generated at 2022-06-25 05:15:27.667776
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 687.19354
    var_0 = load_list_of_tasks(float_0, float_0)
    print(var_0)
    return var_0

# Generated at 2022-06-25 05:15:34.673146
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Basic test case
    '''


# Generated at 2022-06-25 05:15:45.754890
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Set up
    var_0 = '$'
    str_0 = '#'
    nested_list_0 = [var_0, var_0, str_0]
    lst = [nested_list_0, [var_0, str_0, str_0], nested_list_0]
    ansible_0 = [var_0, var_0, var_0]
    ansible_1 = [var_0, var_0, str_0]
    ansible_2 = [var_0, var_0, var_0]
    ansible_3 = [var_0, var_0, str_0]
    ansible_4 = [var_0, var_0, str_0]
    ansible_5 = [var_0, var_0, var_0]
    ansible

# Generated at 2022-06-25 05:15:49.787564
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 = load_list_of_tasks(float, float, float)
    assert(var_0 == 1)

# Generated at 2022-06-25 05:16:00.554119
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 687.19354
    task_ds = [1, 2, 3]
    play = float_0
    block = float_0
    role = float_0
    task_include = float_0
    use_handlers = False
    variable_manager = float_0
    loader = float_0

# Generated at 2022-06-25 05:16:08.393918
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Load a basic list of tasks.
    task_ds_0 = {"foo": "bar"}
    ds_0 = [task_ds_0]

    task_0 = load_list_of_tasks(ds_0, ds_0, ds_0, ds_0, ds_0)[0]

    assert task_0.action == task_ds_0

    # Load a list of tasks containing a block.
    block_ds_0 = {"block": "baz"}
    ds_0 = [block_ds_0]

    block_0 = load_list_of_tasks(ds_0, ds_0, ds_0, ds_0, ds_0)[0]

    assert block_0.action == block_ds_0

    # Load a list of tasks containing an include

# Generated at 2022-06-25 05:16:20.101101
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:16:29.692591
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    src = 'test/test_playbook_tasks/test_load_list_of_tasks/'
    res = 'test/test_playbook_tasks_result/test_load_list_of_tasks/'

    with open(res + 'hosts') as hosts_file:
        my_hosts = [line.strip() for line in hosts_file.readlines()]
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hosts': my_hosts}
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=my_hosts)
    variable_manager.set_inventory(inventory)
    

# Generated at 2022-06-25 05:16:54.534395
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.template import Templar
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.module_utils.six import string_types
    from ansible.module_utils import basic
    class MockModuleUtilsBasic(object):
        class BasicModule(object):
            def __init__(self, action, argument_spec, bypass_checks=None, no_log=None, check_invalid_arguments=None, mutually_exclusive=None, required_together=None, required_one_of=None, add_file_common_args=None, supports_check_mode=None, required_if=None, required_by=None):
                global module_utils_basic_args

# Generated at 2022-06-25 05:16:58.017827
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 687.19354
    var_0 = load_list_of_tasks(float_0, float_0, float_0)


if __name__ == "__main__":
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:17:04.875756
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    # Create new function object and assign it to the 'load_list_of_roles' variable
    load_list_of_roles = Function(
        loads=load_list_of_roles,
        as_name='load_list_of_roles'
    )
    join_path = Function(
        func=os.path.join,
        as_name='join_path'
    )

    # Set the (relative) file paths for testing
    lib_path = os.path.abspath("./lib")

    # Set the search paths for Ansible library (so we don't have to install)
    sys.path.insert(0, lib_path)

    # Execute the test_case method
    test_case_0()

if __name__ == "__main__":
    test_load_list_

# Generated at 2022-06-25 05:17:14.863150
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 571.85988
    float_1 = float_0

    string_0 = "nO;`,'t.%m'v?e4xO4&D^<\"!"
    string_1 = "kS|H0Ci~aN?Izx!XW]/8de{/p"
    string_2 = "W0<^Uo>#T|B&^i9)nh.*6MkH6Q"
    string_3 = "w$[zj;@3e'3|uZh`%V>&uR1<_V"

    list_0 = [string_3, string_3, string_3, string_2]
    list_1 = [string_3, string_3, string_3, string_2]
    list_2

# Generated at 2022-06-25 05:17:23.436608
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:17:33.239892
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible._vendor.yaml.error import YAMLError
    from ansible.parsing.yaml.objects import AnsibleUnicode

    float_0 = 687.19354
    float_1 = 7.8
    float_2 = 9.7
    str_0 = 'hello'
    str_1 = 'world'
    ansible_dict = { 'action': float_0, 'args': {}, 'delegate_to': str_0, 'delegate_facts': False, 'loop': {}, 'loop_args': {}}
    list_0 = [float_0, ansible_dict, float_1]

    float_0 = 687.19354

# Generated at 2022-06-25 05:17:37.203443
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 687.19354
    var_0 = load_list_of_tasks(float_0, float_0, float_0)


# Generated at 2022-06-25 05:17:45.344517
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 668.05
    list_0 = [True]
    str_0 = 's'
    var_0 = load_list_of_tasks(list_0, list_0, float_0, str_0)
    assert var_0[0]
    list_1 = [False]
    str_1 = 'ss'
    var_1 = load_list_of_tasks(list_1, list_1, float_0, str_1)
    assert not var_1[0]
    list_2 = [1]
    str_2 = 'sss'
    var_2 = load_list_of_tasks(list_2, list_2, float_0, str_2)
    assert var_2[0] is 1
    list_3 = [2]
    str

# Generated at 2022-06-25 05:17:51.505459
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """
    Correctly parse lists of task and block
    """
    play = dict(
        name="test_play",
        hosts=[1, 2],
        gather_facts='no',
        any_errors_fatal=False,
        no_log=False,
        roles=[],
        tasks=[
            dict(action=dict(module='shell', args='id')),
            dict(action=dict(module='shell', args='id')),
            dict(action=dict(module='shell', args='id')),
        ]
    )
    # play = Play().load(play, variable_manager=variable_manager, loader=loader)
    # play.post_validate(templar=Templar(loader=loader, variables=variable_manager.get_vars(play=play)))

    tasks = load_list_of

# Generated at 2022-06-25 05:17:54.893592
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 687.19354
    var_0 = load_list_of_tasks(float_0, float_0, float_0)
    assert var_0 == True


# Generated at 2022-06-25 05:18:28.400088
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Fails on block_ds and implicit_blocks on line #49
    '''
    float_0 = 687.19354
    var_0 = load_list_of_tasks(float_0, float_0, float_0)



# Generated at 2022-06-25 05:18:32.986879
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 687.19354
    var_0 = load_list_of_tasks(float_0, float_0, float_0)
    print(var_0)
    assert(var_0 != None)

# Generated at 2022-06-25 05:18:41.689810
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    input = [{u'include_vars': {u'name': u'proxy'}, u'run_once': True, u'name': u'Configure proxy'}]
    # Here's where we should write the test for the function
    result = load_list_of_tasks(input, None, None, None, None, False, None, None)
    # Not sure the appropriate way to test this
    result = repr(result)
    assert result.find("include_vars") == -1
    assert result.find("run_once") == -1
    assert result.find("name") == -1
    assert result.find("TaskInclude") != -1
    assert result.find("True") == -1

# Generated at 2022-06-25 05:18:50.719527
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
        {
            "action": "include_tasks",
            "name": "test"
        },
        {
            "action": "pause",
            "pause_time": 10
        },
        {
            "action": "include_role",
            "name": "test"
        }
    ]
    play = Mock()
    block = Mock()
    role = Mock()
    task_include = Mock()
    use_handlers = False
    variable_manager = Mock()
    loader = Mock()
    # We do not use load_list_of_tasks in actual code. Just add the skip
    # test_case_0()



# Generated at 2022-06-25 05:18:52.250292
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Tested as part of test_case_0
    pass


# Generated at 2022-06-25 05:18:59.858083
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
	print("--- Test Case: load_list_of_tasks")
	# Test Case 1
	print("Testing Test Case 1")
	try:
		test_case_1()
		print("Test Case 1 has not thrown exception")
	except Exception as e:
		print("Test Case 1 has thrown an exception, ", e)

	# Test Case 2
	print("Testing Test Case 2")
	try:
		test_case_2()
		print("Test Case 2 has not thrown exception")
	except Exception as e:
		print("Test Case 2 has thrown an exception, ", e)

	# Test Case 3
	print("Testing Test Case 3")

# Generated at 2022-06-25 05:19:02.563758
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Output: str
    float_0 = 687.19354
    var_0 = load_list_of_tasks(float_0, float_0, float_0)
    print(var_0, "\n")


# Generated at 2022-06-25 05:19:09.754870
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Make sure the list of task data structures is of type list
    with pytest.raises(AnsibleAssertionError) as excinfo:
        load_list_of_tasks("Hello", "Hello", "Hello")
    assert 'The ds' in str(excinfo.value)

    # Make sure the list of task data structures is a valid list
    with pytest.raises(AnsibleAssertionError) as excinfo:
        load_list_of_tasks("Hello", "Hello", "Hello", "Hello")
    assert 'The ds' in str(excinfo.value)

    # Make sure the list of task data structures is of type dict

# Generated at 2022-06-25 05:19:14.143195
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_1 = 48.23601
    float_0 = 687.19354
    var_0 = load_list_of_tasks(float_1, float_0, float_0)


# Generated at 2022-06-25 05:19:21.565863
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    string_0 = "`j!]avHGh5i"
    string_1 = "-[d]K?>"
    string_2 = "3<8Y^'#={{d>]"
    string_3 = "EfMI<j)"
    string_4 = "yt9]4"
    string_5 = "QB"
    string_6 = "th=}:o%/i"
    string_7 = "V"
    string_8 = "*38Oi"
    string_9 = "H"
    string_10 = "U"
    string_11 = "2(aI1"
    string_12 = "=;i)3o8"
    string_13 = "jD]"
    string_14 = "~y(r#]E"

# Generated at 2022-06-25 05:20:00.908927
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test case 0
    list_0 = ["10", "1", "3", "2", "9", "6", "5", "8"]
    string_0 = "1"
    string_1 = "8"
    string_2 = "5"
    string_3 = "10"
    string_4 = "4"
    test_load_list_of_tasks_0(list_0, string_0, string_1, string_2, string_3, string_4)

    # Test case 1
    list_1 = ["5", "8", "1", "10", "2", "6", "7", "9"]
    string_5 = "5"
    string_6 = "10"
    string_7 = "1"
    string_8 = "9"

# Generated at 2022-06-25 05:20:09.447764
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # Create a basic task
    task_ds = {"local_action": "shell echo foo"}
    # Create a basic block
    block_ds = {"block": []}

    # Make the test list with both task and block
    test_list = [ task_ds, block_ds ]
    # Create a basic play
    play_ds = {"hosts": "localhost", "name": "test"}
    # Create task_include
    task_include_ds = {"include": "something.yml"}

    # Test calling load_list_of_blocks
    load_list_of_blocks(test_list, play_ds, task_include=task_include_ds)


# Generated at 2022-06-25 05:20:18.999093
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import uuid
    import datetime
    import pytest
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    pytest.main([__file__])
    block_0 = Block.load(uuid.uuid4(), float_0, float_0, float_0)
    var_0 = load_list_of_tasks(uuid.uuid4(), float_0, block_0, float_0, float_0)
    assert var_0 == var_0, "unexpected value returned"


# Generated at 2022-06-25 05:20:23.837400
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    list_0 = ['load_list_of_blocks', 'load_list_of_blocks', 'load_list_of_blocks']
    list_1 = ['load_list_of_blocks', 'load_list_of_blocks', 'load_list_of_blocks']
    list_2 = ['load_list_of_blocks', 'load_list_of_blocks', 'load_list_of_blocks']
    list_3 = ['load_list_of_blocks', 'load_list_of_blocks', 'load_list_of_blocks']
    list_4 = ['load_list_of_blocks', 'load_list_of_blocks', 'load_list_of_blocks']
    list_5 = ['load_list_of_blocks', 'load_list_of_blocks', 'load_list_of_blocks']
   

# Generated at 2022-06-25 05:20:34.823632
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    data_0 = "['do_some_thing2', 'do_some_thing1']"
    data_1 = [data_0, data_0, data_0]

# Generated at 2022-06-25 05:20:42.283023
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:20:43.924439
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Load the task list with a string
    load_list_of_tasks("string", "string")


# Generated at 2022-06-25 05:20:55.713753
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:21:04.663792
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds = [{'when': [{'vars': {'name1': 'value1'}}], 'name': 'first_task', 'register': 'result'}, {'import_playbook': 'some_playbook.yml', 'name': 'some_name'}]
    play = {'hosts': 'testhost'}
    parent_block = [{'when': [{'vars': {'name1': 'value1'}}], 'name': 'first_task', 'register': 'result'}, {'import_playbook': 'some_playbook.yml', 'name': 'some_name'}]
    role = {'hosts': 'testhost'}
    task_include = {'hosts': 'testhost'}
    use_handlers = False

# Generated at 2022-06-25 05:21:11.644138
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 = True
    var_1 = True
    var_2 = dict()
    var_2['msg'] = "A message describing what happened"
    var_2['pri'] = 30
    var_2['created'] = 'now'
    var_2['_ansible_verbose_always'] = True
    var_2['_ansible_no_log'] = False
    var_2['name'] = 'a meta task'
    var_2['meta'] = 'foo'
    var_2['changed_when'] = True
    var_2['failed_when'] = True
    var_2['always_run'] = True
    var_2['delegate_to'] = "localhost"
    var_2['register'] = "result"
    var_2['failed_when'] = ["result|failed"]
   

# Generated at 2022-06-25 05:21:50.799728
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 870.335938
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    float_9 = float()
    float_10 = float()
    float_11 = float()
    float_12 = float()
    float_13 = float()
    float_14 = float()
    float_15 = float()
    float_16 = float()
    float_17 = float()
    float_18 = float()
    float_19 = float()
    float_20 = float()
    float_21 = float()
    float_22 = float()
    float_23 = float()
    float_

# Generated at 2022-06-25 05:21:59.944810
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 0.0553
    float_1 = 0.0942
    float_2 = 0.0979
    float_3 = 0.0453
    float_4 = 0.0444
    float_5 = 0.0449
    float_6 = 0.0812
    float_7 = 0.0173
    float_8 = 0.0944
    float_9 = 0.0313
    float_10 = 0.0827
    float_11 = 0.0615
    float_12 = 0.0309
    float_13 = 0.0772
    float_14 = 0.0820
    float_15 = 0.0230
    float_16 = 0.0976
    float_17 = 0.0581
    float_18 = 0.0894
    float_19 = 0.0103

# Generated at 2022-06-25 05:22:04.007599
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # try:
        file_name = "test_load_list_of_tasks.yaml"
        with open(file_name) as filehandle:
            yaml_data = yaml.load(filehandle)
        test_case_0()
        test_case_1()
        test_case_2()
        test_case_3()
        test_case_4()
        test_case_5()
    # except Exception as inst:
    #     print(inst)


# Load test case 0

# Generated at 2022-06-25 05:22:12.080358
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import os
    import shutil
    import tempfile
    import sys
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.plugins.loader import plugin_loader
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), 'v2_loader'))

    # define an inventory
    target = tempfile.mk

# Generated at 2022-06-25 05:22:20.800732
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 687.19354
    float_1 = -342.79
    bool_0 = True
    str_0 = ';D'
    var_0 = load_list_of_tasks(float_0, float_0, float_0, float_0, float_0, bool_0, float_1, str_0)
    assert var_0 is None
    var_1 = load_list_of_tasks(None, float_0, float_0, float_0, float_0, bool_0, float_1, str_0)
    assert var_1 is None


if __name__ == "__main__":
    test_case_0()
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:22:25.906120
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print('Test load_list_of_tasks')

    var_0 = 983
    var_1 = 996
    var_2 = 975
    var_3 = 936
    var_4 = 997
    var_5 = 957
    var_6 = 933
    var_7 = 988
    var_8 = 961
    var_9 = 993
    var_10 = 996
    var_11 = 954
    var_12 = 990
    var_13 = 987
    var_14 = 996
    var_15 = 941
    var_16 = 994
    var_17 = 965
    var_18 = 947
    var_19 = 997
    var_20 = 936
    var_21 = 987
    var_22 = 969
   

# Generated at 2022-06-25 05:22:32.411826
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = -634
    str_0 = "prepositional"
    # Dummy variables for testing
    int_1 = 2
    int_2 = -961
    int_3 = -496
    int_4 = -957
    int_5 = -736
    int_6 = -422
    int_7 = -687
    int_8 = -787
    int_9 = -836
    int_10 = -288
    # Test load_list_of_tasks
    assert load_list_of_tasks(int_1, int_2, int_3, int_4, int_5, int_6, int_7, int_8, int_9, int_10) == str_0


# Generated at 2022-06-25 05:22:38.883343
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # for use with test_function
    def do_test(play, block, role, task_include, use_handlers, variable_manager, loader, ds, test_num):
        try:
            ret = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
        except AnsibleAssertionError as e:
            print("test {} failed: {}".format(test_num, e.message))
            return False

        return True

    # tests
    test_0_ds = 687.19354
    test_0_play = 687.19354
    test_0_block = 687.19354
    test_0_role = 687.19354
    test_0_task_include = 687.19354
    test_0

# Generated at 2022-06-25 05:22:42.985070
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    play = AnsiblePlay()
    task = AnsibleTask()
    role = AnsibleRole()
    task_include = AnsibleTaskInclude()
    use_handlers = False
    # Test function with arguments
    debug_tasks = []
    debug_tasks = load_list_of_tasks(debug_tasks, play, task_include, role, task_include, use_handlers)

# Generated at 2022-06-25 05:22:49.424431
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 0.650237
    complex_0 = complex(-0.6412304 + 0.9172944j)
    int_0 = 0
    none_0 = None
    list_0 = [False, (1 + -9.10298*10**35j), -956.0, -5.5]
    float_1 = 0.669898
    none_1 = None
    boolean_0 = True
    float_2 = 0.622201
    none_2 = None
    float_3 = 0.302303
    none_3 = None
    float_4 = 0.0140462
    str_0 = '+4.27654925209898E0'
    str_1 = '-3.06187986771198E9'