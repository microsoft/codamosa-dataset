

# Generated at 2022-06-25 05:14:12.958986
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:14:14.635773
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert(len(load_list_of_tasks.__code__.co_varnames) == 9)
    assert(len(load_list_of_tasks.__code__.co_argcount) == 9)


# Generated at 2022-06-25 05:14:17.518072
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
    except:
        print("Exception in unit test of function load_list_of_tasks")



# Generated at 2022-06-25 05:14:22.428452
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bytes_0 = b']Q\x802I\xfb\x1d\xf5\xbc\xb8\xe5\xdbY\xa2[\xff8'
    str_0 = 'L=lV7jrN(<'
    var_0 = load_list_of_tasks(bytes_0, str_0)
    
    assert var_0 == 15

    bytes_0 = b'\xad\x98x!n\x1c\xaf\x9b\x11\x16\xdb\xc0\x16\xcd\x8d?\xe2\x1f'
    str_0 = '#Kjh<X9=d'
    var_0 = load_list_of_tasks(bytes_0, str_0)
    
    assert var

# Generated at 2022-06-25 05:14:31.713012
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    play = ''
    block = ''
    role = ''
    task_include = ''
    use_handlers = False
    variable_manager = ''
    loader = ''

    # Testing a basic functionality
    list_of_tasks = load_list_of_tasks([
        {'action': 'shell', 'args': 'ls -l'}
    ], play, block, role, task_include, use_handlers, variable_manager, loader)

    assert list_of_tasks

    # Testing for the inclusion of a dynamic file
    list_of_tasks = load_list_of_tasks([
        {'action': 'include_tasks', 'args': '{{ dynamic_file_path }}'}
    ], play, block, role, task_include, use_handlers, variable_manager, loader)

    assert list

# Generated at 2022-06-25 05:14:35.784956
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    for i in range(100):
        try:
            test_case_0()
        except:
            pass


if __name__ == "__main__":
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:14:46.156685
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'ED?;75\x97k\x90m\xab\x8b\xfd\xcfZ\x9f\x9e\x97\xa3\x10'
    str_1 = 'L\x1f\x98\xa6\x9e2\xda\xc3\x96\x86\xe1\x8a\x17\xa9\x9a'
    var_0 = load_list_of_tasks(str_0, str_1)
    var_0 = load_list_of_tasks(str_1, str_0)
    var_0 = load_list_of_tasks(str_0, str_0)
    var_0 = load_list_of_tasks(str_1, str_1)


# Generated at 2022-06-25 05:14:47.242226
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert True


# Generated at 2022-06-25 05:14:54.744218
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.module_utils.common.collections import ImmutableDict
    bytes_0 = b']Q\x802I\xfb\x1d\xf5\xbc\xb8\xe5\xdbY\xa2[\xff8'
    str_0 = '.a[gi9XGpo2'
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    var_0 = load_list_of_tasks(bytes_0, str_0, bool_0, bool_1, bool_2, bool_3)
    assert isinstance(var_0, list)



# Generated at 2022-06-25 05:14:56.203135
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:15:14.641894
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Usage: ansible-playbook --syntax-check -vvvv %
    # playbooks/ddwrt_router/playbooks/stage_restore_user_settings.yml
    task_dict = dict(action=dict(module='shell', args="echo 'hello world'"))
    play = Mock(spec=Play)
    block = Mock(spec=Block)
    role = Mock(spec=Role)
    task_include = Mock(spec=TaskInclude)
    use_handlers = False
    variable_manager = Mock(spec=VariableManager)
    loader = Mock(spec=DataLoader)

    task_list = load_list_of_tasks([task_dict], play,  block, role,
                                   task_include, use_handlers,
                                   variable_manager, loader)

# Generated at 2022-06-25 05:15:18.038417
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'J[j\tbS(b\rX=Z=OP^2'
    str_1 = 'HRB+(-c+6\x0ch?9OK\x0b'
    var_0 = load_list_of_tasks(str_0, str_1, str_1)



# Generated at 2022-06-25 05:15:23.325716
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'lll'
    str_1 = 'lll'
    str_2 = 'lll'
    str_3 = 'lll'
    str_4 = 'lll'
    str_5 = 'lll'
    str_6 = 'lll'
    str_7 = 'lll'
    var_0 = load_list_of_tasks(str_0, str_1, str_2, str_3, str_4, str_5, str_6, str_7)
    print(var_0)


# Generated at 2022-06-25 05:15:32.896544
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import sys
    str_0 = 'nc\x1e\x0fU6\x1d\x1f3'
    str_1 = 'JF8\x1f3XJF8\x1f3X'
    str_2 = 'JF8\x1f3XJF8\x1f3X'
    str_3 = 'JF8\x1f3XJF8\x1f3X'
    str_4 = 'JF8\x1f3XJF8\x1f3X'
    str_5 = 'JF8\x1f3XJF8\x1f3X'
    str_6 = 'JF8\x1f3XJF8\x1f3X'

# Generated at 2022-06-25 05:15:33.674239
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert False

# Generated at 2022-06-25 05:15:35.531373
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:15:46.107103
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'J[j\tbS(b\rX=Z=OP^2'
    str_1 = 'HRB+(-c+6\x0ch?9OK\x0b'
    str_2 = 'J[j\tbS(b\rX=Z=OP^2'
    var_0 = load_list_of_tasks(str_0, str_1, str_2)
    try:
        sputnik_assert_equals(var_0, str_1)
    except NameError:
        print("sputnik_assert_equals not found, please do the following:")
        print("git clone https://github.com/agroce/sputnik")
        print("cd sputnik")
        print("sudo python3 setup.py install")
        raise Name

# Generated at 2022-06-25 05:15:58.041044
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # load_list_of_tasks(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)

    # Path to the yml_file
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    yml_file = os.path.join(BASE_DIR, '..', '..', '..', '..', 'lib', 'ansible', 'playbook', 'play_context.py')

    # Read in yml_file and parse it with yaml
    yml_content = open(yml_file, "r").read()
    ds = yaml.safe_load(yml_content)

    # Create the Task
    test_task = Task()
    test_task

# Generated at 2022-06-25 05:16:03.455814
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("Test 1 calling load_list_of_tasks with args")
    # Call load_list_of_tasks with arguments.
    load_list_of_tasks('J[j\tbS(b\rX=Z=OP^2', 'HRB+(-c+6\x0ch?9OK\x0b')


# Generated at 2022-06-25 05:16:10.217615
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    list_0 = ['47M\x0c\x1d', '\x0f\x0b*\x1b\x0e', '\\\x1d\x08\rM', '\x17!\x1c\x0e\x1a']
    list_1 = [0, 1, 2, 3, 4]
    list_2 = [0, 1, 2, 3, 4]
    str_0 = 'J[j\tbS(b\rX=Z=OP^2'
    str_1 = 'HRB+(-c+6\x0ch?9OK\x0b'
    var_0 = load_list_of_tasks(list_0, str_0, str_1, list_1, list_2)


# Generated at 2022-06-25 05:16:38.964652
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = -95
    str_1 = -90
    str_2 = -54
    str_3 = -80
    int_0 = -30
    str_4 = 'M\x0f0\x1d'
    str_5 = 'Gv\x0cW8\x1c'
    str_6 = '+\x05\x1e\x19\x1c'
    str_7 = '\\qK\\\x05\x1d'
    str_8 = '\x1c\x1d\x1c\x1d\x1c\x1d\x1c\x1d'
    str_9 = '\x1c\x1d\x1c\x1d\x1c\x1d\x1c\x1d'

# Generated at 2022-06-25 05:16:43.469517
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    try:
        test_case_0()
    except Exception:
        print('Exception: %s' % "False")

# Unit test if this file is run as stand alone program
if __name__ == '__main__':
    test_load_list_of_blocks()

# Generated at 2022-06-25 05:16:45.044838
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_case_0()


# Generated at 2022-06-25 05:16:52.557209
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    result = load_list_of_tasks("example 1", "example 2", str_0, str_1,
                                str_1, str_0, str_1, str_1)
    print("Test 1 for function load_list_of_tasks: ")
    if result is None:
        print("Passed")
    else:
        print("Failed")

if __name__ == "__main__":
    test_case_0()
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:17:01.113954
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    #str_0 = 'J[j\tbS(b\rX=Z=OP^2'
    str_0 = ['test']
    str_1 = 'HRB+(-c+6\x0ch?9OK\x0b'
    str_2 = 'HRB+(-c+6\x0ch?9OK\x0b'
    var_0 = load_list_of_tasks(str_0, str_1, str_2)


# Generated at 2022-06-25 05:17:02.162492
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
  test_case_0()

# Modify this to fit main program

# Generated at 2022-06-25 05:17:08.391931
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = '}Ltj\r`d1\x0fOjh\x16N'
    str_1 = '/\x15/\x0b\x1cD\x16\x11\x02I\x1c'
    var_0 = load_list_of_tasks(str_0, str_1, str_1)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 05:17:15.250505
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:17:22.546792
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    list_of_tasks = [
        {'foo': 'bar'},
        {'action': {'module': 'foo', 'args': None}}
    ]

    # Test case with no args
    result = load_list_of_tasks(list_of_tasks)

    # Check for InvalidTypeError
    if any([True for arg in list_of_tasks if not isinstance(arg, dict)]):
        raise AnsibleAssertionError('ds should be a dict')

    # Check for UnreachableCodeError
    if any([True for arg in list_of_tasks if 'action' in arg]):
        pass


# Generated at 2022-06-25 05:17:33.188106
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = {"module": "include", "args": "", "when": 0}
    str_1 = {"module": "import_tasks", "args": "", "when": 0}
    str_2 = {"module": "include_role", "args": "", "when": 0}
    str_3 = {"module": "import_role", "args": "", "when": 0}
    str_4 = {"module": "test", "args": "", "when": 0}

    load_list_of_tasks([str_0, str_1, str_2, str_3, str_4], True, str_0)

    str_5 = {"module": "hello", "args": "", "when": 0}
    str_6 = {"module": "hello", "args": "", "when": 0}
   

# Generated at 2022-06-25 05:18:04.397632
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'LR\x0c_\x07X1\t\x02Z\n)o\x19'
    str_1 = 'A)J[j\tbS(b\rX=Z=OP^2'
    str_2 = 'U5HRB+(-c+6\x0ch?9OK\x0b'
    str_3 = 'LR\x0c_\x07X1\t\x02Z\n)o\x19'
    str_4 = '\x0bB)J[j\tbS(b\rX=Z=OP^2'
    str_5 = '\x02=U5HRB+(-c+6\x0ch?9OK\x0b'

# Generated at 2022-06-25 05:18:12.871848
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # XFAIL: py26
    # XFAIL: py27,py33
    # Missing information
    str_0 = 'The ds ({0!r}) should be a dict but was a {1!r}'
    # XFAIL: py26
    # XFAIL: py27,py33
    # Missing information
    str_1 = 'The ds ({0!r}) should be a list but was a {1!r}'
    # XFAIL: py26
    # XFAIL: py27,py33
    # Missing information
    str_2 = '{0!r}'
    # XFAIL: py26
    # XFAIL: py27,py33
    # Missing information
    str_3 = 'include'
    str_4 = 'import_tasks'

# Generated at 2022-06-25 05:18:23.315993
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    v = None
    v1 = []
    v2 = None
    str_0 = '6=aU6gZ\x0bW&'
    str_1 = '!y\x0cN*]9i'
    var_0 = load_list_of_tasks(v, v1, v2, str_0, str_1)
    var_1 = load_list_of_tasks(v, v1, v2, str_0, str_1)
    var_2 = load_list_of_tasks(v, v1, v2, str_0, str_1)
    try:
        var_3 = load_list_of_tasks(v, v1, v2, str_0, str_1)
    except AnsibleAssertionError:
        var_3

# Generated at 2022-06-25 05:18:34.305033
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:18:42.056947
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:18:52.334129
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:18:56.780529
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_0 = dict(
        x = dict(
            y = dict(
                z = 1,
            ),
        ),
    )
    test_1 = dict(y = dict(z = 1,),)
    test_2 = dict(x = dict(y = dict(z = 1,),),)
    test_3 = dict(x = dict(y = dict(z = 1,),),)

    # Call function
    ret_value = load_list_of_tasks(test_0, test_1, block=test_2, role=test_3)

    # Check value
    assert ret_value == dict(x = dict(y = dict(z = 1,),),)

# Test case for function load_list_of_tasks

# Generated at 2022-06-25 05:19:01.271584
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'J[j\tbS(b\rX=Z=OP^2'
    str_1 = 'HRB+(-c+6\x0ch?9OK\x0b'
    # Function load_list_of_tasks call with arguments module_name, module_args, delegate_to, complex_args and module_vars

    var_1 = load_list_of_tasks(str_0, str_1, str_1)
    assert isinstance(var_1, list)
    

# Generated at 2022-06-25 05:19:08.833363
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = '\x0c\x10\x0c\x0b\x18!\x18\x1c\x1a\x0b\x12\x0f\r\r\r\r\r\r'

# Generated at 2022-06-25 05:19:18.716174
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # This test case was generated from target/template/ansible.unit/load_list_of_tasks.yml on 2020-06-04 22:15:33.393580
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template.safe_eval import AnsibleUndefinedVariable
    from ansible.errors import AnsibleParserError
    from ansible.template.template import Template
    from ansible.utils.unicode import to_bytes
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import re
    import os
    import sys
    import ansible.constants as C
    from ansible.module_utils._text import to_native
    import ansible.module_utils.six as six

# Generated at 2022-06-25 05:20:07.898015
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    str_0 = 'J[j\tbS(b\rX=Z=OP^2'
    str_1 = 'HRB+(-c+6\x0ch?9OK\x0b'
    var_0 = load_list_of_blocks(str_0, str_1, str_1)
    assert var_0 == 0

# Generated at 2022-06-25 05:20:08.516234
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass


# Generated at 2022-06-25 05:20:13.602264
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    var_0 = 'hB\x90~X\x91e\x1e\x1d'
    var_1 = 'm\x0e\x02\xc9\xf3\x0c\x81\xe1\xcf'
    var_2 = '\xbe\xc2X\x9e\xec\x1fi\x96\x8f\xbc'
    var_3 = '&\x00\xe7\x05\x91\xdc\xf2\xff\xfe'
    var_4 = '\x8d\x0b+p\x0f\x00\x8b\x82\x0e'
    var_5 = 'c\x0e}&\x0eV\xb8\xb0d\xe6\x1f'

# Generated at 2022-06-25 05:20:17.269204
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
  with pytest.raises(AnsibleParserError):
    assert load_list_of_tasks(test_case_0,test_case_0, test_case_0, test_case_0, test_case_0, test_case_0, test_case_0, test_case_0)

# Generated at 2022-06-25 05:20:26.245900
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds_0 = 'F6f\x0e'
    play_0 = 'M@:\\\x04'
    block_0 = None
    role_0 = None
    task_include_0 = None
    use_handlers_0 = False
    variable_manager_0 = None
    loader_0 = '\x15'
    var_0 = load_list_of_tasks(ds_0, play_0, block_0, role_0, task_include_0, use_handlers_0, variable_manager_0, loader_0)

    # print decoded text
    print(var_0)


# Generated at 2022-06-25 05:20:36.595593
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from .test_loader import TestLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from .fixtures import task_include_fixture
    from .fixtures import task_fixture

    from ansible.module_utils import basic

    playbook = Play()
    task = Task()
    task.set_loader(TestLoader())
    block_list = []
    var = load_list_of_tasks(task_include_fixture, playbook, Block(), basic.AnsibleModule, None, False, None, None)
    assert var == block_list
    # assert len(var) == 1



# Generated at 2022-06-25 05:20:46.836880
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    str_0 = 'J[j\tbS(b\rX=Z=OP^2'
    str_1 = 'HRB+(-c+6\x0ch?9OK\x0b'
    str_2 = 'HRB+(-c+6\x0ch?9OK\x0b'
    with raises(Exception):
        var_0 = load_list_of_blocks(str_0, str_1, str_2)
    str_3 = 'J[j\tbS(b\rX=Z=OP^2'
    str_4 = 'HRB+(-c+6\x0ch?9OK\x0b'
    str_5 = 'HRB+(-c+6\x0ch?9OK\x0b'
    var_1 = load_list_of

# Generated at 2022-06-25 05:20:53.484290
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'J[j\tbS(b\rX=Z=OP^2'
    str_1 = 'HRB+(-c+6\x0ch?9OK\x0b'
    var_0 = load_list_of_tasks(str_0, str_1, str_1)

if __name__ == '__main__':
    test_case_0();
    test_load_list_of_tasks();

# Generated at 2022-06-25 05:21:02.803023
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'G9f\n]\x7f\x0b\x7f\x0f\x19\x13'
    str_1 = 'rq\r\x0c\x19Q\x10\tq\x14\x1d\x19\x13\tG'
    str_2 = 'G9f\n]\x7f\x0b\x7f\x0f\x19\x13'
    str_3 = 'e!\x1dL\x1d\x1c\x17\x0c\x12\x11\x0b\x1a\x1d\x1a\x1c\x0b\x04\x19\x07\x1c\x0bw'
    var_0 = load_list

# Generated at 2022-06-25 05:21:10.076812
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:22:46.796549
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'B9X#N5r13>O\rqNT2u/7V'
    str_1 = 'O.3q`Z%5r5F:\\\x7f\x7fD'
    str_2 = 'V7xQHJZDY1\x18\'g\n9?o'
    var_0 = load_list_of_tasks(str_0, str_1, str_1, str_2)


# Generated at 2022-06-25 05:22:52.949020
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = ['a', 'b']
    play = 'play'
    block = 'block'
    role = 'role'
    task_include = 'task_include'
    use_handlers = False
    variable_manager = 'variable_manager'
    loader = 'loader'
    obj_0 = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert len(obj_0) == 2
    obj_1 = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert len(obj_1) == 2
    assert obj_1[1] == obj_1[1]

    ds = []
    obj_2 = load_list_of

# Generated at 2022-06-25 05:23:03.073053
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = {'action': 'test', 'args': {'test': 'test'}}
    play = {'become': True}
    block = 'block'
    role = 'role'
    task_include = 'task_include'
    use_handlers = True
    variable_manager = 'variable_manager'
    loader = 'loader'
    result = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert result[0]._parent == block
    assert result[0]._play == play
    assert result[0]._role == role
    assert result[0]._task_include == task_include
    assert result[0]._use_handlers == use_handlers
    assert result[0]._variable_manager == variable_

# Generated at 2022-06-25 05:23:08.101748
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'J[j\tbS(b\rX=Z=OP^2'
    str_1 = 'HRB+(-c+6\x0ch?9OK\x0b'
    var_0 = load_list_of_tasks(str_0, str_1, str_1)

# Unit tests

# main()
if __name__ == '__main__':

    # Unit tests
    test_case_0()
    # Unit test for function load_list_of_tasks
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:23:13.744645
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:23:22.348686
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = var_0 = None
    with pytest.raises(AnsibleAssertionError) as excinfo:
        load_list_of_tasks(str_0, str_0, str_0, str_0, str_0)
    excinfo.match("should be a list")
    str_0 = []
    str_1 = []
    var_0 = load_list_of_tasks(str_0, str_0, str_0, str_0, str_0)
    assert var_0 == str_1
    str_0 = [{'block': {'block': []}}]
    str_1 = load_list_of_blocks(str_0, str_0, str_0)

# Generated at 2022-06-25 05:23:28.018816
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'q@5g5f5'
    str_1 = "p\\*'`"
    list_0 = [2, [1, 5, 3], 3]
    target_0 = load_list_of_tasks(list_0, str_1, str_0)
    assert target_0 == ([], (), 2, [1, 5, 3], 3)
    target_1 = load_list_of_tasks(list_0, str_0, str_1)
    assert target_1 == ([], (), 2, [1, 5, 3], 3)
    target_2 = load_list_of_tasks(list_0, str_0, str_0)
    assert target_2 == ([], (), 2, [1, 5, 3], 3)
    target_3 = load_list_

# Generated at 2022-06-25 05:23:31.368534
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("\n\n")
    test_case_0()


# Generated at 2022-06-25 05:23:34.036290
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert 1 == 1

# Generated at 2022-06-25 05:23:36.984291
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    yaml_doc = {
        'name': 'test'
    }
    ret = load_list_of_tasks(yaml_doc, None, None, None, None, True, None, None)
    assert ret is not None
