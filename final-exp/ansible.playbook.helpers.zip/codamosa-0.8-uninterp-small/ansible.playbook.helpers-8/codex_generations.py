

# Generated at 2022-06-25 05:14:12.508586
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'YE}>LzXWqF8mo'
    bool_0 = True

    # Call method load_list_of_tasks with arguments str_0 and bool_0
    assert load_list_of_tasks(str_0, bool_0) == null

# Generated at 2022-06-25 05:14:13.319020
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert test_case_0() is None


# Generated at 2022-06-25 05:14:19.084205
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'YE}>LzXWqF8mo'
    str_1 = 'nH1c7hb8X3WV7'
    bool_0 = True
    int_0 = (str_1 + str_0)
    str_2 = '7N0{dbxRx2M[='
    int_1 = int_0 ** str_0
    int_1 = (2 ** int_1)
    int_1 = (int_1 + int_0)
    int_1 = (int_1 * int_0)
    int_1 = (int_1 + 2)
    int_1 = (2 ** int_1)
    int_1 = (int_1 + int_0)
    int_1 = (int_1 * int_0)

# Generated at 2022-06-25 05:14:20.344603
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
    except:
        pass


# Generated at 2022-06-25 05:14:23.144922
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    args_0 = 'YE}>LzXWqF8mo'
    args_1 = True
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True



# Generated at 2022-06-25 05:14:32.224955
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Ensures that load_list_of_tasks produces the correct output
    #
    # Input arguments:
    #    str_0: A string
    #    bool_0: A boolean

    str_0 = 'YE}>LzXWqF8mo'
    bool_0 = True
    assert load_list_of_tasks(str_0, bool_0) == str_0
    
    str_0 = '*#?_gxO7]K.W8'
    bool_0 = True
    assert load_list_of_tasks(str_0, bool_0) == str_0
    
    str_0 = 'YE}>LzXWqF8mo'
    bool_0 = False

# Generated at 2022-06-25 05:14:43.520516
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    class TestPlay(object):
        def __init__(self):
            self.hosts = 'localhost'
            self.name = 'playname'
            self.hosts = 'somehost'
            self.name = 'playname'

    class TestBlock(object):
        def __init__(self):
            self.always = ['always']
            self.block = ['block']
            self.rescue = ['rescue']
            self.failure = ['failure']

    list_0 = list()
    play_0 = TestPlay()
    block_0 = TestBlock()
    role_0 = 'root'
    task_include_0 = 'task_include_0'
    use_handlers_0 = True
    variable_manager_0 = 'variable_manager_0'

# Generated at 2022-06-25 05:14:45.269724
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    bool_0 = True
    str_0 = 'wD{_FVp]rk%c7'
    var_0 = load_list_of_roles(str_0, bool_0)


# Generated at 2022-06-25 05:14:49.427555
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test case for normal input
    str_0 = "YE}>LzXWqF8mo"
    bool_0 = True
    var_0 = load_list_of_tasks(str_0, bool_0)

    # Test case for abnormal input
    str_0 = None
    var_0 = load_list_of_tasks(str_0, str_0)

    # Test case for abnormal input
    str_0 = "Wg&8rvT6jZp"
    bool_0 = True
    var_0 = load_list_of_tasks(str_0, bool_0)
    print(var_0)

    # Test case for abnormal input
    str_0 = "Wp]v0<53P5nZ"
    bool_0 = True

# Generated at 2022-06-25 05:14:52.060737
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'F|[p{8nF1B=z#)o'
    bool_0 = True
    var_0 = load_list_of_tasks(str_0, bool_0)

# Generated at 2022-06-25 05:15:12.557753
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    func = load_list_of_tasks

    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

if __name__ == '__main__':
    print('Hello')
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:15:19.663337
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{'yaml_data': '4f4}utXgp6N2U6'}]
    play = 'z!T=1Q2_E?\\bP'
    block = '43{YcZ.G$rRCz'
    role = 'fgu,u1@5xK7*)'
    task_include = ')D}t`1Q2_E?\\bP'
    use_handlers = '9Q2_E?\\bPz!T='
    variable_manager = '43{YcZ.G$rRCz'
    loader = '4f4}utXgp6N2U6'

    task_list = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)

# Generated at 2022-06-25 05:15:30.810579
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    #print ("\nUnitTest: load_list_of_tasks")
    task_ds = None
    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    tqm = None
    play._tq

# Generated at 2022-06-25 05:15:32.958871
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 05:15:42.306228
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """
    Tests load_list_of_tasks
    """

    # test variables
    ds = {
        'a': 'b',
        'c': 'd'
    }
    play = 'play'
    block = 'block'
    role = 'role'
    task_include = 'task_include'
    use_handlers = True
    variable_manager = {
        'e': 'f',
        'g': 'h'
    }
    loader = 'loader'

    # test the code
    result = load_list_of_tasks(
        ds,
        play,
        block,
        role,
        task_include,
        use_handlers,
        variable_manager,
        loader
    )

    # test asserts
    assert result is not None

# Generated at 2022-06-25 05:15:54.080115
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Load modules from the 'tests' directory to test
    from ansible.modules.playbook import static
    from ansible.playbook import play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    ###########################################
    # Module import tests
    ###########################################

    # Unreachable code
    #raise AnsibleParserError("Error when evaluating variable in import path: %s.\n\n" "When using static imports, ensure that any variables used in their names are defined in vars/vars_files\n" "or extra-vars passed in from the command line. Static imports cannot use variables from facts or inventory\n" "sources like group or host vars." % t.args['_raw_params'], obj=

# Generated at 2022-06-25 05:15:56.319481
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass


# Generated at 2022-06-25 05:15:57.465634
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_case_0()


# Generated at 2022-06-25 05:15:58.515468
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True


# Generated at 2022-06-25 05:16:07.439678
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Mock example
    mock_loader = MagicMock()
    mock_loader.path_dwim_relative.return_value = './vars'
    mock_loader.path_dwim.return_value = './vars'
    mock_loader.load_from_file.return_value = './vars'

    mock_variable_manager = MagicMock()
    mock_variable_manager.get_vars.return_value = './vars'

    mock_play = MagicMock()
    mock_task = MagicMock()

    # Mock args
    mock_block = MagicMock()
    mock_block.get_vars.return_value = './vars'
    mock_ds = MagicMock()

    mock_role = MagicMock()
    mock_task_include = MagicMock

# Generated at 2022-06-25 05:16:43.834710
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test case
    try:
        test_case_0()
    except (AnsibleAssertionError, TypeError, AnsibleParserError) as e:
        display.vvv(to_text(e, traceback))
        display.error(to_text(e))
        assert False

# Generated at 2022-06-25 05:16:50.607525
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds = [1,2,3]
    play = TestPlay()
    parent_block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = 'variable_manager'
    loader = 'loader'
    try:
        retval = load_list_of_blocks(ds, play, parent_block, role, task_include, use_handlers, variable_manager, loader)
    except TypeError as ex:
        print('AnsibleAssertionError:  %s' % to_native(ex))
    else:
        print(retval)


# Generated at 2022-06-25 05:16:54.934351
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 = 'YE}>LzXWqF8mo'
    var_1 = True
    var_2 = load_list_of_tasks(var_0, var_1)
    assert var_2


# Generated at 2022-06-25 05:17:03.456525
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test with invalid type for ds
    # TypeError raises when invalid type
    with pytest.raises(TypeError):
        str_0 = 'YE}>LzXWqF8mo'
        bool_0 = True
        load_list_of_tasks(str_0, bool_0)
    # Test with invalid type for play
    # TypeError raises when invalid type
    with pytest.raises(TypeError):
        list_0 = []
        bool_1 = True
        load_list_of_tasks(list_0, bool_1)
    # Test with invalid type for block
    # TypeError raises when invalid type
    with pytest.raises(TypeError):
        list_1 = []
        bool_2 = True

# Generated at 2022-06-25 05:17:08.587497
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = '''
- hosts: all
  tasks:
    - name: test
      debug: msg="{{item}}"
      with_items:
        - "{{host}}"
'''
    bool_0 = True

    try:
        var_0 = load_list_of_tasks(str_0, bool_0)
        display.display(var_0)
    except Exception as e:
        display.display(e)
        assert False



# Generated at 2022-06-25 05:17:17.659712
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'YE}>LzXWqF8mo'
    bool_0 = True
    var_0 = load_list_of_tasks(str_0, bool_0)
    str_1 = 'YE}>LzXWqF8mo'
    bool_1 = False
    var_1 = load_list_of_tasks(str_1, bool_1)
    str_2 = 'YE}>LzXWqF8mo'
    bool_2 = True
    var_2 = load_list_of_tasks(str_2, bool_2)
    str_3 = 'YE}>LzXWqF8mo'
    bool_3 = False
    var_3 = load_list_of_tasks(str_3, bool_3)

# Generated at 2022-06-25 05:17:28.412239
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test cases
    test_case_0()


# END OF GENERATED CODE
#-------------------------------------------------------------------------------

playbook_path = 'play.yml'
variable_manager = VariableManager()
loader = DataLoader()

if len(sys.argv) != 2:
    print("Usage: %s <playbook_path>" % sys.argv[0])
    sys.exit(1)
else:
    playbook_path = sys.argv[1]

try:
    pb = Playbook.load(playbook_path, variable_manager=variable_manager, loader=loader)
except AnsibleParserError as e:
    print(e.message)
    sys.exit(1)

print("Loaded %s plays" % len(pb.get_plays()))

# Generated at 2022-06-25 05:17:35.210331
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = 'YE}>LzXWqF8mo'
    play = True
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    var_0 = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert var_0 == None and\
    "AssertionError: 'YE}>LzXWqF8mo' should be a list but was a <class 'str'>"

# Generated at 2022-06-25 05:17:43.725194
# Unit test for function load_list_of_blocks

# Generated at 2022-06-25 05:17:46.922496
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("Loading test for function load_list_of_tasks...")
    test_case_0()

# Run unit tests
if __name__ == '__main__':
    test_load_list_of_tasks()
    print("Unit test for function load_list_of_tasks is done.\n\n")



# Generated at 2022-06-25 05:18:43.911522
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
    except (AnsibleAssertionError, AnsibleParserError) as e:
        display.error(str(e))


# Generated at 2022-06-25 05:18:54.186051
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 = True
    var_1 = True
    var_2 = True
    var_3 = True
    var_4 = 'u7Gww|>bUd7Vp'
    var_5 = load_list_of_tasks(var_2, var_3, var_4)
    var_6 = 'FshdW/X~x{eBl'
    var_7 = 4
    var_8 = 4
    var_5 = load_list_of_tasks(var_6, var_7, var_8)
    var_9 = 'YE}>LzXWqF8mo'
    var_10 = True
    var_5 = load_list_of_tasks(var_9, var_10)
    var_11 = True
    var_12 = True
   

# Generated at 2022-06-25 05:18:54.937229
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    if test_case_0():
        print('Done!')

# Generated at 2022-06-25 05:18:55.586146
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_case_0()



# Generated at 2022-06-25 05:19:05.930591
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 = True
    var_1 = True
    var_2 = 'a'
    var_3 = 'b'
    var_4 = True
    var_5 = True
    var_6 = 'c'
    var_7 = 'd'
    var_8 = True
    var_9 = True
    var_10 = 'e'
    var_11 = 'f'
    var_12 = True
    var_13 = True
    var_14 = 'g'
    var_15 = 'h'
    var_16 = True
    var_17 = True
    var_18 = 'i'
    var_19 = 'j'
    var_20 = True
    var_21 = True
    var_22 = 'k'
    var_23 = 'l'
    var_24 = True


# Generated at 2022-06-25 05:19:13.067772
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'YE}>LzXWqF8mo'
    bool_0 = True
    var_0 = load_list_of_tasks(str_0, bool_0)
    assert str_0 == 'YE}>LzXWqF8mo'
    assert bool_0 == True
    assert var_0 == []


# Generated at 2022-06-25 05:19:18.762686
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    out = load_list_of_tasks(None, "Ansible", block=None, role=True, task_include=None, use_handlers=True, variable_manager=None, loader=True)
    assert out != None
    assert out != ""
    assert out != True
    assert out != False


# Generated at 2022-06-25 05:19:21.887219
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'YE}>LzXWqF8mo'
    bool_0 = True
    var_0 = load_list_of_tasks(str_0, bool_0)
    if (var_0 == False):
        test_case_0()


# Generated at 2022-06-25 05:19:29.478550
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'YE}>LzXWqF8mo'
    bool_0 = True
    var_0 = load_list_of_tasks(str_0, bool_0)
    assert len(var_0) == 0
    assert isinstance(var_0, list)
    str_1 = '=BO|n18gB,c#'
    bool_1 = False
    var_1 = load_list_of_tasks(str_1, bool_1)
    assert len(var_1) == 0
    assert isinstance(var_1, list)
    str_2 = '-L+S,1F~Oju|'
    bool_2 = True
    var_2 = load_list_of_tasks(str_2, bool_2)

# Generated at 2022-06-25 05:19:33.898036
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """Test case for load_list_of_tasks function
    """
    print("Running Test for load_list_of_tasks")
    test_case_0()

# Generated at 2022-06-25 05:20:25.756616
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    str_0 = 'YE}>LzXWqF8mo'
    bool_0 = True
    list_0 = [None, None, str_0, str_0]
    list_1 = [None, None, None, None, None, None, str_0, str_0, str_0, str_0, str_0, None, None, None, None]
    var_0 = load_list_of_blocks(list_0, list_1, str_0, str_0, str_0, True, list_1, list_0)


# Generated at 2022-06-25 05:20:33.465400
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        # Test case 0
        str_0 = 'YE}>LzXWqF8mo'
        bool_0 = True
        var_0 = load_list_of_tasks(str_0, bool_0)
    except Exception as e:
        display.Display().display(str(e))
        print("Failed to run test_load_list_of_tasks")
    
if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:20:43.438714
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Should throw an exception, since the first parameter is an int
    try:
        load_list_of_tasks(0, True)
    except AnsibleAssertionError:
        pass

    # Should throw an exception, since the second parameter is an int
    try:
        load_list_of_tasks('YE}>LzXWqF8mo', 0)
    except AnsibleAssertionError:
        pass

    # Should throw an exception, since the first parameter is a boolean
    try:
        load_list_of_tasks(True, True)
    except AnsibleAssertionError:
        pass

    # Should throw an exception, since the first parameter is a boolean
    try:
        load_list_of_tasks(True, True, None)
    except AnsibleAssertionError:
        pass

# Generated at 2022-06-25 05:20:45.969058
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
    except Exception as e:
        print('Caught exception: ', e)
        raise AssertionError('load_list_of_tasks() produced an exception')



# Generated at 2022-06-25 05:20:56.049293
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'YE}>LzXWqF8mo'
    bool_0 = True
    var_0 = load_list_of_tasks(str_0, bool_0)

# Initiate validation and test cases
if __name__ == '__main__':
    # Unit test for function load_list_of_tasks
    test_load_list_of_tasks()
    # Unit test for function load_list_of_tasks
    test_load_list_of_tasks()
    # Unit test for function load_list_of_tasks
    test_load_list_of_tasks()
    # Unit test for function load_list_of_tasks
    test_load_list_of_tasks()
    # Unit test for function load_list_of_tasks
    test_

# Generated at 2022-06-25 05:21:01.987499
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    str_0 = 'PzXG?qF8mo'
    bool_0 = True
    str_1 = 'YE}>LzXWqF8mo'
    bool_1 = True
    var_0 = load_list_of_tasks(str_1, bool_1)
    var_1 = load_list_of_blocks(str_0, bool_0)


# Generated at 2022-06-25 05:21:02.984161
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert test_case_0() == 0


# Generated at 2022-06-25 05:21:07.435042
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = 'YE}>LzXWqF8mo'
    play = True
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    result = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert isinstance(result, list)


# Generated at 2022-06-25 05:21:15.377713
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'YE}>LzXWqF8mo'
    bool_0 = True
    var_0 = load_list_of_tasks(str_0, bool_0)
    print(var_0)

if __name__ == "__main__":
    test_load_list_of_tasks()
    test_case_0()

# Generated at 2022-06-25 05:21:22.686054
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = '[1, 2, 3, 4]'
    bool_0 = True
    var_0 = load_list_of_tasks(str_0, bool_0)
    assert var_0 == [1, 2, 3, 4], var_0
    str_1 = '[8, 3, 5, 6]'
    bool_1 = True
    var_1 = load_list_of_tasks(str_1, bool_1)
    assert var_1 == [8, 3, 5, 6], var_1
    str_2 = '[0, 5, 1, 9, 6]'
    bool_2 = True
    var_2 = load_list_of_tasks(str_2, bool_2)
    assert var_2 == [0, 5, 1, 9, 6], var_2
    str_