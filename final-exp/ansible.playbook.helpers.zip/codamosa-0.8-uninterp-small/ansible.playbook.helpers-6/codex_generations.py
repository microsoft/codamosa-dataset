

# Generated at 2022-06-25 05:14:13.329373
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = 'q=59krO(R$3d)JG@'
    play = 'q=59krO(R$3d)JG@'
    block = 'q=59krO(R$3d)JG@'
    role = 'q=59krO(R$3d)JG@'
    task_include = 'q=59krO(R$3d)JG@'
    use_handlers = False
    variable_manager = 'q=59krO(R$3d)JG@'
    loader = 'q=59krO(R$3d)JG@'
    var_0 = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)


# Generated at 2022-06-25 05:14:15.721999
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bool_0 = False
    str_0 = 'waQt!5*gPbs~rW'
    var_0 = load_list_of_tasks(str_0, bool_0)
    var_1 = load_list_of_tasks(str_0, bool_0)


if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:14:25.060675
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    str_2 = 'Hxa:EDC!E_$#v&DQ'
    bool_2 = False
    var_0 = str_2
    var_1 = bool_2
    var_0 = test_case_0()


# unit test data for load_list_of_blocks

# Generated at 2022-06-25 05:14:33.552728
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    str_0 = 'q=59krO(R$3d)JG@'
    bool_0 = True
    var_0 = load_list_of_roles(str_0, bool_0)
    if not isinstance(var_0, list):
        raise Error('test_load_list_of_roles(): FAILED, did not return a list')

    str_1 = 'E/Rb^,{y5&*<.E'
    bool_1 = True
    var_1 = load_list_of_roles(str_1, bool_1)
    if not isinstance(var_1, list):
        raise Error('test_load_list_of_roles(): FAILED, did not return a list')


# Generated at 2022-06-25 05:14:44.374867
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:14:53.495016
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bool_0 = True
    bool_1 = True
    dict_0 = {'action': '', 'args': {}}
    list_0 = ['module']
    bool_2 = False
    list_1 = [dict_0]
    dict_1 = {'action': '', 'delegate_to': '', 'args': {'statically_loaded': False}}
    dict_2 = {'_role': None}
    dict_3 = {'action': '', 'delegate_to': ''}
    dict_4 = {'action': '', 'loop': '', 'args': {'statically_loaded': False}}
    dict_5 = {'action': '', 'args': {'statically_loaded': False}}

# Generated at 2022-06-25 05:15:02.276998
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:15:06.901475
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test 1
    # Input:
    str_0 = 'C8V;W18lX9xV&%:P'
    bool_0 = True
    var_0 = load_list_of_tasks(str_0, bool_0)

    # Expected result:
    # var_0 = []

    # Function output:
    print('var_0 = ', var_0)
    
# Unit tests for function load_list_of_blocks

# Generated at 2022-06-25 05:15:14.409418
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # This test case will produce a list of tasks from a list of dictionaries
    ds_0 = [{'include_tasks' : './../../../../basics.yml', 'name' : 'Include task file dynamically'}, {'include_tasks' : './../../../../basics.yml', 'static' : True}, {'include_tasks' : './../../../../basics.yml', 'static' : False}]
    play_0 = Play().load('../../../../ansible/test/units/modules/utilities/logic/test_action_plugins/ansible.cfg', variable_manager=None, loader=None)
    block_0 = Block()

# Generated at 2022-06-25 05:15:21.950092
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.plugins import loader as plugin_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # These variables are necessary to run Ansible tasks
    # Source: https://github.com/ansible/ansible/blob/devel/test/test_api.py#L12-L14
    loader = DataLoader()
    options = Options()


# Generated at 2022-06-25 05:15:46.015278
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
    except (UnicodeEncodeError, AnsibleAssertionError) as e:
        print(e)
        raise Exception('Unit test failed')


if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:15:51.262240
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:15:54.293368
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_case_0()

if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:15:55.816454
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert False  # TODO: implement your test here

# Unit tests for function load_list_of_blocks

# Generated at 2022-06-25 05:15:59.194143
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = '^`}R#=J'
    str_1 = '^`}R#=J'
    var_0 = load_list_of_tasks(str_0, str_1)


# Generated at 2022-06-25 05:16:07.980120
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:16:20.103222
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 = {}
    var_0['test_case_0'] = {
        'input': '^`}R#=J',
        'expected_result': None,
        'expected_type': None
    }
    var_0['test_case_1'] = {
        'input': '^`}R#=J',
        'expected_result': None,
        'expected_type': None
    }
    var_0['test_case_2'] = {
        'input': '^`}R#=J',
        'expected_result': None,
        'expected_type': None
    }


# Generated at 2022-06-25 05:16:26.885158
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        func = load_list_of_tasks.__code__.co_argcount
    except AttributeError:
        func = load_list_of_tasks.func_code.co_argcount

    assert func == 9

    try:
        test_case_0()
    except AssertionError:
        pass
    except AnsibleUndefinedVariable:
        pass
    except AnsibleParserError:
        pass

# Generated at 2022-06-25 05:16:32.885380
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        assert len(load_list_of_tasks('', '')) == 0
        assert len(load_list_of_tasks([], '')) == 0
        assert len(load_list_of_tasks({}, '')) == 0
        assert len(load_list_of_tasks([{}, {}], '')) == 0
    except (AssertionError, AnsibleAssertionError) as e:
        print('AssertionError: %s' % e)
        exit(1)

    # TODO: implement tests for the remaining cases

if __name__ == "__main__":
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:16:39.133353
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = '^`}R#=J'
    var_0 = load_list_of_tasks(str_0, str_0)
    assert var_0 == '^`}R#=J'

# Generated at 2022-06-25 05:17:17.010507
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    func_name = sys._getframe().f_code.co_name
    print("====> %s" % func_name)

    var_0 = load_list_of_tasks(str_0, str_0)
    print("Var_0 is %s" % var_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:17:18.520176
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Should not crash
    test_case_0()



# Generated at 2022-06-25 05:17:24.347044
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # This function test the case where load_list_of_tasks is working normally
    try:
        test_case_0()
    # This exception happens when loading '^`}R#=J' as a list
    except TypeError:
        pass
    except Exception:
        raise
    else:
        raise Exception('load_list_of_tasks did not fail in the expected way')

if __name__ == '__main__':
    # Unit test for function load_list_of_tasks
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:17:24.980306
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert False



# Generated at 2022-06-25 05:17:32.197393
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Initialize the environment
    str_0 = 'Ncs"`#/`B9OJ2/O8c;'
    # Run unit test
    test_case_0()
    try:
        test_case_0()
        print('test case 0 run successfully')
    except:
        print('test case 0 failed')
test_load_list_of_tasks()

# Generated at 2022-06-25 05:17:40.229292
# Unit test for function load_list_of_blocks

# Generated at 2022-06-25 05:17:47.659789
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 = load_list_of_tasks(None, None)
    var_1 = load_list_of_tasks('', '')
    var_2 = load_list_of_tasks('', False)
    var_3 = load_list_of_tasks(0, 0)
    var_4 = load_list_of_tasks('', 0)
    var_5 = load_list_of_tasks(0, '')
    var_6 = load_list_of_tasks(0, False)
    var_7 = load_list_of_tasks('', 0)
    var_8 = load_list_of_tasks('', False)
    var_9 = load_list_of_tasks(0, '')

# Generated at 2022-06-25 05:17:53.239927
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 = load_list_of_tasks(str, str)
    
    assert isinstance(var_0, list) is True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:17:56.543816
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # No assertion testing
    test_case_0()



# Generated at 2022-06-25 05:18:04.104212
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = [{'action': 'ping'}]
    play = task_ds
    block = play
    role = block
    task_include = role
    use_handlers = task_include
    variable_manager = use_handlers
    loader = variable_manager
    assert len(load_list_of_tasks(task_ds, play, block, role, task_include, use_handlers, variable_manager, loader)) == 1


# Generated at 2022-06-25 05:18:30.583368
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    class Test_load_list_of_tasks(unittest.TestCase):
        def test_0(self):
            str_0 = '^`}R#=J'
            var_0 = load_list_of_tasks(str_0, str_0)
            self.assertNotEqual(var_0, None)
            self.assertNotEqual(var_0, [])

    suite = unittest.TestLoader().loadTestsFromTestCase(Test_load_list_of_tasks)
    unittest.TextTestRunner(verbosity=2).run(suite)

if __name__ == '__main__':
    test_case_0()
    #test_load_list_of_tasks()

# Generated at 2022-06-25 05:18:41.098022
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    logger.info('Testing load_list_of_tasks')
    failure_case_0()
    failure_case_1()
    failure_case_2()
    failure_case_3()
    failure_case_4()
    failure_case_5()
    failure_case_6()
    failure_case_7()
    failure_case_8()
    failure_case_9()
    failure_case_10()
    failure_case_11()
    failure_case_12()
    failure_case_13()
    failure_case_14()
    failure_case_15()
    failure_case_16()
    failure_case_17()
    failure_case_18()
    failure_case_19()
    failure_case_20()
    failure_case_21()
    failure_case_22()

# Generated at 2022-06-25 05:18:43.710028
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    for param_1 in range(3, 7):
        test_case_0()



# Generated at 2022-06-25 05:18:47.141231
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:18:56.608026
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.executor.task_queue_manager import TaskQueueManager

    all_vars = dict(
        test_var = 'foobar'
    )
    variable_manager = VariableManager(loader=None, variables=all_vars)


# Generated at 2022-06-25 05:19:01.542806
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
    except:
        print('Test Failed!')
    else:
        print('Test Passed!')

# Main function

# Generated at 2022-06-25 05:19:04.426925
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
    except Exception as e:
        print("Exception raise:")
        print(e)
        assert False


if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:19:07.563925
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    x = Templatetest.data

    for y in x:
        assert(load_list_of_tasks(y, None) == None)


'''
Test for Main function
'''

# Generated at 2022-06-25 05:19:18.050115
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:19:25.749147
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Case 0
    try:
        test_case_0()
    # TypeError: expected 'str' or 'bytes'
    except TypeError:
        assert True

    # Case 1
    str_0 = 'role name'
    var_0 = load_list_of_tasks(str_0, str_0)
    # should be: [{'block': [{'block': [{'block': [{'include_role': {'name': '{{ role_name }}'}}]}]}]}]
    print(var_0)
    assert type(var_0) is list

    # Case 2
    str_0 = 'role name'
    var_1 = load_list_of_tasks(str_0, str_0)
    # should be: [{'block': [{'block': [{'block

# Generated at 2022-06-25 05:20:01.635921
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 = '?P%}'
    var_1 = 'cez(;'
    var_2 = 'S=5'
    var_3 = '`HqY4'
    var_4 = '}r@'
    var_5 = '0g1F'
    var_6 = '0'
    var_7 = '`HqY4'
    var_8 = '7ah'
    var_9 = '2'
    var_10 = '}r@'
    var_11 = ':D_1'
    var_12 = 'y%3=@'
    var_13 = '?P%}'
    var_14 = 'cez(;'
    var_15 = '^`}R#=J'


# Generated at 2022-06-25 05:20:11.076828
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Testing if the function raises the correct exceptions
    try:
        load_list_of_tasks(str, str)

    except AnsibleAssertionError as e:
        assert type(e) == AnsibleAssertionError

    try:
        load_list_of_tasks(str, str, str)

    except AnsibleAssertionError as e:
        assert type(e) == AnsibleAssertionError

    try:
        load_list_of_tasks('foo', 'foo')

    except AnsibleParserError as e:
        assert type(e) == AnsibleParserError

    try:
        load_list_of_tasks('foo', 'foo', 'foo')

    except AnsibleParserError as e:
        assert type(e) == AnsibleParserError


# Generated at 2022-06-25 05:20:13.763259
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print('')
    try:
        test_case_0()
    except Exception as e:
        print('FAILED: {}'.format(e))

# Global Variable Definitions

# Function Definitions

# Main
if __name__ == "__main__":
    #test_load_list_of_tasks()
    print('hello')

# Generated at 2022-06-25 05:20:20.209279
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    hostvar = {'hostvars': {}, 'inventory_hostname': 'testhost', 'inventory_hostname_short': 'testhost'}
    str_0 = 'TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST'
    var_0 = load_list_of_roles(str_0, str_0, str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 05:20:25.681171
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = '^`}R#=J'
    var_0 = load_list_of_tasks(str_0, str_0)
    assert var_0 == None

test_case_0()

# Generated at 2022-06-25 05:20:36.266127
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 = load_list_of_tasks('', str_0)
    var_1 = load_list_of_tasks(str_0, str_0)
    var_2 = load_list_of_tasks(var_0, var_1)
    var_2 = load_list_of_tasks(var_1, var_0)
    try:
        var_3 = load_list_of_tasks(var_2, var_0)
    except AnsibleAssertionError:
        pass
    var_4 = load_list_of_tasks(var_1, var_1)
    var_5 = load_list_of_tasks('', var_0)
    var_5 = load_list_of_tasks(str_0, var_0)
    var_6

# Generated at 2022-06-25 05:20:40.127620
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    assert callable(load_list_of_tasks)

    test_case_0()


# Generated at 2022-06-25 05:20:43.164014
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    with pytest.raises(AnsibleAssertionError) as excinfo:
        test_case_0()
    assert "should be a list but was a <class 'str'>" in str(excinfo.value)

# Generated at 2022-06-25 05:20:49.484625
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Replace this with your test code
    assert str(load_list_of_tasks('1', '2')) == '3'
    assert str(load_list_of_tasks('1', '2', '3')) == '4'
    assert str(load_list_of_tasks('1', '2', '3', '4')) == '5'
    assert str(load_list_of_tasks('1', '2', '3', '4', '5')) == '6'
    assert str(load_list_of_tasks('1', '2', '3', '4', '5', '6')) == '7'
    assert str(load_list_of_tasks('1', '2', '3', '4', '5', '6', '7')) == '8'
   

# Generated at 2022-06-25 05:20:53.481338
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
    except AssertionError as e:
        print('AssertionError: ', e.args)
    except Exception as e:
        print('Exception: ', e.args)

# main function entry
if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:21:52.239854
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    try:
        # Testing with arguments
        test_case_0()
        assert False
    except AssertionError:
        assert True
    except Exception:
        assert False

    try:
        # Testing with no arguments
        test_case_1()
        assert False
    except AssertionError:
        assert True
    except Exception:
        assert False

    try:
        # Testing with arguments
        test_case_2()
        assert False
    except AssertionError:
        assert True
    except Exception:
        assert False


# Test case 0

# Generated at 2022-06-25 05:21:53.420271
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:21:55.855546
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    for i in range(10000):
        test_case_0()


# Generated at 2022-06-25 05:21:59.097072
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    print("Test function load_list_of_roles")
    str_0 = 'x=Gv'
    str_1 = 'fT3!'
    str_2 = '{6^9'
    var_0 = load_list_of_roles(str_0, str_1, str_2)
    print(var_0)



# Generated at 2022-06-25 05:22:01.393566
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
    except:
        print("Failed test case 0")
        raise

# end of load_list_of_tasks


# Generated at 2022-06-25 05:22:05.374277
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # control flow: if-then-else
    if CURRENT_TEST_CASE == 0:
        test_case_0()



# Generated at 2022-06-25 05:22:08.941732
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:22:18.483122
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print('Testing function load_list_of_tasks')

    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    from tempfile import mkdtemp
    from shutil import rmtree

    from ansible.compat.six import string_types
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.module_utils.six import iteritems
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task import Task

# Generated at 2022-06-25 05:22:20.834971
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
    except Exception as e:
        display.warning(e)

if __name__ == "__main__":
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:22:25.422146
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print()
    print(load_list_of_tasks.__name__)

    # Setup argument values
    # ds = 
    # play = 
    # block = 
    # role = 
    # task_include = 
    # use_handlers = 
    # variable_manager = 
    # loader = 

    # Obtain the result
    result = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)

    # Output results
    print(result)

if __name__ == '__main__':
    # test_case_0()
    test_load_list_of_tasks()