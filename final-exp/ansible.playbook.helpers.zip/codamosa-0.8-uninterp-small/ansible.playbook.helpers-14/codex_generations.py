

# Generated at 2022-06-25 05:14:03.176060
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # No exception thrown for None arg
    load_list_of_tasks(None, None, None)

    # No exception thrown for valid args
    mock_play = mock.Mock()
    t = mock.Mock()
    t.block = 'block'
    r = mock.Mock()
    load_list_of_tasks(['task'], mock_play, t, role=r)


# Generated at 2022-06-25 05:14:06.744637
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test a basic load_list_of_tasks call
    test_case_0()

# Test module functionality if run as script
if __name__ == "__main__":
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:14:13.488509
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from tests.unit.test_loader import load_fixture_to_data
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play import Play
    
    data = load_fixture_to_data('test_load_list_of_tasks.json')
    play = Play.load(data)
    play._variable_manager = combine_vars(loader=None, play=play)
    task_list = load_list_of_tasks(data, play=play)
    assert len(task_list) == 3
    assert isinstance(task_list[0], include)
    assert isinstance(task_list[1], block)
    assert isinstance(task_list[2], task)

# Generated at 2022-06-25 05:14:19.369325
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    
    # Testcase constructed from examples listed at: https://docs.python.org/3/library/ array.html#test-suite
    # Note: In the test case below, the variable 'testcase' is a variable of type 'list'
    # The variable 'template' is a variable of type 'str'
    testcase = [
        [
            {
                "role": {
                    "name": "myrole"
                },
                "name": "myrole"
            }
        ]
    ]
    template = 'myrole'
    # Note: the variable 'play' used in the testcase below is a variable of type 'Play'
    play = {}
    # Note: the variable 'current_role_path' used in the testcase below is a variable of type 'str'

# Generated at 2022-06-25 05:14:27.007622
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Example for function load_list_of_roles
    ds = [{'role': 'dacp_install'}]
    play = None
    current_role_path = None
    variable_manager = None
    loader = None
    collection_search_list = None
    roles = load_list_of_roles(ds, play, current_role_path, variable_manager, loader, collection_search_list)
    print(roles)


# Generated at 2022-06-25 05:14:30.335508
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 = set()
    var_1 = 'lD/'
    var_2 = 'po5y'
    var_3 = load_list_of_tasks(var_0, var_1, var_2)
    print (var_3)


# Generated at 2022-06-25 05:14:36.391480
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds_0 = {'dict': {'nested': {'dict': 'foobar'}}}
    ds_1 = None
    ds_2 = {'list': [{'dict': {'nested': 'foobar'}}, {'dict': {'nested': {'dict': 'foobar'}}}]}
    ds_3 = 'foobar'
    ds_4 = [{'dict': {'nested': {'dict': 'foobar'}}}, {'dict': {'nested': 'foobar'}}]
    ds_5 = {'dict': {'nested': 'foobar'}}
    parent_block_0 = Block()
    role_0 = Role()
    task_include_0 = Task()
    use_handlers_0 = False
    variable_manager_0 = Variable

# Generated at 2022-06-25 05:14:46.850858
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Input parameters
    #   ds: a list of mixed task/block data (parsed from YAML)
    #   play:
    #   block:
    #   role:
    #   task_include:
    #   use_handlers:
    #   variable_manager:
    #   loader:
    # Returns a list of Block() objects, where implicit blocks are created for each bare Task.
    ds        = None
    play      = None
    block     = None
    role      = None
    task_include = None
    use_handlers = None
    variable_manager = None
    loader    = None

    load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)

##
# Load ansible.utils.ssh_fun

# Generated at 2022-06-25 05:14:49.327089
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
	# Test for unexpected type(s)
    try:
        load_list_of_tasks()
    except Exception as e:
        print (str(e))

# Generated at 2022-06-25 05:14:57.849214
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Verify if the required list of roles is loaded correctly
    current_role_path = os.path.join(os.path.dirname(__file__), 'test_role', 'roles')
    loader = DataLoader()
    varmgr = VariableManager()
    play_path = os.path.join(os.path.dirname(__file__), "test_role_include", "test_playbook.yaml")
    play = Play().load(play_path, loader=loader)
    collection_search_list = ['collect2', 'collect1']
    actual_output = load_list_of_roles(play.include_roles, play, current_role_path, varmgr, loader, collection_search_list)

# Generated at 2022-06-25 05:15:17.279868
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    class TestPlay(object):
    # This class may be used to contain the mock objects returned by mocker.mock_open
        pass
    test_play = TestPlay()
    test_play.ROLE_CACHE = {}
    test_play.ROLE_WARNINGS = 0
    def test_ds():
        return [{'action': {'delegate_to': '{{ inventory_hostname }}', 'argv': ['ps', '-ef']}}]
    def test_block():
        return None
    def test_role():
        return None
    def test_task_include():
        return None
    def test_use_handlers():
        return False

# Generated at 2022-06-25 05:15:20.813535
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    vars = {}
    vars['test_of_list_of_tasks'] = load_list_of_tasks()
    print(vars['test_of_list_of_tasks'])
    assert True

# Generated at 2022-06-25 05:15:31.537042
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # test1
    print('\n---Test 1: Test empty ds---')
    class AnsibleParserError1(Exception):
        pass
    try:
        load_list_of_tasks(None,play=None,block=None,role=None,task_include=None,use_handlers=False,variable_manager=None,loader=None)
    except AnsibleParserError1 as error:
        print(error)

    # test2
    print('\n---Test 2: Test invalid ds---')
    class AnsibleParserError2(Exception):
        pass
    ds1 = {}

# Generated at 2022-06-25 05:15:40.347498
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Try to call this function with some botch arguments
    try:
        load_list_of_tasks(ds=1, play=1, block=1, role=1, task_include=1, use_handlers=1, variable_manager=1, loader=1)
    except AnsibleAssertionError as ae:
        assert(ae.args[0] == 'The ds (1) should be a list but was a <type \'int\'>')

    # Try to call this function with some botch arguments

# Generated at 2022-06-25 05:15:49.745856
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Generate a simple data structure that has 1 block and 1 task.
    ds = [
        {'task': {
            'local_action': 'command echo hello'
        }},
        {'block': [
            {'task': {'local_action': 'command echo hello from block'}}
        ]}
    ]

    # Create the BlockLoader and initialize, passing in the data structure.
    loader = DataLoader()
    display = Display()
    variable_manager = VariableManager(loader=loader, inventory=None)
    play_source = dict(
        name="ansible-test",
        hosts='localhost',
        gather_facts='no',
        tasks=ds
    )

    # Create the Play and populate it with it's parameters.

# Generated at 2022-06-25 05:15:54.551116
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    loader = DictDataLoader({})
    variable_manager = VariableManager(loader=loader)

    role_def = {
        'name': 'some_role'
    }
    roles = load_list_of_roles([role_def], variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-25 05:15:58.299133
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # We create a mock loader and ds
    loader_mock = MagicMock()
    ds_mock = MagicMock()

    role_include_mock = load_list_of_roles(ds_mock, loader_mock)

    assert role_include_mock is not None

# Generated at 2022-06-25 05:16:07.408185
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    variable_manager = VariableManager()
    loader = DataLoader()
    loader.set_basedir('/')
    vars = dict(test_var="test")
    variable_manager.set_vars(vars=vars)

# Generated at 2022-06-25 05:16:08.434183
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # FIXME: implement this test
    return


# Generated at 2022-06-25 05:16:19.563492
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("\n---------- TEST: load_list_of_tasks() ----------")
    ### Initialization ###
    var_0 = load_list_of_tasks()
    
    ### Test Functionality ###
    assert_equals(var_0, None)
    
    ### Test Format ###
    assert_true(var_0 is None or isinstance(var_0, (int, int)))
    
    ### Test Type ###
    assert_true(var_0 is None or isinstance(var_0, (int, int)))

if __name__ == '__main__':
    #test_load_list_of_tasks()
    #test_load_list_of_blocks()
    print("\nTest complete.")

# Generated at 2022-06-25 05:17:01.215036
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = \
        '''
        - hosts: all
          connection: local
          gather_facts: no
          tasks:
          - fail:
            msg: "{{MY_VAR}}"
        '''

    # Do some computation to get the YAML structure we'll use.
    a_play = load(str_0)
    load_list_of_tasks(a_play[str_0]['tasks'], a_play)
    load_list_of_tasks(a_play[str_0]['tasks'], a_play)
    load_list_of_tasks(a_play[str_0]['tasks'], a_play)
    load_list_of_tasks(a_play[str_0]['tasks'], a_play)
    load_list

# Generated at 2022-06-25 05:17:12.823563
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task

    str_0 = '<string>'
    dict_0 = {str_0: str_0}
    list_00 = []
    list_0 = [dict_0]
    list_0 = list_0 + list_00

    test_data = [
        (None, None),
        (list_0, list_0),
        (str_0, None)
    ]
    for i in range(len(test_data)):
        if i == 1:
            var_0 = load_list_of_tasks(test_data[i][0], test_data[i][1])
        # print(type(var_0[0]))
        # assert isinstance(var_0[0], Task)
        # print(var_0[0])
       

# Generated at 2022-06-25 05:17:14.099216
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_s = {'foo': 'bar'}
    test_s.update()


# Generated at 2022-06-25 05:17:22.639007
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """
    load_list_of_tasks(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None,
                       loader=None)

    Given a list of task datastructures (parsed from YAML), return a list of Task() or TaskInclude() objects
    """

    args_0 = [
        {
            'block':   None,
            'handler': {
                'name': 'manage_lvm'
            }
        },
        {
            'block':   None,
            'handler': {
                'name': 'manage_lvm'
            }
        }
    ]


# Generated at 2022-06-25 05:17:32.982948
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # We save the current sys.stdout and sys.stderr, so we can restore them
    # later.
    stdout_old = sys.stdout
    stderr_old = sys.stderr
    # We override the print function and catch the prints.
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()

# Generated at 2022-06-25 05:17:34.095556
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # FIXME: Add appropriate test cases here, if known
    pass


# Generated at 2022-06-25 05:17:42.658074
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    t1 = Task.load(dict(_raw_params="test",action="test_action",args={}))
    t2 = Task.load(dict(_raw_params="test",action="test_action2",args={}))
    t3 = Task.load(dict(_raw_params="test",action="test_action3",args={}))

    # Test for all branches
    test_cases = [t1, t2, t3]
    ret = load_list_of_tasks(test_cases, None, None, None, None, None, None, None)
    assert(ret == [t1, t2, t3])

    # Test for all branches but with one task
    test_cases = [t1]

# Generated at 2022-06-25 05:17:53.945944
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = ''
    str_1 = 'f'
    str_2 = 'exv'
    str_3 = 'wI'
    str_4 = '4b'
    str_5 = ':'
    str_6 = 'wo'
    str_7 = 'o'
    str_8 = '6P'
    str_9 = 'E'
    str_10 = 'w'
    str_11 = '7m'
    str_12 = ','
    str_13 = 'zF'
    str_14 = 'd'
    str_15 = 'i'
    str_16 = 'n'
    str_17 = 's'
    str_18 = 'n'
    str_19 = 'X'
    str_20 = 'w'
    str_21 = 'j'

# Generated at 2022-06-25 05:18:04.102883
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    list_0 = list()
    bool_0 = False
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()
    bool_23 = bool()


# Generated at 2022-06-25 05:18:09.919548
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = '*/ifconfig'
    str_1 = ''
    str_2 = 'z'
    str_3 = 'x'
    int_0 = 0
    str_4 = 'w'
    int_1 = 1
    str_5 = 'v'
    str_6 = 'u'
    str_7 = 't'
    str_8 = 's'
    str_9 = 'r'
    str_10 = 'q'
    str_11 = 'p'
    str_12 = 'o'
    str_13 = 'n'
    str_14 = 'm'
    str_15 = 'l'
    str_16 = 'k'
    str_17 = 'j'
    str_18 = 'i'
    str_19 = 'h'

# Generated at 2022-06-25 05:18:44.069275
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task1_ds = {'arg1': 'one', 'arg2': 'two'}
    task2_ds = {'arg1': 'three', 'arg2': 'four'}
    task_ds = [task1_ds, task2_ds]
    play = True
    task_list = load_list_of_tasks(task_ds, play)
    assert task_list[0]['arg1'] == 'one'
    assert task_list[0]['arg2'] == 'two'
    assert task_list[1]['arg1'] == 'three'
    assert task_list[1]['arg2'] == 'four'


# Generated at 2022-06-25 05:18:49.124603
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    str_0 = ''
    bool_0 = False
    dict_0 = {str_0: bool_0}
    var_0 = load_list_of_tasks(str_0, bool_0, dict_0)

# Generated at 2022-06-25 05:18:56.673654
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bool_0 = False
    str_1 = ''
    dict_0 = {str_1: bool_0}
    var_0 = load_list_of_tasks('', dict_0, dict_0, '', bool_0)
    var_1 = load_list_of_tasks(dict_0, dict_0, dict_0, '', bool_0)
    var_2 = load_list_of_tasks([], dict_0, dict_0, '', bool_0)
    var_3 = load_list_of_tasks({}, dict_0, dict_0, '', bool_0)

    test_case_0()


# Generated at 2022-06-25 05:19:00.620383
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # create a mock task data structure
    task_ds = {'action': 'ping', 'name': 'test task 0'}
    task_list = load_list_of_tasks([task_ds], None, task_include=None, use_handlers=False)
    # check the returned task has the right action
    assert task_list[0].action == 'ping'
    # check the returned task has the right name
    assert task_list[0].name == 'test task 0'

# Generated at 2022-06-25 05:19:08.237518
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Example of a call to the function:
    # load_list_of_roles(ds, play, current_role_path=None, variable_manager=None, loader=None, collection_search_list=None)

    # Note: list_0 and str_3 are not used.
    list_0 = []
    str_0 = '#0f{'
    str_1 = '@0b`'
    str_2 = 'P8'
    str_3 = 'Yd{'
    str_4 = 'C,?,B'
    str_5 = '^'
    bool_0 = True
    bool_1 = False
    int_0 = 1
    int_1 = 1
    int_2 = 1
    int_3 = 1
    int_4 = 1
    int_5 = 1
   

# Generated at 2022-06-25 05:19:13.999467
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # We need to create some mock objects to pass the object check
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    variable_manager.set_play_context(play_context)

    templar = Templar(loader=loader, variables=variable_manager.get_vars())

    block_mock = Block()
    block_mock.vars = {}

# Generated at 2022-06-25 05:19:21.495506
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'asd'
    str_1 = 'asd'
    str_2 = 'asd'
    str_3 = 'asd'
    str_4 = 'asd'
    str_5 = 'asd'
    str_6 = 'asd'
    str_7 = 'asd'
    str_8 = 'asd'
    str_9 = 'asd'
    str_10 = 'asd'
    str_11 = 'asd'
    str_12 = 'asd'
    str_13 = 'asd'
    str_14 = 'asd'
    str_15 = 'asd'
    str_16 = 'asd'
    str_17 = 'asd'
    str_18 = 'asd'
    str_19 = 'asd'

# Generated at 2022-06-25 05:19:27.737119
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.errors import AnsibleParserError
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.playbook.task import Task
    from ansible.template import Templar

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block

    # test parser error raised with no block
    task_list = list()
    ds = dict()
    ds['use_handlers'] = True
    try:
        load_list_of_tasks(ds, bool(), task_list)
    except AnsibleParserError as e:
        assert 'is required' in to_native(e)


    # test AnsibleAssertion with non list as input

# Generated at 2022-06-25 05:19:30.644356
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_1 = ''
    str_2 = '__main__.Block'
    dict_1 = {str_1: str_2}
    var_1 = load_list_of_tasks(str_1, bool(), dict_1)


# Generated at 2022-06-25 05:19:36.042126
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = ''
    bool_0 = False
    dict_0 = {str_0: bool_0}
    var_0 = load_list_of_tasks(dict_0, bool_0, dict_0, str_0, str_0, bool_0, str_0, str_0)


# Generated at 2022-06-25 05:20:37.452282
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    mytask = "{'name': 'mytask'}"
    localhost = "{'name': 'localhost'}"
    myaction = "{'action': 'myaction'}"
    mymodule = "{'module': 'mymodule'}"
    myargs = "{'args': 'myargs'}"
    mytask2 = "{'name': 'mytask2'}"
    mytask3 = "{'name': 'mytask3'}"
    mytask4 = "{'name': 'mytask4'}"
    tasks1 = [mytask, mytask2, mytask3, mytask4]
    play1 = "{'name': 'play1'}"
    block1 = "{'block': 'block1'}"
    role1 = "{'role': 'role1'}"
    task_include1 = "{'task_include': 'task_include1'}"

# Generated at 2022-06-25 05:20:42.346465
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = ''
    bool_0 = False
    dict_0 = {str_0: bool_0}
    var_0 = load_list_of_tasks(str_0, bool_0, dict_0)
    return var_0


# Generated at 2022-06-25 05:20:49.139145
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test for exceptions
    try:
        # Test for proper function
        # FIXME: use mock objects for this test
        #test_case_1()
        pass
    except Exception as e:
        print ("Error in the test case have occurred " + str(e))


# Generated at 2022-06-25 05:20:52.045894
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    #module = AnsibleModule(
    #    argument_spec = dict(
    #        bool=dict(default=False, type='bool'),
    #    ),
    #    supports_check_mode=True
    #)
    str_0 = ''
    bool_0 = False
    dict_0 = {str_0: bool_0}
    var_0 = load_list_of_tasks(str_0, bool_0, dict_0)

# Generated at 2022-06-25 05:21:02.678469
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    int_0 = 0
    bool_0 = False
    str_0 = ''
    str_1 = 'abc'
    str_2 = 'abc'
    bool_1 = True
    list_0 = []
    list_1 = []
    tuple_0 = (bool_0, str_0, list_0)
    tuple_1 = (str_1, bool_1, list_1)
    tuple_2 = (str_2, tuple_1, bool_0)
    list_2 = [tuple_0, tuple_1, tuple_2]
    str_3 = 'abc'
    str_4 = 'abc'
    bool_2 = False
    list_3 = []
    list_4 = []
    str_5 = 'abc'
    str_6 = 'abc'

# Generated at 2022-06-25 05:21:11.545030
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    arg_0 = 'abc'
    arg_1 = None
    arg_2 = 'DEF'
    arg_3 = None
    arg_4 = 'GHI'
    arg_5 = None
    arg_6 = 'JKL'
    arg_7 = None
    arg_8 = 'MNO'
    arg_9 = None
    arg_10 = 'PQR'
    arg_11 = None
    arg_12 = 'STU'

    list_0 = [arg_0, arg_2, arg_4, arg_6, arg_8, arg_10]
    var_0 = load_list_of_tasks(list_0, arg_1, arg_3, arg_5, arg_7, arg_9, arg_11, arg_12)

# Generated at 2022-06-25 05:21:14.957116
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    try:
        test_case_0()
    except Exception as e:
        print("Caught exception in test_load_list_of_blocks:", to_native(e))
        raise



# Generated at 2022-06-25 05:21:22.342647
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    #TEST CASE 4
    config_data = yaml.load(open(os.path.join(DATA_PATH, 'tasks_0_wf.yml'), 'r'))
    var_0 = load_list_of_tasks(config_data, dict_0)

    #TEST CASE 5
    config_data = yaml.load(open(os.path.join(DATA_PATH, 'tasks_1_wf.yml'), 'r'))
    var_1 = load_list_of_tasks(config_data, dict_0)

    #TEST CASE 6
    config_data = yaml.load(open(os.path.join(DATA_PATH, 'tasks_2_wf.yml'), 'r'))

# Generated at 2022-06-25 05:21:23.660329
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # no need to do
    pass

# Generated at 2022-06-25 05:21:31.768596
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.utils import display
    from ansible.errors import AnsibleError
    from ansible.utils.hashing import checksum
    from ansible import constants as C
    import pytest
    import sys
    import os
    import inspect
    import datetime
    import time

    # import pytest


# Generated at 2022-06-25 05:22:34.480594
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = ''
    bool_0 = False
    dict_0 = {str_0: bool_0}
    var_0 = load_list_of_tasks(dict_0, bool_0, dict_0, bool_0, bool_0)
    print(var_0)

test_case_0()

test_load_list_of_tasks()

# Generated at 2022-06-25 05:22:42.773318
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = '/'
    str_1 = 'sudo'
    str_2 = 'yum'
    _args_1 = {str_0: str_0, str_1: str_1, str_2: str_2, 'name': 'python-2.7.13'}
    dict_0 = {str_0: str_1, str_1: str_1, 'delegate_to': str_0, 'args': _args_1}

    dict_1 = dict_0.copy()
    dict_1['any_errors_fatal'] = False
    dict_1['block'] = [dict_0]
    dict_1['block'][0]['any_errors_fatal'] = False

    dict_2 = dict_1.copy()

# Generated at 2022-06-25 05:22:49.212461
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    print("Start Test: Load list of roles")
    # Create some test variables
    str_0 = "TEST"
    str_1 = "TEST"
    str_2 = "TEST"
    str_3 = "TEST"
    dict_0 = {str_3: str_3, str_2: [str_2], str_1: str_0}
    dict_1 = {str_1: str_2}
    dict_2 = {str_0: str_0}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {str_1: dict_0, str_0: dict_1}
    dict_6 = {}
    dict_7 = {str_2: dict_2, str_1: dict_3}
    dict_8 = {}
    dict_9

# Generated at 2022-06-25 05:22:54.444746
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = ''
    str_1 = 'a'
    bool_0 = False
    obj_0 = load_list_of_tasks(str_0, str_1, bool_0)
    obj_1 = load_list_of_tasks(str_0, str_1, bool_0)
    var_0 = load_list_of_tasks(str_0, str_1, bool_0)
    var_1 = load_list_of_tasks(str_0, str_1, bool_0)
    var_1 = load_list_of_tasks(str_0, str_1, bool_0)
    var_1 = load_list_of_tasks(str_0, str_1, bool_0)

# Generated at 2022-06-25 05:22:55.255712
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_case_0()


# Generated at 2022-06-25 05:23:04.953970
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Get the source path of the current module
    source_path = os.path.dirname(os.path.realpath(__file__))
    # Compute the path to the test script
    test_script = os.path.join(source_path, 'play.yml')
    # Load the test script
    with open(test_script, 'r') as f:
        test_script = f.read()
    # Now parse the script
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    loader = AnsibleLoader(test_script, None, None)
    vars = VariableManager()
    # Convert to Python data type
    play_data, _ = loader.get_single_data()
    # Test the

# Generated at 2022-06-25 05:23:09.366385
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # ---------- Test with all defaults ----------
    data_0 = ''
    play_0 = ''
    block_0 = ''
    role_0 = ''
    task_include_0 = ''
    use_handlers_0 = False
    variable_manager_0 = ''
    loader_0 = ''

    try:
        list_0 = load_list_of_tasks(data_0, play_0, block_0, role_0, task_include_0, use_handlers_0, variable_manager_0, loader_0)
        assert False
    except (AnsibleAssertionError, TypeError) as e:
        assert e.__class__.__name__ == 'AnsibleAssertionError'
    except Exception as e:
        assert False


# Generated at 2022-06-25 05:23:13.937095
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Given a list of task datastructures (parsed from YAML),
    # Return a list of Task() or TaskInclude() objects.
    args = {'task_ds':{'action': 'test_test_test', 'param_a':'test1', 'param_b':'test2'}}
    ret = load_list_of_tasks(**args)
    assert len(ret) == 1

    args = {'task_ds':[{'action': 'test_test_test', 'param_a':'test1', 'param_b':'test2'}, {'action': 'test_test_test', 'param_a':'test1', 'param_b':'test2'}]}
    ret = load_list_of_tasks(**args)
    assert len(ret) == 2


# Generated at 2022-06-25 05:23:19.289246
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    try:
        assert callable(load_list_of_blocks)
        # Calls the function
        test_case_0()
        # No exception thrown
    except (AssertionError, TypeError, ValueError) as e:
        print('An exception is thrown at: ', e)
    except Exception as e:
        print('An exception is thrown at: ', e)

# Generated at 2022-06-25 05:23:22.238087
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass
