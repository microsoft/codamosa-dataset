

# Generated at 2022-06-25 05:14:08.911267
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    output_file = "temp.txt"
    ds = [dict(action='include', args=dict(a=1,static='yes'), delegate_to='localhost'),
          dict(action='import_tasks', args=dict(a=1,static='yes'), delegate_to='localhost'),
          dict(action='async_status', args=dict(), delegate_to='localhost'),
          dict(action='assert', args=dict(equals=[1,1]), delegate_to='localhost'),
          dict(action='blockinfile', args=dict(path='/path/to/file', block='# stuff'), delegate_to='localhost')]
    ds_incl = [dict(action='include', args=dict(a=1,static='yes'), delegate_to='localhost')]
    dict_0 = None

# Generated at 2022-06-25 05:14:13.318169
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Define function inputs
    ds = 42
    play = 56
    block = 86
    role = 42
    task_include = 56
    use_handlers = 42
    variable_manager = 56
    loader = 86

    # Get the result
    result = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    # Verify the result
    assert (result == 56)


# Generated at 2022-06-25 05:14:19.251876
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:14:26.486777
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # first test an empty ds:
    try:
        load_list_of_tasks(None)
        assert False, 'AnsibleAssertionError not raised'
    except AnsibleAssertionError:
        pass

    # next test a list ds with no items:
    try:
        load_list_of_tasks([])
        assert False, 'AnsibleAssertionError not raised'
    except AnsibleAssertionError:
        pass

    # now test a list with a non-dict item:
    try:
        load_list_of_tasks([123])
        assert False, 'AnsibleAssertionError not raised'
    except AnsibleAssertionError:
        pass

    # now test a list with a non-dict item:

# Generated at 2022-06-25 05:14:34.339776
# Unit test for function load_list_of_roles

# Generated at 2022-06-25 05:14:42.952307
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task1 = {'action': 'set_fact', 'args': ''}
    task2 = {'action': 'set_fact', 'args': ''}
    task3 = {'block': 'command'}
    ds = [task1, task2, task3]
    play = ''
    block = []
    role = ''
    task_include = ''
    use_handlers = False
    variable_manager = ''
    loader = ''
    ret = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert ret is None


# Generated at 2022-06-25 05:14:52.188203
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # #
    # TEST-1: Ensure load_list_of_tasks returns list of objects of type Task or TaskInclude
    #
    ds = [
        {
            'block': [
            ],
            'include': 'tasks/test-consul.yml'
        },
        {'include': 'tasks/test-elasticsearch.yml'}
    ]

    # We need defined objects and functions for the test
    class task:
        def __init__(self, *args, **kwargs):
            pass

    class task_include:
        def __init__(self, *args, **kwargs):
            pass

    class play:
        def __init__(self, *arg, **kwargs):
            pass

    task_list = load_list_of_tasks(ds, play())

# Generated at 2022-06-25 05:15:00.953994
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():


    # This is a list
    list_1 = ['list', 'this', 'is']
    # This is a list
    list_2 = [
        'list',
        'this',
        'is']

    # This is a dictionary
    dict_0 = {}
    # This is a dictionary
    dict_1 = {'key': 'value'}
    # This is a dictionary
    dict_2 = {
        'key': 'value'}

    # This is a string
    string_0 = 'my string'
    # This is a string
    string_1 = "my string"
    # This is a string
    string_2 = "my string {0}".format(string_0)

    # This is a number
    number_0 = 100
    # This is a number
    number_1 = 100.1

# Generated at 2022-06-25 05:15:11.215468
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test case 0
    float_0 = 932.11651
    list_0 = None
    var_0 = load_list_of_tasks(float_0, list_0)
    assert (var_0 == None)

    # Test case 1
    float_0 = 759.1707704430588
    list_0 = [None]
    var_0 = load_list_of_tasks(float_0, list_0)
    assert (var_0 == None)

    # Test case 2
    dict_0 = "{'action': 'win_copy', 'dest': 'C:\\Users\\Administrator\\Documents\\ansible.exe', 'src': 'C:\\Users\\Administrator\\Documents\\ansible.exe'}"

# Generated at 2022-06-25 05:15:12.329027
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    float_0 = 836.24
    list_0 = None
    list_1 = load_list_of_blocks(float_0, list_0)
    # No assertion, loaded


# Generated at 2022-06-25 05:15:39.265770
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 932.11651
    list_0 = None
    dict_0 = {'a': float_0}
    dict_1 = {'b': float_0}
    dict_2 = {'c': float_0}
    list_1 = [dict_0, dict_1, dict_2]

    list_2 = load_list_of_tasks(list_1, float_0, list_0, list_0, list_0, False, list_0, list_0)
    print(list_2)


# Generated at 2022-06-25 05:15:40.708298
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass  # FIXME: load_list_of_tasks should be tested


# Generated at 2022-06-25 05:15:47.253370
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 = [[], ]
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = load_list_of_tasks(var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7)
    assert var_8 == []


# Generated at 2022-06-25 05:15:58.299176
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_data = [
        {
            'roles': [
                {'role': {'meta': 'meta.yml', 'name': 'test_role_0'}}
            ]
        },
        {'role': {'meta': 'meta.yml', 'name': 'test_role_1'}},
        'test_role_2'
    ]
    test_roles = load_list_of_roles(test_data)
    assert len(test_roles) == 3
    assert test_roles[0].get_name() == 'test_role_0'
    assert test_roles[1].get_name() == 'test_role_1'
    assert test_roles[2].get_name() == 'test_role_2'


# Generated at 2022-06-25 05:16:01.685324
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 932.11651
    list_0 = None
    var_0 = load_list_of_roles(float_0, list_0)


# Generated at 2022-06-25 05:16:05.175699
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 519.3046
    list_0 = None
    var_0 = load_list_of_tasks(float_0, list_0)


if __name__ == '__main__':
    test_load_list_of_tasks()
    test_case_0()

# Generated at 2022-06-25 05:16:10.405003
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    print("test_load_list_of_tasks")

    # Setup input argument values
    ds = "ds"
    play = "play"
    block = "block"
    role = "role"
    task_include = "task_include"
    use_handlers = "use_handlers"
    variable_manager = "variable_manager"
    loader = "loader"

    # Compute the result using the function
    result = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)

    # Print the result
    print(result)
    print("Done!")

# Generated at 2022-06-25 05:16:19.446986
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # From /home/travis/miniconda3/envs/ansible-test/share/ansible/ansible/playbook/__init__.py:1401
    #
    #     Given a list of task datastructures (parsed from YAML),
    #     return a list of Task() or TaskInclude() objects.
    #

    # Example of a list of task datastructures, not sure if this is correct
    # yml_task_list = ['task_ds']

    # We are testing a no-op
    pass
    # TODO: Fix incorrect test
    # assert load_list_of_tasks(yml_task_list) == True


# Generated at 2022-06-25 05:16:27.536245
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    list<dict> ds = new list<dict>()
    list<dict> task_ds = new list<dict>()
    task_ds.append({"args":{"test":"test_0"}})
    task_ds.append({"block":{"block":task_ds}})
    ds.append({"block":{"block":task_ds}})
    list<Task> task_list = load_list_of_tasks(ds)
    assert task_list
    '''
    # FIXME: Actually write this test
    raise NotImplementedError


# Generated at 2022-06-25 05:16:37.493298
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    float_0 = 0.425140
    float_1 = float_0
    float_1 = float_0
    float_1 = float_0
    float_1 = float_0
    float_1 = float_0
    float_1 = float_0
    float_1 = float_0
    str_0 = "py"
    float_1 = float_0
    int_0 = 4
    float_1 = float_0
    int_1 = 8
    float_1 = float_0
    int_3 = 2
    float_1 = float_0
    int_4 = 6
    float_1 = float_0
    int_5 = 1
    float_1 = float_0
    int_6 = 3
    float_1 = float_0
    int_9 = 5

# Generated at 2022-06-25 05:16:56.153292
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    print(test_load_list_of_blocks.__doc__)

    print("Test1: Float")
    try:
        test_case_0()
    except AnsibleAssertionError as e:
        print(e)
    else:
        print("Wrong behavior")


# Generated at 2022-06-25 05:17:04.146028
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # create tmp file for testing
    (fd, test_file) = tempfile.mkstemp()
    with open(test_file, "w") as f:
        f.write("{}")
    os.close(fd)

    p = PlayBook.load("test.yml", variable_manager=VariableManager(), loader=DataLoader())

    ## This test is currently failing and needs to be addressed.
    # test_role = Role()
    # test_role._role_name = "test_role"
    #
    # test_include = TaskInclude()
    # test_include.args = dict()
    # test_include.args['_raw_params'] = "TEST"
    # test_include._role = test_role
    #
    # test_task = Task()
    # test_task.args = dict

# Generated at 2022-06-25 05:17:13.679549
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{'shell': 'hostname'}, {'action': 'include', 'args': 'foo.yml'}, {'get_url': 'http://foo'}]
    play = {}
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    # test that type of ds is list and result is list of tasks
    task_list = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert type(task_list) is list
    assert isinstance(task_list[0], Task)
    assert isinstance(task_list[1], TaskInclude)
    assert isinstance(task_list[2], Task)

# Generated at 2022-06-25 05:17:20.108675
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible.playbook.play
    import ansible.playbook.block
    import ansible.playbook.task

    # Setup fixture
    float_0 = 836.24
    var_0 = ansible.playbook.play.Play()
    var_1 = [ansible.playbook.block.Block(var_0, var_0)]
    var_2 = load_list_of_tasks(float_0, var_0, None, None, None, False, None, None)
    # Call function and check output
    assert var_2 == var_1


# Generated at 2022-06-25 05:17:27.636025
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # test case 0
    float_0 = 836.24
    var_0 = None
    var_1 = load_list_of_tasks(float_0, var_0)
    var_2 = load_list_of_tasks(float_0, var_0)
    assert (var_1 == var_2)


# Generated at 2022-06-25 05:17:31.362224
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_case_0()

if __name__ == "__main__":
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:17:39.617338
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 0
    var_0 = None
    var_1 = 1.10
    var_2 = 'hcf'
    var_3 = 'sbdqhjb'
    var_4 = False
    float_0 = 672.67
    float_1 = 7.28
    float_2 = 5.16
    float_3 = 1.46
    float_4 = 4.87
    float_5 = 10.65
    str_0 = 'njd'
    str_1 = 'fia'
    str_2 = 'xyy'
    str_3 = 'rnp'
    str_4 = 'qyd'
    str_5 = 'azk'
    str_6 = 'min'
    str_7 = 'tvy'
    str_8 = 'dsd'


# Generated at 2022-06-25 05:17:46.988138
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:17:57.582261
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    #Test1: taskds is a list
    tasks = [
        {
            'action': 'ping',
        },
        {
            'action': 'ping1',
        }
    ]
    task_list = load_list_of_tasks(tasks, None, None, None, None, False, None, None)
    assert len(task_list) == 2, "Test1 failed"
    assert isinstance(task_list[0], Task)
    assert isinstance(task_list[1], Task)

    #Test2: taskds is not a list
    tasks = {"test" : "test1"}
    try:
        load_list_of_tasks(tasks, None, None, None, None, False, None, None)
    except AnsibleAssertionError as e:
        assert str(e)

# Generated at 2022-06-25 05:17:58.246892
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass

# Generated at 2022-06-25 05:18:34.304767
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # test function load_list_of_tasks
    print("test function load_list_of_tasks")

    ######
    # prepare
    ######

    # create a mock loader
    loader_mock = mock.MagicMock()
    loader_mock.get_basedir = mock.MagicMock(return_value='/tmp')

    # create a mock variable_manager
    variable_manager_mock = mock.MagicMock()
    variable_manager_mock.get_vars = mock.MagicMock(return_value={})

    # create a mock play
    play_mock = mock.MagicMock()
    play_mock.handlers = []

    # create a mock task_include
    task_include_mock = mock.MagicMock()

    # create a mock parent_block
   

# Generated at 2022-06-25 05:18:42.056724
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    list_0 = [836.24, 'dict_0', 'dict_1', 'dict_2']
    list_1 = ['list_0', None, 56.429999999999994, 'dict_0', 'dict_1', 'dict_2']
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    var_0 = None
    var_1 = load_list_of_tasks(list_1, list_0, dict_2, dict_0, dict_1)
    var_1 = load_list_of_tasks(list_0, list_1, dict_2, dict_0, dict_1)
    var_1 = load_list_of_tasks(list_0, list_1, dict_1, dict_0, dict_2)


# Generated at 2022-06-25 05:18:47.177823
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("test_load_list_of_tasks")

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()

if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:18:51.659965
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 836.24
    var_0 = None
    var_1 = load_list_of_tasks(float_0, var_0)

if __name__ == "__main__":
    test_case_0()
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:18:59.425231
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible.playbook.task
    import ansible.playbook.role
    ansible.playbook.task.Task.load = task_load_mock
    ansible.playbook.role.role_definition.load = role_load_mock

    # Test call with the following arguments:
    #     ds = 3.2
    #     play = None
    #     block = None
    #     role = None
    #     task_include = None
    #     use_handlers = False
    #     variable_manager = None
    #     loader = None
    # Your code should set the expected results as follows:
    #     expected_result = None

    data = [3.2]
    ansible_module._ANSIBLE_ARGS = object()

# Generated at 2022-06-25 05:19:01.207346
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
    except AssertionError as e:
        print(e)

# Generated at 2022-06-25 05:19:08.771978
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # python -m ansible.playbook.play_context test_load_list_of_tasks
    # not very robust, but good enough for now.
    display.verbosity = 4
    loader = DataLoader()
    passwords = {}
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

# Generated at 2022-06-25 05:19:10.432714
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 836.24
    var_0 = None
    var_1 = load_list_of_tasks(float_0, var_0)


# Generated at 2022-06-25 05:19:12.036267
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # This is a test stub to test the load_list_of_tasks function.
    # The function depends on third party modules and plugins and cannot be tested.
    pass


# Generated at 2022-06-25 05:19:23.172181
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 836.24
    float_1 = float(-36.985)
    dict_0 = {"foo": "bar"}
    dict_1 = {"foo": "bar", "baz": float_0}
    list_0 = [float_0, float_1, dict_0, dict_1]
    var_0 = None
    var_1 = load_list_of_tasks(list_0, var_0)
    assert len(var_1) == 4
    assert var_1[0].name == float_0
    assert var_1[0].args == float_1
    assert var_1[1].name == dict_0
    assert var_1[1].args == dict_1
    assert var_1[2].name == dict_0
    assert var_1[2].args == dict

# Generated at 2022-06-25 05:20:16.312581
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    array_0 = [None, 3.6]
    set_0 = set([-2.7, 3.0999999999999996])
    var_0 = -8.0

    # Error thrown: array_0 & set_0 need to be of type "dict"
    load_list_of_tasks(array_0, set_0)


# Generated at 2022-06-25 05:20:27.324131
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 836.24
    float_1 = 201.5
    float_2 = 98.9
    float_3 = 192.6
    float_4 = 828.21
    var_0 = None
    var_1 = load_list_of_blocks(float_0, var_0)


    ds = [{
        'action': 'command',
        'args': {
            'cmd': 'The command',
            '_uses_shell': False,
            '_raw_params': 'The command',
            'creates': False,
            'removes': False,
            'warn': True
        },
        'delegate_to': None,
        'register': 'shell',
        'run_once': False
    }]
    play = None
    block = None
    role = None


# Generated at 2022-06-25 05:20:32.169938
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 836.24
    var_0 = None
    var_1 = load_list_of_tasks(float_0, var_0)


# Generated at 2022-06-25 05:20:34.611252
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 836.24
    var_0 = None
    var_1 = load_list_of_tasks(float_0, var_0)
    print(var_1)


# Generated at 2022-06-25 05:20:42.172840
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    data = {
        "name": "test task",
        "local_action": "command echo hello world"
    }
    data1 = {
        "name": "include task",
        "include_tasks": "{{ playbook_dir }}/tasks/test.yml"
    }
    data2 = {
        "name": "test loop",
        "local_action": "command echo hello {{ item }}",
        "with_items": "{{ items }}"
    }
    data3 = {
        "name": "include task",
        "import_tasks": "{{ playbook_dir }}/tasks/test.yml"
    }

    data_list = []
    data_list.append(data)
    data_list.append(data1)
    data_list.append(data2)

    data_

# Generated at 2022-06-25 05:20:48.997440
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ansible_1 = Ansible()
    ansible_1.options = Options()
    ansible_1.options._load_plugins = True
    ansible_1.options.tags = ['tags_0']
    ansible_1.options.skip_tags = ['skip_tags_0']
    ansible_1.options.strategy = 'strategy_1'
    ansible_1.options.step = False
    ansible_1.options.start_at_task = 'start_at_task_0'
    ansible_1.options.verbosity = 2
    ansible_1.options.check = True
    ansible_1._options_initialization_errors = []
    ansible_2 = Ansible()
    ansible_2.options = Options()

# Generated at 2022-06-25 05:20:58.835192
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test cases
    ds = {'name': 'file name', 'state': 'file'}
    play = 'play name'
    block = 'block name'
    role = 'role name'
    task_include = 'task_include name'
    use_handlers = True
    variable_manager = {'hostvars': {'host1': {'ansible_host': '192.168.0.20'}}}
    loader = {'_loader': 'ansible.parsing.dataloader.DataLoader'}
    assert load_list_of_tasks(ds, play, block, role, task_include,
                              use_handlers, variable_manager, loader)

    ds = {'block_list': [{'name': 'block name'}]}
    play = 'play name'
    block

# Generated at 2022-06-25 05:21:03.099171
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    dict_0 = dict()
    dict_0['x'] = random.random()
    dict_1 = dict()
    dict_1['x'] = random.random()
    list_0 = [dict_0, dict_1]
    var_1 = load_list_of_tasks(list_0, dict_1)
    assert(var_1 == None)


if __name__ == "__main__":
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:21:08.385439
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 10
    float_0 = 836.24
    var_1 = load_list_of_tasks(int_0, float_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 05:21:19.705120
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    
    # Input params
    ds = []
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    
    # Return var
    task_list = None
    

# Generated at 2022-06-25 05:23:01.125565
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    with pytest.raises(AnsibleAssertionError):
        load_list_of_tasks("", "")

# Generated at 2022-06-25 05:23:07.835497
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    dict_0 = dict()
    dict_0 = dict()
    dict_0.setdefault(3, 1.0)
    dict_0.setdefault(0, '')
    dict_0.setdefault(1, '')
    dict_0.setdefault(2, '')
    dict_0[1] = dict()
    dict_0[1][1] = dict()
    dict_0[1][1].setdefault('', '')
    dict_0[1][1][''] = 'b'
    dict_0[1][2] = dict()
    dict_0[1][2].setdefault('', '')
    dict_0[1][2][''] = 'c'
    dict_0[1][3] = dict()
    dict_0[1][3].setdefault('', '')

# Generated at 2022-06-25 05:23:09.382100
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_string = "test string"
    test_result = load_list_of_tasks(test_string)
    assert test_result == None

# Test positive values

# Generated at 2022-06-25 05:23:18.628373
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = (1, 2,)
    play = 'play'
    loader = None
    variable_manager = None
    role = 1
    task_include = 2
    use_handlers = False
    block = 3
    # Case 0
    float_0 = 968.57
    var_0 = None
    var_1 = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert var_1 == [1, 2]
    var_2 = load_list_of_tasks(float_0, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert var_2 == float_0
    # Case 1
    float_0 = 2.07
    var_3 = load_list_

# Generated at 2022-06-25 05:23:23.347922
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 836.24
    var_0 = None
    var_1 = load_list_of_tasks(float_0, var_0)
    assert var_1 == None


# Generated at 2022-06-25 05:23:24.740173
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("IN test_load_list_of_tasks")
    print("Function load_list_of_tasks not fully tested")


# Generated at 2022-06-25 05:23:26.506893
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    float_0 = 953.53
    var_2 = None
    var_3 = None
    var_4 = load_list_of_tasks(float_0, var_2, var_3)

# Generated at 2022-06-25 05:23:31.616267
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = "Hello,World!" # string

# Generated at 2022-06-25 05:23:40.741701
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Set up mock ansible environment
    run_setup()

    ds = [
        {'include_tasks': 'foobar.yml'},
        {'import_tasks': 'foobaz.yml'},
    ]
    play = Play().load({u'name': u'test'})
    task_list = load_list_of_tasks(ds, play)
    assert len(task_list) == 2
    assert 'foobar.yml' in task_list[0]._task.args
    assert task_list[0]._task.statically_loaded
    assert 'foobaz.yml' in task_list[1]._task.args
    assert task_list[1]._task.statically_loaded

