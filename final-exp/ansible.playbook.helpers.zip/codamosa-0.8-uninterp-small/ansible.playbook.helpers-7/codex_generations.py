

# Generated at 2022-06-25 05:14:14.749827
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test case 0
    try:
        test_case_0()
    except:
        assert False
        # we catch the exception raised by the function load_list_of_tasks
        # when the input argument's type is wrong
    else:
        assert True

    # Test case 1
    input_variables = {'foo': 1, 'bar': 'baz'}
    # in the test_case_1, the 'extra_vars' is not the correct type
    # so the function load_list_of_tasks will raise an exception
    try:
        test_case_1(input_variables)
    except Exception as e:
        assert True
    else:
        assert False
    # Test case 2
    input_variables = {'foo': 1, 'bar': 'baz'}
    output_vari

# Generated at 2022-06-25 05:14:23.442877
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        # Test case 0
        test_case_0()
    except AnsibleAssertionError as e:
        assert(e.message == None)

    try:
        # Test case 1
        test_case_1()
    except AnsibleAssertionError as e:
        assert(e.message == None)

    try:
        # Test case 2
        test_case_2()
    except AnsibleAssertionError as e:
        assert(e.message == """load_list_of_tasks() got an unexpected keyword argument 'test'""")

    try:
        # Test case 3
        test_case_3()
    except AnsibleAssertionError as e:
        assert(e.message == None)


# Generated at 2022-06-25 05:14:26.557953
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # NOTE: tests cannot use namedtuple because they are not pickleable across processes
    with pytest.raises(AnsibleAssertionError):
        test_case_0()


# Generated at 2022-06-25 05:14:33.924838
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    dict_0 = None

    module = imp.find_module('ansible')
    if module is None:
        sys.exit()

    loader = DataLoader()

    print('INFO: In %s' % os.path.basename(__file__))
    print('INFO: Calling function "load_list_of_tasks" with param %s' % (dict_0))
    var_0 = load_list_of_tasks(dict_0, dict_0, dict_0)
    var_1 = load_list_of_tasks(dict_0, dict_0, dict_0)

if __name__ == "__main__":
    # test_case_0()
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:14:44.640534
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    dict_0 = dict()
    dict_0['pid'] = 0
    dict_0['tasks'] = dict()
    dict_0['tasks']['pid'] = 0
    dict_0['tasks']['tasks'] = dict()
    dict_0['tasks']['tasks']['debug'] = dict()
    dict_0['tasks']['tasks']['debug']['msg'] = 'The value of var1 is {{ var1 }}'
    dict_0['tasks']['tasks']['debug']['pid'] = 0
    dict_0['tasks']['tasks']['debug']['tasks'] = dict()

    dict_0['tasks']['tasks']['set_fact'] = dict()

# Generated at 2022-06-25 05:14:53.734918
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_file_path_str = "/my/home/work/test"
    test_file_path = os.path.abspath(test_file_path_str)
    test_file_path_1 = "/my/home/work"
    test_file_path_2 = "test"
    path_cut = os.path.join(test_file_path_1, test_file_path_2)

# Generated at 2022-06-25 05:14:56.203223
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Function load_list_of_tasks should return AnsibleUndefinedVariable when the first argument is None

    with pytest.raises(AnsibleUndefinedVariable):
        test_case_0()

# Generated at 2022-06-25 05:15:06.671030
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    dict_0 = dict()
    dict_0['_ansible_no_log'] = False
    dict_0['_ansible_verbosity'] = 1
    dict_0['_ansible_version'] = u'2.5.5'
    dict_0['_ansible_version_major_minor'] = u'2.5'
    dict_0['_ansible_version_full'] = u'2.5.5'
    dict_0['ansible_version'] = dict()
    dict_0['ansible_version']['full'] = u'2.5.5'
    dict_0['ansible_version']['major'] = 2
    dict_0['ansible_version']['minor'] = 5
    dict_0['ansible_version']['revision'] = 5
   

# Generated at 2022-06-25 05:15:15.443360
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    dict_0 = dictionary()
    dict_1 = dictionary()
    dict_1['host'] = 'localhost'
    dict_0['hosts'] = dict_1
    dict_0['name'] = 'foo'
    dict_0['gather_facts'] = 'no'
    dict_0['tasks'] = list()

    dict_0['tasks'].append(dict_1)
    dict_1['name'] = 'debug'
    dict_1['debug'] = 'msg="this is a test"'
    var_0 = load_list_of_tasks(dict_0, dict_0, dict_0)

    #assert var_0 == "msg=this is a test"
    # TODO: Something is wrong with the above test, there are no tasks



# Generated at 2022-06-25 05:15:16.818999
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    print("[+] TEST: load_list_of_roles")
    test_case_0()
    # assert ...
    print("[-] TEST: load_list_of_roles")


# Generated at 2022-06-25 05:15:31.739759
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = dict()
    play = dict()
    block = dict()
    role = dict()
    task_include = dict()
    use_handlers = True
    variable_manager = dict()
    loader = dict()
    result = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert True


# Generated at 2022-06-25 05:15:40.570780
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # create mock object for
    # ansible.utils.display.Display()
    mock_display = MagicMock()
    mock_display_instance = mock_display.return_value
    mock_display_instance.warning = MagicMock(return_value="Display.warning")

    # create mock object for
    # ansible.template.Templar()
    mock_templar = MagicMock()
    mock_templar_instance = mock_templar.return_value

    # create mock object for
    # ansible.module_utils.common.removed_module
    mock_removed_module = MagicMock()
    mock_removed_module_instance = mock_removed_module.return_value

    # create mock object for
    # ansible.plugins.action.ActionBase()
    mock_action_base

# Generated at 2022-06-25 05:15:45.825646
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():   
    try:
        test_case_0()
    except Exception as ex:
        print("Exception caught:\n" + str(ex))

# Entry point for the script
if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:15:58.002784
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:16:00.934695
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert test_case_0() == True

# OSCAR
# Total Lines of Code (LOC) in module: 16
# LOC per test case: 1

# Generated at 2022-06-25 05:16:05.065133
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # FIXME: THIS TEST SHOULD INCLUDE A PROPER PLAY OBJECT (WHICH WOULD
    # FIXME: REQUIRE MANY MORE FIXME'S).

    block = dict()
    role = dict()
    task_include = dict()
    use_handlers = False
    variable_manager = dict()
    loader = dict()
    test_case_0()



# Generated at 2022-06-25 05:16:11.305699
# Unit test for function load_list_of_roles

# Generated at 2022-06-25 05:16:16.424607
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    """
    load_list_of_blocks
    """
    ds = None
    play = None
    parent_block = None
    role = 'role'
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None

    result = load_list_of_blocks(ds,play, parent_block, role, task_include, use_handlers, variable_manager, loader)


# Generated at 2022-06-25 05:16:27.744003
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Mock Ansible file (ansible/playbook/tests/files/host_vars/host_vars.yml)
    mock_open_ansible_data = [{
        'key': 'value'
    }]
    mock_open_ansible = mock.mock_open(read_data=json.dumps(mock_open_ansible_data))
    mock_open_ansible_context_manager = mock.MagicMock()
    mock_open_ansible_context_manager.__enter__.return_value = mock_open_ansible
    mock_open_ansible_context_manager.__exit__.return_value = None

    # Mock Ansible file (ansible/playbook/tests/files/group_vars/group_vars.yml)
    mock_open_ansible_data

# Generated at 2022-06-25 05:16:30.004394
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    var_0 = dict()
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    assert load_list_of_roles(var_0, var_1, var_2, var_3, var_4, var_5)



# Generated at 2022-06-25 05:17:03.314158
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # load_list_of_tasks()
    var_0 = S.load_list_of_tasks(data, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert var_0 == [(task_ds, args_parser), (action, args, delegate_to), (task_ds, block, role, task_include, variable_manager, loader), (task_ds, args_parser), (action, args, delegate_to), (task_ds, block, role, task_include, variable_manager, loader), (task_ds, args_parser), (action, args, delegate_to), (task_ds, block, role, task_include, variable_manager, loader)]

# Generated at 2022-06-25 05:17:13.037322
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_1 = list()

# Generated at 2022-06-25 05:17:21.574724
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    var_0 = dict()

    ds = None
    play = None
    parent_block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None

    # Test 1
    ds = None
    r = load_list_of_blocks(ds, play, parent_block, role, task_include, use_handlers, variable_manager, loader)
    assert isinstance(r, list)
    assert True




# Generated at 2022-06-25 05:17:33.104816
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    #from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    #from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    var_0 = dict()
    var_0['hostvars'] = dict()
    var_0['hostvars']['myhost'] = dict()
    var_0['hostvars']['myhost']['name'] = 'myhost'

    var_1 = dict()
    var_1['inventory'] = dict()
    var_1['inventory']['groups'] = dict()

    # create a play and fill it

# Generated at 2022-06-25 05:17:34.423350
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """
    Test function load_list_of_tasks
    """
    var_0 = dict()
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 05:17:40.218495
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Initialization
    ds = dict()
    play = dict()
    block = dict()
    role = dict()
    task_include = dict()
    use_handlers = True
    variable_manager = dict()
    loader = dict()

    ret = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)

    assert ret is not None
    assert_is_instance(ret, list)


# Generated at 2022-06-25 05:17:47.431891
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    _host = Mock(spec=['get_name'])
    _host.get_name.return_value = 'localhost'
    _loader = Mock(spec=['get_basedir', 'path_dwim', 'path_dwim_relative', 'set_basedir'])
    _loader.path_dwim.return_value = '/test/roles/role1/tasks/main.yml'
    _loader.path_dwim_relative.return_value = '/test/roles/role1/tasks/main.yml'
    _variable_manager = Mock(spec=['get_vars'])
    _variable_manager.get_vars.return_value = var_0

# Generated at 2022-06-25 05:17:57.676645
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible import constants as C
    from ansible.module_utils._text import to_native
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.utils.display import Display
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
#    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C

    # We might not be able to load these packages if they're not installed
    try:
        import yaml
        import jinja2
    except ImportError:
        print('1')
        variable_manager = VariableManager()


# Generated at 2022-06-25 05:17:59.752635
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 = dict()

    load_list_of_tasks(var_0)


# Generated at 2022-06-25 05:18:06.115494
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # since this function's return value is contingent on the
    #  successful parsing of the yaml file specified, we will
    #  just go by the docstring returned.
    '''
    Loads and returns a list of RoleInclude objects from the ds list of role definitions

    :param ds: list of roles to load
    :param play: calling Play object
    :param current_role_path: path of the owning role, if any
    :param variable_manager: varmgr to use for templating
    :param loader: loader to use for DS parsing/services
    :param collection_search_list: list of collections to search for unqualified role names
    :return:
    '''
    pass



# Generated at 2022-06-25 05:18:26.657440
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # First test case with empty dictionary
    var_0 = dict()
    # Be sure to use the correct type
    ansible_module_utils.basic.on_include_called = 0
    ansible_module_utils.basic.on_import_called = 0
    # check the output from this function
    assert load_list_of_tasks(var_0) == None

# Generated at 2022-06-25 05:18:32.986078
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print('Testing load_list_of_tasks')

    # Empty task list
    test = [var_0]
    ret = load_list_of_tasks(test, None, None, None, None, False, None, None)
    assert(ret == test)

    print('Test successful')


# Generated at 2022-06-25 05:18:38.495126
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 = 'ds'
    var_1 = 'play'
    var_2 = 'block'
    var_3 = 'role'
    var_4 = 'task_include'
    var_5 = 'use_handlers'
    var_6 = 'variable_manager'
    var_7 = 'loader'
    var_8 = 'Task()'
    var_9 = 'TaskInclude()'
    load_list_of_tasks(var_0,var_1,var_2,var_3,var_4,var_5,var_6,var_7)

# Generated at 2022-06-25 05:18:44.303950
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    display = Display()
    var_0 = dict()
    var_0['tasks'] = [{'block': [{'tasks': [{'shell': 'echo hello world'}]}]}]
    var_0['name'] = 'test'
    var_0['uuid'] = '1'

    var_1 = LamdbaVariableManager()
    var_2 = DataLoader()

    var_3 = Play().load(var_0, variable_manager=var_1, loader=var_2)

    try:
        var_4 = load_list_of_tasks(var_3.tasks, var_3, None, None, None, False, var_1, var_2)
    except Exception as e:
        display.error(e)
    return True


# Generated at 2022-06-25 05:18:47.021511
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 = Task()
    var_1 = Task()
    assert load_list_of_tasks(var_0, var_1)


# Generated at 2022-06-25 05:18:53.218114
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = dict(action='setup')
    play = Play()
    block = Block()
    role = Role()
    task_include = None
    use_handlers = False
    variable_manager = VariableManager()
    loader = DataLoader()

    assert len(load_list_of_tasks(task_ds, play, block, role, task_include, use_handlers, variable_manager, loader)) == 0


# Generated at 2022-06-25 05:19:00.264416
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = list()
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = True
    variable_manager = VariableManager()
    loader = DataLoader()

    # No exception, return a Task() object
    assert isinstance(load_list_of_tasks(ds=ds, play=play, block=block, role=role, task_include=task_include, use_handlers=use_handlers, variable_manager=variable_manager, loader=loader), list)

    # AssertionError exception raised when ds is a dict
    ds = dict()
    exception_thrown = False

# Generated at 2022-06-25 05:19:09.827287
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    display = json.loads('{"deprecated_message": "foo"}')

    loader = json.loads('{"path_exists": "foo"}')
    var_0 = json.loads('[]')
    task = json.loads('{"deprecated_message": "foo"}')
    variable_manager = json.loads('{"vv": "foo"}')
    loader = json.loads('{"path_dwim_relative": "foo"}')
    var_0 = json.loads('[]')
    play = json.loads('{"deprecated_message": "foo"}')
    role = json.loads('{"deprecated_message": "foo"}')
    task_include = json.loads('{"_task_fields": "foo"}')
    use_handlers = json.loads('true')
    # load_list_of_tasks(ds, play

# Generated at 2022-06-25 05:19:16.249014
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # FIXME: implement real unit tests
    var_0 = dict()
    result = load_list_of_tasks(var_0)
    try:
        assert result == True
    except AssertionError as e:
        print(e)
        # System exit with error
        sys.exit(1)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 05:19:17.297310
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass # TODO: implement your test here


# Generated at 2022-06-25 05:19:37.950460
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bytes_0 = b'\xc6\x10u\x1a\xe8\xfd1\x13\xb7\xf6\x87\xea'
    bytes_1 = b'\xb5\x14\x9e\xd6\x02\xa5\xde2\x96\xf6n\xfe\x8c\x9d\x02'
    var_0 = load_list_of_tasks(bytes_0, bytes_1)


# Generated at 2022-06-25 05:19:42.328096
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    bytes_0 = b'\x89\x15\xac\xa8\x94\xd6\xb0\xe4\x10\x82\x0b\x1c:\x18\x8fv\xb3\xfe\xa7\xf4\xa4'

# Generated at 2022-06-25 05:19:51.562797
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bytes_0 = b'\xb7\xfa\xe1\x9a\xed\x92\xcd\xa0\xd8\xef\x1b\xca\xb7\xf8\xde\x17\x0b\xc2\x05\xc2\x00\x00\x00\x00\x00\x00\x00\x00\xf6\x06\x19\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    var_0 = load_list_of_blocks(bytes_0, bytes_0)
    var_

# Generated at 2022-06-25 05:20:01.601441
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # b_0 from bug
    b_0 = b'\xf0\x9F\x8C\xBD'
    assert b_0 != None
    # b_1 from bug
    b_1 = b'\xef\xbb\xbf\xe2\x80\x98'
    assert b_1 != None
    # b_2 from bug
    b_2 = b'\x7f\xe2\x80\x99\xe2\x80\xa2\xe2\x80\x9c\xe2\x80\xa6\xe2\x80'
    assert b_2 != None
    # b_3 from bug

# Generated at 2022-06-25 05:20:11.050612
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Load playbook
    with open('playbook.yml', 'r') as file:
        playbook = yaml.safe_load(file)
    pb = Playbook.load(playbook, variable_manager=None, loader=None)


    # Test from the beginning
    load_list_of_tasks(pb, pb.get_plays_by_name("linux"), None, None, None, False, None, None)


    # Test from the second tasks
    for block in pb.get_plays_by_name("linux").task_blocks:
        tasks = block.block
        load_list_of_tasks(tasks[1:], pb.get_plays_by_name("linux"), block, None, None, False, None, None)


    # Test from the third task

# Generated at 2022-06-25 05:20:17.779837
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    v0 = None
    v1 = b'\x10\x00'
    v2 = b'\x10\x10'
    v3 = [v0, v2, v2, v1, v2, v0, v0, v1, v1, v1, v1, v1]
    v4 = b'\x80\x81'
    v5 = b'\x88\x88'

# Generated at 2022-06-25 05:20:27.435087
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bytes_0 = b"\x04\x00\xf0\x01\x00\x00\x00\x04H\x00\x00\x00\x04H\x00\x00\x00\x03H\x00\x00\x00\x01A\x00\x00\x00\x02A\x00\x00\x00\x03A\x00\x00\x00\x04A\x00\x00\x00\x05A\x00\x00\x00\x06A\x00\x00\x00\x07A\x00\x00\x00\x08A\x00\x00\x00\tA\x00\x00\x00\n"

# Generated at 2022-06-25 05:20:38.085301
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Initialisation for testcase
    list_of_tasks = [{'name': 'task1'}, {'block': {'name': 'block2', 'body': [{'name': 'task2.1'}, {'name': 'task2.2'}]}}]

    # Unit test for function load_list_of_tasks
    list_of_tasks_return = load_list_of_tasks(list_of_tasks, list_of_tasks)

    if isinstance(list_of_tasks_return, list):
        assert len(list_of_tasks_return) == 2
        assert list_of_tasks_return[0].name == 'task1'
        assert list_of_tasks_return[1].block[0].name == 'task2.1'
        assert list

# Generated at 2022-06-25 05:20:46.927717
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.play_context import PlayContext

    variable_manager = VariableManager()
    loader = DataLoader()
    options = Options(connection='local', module_path=None, forks=100, become=None, become_method=None, become_user=None, check=False, diff=False)
    passwords = dict(vault_pass='secret')
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

# Generated at 2022-06-25 05:20:56.935235
# Unit test for function load_list_of_blocks

# Generated at 2022-06-25 05:21:20.528184
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:21:28.473295
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bytes_0 = b'\x94\x00\x00\x00\x01\x00\x00\x00@\x00\x00\x00s\x07\x00\x00\x00{\x07\x00\x00\x00\x13\x01\x00\x00(\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    var_0 = load_list_of_tasks(bytes_0, bytes_0)
    bytes_1 = b'\x7f\xd1\x04\xf2\x0e\xac\xfa\xcf\x9b\x1b\x1b\xa5\x1b'
    var_1 = load_list_

# Generated at 2022-06-25 05:21:32.002915
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bytes_0 = b'\x14\x0e\x8c\\\x1b\x17\x9f*G\xc5\x01\x11\x90\xfc7h'
    var_0 = load_list_of_tasks(bytes_0, bytes_0)


if __name__ == "__main__":
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:21:39.467420
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:21:48.119954
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    bytes_0 = b'5y)\x19\x86\x06\x13A\x80\x91Rq|b\xa5\x1e'
    bytes_1 = b'\x1c\x01\r\r\r\r\x04f\x91\x03\xaa\xb6\xfc\xc0\xe9\n\xd5'
    bytes_2 = b'\x00\x00\x00\x00No\x07\x0f\xd3\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 05:21:55.082695
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    bytes_0 = b'\x10\x17\x04\x04\t\x80\x9ch-\x1f\xb0c\x06\xae\x8e\xdc\xa1\x1d'

# Generated at 2022-06-25 05:22:00.431482
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bytes_0 = b'\x8d\x9b\xd1\xdf\x84\x80\xaa\x94\xd6\xe2\x8a\xe9\x81\xdc)l\x8b\xf0\xd6\xb6\x9c\x07\xb9\x94\x1c\x8f\xc3\r\x01\x97\xc3'
    var_0 = load_list_of_tasks(bytes_0, bytes_0)


if __name__ == '__main__':
    test_case_0()
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:22:04.795792
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    data = [{
        'foo': 'bar',
    }]
    # FIXME
    # this test is failing on 2.9.x because of a change in a local variable name
    # found in block.py:load()
    play = Mock()
    block = Mock()
    role = Mock()
    task_include = Mock()
    use_handlers = Mock()
    variable_manager = Mock()
    loader = Mock()
    load_list_of_tasks(data, play, block, role, task_include, use_handlers, variable_manager, loader)


# Generated at 2022-06-25 05:22:12.740225
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_list_list_bytes_0 = [ [b'\x00\x00\x00\x00'], [b''], [b'\x00\x00\x00\x00'] ]
    var_list_list_bytes_1 = [ [b'\x00\x00\x00\x00'], [b''], [b'\x00\x00\x00\x00'] ]
    var_list_int_0 = [0, 0, 0]
    var_list_int_1 = [0, 0, 0]
    var_list_int_2 = [0, 0, 0]
    var_list_int_3 = [0, 0, 0]
    var_list_int_4 = [0, 0, 0]

# Generated at 2022-06-25 05:22:21.371950
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("Testing load_list_of_tasks ...", end="")

# Generated at 2022-06-25 05:23:23.062685
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 = load_list_of_tasks(b'5y)\x19\x86\x06\x13A\x80\x91Rq|b\xa5\x1e', b'5y)\x19\x86\x06\x13A\x80\x91Rq|b\xa5\x1e')
    # self.assertEqual(var_0, )


# Generated at 2022-06-25 05:23:28.736845
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    task_include_0 = TaskInclude(None, None, None, dict_0, None, None, None, None)
    dict_2['block'] = dict_1
    dict_2['block']['task_include'] = task_include_0
    load_list_of_tasks(dict_2, None, None, None, None, None, None, None)

# Generated at 2022-06-25 05:23:32.731676
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bytes_0 = b'a\x03\xda\x07\xde\xb8d\xee\xac\x06\xf7\xbf'
    var_0 = load_list_of_tasks(bytes_0, bytes_0)


# Generated at 2022-06-25 05:23:39.766104
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bytes_0 = b'p\x1d\x87\x04\xc6)\xa9\xa72\xe8\xef\x84\x1c\x0f\x16'
    bytes_1 = b'\x1d\xdf\x1c\x99\x13\x00\x87\x9f\x07\x89\x03\x8d\x1fGb\xdb\xba\xa8V\x9f\x9c\x89'
    res_0 = load_list_of_tasks(bytes_0, bytes_0, bytes_1)