

# Generated at 2022-06-25 05:14:04.739802
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # This function is used so that we can test method load_list_of_tasks of class Role
    # Without having to make an instance of class Role

    # FIXME: file is missing, should raise AnsibleFileNotFound
    # str_0 = '~\x0c'
    # bool_0 = False
    # var_0 = load_list_of_roles(str_0, bool_0)
    pass


# Generated at 2022-06-25 05:14:14.475740
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    dl  = DataLoader()
    play_source = dict(
         name = "Ansible Play 0",
         hosts = 'localhost',
         gather_facts = 'no',
         tasks = [
              dict(action=dict(module='setup', args='')),
           ]
    )

    play = Play().load(play_source, variable_manager=VariableManager(), loader=dl)

    inventory = InventoryManager(loader=dl, sources='localhost,')
    variable_manager = VariableManager(loader=dl, inventory=inventory)

    # Create

# Generated at 2022-06-25 05:14:15.026967
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert False


# Generated at 2022-06-25 05:14:23.471872
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = {}
    play = {}
    block = {}
    role = {}
    task_include = {}
    use_handlers = True
    variable_manager = {}
    loader = {}

    # save initial globals
    initial_globals = copy.copy(globals())

    # set a global for the test
    globals()['C'] = {}
    globals()['C']['_ACTION_ALL_INCLUDE_IMPORT_TASKS'] = ['action1', 'action2']
    globals()['C']['_ACTION_INCLUDE_TASKS'] = ['action1']
    globals()['C']['_ACTION_IMPORT_TASKS'] = ['action2']

# Generated at 2022-06-25 05:14:27.364533
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds_0 = []
    play_0 = None
    block_0 = None
    role_0 = None
    task_include_0 = None
    use_handlers_0 = False
    variable_manager_0 = None
    loader_0 = None
    load_list_of_tasks(ds_0, play_0, block_0, role_0, task_include_0, use_handlers_0, variable_manager_0, loader_0)




# Generated at 2022-06-25 05:14:31.389279
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        load_list_of_tasks(ansible_data, ansible_play, ansible_block, ansible_role, ansible_task_include, ansible_use_handlers, ansible_variable_manager, ansible_loader)
    except Exception as e:
        print(str(e))


# Generated at 2022-06-25 05:14:38.404632
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # args
    ds = dict()
    play = dict()
    block = dict()
    role = dict()
    task_include = dict()
    use_handlers: bool = False
    variable_manager = dict()
    loader = dict()
    result = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert isinstance(result, list)


# Generated at 2022-06-25 05:14:48.605061
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    #
    # Validate invalid value of ds
    #
    with pytest.raises(AnsibleAssertionError):
        load_list_of_tasks('foo', None, None, None, None, None)

    #
    # Validate invalid value of play
    #
    with pytest.raises(AnsibleAssertionError):
        load_list_of_tasks([], 'foo', None, None, None, None)

    #
    # Validate invalid value of use_handlers
    #
    with pytest.raises(AnsibleAssertionError):
        load_list_of_tasks([], None, None, None, None, 'foo')

    #
    # Validate invalid value of loader
    #

# Generated at 2022-06-25 05:14:50.412941
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    check = unittest.TestCase()
    try:
        test_case_0()
    except Exception as e:
        check.assertEqual(str(e), 'ds (~\x0c) should be a list but was a %s' % type('~\x0c'))


# Generated at 2022-06-25 05:14:54.147668
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    print("Test: 'load_list_of_roles'")
    try:
        test_case_0()
        print("Test: 'load_list_of_roles' - PASSED")
    except Exception as e:
        print(str(e))
        print("Test: 'load_list_of_roles' - FAILED")



# Generated at 2022-06-25 05:15:30.706694
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    loader_mock = Mock()
    play_mock = Mock()
    block_mock = Mock()
    role_mock = Mock()
    task_include_mock = Mock()
    use_handlers_mock = Mock()
    variable_manager_mock = Mock()
    param1 = Mock()
    param2 = Mock()
    param3 = Mock()
    param4 = Mock()
    param5 = Mock()
    param6 = Mock()
    param7 = Mock()
    param8 = Mock()
    param9 = Mock()
    param10 = Mock()
    param11 = Mock()
    param12 = Mock()
    param13 = Mock()
    param14 = Mock()
    param15 = Mock()
    param16 = Mock()
    param20 = []

# Generated at 2022-06-25 05:15:34.350516
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    i = 0
    for role_def in role_defs:
        role = RoleInclude.load(role_def, play=play, current_role_path=current_role_path, variable_manager=variable_manager, loader=loader, collection_list=collection_search_list)
        assert isinstance(role, RoleInclude)
        i += 1



if __name__ == '__main__':
    test_load_list_of_roles()

# Generated at 2022-06-25 05:15:45.381801
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = list()
    ds.append({'name': 'task0', 'action': {'module': 'debug', 'args': {'msg': 'msg0'}}})
    ds.append({'name': 'task1', 'action': {'module': 'debug', 'args': {'msg': 'msg1'}}})
    ds.append({'name': 'task2', 'action': {'module': 'debug', 'args': {'msg': 'msg2'}}})

    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None

    # Don't know how to generate a Task object
    # task_list = load_list_of_tasks(ds, play, block, role, task_include,

# Generated at 2022-06-25 05:15:55.557818
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    # list of tasks
    tasks = [
        {
            'name': 'Test Task',
            'action': 'debug'
        }
    ]

    test_tasks = load_list_of_tasks(tasks, None, None, None, False, None, loader)
    assert(len(test_tasks) == 1)
    assert(test_tasks[0].task_include is None)
    #assert(test_tasks[0].action == 'debug')

# Generated at 2022-06-25 05:16:05.231907
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    loader = DictDataLoader({'/etc/ansible/test.yml': '''
---
- hosts: localhost
  tasks:
    - name: a simple task
      ping:

    - include: other.yml
      static: yes
      when: false # this would normally be ignored, but use it for testing purposes

    - include: other.yml
      when: false
      static: yes
    '''.lstrip(),
                            '/etc/ansible/other.yml': '''
---
- name: task1
  ping:
    data: 'pong'

    - name: task2
      ping:
    '''.lstrip(),
                            })

# Generated at 2022-06-25 05:16:10.698648
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Test 1
    import ansible.playbook.role.include
    assert load_list_of_roles([{"name": "C", "foo": "Foo"}], 0, current_role_path=None, variable_manager=None, loader=None, collection_search_list=None) == [ansible.playbook.role.include.RoleInclude({"name": "C", "foo": "Foo"}, play=0, current_role_path=None, variable_manager=None, loader=None, collection_list=None)]

if __name__ == "__main__":
    test_case_0()
    test_load_list_of_roles()

# Generated at 2022-06-25 05:16:15.736540
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    '''
    # FIXME
    # load_list_of_tasks(var_0, var_1, var_2, var_3, bool_0)

    assert False # TODO: implement your test here


# Generated at 2022-06-25 05:16:20.230265
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bool_0 = None
    str_0 = '\t'
    bool_1 = bool()
    var_0 = load_list_of_tasks(bool_1, bool_0, str_0, str_0, bool_1, bool_1)


# Generated at 2022-06-25 05:16:29.749265
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Simple
    dict_0 = {
    'block': '0',
    'host': 'k',
    'ignore_errors': '0',
    'name': 'z',
    'register': 'j',
    'run_once': '1',
    'when': '1',
    }

    dict_1 = {
    'block': '0',
    'host': 'k',
    'ignore_errors': '0',
    'name': 'z',
    'register': 'j',
    'run_once': '1',
    'when': '1',
    'roles': '0',
    }


# Generated at 2022-06-25 05:16:31.865826
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    bool_0 = None
    str_1 = '\t'
    var_0 = load_list_of_blocks(bool_0, bool_0, str_1, str_1, str_1)



# Generated at 2022-06-25 05:17:07.140394
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test of possible inputs
    bool_0 = None
    str_0 = '\t'
    var_0 = load_list_of_tasks(bool_0, bool_0, str_0, str_0, str_0)
    assert len(var_0) == 0



# Generated at 2022-06-25 05:17:15.049524
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{"action": {"module": "add_host", "args": {"hostname": "localhost", "ip": "127.0.0.1"}}}]
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    assert load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)

    ds = None
    assert load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)

    ds = [None]

# Generated at 2022-06-25 05:17:23.552639
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bool_0 = None
    str_0 = '\t'
    str_1 = 'hosts'
    str_2 = 'ignore_errors'
    str_3 = 'tasks'
    str_4 = 'connection'
    str_5 = 'name'
    str_6 = 'roles'
    str_7 = 'include_role'
    str_8 = 'when'
    str_9 = 'transport'
    str_10 = 'any_errors_fatal'
    str_11 = 'meta'
    str_12 = 'has_vars'
    str_13 = 'gather_facts'
    str_14 = 'post_tasks'
    str_15 = 'pre_tasks'
    str_16 = 'become'
    str_17 = 'vars'
    str

# Generated at 2022-06-25 05:17:33.813998
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # scalar values
    def test_load_list_of_tasks_0():
        bool_0 = False
        str_0 = '_\t'
        str_1 = '~%N('
        str_2 = '@8"/'
        str_3 = '\t(~'
        str_4 = '_\v'
        # str_5 = ': '
        var_0 = load_list_of_blocks(bool_0, bool_0, str_0, str_1, str_2, str_3, str_4)

    # scalar values
    def test_load_list_of_tasks_1():
        bool_0 = True
        str_0 = '_\x06'
        str_1 = '~%N('

# Generated at 2022-06-25 05:17:42.453430
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    module_utils = ModuleUtils()
    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()

    # Initialize display args
    display.verbosity = 3
    variable_manager._extra_vars = {'is_debug': True}
    variable_manager.set_available_variables({'is_debug': True})

    # Playbook keys
    playbook_var = {'name': 'ansible-test', 'hosts': 'localhost,',
                    'gather_facts': 'no', 'tasks': None}

    # initialize needed objects
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-25 05:17:49.604843
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bool_0 = None
    str_0 = '\t'
    var_0 = load_list_of_tasks(bool_0, bool_0, str_0, str_0, str_0)
    try:
        load_list_of_tasks([str_0], None, None, None, None)
    except AnsibleParserError as e:
        assert "should be a dict but was a" in str(e)

# Generated at 2022-06-25 05:17:57.792441
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TaskInclude test
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = [{'hosts': 'all', 'name': 'test', 'gather_facts': 'no', 'tasks': [{'include': '%(tmp)s/var_6'}]}]
    var_7 = None
    var_6 = '%(tmp)s/var_6'
    var_9 = '%(tmp)s/var_6'
    var_8 = [{'name': 'task', 'debug': {'msg': 'variable=%(var_9)s'}}]

# Generated at 2022-06-25 05:18:07.152104
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bool_0 = True
    str_0 = '\t'
    tuple_0 = (str_0, str_0)

# Generated at 2022-06-25 05:18:19.046924
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    a = 1
    b = 2
    c = 3
    d = 4
    e = 5
    f = 6
    g = 7
    h = 8
    i = 9
    j = 10
    k = 11
    l = 12
    m = 13
    n = 14
    o = 15
# Call function load_list_of_tasks with the following parameters:
#  (bool_0, bool_0, str_0, str_0, str_0)
    load_list_of_tasks(bool_0, bool_0, str_0, str_0, str_0)
# AssertionError:
# pass
# AssertionError:
# pass
# call_tokens:
#   - name: load_list_of_tasks
#     offset: 9
#     flags:

# Generated at 2022-06-25 05:18:29.848728
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = {
        'action': 'command',
        '_ansible_parsed': True,
        'args': {
            '_ansible_no_log': False,
            '_ansible_check_mode': False,
            'argv': '/bin/foo'
        },
        'delegate_to': '127.0.0.1',
        'async': 10
    }
    # pylint: disable=unused-argument
    def mock_args_parser_parse(skip_action_validation=False):
        return ('command', {
            '_ansible_no_log': False,
            '_ansible_check_mode': False,
            'argv': '/bin/foo'
        }, '127.0.0.1')

# Generated at 2022-06-25 05:19:03.754147
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test the basic case
    bool_0 = None
    str_0 = '\t'
    var_0 = load_list_of_tasks(bool_0, bool_0, str_0, str_0)
    assert var_0 is None

    # Test the basic case
    bool_0 = False
    str_0 = 'I'
    var_0 = load_list_of_tasks(bool_0, str_0, str_0, str_0)
    assert var_0 == []

    # Test the basic case
    bool_0 = True
    list_0 = []
    str_0 = ''
    var_0 = load_list_of_tasks(bool_0, list_0, str_0, str_0)
    assert var_0 == []

    # Test the basic case


# Generated at 2022-06-25 05:19:15.471447
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Initialize the test data
    class Display:
        def __init__(self):
            self.vv = None
        def warning(self, *args):
            pass
    class AnsibleRuntime:
        def __init__(self):
            self.DEFAULT_HANDLER_EXTS = ('.yml', '.yaml',)
        def get_module_path(self):
            return '/tmp/ansible/lib/ansible/modules/'
    class AnsibleParserError:
        def __init__(self, msg, obj=None, suppress_extended_error=None, orig_exc=None):
            self.msg = msg
            self.obj = obj
    class AnsibleUndefinedVariable:
        def __init__(self, obj=None, orig_exc=None):
            self.obj = obj

# Generated at 2022-06-25 05:19:20.715961
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Creating test case variables
    ds = None
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = None
    variable_manager = None
    loader = None
    # Invoking load_list_of_tasks method
    load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)

if __name__ == '__main__':
    test_load_list_of_tasks()
    test_case_0()

# Generated at 2022-06-25 05:19:26.708406
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'foo'
    str_1 = 'bar'
    str_2 = 'baz'
    str_3 = 'x'
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    var_0 = load_list_of_tasks(list(), str_0, str_1, str_2, int_0, int_1, int_2)
    var_1 = load_list_of_tasks(dict(), str_3, str_3, str_3, int_3, int_3, int_3)


# Generated at 2022-06-25 05:19:29.672162
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print('Testing function load_list_of_tasks')
    bool_0 = None
    str_0 = '\t'
    var_0 = load_list_of_tasks(bool_0, bool_0, str_0, str_0)


# Generated at 2022-06-25 05:19:40.975619
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Test args containing a dict
    ds = dict()

    # Test args containing a list
    play = list()

    # Test args containing a dict
    block = dict()

    # Test args containing a str
    role = str()

    # Test args containing a dict
    task_include = dict()

    # Test args containing a boolean
    use_handlers = True

    # Test args containing a dict
    variable_manager = dict()

    # Test args containing a dict
    loader = dict()

    # Act
    result = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    result1 = load_list_of_tasks(list(), play, block, role, task_include, use_handlers, variable_manager, loader)

    # Ass

# Generated at 2022-06-25 05:19:49.209837
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds_0 = []
    play_0 = None
    block_0 = None
    role_0 = None
    task_include_0 = None
    use_handlers_0 = True
    variable_manager_0 = None
    loader_0 = None
    var_0 = load_list_of_tasks(ds_0, play_0, block_0, role_0, task_include_0, use_handlers_0, variable_manager_0, loader_0)

# Generated at 2022-06-25 05:19:54.878170
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Unit tests for load_list_of_tasks
    bool_0 = None
    bool_1 = None
    list_0 = []
    str_0 = '\t'
    var_0 = load_list_of_tasks(list_0, bool_0, bool_1, str_0, str_0)
    assert(var_0 == [])



# Generated at 2022-06-25 05:20:00.845400
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = ["ds"]
    play = "play"
    block = "block"
    role = "role"
    task_include = "task_include"
    use_handlers = True
    variable_manager = "variable_manager"
    loader = "loader"

    ret = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert ret is not None

# Generated at 2022-06-25 05:20:02.446752
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    bool_0 = None
    str_0 = '\t'
    var_0 = load_list_of_roles(bool_0, bool_0, str_0, str_0, str_0)

# Generated at 2022-06-25 05:20:55.188792
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    block = "Task"
    role = "Method"
    task_include = "Argument"
    use_handlers = ("AnsibleAssertionError", "dict")
    variable_manager = "AnsibleError"
    loader = "AnsibleParserError"
    print ("Load list of tasks")
    assert load_list_of_tasks(dict, block, role, task_include, use_handlers, variable_manager, loader) == None
test_load_list_of_tasks()

# Generated at 2022-06-25 05:20:57.210990
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks() != None


# Generated at 2022-06-25 05:21:05.181271
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    :return:
    '''
    test_loader = DataLoader()
    test_variable_manager = VariableManager()
    my_play = Play()
    my_play.become = 'yes'
    my_block = Block()
    my_block._play = my_play

    # Test case #1 - Check that the function returns an empty list
    result = load_list_of_tasks(None, my_play, my_block, 'role01', 'task01', False, test_variable_manager)
    assert len(result) == 0

    # Test case #2 - Check that the function returns a list of one task object
    my_task = Task()
    my_task._role = 'role01'
    my_task._parent = my_block
    my_task._task_include = 'task01'

# Generated at 2022-06-25 05:21:11.465901
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.utils import context_objects as co

    # AnsibleVarManager test data for RoleInclude.load().
    varManager = co.AnsibleVarManager()
    varManager.set_fact('ansible_user', 'galaxy')


# Generated at 2022-06-25 05:21:18.877542
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("test_load_list_of_tasks()")

    '''
    Test-cases:
    test_case_0: If a None value is passed as a parameter, raise AnsibleAssertionError
    test_case_1: If the first argument(ds) is not a list, raise AnsibleAssertionError
    '''

    # Test-case 0
    try:
        test_case_0()
    except AnsibleAssertionError:
        print("test_case_0: AnsibleAssertionError raised as expected")

test_load_list_of_tasks()

# Generated at 2022-06-25 05:21:26.918035
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print_info("Test:load_list_of_tasks")
    bool_0 = True
    str_0 = '\t'
    str_1 = 'include_tasks'
    var_0 = load_list_of_tasks(bool_0, bool_0, str_0, str_0, str_1)



# Generated at 2022-06-25 05:21:28.094861
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    try:
        test_case_0()
    except Exception as e:
        print(e)

# Generated at 2022-06-25 05:21:37.658177
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    rand_0 = random.randint(-100, 100)
    rand_1 = random.randint(-100, 100)
    rand_str_0 = str(random.randint(-100, 100))
    rand_str_1 = str(random.randint(-100, 100))
    rand_str_2 = str(random.randint(-100, 100))
    rand_str_3 = str(random.randint(-100, 100))
    rand_str_4 = str(random.randint(-100, 100))
    rand_str_5 = str(random.randint(-100, 100))
    list_0 = [rand_str_0, rand_str_1]
    list_1 = [rand_str_2, rand_str_3]


# Generated at 2022-06-25 05:21:44.675772
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("Test1: None")
    ds = None
    play = False
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    var_0 = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    print("passed!")


# Generated at 2022-06-25 05:21:52.063515
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    loader = DataLoader()
    path = 'test/yaml/include_tasks.yml'
    ds = loader.load_from_file(path)
    task_list = load_list_of_tasks(ds, None, None, None, None, False, None, loader)
    assert task_list, "task_list should not be empty"
    assert task_list[0].name == "print var", "First task should be print var"
    assert task_list[1].name == "print msg", "Second task should be print msg"