

# Generated at 2022-06-25 05:14:05.907954
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(dict(), True)
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()
    variable_manager.options_vars = dict()
    variable_manager.playbook_vars = dict()
    variable_manager.set_inventory(None)
    
    with pytest.raises(Exception) as exception_info:
        # Test for valid call types
        task_0 = {
            'block': {'test': 'test', 'test1': 'test1'}
        }
        task_1 = {'name': 'test'}
        list_0 = [task_0]
        list_1 = [task_1]

# Generated at 2022-06-25 05:14:07.667723
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    res = load_list_of_tasks()
    assert res == False
    pass

# Generated at 2022-06-25 05:14:12.248847
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    bool_0 = True
    current_role_path = None
    variable_manager = None
    loader = None
    collection_search_list = None
    test_0 = load_list_of_roles(bool_0, bool_0)
    assert test_0 is None

# Generated at 2022-06-25 05:14:13.075762
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_case_0()


# Generated at 2022-06-25 05:14:19.049656
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    ansible_path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    config_path = os.path.join(ansible_path, 'test') + '/test_playbook.yml'
    os.environ['ANSIBLE_CONFIG'] = config_path

    option_0 = True
    option_1 = False
    option_2 = True
    option_3 = False
    option_4 = False

    print('********Unit Test********')
    print('Testing load_list_of_tasks')
    print('Test Case 0:')
    #Test case with no arguments
    test_case_0()

    print('Test Case 1:')
    #Test case with the option arguments

# Generated at 2022-06-25 05:14:20.563303
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("Testing function load_list_of_tasks")
    test_case_0()


# Generated at 2022-06-25 05:14:21.412489
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_case_0()



# Generated at 2022-06-25 05:14:26.339722
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    try:
        test_case_0()

    except Exception as e:
        print("Exception in user code:")
        print("-"*60)
        traceback.print_exc(file=sys.stdout)
        print("-"*60)
        raise(e)

    else:
        print("All ok")


# Generated at 2022-06-25 05:14:34.256577
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Creation of a boolean class variable
    bool_var = True

    # Creation of an integer class variable
    int_var = 100

    # Creation of a string class variable
    str_var = "str"

    # Creation of a list class variable
    list_var = []

    # Creation of a dict class variable
    dict_var = dict()

    # Create sets for testing the test case
    sets = [
        (bool_var, bool_var),
        (int_var, bool_var),
        (str_var, bool_var),
        (list_var, bool_var),
        (dict_var, bool_var),
    ]

    # Test all test sets

# Generated at 2022-06-25 05:14:44.774737
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:15:11.236308
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # try some cases where it should raise exception
    try:
        load_list_of_tasks(None)
    except TypeError:
        pass
    else:
        raise Exception("Should fail because of missing args")

    try:
        load_list_of_tasks(None, None, None, None, None, None, Test_AnsibleVars())
    except TypeError:
        pass
    else:
        raise Exception("Should fail because of missing args")

    try:
        load_list_of_tasks(None, None, None, None, None, None, None, Test_AnsibleVars())
    except TypeError:
        pass
    else:
        raise Exception("Should fail because of missing args")


# Generated at 2022-06-25 05:15:13.869572
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Test case 0
    var_0 = ['../ansible-test/test_playbooks/playbook-test.yml', 'r']
    var_1 = ['../ansible-test/test_playbooks/playbook-test.yml', 'r']
    test_case_0()


# Generated at 2022-06-25 05:15:14.699482
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass


# Generated at 2022-06-25 05:15:16.814167
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        # 0
        test_case_0()
        # 1
        test_case_0()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 05:15:27.948529
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:15:29.227725
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO: Implement the unit test here.
    pass



# Generated at 2022-06-25 05:15:39.513247
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.errors import AnsibleParserError
    from ansible.module_utils._text import to_bytes, to_text

    role = dict(
        name = to_text(test_data_loader("ansible/test/data/variables/role/name_0")),
        tasks = to_text(test_data_loader("ansible/test/data/variables/role/tasks_0")),
    )

    # test load_list_of_roles
    # Expect no exception

    load_list_of_roles(role, playbook=None)

    # test load_list_of_roles
    # Expect exception Ansi

# Generated at 2022-06-25 05:15:45.932054
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 =["1", "2"]
 
    # run the code from the module
    with pytest.raises(AnsibleAssertionError) as excinfo:
        load_list_of_tasks(var_0)
    # verify the error message
    assert 'The ds (1) should be a list but was a <class' in str(excinfo.value)
## END

# Generated at 2022-06-25 05:15:47.538377
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    data = dict(
        param = 'test'
    )
    print(load_list_of_tasks(data, None, None, None, None))


# Test Runner

# Generated at 2022-06-25 05:15:53.092538
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Test defined in ANSIBLE/ansible-2.9.0/test/units/playbook/test_helpers.py

    # FIXME: doesn't test, just loads

    var_0 = load_list_of_roles()
    assert (var_0 == None)



# Generated at 2022-06-25 05:16:06.218805
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True


# Generated at 2022-06-25 05:16:12.604010
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bool_0 = True
    bool_1 = False
    bool_0 = True
    bool_1 = False
    bool_0 = True
    bool_0 = True
    bool_1 = False
    list_0 = ["", ""]
    list_1 = ["", ""]
    str_0 = "asd"
    str_1 = "asd"
    str_2 = "asd"
    str_3 = "asd"
    str_4 = "asd"
    str_5 = "asd"
    str_6 = "asd"
    str_7 = ""
    str_8 = "asd"

    with pytest.raises(AnsibleParserError):
        load_list_of_tasks(bool_0, bool_0)


# Generated at 2022-06-25 05:16:14.647296
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Check for a boolean input value
    test_case_0()

##################
# MAIN FUNCTION
##################


# Generated at 2022-06-25 05:16:17.608965
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
    except AnsibleAssertionError as e:
        assert False, "The list of tasks should be a list of Task() or TaskInclude() objects"



# Generated at 2022-06-25 05:16:24.809189
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    with tempfile.NamedTemporaryFile() as temp:
        temp.write(b'foo')
        temp.flush()
        args_parser = ModuleArgsParser({
            'include_tasks': temp.name
        })
        try:
            args_parser.parse()
        except AnsibleParserError:
            pass

if __name__ == "__main__":
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:16:29.469706
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    try:
        pass # FIXME: implement test

    except (AnsibleAssertionError, AnsibleUndefinedVariable) as e:
        # FIXME: remove this
        raise Exception(e)


# Generated at 2022-06-25 05:16:30.286302
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert func1() == False


# Generated at 2022-06-25 05:16:32.156182
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("Test: load_list_of_tasks()")

    print("Test 0: "),
    test_case_0()


# Generated at 2022-06-25 05:16:34.460760
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ret_0 = load_list_of_tasks(bool_0, bool_0)
    return var_0

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:16:38.328927
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # An AnsibleUndefinedVariable exception is thrown when an undefined variable
    # is used in the Ansible task
    try:
        test_case_0()
    except AnsibleUndefinedVariable:
        pass

if __name__ == '__main__':
    test_load_list_of_blocks()

# Generated at 2022-06-25 05:17:31.646005
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.utils.display import Display
    display = Display()

    # Assign parameter values
    ds = bool_0
    play = bool_0
    block = bool_0
    role = bool_0
    task_include = bool_0
    use_handlers = bool_0
    variable_manager = bool_0
    loader = bool_0

    # Call function
    try:
        load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)

    except NameError as err:
        assert False, "An exception was raised: " + str(err)


# Generated at 2022-06-25 05:17:37.280439
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    with pytest.raises(AnsibleAssertionError) as excinfo:
        test_case_0()
    assert 'should be a list' in str(excinfo.value)



# Generated at 2022-06-25 05:17:45.377884
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    play = dict()
    parent_block = dict()
    role = dict()
    task_include = dict()
    use_handlers = False
    variable_manager = dict()
    loader = dict()
    ds = dict()
    block_list = dict()
    # Check if the function returns a list
    if isinstance(block_list, list):
        try:
            # Try to load a list of blocks
            block_list = load_list_of_blocks(ds, play, parent_block, role, task_include, use_handlers, variable_manager, loader)
        except TypeError:
            raise TypeError("Unit test for load_list_of_blocks() failed: Wrong return type")
    else:
        raise TypeError("Unit test for load_list_of_blocks() failed: Wrong return type")


# Generated at 2022-06-25 05:17:48.514581
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("# Unit test for function load_list_of_tasks:")
    print("## Case 0: ")
    test_case_0()

if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:17:57.749483
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    list_of_tasks_ds_0 = [{}]
    list_of_tasks_ds_1 = [{}]
    list_of_tasks_ds_2 = [{}]
    list_of_tasks_ds_3 = [{}]
    list_of_tasks_play_0 = True
    list_of_tasks_play_1 = True
    list_of_tasks_block_1 = [{}]
    list_of_tasks_block_2 = [{}]
    list_of_tasks_block_3 = [{}]
    list_of_tasks_role_1 = [{}]
    list_of_tasks_role_2 = [{}]
    list_of_tasks_role_3 = [{}]
   

# Generated at 2022-06-25 05:18:01.469990
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    parser = argparse.ArgumentParser()
    parser.add_argument('--test', action='store_true', help='Run test cases')
    args = parser.parse_args()

    if args.test:
        test_case_0()


# Generated at 2022-06-25 05:18:08.941904
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bool_0 = True
    bool_1 = False
    import ansible.playbook.task

    var_0 = [ ansible.playbook.task.ModuleArgsParser('test') ]
    var_1 = load_list_of_tasks(var_0, bool_1)
    assert var_1[0]._task.all_parents_static() == bool_1


# Generated at 2022-06-25 05:18:11.343629
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_case_0()

# Program entry point
if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:18:13.690945
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks('a', 'a') == 'a'

# Generated at 2022-06-25 05:18:15.732641
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print(test_case_0())

test_load_list_of_tasks()

# Generated at 2022-06-25 05:19:06.785826
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
    except Exception as err:
        print('Exception: ', str(err))
        traceback.print_tb(err.__traceback__)

# Global fixture for function load_list_of_tasks

# Generated at 2022-06-25 05:19:17.519394
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    func_args = []
    hosts_path = tempfile.mkdtemp()
    write_host_file(hosts_path, 'testhost', 'testuser', 'testpass')
    loader, inventory, variable_manager = _load_env(hosts_path)
    variable_manager.set_inventory(inventory)
    variable_manager.extra_vars = load_extra_vars(loader=loader, options=Options(connection='local', forks=10, become=None, become_method=None, become_user=None, check=False, diff=False, listhosts=None, listtasks=None, listtags=None, syntax=None), variable_manager=variable_manager)

# Generated at 2022-06-25 05:19:19.414322
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
    except Exception as e:
        print("[-] Test case 0 Failed: %s"%str(e))


# Generated at 2022-06-25 05:19:27.073491
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bool_0 = True
    bool_1 = False
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_4 = 4
    int_7 = 7
    int_8 = 8
    str_0 = "0"
    str_1 = "1"
    str_2 = "2"
    str_3 = "3"
    str_4 = "4"
    str_5 = "5"
    str_6 = "6"
    str_7 = "7"
    str_9 = "9"
    str_10 = "10"
    str_11 = "11"
    str_12 = "12"
    str_23 = "23"
    str_24 = "24"
    str_25 = "25"
    str_26 = "26"

# Generated at 2022-06-25 05:19:33.906495
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_1 = {
        'block': {
            'key_0': "test case 0", 
            'key_1': {
                'key_2': False, 
                'key_3': -0.8710937, 
                'key_4': {
                    'key_5': 'test case 1', 
                    'key_6': 'test case 1', 
                    'key_7': [
                        'test case 0', 
                        'test case 1', 
                        'test case 2', 
                        'test case 3'
                    ]
                }
            }
        }, 
        'tasks': [
            True, 
            {
                'key_8': 'test case 1'
            }
        ]
    }
    var_2 = 10.1

# Generated at 2022-06-25 05:19:37.121442
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Set up mock variables
    bool_0 = True
    var_0 = load_list_of_tasks(bool_0, bool_0)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 05:19:47.230581
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Try loading list as tasks
    ds = [
        {'set_fact': {'foo': 'bar'}},
        {'include': 'other.yml'},
    ]
    play = True
    block = True

    # Expected result
    # Task {'set_fact': {'foo': 'bar'}}
    # IncludeTasks {'include': 'other.yml'}
    result = load_list_of_tasks(ds, play, block)

    print("Result:")
    for i in range(len(result)):
        print("Task " + str(result[i]))

    if ds == [result[0], result[1]]:
        return
    else:
        return 1


# Generated at 2022-06-25 05:19:48.893655
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
        assert True == True
    except AssertionError:
        assert True == False


# Generated at 2022-06-25 05:19:58.279457
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bool_0 = True
    str_0 = 'v_8TTB'
    float_0 = float('-inf')
    lst_0 = []
    lst_1 = []
    lst_2 = []
    lst_3 = []
    lst_4 = []
    lst_5 = []
    lst_6 = []
    lst_7 = []
    lst_8 = []
    lst_9 = []
    lst_10 = []
    lst_11 = []
    lst_12 = []
    lst_13 = []
    lst_14 = []
    lst_15 = []
    lst_16 = []
    lst_17 = []
    lst_18 = []
    lst_19 = []
    lst_20 = []


# Generated at 2022-06-25 05:20:00.606284
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        assert(test_case_0())
    except AssertionError:
        display.display("An AssertionError was raised, but no AssertionError was expected.")
        return False
    return True

# Test cases for function load_list_of_tasks

# Generated at 2022-06-25 05:21:01.165306
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole

    task_ds = {
        "block": [
            {
                "block": [],
                "block_end": "*/",
                "block_start": "* TEST"
            }
        ],
        "block_end": "*/",
        "block_start": "* TEST"
    }
    task_ds2 = {
        "include_tasks": "tasks/main.yml"
    }
    task_ds3 = {
        "include_role": {
          "name": "test"
        }
    }

# Generated at 2022-06-25 05:21:02.924949
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("----------test_load_list_of_tasks----------")
    test_case_0()
    print("----------test_load_list_of_tasks----------")



# Generated at 2022-06-25 05:21:05.180465
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bool_0 = True
    var_0 = load_list_of_tasks(bool_0, bool_0)



# Generated at 2022-06-25 05:21:08.254521
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        print(sys.exc_info()[0])
        print(traceback.format_exc())
        assert False

# unit test for
# ansible/lib/ansible/playbook/__init__.py

# Generated at 2022-06-25 05:21:11.816166
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("test_load_list_of_tasks")
    test_case_0()

# Generated at 2022-06-25 05:21:16.065616
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # FIXME: function load_list_of_tasks should not return anything
    # If a function don't return anything, you can remove the variable
    var_0 = load_list_of_tasks()
    assert(var_0 == None)



# Generated at 2022-06-25 05:21:22.810070
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{ "action": { "module": "system", "args": { "commands": "echo 'jerry'", "register": "output" } }, "loop": { "name": "item", "items": [ "server1", "server2" ] } }]
    play = {}
    block = {}
    role = {}
    task_include = {}
    use_handlers = True
    variable_manager = {}
    loader = {}

# Generated at 2022-06-25 05:21:31.065237
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    section_0 = {
        'include_vars': dict(
            file='/etc/ansible/facts.d/{{ ansible_os_family }}.fact'
        ),
        'block':[
            
        ],
        'name': 'Load facts',
        'register': 'local_facts'
    }
    
    section_1 = {
        'include_vars': dict(
            file='/etc/ansible/facts.d/{{ ansible_os_family }}.fact'
        ),
        'block':[
            
        ],
        'name': 'Load facts',
        'register': 'local_facts'
    }
    

# Generated at 2022-06-25 05:21:34.214917
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    os.chdir('/Users/alex/Documents/ansible/ansible/')
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()



# Generated at 2022-06-25 05:21:36.049687
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # assert True
    #assert load_list_of_tasks(bool_0, bool_0) == 
    #raise NotImplementedError()
    pass

# Generated at 2022-06-25 05:23:36.714501
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 0
    int_1 = 0
    str_0 = str(int_0)
    str_1 = str(int_0)
    var_0 = load_list_of_tasks(int_1, int_0)
    var_1 = load_list_of_tasks(str_0, str_1)


# Generated at 2022-06-25 05:23:42.624541
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_0 = {"when": True, "action": {"__ansible_module__": "ping", "__ansible_arguments__": "", "__ansible_positional_args__": ["", "", ""], "__ansible_no_log__": False}, "local_action": "command", "args": "", "__ansible_module__": "ping", "__ansible_arguments__": "", "__ansible_positional_args__": ["", "", ""], "__ansible_no_log__": False}
    bool_0 = True
    var_0 = load_list_of_tasks([task_0], bool_0)
    for i in var_0:
        print(i.action)
