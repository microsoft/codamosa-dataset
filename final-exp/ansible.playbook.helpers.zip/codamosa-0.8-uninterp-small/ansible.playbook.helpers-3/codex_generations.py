

# Generated at 2022-06-25 05:14:01.646060
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    with pytest.raises(AssertionError, match="The ds \(1.5\) should be a list but was a <class 'float'>"):
        test_case_0()

# Generated at 2022-06-25 05:14:02.834599
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
  pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:14:07.789291
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = ''
    play = ''
    block = ''
    role = ''
    task_include = ''
    use_handlers = ''
    variable_manager = ''
    loader = ''
    rv = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert rv is None


# Generated at 2022-06-25 05:14:10.511824
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
    except Exception as e:
        display.error(str(e))
        display.traceback()
        return False


# Generated at 2022-06-25 05:14:17.116638
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    #
    # Test case 0
    #
    float_0 = 1.5
    str_0 = None
    var_0 = load_list_of_tasks(float_0, float_0, str_0)
    
    #
    # Test case 1
    #
    int_0 = 90
    str_1 = None
    var_1 = load_list_of_tasks(int_0, int_0, str_1)
    #
    # Test case 2
    #
    var_2 = load_list_of_tasks('kwach', 'kwach', 'kwach')
    #
    # Test case 3
    #
    list_0 = [0, 1, 2, 3]
    str_3 = 'oscar'

# Generated at 2022-06-25 05:14:18.715966
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_case_0()

# unit test for function load_list_of_blocks

# Generated at 2022-06-25 05:14:26.158096
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import tempfile
    from ansible.cli.playbook import play_ds
    from ansible.playbook.play import Play
    from ansible.cli import CLI
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import module_loader

    test_dir = tempfile.mkdtemp()

    cli = CLI()
    option_parser = cli.create_option_parser()
    (options, args) = option_parser.parse_args(['ansible-playbook', '--inventory-file=%s' % os.devnull, '--list-tasks', test_dir])

    loader, inventory, variable_manager = cli.setup_vars(options)

# Generated at 2022-06-25 05:14:29.459442
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    #float_0 = 1.5
    #str_0 = None
    #var_0 = load_list_of_tasks(float_0, float_0, str_0)

    #assert var_0 == 'hello'
    assert True


# Generated at 2022-06-25 05:14:40.877351
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import task_include as task_include_m
    from ansible.playbook.task import Task

    str_0 = None
    float_0 = 1.5
    str_1 = "baz"
    str_2 = "foo"
    float_1 = 1.0
    str_3 = "bar"
    str_4 = "baz"
    float_2 = 3.14

    list_0 = [
        { "block": [
            { str_2:
                [ { str_3: float_1 }, { str_4: float_2 }
                ]
            }
        ] }
    ]

    list_1 = []

    # Pass: call function with correct arguments

# Generated at 2022-06-25 05:14:50.554834
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'command'
    str_1 = 'role'
    str_2 = 'my_role'
    dict_0 = dict()
    dict_0['action'] = str_0
    dict_0['role'] = str_1
    dict_0['role_name'] = str_2
    dict_1 = dict()
    dict_1['action'] = str_0
    dict_1['role'] = str_1
    dict_1['role_name'] = str_2
    dict_2 = dict()
    dict_2['action'] = str_0
    dict_2['role'] = str_1
    dict_2['role_name'] = str_2
    list_0 = list()
    list_0.append(dict_0)
    list_0.append(dict_1)


# Generated at 2022-06-25 05:15:11.501866
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task

    try:
        int(1).bit_length()
    except AttributeError:
        import unittest
        import sys

        raise unittest.SkipTest("Python 2.6 detected: cannot run load_list_of_tasks unit tests")

    # create a fake action plugin in memory
    fake_action = type('my_fake_action', (object,), {})
    fake_action.__name__ = 'fake'
    fake_action.bypass_checks = False
    fake_action.no_log = False

# Generated at 2022-06-25 05:15:14.111623
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'jvb9LH'
    int_1 = 1964
    list_0 = load_list_of_tasks(str_0, int_1)

# Tests for load_list_of_blocks

# Generated at 2022-06-25 05:15:18.067700
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = 'jvb9LH'
    play = 1964
    block = 'uvFA7V'
    role = 'l5ZJE5'
    task_include = 'l5ZJE5'
    # func call load_list_of_tasks
    var_0 = load_list_of_tasks(ds, play, block, role, task_include)


# Generated at 2022-06-25 05:15:22.551949
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    str_0 = 'NVH'
    str_1 = 'CJ8'
    str_2 = 'N6U'
    str_3 = 'JZn'
    int_0 = 1959
    int_1 = 1707
    var_0 = load_list_of_roles(str_0, int_0, str_1, str_2, str_3, int_1)


# Generated at 2022-06-25 05:15:29.431369
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # TODO: Configure the testcase
    str_0 = 'K2z75c'
    int_0 = -947
    current_role_path = 'w2Q0uE'
    variable_manager = VariableManager()
    loader = DataLoader()
    collection_search_list = 'gwLZdA'
    # Execute the function
    load_list_of_roles(str_0, int_0, current_role_path, variable_manager, loader,
                       collection_search_list)


# Generated at 2022-06-25 05:15:35.924532
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = "Sx42tc"
    int_0 = 1074
    dict_0 = dict()
    dict_0['T9T'] = "m"
    dict_0['KSi'] = "Qw%De"
    dict_0['NvN'] = "Ro"
    dict_0['Ki'] = "vD7)"
    dict_0['6i'] = "T"
    dict_0['ny'] = "l"
    dict_0['cQ2'] = "iP"
    dict_0['8z'] = "I"
    dict_0['gv'] = "R"
    dict_0['Nt'] = "0]h"
    dict_0['m'] = "l;@"
    dict_0['NTI'] = "k"
    dict_0

# Generated at 2022-06-25 05:15:44.076800
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = '[{\'block\': \'hello world\'}, {}]'
    play = 'z38tjw'
    block = None
    loader = None
    variable_manager = None
    task_include = None
    use_handlers = False

    result = load_list_of_tasks(ds, play, block, task_include, use_handlers, variable_manager, loader)
    assert result == 'VJXyCm0'


# Generated at 2022-06-25 05:15:53.423240
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print('Testing load_list_of_tasks...')

    task_ds = [{'a': 'b'}]
    play = object()
    block = object()
    role = object()
    task_include = object()
    use_handlers = False
    variable_manager = object()
    loader = object()

    task_list = load_list_of_tasks(task_ds, play, block, role, task_include, use_handlers, variable_manager, loader)

    assert len(task_list) == 1
    assert task_list[0]['a'] == 'b'
    print('Passed unit test')


# Generated at 2022-06-25 05:16:01.306182
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks(None, "play", None, None, None, False, None, None) == []
    assert load_list_of_tasks([], "play", None, None, None, False, None, None) == []
    assert load_list_of_tasks(None, "play", "block", None, None, False, None, None) == []
    assert load_list_of_tasks([], "play", "block", None, None, False, None, None) == []
    assert load_list_of_tasks(None, "play", None, "role", None, False, None, None) == []
    assert load_list_of_tasks([], "play", None, "role", None, False, None, None) == []

# Generated at 2022-06-25 05:16:07.853586
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = '2UWL'
    int_0 = 1676
    str_1 = 'jvb9LH'
    load_list_of_tasks(str_0, int_0, str_1)

str_0 = '2UWL'
int_0 = 1676
str_1 = 'jvb9LH'
int_1 = 3204
int_2 = -3500
str_2 = 'e'
str_3 = '2UWL'
load_list_of_tasks(str_0, int_0, str_1, bool_0, int_1, bool_1, str_2, str_3)

# Generated at 2022-06-25 05:16:34.951530
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'YhDURR'
    int_0 = 518
    var_0 = load_list_of_tasks(str_0, int_0)


# Generated at 2022-06-25 05:16:39.164587
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = {'block': {'rescue': 'some'}, 'some': 'dict'}
    task_ds_1 = {'some': 'dict'}
    task_ds_2 = {'some_int': 12}
    loader = DictDataLoader({'test.yml': "{test: foo}"})
    variable_manager = VariableManager()
    variable_manager._fact_cache = {'test': 'foo'}
    display.verbosity = 3
    try:
        load_list_of_tasks(task_ds, 1, 1, 1)
        assert 0
    except AnsibleAssertionError:
        assert 1

# Generated at 2022-06-25 05:16:41.723615
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Module_utils/shippable/util.py
    from ansible.errors import AnsibleUndefinedVariable

    # Test case 0
    str_0 = 'jvb9LH'
    int_0 = 1964
    var_0 = load_list_of_tasks(str_0, int_0)



# Generated at 2022-06-25 05:16:50.368031
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # setup
    ds = ['foo', 'bar']
    play = {}
    block = None
    role = 'role'
    # execute the function
    return_value = load_list_of_tasks(ds, play, block, role)
    assert return_value[0] == [{'foo': 'foo'}, None, [], [], {}, {'_ansible_for_loop_index': 0, '_ansible_for_loop_var': 'item'}, {}, {}, {}, {}]
    assert return_value[1] == [{'bar': 'bar'}, None, [], [], {}, {'_ansible_for_loop_index': 1, '_ansible_for_loop_var': 'item'}, {}, {}, {}, {}]

    ds = ['foo', 'bar']

# Generated at 2022-06-25 05:16:57.591700
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = "test_value"
    int_0 = 1234
    var_0 = load_list_of_tasks(str_0, int_0)

if __name__ == "__main__":
    print ("[+] Running tests")
    test_case_0()
    test_load_list_of_tasks()
    print ("[-] Done")

# Generated at 2022-06-25 05:17:03.700938
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 = ['o\x07\x0c\x00', 'o\x07\x0c\x00', '\\', '\\']
    var_1 = 0x7e
    var_2 = 0x7e
    var_3 = 0x7e
    var_4 = 0x7e
    var_5 = 0x7e
    var_6 = 0x7e
    var_7 = 0x7e
    var_8 = 0x7e
    var_9 = 0x7e
    var_10 = load_list_of_tasks(var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7, var_8, var_9)


# Generated at 2022-06-25 05:17:07.998927
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'lAzhWp'
    str_1 = 'xD1BoH'
    str_2 = 'zlP0oR'
    int_0 = 1696
    var_5 = load_list_of_tasks(str_0, str_1, str_2, int_0)
    testcase_0(var_5)


# Generated at 2022-06-25 05:17:10.489602
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    list_0 = []
    int_0 = 1964
    list_1 = []
    var_0 = load_list_of_tasks(list_0, int_0, list_1)


# Generated at 2022-06-25 05:17:16.956391
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = 'jvb9LH'
    play = 1964
    block = 'sVl8Wq'
    task_include = 'PZoJUY'
    use_handlers = 'jyS7V1'
    variable_manager = 'hDmZ4'
    loader = 'e2V7iy'
    result = load_list_of_tasks(
        ds,
        play,
        block,
        task_include,
        use_handlers,
        variable_manager,
        loader,
    )



# Generated at 2022-06-25 05:17:19.220253
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    if DEBUG == True:
        load_list_of_tasks(ds=ds, play=play, block=block, role=role, task_include=task_include, use_handlers=use_handlers, variable_manager=variable_manager, loader=loader)
        

# Generated at 2022-06-25 05:17:33.024973
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Variables
    str_0 = 'jvb9LH'
    int_0 = 1964
    var_0 = load_list_of_tasks(str_0, int_0)
    assert var_0 == None


# Generated at 2022-06-25 05:17:37.165255
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'jvb9LH'
    int_0 = 1964
    var_0 = load_list_of_tasks(str_0, int_0)

# Generated at 2022-06-25 05:17:46.107356
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{'foo': 'bar'}]
    play = 10
    block = 11
    role = 12
    task_include = 13
    use_handlers = False
    variable_manager = 14
    loader = 15

    task_list = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert len(task_list) == 2
    assert isinstance(task_list[0], Block)
    assert isinstance(task_list[1], TaskInclude)

# Generated at 2022-06-25 05:17:57.531241
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass_str = 'example'
    pass_int = 8080
    pass_float = 3.14
    pass_list = [0, 1, 2]

# Generated at 2022-06-25 05:18:00.643946
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'jvb9LH'
    int_0 = 1964
    var_0 = load_list_of_tasks(str_0, int_0)


# Generated at 2022-06-25 05:18:04.347326
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True


# Generated at 2022-06-25 05:18:07.283854
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    display = Display()
    display.deprecated('"include" is deprecated, use include_tasks/import_tasks instead', '2.16')
    # TODO: place more unit tests here


# Generated at 2022-06-25 05:18:10.890501
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # args 0 to 1
    str_0 = 'jvb9LH'
    int_0 = 1964
    var_0 = load_list_of_tasks(str_0, int_0)



# Generated at 2022-06-25 05:18:15.684611
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'vYlSj'
    int_0 = 1954
    str_1 = 'OdO'
    test_case_0(str_0, int_0, str_1)


# Generated at 2022-06-25 05:18:23.522551
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    args = {}

    ds = [{'include': 'test-include.yml'}]
    play = Play()
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None

    try:
        result = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    except Exception as e:
        result = None
    assert result is not None

if __name__ == '__main__':
    test_case_0()
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:18:46.481577
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # test case start
    str_0 = 'jvb9LH'
    int_0 = 1964
    var_0 = load_list_of_tasks(str_0, int_0)
    # test case end


# Generated at 2022-06-25 05:18:49.288422
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # if action in C._ACTION_ALL_INCLUDE_IMPORT_TASKS:
    task_ds = ['include_tasks']


# Generated at 2022-06-25 05:18:55.390900
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Create mocks for the parameter types
    ds = 'string'
    play = Play()
    current_role_path = 'string'
    variable_manager = VariableManager()
    loader = DataLoader()
    collection_search_list = 'string'

    # Call the function
    result = load_list_of_roles(ds, play, current_role_path, variable_manager, loader, collection_search_list)
    assert isinstance(result, list)
    assert len(result) == 0

# Generated at 2022-06-25 05:19:01.959812
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    dict_0 = dict()
    dict_0['1'] = 'vK8qtdWw'
    dict_0['2'] = '{@j#7h'
    dict_0['3'] = 'P!o^'
    dict_0['4'] = 1332
    dict_0['5'] = 'o[yK'
    dict_0['6'] = 'q*8,c'
    dict_0['7'] = 'q3J'
    dict_0['8'] = 'p'
    dict_0['9'] = '@+6;I0'
    dict_0['10'] = ']k!w'
    dict_0['11'] = 'I`9X1'
    dict_0['12'] = 'a?su'

# Generated at 2022-06-25 05:19:09.463127
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("test_load_list_of_tasks")
    str_0 = 'jvb9LH'
    int_0 = 1964
    str_1 = 'jvb9LH'
    str_2 = 'jvb9LH'
    str_3 = 'jvb9LH'
    str_4 = 'jvb9LH'
    str_5 = 'jvb9LH'
    str_6 = 'jvb9LH'
    str_7 = 'jvb9LH'
    var_0 = load_list_of_tasks(str_0, int_0, str_1, str_2, str_3, str_4, str_5, str_6, str_7)
    test_case_0()
    test_case_1

# Generated at 2022-06-25 05:19:18.945569
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_0 = Task({"name": "name_0", "action": "action_0", "block_0": "block_0"}, "parent_block_0", "role_0", "task_include_0", "use_handlers_0", "variable_manager_0", "loader_0")
    task_list_0 = [task_0]
    block_0 = Block({"name": "name_1", "block_0": "block_1"}, "task_list_0", "parent_block_1", "role_1", "task_include_1", "use_handlers_1", "variable_manager_1", "loader_1")
    block_list_0 = [block_0]
    str_0 = 'jvb9LH'

# Generated at 2022-06-25 05:19:23.341721
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    list_0 = [{}, {}]
    int_0 = 1948
    int_1 = 1949
    str_0 = 'v6UZ7s'
    int_2 = 1951
    int_3 = 1952
    var_0 = load_list_of_tasks(list_0, int_0, int_1, str_0, int_2, int_3)
    assert var_0 == 3



# Generated at 2022-06-25 05:19:30.768792
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Testing method load_list_of_tasks

    class MockTaskInclude(object):
        def __init__(self, *args, **kwargs):
            self.kwargs = kwargs
            self._parent = None
            if 'block' in kwargs:
                self._parent = kwargs['block']
            self.args = args
            self.task_include = None
            self.tags = []
        def copy(self, exclude_parent=False):
            task_copy = MockTaskInclude(*self.args, **self.kwargs)
            if not exclude_parent:
                task_copy.set_parent(self._parent)
            return task_copy
        def set_parent(self, parent):
            self._parent = parent

# Generated at 2022-06-25 05:19:41.084696
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = ';'
    int_0 = 583
    dict_0 = dict()
    dict_0[str_0] = int_0
    dict_0['_'] = 'maL'
    str_1 = 'OQAXil'
    dict_0[str_1] = 'xVZC'
    str_2 = 't0Fpo'
    dict_0[str_2] = 'L'
    dict_0['H'] = '1!@r'
    dict_0['A'] = 'woGj'
    dict_0['K'] = '}G<i'
    dict_0['s'] = 'KpX'
    str_3 = 'nj'
    dict_0[str_3] = '3jiH'

# Generated at 2022-06-25 05:19:50.554148
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Initialize test variables

    # Load an empty list into memory
    ds_0 = []
    play_0 = ''
    block_0 = ''
    role_0 = ''
    task_include_0 = ''
    use_handlers_0 = False
    variable_manager_0 = ''
    loader_0 = ''
    output_0 = load_list_of_tasks(ds_0, play_0, block_0, role_0, task_include_0, use_handlers_0, variable_manager_0, loader_0)

    # Load a invalid list into memory
    ds_1 = 'foo'
    play_1 = ''
    block_1 = ''
    role_1 = ''
    task_include_1 = ''
    use_handlers_1 = False
    variable_manager_1

# Generated at 2022-06-25 05:20:23.241877
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = '*'
    int_0 = 1931
    var_0 = load_list_of_tasks(str_0, int_0)
    var_1 = load_list_of_tasks(str_0, int_0)


# Generated at 2022-06-25 05:20:31.879092
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = load_list_of_blocks('jvb9LH', 1964)
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    assert load_list_of_tasks(ds, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None) == None
    assert load_list_of_tasks(ds, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None) == None
    assert load_list_of_tasks(ds, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None) == None

# Generated at 2022-06-25 05:20:35.856725
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
   assert load_list_of_tasks ('jvb9LH',1964) == None

# Generated at 2022-06-25 05:20:43.786809
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'DgBb4'
    int_0 = 0
    str_1 = 'vfry'
    int_1 = 7394
    str_2 = 'aZH'
    int_2 = 5321
    var_2 = load_list_of_tasks(str_0, int_0, str_1, int_1, str_2, int_2)
    print(var_2)


# Generated at 2022-06-25 05:20:53.349527
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Arrange
    ds = ['a', 'b']
    play = object()
    block = object()
    role = object()
    task_include = object()
    use_handlers = True
    variable_manager = object()
    loader = object()

    # Act
    ret_val = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)

    # Assert
    assert ret_val is not None
    assert ret_val == []

# Generated at 2022-06-25 05:20:55.809080
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:21:04.811669
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    PlaybookInclude = collections.namedtuple('PlaybookInclude', ['_role_name'])
    Template = collections.namedtuple('Template', ['template'])
    VariableManager = collections.namedtuple('VariableManager', ['get_vars', 'get_vars'])
    var_0 = VariableManager(get_vars=lambda self, *args, **kwargs: None, get_vars=lambda self, *args, **kwargs: None)
    int_0 = 1
    var_1 = Template(template=lambda self, *args, **kwargs: None)
    var_2 = PlaybookInclude(
        _role_name=var_1
    )

# Generated at 2022-06-25 05:21:11.169007
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_0 = ['jvb9LH', 1964]
    task_1 = ['jvb9LH', 1964]
    task_2 = ['jvb9LH', 1964]
    task_3 = ['jvb9LH', 1964]
    task_4 = ['jvb9LH', 1964]
    task_5 = ['jvb9LH', 1964]
    task_6 = ['jvb9LH', 1964]
    task_7 = ['jvb9LH', 1964]
    task_8 = ['jvb9LH', 1964]
    task_9 = ['jvb9LH', 1964]
    task_10 = ['jvb9LH', 1964]
    task_11 = ['jvb9LH', 1964]

# Generated at 2022-06-25 05:21:16.370396
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    #print(load_list_of_tasks(([{'name': 'test'}]), "play"))
    dict = [{'block': 'df'}]
    load_list_of_tasks(dict, "play")


if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:21:19.674395
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    str_0 = 'jvb9LH'
    int_0 = 1964
    var_0 = load_list_of_blocks(str_0, int_0)
    if str_0 is not None:
        raise Exception('Failed')
    if int_0 <= 0:
        raise Exception('Failed')


# Generated at 2022-06-25 05:21:40.176627
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'jvb9LH'
    int_0 = 1964
    var_0 = load_list_of_tasks(str_0, int_0)


# Generated at 2022-06-25 05:21:44.101706
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'jvb9LH'
    int_0 = 1964
    var_0 = load_list_of_tasks(str_0, int_0)


# Generated at 2022-06-25 05:21:47.437989
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    test_case_0()


# Generated at 2022-06-25 05:21:50.112769
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'hV6UHX'
    int_0 = 1478
    var_0 = load_list_of_tasks(str_0, int_0)


# Generated at 2022-06-25 05:21:57.079384
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:22:02.391632
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'jvb9LH'
    int_0 = 1964
    var_0 = load_list_of_blocks(str_0, int_0)
    var_1 = load_list_of_tasks(var_0, int_0)
    display.display(var_1)

# Generated at 2022-06-25 05:22:08.723673
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    assert callable(load_list_of_tasks)
    str_0 = 'jvb9LH'
    int_0 = 1964
    var_0 = load_list_of_tasks(str_0, int_0)
    str_0 = 'jvb9LH'
    int_0 = 1964
    var_0 = load_list_of_tasks(str_0, int_0)



# Generated at 2022-06-25 05:22:11.254261
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_str = 'q3jk8'
    test_int = 6689
    test_var = load_list_of_tasks(test_str, test_int)
    assert test_var is not None


# Generated at 2022-06-25 05:22:19.985430
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Load dictionary from JSON file
    with open("tests/parsers/fixtures/play_parser_play_2.json") as f:
        data = json.load(f)
    # Parse data structure
    result = load_list_of_tasks(data, 0, None, None, None, False, None, None)
    assert len(result) == 3
    # Parse individual tasks
    task_1 = result[0]
    task_2 = result[1]
    task_3 = result[2]
    # Task 1
    assert task_1.action == 'firewall'
    assert task_1.name == 'Append rule to iptables'
    # Task 2
    assert task_2.action == 'include_vars'

# Generated at 2022-06-25 05:22:27.014582
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible.utils.template
    from ansible.errors import AnsibleParserError

    # Test 0
    list_0 = []

    try:
        load_list_of_tasks(list_0)
        raise Exception('Expected an exception when calling load_list_of_tasks() with the wrong number of arguments.')
    except TypeError:
        pass
    except Exception as e:
        print(e)
        raise Exception('Expected a TypeError.')

    # Test 1
    dict_0 = dict()
