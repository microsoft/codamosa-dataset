

# Generated at 2022-06-25 05:13:53.375889
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass

# Generated at 2022-06-25 05:13:54.504889
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_case_0()
    
if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:14:01.893489
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # FIXME: This unit test is broken
    #bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    bool_0 = False
    assert(load_list_of_tasks(None, bool_0) == None)
    #assert(load_list_of_tasks(bytes_0, bool_0) == None)


# Generated at 2022-06-25 05:14:11.320077
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    role_path = 'renamed_test/test_role_1'
    ds = 'test playbook'
    play = 'test playbook'
    parent_block = 'test playbook'
    role = 'test role'
    task_include = 'test role'
    use_handlers = False
    variable_manager = 'test role'
    loader = 'test role'
    ansible_1_2_3_0 = load_list_of_blocks(ds, play, parent_block, role, task_include, use_handlers, variable_manager, loader)
    role_path = 'renamed_test/test_role_1'
    ds = 'test playbook'
    play = 'test playbook'
    parent_block = 'test playbook'
    role = 'test role'
    task_include = 'test role'
   

# Generated at 2022-06-25 05:14:19.363578
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bool_0 = False
    bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    var_1 = load_list_of_tasks(bytes_0, bool_0)
    print('var_1', repr(var_1))


# Generated at 2022-06-25 05:14:23.162980
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
    except Exception as exc:
        display.error(exc.msg)
        raise



# Generated at 2022-06-25 05:14:25.457376
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert_equals(2,1+1)

# unit tests for load_list_of_tasks goes here
# unit tests for load_list_of_blocks goes here


# Generated at 2022-06-25 05:14:27.381192
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Maybe This test is Redundant!!!
    test_case_0()


# Generated at 2022-06-25 05:14:31.121005
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # From generated test case data
    bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    bool_0 = False
    var_0 = load_list_of_tasks(bytes_0, bool_0)


# Generated at 2022-06-25 05:14:35.016919
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
    except:
        print("Exception raised, test_load_list_of_tasks")
        raise



# Generated at 2022-06-25 05:14:57.020506
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    bool_0 = False
    var_0 = load_list_of_tasks(bytes_0, bool_0)
    assert isinstance(var_0, list)
    pass


# Generated at 2022-06-25 05:15:04.930261
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # AssertionError(msg=None, *args, **kwargs)
    load_list_of_tasks = AssertionError()
    assert load_list_of_tasks, "load_list_of_tasks: no assert"

if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:15:12.808711
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test the function with bytes_0:
    bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    bool_0 = False
    var_0 = load_list_of_tasks(bytes_0, bool_0)
    
    # Test the function with bytes_1:
    bytes_1 = b'\x1e\x0f\x03\x17\x1a\x00\x18\t\x05\x08\t\x12\x03'
    bool_1 = False
    var_1 = load_list_of_tasks(bytes_1, bool_1)
    
    # Test the function with bytes_2:

# Generated at 2022-06-25 05:15:23.674083
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    task_ds_0 = {}
    block_0 = None
    task_include_0 = None
    role_0 = None
    loader_0 = None
    variable_manager_0 = None
    play_0 = None

    assert load_list_of_tasks(task_ds_0, play_0, block_0, role_0, task_include_0, False, variable_manager_0, loader_0)

    try:
        assert load_list_of_tasks(task_ds_0, play_0, block_0, role_0, task_include_0, False, variable_manager_0, loader_0) == None
    except NotImplementedError:
        pass


# Generated at 2022-06-25 05:15:29.500274
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    bool_0 = False
    var_0 = load_list_of_tasks(bytes_0, bool_0)
    print(var_0)

if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:15:30.374614
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_case_0()

# Generated at 2022-06-25 05:15:34.560601
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
        bool_0 = False
        var_0 = load_list_of_tasks(bytes_0, bool_0)
    except Exception:
        assert False


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-25 05:15:36.679404
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    bool_0 = False
    var_0 = load_list_of_tasks(bytes_0, bool_0)


# Generated at 2022-06-25 05:15:38.998408
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test for load_list_of_tasks
    bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    bool_0 = False
    var_0 = load_list_of_tasks(bytes_0, bool_0)



# Generated at 2022-06-25 05:15:45.430156
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    load_list_of_tasks(False, True)
    try:
        load_list_of_tasks('\xa7\x18\xbe\x83', 'F\x15\xc8\xdc\x17\x0e\x99\xed\x88')
        raise Error('AssertionError expected')
    except AssertionError:
        pass


# Generated at 2022-06-25 05:16:14.684779
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    bool_0 = False
    var_0 = load_list_of_tasks(bytes_0, bool_0)



# Generated at 2022-06-25 05:16:22.123473
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar

    # Test Cases

    # bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    # bool_0 = False
    # var_0 = load_list_of_tasks(bytes_0, bool_0)
    # assert(var_0 == '')


# Generated at 2022-06-25 05:16:24.565905
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_case_0()

# vim: set noet ts=4 sw=4 ft=python :

# Generated at 2022-06-25 05:16:29.630868
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
        bool_0 = False
        var_0 = load_list_of_tasks(bytes_0, bool_0)
    except Exception as e:
        print(e)
        # load_list_of_tasks is not supported on Windows.

if __name__ == "__main__":
    test_case_0()
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:16:30.895533
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_case_0()

# Print function for function load_list_of_tasks

# Generated at 2022-06-25 05:16:33.443241
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("Unit test for function load_list_of_tasks")
    test_case_0()

if __name__ == "__main__":
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:16:36.101952
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    list_0 = [b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT']
    bool_0 = False
    var_0 = load_list_of_tasks(list_0, bool_0)


# Generated at 2022-06-25 05:16:39.541181
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    #print("test_load_list_of_tasks")
    #var_0 = load_list_of_tasks(bytes_0, bool_0)
    
    #test_case_0
    bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    bool_0 = False
    var_0 = load_list_of_tasks(bytes_0, bool_0)


# Generated at 2022-06-25 05:16:40.492090
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True

# Generated at 2022-06-25 05:16:49.885971
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Test of 0 parameter.
    try:
        test_case_0()
    except Exception:
        TestUtil.print_exception_traceback()
        assert False

    # Test of 2 parameter.

# Generated at 2022-06-25 05:18:25.748377
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Example #0
    bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    bool_0 = False
    var_0 = load_list_of_tasks(bytes_0, bool_0)
    # Example #1
    list_0 = [1, 2, 3]
    bool_0 = False
    var_0 = load_list_of_tasks(list_0, bool_0)


# Generated at 2022-06-25 05:18:29.775769
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print()
    print('Testing test_load_list_of_tasks()')

    try:
        test_case_0()
    except Exception as e:
        print('FAILURE: exception encountered in test_case_0()')
        print(e)


if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:18:32.566949
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Try to load a list of tasks
    bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    bool_0 = False
    var_0 = load_list_of_tasks(bytes_0, bool_0)
    assert var_0 is None

# Generated at 2022-06-25 05:18:37.524882
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test a byte string 
    byteString = b'This is a byte string'
    assert load_list_of_tasks(byteString, False) == None
    # Test a string
    string = "This is a string"
    assert load_list_of_tasks(string, False) == None

# Generated at 2022-06-25 05:18:38.746539
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    print("\n>>> TEST0: ")
    test_case_0()


# Generated at 2022-06-25 05:18:40.463976
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    bool_0 = False
    var_0 = load_list_of_tasks(bytes_0, bool_0)


# Generated at 2022-06-25 05:18:46.487571
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    bool_0 = False
    var_0 = load_list_of_tasks(bytes_0, bool_0)
    assert var_0 == None
    bytes_1 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    bool_1 = True
    var_1 = load_list_of_tasks(bytes_1, bool_1)
    assert var_1 == None
    bytes_2 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    bool_2 = False

# Generated at 2022-06-25 05:18:56.082430
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Setup
    bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    bool_0 = False
    bool_1 = True
    var_0 = load_list_of_tasks(bytes_0, bool_0)
    var_1 = load_list_of_tasks(bytes_0, bool_1)

    # Assertions
    if 'abc' in var_0:
        print('assertion: ' + 'abc' + ' in ' + str(var_0))
    else:
        print('AssertionError: ' + str('abc') + ' in ' + str(var_0))

# Generated at 2022-06-25 05:19:01.505179
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    load_list_of_tasks(b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT', False)


# Generated at 2022-06-25 05:19:02.873675
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("Testcase 0 not implemented")
    test_case_0()


# Generated at 2022-06-25 05:20:46.817208
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 = True
    var_1 = []
    var_1.append(var_0)
    var_1.append(var_0)
    var_1.append(var_0)
    load_list_of_tasks(var_1, var_0)
    test_case_0()
# test for method load_list_of_blocks

# Generated at 2022-06-25 05:20:52.960137
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    bool_0 = False
    var_0 = load_list_of_tasks(bytes_0, bool_0)
    assert var_0 == False

# Test cases in ansible.utils.unicode.native


# Test cases in ansible.utils.unsafe_proxy

# Generated at 2022-06-25 05:21:00.078168
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    bool_0 = False
    var_0 = load_list_of_tasks(bytes_0, bool_0)
    assert var_0 == None

if __name__ == "__main__":
    test_case_0()
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:21:02.436634
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO: add test cases
    # test_case_0()
    pass



# Generated at 2022-06-25 05:21:08.539749
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    bool_0 = False
    var_0 = load_list_of_tasks(bytes_0, bool_0)



# Generated at 2022-06-25 05:21:15.476362
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # A few basic sanity tests
    assert load_list_of_tasks(None, None) == []

    good_arg = [{'name': 'x'}]
    assert load_list_of_tasks(good_arg, None)
    assert load_list_of_tasks(good_arg, None)[0].module_name == 'x'



# Generated at 2022-06-25 05:21:22.495193
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # Test with simple data - should get two bare tasks in one block
    data = [
        {'include': 'tasks/main.yml'},
        {'debug': 'msg={{testvar}}'},
        {'notify': 'always'},
    ]
    result = load_list_of_blocks(data)
    assert len(result) == 1
    assert len(result[0]) == 3
    assert result[0][1] == {'debug': 'msg={{testvar}}'}

    # Test with an explicit block

# Generated at 2022-06-25 05:21:30.723750
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'
    bool_0 = False
    var_0 = load_list_of_tasks(bytes_0, bool_0)
    if var_0:
        raise Exception("expected a value but the value is : %s" %var_0)
    bytes_0 = b'\xf1?ga\xea\xfe\x18]nQ\xff^\xa3WT'

# Generated at 2022-06-25 05:21:37.013494
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    play = False
    block = None
    role = None
    task_include = 'F\x1c\x9c\xf8\xaaz\xf6\x0c\x8e'
    use_handlers = True
    variable_manager = VariableManager(loader=None, inventory=None)
    loader = DataLoader()
    ds = '\x86\x9f\x04\xdb\x01\x93\x08\xa5'
    list_0 = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert type(list_0) == list


# Generated at 2022-06-25 05:21:46.635402
# Unit test for function load_list_of_blocks