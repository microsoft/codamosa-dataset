

# Generated at 2022-06-25 05:14:05.323274
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    set_0 = None
    set_1 = None
    int_0 = 12
    var_0 = load_list_of_tasks(set_0, set_0, int_0)
    var_1 = load_list_of_tasks(set_1, set_0, int_0)
    test_case_0()
    test_case_1()


# CUT end


# CUT begin
# TODO: tests for load_list_of_blocks


# Generated at 2022-06-25 05:14:14.929090
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    set_0 = None
    set_1 = None
    int_0 = 12
    var_0 = load_list_of_roles(set_0, set_0, set_1, int_0)
    var_1 = load_list_of_roles(set_0, set_0, set_1, int_0)
    var_2 = load_list_of_roles(set_0, set_0, set_1, int_0)

if __name__ == "__main__":
    import sys
    import os
    import inspect
    import pytest
    import tempfile
    import logging
    logging.basicConfig(level=logging.DEBUG)
    logging.getLogger().setLevel(logging.DEBUG)

    # Test case 0: Run a trivial unit test that
    # should return

# Generated at 2022-06-25 05:14:20.298191
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("Testing with list of tasks")
    ds = {}
    play = None
    block = 12
    role = None
    task_include = None
    use_handlers = None
    variable_manager = None
    loader = None
    try:
        load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
        assert False
    except Exception as e:
        if 'should be a list' in str(e):
            print("\tPASSED")
        else:
            print("\tFAILED")
            print("\tExpected error: %s" % 'should be a list')
            print("\tActual error: %s" % str(e))
            assert False


# Testing load_list_of_tasks with a

# Generated at 2022-06-25 05:14:26.843761
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        set_0 = None
        int_0 = 12
        var_0 = load_list_of_tasks(set_0, set_0, int_0)
        assert var_0 == None
    except AssertionError:
        # Should be None, not an AssertionError
        raise
    else:
        # Should be an AssertionError
        assert False

test_case_0()


# Generated at 2022-06-25 05:14:34.582302
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Load the data file
    data_file = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'fixtures',
        'load_list_of_tasks.yml'
    )

    with open(data_file, 'r') as f:
        test_cases = yaml.safe_load(f)


# Generated at 2022-06-25 05:14:36.854501
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        assert(test_case_0())
    except:
        print('test_case_0() failed')


# Generated at 2022-06-25 05:14:43.879514
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    set_0 = None
    int_0 = 12
    var_0 = load_list_of_tasks(set_0, set_0, int_0)

    assert var_0 == None, 'Return value mismatch, expected value is %s, actual value is %s' % (None, var_0)
    assert type(var_0) == type(None), 'Return value has different type, expected type is %s, actual type is %s' % (type(None), type(var_0))


# Generated at 2022-06-25 05:14:46.805434
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print('Testing function load_list_of_tasks')

    # test case 0
    test_case_0()


if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:14:49.914054
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        set_0 = None
        int_0 = 12
        var_0 = load_list_of_tasks(set_0, set_0, int_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 05:14:57.913798
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    var_0 = None
    var_1 = None
    var_2 = 12
    var_3 = None
    var_4 = 12
    var_5 = None
    var_6 = 12
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-25 05:15:15.685986
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    fixture_file = 'load_list_of_roles.yml'
    fixture_file_path = utils.get_fixture_file_path(fixture_file)
    with open(fixture_file_path, 'r') as f:
        tasks_list = yaml.load(f)

    # An empty list should return an empty list
    assert load_list_of_roles([], None, None, None, None, None) == []

    # Non list should raise an assertion error
    with pytest.raises(AssertionError):
        load_list_of_roles(1, None, None, None, None, None)

    # Non dict should raise an assertion error

# Generated at 2022-06-25 05:15:20.901692
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Set up mock objects
    ds = [ { 'action': 'ping', 'async': '10', 'delegate_to': 'localhost' } ]
    play = Mock()
    parent_block = Mock(return_value='parent_block')
    role = Mock(return_value='role')
    task_include = Mock(return_value='task_include')
    use_handlers = Mock(return_value=False)
    variable_manager = Mock(return_value='variable_manager')
    loader = Mock(return_value='loader')
    expected_result = [ { 'async': '10', 'action': 'ping', 'delegate_to': 'localhost' } ]

    # Perform the test

# Generated at 2022-06-25 05:15:30.878452
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    str_0 = 'fixtures'
    str_1 = 'load_list_of_tasks.yml'
    str_2 = 'platform_centos7.json'
    str_3 = 'test_load_list_of_tasks_0.json'
    str_4 = 'test_load_list_of_blocks_0.json'
    str_5 = 'fixtures'
    str_6 = 'load_list_of_blocks.yml'
    str_7 = 'platform_centos7.json'
    str_8 = 'test_load_list_of_blocks_0.json'


# Generated at 2022-06-25 05:15:35.421160
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    dest = os.path.join('fixtures', 'load_list_of_tasks.yml')
    ds = parse_yaml_linewise(dest)
    #
    # sanity check
    #

    assert(len(ds) == 2)
    assert(ds[0] == {'debug': 'msg=test1'})
    assert(ds[1] == {'debug': 'msg=test2'})



# Generated at 2022-06-25 05:15:45.787371
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # import statements
    import os
    import pprint
    # setup
    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    # init vars
    path = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'units', 'fixtures', 'load_list_of_tasks.yml')
    ds = None
    play = None
    parent_block = None
    role = None
    task_include = None
    use_handlers = None
    ansible_group_names = ['test0']
    try:
        ds = loader.load_from_file(path)
    except AnsibleFileNotFound as e:
        display.error("The file '%s' was not found." % path) # TODO:

# Generated at 2022-06-25 05:15:58.015054
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    # This test case checks the content of the specified file
    fixture_dir = 'fixtures/load_list_of_roles.yml'

    assert os.path.exists(fixture_dir), \
            "load_list_of_roles test case 0: fixture file not found: %s" % fixture_dir

    if not os.path.exists(fixture_dir):
        raise IOError("file not found: %s" % fixture_dir)

    fh = open(fixture_dir,'r')
    test_data = yaml.safe_load(fh)
    fh.close()

    fname_ds = 'fixtures' + os.sep + 'load_list_of_roles.yml'

# Generated at 2022-06-25 05:16:02.042343
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # FIXME: Test does not reflect how function is used
    fileobj_0 = open(str_0 + str_1, 'rb')
    try:
        fileobj_0.close()
    except:
        fileobj_0.close()


# Generated at 2022-06-25 05:16:11.952526
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = """
---
- name: This is a task
  shell: /bin/false
- block:
    - name: This is a task
      shell: /bin/false
  rescue:
    - name: This is a task
      shell: /bin/false
  always:
    - name: This is a task
      shell: /bin/false
- name: This is a task
  shell: /bin/false
    """
    #ds_list = yaml.load(ds,Loader=Loader)
    ds_list = yaml.load(ds,Loader=Loader)
    print(ds_list)
    # To support ansible deprecation warning
    # ansible.utils.deprecation.deprecate(deprecated_in='2.9', removed_in='2.13', current_version=C.

# Generated at 2022-06-25 05:16:20.740726
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent circular import issues
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

    pb = Playbook.load('test/unit/test_playbooks/load_list_of_tasks.yml', variable_manager=None, loader=None)
    assert len(pb.get_plays()) == 1
    for play in pb.get_plays():
        assert play.name == 'test play'
        play_context = PlayContext(play, None)
        play.post_validate(play_context)
        assert len(play.tasks) == 12
        assert len([task for task in play.tasks if isinstance(task, Task)]) == 2
        assert len([task for task in play.tasks if isinstance(task, TaskInclude)])

# Generated at 2022-06-25 05:16:30.073396
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    str_0 = 'fixtures'
    str_1 = 'load_list_of_tasks.yml'
    str_2 = os.path.join(str_0, str_1)
    str_3 = 'role'
    str_4 = 'tasks'
    str_5 = 'include.yml'
    str_6 = os.path.join(str_0, str_3, str_4, str_5)
    str_7 = 'include_role'
    str_8 = 'include_tasks'
    str_9 = 'import_tasks'
    str_10 = 'import_role'
    str_11 = '/tmp/ansible_test_dir/test_static/test_static.yaml'
    str_12 = 'main.yml'
    str_13 = os

# Generated at 2022-06-25 05:16:49.420473
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test for correct behavior for load_list_of_tasks when no parameters are passed
    assert load_list_of_tasks()
    # Test for correct behavior of load_list_of_tasks when no parameter is passed
    assert load_list_of_tasks()
    # Test for correct behavior of load_list_of_tasks when the following
    # parameters are passed:
    #
    # ds:           <list>
    # play:         <dict>
    # role:         <object>
    # task_include: <list>
    # use_handlers: <bool>
    # variable_manager: <module>
    # loader:       <module>

# Generated at 2022-06-25 05:16:52.364529
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        str_0 = 'rb'
    except AnsibleAssertionError:
        pass


# Generated at 2022-06-25 05:17:00.512190
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = []
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    expected_result = None
    actual_result = load_list_of_tasks(task_ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert actual_result == expected_result


# Generated at 2022-06-25 05:17:12.752895
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    display.deprecated('The --tree option is deprecated. Use --tree <value> instead', version='2.12')
    display.vvvv('This is verbose output')
    display.vvvvv('This is extremely verbose output')
    display.vvvvvv('This is ultra verbose output')
    display.v('This is normal verbose output')
    display.vv('This is more verbose output')
    display.vvv('This is less verbose output')
    display.debug('This is debug output')
    display.deprecated('This is deprecated')
    display.warning('This is a warning')
    display.error('This is an error')
    display.system('This is a system message')
    display.running('')
    display.system('This is a system message')
    display.ok('OK')
    display.ok

# Generated at 2022-06-25 05:17:18.645291
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # 
    ds = {'module_name': 'os', 'module_args': {'name': 'value'}}
    play = {'block': subprocess.getoutput('pwd').splitlines()}
    block = {'block': subprocess.getoutput('pwd').splitlines()}
    role = '-1'
    task_include = {'block': subprocess.getoutput('pwd').splitlines()}
    use_handlers = '-1'
    variable_manager = subprocess.getoutput('pwd').splitlines()
    loader = {'block': 'rb'}
    ansible.playbook.task.Task.load = MagicMock(return_value='rb')
    ansible.playbook.role_include.IncludeRole.load = MagicMock(return_value='rb')
    ans

# Generated at 2022-06-25 05:17:29.255907
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.compat.tests import unittest
    import ansible.compat.tests.mock as mock

    class TestLoadListOfTasks(unittest.TestCase):

        def test_load_list_of_tasks(self):
            def _get_mock_loader():
                mock_loader = mock.MagicMock()
                mock_loader.path_dwim.return_value = '/test/a'
                mock_loader.path_dwim_relative.return_value = '/test/a'
                return mock_loader

            def _get_mock_variable_manager():
                mock_variable_manager = mock.MagicMock()

                def get_vars(play=None, task=None, include_hostvars=True):
                    return dict(a='a')

                mock_variable

# Generated at 2022-06-25 05:17:38.477357
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # load_list_of_tasks should take 5 arguments
    assert func_test.test(load_list_of_tasks, '5')
    # Original code:
    #
    # def load_list_of_tasks(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None):
    #     '''
    #     Given a list of task datastructures (parsed from YAML),
    #     return a list of Task() or TaskInclude() objects.
    #     '''
    #
    #     # we import here to prevent a circular dependency with imports
    #     from ansible.playbook.block import Block
    #     from ansible.playbook.handler import Handler
    #     from ansible.playbook

# Generated at 2022-06-25 05:17:40.807547
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True

# Generated at 2022-06-25 05:17:46.627889
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = str(0)
    play = str(2)
    block = str(3)
    role = str(4)
    task_include = str(5)
    use_handlers = bool()
    variable_manager = bool()
    loader = bool()

    ret = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    func_name = sys._getframe().f_code.co_name
    if (ret == None):
        return True, func_name
    else:
        return False, func_name


# Generated at 2022-06-25 05:17:57.557458
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Init test case
    str_0 = 'rb'
    str_1 = '8Bv['
    str_2 = 'd'
    str_3 = '&B'
    str_4 = '%B'
    str_5 = 'rb'
    str_6 = '8Bv['
    str_7 = 'd'
    str_8 = '&B'
    str_9 = '%B'
    str_10 = 'rb'
    str_11 = '8Bv['
    str_12 = 'd'
    str_13 = '&B'
    str_14 = '%B'
    str_15 = 'rb'
    str_16 = '8Bv['
    str_17 = 'd'
    str_18 = '&B'

# Generated at 2022-06-25 05:18:12.641290
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 12
    var_0 = load_list_of_tasks(int_0, int_0, int_0)
    print("%r" % var_0)

if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:18:15.827838
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_case_0()


if __name__ == "__main__":
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:18:18.118454
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 12
    var_0 = load_list_of_tasks(int_0, int_0, int_0)
    print(var_0)



# Generated at 2022-06-25 05:18:28.941304
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:18:30.831018
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test 1
    try:
        test_case_0()
    except Exception as e:
        return False
    return True



# Generated at 2022-06-25 05:18:35.587657
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    args = []
    if len(sys.argv) > 1:
        args.extend(sys.argv[1:])
    else:
        args.append('0')
    for arg in args:
        try:
            func = globals()["test_case_" + arg]
            func()
            print("TEST OK")
        except AssertionError as e:
            print("TEST ERROR")
            print(e)
            sys.exit(1)

# Generated at 2022-06-25 05:18:39.043901
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        # Call function
        test_case_0()

    # exceptions
    except Exception as exception_instance:
        print(exception_instance)


### Unit Test Runner ###
if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:18:39.900749
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert test_case_0() == None


# Generated at 2022-06-25 05:18:44.101869
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    result = load_list_of_tasks(None, None, None, None, None, None, None, None)
    assert result == []


# Generated at 2022-06-25 05:18:54.379985
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        load_list_of_tasks(12, 12, 12)
    except Exception as e:
        assert type(e) == AnsibleAssertionError

    #assert load_list_of_tasks('12', 12, 12) == AnsibleAssertionError

    #assert load_list_of_tasks(True, 12, 12) == AnsibleAssertionError

    #assert load_list_of_tasks(12.0, 12, 12) == AnsibleAssertionError

    #assert load_list_of_tasks(12, '12', 12) == AnsibleAssertionError

    #assert load_list_of_tasks(12, True, 12) == AnsibleAssertionError

    #assert load_list_of_tasks(12, 12.0, 12) == AnsibleAss

# Generated at 2022-06-25 05:19:44.423687
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("COMPLETE")
    int_0 = 12
    var_0 = load_list_of_tasks(int_0, int_0, int_0)
    print(type(var_0))

    var_1 = load_list_of_tasks([], int_0, int_0)
    print(type(var_1))

    var_2 = load_list_of_tasks([int_0], int_0, int_0)
    print(type(var_2))

    var_3 = load_list_of_tasks([{int_0: int_0}], int_0, int_0)
    print(type(var_3))

    var_4 = load_list_of_tasks([{'block': int_0}], int_0, int_0)
    print

# Generated at 2022-06-25 05:19:52.841338
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 12
    str_0 = "12"
    list_0 = ['A', 'B', 'C']
    tuple_0 = (1, 2, 3, 4, 5, 6, 7)
    dict_0 = {'A': 1, 'B': 2, 'C': 3}
    var_0 = load_list_of_tasks(int_0, int_0, int_0)
    var_1 = load_list_of_tasks(str_0, int_0, int_0)
    var_2 = load_list_of_tasks(list_0, int_0, int_0)
    var_3 = load_list_of_tasks(tuple_0, int_0, int_0)

# Generated at 2022-06-25 05:19:55.463605
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 12
    var_0 = load_list_of_tasks(int_0, int_0, int_0)

# Generated at 2022-06-25 05:20:01.375449
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """
    This test is added to demonstrate the issue described by
    http://stackoverflow.com/questions/39480127/

    Expected:
        ansibullbot.parsing.load_list_of_tasks raises an exception
        of type AnsibleAssertionError

    Actual:
        ansibullbot.parsing.load_list_of_tasks returns a value

    """

    # Test with a valid int
    int_0 = 12
    var_0 = load_list_of_tasks(int_0, int_0, int_0)

    # Test with an invalid int
    int_1 = -42
    var_1 = load_list_of_tasks(int_1, int_1, int_1)

# Generated at 2022-06-25 05:20:07.851117
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("[*] test_load_list_of_tasks: begin")

    int_0 = 12
    var_0 = load_list_of_tasks(int_0, int_0, int_0)
    print("[*] var_0: " + str(var_0))

    print("[*] test_load_list_of_tasks: end")


# Generated at 2022-06-25 05:20:18.150878
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 2
    int_1 = 6
    str_0 = 'Test'
    str_1 = 'Role'
    str_2 = 'Name'
    str_3 = 'Task'

    dict_0 = dict(
        name = str_0,
        action = str_1,
    )
    dict_1 = dict(
        name = str_2,
        action = str_3,
    )
    dict_2 = dict(
        name = str_0,
        action = str_3,
    )
    list_0 = []
    list_0.append(dict_0)
    list_0.append(dict_1)
    list_0.append(dict_2)

# Generated at 2022-06-25 05:20:21.088491
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    int_0 = 12
    int_1 = 10
    int_2 = 9
    int_3 = 7
    int_4 = 5
    int_5 = 3
    int_6 = 1

    test_case_0(int_0, int_1, int_2, int_3, int_4, int_5, int_6)


# Generated at 2022-06-25 05:20:22.785797
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # FIXME: How to define the test case?
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 05:20:31.853688
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 1
    int_1 = 2
    int_2 = 3
    int_3 = 4
    int_4 = 5
    # type = int, type = str, type = str, type = int, type = int
    var_0 = ([{'block': 'task_list'}, {'block': 'task_list'}, {'block': 'task_list', 'action': 'dummy_action'}], int_0, int_1, int_2, int_3)
    var_1 = ([{'block': 'task_list'}, {'block': 'task_list'}, {'block': 'task_list', 'action': 'dummy_action'}])

# Generated at 2022-06-25 05:20:37.936090
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    var_0 = 12
    var_1 = var_0
    var_2 = var_0
    var_3 = load_list_of_tasks(var_0, var_1, var_2)
    assert var_3 == 12


# Generated at 2022-06-25 05:21:24.363344
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # test_case_0
    int_0 = 12
    var_0 = load_list_of_tasks(int_0, int_0, int_0)
    # test_case_1
    dict_0 = {}
    dict_0['name'] = 'host2'
    dict_0['groups'] = 'all'
    list_0 = ['host2']
    dict_0['hosts'] = list_0
    dict_0['vars'] = {}
    var_1 = load_list_of_tasks(dict_0, int_0, int_0)
    # test_case_2
    dict_1 = {}
    list_1 = []
    dict_1['inventory'] = list_1
    list_2 = []
    dict_1['hosts'] = list_2
    list

# Generated at 2022-06-25 05:21:28.360668
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Calling function 'load_list_of_tasks' with arguments (12, 12, 12)
    int_0 = 12
    var_0 = load_list_of_tasks(int_0, int_0, int_0)
    # AssertionError raised
    assert var_0 == None


# Generated at 2022-06-25 05:21:31.481661
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True == False, "Unit test not implemented"

# Generated at 2022-06-25 05:21:33.469727
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        test_case_0()
    except Exception as e:
        print(str(e))
        print('An error occurred.')

# Generated at 2022-06-25 05:21:35.532030
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("Running test_load_list_of_tasks")
    test_case_0()

if __name__ == "__main__":
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:21:43.844802
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:21:49.366817
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test case 0:
    try:
        test_case_0()
    except AnsibleAssertionError as e:
        print('\n Exception raised: ' + str(e))
        assert True



# Generated at 2022-06-25 05:21:59.834467
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # Load a simple block definition
    int_0 = 12
    str_0 = 'str'
    var_0 = load_list_of_blocks(int_0, int_0, int_0)
    assert var_0 == (int_0, int_0, int_0)
    var_0 = load_list_of_blocks(str_0, int_0, int_0)
    assert var_0 == (str_0, int_0, int_0)
    var_0 = load_list_of_blocks(None, int_0, int_0)
    assert var_0 == (None, int_0, int_0)
    var_0 = load_list_of_blocks(int_0, str_0, int_0)

# Generated at 2022-06-25 05:22:01.361212
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_case_0()
if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-25 05:22:09.737072
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Initialization
    print('Unit test for function load_list_of_tasks')
    print('==============================================================')
    try:
        print('Beginning testing')
        test_case_0()
        print('Testing Done')
        print('All test cases passed')
        print('==============================================================')
    except Exception as e:
        print('Testing Failed')
        print('==============================================================')
        print(e)

if __name__ == "__main__":
    # test_load_list_of_tasks()
    print('No test case in this module')

# Generated at 2022-06-25 05:23:01.993961
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print ("Test: '%s'" % load_list_of_tasks.__name__)
    print ("Target: %s" % load_list_of_tasks.__doc__)

    test_case_0()

test_load_list_of_tasks()

# Generated at 2022-06-25 05:23:02.747486
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert True == True



# Generated at 2022-06-25 05:23:09.304566
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    with pytest.raises(AnsibleAssertionError) as exc_info:
        test_case_0()
    assert 'The ds' in str(exc_info.value)
#
# '''
# Validate the given dictionary contains only valid attributes for the Task() or Block() class.
# This is used to validate dictionaries read in from YAML files, before creating the objects.
# '''
#
#
# def validate_v1_task_data(data, dataclass=Block, variable_manager=None, loader=None, use_handlers=False):
#     '''
#     Given a task or block data structure, ensures it only contains supported keys.
#     '''
#     from ansible.playbook.task import Task
#     from ansible.playbook.block import Block
#
#     if

# Generated at 2022-06-25 05:23:11.626469
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Set up objects to test with
    int_0 = 12

    try:
        test_case_0()
    except Exception as e:
        print('Exception raised: {0}'.format(e.message))
        display.display('Caught exception in testcase 0')

# Load tests

# Generated at 2022-06-25 05:23:14.848391
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = None
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = None
    variable_manager = None
    loader = None

    task_list = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)


if __name__ == '__main__':

    test_case_0()

# Generated at 2022-06-25 05:23:22.402056
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Unit test setup
    int_0 = 12
    class test():
        def __init__(self):
            self.name = None
            self.tasks = None
            self.vars_files = None
            self.roles = None
            self.tags = None
            self.default_vars = None
            self.handlers = None
            self.block_list = None
            self.block = None

    test_0 = test()
    test_0.tags = None
    test_0.roles = None

    class test():
        def __init__(self):
            self.play = None
            self.block = None
    test_1 = test()
    test_1.play = test_0
    test_1.block = test_0
    test_1.block = test_0
    test

# Generated at 2022-06-25 05:23:28.069013
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible.playbook.play
    import ansible.playbook.task_include
    import ansible.playbook.task
    import ansible.playbook.role_include
    import ansible.playbook.handler
    import ansible.playbook.block
    import ansible.template
    int_0 = 12
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
   

# Generated at 2022-06-25 05:23:34.591223
# Unit test for function load_list_of_tasks

# Generated at 2022-06-25 05:23:37.849213
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    int_0 = 12
    var_0 = load_list_of_tasks(int_0, int_0, int_0)
    var_1 = load_list_of_tasks(int_0, int_0, int_0)

