

# Generated at 2022-06-21 00:32:31.595225
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
        {'shell': 'echo $ANSIBLE_CONFIG'}
    ]
    t = load_list_of_tasks(ds)
    assert(str(t[0]) == 'echo $ANSIBLE_CONFIG')

# Generated at 2022-06-21 00:32:40.030766
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    class FakeVariableManager:
        def __init__(self):
            self.vars = dict()
            self.extra_vars = dict()

        def set_fact(self, k, v):
            self.extra_vars[k] = v

        def get_vars(self):
            return dict()

        def get_extra_vars(self, *args, **kwargs):
            return self.extra_vars

        def merge_extra_vars(self, *args, **kwargs):
            pass

    class FakeLoader:
        class _dicts:
            class foo:
                class bar:
                    name = 'foo.bar'

        def get(self, *args, **kwargs):
            return FakeLoader._dicts


# Generated at 2022-06-21 00:32:54.848510
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import load_extra_vars
    from ansible.vars.manager import VariableManager
    loader = None
    play_context = PlayContext(role_name='test_role')
    variable_manager = VariableManager(loader=loader, play_context=play_context)
    variable_manager.extra_vars = load_extra_vars(loader=loader, play_context=play_context, options=play_context.options)
    variable_manager.options_vars = {}
    variable_manager.set_nonpersistent_facts(play_context)
    variable_manager.set_available_variables(loader=loader, play=play_context)
    # Use more than one tasks to

# Generated at 2022-06-21 00:33:08.696804
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role import Role
    from ansible.playbook.role_context import RoleContext
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    #    from ansible.plugins.loader import become_loader
    #    from units.plugins.loader import ActionModuleLoader
    from units.mock.plugins import ActionModuleLoader
    from units.mock.plugins import ModuleLoader

    #    become_loader.add_directory(os.path.join(os.

# Generated at 2022-06-21 00:33:14.075015
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    role_obj = Role()
    role_obj.play = Play()
    role_obj.play.variable_manager = VariableManager()
    role_obj.play.variable_manager._fact_cache = {}

    role_obj.load_role(loader=None, variable_manager=None, use_role_includevars=False,
                        parent_role=None, task_include=None,
                        role_params={}, from_cnf=None, static_play=False)

    fake_ds = [{'role': 'test'}, {'role': 'test2'}]
    assert load_list_of_roles(fake_ds, role_obj.play, variable_manager=role_obj.play.variable_manager, loader=None) == []



# Generated at 2022-06-21 00:33:27.870475
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    def run_test(test, name, ds):
        try:
            actual = load_list_of_tasks(ds)
        except Exception:
            test.fail('%s' % name)
        else:
            test.assertEquals(actual, None)

    # We need to add a fake ansible.module_utils._text.to_bytes(text) function
    # because load_list_of_tasks references it.
    def to_bytes(text):
        return text
    from ansible import module_utils
    import sys
    sys.modules['ansible.module_utils._text'] = module_utils

    to_bytes = sys.modules['ansible.module_utils._text'].to_bytes = to_bytes

    test = AnsibleFailTest()


# Generated at 2022-06-21 00:33:34.266495
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task_include import TaskInclude
    task_list = load_list_of_tasks([{}, {}])
    assert isinstance(task_list[0], TaskInclude)
    assert isinstance(task_list[1], TaskInclude)



# Generated at 2022-06-21 00:33:42.806995
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook import PlayBook
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_source = dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

# Generated at 2022-06-21 00:33:43.728502
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True

# Generated at 2022-06-21 00:33:53.235490
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    import copy
    from ansible.utils.vars import combine_vars

    parent_block = Block()

    host = Host('127.0.0.1')
    host.vars = {'foo': 'bar'}
    play = Play().load({}, variable_manager=VariableManager(), loader=None)

    # Test implicit blocks
    task_ds = dict(
        include='123',
        action='test',
    )
    task = Task.load(task_ds, play=play, variable_manager=VariableManager())
    assert task.include == '123'
    assert task.action == 'test'


# Generated at 2022-06-21 00:34:05.483318
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # FIXME: need to mock out the loader and specify it as a parameter
    # FIXME: mock out the varmgr
    pass

# Generated at 2022-06-21 00:34:07.281893
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds = [{}, {}, {}]
    load_list_of_blocks(ds, None)


# Generated at 2022-06-21 00:34:14.458811
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.inventory import Inventory
    from collections import namedtuple
    from ansible.vars.manager import VariableManager

    play_source =  dict(
            name = "Ansible Play for Configuration",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='setup', args='')),
                dict(action=dict(module='debug', args=dict(msg='{{ansible_facts.interface_lo.ipv4.address}}')))
            ]
        )
    fake_loader = FakeLoader({'./test.yaml': play_source})
    play = Play().load(dict(name='test', play=play_source), variable_manager=VariableManager(), loader=fake_loader)
   

# Generated at 2022-06-21 00:34:18.426625
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{u'action': {}, u'include': u'roles/apache', u'name': u'include apache'}, {u'include': u'roles/tomcat', u'name': u'include tomcat'}]
    assert load_list_of_tasks(ds) == ['roles/apache', 'roles/tomcat']


# Generated at 2022-06-21 00:34:19.461835
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass
# end of test_load_list_of_roles function



# Generated at 2022-06-21 00:34:32.685819
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook import compile
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import add_all_plugin_dirs
    import ansible.constants as C

    add_all_plugin_dirs()

    ds_list = [
        {
            u'name': u'test_role',
        },
    ]
    play_ds = dict(
        name="Ansible Play",
        hosts='all',
        gather_facts='no',
        roles=[
        ],
    )

    # create the object populated with data from the datastructure

# Generated at 2022-06-21 00:34:43.792762
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    Given a list of mixed task/block data (parsed from YAML),
    return a list of Block() objects, where implicit blocks
    are created for each bare Task.
    '''

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block

    if not isinstance(ds, (list, type(None))):
        raise AnsibleAssertionError('%s should be a list or None but is %s' % (ds, type(ds)))

    block_list = []
    if ds:
        count = iter(range(len(ds)))
        for i in count:
            block_ds = ds[i]
            # Implicit blocks are created by bare tasks listed in a play without
            # an explicit block statement. If we have two implicit blocks in a row,

# Generated at 2022-06-21 00:34:51.995029
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    hosts = [
        dict(name='host0'),
        dict(name='host1'),
    ]

    tasks = [
        dict(name='task0', action=dict(module='ping')),
        dict(name='task1', action=dict(module='ping')),
    ]
    # this is because the block loads the tasks, so we need to do a 2 step test
    # to ensure we arent doing double loads
    assert len(load_list_of_tasks(tasks, hosts)) == 2

    # also test with a loop
    host_loop = [
        dict(name='host0'),
        dict(name='host1'),
    ]
    tasks = [
        dict(name='task0', action=dict(module='ping'), with_items=host_loop, loop=True),
    ]
    assert len

# Generated at 2022-06-21 00:35:02.631311
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.block import Block
    import ansible.playbook.role.definition
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()

    ansible.playbook.role.definition.ROLE_CACHE[0] = dict(
        name="test",
        tasks=[1, 2],
        handlers=[3],
    )

    task_list = [1, 2]
    task_list[0] = Task()
    task_list[0].block = Block()
    task_list[0].block.parent_block = Block()
    task_list[0].block.rescue = Block()
    task_

# Generated at 2022-06-21 00:35:12.471197
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # Common test vars
    test_playbook_path = os.path.join(C.TEST_DIR, 'test_playbook.yml')
    test_playbook = os.path.abspath(test_playbook_path)
    test_directory = os.path.dirname(test_playbook)
    display.verbosity = 3
    block_list = []
    filename = test_playbook_path

    # This test includes a handler in the task list, which is not supported for block
    # loading but was previously not checked for. This is to ensure proper handling of
    # such a case, which currently raises an error.
    ds = dict(
        name="Test Handler",
        register="test_result",
        handler="test",
    )
    with open(filename, 'w') as f:
        f

# Generated at 2022-06-21 00:35:41.350029
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Loads and returns a list of RoleInclude objects from the ds list of role definitions
    :param ds: list of roles to load
    :param play: calling Play object
    :param current_role_path: path of the owning role, if any
    :param variable_manager: varmgr to use for templating
    :param loader: loader to use for DS parsing/services
    :param collection_search_list: list of collections to search for unqualified role names
    :return:
    '''
    # TODO need to create unit test for this function
    pass


# Generated at 2022-06-21 00:35:51.204465
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    # Test with a single block
    ds = [
        dict(
            block=dict(
                tasks=[
                    dict(action=dict(module='shell', args='echo "This is a test"'),
                         register='shell_out'),
                    dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
                ]
            )
        )
    ]

    block_list = load_list_of_blocks(ds, None, None, None, None, None, None, None)
    assert len(block_list) == 1



# Generated at 2022-06-21 00:35:52.809838
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # TODO
    pass



# Generated at 2022-06-21 00:36:00.318806
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    fake_loader = DictDataLoader({})
    fake_inventory = InventoryManager(loader=fake_loader, sources='')
    fake_variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)


# Generated at 2022-06-21 00:36:12.919136
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.errors
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    assert load_list_of_blocks(None, None) == []

    class MockLoader(DataLoader):
        def _get_file_contents(self, path):
            return ''
    class MockVariableManager(VariableManager):
        def __init__(self):
            self.v

# Generated at 2022-06-21 00:36:24.458160
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ds = [{"role": "unqualified"}, {"role": "qualified", "name": "unqualified"}, {"role": "qualified", "collection": "collectionname"}]

    play = Play()
    play.ROLE_CACHE = {'unqualified': {"task": [], "vars_files": [], "defaults": [], "meta": []},
                       'qualified': {"task": [], "vars_files": [], "defaults": [], "meta": []},
                       'collectionname.qualified': {'task': [], 'vars_files': [], 'defaults': [], 'meta': []}}
    current_role_path = 'my_role_path'
    vars = VariableManager()
    ldr = DataLoader()
    collection_search_list = ['my_collection', 'other_collection']
    expected

# Generated at 2022-06-21 00:36:35.453628
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # No value
    ds = None
    assert load_list_of_roles(ds=ds, play=None,
                              current_role_path=None, variable_manager=None,
                              loader=None, collection_search_list=None) == []

    # Empty array
    ds = []
    assert load_list_of_roles(ds=ds, play=None,
                              current_role_path=None, variable_manager=None,
                              loader=None, collection_search_list=None) == []

    # Invalid type
    ds = 42

# Generated at 2022-06-21 00:36:48.137975
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    ################################################
    # test good cases (no exception should be raised)
    ################################################

    # all three following cases should return the same result
    task1 = {'action': 'test', 'arg': 'test'}
    task2 = {'action': 'test', 'arg': 'test'}
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    # case 1
    ds = [task1, task2]
    tl = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)

# Generated at 2022-06-21 00:36:56.625297
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import load_list_of_blocks as load_blocks
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    # Test that a list containing a single block as a dict is correctly converted
    # to a Block object.
    ds = [{ 'block': [{'task': {'foo': 'bar'}}]}]
    block_list = load_blocks(ds, loader=loader)
    assert isinstance(block_list, list)
    assert len(block_list) == 1
    assert isinstance(block_list[0], Block)
    assert isinstance(block_list[0].block, list)

# Generated at 2022-06-21 00:37:02.652173
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible import constants as C
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # ds will be the data structure passed to load_list_of_roles
    # Setting up the data structure
    ds = []
    ds.append({"role": "foo", "tags": ["t1"], "when": "some_value"})
    ds.append({"role": "bar", "tags": ["t2"], "when": "some_value"})

    # Setting up the

# Generated at 2022-06-21 00:37:25.563535
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    class Task():
        def __init__(self, task_ds):
            self.task_ds = task_ds

    class Block():
        def __init__(self, block_ds):
            self.block_ds = block_ds

    class Role():
        def __init__(self, role_path):
            self.role_path = role_path

    class Playbook():
        pass

    class TaskInclude():
        def __init__(self, task_ds):
            self.task_ds = task_ds

    class VariableManager():
        pass

    class Loader():
        pass

    test_ds = [
        "foo",
        "bar",
        {"block": "baz"},
        {"include": "boo"},
        {"include_role": "far"}
    ]

    load_list_of

# Generated at 2022-06-21 00:37:34.349203
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible_collections
    import pytest
    from ansible.plugins.loader import collection_loader

    collection_search_list = (ansible_collections.networking.vyos.vyos,
                              ansible_collections.network.arista.eos,
                              ansible_collections.network.vyos.vyos)

    ds = [{'name': 'vyos-role-test-a'}, {'name': 'vyos-role-test-b'}]

# Generated at 2022-06-21 00:37:43.743349
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.constants as C
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import add_all_plugin_dirs

    # Add the tests/test_modules dir to the module loader path so we can load our
    # test modules (and not a random test modules from the system's installed set)
    add_all_plugin_dirs([os.path.join(os.path.dirname(__file__), '..', 'test_modules')])

    loader = DataLoader()

   

# Generated at 2022-06-21 00:37:52.710584
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.module_utils._text import to_text

    loader, inventory, variable_manager = _init_loader_inventory_variable_manager()
    variable_manager._fact_cache = {
        "localhost": {
            "local_fact": "this is a fact",
            "scoped_local_fact": "this is a scoped fact"
        }
    }

    all_vars = variable_manager.get_vars(play=Play().load({}, variable_manager=variable_manager, loader=loader))
    templar = Templar(loader=loader, variables=all_vars)

    playbook_path = '/tmp/test/test_file.yml'

# Generated at 2022-06-21 00:38:01.586792
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from collections import namedtuple
    FakeRole = namedtuple('FakeRole', ['get_role_path'])
    fake_role = FakeRole(get_role_path=lambda self: '/home/vagrant/ansible/roles/apache')


# Generated at 2022-06-21 00:38:03.341875
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ds = ['test_role']
    play = None
    current_role_path = None
    variable_manager = None
    loader = None

    load_list_of_roles(ds, play, current_role_path, variable_manager, loader)

# Generated at 2022-06-21 00:38:12.706245
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.parsing.yaml import objects
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.inventory.host import Host

    h = Host('testhost')
    h.set_variable('foo', objects.AnsibleUnicode('bar'))
    h.set_variable('wibble', objects.AnsibleUnicode('wobble'))
    h.set_variable('thing', objects.AnsibleUnicode('stuff'))

# Generated at 2022-06-21 00:38:22.632238
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    def test_load_list_of_tasks():
        # Tests
        assert load_list_of_tasks([]) == []                                   # 0, {}
        assert load_list_of_tasks([{'include': 'whatever'}]) == [{'include': 'whatever'}]       # 1, {'include': 'whatever'}
        assert load_list_of_tasks([{'include': 'whatever'}, {'include': 'something'}]) == [{'include': 'whatever'}, {'include': 'something'}]  # 2, {'include': 'something'}
        assert load_list_of_tasks([{'include': 'whatever'}, {'block': 'something'}]) == [{'include': 'whatever'}, {'block': 'something'}]  # 2, {'block': '

# Generated at 2022-06-21 00:38:33.178998
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    env = dict()
    module_plugins = AnsiblePlugin(AnsibleModule)
    env["module_plugins"] = module_plugins
    env["module_utils"] = AnsibleModuleUtils()
    env["action_plugins"] = AnsiblePlugin(ActionBase)
    env["_module_plugins"] = copy.deepcopy(env["module_plugins"])
    env["_action_plugins"] = copy.deepcopy(env["action_plugins"])
    env["connection_plugins"] = AnsiblePlugin(ConnectionBase)
    env["_connection_plugins"] = copy.deepcopy(env["connection_plugins"])
    env["shell_plugins"] = AnsiblePlugin(ShellModule)
    env["_shell_plugins"] = copy.deepcopy(env["shell_plugins"])
    env["cache"] = DataCache()


# Generated at 2022-06-21 00:38:39.414265
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play()
    b = load_list_of_roles(
        ds=[
            {
                'name': 'role1',
                'vars': {
                    'role_var': 'value'
                },
                'role_path': 'roles/role1/',
                'tags': ['a'],
            },
            {
                'name': 'role2',
                'role_path': 'roles/role2/',
                'tags': ['b'],
            },
        ],
        play=play,
        current_role_path='/etc/ansible/roles/role3',
        variable_manager=variable_manager,
        loader=loader,
    )
    assert b[0].name == 'role1'


# Generated at 2022-06-21 00:39:14.333898
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor import playbook_executor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    class ResultCallback(CallbackBase):
        def v2_runner_on_ok(self, result, **kwargs):
            host = result

# Generated at 2022-06-21 00:39:24.449006
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role import Role
    from ansible.playbook.role.metadata import RoleMetadata

    def create_role(r, p=None, c=None):
        return Role.load(r, p, c)


# Generated at 2022-06-21 00:39:33.287618
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.timevar import TimeVar

    play_context = PlayContext()
    play_context.SETUP_CACHE = dict()

    play = dict(
        name='test',
        max_fail_percentage=0,
        vars=dict(),
        vars_prompt=dict(),
        vars_files=list(),
        roles=dict(),
        tasks=list(),
        handlers=list(),
    )


# Generated at 2022-06-21 00:39:42.797342
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    play = {
        'hosts': 'all',
        'gather_facts': 'no'
    }


# Generated at 2022-06-21 00:39:49.683696
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import sys, os
    # Fake a playbook
    playbook_file = '/tmp/fake_playbook'
    task_name = 'fake_task_name'
    # we import here to prevent a circular dependency with imports
    # Fake a play
    # Fake a role
    # Fake a task_include
    # Fake a vars_file
    # Fake a vars_file
    # Fake a vars_file
    # Fake a vars_file
    # Fake a vars_file
    # Fake a vars_file
    # Fake a vars_file
    # Fake a vars_file
    # Fake a vars_file
    # Fake a vars_file
    # Fake a vars_file
    # Fake a vars_file
    # Fake a vars_file
    # Fake a vars_file
   

# Generated at 2022-06-21 00:39:51.011227
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
   ds = load_list_of_roles('roles')
   assert(ds != None)
   return


# Generated at 2022-06-21 00:40:00.397586
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.definition import RoleDefinition

    class MockPlay(object):
        pass

    class MockVarMgr(object):
        def get_vars(self, play=None, task=None):
            return {}

    class MockLoader(object):
        def path_dwim_relative(self, base, subdir, filename):
            return filename

        def path_dwim(self, filename):
            return filename

    play = MockPlay()
    vars = MockVarMgr()
    loader = MockLoader()

    role_ds = {"name": "web"}

    role_list = load_list_of_roles(ds=[role_ds], play=play, variable_manager=vars, loader=loader)

    assert len(role_list) == 1

# Generated at 2022-06-21 00:40:09.553912
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{'block': [{'task': {'nop': 'nop'}}]}, {'include_tasks': 'nop'}]
    # ds = [{'block': [{'task': {'nop': 'nop'}}]}]
    play = {'gather_facts': 'smart'}
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    task_list = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    for task in task_list:
        print(task)

# Generated at 2022-06-21 00:40:20.401949
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task

    ds = [
      {'block': None, 'name': u'ping', 'action': {'__ansible_module__': u'ping'}},
      {'include': 'file.yml'},
      {'include_role': 'foobar'}
    ]

    # We just want to check load_list_of_tasks is working,
    # not calling load_list_of_blocks() or any other functions
    # Therefore, we mock them so they dont call anything that
    # is not mocked as well, leading to unexpected unit tests failures

# Generated at 2022-06-21 00:40:29.622821
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # FIXME: We need to fake a loader and vars_manager here
    ds = [
        dict(role=dict(name='example')),
        dict(role=dict(name='example', tasks_from='other')),
        dict(role=dict(name='example', loop='{{ example_var }}')),
        dict(role=dict(name='example', loop_control=dict(loop_var='example_var'))),
    ]
    for item in ds:
        result = load_list_of_roles(ds=item, play=[], collection_search_list=None)
        assert isinstance(result[0], RoleInclude)



# Generated at 2022-06-21 00:40:55.682149
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds = []
    pass



# Generated at 2022-06-21 00:41:07.968360
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task.include import TaskInclude
    from ansible.parsing.dataloader import DataLoader

    def _test_block(block, expected):
        if not block.block:
            assert not expected['block']
        else:
            assert block.block == expected['block']
        assert len(block.block, ) == len(expected['tasks'])
        assert block.block == expected['tasks']
        assert block.role == expected['role']
        assert block.task_include == expected['task_include']
        assert block.strategy == expected['strategy']
        assert block.rescue == expected['rescue']
        assert not block.always


# Generated at 2022-06-21 00:41:13.837589
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task.include import Include
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    play = Play()

    yaml_data = """
    - hosts: localhost
      vars:
        foo: bar
      tasks:
        - name: test task 1
          shell: echo "{{ foo }}"
        - name: test task 2
          shell: echo "{{ foo }}"
        - name: test task 3
          shell: echo "{{ foo }}"
    """

    ds = loader.load_from_data(yaml_data)
    result = load_list_of

# Generated at 2022-06-21 00:41:21.096119
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # this test is trivial as the function is not currently designed to be unit tested
    ds = [{"name": "role1"}, {"name": "role2"}]
    result = load_list_of_roles(ds, None)
    assert result is not None
    assert len(result) == 2

# Generated at 2022-06-21 00:41:33.709611
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Creating Dummy play, variable_manager and loader
    play = DummyPlay()
    variable_manager = DummyVariableManager()
    loader = DummyLoader()

    # Creating Dummy role and appending it to list of roles in the play object
    role = DummyRole()
    role.get_name.return_value = "Foo"
    play.get_roles.return_value = [role]
    # Creating dummy role definition
    role_ds = dict(role="Foo")
    assert (load_list_of_roles([role_ds], play, variable_manager=variable_manager, loader=loader))

    # Creating Dummy collection
    collection = DummyCollection()
    collection.get_name.return_value = "FooCollection"
    # Creating dummy role definition

# Generated at 2022-06-21 00:41:45.161107
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    test load_list_of_roles function
    '''
    ds = [1, 2, 3]
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.role.include import RoleInclude
    loader = Mock()
    loader.module_loader = Mock()
    loader.module_loader.get = lambda *a, **kw: Mock()
    loader.get_basedir = lambda: 'basedir'
    play = Mock()
    play.vars = dict()
    play.vars['bar'] = 'foo'
    variable_manager = Mock()
    variable_manager.get_vars = lambda *a, **kw: dict()
    current_role_path = 'current_role_path'
    collection_list = []

# Generated at 2022-06-21 00:41:49.639923
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert load_list_of_roles(ds=['test'], play=None, current_role_path=None, variable_manager=None, loader=None) == 'test'

# Generated at 2022-06-21 00:41:56.818795
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_play_ds = [
        {"name": "Test play", "hosts": "all", "gather_facts": "no", "tasks": [
            {"name": "Test task", "action": {
                "module": "test_module",
                "args": "test arg"
            }},
            {"name": "Test task include", "action": {
                "module": "include",
                "args": "test_task_include.yml"
            }},
        ]}
    ]
    test_task_include_ds = [
        {"name": "Test task in task include", "action": {
            "module": "test_module",
            "args": "test arg"
        }}
    ]

# Generated at 2022-06-21 00:42:05.771358
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as OrigPlay


# Generated at 2022-06-21 00:42:15.620269
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Test load_list_of_roles()

    Test with roles not in a list
    Test with a single role
    Test with multiple roles
    Test with roles that include unqualified role names
    '''

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import loader
    import ansible.inventory
    import ansible.vars.manager
    import ansible.constants as C

    collection_search_list = [os.path.join(test_data_path, 'collections')]

    # Set some initial variables and options
    loader.add_directory(C.DEFAULT_MODULE_PATH)

    inventory = ansible.inventory.Inventory(loader=loader, variable_manager=ansible.vars.manager.VariableManager(), host_list=[])
    variable_manager = ans