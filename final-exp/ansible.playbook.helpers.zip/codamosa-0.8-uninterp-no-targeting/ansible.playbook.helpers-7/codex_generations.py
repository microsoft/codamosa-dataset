

# Generated at 2022-06-21 00:32:56.701663
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block

    task = {'block': [{'block': [{'include_role': {'name': 'test', 'static': True}}, {'include_tasks': {'name': 'test', 'static': True}}]}]}
    task_list = load_list_of_tasks(task, None, None, None, None, False, None, None)
    assert task_list[0].__class__ == Block
    assert task_list[0].block[0].__class__ ==  TaskInclude
    assert task_list[0].block[1].__class__ ==  TaskInclude


# Generated at 2022-06-21 00:32:57.329418
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass



# Generated at 2022-06-21 00:33:10.322189
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.vault import VaultLib
    from ansible.plugins.loader import load_plugin
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    def _create_fake_loader(paths):
        class FakeLoader(DataLoader):
            def is_file(self, path):
                return path in paths

        return FakeLoader()


# Generated at 2022-06-21 00:33:14.287495
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    def check(input, output):
        import copy
        import sys
        if sys.version_info >= (3, 0):
            import io
            output = io.StringIO(str(output))
        else:
            import StringIO
            output = StringIO.StringIO(str(output))
        # Create a loader
        loader = DictDataLoader({})
        # Create a variable manager that uses the loader
        variable_manager = VariableManager(loader=loader)
        # Create a PlayContext
        play_context = PlayContext()
        # Create a Play
        play = Play().load(input, variable_manager=variable_manager, loader=loader)
        # Create a TaskInclude
        task_include = TaskInclude(play=play)
        # Load the play

# Generated at 2022-06-21 00:33:28.039481
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayObject
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager(None, None, None, None, None, None)
    play = Play.load(dict(
        hosts='localhost',
        roles=None,
        tasks=['task1', 'task2']
    ), tqm)
    play = PlayObject.load(
        play,
        variable_manager=tqm.variable_manager,
        loader=tqm.loader
    )
    load_list_of_blocks(play.tasks, play)

# Generated at 2022-06-21 00:33:37.708591
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    [{'role': {'name': 'ansible-role-foo'}}]
    '''
    ds = [{'role': {'name': 'ansible-role-foo'}}]
    assert load_list_of_roles(ds, None)
    assert load_list_of_roles(ds, None)[0]._role_name == 'ansible-role-foo'
    assert load_list_of_roles(ds, None)[0].name == 'ansible-role-foo'

    '''
    # Old
    [{'name': 'ansible-role-foo'}]
    '''
    ds = [{'name': 'ansible-role-foo'}]
    assert load_list_of_roles(ds, None)
    assert load_list_

# Generated at 2022-06-21 00:33:46.291451
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook import Play
    from ansible.playbook.block import Block

    p = Play().load({
        'name': 'Test Play',
        'hosts': 'localhost',
        'gather_facts': 'no',
        'tasks': [
            {'action': 'setup'},
            {
                'block': [
                    {'action': 'debug', 'msg': 'hello'},
                    {'name': 'fail', 'action': 'fail', 'msg': 'hello'},
                ]
            },
            {'action': 'debug', 'msg': 'goodbye'},
        ],
        'post_tasks': [
            {'action': 'debug', 'msg': 'here'},
        ]
    })

    assert len(p.block_list) == 3
    assert p.block_

# Generated at 2022-06-21 00:33:52.898075
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Test loading a role include with no role name specified
    role_def = {
        'name': 'a_role'
    }
    with pytest.raises(AnsibleParserError):
        load_list_of_roles([role_def], play=None)
    # Test loading a role include with a loop specified
    role_def = {
        'name': 'a_role',
        'role': 'another_role',
        'loop': 'loop_var'
    }
    with pytest.raises(AnsibleParserError):
        load_list_of_roles([role_def], play=None)


# Generated at 2022-06-21 00:34:03.294075
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO, BytesIO

    display.verbosity = 3
    yaml_text = u'''
    tasks:
    - action: local_action
      module: test
      host: 127.0.0.1
      args:
        test: this is a test
    '''



# Generated at 2022-06-21 00:34:13.168640
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    play = Play()
    play._variable_manager = VariableManager()
    play_context = PlayContext()
    play_context.CLIARGS = {}
    play._variable_manager.extra_vars = play_context.CLIARGS

    example_list = [{'hosts': 'da', 'tasks': [{'name': 'ls', 'action': 'shell', 'args': {'chdir': '/home'}}]}]
    # Example_list of list

    # the type of return value must be list
    assert isinstance(load_list_of_blocks(example_list, play), list)

    # the element of return value must be object of class Block

# Generated at 2022-06-21 00:34:35.298860
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    if __name__ == '__main__':
        '''
        unit testing for function load_list_of_blocks
        '''
        from ansible.playbook.playbook import Playbook
        from ansible.executor.task_queue_manager import TaskQueueManager
        from ansible.plugins.loader import add_all_plugin_dirs
        from ansible.vars.manager import VariableManager
        from ansible.inventory.manager import InventoryManager
        import ansible.constants as C

        class Options(object):
            '''
            Options class for use with testcase
            '''

# Generated at 2022-06-21 00:34:42.078751
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Test load_list_of_roles function.
    '''
    display.display = lambda x, y: x
    role1 = {
        'role': 'geerlingguy.docker',
        'version': '1.4.1',
    }
    role2 = {
        'role': 'geerlingguy.docker',
        'version': '1.3.0',
    }
    ds = [role1, role2]
    my_play = Play().load({'name': 'test play', 'hosts': 'localhost'}, variable_manager=VariableManager(), loader=DictDataLoader())
    my_roles = load_list_of_roles(ds, play=my_play)
    assert len(my_roles) == 2
    assert my_roles[0].get_

# Generated at 2022-06-21 00:34:54.856859
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    ds = [
        {'block': [
            'hosts: host1',
            {'task': {'with': 'items'}},
        ]},
        {'task': 'task1'},
        {'task': 'task2'},
        {'block': [
            'rescue:',
            'hosts: host1',
            {'task': {'with': 'items'}},
        ]},
        {'block': [
            'always:',
            'hosts: host1',
            {'task': {'with': 'items'}},
        ]},
    ]

    assert isinstance

# Generated at 2022-06-21 00:34:57.188687
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # We need to have access to the play object, so we need to mock it
    # First we define the class
    play = type("Play", (object,), dict())

    # We then create our ds item
    ds = list()
    ds.append("test1")
    ds.append("test2")
    ds.append("test3")

    # We then extract our block list
    block_list = load_list_of_blocks(ds=ds, play=play)
    assert len(block_list) == 3


# Generated at 2022-06-21 00:35:07.954807
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    This function tests load_list_of_roles function by providing valid and invalid inputs.
    AssertionErrors are expected.
    :return:
    '''
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    # Create a valid ds
    ds = [{'name': 'role_name'}]
    play_context = PlayContext()

# Generated at 2022-06-21 00:35:15.132278
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    # print "Testing task and block loading..."

# Generated at 2022-06-21 00:35:26.151627
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.role.include import RoleInclude
    import ansible.playbook.play

    # create a list of role definitions
    role_defs = []
    role_defs.append({
        'role': 'default_role',
        'name': 'default_role_name',
        'scenario': 'default_scenario',
        'loop': ['1', '2']})
    role_defs.append({
        'role': 'single_loop',
        'loop': ['3', '4']})
    role_defs.append({
        'role': 'outer_loop',
        'loop': ['5', '6']})

# Generated at 2022-06-21 00:35:34.787752
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds = [
            {
                'block': [
                    {
                        'block': 'a',
                        'name': 'hello'
                    },
                    'world',
                    [
                        'a',
                        'b'
                    ]
                ]
            },
            {
                'block': 'b',
                'name': 'hello'
            },
            'world',
            [
                'a',
                'b'
            ],
            None,
            {
                'block': 'b',
                'name': 'hello'
            },
        ]
    block_list = load_list_of_blocks(ds)
    assert len(block_list) == 6

# Generated at 2022-06-21 00:35:41.221879
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    Unit test for function load_list_of_blocks
    '''

    def load_test_run(test_name, play_ds, task_ds, expected_blocks_num, expected_tasks_num):
        '''
        Function that runs the tests
        '''

        from ansible.playbook.play import Play
        from ansible.playbook.task import TaskInclude

        play = Play.load(
            data=play_ds,
            variable_manager=None,
            loader=None,
        )
        block_list = load_list_of_blocks(task_ds, play, task_include=TaskInclude(), variable_manager=None)
        assert len(block_list) == expected_blocks_num, 'Incorrect number of blocks: %d' % len(block_list)

# Generated at 2022-06-21 00:35:53.704457
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole

# Generated at 2022-06-21 00:36:24.982569
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    play = dict(name='', hosts='', gather_facts='no', roles=[], remote_user='', become='', become_user='', become_method='')
    ds = [{'name': 'Task name', 'connection': 'smart', 'action': 'test'}]
    load_list_of_roles(ds, play, current_role_path='', variable_manager='', loader='', collection_search_list='')
    # Expected result: ansible.utils.display.Display.deprecated(msg, version='2.16')
    result = load_list_of_roles(ds, play, current_role_path='', variable_manager='', loader='', collection_search_list='')
    assert result is not None

# Generated at 2022-06-21 00:36:27.876835
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_list = load_list_of_tasks()
    assert task_list is not None

# Generated at 2022-06-21 00:36:36.477716
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    display.display('Hello world')
    display.display('Hello world')
    display.display('Hello world')
    display.display('Hello world')
    display.display('Hello world')
    display.display('Hello world')
    display.display('Hello world')
    display.display('Hello world')
    display.display('Hello world')
    display.display('Hello world')
    display.display('Hello world')
    display.display('Hello world')
    display.display('Hello world')
    display.display('Hello world')
    display.display('Hello world')
    display.display('Hello world')
    display.display('Hello world')
    display.display('Hello world')
    display.display('Hello world')
    display.display('Hello world')



# Generated at 2022-06-21 00:36:37.893208
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True
    return True

# Generated at 2022-06-21 00:36:45.453431
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.cli.playbook.play_context import PlayContext
    import ansible.constants as C

    add_all_plugin_dirs()
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    play_context = PlayContext()
    inventory = InventoryManager(loader, None, sources="localhost")
    vars_manager = VariableManager(loader=loader, inventory=inventory)
    play = Play().load("testdata/playbooks/debug_playbook.yml", variable_manager=vars_manager, loader=loader, inventory=inventory)

    assert len(play._entries) == 4

    first_role = play._entries[0]
    assert isinstance(first_role, RoleInclude)

# Generated at 2022-06-21 00:36:52.557240
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.collection import CollectionLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import wrap_var
    import sys
    import ansible.constants as C
    import json

    # This makes sure that we don't load any plugins which could be in the custom
    # roles/plugins directory used by the unit test
    C.DEFAULT_CUST

# Generated at 2022-06-21 00:37:04.637669
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    block_list = load_list_of_blocks(False, False, False, False, False, False, False, False)
    assert block_list is False

    ds = [{'block': 'name'}, {'task': 'name'}]
    block_list = load_list_of_blocks(ds, False, False, False, False, False, False, False)
    assert len(block_list) == 2
    assert isinstance(block_list[0], Block)
    assert isinstance(block_list[1], Block)

    ds = [{'task': 'name'}, {'task': 'name'}]

# Generated at 2022-06-21 00:37:12.757443
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': '1'}
    variable_manager.set_inventory(loader.load_from_file("/etc/ansible/inventory"))
    play = Play.load(dict(name="Ansible Play", hosts="all", roles=['foobar']), variable_manager=variable_manager, loader=loader)
    roles = load_list_of_roles(play.roles, play=play, variable_manager=variable_manager, loader=loader)
    assert len

# Generated at 2022-06-21 00:37:14.309905
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO
    pass

# Generated at 2022-06-21 00:37:25.336647
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
	from ansible.playbook.play_context import PlayContext
	from ansible.executor.playbook_executor import PlaybookExecutor
	from ansible.playbook import Playbook
	from ansible.parsing.dataloader import DataLoader
	from ansible.vars.manager import VariableManager
	from ansible.executor.task_queue_manager import TaskQueueManager
	
	playbook_path = 'playbook_location.yaml'

	loader = DataLoader()
	inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='/etc/ansible/hosts')
	variable_manager = VariableManager(loader=loader, inventory=inventory)

	passwords = {}

# Generated at 2022-06-21 00:38:17.788870
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    try:
        load_list_of_blocks()
        assert False, "Function load_list_of_blocks didn't take any arguments. It shouldn't be empty."
    except TypeError:
        assert True
    from ansible.playbook.play_context import PlayContext
    context = PlayContext()
    context._included_paths = []
    # Create an instance of class Play()
    from ansible.playbook.play import Play

# Generated at 2022-06-21 00:38:24.577912
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.playbook.block as block

    ds = [['tasks', [{'action': {'module': 'shell', 'args': 'ls'}, 'name': 'test'}]]]

    result = load_list_of_blocks(ds)

    assert isinstance(result[0], block.Block)



# Generated at 2022-06-21 00:38:34.151386
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import ansible.playbook.role.include
    import ansible.playbook.role.definition

    class Play(object):
        def __init__(self):
            self.ROLE_CACHE = {}

    class RoleInclude(object):
        def __init__(self):
            pass

    play = Play()
    role = RoleInclude()

    ansible.playbook.role.include.Play = Play
    ansible.playbook.role.include.RoleInclude = RoleInclude
    ansible.playbook.role.definition.RoleDefinition = RoleInclude
    ansible.playbook.role.include.get_collections_from_paths = lambda paths: None
    def get_role_definition(self, name, play, current_role_path=None, collection_list=None):
        pass
    ans

# Generated at 2022-06-21 00:38:38.642857
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    results, playbook = load_list_of_roles_data()
    assert playbook.keys() == results.keys()
    for item in results.keys():
        assert playbook[item] == results[item]


# Generated at 2022-06-21 00:38:50.565809
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    This function will be executed when this module is invoked directly
    """
    path = os.path.dirname(__file__)  # This is your Project Root
    # print("path : " + path)
    test_roles = [
        {
            'name': 'apache',
            'version': '1.0.0',
            'src': 'https://somewhere.com/roles/apache.git'
        }
    ]
    test_roles = load_list_of_roles(test_roles, '/path/to/test_roles')
    assert isinstance(test_roles, list)
    assert isinstance(test_roles[0], RoleInclude), "test_roles[0] should be a RoleInclude."
    assert test_roles[0].get_name()

# Generated at 2022-06-21 00:38:57.703437
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    with open('/home/capp/projects/ansible/lib/ansible/playbook/data/test_load_list_of_blocks.json', 'r') as f:
        test_data = json.load(f)
    role = RoleInclude.load(test_data[0])
    assert role.get_blocks()



# Generated at 2022-06-21 00:39:04.568595
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleUndefinedVariable, AnsibleParserError
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.utils.display import Display

    class Options(object):
        pass

    class PlayContext(object):
        pass

    #

# Generated at 2022-06-21 00:39:14.568436
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Test the load_list_of_roles method
    '''
    # pylint: disable=too-many-locals,too-many-statements
    from ansible.playbook.play import Play
    from ansible.errors import AnsibleParserError
    from ansible.module_utils.six import string_types

    myplay = Play().load({
        'name' : 'testloadlistofroles',
        'tasks' : []
    }, variable_manager=None, loader=None)

    # Loop through the expected role definitions and make sure it loads
    # correctly

# Generated at 2022-06-21 00:39:24.528221
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # Create a block
    block_ds = dict(
        block=dict(
            tasks=[
                dict(
                    action=dict(
                        module='shell',
                        args="echo 1 >> /tmp/hello.txt",
                    )
                ),
                dict(
                    action=dict(
                        module='shell',
                        args="echo 2 >> /tmp/hello.txt",
                    )
                ),

            ]
        )
    )
    new_block = Block.load(
        block_ds,
        play=None,
        parent_block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=None,
        loader=None,
    )


# Generated at 2022-06-21 00:39:33.296068
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    def _make_playbook(playbook):
        return {
            'name': 'test',
            'playbooks': [playbook],
        }

    # Test implicit blocks

# Generated at 2022-06-21 00:41:30.751905
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass



# Generated at 2022-06-21 00:41:38.650656
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host, Group
    from ansible.inventory.ini import InventoryParser
    from ansible.parsing.splitter import parse_kv

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/ansible/inventory/test_inventory.ini'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-21 00:41:46.118155
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.utils.display import Display

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play.load(
        dict(
            name="test play",
            hosts=["testhost"],
            gather_facts="no",
            roles=["role1", "role2"],
        ),
        loader=loader,
        variable_manager=variable_manager,
        display=display,
    )

    assert len(load_list_of_roles(play.roles, play, current_role_path=None, variable_manager=variable_manager, loader=loader)) == 2
    assert len(play.roles) == 2
    # unit test that the function doesn

# Generated at 2022-06-21 00:41:55.622340
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils import context_objects as co
    mock_play = Play().load({}, variable_manager=co.VariableManager(), loader=co.DataLoader())
    mock_role_path = '/foo/bar/baz'
    mock_role_defs = [
        RoleDefinition().load({'name': 'mock_role_0'}, play=mock_play),
        RoleDefinition().load({'name': 'mock_role_1'}, play=mock_play),
    ]
    mock_role_defs[0]._role_name = 'mock_role_0'
    mock_role_defs[1]._role_name = 'mock_role_1'

# Generated at 2022-06-21 00:41:56.935400
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass

# Generated at 2022-06-21 00:42:03.263738
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Unit test for function load_list_of_roles
    """
    # empty list of roles
    ds = []
    ret = load_list_of_roles(ds)
    assert ret == []

    # list of roles
    ds = [{'role': 'test_role'}]
    ret = load_list_of_roles(ds)
    assert ret[0].name == 'test_role'



# Generated at 2022-06-21 00:42:06.093717
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    result = load_list_of_tasks()
    assert is_list(result)
    assert result == []


# Generated at 2022-06-21 00:42:10.128396
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    test_play = open("/etc/hostname.json")
    ds = test_play.read()
    print(load_list_of_blocks(ds))


# Generated at 2022-06-21 00:42:11.546277
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert False, "No test defined"

# Generated at 2022-06-21 00:42:23.409601
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play = 'test_play'
    block = 'test_block'
    role = 'test_role'
    task_include = 'test_task_include'
    use_handlers = True
    variable_manager = VariableManager()
    loader = None
