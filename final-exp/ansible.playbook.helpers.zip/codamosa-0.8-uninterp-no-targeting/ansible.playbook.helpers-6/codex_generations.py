

# Generated at 2022-06-21 00:32:48.980358
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.errors import AnsibleAssertionError
    try:
        load_list_of_roles(None, None, None)
    except AnsibleAssertionError:
        pass
    load_list_of_roles([1, 2, 3], None, None)


# Generated at 2022-06-21 00:32:59.393222
# Unit test for function load_list_of_tasks

# Generated at 2022-06-21 00:33:11.385015
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    class Options(object):
        connection = 'ssh'
        module_path = '/usr/share/ansible'
        forks = 5
        become = None
        become_method = None
        become_user = None
        check = False
        diff = False
        listhosts = None
        listtasks = None
        listtags = None
        syntax = None
        timeout = 10
        private_key_file = None
        host_key_checking = True

# Generated at 2022-06-21 00:33:12.581371
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # TODO
    pass



# Generated at 2022-06-21 00:33:13.779528
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert False, "No test for function load_list_of_tasks"

# Generated at 2022-06-21 00:33:27.369332
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import itertools

    from ansible.playbook.block import Block

    # given
    pb = Playbook()
    ds = [
        dict(
            name='test',
            tasks=[dict(name='test_task')],
        ),
        dict(
            name='test2',
            tasks=[dict(name='test_task2')],
        ),
    ]

    # when
    result, error = load_list_of_blocks(ds, pb)

    # then
    assert not error
    assert isinstance(result, list)
    for count, block_ds in itertools.count(0):
        assert isinstance(result[count], Block)
        assert result[count].block  # non implicit block

        if count == len(ds) - 1:
            break


# Generated at 2022-06-21 00:33:40.217447
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 00:33:52.082866
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # We need to mock the playbook object so we don't try to parse the entire YAML file
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    # Set up the play
    play = Play().load({'name': 'test play'}, variable_manager={}, loader=None)

    # Set up the tasks
    tasks = [
        {'name': 'test task'},
        {'block': [
            {'name': 'test task 2'},
        ]}
    ]

    # We only use the tasks list for comparison, so we don't need to check everything
    task1 = Task()
    task1.action = {'__ansible_module__': 'test'}
    task1.name = 'test task'
    task2 = Task()

# Generated at 2022-06-21 00:33:58.801373
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play

    play_ds = {
        'name': 'test play',
        'hosts': 'localhost',
        'tasks': [],
        'roles': [
            {'name': 'role_1'},
            {'name': 'role_2'},
            {'name': 'role_3'}
        ]
    }
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    play = Play.load(play_ds, variable_manager=variable_manager, loader=loader)
    assert load_list_of_roles(play_ds['roles'], play, variable_manager=variable_manager, loader=loader)



# Generated at 2022-06-21 00:34:11.855713
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='')
    play_context = PlayContext()
    play_context.network_os = 'junos'
    play_context.remote_addr = '10.10.10.10'

# Generated at 2022-06-21 00:34:35.314190
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    returns a list of block objects
    '''
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    p = Play()
    p._variable_manager = None
    p._loader = None
    p.hosts = []

    list_of_tasks = [{'name': 'first_task'},{'name': 'second_task'},{'name': 'third_task'}]
    block_list = load_list_of_blocks(list_of_tasks, p, None, variable_manager=p._variable_manager, loader=p._loader)
    assert isinstance(block_list, list)

    for b in block_list:
        assert isinstance(b, Task)




# Generated at 2022-06-21 00:34:36.691248
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert 0 == 0


# Generated at 2022-06-21 00:34:43.023988
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible.playbook.task as task
    import ansible.playbook.task_include as task_include
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.playbook.play import Play
    import ansible.playbook.block as block
    import ansible.vars.hostvars
    from ansible.inventory.host import Host
    import ansible.inventory.manager
    from ansible.vars.hostvars import HostVars
    import ansible.vars.unsafe_proxy
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.role_include import IncludeRole
    import ansible.playbook.handler_task_include as handler_task_include

    class Object(object):
        pass

    # Create data

# Generated at 2022-06-21 00:34:55.412257
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    test_file = os.path.join(os.path.dirname(__file__), 'test_load_list_of_roles.yml')
    hosts = dict()
    with open(test_file) as f:
        raw_data = f.read()
        file_data = yaml.load(raw_data, Loader=AnsibleLoader)
        file_data = file_data[0]  # We only want the first item from the list
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    var = Variable(loader=loader, templar=None, vault_secrets=None, source=('vars', 'vars'))
    var.parse({'roles': {'app': 'appserver'} })
    variable_manager.append_global_vars([var])

# Generated at 2022-06-21 00:35:03.469650
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.errors import AnsibleError

    ds = '[{"role": "foo", "some_var": "some_value"}]'
    x = load_list_of_roles(yaml.safe_load(ds), None)
    assert isinstance(x[0], RoleInclude)
    assert x[0].name == 'foo'
    assert x[0].role_vars == {'some_var': 'some_value'}
    assert x[0]._role_name == 'foo'

    ds = '[{"role": "foo", "some_var": "some_value", "some_list": [1, 2, 3]}]'
    x = load_list_of_roles(yaml.safe_load(ds), None)
    assert isinstance(x[0], RoleInclude)
    assert x

# Generated at 2022-06-21 00:35:12.849219
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    test_playbook = 'playbook.yml'
    test_playbook_dir = 'playbookdir'
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    playbooks = []


# Generated at 2022-06-21 00:35:16.778017
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    load_list_of_blocks return a list of Block() objects, where implicit blocks
    are created for each bare Task.
    '''


# Generated at 2022-06-21 00:35:19.029703
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    _result = load_list_of_blocks()
    assert _result == None


# Generated at 2022-06-21 00:35:28.297502
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block

    blocks = [
        {
            'block': [
                {'task': {'name': "test1"}},
                {'task': {'name': "test2"}},
                {'task': {'name': "test3"}},
            ]
        },
        {'task': {'name': "test4"}},
        {'task': {'name': "test5"}},
    ]
    block_list = load_list_of_blocks(blocks, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert len(block_list) == 2
    assert isinstance(block_list[0], Block)

# Generated at 2022-06-21 00:35:30.641913
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert load_list_of_blocks(None) == []
    assert load_list_of_blocks(False) == []



# Generated at 2022-06-21 00:36:01.629043
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import json
    import os
    import shutil
    import sys
    import tempfile

    # We need to set up a fake environment, so that the modules
    # we are testing get loaded properly
    # This is ripped right out of the core
    real_environ = os.environ.copy()

    # Setup minimal ansible.cfg and a fake collection path
    ansible_cfg = tempfile.NamedTemporaryFile(mode="w+t", delete=False)
    ansible_cfg_path = os.path.dirname(ansible_cfg.name)

# Generated at 2022-06-21 00:36:13.717549
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.playbook.play
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block


# Generated at 2022-06-21 00:36:21.398995
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds=[[{'action': 'command', 'register': 'r', 'args': 'echo hello'}],
             [{'action': 'command', 'register': 'r', 'args': 'echo world'}],
             [{'action': 'command', 'register': 'r', 'args': 'echo world'}]]
    load_list_of_tasks(task_ds)
# --------------------------------------------------------------- #

# Generated at 2022-06-21 00:36:33.757104
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.task import Task
    from ansible.template.safe_eval import safe_eval
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy

    class FakeVars(object):
        def get_vars(self, loader, path, entities, cache=True):
            return {'foo': 'bar'}

    class FakeVMM(VariableManager):
        def get_vars(self, loader=None, path=None):
            return FakeVars()

    class FakeLoader(object):
        pass


# Generated at 2022-06-21 00:36:39.470464
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # note: this test code lives in the lib/ansible/playbook directory
    # and requires python 3.5+
    import ast
    bad_input = '-'
    assert not isinstance(ast.literal_eval(bad_input), list), "Input must be a list of parameters"


# Generated at 2022-06-21 00:36:52.429103
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.callback import CallbackModule
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-21 00:37:04.600798
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    import sys

    #hosts = "localhost,"
    #hosts = "localhost,"

    hosts = """
    [local]
    localhost
    """


    #hosts = "localhost,"

    #hosts = """
    #[local]
    #localhost ansible_connection=local
    #"""


# Generated at 2022-06-21 00:37:05.301293
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # TODO: test me ...
    pass



# Generated at 2022-06-21 00:37:10.424888
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.vars import get_vars
    from units.mock.vm import get_vault_secret

    def load_fixture(path, content_type=None):
        if path.endswith('/meta/main.yml'):
            return {}

    loader = DictDataLoader({})
    loader.set_basedir('/')
    loader.set_data({}, 'meta/main.yml')
    loader.set_data(load_fixture, 'roles/foo/meta/main.yml')

    p = Play()

# Generated at 2022-06-21 00:37:23.514978
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import connection_loader

    context = PlayContext()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 00:38:00.339397
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # create fake dataset
    ds = []
    r1 = dict(name="role1", tags=['role1_tag'], tasks="role1_tasks.yml")
    r2 = dict(name="role2", tasks="role2_tasks.yml")
    ds.append(r1)
    ds.append(r2)
    # create fake RoleInclude object
    role1_include_obj = RoleInclude()
    role1_include_obj.name = "role1"
    role1_include_obj.tags = ['role1_tag']
    role1_include_obj.tasks = "role1_tasks.yml"
    # fake RoleInclude object for role2
    role2_include_obj = RoleInclude()

# Generated at 2022-06-21 00:38:11.340212
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    vars_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=vars_manager)
    play = Play().load({
        'name': 'foo',
        'hosts': 'all',
        'roles': '',
        'gather_facts': 'no',
        'tasks': [
            {'name': 'debug me',  'debug': 'stuff'},
            {'name': 'no debug', 'debug': ''},
        ]
    }, variable_manager=vars_manager, loader=loader)

    block_list = load_list_of_

# Generated at 2022-06-21 00:38:12.161753
# Unit test for function load_list_of_roles

# Generated at 2022-06-21 00:38:18.380890
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # This unit test checks the function load_list_of_roles with its four
    # parameters. We will create a simple play to test the role inclusion
    # and the role definition. We will check the role inclusion with the
    # role definition created. If the role inclusion is working then it
    # will return the role inclusion object.
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    add_all_plugin_dirs()

# Generated at 2022-06-21 00:38:31.040517
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    Test the load_list_of_blocks function with a simple list of tasks.
    '''
    import ansible.playbook
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    variable_manager = ansible.playbook.variable_manager.VariableManager()
    loader = ansible.parsing.dataloader.DataLoader()
    pb = ansible.playbook.Playbook()
    play = ansible.playbook.Play().load({}, variable_manager=variable_manager, loader=loader)
    play._included_files = []

# Generated at 2022-06-21 00:38:42.894876
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    # Test load_list_of_roles, create a fake task
    import io
    import yaml
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text, to_native

    # Test load_list_of_roles, create a fake task
    data = '''
    ---
    - name: fake_task
      import_role:
        name: "{{ item }}"
        tasks_from: do_this
        loop:
          - foo
          - bar
    '''

    if PY3:
        data = to_bytes(data, errors='surrogate_or_strict')

# Generated at 2022-06-21 00:38:48.042735
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert load_list_of_blocks([], None) == []
    assert load_list_of_blocks(None, None) == []
    assert load_list_of_blocks(1, None) == []
    assert load_list_of_blocks("test", None) == []



# Generated at 2022-06-21 00:39:01.114325
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext

    playbook_dir = os.path.dirname(os.path.dirname(__file__))
    collection_dir = os.path.join(playbook_dir, 'collections')
    collection_list = [collection_dir]
    ds = [{
        'role': 'test_role',
        'tasks': [{
            'include': 'test_role_include'
        }],
        'vars': {'test_role_var': 'test_role_var_value'}
    }]
    play = Play()
    context = PlayContext()
    current_role_path = None
    variable_manager = VariableManager()
    loader = DataLoader()
    roles = load_

# Generated at 2022-06-21 00:39:04.010594
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ''' ansible.parsing.dataloader.load_list_of_tasks() '''
    pass

# Generated at 2022-06-21 00:39:14.364753
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Run tests for load_list_of_tasks.
    '''
    import six
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.cli import CLI
    from ansible.errors import AnsibleParserError

    yaml.add_representer(type(None), lambda self, data: self.represent_scalar(u'tag:yaml.org,2002:null', u'null'))

    cli = CLI()
    cli.parse()

# Generated at 2022-06-21 00:40:01.063031
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    task1 = AnsibleBaseYAMLObject()
    task1.data = 'test_task_data'
    task2 = AnsibleBaseYAMLObject()
    task2.data = 'test_task_data'
    task3 = AnsibleBaseYAMLObject()
    task3.data = 'test_task_data'
    task4 = AnsibleBaseYAMLObject()
    task4.data = 'test_task_data'

    # test_list - list of bare tasks and tasklist
    test_list = [task1, task2, task3, task4]
    assert load_list_of_blocks(test_list, None, None, None) == test_list

    # test_list2 - list of bare tasks

# Generated at 2022-06-21 00:40:09.552291
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import ansible.playbook
    import ansible.playbook.play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude

    playbook_test = ansible.playbook.PlayBook()
    play_test = ansible.playbook.play.Play()
    loader_test = DictDataLoader({})
    variable_manager_test = VariableManager()
    role_test = RoleDefinition()

    role_defs = [dict(name='testrole')]
    load_list_of_roles(role_defs, play_test, loader=loader_test, variable_manager=variable_manager_test)


# Generated at 2022-06-21 00:40:20.375765
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.playbook.block import Block
    ds = [
        AnsibleMapping(
            dict(
                tasks = AnsibleSequence([
                    AnsibleMapping(dict(name = AnsibleUnicode("first"))),
                    AnsibleMapping(dict(name = AnsibleUnicode("second"))),
                ])
            )
        )
    ]
    assert load_list_of_blocks(ds) == [Block.load(ds[0])]

# Generated at 2022-06-21 00:40:28.823333
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """
    test_load_list_of_tasks:
    """
    empty_list = []
    res = load_list_of_tasks(empty_list)
    assert len(res) == 0

    tasks = [{"action": {"module": "shell",
                         "args": "ls -la"}}]
    res = load_list_of_tasks(tasks, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert len(res) == 1

# Generated at 2022-06-21 00:40:38.874122
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude
    dummy_variable_manager = DummyVariableManager()
    dummy_loader = DummyLoader()

    test_role_list = [{
                          'name': 'role1',
                          'foobar': 'baz'
                      },
                      {
                          'name': 'role2'
                      }]

    object_role_list = load_list_of_roles(test_role_list, None, variable_manager=dummy_variable_manager,
                                          loader=dummy_loader)

    assert len(object_role_list) == 2
    for role in object_role_list:
        assert isinstance(role, RoleInclude)



# Generated at 2022-06-21 00:40:49.119978
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    print()
    print("Testing load_list_of_blocks()")
    #from ansible.playbook.play_context import PlayContext
    #from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import role_resolver
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import module_loader
    from ansible.playbook.play import Play
    #from ansible.playbook.block import Block

# Generated at 2022-06-21 00:40:58.995711
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.collection_loader import AnsibleCollectionResolver
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    # build a mock play
    play_context = PlayContext()

    # build a mock loader
    collection_loader = AnsibleCollectionResolver()

    # build a mock loader
    loader = DataLoader()

    # build a mock variable manager
    variable_manager = VariableManager()

    ds = []

    ds.append(dict(role="some_role"))
    ds.append(dict(role="some_role", name="foo"))
    ds.append(dict(name="foo", role="some_role"))

# Generated at 2022-06-21 00:41:07.561822
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.parsing.yaml import safe_load
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader)

    host = inventory.add_host('localhost')
    host.vars = {
        'ansible_python_interpreter': '/usr/bin/python',
        'ansible_connection': 'local'
    }


# Generated at 2022-06-21 00:41:08.455472
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass

# Generated at 2022-06-21 00:41:14.602445
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        load_list_of_tasks('/etc/hosts')
    except AnsibleAssertionError as e:
        assert str(e) == 'The ds ({0}) should be a list but was a {1}'.format('/etc/hosts', str(type('/etc/hosts')))

# vim: set expandtab sw=4 :