

# Generated at 2022-06-21 00:32:51.927854
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    ds = [
        {'name': 'print_var',
         'debug': 'msg={{var}}',
         'vars': {'var': 'This is var'}
        },
        {'name': 'print_var',
         'debug': 'msg={{var}}',
         'vars': {'var': 'This is var2'}
        },
        {'include': '{{include_file}}',
         'vars': {'include_file': 'include_file.yml'}
        },
    ]
    # ds is a list, so all_ds is a duplicate
    all_ds = ds

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.task import Task


# Generated at 2022-06-21 00:33:04.315884
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.loader import role_loader
    role_loader.add_directory(DATA_PATH + '/roles')

    ds = [{'name': 'apache2'}, {'name': 'mod_jk'}]
    play = Play()
    current_role_path = None
    variable_manager = VariableManager()
    loader = DataLoader()
    collection_search_list = []
    roles = load_list_of_roles(ds, play, current_role_path, variable_manager, loader, collection_search_list)
    assert isinstance(roles, list)
    for role in roles:
        assert isinstance(role, RoleInclude)

# Generated at 2022-06-21 00:33:14.201279
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude

    pc = PlayContext()
    play = Play().load({}, pc, play_context=pc, variable_manager=variable_manager, loader=loader)

    # Test load_list_of_roles with no role definition
    role_list = RoleDefinition.load({}, play=play, variable_manager=variable_manager, loader=loader)
    assert load_list_of_roles(None, play, variable_manager=variable_manager, loader=loader) == []

    # Test load_list_of_roles with no role definition

# Generated at 2022-06-21 00:33:27.998083
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader    
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import test_loader
    import os
    test_dir = '%s/../../test/units/parsing/yaml/' % os.path.dirname(os.path.abspath(__file__))
    global_vars = {'ansible_connection': 'local'}
    local_inventory = ansible.inventory.Inventory()

    # setup yaml_loader
    tasks = []
   

# Generated at 2022-06-21 00:33:40.685857
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # test load_list_of_roles
    def _test_load_role(role_def, role_name, role_path, vars_files, tasks_file, handlers_file, meta_file, defaults_file, tasks_dir,
                        files_dir, templates_dir, vars_dir, handlers_dir, meta_dir, defaults_dir, when, dependencies):
        role = load_list_of_roles(role_def, None, None, None, None, [])[0]
        assert role.name == role_name
        assert role.get_path() == role_path
        assert role.vars_files == vars_files
        assert role.tasks_file == tasks_file
        assert role.handlers_file == handlers_file
        assert role.meta_file == meta_file

# Generated at 2022-06-21 00:33:42.366625
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # TODO: complete this test
    pass

# Unit test function for function load_list_of_blocks

# Generated at 2022-06-21 00:33:43.845768
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert load_list_of_roles(['common']) == 'role[common]'


# Generated at 2022-06-21 00:33:44.730717
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert False

# Generated at 2022-06-21 00:33:53.554807
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role_include import IncludeRole

    task_list = []
    ds = [
        {'block': 'myblock', 'tags': [], 'tasks': [{'task': 'mytask',
                                                    'tags': [],
                                                    'when': 'here'}]},
        {'handler': 'myhandler', 'tags': [], 'when': 'here'},
        {'include_role': 'myrole', 'tags': [], 'when': 'here'},
    ]
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    task_list = load

# Generated at 2022-06-21 00:34:03.650573
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass

# Generated at 2022-06-21 00:34:22.274275
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # UNIT TEST:
    # Check that we properly handle a None value for ds
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved

    play = Play.load(
        dict(
            name="test play",
            hosts=["all"],
            gather_facts='no',
            roles=["test_role"],
            vars=dict(foo="bar"),
        ),
    )

    # We need a valid VariableManager object for this to work, but we don't care about
    # the actual values as long as we don't fail
    pm = {}
    vm = VariableManager(loader=None, inventory=None, version_info=pm)

# Generated at 2022-06-21 00:34:30.614583
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    assert isinstance(load_list_of_roles([{'role': 'role_one'}, {'role': 'role_two'}]), list)
    assert isinstance(load_list_of_roles([{'role': 'role_one'}, {'role': 'role_two'}])[0], RoleInclude)



# Generated at 2022-06-21 00:34:38.064191
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader
    import ansible.constants as C
    # create the variable manager, which will be shared across all objects
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='tests/inventory')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 00:34:38.819665
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert True

# Generated at 2022-06-21 00:34:47.269966
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Test that parsing a list of tasks works
    task_ds = [{'action': 'ping'}, {'action': 'ping'}]
    task_list = load_list_of_tasks(ds=task_ds, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert len(task_list) == 2

    # Test that list of tasks with include works
    task_ds = [
            {'action': 'ping'},
            {'action': 'include_tasks', 'args': {'tasks': ['tasks/main.yaml']}}
            ]

# Generated at 2022-06-21 00:34:58.235866
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    ds = [{'action': {'test': 'test'}, 'block': 'test', 'rescue': {'test': 'test'}, 'always': {'test': 'test'}}]
    play = Play().load(ds={'name': 'test_load_list_of_blocks', 'hosts': 'all', 'tasks': load_list_of_blocks(ds, play=play)}, variable_manager=None, loader=None)
    assert isinstance(play.tasks[0], Block)
    # TODO: Test for when a block has a task with a "rescue" or "always" attribute
    # TODO: Test for when a block has a task with a "tags" attribute
    # TODO: Test for

# Generated at 2022-06-21 00:35:08.976716
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook import Play
    from ansible.plugins.loader import role_loader
    from ansible.plugins.loader import collection_loader

    src_data_collection = '''
- hosts: all
  tasks:
    - ansible.builtin.debug:
        msg: "Print debug message"
'''
    src_data = f'''
- hosts: all
  roles:
    - test_role
    - test_role:
        role: test_role1
      tasks:
        - ansible.builtin.debug:
            msg: "Print debug message"
        - import_role:
            name: test_role2
            static: yes
    - test_role2:
        test: yes
'''
    data = yaml.load(src_data)
    data_collection = yaml.load

# Generated at 2022-06-21 00:35:17.779587
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible.playbook.task
    ds=[]
    ds.append({"action": "yum", "name": "vim-enhanced"})
    ds.append({"action": "remote_management", "name": "vim-enhanced"})
    ds.append({"action": "include_tasks", "name": "vim-enhanced"})
    ds.append({"action": "include", "name": "vim-enhanced"})
    ds.append({"action": "import_tasks", "name": "vim-enhanced"})
    ds.append({"action": "import_playbook", "name": "vim-enhanced"})
    ds.append({"action": "block", "name": "vim-enhanced"})

    #print(load_list_of_

# Generated at 2022-06-21 00:35:30.084169
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Unit test for load_list_of_roles
    """
    fake_loader = FakeLoader()
    fake_variable_manager = FakeVariableManager()

    fake_play = FakePlay()

    # test_1
    ds = [{'role': 'test_role_1'},
          {'role': 'test_role_2'}]
    roles = load_list_of_roles(ds, fake_play,
                               variable_manager=fake_variable_manager, loader=fake_loader)

    assert len(roles) == 2
    assert roles[0].name == 'test_role_1'
    assert roles[1].name == 'test_role_2'
    assert roles[0]._role is None
    assert roles[1]._role is None

    # test_2
    ds

# Generated at 2022-06-21 00:35:42.768637
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''Unit test for function load_list_of_roles'''
    temp_ds_list = [
        {"role": "webservers"},
        {"role": "databases", "some_var": "foo"},
        {"role": "common", "tags": ["common"], "when": "ansible_os_family == 'RedHat'"}]

    my_play = Play()
    my_play.hosts = "all"
    my_play.connection = "local"

    roles_1 = load_list_of_roles(temp_ds_list, my_play)
    assert(roles_1[0].get_name() == "webservers")
    assert(roles_1[1].get_name() == "databases")


# Generated at 2022-06-21 00:36:15.630299
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.executor.playbook_executor import PlaybookExecutor

    host_list = [
        'localhost',
    ]
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=host_list)
    pb_executor = PlaybookExecutor(
        playbooks=['./test_playbooks/test_load_list_of_blocks.yaml'],
        inventory=inventory,
        variable_manager=VariableManager(),
        loader=loader,
        passwords={},
    )

    result = pb_executor.run()

# Generated at 2022-06-21 00:36:25.220600
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import copy
    import inspect
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    from units.mock.loader import DictDataLoader

    def _load_plugins():
        global _action_plugins

# Generated at 2022-06-21 00:36:35.645813
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    ansible.playbook.base.test_load_list_of_tasks
    '''
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    ds = [dict(action='A'), dict(action='B'), dict(action='C')]
    result = load_list_of_tasks(ds, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert all([isinstance(t, Task) for t in result])
    assert result[0].action == 'A'

# Generated at 2022-06-21 00:36:48.136750
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    # We need a play to pass to load so we make one
    play_ds = {"hosts": "localhost", "gather_facts": "no"}
    display.verbosity = 3
    play = Play().load(play_ds, variable_manager=VariableManager(), loader=DataLoader())

    # We need a block to pass to load so we make one
    block_ds = {"tasks": [{"debug": {"msg": "This is a test"}}]}

# Generated at 2022-06-21 00:36:56.624773
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # we import here to prevent a circular dependency with imports
    import test.support.build_ansible_module as build_ansible_module
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.six import string_types
    import test.support.ansible_test_data as ansible_test_data
    from ansible.playbook.play import Play

    my_play = Play()
    # Set up the context for the roles
    my_play.context = PlayContext()
    my_play.context.become = None
    my_play.context.become_method = None
    my_play.context.become_user = None
    my_play.context.remote_addr = None
    my_play.context

# Generated at 2022-06-21 00:36:57.781296
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass


# Generated at 2022-06-21 00:37:06.988139
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Given a list of task datastructures (parsed from YAML),
    # return a list of Task() or TaskInclude() objects.
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.template import Templar
    # loading task
    task_ds = {
        'name': 'Example task name',
        'action': {
            'module': 'shell',
            'args': {
                'echo': 'Hello World!',
            },
        },
        'when': 'ansible_os_family == "RedHat"',
        'register': 'shell_out',
    }

# Generated at 2022-06-21 00:37:11.827686
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    play = Play()

    ds = [
        {'include': 'foo'},
        {'include': 'bar'},
        {'include': 'baz'},
    ]

    blocks = load_list_of_blocks(ds, play)
    assert len(blocks) == 1
    assert len(blocks[0].block) == 3


# Generated at 2022-06-21 00:37:24.097390
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.vars import combine_vars
    import ansible.constants as C

    loader = DataLoader()
    variable_manager = VariableManager()
    add_all_plugin_dirs()

    # sample input

# Generated at 2022-06-21 00:37:33.293166
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # check with list of valid blocks
    b_list = load_list_of_blocks([{'block':1},{'block':2}])
    assert type(b_list[0]) is Block

    # check with list of valid and invalid blocks
    b_list = load_list_of_blocks([{'block':1},{'block':2},{'task':{'name':'name'}}])
    assert type(b_list[0]) is Block
    assert type(b_list[2]) is Block

    # check with list of all invariant blocks
    b_list = load_list_of_blocks([{'task':{'name':'name'}},{'task':{'name':'name'}},{'task':{'name':'name'}}])
    assert type(b_list[0])

# Generated at 2022-06-21 00:38:10.913208
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # The only test for this function is for the implicit block.
    # That test is done with a YAML test.
    pass



# Generated at 2022-06-21 00:38:12.127181
# Unit test for function load_list_of_tasks

# Generated at 2022-06-21 00:38:22.395319
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Function to test load_list_of_roles function
    :return:
    '''
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.errors import AnsibleError
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import os.path
    import json

    # Unit test for function load_list_of_roles
    # Given

# Generated at 2022-06-21 00:38:33.067266
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # this test is pointless without running it in the context of a playbook,
    # however, we load some stuff that is not available outside of the
    # context of a playbook so we mock it out here
    class MockPlay(object):

        def __init__(self):
            self.connection = 'local'
            self.become_method = None
            self.remote_user = None
            self.remote_port = None
            self.become = False
            self.become_user = None
            self.become_pass = None
            self.set_remote_user = None

    class MockInventory(object):
        pass

    class MockVariableManager(object):
        def __init__(self):
            self._extra_vars = dict()


# Generated at 2022-06-21 00:38:43.803827
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.included_file import IncludedFile

# Generated at 2022-06-21 00:38:55.089274
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    task_ds_1 = dict(action='test_action', args=dict(test='test'))
    task_ds_2 = dict(action='test_action_2', args=dict(test2='test2'))
    task_ds_3 = dict(action='test_action_3', args=dict(test3='test3'))

    ds = [task_ds_1, task_ds_2, task_ds_3]


# Generated at 2022-06-21 00:38:56.294606
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True



# Generated at 2022-06-21 00:39:04.221961
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Test for function load_list_of_roles
    """
    import ansible_collections.ansible.community.tests.unit.compat.mock as mock

    # Preliminary data
    pb_datadir_path = "/path/to/playbook/directory"
    role_path_name_no_collections = "/path/to/role"
    role_path_name_with_collections = "/path/to/collection/role"

    # Mock data
    def get_basedir():
        return pb_datadir_path

    # Patcher(s)
    patchers = []
    mock_loader = mock.Mock()
    mock_loader.get_basedir = get_basedir

# Generated at 2022-06-21 00:39:14.424844
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role import definition
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-21 00:39:21.753201
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    for test in ['[]', [{'block': {'foo': 'bar'}}], [['a'], ['b']]]:
        assert isinstance(Block.load(test), Block)
    try:
        Block.load({})
    except AnsibleParserError as error:
        assert isinstance(error, AnsibleParserError)
    else:
        assert False, "AnsibleParserError not raised"


# Generated at 2022-06-21 00:40:13.621782
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert False, 'is this unit test reachable?'

# Generated at 2022-06-21 00:40:17.236712
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # TODO:  This file is currently still in Ansible 2.x format.  It needs to be converted to Ansible 2.5 format.  The test should be completed after this is done.
    raise NotImplementedError

# Generated at 2022-06-21 00:40:23.396585
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # TODO: write unit test for load_list_of_blocks

    # http://docs.pytest.org/en/latest/xunit_setup.html

    # TODO: load_list_of_blocks doesn't have tests yet!
    # see github #669
    assert True

# Generated at 2022-06-21 00:40:32.002064
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import ansible.collections.ansible.builtin
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import test_module_loader
    from ansible.plugins.loader import vars_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

# Generated at 2022-06-21 00:40:36.628768
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    try:
        load_list_of_blocks(dict(a=1), None, None, None, None, None, None, None);
    except AnsibleAssertionError as  ex:
        assert ex.message == "should be a list or None but is <type 'dict'>"
    else:
        raise

# Generated at 2022-06-21 00:40:48.016124
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    from unittest import mock

    from ansible.playbook import Play
    from ansible.playbook.role.definition import RoleDefinition

    from ansible.vars import VariableManager
    from ansible.playbook.role.include import RoleInclude

    # Create a mock task list and set the return value
    role = RoleDefinition()
    role.get_task_list = mock.MagicMock(return_value=[])
    role.get_handler_list = mock.MagicMock(return_value=[])
    role.get_default_vars = mock.MagicMock(return_value={})
    role.get_vars = mock.MagicMock(return_value={})
    role.get_meta = mock.MagicMock(return_value=None)

    # Create the mock object and set the return value
    role_

# Generated at 2022-06-21 00:40:58.593124
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    block=None
    role=None
    task_include=None
    use_handlers=False
    variable_manager=None
    loader=None
    ds=[dict(
        local_action=dict(
            module=dict(
                args=list(),
                kwargs=dict(),
                name='local_action',
            ),
            module_args=dict(
                args=list(),
                kwargs=dict(),
                name='local_action',
            ),
            name='local_action',
        )
    )]
    task_list=load_list_of_tasks(ds,play=None,block=block,role=role,task_include=task_include,use_handlers=use_handlers,variable_manager=variable_manager,loader=loader)
    logging.info(task_list)


# Generated at 2022-06-21 00:41:08.542318
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test for ansible.utils.list_of_tasks.load_list_of_tasks function.

    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.errors import AnsibleAssertionError
    from ansible.playbook.play import Play
    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader

    loader = DictDataLoader({})
    variable_manager = VariableManager()
    loader.set_basedir('/')


# Generated at 2022-06-21 00:41:14.194517
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.template import Templar
    assert load_list_of_blocks([{'block': 'a'}, 'b'], Play()) == [Block(parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None, play=Play(), ds={'block': 'a'}, strategy='linear', failed_when_required=False, name='a', when=None), Block(parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None, play=Play(), ds='b', strategy='linear', failed_when_required=False, name='Implicit', when=None)]
    assert load_list

# Generated at 2022-06-21 00:41:20.034418
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    task_list = []
    myhostvars = {
        "ansible_host": "127.0.0.1",
        "ansible_user": "demo",
        "ansible_password": "demo",
        "ansible_port": 22,
    }

    mygroupvars = {
        "ansible_ssh_common_args": "-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null",
    }


# Generated at 2022-06-21 00:42:14.669367
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    Basic smoke test to confirm that we aren't actually crashing.
    '''

    # We need to import here to prevent circular dependencies
    from ansible.playbook import Play
    import ansible.constants as C

    # fake args
    args = [
        "playbook",
        "playbook.yml",
    ]


    # fake options