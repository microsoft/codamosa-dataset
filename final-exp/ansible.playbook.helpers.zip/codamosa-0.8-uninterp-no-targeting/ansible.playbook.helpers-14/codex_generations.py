

# Generated at 2022-06-21 00:32:38.063112
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    class AnsiblePlay():
        pass

    class AnsibleVM():

        def __init__(self, role=None):
            self.role = role

    class AnsibleTask():
        def __init__(self, name, block=None, loop=None, loop_args=None, loop_with_items=None, when=None, rescue=None, always=None, tags=None, ignore_errors=False, failed_when=False, register=None, delegate_to=None, until=None, retries=0):
            self.name = name
            self.module_vars = None
            self.block = block
            self.loop = loop
            self.loop_args = loop_args
            self.loop_with_items = loop_with_items
            self.when = when
            self.rescue = rescue

# Generated at 2022-06-21 00:32:51.968099
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    display.verbosity = 3


# Generated at 2022-06-21 00:32:54.849133
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # This file is empty because the function is tested in unit tests of Block
    pass



# Generated at 2022-06-21 00:33:08.700720
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Run a simple unit test from the command line to test loading of role name with and without association of a role path
    to the owner role.
    :return:
    """
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.loader import add_all_plugin_dirs

    # hard code role file that is statically included in the repository
    role_file = './examples/ansible-lint/test.yml'

    # dummy Play object
    play = Play()

    # normal case
    host_list = ["localhost"]
    play._variable_manager = VariableManager()
    play._variable_manager.extra_vars = {'hosts':host_list}

    # need to register plugins for the process to work correctly
    add

# Generated at 2022-06-21 00:33:09.531780
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass


# Generated at 2022-06-21 00:33:14.727193
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.definition import RoleDefinition

    # create a simple play with a play context
    play_ctxt = PlayContext()
    play_obj = Play().load({}, play_context=play_ctxt, variable_manager=None, loader=None)

    # load the test data and update context/obj with it
    test_data = [{"role": "common"}]
    roles = load_list_of_roles(test_data, play_obj, current_role_path=None, variable_manager=None, loader=None, collection_search_list=[])
    assert len(roles) == 1

# Generated at 2022-06-21 00:33:16.664732
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert False, "Unit test not implemented for load_list_of_roles"

# Generated at 2022-06-21 00:33:29.756562
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook import Play
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    # Test 1
    # test without current_role_path
    class TestPlay(Play):
        def __init__(self, variable_manager=None, loader=None):
            super(TestPlay, self).__init__(name="test", variable_manager=variable_manager, loader=loader)
            self._variable_manager = variable_manager
            self._loader = loader

    play = TestPlay(VariableManager(loader=None), './test')
    roles = load_list_of_roles([{'role':'test'}],play, current_role_path=None, variable_manager=play._variable_manager, loader=play._loader)
    assert roles[0]._role_name == 'test'

# Generated at 2022-06-21 00:33:41.010012
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Load list of tasks, given an empty list,
    # then given a list of valid task data structures.
    #  @param task_ds
    #             The list of tasks to load.

    task_ds = []
    play = None
    block = None
    role = None
    task_include = None
    use_handlers= False
    variable_manager = None
    loader = None

    load_list_of_tasks(task_ds,
                       play=play,
                       block=block,
                       role=role,
                       task_include=task_include,
                       use_handlers=use_handlers,
                       variable_manager=variable_manager,
                       loader=loader)

    # FIXME: Uncomment the lines below when issue #55371 is fixed.
    #task_ds = [{"meta": "foo"}]

# Generated at 2022-06-21 00:33:50.009028
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # TODO: This needs to be moved to a proper unit tests framework,
    # and a full suite of unit tests needs to be written.

    # test load_list_of_tasks's return value with a list of dictionaries
    assert load_list_of_tasks([{}]) == []
    assert load_list_of_tasks([{'block': 'block', 'block_id': 'block_id'}]) == []
    assert load_list_of_tasks([{'action': 'action', 'name': 'name'}]) == []

# Generated at 2022-06-21 00:34:12.400208
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    ds = [dict(name="first", action=dict(module="shell", args="echo foo"))]
    b = Block.load(ds[0], play=None, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=variable_manager, loader=loader)
    assert isinstance(b, Block)
    assert b.block  # implicit blocks are always a list (single or multiple items)
    assert b._parent is None
    assert b.root() is b
    assert len(b.block) == 1

# Generated at 2022-06-21 00:34:13.492301
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-21 00:34:24.273652
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    import ansible.plugins.loader
    from ansible.template import Templar

    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.inventory.manager import InventoryManager

    # Load list of tasks
    inventory = InventoryManager(loader=ansible.plugins.loader, sources='localhost,')

    play_context = PlayContext()

    loader = DataLoader()
    # create a task
    task_ds = dict(action=dict(module='setup'))
    t = Task.load(task_ds)
    # create a play

# Generated at 2022-06-21 00:34:34.636682
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Validates that load_list_of_roles() properly generates a list of
    RoleInclude objects from the ds list of role definitions
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins import plugin_loader

    test_data = [{'name': 'role1', 'tasks': [{'name': 'task1', 'debug': 'msg=test1'}]},
                 {'name': 'role2', 'tasks': [{'name': 'task2', 'debug': 'msg=test2'}]}]


# Generated at 2022-06-21 00:34:40.129056
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Unit test for the load_list_of_roles function
    :return:
    """
    loader, play, variable_manager, all_vars = (
        TestPlaybook.playbook_loader(), TestPlaybook.play(), TestPlaybook.variable_manager(), TestPlaybook.all_vars_from_file()
    )
    ds = """
    - name: geerlingguy.repo-remi
      when: ansible_distribution == 'CentOS'
      repo: remi-safe
      state: enabled
    - name: geerlingguy.repo-epel
      when: ansible_distribution == 'CentOS'
      state: latest
    """
    ds = yaml.load(ds)

# Generated at 2022-06-21 00:34:47.824856
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler

    def assert_load_list_of_blocks(ds, play, role):
        block_list = load_list_of_blocks(ds, play, role=role)
        assert isinstance(block_list, list)
        for block in block_list:
            assert isinstance(block, Block)
            assert isinstance(block.parent_block, Block)
            assert isinstance(block.task_include, Task)
            assert isinstance(block.use_handlers, bool)
            assert isinstance(block.name, str)
            assert isinstance(block.vars, dict)

# Generated at 2022-06-21 00:34:58.928754
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    #from ansible.playbook.play import Play
    #from ansible.playbook.task import Task
    #from ansible.playbook.role import Role
    #from ansible.parsing.mod_args import ModuleArgsParser
    import pytest

    #from units.mock.loader import DictDataLoader
    #from units.mock.path import mock_unfrackpath_noop


    def make_task(text):
        return Task.load(dict(action=dict(module=text)))


# Generated at 2022-06-21 00:35:01.725986
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert load_list_of_blocks(None, "play", "parent_block") is None
    assert load_list_of_blocks("name", "play", "parent_block") is True



# Generated at 2022-06-21 00:35:12.924837
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test that a non-list in load_list_of_tasks raises an error
    try:
        load_list_of_tasks('test', 'play')
    except AnsibleAssertionError:
        pass
    else:
        assert False, "AnsibleAssertionError not raised"

    # Test that a list with a bad data structure raises an error
    try:
        load_list_of_tasks(['test'])
    except AnsibleParserError:
        pass
    else:
        assert False, "AnsibleParserError not raised"

    # Test that a list with a valid data structure does not raise an error
    result = load_list_of_tasks([{'name': 'test'}])

# Generated at 2022-06-21 00:35:21.821170
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()

    # test include tasks
    play_ds = dict(
        name='foobar',
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(include='blah.yml'))
        ]
    )
    play = Play().load(play_ds, variable_manager=variable_manager, loader=loader)

    task_list = load_list_of_tasks(
        play_ds['tasks'],
        play=play,
        task_include=None,
        variable_manager=variable_manager,
        loader=loader,
    )

# Generated at 2022-06-21 00:35:57.040449
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources="localhost,")
    variable_manager.set_inventory(inventory)
    passwords = {}
    pbex = PlaybookExecutor(playbooks=['test_playbook.yml'],
                            inventory=inventory,
                            variable_manager=variable_manager,
                            loader=loader,
                            passwords=passwords)
    results

# Generated at 2022-06-21 00:36:03.063253
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play

    play_data = dict(
        name = "test play",
        hosts = 'testhosts',
        gather_facts = 'no',
        roles = [
            dict(
                name = 'fake_role_1',
                tasks = [
                    dict(action=dict(module='setup', args=dict()), register='setup_result'),
                ],
            ),
            dict(
                name = 'fake_role_2',
                tasks = [
                    dict(action=dict(module='setup', args=dict()), register='setup_result'),
                ],
            ),
        ]
    )

    play_source = dict(
        name="ansible-playbook",
        hosts='all',
        gather_facts='no',
        roles=play_data['roles'])



# Generated at 2022-06-21 00:36:14.508489
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext as pc

    # load_list_of_roles(ds, play, current_role_path=None, variable_manager=None, loader=None, collection_search_list=None):

    # ds = list of roles to load
    ds = [
        {
            'name': 'test_role',
            'tasks': [
                {
                    'name': 'test_task'
                }
            ]
        }
    ]
    ds = yaml.load(yaml.safe_dump(ds))

    # play = calling Play object
    play = Play()

    # current_role_path = path of the owning role, if any
    cur_role_path = '/path/to/role'

    # variable_manager = varmgr to use for tem

# Generated at 2022-06-21 00:36:24.813932
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.get_vars(loader=loader)
    play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        roles = [dict(
            name = "role1",
            tags = ["a", "b"],
            task_files = ["task_file1"],
            handlers_files = ["handlers_file1"],
            vars_files = ["vars_file1"],
            vars = {"var1": "val1"}
        )],
        tasks = [dict(
            action = dict(
                module = "ping",
            )
        )]
    ), variable_manager=variable_manager, loader=loader)
    host = Host("localhost")
    play

# Generated at 2022-06-21 00:36:26.584185
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert False




# Generated at 2022-06-21 00:36:36.396818
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.vars.file_var_storage import FileVariableManager
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor import task_queue_manager

    # First we need to set up the objects we'll use to run a playbook
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.options_vars = {'first_var': "Ansible", 'second_var': "is", 'third_var': "awesome"}
    variable_manager.extra_vars = {'hosts': 'hosts'}

# Generated at 2022-06-21 00:36:44.800019
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    tasks = []
    tasks.append(Task.load({
        'name': 'task1',
        'action': {'module': 'debug', 'args': 'var=1'}
    }))
    tasks.append(Task.load({
        'name': 'task2',
        'action': {'module': 'debug', 'args': 'var=2'}
    }))

# Generated at 2022-06-21 00:36:55.390734
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import unittest
    import mock
    from ansible.playbook.play import Play

    class TestRoles(unittest.TestCase):
        def setUp(self):
            self.play = None
            self.roles = None
            self.current_role_path = None
            self.variable_manager = None
            self.loader = None
            self.collection_search_list = None
            self.role_def = None

        def test_instantiate_role_include(self):
            self.role_def = {'role': 'test'}
            with mock.patch('ansible.playbook.role.include.RoleInclude.load') as mock_role_include:
                mock_role_include.return_value = None

# Generated at 2022-06-21 00:37:05.911549
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    play = Play.load(
        dict(
            name="Ansible Play",
            hosts=["all"],
            gather_facts="no",
            tasks=[{"action": {"module": "shell", "args": "ls"}}],
        ),
        variable_manager=variable_manager,
        loader=loader,
    )


# Generated at 2022-06-21 00:37:13.984665
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import plugin_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from units.mock.loader import DictDataLoader

    play_context = PlayContext()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=DictDataLoader({}))
    inventory_manager.set_inventory(inventory_manager.loader.inventory_basedir("hosts"))
    loader = DataLoader()
    templar = Templar(loader, variable_manager)

# Generated at 2022-06-21 00:38:23.435614
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.vars.reserved import Reserved
    from ansible.vars.hostvars import HostVars
    # load_list_of_roles init with role_name definition
    role_name = [
      {
        "role_name": "test_role_1"
      }
    ]
    # load_list_of_roles init with role_name and loop definition
    extra_vars = {
      "role_name": [
        "test_role_1",
        "test_role_2"
      ]
    }
    # call loop on load_list_of_roles
    role_name_extra_vars = [
      {
        "role_name": "{{ role_name }}"
      }
    ]
    # variables to init play

# Generated at 2022-06-21 00:38:27.851321
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds = [{'block': 'test_block'}]
    assert load_list_of_blocks(ds, None) == [{'block': 'test_block'}]



# Generated at 2022-06-21 00:38:35.917340
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    role_path = '/path/to/test_role'

    # ds: dict of role definition
    ds = dict(
        name='test_role'
    )

    loader = DictDataLoader({
        role_path: dict()
    })
    pm = PlaybookExecutor._create_play_context(playbooks=[], loader=loader, variable_manager=VariableManager())
    pm._variable_manager.set_play_context(pm)
    pm.add_tasks(load_list_of_roles(ds, pm.play, current_role_path=role_path, loader=loader))

    # Check that the correct plays were added to the Play context
    assert len(pm.block_list) == 1

    # Check that the correct roles were loaded
    assert len(pm.block_list[0].roles)

# Generated at 2022-06-21 00:38:45.222638
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.template import Templar


# Generated at 2022-06-21 00:38:58.457166
# Unit test for function load_list_of_tasks

# Generated at 2022-06-21 00:38:59.274434
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # TODO: implement unit test
    pass


# Generated at 2022-06-21 00:39:12.325777
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ds = [
        {
            'name': 'test',
            'scm': 'git'
        },
        {
            'name': 'batman',
            'scm': 'git',
            'version': 'v0.9.1',
            'src': 'git@github.com:pcthingz/ansible-role-batman.git',
            'vars': {
                'bat_man': 'Batman'
            }
        },
        {
            'name': 'batman',
            'vars': {
                'bat_man': 'Bruce',
                'bat_cave': 'Wayne Manor'
            },
            'tasks': ['test.yml']
        }
    ]

    from ansible.plugins.loader import role_loader
    role_cache = role_loader._role

# Generated at 2022-06-21 00:39:23.542972
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.playbook import Playbook

    dummy_file = '''
    - name: test play
      hosts: localhost
      roles:
        - geerlingguy.mysql
        - role2
    '''

    dummy_playbook = Playbook()
    variables = VariableManager()

    ret = dummy_playbook.load(dummy_file, loader=DataLoader(), variable_manager=variables)
    play = next(ret.plays).serialize()

    root_dir = os.path.split(os.path.realpath(__file__))[0]


# Generated at 2022-06-21 00:39:25.056284
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # TODO: Mock objects
    pass


# Generated at 2022-06-21 00:39:33.506684
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as PlayObj
    from ansible.playbook.role import include
    ds_list=[]
    play=Play.load(ds_list,variable_manager=None, loader=None)
    ds_extra_attrs={}
    rolepath=''
    v_m=None
    l=None
    c_s=None
    list_of_roles=load_list_of_roles(ds_list,play, rolepath,v_m,l,c_s)
    assert list_of_roles == []
    #when ds is a non list

    ds_list=None

# Generated at 2022-06-21 00:41:19.450940
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    my_play = {}
    my_play['play'] = {'hosts': ['host1', 'host2', 'host3'], 'gather_facts': 'no', 'roles': []}
    play = Play().load(my_play, variable_manager=None, loader=None)
    # load one static and one dynamic include for each type of include

# Generated at 2022-06-21 00:41:31.087960
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import copy
    import os
    import tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # build a simple test task
    test_task = dict(
        name='test',
        action='ping',
    )
    test_task['action'] = AnsibleUnsafeText(to_text(test_task['action'], errors='surrogate_then_replace'))
    test_task['name'] = AnsibleUn

# Generated at 2022-06-21 00:41:38.807353
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # check load_list_of_roles() to raise exception on None parameter
    try:
        load_list_of_roles(ds=None, play=None, current_role_path=None, variable_manager=None, loader=None, collection_search_list=None)
    except AnsibleAssertionError as e:
        assert e.message == 'ds () should be a list but was a <class \'NoneType\'>'
    else:
        assert False, "Failed to raise AnsibleAssertionError {0}".format("'ds () should be a list but was a <class \'NoneType\'>'")

    # check if load_list_of_roles() returns empty array on empty list

# Generated at 2022-06-21 00:41:40.157190
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    #TODO
    pass


# Generated at 2022-06-21 00:41:47.443967
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DictDataLoader({})
    variable_manager = VariableManager()
    play = dict(
        hosts='all',
        roles=[],
        role_paths=['some_role'],
        tasks=[],
    )
    play_context = PlayContext()
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=dict(vars=dict())))
    ds = [
        dict(role='foo.bar'),
        dict(role='myrole', static='yes'),
        dict(role='baz', static=False),
        dict(role='bob', static='no', bar='foo'),
    ]
   

# Generated at 2022-06-21 00:41:56.045867
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.playbook_executor import PlaybookExecutorOptions
    from ansible.executor.playbook_executor import PlaybookExecutorStats

# Generated at 2022-06-21 00:42:00.676901
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.loader import AnsibleLoader
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    import os

    ds = """
    - role1
    - role2
    """

    ds_loader = AnsibleLoader(ds, variable_manager=None)

    role1 = {
        'name': 'role1',
        'path': os.path.join(os.path.dirname(__file__), 'role1')
    }

# Generated at 2022-06-21 00:42:01.724424
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert False, 'Unit tests not implemented'

# Generated at 2022-06-21 00:42:14.131355
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    play_source = dict(
        name="Test Play",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='Hello World!')))
        ]
    )
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)